

# Generated at 2022-06-21 04:30:26.954168
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('test') == 'test'
    assert from_yaml('test: "string"') == {'test': 'string'}
    assert from_yaml('test: "string"\n') == {'test': 'string'}
    assert from_yaml('test: "string"\nstring') == {'test': 'string\nstring'}
    assert from_yaml('test: 3.14') == {'test': 3.14}
    assert from_yaml('test: {\n  key: value\n}') == {'test': {'key': 'value'}}
    assert from_yaml("""
    test:
      - a
      - b
    """) == {'test': ['a', 'b']}



# Generated at 2022-06-21 04:30:40.787985
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('string', 'string') == ['string']
    assert regex_findall('string', 'ring') == ['ring']
    assert regex_findall('string', '^s') == ['s']
    assert regex_findall('string', 's$') == ['s']
    assert regex_findall('string', '^s.*s$') == ['string']
    assert regex_findall('string', '[0-9]') == []
    assert regex_findall('string', '[0-9]', ignorecase=True) == []
    assert regex_findall('string', 'str') == ['str']
    #
    assert regex_findall('string\nanother', '^str') == ['str']

# Generated at 2022-06-21 04:30:53.845444
# Unit test for function combine
def test_combine():
    print(combine({'a': 'A'}, {'b': 'B'}))
    print(combine({'a': 'A'}, {'a': 'A'}))
    print(combine({}, {'a': 'A'}))
    print(combine({'a': 'A'}, {}, {'b': 'B'}))
    print(combine({'a': 'A'}, {'a': 'B'}, {'a': 'C'}))
    print(combine({'a': 'A'}, {'a': 'B'}, {'b': 'C'}))
    print(combine({'a': 'A'}, {'b': 'B'}, {'a': 'C'}))

# Generated at 2022-06-21 04:31:03.531374
# Unit test for function to_bool
def test_to_bool():
    '''
    Ensure function properly transform input to a boolean
    '''
    # no functions
    assert to_bool(1) is True
    assert to_bool('1') is True
    assert to_bool(0) is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool(None) is None

    # checks real boolean
    assert to_bool(True) is True
    assert to_bool(False) is False

    # ensure that comparisons are not false
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool(None) == None



# Generated at 2022-06-21 04:31:14.935458
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict(
        [{'key': 'foo', 'value': 'bar'},
         {'key': 'foobar', 'value': 'barbar'}]) == {
             'foo': 'bar',
             'foobar': 'barbar'}

    assert list_of_dict_key_value_elements_to_dict(
        [{'key': 'foo', 'value': 'bar'}]) == {
            'foo': 'bar'}



# Generated at 2022-06-21 04:31:23.533099
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('1,2,3', '[0-9]', '9') == '9,9,9'
    assert regex_replace('1,2,3', '[0-9]', '9', multiline=False) == '9,9,9'
    assert regex_replace('1,2,3', '[0-9]', '9', multiline=True) == '1,2,3'
    assert regex_replace('abc', '[a-z]', 'z') == 'zzz'
    assert regex_replace('ABC', '[a-z]', 'z') == 'ABC'
    assert regex_replace('ABC', '[a-z]', 'z', ignorecase=True) == 'zzz'



# Generated at 2022-06-21 04:31:32.406461
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'a': 'b'}) == '{\n    "a": "b"\n}'
    assert to_nice_json({'a': 'b'}, sort_keys=False) == '{\n    "a": "b"\n}'
    assert to_nice_json({'b': 'a'}, sort_keys=True) == '{\n    "b": "a"\n}'
    assert to_nice_json({'a': 'b', 'b': 'a'}, sort_keys=True) == '{\n    "a": "b",\n    "b": "a"\n}'

# Generated at 2022-06-21 04:31:36.792327
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('pi:3.14159') == 'f7a6a1db63c7b09d93d6ee766b24ddfab9ca743a'



# Generated at 2022-06-21 04:31:49.268909
# Unit test for function regex_search
def test_regex_search():
    # The following are all similar
    assert regex_search('value', '^val') == 'val'
    assert regex_search('value', '^val') == 'val'
    assert regex_search('value', '^val') == 'val'

    assert regex_search('value', '^val', '\\1') is None
    assert regex_search('value', '^val', '\\g<0>') == 'val'
    assert regex_search('value', '^val', '\\g<1>') is None
    assert regex_search('value', '^val', '\\g<1>', '\\g<0>') == ['', 'val']
    assert regex_search('value', '^val', '\\2', '\\1') is None

# Generated at 2022-06-21 04:32:00.390999
# Unit test for function ternary
def test_ternary():
    assert to_bool('1') == ternary('1', True, False)
    assert to_bool('') == ternary('', True, False)
    assert to_bool(1) == ternary(1, True, False)
    assert to_bool(0) == ternary(0, True, False)
    assert to_bool('1') == ternary('1', True, "0")
    assert to_bool('') == ternary('', True, "0")
    assert to_bool(1) == ternary(1, True, "0")
    assert to_bool(0) == ternary(0, True, "0")
    assert None == ternary(None, True, None, None)
    assert 'foo' == ternary('', True, 'foo', 'bar')



# Generated at 2022-06-21 04:32:06.960047
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2018-05-21 12:46:00') == datetime.datetime(2018, 5, 21, 12, 46)


# Generated at 2022-06-21 04:32:22.290920
# Unit test for function do_groupby
def test_do_groupby():
    # In this test, we are testing that the output of the filter does not have
    # any namedtuples, and that it has the correct number of elements.

    # Load test data (a list of hosts)
    import ansible.parsing.vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy

    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.inventory.host import Host

    # Create a list of Host() objects
    hosts = [
        Host(name='localhost', port=22),
        Host(name='foo', port=22),
        Host(name='bar', port=22)
    ]
    # Compile the Jinja2 Template
    j2_env

# Generated at 2022-06-21 04:32:30.438562
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('Můj oblíbený kafe se jmenuje Aviator.')) == 'Můj oblíbený kafe se jmenuje Aviator.'
    assert b64decode(b64encode('Můj oblíbený kafe se jmenuje Aviator.', encoding='iso-8859-1')) == 'Můj oblíbený kafe se jmenuje Aviator.'
    assert b64decode(b64encode('Můj oblíbený kafe se jmenuje Aviator.', encoding='utf-16')) == 'Můj oblíbený kafe se jmenuje Aviator.'

# Generated at 2022-06-21 04:32:35.000324
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('123') == 'MTIz'
    assert b64encode(u'123') == 'MTIz'
    assert b64encode('À') == 'w6g='
    assert b64encode(u'À') == 'w6g='


# Generated at 2022-06-21 04:32:40.853413
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foobar', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foobar', 'foobar', '\\g<0>') == 'foobar'
    assert regex_search('foo\nbar', '^bar', '\\g<0>', multiline=True) == 'bar'
    assert regex_search('foo\nBar', '^Bar', '\\g<0>', ignorecase=True) == 'Bar'
    assert regex_search('foo\nbar', 'o(.*)r', '\\g<1>', multiline=True) == 'oba'
    assert regex_search('foo\nBar', 'o(.*)r', '\\g<1>', ignorecase=True) == 'B'

# Generated at 2022-06-21 04:32:45.692799
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({"a": "1", "b": "2"}) == [{"key": "a", "value": "1"}, {"key": "b", "value": "2"}]



# Generated at 2022-06-21 04:32:50.925447
# Unit test for function combine
def test_combine():
    # test recursive merge
    dict1 = dict(a={'b': {'c': 1}}, d={'e': 'f'})
    dict2 = dict(a={'b': {'d': 2}}, g={'h': 'k'})
    expected_dict = dict(a={'b': {'c': 1, 'd': 2}}, d={'e': 'f'}, g={'h': 'k'})
    combined = combine(dict1, dict2, recursive=True)
    assert combined == expected_dict

    # test recursive merge with list merge
    dict1 = dict(a={'b': {'c': 1}}, d=[1, 2, 3], e=[4, 5, 6])

# Generated at 2022-06-21 04:33:02.453894
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert isinstance(from_yaml_all("--- "), list)
    assert from_yaml_all("--- ") == []
    assert isinstance(from_yaml_all(""), list)
    assert from_yaml_all("") == []
    assert isinstance(from_yaml_all("[]"), list)
    assert from_yaml_all("[]") == []
    assert isinstance(from_yaml_all(""), list)
    assert from_yaml_all("") == []
    assert isinstance(from_yaml_all("---\n- a\n- b"), list)
    assert from_yaml_all("---\n- a\n- b") == ['a', 'b']

# Generated at 2022-06-21 04:33:09.433953
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2017-09-22 07:56:52", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2017, 9, 22, 7, 56, 52)
    assert to_datetime("2017-01-01", "%Y-%m-%d") == datetime.datetime(2017, 1, 1, 0, 0)



# Generated at 2022-06-21 04:33:21.310445
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == "a: b\n"
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == "a: b\nc: d\n"
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': {}}, default_flow_style=False) == "a: b\nc: d\ne: {}\n"
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': {}, 'f': 'g'}, default_flow_style=False) == "a: b\nc: d\ne: {}\nf: g\n"



# Generated at 2022-06-21 04:33:45.944620
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("dGVzdA==") == "test"



# Generated at 2022-06-21 04:33:53.980879
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = "password"
    res = get_encrypted_password(password, hashtype='sha256')
    assert not res.startswith('$6$')
    res = get_encrypted_password(password, hashtype='sha256', salt=True)
    assert res.startswith('$5$')
    res = get_encrypted_password(password, hashtype='md5', salt=True)
    assert res.startswith('$1$')
    res = get_encrypted_password(password, hashtype='blowfish', salt=True)
    assert res.startswith('$2$')
    res = get_encrypted_password(password, hashtype='sha512', salt=True)
    assert res.startswith('$6$')


# Generated at 2022-06-21 04:34:00.141687
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all("---\n- b\n- c") == ['b', 'c']
    assert from_yaml_all("---\n- b\n- c\n---\n- d\n- e") == ['b', 'c', 'd', 'e']



# Generated at 2022-06-21 04:34:06.085640
# Unit test for function to_json
def test_to_json():
    from ansible.module_utils.common.collections import Mapping
    test_data = dict(a=1,b=2)
    assert isinstance(to_json(test_data), str)
    assert isinstance(to_json(dict()), str)
    assert isinstance(to_json(dict(a=Mapping())), str)
    assert isinstance(to_json([]), str)
    assert isinstance(to_json(123), str)
    assert isinstance(to_json('some string'), str)
    print('to_json is ok')


# Generated at 2022-06-21 04:34:08.726683
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2]') == [1, 2], 'from_yaml should load a yaml string'



# Generated at 2022-06-21 04:34:20.157143
# Unit test for function regex_search
def test_regex_search():
    value = 'This is a test'
    assert regex_search(value, r'is') == 'is'
    assert regex_search(value, r'is', '\\g<0>') == 'is'
    assert regex_search(value, r'(\w)', '\\g<1>') == 'T'
    assert regex_search(value, r'(\w)', '\\1') == 'T'
    assert regex_search(value, r'(\w)', '\\2') == None
    assert regex_search(value, r'(\w)', '\\g<3>') == None



# Generated at 2022-06-21 04:34:21.122804
# Unit test for function b64encode
def test_b64encode():
    assert 'VGFyYXJjbg==' == b64encode('Tararang')



# Generated at 2022-06-21 04:34:21.956784
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u'hello') == u'aGVsbG8='



# Generated at 2022-06-21 04:34:23.389174
# Unit test for function subelements
def test_subelements():
    import doctest

    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failure_count == 0


# Generated at 2022-06-21 04:34:28.340873
# Unit test for function from_yaml_all
def test_from_yaml_all():
    example = '''- 1
- 2
- 3
'''
    expected = [1, 2, 3]
    assert list(from_yaml_all(example)) == expected
# end unit test



# Generated at 2022-06-21 04:34:57.527219
# Unit test for function regex_findall
def test_regex_findall():
    value = "foo bar\n baz"
    assert regex_findall(value, "foo|bar", multiline=True) == [u'foo', u'bar']



# Generated at 2022-06-21 04:34:58.531022
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 04:34:59.982017
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:35:07.650534
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text', "Failed on style 'plain'"
    assert comment('text', style='plain') == '# text'
    assert comment('text', style='erlang') == '% text'
    assert comment(
        'multi\nline\ntext',
        newline='\r',
        style='c') == '// multi\r// line\r// text'
    assert comment('multi\nline\ntext', style='cblock') == '/*\n * multi\n * line\n * text\n */'
    assert comment('multi line and\ndecorated text\n', style='xml') == '<!--\n - multi line and\n - decorated text\n - \n-->'



# Generated at 2022-06-21 04:35:18.855832
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'



# Generated at 2022-06-21 04:35:22.179954
# Unit test for function regex_findall
def test_regex_findall():
    test_string = "Hello World, this is a number 12345 and also a number 67890"
    assert regex_findall(test_string, '\d{5}') == ['12345', '67890']


# Generated at 2022-06-21 04:35:34.357576
# Unit test for function combine
def test_combine():
    from ansible.parsing.yaml.objects import AnsibleSequence

    assert combine({'a': 'a', 'b': 'b'}, {'b': 'c', 'c': 'c'}) == {'a': 'a', 'b': 'c', 'c': 'c'}
    assert combine({'a': 'a', 'b': 'b'}, {'c': 'c'}) == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert combine({'a': 'a', 'b': 'b'}, {'c': 'c'}) == {'a': 'a', 'b': 'b', 'c': 'c'}

# Generated at 2022-06-21 04:35:49.354557
# Unit test for function do_groupby
def test_do_groupby():
    '''
    The do_groupby() wrapped above was designed to fix an issue
    with jinja2>=2.9.0,<2.9.5 where a namedtuple was returned, which
    prevented ansible.template.safe_eval.safe_eval from being able to parse
    and eval the data.
    '''
    from jinja2 import Environment
    import doctest

    # Test data set up
    env = Environment()
    env.filters['groupby'] = do_groupby

# Generated at 2022-06-21 04:36:02.452940
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y") == time.strftime("%Y")
    assert strftime("%Y", 0) == "1970"
    assert strftime("%Y", second=int(time.time())) == time.strftime("%Y")
    assert strftime("%Y%m%d%H%M%S") == time.strftime("%Y%m%d%H%M%S")
    assert strftime("%Y%m%d%H%M%S", 0) == "19700101000000"
    assert strftime("%Y%m%d%H%M%S", second=int(time.time())) == time.strftime("%Y%m%d%H%M%S")



# Generated at 2022-06-21 04:36:14.448502
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('hello world') == 'hello world'
    assert from_yaml({"foo": "bar"}) == {"foo": "bar"}
    assert from_yaml(42) == 42
    assert from_yaml(42.3) == 42.3
    assert from_yaml(True) is True
    assert from_yaml(False) is False
    assert from_yaml(None) is None
    assert from_yaml([1, 2, 3]) == [1,2,3]
    assert from_yaml(()  ) == ()
    assert type(from_yaml('42')) == int
    assert type(from_yaml('42.3')) == float


# Generated at 2022-06-21 04:36:37.891196
# Unit test for function flatten
def test_flatten():
    assert flatten(["foo", "bar", "baz"]) == ["foo", "bar", "baz"]
    assert flatten({"foo": "bar"}) == [{'foo': 'bar'}]
    assert flatten(["foo", {"bar": ["baz", "qux"]}], levels=1) == ['foo', {'bar': ['baz', 'qux']}]
    assert flatten(["foo", {"bar": ["baz", "qux"]}], levels=2) == ['foo', 'baz', 'qux']
    assert flatten(["foo", {"bar": ["baz", "qux"], "a": ["b", "c"]}], levels=1) == ['foo', {'bar': ['baz', 'qux'], 'a': ['b', 'c']}]

# Generated at 2022-06-21 04:36:44.853077
# Unit test for function mandatory
def test_mandatory():
    test_filter = {'val': 'foo'}
    assert mandatory(test_filter['val']) == 'foo'
    try:
        mandatory(test_filter['val2'])
    except AnsibleFilterError:
        pass
    except Exception as e:
        raise(e)
    else:
        assert False, 'Expected AnsibleFilterError'



# Generated at 2022-06-21 04:36:48.155749
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json([1,2,3]) == '[1, 2, 3]'
    assert to_nice_json({'foo': [1,2,3], 'bar': [4,5,6]}) == '{\n    "bar": [4, 5, 6],\n    "foo": [1, 2, 3]\n}'



# Generated at 2022-06-21 04:36:50.068223
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', '1388530800.48179') == '2014'



# Generated at 2022-06-21 04:36:52.093848
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}, default_flow_style=False) == u'{}\n...\n'



# Generated at 2022-06-21 04:37:01.620657
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [3]]) == [1, 2, 3]
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([[1], 2, 3]) == [1, 2, 3]
    assert flatten([[1], [[2, 3]], [4]]) == [1, 2, 3, 4]
    assert flatten([[[1], 2, 3]]) == [[1], 2, 3]
    assert flatten([[[1], 2, 3]], levels=1) == [1, 2, 3]
    assert flatten([[[1], 2, 3]], levels=2) == [1, 2, 3]

# Generated at 2022-06-21 04:37:06.730424
# Unit test for function fileglob
def test_fileglob():
    if not os.path.isfile('/opt/testfile'):
        os.mknod('/opt/testfile')
    if os.path.isfile('/opt/testfolder'):
        os.rmdir('/opt/testfolder')
    assert fileglob('/opt/test*') == ['/opt/testfile']



# Generated at 2022-06-21 04:37:14.096348
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    seed = 123456789
    r = Random(seed)
    result = randomize_list(mylist, seed)
    r.shuffle(mylist)
    assert mylist == result
    assert randomize_list(mylist, seed) == result



# Generated at 2022-06-21 04:37:21.214546
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = 'password'
    hashtype = 'sha256'
    salt = '$5$q7W9FvZP$'
    salt_size = 16
    rounds = 10000
    ident = '$5$'

    # Test default values
    assert get_encrypted_password(password) == get_encrypted_password(password, hashtype)
    assert get_encrypted_password(password) == get_encrypted_password(password, hashtype, ident='$1$')
    assert get_encrypted_password(password, hashtype) == get_encrypted_password(password, hashtype, ident='$1$')
    assert get_encrypted_password(password, hashtype) != get_encrypted_password(password, hashtype, salt=salt, ident='$1$')

    # Test function with default values and key salt_size
    # Default salt

# Generated at 2022-06-21 04:37:29.186800
# Unit test for function path_join
def test_path_join():
    assert path_join('foo') == 'foo'
    assert path_join(['foo', 'bar']) == 'foo/bar'
    assert path_join(['foo', 'bar', 'baz']) == 'foo/bar/baz'
    assert path_join(['foo', '', 'bar']) == 'foo/bar'
    assert path_join(['foo', '', 'bar', '/tmp/']) == 'foo/bar/tmp'
    assert path_join('/tmp/foo') == '/tmp/foo'


# Generated at 2022-06-21 04:38:06.074599
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('foobar', 'foo(b|a)r') == ['bar']
    assert regex_findall('foobarFOOBAR', 'foo(b|a)r', ignorecase=True) == ['bar', 'BAR']
    assert regex_findall('foobarFOOBAR', 'foo(b|a)r', ignorecase=False) == ['bar']
    assert regex_findall('foobarFOOBAR', 'foo(b|a)r', multiline=True) == ['bar', 'BAR']
    assert regex_findall('foobarfoobar', 'foo(b|a)r', multiline=True) == ['bar', 'bar']

# Generated at 2022-06-21 04:38:16.512923
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}, {'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert combine(
        {'a': 1},
        {'b': 2},
        {'c': 3},
        {'a': 2, 'b': 0},
        {'c': 1, 'd': 4},
    ) == {'a': 2, 'b': 0, 'c': 1, 'd': 4}
    assert combine({'a': {'b': {'c': 1}}}, {'a': {'b': {'d': 2}}}) == {'a': {'b': {'d': 2, 'c': 1}}}

# Generated at 2022-06-21 04:38:23.662411
# Unit test for function to_json
def test_to_json():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    def test(a, b):
        assert to_json(a) == to_text(b)
    test({"a": 1}, '{"a": 1}')
    test({"a": 1, "b": "c"}, '{"a": 1, "b": "c"}')
    test(AnsibleUnsafeText('{"a": 1}'), '{"a": 1}')



# Generated at 2022-06-21 04:38:36.254075
# Unit test for function subelements
def test_subelements():
    ''' Test the subelements function '''
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    obj = {"admin": {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}}
    subelements(obj, 'admin.groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

# Generated at 2022-06-21 04:38:40.652092
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'alpha': '1', 'beta': '2'}, default_flow_style=None) == '{alpha: 1, beta: 2}\n\n'

# Generated at 2022-06-21 04:38:49.839204
# Unit test for function randomize_list
def test_randomize_list():
    '''Test randomize_list'''
    class TestRandom(object):
        '''TestRandom'''
        def __init__(self):
            self.count = 0
            self.seed = 0
            self.value = []
        def shuffle(self, mylist):
            self.count += 1
            self.seed += 1
            self.value = mylist

    def assert_randomize_list(expected, seed, mylist):
        '''Assert Randomize List'''
        test_random.seed = seed
        result = randomize_list(mylist, seed=seed)
        assert result == expected
        assert test_random.seed == seed
        assert test_random.value == result
        assert test_random.count == 1

    test_random = TestRandom()
    # Test randomize_list with no seed
   

# Generated at 2022-06-21 04:38:53.565385
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({"foo": "bar", "spam": "eggs"}, default_flow_style=False) == """
foo: bar
spam: eggs
"""



# Generated at 2022-06-21 04:39:05.362951
# Unit test for function extract
def test_extract():
    src = dict(
        a=dict(
            b=dict(
                c=[
                    dict(d=1),
                    dict(d=2),
                ]
            ),
        ),
        x=1,
    )
    assert extract('x', src) == 1
    assert extract('a', src) == dict(b=dict(c=[dict(d=1), dict(d=2)]))
    assert extract('b', src['a']) == dict(c=[dict(d=1), dict(d=2)])
    assert extract('c', src['a']['b']) == [dict(d=1), dict(d=2)]
    assert extract('c', src, 'a') == [dict(d=1), dict(d=2)]

# Generated at 2022-06-21 04:39:08.370768
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-01-01T00:00:00") == datetime.datetime(2018,1,1)
    assert to_datetime("2018-01-01T00:00:00Z") == datetime.datetime(2018,1,1)


# Generated at 2022-06-21 04:39:09.464279
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-21 04:39:41.667890
# Unit test for function ternary
def test_ternary():
    assert ternary(1, True, False) == True
    assert ternary(0, True, False) == False
    assert ternary(0, 2, 3) == 2
    assert ternary(None, 2, 3, 4) == 4


# Generated at 2022-06-21 04:39:50.351471
# Unit test for function regex_findall
def test_regex_findall():
    assert [], regex_findall(1, 1)
    assert [], regex_findall(None, 1)
    assert [], regex_findall("", "", "")
    assert ["a"], regex_findall("a", "a")
    assert ["a"], regex_findall("a", "a", ignorecase=True)
    assert ["a", "A"], regex_findall("aA", "a", ignorecase=False)
    assert ["a", "A"], regex_findall("aA", "a", ignorecase=True)
    assert ["a", "A", "a", "A"], regex_findall("aAbBaA", "a", ignorecase=False)
    assert ["a", "A", "a", "A"], regex_findall("aAbBaA", "a", ignorecase=True)

