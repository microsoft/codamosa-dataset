

# Generated at 2022-06-21 04:30:27.604887
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({'x': 1}) == {'x': 1}
    assert combine({'x': 1}, {'x': 2}) == {'x': 2}
    assert combine({'x': 1}, {'y': 2}) == {'x': 1, 'y': 2}
    assert combine({'x': 1}, {'x': 2}, {'x': 3}) == {'x': 3}
    assert combine({'x': 1}, {'x': 2}, {'x': 3}, {'x': 4}) == {'x': 4}
    assert combine({'x': 1}, {'x': 2}, {'x': 3}, {'x': 4}, {'x': 5}) == {'x': 5}

# Generated at 2022-06-21 04:30:35.084251
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'key1': 'value1', 'key2': 'value2'}) == [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}]
    assert dict_to_list_of_dict_key_value_elements({'key1': 'value1'}, value_name='val') == [{'key': 'key1', 'val': 'value1'}]



# Generated at 2022-06-21 04:30:48.277718
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, 3, 4, 5, 6], levels=2) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=1) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=0) == [1, 2, [3, 4, [5, 6]]]

# Generated at 2022-06-21 04:30:59.428198
# Unit test for function b64decode
def test_b64decode():
    assert b64decode.__name__ == 'b64decode'
    assert b64decode('Zm9vZGVjdmVuaXRpZW5jeS4=', encoding='utf-16') == u'foodecvenitiencȳ.'
    assert b64decode('aHR0cHM6Ly95YW5nY2h1Lm5ldC9leHBlcnRvaXM=') == u'https://yangchu.net/expertois'

# Generated at 2022-06-21 04:31:02.373094
# Unit test for function quote
def test_quote():
    assert quote('foo bar') == '\'foo bar\'', "quote failed"
    assert quote('"') == '\'"\'', "quote failed"



# Generated at 2022-06-21 04:31:05.854529
# Unit test for function fileglob
def test_fileglob():
    assert ['/tmp/1'] == fileglob("/tmp/1")
    assert [] == fileglob("/tmp/1", "/not/tmp/2")
    assert ['/tmp/2'] == fileglob("/tmp/1", "/tmp/2")



# Generated at 2022-06-21 04:31:18.225543
# Unit test for function mandatory
def test_mandatory():
    env = DummyEnvironment([], None)

    # Test the object itself with the normal message
    obj = env.undefined('obj')
    assert obj is not None
    try:
        mandatory(obj)
        raise Exception("mandatory() did not fail when it should have")
    except AnsibleFilterError as e:
        assert "Mandatory variable 'obj' not defined." == to_text(e)

    # Test with a custom message
    try:
        mandatory(obj, "Hello, world!")
        raise Exception("mandatory() did not fail when it should have")
    except AnsibleFilterError as e:
        assert "Hello, world!" == to_text(e)

    # Test a string argument

# Generated at 2022-06-21 04:31:29.349802
# Unit test for function to_json
def test_to_json():
    ''' Unit test for function to_json '''
    from ansible import context
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-21 04:31:31.977545
# Unit test for function to_json
def test_to_json():
    assert to_json({'name': 'tom'}) == '{"name": "tom"}'


# Generated at 2022-06-21 04:31:37.237054
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    data = [{'key': 'a', 'value': 'A'}, {'key': 'b', 'value': 'B'}]
    assert list_of_dict_key_value_elements_to_dict(data) == dict(a='A', b='B')



# Generated at 2022-06-21 04:31:52.007611
# Unit test for function comment

# Generated at 2022-06-21 04:31:57.599415
# Unit test for function comment
def test_comment():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestComment(unittest.TestCase):
        @patch('ansible.utils.comment.to_native')
        def test_comment_plain(self, mock_to_native):
            mock_to_native.return_value = "passed text"
            result = comment("passed text")
            self.assertEqual(result, '# passed text')
            mock_to_native.return_value = "#passed text"
            result = comment("#passed text")
            self.assertEqual(result, '# #passed text')
            result = comment("passed text", decoration='@ ')
            self.assertEqual(result, '@ passed text')

# Generated at 2022-06-21 04:32:01.367812
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("YXNpYW4=\n") == u'ansible'
    assert b64decode("YXNpYW4=\n".encode('utf-8')) == u'ansible'
    assert b64decode("YXNpYW4=\n", encoding='utf-8') == u'ansible'


# Generated at 2022-06-21 04:32:04.171457
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [ { 'key': 'k1', 'value': 'v1' }, { 'key': 'k2', 'value': 'v2' } ]
    mydict = list_of_dict_key_value_elements_to_dict(mylist)
    assert mydict['k1'] == 'v1'
    assert mydict['k2'] == 'v2'


# Generated at 2022-06-21 04:32:11.915862
# Unit test for function to_json
def test_to_json():
    assert to_json(True) == "true"
    assert to_json(False) == "false"
    assert to_json(None) == "null"
    assert to_json({}) == "{}"
    assert to_json(set()) == "[]"
    assert to_json(["foo", "bar"]) == "[\"foo\",\"bar\"]"
    assert to_json(["foo", {"bar": "baz"}]) == "[\"foo\",{\"bar\":\"baz\"}]"
    assert to_json({"foo": "bar"}) == "{\"foo\":\"bar\"}"
    assert to_json({"foo": {"bar": "baz"}}) == "{\"foo\":{\"bar\":\"baz\"}}"
    # Sizes will change depending on environment (eg 32/64 bit).

# Generated at 2022-06-21 04:32:13.793696
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('any carnal pleasur') == 'YW55IGNhcm5hbCBwbGVhc3Vy'



# Generated at 2022-06-21 04:32:14.969457
# Unit test for function b64decode
def test_b64decode():
    # The expected result for the following test is "ansible"
    assert b64decode(b64encode('ansible')) == 'ansible'



# Generated at 2022-06-21 04:32:16.596062
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:32:23.017517
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'name':'Ansible', 'type':'Software', 'license':'GPL'}) == '''{
    "license": "GPL",
    "name": "Ansible",
    "type": "Software"
}'''


# Generated at 2022-06-21 04:32:33.063210
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    import yaml
    if PY3:
        basestring = str
        unicode = str

    # Test with ASCII string
    data1 = u'foo: bar\n'
    assert from_yaml(data1) == {u'foo': u'bar'}
    assert isinstance(from_yaml(data1)[u'foo'], unicode)
    assert isinstance(to_text(data1), unicode)

    # Test with ASCII string and custom string wrapper
    data1_custom = u'foo: bar\n'
    class nstr(str):
        pass
   

# Generated at 2022-06-21 04:32:41.660990
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'foo': 'bar', 'baz': 'qux'}
    result = dict_to_list_of_dict_key_value_elements(mydict)
    assert result == [{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'qux'}]

    mydict = {'foo': 'bar', 'baz': 'qux'}
    result = dict_to_list_of_dict_key_value_elements(mydict, 'name', 'value')
    assert result == [{'name': 'foo', 'value': 'bar'}, {'name': 'baz', 'value': 'qux'}]



# Generated at 2022-06-21 04:32:49.554157
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape("one two") == "one\\ two"
    assert regex_escape("one[two") == "one\\[two"
    assert regex_escape("one]two") == "one\\]two"
    assert regex_escape("one^two") == "one\\^two"
    assert regex_escape("one$two") == "one\\$two"
    assert regex_escape("one|two") == "one\\|two"
    assert regex_escape("one(two") == "one\\(two"
    assert regex_escape("one)two") == "one\\)two"
    assert regex_escape("one*two") == "one\\*two"
    assert regex_escape("one?two") == "one\\?two"
    assert regex_escape("one+two") == "one\\+two"
    assert regex

# Generated at 2022-06-21 04:33:00.624850
# Unit test for function to_uuid
def test_to_uuid():
    args = ['example.com',
            'example.com',
            {'namespace': uuid.UUID('361e6d51-faec-444a-9079-341386da8e2e')},
            {'namespace': uuid.UUID('361e6d51-faec-444a-9079-341386da8e2e')},
            {'namespace': '361e6d51-faec-444a-9079-341386da8e2e'},
            {'namespace': '361e6d51-faec-444a-9079-341386da8e2e'}]
    result = set(map(lambda x: to_uuid(*x), args))
    assert len(result) == len(args)
    # Check that

# Generated at 2022-06-21 04:33:11.032333
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abcdef', 'bcd', 'BLAM') == 'aBLAMef'
    assert regex_replace('abcdef', 'x+') == 'abcdef'
    assert regex_replace('abcdef', 'x+', replacement='blah') == 'abcdef'
    assert regex_replace('abcdef', pattern='(bc)(d).*?(e)', replacement='blah') == 'ablahf'
    assert regex_replace('abcdef', pattern='(bc)(d).*?(e)', replacement='blah', ignorecase=True) == 'ablahf'
    assert regex_replace('abcdef', pattern='(BC)(D).*?(E)', replacement='blah', ignorecase=False) == 'abcdef'

# Generated at 2022-06-21 04:33:13.604427
# Unit test for function regex_replace
def test_regex_replace():
    assert "abef" == regex_replace(value='abcdef', pattern='cd', replacement='ef')


# Generated at 2022-06-21 04:33:15.651949
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:33:27.485270
# Unit test for function randomize_list
def test_randomize_list():
    # The test should pass for the following example
    mylist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    seed = 54321
    r = Random(seed)
    shuffled_list = randomize_list(mylist, seed)
    assert(shuffled_list == [2, 3, 8, 7, 10, 6, 9, 1, 5, 4])

    no_seed_list = randomize_list(mylist)
    assert(no_seed_list != mylist)
    shuffled_list = randomize_list(mylist, seed)
    assert(shuffled_list == [2, 3, 8, 7, 10, 6, 9, 1, 5, 4])



# Generated at 2022-06-21 04:33:29.066915
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 04:33:32.957957
# Unit test for function regex_replace
def test_regex_replace():
    result = regex_replace(value='Ansible', pattern='ansible', replacement='ANSIBLE', ignorecase=True)
    assert result == 'ANSIBLE'



# Generated at 2022-06-21 04:33:34.458474
# Unit test for function b64encode
def test_b64encode():
    string = "ansible"
    assert b64encode(string) == "YW5zaWJsZQ=="



# Generated at 2022-06-21 04:33:51.732793
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{"key": "one", "value": 1}, {"key": "two", "value": 2}]) == {"one": 1, "two": 2}
    assert list_of_dict_key_value_elements_to_dict([{"one": 1}, {"two": 2}], key_name="one", value_name="two") == {"1": 2}
    assert list_of_dict_key_value_elements_to_dict([{"one": 1}, {"two": 2}], key_name="two", value_name="two") == {"2": 2}

# Generated at 2022-06-21 04:34:03.758906
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    '''Test for dict_to_list_of_dict_key_value_elements'''
    data = {'one': 1, 'two': 2, 'three': 3}
    assert dict_to_list_of_dict_key_value_elements(data) == [
        {'key': 'one', 'value': 1},
        {'key': 'two', 'value': 2},
        {'key': 'three', 'value': 3}
    ]
    assert dict_to_list_of_dict_key_value_elements(data, key_name='aaa', value_name='bbb') == [
        {'aaa': 'one', 'bbb': 1},
        {'aaa': 'two', 'bbb': 2},
        {'aaa': 'three', 'bbb': 3}
    ]
   

# Generated at 2022-06-21 04:34:14.097183
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'key': 'value'}) == 'key: value\n'
    assert to_nice_yaml({'key': 'value', 'key2': 'value2'}) == 'key: value\nkey2: value2\n'
    assert to_nice_yaml({'key': 'value', 'key2': 'value2', 'key3': 'value3'}) == 'key: value\nkey2: value2\nkey3: value3\n'
    assert to_nice_yaml({'key': 'value', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}) == 'key: value\nkey2: value2\nkey3: value3\nkey4: value4\n'

# Generated at 2022-06-21 04:34:22.762785
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=vars_manager, host_list='localhost,')
    hosts = inventory.get_hosts()
    variable_manager = VariableManager(loader=loader, inventory=inventory)


    if __name__ == "__main__":
        from ansible.module_utils.basic import AnsibleModule
        m = AnsibleModule(argument_spec=dict(
            value=dict(type='str', required=True),
        ), supports_check_mode=True)
        print(m.params['value'])

# Generated at 2022-06-21 04:34:26.520416
# Unit test for function comment
def test_comment():
    text = "Text to comment"
    passed = 1
    passed *= (comment(text, 'plain') == '# Text to comment')
    passed *= (comment(text, 'erlang', prefix='%%') == '%%% Text to comment')
    passed *= (comment(text, 'c', decoration='/* ') == '// /* Text to comment')
    passed *= (comment(text, 'cblock') == '/*\n * Text to comment\n */')
    passed *= (comment(text, 'xml', prefix='<!-- - ', decoration=' ', end='') == '<!-- - Text to comment')
    if not passed:
        raise AssertionError
test_comment()



# Generated at 2022-06-21 04:34:37.940450
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({}, 'key', 'value') == []
    assert dict_to_list_of_dict_key_value_elements({'a': '1', 'b': '2'}, 'key', 'value') == [{'key': 'a', 'value': '1'}, {'key': 'b', 'value': '2'}]
    assert dict_to_list_of_dict_key_value_elements({'a': '1', 'b': '2'}, 'key', 1) == [{'key': 'a', 1: '1'}, {'key': 'b', 1: '2'}]

# Generated at 2022-06-21 04:34:44.224710
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(None, 1, 2, 3) == 3
    assert ternary('', 1, 2) == 2
    assert ternary('f', 1, 2) == 1
    assert ternary('foobar', 1, 2) == 1
    assert ternary(0, 1, 2) == 2
    assert ternary(1, 1, 2) == 1
    assert ternary(-1, 1, 2) == 1



# Generated at 2022-06-21 04:34:54.945119
# Unit test for function rand
def test_rand():
    assert rand(end=0) == 0
    # Test random step
    assert rand(end=10, step=2) in [0,2,4,6,8]
    # Test random with float

# Generated at 2022-06-21 04:35:05.542834
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote(u'foo') == u"foo"
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote(u'foo"bar') == u'"foo\\"bar"'
    assert quote(u'foo\\bar') == u"'foo\\\\bar'"
    assert quote(u'foo^bar') == u"'foo^bar'"
    assert quote(u'foo$bar') == u"'foo$bar'"
    assert quote(u'foo(bar)') == u"'foo(bar)'"
    assert quote(u'foo`bar`') == u'"foo`bar`"'
    assert quote(u'foo\nbar') == u"'foo\\nbar'"



# Generated at 2022-06-21 04:35:12.870237
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'a', 'b') == 'a'
    assert ternary(0, 'a', 'b') == 'b'

    assert ternary(None, 'a', 'b', 'c') == 'c'
    assert ternary(False, 'a', 'b', 'c') == 'b'
    assert ternary(True, 'a', 'b', 'c') == 'a'


# Generated at 2022-06-21 04:35:18.750520
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    got = get_encrypted_password("plainpass", hashtype='sha256', salt_size=16, rounds=2048)
    assert got.startswith("$5$rounds=2048$")
    assert len(got.split("$")[2]) == 16



# Generated at 2022-06-21 04:35:21.403566
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/etc/*") == ['/etc/locale.alias', '/etc/mime.types']



# Generated at 2022-06-21 04:35:26.258070
# Unit test for function quote
def test_quote():
    assert quote(None) == u''
    assert quote('') == u''
    assert quote('a') == u'a'



# Generated at 2022-06-21 04:35:37.787686
# Unit test for function flatten

# Generated at 2022-06-21 04:35:41.488213
# Unit test for function fileglob
def test_fileglob():
    fn = fileglob("/test/test.txt")
    assert fn[0] == "test.txt"


# Generated at 2022-06-21 04:35:47.870426
# Unit test for function regex_replace
def test_regex_replace():
    failed = False
    # simple example replacing a string
    if regex_replace('hello', 'll', 'xx') != 'hexxo':
        failed = True
    # replacement string can be the empty string
    if regex_replace('hello', 'll', '') != 'heo':
        failed = True
    # when pattern is not found the original string is returned
    if regex_replace('hello', 'xx', '') != 'hello':
        failed = True
    if failed:
        raise AnsibleFilterError('regex_replace failed unit tests')



# Generated at 2022-06-21 04:35:53.707736
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2014-01-18 19:15:41") == datetime.datetime(2014, 1, 18, 19, 15, 41)
    assert to_datetime("2014-01-18 19:15:41", format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2014, 1, 18, 19, 15, 41)
    assert to_datetime("2014-01-18 19:15:41", format="%Y-%m-%d") == datetime.datetime(2014, 1, 18, 0, 0)



# Generated at 2022-06-21 04:36:01.802522
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("c3VyZmFjZW1lbnRv") == "superficmento"
    assert b64decode("IUAjJCVeJiMlXiYjJSXiJiMlXiYjJSMh") == "H@C%V^B^CV^BCV^BCR!"



# Generated at 2022-06-21 04:36:14.109662
# Unit test for function from_yaml_all
def test_from_yaml_all():
    import yaml

    yaml_map = {'a': 'A', 'b': 'B', 'c': 'C'}
    yaml_list = [yaml_map, yaml_map, yaml_map]
    yaml_data = yaml.dump(yaml_list)

    yaml_list_copy = from_yaml_all(yaml_data)
    assert len(yaml_list_copy) == 3
    assert yaml_list_copy[0] == yaml_list[0]
    assert yaml_list_copy[1] == yaml_list[1]
    assert yaml_list_copy[2] == yaml_list[2]



# Generated at 2022-06-21 04:36:23.766200
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(
        a=5,
        b=dict(
            c="asdf",
            d=["hjkl", dict(e="qwert")]
        )
    )) == "a: 5\n"\
          "b:\n"\
          "  c: asdf\n"\
          "  d:\n"\
          "  - hjkl\n"\
          "  - e: qwert\n"



# Generated at 2022-06-21 04:36:38.198253
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('foo and bar', 'foo(.*)bar') == [' and ']


# Generated at 2022-06-21 04:36:44.323863
# Unit test for function to_bool
def test_to_bool():
    """
    Test for to_bool utility function.
    """
    # There are some converion path that would fail, but we give up on them
    # rather than throw an exception
    assert to_bool("1") is True
    assert to_bool("") is False
    assert to_bool("False") is False



# Generated at 2022-06-21 04:36:55.891565
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'hello', u'h$', u'H') == u'Hello'
    assert regex_replace(u'hello world', u'^.*?(\w+) (\w+)', u'\\2 \\1', multiline=True) == u'world hello'
    assert regex_replace(u'hello', u'[hx]', u'H', ignorecase=True) == u'Hello'
    assert regex_replace(u'hello', u'l[lt]', u'm') == u'hemmo'
    assert regex_replace(u'hello', u'l[^lo]', u'm') == u'hello'
    assert regex_replace(u'hello', u'l([^l]|$)', u'm') == u'hellmo'

# Generated at 2022-06-21 04:37:08.469303
# Unit test for function fileglob
def test_fileglob():
    files = ['one.txt', 'two', 'three']
    dirname = '/tmp/test_fileglob_%s' % time.time()
    for f in files:
        fd = open(os.path.join(dirname, f), 'w')
        fd.write('empty\n')
        fd.close()
    assert sorted(fileglob('%s/*' % dirname)) == sorted([os.path.join(dirname, f) for f in files])
    assert sorted(fileglob('%s/t*' % dirname)) == sorted([os.path.join(dirname, f) for f in files[-2:]])
    assert fileglob('%s/none' % dirname) == []
    assert fileglob('%s/*.xxx' % dirname) == []


# Generated at 2022-06-21 04:37:10.188068
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u"\u00A3123",u"\u00A3(.*)",u"#\\1") == u'#123'

# Generated at 2022-06-21 04:37:15.148356
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(None, 1, 2, 3) == 3


# Generated at 2022-06-21 04:37:25.833430
# Unit test for function combine
def test_combine():
    '''
    Test the combine function
    '''
    test_dicts = {
        u'a': 1,
        u'b': 2,
        u'c': {
            u'c1': {
                u'c11': 121,
                u'c12': 122
            },
            u'c2': {
                u'c21': 221,
                u'c22': 222
            }
        }
    }


# Generated at 2022-06-21 04:37:27.603275
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory('foo', msg="This is foo") == 'foo'



# Generated at 2022-06-21 04:37:42.833581
# Unit test for function regex_search
def test_regex_search():
  assert regex_search(value="foo", regex="foo") == "foo"
  assert regex_search(value="foo", regex="foo", ignorecase=True) == "foo"
  assert regex_search(value="foo", regex="foo", multiline=True) == "foo"
  assert regex_search(value="foo", regex="foo", ignorecase=True, multiline=True) == "foo"
  assert regex_search(value="boo", regex="foo", ignorecase=True, multiline=True) == "boo"
  assert regex_search(value="foo", regex="foo", ignorecase=True, multiline=True, nocapture=True) == "foo"

# Generated at 2022-06-21 04:37:47.297676
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True)
    assert to_bool('yes')
    assert not to_bool(False)
    assert not to_bool('no')
    assert not to_bool('foobar')



# Generated at 2022-06-21 04:38:04.125028
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='(a)', replacement='a') == 'abcd'
    assert regex_replace(value='abcd', pattern='(a)', replacement='a', ignorecase=True) == 'aBCD'
    assert regex_replace(value='abcd', pattern='(A)', replacement='a', ignorecase=True) == 'aBCD'
    assert regex_replace(value='abcd', pattern='(a)', replacement='a', multiline=True) == 'abcd'
    assert regex_replace(value='abcd\n', pattern='(a)', replacement='a', multiline=True) == 'abcd\n'
    assert regex_replace(value='abcd\n', pattern='(a)', replacement='a', multiline=False) == 'abcd\n'

# Generated at 2022-06-21 04:38:10.038215
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subele = 'groups'
    assert subelements(obj, subele) == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-21 04:38:23.117102
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    # jinja2 overrides
    assert filters['groupby'] == do_groupby

    # base 64
    assert filters['b64decode'] == b64decode
    assert filters['b64encode'] == b64encode

    # uuid
    assert filters['to_uuid'] == to_uuid

    # json
    assert filters['to_json'] == to_json
    assert filters['to_nice_json'] == to_nice_json
    assert filters['from_json'] == json.loads

    # yaml
    assert filters['to_yaml'] == to_yaml
    assert filters['to_nice_yaml'] == to_nice_yaml
    assert filters['from_yaml'] == from_yaml

# Generated at 2022-06-21 04:38:38.080871
# Unit test for function comment
def test_comment():
    p = {
        'beginning': '/*',
        'decoration': ' * ',
        'prefix': ' * ',
        'prefix_count': 1,
        'postfix': ' * ',
        'postfix_count': 1,
        'end': ' */'
    }
    assert comment('comment text', style='cblock') == "%(beginning)s%(prefix)s%(decoration)s%(decoration)scomment text%(decoration)s%(postfix)s%(end)s" % p
    assert comment('comment text', style='cblock', newline='\r\n') == "%(beginning)s%(prefix)s%(decoration)s%(decoration)scomment text%(decoration)s%(postfix)s%(end)s" % p
    assert comment

# Generated at 2022-06-21 04:38:44.885468
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value="", pattern="") == ""
    assert regex_replace(value="Hello World", pattern=" ") == "HelloWorld"
    assert regex_replace(value="Hello World,World Again ", pattern="World", replacement="World") == "Hello World,World Again "
    assert regex_replace(value="Hello World,World Again ", pattern="World", replacement="Planet") == "Hello Planet,Planet Again "
    assert regex_replace(value="Hello World", pattern="World", replacement="Planet", ignorecase=True) == "Hello Planet"
    assert regex_replace(value="Hello World", pattern="World", replacement="Planet", ignorecase=False) == "Hello Planet"



# Generated at 2022-06-21 04:38:53.551227
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool('true') == True
    assert to_bool('True') == True
    assert to_bool('TRUE') == True
    assert to_bool('1') == True
    assert to_bool('yes') == True
    assert to_bool('on') == True
    assert to_bool(False) == False
    assert to_bool('false') == False
    assert to_bool('no') == False
    assert to_bool('off') == False
    assert to_bool('0') == False



# Generated at 2022-06-21 04:39:06.467228
# Unit test for function do_groupby
def test_do_groupby():
    import itertools
    import ansible.template.jinja2
    from ansible.template.jinja2 import AnsibleEnvironment
    from ansible.template.jinja2 import AnsibleUndefined
    from ansible.template.jinja2 import AnsibleUndefinedVariableError
    jinja_context = {'inventory_hostname': 'foo'}
    jinja_env = AnsibleEnvironment(loader=DictLoader({'foo': '{{ foo }}'}), undefined=AnsibleUndefined)


# Generated at 2022-06-21 04:39:17.233677
# Unit test for function rand
def test_rand():
    r1 = rand(list(range(10)), seed=1)
    r2 = rand(list(range(10)), seed=1)
    assert r1 == r2
    assert rand(list(range(10)), seed=1) != rand(list(range(10)), seed=2)
    assert rand(list(range(10)), seed=2) != rand(list(range(10)), seed=1)
    assert rand(list(range(10)), seed=1) != rand(list(range(10)), seed=3)
    assert rand(list(range(10)), seed=2) != rand(list(range(10)), seed=3)
    assert rand(0, 2, 4, seed=1) == 4
    assert rand(0, 2, 4, seed=2) == 0

# Generated at 2022-06-21 04:39:26.625154
# Unit test for function rand
def test_rand():
    rand_tests = (
        # returns int
        ((10,), '[0:10:1]'),
        ((0, 10), '[0:10:1]'),
        ((10, 20), '[10:20:1]'),
        ((10, 20, 2), '[10:20:2]'),
        # returns choice
        (('abc',), 'abc'),
        (('abc', 'def'), 'abc|def'),
        ((['abc', 'def'],), 'abc|def'),
        (((x for x in ['abc', 'def']),), 'abc|def'),
        (([],), []),
    )

    f = rand
    env = {}
    for args, result in rand_tests:
        assert f(env, *args)
        assert f(env, *args) in result.split('|')
#

# Generated at 2022-06-21 04:39:30.174549
# Unit test for function to_uuid
def test_to_uuid():
    x = to_uuid('test123')
    assert(x == '361e6d51-fae6-5025-b066-f451d25f7d21')



# Generated at 2022-06-21 04:39:44.966160
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    def assert_invalid(data):
        try:
            from_yaml(data)
        except Exception:
            return
        assert False, 'Data should be invalid: %r' % data

    assert isinstance(from_yaml(''), type(None))
    assert isinstance(from_yaml('""'), string_types)
    assert '\n' in from_yaml('|\n hello\n')
    assert '\n' in from_yaml('>\n hello\n')
    assert_invalid('hello')

    # yaml_load and yaml_load_all are tested by aJSON tests

# Generated at 2022-06-21 04:39:50.345750
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert list(from_yaml_all("""
    - { foo: 1, bar: 2 }
    - { foo: 3, bar: 4 }
    """)) == [{'foo': 1, 'bar': 2}, {'foo': 3, 'bar': 4}]



# Generated at 2022-06-21 04:40:03.789700
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert isinstance(from_yaml_all("a: 1\nb: 2\n"), list)
    assert len(from_yaml_all("a: 1\nb: 2\n")) == 2
    assert isinstance(from_yaml_all("a: 1\nb: 2\n")[0], dict)
    assert len(from_yaml_all("a: 1\nb: 2\n")[0]) == 1
    assert from_yaml_all("a: 1\nb: 2\n")[0]['a'] == 1
    assert isinstance(from_yaml_all("a: 1\nb: 2\n")[1], dict)
    assert len(from_yaml_all("a: 1\nb: 2\n")[1]) == 1