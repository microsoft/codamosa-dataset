

# Generated at 2022-06-21 04:30:13.259215
# Unit test for function fileglob
def test_fileglob():
    paths = ['./test/test.txt', './test/test.cfg']
    pathnames = ['/path/to/file/*.txt', './test/*.cfg']
    result = []
    for path in pathnames:
        result.append(fileglob(path))
    assert result == paths

#------------------------------------------------------------------------------
# Hashes
#------------------------------------------------------------------------------

# Generated at 2022-06-21 04:30:23.572271
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    data = {
        "test": {
            "test1": [
                1,
                2,
                3
            ],
            "test2": {
                "test3": 2
            }
        }
    }

    data_str = '''
{
    "test": {
        "test1": [
            1,
            2,
            3
        ],
        "test2": {
            "test3": 2
        }
    }
}
'''
    assert to_nice_yaml(data) == data_str
# END

# Generated at 2022-06-21 04:30:32.618452
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    func = globals()['get_encrypted_password']
    # Test for password 'ansible'
    # Expected output for blowfish hash
    expected = '$2b$06$T9R9Y/ZPIbKm8hcgFUBtC.rHrq3tVxKtEQHLYVF5ZlQ5N5E5vfKjG'
    result = func(password='ansible', hashtype='blowfish', salt_size=22)
    assert result == expected
    # Test for password 'ansible'
    # Expected output for sha512 hash

# Generated at 2022-06-21 04:30:39.010270
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('foo', 'sha512', rounds=5000) == '$6$rounds=5000$/6aZiOmgZ0HtMd5I.$Mg1Lw5GAHJnQz0uVtr.B.SMq3V7ZcxCbEe7a.Q2wvVhWLVCweaZrEjbHnLGJ9YhZiD1w8Ac2QoE.YSF18fOZp.'
    assert get_encrypted_password('foo', 'blowfish') == b'$2a$12$g7V0/oZP69qZhf5GzN7V2eRh.vnq3.W.U46d7nQxkD6HdxX6kMg6O'



# Generated at 2022-06-21 04:30:43.540042
# Unit test for function to_json
def test_to_json():
    assert to_json({'a': [1,2,3], 'b': {'c': 'd'}}) == '{"a": [1, 2, 3], "b": {"c": "d"}}'



# Generated at 2022-06-21 04:30:49.385030
# Unit test for function ternary
def test_ternary():
    assert ternary(0, 1, 2) == 2
    assert ternary(1, 2, 3) == 2
    assert ternary("a", "b", "c") == "b"
    assert ternary("", "b", "c") == "c"
    assert ternary([], "b", "c") == "b"
    assert ternary(None, "b", "c", "d") == "d"



# Generated at 2022-06-21 04:30:53.240615
# Unit test for function subelements
def test_subelements():
    try:
        obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
        result_filter = subelements(obj, 'groups')
        assert len(result_filter) == 1
        assert isinstance(result_filter[0], tuple)
        assert len(result_filter[0]) == 2
    except AssertionError as e:
        raise AssertionError(str(e))
    except Exception as e:
        raise AssertionError("Failed to parse subelements: (%s) %s" % (type(e), str(e)))



# Generated at 2022-06-21 04:30:59.481309
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten(['1', 2, [[3], 4], 'a'], levels=2) == ['1', 2, 3, 4, 'a']
    assert flatten([1, 2, [3, 4, [5, 6], 7], 8], levels=1) == [1, 2, 3, 4, [5, 6], 7, 8]
    assert flatten([1, 2, [3, 4, [5, 6], 7], 8], levels=2) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert flatten([1, 2, [[3, 4], [5, 6]], 7, 8], levels=2) == [1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-21 04:31:07.835276
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'true_val', 'false_val') == 'true_val'
    assert ternary(None, 'true_val', 'false_val') == 'false_val'
    assert ternary(0, 'true_val', 'false_val') == 'false_val'
    assert ternary(1, 'true_val', 'false_val', 'none_val') == 'true_val'
    assert ternary(None, 'true_val', 'false_val', 'none_val') == 'none_val'
    assert ternary(0, 'true_val', 'false_val', 'none_val') == 'none_val'



# Generated at 2022-06-21 04:31:12.516967
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo[bar]baz') == r'foo\[bar\]baz'
    assert regex_escape(r'foo[bar]baz', re_type='python') == r'foo\[bar\]baz'
    assert regex_escape(r'foo[bar]baz', re_type='posix_basic') == r'foo\[bar\]baz'



# Generated at 2022-06-21 04:31:26.863033
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2016-8-6 07:08:09", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2016, 8, 6, 7, 8, 9)


# Generated at 2022-06-21 04:31:42.408541
# Unit test for function from_yaml
def test_from_yaml():
    if sys.version_info < (2, 7):
        pass
        # some examples disabled for python 2.6, because these features
        # were not available in the supported version of PyYAML
    from ansible.compat.tests import unittest

    class FromYamlTest(unittest.TestCase):

        def test_none(self):
            self.assertTrue(from_yaml(None) is None)

        def test_boolean(self):
            self.assertTrue(from_yaml(True) is True)
            self.assertFalse(from_yaml(False))

        def test_integer(self):
            self.assertEqual(from_yaml(42), 42)

        def test_float(self):
            self.assertEqual(from_yaml(3.14), 3.14)



# Generated at 2022-06-21 04:31:54.598689
# Unit test for function ternary
def test_ternary():
    assert ternary(1, "yes", "no") == "yes"
    assert ternary(None, "yes", "no") == "no"
    assert ternary(None, "yes", "no", none_val="maybe") == "maybe"
    assert ternary(0, "yes", "no") == "no"
    assert ternary(0.0, "yes", "no") == "no"
    assert ternary(1.5, "yes", "no") == "yes"
    assert ternary(-1, "yes", "no") == "yes"
    assert ternary(15, "yes", "no") == "yes"
    assert ternary((), "yes", "no") == "no"
    assert ternary((0,), "yes", "no") == "yes"

# Generated at 2022-06-21 04:31:58.750052
# Unit test for function combine
def test_combine():
    # examples from the documentation
    assert combine({"a": "b"}, {"c": "d"}) == {"a": "b", "c": "d"}
    assert combine({"a": "b"}, {"a": {"c": "d"}}) == {"a": {"c": "d"}}
    assert combine({"a": {"c": "d"}}, {"a": "b"}) == {"a": {"c": "d"}}
    assert combine([{"a": "b"}, {"c": "d"}]) == {"a": "b", "c": "d"}
    assert combine([{"a": "b"}, {"a": {"c": "d"}}]) == {"a": {"c": "d"}}

# Generated at 2022-06-21 04:32:02.643189
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("aGVsbG8=", encoding="utf-8") == "hello"
    assert b64decode("aGVsbG8=", encoding="utf-16") == u"h\u0000e\u0000l\u0000l\u0000o\u0000"
    assert b64decode("aGVsbG8=", encoding="iso-8859-1") == to_text(b"hello")



# Generated at 2022-06-21 04:32:07.038994
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'



# Generated at 2022-06-21 04:32:09.548771
# Unit test for function strftime
def test_strftime():
    import doctest
    doctest.run_docstring_examples(strftime, globals())



# Generated at 2022-06-21 04:32:12.341085
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert hasattr(fm, 'filters')



# Generated at 2022-06-21 04:32:20.255176
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo 123 bar','bar') == 'bar'
    assert regex_search('foo 123 bar','(\d+)') == '123' # returns only the first match
    assert regex_search('foo 123 bar','(\d+)','\\g<1>') == ['123','123'] # returns all matches when references are used
    assert regex_search('foo 123 bar','(\d+)','\\1') == ['123','123'] # returns all matches when index references are used
    assert regex_search('foo 123 bar','(\d+)','\\g<1>','\\1') == ['123','123','123'] # returns all matches when both kind of references are used


# Generated at 2022-06-21 04:32:31.014397
# Unit test for function strftime
def test_strftime():
    from ansible.module_utils.six import PY2
    from datetime import datetime
    # Python 2 returns unicode string from strftime()
    if PY2:
        assert isinstance(strftime('%Y'), unicode)
    # ISO 8601 format
    assert strftime('%Y-%m-%dT%H:%M:%S') == datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    # String format
    assert strftime('%Y-%m-%d', 0) == datetime.fromtimestamp(0).strftime('%Y-%m-%d')
    # Epoch
    assert strftime('', 1) == datetime.fromtimestamp(1).strftime('')
    # Invalid value for `second`
   

# Generated at 2022-06-21 04:32:41.511953
# Unit test for function fileglob
def test_fileglob():
    from ansible.plugins.loader import find_filter_plugins
    find_filter_plugins()
    assert fileglob('/usr/bin/*') != []



# Generated at 2022-06-21 04:32:51.487918
# Unit test for function from_yaml
def test_from_yaml():
    # Get some test data
    from ansible.utils.jinja import TruthyUndefined
    class LocalLoader(object):
        def __init__(self, data):
            self.data = data
        def get_basedir(self):
            return '.'
        def load(self, *args, **kwargs):
            return self.data
    # Load yaml file
    nope_file = to_bytes('nope.yaml')
    loader = LocalLoader({
        nope_file: """---
# Note that this is a proper yaml file
not_a_boolean: yes
a_boolean: true
a_list: [a, b]
a_dict: {
  "b": {
    "a": 0
  }
}
"""})
    # Test that valid data is returned

# Generated at 2022-06-21 04:33:03.135285
# Unit test for function rand
def test_rand():
    import unittest
    class TestRand(unittest.TestCase):
        env = dict()
        maxDiff = None


# Generated at 2022-06-21 04:33:08.786481
# Unit test for function path_join
def test_path_join():
    assert path_join(['foo', 'bar']) == 'foo/bar'
    assert path_join(['foo', 'bar', 'baz']) == 'foo/bar/baz'
    assert path_join('foo') == 'foo'
    assert path_join('foo/bar') == 'foo/bar'
    assert path_join('foo/bar/baz') == 'foo/bar/baz'



# Generated at 2022-06-21 04:33:24.567823
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Jinja2Environment
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_env = Jinja2Environment(undefined=AnsibleUndefined, extensions=['jinja2.ext.do'])
    test_env.filters['groupby'] = do_groupby

    entries = [
        {'name': AnsibleUnsafeText('foo'), 'state': 'present'},
        {'name': AnsibleUnsafeText('bar'), 'state': 'absent'},
        {'name': AnsibleUnsafeText('baz'), 'state': 'present'}
    ]

    results = test_env.from_string('{{ entries|groupby("state") }}').render(entries=entries)
    # We must be able to eval the results, which was broken in jin

# Generated at 2022-06-21 04:33:34.025496
# Unit test for function regex_search

# Generated at 2022-06-21 04:33:40.059182
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(None) == None
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool('yes') == True
    assert to_bool('no') == False
    assert to_bool('on') == True
    assert to_bool('off') == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('y') == False
    assert to_bool('n') == False


# Generated at 2022-06-21 04:33:51.892840
# Unit test for function to_yaml
def test_to_yaml():
    from ansible.compat.tests import unittest
    import yaml

    class TestAnsibleYaml(unittest.TestCase):
        def test_basic_dict(self):
            test_dict = {'a': 'test1', 'b': 'test2'}
            expected = u"a: test1\nb: test2\n"
            real = to_yaml(test_dict)
            self.assertEqual(real, expected)
        def test_block_seq(self):
            test_list = ["one", "two one", {"one": "nested one"}]
            expected = u"""\
- one
- 'two one'
- one: nested one\n\n"""
            real = to_yaml(test_list, default_flow_style=False)
            self.assertEqual

# Generated at 2022-06-21 04:33:53.277398
# Unit test for function to_bool
def test_to_bool():
  assert to_bool('true')



# Generated at 2022-06-21 04:34:00.009902
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    template_str = '''
        {%- set test_var = 'test_ok' %}
        {{ test_var }}
        {% set test_var = mandatory() %}
        {{ test_var }}
    '''

    template_str2 = '''
        {% set test_var = mandatory() %}
        {{ test_var }}
    '''

    template_str3 = '''
        {% set test_var = mandatory("test_ko", msg="test_ko_msg") %}
    '''


# Generated at 2022-06-21 04:34:14.015513
# Unit test for function do_groupby
def test_do_groupby():
    '''Test do_groupby filter'''
    env = jinja2.Environment()
    env.globals.update(
        do_groupby=environmentfilter(do_groupby),
        groupby=environmentfilter(groupby),
    )

    # Test normal groupby

# Generated at 2022-06-21 04:34:24.950877
# Unit test for function rand
def test_rand():
    # test with a list
    assert rand(None, list(range(10))) in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # test with a tuple
    assert rand(None, tuple(range(10))) in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # test with a set
    assert rand(None, set(range(10))) in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # test with an integer
    assert rand(None, 10) in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # test with a range

# Generated at 2022-06-21 04:34:35.601998
# Unit test for function combine
def test_combine():
    dict1 = dict(a=1, b=20, c=3)
    dict2 = dict(b=200, d=4)
    dict3 = dict(a=300, e=5)
    dict4 = dict(g=6)
    dict5 = dict(h=7)

    assert combine(dict1, dict2) == dict(a=1, b=200, c=3, d=4)
    assert combine(dict1, dict2, dict3) == dict(a=300, b=200, c=3, d=4, e=5)
    assert combine(dict1, dict2, dict3) != combine(dict1, dict3, dict2)

# Generated at 2022-06-21 04:34:39.823729
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("hello") == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-21 04:34:46.153985
# Unit test for function quote
def test_quote():
    from ansible.compat.tests import unittest
    from ansible.modules.extras.tests.test_packaging import TestPackaging

    class TestMyQuote(TestPackaging):
        def call_quote(self, example, expected):
            result = quote(example)
            if result != expected:
                raise AssertionError
            return result


# Generated at 2022-06-21 04:35:00.065760
# Unit test for function regex_replace
def test_regex_replace():
    value = """
    foo
    FOO
    bar
    BAR
    """
    assert regex_replace(value, r'[fF]oo', 'baz') == 'baz\nbaz\nbar\nBAR\n'
    assert regex_replace(value, r'[fF]oo', 'baz', ignorecase=True) == 'baz\nbaz\nbar\nbar\n'
    assert regex_replace(value, r'^[fF]oo', 'baz', multiline=True) == 'baz\nFOO\nbar\nBAR\n'
    assert regex_replace(value, r'^[fF]oo', 'baz', ignorecase=True, multiline=True) == 'baz\nbaz\nbar\nbar\n'



# Generated at 2022-06-21 04:35:12.144240
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    # test input arguments
    ansible_inputs = [
        None,
        1,
        'str',
        [],
        ['str1', 'str2'],
        [1, 2],
        [{'key': 'key1'}, {'value': 'value1'}],
        [{'key': 'key1', 'value': 'value1', 'other_key': 'other_value1'}, {'key': 'key2', 'value': 'value2', 'other_key': 'other_value2'}],
    ]

# Generated at 2022-06-21 04:35:24.414116
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('', '', '') == ''
    assert regex_replace('', '', '', True, True) == ''
    assert regex_replace('', 'the', '') == ''
    assert regex_replace('', 'the', '', True, True) == ''
    assert regex_replace('', '', 'the') == ''
    assert regex_replace('', '', 'the', True, True) == ''
    assert regex_replace('a', '', '') == 'a'
    assert regex_replace('ab', 'a', '') == 'b'
    assert regex_replace('ab', 'b', 'bb') == 'abb'
    assert regex_replace('ab', 'b', 'bb', True) == 'abb'
    assert regex_replace('ab', 'b', 'bb', True, True) == 'abb'
   

# Generated at 2022-06-21 04:35:30.968207
# Unit test for function quote
def test_quote():
    assert quote(None) == ""
    assert quote("my \"arg\"") == "my \\\"arg\\\""
    assert quote("my 'arg'") == "'my '\\''arg'\\'''"
    assert quote("my \"arg\" is $foo") == "my \\\"arg\\\" is \\$foo"



# Generated at 2022-06-21 04:35:41.554614
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    data = {'a': 1, 'b': 2, 'c': 3}
    expected = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}]
    assert(dict_to_list_of_dict_key_value_elements(data) == expected)
    assert(dict_to_list_of_dict_key_value_elements(data, key_name='foo', value_name='bar') == [{'bar': 1, 'foo': 'a'}, {'bar': 2, 'foo': 'b'}, {'bar': 3, 'foo': 'c'}])
    assert(dict_to_list_of_dict_key_value_elements([]) == [])

# Generated at 2022-06-21 04:36:00.232300
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('mypassword') == '$6$rounds=3900$Q.9XOvJ/hSfS/tvy$QwKjgFVRhBJ4KK4zHDqvbdf9gjK3q3aNpJeqdMZw1Nn0.TQTmYF/jKzg9XyN0q3qpGqJ8sAvkLZcxTzT2YHGk/'
    assert get_encrypted_password('mypassword', 'md5') == '$1$e4uhJH4h$4.gsoWpMvj7e5D5rjk8Vw.'

# Generated at 2022-06-21 04:36:08.246662
# Unit test for function fileglob
def test_fileglob():
    basedir = tempfile.mkdtemp()


# Generated at 2022-06-21 04:36:10.941942
# Unit test for function path_join
def test_path_join():
    assert path_join(['/etc', 'passwd']) == '/etc/passwd'
    assert path_join(['/etc', '/passwd']) == '/passwd'
    assert path_join({'a': 1, 'b': 2}) == 'a/b'



# Generated at 2022-06-21 04:36:16.462249
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'a': 'b', 'c': 'd'}) == '{\n    "a": "b",\n    "c": "d"\n}'



# Generated at 2022-06-21 04:36:23.200676
# Unit test for function to_uuid
def test_to_uuid():
    tests = ('123456789012345678901234567890123456', '1234567890', '12345678901234567890123456789012345678901234567890')
    for t in tests:
        actual = to_uuid(t)
        assert type(actual) is unicode



# Generated at 2022-06-21 04:36:31.396236
# Unit test for function to_nice_json
def test_to_nice_json():
  x = {"a": [1,2,3], "b": {"c": 4}}
  expected = '''{
    "a": [
        1,
        2,
        3
    ],
    "b": {
        "c": 4
    }
}'''
  retval = to_nice_json(x)
  assert retval == expected


# Generated at 2022-06-21 04:36:41.188360
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(None, 1, 2) == 2
    assert ternary(True, 1, 2, 3) == 1
    assert ternary(False, 1, 2, 3) == 2
    assert ternary(None, 1, 2, 3) == 3
    assert ternary("test", 1, 2) == 1
    assert ternary("", 1, 2) == 2



# Generated at 2022-06-21 04:36:46.889794
# Unit test for function mandatory
def test_mandatory():
    assert mandatory({'a': 1}) == {'a': 1}
    try:
        mandatory('some unknown variable', 'Some error message')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Some error message'
    try:
        mandatory('some unknown variable')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'some unknown variable' not defined."



# Generated at 2022-06-21 04:36:56.064666
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import MagicMock, patch
    from ansible.template import random_errors

    @random_errors
    def fake_groupby(value, attribute):
        yield 'foo', 'bar'

    class TestGroupby(unittest.TestCase):
        def test_groupby(self):
            with patch('ansible.parsing.jinja2.filters._do_groupby', new=fake_groupby):
                results = do_groupby(MagicMock(), 'value', 'attribute')
                self.assertListEqual(results, [('foo', 'bar')])


# Generated at 2022-06-21 04:37:02.137198
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('aabbcc', 'a', 'b') == 'bbbbcc'
    assert regex_replace('aabbcc', 'a+', 'b') == 'bbbcc'
    assert regex_replace('aabbcc', 'a+', 'b', ignorecase=True) == 'bbbbcc'
    assert regex_replace('\nabc\ndef\n', '\n', ' ') == ' abc def '
    assert regex_replace('\nabc\ndef\n', '\n', ' ', multiline=True) == ' abc def '



# Generated at 2022-06-21 04:37:13.185893
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert "groupby" in f.filters().keys()


if __name__ == '__main__':
    module = FilterModule()

# Generated at 2022-06-21 04:37:25.293058
# Unit test for function to_json
def test_to_json():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import OrderedDict

    test_dict = {"test":[1,2,3]}
    test_list = [1,2,3]
    test_str = "test"
    test_none = None
    test_unicode = u'\u2713'

    assert to_json(test_dict) == '{"test": [1, 2, 3]}'
    assert to_json(test_list) == '[1, 2, 3]'
    assert to_json(test_str) == '"test"'
    assert to_json(test_none) == 'null'
    assert to_json(test_unicode) == u'"\u2713"'.encode('utf8')

    # Ord

# Generated at 2022-06-21 04:37:30.841241
# Unit test for function do_groupby
def test_do_groupby():
    # using the filterspec fixture would be better, but it's not available in this module
    environment = Environment()
    environment.filters['groupby'] = do_groupby
    environment.filters['selectattr'] = selectattr

    value = [{'a': 1, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    template = Template('{{ value | groupby("a") | map(attribute="grouper") | list }}',
                        environment=environment)
    assert template.render(value=value) == "[(1, 1, 2), (2, 3)]"



# Generated at 2022-06-21 04:37:40.502468
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'does-not-exist') == []



# Generated at 2022-06-21 04:37:45.590864
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(['a', 'b', 'c', 'd', 'e', 'f'], seed=2) == ['a', 'c', 'e', 'd', 'b', 'f']



# Generated at 2022-06-21 04:37:57.934013
# Unit test for function quote
def test_quote():
    assert quote('Simple String') == '"Simple String"'
    assert quote('Simple String with a space') == '"Simple String with a space"'
    assert quote('Simple String with \'single quotes\'') == '"Simple String with \'single quotes\'"'
    assert quote('Simple String with "double quotes"') == '"Simple String with \"double quotes\""'
    assert quote('Simple String with $dollar sign') == '"Simple String with $dollar sign"'
    assert quote('Simple String with ^caret') == '"Simple String with ^caret"'
    assert quote('Simple String with #hashtag') == '"Simple String with #hashtag"'



# Generated at 2022-06-21 04:38:00.539572
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) != [1, 2, 3]



# Generated at 2022-06-21 04:38:12.379159
# Unit test for function comment
def test_comment():
    assert comment('text', 'plain') == "# text\n"
    assert comment('text', 'erlang') == "% text\n"
    assert comment('text', 'c') == "// text\n"
    assert comment('text', 'cblock') == "/*\n * text\n */\n"
    assert comment('text', 'xml') == "<!--\n - text\n-->\n"

    assert comment('text', 'plain', prefix='*') == "* text\n"
    assert comment('text', 'erlang', prefix='*') == "%* text\n"
    assert comment('text', 'c', prefix='*') == "//* text\n"
    assert comment('text', 'cblock', decoration='  ', prefix='*') == "/*\n  * text\n */\n"

# Generated at 2022-06-21 04:38:18.284920
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({"foo": "bar", "baz": ["quux", 42]}, indent=10) == """{
          foo: bar,
          baz: [
                    quux,
                    42
          ]
}"""


# Generated at 2022-06-21 04:38:25.641360
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('a') == 'a'
    assert regex_escape('.') == '\\.'
    assert regex_escape('$') == '\\$'
    assert regex_escape('*') == '\\*'
    assert regex_escape('\\') == '\\\\'
    assert regex_escape('a|b') == 'a\\|b'
    assert regex_escape('a.b$c*d\\e') == 'a\\.b\\$c\\*d\\\\e'
    assert regex_escape('a.b$c*d\\e', re_type='python') == 'a\\.b\\$c\\*d\\\\e'
    assert regex_escape('a.b$c*d\\e', re_type='posix_basic') == 'a\\.b\\$c\\*d\\\\e'


# Generated at 2022-06-21 04:38:43.241731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class Mock_FilterModule(object):
        ''' Ansible core jinja2 filters '''

# Generated at 2022-06-21 04:38:48.625210
# Unit test for function ternary
def test_ternary():
    assert ternary('True', 'foo', 'bar', None) == 'bar'
    assert ternary('False', 'foo', 'bar', None) == 'foo'
    assert ternary(None, 'foo', 'bar', None) == None



# Generated at 2022-06-21 04:38:51.971457
# Unit test for function regex_search
def test_regex_search():
    """
    >>> test_regex_search()
    [1, 2]
    ['bar', 'foo']
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 04:39:05.173155
# Unit test for function to_json
def test_to_json():
    """
    Test the to_json filter.
    """
    # Check that we can convert ascii to json
    ascii_in = u'{"Hello": "World", "1": "2"}'
    json_ok = u'{"1": "2", "Hello": "World"}'
    json_out = to_json(ascii_in)
    assert(json_out == json_ok)

    # Check that we can convert utf-8 to json
    utf8_in = u'{"Здравствуйте": "Мир", "Один": "Два"}'

# Generated at 2022-06-21 04:39:09.946065
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('[test]') == r'\[test\]'
    assert regex_escape('[test]', re_type='posix_basic') == r'\[test\]'
# Unit test regex_escape



# Generated at 2022-06-21 04:39:25.183266
# Unit test for function comment
def test_comment():
    assert comment('Hello World') == '# Hello World'
    assert comment('Hello\nWorld\n!') == '# Hello\n# World\n# !'
    assert comment('C style', style='c') == '// C style'
    assert comment('C style block', style='cblock', prefix='/// ') == '/**\n/// C style block\n */'
    assert comment('C style block', style='cblock', decoration='/// ') == '/**\n/// C style block\n */'
    assert comment('C style block', style='cblock', decoration='/// ', prefix='/// ') == '/**\n/// C style block\n */'
    assert comment('C style block', style='cblock', decoration='/// ', prefix='/// ') == '/**\n/// C style block\n */'

# Generated at 2022-06-21 04:39:34.422425
# Unit test for function extract
def test_extract():
    data = {'k1': {'k2': 'v2'}}
    obj = AnsiGlass(data)
    assert obj.get('k1', 'k2') == 'v2'
    assert extract('k1', obj, None) == {'k2': 'v2'}
    assert extract('k2', obj, 'k1') == 'v2'
    assert extract('k2', obj, 'k1', 'k3') == None
    assert extract('k1', obj, None, 'k3') == {'k2': 'v2'}

    data = {'k1': {'k2': {'k3': 'v3'}}}
    obj = AnsiGlass(data)
    assert obj.get('k1', 'k2', 'k3') == 'v3'

# Generated at 2022-06-21 04:39:44.579394
# Unit test for function to_yaml
def test_to_yaml():
    # None
    assert to_yaml(None) == 'null'
    # Empty string
    assert to_yaml('') == "''\n"
    # Empty list
    assert to_yaml([]) == "[]\n"
    # Empty dict
    assert to_yaml({}) == "{}\n"
    # Combined dict with list and integer
    assert to_yaml({'a':[1,2,3]}) == '{\n    a: [1, 2, 3]\n}\n'
    # To convert multiple values from a list
    assert to_yaml([{'a':[1,2,3]},{'b':[1,2,3]}]) == '- a: [1, 2, 3]\n- b: [1, 2, 3]\n'
    # To convert multiple

# Generated at 2022-06-21 04:39:51.503975
# Unit test for function regex_replace