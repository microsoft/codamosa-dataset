

# Generated at 2022-06-21 04:30:28.293569
# Unit test for function do_groupby
def test_do_groupby():
    env = Environment(undefined=Undefined)
    result = env.from_string('{{ [{ "a": "b", "c": "d" }, { "a": "e", "c": "f" }] | groupby("a") }}').render()
    assert result == "[('b', [{'c': 'd', 'a': 'b'}]), ('e', [{'c': 'f', 'a': 'e'}])]"



# Generated at 2022-06-21 04:30:36.051046
# Unit test for function combine
def test_combine():
    one = {'a': 1, 'b': 2, 'c': {'ca': 3, 'cb': 4, 'cc': [1, {'cca': 5}]}}
    two = {'c': {'cb': 5, 'cc': [2, 3, 4]}}
    three = {'c': {'cc': [1, 3]}}


# Generated at 2022-06-21 04:30:44.202384
# Unit test for function from_yaml_all
def test_from_yaml_all():
    testlist = []
    yamllist = from_yaml_all('''
- name: item1
  value: one

- name: item2
  value: two

- name: item3
  value: three
''')
    for item in yamllist:
        testlist.append(item)
    assert len(testlist) == 3



# Generated at 2022-06-21 04:30:49.617776
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'\a[b]$c*d(e)\f') == r'\\a\[b\]\$c\*d\(e\\f'
    assert regex_escape(r'\a[b]$c*d(e)\f', re_type='posix_basic') == r'\\a[b]\$c*d(e)\\f'
    try:
        regex_escape(r'x', re_type='posix_extended')
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)



# Generated at 2022-06-21 04:31:02.113149
# Unit test for function comment
def test_comment():
    # Default line comment
    assert comment("Blah") == "# Blah"
    assert comment("Blah\nBlah\nBlah") == "# Blah\n# Blah\n# Blah"
    assert comment("Blah\nBlah\nBlah\n") == "# Blah\n# Blah\n# Blah\n"
    assert comment("Blah", prefix="") == "# Blah"
    assert comment("Blah", prefix=">>") == ">># Blah"
    assert comment("Blah", prefix="", prefix_count=0) == "# Blah"
    assert comment("Blah", prefix=">>", prefix_count=0) == "# Blah"
    assert comment("Blah", prefix="", prefix_count=1) == "# Blah"

# Generated at 2022-06-21 04:31:04.482028
# Unit test for function path_join
def test_path_join():
    assert path_join(['/etc/httpd', 'conf', 'httpd.conf']) == '/etc/httpd/conf/httpd.conf'



# Generated at 2022-06-21 04:31:09.732970
# Unit test for function extract
def test_extract():
    assert extract({'a': 'foo'}, 'a', {'b': {'a': 'foo'}, 'a': {'a': 'bar'}}) == 'foo'
    assert extract({'a': 'foo'}, 'a', {'b': {'a': 'foo'}, 'a': {'a': 'bar'}}, morekeys=['a']) == 'bar'
    assert extract({'a': 'foo'}, 'a', {'b': {'a': 'foo'}, 'a': {'a': {'a': 'bar'}}} , morekeys='a') == {'a': 'bar'}

# Generated at 2022-06-21 04:31:14.312144
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('6pOLKn6oOF5oSXn+ihiOWGmeihiOaWmemdmei1muW5s+i3rQ==') == u'你好，世界！'
    assert b64decode('6pOLKn6oOF5oSXn+ihiOWGmeihiOaWmemdmei1muW5s+i3rQ==', encoding='utf-16') == u'你好，世界！'

# Generated at 2022-06-21 04:31:27.843323
# Unit test for function do_groupby
def test_do_groupby():
    t = Template("{{ ['a', 'a', 'b'] | groupby('upper') | list }}")
    assert t.render() == "[('A', ['a', 'a']), ('B', ['b'])]"
    t = Template("{{ ['a', 'a', 'c', 'b'] | groupby('upper') | list }}")
    assert t.render() == "[('A', ['a', 'a']), ('C', ['c']), ('B', ['b'])]"
# end of unit test for function do_groupby

# overridden groupby filter for jinja2, to address issue with
# jinja2>=2.9.0,<2.9.5 where a namedtuple was returned which
# has repr that prevents ansible.template.safe_eval.safe_eval from being
# able to parse and

# Generated at 2022-06-21 04:31:43.272909
# Unit test for function fileglob
def test_fileglob():
    import tempfile
    import os

    gooddirs = ['dir1', 'dir2', 'dir3']
    goodfiles = ['One', 'fish', 'two', 'fish', 'red', 'fish', 'blue', 'fish']
    badfiles = ['bad1', 'bad2', 'bad3']

    rootdir = tempfile.mkdtemp()
    os.makedirs(os.path.join(rootdir, 'good'))
    os.makedirs(os.path.join(rootdir, 'bad'))

    for g in gooddirs:
        os.makedirs(os.path.join(rootdir, 'good', g))
    for g in goodfiles:
        f = open(os.path.join(rootdir, 'good', g), 'w')
        f.close()

# Generated at 2022-06-21 04:32:01.248174
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u"TeST", "test", "FAIL", True) == u"FAIL"
    assert regex_replace(u"TeST", "test", "FAIL", False) == u"TeST"
    assert regex_replace(u"test", "test", "FAIL", False) == u"FAIL"
    assert regex_replace(u"test", "test", "FAIL", True) == u"FAIL"
    assert regex_replace(u"TeST", b"test", b"FAIL", True) == u"FAIL"
    assert regex_replace(u"TeST", b"test", b"FAIL", False) == u"TeST"
    assert regex_replace(u"test", b"test", b"FAIL", False) == u"FAIL"

# Generated at 2022-06-21 04:32:11.715878
# Unit test for function do_groupby
def test_do_groupby():
    import ansible.template
    import ansible.template.safe_eval
    import jinja2
    from collections import namedtuple

    env = jinja2.Environment()

    # Make sure we render template
    env.filters['template'] = ansible.template.template

    # monkeypatch ansible.template.safe_eval.safe_eval to allow namedtuple repr
    original_safe_eval = ansible.template.safe_eval.safe_eval
    def safe_eval(value):
        if isinstance(value, namedtuple):
            return value
        return original_safe_eval(value)
    ansible.template.safe_eval.safe_eval = safe_eval

    # Add do_groupby filter
    env.filters['groupby'] = do_groupby

    # Create some data to play with
   

# Generated at 2022-06-21 04:32:20.906900
# Unit test for function strftime
def test_strftime():
    assert '10/31/17' == strftime("%m/%d/%y")
    assert '10/31/2017' == strftime("%m/%d/%Y")
    assert 'Oct 31, 2017' == strftime("%b %d, %Y")
    assert 'October 31, 2017' == strftime("%B %d, %Y")
    assert '17:51:13' == strftime("%H:%M:%S")
    assert 'PM' == strftime("%p")
    assert 'Tuesday' == strftime("%A")
    assert 'Oct' == strftime("%b")
    assert 'Oct 31, 2017, 5:51:13 PM' == strftime("%B %d, %Y, %I:%M:%S %p")

# Generated at 2022-06-21 04:32:32.584729
# Unit test for function do_groupby
def test_do_groupby():
    """Unit test for function do_groupby"""
    def test_helper(value, attribute):
        from jinja2 import Environment
        from jinja2.runtime import Context
        from .lookup_plugins.jinja2_filters import _do_groupby

        # NOTE:  the `test` jinja2 env doesn't have all of the filters we
        # normally have loaded up for templating, so we need to load these
        # filters so `groupby` will exist.

# Generated at 2022-06-21 04:32:39.762620
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2},
        {'key': 'c', 'value': 3},
    ]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'a': 1, 'b': 2, 'c': 3}
    assert list_of_dict_key_value_elements_to_dict(mylist, key_name='k', value_name='v') == {'a': 1, 'b': 2, 'c': 3}
    assert list_of_dict_key_value_elements_to_dict(mylist, key_name='k') == {'a': 1, 'b': 2, 'c': 3}
    assert list_of_dict_key_

# Generated at 2022-06-21 04:32:45.977892
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1}) == "---\na: 1\n"
    assert to_yaml([1, {'a': 'b'}]) == "---\n- 1\n- a: b\n"
    assert to_yaml(None) == "--- ~\n"



# Generated at 2022-06-21 04:33:00.843170
# Unit test for function comment
def test_comment():
    assert comment('foo') == '# foo'
    assert comment('foo bar', style='erlang') == '% foo bar'
    assert comment('foo bar', style='c') == '// foo bar'
    assert comment('foo bar', style='cblock') == '/*\n * foo bar\n */'
    assert comment('foo bar', style='xml') == '<!-- - foo bar-->'
    assert comment('foo bar', style='plain', decoration=' ') == ' foo bar'
    assert comment('foo bar', style='c', decoration=' ') == ' // foo bar'
    assert comment('foo bar', style='cblock', decoration=' ') == ' /*\n  * foo bar\n  */'
    assert comment('foo bar', style='xml', decoration=' ') == ' <!-- - foo bar-->'

# Generated at 2022-06-21 04:33:07.261649
# Unit test for function do_groupby
def test_do_groupby():

    t = _do_groupby(None, [{'a': 1, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3}], 'a')
    assert t == [({'b':1, 'a': 1}, [{'b': 1, 'a': 1}, {'b': 2, 'a': 1}]), ({'b': 3, 'a': 2}, [{'b': 3, 'a': 2}])]

    t = do_groupby(None, [{'a': 1, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3}], 'a')

# Generated at 2022-06-21 04:33:09.386079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-21 04:33:15.300416
# Unit test for function quote

# Generated at 2022-06-21 04:33:27.455211
# Unit test for function to_json
def test_to_json():
    _ = to_json([1, 2, 3])
    _ = to_json(dict(foo='bar', baz='bat'))
    _ = to_json(dict(foo=u'bar', baz=u'bat'))
    try:
        _ = to_json(set([1, 2, 3]))
        assert False
    except TypeError:
        pass



# Generated at 2022-06-21 04:33:30.665935
# Unit test for function regex_findall
def test_regex_findall():
    assert ["foo"] == regex_findall("bar foobar foo", "foo")
    assert ["foo", "foo"] == regex_findall("bar foobar foo", "foo", multiline=True)



# Generated at 2022-06-21 04:33:45.331119
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # 1. Test if all the input and output yaml are correctly rendered.
    cases = [
            # Inpout and output are both simple string
            ('foo', 'foo\n...\n'),
            # Input is a list
            (['foo', 'bar'], '- foo\n- bar\n'),
            # Input is a dictionary
            ({'foo': 'bar'}, 'foo: bar\n'),
            # Input is too complicated
            ({'baz': {'foo': ['bar', 'bar2']}}, '''baz:
    foo:
    - bar
    - bar2\n'''),
    ]
    for ipt, expected in cases:
        assert expected == to_nice_yaml(ipt, indent=4)

    # 2. Test if indent argument works

# Generated at 2022-06-21 04:33:46.232026
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule().filters())



# Generated at 2022-06-21 04:33:54.661049
# Unit test for function get_hash
def test_get_hash():

    # Get the hash for a small string
    string = 'TEST'
    hash_type = 'sha1'
    hash_result = get_hash(string, hashtype=hash_type)
    assert isinstance(hash_result, str)
    assert len(hash_result) == hashlib.new(hash_type).hexdigest_size * 2

    # Get the hash for a long string
    string = 'test' * 1024
    hash_type = 'sha512'
    hash_result = get_hash(string, hashtype=hash_type)
    assert isinstance(hash_result, str)
    assert len(hash_result) == hashlib.new(hash_type).hexdigest_size * 2

    # Get the hash for a non-string
    string = 10
    hash_type = 'md5'
    hash

# Generated at 2022-06-21 04:34:05.376453
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], 1) == [1, 2, 3, 4, [5, 6]]
    assert flatten([[0], 1, 2, [3, 4, [5, 6]]], 2) == [0, 1, 2, 3, 4, [5, 6]]

    assert flatten([[0], 1, 2, [3, 4, [5, 6, [7, 8]]]]) == [0, 1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-21 04:34:16.571073
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool('True') is True
    assert to_bool('true') is True
    assert to_bool('TRUE') is True
    assert to_bool('1') is True
    assert to_bool('t') is True
    assert to_bool('T') is True
    assert to_bool('on') is True
    assert to_bool('ON') is True
    assert to_bool('yes') is True
    assert to_bool('YES') is True

    assert to_bool(False) is False
    assert to_bool('False') is False
    assert to_bool('false') is False
    assert to_bool('FALSE') is False
    assert to_bool('0') is False
    assert to_bool('f') is False
    assert to_bool('F') is False

# Generated at 2022-06-21 04:34:20.471155
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({"a": 1, "b": 2}) == '{\n    "a": 1,\n    "b": 2\n}'


# Generated at 2022-06-21 04:34:27.402004
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(r'abc3.14abcxyz', r'\d+\.?\d*') == '3.14'
    assert regex_search(r'abc3.14abcxyz', r'\d+\.?\d*', '\\g<0>', multiline=True) == ['3.14']
    assert regex_search(r'abc3.14abcxyz', r'\d+\.?\d*', '\\g<1>', multiline=True) == []
    assert regex_search(r'abc3.14abcxyz', r'(\d+)\.?(\d*)', '\\g<2>', multiline=True) == ['14']

# Generated at 2022-06-21 04:34:36.788828
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({}) == []
    assert dict_to_list_of_dict_key_value_elements({'key1': 'value1'}) == [{'key': 'key1', 'value': 'value1'}]
    assert dict_to_list_of_dict_key_value_elements({'key1': 'value1', 'key2': 'value2'}, key_name='k', value_name='v') == [{'k': 'key1', 'v': 'value1'}, {'k': 'key2', 'v': 'value2'}]


# Generated at 2022-06-21 04:34:52.420901
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("foo") == "foo"
    assert mandatory("", "foo") == ""
    try:
        mandatory(AnsibleUndefined("foo"))
        assert False
    except AnsibleFilterError as e:
        assert "Mandatory variable 'foo' not defined." == to_native(e)
    try:
        mandatory(AnsibleUndefined("foo"), "bar")
        assert False
    except AnsibleFilterError as e:
        assert "bar" == to_native(e)
test_mandatory.__test__ = False


# Generated at 2022-06-21 04:34:55.845706
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/bin/[df]*") == ['/bin/df', '/bin/dmesg']



# Generated at 2022-06-21 04:34:58.964133
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]


# Generated at 2022-06-21 04:35:04.699482
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2017-04-29 18:20:50') == datetime.datetime(2017, 4, 29, 18, 20, 50)
    assert to_datetime('2017-04-29 18:20:50', '%Y-%m-%d %H:%M:%S') == datetime.datetime(2017, 4, 29, 18, 20, 50)



# Generated at 2022-06-21 04:35:11.624741
# Unit test for function mandatory
def test_mandatory():
    env = {'b': 'b value'}
    assert mandatory(env['a']) is AnsibleUndefined
    assert mandatory(env['a'], 'msg') is AnsibleUndefined
    assert mandatory('b'%env) is 'b value'
    assert mandatory('b'%env, 'msg') is 'b value'



# Generated at 2022-06-21 04:35:24.074337
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%dT%H:%M:%S", 0) == "1970-01-01T00:00:00"
    assert strftime("%Y-%m-%dT%H:%M:%S", 1465344573) == "2016-06-06T07:36:13"
    assert strftime("%Y-%m-%dT%H:%M:%S", "1465344573") == "2016-06-06T07:36:13"
    assert strftime("%Y-%m-%dT%H:%M:%S", "1465344573.123") == "2016-06-06T07:36:13"

# Generated at 2022-06-21 04:35:30.617074
# Unit test for function randomize_list
def test_randomize_list():
    my_list1 = ['a', 'b', 'c', 'd']
    my_list2 = ['a', 'b', 'c', 'd']
    result1 = randomize_list(my_list1, seed=0)
    result2 = randomize_list(my_list2, seed=1)
    assert result1 != result2



# Generated at 2022-06-21 04:35:38.897241
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    # test dict_to_list_of_dict_key_value_elements
    test_dict = dict(A='a', B='b')
    actual_results = dict_to_list_of_dict_key_value_elements(test_dict)
    expected_results = [{'key': 'A', 'value': 'a'}, {'key': 'B', 'value': 'b'}]
    assert actual_results == expected_results



# Generated at 2022-06-21 04:35:47.950325
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', time.time()) == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d', time.time()) == time.strftime('%Y-%m-%d')
    assert strftime('%Y-%m-%d', 1448450534) == '2015-11-23'



# Generated at 2022-06-21 04:35:52.003670
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'a':1}) == '{\n    "a": 1\n}'
    assert to_nice_json({'a':[1,2,3]}) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'


# Generated at 2022-06-21 04:36:05.897448
# Unit test for function rand
def test_rand():
    from ansible.plugins.filter.core import FilterModule
    from ansible.template import JinjaEnvironment
    import pytest
    import random

    randstring = 'abcdefghijklmnopqrstuvwxyz'
    randlist = list(randstring)

    random.seed(1)
    randint_normal = random.randint(1, 30)
    randint_step = random.randrange(0, 30, 3)
    randlist_choice = random.choice(randlist)

    filt = FilterModule()
    env = JinjaEnvironment()
    env.filters['rand'] = filt.filters()['rand']
    env.tests['uuid_match'] = filt._uuid_match


# Generated at 2022-06-21 04:36:13.421430
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == '{}\n'
    assert to_yaml({'a': 1}) == '{a: 1}\n'
    assert to_yaml({'a': 1}, default_flow_style=False) == 'a: 1\n'
    assert to_yaml([]) == '[]\n'
    assert to_yaml(['a']) == '- a\n'



# Generated at 2022-06-21 04:36:26.629893
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', r'world') == 'world'
    assert regex_search('hello world', r'world', '\\g<1>') == ['world', 'hello']
    assert regex_search('hello world', r'world', '\\g<1>', '\\g<0>') == ['world', 'hello', 'world']
    assert regex_search('Hello World', r'world', ignorecase=True) == 'World'
    assert regex_search('Hello World', r'world', '\\g<1>', ignorecase=True) == ['World', 'Hello']
    assert regex_search('hello world', r'world') is None
    assert regex_search('hello world', r'world', '\\g<1>') is None
    assert regex_search('hello world', r'world', '\\g<2>')

# Generated at 2022-06-21 04:36:33.844279
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'a', 'b') == 'a'
    assert ternary(0, 'a', 'b') == 'b'
    assert ternary(None, 'a', 'b') == 'b'
    assert ternary(1, 'a', 'b', 'c') == 'a'
    assert ternary(0, 'a', 'b', 'c') == 'b'
    assert ternary(None, 'a', 'b', 'c') == 'c'



# Generated at 2022-06-21 04:36:47.647610
# Unit test for function to_yaml
def test_to_yaml():
    if sys.version_info < (2, 7):
        from ansible.compat.tests import unittest
    else:
        import unittest

    class TestToYaml(unittest.TestCase):
        def test_to_yaml_string(self):
            self.assertEqual(to_yaml('string'), "--- 'string'\n")

        def test_to_yaml_dict(self):
            self.assertEqual(to_yaml({'key': 'value'}, default_flow_style=True), "--- {key: value}\n")

        def test_to_yaml_list(self):
            self.assertEqual(to_yaml(['list']), "---\n- 'list'\n")


# Generated at 2022-06-21 04:36:58.340420
# Unit test for function path_join
def test_path_join():
    assert path_join('/var/tmp') == path_join(['/var', 'tmp']) == '/var/tmp'
    assert path_join(['/var/tmp', '']) == '/var/tmp/'
    assert path_join(['/var/tmp', '..']) == '/var'
    assert path_join(['/var/tmp', '../..']) == '/'
    assert path_join(['/var/tmp', '../../..']) == '/'
    assert path_join(['/var/tmp', '../../../..']) == '/'
    assert path_join(['/var/tmp', '/etc', '/var/log']) == '/var/log'


# Generated at 2022-06-21 04:37:03.457405
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[]') == []
    # The following case will fail because ``to_text`` will
    # call ``yaml_load`` on the object.
    #assert from_yaml(object()) is None


# Generated at 2022-06-21 04:37:10.291776
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' return a list of tuples of input dictionary and output list of dictionary '''

# Generated at 2022-06-21 04:37:22.093639
# Unit test for function fileglob
def test_fileglob():
    files = [ "/tmp/testme", "/tmp/testme2", "/tmp/abc/def" ]
    for f in files:
        open(f,"a").close()
    assert fileglob("/tmp/*me") == [ "/tmp/testme", "/tmp/testme2" ]
    assert fileglob("/tmp/*me2") == [ "/tmp/testme2" ]
    assert fileglob("/tmp/testme*") == [ "/tmp/testme", "/tmp/testme2" ]
    assert fileglob("/tmp/abc/*") == [ "/tmp/abc/def" ]
    assert fileglob("/tmp/*") == [ "/tmp/testme", "/tmp/testme2", "/tmp/abc/def" ]
    for f in files:
        os.remove(f)



# Generated at 2022-06-21 04:37:31.685490
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('mystring') == '1d8ab50a-f43e-5e09-b0a9-fa2d2fa98c24'
    assert to_uuid('mystring', 'a4aa4deb-4f39-4c53-b1e0-24fd2fd2d816') == '3ba4c4e4-81f9-5d4a-b03c-716d1f8adcab'
    assert to_uuid('mystring', namespace=UUID_NAMESPACE_ANSIBLE) == '1d8ab50a-f43e-5e09-b0a9-fa2d2fa98c24'

# Generated at 2022-06-21 04:37:45.264221
# Unit test for function rand

# Generated at 2022-06-21 04:37:57.168779
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b"test", "md5") == "098f6bcd4621d373cade4e832627b4f6"
    assert get_hash(b"test", "sha1") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert get_hash(b"test", "sha256") == "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"


# Generated at 2022-06-21 04:38:06.066748
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

# Generated at 2022-06-21 04:38:10.461605
# Unit test for function ternary
def test_ternary():
    assert ternary(0, "true", "false") == "false"
    assert ternary(1, "true", "false") == "true"
    assert ternary(None, "true", "false", "none") == "none"



# Generated at 2022-06-21 04:38:21.633974
# Unit test for function rand
def test_rand():
    f = partial(rand, seed=1)
    assert [f(1, 4), f(1, 4), f(1, 4), f(1, 4)] == [3, 1, 2, 1]
    assert [f(1, 4, step=2), f(1, 4, step=2), f(1, 4, step=2), f(1, 4, step=2)] == [1, 3, 1, 3]
    assert [f([1, 2, 3]), f([1, 2, 3]), f([1, 2, 3]), f([1, 2, 3])] == [2, 1, 3, 3]


# Generated at 2022-06-21 04:38:31.497024
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(string='string') == 'c3RyaW5n'
    assert b64encode(string='string', encoding='iso-8859-1') == 'c3RyaW5n'
    assert b64encode(string=to_bytes('string', encoding='iso-8859-1')) == 'c3RyaW5n'
    assert b64encode(string=str('string')) == 'c3RyaW5n'



# Generated at 2022-06-21 04:38:36.664505
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    result = subelements(obj, 'groups')
    assert result == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-21 04:38:44.057156
# Unit test for function mandatory
def test_mandatory():
    from ansible.template import Jinja2Environment

    env = Jinja2Environment()
    env.filters.update(do_mandatory=mandatory)

    assert env.from_string("{{ var | mandatory }}").render(var='hello') == 'hello'
    assert env.from_string("{{ var|mandatory(msg='foo') }}").render(var='hello') == 'hello'
    assert env.from_string("{{ var|mandatory(msg='foo') }}").render() == 'ERROR'
    assert env.from_string("{{ var|mandatory }}").render() == 'ERROR'



# Generated at 2022-06-21 04:38:50.499019
# Unit test for function fileglob
def test_fileglob():
    files = ["/bin/foo", "/bin/bar"]
    fake_glob = lambda x: files
    old_glob = glob.glob
    glob.glob = fake_glob
    found_files = fileglob("/bin/*")
    glob.glob = old_glob
    assert found_files == files



# Generated at 2022-06-21 04:38:55.521881
# Unit test for function to_uuid
def test_to_uuid():
    # This test method is for the unit test for ``to_uuid`` filter

    # with no namespace specified
    # single string
    assert to_uuid("ansible") == "f636d77a-49ec-5159-b3ed-6e3f819e88e1"
    # multiple strings
    assert to_uuid("ansible", "tower") == "10a3c8a4-f6fb-53b4-9d2c-da8ee4c4f77a"
    # sequence type
    t_list = ["ansible", "tower"]
    assert to_uuid(t_list) == "a0650c2e-41f2-5a3d-9e33-db86848a791d"
    t_tuple = ("ansible", "tower")


# Generated at 2022-06-21 04:39:06.552948
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('[foo, bar]') == ["foo", "bar"]
    assert from_yaml('- { foo: bar }') == [{'foo': 'bar'}]
    assert from_yaml('{ foo: [bar, baz] }') == {'foo': ['bar', 'baz']}
    assert from_yaml('foo') == u'foo'



# Generated at 2022-06-21 04:39:17.270343
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid("test") == '361e6d51-faec-544a-9079-341386da8e2e'
    assert to_uuid("test", "00000000-1111-2222-3333-444444444444") == '3f3f8db4-4e4c-57f4-b26c-52a4b2a1b50d'
    # Make sure we've got the namespace from the UUID class.
    assert to_uuid("test", UUID_NAMESPACE_ANSIBLE) == '361e6d51-faec-544a-9079-341386da8e2e'

# Generated at 2022-06-21 04:39:19.231804
# Unit test for function path_join
def test_path_join():
    assert path_join(['/a/b', 'c/d', 'e', 'f/g']) == '/a/b/c/d/e/f/g'

# Unit tests for function to_nice_yaml
# Uses YamlTest's yaml_run_test_suite() with a custom set of tests

# Generated at 2022-06-21 04:39:22.985851
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    # Note: The output from this test is used as a unit test for the Jinja2
    # implementation in lib/ansible/template/template.py, so be careful when
    # making changes.
    assert list_of_dict_key_value_elements_to_dict([]) == {}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a'}]) == {}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 'b'}, {'key': 'b', 'value': 'c'}]) == {'a': 'b', 'b': 'c'}



# Generated at 2022-06-21 04:39:26.239631
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters()['to_uuid'] == to_uuid

# Generated at 2022-06-21 04:39:32.454822
# Unit test for function subelements
def test_subelements():
    assert(subelements([{"a": {"b": ["c", "d"]}}], 'a.b') == [({'a': {'b': ['c', 'd']}}, 'c'), ({'a': {'b': ['c', 'd']}}, 'd')])
    assert(subelements([{"a": {"b": "c"}}], 'a') == [({'a': {'b': 'c'}}, {'b': 'c'})])



# Generated at 2022-06-21 04:39:44.286500
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    test_case = {
        'test_dict': {'test_key': 'test_value'},
        'key_name': 'test_key',
        'value_name': 'test_value',
    }
    test_case1 = {
        'test_dict': {'test_key': 'test_value'},
        'key_name': 'test_key1',
        'value_name': 'test_value',
    }
    test_case2 = {
        'test_dict': {'test_key': 'test_value'},
        'key_name': 'test_key',
        'value_name': 'test_value1',
    }

# Generated at 2022-06-21 04:39:53.827118
# Unit test for function from_yaml_all
def test_from_yaml_all():
    test_data = """\
foo:
-   bar: baz
-   biz: buz

bar:
-   baz: biz
-   buz: biz
"""
    expected_data = [{'foo': [{'bar': 'baz'}, {'biz': 'buz'}]},
                     {'bar': [{'baz': 'biz'}, {'buz': 'biz'}]}]
    assert from_yaml_all(test_data) == expected_data

