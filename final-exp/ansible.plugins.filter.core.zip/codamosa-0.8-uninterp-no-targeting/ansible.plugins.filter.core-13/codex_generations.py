

# Generated at 2022-06-21 04:30:25.667847
# Unit test for function path_join
def test_path_join():
    assert path_join('test') == os.path.join('test')
    assert path_join(['test', 'test']) == os.path.join('test', 'test')
    assert path_join('test/test') == os.path.join('test', 'test')
    assert path_join(['test', 'test']) == os.path.join('test', 'test')
    assert path_join(('test', 'test')) == os.path.join('test', 'test')
    assert path_join('test', 'test') == os.path.join('test', 'test')



# Generated at 2022-06-21 04:30:31.969821
# Unit test for function quote
def test_quote():
    assert quote(None) == u""
    assert quote('123') == u'123'
    assert quote('a,b') == u"'a,b'"
    assert quote('a,b c,d') == u"'a,b c,d'"
    assert quote('"a,b" c,d') == u"'"'\\'"'a,b'"'\\'"' c,d'"
    assert quote(u'\x01\x02\x03\x04') == u"$'\\x01\\x02\\x03\\x04'"



# Generated at 2022-06-21 04:30:37.747976
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('', '') == []
    assert regex_findall('abc', '') == []
    assert regex_findall('abc', 'a',) == ['a']
    assert regex_findall('abc', 'a', ignorecase=True) == ['a']
    assert regex_findall('abc', '[a-c]') == ['a', 'b', 'c']
    assert regex_findall('aaaa', 'a{3,3}') == ['aaa']
    assert regex_findall('aaaa', 'a+') == ['aaaa']
    assert regex_findall('abcdabcd', 'abc', multiline=True) == ['abc', 'abc']
    assert regex_findall('abcdabcd', 'abc', multiline=False) == ['abc']

# Generated at 2022-06-21 04:30:48.649591
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password(password="password", hashtype="sha512", salt="salt", rounds=5000) == '$6$salt$zgP/TnT8yA1AYN/iK6k1Mc6zMTO6ZKjX9dY6.xmDtlQ2jywHQ6m1.p6UcDB6UfO6ZK9JYgyddFDvyLBAxz2Kj1'
    assert get_encrypted_password(password="password", hashtype="blowfish", salt="salt", rounds=8) == '$2a$08$salt$7Nu8KZlV7ZuE9/mnJ7Kxnu/y/q3rTFH2jKmtwTyghWPJEp5I5mX.a'

# Generated at 2022-06-21 04:30:53.845923
# Unit test for function rand
def test_rand():
    env = {'vars': {}}
    tests = (
        (2,),
        (2, 4,),
        (2, 4, 1,),
        (2, 4, 1, 'seeded'),
        ([2, 4, 5],),
    )
    for args in tests:
        result = rand(env, *args)
        assert isinstance(result, integer_types) or result in args[0]



# Generated at 2022-06-21 04:31:04.482772
# Unit test for function quote
def test_quote():
    assert quote(None) == u''
    assert quote('"') == u'"\'"\'"'
    assert quote(u'\'\'') == u"'" + u'\'"\'"\''
    assert quote(u'`') == u'"`"\'"`"\'"`"'
    assert quote(u'$') == u'"$"\'"$"\'"$"'
    assert quote(u'!') == u'"!"\'"!"\'"!"'
    # Here comes a list from https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/vars.py

# Generated at 2022-06-21 04:31:10.309995
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

if __name__ == '__main__':
    test_form_multiline_dict_str()
    test_to_nice_json()
    test_to_nice_yaml()

# Generated at 2022-06-21 04:31:15.566423
# Unit test for function quote
def test_quote():
    items = [u'foo bar baz', u'foo"bar', u'do"not', u"don't", u'!@#$%^&*()']
    for item in items:
        quoted = quote(item)
        assert quoted == u'"%s"' % item
test_quote()



# Generated at 2022-06-21 04:31:26.610109
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("a: 1") == {'a': 1}
    assert from_yaml("a: 'b'") == {'a': 'b'}
    assert from_yaml("a: \"b\"") == {'a': 'b'}
    assert from_yaml("a: null") == {'a': None}
    assert from_yaml("a: [1,2,3]") == {'a': [1, 2, 3]}
    assert from_yaml("a: {x: 1, y: 2}") == {'a': {'x': 1, 'y': 2}}



# Generated at 2022-06-21 04:31:39.872954
# Unit test for function b64decode
def test_b64decode():
    # Test 1: verify the decoding of a string with special characters
    # using an utf-8 encoding
    test11 = {'bytes': b'5L2g5aW9', 'string': u'中文', 'encoding': 'utf-8'}
    assert b64decode(test11['bytes']) == test11['string'].encode('utf-8')
    assert b64decode(test11['bytes'], encoding=test11['encoding']) == test11['string']
    # Test 2: verify the decoding of a string with special characters
    # using an utf-16 encoding
    test21 = {'bytes': b'5L2g5aW9', 'string': u'中文', 'encoding': 'utf-16'}

# Generated at 2022-06-21 04:32:08.784776
# Unit test for function ternary
def test_ternary():
    # Test true value
    assert ternary(1, 'one', 'two') == 'one'
    assert ternary([], 'one', 'two') == 'one'
    assert ternary((), 'one', 'two') == 'one'
    assert ternary({}, 'one', 'two') == 'one'
    assert ternary({'a': 1}, 'one', 'two') == 'one'
    # Test false value
    assert ternary(0, 'one', 'two') == 'two'
    assert ternary('', 'one', 'two') == 'two'
    assert ternary(None, 'one', 'two') == 'two'
    # Test None value
    assert ternary(None, 'one', 'two', 'three') == 'three'



# Generated at 2022-06-21 04:32:19.666640
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo') == 'foo'
    assert from_yaml('foo\nbar\nbaz') == 'foo\nbar\nbaz'
    assert from_yaml('- foo\n- bar\n- baz') == ['foo', 'bar', 'baz']
    assert from_yaml('- foo\n- bar\n- baz\n') == ['foo', 'bar', 'baz']
    assert from_yaml('- foo\n- bar\n- baz\n\n') == ['foo', 'bar', 'baz']
    assert from_yaml('{foo: bar, baz: foo}') == {'foo': 'bar', 'baz': 'foo'}



# Generated at 2022-06-21 04:32:29.497286
# Unit test for function ternary
def test_ternary():
    assert ternary(True, True, False) == True
    assert ternary(True, False, True) == False
    assert ternary(False, True, False) == False
    assert ternary(False, False, True) == True
    assert ternary(None, True, False) == False
    assert ternary(None, False, True) == True
    assert ternary(False, None, True) == True
    assert ternary(None, None, True) == True
    assert ternary(None, True, None) == True
    assert ternary(None, None, None) == None


# Generated at 2022-06-21 04:32:39.387069
# Unit test for function do_groupby
def test_do_groupby():
    x = [{'title': 'a', 'content': 'Foo'}, {'title': 'b', 'content': 'Bar'}]
    y = [{'content': 'Foo'}, {'content': 'Bar'}]
    tmpl1 = Template('{{ x|groupby("title")|list }}', undefined=StrictUndefined)
    tmpl2 = Template('{{ y|groupby("title")|list }}', undefined=StrictUndefined)
    assert tmpl1.render(x=x) == '[([{title: a, content: Foo}], a), ([{title: b, content: Bar}], b)]'
    assert tmpl2.render(y=y) == '[([{content: Foo}], None), ([{content: Bar}], None)]'



# Generated at 2022-06-21 04:32:50.602080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert isinstance(module.filters(), dict)

# Generated at 2022-06-21 04:33:01.835810
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('test') == u'92ea1c22-d0e7-55b8-adfa-7c9f9d15d7c8'
    assert to_uuid('test', '361E6D51-FAEC-444A-9079-341386DA8E2E') == u'92ea1c22-d0e7-55b8-adfa-7c9f9d15d7c8'
    assert to_uuid('test', uuid.uuid4()) == u'5d5c3fda-8c83-5b36-a744-c4d84eaff1ea'
    assert to_uuid('test', u'361E6D51-FAEC-444A-9079-341386DA8E2E') == u

# Generated at 2022-06-21 04:33:11.939572
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2

    env = jinja2.Environment(**get_jinja_environment_argument(), extensions=['jinja2.ext.do'])
    env.filters['groupby'] = do_groupby

    results = env.from_string('{{ [{a:1,b:2},{a:3,b:4}]|groupby("a") }}').render()
    assert results == '[(1, [{a:1,b:2}]), (3, [{a:3,b:4}])]'

    results = env.from_string('{{ [{a:1,b:2},{a:3,b:4}]|groupby("b") }}').render()

# Generated at 2022-06-21 04:33:20.107880
# Unit test for function to_bool
def test_to_bool():
  assert to_bool('yes') == True
  assert to_bool('on') == True
  assert to_bool('1') == True
  assert to_bool('true') == True
  assert to_bool(1) == True
  assert to_bool('no') == False
  assert to_bool('off') == False
  assert to_bool('0') == False
  assert to_bool('false') == False
  assert to_bool(0) == False



# Generated at 2022-06-21 04:33:24.983264
# Unit test for function strftime
def test_strftime():
    _epoch = time.time()
    assert strftime('%Y-%m-%d', _epoch) == time.strftime('%Y-%m-%d', time.localtime(_epoch))



# Generated at 2022-06-21 04:33:30.608590
# Unit test for function rand
def test_rand():
    integer_test_end = 10
    integer_test_start = 0
    integer_test_step = 1
    integer_test_seed = 1

    seq_test_end = [1, 2, 3]
    seq_test_seed = 1

    # Test if function rand returns a random number n in the range start <= n < end
    for i in range(100):
        n = rand(environment=None, end=integer_test_end, start=integer_test_start, step=integer_test_step, seed=integer_test_seed)
        assert (n >= integer_test_start and n < integer_test_end)

    # Test if function rand returns a random element from seq
    # This test is less deterministic than the integer test

# Generated at 2022-06-21 04:33:44.815949
# Unit test for function to_json
def test_to_json():
    assert json.loads(to_json({'x': 'y'})) == {'x': 'y'}



# Generated at 2022-06-21 04:33:49.532336
# Unit test for function flatten
def test_flatten():
    assert flatten([['foo', 'bar'], [['baz'], 'qux'], 'corge']) == ['foo', 'bar', 'baz', 'qux', 'corge']
    assert flatten([['foo', 'bar'], [['baz'], 'qux'], 'corge'], levels=1) == ['foo', 'bar', ['baz'], 'qux', 'corge']
    assert flatten([['foo', 'bar'], [['baz'], 'qux'], 'corge'], levels=2) == ['foo', 'bar', 'baz', 'qux', 'corge']

# Generated at 2022-06-21 04:34:01.928522
# Unit test for function rand
def test_rand():
    environment = {}
    assert rand(environment, 100) < 100
    from random import randint
    seed = randint(1, 10000000)
    assert rand(environment, 100, seed=seed) == rand(environment, 100, seed=seed)
    assert rand(environment, 100, start=10, step=2, seed=seed) == rand(environment, 100, start=10, step=2, seed=seed)
    assert rand(environment, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], seed=seed) == rand(environment, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], seed=seed)



# Generated at 2022-06-21 04:34:07.618928
# Unit test for function fileglob
def test_fileglob():
    p = os.path.realpath(os.path.dirname(__file__))
    list1 = fileglob("%s/../lib/ansible/modules/core/*.py"%p)
    list2 = glob.glob("%s/../lib/ansible/modules/core/*.py"%p)
    list2 = [g for g in list2 if os.path.isfile(g)]
    assert len(list1) == len(list2)
    assert set(list1) == set(list2)



# Generated at 2022-06-21 04:34:15.464603
# Unit test for function ternary
def test_ternary():
    assert ternary(1,    2,   3) == 2
    assert ternary(True, 2,   3) == 2
    assert ternary(None, 2,   3) == 3
    assert ternary(None, 2,   3, 4) == 4
    assert ternary(0,    2,   3) == 3
    assert ternary(False,2,   3) == 3



# Generated at 2022-06-21 04:34:28.705144
# Unit test for function combine
def test_combine():
    assert combine({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert combine({'a': 'b'}, {'a': 'd'}) == {'a': 'd'}
    assert combine({'a': 'b'}, {'a': {'c': 'd'}}) == {'a': {'c': 'd'}}
    assert combine({'a': {'c': 'd'}}, {'a': 'b'}) == {'a': 'b'}
    assert combine({'a': {'c': 'd'}}, {'a': {'c': 'e'}}) == {'a': {'c': 'e'}}

# Generated at 2022-06-21 04:34:35.805495
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('U2twaWV0ZXRhIHBpcGVyYmFuZyB0ZW1wYXJ0dXM=') == u'Stkilete pipéband temp'
    assert b64decode('V2VtbWFyY2ggc3VwZXJ0b3J0IG9uZm9yZXN0IGNvcmVjYXM=') == u'Wemmar schuperto onforet cor'

# Generated at 2022-06-21 04:34:40.451949
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('swag') == '96362a0d0c0118aee7ea0ca6595f8e15f35e2a20', \
        'should hash string'


# Generated at 2022-06-21 04:34:43.370967
# Unit test for function to_json
def test_to_json():
    assert to_json([1, 2, 3]) == "[1, 2, 3]"
    assert to_json({"k": "v"}) == '{"k": "v"}'



# Generated at 2022-06-21 04:34:55.034832
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == u"{}\n"
    assert to_yaml(None) == u"null\n"
    assert to_yaml(123, default_flow_style=False) == u"123\n"
    assert to_yaml(
        [1, 2, 3],
        default_flow_style=False
    ) == u"""\
- 1
- 2
- 3
"""
    assert to_yaml(
        {'a': 1, 'b': 2},
        default_flow_style=False
    ) == u"""\
a: 1
b: 2
"""

# Generated at 2022-06-21 04:35:09.801285
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('YQ==') == "a"
    assert b64decode('YWI=') == "ab"
    assert b64decode('YWJj') == "abc"
    assert b64decode('YWJjZA==') == "abcd"
    assert b64decode('25hello%20world%25') == "%hello world%"

# Generated at 2022-06-21 04:35:18.072484
# Unit test for function extract
def test_extract():
    assert extract(item='a', container={'a':'b'}) == 'b'
    assert extract(item='a', container={'a':{'b':'c'}}) == {'b':'c'}
    assert extract(item='a', container={'a':{'b':'c'}}, morekeys='b') == 'c'
    assert extract(item='a', container={'a':{'b':['c', 'd']}}, morekeys=1) == 'd'

# Generated at 2022-06-21 04:35:22.302935
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2, none_val=0) == 1
    assert ternary(False, 1, 2, none_val=0) == 2
    assert ternary(None, 1, 2, none_val=0) == 0



# Generated at 2022-06-21 04:35:34.333803
# Unit test for function rand
def test_rand():
    env = jinja2.Environment()
    env.filters['rand'] = rand
    template = env.from_string("{{ [1, 2, 3]|rand }}")
    assert template.render() in ['1', '2', '3']
    template = env.from_string("{{ 'abc'|rand }}")
    assert template.render() in ['a', 'b', 'c']
    template = env.from_string("{{ 100|rand(step=3) }}")
    assert template.render() in ['0', '3', '6', '9', '12', '15', '18', '21', '24', '27', '30', '33', '36', '39']
    template = env.from_string("{{ 10|rand(20) }}")

# Generated at 2022-06-21 04:35:49.287849
# Unit test for function regex_escape
def test_regex_escape():
    if sys.version_info[0] < 3:
        from ansible.compat.tests.mock import patch
        import __builtin__ as builtins

        with patch.object(builtins, 'open', mock_open(read_data='foo')):
            assert regex_escape('[foo]') == '\\[foo\\]'
            assert regex_escape('[foo]', 'posix_basic') == '\\[foo\\]'
            assert regex_escape('[foo]', 'posix_extended') == '\\[foo\\]'
    else:
        assert regex_escape('[foo]') == '\\[foo\\]'
        assert regex_escape('[foo]', 'posix_basic') == '\\[foo\\]'

# Generated at 2022-06-21 04:35:50.152743
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule)


# Generated at 2022-06-21 04:35:55.854768
# Unit test for function quote
def test_quote():
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote(u'foo\nbar') == u"'foo\nbar'"

# Generated at 2022-06-21 04:36:05.947666
# Unit test for function to_uuid
def test_to_uuid():
    from ansible.module_utils.parsing.convert_bool import boolean

    uuid_namespace=UUID_NAMESPACE_ANSIBLE
    namespace = uuid.UUID('47D7B439-3534-4707-8CBE-9E4D7DB4B4D5')
    test_cases = dict(
        string='foo',
        expect='71cd9f11-48da-5604-a3b1-42e68dff7dcf',
        id=1,
    )
    result = to_uuid(test_cases['string'], namespace=namespace)

# Generated at 2022-06-21 04:36:12.257874
# Unit test for function flatten
def test_flatten():
    assert flatten([[1, 2, 3], 4]) == [1, 2, 3, 4]
    assert flatten([1, 2, [3, 4, 5], 6]) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2, [3, 4, [5]]]]) == [1, 2, 3, 4, [5]]
    assert flatten([[1, 2, [3, 4, [5]]]], levels=2) == [1, 2, 3, 4, 5]
    assert flatten([[1], 2, [3], 4, 5], skip_nulls=False) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 04:36:26.008450
# Unit test for function regex_replace
def test_regex_replace():
    # Tests for all parameters
    assert regex_replace(value="hello world", pattern="(?P<first>\w+) (?P<second>\w+)", replacement="\g<second> \g<first>") == "world hello"
    # Test for ignorecase parameter
    assert regex_replace(value="hello world", pattern="hello", replacement="world", ignorecase=True) == "world world"
    # Test for multiline parameter
    assert regex_replace(value="hello\nworld\n", pattern="^(hello)", replacement="bye", multiline=True) == "bye\nworld\n"
    # Test for default value
    assert regex_replace(value="hello world") == "hello world"
    assert regex_replace(pattern="(?P<first>\w+) (?P<second>\w+)") == ""

# Generated at 2022-06-21 04:36:46.159345
# Unit test for function to_nice_json
def test_to_nice_json():
    from ansible.module_utils.common.collections import OrderedDict
    from ansible.template import AnsibleJ2Template
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.utils.vars import combine_vars

    test_json_data = OrderedDict((("items", {"test_item": {"id": 1, "name": "test_name"}}),))
    test_vars = {"test_string": "test_string", "test_int": 1, "test_list": ["test_item1", "test_item2"],
                 "test_dict": {"test_key": "test_value"}}


# Generated at 2022-06-21 04:36:51.231163
# Unit test for function regex_search
def test_regex_search():
    _regex_test = regex_search('test regex', '\w+ regex')
    assert _regex_test == 'test regex'
    _regex_test = regex_search('test regex', '\w+ regex', kwargs={'multiline':True})
    assert _regex_test == 'test regex'
    _regex_test = regex_search('test regex', '^\w+ regex')
    assert _regex_test is None
    _regex_test = regex_search('test regex', '^\w+ regex', kwargs={'multiline':True})
    assert _regex_test == 'test regex'

# Generated at 2022-06-21 04:36:53.475245
# Unit test for function fileglob
def test_fileglob():
    results = fileglob('/home')
    assert isinstance(results, list)


# Generated at 2022-06-21 04:37:05.116614
# Unit test for function regex_escape
def test_regex_escape():
    strings = {'a.b*c': 'a\\.b\\*c',
               'd?e+f': 'd\\?e\\+f',
               'g|h': 'g\\|h',
               'i(j': 'i\\(j',
               'k)l': 'k\\)l',
               'm{n': 'm\\{n',
               'o}p': 'o\\}p',
               'q^r': 'q\\^r',
               's$t': 's\\$t',
               'u\\v': 'u\\\\v'}
    for string, expected in strings.items():
        escaped = regex_escape(string)
        assert escaped == expected, escaped


# Generated at 2022-06-21 04:37:08.681218
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2019-02-17 17:45:00') == datetime.datetime(2019, 2, 17, 17, 45, 00)



# Generated at 2022-06-21 04:37:15.573909
# Unit test for function b64decode
def test_b64decode():
    # testcases for b64decode
    assert(b64decode('ZW5jb2RlIG1l') == 'encode me')
    assert(b64decode('ZW5jb2RlIG1l') == b64encode('encode me'))


# Generated at 2022-06-21 04:37:21.614821
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'a': 1, 'b': 2}
    assert dict_to_list_of_dict_key_value_elements(mydict) == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    assert dict_to_list_of_dict_key_value_elements(mydict, 'foo', 'bar') == [{'foo': 'a', 'bar': 1}, {'foo': 'b', 'bar': 2}]
    # Test that exceptions are triggered
    try:
        dict_to_list_of_dict_key_value_elements(['a'])
        assert False, 'dict_to_list_of_dict_key_value_elements should have thrown exception'
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-21 04:37:27.066164
# Unit test for function rand
def test_rand():
    assert rand(end=1, start=0) == 0
    assert 0 <= rand(end=1000000000000) < 1000000000000

    l = [0, 1, 2, 3]
    assert rand(end=l) in l

# Generated at 2022-06-21 04:37:32.386902
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'c': 3, 'b': 4}) == {'a': 1, 'b': 4, 'c': 3}



# Generated at 2022-06-21 04:37:39.087221
# Unit test for function extract
def test_extract():
    container = {'a': {'b': {'c': 5}}}
    item = 'a'
    morekeys = ['b', 'c']

    value = extract(item, container, morekeys)

    assert value == 5



# Generated at 2022-06-21 04:37:51.634204
# Unit test for function to_json
def test_to_json():
    assert to_json({"a": [1, 2]}) == '{"a": [1, 2]}'
    assert to_json({"a": [1, 2]}, sort_keys=True) == '{"a": [1, 2]}'
    assert to_json({"a": [1, 2]}, sort_keys=True, indent=4) == '{\n    "a": [\n        1, \n        2\n    ]\n}'



# Generated at 2022-06-21 04:38:04.453374
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(None) is None
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('YES') is True
    assert to_bool('nO') is False
    assert to_bool('TrUe') is True
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('Off') is False
    assert to_bool('On') is True
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool('100') is True
    assert to_bool(1) is True
    assert to_bool(0) is False

# Generated at 2022-06-21 04:38:09.463524
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('John') == '92c1dceb-8be8-5f70-b08f-9b9e8f13d415'



# Generated at 2022-06-21 04:38:10.385975
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:38:21.534431
# Unit test for function to_datetime
def test_to_datetime():
    # test string in correct ansible date_time format
    string = "2019-10-01 10:10:10"
    format = "%Y-%m-%d %H:%M:%S"

# Generated at 2022-06-21 04:38:33.873140
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text\n', 'failed default style'
    assert comment('text', style='plain', decoration='--') == '-- text\n', 'failed custom style 1'
    assert comment('text', style='c', decoration='//', newline='\r\n') == '// text\r\n', 'failed custom style 2'
    assert comment('text', style='cblock', prefix='prefix', prefix_count=2) == '/*\n * prefix\n * prefix\n * text\n */\n', 'failed custom style 3'
    assert comment('text\ntext', style='cblock', prefix='') == '/*\n text\n text\n */\n', 'failed custom style 4'

# Generated at 2022-06-21 04:38:45.539165
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
    assert flatten([[[1, 2, 3], [4, 5]], 6]) == [1, 2, 3, 4, 5, 6]
    assert flatten(42) == [42]
    assert flatten([1, [2], [[3]]]) == [1, 2, 3]
    assert flatten([1, [2], [[3]]], levels=1) == [1, 2, [3]]
    assert flatten([1, [2], [[3]]], levels=2) == [1, 2, 3]

# Generated at 2022-06-21 04:38:50.922137
# Unit test for function mandatory
def test_mandatory():
    from jinja2.environment import Environment

    env = Environment()
    env.filters['mandatory'] = mandatory
    template = env.from_string('{{mandatory(undefined_value)}}')
    assert template.render(undefined_value=0) == '0'



# Generated at 2022-06-21 04:39:04.073290
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"], "othergroups": {"authorized": ["/tmp/alice/twokey.pub"]}}]

# Generated at 2022-06-21 04:39:19.124654
# Unit test for function rand
def test_rand():
    import random

    def fuzz(n, m, i):
        """ Helper function to fuzz range of integers to test edge cases of rand """
        return list(range(n, m, i))


# Generated at 2022-06-21 04:39:30.889158
# Unit test for function path_join
def test_path_join():
    assert '/some/path/some_file' == path_join(['/some/path', 'some_file'])
    assert '/some/path/some_file' == path_join('/some/path/some_file')



# Generated at 2022-06-21 04:39:42.120188
# Unit test for function mandatory
def test_mandatory():
    # Test that mandatory raises when passed an AnsibleUndefined object
    try:
        dummy_var = AnsibleUndefined
        dummy_msg = "This is an error"
        mandatory(dummy_var, msg=dummy_msg)
        assert False
    except AnsibleFilterError as e:
        assert e.message == dummy_msg
    # Test that it does not raise when passed a non-undefined object
    try:
        dummy_var = "This is not undefined"
        assert mandatory(dummy_var) == dummy_var
    except AnsibleFilterError:
        assert False



# Generated at 2022-06-21 04:39:48.131659
# Unit test for function get_hash
def test_get_hash():
    assert '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12' == get_hash('The quick brown fox jumps over the lazy dog')



# Generated at 2022-06-21 04:39:56.904275
# Unit test for function do_groupby
def test_do_groupby():
    """Test ansible.plugins.filter.core._do_groupby filter
    """
    from jinja2 import Environment, DictLoader
    from ansible.template.jinja2_native import AnsibleJ2Undefined

    env = Environment(loader=DictLoader({'groupby.j2': '{% for group in [{"foo":99, "bar":101}, {"foo":99}, {"foo":100}] | groupby("foo") %}{{ group.grouper }}={% for item in group.list %}{{ item.bar }},{% endfor %}{% endfor %}'}))
    env.filters['groupby'] = do_groupby
    template = env.get_template('groupby.j2')
