

# Generated at 2022-06-21 04:30:21.286890
# Unit test for function quote
def test_quote():
    from ansible.compat.tests.mock import patch

    with patch('ansible.module_utils.basic.AnsibleModule') as am:
        am.params = {'shell': 'bash'}
        assert quote(None) == "''"
        assert quote('test') == 'test'
        assert quote('t e\ns t') == 't\ e\\ns\ t'
        assert quote('test"test') == r'test\"test'
        assert quote('test$test') == r'test\$test'
        assert quote('test!test') == r'test\!test'
        # test backslash escaping
        assert quote(r'test\test') == r'test\\test'
        assert quote(r'test\\test') == r'test\\\\test'

# Generated at 2022-06-21 04:30:31.452623
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3, [4, 5], [6], 7, 8, [9, 10]]) == list(range(1, 11))
    assert flatten([1, 2, 3, [4, 5], [6], 7, 8, [9, 10]], levels=1) == [1, 2, 3, 4, 5, 6, 7, 8, [9, 10]]
    assert flatten([1, 2, 3, [4, 5], [6], 7, 8, [9, 10]], levels=2) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-21 04:30:34.992306
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', None) == time.strftime('%Y')
    assert strftime('%Y', 1427576965.49) == '2015'
    assert strftime('%Y-%m-%d', '2015-03-27') == '2015-03-27'



# Generated at 2022-06-21 04:30:48.205160
# Unit test for function from_yaml
def test_from_yaml():
    x = "test"
    assert (from_yaml(x)) == "test"

    x = "{'test': 1, 'test2': 2}"
    assert (from_yaml(x)) == {'test': 1, 'test2': 2}

    x = "yes"
    assert (from_yaml(x)) == "yes"

    x = "{'test': 1, 'test2': 2}"
    y = "{'test': 1, 'test2': 2}"
    assert (from_yaml(x) == from_yaml(y))

    x = "['test', 'test2']"
    assert (from_yaml(x)) == ['test', 'test2']

    x = "['test', 'test2']"
    y = "['test', 'test2']"

# Generated at 2022-06-21 04:30:55.351890
# Unit test for function to_json
def test_to_json():
    my_list = [1, 2, 3]
    my_dict = {'1': 'one', '2': 'two', '3': 'three'}
    assert to_json(my_list) == '[1, 2, 3]', 'list is not serialized to JSON array'
    assert to_json(my_dict) == '{"1": "one", "2": "two", "3": "three"}', 'dict is not serialized to JSON object'
    assert to_json(True) == 'true', 'bool is not serialized to JSON boolean'


# Generated at 2022-06-21 04:31:01.589210
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(get_hash('abc') + get_hash('abc'), hashtype='sha1') == get_hash('abcabc', hashtype='sha1')
    assert get_hash(get_hash('abc') + get_hash('abc'), hashtype='md5') == get_hash('abcabc', hashtype='md5')



# Generated at 2022-06-21 04:31:06.530139
# Unit test for function ternary
def test_ternary():
    assert ternary(None, "a", "b") is None
    assert ternary("abc", "a", "b") == "a"
    assert ternary(False, "a", "b") == "b"
    assert ternary(0, "a", "b") == "b"
    assert ternary(0, "a", "b", none_val="c") == "c"



# Generated at 2022-06-21 04:31:12.799252
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'123_$*.') == r'123\_\$\*\.'
    assert regex_escape(r'123_$*.', re_type='posix_basic') == r'123\_\$\*\.'
#           assert regex_escape(r'123_$*.', re_type='posix_extended') == r'123_\$\*.'
    assert regex_escape(r'123_$*.', re_type='invalid') == 'Invalid regex type (invalid)'



# Generated at 2022-06-21 04:31:15.378089
# Unit test for function path_join
def test_path_join():
    expected = '/dir/dir2'
    result = path_join(['/dir', 'dir2'])
    assert result == expected, "First test failed: %s" % result
    result = path_join('/dir/dir2')
    assert result == expected, "Second test failed: %s" % result


# Generated at 2022-06-21 04:31:22.573112
# Unit test for function subelements
def test_subelements():
    element_list = [{'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']},
                    {'name': 'bob', 'groups': ['admins', 'users'], 'authorized': []},
                    {'name': 'charlie', 'groups': [], 'authorized': ['/var/lib/charlie/.ssh/id_rsa.pub']},
                    {'name': 'dave', 'groups': [], 'authorized': ['/tmp/dave/mykey.pub', '/root/davekey.pub']}]

# Generated at 2022-06-21 04:31:38.321785
# Unit test for function b64decode
def test_b64decode():
    """ Validate that b64decode works as expected
    """
    b64_string = "dGVzdGluZyBzdHJpbmc="
    assert passlib.hash.md5_crypt.encrypt("testing string") == b64decode(b64_string)


# Generated at 2022-06-21 04:31:50.611011
# Unit test for function to_nice_yaml

# Generated at 2022-06-21 04:31:56.562950
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'list': [1, 2, 3]}, default_flow_style=False) == u"list:\n- 1\n- 2\n- 3\n"
    assert to_yaml({'dict': {'a': 1, 'b': 2}}, default_flow_style=False) == u"dict:\n  a: 1\n  b: 2\n"
    assert to_yaml({'dict': {'a': 1, 'b': 2}}, default_flow_style=True) == u"{dict: {a: 1, b: 2}}\n"
    assert to_yaml("Hello world!") == u"!str Hello world!\n"

# Generated at 2022-06-21 04:32:01.136222
# Unit test for function comment
def test_comment():
    print("Test comment:")
    test_text = u'* simple test'
    print(comment(test_text, style='plain'))
    print(comment(test_text, style='erlang'))
    print(comment(test_text, newline='\n', style='c'))
    print(comment(test_text, newline='\n', style='cblock'))
    print(comment(test_text, newline='\n', style='xml'))

    test_text = u'simple test'
    print(comment(test_text, decoration='<!--', newline='\n', style='xml'))

    test_text = u'''* simple test
* another line'''
    print(comment(test_text, decoration='/*', newline='\n'))

    test_text = u''

# Generated at 2022-06-21 04:32:10.498270
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('True') is True
    assert to_bool('true') is True
    assert to_bool('YES') is True
    assert to_bool('yes') is True
    assert to_bool('yEs') is True
    assert to_bool('1') is True
    assert to_bool('on') is True
    assert to_bool('On') is True
    assert to_bool(1) is True
    assert to_bool(True) is True
    assert to_bool('false') is False
    assert to_bool('False') is False
    assert to_bool('NO') is False
    assert to_bool('no') is False
    assert to_bool('nO') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool(0) is False

# Generated at 2022-06-21 04:32:11.530466
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()

# Code for running doctests
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 04:32:18.019471
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{a: 1}') == {u'a': 1}
    assert from_yaml('{a: 1}') != {'a': 1}
    assert from_yaml(to_text('{a: 1}')) == {u'a': 1}
    assert from_yaml(to_text('{a: 1}')) != {'a': 1}



# Generated at 2022-06-21 04:32:24.205376
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2017-12-31 10:45:30", "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d %H:%M:%S") == "2017-12-31 10:45:30"



# Generated at 2022-06-21 04:32:36.440425
# Unit test for function flatten
def test_flatten():
    # Test 1
    mv = "one,two,three,four"
    mvl = flatten(mv)
    assert ','.join(mvl) == mv
    # Test 2
    mv = "[one, two, [three, four, [five, six]]]"
    mvl = flatten(mv)
    assert ','.join(mvl) == "one,two,three,four,five,six"
    # Test 3
    mvl = flatten(mv, 1)
    assert ','.join(mvl) == "one,two,[three, four, [five, six]]"
    # Test 4
    mvl = flatten(mv, 2)
    assert ','.join(mvl) == "one,two,three,four,[five, six]"
    # Test 5


# Generated at 2022-06-21 04:32:43.269377
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5], 'seed') == [4, 1, 2, 5, 3]
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]



# Generated at 2022-06-21 04:32:58.957426
# Unit test for function to_json
def test_to_json():
    print('function: %s' % sys._getframe().f_code.co_name)
    assert to_json(['a', 'b', 'c']) == '["a", "b", "c"]'
    dict1 = dict(a='b', c='d')
    dict2 = dict(e='f', g='h')
    assert to_json(dict1) == '{"a": "b", "c": "d"}'
    assert to_json([dict1, dict2]) == '[{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]'



# Generated at 2022-06-21 04:33:05.989831
# Unit test for function to_json
def test_to_json():
    a = {'foo': ['bar', 'baz']}
    assert to_json(a) == '{"foo": ["bar", "baz"]}'

# Legacy filters
to_json.__doc__ = to_json.__doc__.replace('the value', 'a value')


# Generated at 2022-06-21 04:33:14.541270
# Unit test for function comment

# Generated at 2022-06-21 04:33:20.133292
# Unit test for function rand
def test_rand():
    assert rand([1, 2, 3]) in [1, 2, 3]
    assert rand(10, 50, 5) in range(10, 50, 5)
    assert rand(0, 100, 10) in range(0, 100, 10)



# Generated at 2022-06-21 04:33:30.552358
# Unit test for function do_groupby
def test_do_groupby():
    jinja_env = jinja2.Environment()
    jinja_env.filters['groupby'] = do_groupby
    mylist = [{'a': 'x', 'b': 'X', 'c': '1'},
              {'a': 'y', 'b': 'Y', 'c': '2'},
              {'a': 'z', 'b': 'Z', 'c': '2'}]
    template = '{{ mylist | groupby("c") | map(attribute="grouper") | list }}'
    rendered = jinja_env.from_string(template).render(dict(mylist=mylist))
    # do_groupby should return a list of tuples, not a list of namedtuples
    assert len(eval(rendered)) == 2

# Generated at 2022-06-21 04:33:33.634717
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y") == time.strftime("%Y", time.localtime())



# Generated at 2022-06-21 04:33:39.860774
# Unit test for function from_yaml
def test_from_yaml():
    b = to_bytes('---\na: 1\n')
    assert from_yaml(b) == {'a': 1}
    b = to_bytes('\x82')
    assert from_yaml(b) == b
    b = '\x82'
    assert (from_yaml(b) == b)



# Generated at 2022-06-21 04:33:45.377452
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%Y', 1450000000000) == '2016'
    try:
        strftime('%Y', 'foobar')
        assert 0
    except Exception:
        pass
    return

# Generated at 2022-06-21 04:33:52.999505
# Unit test for function extract
def test_extract():
    env = DummyEnvironment()
    testdict = {
        'a': {
            'b': {
                'c': {
                    'd': [
                        1,
                        2,
                        3
                    ]
                }
            }
        }
    }
    assert extract(env, ['c', 'd'], testdict) == [
        1,
        2,
        3
    ]
    assert extract(env, 'c', testdict) == {
        'd': [
            1,
            2,
            3
        ]
    }
    assert extract(env, 'c', testdict, morekeys='d') == [
        1,
        2,
        3
    ]

# Generated at 2022-06-21 04:34:04.505012
# Unit test for function flatten
def test_flatten():
    assert flatten([]) == []
    assert flatten(["a", "b", "c"]) == ["a", "b", "c"]
    assert flatten(["a", "b", ["c", "d"]]) == ["a", "b", "c", "d"]
    assert flatten(["a", ["b", ["c", "d"]]]) == ["a", "b", "c", "d"]
    assert flatten(["a", ["b", [None, "d"]]]) == ["a", "b", None, "d"]
    assert flatten(["a", ["b", ["c", "d"]]], skip_nulls=False) == ["a", "b", "c", "d"]

# Generated at 2022-06-21 04:34:27.070155
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test_string', 'es') == 'es'
    assert regex_search('test_string', 'st') == 'st'
    assert regex_search('test_string', '^t') == 't'
    assert regex_search('test_string', 'g$') == 'g'
    assert regex_search('test_string', r'\g<0>') == 'test_string'
    assert regex_search('test_string', r'\g<1>') == 't'
    assert regex_search('test_string', r'\g<1>', r'\g<2>') == ['t', 's']
    assert regex_search('test_string', r'\g<1>', r'\g<3>') == ['t', None]

# Generated at 2022-06-21 04:34:31.049576
# Unit test for function b64encode
def test_b64encode():
    TEST_STRING = "This is a string"
    TEST_ENCODING = 'utf-8'
    assert b64encode(TEST_STRING, TEST_ENCODING) == base64.b64encode(to_bytes(TEST_STRING, encoding=TEST_ENCODING, errors='surrogate_or_strict'))


# Generated at 2022-06-21 04:34:37.126331
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json([1,2,3]) == '[\n    1,\n    2,\n    3\n]'
    assert to_nice_json(dict(a=1,b=2,c=3)) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert to_nice_json({'a':[1,2,3]}, sort_keys=False) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'
    assert to_nice_json({'a':[1,2,3]}, sort_keys=True) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-21 04:34:44.339251
# Unit test for function to_json
def test_to_json():
    assert to_json({'a': 'b'}) == '{"a": "b"}'
    assert to_json({'a': 'b', 'c': 'd'}, indent=2) == '{\n  "a": "b",\n  "c": "d"\n}'
    assert to_json({'a': 'b', 'c': 'd'}, sort_keys=True) == '{"a": "b", "c": "d"}'
    assert to_json({'a': 'b', 'c': 'd'}, separators=(',', ':')) == '{"a":"b","c":"d"}'



# Generated at 2022-06-21 04:34:54.973142
# Unit test for function rand
def test_rand():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variables=VariableManager(), host_list=[])
    templar = Templar(loader=loader, variables=inventory.get_vars())
    assert templar._compile_filter('random', 'rand', None)(end=3) in range(3)
    assert templar._compile_filter('random', 'rand', None)(end=3, start=1, step=1) in range(1, 3)
    assert templar._compile_filter('random', 'rand', None)(end=[1, 2, 3]) in [1, 2, 3]

# Generated at 2022-06-21 04:35:01.601392
# Unit test for function to_bool
def test_to_bool():
    '''
    Basic test of to_bool.
    '''
    # None or already boolean should return the same value
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None

    # Different ways of saying True
    assert to_bool("yes") is True
    assert to_bool("on") is True
    assert to_bool("1") is True
    assert to_bool("true") is True
    assert to_bool(1) is True

    # Non-default falsy values should return False
    assert to_bool("") is False
    assert to_bool("false") is False
    assert to_bool("0") is False
    assert to_bool("off") is False
    assert to_bool("no") is False
    assert to_bool(0)

# Generated at 2022-06-21 04:35:08.977897
# Unit test for function to_yaml
def test_to_yaml():
    # Verify that the to_yaml filter works correctly
    results = to_yaml(
        {
            'foo': 'bar',
            'baz': ['one', 'two', 'three'],
        }
    )
    assert results == 'foo: bar\nbaz:\n- one\n- two\n- three\n'
    results = to_yaml(
        {
            'foo': 'bar',
            'baz': ['one', 'two', 'three'],
        },
        default_flow_style=False
    )
    assert results == 'foo: bar\nbaz:\n- one\n- two\n- three\n'

# Generated at 2022-06-21 04:35:17.490386
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    obj = {'a': {'b': {'c': ['foo', 'bar']}}}
    assert subelements(obj, 'a.b.c') == [({'b': {'c': ['foo', 'bar']}}, 'foo'), ({'b': {'c': ['foo', 'bar']}}, 'bar')]
    obj = [{'a': {'b': {'c': ['foo', 'bar']}}}]

# Generated at 2022-06-21 04:35:26.017640
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    src = {'a': {'b': range(0,10), 'c': u'foo'}}
    res = to_nice_yaml(src)
    assert res == text_type(u'a:\n'
        u'    b:\n'
        u'    - 0\n'
        u'    - 1\n'
        u'    - 2\n'
        u'    - 3\n'
        u'    - 4\n'
        u'    - 5\n'
        u'    - 6\n'
        u'    - 7\n'
        u'    - 8\n'
        u'    - 9\n'
        u'    c: foo\n')



# Generated at 2022-06-21 04:35:35.100462
# Unit test for function from_yaml
def test_from_yaml():
    assert list == type(from_yaml('[1, 2, 3]'))
    assert dict == type(from_yaml('{a: b}'))
    assert list == type(from_yaml(u'[1, 2, 3]'))  # noqa: F821
    assert dict == type(from_yaml(u'{a: b}'))

    assert list == type(from_yaml('[1, 2, 3]', loader=yaml.Loader))
    assert dict == type(from_yaml('{a: b}', loader=yaml.Loader))
    assert list == type(from_yaml(u'[1, 2, 3]', loader=yaml.Loader))
    assert dict == type(from_yaml(u'{a: b}', loader=yaml.Loader))




# Generated at 2022-06-21 04:35:52.207182
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import lib.ansible.module_utils.facts as facts
    fm = FilterModule()
    # Don't test 'subelements' filter as it calls extract, which is not mocked
    my_filters = [filter_name for filter_name in fm.filters() if filter_name != 'subelements']

# Generated at 2022-06-21 04:36:00.791297
# Unit test for function to_json
def test_to_json():
    res = to_json(dict(a=1, b=2, c=3))
    assert res == '{"c": 3, "b": 2, "a": 1}'
    res = to_json(dict(a=1, b=2, c=3), indent=4)
    assert res == '{\n    "c": 3,\n    "b": 2,\n    "a": 1\n}'



# Generated at 2022-06-21 04:36:02.402167
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))



# Generated at 2022-06-21 04:36:15.103709
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = 'test_password'
    ret = get_encrypted_password(password)
    assert isinstance(ret, string_types)
    # assert ret == '$1$xxxxx$xxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    ret = get_encrypted_password('test_password', 'sha256')
    assert isinstance(ret, string_types)
    ret = get_encrypted_password('test_password', 'sha512')
    assert isinstance(ret, string_types)
    ret = get_encrypted_password('test_password', 'blowfish')
    assert isinstance(ret, string_types)
    try:
        ret = get_encrypted_password('test_password', 'bad_hashtype')
    except AnsibleFilterError as e:
        assert str(e) == 'passlib hash algorithm "bad_hashtype" is not supported'


# Generated at 2022-06-21 04:36:27.381211
# Unit test for function regex_escape
def test_regex_escape():
    from distutils.version import LooseVersion
    import re as __re

    re_python = regex_escape('$a,b.c*d?e[f\\g]h^i(j|k)l{m}n', re_type='python')
    if LooseVersion(__re.__version__) >= LooseVersion('2.9'):
        assert re_python == r'\$a\,b\.c\*d\?e\[f\\g\]h\^i\(j\|k\)l\{m\}n'
    else:
        assert re_python == r'\$a\,b\.c\*d\?e\[f\\g\]h\^i\(j\|k\)l\{m\}n'

# Generated at 2022-06-21 04:36:30.483232
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('foobum', r'(b|d)um', ignorecase=True) == ['bum']



# Generated at 2022-06-21 04:36:44.543992
# Unit test for function fileglob
def test_fileglob():
    if not os.path.exists(os.getcwd() + '/fileglob'):
        os.makedirs(os.getcwd() + '/fileglob')
    with open(os.getcwd() + '/fileglob/file1.txt', 'w') as f:
        f.write('')
    with open(os.getcwd() + '/fileglob/file2.txt', 'w') as f:
        f.write('')
    with open(os.getcwd() + '/fileglob/file3.txt', 'w') as f:
        f.write('')
    os.makedirs(os.getcwd() + '/fileglob/dir1')
    os.makedirs(os.getcwd() + '/fileglob/dir2')
   

# Generated at 2022-06-21 04:36:55.939207
# Unit test for function list_of_dict_key_value_elements_to_dict

# Generated at 2022-06-21 04:37:08.466662
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('string', namespace='36b5495a-4e4b-4c85-b96e-988f9b949b2a') == '6f7f0e2e-7b14-5f93-bd0e-c32f21b67f37'
    assert to_uuid('string', namespace=uuid.UUID('{36b5495a-4e4b-4c85-b96e-988f9b949b2a}')) == '6f7f0e2e-7b14-5f93-bd0e-c32f21b67f37'

# Generated at 2022-06-21 04:37:10.564458
# Unit test for function path_join
def test_path_join():
    seq_input = ['/opt', 'fiz', 'bin', 'fuz']
    str_input = "/opt/fiz/bin/fuz"
    assert path_join(seq_input) == str_input
    assert path_join(str_input) == str_input


# Generated at 2022-06-21 04:37:26.239511
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert flatten([[1, 2], 3, 4]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4, [5]]]]]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, [4, [5]]]], 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-21 04:37:33.087222
# Unit test for function regex_search
def test_regex_search():
    # Test regex_search from Jinja2
    from ansible.module_utils.six.moves import builtins
    setattr(builtins, 'lookup', {
        'regex': {
            'regex_search': regex_search,
        },
    })

    def run_test(value, regex, *args, **kwargs):
        # Wrap the regex search in a Jinja2 template
        template = '{{ "%s" | regex_search(r"%s", %s) }}' % (value, regex, ', '.join(['"%s"' % arg for arg in args]))
        return template.format(value=value, regex=regex, args=args, kwargs=kwargs)

    # Test regex_search with backrefs

# Generated at 2022-06-21 04:37:40.615932
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("YW55IGNhcm5hbCBwbGVhcw==") == "any carnal pleas"
    utf8_encoded = u"YW55IGNhcm5hbCBwbGVhc3U="
    assert b64decode(utf8_encoded) == u"any carnal pleasu"


# Generated at 2022-06-21 04:37:47.995916
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo") == "foo"
    assert from_yaml(u"foo") == "foo"
    assert from_yaml("2") == 2
    assert from_yaml("2.3") == 2.3
    assert from_yaml("true") == True
    assert from_yaml("false") == False
    assert from_yaml("null") == None



# Generated at 2022-06-21 04:37:52.157348
# Unit test for function to_json
def test_to_json():
    # Simple list
    assert to_json(['test', 'test']) == '["test", "test"]'

    # String
    assert to_json('string') == '"string"'

    # Dictionary
    assert to_json({'key': 'value'}) == '{"key": "value"}'

    # Integer
    assert to_json(5) == '5'

    # Unicode
    assert to_json(u'abcd') == '"abcd"'



# Generated at 2022-06-21 04:38:03.475669
# Unit test for function quote
def test_quote():
    assert quote(u"Hello world") == u"'Hello world'"
    assert quote(u"Hello world's") == u"'Hello world'\\''s'"
    assert quote(u"Hello world\\") == u"'Hello world\\'"
    assert quote(u"'Hello world'") == u"''\\''Hello world'\\'''"
    assert quote(u"Hello 'world'") == u"'Hello '\\''world'\\'''"
    assert quote(u"Hello 'world\\'s'") == u"'Hello '\\''world'\\\\''s'\\'''"
    assert quote(u"He said 'Hello world'") == u"'He said '\\''Hello world'\\'''"



# Generated at 2022-06-21 04:38:05.337949
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) > 0
    assert 'md5' in filters
    assert 'quote' in filters

# Generated at 2022-06-21 04:38:11.465870
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-21 04:38:16.306494
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(2) == 2

    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'abc' not defined."

    try:
        mandatory(Undefined(), '{} is undefined.')
    except AnsibleFilterError as e:
        assert to_text(e) == "abc is undefined."


# Generated at 2022-06-21 04:38:19.479579
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters()['groupby'] == do_groupby

# Generated at 2022-06-21 04:38:57.915689
# Unit test for function subelements
def test_subelements():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.base import Base
    from ansible.utils._text import to_text

    class FakeBase(Base):
        def __init__(self, **kwargs):
            self._attributes = {key: FieldAttribute(self, key, FieldAttribute.NO_CONVERT)
                                for key in kwargs}
            for key, value in kwargs.items():
                setattr(self, key, value)

        @staticmethod
        def load(data, file_name=None, vault_password=None):
            if data is None:
                data = {}
            elif isinstance(data, string_types):
                data = to_

# Generated at 2022-06-21 04:39:08.485310
# Unit test for function combine
def test_combine():
    assert {'a': 'A', 'b': 'B'} == combine({"a": "A"}, {"b": "B"})
    assert {'a': 'A', 'b': 'B'} == combine({"a": "A"}, {"b": "B"}, {})
    assert {'a': 'A', 'b': 'B'} == combine({}, {"a": "A"}, {"b": "B"}, {})
    assert {'a': 'A', 'b': ['B']} == combine({}, {"a": "A"}, {"b": ["B"]}, {})
    assert {'a': 'A', 'b': 'C'} == combine({"a": "A", "b": "B"}, {"b": "C"})
    assert {'x': 'X', 'a': 'A', 'b': 'C'}

# Generated at 2022-06-21 04:39:10.819724
# Unit test for function b64decode
def test_b64decode():
    test_data = [
        ("InB5dGhvbg==", "python"),
        ("InB5dGhvbi4=", "python."),
        ("InB5dGhvbi4u", "python..")
    ]
    for d in test_data:
        if b64decode(*d) != d[1]:
            raise Exception("Encoding of string failed.")



# Generated at 2022-06-21 04:39:13.349154
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M") == time.strftime("%Y-%m-%d %H:%M")



# Generated at 2022-06-21 04:39:23.402742
# Unit test for function regex_findall
def test_regex_findall():
    valid = [('field1', 'field2', 'field3'),
             ('field4', 'field5', 'field6'),
             ('field7', 'field8', 'field9')]
    data = '''
field1,field2,field3
field4,field5,field6
field7,field8,field9
'''
    res = regex_findall(data, r'(\w+)\s*?,\s*?(\w+)\s*?,\s*?(\w+)', multiline=True)
    assert res == valid



# Generated at 2022-06-21 04:39:26.750145
# Unit test for function to_yaml
def test_to_yaml():
    '''to_yaml returns a string'''
    assert isinstance(to_yaml({'foo': 'bar'}), string_types)



# Generated at 2022-06-21 04:39:35.151632
# Unit test for function regex_replace
def test_regex_replace():
    ''' Unit test for function regex_replace '''
    test_string = '''
    user1: "password1"
    user2: "password2"
    user3: "password3"
    '''
    assert regex_replace(test_string, pattern='(user\d+: ").+("$)', replacement=r"\1********\2", ignorecase=False, multiline=False) == '''
    user1: "password1"
    user2: "password2"
    user3: "password3"
    '''

# Generated at 2022-06-21 04:39:44.583852
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y%m%d-%H%M%S") == time.strftime("%Y%m%d-%H%M%S")
    assert strftime("%Y%m%d-%H%M%S", second=0) == time.strftime("%Y%m%d-%H%M%S", time.localtime(0))
    assert strftime("%Y%m%d-%H%M%S", second="0") == time.strftime("%Y%m%d-%H%M%S", time.localtime(0))
    assert strftime("%Y%m%d-%H%M%S", second="0.0") == time.strftime("%Y%m%d-%H%M%S", time.localtime(0))
    assert strftime

# Generated at 2022-06-21 04:39:48.728610
# Unit test for function strftime

# Generated at 2022-06-21 04:39:57.004464
# Unit test for function quote
def test_quote():
    assert quote('hello') == '\'hello\''
    assert quote("hello world") == '\'hello world\''
    assert quote("'hello'") == '"\'hello\'"'
    assert quote("hello''") == '"hello\'\'"'
    assert quote("'hello''") == '"\'hello\'\'"'
    assert quote(True) == 'True'
    assert quote(None) == '\'\''
    assert quote([]) == '[]'
    assert quote(['hello', 'world']) == '["hello", "world"]'
    assert quote({}) == '{}'
    assert quote({'a': 'b'}) == "{'a': 'b'}"
    assert quote(['a', 1, [], {}, None]) == '["a", 1, [], {}, None]'