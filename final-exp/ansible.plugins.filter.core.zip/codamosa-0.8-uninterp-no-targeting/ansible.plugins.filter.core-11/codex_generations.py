

# Generated at 2022-06-21 04:30:24.905666
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mydict = {'key': 'value'}
    test_string = "items2dict requires a list of dicts with a 'key' and 'value' keys, got %s instead."
    # mylist not a list
    try:
        list_of_dict_key_value_elements_to_dict(mydict)
    except AnsibleFilterTypeError as e:
        assert (to_native(e) == test_string % (type(mydict)))
    # mylist is a list with a single dict, but the dict has not the right keys
    mylist = [mydict]
    try:
        list_of_dict_key_value_elements_to_dict(mylist)
    except AnsibleFilterTypeError as e:
        assert (to_native(e) == test_string % (type(mylist)))


# Generated at 2022-06-21 04:30:31.251473
# Unit test for function randomize_list
def test_randomize_list():
    # testing string
    mylist = ['foo', 'bar', 'baz', 'baz']
    assert randomize_list(mylist, seed='') == ['baz', 'bar', 'baz', 'foo']
    # testing arrays of integers
    mylist_i = [1, 2, 3, 4, 5, 6]
    assert randomize_list(mylist_i, seed='abcd') == [4, 2, 6, 5, 3, 1]



# Generated at 2022-06-21 04:30:40.923293
# Unit test for function comment

# Generated at 2022-06-21 04:30:44.896946
# Unit test for function to_json
def test_to_json():
    data = dict(ip_address="10.10.10.10")
    result = to_json(data)
    assert result == '{"ip_address": "10.10.10.10"}', result



# Generated at 2022-06-21 04:30:55.464541
# Unit test for function comment
def test_comment():
    # Default and empty
    assert comment("Text") == '\n# Text'
    assert comment("") == '\n# '
    assert comment("", decoration='! ') == '\n! '
    assert comment("Text", decoration='! ') == '\n! Text'
    # Default with prefix and postfix
    assert comment("Text", decoration='! ', prefix='> ', postfix=' >') == '\n> ! Text >'
    assert comment("Text", decoration='! ', prefix='> ', postfix=' >', prefix_count=2, postfix_count=2) == '\n> > ! Text > >'
    assert comment("Text", decoration='! ', prefix='> ', postfix=' >', prefix_count=0, postfix_count=0) == '\n! Text'

# Generated at 2022-06-21 04:30:59.557580
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert "a" in from_yaml_all("---\na\n---\nb")
    assert "b" in from_yaml_all("---\na\n---\nb")



# Generated at 2022-06-21 04:31:01.983409
# Unit test for constructor of class FilterModule
def test_FilterModule():
    cls = FilterModule()
    assert isinstance(cls, FilterModule) is True


# Generated at 2022-06-21 04:31:14.615178
# Unit test for function flatten
def test_flatten():
    assert flatten([3, 4, 5, 6]) == [3, 4, 5, 6]
    assert flatten(['str', 3, [4, 5], 6]) == ['str', 3, 4, 5, 6]
    assert flatten([['str', 3], [4, 5], 6]) == ['str', 3, 4, 5, 6]
    assert flatten([['str', 3], [4, [5, 6]]]) == ['str', 3, 4, 5, 6]
    assert flatten([['str', 3], [4, [5]], 6, 7]) == ['str', 3, 4, 5, 6, 7]
    assert flatten([[1, 2, 3], [4, [5]], 6, 7], levels=1) == [1, 2, 3, 4, [5], 6, 7]

# Generated at 2022-06-21 04:31:27.917878
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' dict_to_list_of_dict_key_value_elements returns a list of dict elements of
        the key/value pairs of the input dict.
        By default, the key and value elements from the dict are named
        'key' and 'value', but this can be overridden by specifying the
        key_name and value_name values. '''

    inputdict = dict(foo=42, bar=43)
    expected = [
        {'key': 'foo', 'value': 42},
        {'key': 'bar', 'value': 43},
    ]
    ret = dict_to_list_of_dict_key_value_elements(inputdict)
    assert ret == expected, 'Got %s instead of %s' % (ret, expected)

    # test with overridden key/value names


# Generated at 2022-06-21 04:31:37.979371
# Unit test for function subelements
def test_subelements():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    obj = [{AnsibleUnicode("name"): AnsibleUnicode("alice"),
            AnsibleUnicode("groups"): [AnsibleUnicode("wheel")],
            AnsibleUnicode("authorized"): [AnsibleUnicode("/tmp/alice/onekey.pub")]
            }]
    expected = [(obj[0], "wheel")]
    actual = subelements(obj, "groups")
    assert actual == expected


# Generated at 2022-06-21 04:31:46.721223
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    entry = {"name": "test", "state": "present", "groups": ["wheel", "ssh"]}
    result = to_nice_yaml(entry)
    assert result == u'groups:\n- ssh\n- wheel\nname: test\nstate: present\n'


# Generated at 2022-06-21 04:31:49.868812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_groupby(None, None, None)==_do_groupby(None, None, None)

# Generated at 2022-06-21 04:32:00.695586
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Arrange
    mod = FilterModule()
    mydict = {'a': 'b', 'c': 'd', 'e': 'f'}
    mylist = [{'key': 'a', 'value': 'b'}, {'key': 'c', 'value': 'd'}, {'key': 'e', 'value': 'f'}]

    # Test dict2items
    ret = mod.filters()['dict2items'](mydict)
    assert ret == mylist

    # Test items2dict
    ret = mod.filters()['items2dict'](mylist)
    assert ret == mydict


# This is here to ensure that unit test for method filters of class FilterModule can
# be run on its own without errors. It will be called when invoked with:
# python -m ansible.module_utils.common

# Generated at 2022-06-21 04:32:08.080118
# Unit test for function to_nice_json
def test_to_nice_json():
    data = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}, 'd': 'hello'}
    assert to_nice_json(data) == '{\n    "a": 1,\n    "b": 2,\n    "c": {\n        "a": 1,\n        "b": 2\n    },\n    "d": "hello"\n}', \
        "to_nice_json did not return expected result"


# Generated at 2022-06-21 04:32:19.921429
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('foo','[^ ]*') == ['foo']
    assert regex_findall('foo','f([^ ]*)') == ['oo']
    assert regex_findall('foo', 'fo(o)') == ['o']
    assert regex_findall('foo', '([^ ]*)') == ['foo']
    assert regex_findall('foo', '([^ ]*)', multiline=True) == ['foo']
    # Ignore case
    assert regex_findall('foo', '([^ ]*)', ignorecase=True, multiline=True) == ['foo']
    assert regex_findall('FOO', '([^ ]*)', ignorecase=True, multiline=True) == ['FOO']
    assert regex_findall('foo', '([^ ]*)', ignorecase=True) == ['foo']


# Generated at 2022-06-21 04:32:25.214067
# Unit test for function combine
def test_combine():
    import yaml
    # test 1
    d1 = {'a_dict': {'a': 1, 'b': 2}}
    d2 = {'a_dict': {'b': 3, 'c': 4}}
    assert combine(d1, d2) == {'a_dict': {'a': 1, 'b': 3, 'c': 4}}
    # test 2
    d1 = {'a_list': [1, 2, 3]}
    d2 = {'a_list': [3, 4, 5]}
    assert combine(d1, d2) == {'a_list': [1, 2, 3, 4, 5]}
    # test 3
    d1 = {'a_list': [1, 2, ['a', 'b']]}

# Generated at 2022-06-21 04:32:40.499374
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    dict_to_list_of_dict_key_value_elements_output = [{'value': 'alice', 'key': 'name'}, {'value': ['wheel'], 'key': 'groups'}, {'value': ['/tmp/alice/onekey.pub'], 'key': 'authorized'}]
    assert dict_to_list_of_dict_key_value_elements({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}) == dict_to_list_of_dict_key_value_elements_output


# Generated at 2022-06-21 04:32:46.230877
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('This is a string', 'is') == ['is', 'is']
    assert regex_findall('This is a string', 'li') == ['li']
    assert regex_findall('This is a string', '123') == []
    assert regex_findall('This is a string', ' ') == [' ', ' ']



# Generated at 2022-06-21 04:32:50.550002
# Unit test for function fileglob
def test_fileglob():
    glob_path = "/etc/resolv.conf*"
    pathname = fileglob(glob_path)
    assert '/etc/resolv.conf' in pathname



# Generated at 2022-06-21 04:32:53.601126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm
    assert fm.filters()


# Generated at 2022-06-21 04:33:12.625436
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([1,2,3]) == "- 1\n- 2\n- 3\n"
    assert to_nice_yaml({'a':1,'b':2,'c':3}) == "a: 1\nb: 2\nc: 3\n"
    assert to_nice_yaml({'items':[1,2,3]}) == "items:\n- 1\n- 2\n- 3\n"
    assert to_nice_yaml({'items':{"a":1,"b":2,"c":3}}) == "items:\n  a: 1\n  b: 2\n  c: 3\n"
    # The function to_nice_yaml should not be using the yaml_load defaults

# Generated at 2022-06-21 04:33:16.512869
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b'Zm9vYmFyCg==') == u'foobar\n'



# Generated at 2022-06-21 04:33:19.142929
# Unit test for function b64decode
def test_b64decode():
    test_string = u'こんにちは'
    assert test_string == b64decode(b64encode(test_string))

# Generated at 2022-06-21 04:33:23.355243
# Unit test for function combine
def test_combine():
    import sys
    import doctest

    print("running combined doctests")
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-21 04:33:31.281130
# Unit test for function quote
def test_quote():
    assert quote('foo') == u"'foo'"
    assert quote('foo bar') == r"'foo bar'"
    assert quote('"foo"') == u"'\"foo\"'"
    assert quote('\'"foo"\'') == r"''\"'\"'foo'\"\"''"
    assert quote(u'\'"foo"\'') == r"''\"'\"'foo'\"\"''"
    assert quote(r'\'"foo"\'') == r"''\"'\"'foo'\"\"''"



# Generated at 2022-06-21 04:33:43.993512
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({}) == {}
    assert combine({}, {}) == {}

    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}

    assert combine({'a': 1}, {'a': 2, 'b': 2}) == {'a': 2, 'b': 2}
    assert combine({'a': 1, 'b': 0}, {'a': 2, 'b': 2}) == {'a': 2, 'b': 2}
    assert combine({'a': 1, 'b': 0}, {'a': 2, 'b': 2, 'c': 3}) == {'a': 2, 'b': 2, 'c': 3}


# Generated at 2022-06-21 04:33:50.398779
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('a') == get_hash('a')
    assert get_hash('a') != get_hash('b')
    assert get_hash('a') != get_hash('a', 'md5')
    assert get_hash('a', 'md5') == get_hash('a', 'md5')
    assert get_hash('a', 'unknown') == AnsibleFilterError



# Generated at 2022-06-21 04:34:03.612529
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('Zm9vYmFy', 'utf-8') == 'foobar'
    assert b64decode('Zg==') == 'f'
    assert b64decode('Zm8=') == 'fo'
    assert b64decode('Zm9v') == 'foo'

    # Test encoding
    assert b64decode('ZmfDqQ==', 'ascii') == 'Zm\xc3\xb3'

    # Test errors
    assert b64decode('ZmfDqQ==', 'ascii', 'surrogate_or_strict') == 'Zm\ufffd\ufffd'
    raises(AnsibleFilterError, 'b64decode(u"ZmfDqQ==", u"ascii", u"strict")')


# Generated at 2022-06-21 04:34:14.098116
# Unit test for function flatten
def test_flatten():
    assert flatten([[1], 2, [[3, 4], 5], [[[]]], [[[6]]], 7, 8, []]) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert flatten([[1], 2, [[3, 4], 5], [[[]]], [[[6]]], 7, 8, []], levels=3) == [1, 2, 3, 4, 5, 6, 7, 8]
    assert flatten([[1], 2, [[3, 4], 5], [[[]]], [[[6]]], 7, 8, []], levels=2) == [1, 2, 3, 4, 5, [[]], [[6]], 7, 8]

# Generated at 2022-06-21 04:34:23.175504
# Unit test for function regex_replace
def test_regex_replace():
    value = 'some-string'
    pattern = '[\W]+'
    replacement = '-'
    ignorecase = False
    multiline = False
    assert regex_replace(value, pattern, replacement, ignorecase, multiline) == 'some-string'
    value = 'some-STRING'
    ignorecase = True
    assert regex_replace(value, pattern, replacement, ignorecase, multiline) == 'some-STRING'
    value = 'some-string\nother-string'
    ignorecase = False
    multiline = True
    assert regex_replace(value, pattern, replacement, ignorecase, multiline) == 'some-string\nother-string'
    value = 'some-string\nother-string'
    pattern = '\n'
    replacement = ','
    ignorecase = False
   

# Generated at 2022-06-21 04:34:41.798582
# Unit test for function do_groupby
def test_do_groupby():
    # Test data
    input = [{'foo': 'bar', 'group': 'one'},
             {'foo': 'baz', 'group': 'two'},
             {'foo': 'qux', 'group': 'one'}]
    # Execute the function
    result = do_groupby(None, input, 'group')
    # Validate the result
    assert isinstance(result, list)
    assert isinstance(result[0], tuple)
    assert isinstance(result[1], tuple)
    assert isinstance(result[0][0], six.string_types)
    assert isinstance(result[0][1], list)
    assert isinstance(result[1][0], six.string_types)
    assert isinstance(result[1][1], list)



# Generated at 2022-06-21 04:34:45.988880
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    dict = {"key": "testvalue"}
    assert to_nice_yaml(dict, indent=4) == "key: testvalue\n"


# Generated at 2022-06-21 04:34:55.758017
# Unit test for function to_uuid
def test_to_uuid():
    assert '9e8f5e5e-fa32-5d07-b40a-7cbb44e8c14b' == to_uuid('secret/key1')
    assert 'de3f3d8c-f2de-5568-ad97-e9d8fbbc3388' == to_uuid('secret/key1', None)
    assert '6c89f1d9-06ed-5069-a70c-bbe87d73fab6' == to_uuid('secret/key1', '361e6d51-faec-444a-9079-341386da8e2e')

# Generated at 2022-06-21 04:35:02.985226
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo?') == r'foo\?'
    assert regex_escape(r'foo[*]') == r'foo\[\*\]'
    assert regex_escape('[*]') == r'\[\*\]'
    assert regex_escape(r'foo*bar\baz') == r'foo\*bar\\baz'
    assert regex_escape(r'foo#bar\baz') == r'foo\#bar\\baz'
    assert regex_escape(r'$1') == r'\$1'
    assert regex_escape(r'$1', re_type='posix_basic') == r'$1'
    assert regex_escape(r'\$1', re_type='posix_basic') == r'\\$1'

# Generated at 2022-06-21 04:35:16.332185
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    '''
    Test of the function dict_to_list_of_dict_key_value_elements
    :return: None
    '''
    mydict = {'a': 2, 'b': 4}
    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='key', value_name='value')
    assert result == [{'key': 'a', 'value': 2}, {'key': 'b', 'value': 4}]
    mydict = {'a': {'b': 1, 'c': 2}, 'd': {'e': 3, 'f': 4}}
    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='key', value_name='value')

# Generated at 2022-06-21 04:35:23.197263
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote('') == u"''"
    assert quote('a') == u"a"
    assert quote('a b') == u"a b"  # No quotes for a single token
    assert quote('a b c') == u"a\ b\ c"
    assert quote('a"b') == u"'a\"b'"
    assert quote('a"b c') == u"a\"b\ c"



# Generated at 2022-06-21 04:35:34.404652
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool(True) is True
    assert to_bool('Foo') is False
    assert to_bool('foo') is False
    assert to_bool('Off') is False
    assert to_bool('true') is True
    assert to_bool('True') is True
    assert to_bool('YES') is True
    assert to_bool('no') is False
    assert to_bool('No') is False
    assert to_bool('n') is False
    assert to_bool('0') is False
    assert to_bool('1') is True
    assert to_bool(0) is False
    assert to_bool(1) is True
    assert to_bool(2) is True



# Generated at 2022-06-21 04:35:41.143434
# Unit test for function comment
def test_comment():
    import pytest
    assert comment("text", style='plain') == "# text"
    assert comment("text", style='erlang') == "% text"
    assert comment("text", style='c') == "// text"
    assert comment("text", style='cblock') == "/*\n * text\n */"
    assert comment("text", style='xml') == "<!--\n - text\n-->"
    assert comment("text", style='c', decoration='// ') == "// text"
    assert comment("text", style='c', decoration='fff') == "ffftext"
    assert comment("'''text'''", style='c', decoration='> ') == "> '''text'''"

# Generated at 2022-06-21 04:35:50.587757
# Unit test for function comment
def test_comment():
    # test for function comment
    # 1. test function comment
    # 2. test function comment with a decoration
    # 3. test function comment with a decoration and text on newline
    # 4. test function comment with a decoration and text on newline and new parameters
    print('Test function comment')
    print(comment('A simple comment'))
    print(comment('A simple comment with a decoration', decoration='$ '))
    print(comment('A simple comment with a decoration and text on newline\n', decoration='$ '))
    print(comment('A simple comment with a decoration and text on newline\n', decoration='$ ', prefix='', postfix='', newline=''))


# Generated at 2022-06-21 04:36:00.939848
# Unit test for function to_json
def test_to_json():
    assert json.loads(to_json([1, 2])) == [1, 2]
    assert json.loads(to_json(dict(a=1, b=2))) == dict(a=1, b=2)
    assert json.loads(to_json(dict(a=1, b=[2, 3]))) == dict(a=1, b=[2, 3])
    assert json.loads(to_json(dict(a=1, b=dict(c=2)))) == dict(a=1, b=dict(c=2))



# Generated at 2022-06-21 04:36:10.033757
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/usr/bin/*') != []
    assert fileglob('*') != []
    assert fileglob('*') != ''


# Generated at 2022-06-21 04:36:16.139084
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([['hello', 'world']]) == '''- - hello
  - world
'''
    assert to_nice_yaml({'some': 'dict'}) == '''some: dict
'''



# Generated at 2022-06-21 04:36:19.841310
# Unit test for function from_yaml_all
def test_from_yaml_all():
    data = '---\n- foo: bar\n'
    assert isinstance(from_yaml_all(data), list)



# Generated at 2022-06-21 04:36:30.678731
# Unit test for function quote
def test_quote():
    ''' Unit test for function quote '''
    # shlex_quote will put single quotes around a string if
    # it contains unsafe characters.
    # This includes single quotes.
    # So here we just want to check that the returned string
    # contains single quotes, and therefore is properly wrapped.
    # We will test a few different unsafe characters.
    # Plus, we want to check that it is a string, should
    # be a unicode string on both Python 2 and Python 3.
    # So to_text() is applied to a.
    for a in (u"'", u'"', u'!', u';', u' '):
        assert u"'" in quote(to_text(a))
    # Also, even if a string is safe, we still want to
    # check that it has been quoted.

# Generated at 2022-06-21 04:36:38.539748
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''
    Just to test if all filters are stored and can be invoked.
    '''
    fm = FilterModule()
    filters = fm.filters()
    for filter_name, filter_function in filters.items():
        dummy_text = 'This is a %s filter test.' % filter_name
        try:
            filter_function(dummy_text)
        except:
            raise Exception('Filter "%s" raised exception.' % (filter_name,))

# Generated at 2022-06-21 04:36:50.106737
# Unit test for function to_uuid
def test_to_uuid():
    from ansible.module_utils import basic
    import ansible.module_utils.basic as ansible_basic
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import BytesIO

    class TestAnsibleModule(object):
        def __init__(self):
            self.basic = ansible_basic
            self.run_command = basic.run_command
            self.ANSIBLE_MODULE_KWARGS = {'no_log': True}
            self.log = basic._ANSIBLE_ARGS['module_args']['_ansible_verbosity']

        def exit_json(self, **kwargs):
            sys.stdout.write(json.dumps(kwargs))
            sys.stdout.write('\n')
            sys.exit

# Generated at 2022-06-21 04:36:58.009815
# Unit test for function to_bool
def test_to_bool():
    '''Unit test for function to_bool'''
    true_inputs = [1, True, "yes", "on", "1", "True", True]
    false_inputs = [None, 0, False, "no", "off", "0", "False", False]
    for a in true_inputs:
        assert (to_bool(a) is True)
    for a in false_inputs:
        assert (to_bool(a) is False)
    return True



# Generated at 2022-06-21 04:37:07.171357
# Unit test for function from_yaml_all
def test_from_yaml_all():
    results = []
    test_data = """
- id: 1
  name: record_one
  description: first record
- id: 2
  name: record_two
  description: second record
"""
    for record in from_yaml_all(test_data):
        results.append(record)
    assert len(results) == 2
    assert results[0]['id'] == 1
    assert results[1]['id'] == 2
    assert results[0]['name'] == 'record_one'
    assert results[1]['name'] == 'record_two'



# Generated at 2022-06-21 04:37:11.091530
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('.') == '\.'
    assert regex_escape('.*') == '\.\*'



# Generated at 2022-06-21 04:37:14.839607
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all('a: 1\nb: 2') == [{'a': 1}, {'b': 2}]

# Generated at 2022-06-21 04:37:23.519131
# Unit test for function regex_findall
def test_regex_findall():
  value = """
  This is our list:
  - first item
  - second item
  - third item
  """
  result = regex_findall(value, "(\w+)\s+(\w+)")
  assert result == [('first','item'),('second','item'),('third','item')]



# Generated at 2022-06-21 04:37:30.620724
# Unit test for function ternary
def test_ternary():
    assert ternary({"a": "1", "b": "2"}, "true", "false") == "true"
    assert ternary(True, "true", "false") == "true"
    assert ternary(False, "true", "false") == "false"
    assert ternary("", "true", "false") == "false"
    assert ternary("foo", "true", "false") == "true"
    assert ternary(None, "true", "false") == "false"
    assert ternary(None, "true", "false", "none") == "none"
    return True



# Generated at 2022-06-21 04:37:33.549198
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("Hello World!") == 'SGVsbG8gV29ybGQh'



# Generated at 2022-06-21 04:37:42.185355
# Unit test for function to_yaml
def test_to_yaml():
    '''
    >>> test_to_yaml()
    u'[1, 2, 3, 4]'
    '''
    data = "{'a':1, 'b': [1, 2, 3, 4], 'c': {'c1': {'d1': 'value1', 'd2': 2}, 'c2': 'value2'}}"
    results = to_yaml(data)
    return results


# Generated at 2022-06-21 04:37:47.206119
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{"key": "one", "value": 1}, {"key": "two", "value": 2}, {"key": "three", "value": 3}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'one': 1, 'two': 2, 'three': 3}



# Generated at 2022-06-21 04:37:53.192091
# Unit test for function comment
def test_comment():
    output = comment('Test comment')
    assert output == '# Test comment', output
    output = comment('Test comment', prefix='XXX')
    assert output == 'XXX# Test comment', output
    output = comment('Test comment', prefix_count=2)
    assert output == '# \n# Test comment', output
    output = comment('Test comment', decoration=' - ')
    assert output == '#  - Test comment', output
    output = comment('Test comment', decoration=' - ',
                     postfix=' | ')
    assert output == '#  - Test comment | ', output
    output = comment('Test comment', decoration=' - ',
                     postfix=' | ', postfix_count=2)
    assert output == '#  - Test comment |  | ', output

# Generated at 2022-06-21 04:38:01.111856
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2017-07-07 21:00:00') == datetime.datetime(2017, 7, 7, 21, 0)
    assert to_datetime('2017-07-07T21:00:00Z', format='%Y-%m-%dT%H:%M:%SZ') == datetime.datetime(2017, 7, 7, 21, 0)


# Generated at 2022-06-21 04:38:12.455357
# Unit test for function subelements
def test_subelements():
    """This function uses the doctest syntax to test the function
    'subelements'.
    """
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    expected = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups') == expected
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'authorized')
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert sube

# Generated at 2022-06-21 04:38:20.332953
# Unit test for function from_yaml_all
def test_from_yaml_all():
    yaml_strings = [
        '''- one
        - two
        - three''',
        '''one: 1
        two: 2
        three: 3'''
    ]
    for y in yaml_strings:
        assert isinstance(from_yaml_all(y), list)
    json_strings = [
        '''[
            { "name": "John", "surname": "Doe" },
            { "name": "Jane", "surname": "Doe" }
        ]'''
    ]
    for j in json_strings:
        assert isinstance(from_yaml_all(j), list)



# Generated at 2022-06-21 04:38:33.361544
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    if not passlib_or_crypt.geturandom_available:
        print("Skipping test_get_encrypted_password, geturandom not available on system")
        return
    password = "letmein"
    encrypted_password = get_encrypted_password(password, 'sha512').split('$')
    assert len(encrypted_password) == 5
    assert encrypted_password[0] == '6'
    assert len(encrypted_password[1]) == 16
    assert encrypted_password[2] == 'rounds=5000$'
    assert len(encrypted_password[3]) == 16
    assert len(encrypted_password[4]) == 86

# Generated at 2022-06-21 04:38:41.914426
# Unit test for function strftime
def test_strftime():
    if strftime("%Y-%m-%d %H:%M:%S", 1483438905) == "2017-01-03 23:05:05":
        return True
    else:
        raise Exception("Assertion failure")


# Generated at 2022-06-21 04:38:50.013796
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(None, msg="Null value") == None
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    try:
        assert mandatory(Undefined)
        assert False
    except:
        assert True



# Generated at 2022-06-21 04:39:02.057565
# Unit test for function from_yaml
def test_from_yaml():
    # Simple string
    assert from_yaml("hello") == "hello"
    # Nested dict
    assert from_yaml('{ key: [ "nested", "list" ] }') == {'key': ['nested', 'list']}
    # Nested dict with text wrapper
    assert from_yaml('{ key: [ "nested", "list" ] }'.encode('utf-8')) == {'key': ['nested', 'list']}
    # Nested dict with unsafe key
    assert from_yaml('{ "unsafe\x00key": "value" }') == {'unsafe\x00key': 'value'}



# Generated at 2022-06-21 04:39:09.570110
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    env = jinja2.Environment()
    input_data = [
        {
            "name": "test1",
            "test1_key1": "test1_val1",
        },
        {
            "name": "test1",
            "test1_key2": "test1_val2",
        },
        {
            "name": "test2",
            "test2_key1": "test2_val1",
        }
    ]
    # Calculate the test result using the original function
    test_result = _do_groupby(env, input_data, 'name')
    # Calculate the expected result using the original function
    expected_result = do_groupby(env, input_data, 'name')

    # Verify the results match

# Generated at 2022-06-21 04:39:18.582408
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(b"{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("{'foo': 'bar'}") == {'foo': 'bar'}
    assert from_yaml("- foo\n- bar") == ['foo', 'bar']
    assert from_yaml(b"- foo\n- bar") == ['foo', 'bar']
    assert from_yaml(b"- {'foo': 'bar'}\n- [foo, bar]") == [{'foo': 'bar'}, ['foo', 'bar']]
    assert from_yaml(u"- {'foo': 'bar'}\n- [foo, bar]") == [{'foo': 'bar'}, ['foo', 'bar']]

# Generated at 2022-06-21 04:39:25.184435
# Unit test for function to_bool
def test_to_bool():
    for true in ('True', 'true', '1', 1, True):
        assert to_bool(true) is True

    for false in ('False', 'false', '0', 0, 0.0, False):
        assert to_bool(false) is False

    for error in (None, 'foo', '00', 2, True):
        try:
            to_bool(error)
        except Exception:
            pass
        else:
            assert False



# Generated at 2022-06-21 04:39:37.901877
# Unit test for function rand
def test_rand():
    env = Environment()
    assert rand(env, [1, 2, 3]) in [1, 2, 3]
    assert rand(env, 4, 0) in [0, 1, 2, 3]
    assert rand(env, 5, 0, 2) in [0, 2, 4]
    assert rand(env, 4, seed=None) in [0, 1, 2, 3]
    assert rand(env, 4, seed=0) in [0, 1, 2, 3]
    assert rand(env, 4, seed=0) in [0, 1, 2, 3]
    assert rand(env, 4, seed=1) in [0, 1, 2, 3]



# Generated at 2022-06-21 04:39:43.399601
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = [1,2,3,4,5]
    b = to_nice_yaml(a)
    assert b == "- 1\n- 2\n- 3\n- 4\n- 5\n"


# Generated at 2022-06-21 04:39:55.708535
# Unit test for function extract
def test_extract():
    from ansible.compat.tests import unittest
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    environment = Templar(PlayContext())

    container = {
        "keya": {
            "keyb": {
                "keyc": {
                    "keyd": "value"
                }
            }
        }
    }
    assert extract(environment, u'keyb', container) == {u'keyc': {u'keyd': u'value'}}
    assert extract(environment, u'keyb', container, morekeys=u'keyc') == {u'keyd': u'value'}
    assert extract(environment, u'keyb', container, morekeys=[u'keyc']) == {u'keyd': u'value'}