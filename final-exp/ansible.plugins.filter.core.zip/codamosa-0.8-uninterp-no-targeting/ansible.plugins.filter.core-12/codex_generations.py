

# Generated at 2022-06-21 04:30:31.817727
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    display.debug("Test for get_encrypted_password")
    input_string = "test123"
    expected_result = get_encrypted_password(input_string)
    actual_result = passlib_or_crypt("test123", "sha512_crypt")
    assert (expected_result == actual_result)
    display.debug("Actual result of get_encrypted_password is %s.", actual_result)



# Generated at 2022-06-21 04:30:36.891082
# Unit test for function from_yaml_all
def test_from_yaml_all():
    yaml_data = """
    - bar:
        name: bar
        age: 20
        weight: 60
    - foo:
        name: foo
        age: 55
        height: 178
    """
    data = from_yaml_all(yaml_data)
    assert isinstance(data, list)
    assert len(data) == 2
    assert isinstance(data[0], dict)
    assert isinstance(data[1], dict)
    assert set(data[0].keys()) == set(['bar'])
    assert set(data[1].keys()) == set(['foo'])



# Generated at 2022-06-21 04:30:40.296521
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=0) == [5, 1, 2, 4, 3]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == [2, 1, 3, 5, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=2) == [2, 3, 1, 5, 4]



# Generated at 2022-06-21 04:30:46.486628
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall("foo bar baz", "b.+") == ['bar', 'baz']
    assert regex_findall("foo bar baz", r"b.+", ignorecase=True) == ['Bar', 'baz']
    assert regex_findall("foo bar\nbaz", r"b.+", ignorecase=True, multiline=True) == ['Bar', 'baz']



# Generated at 2022-06-21 04:30:49.759504
# Unit test for function strftime
def test_strftime():
  from datetime import datetime
  x = strftime(string_format='%Y-%m-%d %H:%M:%S', second=datetime.now()) # FIXME - use a constant
  assert x == '2017-11-17 20:17:58'



# Generated at 2022-06-21 04:30:53.881581
# Unit test for function comment
def test_comment():
    if comment('Hello, world!') == '# Hello, world!':
        return 'test_comment: ok'
    else:
        return 'test_comment: failed'



# Generated at 2022-06-21 04:31:00.282492
# Unit test for function rand
def test_rand():
    assert rand([9, 50, 4], 3, 0, 1) in [0, 1, 2]
    assert rand([9, 50, 4], 3, 0, 2) in [0, 2]
    assert rand([9, 50, 4], 3) in [1, 2]
    assert rand([9, 50, 4], seed='foo') in [9, 50, 4]



# Generated at 2022-06-21 04:31:05.591806
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    hashtype = 'md5'
    salt = None
    salt_size = None
    rounds = None
    ident = None
    password = 'test'
    enc_password = get_encrypted_password(password, hashtype, salt, salt_size, rounds, ident)

# Generated at 2022-06-21 04:31:11.076079
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
        assert {'a': 1, 'b': 2} == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}])



# Generated at 2022-06-21 04:31:17.438462
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = dict([('foo', 'bar'), ('baz', 'qux')])
    result = dict_to_list_of_dict_key_value_elements(mydict)
    assert result == [{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'qux'}]



# Generated at 2022-06-21 04:31:31.544660
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # Default values
    p = get_encrypted_password('password')
    assert len(p) == 90
    assert p[-2:] == '$6'
    assert p[:7] == '$6$salt'

    # Specifying rounds
    p = get_encrypted_password('password', rounds=20000)
    assert p[-2:] == '$6'
    assert p[:3] == '$6$'
    assert len(p) == 90
    p = get_encrypted_password('password', rounds=200000)
    assert p[-2:] == '$6'
    assert p[:3] == '$6$'
    assert len(p) == 91
    p = get_encrypted_password('password', rounds=2000000)
    assert p[-2:] == '$6'
    assert p

# Generated at 2022-06-21 04:31:42.591708
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == r'foo'
    assert regex_escape('foo.bar') == r'foo\.bar'
    assert regex_escape('foo.$bar') == r'foo\.\$bar'
    assert regex_escape('foo*bar') == r'foo\*bar'
    assert regex_escape('foo\\bar') == r'foo\\bar'
    # This is a basic test, and just verifies that that the filter doesn't
    # crash if called with an unknown regex type, or a non-string value.
    # The actual output for these cases is not verified.
    assert regex_escape(None) is None
    assert regex_escape(42) == '42'
    assert regex_escape(True) == 'True'
    assert regex_escape('foo') == r'foo'

# Generated at 2022-06-21 04:31:46.836329
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('') == '361e6d51-faec-444a-9079-341386da8e2e'
    assert to_uuid('', '00000000-0000-0000-0000-000000000000') == 'dfef29c0-2b8c-5edf-87f6-a5f5d54218a5'



# Generated at 2022-06-21 04:31:59.424836
# Unit test for function list_of_dict_key_value_elements_to_dict

# Generated at 2022-06-21 04:32:03.758396
# Unit test for function comment

# Generated at 2022-06-21 04:32:07.927265
# Unit test for function do_groupby
def test_do_groupby():
    # Test case 1:
    #   goal: test with a different attribute
    #   input: a list containing one pair of dictionaries
    #   expected: list with one tuple containing the two dictionaries
    value = [{'a':1, 'b':10}, {'a':2, 'b':20}]
    attribute = 'a'
    result = [({'a':1, 'b':10}, {'a':2, 'b':20})]
    assert result == _do_groupby(value, attribute)
    # Test case 2:
    #   goal: test with a different attribute
    #   input: a list containing two pairs of dictionaries
    #   expected: list with two tuples containing the dictionary

# Generated at 2022-06-21 04:32:19.890084
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    res_sha512_empty = get_encrypted_password('')
    res_sha512_test = get_encrypted_password('test')
    res_sha512_test2 = get_encrypted_password('test')
    res_sha512_test_salt = get_encrypted_password('test', salt='abc')
    res_sha512_test_salt_size = get_encrypted_password('test', salt_size=5)
    res_sha512_test_rounds = get_encrypted_password('test', rounds=1000)
    res_sha512_test_ident = get_encrypted_password('test', ident=26)
    res_sha512_test_rounds_salt = get_encrypted_password('test', rounds=1000, salt='abc')
    res_sha512_test_rounds_salt_size = get

# Generated at 2022-06-21 04:32:24.517254
# Unit test for function extract
def test_extract():
    import jinja2
    env = jinja2.Environment(extensions=[])
    env.filters['extract'] = extract

    assert env.from_string('{{ x | extract("baz") }}').render(x={'baz': 1}) == 1



# Generated at 2022-06-21 04:32:31.566588
# Unit test for function extract
def test_extract():
    try:
        # noinspection PyStatementEffect
        '''Unit test for function extract'''
        x = extract(container={'a': {'b': {'c': 'C'}}},
                    item='a', morekeys=['b', 'c'])
        assert x == 'C'
    except AssertionError:
        raise AssertionError('Function extract failed.\nActual: {0}'.format(x))



# Generated at 2022-06-21 04:32:35.032920
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2015-01-01 00:00:00', format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2015, 1, 1, 0, 0, 0)


# Generated at 2022-06-21 04:32:50.437382
# Unit test for function subelements
def test_subelements():
    '''
    >>> import json
    >>> obj = json.loads('''

# Generated at 2022-06-21 04:33:01.679776
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3, [4, 5], 6, [7, [8, [9, 10]]]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert flatten([1, 2, 3, [4, 5], 6, [7, [8, [9, 10]]]], 1) == [1, 2, 3, 4, 5, 6, 7, [8, [9, 10]]]
    assert flatten([1, 2, 3, [4, 5], 6, [7, [8, [9, 10]]]], 3) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-21 04:33:04.605783
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u"\xC2\xA9", encoding='utf-8') == 'wr0='


# Generated at 2022-06-21 04:33:08.565394
# Unit test for function b64decode
def test_b64decode():
    if PY3:
        assert b64decode(b'wqA=') == '%s' % unichr(82)
    else:
        assert b64decode(b'wqA=') == unichr(82)



# Generated at 2022-06-21 04:33:14.687520
# Unit test for function ternary
def test_ternary():
    # test true
    assert ternary(1, 'a', 'b') == 'a'
    # test false
    assert ternary(0, 'a', 'b') == 'b'
    # test none
    assert ternary(None, 'a', 'b', 'c') == 'c'



# Generated at 2022-06-21 04:33:17.805196
# Unit test for function path_join
def test_path_join():
    assert path_join(['/etc', 'ansible', 'ansible.cfg']) == '/etc/ansible/ansible.cfg'



# Generated at 2022-06-21 04:33:26.976402
# Unit test for function to_json
def test_to_json():
    assert to_json({1: "foo", 2: "bar"}) == '{"1": "foo", "2": "bar"}'
    assert to_json({1: "foo", 2: "bar"}) == '{"1": "foo", "2": "bar"}'
    assert to_json([1, "foo", 2, "bar"]) == '[1, "foo", 2, "bar"]'
    assert to_json(["foo", "bar"]) == '["foo", "bar"]'


# Common Jinja2 filters that live in Ansible core

# Generated at 2022-06-21 04:33:31.128716
# Unit test for function flatten

# Generated at 2022-06-21 04:33:41.949061
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('True') is True
    assert to_bool('False') is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None
    return True



# Generated at 2022-06-21 04:33:52.731999
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # unittest.TestCase is not available in ansible 2.3 and earlier
    class MyTestCase:
        def assertEqual(self, actual, expected):
            if actual != expected:
                raise AssertionError('expected %s != %s' % (repr(expected), repr(actual)))
    my_test = MyTestCase()

# Generated at 2022-06-21 04:34:01.201615
# Unit test for function quote
def test_quote():

    # Test for quote
    assert quote(None) == u"'None'"
    assert quote(u"abc") == u"'abc'"
    assert quote(u"a'b'c") == u"'a'\"'\"'b'\"'\"'c'"
    assert quote(u"a'b\"c") == u"'a'\"'\"'b\"c'"
    assert quote(u"a\"b'c") == u"'a\"b'\"'\"'c'"
    assert quote(u"a\"b\"c") == u"'a\"b\"c'"


# Generated at 2022-06-21 04:34:06.462413
# Unit test for function to_datetime
def test_to_datetime():
    string = "2018-07-11 16:26:03"
    assert to_datetime(string) == datetime.datetime(2018,7,11,16,26,3)



# Generated at 2022-06-21 04:34:14.736119
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u"_", u"^_", u"FOO") == u"FOO"
    assert regex_replace(u"AB_", u"^AB_", u"FOO") == u"FOO"
    assert regex_replace(u"123AB_", u"^AB_", u"FOO") == u"123AB_"
    # Multiline
    assert regex_replace(u"AB_\nCD_", u"^AB_$", u"FOO", multiline=True) == u"AB_\nFOO"


# Generated at 2022-06-21 04:34:16.700613
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%Y', 0) == '1970'
    assert strftime('%Y', 1573037303.9) == '2019'



# Generated at 2022-06-21 04:34:21.607303
# Unit test for function flatten
def test_flatten():
    assert [] == flatten([])
    assert [1, 2, 3] == flatten([1, 2, 3])
    assert [1, 2, 3] == flatten([[1, 2, 3]])
    assert [1, 2, 3] == flatten([[[1, 2, 3]]])
    assert [1, 2, 3] == flatten([[1], [2], [3]])
    assert [1, 2, 3, 4] == flatten([1, [2, 3], 4])
    assert [1, 2, 3, 4] == flatten([1, [2, 3, [4]]])
    assert [1, 2, 3, 4] == flatten([1, [2, 3, [4]]], levels=1)

# Generated at 2022-06-21 04:34:28.116736
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'c': {'b': '2'}, 'd': [1, 2, 3]}) == "{a: 1, c: {b: 2}, d: [1, 2, 3]}\n"
    assert to_yaml({'a': 1, 'c': {'b': '2'}, 'd': [1, 2, 3]}, default_flow_style=False) == "a: 1\nc:\n  b: '2'\nd:\n  - 1\n  - 2\n  - 3\n"

# Generated at 2022-06-21 04:34:36.081171
# Unit test for function rand
def test_rand():

    # Test with integer
    assert rand(2, 0, 1) == 1
    assert rand(10, 5) == 7
    assert rand(10, step=2) == 8

    # Random seed
    assert rand(10, seed=1) == 8

    # Test with list
    assert rand(['a', 'b']) in ['a', 'b']
    assert rand(['a', 'b'], seed=1) in ['a', 'b']

    # Test with default value
    assert rand(2) == 0

    # Test with error
    try:
        rand(3, 2, 1)
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError

    try:
        rand(['a', 'b'], 1)
    except AnsibleFilterError:
        pass

# Generated at 2022-06-21 04:34:42.089319
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(3, msg="test_mandatory") == 3
    try:
        mandatory(Undefined(name='test_mandatory'))
        assert False, "Should not be reached. An exception must be raised"
    except Exception as e:
        assert "Mandatory variable 'test_mandatory'" in to_text(e)
        pass



# Generated at 2022-06-21 04:34:54.397809
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    if passlib_or_crypt is None:
        # not installed, so don't test
        pass
    else:
        assert get_encrypted_password('test', 'md5') == get_encrypted_password('test', 'md5_crypt')
        assert get_encrypted_password('test', 'blowfish') == get_encrypted_password('test', 'bcrypt')
        assert get_encrypted_password('test', 'sha256') == get_encrypted_password('test', 'sha256_crypt')
        assert get_encrypted_password('test', 'sha512') == get_encrypted_password('test', 'sha512_crypt')

        md5_crypt = get_encrypted_password('test', 'md5_crypt')
        bcrypt = get_encrypted_password('test', 'bcrypt')
        assert md5_crypt != bcrypt

        sha256

# Generated at 2022-06-21 04:34:58.933784
# Unit test for function do_groupby
def test_do_groupby():
    # Python 2.6 doesn't have ordered dicts, so we'll just get the same
    # functionality by using regular dicts, then sorting them by key.
    # This isn't particularly performant, but it doesn't need to be.
    if sys.version_info >= (2, 7):
        from collections import OrderedDict
        def ordered_dict():
            return OrderedDict()
    else:
        def ordered_dict():
            return dict()

    env = jinja2.Environment()
    expected = ordered_dict()
    expected['d'] = ['d1', 'd2', 'd3']
    expected['b'] = ['b1', 'b2']
    expected['a'] = ['a1', 'a2', 'a3']
    expected['c'] = ['c1', 'c2']


# Generated at 2022-06-21 04:35:16.430622
# Unit test for function quote
def test_quote():
    assert quote('string') == 'string'
    assert quote(u'string') == 'string'
    assert quote(123) == u'123'
    assert quote('') == "''"
    assert quote(None) == "''"
    assert quote('!') == '\!'
    assert quote('foo"bar') == 'foo"bar'
    assert quote('foo\'bar') == 'foo\'bar'
    assert quote('foo"bar\\') == '"foo\\"bar\\\\"'
    assert quote('foo\'bar\\') == '\'foo\\\'bar\\\\\''
    assert quote(True) == "'True'"
    assert quote(False) == "'False'"
    assert quote([1, 2]) == str([1, 2])

# Generated at 2022-06-21 04:35:17.140899
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:35:20.405812
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'one1two2three3four4', u'[0-9]', u'9') == u'one9two9three9four9'



# Generated at 2022-06-21 04:35:22.179560
# Unit test for function to_json
def test_to_json():
    assert to_json([1,2,3]) == '[1, 2, 3]'



# Generated at 2022-06-21 04:35:34.334725
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory('hello') == 'hello'
    assert mandatory(None) is None
    assert mandatory([ 1, 2 ]) == [ 1, 2 ]

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable 'foo' not defined."
    else:
        assert False, "mandatory did not raise an exception"
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable not defined."
    else:
        assert False, "mandatory did not raise an exception"

# Generated at 2022-06-21 04:35:46.412753
# Unit test for function combine
def test_combine():
    from ansible.template.safe_eval import unsafe_eval

    def test(source, expected, **kwargs):
        result = unsafe_eval(u"{{ %s | combine(%s) }}" % (source, to_text(kwargs, errors='surrogate_or_strict')))
        assert result == expected, "combine(%r) returned %r instead of %r" % (source, result, expected)

    test('{a: {b: {c: 1}}}', {'a': {'b': {'c': 1}}})
    test('{a: 1}', {'a': 1})
    test('{a: 1, b: 2}', {'a': 1, 'b': 2})

# Generated at 2022-06-21 04:35:47.670167
# Unit test for function mandatory
def test_mandatory():
    return mandatory(None)
assert test_mandatory()



# Generated at 2022-06-21 04:35:55.058274
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('alice', 'alice') == 'alice'
    assert regex_search('alice', 'bob') == None
    assert regex_search('alice', 'a') == 'a'
    assert regex_search('alice', 'A', ignorecase=True) == 'a'
    assert regex_search('alice', '\\g<0>') == 'alice'
    assert regex_search('alice', '(alice)') == ['alice']
    assert regex_search('alice', '(al)(ice)') == ['al', 'ice']
    assert regex_search('alice', '(al)(ice)', '\\g<1>') == 'al'

# Generated at 2022-06-21 04:35:58.836447
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json([1, 2, 3]) == '[\n    1,\n    2,\n    3\n]'


# Generated at 2022-06-21 04:36:06.897309
# Unit test for function flatten
def test_flatten():
    mylist = ['foo', ['bar', ['baz', 'buz']]]
    result = flatten(mylist)
    assert result == ['foo', 'bar', 'baz', 'buz']
    result = flatten(result)
    assert result == ['foo', 'bar', 'baz', 'buz']
    result = flatten(mylist, levels=1)
    assert result == ['foo', 'bar', ['baz', 'buz']]

    # skip_nulls behavior
    mylist = ['foo', 'null', [['baz', ['buz', None]], 'bar']]
    # don't skip nulls
    result = flatten(mylist, skip_nulls=False)
    assert 'null' in result
    assert None in result
    # skip nulls

# Generated at 2022-06-21 04:36:27.920379
# Unit test for function do_groupby
def test_do_groupby():
    # Apply function to known data strucures
    data = [dict(foo='bar', baz='bang'), dict(foo='bar2', baz='baz')]
    assert [('bar', 'bang'), ('bar2', 'baz')] == do_groupby(data, 'foo')
    assert [('bar2', 'baz')] == do_groupby(data, 'foo', 'bar2')
    assert [('bar', 'bang'), ('bar2', 'baz')] == do_groupby(data, 'foo', 'bar3')

    # Test filter on a list of dicts
    data = [{'key': 'value1'}, {'key': 'value2'}]

# Generated at 2022-06-21 04:36:34.106654
# Unit test for function fileglob
def test_fileglob():
    path = '/tmp/haha'
    if os.path.exists(path):
        os.remove(path)
    files = fileglob(path)
    assert files == []
    with open(path, 'w') as f:
        f.write('haha')
    files = fileglob(path)
    assert len(files) > 0
    os.remove(path)



# Generated at 2022-06-21 04:36:45.789645
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'foo', 'bar') == 'foo'
    assert ternary(0, 'foo', 'bar') == 'bar'
    assert ternary(None, 'foo', 'bar') == 'bar'
    assert ternary('', 'foo', 'bar') == 'bar'
    assert ternary('', 'foo', 'bar', 'baz') == 'baz'
    assert ternary(0, 'foo', 'bar', 'baz') == 'bar'
    assert ternary(1, 'foo', 'bar', 'baz') == 'foo'



# Generated at 2022-06-21 04:36:56.266073
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2], 3]) == [1, 2, 3]
    assert flatten([[1, [2, [3, 'a']]]]) == [1, 2, 3, 'a']
    assert flatten([[1, [2, [3, 'a']]]], levels=1) == [1, 2, [3, 'a']]
    assert flatten([[1, [2, [3, 'a']]]], levels=2) == [1, 2, 3, 'a']
    assert flatten([[1, [2, [3, 'a']]]], levels=3) == [1, 2, 3, 'a']

# Generated at 2022-06-21 04:37:03.029212
# Unit test for function from_yaml_all
def test_from_yaml_all():
    tests = [
        { "data": "a: 1", "expected": {"a": 1} },
        { "data": "\na: 1\nb: 2\n", "expected": {"a": 1, "b": 2} },
        { "data": "---\na: 1\nb: 2", "expected": [{"a": 1, "b": 2}] },
        { "data": "---\na: 1\nb: 2\n---\na: 3\nb: 4", "expected": [{"a": 1, "b": 2}, {"a": 3, "b": 4}] },
    ]
    for test in tests:
        assert from_yaml_all(test["data"]) == test["expected"]



# Generated at 2022-06-21 04:37:08.238657
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # handle all formats
    assert get_encrypted_password('foo', 'md5') == '$1$1LQmr8rL$l5eAjAIgxX9vn8pF5C7zL1'
    assert get_encrypted_password('foo', 'blowfish') == '$2b$12$xtj4BD7EiulLAGzc7Ijm8urlzDSOk0TdTWPuV9BH0TbW4KF4x1QQa'

# Generated at 2022-06-21 04:37:12.960452
# Unit test for function combine
def test_combine():
    assert combine({'A': 'a'}, {'B': 'b'}) == {'A': 'a', 'B': 'b'}
    assert combine({'A': 'a'}, {'A': 'b'}) == {'A': 'b'}
    assert combine({'A': 'a'}, {'B': 'b'}, {'A': 'c'}) == {'A': 'c', 'B': 'b'}
    assert combine({'A': 'a'}, {'B': 'b'}, {'C': 'c'}, {'A': '1'}) == {'A': '1', 'B': 'b', 'C': 'c'}

# Generated at 2022-06-21 04:37:21.286455
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/cat') == ['/bin/cat']
    assert fileglob('/bin/*') == ['/bin/cat', '/bin/ls']
    assert fileglob('/bin/*s') == ['/bin/ls']
    assert fileglob('/bin/*t') == ['/bin/cat']
    assert fileglob('/bin/*s*') == ['/bin/ls']
    assert fileglob('/bin/*t*') == ['/bin/cat']



# Generated at 2022-06-21 04:37:27.380331
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("testing", "utf-8") == "dGVzdGluZw=="
    assert b64encode("testing", "utf-16") == "dABlAHMAcwB3AG8AcgBkAA=="



# Generated at 2022-06-21 04:37:30.658388
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5], 1) == [2, 4, 3, 1, 5]



# Generated at 2022-06-21 04:37:50.692719
# Unit test for function b64decode
def test_b64decode():
    utf8 = '中文'
    base64_utf8 = '5Lit5paH'
    assert b64encode(utf8) == base64_utf8
    assert b64decode(base64_utf8) == utf8
    assert b64decode(b64encode(utf8)) == utf8

    gbk = to_text(utf8, encoding='gbk', errors='surrogate_or_strict')
    base64_gbk = 'uaLnuaWh'
    assert b64encode(gbk, encoding='gbk') == base64_gbk
    assert b64decode(base64_gbk, encoding='gbk') == gbk
    assert b64decode(b64encode(gbk, encoding='gbk'), encoding='gbk') == gb

# Generated at 2022-06-21 04:38:04.048697
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({'a': 1}) == {'a': 1}
    assert combine({'a': 1, 'b': 2}, {'c': 3, 'd': 4}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    # higher prio takes precedence
    assert combine({'a': 1, 'b': 2}, {'c': 3, 'b': 5}) == {'a': 1, 'b': 5, 'c': 3}
    # keep in mind that the order matter
    # with the following, the `b` keys is replaced twice
    # first c win and then d win, as c and d comes after b in the arguments.
    # The result will be `b: 2` because b comes at the end of the arguments
    # but it could have been `

# Generated at 2022-06-21 04:38:15.040780
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.module_utils.six import PY3
    from ansible.template.vars import AnsibleJ2Vars
    from jinja2 import Dict, Undefined

    # TODO: Create a mock environment for this
    # (see ansible/test/units/template/test_vars_prune.py)
    ev = {}

    if PY3:
        from copy import copy
        ev = copy(ev)
        ev.update({'__builtins__': __builtins__})
    environment = AnsibleJ2Vars(Dict(), ev)

    setattr(environment, 'Undefined', Undefined)

    # convert an empty list to a tuple else this test fails
    # on Python 3.5.0 with an IndexError
    assert do_groupby(environment, (), 'a') == ()




# Generated at 2022-06-21 04:38:17.362399
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-21 04:38:23.629868
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    output = to_nice_yaml([1, 2, 3, 4, 5], indent=5)
    assert output == "- 1\n- 2\n- 3\n- 4\n- 5\n"
    output = to_nice_yaml({'a': 'value', 'b': {'c': 'd'}}, indent=5, width=36)
    assert output == """a: value
b:
    c: d\n"""

# Test that Jinja2 can handle our objects


# Generated at 2022-06-21 04:38:36.181332
# Unit test for function flatten
def test_flatten():
    assert flatten([[(1, 2), (3, 4)], [(5, 6), (7, 8)]]) == [(1, 2), (3, 4), (5, 6), (7, 8)]
    assert flatten([[1, 2], [[3, 4]]]) == [1, 2, [3, 4]]
    assert flatten([[1, 2], [[3, 4]]], levels=2) == [1, 2, 3, 4]
    assert flatten([[[1, 2]], [[3, 4]]], levels=2) == [[1, 2], [3, 4]]
    assert flatten([[[1, 2]], [[3, 4]]], levels=1) == [[1, 2], [3, 4]]

# Generated at 2022-06-21 04:38:41.458620
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('Thisismypassword', salt_size=16) is not None

    with pytest.raises(AnsibleFilterError):
        get_encrypted_password('Thisismypassword', hashtype='nothashingalgo')



# Generated at 2022-06-21 04:38:54.912011
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2012-12-21 12:21:59') == datetime.datetime(2012, 12, 21, 12, 21, 59)
    assert to_datetime('2012-12-21 12:21:59', format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2012, 12, 21, 12, 21, 59)
    assert to_datetime('21/12/2012 12:21:59', format="%d/%m/%Y %H:%M:%S") == datetime.datetime(2012, 12, 21, 12, 21, 59)
    assert to_datetime('21/12/2012', format="%d/%m/%Y") == datetime.datetime(2012, 12, 21)

# Generated at 2022-06-21 04:39:04.320501
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader, Environment
    env = Environment(loader=DictLoader(dict()), extensions=['jinja2.ext.do'])
    env.filters['groupby'] = do_groupby
    result = env.from_string("""
{% set d = [{"a": 1, "b": 2}, {"a": 3, "b": 4}, {"a": 1, "b": 2}] %}
{% for k,g in d|groupby("a") %}
{{k}} = {{g}}
{% endfor %}
""").render()
    expected = """
1 = [{u'a': 1, u'b': 2}, {u'a': 1, u'b': 2}]
3 = [{u'a': 3, u'b': 4}]
"""


# Generated at 2022-06-21 04:39:11.578204
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3], skip_nulls=False) == [1, 2, 3]
    assert flatten([1, 2, 3], skip_nulls=True) == [1, 2, 3]
    assert flatten([1, 2, 3, None], skip_nulls=True) == [1, 2, 3]
    assert flatten([1, 2, 3, 'None'], skip_nulls=True) == [1, 2, 3]
    assert flatten([1, 2, 3, 'null'], skip_nulls=True) == [1, 2, 3]
    assert flatten([1, 2, 3, ''], skip_nulls=True) == [1, 2, 3]

# Generated at 2022-06-21 04:39:31.008687
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None


# Generated at 2022-06-21 04:39:37.022576
# Unit test for function randomize_list
def test_randomize_list():
    x = [1,2,3,4,5,6]
    y = randomize_list(x)
    assert set(x) == set(y)
    assert x != y



# Generated at 2022-06-21 04:39:44.995587
# Unit test for function randomize_list
def test_randomize_list():
    # Seed a list of ints and verify that the shuffled list matches
    mylist = range(0,10)
    actual_list = randomize_list(mylist, seed=1)
    expected_list = [4, 7, 9, 2, 8, 0, 1, 5, 6, 3]
    assert expected_list == actual_list
    # Un-seed a list of ints and verify that the shuffled list does not match
    mylist = range(0,10)
    actual_list = randomize_list(mylist)
    expected_list = [4, 7, 9, 2, 8, 0, 1, 5, 6, 3]
    assert expected_list != actual_list
    # Seed a list of ints and verify that the shuffled list matches
    mylist = range(0,10)

# Generated at 2022-06-21 04:39:49.176171
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(1)
    assert to_bool(None)
    assert not to_bool(0)
    assert not to_bool("")

