

# Generated at 2022-06-21 04:30:21.224422
# Unit test for function regex_search
def test_regex_search():
    # Test a regex without any capture groups
    assert regex_search("foobar", "foo.*") == "foobar"
    assert regex_search("foo", "foo.*") == "foo"
    assert regex_search("bar", "foo.*") is None

    # Test a regex with 1 capture group
    assert regex_search("foobar", "foo(.+)") == "bar"
    assert regex_search("foo", "foo(.+)") is None
    assert regex_search("bar", "foo(.+)") is None

    # Test a regex with 2 capture groups
    assert regex_search("foobar", "foo(.+)(bar)") == ["bar", "bar"]

# Generated at 2022-06-21 04:30:24.906455
# Unit test for function randomize_list
def test_randomize_list():
    r = randomize_list(['a', 'b', 'c', 'd', 'e'])
    assert isinstance(r, list)
    assert len(r) == 5



# Generated at 2022-06-21 04:30:33.802677
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    assert get_hash('Hello world', 'md5') == 'b10a8db164e0754105b7a99be72e3fe5'
    assert get_hash('Hello world', 'sha256') == 'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e'



# Generated at 2022-06-21 04:30:41.620673
# Unit test for function quote
def test_quote():
    assert quote(None) == "''"
    assert quote('') == "''"
    assert quote('a b') == "'a b'"
    assert quote('a\'b') == "''\\''a'\\''b'\\'''"
    assert quote('a"b') == "'a\"b'"



# Generated at 2022-06-21 04:30:46.216661
# Unit test for function to_yaml
def test_to_yaml():
    '''
    >>> test_to_yaml()
    ---
    foo: bar
    bar:
    - baz
    - 1
    '''
    a = {'bar': ['baz', 1], 'foo': 'bar'}
    print(to_yaml(a))



# Generated at 2022-06-21 04:30:50.816002
# Unit test for function to_uuid
def test_to_uuid():
    mystring = 'foo'
    mynamespace = '361e6d51-fae2-444a-9079-341386da8e2e'
    myuuid = 'e92e9edb-2fd7-5415-87e2-cab58b1d0e93'
    assert(to_uuid(mystring, mynamespace) == myuuid)



# Generated at 2022-06-21 04:31:03.436296
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment

    env = JinjaEnvironment(undefined=jinja2.StrictUndefined)
    env.filters.update(dict(groupby=do_groupby))
    test_data = [
        dict(name='foo', value=1),
        dict(name='bar', value=2),
        dict(name='baz', value=3)
    ]
    template = env.from_string("{{ dicts | groupby('name') | list }}")
    assert template.render(dicts=test_data) == "[('bar', [{'name': 'bar', 'value': 2}]), ('baz', [{'name': 'baz', 'value': 3}]), ('foo', [{'name': 'foo', 'value': 1}])]"

# original groupby filter, as in

# Generated at 2022-06-21 04:31:17.569274
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for constructor of class FilterModule. '''

    filters = FilterModule().filters()

    # Create an Acceptable Ansible Filter Module

# Generated at 2022-06-21 04:31:29.078902
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('') == 'a3a3a8f6-fbe6-572e-936c-8d0e59228ea6'
    assert to_uuid('test') == 'b63d7a9c-c934-5573-b66a-7b45f3481af6'
    assert to_uuid('test', 'cf24e9d8-d85c-11e1-bdfc-cfa6b29bb814') == '7da9365b-ca67-5548-b66a-7b45f3481af6'

# Generated at 2022-06-21 04:31:40.551455
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    x = 123
    y = 456
    z = 789
    assert module.filters()['bool']('True') is True
    assert module.filters()['bool']('False') is False
    assert module.filters()['bool']('string') is True
    assert module.filters()['bool']('0') is False
    assert module.filters()['bool'](0) is False
    assert module.filters()['bool'](1) is True
    assert module.filters()['b64encode'](y) == 'NDU2'
    assert module.filters()['b64decode']('NDU2') == '456'
    # assert module.filters()['basename'](x) == '/Users/dwozniak/git/ansible/lib/ans

# Generated at 2022-06-21 04:31:47.560852
# Unit test for function quote
def test_quote():
    assert quote(u'foo') == u"'foo'"
    assert quote(u"'foo'") == u"''\\''foo\\'''"

    assert quote(42) == u'42'



# Generated at 2022-06-21 04:31:55.294546
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'Ansible is great', u'ansible', u'Ansible', ignorecase=True) == u'Ansible is great'
    assert regex_replace(u'###', u'##', u'#') == u'#'
    assert regex_replace(u'''#comment1
## comment2
#comment3''', u'#.*$', u'', multiline=True) == u''



# Generated at 2022-06-21 04:31:55.744063
# Unit test for function comment
def test_comment():
    return True



# Generated at 2022-06-21 04:32:02.092966
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'


# Generated at 2022-06-21 04:32:10.820998
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('abc/def') == 'abc\\/def'
    assert regex_escape('abc.def') == 'abc\\.def'
    # Note: the '$' is not escaped because we're explicitly testing python
    # regex, which doesn't require it.
    assert regex_escape('abc$def') == 'abc$def'
    assert regex_escape('abc*def') == 'abc\\*def'
    assert regex_escape('abc+def') == 'abc\\+def'
    assert regex_escape('abc?def') == 'abc\\?def'
    assert regex_escape('abc|def') == 'abc\\|def'
    assert regex_escape('abc(def') == 'abc\\(def'
    assert regex_escape('abc)def') == 'abc\\)def'

# Generated at 2022-06-21 04:32:13.478061
# Unit test for function to_yaml
def test_to_yaml():
    t = {'foo':'bar'}
    assert to_yaml(t) == to_text('{foo: bar}\n')
    r = random_password(1,10)
    assert len(to_yaml(r)) == len(to_text('- %s\n' % r[0]))
    return True



# Generated at 2022-06-21 04:32:19.259236
# Unit test for function mandatory
def test_mandatory():
    import pytest

    try:
        mandatory(None)
        assert False
    except:
        assert True

    try:
        mandatory(None, 'A message')
        assert False
    except:
        assert True

    try:
        mandatory(0)
        assert False
    except:
        assert True

    try:
        mandatory('')
        assert False
    except:
        assert True

    assert mandatory('something') == 'something'



# Generated at 2022-06-21 04:32:32.364595
# Unit test for function extract
def test_extract():
    from ansible.template import Templar

    t = Templar(loader=DictDataLoader({}))

    # test basic use
    data = {'a': {'b': {'c': 3}}}
    assert extract('a', data) == {'b': {'c': 3}}
    assert extract('b', extract('a', data)) == {'c': 3}
    assert extract('c', extract('b', extract('a', data))) == 3

    # test morekeys use
    assert extract('a', data, morekeys=['b']) == {'c': 3}
    assert extract('b', t.template({'myvar': 'b'}), data) == {'c': 3}

# Generated at 2022-06-21 04:32:40.447745
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert flatten([[1, 2], 3, [4, 5], 6]) == [1, 2, 3, 4, 5, 6]
    assert flatten(['1', '2', '3']) == ['1', '2', '3']
    assert flatten(['1', ['2', '3']]) == ['1', '2', '3']
    assert flatten([['1', '2'], ['3', '4']]) == ['1', '2', '3', '4']

# Generated at 2022-06-21 04:32:51.009815
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mydict = {'a': 'A', 'b': 'B'}
    mylist = [{'key': 'a', 'value': 'A'}, {'key': 'b', 'value': 'B'}]
    mylist_wrong_format = [{'key': 'a'}, {'key': 'b', 'value': 'B'}]
    mystring = "A string"
    assert mydict == list_of_dict_key_value_elements_to_dict(mylist)
    try:
        list_of_dict_key_value_elements_to_dict(mystring)
        assert False, "Should have failed with TypeError"
    except AnsibleFilterTypeError:
        assert True

# Generated at 2022-06-21 04:33:05.110093
# Unit test for function path_join
def test_path_join():
    assert path_join('/foo') == '/foo'
    assert path_join('/foo/') == '/foo'
    assert path_join(['/foo', 'bar']) == '/foo/bar'
    assert path_join(['/foo', '/bar']) == '/bar'
    assert path_join(['/foo', 'bar/']) == '/foo/bar'
    assert path_join(['/foo', '', 'bar']) == '/foo/bar'
    assert path_join(['/foo', '', 'bar/']) == '/foo/bar'
    assert path_join('foo', 'bar') == 'foo/bar'
    assert path_join('foo', 'bar/') == 'foo/bar'
    assert path_join('foo/', 'bar') == 'foo/bar'
    assert path_join

# Generated at 2022-06-21 04:33:06.652534
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('foo') == 'Zm9v'



# Generated at 2022-06-21 04:33:12.672839
# Unit test for function get_hash
def test_get_hash():
    for test in ['test', u'test', b'test']:
        assert(get_hash(test, 'md5') == md5s(test))
        assert(get_hash(test, 'sha1') == checksum_s(test))
    return True



# Generated at 2022-06-21 04:33:21.358578
# Unit test for function b64encode
def test_b64encode():
    # Base64 an empty byte string
    assert b64encode(b'') == to_text('')
    assert b64encode('') == to_text('')
    # Base64 an unicode string
    assert b64encode(to_text(u'fòô', encoding='utf-8')) == to_text('ZsO2bw==')
    # Base64 a byte string
    assert b64encode(to_bytes('fòô', encoding='utf-8')) == to_text('ZsO2bw==')



# Generated at 2022-06-21 04:33:33.021073
# Unit test for function path_join
def test_path_join():
    assert path_join("/my/path") == "/my/path"
    assert path_join("/my", "path") == "/my/path"
    assert path_join("/my", "path/") == "/my/path/"
    assert path_join("/my/", "/path") == "/my/path"
    assert path_join("/my/", "/path/") == "/my/path/"
    assert path_join(["/my", "/path"]) == "/my/path"
    assert path_join(["/my", "/path/"]) == "/my/path/"
    assert path_join(["/my/", "/path"]) == "/my/path"
    assert path_join(["/my/", "/path/"]) == "/my/path/"

# Generated at 2022-06-21 04:33:35.958772
# Unit test for function fileglob
def test_fileglob():
    assert ['/tmp/foo'] == fileglob('/tmp/foo')
    assert [] == fileglob('/tmp/non-existing')
    assert [] == fileglob('non-existing')
    if os.path.isdir('/tmp/'):
        assert [] != fileglob('/tmp/*')
        assert [] == fileglob('/tmp/*', True)



# Generated at 2022-06-21 04:33:46.306770
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': {'b2': 3}, 'c': 4}) == {'a': 1, 'b': {'b2': 3}, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}

# Generated at 2022-06-21 04:33:50.613644
# Unit test for function mandatory
def test_mandatory():
    def check_filter(x):
        return mandatory(x, msg="Mandatory failed")
    assert check_filter("check_filter succeeded") == "check_filter succeeded"

    import pytest
    with pytest.raises(AnsibleFilterError):
        assert mandatory(AnsibleUndefined('foo'))



# Generated at 2022-06-21 04:33:56.435706
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key':1, 'value':2}, {'key':3, 'value':4}, {'key':5, 'value':6}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {1:2, 3:4, 5:6}
    mylist = [{'id':1, 'value':2}, {'id':3, 'value':4}, {'id':5, 'value':6}]
    assert list_of_dict_key_value_elements_to_dict(mylist, 'id', 'value') == {1:2, 3:4, 5:6}
    mylist = [{'id':1, 'mark':2}, {'id':3, 'mark':4}, {'id':5, 'mark':6}]

# Generated at 2022-06-21 04:34:02.745185
# Unit test for function b64decode
def test_b64decode():
    def utf8(inp):
        return b64decode(b64encode(inp))

    assert utf8(u"\u5341\u56db") == u"\u5341\u56db"
    assert utf8(u"\u4e00\u4e8c\u4e09") == u"\u4e00\u4e8c\u4e09"



# Generated at 2022-06-21 04:34:21.833630
# Unit test for function randomize_list
def test_randomize_list():
    def test_equal(first, second):
        if isinstance(first, list):
            assert (
                len(first) == len(second) and
                all(test_equal(test, truth) for test, truth in zip(first, second))
            )
            return True
        else:
            try:
                assert first == second
            except TypeError:
                try:
                    assert abs(first - second) < 1E-12
                except TypeError:
                    return False
            return True

    for seed in range(4):
        for length in range(4):
            first = list(range(length))
            second = randomize_list(first, seed)
            third = randomize_list(first, seed)
            assert test_equal(second, third)


# Generated at 2022-06-21 04:34:24.890763
# Unit test for function to_bool
def test_to_bool():
    assert to_bool("yes") is True
    assert to_bool("on") is True
    assert to_bool("1") is True
    assert to_bool("true") is True
    assert to_bool(1) is True
    assert to_bool("no") is False
    assert to_bool("off") is False
    assert to_bool("0") is False
    assert to_bool("false") is False
    assert to_bool(0) is False
    assert to_bool("random") is False



# Generated at 2022-06-21 04:34:33.073816
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'k':'v'}, default_flow_style=True) == "k: v\n"
    assert to_yaml({'k':'v'}) == "k: v\n"
    assert to_yaml({'k':{'k':'v'}}, default_flow_style=True) == "k:\n  k: v\n"
    assert to_yaml({'k':{'k':'v'}}) == """\
k:
  k: v
"""
# End unit test



# Generated at 2022-06-21 04:34:41.950185
# Unit test for function get_hash
def test_get_hash():
    hash_val = get_hash('test', 'sha1')
    assert hash_val == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    hash_val = get_hash('test', 'sha256')
    assert hash_val == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    hash_val = get_hash('test', 'md5')
    assert hash_val == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-21 04:34:43.675448
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:34:54.744716
# Unit test for function rand
def test_rand():
    # Test integers
    assert rand(10) in range(10)
    assert rand(1, 10) in range(1, 10)
    assert rand(1, 10, 2) in (1, 3, 5, 7, 9)
    assert rand(end=10) in range(10)
    assert rand(start=1, end=10) in range(1, 10)
    assert rand(end=10, step=2) in (0, 2, 4, 6, 8)
    assert rand(end=10, step=2, seed=1) in (0, 2, 4, 6, 8)
    assert rand(step=2, end=10, seed=1) in (0, 2, 4, 6, 8)
    assert rand(end=10, seed=1) in range(10)
    # Test lists
    assert rand

# Generated at 2022-06-21 04:34:59.544211
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    from ansible.compat import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = u'''
    - key: fookey1
      value: foovalue1
    - key: fookey2
      value: foovalue2
    '''

    my_list = AnsibleLoader(StringIO(data), '', '', '',).get_single_data()
    new_dict = list_of_dict_key_value_elements_to_dict(my_list)
    assert my_list == new_dict



# Generated at 2022-06-21 04:35:09.162125
# Unit test for function to_uuid
def test_to_uuid():
    for i in range(10):
        assert re.match(r'^[0-9a-f]{8}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{12}$', to_uuid('value'))
        assert to_uuid('value', 'a5b2c3f3-8a46-11e7-bb31-be2e44b06b34') == '9a9a6f56-8a47-11e7-bb31-be2e44b06b34'


# Generated at 2022-06-21 04:35:23.630303
# Unit test for function to_uuid
def test_to_uuid():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    class ResultsCollector(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(ResultsCollector, self).__init__(*args, **kwargs)
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}
        def v2_runner_on_unreachable(self, result):
            self.host_unreachable[result._host.get_name()] = result

# Generated at 2022-06-21 04:35:30.137574
# Unit test for function extract
def test_extract():
    env = jinja2.Environment(loader=jinja2.DictLoader({'foo': "<h1>Hello, {{ place }}!</h1>\n"}))
    template = env.from_string("{{ html | extract('h1', '__content__') }}")

    # Test that the filter extracts an element from a structure
    assert template.render(
        html={'__content__': {'h1': 'Hello, World!'}}
    ) == "Hello, World!"
    assert template.render(
        html={'__content__': {'h1': 'Hello, World!', 'p': 'test'}}
    ) == "Hello, World!"

    # Test that the filter accesses a string

# Generated at 2022-06-21 04:35:46.256678
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    # Test empty dict
    assert dict_to_list_of_dict_key_value_elements({}) == []

    # Test dict with one element
    assert dict_to_list_of_dict_key_value_elements({'key': 'value'}) == [{'key': 'key', 'value': 'value'}]

    # Test dict with several elements
    assert dict_to_list_of_dict_key_value_elements({'key': 'value', 'key2': 'value2'}) == [{'key': 'key', 'value': 'value'}, {'key': 'key2', 'value': 'value2'}]

    # Test dict with default parameters
    assert dict_to_list_of_dict_key_value_elements({'key': 'value', 'key2': 'value2'})

# Generated at 2022-06-21 04:35:55.057718
# Unit test for function do_groupby
def test_do_groupby():
    """Test jinja2 `do_groupby` function
    """
    from jinja2.utils import contextfunction
    from jinja2.runtime import Context
    from jinja2.environment import Environment
    from jinja2.exceptions import TemplateRuntimeError
    import jinja2.filters

    # Use our do_groupby function instead of the one in jinja2.filters
    jinja2.filters.FILTERS['groupby'] = contextfunction(do_groupby)

    environment = Environment()

# Generated at 2022-06-21 04:36:05.115364
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u"helloé") == u"aGVsbG8="
    assert b64encode(u"hello", encoding='ascii') == u"aGVsbG8="
    assert b64encode(u'\u0411\u0435\u0440\u0435\u0437\u0435\u043a') == u'0L/RgNC10LTRgNC10LzQtdC90YLRgA=='
    assert b64encode(u'\u0411\u0435\u0440\u0435\u0437\u0435\u043a', encoding='koi8-r') == u'0P/QtNCw0YPQsdC+0LPQtNCw0ZfQsA=='



# Generated at 2022-06-21 04:36:12.776341
# Unit test for function get_hash
def test_get_hash():
    data = 'Test Data'
    hash_data = get_hash(data)
    try:
        assert(hash_data == '6cccdb84f3a7ff3c512e2d89a0c5d5c745a5d5a5')
    except AssertionError:
        print("Hash not generated properly")


# Generated at 2022-06-21 04:36:26.299565
# Unit test for function rand
def test_rand():
    assert rand(1, 3) in (1, 2, 3)
    assert rand(1, end=3) in (1, 2, 3)
    assert rand(end=3) in (0, 1, 2, 3)
    assert rand(1, 3, 2) in (1, 3)
    assert rand(1, end=3, step=2) in (1, 3)
    assert rand(end=3, step=2) in (0, 2)
    assert rand([1, 'a', {'foo': 'bar'}]) in ([1, 'a', {'foo': 'bar'}])
    assert rand([1, 'a', {'foo': 'bar'}], seed=1) in ([1, 'a', {'foo': 'bar'}])

# Generated at 2022-06-21 04:36:40.495027
# Unit test for function to_nice_json
def test_to_nice_json():
    template = '''
    [
        {
            "book": [
                {
                    "author": "J.R.R. Tolkien",
                    "name": "Lord of The Rings"
                },
                {
                    "author": "Dan Brown",
                    "name": "Origin"
                }
            ]
        }
    ]
    '''
    # Template returns a list of dicts
    result = yaml.safe_load(template)
    # Some template variables
    classname = "Biology"
    course = "Science"
    # Creating the output dictionary for to_nice_json
    output = dict()
    output['class'] = classname
    output['course'] = course
    output['books'] = result
    # Output from to_nice_json

# Generated at 2022-06-21 04:36:43.898067
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote('abc"def') == u'"abc\\"def"'



# Generated at 2022-06-21 04:36:47.058801
# Unit test for function b64encode
def test_b64encode():
    b64encode('foo') == 'Zm9v'



# Generated at 2022-06-21 04:36:53.638221
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  paths = []
  test_FilterModule_filters_paths = paths
  obj = []
  test_FilterModule_filters_obj = obj
  subelements = []
  test_FilterModule_filters_subelements = subelements
  #Calling FilterModule().filters()
  assert True # TODO: implement your test here


# Generated at 2022-06-21 04:37:02.161153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from . import FilterModule as _FilterModule
    from ansible.compat.six import string_types as _string_types

    _my_class = _FilterModule

    assert isinstance(_my_class.filters, type(dict))

    key = 'groupby'
    assert key in _my_class.filters().keys()
    assert callable(_my_class.filters()[key])

    key = 'b64decode'
    assert key in _my_class.filters().keys()
    assert callable(_my_class.filters()[key])

    key = 'b64encode'
    assert key in _my_class.filters().keys()
    assert callable(_my_class.filters()[key])

    key = 'to_uuid'
    assert key in _my_class.filters

# Generated at 2022-06-21 04:37:23.583109
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    results = json.dumps(set(subelements(obj, 'authorized')))
    assert results == set([
        '{"authorized": [{"authorized": [], "groups": ["wheel"], "name": "alice"}], "name": "\\/tmp\\/alice\\/onekey.pub"}',
        '{"authorized": [{"authorized": [], "groups": ["wheel"], "name": "alice"}], "name": "/tmp/alice/onekey.pub"}'
    ])
    results = json.dumps(set(subelements(obj, 'groups')))

# Generated at 2022-06-21 04:37:26.175337
# Unit test for function quote
def test_quote():
    assert quote('value1 value2') == u'\'value1 value2\''



# Generated at 2022-06-21 04:37:27.564010
# Unit test for function quote
def test_quote():
    assert quote('foo bar') == r"'foo bar'"



# Generated at 2022-06-21 04:37:31.880670
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u'你好') == '5L2g5aW9'



# Generated at 2022-06-21 04:37:39.821352
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('''
        hello: world
        foo:
        - 1st
        - 2nd
        - 3rd
        ''') == dict(hello='world', foo=['1st', '2nd', '3rd'])



# Generated at 2022-06-21 04:37:46.167237
# Unit test for function rand
def test_rand():
    assert rand(1, 5) in range(0, 5)
    assert rand(1, 5, seed='foobar') in range(0, 5)
    seq = ['a', 'b', 'c', 'd']
    assert rand(1, seq) in seq



# Generated at 2022-06-21 04:38:01.846330
# Unit test for function subelements
def test_subelements():

    # basic
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

    # nested

# Generated at 2022-06-21 04:38:10.130310
# Unit test for function randomize_list
def test_randomize_list():
    '''
    randomize_list:
      - [ 1, 2, 3, 4, 5 ]
    '''

    # Some 'random' results:
    # [ 5, 4, 2, 1, 3 ]
    # [ 3, 5, 4, 1, 2 ]
    # [ 3, 4, 5, 1, 2 ]
    # [ 4, 2, 1, 5, 3 ]
    # [ 2, 5, 1, 3, 4 ]
    # [ 1, 2, 3, 5, 4 ]
    # [ 2, 3, 1, 5, 4 ]
    # [ 5, 4, 2, 1, 3 ]
    # [ 4, 2, 1, 5, 3 ]
    # [ 2, 1, 5, 3, 4 ]

    # This test doesn't validate the result, just makes sure the list
    # has been randomized

# Generated at 2022-06-21 04:38:13.308359
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([1,2,3,4]) == "- 1\n- 2\n- 3\n- 4\n"



# Generated at 2022-06-21 04:38:17.362800
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) is None
    assert from_yaml(42) == 42
    assert from_yaml(0) == 0
    assert from_yaml('foobar') == 'foobar'
    assert from_yaml({'foo': 'bar'}) == {'foo': 'bar'}
    assert from_yaml(['foo', 'bar']) == ['foo', 'bar']



# Generated at 2022-06-21 04:38:47.553642
# Unit test for function mandatory
def test_mandatory():
    ''' mandatory should raise an AnsibleFilterError when input is an AnsibleUndefined '''
    from jinja2.runtime import Undefined
    assert not isinstance(mandatory('foo'), AnsibleUndefined)
    try:
        mandatory(Undefined)
    except AnsibleFilterError as e:
        assert to_text(e) == 'Mandatory variable not defined.'
    else:
        assert False, 'a AnsibleFilterError should be raised'



# Generated at 2022-06-21 04:38:53.532484
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    from jinja2.runtime import Undefined
    env = jinja2.Environment(undefined=Undefined, keep_trailing_newline=True, trim_blocks=True, lstrip_blocks=True)
    # We will test with do_groupby, but use an eval to compare the results
    # This is to ensure that ansible.template.safe_eval.safe_eval can correctly parse the groupby result
    assert eval(do_groupby(env, [("a", 1), ("b", 2), ("c", 3)], 'key')) == [("a", [(("key", "a"), ("value", 1))]), ("b", [(("key", "b"), ("value", 2))]), ("c", [(("key", "c"), ("value", 3))])]

# Generated at 2022-06-21 04:39:05.329411
# Unit test for function regex_replace
def test_regex_replace():

    assert regex_replace('a', 'a', 'b') == 'b'
    assert regex_replace('a', 'a') == ''
    assert regex_replace('', 'a') == ''
    assert regex_replace(None, 'a') == ''
    assert regex_replace('A', 'a', ignorecase=True) == ''
    assert regex_replace('A', 'a', ignorecase=True, multiline=True) == ''
    assert regex_replace('A\n', 'a', ignorecase=True, multiline=True) == '\n'
    assert regex_replace('A', 'a', multiline=True) == ''
    assert regex_replace('A\n', 'a', multiline=True) == '\n'
    assert regex_replace('', 'a', multiline=True) == ''
   

# Generated at 2022-06-21 04:39:20.085819
# Unit test for function b64decode
def test_b64decode():
    expected_results = dict(
      en1 = "hello world!",
      utf8 = "mañana",
      latin1 = "mañana",
      base64_invalid = "maÃ±ana"
    )
    encoded_strings = dict(
      en1 = "aGVsbG8gd29ybGQh",
      utf8 = "bWFsw7FuYQ==",
      latin1 = "bWFhw7FuYQ==",
      base64_invalid = "bWEywYJuw7E="
    )
    failed = False

# Generated at 2022-06-21 04:39:26.307316
# Unit test for function to_yaml
def test_to_yaml():
    import yaml
    content = yaml.load("""
- a:
    b: 1
""")
    assert(to_yaml(content) == "- a:\n    b: 1\n")
    assert(to_yaml(content, default_flow_style=True) == "- {a: {b: 1}}\n")
    assert(to_yaml(12345) == "12345\n")
    assert(to_yaml({'k': 1234}) == "k: 1234\n")
# End unit test for function to_yaml



# Generated at 2022-06-21 04:39:34.347107
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("10") == 10
    assert from_yaml("foo") == "foo"
    assert from_yaml("10\n") == 10
    assert from_yaml("foo\n") == "foo"
    assert from_yaml(u"foo\n") == u"foo"
    assert from_yaml(b"foo\n") == u"foo"


# Generated at 2022-06-21 04:39:41.698935
# Unit test for function quote
def test_quote():
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote(u'foo "bar"') == u'"foo \"bar\""'

# Generated at 2022-06-21 04:39:50.377298
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({1: 'a'}) == [{'key': 1, 'value': 'a'}]
    assert dict_to_list_of_dict_key_value_elements({1: 'a', 2: 'b'}) == [{'key': 1, 'value': 'a'}, {'key': 2, 'value': 'b'}]
    assert dict_to_list_of_dict_key_value_elements({1: 'a'}, 'a', 'b') == [{'a': 1, 'b': 'a'}]

# Generated at 2022-06-21 04:39:59.093800
# Unit test for function regex_findall
def test_regex_findall():
    ''' function regex_findall should return a list of strings '''
    regex = '^[^ ]+'
    multiline = True
    ignorecase = False
    # test results
    expected = ['I', 'want', 'to', 'get', 'good', 'results']
    value = 'I want to get good results'
    results = regex_findall(value, regex, multiline, ignorecase)
    assert expected == results
