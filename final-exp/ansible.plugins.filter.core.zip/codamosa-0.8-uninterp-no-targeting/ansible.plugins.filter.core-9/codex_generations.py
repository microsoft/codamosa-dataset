

# Generated at 2022-06-21 04:30:22.387433
# Unit test for function b64decode
def test_b64decode():
    result = b64decode('SSBhbSBhIHRlc3Q=', 'utf-8')
    assert result == "I am a test"



# Generated at 2022-06-21 04:30:31.613486
# Unit test for function b64encode
def test_b64encode():
    for (string, expected_b64_encoded) in [
        ('test', 'dGVzdA=='),
        (u'test', u'dGVzdA=='),
        ('\n', 'Cg=='),
        ('\x00', 'AA=='),
        ('\xff', '/+8=')
    ]:
        assert b64encode(string) == expected_b64_encoded


# Generated at 2022-06-21 04:30:44.130377
# Unit test for function subelements
def test_subelements():
    import json
    import doctest
    from collections import namedtuple

    SubElementObject = namedtuple('SubElementObject', ['obj', 'subelements'])


# Generated at 2022-06-21 04:30:49.566732
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('spam', '(\w{4})', '\\g<1>') == 'spam'
    assert regex_search('hey spam', '(\w+)\s?(\w+)', '\\g<1>', '\\g<2>') == ['hey', 'spam']
    assert regex_search('my dog', '(\w+)\s?(\w+)', '\\g<2>') == 'dog'
    assert regex_search('SPAM', '^(\w{4})$', ignorecase=True) == 'SPAM'



# Generated at 2022-06-21 04:30:58.630645
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('true')
    assert to_bool('True')
    assert to_bool(True)
    assert to_bool(1)
    assert to_bool('yes')
    assert to_bool('on')
    assert to_bool('1')
    assert to_bool('') is False
    assert to_bool('false') is False
    assert to_bool(False) is False
    assert to_bool(0) is False
    assert to_bool(['false']) is False
    assert to_bool(['true'])
    assert to_bool('foo') is False
    assert to_bool('0') is False



# Generated at 2022-06-21 04:31:02.206781
# Unit test for function b64encode
def test_b64encode():
    # Test string
    string = 'hello world'
    # Test ASCII
    encoded_string = b64encode(string)
    assert encoded_string == 'aGVsbG8gd29ybGQ='
    # Test unicode
    string = 'ěšč'
    encoded_string = b64encode(string)
    assert encoded_string == '16HUi8KM'
    # Test unicode binary
    string = '\xc4\x9b\xc5\xa1\xc4\x8d'
    encoded_string = b64encode(string)
    assert encoded_string == '16HUi8KM'



# Generated at 2022-06-21 04:31:08.022244
# Unit test for function strftime
def test_strftime():
    assert strftime('%m/%d/%Y') == time.strftime('%m/%d/%Y')
    assert strftime('%m/%d/%Y', 0) == time.strftime('%m/%d/%Y', time.localtime(0))
    assert strftime('%m/%d/%Y', '0') == time.strftime('%m/%d/%Y', time.localtime(0))
    assert strftime('%m/%d/%Y', '1.4') == time.strftime('%m/%d/%Y', time.localtime(1.4))



# Generated at 2022-06-21 04:31:15.643168
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    try:
        mandatory(AnsibleUndefined)
        assert 0, "should have thrown an exception"
    except AnsibleFilterError as e:
        pass

    try:
        mandatory(AnsibleUndefined, "This is an error")
        assert 0, "should have thrown an exception"
    except AnsibleFilterError as e:
        assert "This is an error" in to_text(e)



# Generated at 2022-06-21 04:31:16.658483
# Unit test for function quote
def test_quote():
    assert quote(True) == 'True'



# Generated at 2022-06-21 04:31:21.777494
# Unit test for function to_uuid
def test_to_uuid():
    uuid_re = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I)
    assert uuid_re.search(to_uuid('foo', namespace='4c9a987a-24dd-50f8-b5f5-eceb1a954e18'))



# Generated at 2022-06-21 04:31:39.214940
# Unit test for function subelements
def test_subelements():

    # single dict
    obj = {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}

    result = subelements(obj, 'authorized')
    assert result == [(obj, '/tmp/alice/onekey.pub')]

    # list of dicts
    obj = [
        {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]},
        {"name": "bob", "groups": ["wheel", "othergroup"], "authorized": ["/tmp/bob/onekey.pub", "/tmp/bob/anotherkey.pub"]},
    ]

    result = subelements(obj, 'authorized')

# Generated at 2022-06-21 04:31:50.984355
# Unit test for function comment
def test_comment():
    # If one of these fails, then the test also fails and informs you of the mismatch
    assert(comment('This is a **bold** comment', style='erlang', decoration='%% ') == '% This is a **bold** comment')
    assert(comment('This is a comment', style='xml', decoration='<!-- ') == '<!-- This is a comment -->')
    assert(comment('This is a comment', style='xml', decoration='<!-- ') == '<!-- This is a comment -->')
    assert(comment('This is a comment', style='xml', decoration='<!-- ') == '<!-- This is a comment -->')
    assert(comment('This is a comment', style='xml', decoration='<!-- ') == '<!-- This is a comment -->')

# Generated at 2022-06-21 04:31:56.243279
# Unit test for function do_groupby
def test_do_groupby():
    class FakeEnvironment:
        def getitem(a, b, c):
            return c
    class FakeNamedtuple:
        def __iter__(self):
            yield 1
    value = ['a', 'b']
    environment = FakeEnvironment()
    for namedtuple in [False, True]:
        with patch.object(builtins, 'tuple', new=FakeNamedtuple if namedtuple else tuple):
            result = do_groupby(environment, value, 'a')
            assert result == [FakeNamedtuple(), FakeNamedtuple()], "do_groupby returned %s, but should have returned %s" % (result, [FakeNamedtuple(), FakeNamedtuple()])



# Generated at 2022-06-21 04:31:58.382234
# Unit test for function path_join
def test_path_join():
    assert path_join([1, 2]) == os.path.join(1, 2)
    assert path_join([1, 2, '3']) == os.path.join(1, 2, '3')
    assert path_join('foo') == os.path.join('foo')



# Generated at 2022-06-21 04:32:09.266963
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('foo', 'oo', 'dd', ignorecase=False) == 'fdd'
    assert regex_replace('foo', 'oo', 'dd', ignorecase=True) == 'fdd'
    assert regex_replace('foo', 'OO', 'dd', ignorecase=True) == 'foo'
    assert regex_replace('foo\nbar', '^ba', 'BA', multiline=False) == 'foo\nbar'
    assert regex_replace('foo\nbar', '^ba', 'BA', multiline=True) == 'foo\nBAr'
    assert regex_replace('foo\nbar', '^ba', 'BA', ignorecase=True, multiline=True) == 'foo\nBAr'

# Generated at 2022-06-21 04:32:16.464963
# Unit test for function rand
def test_rand():
    try:
        rand(None, 4, 1, 1)
        rand(None, 4, 1, 1, 'seed')
        rand(None, "not an int")
        rand(None, "not an int", "not a start")
        rand(None, "not an int", "not a start", "not a step")
    except AnsibleFilterError:
        pass



# Generated at 2022-06-21 04:32:23.551391
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/bin/bash") == ["/bin/bash"]
    assert fileglob("/bin/b*") == ["/bin/bash"]
    assert fileglob("/nonexistentpath") == []



# Generated at 2022-06-21 04:32:25.282933
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('name: foo_123', 'foo_(\d+)') == ['123']



# Generated at 2022-06-21 04:32:27.255618
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert {'key1': 'value1', 'key2': 'value2'} == list_of_dict_key_value_elements_to_dict([
        {'value': 'value1', 'key': 'key1'},
        {'key': 'key2', 'value': 'value2'},
    ])



# Generated at 2022-06-21 04:32:40.422178
# Unit test for function ternary
def test_ternary():
    true = ternary(True, 'yes', 'no')
    assert true == 'yes'
    false = ternary(False, 'yes', 'no')
    assert false == 'no'
    none_val = ternary(None, 'yes', 'no', 'maybe')
    assert none_val == 'maybe'
    none_val = ternary(None, 'yes', 'no')
    assert none_val == 'no'
    zero_true = ternary(0, 'yes', 'no')
    assert zero_true == 'no'
    empty_true = ternary('', 'yes', 'no')
    assert empty_true == 'no'



# Generated at 2022-06-21 04:32:48.287495
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo.*bar') == r'foo\.'
    assert regex_escape(r'foo.*bar', re_type='posix_basic') == r'foo\.\*bar'
    assert regex_escape(r'foo.*bar', re_type='posix_extended') == r'foo\.\*bar'



# Generated at 2022-06-21 04:32:59.690500
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) is None
    assert from_yaml(True) is True
    assert from_yaml(42) == 42
    assert from_yaml("42") == 42
    assert from_yaml("42.1") == 42.1
    assert from_yaml("true") is True
    assert from_yaml("false") is False
    assert from_yaml("null") is None
    assert from_yaml("{'a': 1}") == {'a': 1}
    assert from_yaml("[1,2,3]") == [1, 2, 3]



# Generated at 2022-06-21 04:33:09.470713
# Unit test for function subelements
def test_subelements():
    assert subelements({'key': 'value'}, 'key') == [(('value',), 'key')]
    assert subelements([{'key': 'value'}], 'key') == [(('value',), 'key')]
    assert subelements([{'key': 'value'}], ['key']) == [(('value',), 'key')]
    assert subelements([{'key': {'subkey': 'value'}}], 'key.subkey') == [(('value',), 'subkey')]
    assert subelements({'key': {'subkey': 'value'}}, 'key.subkey') == [(('value',), 'subkey')]

# Generated at 2022-06-21 04:33:21.835769
# Unit test for function to_nice_json
def test_to_nice_json():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence, is_set

    assert to_nice_json({'foo': {'bar': 'baz'}}) == to_text('{\n    "foo": {\n        "bar": "baz"\n    }\n}')
    assert to_nice_json({'foo': {'bar': 'baz'}}, sort_keys=True) == to_text('{\n    "foo": {\n        "bar": "baz"\n    }\n}')

    class Foo(basic.AnsibleModule):
        pass

    assert '"bar": "baz"' in to_nice_json({'foo': Foo()})

# Generated at 2022-06-21 04:33:30.037827
# Unit test for function regex_replace
def test_regex_replace():
    # Basic call
    assert regex_replace('asdf1234', r'\d+', '#') == 'asdf#'
    # Regex with flags
    assert regex_replace('asdf1234', r'(?i)\d+', '#') == 'asdf#'
    # Passing a unicode string
    assert regex_replace(u'asdf1234', r'\d+', '#') == 'asdf#'


# Generated at 2022-06-21 04:33:41.182315
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None
    assert to_bool('') is False
    assert to_bool(' ') is False
    assert to_bool('  ') is False



# Generated at 2022-06-21 04:33:52.411216
# Unit test for function comment
def test_comment():
    # Test plain
    assert comment(
        'This is a plain comment.', style='plain') == '# This is a plain comment.'
    assert comment(
        'This is a plain comment.\nWith a newline.', style='plain') == '# This is a plain comment.\n# With a newline.'
    assert comment(
        'This is a plain comment.', style='plain', beginning='#######') == '#######\n# This is a plain comment.'
    assert comment(
        'This is a plain comment.', style='plain', decoration=';; ', prefix=';;') == ';; ;; This is a plain comment.'
    assert comment(
        'This is a plain comment.', style='plain', decoration=';; ', postfix=';;') == '# ;; This is a plain comment.;; '

# Generated at 2022-06-21 04:33:54.390444
# Unit test for function path_join
def test_path_join():
    assert path_join(['/tmp', 'file.txt']) == '/tmp/file.txt'
    assert path_join('/tmp/file.txt') == '/tmp/file.txt'



# Generated at 2022-06-21 04:34:00.948255
# Unit test for function to_bool
def test_to_bool():
    '''Test function to_bool'''
    assert to_bool(1) == True
    assert to_bool('yes') == True
    assert to_bool(True) == True
    assert to_bool(0) == False
    assert to_bool('no') == False
    assert to_bool(False) == False



# Generated at 2022-06-21 04:34:13.136449
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    import base64
    import hashlib
    import hmac
    import os
    import random
    import struct

    def encrypt_blob(key, plaintext, associated_data):
        # type: (bytes, bytes, bytes) -> bytes
        """
        Encrypts the plaintext with the given key and associated data.

        Args:
            key: An AES256 key.
            plaintext: The data to encrypt.
            associated_data: Authenticated but unencrypted data

        Returns:
            The encrypted data, with the MAC prepended.
        """
        # Generate

# Generated at 2022-06-21 04:34:23.703692
# Unit test for function quote
def test_quote():
    assert quote('foo') == b'\'foo\''
    assert quote('"foo"') == b'"\\"foo\\""'
    assert quote(None) == b'\'\''
    assert quote(b'foo') == b'\'foo\''
    assert quote(u'foo') == u'\'foo\''
    assert quote(u' "foo" ') == u'" \\"foo\\" "'



# Generated at 2022-06-21 04:34:29.073548
# Unit test for function do_groupby
def test_do_groupby():
    from ansible import constants
    from ansible.parsing.dataloader import DataLoader

    env = Environment(loader=DictLoader({}))
    filter_loader = FilterModule()
    env.filters.update(filter_loader.filters())

    constants.HASH_BEHAVIOUR = 'replace'
    with env.push_runtime():
        # test to see if a namedtuple is returned
        bad_groupby = env.filters['groupby']('foo', '[ { "foo": "f"}, { "foo": "f"} ]')
        assert(isinstance(bad_groupby[0][0], tuple))

        # test to see if a normal tuple is returned

# Generated at 2022-06-21 04:34:30.434699
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo', 'bar') == 'foo'
    raises(AnsibleFilterError, 'mandatory("foo")')



# Generated at 2022-06-21 04:34:43.499776
# Unit test for function quote
def test_quote():
    '''Return a Python test case for quote'''

    TESTS = [
        (None, u"''"),
        (123, u"'123'"),
        ('abcd efg', u"'abcd efg'"),
    ]

    from ansible.utils.pytest.loader import ModuleLoader
    from ansible.utils.pytest.runner import run_pytest
    import pytest

    loader = ModuleLoader(None)
    test_gen = loader.load_common_tests_for_module(test_quote, 'quote')
    test_gen.add_generator(test_quote)

    return run_pytest(test_gen, tests=TESTS)



# Generated at 2022-06-21 04:34:51.473702
# Unit test for function combine
def test_combine():
    # Check that it works with no argument
    assert combine() == {}

    # Check that it works with one argument
    assert combine({'a': 1}) == {'a': 1}

    # Check that it works with two arguments
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}

    # Check that it works with three arguments
    assert combine({'a': 1}, {'b': 2}, {'b': 3}) == {'a': 1, 'b': 3}

    # Check that it works with non-standard types
    value_random = object()
    assert combine({'a': value_random}) == {'a': value_random}

    # Check that it works with a list that has only one dict

# Generated at 2022-06-21 04:34:54.655370
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 1, 0) == 1
    assert ternary(0, 1, 0) == 0
    assert ternary("foo", "foo", "bar") == "foo"
    assert ternary("", "foo", "bar") == "bar"
    assert ternary(True, 1, 0) == 1
    assert ternary(False, 1, 0) == 0



# Generated at 2022-06-21 04:35:02.957325
# Unit test for function to_yaml
def test_to_yaml():

    # a nested dict converted to yaml
    result = to_yaml({'a': 1, 'b': {'c': 2}}, width=60)
    assert result == 'a: 1\nb:\n  c: 2\n'

    # a nested dict with dotted key converted to yaml
    result = to_yaml({'a': 1, 'b': {'c.d': 2}}, width=60)
    assert result == 'a: 1\nb:\n  "c.d": 2\n'


# Generated at 2022-06-21 04:35:07.176650
# Unit test for function combine
def test_combine():
    if not hasattr(combine, '__iter__'):
        raise AssertionError("'combine' is not an iterator.  If you're using a jinja2 version < 2.7, you can use the jinja2_iteration_utilities: https://github.com/jtyr/jinja2-iteration-utilities")
    if combine.__iter__() is not combine:
        raise AssertionError("'combine' is not an iterator.  If you're using a jinja2 version < 2.7, you can use the jinja2_iteration_utilities: https://github.com/jtyr/jinja2-iteration-utilities")

# Generated at 2022-06-21 04:35:16.785451
# Unit test for function flatten
def test_flatten():
    # Test all inputs that should return [1,2,3,4]
    data_valid = [
        [1, 2, 3, 4],
        [[1, 2], 3, 4],
        [[1, 2], 3, [4]],
        [[1, 2], [3, 4]],
        [[[1, 2]], [3, 4]],
        [[[1, 2]], [[3, 4]]],
        [[1, 2], [[3, 4]]],
        [1, 2, [3, 4]],
    ]
    for data in data_valid:
        assert flatten(data) == [1, 2, 3, 4]
        assert flatten(data, levels=0) == [1, 2, [3, 4]]

# Generated at 2022-06-21 04:35:19.049001
# Unit test for function regex_search
def test_regex_search():
    x = regex_search('Hello World', 'World')
    assert x == 'World'



# Generated at 2022-06-21 04:35:27.834668
# Unit test for function get_hash
def test_get_hash():
    h = get_hash('foobar')
    assert h == '8843d7f92416211de9ebb963ff4ce28125932878'


# ansible-specific filtering

# Generated at 2022-06-21 04:35:35.641687
# Unit test for function comment
def test_comment():
    # Test all predefined comment styles
    for style in comment._filter.comment_styles:
        assert comment('test1', style=style) == comment('test1', **comment._filter.comment_styles[style])

    # Test custom comment style
    p = {
        'newline': '\n',
        'prefix': '// ',
        'postfix': '// ',
        'beginning': '/*',
        'end': '*/'
    }
    assert comment('test2', **p) == '%s\n%s\n%s\n%s%s\n' % (p['beginning'], p['prefix'], '// test2', p['postfix'], p['end'])

    # Test shorthands

# Generated at 2022-06-21 04:35:50.891692
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # Check if it can parse valid YAML strings
    assert from_yaml_all("---\n- a\n- b") == [{u'a': None}, {u'b': None}]

    # Check if it can handle invalid strings
    assert from_yaml_all("- a\n- b") == [{u'- a': None, u'- b': None}]
    assert from_yaml_all("- a\n- b") == [{u'- a': None, u'- b': None}]
    assert from_yaml_all("- a\n- b") == [{u'- a': None, u'- b': None}]
    assert from_yaml_all("- a\n- b") == [{u'- a': None, u'- b': None}]
    assert from_yaml_

# Generated at 2022-06-21 04:36:03.254803
# Unit test for function rand
def test_rand():
    result = rand('foo', 10)
    assert result >= 0 and result < 10
    result = rand('foo', 10, 3)
    assert result >= 3 and result < 10
    result = rand('foo', 10, 3, 2)
    assert result >= 3 and (result - 3) % 2 == 0 and result < 10
    result = rand('foo', 10, 3, seed='bar')
    assert result >= 3 and result < 10

    result = rand('foo', [1, 2, 3])
    assert result in [1, 2, 3]
    result = rand('foo', (1, 2, 3))
    assert result in (1, 2, 3)
    result = rand('foo', {'a': 1, 'b': 2})
    assert result in {'a': 1, 'b': 2}


# Generated at 2022-06-21 04:36:13.493307
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError('Undefined failed.')

    mandatory([1], msg="Optional message")

    try:
        mandatory(Undefined(name='foo'), msg="Optional message")
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError('Undefined failed')

    assert 'bar' == mandatory('bar')



# Generated at 2022-06-21 04:36:24.387995
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('1970-01-01 00:00:00') == datetime.datetime(1970, 1, 1, 0, 0)
    assert to_datetime('1970-01-01 00:00:00', '%Y-%m-%d %H:%M:%S') == datetime.datetime(1970, 1, 1, 0, 0)
    assert to_datetime('Jan 02 2017 01:02:03', '%b %d %Y %H:%M:%S') == datetime.datetime(2017, 1, 2, 1, 2, 3)



# Generated at 2022-06-21 04:36:37.737317
# Unit test for function from_yaml_all
def test_from_yaml_all():
    test_vars = {}
    test_string = '''
        one
        ---
        two
        ---
        three
        {% if test_vars.is_defined %}
        ---
        four
        {% endif %}
        ---
        five
    '''
    from ansible.errors import AnsibleFilterError
    from ansible.template import AnsibleEnvironment
    env = AnsibleEnvironment(loader=None)
    try:
        for each in from_yaml_all(test_string):
            env.filters['from_yaml'](each)
    except AnsibleFilterError as e:
        # The test failed
        print(e)
        sys.exit(1)
    sys.exit(0)
if __name__ == "__main__":
    test_from_yaml_all()



# Generated at 2022-06-21 04:36:44.413454
# Unit test for function rand
def test_rand():
    assert rand('', 0) == 0
    assert rand('', 1) == 0
    assert rand('', 10) < 10
    assert rand('', [1, 2, 3, 4]) in [1, 2, 3, 4]
    assert rand('', [1, 2, 3, 4], seed=1) in [1, 2, 3, 4]



# Generated at 2022-06-21 04:36:55.916005
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['b64decode'] == b64decode
    assert f.filters()['b64encode'] == b64encode
    assert f.filters()['to_uuid'] == to_uuid
    assert f.filters()['to_json'] == to_json
    assert f.filters()['to_nice_json'] == to_nice_json
    assert f.filters()['from_json'] == json.loads
    assert f.filters()['to_yaml'] == to_yaml
    assert f.filters()['to_nice_yaml'] == to_nice_yaml
    assert f.filters()['from_yaml'] == from_yaml
    assert f.filters()['from_yaml_all'] == from_y

# Generated at 2022-06-21 04:36:59.521009
# Unit test for function to_json
def test_to_json():
    val = 'a'
    assert to_json(val) == '"a"'
    val = [1, 2, 3]
    assert to_json(val) == '[1, 2, 3]'


# Generated at 2022-06-21 04:37:19.175946
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('foobar') == '5a5c62b5-8a10-5a9f-9b0c-55e5947b9650'
    # The following examples are from Wikipedia:
    # https://en.wikipedia.org/wiki/Universally_unique_identifier
    assert to_uuid('urn:uuid:f81d4fae-7dec-11d0-a765-00a0c91e6bf6') == 'f81d4fae-7dec-11d0-a765-00a0c91e6bf6'

# Generated at 2022-06-21 04:37:25.252182
# Unit test for function to_bool
def test_to_bool():
    b = to_bool('yEs')
    assert True == b
    b = to_bool(True)
    assert True == b
    b = to_bool('yEs')
    assert True == b
    b = to_bool('yEs')
    assert True == b
    b = to_bool('yEs')
    assert True == b
    b = to_bool('yEs')
    assert True == b
    b = to_bool('yEs')
    assert True == b
    b = to_bool('yEs')
    assert True == b



# Generated at 2022-06-21 04:37:28.748481
# Unit test for function b64encode
def test_b64encode():
    string = 'Hello World'
    assert 'SGVsbG8gV29ybGQ=' == b64encode(string)
    assert 'SGVsbG8gV29ybGQ=' == b64encode(string, encoding='utf-8')



# Generated at 2022-06-21 04:37:43.873855
# Unit test for function strftime
def test_strftime():
    assert strftime("%a") == time.strftime("%a")
    assert strftime("%A") == time.strftime("%A")
    assert strftime("%b") == time.strftime("%b")
    assert strftime("%B") == time.strftime("%B")
    assert strftime("%d") == time.strftime("%d")
    assert strftime("%e") == time.strftime("%e")
    assert strftime("%H") == time.strftime("%H")
    assert strftime("%I") == time.strftime("%I")
    assert strftime("%m") == time.strftime("%m")
    assert strftime("%M") == time.strftime("%M")
    assert strftime("%n") == time.strftime("%n")
   

# Generated at 2022-06-21 04:37:49.782876
# Unit test for function comment
def test_comment():
    print(comment('Test', 'c'))
    print(comment('Test', 'erlang'))
    print(comment('Test', 'plain'))
    print(comment('Test', 'cblock'))
    print(comment('Test', 'cblock', prefix='//'))
    print(comment('Test', 'cblock', prefix='// ', decoration=' '))
    print(comment('Test', 'xml'))
    print(comment('Test', 'xml', decoration='  ', prefix='## ', prefix_count=4))



# Generated at 2022-06-21 04:37:54.136732
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('1') is True
    assert to_bool('false') is False
    assert to_bool(1) is True


# Generated at 2022-06-21 04:38:05.148033
# Unit test for function regex_findall
def test_regex_findall():
    ''' Test return of all matches by regex_findall '''
    assert regex_findall('a.b', 'a.b') == ['a.b']
    assert regex_findall('a.b', 'a.b', ignorecase=True) == ['a.b']
    assert regex_findall('a.b', 'a.b', multiline=True) == ['a.b']
    assert regex_findall('a.b', 'a.b', ignorecase=True, multiline=True) == ['a.b']
    assert regex_findall('a.b\na.b', '^a.b$', multiline=True) == ['a.b', 'a.b']

# Generated at 2022-06-21 04:38:08.852464
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes')
    assert to_bool('True')
    assert to_bool('true')
    assert to_bool('1')
    assert to_bool(1)
    assert not to_bool('no')
    assert not to_bool('False')
    assert not to_bool('false')
    assert not to_bool('0')
    assert not to_bool(0)



# Generated at 2022-06-21 04:38:10.535189
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.__class__.__name__ == 'FilterModule'

# Generated at 2022-06-21 04:38:20.061335
# Unit test for function do_groupby
def test_do_groupby():
    """Unit test for the do_groupby filter, which wraps the jinja2
    implementation to ensure it returns a tuple, not a namedtuple.
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from jinja2 import DictLoader, Environment

    env = Environment(loader=DictLoader({'test': '{{ items|groupby("name") }}'}))
    env.filters.update(C.__dict__)
    data = env.get_template('test').render({'items': [ImmutableDict({'name': 'A', 'value': 1}), ImmutableDict({'name': 'B', 'value': 2}), ImmutableDict({'name': 'A', 'value': 3})]})
    output = ast.literal_eval(data)

# Generated at 2022-06-21 04:38:44.032945
# Unit test for function extract
def test_extract():
    item = "a"
    container = {"a": "b"}
    assert(extract(item, container) == "b")
    container = {"a": {"b": "c"}}
    assert(extract(item, container) == {"b": "c"})
    assert(extract(item, container, "b") == "c")
    assert(extract(item, container, morekeys=["b"]) == "c")
    assert(extract(item, container, morekeys=("b",)) == "c")



# Generated at 2022-06-21 04:38:48.224832
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('abc123!?"') == 'YWJjMTIzIT8='
    assert b64encode('üöä-+#/') == 'w7zDpMKnLys='
    assert b64encode('中文') == '5Lit5paH'
    assert b64encode('öäü-öäü') == 'w67DpMKnLXnDpMKn'



# Generated at 2022-06-21 04:38:56.579789
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    pw = get_encrypted_password('test')
    # note that this is the best we can do without updating the value
    # returned by the function.
    assert pw == '$6$rounds=656000$Y8aLbzF5.5ET.p5W$U8PZo9x6xFY1/pWH1/j8vmeFnGQoBg6U/PQrHZ74q3DgDeA3AepfY.Y8yc.pTxvyg/sCd.U8W6I9omZx0xMja1'
    pw = get_encrypted_password('test', 'sha512', salt='AB01')

# Generated at 2022-06-21 04:39:02.800078
# Unit test for function ternary
def test_ternary():
    assert ternary("foo", "f", "b") == "f"
    assert ternary("", "f", "b") == "b"
    assert ternary(None, "f", "b") == "b"
    assert ternary(None, "f", "b", "n") == "n"



# Generated at 2022-06-21 04:39:13.590033
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool(1) is True
    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool(0) is False
    assert to_bool('') is False
    assert to_bool('foo') is False
    assert to_bool(True) is True
    assert to_bool(False) is False



# Generated at 2022-06-21 04:39:14.976745
# Unit test for function combine
def test_combine():
    pass



# Generated at 2022-06-21 04:39:25.727890
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', r'\s', '\\1') == ' '
    assert regex_search('hello world', r'\s', '\\g<1>') == ' '
    assert regex_search('hello world', r'\w{5}', '\\g<0>') == 'hello'
    assert regex_search('/tmp/a/b/c/file.txt', r'/([^/]*)$', '\\1') == 'file.txt'
    assert regex_search('/tmp/a/b/c/file.txt', r'/([^/]*)$', '\\g<1>') == 'file.txt'
    assert regex_search('/tmp/a/b/c/file.txt', r'/([^/]*)$', '\\g<1>', '\\g<0>')

# Generated at 2022-06-21 04:39:34.170465
# Unit test for function path_join
def test_path_join():
    assert path_join('one') == 'one'
    assert path_join('one', 'two') == 'one/two'
    assert path_join(['one', 'two']) == 'one/two'
    assert path_join(['one', 'two']) == 'one/two'
    assert path_join('one', ['two', 'three']) == 'one/two/three'
    assert path_join(['one', ['two', 'three']]) == 'one/two/three'
    assert path_join(['one', [['two', 'three']]]) == 'one/two/three'
    assert path_join(['one', ['two', ['three', 'four']]]) == 'one/two/three/four'



# Generated at 2022-06-21 04:39:44.032817
# Unit test for function comment
def test_comment():
    assert comment('text', style='plain') == "# text"
    assert comment('text', style='erlang') == "% text"
    assert comment('text', style='c') == "// text"
    assert comment('text', style='cblock') == """/*
 * text
 */"""
    assert comment('text', style='xml') == '<!-- - text-->'
    assert comment('text', style='cblock', decoration=' * ') == """/*
 * text
 */"""
    assert comment('text', style='cblock', beginning='/*', end=' */') == """/*
 * text
 */"""
    assert comment('text', style='cblock', decoration='**') == """/*
**text
*/"""
    assert comment('text\nnewline', style='plain') == """# text
# newline"""

# Generated at 2022-06-21 04:39:55.809383
# Unit test for function combine
def test_combine():
    assert combine({1: 1}, {2: 2}) == {1: 1, 2: 2}
    assert combine({'foo': {'bar': 'baz'}}, {'foo': {'bar': 'boo'}}) == {'foo': {'bar': 'boo'}}
    assert combine({'foo': {'bar': 'baz'}}, {'foo': {'bar': 'boo'}}, recursive=True) == {'foo': {'bar': 'boo'}}
    assert combine({'foo': {'bar': 'baz'}}, {'foo': {'bar': 'boo'}}, recursive=False) == {'foo': {'bar': 'baz'}}