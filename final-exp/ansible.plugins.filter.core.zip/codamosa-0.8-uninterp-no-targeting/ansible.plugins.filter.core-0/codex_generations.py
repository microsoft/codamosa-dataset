

# Generated at 2022-06-21 04:30:15.187536
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', 1517893709) == '2018-02-07 03:08:29'
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%H:%M:%S') == time.strftime('%H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', 12345678909) == '2009-02-13 17:31:50'

# Generated at 2022-06-21 04:30:20.307352
# Unit test for function b64encode

# Generated at 2022-06-21 04:30:27.489430
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'') == r''
    assert regex_escape(r'foo') == r'foo'
    assert regex_escape(r'foo.bar') == r'foo\.bar'
    assert regex_escape(r'foo|bar') == r'foo\|bar'
    assert regex_escape(r'\1') == r'\\1'
    assert regex_escape(r'{1}') == r'\{1\}'
    assert regex_escape(r'foo', re_type='posix_basic') == r'foo'
    assert regex_escape(r'foo.bar', re_type='posix_basic') == r'foo\.bar'
    assert regex_escape(r'foo|bar', re_type='posix_basic') == r'foo\|bar'
    assert regex_escape

# Generated at 2022-06-21 04:30:37.625247
# Unit test for function path_join
def test_path_join():
    assert path_join('/a') == '/a'
    assert path_join('/a/') == '/a'
    assert path_join('a', 'b') == 'a/b'
    assert path_join(('a', 'b')) == 'a/b'
    assert path_join(['a', 'b']) == 'a/b'
    assert path_join(['a/', 'b']) == 'a/b'
    assert path_join(['/a', 'b']) == '/a/b'
    assert path_join(['/a/', 'b']) == '/a/b'
    assert path_join(('/a/', '/b/')) == '/a/b'
    assert path_join(('/a/', '/b')) == '/a/b'



# Generated at 2022-06-21 04:30:48.481203
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(pattern='(\w+)',
                         replacement=r'\1',
                         value='the fox ran',
                         ignorecase=True) == 'the fox ran'
    assert regex_replace(pattern='(\w+)',
                         replacement=r'\1',
                         value='the fox ran',
                         multiline=True) == 'the fox ran'
    assert regex_replace(pattern='(?P<animal>\w+)',
                         replacement=r'\g<animal>',
                         value='the fox ran',
                         ignorecase=True) == 'the fox ran'
    assert regex_replace(pattern='(?P<animal>\w+)',
                         replacement=r'\g<animal>',
                         value='the fox ran',
                         multiline=True) == 'the fox ran'

# Generated at 2022-06-21 04:30:51.013000
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    container = dict()
    container['new_yaml'] = to_nice_yaml({'x':'y'},indent=4)
    print(container['new_yaml'])


# Generated at 2022-06-21 04:30:58.469962
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subels = 'groups'
    assert subelements(obj, subels) == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]


# Generated at 2022-06-21 04:31:07.095747
# Unit test for function combine
def test_combine():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert combine(
        {'a': '1', 'b': '2'},
        {'b': '3', 'c': '4'}
    ) == {'a': '1', 'b': '3', 'c': '4'}

    assert combine(
        AnsibleUnicode('{"a": "1", "b": "2"}', 500, 0),
        AnsibleUnicode('{"b": "3", "c": "4"}', 500, 0)
    ) == {'a': '1', 'b': '3', 'c': '4'}


# Generated at 2022-06-21 04:31:10.533315
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'test'}, indent=1) == """{a: test}"""



# Generated at 2022-06-21 04:31:19.993178
# Unit test for function regex_replace
def test_regex_replace():
    '''
    Test function returns expected output
    '''
    value = '''
Can you hear me now?
no
Try me now
You should, I can hear you.
'''
    replaced = '''
I can hear you now?
no
I will hear you now
You should, I can hear you.
'''
    # pattern = r'^(Can|Try) (you|me) (\.|\?)$'
    # replacement = r'I will hear \2\3'
    # print(regex_replace(value,pattern,replacement,multiline=True))
    assert regex_replace(value, r'^(Can|Try) (you|me) (\.|\?)$', r'I will hear \2\3', multiline=True) == replaced



# Generated at 2022-06-21 04:31:39.678945
# Unit test for function ternary
def test_ternary():
    x = 1
    y = 0

    # With three args, should behave like C ternary operator
    assert ternary(x, 'x', 'y') == 'x'
    assert ternary(y, 'x', 'y') == 'y'

    # With four args, should also handle None directly
    assert ternary(x, 'x', 'y', none_val='z') == 'x'
    assert ternary(y, 'x', 'y', none_val='z') == 'y'
    assert ternary(None, 'x', 'y', none_val='z') == 'z'


# Generated at 2022-06-21 04:31:42.875065
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("é") == 'w6k='
    assert b64encode("\xe9") == 'w6k='


# Generated at 2022-06-21 04:31:49.177895
# Unit test for function ternary
def test_ternary():
    test_inputs = [
        (1, 'true_val', 'false_val', 'none_val'),
        ('Abc', 'true_val', 'false_val', 'none_val')
    ]
    expected_outputs = [
        'true_val', 'true_val'
    ]
    assert [ternary(i, 'true_val', 'false_val', 'none_val') for i in test_inputs] == expected_outputs



# Generated at 2022-06-21 04:31:55.650206
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("Zm9v") == "foo"
    assert b64decode(b64encode("foo", encoding='utf-16'), encoding='utf-16') == "foo"
    assert b64decode(b64encode("foo", encoding='utf-32'), encoding='utf-32') == "foo"
    assert b64decode(b64encode("foo"), encoding='latin_1') == "foo"
    assert b64decode(b64encode("foo"), encoding='cp65001') == "foo"

_do_groupby = jinja2.filters.do_groupby


# taken from http://stackoverflow.com/a/15505687/389766 and modified.

# Generated at 2022-06-21 04:32:03.048071
# Unit test for function b64decode
def test_b64decode():
    '''
    Test b64decode with different input
    '''
    string = 'SSBhbSBhbiBlbmNvZGVkIHN0cmluZw=='
    result = 'I am an encoded string'
    assert b64decode(string) == result

    string = 'SSBhbSBhbiBlbmNvZGVkIHN0cmluZw==\n'
    result = 'I am an encoded string'
    assert b64decode(string) == result

    string = 'SSBhbSBhbiBlbmNvZGVkIHN0cmluZw=='
    result = 'I am an encoded string'
    assert b64decode(string) == result


# Generated at 2022-06-21 04:32:03.925375
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))


# Generated at 2022-06-21 04:32:15.569097
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()

# Generated at 2022-06-21 04:32:16.701636
# Unit test for function b64decode
def test_b64decode():
    return (
        b64decode('MTIz') == '123',
        b64decode('MTIz', encoding='utf-16') == '123',
    )


# Generated at 2022-06-21 04:32:19.732540
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'first', 'value': 1}, {'key': 'second', 'value': 2}]
    mydict = list_of_dict_key_value_elements_to_dict(mylist)
    assert mydict == dict(mylist)



# Generated at 2022-06-21 04:32:28.404273
# Unit test for function comment
def test_comment():
    assert comment("comment", style='plain') == '# comment'
    assert comment("cblock", style='cblock') == '/*\n * cblock\n */'
    assert comment("erlang", style='erlang') == '% erlang'
    assert comment("cstyle", style='c') == '// cstyle'
    assert comment("xmlcomment", style='xml') == '<!--\n - xmlcomment\n-->'

    # Test newline
    assert comment("newline", style='plain', newline='\n') == '# newline'
    assert comment("newline", style='plain', newline='\r\n') == '# newline'
    assert comment("newline", style='plain', newline='\r') == '# newline'

    # Test decoration

# Generated at 2022-06-21 04:32:39.624390
# Unit test for function strftime
def test_strftime():
    ''' strftime unit test'''

    # Testing for string format
    expected_return1 = time.strftime('%m/%d/%Y')
    returned_value1 = strftime('%m/%d/%Y')
    assert returned_value1 == expected_return1

    # Testing for epoch format
    expected_return2 = time.strftime('%m/%d/%Y')
    returned_value2 = strftime('%m/%d/%Y', time.time())
    assert returned_value2 == expected_return2



# Generated at 2022-06-21 04:32:48.961740
# Unit test for function combine
def test_combine():
    assert combine(dict(a=1, b=2), dict(c=3, b=4)) == dict(a=1, b=4, c=3)
    assert combine(dict(a=1, b=2), dict(c=3, b=4), recursive=True) == dict(a=1, b=4, c=3)
    assert combine(dict(a=1, b=dict(b1=1, b2=2)), dict(c=3, b=dict(b1=4, b3=3)), recursive=True) == dict(a=1, b=dict(b1=4, b2=2, b3=3), c=3)

# Generated at 2022-06-21 04:32:55.992632
# Unit test for function strftime
def test_strftime():
    string = '%Y-%m-%dT%H:%M:%S.%f%z'
    second = 1468364721.1615
    date = strftime(string, second=second)
    assert date == "2016-07-13T20:28:41.161500+0300"


# Generated at 2022-06-21 04:33:00.654940
# Unit test for function to_datetime
def test_to_datetime():
    string = "2001-12-15 01:31:21"
    assert to_datetime(string) == datetime.datetime(2001, 12, 15, 1, 31, 21)
    assert to_datetime(string, format="%Y-%m-%d %H:%M") == datetime.datetime(2001, 12, 15, 1, 31)



# Generated at 2022-06-21 04:33:03.019260
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('foo') == 'a0bfc7ad-84e3-5a55-9cd9-c96533e2e6f3'



# Generated at 2022-06-21 04:33:12.846740
# Unit test for function mandatory
def test_mandatory():
    import jinja2 as j2
    from ansible.parsing.dataloader import DataLoader

    env = j2.Environment(loader=j2.DictLoader({
        't.j2': '',
    }))
    env.filters['mandatory'] = mandatory
    assert env.get_template('t.j2').render() == ''

    assert env.get_template('t.j2').render(x='x') == 'x'

    with pytest.raises(AnsibleFilterError):
        env.get_template('t.j2').render(x=None)

    assert env.get_template('t.j2').render(x=None, msg='x is None') == 'x is None'

    with pytest.raises(AnsibleFilterError):
        env.get_

# Generated at 2022-06-21 04:33:17.231474
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('foo') == 'f8c3b3ae-4670-5d4e-8a4f-4cb1c9f9b59c'


# Generated at 2022-06-21 04:33:19.508016
# Unit test for function b64encode
def test_b64encode():
    string = 'some data'
    result = b64encode(string)

    assert result == 'c29tZSBkYXRh'


# Generated at 2022-06-21 04:33:29.245642
# Unit test for function to_json
def test_to_json():
    ansible_json = to_json({'name': 'test name', 'value': [1, 2, 3]}, sort_keys=True)
    assert ansible_json == '{"name": "test name", "value": [1, 2, 3]}'
    ansible_json = to_json('test string')
    assert ansible_json == '"test string"'
    ansible_json = to_json(123)
    assert ansible_json == '123'



# Generated at 2022-06-21 04:33:38.061498
# Unit test for function from_yaml
def test_from_yaml():
    assert {} == from_yaml('{}')
    assert (from_yaml('{a: a}') == from_yaml('{a: a}\n') ==
            from_yaml('\n{a: a}') == from_yaml('\n{a: a}\n'))
    # Test that a subclassed string is passed through unchanged
    assert isinstance(from_yaml('foo'), string_types)



# Generated at 2022-06-21 04:33:48.095190
# Unit test for function ternary
def test_ternary():
    assert(True == ternary(True, True, False))
    assert(False == ternary(False, True, False))
    assert(False == ternary(None, True, False))
    assert(True == ternary(None, True, False, True))
    assert(False == ternary(None, True, False, False))



# Generated at 2022-06-21 04:33:58.604251
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Template
    from jinja2 import Environment
    from jinja2 import meta
    from textwrap import dedent

    ast = meta.find_undeclared_variables(env.parse(dedent('''
    {% with groups['foo'] %}
      {% for color in ['red', 'blue', 'yellow'] %}
        {% set key = {'color': color} %}
        {{ groups['bar']|groupby(key) }}
      {% endfor %}
    {% endwith %}
    ''')))

    assert ast == set()



# Generated at 2022-06-21 04:34:06.192580
# Unit test for function ternary
def test_ternary():
    assert ternary(1, "true", "false") == "true"
    assert ternary(0, "true", "false") == "false"
    assert ternary(1, "true", "false", "maybe") == "true"
    assert ternary(None, "true", "false", "maybe") == "maybe"
    assert ternary(True, "true", "false") == "true"
    assert ternary(False, "true", "false") == "false"
    assert ternary(True, "true", "false", "maybe") == "true"
    assert ternary(None, "true", "false", "maybe") == "maybe"



# Generated at 2022-06-21 04:34:09.097217
# Unit test for function fileglob
def test_fileglob():
    assert [u'/etc/hosts'] == fileglob(u'/etc/hosts')
    assert [] == fileglob(u'/nofile')


# Generated at 2022-06-21 04:34:18.069812
# Unit test for function ternary
def test_ternary():
    assert ternary(None, "T", "F", "N") == "N"
    assert ternary(True, "T", "F", "N") == "T"
    assert ternary(False, "T", "F", "N") == "F"
    assert ternary(0, "T", "F", "N") == "F"
    assert ternary("foo", "T", "F", "N") == "T"
test_ternary()



# Generated at 2022-06-21 04:34:26.534525
# Unit test for function randomize_list
def test_randomize_list():
    assert [1, 2, 3] == randomize_list((1, 2, 3))
    assert [1, 2, 3, 4] == randomize_list((1, 2, 3, 4))
    assert ['a', 'b', 'c', 'd'] == randomize_list(['a', 'b', 'c', 'd'])
    assert [1, 2, 3, 4] == randomize_list([1, 2, 3, 4])
    assert [1, 2, 3, 4] != randomize_list([1, 2, 3, 4], seed="not_random")
    assert [1, 2, 3, 4] != randomize_list([1, 2, 3, 4], seed="not_random")

# Generated at 2022-06-21 04:34:28.334245
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2, 'c': 3}, {'c': 4, 'd': 5}, {'c': 6}) == {'a': 1, 'b': 2, 'c': 6, 'd': 5}



# Generated at 2022-06-21 04:34:32.572389
# Unit test for function subelements
def test_subelements():
    '''Test for function subelements. All tests should pass.'''
    context = {'user': {'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}}

    # Can we get an element from a dictionary?
    result = subelements(context, 'user.name')
    assert len(result) == 1
    assert result[0] == ({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'alice')

    # Can we get a list of elements from a dictionary?
    result = subelements(context, 'user.groups')
    assert len(result) == 1

# Generated at 2022-06-21 04:34:43.557527
# Unit test for function randomize_list
def test_randomize_list():
    # Confirm that we can randomize a list
    assert randomize_list([1, 2, 3]) != [1, 2, 3]
    # Confirm that we can seed the randomizer and get the same result for the same seed
    assert randomize_list([1, 2, 3], seed=42) == randomize_list([1, 2, 3], seed=42)
    # Confirm that we get the same result for the same list, regardless of whether
    # we seed
    assert randomize_list([1, 2, 3]) == randomize_list([1, 2, 3])
    # Confirm that we don't get the same result for different lists
    assert randomize_list([1, 2, 3, 4]) != randomize_list([1, 2, 3])


# Generated at 2022-06-21 04:34:46.223102
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b'U3ltYm9s') == 'Symbol'



# Generated at 2022-06-21 04:34:54.235366
# Unit test for function path_join
def test_path_join():
    assert("a/b/c" == path_join("a", "b", "c"))
    assert("a/b/c" == path_join(["a", "b", "c"]))
    assert("a/b/c" == path_join("a", ["b", "c"]))
    assert("a/b/c" == path_join(["a", "b"], "c"))



# Generated at 2022-06-21 04:35:01.059425
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    ''' unit test for list_of_dict_key_value_elements_to_dict '''

    mylist = [{'key': 'one', 'value': 1}, {'key': 'two', 'value': 2}, {'key': 'three', 'value': 3}]
    mylist_expected_ret = {'one': 1, 'two': 2, 'three': 3}
    mylist_ret = list_of_dict_key_value_elements_to_dict(mylist)
    assert mylist_ret == mylist_expected_ret, mylist_ret

    mylist = [{'host': 'one', 'port': 1}, {'host': 'two', 'port': 2}, {'host': 'three', 'port': 3}]
    # this does not raise an exception and silently ignores the extra key
    my

# Generated at 2022-06-21 04:35:03.283593
# Unit test for function b64decode
def test_b64decode():
    try:
        assert b64decode('YWJj', encoding='utf-16') == 'abc'
    except Exception as e:
        print(e)
        raise



# Generated at 2022-06-21 04:35:08.044563
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('foobar') == 'Zm9vYmFy'
    assert b64encode('foo bar') == 'Zm9vIGJhcg=='
    assert b64encode(u'fôô☺') == u'ZsOkw7jhkA=='

# Generated at 2022-06-21 04:35:18.611236
# Unit test for function combine
def test_combine():
    # Test with a list of dicts
    d = combine([{"a": 2}, {"b": 3}])
    assert d == {"a": 2, "b": 3}

    # Test with a list of dicts, the last having higher priority
    d = combine([{"a": 2}, {"a": 1, "b": 3}])
    assert d == {"a": 1, "b": 3}

    # Test with a list of dicts, the last having higher priority
    d = combine([{"a": {"a1": 1}, "b": 3}, {"a": {"a2": 2}}])
    assert d == {"a": {"a2": 2}, "b": 3}

    # Test with a list of dicts, the last having higher priority with recursive = True

# Generated at 2022-06-21 04:35:26.998152
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    '''
    Unit test for function get_encrypted_password
    '''
    def _passlib_rounds(rounds=None):
        if rounds is None:
            return 0
        elif rounds is False:
            return 1
        else:
            return rounds

    # password == 'password'
    # salt == '12345'
    # seed == 'seed'
    # rounds == 10
    # ident == '1'
    # salt_size == 8

    # md5_crypt test
    assert get_encrypted_password('password', 'md5', salt='12345', seed='seed', rounds=10, ident='1', salt_size=8) == '$1$12345$tYwYgWd1tTxe1eJyQb27v.'
    # sha256_crypt test
    assert get_

# Generated at 2022-06-21 04:35:34.410172
# Unit test for function quote
def test_quote():
    assert quote(None) == u""
    assert quote(u'foo') == u'"foo"'

# Generated at 2022-06-21 04:35:41.460270
# Unit test for function subelements
def test_subelements():
    assert subelements([{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}], 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]


# Generated at 2022-06-21 04:35:43.703556
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all("- mongodb\n- postgresql\n") == [u'mongodb', u'postgresql']



# Generated at 2022-06-21 04:35:46.131470
# Unit test for function from_yaml_all
def test_from_yaml_all():
    import doctest
    return doctest.testmod(from_yaml_all)



# Generated at 2022-06-21 04:36:05.790788
# Unit test for function extract
def test_extract():
    import ansible.constants as C
    c = C._C
    C._ANSIBLE_TESTING_INTERNAL_DATASTORES = True

    env = Environment(undefined=ansible_undefined_singleton)
    ansible_facts = {'foo': {'bar': {'baz': 'qux'}}}
    env._shared_loader_context['ansible_facts'] = ansible_facts
    assert extract(env, 'foo', c) == ansible_facts['foo']
    assert extract(env, 'bar', c, 'foo') == ansible_facts['foo']['bar']
    assert extract(env, 'baz', c, 'foo', 'bar') == ansible_facts['foo']['bar']['baz']

    C._ANSIBLE_TESTING_INTERNAL_

# Generated at 2022-06-21 04:36:15.331684
# Unit test for function from_yaml
def test_from_yaml():
    import textwrap
    # test with invalid data
    assert from_yaml('{"foo": 1}') == {}

    # test with data that pyyaml can't parse
    assert from_yaml('{foo: 1}') == '{foo: 1}'

    # test with data that pyyaml can parse
    assert from_yaml('foo: 1') == {u'foo': 1}

    # test with a multiline string
    assert from_yaml(textwrap.dedent("""
    foo:
      - bar: 1
      - baz: 2
    """)) == {u'foo': [{u'bar': 1}, {u'baz': 2}]}



# Generated at 2022-06-21 04:36:18.759265
# Unit test for function b64encode
def test_b64encode():
    assert(b64encode('John Smith') == 'Sm9obiBTYXRoaA==')
    assert(b64encode('John Smith', encoding='ascii') == 'Sm9obiBTYXRoaA==')
    assert(b64encode('John Smith', encoding='latin-1') == 'Sm9obiBTYXRoaA==')



# Generated at 2022-06-21 04:36:22.646436
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # unicode
    assert to_nice_yaml({'a': u'\u0430'}) == u'a: \u0430\n'



# Generated at 2022-06-21 04:36:35.791189
# Unit test for function to_yaml
def test_to_yaml():
    assert(to_yaml([1,2,3], default_flow_style=False) == "[1, 2, 3]\n")
    assert(to_yaml([1,2,3], default_flow_style=True) == "[1, 2, 3]")
    assert(to_yaml([1,2,3]) == "[1, 2, 3]\n")
    assert(to_yaml({"one":1,"two":2,"three":3}) == """{one: 1, two: 2, three: 3}\n""")

# Generated at 2022-06-21 04:36:48.711687
# Unit test for function extract
def test_extract():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    # test some basic extraction cases
    assert extract(inventory, 'a', {'a': '1'}) == '1'
    assert extract(inventory, 'a', {'a': '1'}, 'b') == '1'
    assert extract(inventory, 'b', {'a': '1'}, 'b') is None
    # test more complex extraction cases

# Generated at 2022-06-21 04:36:57.636087
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(None) is None
    assert to_bool(True)
    assert to_bool(False) is False
    assert to_bool("on")
    assert to_bool("off") is False
    assert to_bool("1")
    assert to_bool("0") is False
    assert to_bool("yes")
    assert to_bool("no") is False
    assert to_bool("true")
    assert to_bool("false") is False
    assert to_bool(1)
    assert to_bool(0) is False
    assert to_bool("whatever") is True



# Generated at 2022-06-21 04:37:01.299804
# Unit test for function to_nice_json
def test_to_nice_json():
    assert '''{
    "foo": "bar"
}''' == to_nice_json({'foo': 'bar'})



# Generated at 2022-06-21 04:37:07.163421
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('A.B?') == 'A\\.B\\?'
    assert regex_escape('A.B?', re_type='python') == 'A\\.B\\?'
    assert regex_escape('A.B?', re_type='posix_basic') == 'A\\.B\\?'
    # TODO: add more descriptive test
    # assert regex_escape('A.B?', re_type='posix_extended') == 'A\\.B\\?'
    assert regex_escape('$*\\') == '\\$\\*\\\\'
    assert regex_escape('$*\\', re_type='posix_basic') == '\\$\\*\\\\'



# Generated at 2022-06-21 04:37:13.563687
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1,2,3,4]
    # test w/ seed
    assert randomize_list(mylist, seed=1024) == mylist
    # test w/o seed
    assert randomize_list(mylist) != mylist



# Generated at 2022-06-21 04:37:26.169506
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    x = {'a': 'b', 'c': ['d', 'e']}
    assert to_nice_yaml(x) == to_yaml(x)



# Generated at 2022-06-21 04:37:30.586279
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # https://github.com/ansible/ansible/issues/49562
    data = '\n'.join(("# test", "a: 1", "- 2", "- 3"))
    val = from_yaml_all(data)
    assert isinstance(val, list)
    assert len(val) == 2
    assert val[0]['a'] == 1
    assert val[1] == [2, 3]



# Generated at 2022-06-21 04:37:40.049303
# Unit test for function to_json
def test_to_json():
    # test of list
    result = to_json([1, 2, 3])
    assert u'[1, 2, 3]' == result
    # test of dict
    result = to_json({'foo': 'bar'})
    assert u'{"foo": "bar"}' == result
    # test of bool
    result = to_json(True)
    assert u'true' == result


# Generated at 2022-06-21 04:37:50.637432
# Unit test for function regex_escape
def test_regex_escape():

    def assert_equal(x, y):
        if x != y:
            raise AssertionError("{0} != {1}".format(x, y))

    assert_equal(regex_escape(""), "")
    assert_equal(regex_escape("foo"), "foo")
    assert_equal(regex_escape("foo bar"), "foo bar")
    assert_equal(regex_escape("foo(bar"), "foo\\(bar")
    assert_equal(regex_escape("foo)bar"), "foo\\)bar")
    assert_equal(regex_escape("foo(bar)"), "foo\\(bar\\)")
    assert_equal(regex_escape("foo|bar"), "foo\\|bar")
    assert_equal(regex_escape("foo&bar"), "foo&bar")
    assert_equal

# Generated at 2022-06-21 04:38:04.048810
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('こんにちは') == '44GT44KT44Gr44Gh44Gv'
    assert b64encode('\u3053\u3093\u306b\u3061\u306f', 'utf-8') == '44GT44KT44Gr44Gh44Gv'
    assert b64encode('\u3053\u3093\u306b\u3061\u306f', 'shift-jis') == '44GI44GE44GO44GK44CC'
    assert b64encode('こんにちは', 'shift-jis') == '44GI44GE44GO44GK44CC'

# Generated at 2022-06-21 04:38:07.291310
# Unit test for function to_json
def test_to_json():
    assert to_json({'a': 10, 'b': [1,2,3]}) == '{"a": 10, "b": [1, 2, 3]}'



# Generated at 2022-06-21 04:38:14.315062
# Unit test for function randomize_list
def test_randomize_list():
    mylist = ['apple', 'banana', 'cranberry', 'dragonfruit', 'elderberry']
    expected = ['banana', 'apple', 'cranberry', 'elderberry', 'dragonfruit']
    assert randomize_list(mylist, seed='3H8nN70Ng') == expected, 'randomize_list should return an object of the same type that was passed in'
    assert randomize_list(mylist) != expected, 'randomize_list should return a randomized list'



# Generated at 2022-06-21 04:38:21.643213
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2010-03-03 06:06:06", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2010, 3, 3, 6, 6, 6)


# Generated at 2022-06-21 04:38:33.913416
# Unit test for function path_join
def test_path_join():
    x = path_join(['a', 'b', 'c'])
    y = path_join((('a', 'b', 'c'),))
    z = path_join('a/b/c')
    y1 = path_join(('a', 'b', 'c'))
    y2 = path_join(('a',))
    y3 = path_join(('b',))
    z1 = path_join('a')
    z2 = path_join('b')
    assert x == 'a/b/c'
    assert y == 'a/b/c'
    assert z == 'a/b/c'
    assert y1 == 'a/b/c'
    assert y2 == 'a'
    assert y3 == 'b'
    assert z1 == 'a'

# Generated at 2022-06-21 04:38:44.341959
# Unit test for function extract
def test_extract():
    assert extract(None, 'a', {'a': 1}) == 1
    assert extract(None, 'a', {'b': 'c'}) is None
    assert extract(None, 'a', {'a': {'b': {'c': 2}}}, 'b') == {'c': 2}
    assert extract(None, 'a', {'a': {'b': {'c': 2}}}, 'b', 'c') == 2
    assert extract(None, 'a', {'a': {'b': {'c': 2}}}, ['b', 'c']) == 2



# Generated at 2022-06-21 04:39:05.474907
# Unit test for function comment
def test_comment():
    assert '# F' == comment('F', 'plain', decoration='# ')
    assert '# Foo' == comment('Foo', 'plain', decoration='# ')
    assert '# Foo' == comment('Foo', 'plain', decoration='# ', newline='')
    assert '# Foo\n# Bar\n' == comment('Foo\nBar', 'plain', decoration='# ')
    assert '# Foo\n# Bar\n\n' == comment('Foo\nBar', 'plain', decoration='# ', newline='\n', postfix_count=2)
    assert '# Foo\n# Bar\n\n\n' == comment('Foo\nBar', 'plain', decoration='# ', postfix_count=3)

# Generated at 2022-06-21 04:39:10.389196
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('password', hashtype='sha512', salt='$6$saltstring') == '$6$saltstring$svn8UoSVapNtMuq1ukKS4tPQd8iKwSMHWjl/O817G3uBnIFNjnQJuesI68u4OTLiBFdcbYEdFCoEOfaS35inz1'
    assert get_encrypted_password('password', hashtype='blowfish', salt='$2a$07$usesomesillystringforsalt$') == '$2a$07$usesomesillystringfore2uDLvp1Ii2e./U9C8sBjqp8I90dH6hi'



# Generated at 2022-06-21 04:39:22.464408
# Unit test for function combine
def test_combine():
    # Test 1
    test1 = dict()
    test2 = dict()
    test2['test'] = 'test'
    test2['test2'] = 'test2'
    test3 = dict()
    test3['test'] = 'test3'
    test3['test3'] = 'test3'
    result = combine(test1, test2, test3)
    assert result == {'test': 'test3', 'test2': 'test2', 'test3': 'test3'}

    # Test 2
    test2 = dict()
    test2['test'] = 'test'
    test2['test2'] = 'test2'
    test3 = dict()
    test3['test'] = 'test3'
    test3['test3'] = 'test3'
    result = combine(test2, test3)

# Generated at 2022-06-21 04:39:31.403416
# Unit test for function mandatory
def test_mandatory():
    # Make sure that if we have the variable defined it does not raise an exception
    assert mandatory('present') == 'present'
    # Make sure that if we don't have the variable defined it does not raise an exception
    from jinja2.runtime import Undefined
    from jinja2.exceptions import UndefinedError
    try:
        mandatory(Undefined('mandatory_var'))
    except AnsibleFilterError as e:
        assert e.message == 'Mandatory variable \'mandatory_var\' not defined.'



# Generated at 2022-06-21 04:39:42.212179
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y%m%d") == time.strftime("%Y%m%d")
    assert strftime("%Y%m%d", time.time()) == time.strftime("%Y%m%d", time.localtime(time.time()))
    assert strftime("%Y%m%d", time.time() + 3600) == time.strftime("%Y%m%d", time.localtime(time.time() + 3600))
    assert strftime("%Y%m%d", "1570384294") == "20191002"



# Generated at 2022-06-21 04:39:49.215372
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({1: 'foo', 2: 'bar'}) == [{'key': 1, 'value': 'foo'}, {'key': 2, 'value': 'bar'}]
    assert dict_to_list_of_dict_key_value_elements({'a': 'foo', 'b': 'bar'}, key_name='mykey', value_name='myvalue') == [{'mykey': 'a', 'myvalue': 'foo'}, {'mykey': 'b', 'myvalue': 'bar'}]

