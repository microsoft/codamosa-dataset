

# Generated at 2022-06-21 04:30:22.533592
# Unit test for function to_datetime
def test_to_datetime():
    value = to_datetime(u'2016-12-12 00:01:00')
    assert isinstance(value, datetime.datetime)
    assert str(value) == "2016-12-12 00:01:00"


# Generated at 2022-06-21 04:30:29.525170
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 2, 3) == 2
    assert ternary(0, 2, 3) == 3
    assert ternary(None, 2, 3) == 3
    assert ternary(None, 2, 3, None) is None



# Generated at 2022-06-21 04:30:31.727859
# Unit test for function flatten
def test_flatten():
    return flatten(['hi', '1,2,3', ['a', ['b', 'c'], 'd'], [1, 2, 3], None])



# Generated at 2022-06-21 04:30:38.084547
# Unit test for function to_nice_yaml
def test_to_nice_yaml():

    assert to_nice_yaml({'a': 1, 'b': {'c': 2}, 'd': [3, 4]}) == '''{a: 1,
b: {c: 2},
d: [3,
    4]}'''
    assert to_nice_yaml({'a': 1, 'b': {'c': 2}, 'd': [3, 4]}, indent=3) == '''{a: 1,
   b: {c: 2},
   d: [3,
      4]}'''



# Generated at 2022-06-21 04:30:45.223177
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('ok') == 'ok'
    assert mandatory('') == ''
    assert mandatory(None) is None
    assert mandatory({'a': 'b'}) == {'a': 'b'}
    assert mandatory([1, 2]) == [1, 2]
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory(True) is True
    assert mandatory(False) is False



# Generated at 2022-06-21 04:30:56.917389
# Unit test for function ternary
def test_ternary():
    '''
    Unit test for function ternary
    '''
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'neither') == 'neither'
    assert ternary(2, 3, 'a') == 3
    assert ternary(2, 3, 'a', 'neither') == 3
    assert ternary('foo', 'a', 'b') == 'a'
    assert ternary('foo', 3, 'b', 'neither') == 3



# Generated at 2022-06-21 04:31:07.628791
# Unit test for function from_yaml_all
def test_from_yaml_all():
    data = """
- this
- is
- a
- list
"""
    assert from_yaml_all(data) == [u'this', u'is', u'a', u'list']

    data = """
- key:value
- number:42
"""
    assert from_yaml_all(data) == [{u'key': u'value'}, {u'number': 42}]
    # Ensure that we print the error message if we fail.
    # detect_encoding has some unit tests to check the main cases.
    # This test is just to ensure we invoke it and print errors.

# Generated at 2022-06-21 04:31:15.198001
# Unit test for function regex_findall
def test_regex_findall():
    from ansible.parsing.yaml import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    input_str = unicode_wrap("""
        id: "1234567890"
        name: "{{ hostvars[inventory_hostname]['ansible_default_ipv4']['macaddress'] }}"
        type: "{{ hostvars[inventory_hostname]['ansible_default_ipv4']['interface'] }}"
        """)
    input_data = yaml_load(input_str)

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 04:31:28.030541
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment(loader=DictLoader({
        'test.j2': '{% for key, values in values|groupby("fruit") -%}{{key}}|{{values}}{% endfor %}'}))
    values = [{'fruit': 'apple', 'vegetable': 'cucumber'},
              {'fruit': 'apple', 'vegetable': 'parsnip'},
              {'fruit': 'banana', 'vegetable': 'carrot'},
              {'fruit': 'banana', 'vegetable': 'potato'}]
    template = env.get_template('test.j2')
    output = template.render(values=values)

   

# Generated at 2022-06-21 04:31:34.548639
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', '1469758400') == '2016-07-26'  # epochseconds=1469758400, Monday
    assert strftime('%Y-%m-%d', 1469758400) == '2016-07-26'



# Generated at 2022-06-21 04:31:55.026911
# Unit test for function path_join
def test_path_join():
    assert path_join("/a/b/c") == os.path.join("/a/b/c")
    assert path_join(["/a/b/c", "d"]) == os.path.join("/a/b/c", "d")
    assert path_join(["/a", "b", "c"]) == os.path.join("/a", "b", "c")
    try:
        path_join([1,2,3])
    except AnsibleFilterTypeError as err:
        assert "|path_join expects string or sequence, got int" in to_text(err)



# Generated at 2022-06-21 04:32:08.083485
# Unit test for function regex_findall
def test_regex_findall():
    testseq = ["b123", "b456"]
    teststr = "b123aaa\nb456bbb"
    assert [["123", "456"]] == regex_findall(teststr, "b(\\d+)", True)
    assert [["123"], ["456"]] == regex_findall(teststr, "b(\\d+)", False)
    assert [["123", "456"]] == regex_findall(teststr, "b(?:\\d+)", True)
    assert [["123"], ["456"]] == regex_findall(teststr, "b(?:\\d+)", False)
    assert [[]] == regex_findall("", "b\\d+", True)
    assert [[]] == regex_findall("", "b\\d+", False)

# Generated at 2022-06-21 04:32:17.603343
# Unit test for function to_datetime
def test_to_datetime():
    format = "%Y-%m-%d %H:%M:%S"
    timestamp = datetime.datetime.now().strftime(format)
    dt = to_datetime(timestamp, format)
    assert dt.__class__.__name__ == "datetime"
    assert dt.strftime(format) == timestamp
    try:
        assert to_datetime(timestamp, "") == None
    except Exception:
        assert sys.exc_info()[0].__name__ == "ValueError"



# Generated at 2022-06-21 04:32:23.164031
# Unit test for function combine
def test_combine():
    assert combine({1: 'a', 2: 'b'}, {2: 'c', 3: 'd'}) == {1: 'a', 2: 'c', 3: 'd'}



# Generated at 2022-06-21 04:32:33.579812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.unit import TestCase
    from ansible.utils.unit import mock
    from ansible.utils.unit import get_exception_callback
    from ansible import errors

    class TestFilterModule(TestCase):
        def setUp(self):
            self.m_module = mock.MagicMock()
            self.m_module.params = {}
            self.m_module.check_mode = False
            self.m_module.run_command.side_effect = errors.AnsibleError('test')
            self.m_module.fail_json.side_effect = get_exception_callback('fail_json')

        def _test_filter_module(self, method, *args, **kwargs):
            m = mock.MagicMock()
            m.return_value = None
            m.__name

# Generated at 2022-06-21 04:32:38.141782
# Unit test for function to_uuid
def test_to_uuid():
    uuid_original = uuid.uuid5(UUID_NAMESPACE_ANSIBLE, "TEST_UUID_STRING")
    uuid_new = to_uuid("TEST_UUID_STRING", "361E6D51-FAEC-444A-9079-341386DA8E2E")
    assert uuid_original == uuid_new



# Generated at 2022-06-21 04:32:50.057308
# Unit test for function to_json
def test_to_json():
    assert to_json(dict(a=1, b=2)) == '{"a": 1, "b": 2}', 'dict failed to serialize'
    assert to_json(list(range(4))) == '[0, 1, 2, 3]', 'list failed to serialize'
    assert to_json(None) == 'null', 'null failed to serialize'
    assert to_json(True) == 'true', 'true failed to serialize'
    assert to_json(False) == 'false', 'false failed to serialize'
    assert to_json(b'bytes') == '"bytes"', 'bytes failed to serialize'
    assert to_json(b'bytes') == '"bytes"', 'bytes failed to serialize'

# Generated at 2022-06-21 04:32:59.257200
# Unit test for function to_uuid
def test_to_uuid():
    # Test against an example from RFC 4122 Section 5.5
    test_string = 'http://docs.python-guide.org/en/latest/writing/structure/'
    test_namespace = '7e3a07d4-fa81-11e4-bd1e-001b210f55b5'

    result_string = to_uuid(test_string, test_namespace)
    expected_string = '7cc4dee5-e54a-5b5d-b5a5-ac134243c7e8'

    assert result_string == expected_string



# Generated at 2022-06-21 04:33:09.434772
# Unit test for function comment
def test_comment():
    a = "# foo\n# bar"
    b = comment("foo\nbar", style='plain')
    assert a == b
    a = "// foo\n// bar"
    b = comment("foo\nbar", style='c')
    assert a == b
    a = "/*\n * foo\n * bar\n */"
    b = comment("foo\nbar", style='cblock')
    assert a == b
    a = "<!--\n - foo\n - bar\n-->"
    b = comment("foo\nbar", style='xml')
    assert a == b
    a = "/*\n * foo\n * bar\n */"
    b = comment("foo\nbar", style='cblock', decoration=' * ')
    assert a == b

# Generated at 2022-06-21 04:33:21.837978
# Unit test for function comment
def test_comment():
    assert comment(
        'This is a text\nwhich should be\ncommented.',
        'plain') == '# This is a text\n# which should be\n# commented.'
    assert comment(
        'This is a text\nwhich should be\ncommented.',
        'erlang') == '% This is a text\n% which should be\n% commented.'
    assert comment(
        'This is a text\nwhich should be\ncommented.',
        'c') == '// This is a text\n// which should be\n// commented.'
    assert comment(
        'This is a text\nwhich should be\ncommented.',
        'cblock') == '/*\n * This is a text\n * which should be\n * commented.\n */'

# Generated at 2022-06-21 04:33:47.869240
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('hello') == 'hello'
    assert from_yaml('[1, 2, 3, 4]') == [1, 2, 3, 4]
    assert from_yaml('{foo: bar}') == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar", baz: true}') == {'foo': 'bar', 'baz': True}
    assert from_yaml('[foo, bar, baz, true]') == ['foo', 'bar', 'baz', True]
    assert from_yaml('[foo, [bar, baz], true]') == ['foo', ['bar', 'baz'], True]

# Generated at 2022-06-21 04:33:50.366378
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', second=1257894000.0) == '2009'



# Generated at 2022-06-21 04:34:05.297384
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) is None
    assert from_yaml('string') == 'string'
    assert from_yaml('{a: b}') == dict(a='b')
    assert from_yaml('10') == 10
    assert from_yaml('-10') == -10
    assert from_yaml('10.1') == 10.1
    assert from_yaml('-10.1') == -10.1
    assert from_yaml('true') is True
    assert from_yaml('false') is False
    assert from_yaml('# this is a comment\ntest') == 'test'
    assert from_yaml('\n- 1\n- 2\n') == [1, 2]

# Generated at 2022-06-21 04:34:16.502870
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("") == datetime.datetime(1, 1, 1, 0, 0)
    assert to_datetime("1970-01-01 00:00:00") == datetime.datetime(1970, 1, 1, 0, 0)
    assert to_datetime("1970-01-01 00:00:00", "%Y-%m-%d %H:%M:%S") == datetime.datetime(1970, 1, 1, 0, 0)
    assert to_datetime("1970-01-01 00:00:00", "%Y-%m-%d %H:%M:%S.4") == datetime.datetime(1970, 1, 1, 0, 0)

# Generated at 2022-06-21 04:34:23.481112
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool(1) is True
    assert to_bool('no') is False
    assert to_bool('false') is False
    assert to_bool('0') is False
    assert to_bool('off') is False
    assert to_bool(0) is False



# Generated at 2022-06-21 04:34:30.710710
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'qux'}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'foo': 'bar', 'baz': 'qux'}



# Generated at 2022-06-21 04:34:38.840774
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', second=0) == "1970-01-01"
    assert strftime('%Y-%m-%d %H:%M:%S', second=0) == "1970-01-01 00:00:00"
    assert strftime('%s %s', second=0) == "0 0"



# Generated at 2022-06-21 04:34:45.884399
# Unit test for function get_encrypted_password

# Generated at 2022-06-21 04:34:46.879488
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello world') == 'aGVsbG8gd29ybGQ=\n'



# Generated at 2022-06-21 04:34:54.463712
# Unit test for function combine
def test_combine():
    import pytest
    class Undef:
        def __eq__(self, other):
            return isinstance(other, AnsibleUndefined)
        def __repr__(self):
            return '<undefined>'

    undef = Undef()
    # Test recursive
    assert combine(dict(a=dict(b=undef)), dict(a=dict(b="c"))) == dict(a=dict(b="c"))
    assert combine(dict(a=dict(b=dict(c=undef))), dict(a=dict(b=dict(c="c")))) == dict(a=dict(b=dict(c="c")))
    # Test list_merge
    assert combine(dict(a=[1]), dict(a=[2])) == dict(a=[2])

# Generated at 2022-06-21 04:35:13.826366
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d') == time.strftime('%Y-%m-%d')
    assert strftime('%s') == time.strftime('%s')
    assert strftime('%s', 1234) == time.strftime('%s', time.localtime(1234))
    assert strftime('%Y-%m-%d %H:%M') == time.strftime('%Y-%m-%d %H:%M')
    assert strftime('%Y-%m-%d %H:%M', 1234) == time.strftime('%Y-%m-%d %H:%M', time.localtime(1234))



# Generated at 2022-06-21 04:35:24.887152
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    import os
    import crypt
    import unittest

    class GetEncryptedPasswordTest(unittest.TestCase):
        def test_md5_crypt(self):
            # Test the default behaviour
            encrypted_password = get_encrypted_password('thisisasecret')
            self.assertEqual(encrypted_password, crypt.crypt('thisisasecret', encrypted_password))
            encrypted_password = get_encrypted_password('thisisasecret', hashtype='md5')
            self.assertEqual(encrypted_password, crypt.crypt('thisisasecret', encrypted_password))
            # Test the generated salt
            password = 'thisisasecret'
            salt = "$1$TMPsalt$"
            encrypted_password = get_encrypted_password(password, salt=salt)
            expected = crypt.crypt

# Generated at 2022-06-21 04:35:32.289990
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("abc") == 'YWJj'
    assert b64encode("abc", encoding='utf-16') == 'NK1QAA=='
    assert b64encode("Ã‚Â£") == 'wqY='



# Generated at 2022-06-21 04:35:44.676465
# Unit test for function flatten
def test_flatten():
    assert([1, 2, 3, 4, 5, 6] == flatten([1, 2, 3, [4, 5, [6]]]))
    assert([1, 2, 3, 4, 5, 6] == flatten([1, 2, 3, [4, 5, [6]], [1, 2, 3, [4, 5, [6]]]]))
    assert([1, 2, 3, 6, 7, 8] == flatten([1, 2, 3, 6, 7, 8]))
    assert([1, 2, 3, 4, 5, 6] == flatten([1, 2, 3, [4, 5, [6]], [1, 2, 3, [4, 5, [6]]]], levels=1))

# Generated at 2022-06-21 04:35:59.732977
# Unit test for function to_json
def test_to_json():
    assert to_json({}) == "{}"
    assert to_json({'a': 'b', 'c': {'d': 'e'}}) == '{"a": "b", "c": {"d": "e"}}'
    # list of dicts
    assert to_json([{'a': 'b'}]) == '[{"a": "b"}]'
    # list of dicts and lists
    assert to_json([{'a': 'b'}, {'a': 'c'}, [{'a': 'd'}, {'a': 'e'}]]) == '[{"a": "b"}, {"a": "c"}, [{"a": "d"}, {"a": "e"}]]'
    # dict of dicts

# Generated at 2022-06-21 04:36:08.193249
# Unit test for function flatten
def test_flatten():

    assert flatten(["foo"]) == ["foo"]

    assert flatten(["foo", "bar"]) == ["foo", "bar"]

    assert flatten([["foo"]]) == ["foo"]

    assert flatten([["foo", "bar"]]) == ["foo", "bar"]

    assert flatten([["foo"], ["bar"]]) == ["foo", "bar"]

    assert flatten([["foo", "bar"]], levels=0) == [["foo", "bar"]]

    assert flatten([["foo"], ["bar"]], levels=0) == [["foo"], ["bar"]]

    assert flatten([["foo"], ["bar"]], levels=1) == ["foo", "bar"]

    assert flatten(["foo", "bar"], levels=1) == ["foo", "bar"]


# Generated at 2022-06-21 04:36:17.817816
# Unit test for function regex_escape
def test_regex_escape():
    # Basic tests
    assert regex_escape(r'test 1') == 'test\\ 1'
    assert regex_escape('test 1.$^') == 'test\\ 1\\.\\$\\^'
    # Test \ escapes
    assert regex_escape(r'test \1') == 'test\\\\1'
    assert regex_escape(r'test \1 $*') == 'test\\\\1\\ \\$\\*'
    # NOTE: the next two tests are weird, but are the actual results from the
    # actual code.  Because re.escape adds an extra \ to any string it escapes,
    # this means that if a string has no special characters, it's escaped to
    # empty string.  I'm choosing to let this weirdness stand, and as best I
    # can tell it has no negative effect.

# Generated at 2022-06-21 04:36:23.805462
# Unit test for function regex_escape
def test_regex_escape():
    assert 'foo\\\\bar' == regex_escape('foo\\bar')
    assert 'foo\.' == regex_escape('foo.', 'posix_basic')
    assert 'foo\\.' == regex_escape('foo.', 'posix_basic')
    assert 'foo\\\\.' == regex_escape('foo\\.', 'posix_basic')



# Generated at 2022-06-21 04:36:34.106429
# Unit test for function randomize_list
def test_randomize_list():
    """ Test function to test randomize_list
    :return:
    """
    my_list = ['one','two','three','four','five','six','seven','eight','nine','ten']
    # Randomize my_list with a seed, should return the same list
    list_one = randomize_list(my_list, seed=0)
    list_two = randomize_list(my_list, seed=0)
    assert list_one == list_two
    list_three = randomize_list(my_list, seed=1)
    # Randomize list without seed should return new randomized list
    assert list_one != list_three


# Generated at 2022-06-21 04:36:46.363296
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('foo', hashtype='md5') == '$1$rOc7VofZ$qQPzdJZgLYc1JJV00NpO1'
    assert get_encrypted_password('foo', hashtype='blowfish') == '$2b$12$O8d0b1eV7XuG9Q2V7zLmqu5CDo7xuWMm5wV7yjYWyNZvF1ZXp9JcK'
    assert get_encrypted_password('foo', hashtype='sha256') == '$5$bvhSX9Gl$TfCZzWjRcRNx6U4wLFgYW8jvAHhBX9HK1b0fMjz8mv7'
    assert get_encrypted

# Generated at 2022-06-21 04:37:04.412814
# Unit test for function rand
def test_rand():
    assert rand([1, 2, 3], seed='abc') == 2
    assert 0 <= rand(5, seed='abc') <= 4
    assert rand([1, 2, 3], 0, seed='abc') == 2
    assert rand([1, 2, 3], 0, 4, seed='abc') in [1, 3]
    assert rand(10, 14, 2, seed='abc') in [10, 12, 14]



# Generated at 2022-06-21 04:37:08.293728
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'alice', 'value': '1'}, {'key': 'bob', 'value': '2'}]
    expected_dict = {'alice': '1', 'bob': '2'}
    assert list_of_dict_key_value_elements_to_dict(mylist) == expected_dict



# Generated at 2022-06-21 04:37:14.112448
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    assert callable(FilterModule().filters)

# unit tests
if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-21 04:37:26.593451
# Unit test for function b64encode
def test_b64encode():
    # Testing b64encode
    string = b'Hello ansible'
    assert b64encode(string) == 'SGVsbG8gYW5zaWJsZQ=='
    assert b64encode(string, encoding='ascii') == 'SGVsbG8gYW5zaWJsZQ=='

    assert b64encode(string, encoding='utf-32') == 'AAAAD3d0bG9hZGFqYXNpbGJl'
    assert b64encode(string, encoding='utf-16') == 'SGVsbG8gYW5zaWJsZQ=='
    assert b64encode(string, encoding='utf-8') == 'SGVsbG8gYW5zaWJsZQ=='

# Generated at 2022-06-21 04:37:33.461335
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', '0') == '1970-01-01'
    assert strftime('%Y-%m-%d', 0.0) == '1970-01-01'
    assert strftime('%Y-%m-%d', 0) == '1970-01-01'



# Generated at 2022-06-21 04:37:45.115918
# Unit test for function rand
def test_rand():
    from ansible.release import __version__
    assert sys.version_info >= (2, 6) or __version__ > '2.3'
    end = 20
    seed = 42
    r = RandFilterModule(seed)
    assert r.rand(end) == 18
    r = RandFilterModule(seed)
    assert r.rand(end, seed=seed) == 18
    r = RandFilterModule(seed)
    assert r.rand(end, start=10) == 12
    r = RandFilterModule(seed)
    assert r.rand(end, start=10, seed=seed) == 12
    r = RandFilterModule(seed)
    assert r.rand(end, start=10, step=2) == 14
    r = RandFilterModule(seed)

# Generated at 2022-06-21 04:37:56.423279
# Unit test for function path_join
def test_path_join():
    return (
        ('/path/to/file', path_join('/path/to/', '/file'),),
        ('/path/to/file', path_join(['/path/to/', '/file']),),
        ('/', path_join('/path/to/', '/file', '/'),),
        ('/', path_join(['/path/to/', '/file', '/']),),
        ('/', path_join('', '', '/'),),
        ('/', path_join(['', '', '/']),),
    )



# Generated at 2022-06-21 04:38:05.821473
# Unit test for function subelements
def test_subelements():
    obj = [{
        'name': 'alice',
        'groups': ['wheel'],
        'authorized': ['/tmp/alice/onekey.pub'],
        'shell': '/bin/zsh',
        'uid': 500,
        'full_name': 'Alice Appleworth'
    }]
    result = subelements(obj, 'groups')
    assert result == [
        ({
            'name': 'alice',
            'groups': ['wheel'],
            'authorized': ['/tmp/alice/onekey.pub'],
            'shell': '/bin/zsh',
            'uid': 500,
            'full_name': 'Alice Appleworth'
        }, 'wheel')
    ]

# Generated at 2022-06-21 04:38:16.455256
# Unit test for function comment

# Generated at 2022-06-21 04:38:17.899020
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('*') == []
    assert fileglob('*/ansible/modules/*') == []



# Generated at 2022-06-21 04:38:42.595410
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    inp = {"foo": ["one","two"], "bar": {"baz": "three", "bat": [1,2,3]}}
    out = "foo:\n"
    out += "    - one\n"
    out += "    - two\n"
    out += "bar:\n"
    out += "    baz: three\n"
    out += "    bat:\n"
    out += "        - 1\n"
    out += "        - 2\n"
    out += "        - 3\n"
    assert to_nice_yaml(inp)==out



# Generated at 2022-06-21 04:38:46.728194
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2012-12-12 12:12:12") == datetime.datetime(2012, 12, 12, 12, 12, 12)



# Generated at 2022-06-21 04:38:56.031664
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(None) == None
    assert from_yaml('{foo: 42}') == {u'foo': 42}
    assert from_yaml('{foo: 42}') == {u'foo': 42}
    assert from_yaml('hello: "world"') == {u'hello': u'world'}
    assert from_yaml(yaml_load('{foo: 42}')) == {u'foo': 42}
    assert from_yaml('test: [foo, bar, {baz: 42}]') == {'test': [u'foo', u'bar', {u'baz': 42}]}

# Generated at 2022-06-21 04:39:06.126084
# Unit test for function to_nice_json
def test_to_nice_json():
    # Test empty JSON (Empty Dict)
    assert to_nice_json({}) == '{}'
    # Test single key:value pair
    assert to_nice_json({'first': 'Adam'}) == '{\n    "first": "Adam"\n}'
    # Test two key:value pairs
    assert to_nice_json({'first': 'Adam', 'last': 'West'}) == '{\n    "first": "Adam",\n    "last": "West"\n}'
    # Test single key:dict pair

# Generated at 2022-06-21 04:39:13.884188
# Unit test for function extract
def test_extract():
    assert extract('a','item', {'item': 'a'}) == 'a'
    assert extract('a','item', {'item': {'otheritem': 'a'}}) == {'otheritem': 'a'}
    assert extract('a','item', {'item': {'otheritem': 'a'}}, 'otheritem') == 'a'
    assert extract('a','item', {'item': {'otheritem': 'a'}}, 'otheritem', 'more_otheritem') == 'a'
    assert extract(extract('a','item', {'item': {'otheritem': 'a'}}, 'otheritem', 'more_otheritem'), 'more_otheritem', {'item': {'otheritem': 'a'}}, ['item', 'otheritem', 'more_otheritem']) == 'a'
    assert extract

# Generated at 2022-06-21 04:39:25.522628
# Unit test for function comment
def test_comment():
    import pytest
    from ansible.plugins.filter.core import comment

    # Test the default case where we just pass the text
    # and expect the output to be
    # # <text>
    def test_default():
        assert comment('This is a default test') == '# This is a default test'
    test_default()

    # Test that we can pass multiple lines of text
    # and expect to preserve the newlines
    def test_newline():
        assert comment(
            'This is a test\nwith multiple lines') == '# This is a test\n# with multiple lines'
    test_newline()

    # Test that we can pass a different newline
    # and expect to preserve the newlines

# Generated at 2022-06-21 04:39:37.676767
# Unit test for function regex_findall
def test_regex_findall():
    # test 1: simple string
    assert regex_findall('Hello World!','Hello') == ['Hello']

    # test 2: simple string, list
    assert regex_findall('Hello World, hello!','hello', ignorecase=True) == ['hello', 'hello']

    # test 3: unicode
    assert regex_findall(u'\N{SNOWMAN}World!', u'\N{SNOWMAN}') == [u'\N{SNOWMAN}']

    # test 4: empty lines
    assert regex_findall('Hello\n\nWorld!','^$', multiline=True) == ['', '']



# Generated at 2022-06-21 04:39:41.476013
# Unit test for function to_json
def test_to_json():
    assert to_json({'foo': 'bar'}) == '{"foo": "bar"}'
    assert to_json({'foo': 'bar'}, indent="4") == "{\n    \"foo\": \"bar\"\n}"



# Generated at 2022-06-21 04:39:43.602245
# Unit test for function combine
def test_combine():
    # TODO: implement
    pass



# Generated at 2022-06-21 04:39:55.735570
# Unit test for function to_uuid
def test_to_uuid():
    """ Test function to_uuid """
    uuid_hex = "361e6d51-faec-444a-9079-341386da8e2e"
    uuid_str = "361E6D51-FAEC-444A-9079-341386DA8E2E"

    uuid_result = to_uuid('Fail string')
    assert uuid_result != uuid.UUID(uuid_hex)
    uuid_result = to_uuid(uuid_hex)
    assert uuid_result != uuid.UUID(uuid_hex)
    uuid_result = to_uuid(uuid_str)
    assert uuid_result != uuid.UUID(uuid_hex)
