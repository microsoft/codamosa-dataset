

# Generated at 2022-06-23 10:05:27.208557
# Unit test for function rand
def test_rand():
    rand_return = rand(None, 10, 2, 2)
    assert rand_return in [2, 4, 6, 8, 10]


# Generated at 2022-06-23 10:05:30.609118
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    filtered_value = to_nice_yaml(a={1:2, 3:4})
    assert filtered_value == "---\n" + to_text("""{
    1: 2,
    3: 4
}""")


# Generated at 2022-06-23 10:05:40.089208
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory("foo") == "foo"

    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'None' not defined."

    try:
        mandatory(Undefined("bar"))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'bar' not defined."

    try:
        mandatory(Undefined(), "Invalid value: foo")
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Invalid value: foo"
# -- END: Unit test for function mandatory



# Generated at 2022-06-23 10:05:49.525275
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert get_hash('abcdef') != 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert get_hash('abc', 'sha256') == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'


# Generated at 2022-06-23 10:05:53.568993
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", 1318742399) == "2011-10-14 17:59:59"
    assert strftime("%Y-%m-%d %H:%M:%S")
# --



# Generated at 2022-06-23 10:05:56.936191
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2012-03-29 14:57:48") == datetime.datetime(2012, 3, 29, 14, 57, 48)



# Generated at 2022-06-23 10:06:00.808356
# Unit test for function regex_replace
def test_regex_replace():
    '''basic tests'''

    assert regex_replace(u'abcdefg', u'efg', u'xyz') == u'abcdxyz'
    assert regex_replace(u'abcdefg', u'(efg)', u'xyz\\1') == u'abcdxyzefg'



# Generated at 2022-06-23 10:06:04.546122
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('TRUE') is True
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('n') is False
    assert to_bool('false') is False
    assert to_bool(None) is None
    assert to_bool('{foo}') is False



# Generated at 2022-06-23 10:06:09.805950
# Unit test for function fileglob
def test_fileglob():
    pathname = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'integration', 'filter_plugins', 'testdata', 'fileglob', 'sample.*')
    assert fileglob(pathname) == [os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'integration', 'filter_plugins', 'testdata', 'fileglob', 'sample.txt')]



# Generated at 2022-06-23 10:06:15.477477
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'one', 'two') == 'one'
    assert ternary(1, 'one', 'two') == 'one'
    assert ternary('', 'one', 'two') == 'one'
    assert ternary(False, 'one', 'two') == 'two'
    assert ternary(0, 'one', 'two') == 'two'
    assert ternary(None, 'one', 'two') == 'two'
    assert ternary(None, 'one', 'two', 'three') == 'three'



# Generated at 2022-06-23 10:06:30.365224
# Unit test for function combine
def test_combine():
    assert combine({'foo': 'bar'}, {}) == {'foo': 'bar'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}) == {'foo': 'baz'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}, recursive=True) == {'foo': 'baz'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}, list_merge='sort') == {'foo': 'baz'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}, list_merge='unique') == {'foo': 'baz'}

# Generated at 2022-06-23 10:06:33.019009
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
# Note: the following line causes the test to fail
#    assert mandatory(None) != None



# Generated at 2022-06-23 10:06:41.437338
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('True') is True
    assert to_bool('true') is True
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool(1) is True
    assert to_bool('False') is False
    assert to_bool('false') is False
    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool(0) is False



# Generated at 2022-06-23 10:06:44.641000
# Unit test for function to_nice_json
def test_to_nice_json():
    result = to_nice_json({'a': 1, 'b': 2, 'c': 3})
    assert result == """{
    "a": 1,
    "b": 2,
    "c": 3
}"""


# Generated at 2022-06-23 10:06:48.712948
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('something') == 'something'
    assert regex_escape('something.else$') == 'something\\.else\\$'
    assert regex_escape('something.else$', re_type='posix_basic') == 'something\\.else\\$'
    assert regex_escape('something.else$', re_type='python') == 'something\\.else\\$'



# Generated at 2022-06-23 10:06:59.750273
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password='foobar'
    hashtype='blowfish'
    salt_size=8
    rounds=5000
    ident='2b'

    def salt_randstr(size=16, chars=os.urandom(8)):
        ''' return a random salt string '''
        return ''.join(chars[ord(c) % len(chars)] for c in os.urandom(size))


    salt = salt_randstr(salt_size)
    salt_size = None
    try:
        pwcrypt = get_encrypted_password(password, hashtype, salt, salt_size, rounds, ident)
        assert pwcrypt is not None
        assert len(pwcrypt) > 0
        print(pwcrypt)
    except AnsibleError as e:
        raise Exception(to_native(e))

# Generated at 2022-06-23 10:07:04.994680
# Unit test for function comment
def test_comment():
    assert comment("""Some text.
This is a multiline string.""") == """# Some text.
# This is a multiline string."""
    assert comment("""Some text.
This is a multiline string.""", decoration='  ') == """  Some text.
  This is a multiline string."""
    assert comment("""Some text.
This is a multiline string.""", decoration='  ', prefix_count=0) == """Some text.
  This is a multiline string."""
    assert comment("""Some text.
This is a multiline string.""", prefix="", prefix_count=0) == """Some text.
This is a multiline string."""

# Generated at 2022-06-23 10:07:13.672618
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    # Check if function raises an error when value is undefined
    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError as afe:
        assert to_text(afe) == 'Mandatory variable not defined.'

    # Check if function raises an error when the name of value is defined
    try:
        mandatory(Undefined(name='my_var'))
        assert False
    except AnsibleFilterError as afe:
        assert to_text(afe) == to_text("Mandatory variable 'my_var' not defined.")

    # Check if function raises an error with a custom error message
    try:
        mandatory(Undefined(), msg='A custom error')
        assert False
    except AnsibleFilterError as afe:
        assert to_text(afe) == to_

# Generated at 2022-06-23 10:07:17.018865
# Unit test for function to_json
def test_to_json():
    assert json.loads(to_json(1)) == 1
    assert json.loads(to_json('a')) == 'a'
    assert json.loads(to_json(['a', 'b'])) == ['a', 'b']


# Generated at 2022-06-23 10:07:31.746180
# Unit test for function rand
def test_rand():
    assert rand([1, 2, 3]) in [1, 2, 3]
    assert rand(10) in range(10)
    assert rand(1, 10) in range(1, 10)
    assert rand(0, 10, 2) in [0, 2, 4, 6, 8]
    assert rand(0, 10, 2) in [0, 2, 4, 6, 8]
    assert rand(-10, -1, 2) in [-10, -8, -6, -4, -2]
    assert rand(-10, -1, -2) in [-10, -8, -6, -4, -2]
    assert rand(-10, -1, 2, seed=0) in [-10, -8, -6, -4, -2]

# Generated at 2022-06-23 10:07:39.309047
# Unit test for function regex_search
def test_regex_search():
    regex_p = r'cat'
    regex_i = r'cAt'
    regex_m = r'caT'
    regex_im = r'Cat'

    test_cat = 'cat'
    test_cat_i = 'cAt'
    test_cat_m = 'caT'
    test_cat_im = 'Cat'

    assert regex_search(test_cat, regex_p) == test_cat
    assert regex_search(test_cat, regex_p, ignorecase=True) == test_cat
    assert regex_search(test_cat_i, regex_p, ignorecase=True) == test_cat_i
    assert regex_search(test_cat, regex_p, multiline=True) == test_cat

# Generated at 2022-06-23 10:07:45.562108
# Unit test for function regex_search
def test_regex_search():
    res = regex_search('hello world', 'hello')
    assert res == 'hello'
    res = regex_search('hello world', 'hello\\s+\\w+')
    assert res == 'hello world'
    res = regex_search('hello world', 'goodbye')
    assert res is None
    res = regex_search('hello world', 'hello', '\\g<0>')
    assert res == ['hello']
    res = regex_search('hello world', 'hello\\s+(\\w+)', '\\g<0>', '\\g<1>')
    assert res == ['hello world', 'world']
    res = regex_search('hello world', 'hello\\s+(\\w+)', '\\g<0>', '\\1')
    assert res == ['hello world', 'world']



# Generated at 2022-06-23 10:07:58.058971
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('asdf', hashtype='md5') == '$1$DCODELAS$NpVnzPyMQoT6zpJ6MtaUf0'
    assert get_encrypted_password('asdf', hashtype='sha256') == '$5$rounds=50000$DCODELAS$3ar.LpV7oZHl0jV7gZlgg0e9XB5c5BpDtjS0ht.YuP0'

# Generated at 2022-06-23 10:08:00.504161
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'b': 'b_val', 'a': 'a_val'}
    assert dict_to_list_of_dict_key_value_elements(mydict, key_name='key_name', value_name='value_name') == \
        [{'key_name': 'b', 'value_name': 'b_val'}, {'key_name': 'a', 'value_name': 'a_val'}]



# Generated at 2022-06-23 10:08:05.037086
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool('1') == True
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool('0') == False



# Generated at 2022-06-23 10:08:13.810711
# Unit test for function regex_search
def test_regex_search():
    ''' Unit test for function regex_search '''

    # Test with no backref
    result = regex_search('abcdef', r'cd')
    assert result, 'Regex search did not match'

    # Test with backref
    result = regex_search('abcdef', r'cd', '\\1')
    assert result == ['e'], 'Regex search did not match'

    # Test with backref group
    result = regex_search('abcdef', r'd(.)f', '\\g<1>')
    assert result == ['e'], 'Regex search did not match'

    # Test with backref and backref group
    result = regex_search('abcdef', r'd(.)f', '\\1', '\\g<1>')
    assert result == ['e', 'e'], 'Regex search did not match'

# Generated at 2022-06-23 10:08:18.474943
# Unit test for function from_yaml_all
def test_from_yaml_all():
    import yaml
    data = '''
- one
- two
- three
'''
    result = from_yaml_all(data)
    assert result == yaml_load_all(to_text(data))



# Generated at 2022-06-23 10:08:30.227666
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('password123', 'md5') == '$1$qwertyui$GmQQ0h5iSj5wd5l5m6YOl.'
    assert get_encrypted_password('password123', 'blowfish') == '$2b$12$VpEgYFkVWV7bzDG/uV/WquzPxoHfIiuQ1QG9sWlTUXIDeT1TtLwZO'
    assert get_encrypted_password('password123', 'sha256') == '$5$rounds=535000$abcdefghijklmnop$G0loiOpgrojQ2O.yX9sTtM0j/zCZGTB/ZtT8KDlzf0B'
    assert get_encrypted

# Generated at 2022-06-23 10:08:39.907554
# Unit test for function to_bool

# Generated at 2022-06-23 10:08:46.027735
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo+') == r'foo\+'
    assert regex_escape(r'foo+', re_type='posix_basic') == r'foo\+'
    assert regex_escape(r'foo+', re_type='posix_extended') == r'foo\+(?!\()'



# Generated at 2022-06-23 10:08:50.894122
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', 1516896372.3052883) == '2018-01-23 08:19:32'



# Generated at 2022-06-23 10:08:55.590448
# Unit test for function b64encode
def test_b64encode():
    teststr = "test"
    teststr_b64encoded = "dGVzdA=="
    assert b64encode(teststr) == teststr_b64encoded



# Generated at 2022-06-23 10:09:03.226150
# Unit test for function extract
def test_extract():
    from jinja2 import Environment
    env = Environment()

    tests = [
        (
            {'a': {'b': 'hello'}, 'c': 'world'},
            'a.b',
            'hello'
        ),
        (
            {'a': {'b': 'hello'}, 'c': 'world'},
            'a',
            {'b': 'hello'}
        ),
        (
            {'a': {'b': 'hello'}, 'c': 'world'},
            'c',
            'world'
        )
    ]

    for data, item, result in tests:
        assert extract(env, item, data) == result, 'Extraction failed for %s' % item



# Generated at 2022-06-23 10:09:17.524166
# Unit test for function combine
def test_combine():
    assert combine(dict(a=1, b=2, c=1)) == {'a': 1, 'b': 2, 'c': 1}
    assert combine(dict(a=1, b=2, c=1), dict(a=2, d=3)) == {'a': 2, 'b': 2, 'c': 1, 'd': 3}
    assert combine(dict(a=1, b=2, c=1), dict(a=2, d=3), dict(e=4, c=2)) == {'a': 2, 'b': 2, 'e': 4, 'c': 2, 'd': 3}

# Generated at 2022-06-23 10:09:29.694036
# Unit test for function path_join
def test_path_join():
    import unittest
    import sys

    class TestPathJoin(unittest.TestCase):

        def setUp(self):
            pass

        def test_path_join(self):
            self.assertTrue(
                path_join('/tmp') == '/tmp'
            )
            self.assertTrue(
                path_join('/tmp', '/abc') == '/tmp/abc'
            )
            self.assertTrue(
                path_join('/tmp', '/abc', '/def/ghi') == '/tmp/abc/def/ghi'
            )

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-23 10:09:36.189566
# Unit test for function subelements
def test_subelements():
    """
    Unit test for function subelements
    """
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]



# Generated at 2022-06-23 10:09:46.768841
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid("ansible") == "0bd0a7b9-9e17-5257-a024-be6de1c6b31c"
    assert to_uuid("ansible", namespace="this-must-be-an-uuid") == "ba40efd7-d6dd-57a7-9c9b-28f00b6e38d6"
    assert to_uuid("ansible", namespace=UUID_NAMESPACE_ANSIBLE) == "0bd0a7b9-9e17-5257-a024-be6de1c6b31c"



# Generated at 2022-06-23 10:09:50.689253
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{"test": "this is a test value"}') == {'test': 'this is a test value'}
# end unit test



# Generated at 2022-06-23 10:09:58.286093
# Unit test for function regex_findall
def test_regex_findall():
    list = regex_findall('', 'x')
    assert len(list) == 0
    list = regex_findall('abcdefabcdefabcdef', 'a', False, False)
    assert len(list) == 3
    assert list[0] == 'a'
    list = regex_findall('abcdefabcdefabcdef', 'a', False, True)
    assert len(list) == 3
    assert list[0] == 'a'
    list = regex_findall('abcdefabcdefabcdef', 'a', True, False)
    assert len(list) == 3
    assert list[0] == 'a'
    list = regex_findall('abcdefabcdefabcdef', 'a', True, True)
    assert len(list) == 3
    assert list[0] == 'a'



# Generated at 2022-06-23 10:10:01.469200
# Unit test for function extract
def test_extract():
    ''' extract unit test '''
    env = None
    key = 'c'
    morekeys = ['b']
    data = {'a': {'b': {'c': 'd'}}}
    assert extract(key, data, env, morekeys) == 'd'



# Generated at 2022-06-23 10:10:05.404845
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'hello/world', 'python') == 'hello\\/world'
    assert regex_escape(r'hello/world', 'posix_basic') == 'hello\/world'
    assert regex_escape(r'hello/world', 'posix_extended') == 'hello\/world'


# Generated at 2022-06-23 10:10:11.963900
# Unit test for function to_yaml
def test_to_yaml():
    ''' to_yaml unit tests '''
    print("to_yaml(dict(a=1, b='string')) =>", to_yaml(dict(a=1, b='string')))
    print("to_yaml([1,2,3]) =>", to_yaml([1,2,3]))
    print("to_yaml({u'a': u'b'}) =>", to_yaml({u'a': u'b'}))
    print("to_yaml('some string') =>", to_yaml('some string'))


# --- DATE FILTERS -----------------------------------------------------------


# Generated at 2022-06-23 10:10:21.909253
# Unit test for function ternary

# Generated at 2022-06-23 10:10:27.425544
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['md5']('dummy') == '6a1e6379c3cb421791eaa73d7b23ee26'

# Generated at 2022-06-23 10:10:38.385204
# Unit test for function regex_escape
def test_regex_escape():
    import re
    # list of special characters:
    # https://www.rexegg.com/regex-quickstart.html
    special_chars = r'\\$()[]{}?*+|^-.!'
    # list of BRE special chars:
    # https://en.wikibooks.org/wiki/Regular_Expressions/POSIX_Basic_Regular_Expressions
    bre_special_chars = r'\[]^$.|?*+()'

    for i in [special_chars, bre_special_chars]:
        escaped = regex_escape(i)
        assert re.match(r'\\' + escaped, i)

    escaped = regex_escape(special_chars, re_type='posix_basic')
    assert re.match(r'\\' + escaped, special_chars)



# Generated at 2022-06-23 10:10:40.665828
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:10:45.931633
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('') is None
    assert from_yaml('[]') == []
    assert from_yaml('{}') == {}
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('- baz') == ['baz']
    assert from_yaml('- 1') == ['1']



# Generated at 2022-06-23 10:10:48.742908
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == to_text('{}\n...\n')



# Generated at 2022-06-23 10:10:57.543766
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  fm = FilterModule()
  filters = fm.filters()

  # Test the '/' generates the same result with or without jinja2.
  # For these tests we use a list to match the jinja2 output that is a string
  # or a list in some case
  assert ['/etc/foo'] == filters['path_join']('/etc', 'foo')
  assert ['/etc/foo'] == filters['path_join'](['/etc', 'foo'])

  # Test ternary with default value
  assert 'bar' == filters['ternary']('foo')
  assert 'foo' == filters['ternary']('foo', 'foo')

  # Test standard ternary using None as false
  assert 'foo' == filters['ternary'](True, 'foo')

# Generated at 2022-06-23 10:11:01.301983
# Unit test for function get_hash
def test_get_hash():
    data = 'foobar'
    val = get_hash(data)
    assert val == '8843d7f92416211de9ebb963ff4ce28125932878'


# Generated at 2022-06-23 10:11:13.762643
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}]) == {'a': 1}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}
    try:
        list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b'}])
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:11:20.988252
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    list_of_dict = [
        {'key': 'red', 'value': '#FF0000'},
        {'key': 'green', 'value': '#00FF00'},
        {'key': 'blue', 'value': '#0000FF'}
        ]
    ret = list_of_dict_key_value_elements_to_dict(list_of_dict)
    assert ret == {'red': '#FF0000', 'green': '#00FF00', 'blue': '#0000FF'}



# Generated at 2022-06-23 10:11:22.662448
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None, msg='Custom error message')



# Generated at 2022-06-23 10:11:35.490307
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment, DictLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    env = Environment(loader=DictLoader({}))
    env.filters.update(jinja2_filters)
    templar = Templar(loader=env.loader, variables=HostVars(dict(), 'dummy'))

    input_data = [
        {'foo': 'x', 'bar': '1'},
        {'foo': 'y', 'bar': '2'},
        {'foo': 'x', 'bar': '3'},
        {'foo': 'y', 'bar': '4'},
    ]

    # This is what we'd get in the version that has the bug

# Generated at 2022-06-23 10:11:47.580985
# Unit test for function from_yaml_all
def test_from_yaml_all():
    yaml_str = '''
---
- foo:
  - bar: 1
  - bar: 2
- bar: 3
- foo:
  - bar: 4
'''
    assert list(from_yaml_all(yaml_str)) == [{'foo': [{'bar': 1}, {'bar': 2}]}, {'bar': 3}, {'foo': [{'bar': 4}]}]



# Generated at 2022-06-23 10:12:00.162250
# Unit test for function subelements
def test_subelements():
    from ansible import errors

# Generated at 2022-06-23 10:12:12.959167
# Unit test for function extract
def test_extract():
    from ansible.errors import AnsibleError, AnsibleFilterError
    from ansible import utils
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    basedir = os.path.dirname(__file__)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=Host('localhost'))
    variable_manager.set_inventory(inventory)

    # setup jinja2 env

# Generated at 2022-06-23 10:12:21.944819
# Unit test for function from_yaml_all
def test_from_yaml_all():
    import os
    import pytest
    from ansible.errors import AnsibleFilterError
    basedir=os.path.join(os.path.dirname(__file__), '..')
    filename=os.path.join(basedir, 'test', 'units', 'test_filter_plugins', 'files', 'from_yaml_all.yml')
    with open(filename, 'r') as fileobj:
        data = fileobj.read()

    assert isinstance(data, str)
    assert data != ""
    assert data[0] == '-'
    assert data[-1] == '-'

    assert isinstance(from_yaml_all(data), list)
    assert len(from_yaml_all(data)) == 2


# Generated at 2022-06-23 10:12:35.211385
# Unit test for function flatten
def test_flatten():
    assert flatten([[1],[2]]) == [1, 2]
    assert flatten([1,2], levels=2) == [1, 2]
    assert flatten([[1,2],[3,4]]) == [1, 2, 3, 4]
    assert flatten([1,[2,3],[4,[5,6]]]) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1,[2,3],[4,[5,6]]], levels=2) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1,[2,3],[4,[5,6]]]]) == [1, 2, 3, 4, [5, 6]]

# Generated at 2022-06-23 10:12:37.824744
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  fm = FilterModule()
  fm.filters()

# Generated at 2022-06-23 10:12:43.516899
# Unit test for function from_yaml
def test_from_yaml():
    bad_data = '{ foo: 1 }'
    assert from_yaml(bad_data) == '{ foo: 1 }', "bad_data did not pass through unchanged"

    good_data = '''
foo:
     bar: 1
     bam: 2
    '''
    assert from_yaml(good_data) == {'foo': {'bar': 1, 'bam': 2}}, "good_data was not parsed"

# Generated at 2022-06-23 10:12:45.175081
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 10:12:54.770421
# Unit test for function combine
def test_combine():
    assert combine(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
    assert combine(1, 2, 3) == [1, 2, 3]

    # no merge when not a dict
    assert combine(1, 2, 3, b=2) == [1, 2, 3]
    assert combine(1, b=2) == [1]

    assert combine(dict(a=1, b=2, c=3), dict(a=2, b=3, e=5), dict(a=3, c=6)) == dict(a=3, b=3, c=6, e=5)

# Generated at 2022-06-23 10:12:58.751909
# Unit test for function fileglob
def test_fileglob():
    result = fileglob('/etc/*/*')
    assert len(result) > 0
    assert isinstance(result, list)
    assert result[0][:5] == '/etc/'



# Generated at 2022-06-23 10:13:02.349862
# Unit test for function quote
def test_quote():
    assert quote(None) == ""
    assert quote(" foo ") == "' foo '"
    assert quote("'bar'") == "'\\'bar\\''"
    assert quote("foobar") == "'foobar'"



# Generated at 2022-06-23 10:13:15.744487
# Unit test for function to_nice_json
def test_to_nice_json():
    """Return a valid AnsibleVariable object"""
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
     
    from ansible.vars.hostvars import HostVars
    hvars = HostVars(host='hostname', variables={'hostvars':'hostvar'})
    hvars.vars = hvars
    hvars._hostname = hvars.host
    hvars.get_vars = lambda: hvars
    hvars.get_hostname = lambda: hvars.host
    #hvars.get_vars = lambda: hvars
    hvars._ds = hvars
    hvars.get_all

# Generated at 2022-06-23 10:13:23.585419
# Unit test for function path_join
def test_path_join():
    assert path_join('/home/') == '/home/'
    assert path_join([]) == ''
    assert path_join('/home/', '/usr/') == '/home/usr'
    assert path_join(['/home/', '/usr/']) == '/home/usr'
    assert path_join(('/home/', '/usr/')) == '/home/usr'
    assert path_join([u'/home/', u'/usr/']) == '/home/usr'
    assert path_join([b'/home/', b'/usr/']) == '/home/usr'
    assert path_join(b'/home/', b'/usr/') == '/home/usr'
    assert path_join(b'/home/', '/usr/') == '/home/usr'

# Generated at 2022-06-23 10:13:31.808425
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo bar baz', re_type='python') == 'foo\\ bar\\ baz'
    assert regex_escape(r'foo bar baz', re_type='posix_basic') == 'foo\\ bar\\ baz'
    try:
        regex_escape(r'foo bar baz', re_type='badtype')
        assert False, 'should raise AnsibleFilterError'
    except AnsibleFilterError:
        pass



# Generated at 2022-06-23 10:13:43.674189
# Unit test for function quote
def test_quote():
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"
    assert quote(u"foo bar") == u"'foo bar'"

# Generated at 2022-06-23 10:13:45.514949
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:13:49.651530
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=12) == [2, 5, 4, 3, 1]



# Generated at 2022-06-23 10:13:56.908723
# Unit test for function to_nice_json
def test_to_nice_json():
    a = {"a": {
        "b": [1, 2, 3, "foo", "bar", {"a":"b", "c":5}],
        },
        "c": "d",
        "e": 1,
    }
    assert to_nice_json(a) == '{\n    "a": {\n        "b": [\n            1,\n            2,\n            3,\n            "foo",\n            "bar",\n            {\n                "a": "b",\n                "c": 5\n            }\n        ]\n    },\n    "c": "d",\n    "e": 1\n}'



# Generated at 2022-06-23 10:14:08.146165
# Unit test for function rand
def test_rand():
    from ansible.template.safe_eval import safe_eval
    from ansible.errors import AnsibleFilterError
    f = lambda x,y=10: rand(x)
    assert safe_eval('10|random(0,100)', locals={'random':f}) in range(0,100)
    assert safe_eval('10|random(100)', locals={'random':f}) in range(0,100)
    assert safe_eval('10|random(0,100,10)', locals={'random':f}) in range(0,100,10)
    assert safe_eval('[1,2,3]|random', locals={'random':f}) in [1,2,3]

# Generated at 2022-06-23 10:14:11.100803
# Unit test for function extract
def test_extract():
    # Check list of keys
    env = DummyEnvironment()
    ret = extract(env, 'baz.bash', {'baz': {'bash': 'foo'}}, ['bar', 'bash'])
    assert ret == 'foo'
    # Check single key
    ret = extract(env, 'baz.bash', {'baz': {'bash': 'foo'}}, 'bar')
    assert ret == {'bash': 'foo'}



# Generated at 2022-06-23 10:14:22.532039
# Unit test for function ternary
def test_ternary():
    assert ternary("abc", "def", "ghi") == "def"
    assert ternary(None, "def", "ghi") == "ghi"
    assert ternary("abc", "def", "ghi", "jkl") == "def"
    assert ternary(None, "def", "ghi", "jkl") == "jkl"
    assert ternary(False, "def", "ghi") == "ghi"
    assert ternary(0, "def", "ghi") == "ghi"
    assert ternary(0, "def", "ghi", "jkl") == "ghi"
    assert ternary(1, "def", "ghi", "jkl") == "def"
    assert ternary({}, "def", "ghi", "jkl")

# Generated at 2022-06-23 10:14:28.785987
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'l{2}') == 'll'
    assert regex_search('hello', 'l{2}', 0) == 'll'
    assert regex_search('hello', 'l{2}', '\\g<0>') == ['ll']
    assert regex_search('hello', 'l{1}', '\\g<0>', '\\1') == ['l', 1]
    assert regex_search('hello', 'l{1}', '\\g<1>') == [1]
    assert regex_search('hello', 'l{2}', '\\2') is None
    assert regex_search('hello', 'l{2}', '\\g<2>') is None
    assert regex_search('hello', 'l{2}', '\\g<3>') is None

# Generated at 2022-06-23 10:14:41.126040
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(
        'a line\n',
        r'line',
        ignorecase=True,
        multiline=True
    ) == 'line'
    assert regex_search(
        'a line\n',
        r'line',
        '\\g<0>',
        ignorecase=True,
        multiline=True
    ) == ['line']
    assert regex_search(
        'a line\n',
        r'line',
        '\\g<0>',
        '\\2',
        ignorecase=True,
        multiline=True
    ) == ['line']   # Fallback \\2 exists

# Generated at 2022-06-23 10:14:53.266479
# Unit test for function to_datetime
def test_to_datetime():
    # Test if string is properly converted to datetime class,
    # and assert if string cannot be parsed.
    string = "2015-06-01 22:14:15"
    dt = to_datetime(string, format="%Y-%m-%d %H:%M:%S")
    assert dt.year == 2015, "Testing to_datetime: Test failed for year"
    assert dt.month == 6, "Testing to_datetime: Test failed for month"
    assert dt.day == 1, "Testing to_datetime: Test failed for day"
    assert dt.hour == 22, "Testing to_datetime: Test failed for hour"
    assert dt.minute == 14, "Testing to_datetime: Test failed for minute"

# Generated at 2022-06-23 10:15:00.434798
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'.+*?()^$\|') == (
        r'\.\+\*\?\(\)\^\$\\\|')
    assert regex_escape(r'.+*?()^$\|', re_type='posix_basic') == (
        r'\.\+\*\?\(\)\^\$\\\|')
    try:
        regex_escape(r'.+*?()^$\|', re_type='posix_extended')
    except AnsibleFilterError as e:
        assert str(e).startswith('Regex type ')



# Generated at 2022-06-23 10:15:06.990383
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2016-02-04 15:20:30") == datetime.datetime(2016, 2, 4, 15, 20, 30)
    assert to_datetime("2016/02/04 15:20:30", "%Y/%m/%d %H:%M:%S") == datetime.datetime(2016, 2, 4, 15, 20, 30)
    assert to_datetime("2016-02-04", "%Y-%m-%d") == datetime.datetime(2016, 2, 4)


# Generated at 2022-06-23 10:15:19.763495
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('abc') == 'YWJj'
    assert b64encode('abc', encoding='ascii') == 'YWJj'
    assert b64encode(to_bytes('abc')) == 'YWJj'
    assert b64encode(to_bytes('abc'), encoding='ascii') == 'YWJj'
    assert b64encode(u'\u00fc') == 'w6k='
    assert b64encode(u'\u00fc', encoding='latin-1') == 'w6k='
    assert b64encode(u'\u00fc'.encode('utf-16')) == 'AIA/'

# Generated at 2022-06-23 10:15:31.467020
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value="abc123xyz", pattern="123") == "abcxyz"
    assert regex_replace(value="123abcxyz", pattern="123") == "abcxyz"
    assert regex_replace(value="123abcxyz123", pattern="123") == "abcxyz"
    assert regex_replace(value="123abc123xyz123", pattern="123") == "abcxyz"
    assert regex_replace(value="123123", pattern="123") == ""
    assert regex_replace(value="abcabc", pattern="abc") == ""
    assert regex_replace(value="abcabc", pattern="abc", replacement="ABC") == "ABCABC"
    assert regex_replace(value="abcabc", pattern="abc", replacement="-") == "--"