

# Generated at 2022-06-23 10:05:31.094524
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key':'1', 'value':'a'}, {'key':'2', 'value':'b'}, {'key':'3', 'value':'c'}]) == {'1':'a', '2':'b', '3':'c'}



# Generated at 2022-06-23 10:05:35.246017
# Unit test for function b64decode
def test_b64decode():
    ''' test b64decode function '''
    expected1 = 'test'
    actual1 = b64decode(b64encode(expected1))
    assert actual1 == expected1

    expected2 = u'\u0109'
    actual2 = b64decode(b64encode(expected2), encoding='utf-16')
    assert actual2 == expected2



# Generated at 2022-06-23 10:05:38.879792
# Unit test for function quote
def test_quote():
    assert quote(None) == u""
    assert quote(u"foo") == u'"foo"'



# Generated at 2022-06-23 10:05:42.539343
# Unit test for function extract
def test_extract():

    testvar = {
        'x': {
            'y': {
                'z': ['a', 'b', 'c']
            }
        }
    }
    assert extract('z', testvar, morekeys=['x', 'y']) == ['a', 'b', 'c']



# Generated at 2022-06-23 10:05:45.803032
# Unit test for function path_join
def test_path_join():
    if path_join(('/', '/foo', '/bar')) != '/foo/bar':
        raise AssertionError('path_join fails to join path elements with /')
    if path_join('/foo/bar') != '/foo/bar':
        raise AssertionError('path_join fails to concatenate path elements')



# Generated at 2022-06-23 10:05:49.956876
# Unit test for function extract
def test_extract():
    assert extract('foo', {u'bar': {u'foo': u'foostring'}}) == 'foostring'
    assert extract('foo', {u'bar': {u'foo': u'foostring'}}, 'bar') == 'foostring'
    assert extract(4, {u'bar': [1, 2, 3, 4, 5]}) == 4
    assert extract(4, {u'bar': [1, 2, 3, 4, 5]}, 'bar') == 4
    assert extract(4, {u'bar': [1, 2, 3, 4, 5]}, 'bar', 'foo') == 4



# Generated at 2022-06-23 10:05:52.651040
# Unit test for function fileglob
def test_fileglob():
    path_list = fileglob("/tmp/")
    for p in path_list:
        assert os.path.isfile(p)



# Generated at 2022-06-23 10:05:57.163920
# Unit test for function extract
def test_extract():
    assert extract(1, "a", [{"a": 1}]) == 1
    assert extract(1, "a", [{"a": 1}], "b") is None
    assert extract(1, "a", [{"a": {"b": 1}}], "b") == 1
    assert extract(1, "a", [{"a": [1, 2]}]) == [1, 2]
    assert extract(1, "a", [{"a": [1, 2]}], "1") == 2
    assert extract("aaa", "a", [{"a": "aaa"}]) == "aaa"
    assert extract("aaa", "a", [{"a": "aaa"}], "b") is None
    assert extract("aaa", "a", [{"a": {"b": "aaa"}}], "b") == "aaa"

# Generated at 2022-06-23 10:06:00.718212
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    ''' Ensure proper conversion of list of dictionaries containing a 'key' and 'value' key to a dictionary'''
    in_data = {
        'in_data':
            [
                {'key': 'key_1', 'value': 'value_1'},
                {'key': 'key_2', 'value': 'value_2'}
            ]
    }
    out_data = {'key_1': 'value_1', 'key_2': 'value_2'}

    assert list_of_dict_key_value_elements_to_dict(in_data['in_data']) == out_data

# Generated at 2022-06-23 10:06:03.316960
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    # Create an instance of class FilterModule
    fm = FilterModule()
    # Create a fake ansible module
    class FakeModule: pass
    fake_module = FakeModule()
    # Call method filters of class FilterModule
    fm.filters()
    # Confirm that an exception wasn't raised
    assert True



# Generated at 2022-06-23 10:06:09.862754
# Unit test for function regex_replace
def test_regex_replace():
    assert 'aBcd' == regex_replace('aAbcd', 'A', 'B')
    assert 'xyz'  == regex_replace('abc123def', '[0-9]+', 'xyz')
    assert 'abcXYZdef' == regex_replace('abc123def', '[0-9]+', 'xyz', ignorecase=True)
    assert 'abcd' == regex_replace('abcd\nabcd', '\n', '')
    assert 'abcdabcd' == regex_replace('abcd\nabcd', '\n', '', multiline=True)



# Generated at 2022-06-23 10:06:12.115502
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", 10) == '1970-01-01 00:00:10'



# Generated at 2022-06-23 10:06:17.413965
# Unit test for function ternary
def test_ternary():
    assert ternary('a', 'A', 'Z') == 'A'
    assert ternary(1, 'A', 'Z') == 'A'
    assert ternary([], 'A', 'Z') == 'A'
    assert ternary(False, 'A', 'Z') == 'Z'
    assert ternary(0, 'A', 'Z') == 'Z'
    assert ternary('', 'A', 'Z') == 'Z'
    assert ternary(None, 'A', 'Z', 'N') == 'N'
    assert ternary(None, 'A', 'Z') == 'Z'



# Generated at 2022-06-23 10:06:18.317600
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 10:06:23.291739
# Unit test for function comment
def test_comment():
    # Default
    assert comment('Hello world!') == """# Hello world!\n"""
    # With a custom decorator
    assert comment(
        'Hello world!',
        decoration='=====') == '# =====\n# Hello world!\n# =====\n'
    # With a custom newline
    assert comment(
        'Hello world!',
        newline='<br/>') == """# Hello world!<br/>"""
    # With a custom beginning
    assert comment(
        'Hello world!',
        newline='<br/>',
        beginning='<!--') == """<!--<br/># Hello world!<br/>"""
    # With a custom end
    assert comment(
        'Hello world!',
        newline='<br/>',
        end='-->') == """# Hello world!<br/>-->"""

# Generated at 2022-06-23 10:06:28.464952
# Unit test for function ternary
def test_ternary():
    assert(ternary(True, 1, 2) == 1)
    assert(ternary(False, 1, 2) == 2)
    assert(ternary(None, 1, 2) == 2)
    assert(ternary(None, 1, 2, 3) == 3)



# Generated at 2022-06-23 10:06:33.479817
# Unit test for function to_json
def test_to_json():
    assert json.loads(to_json([1, 2, 3])) == [1, 2, 3]
    assert json.loads(to_json({"a": [[1], [2], [3]]})) == {"a": [[1], [2], [3]]}



# Generated at 2022-06-23 10:06:39.309259
# Unit test for function randomize_list
def test_randomize_list():
    mylist = ['apple', 'orange', 'banana']
    seed = 12345
    r = Random(seed)
    r.shuffle(mylist)
    assert mylist == ['banana', 'apple', 'orange']
    # Additional test for a non-list mylist, which should just return the original value
    mylist = 12345
    mylist = randomize_list(mylist, seed)
    assert mylist == 12345



# Generated at 2022-06-23 10:06:42.665553
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert {'a': 1, 'b': 2, 'c': 3, 'd': 4} == list_of_dict_key_value_elements_to_dict([
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2},
        {'key': 'c', 'value': 3},
        {'key': 'd', 'value': 4}
    ])



# Generated at 2022-06-23 10:06:44.070082
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() != None
test_FilterModule_filters()

# Generated at 2022-06-23 10:06:55.753375
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(r'\r\n', r'\r\n', '\n', True, False) == '\n'
    assert regex_replace('\r\n', r'\r\n', '\n', True, False) == '\n'
    source = r'foo\r\nbar'
    assert regex_replace(source, r'\\r\\n', '\n', True, False) == 'foo\nbar'
    assert regex_replace(source, r'\\r\\n', '\n', True, False) == to_text(source).replace('\r\n', '\n')
    assert regex_replace(source, r'\\r\\n', '\n', True, False) == to_native(source).replace('\r\n', '\n')



# Generated at 2022-06-23 10:07:02.142552
# Unit test for function to_nice_json
def test_to_nice_json():
    data = """\
    {
        "attached_devices": [ "sda", "sdb" ],
        "parameters": {
            "path": "/dev",
            "wwn": "0x50014380086c9fe1"
        }
    }
    """
    assert(data == to_nice_json(data))


# Generated at 2022-06-23 10:07:11.786249
# Unit test for function combine
def test_combine():
    def deep_structure(seq):
        return any([isinstance(x, list) or isinstance(x, dict) for x in seq])

    assert combine() == {}

    assert combine(1) == 1
    assert combine([]) == {}
    assert combine({}) == {}
    assert combine(None) is None
    assert combine(['a']) == 'a'
    assert combine('a') == 'a'
    assert combine(['a', 'b']) == ['a', 'b']
    assert combine(['a', 'b', 'c']) == ['a', 'b', 'c']

    assert combine([{'a': 1, 'b': 2}, {'b': 3, 'c': 4}]) == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-23 10:07:17.518679
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", 1476042953) == "2016-10-07 23:12:33"
    assert strftime("%Y-%m-%d %H:%M:%S", "1476042953") == "2016-10-07 23:12:33"
    assert strftime("%Y-%m-%d", 1465286189) == "2016-06-07"
    assert strftime("%Y-%m-%d", "1465286189") == "2016-06-07"
    assert strftime("%H:%M:%S", 1465286189) == "21:03:09"
    assert strftime("%H:%M:%S", "1465286189") == "21:03:09"



# Generated at 2022-06-23 10:07:27.801662
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    data = {"a": "b", "c": "d"}
    result = dict_to_list_of_dict_key_value_elements(data)
    assert result == [{"key": "a", "value": "b"}, {"key": "c", "value": "d"}]
    data = {"a": "b"}
    result = dict_to_list_of_dict_key_value_elements(data, key_name='key1', value_name='value1')
    assert result == [{"key1": "a", "value1": "b"}]



# Generated at 2022-06-23 10:07:33.794571
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(False) == False
    assert to_bool(True) == True
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool({}) == False
    assert to_bool([]) == False
    assert to_bool('asdf') == False



# Generated at 2022-06-23 10:07:44.093742
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2017-03-07 12:47:37") == datetime.datetime(2017, 3, 7, 12, 47, 37)
    assert to_datetime("2017-03-07 12:47:37", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2017, 3, 7, 12, 47, 37)
    assert to_datetime("07-03-17 12:47:37", "%d-%m-%y %H:%M:%S") == datetime.datetime(2017, 3, 7, 12, 47, 37)



# Generated at 2022-06-23 10:07:52.181500
# Unit test for function to_yaml
def test_to_yaml():
    '''Test for to_yaml'''
    assert to_yaml({'a list': [1, 42, 3.141, 1337, 'helpIamTrappedInAVerboseYamlFactory'], 'a string': 'bla', 'a number': 42}) == '{a list: [1, 42, 3.141, 1337, helpIamTrappedInAVerboseYamlFactory], a string: bla, a number: 42}\n'


# Generated at 2022-06-23 10:07:55.787591
# Unit test for function comment
def test_comment():
    return comment('Comment block.',
                   style='cblock',
                   decoration='// ',
                   beginning='/*',
                   end=' */',
                   newline='\n')



# Generated at 2022-06-23 10:08:05.309368
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' return the results of the filter under test '''
    def test(mydict):
        return dict_to_list_of_dict_key_value_elements(mydict)

    ''' test 'dict2items' filter with a valid dictionary '''
    valid_dict = {'foo': 'bar'}
    assert test(valid_dict) == [{'key': 'foo', 'value': 'bar'}]

    ''' test 'dict2items' filter with a non-iterable dictionary '''
    non_iterable_dict = 'foo'
    try:
        test(non_iterable_dict)
    except AnsibleFilterTypeError as ae:
        assert "dict2items requires a dictionary, got %s instead" % type(non_iterable_dict) in str(ae)
    else:
        assert False

# Generated at 2022-06-23 10:08:11.126753
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(u"This is a test.", 'test', '\\g<0>') == u"test"
    assert regex_search(u"This is a test.", '^(?P<a>\w+) (?P<b>\w+) (?P<a>\w+) (?P<d>\w+)\.', '\\g<a>', '\\g<b>', '\\g<d>') == [u"This", u"is", u"test"]



# Generated at 2022-06-23 10:08:16.757413
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # For utf-16 unicode strings
    # Python 2.7.9+ and 3.4+ already do this.
    if sys.version_info[0:2] < (2, 7) or (3, 0) <= sys.version_info[0:2] < (3, 4):
        if sys.maxunicode == 65535:
            # narrow python build
            sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())

if __name__ == '__main__':
    test_FilterModule_filters()

# Generated at 2022-06-23 10:08:19.552044
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('spam') == 'spam'



# Generated at 2022-06-23 10:08:25.483838
# Unit test for function to_bool
def test_to_bool():
    true_values = [
        'true', 'yes', 'on',
        [], True, 1, '1',
    ]
    for value in true_values:
        assert to_bool(value) is True

    false_values = [
        'false', 'no', 'off',
        None, False, 0, '0', '', [], {},
    ]
    for value in false_values:
        assert to_bool(value) is False



# Generated at 2022-06-23 10:08:36.233789
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(u'aaa', hashtype='md5') == '47bce5c74f589f4867dbd57e9ca9f808'
    assert get_hash('aaa', hashtype='md5') == '47bce5c74f589f4867dbd57e9ca9f808'
    assert get_hash(b'aaa', hashtype='md5') == '47bce5c74f589f4867dbd57e9ca9f808'
    assert get_hash(u'aaa', hashtype='sha256') == '47bce5c74f589f4867dbd57e9ca9f808'
    assert get_hash('aaa', hashtype='sha256') == '47bce5c74f589f4867dbd57e9ca9f808'
    assert get

# Generated at 2022-06-23 10:08:41.227777
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', '^(t)', '\\g<1>') == 't'
    assert regex_search('test', '^(t)', '\\g<1>', '\\1') == ['t', 't']
    assert regex_search('test', '^(t)', '\\1') == 't'
    assert regex_search('test', '^(t)', 1) == 't'



# Generated at 2022-06-23 10:08:46.895942
# Unit test for function to_json
def test_to_json():
    assert '"2"' == to_json(2)
    assert '["2"]' == to_json(['2'])
    assert '{"a": "2"}' == to_json(dict(a='2'))
    assert '{"a": "2"}' == to_json([('a', '2')])



# Generated at 2022-06-23 10:08:57.734810
# Unit test for function from_yaml_all
def test_from_yaml_all():
    test_string = """
---
- 'a'
---
- 'b'
---
{}
---
- 'd'
"""
    yaml_all = from_yaml_all(test_string)
    assert ['a'] == list(yaml_all)
    assert ['b'] == list(yaml_all)
    assert {} == list(yaml_all)[0]
    assert ['d'] == list(yaml_all)
    assert [] == list(yaml_all)
    assert len(list(yaml_all)) == 0



# Generated at 2022-06-23 10:09:09.113342
# Unit test for function do_groupby
def test_do_groupby():
    """Verify that do_groupby() is returning tuples, rather than namedtuples
    This is used to verify that the fix for https://github.com/ansible/ansible/issues/20098
    is present in ansible.
    """
    from ansible.template import JinjaEnvironment
    myenv = JinjaEnvironment()
    myenv.filters['groupby'] = do_groupby

    data = [{'id': 1, 'group': 'foo'},
            {'id': 2, 'group': 'foo'},
            {'id': 3, 'group': 'bar'}]
    template = """{% set groups = mydata | groupby("group") -%}
{{ groups | map(attribute="list") | list }}
"""

    t = myenv.from_string(template)
    results = t.render

# Generated at 2022-06-23 10:09:20.004393
# Unit test for function regex_escape
def test_regex_escape():
    ''' Unit test for regex_escape '''
    test_strings = dict()
    test_strings['posix_basic'] = [
        ['', ''],
        ['a', 'a'],
        ['.', r'\.'],
        ['^$*\\', r'\^\$\*\\'],
        ['(,.),[,],{,},|', r'\(\,\.\),\[,\],\{,\},\|'],
    ]
    test_strings['python'] = [
        ['', ''],
        ['a', 'a'],
        ['.', r'\.'],
        ['^$*+?{}[]\\|()', r'\^\$\*\+\?\{\}\[\]\\\|\(\)'],
    ]
    failures = 0


# Generated at 2022-06-23 10:09:26.874194
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([]) == []
    assert randomize_list(["1"]) == ["1"]
    assert randomize_list(["1", "2"]) == ["2", "1"]
    assert randomize_list(["1", "2", "3"]) == ["3", "2", "1"]
    assert randomize_list(["1", "2", "3"], "myseed") == ["1", "3", "2"]



# Generated at 2022-06-23 10:09:39.552552
# Unit test for function comment
def test_comment():
    assert (comment("This is a comment.", style='plain') == '# This is a comment.')
    assert (comment("This is a comment.", style='c') == '// This is a comment.')
    assert (comment("This is a comment.", style='cblock') == '/*\n'
                                                             ' * This is a comment.\n'
                                                             ' */')
    assert (comment("This is a comment.", style='erlang') == '% This is a comment.')
    assert (comment("This is a comment.", style='xml') == '<!--\n'
                                                          ' - This is a comment.\n'
                                                          '-->')


# Generated at 2022-06-23 10:09:45.566839
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(
        {'item1': 'value1', 'item2': 2}, 'key', 'value') == [
        {'key': 'item1', 'value': 'value1'},
        {'key': 'item2', 'value': 2}
    ]



# Generated at 2022-06-23 10:09:55.319932
# Unit test for function to_bool
def test_to_bool():
    true_args = ['True', 'true', '1', 1]
    false_args = ['False', 'false', '', 0]
    for args in true_args:
        true_val = to_bool(args)
        assert true_val is True, "to_bool returned %s, expected %s" % (true_val, True)
    for args in false_args:
        false_val = to_bool(args)
        assert false_val is False, "to_bool returned %s, expected %s" % (false_val, False)
    none_bool = to_bool(None)
    assert not none_bool, "to_bool returned %s, expected %s" % (none_bool, False)



# Generated at 2022-06-23 10:10:06.724726
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', '(f)oo', '\\1') == 'f'
    assert regex_search('bar', '(b)ar', '\\1') == 'b'
    assert regex_search('baz', '(b)az', '\\1') == 'b'
    assert regex_search('1foo2', r'(\d)foo(\d)', '\\2') == '2'
    assert regex_search('1foo2', r'(\d)foo(\d)', '\\1', '\\2') == ['1', '2']
    assert regex_search('bar', r'(?P<b>b)ar', '\\g<b>') == 'b'

# Generated at 2022-06-23 10:10:10.650638
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo[bar]') == 'foo\\[bar\\]'
    assert regex_escape('foo[bar]', re_type='posix_basic') == 'foo\\[bar\\]'
    # TODO: implement posix_extended
    # assert regex_escape('foo[bar]', re_type='posix_extended') == 'foo\\[bar\\]'


# Generated at 2022-06-23 10:10:11.400794
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:10:21.608439
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    # Test using default values for key_name and value_name
    mydict = {'key1': 'value1', 'key2': 'value2'}
    result = dict_to_list_of_dict_key_value_elements(mydict)
    expected = [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}]
    assert result == expected
    # Test using non-default values for key_name and value_name
    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='new_key', value_name='new_value')

# Generated at 2022-06-23 10:10:24.785888
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("1234") == u"1234"



# Generated at 2022-06-23 10:10:36.940898
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictEnvironment
    jenv = DictEnvironment()
    fn = jenv.from_string("{% set mylist = [{'id': 1, 'a': 'A', 'b': 'B'}, {'id': 1, 'a': 'C', 'b': 'D'}, {'id': 1, 'a': 'E', 'b': 'F'}] %}"
                          "{% for value in mylist | groupby('id') %}"
                          "{{ value }}"
                          "{% endfor %}").render()
    assert "((1, 'A', 'B'), (1, 'C', 'D'), (1, 'E', 'F'))" in fn

# Generated at 2022-06-23 10:10:46.048123
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    # Rather than use the ansible.module_utils.six.assertCountEqual, I am using a simple assert in this method
    assert(dict_to_list_of_dict_key_value_elements({'key1': 'value1', 'key2': 'value2'}, key_name='key', value_name='value') ==
           {'key1': {'key': 'key1', 'value': 'value1'}, 'key2': {'key': 'key2', 'value': 'value2'}})



# Generated at 2022-06-23 10:10:49.815741
# Unit test for function b64encode
def test_b64encode():
    try:
        result = b64encode(u'\u00e9')
        if result == 'w6k=':
            return "'%s' == '%s'" % (result, 'w6k=')
    except UnicodeEncodeError:
        return "Encoding Error"


# Generated at 2022-06-23 10:10:54.456607
# Unit test for function randomize_list

# Generated at 2022-06-23 10:10:58.160511
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all('{foo: True}\n{foo: True}') == [{'foo': True}, {'foo': True}]



# Generated at 2022-06-23 10:11:01.099505
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import ansible.plugins.filter.core
    a = ansible.plugins.filter.core.FilterModule()


# Generated at 2022-06-23 10:11:04.371787
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M', 1526649020) == '2018-05-19 11:50'



# Generated at 2022-06-23 10:11:16.191170
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('xyz', 'x') == ['x']
    assert regex_findall('xyz', 'X', ignorecase=True) == ['x']
    assert regex_findall('xyz', '.') == ['x', 'y', 'z']
    assert regex_findall('xyz', '^') == ['']
    assert regex_findall('xyz', '$') == ['']
    assert regex_findall('xyz', '\w') == ['x', 'y', 'z']
    assert regex_findall('xyz', '\d') == []
    assert regex_findall('x\ny', '.') == ['x', 'y']
    assert regex_findall('x\ny', '.y') == ['xy', 'yy']

# Generated at 2022-06-23 10:11:24.327536
# Unit test for function quote
def test_quote():
    assert quote(True) == u"'True'"
    assert quote(False) == u"'False'"
    assert quote("nasty|value") == u"nasty\\|value"
    assert quote("nasty&value") == u"nasty\\&value"
    assert quote("nasty;value") == u"nasty\\;value"
    assert quote("nasty?value") == u"nasty\\?value"
    assert quote("nasty$value") == u"nasty\\$value"
    assert quote("nasty*value") == u"nasty\\*value"
    assert quote("nasty#value") == u"nasty\\#value"
    assert quote("nasty`value") == u"nasty\\`value"
    assert quote("nasty{value") == u"nasty\\{value"

# Generated at 2022-06-23 10:11:37.030886
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-01-01 23:59:59", format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2018,1,1,23,59,59)
    assert to_datetime("2018-01-01", format="%Y-%m-%d") == datetime.datetime(2018,1,1,0,0)
    assert to_datetime("2018/01/01", format="%Y/%m/%d") == datetime.datetime(2018,1,1,0,0)
    assert to_datetime("2018-01-01 00:00:00", format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2018,1,1,0,0,0)
   

# Generated at 2022-06-23 10:11:43.196760
# Unit test for function to_datetime
def test_to_datetime():
    string = "2017-05-11 14:05:34"
    assert to_datetime(string, format="%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d %H:%M:%S") == "2017-05-11 14:05:34"
    assert to_datetime(string, format="%Y-%m-%d %H:%M:%S").utctimetuple() == time.struct_time((2017, 5, 11, 14, 5, 34, 3, 131, 0))
    assert to_datetime(string, format="%Y-%m-%d %H:%M:%S").isoformat() == u"2017-05-11T14:05:34"

# Generated at 2022-06-23 10:11:48.943122
# Unit test for function ternary
def test_ternary():
    import ansible.plugins.filter.core
    ansible.plugins.filter.core.ternary = ternary

    assert ternary(False, 1, 2) == 2
    assert ternary(1, 1, 2) == 1
    assert ternary(0, 1, 2) == 2
    assert ternary(None, 1, 2) == 2



# Generated at 2022-06-23 10:11:57.862513
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    print('//')
    print('// to_nice_yaml:')
    print('//')
    from ansible.module_utils.common.collections import MutableMapping
    import datetime
    from dateutil.tz import tzutc
    t = datetime.datetime.utcnow().replace(tzinfo=tzutc())
    y = MutableMapping({'some_date_time': t, 'simple_list': ['elem1', 'elem2']})
    print(to_nice_yaml(y))



# Generated at 2022-06-23 10:12:11.167475
# Unit test for function comment
def test_comment():
    # Formatting parameters
    params_plain = {
        'newline': '\n',
        'beginning': '',
        'prefix': '# ',
        'prefix_count': 1,
        'decoration': '',
        'postfix': '# ',
        'postfix_count': 1,
        'end': ''
    }
    # Helper function for comparison
    def compare(expected, result, params):
        newline = params['newline']
        prefix = params['prefix'].replace(' ', r'[ ]')
        decoration = params['decoration'].replace(' ', r'[ ]')
        # Check the count of each substring
        assert(expected.count(prefix) == result.count(r'# '))
        assert(expected.count(decoration) == result.count(r' - '))


# Generated at 2022-06-23 10:12:18.500907
# Unit test for function rand
def test_rand():
    for d in [dict(end=10), dict(end=10, seed=1), dict(end=10, start=2), dict(end=10, start=3, step=3),
              dict(end=list(range(10)))]:
        random_number = rand(None, **d)
        assert random_number >= 0
        assert random_number < 10



# Generated at 2022-06-23 10:12:30.314491
# Unit test for function combine
def test_combine():
    """
    basic test function
    """
    current_func = sys._getframe().f_code.co_name
    print("Running: %s" % current_func)
    a = dict()
    a['a'] = 'A'
    b = dict()
    b['b'] = 'B'
    correct_value = {'a': 'A', 'b': 'B'}
    # run test
    result = combine(a, b)
    if result != correct_value:
        print("Error in: %s" % current_func)
        print("Result: %s" % result)
        print("Correct Value: %s" % correct_value)
        print("-")
        return False

    # run test
    result = combine(b, a)

# Generated at 2022-06-23 10:12:39.395167
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'one', 'value': 'foo'}, {'key': 'two', 'value': 'bar'}, {'key': 'three', 'value': 'baz'}]

    thisdict = list_of_dict_key_value_elements_to_dict(mylist, key_name='key', value_name='value')
    if thisdict != {'one': 'foo', 'two': 'bar', 'three': 'baz'}:
        raise AssertionError('items2dict returned "%s" instead of the expected "%s"' % (thisdict, {'one': 'foo', 'two': 'bar', 'three': 'baz'}))


# Generated at 2022-06-23 10:12:43.396199
# Unit test for function regex_replace
def test_regex_replace():
  string = "OS is RedHat"
  pattern = "OS"
  replacement = "Platform"
  ignorecase = True
  multiline = False
  test = regex_replace(string, pattern, replacement, ignorecase, multiline)
  assert test == "Platform is RedHat"


# Generated at 2022-06-23 10:12:47.108168
# Unit test for function extract
def test_extract():
    puts(from_yaml("""
        - k1: k2
          k3: k4
        - a
        - b
        - k2:
            k5: k6
            
    """))
    assert('k4' == extract('k3', {'k1': {'k2': 'k4'}}))
    assert('k6' == extract('k5', {'k1': {'k2': {'k5': 'k6'}}}, 'k2'))
    assert('b' == extract(2, from_yaml("""
        - k1: k2
          k3: k4
        - a
        - b
    """)))


# -- end of filters --



# Generated at 2022-06-23 10:12:51.813294
# Unit test for function to_nice_json
def test_to_nice_json():
    myvar = {'name': 'Brian', 'role': 'Ansible'}
    expected = '''{
    "name": "Brian",
    "role": "Ansible"
}'''
    print(to_nice_json(myvar))
    assert to_nice_json(myvar) == expected, 'Test to_nice_json'



# Generated at 2022-06-23 10:13:04.647346
# Unit test for function regex_findall
def test_regex_findall():
    '''
    Validate the regex_findall function
    '''
    # Loop a list of test data and compare the actual results against
    # the expected results
    test_data = [
        (-1, re.compile(r'(\d+)\.'), "1.2.3", ['1', '2', '3']),
        (-1, re.compile(r'(\d+)\.'), "1.2.3.4.5.6.", ['1', '2', '3', '4', '5', '6']),
        (-1, re.compile(r'(\d+)\.'), "1.2.3.4.5.6.7.8.9.", ['1', '2', '3', '4', '5', '6', '7', '8', '9']),
    ]


# Generated at 2022-06-23 10:13:10.307432
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('ABcd12#$')) == u'ABcd12#$'
    assert b64decode(b64encode('ABcd12#$'), encoding='utf-16') == u'ABcd12#$'



# Generated at 2022-06-23 10:13:15.793850
# Unit test for function mandatory
def test_mandatory():
    from jinja2 import Undefined
    from jinja2.filters import do_mandatory
    undefined_var = Undefined('test')
    assert do_mandatory(undefined_var) is undefined_var
    try:
        do_mandatory(undefined_var, msg='Some message')
        assert False, "msg argument did not throw exception"
    except AnsibleFilterError:
        pass
    try:
        do_mandatory(undefined_var)
        assert False, "Mandatory variable not defined exception not raised"
    except AnsibleFilterError:
        pass
    assert do_mandatory('test') == 'test'
    assert do_mandatory('') == ''
    assert do_mandatory(None) is None
    assert do_mandatory(True) is True
    assert do_mandatory(False)

# Generated at 2022-06-23 10:13:20.131133
# Unit test for function regex_escape
def test_regex_escape():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert regex_escape('test string') == 'test\ string'
    assert regex_escape(None) == ''
    class test_class():
        def __str__(self):
            return 'test_string'
    assert regex_escape(test_class()) == 'test_string'
    assert regex_escape(AnsibleUnsafeText('test string')) == 'test string'



# Generated at 2022-06-23 10:13:23.810477
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('1') == 1
    assert from_yaml('foo') == 'foo'
    assert from_yaml('[1,2,3]') == [1, 2, 3]



# Generated at 2022-06-23 10:13:35.690993
# Unit test for function regex_search
def test_regex_search():
    '''
    Test function regex_search
    '''
    assert regex_search("Hello", "Hello") == "Hello"
    assert regex_search("Hello", "Hello", "\\g<1>") == "Hello"
    assert regex_search("Hello", "Hello", "\\1") == "Hello"
    assert regex_search("Hello World", "Hello (\\S+)", "\\1") == "World"
    assert regex_search("Hello World", "Hello (\\S+)", "\\g<1>") == "World"
    assert regex_search("Hello World", "Hello (\\S+)", "\\g<1>", "\\1") == ["World", "World"]

# Generated at 2022-06-23 10:13:39.854403
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(1)
    assert to_bool('1')
    assert to_bool('true')
    assert not to_bool(0)
    assert not to_bool('0')
    assert not to_bool('false')



# Generated at 2022-06-23 10:13:42.737167
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([{'foo': 'bar', 'spam': 'ham'}]) == '''
- foo: bar
  spam: ham
'''



# Generated at 2022-06-23 10:13:54.215877
# Unit test for function ternary
def test_ternary():
    class Test:
        def __bool__(self): return self
    assert ternary(True, 0, 1) == 0
    assert ternary(False, 0, 1) == 1
    assert ternary(None, 0, 1) == 1
    assert ternary(Test(), 0, 1) == 0
    assert ternary(Test(), 0, 1, True) == 0
    assert ternary(Test(), 0, 1, False) == 0
    assert ternary(Test(), 0, 1, None) == 0
    assert ternary(None, 0, 1, False) == 0
    assert ternary(None, 0, 1, True) == 1
    assert ternary(None, None, None, 'test') == 'test'
    assert ternary(None, 'test', None, '') == ''


# Generated at 2022-06-23 10:13:57.106240
# Unit test for function rand
def test_rand():
    r = rand(None, range(1,100))
    assert r in range(1,100)


# Generated at 2022-06-23 10:14:04.160082
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == '{}\n...\n'
    assert to_yaml(dict(a='b')) == '{a: b}\n'
    assert to_yaml(dict(a='b'), default_flow_style=False) == '{a: b}\n'
    assert to_yaml(dict(a='b'), default_flow_style=True) == '{a: b}\n'



# Generated at 2022-06-23 10:14:13.809397
# Unit test for function ternary
def test_ternary():
    assert ternary(0, 1, 2) == 2
    assert ternary(0, 1, 2, none_val=3) == 3
    assert ternary(None, 1, 2) == 2
    assert ternary(None, 1, 2, none_val=3) == 3
    assert ternary(1, 1, 2) == 1
    assert ternary(1, 1, 2, none_val=3) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(False, 1, 2, none_val=3) == 2
    assert ternary(True, 1, 2) == 1
    assert ternary(True, 1, 2, none_val=3) == 1



# Generated at 2022-06-23 10:14:18.415361
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == "--- {}\n"
    assert to_yaml({'foo': 'bar'}) == "---\nfoo: bar\n"
    assert to_yaml(['foo', 'bar']) == "---\n- foo\n- bar\n"



# Generated at 2022-06-23 10:14:19.083500
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:14:25.188427
# Unit test for function quote
def test_quote():
    assert quote(None) == u""
    assert quote(u"") == u""
    assert quote(u"hello") == u"hello"
    assert quote(u"hello world") == u"'hello world'"
    assert quote(u"hello;world") == u"'hello;world'"
    assert quote(u"hello'world") == u"'hello'\\''world'"
    assert quote(u"hello 'world'") == u"'hello '\\''world'\\'''"
    assert quote(u"hello \"world\"") == u"'hello \"world\"'"



# Generated at 2022-06-23 10:14:26.816438
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'foo', 'value': 'bar'}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'foo': 'bar'}



# Generated at 2022-06-23 10:14:40.027724
# Unit test for function path_join
def test_path_join():
    assert path_join('/var') == '/var'
    assert path_join('/var', 'log') == '/var/log'
    assert path_join('/var', 'log', 'messages') == '/var/log/messages'

    assert path_join(['/var']) == '/var'
    assert path_join(['/var', 'log']) == '/var/log'
    assert path_join(['/var', 'log', 'messages']) == '/var/log/messages'
    assert path_join(['/var', '/log', '/messages']) == '/var/log/messages'
    assert path_join(['var', 'log', 'messages']) == 'var/log/messages'



# Generated at 2022-06-23 10:14:51.920656
# Unit test for function ternary
def test_ternary():
    assert ternary(None, 'true', 'false', none_val='none') == 'none'
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(1, 'true', 'false') == 'true'
    assert ternary(0, 'true', 'false') == 'false'
    assert ternary(-1, 'true', 'false') == 'true'
    assert ternary(1, 'true', 'false') == 'true'
    assert ternary(2, 3, 4) == 3
    assert ternary(None, 3, 4, 5) == 5
    assert ternary(0, 3, 4, 5) == 4



# Generated at 2022-06-23 10:15:01.636949
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='I love Ansible', pattern='I love (\S+)', replacement=r'I hate \1') == 'I hate Ansible'
    assert regex_replace(value='I love Ansible', pattern='I love (\S+)', replacement=r'I hate \1', ignorecase=True) == 'I hate Ansible'
    assert regex_replace(value='I Love Ansible', pattern='I love (\S+)', replacement=r'I hate \1') == 'I Love Ansible'
    assert regex_replace(value='I love Ansible', pattern='^I love (\S+)', replacement=r'I hate \1') == 'I love Ansible'

# Generated at 2022-06-23 10:15:05.957272
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert(dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2}, 'key', 'value') == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}])


# Generated at 2022-06-23 10:15:13.677487
# Unit test for function fileglob
def test_fileglob():
    basedir = os.path.abspath(os.path.dirname(__file__))
    filelist = fileglob(basedir + "/../../lib/ansible/modules/*/*")
    assert isinstance(filelist, list)
    # An empty list is never a file
    assert len(filelist) > 0



# Generated at 2022-06-23 10:15:22.653062
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    ''' items2dict should return a dictionary from the given list '''
    my_list = [
        {
            'key': 'key1',
            'value': 'val1',
            'other': 'other1'
        },
        {
            'key': 'key2',
            'value': 'val2',
            'other': 'other2'
        },
        {
            'key': 'key3',
            'value': 'val3',
            'other': 'other3'
        }
    ]

    my_dict = list_of_dict_key_value_elements_to_dict(my_list, key_name='key', value_name='value')
    assert isinstance(my_dict, dict)
    assert 'key1' in my_dict
    assert 'key2' in my_dict


# Generated at 2022-06-23 10:15:32.267622
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({}) == {}
    assert combine({'a': 1}) == {'a': 1}
    assert combine({'a': 1}, {}) == {'a': 1}
    assert combine({'a': 1}, {'a': 2, 'b': 3}) == {'a': 2, 'b': 3}
    assert combine({'a': 1}, {'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert combine({'a': 1}, {'a': 2, 'b': 3, 'c': 4}, {'a': 5, 'c': 6}) == {'a': 5, 'b': 3, 'c': 6}