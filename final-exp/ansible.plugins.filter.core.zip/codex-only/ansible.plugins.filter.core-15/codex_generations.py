

# Generated at 2022-06-23 10:05:29.535004
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S") == '2017-01-26 05:17:55'



# Generated at 2022-06-23 10:05:39.924780
# Unit test for function to_uuid
def test_to_uuid():
    import uuid
    assert uuid.UUID(to_uuid(u'foo')) == uuid.UUID('361e6d51-faec-58dd-9994-341386da8e2e')
    assert uuid.UUID(to_uuid(u'foo', uuid.uuid4())) == uuid.UUID('6d0b0f09-6cd8-5a32-b47d-6e2ae779a8b6')
    assert uuid.UUID(to_uuid(u'foo', uuid.uuid4().hex)) == uuid.UUID('0019d2b2-33f9-5f35-a130-1e0a12159bde')

# Generated at 2022-06-23 10:05:47.925285
# Unit test for function to_nice_json
def test_to_nice_json():
    '''Test function to_nice_json'''
    data = {'a': 'a', 'b': 'b', 'c': 'c'}
    json_data = to_nice_json(data)

    assert(json_data == '{\n    "a": "a",\n    "b": "b",\n    "c": "c"\n}')



# Generated at 2022-06-23 10:05:51.453471
# Unit test for function to_yaml
def test_to_yaml():
    _test = {
        "test": "success"
    }
    _yaml = to_yaml(_test)
    assert _yaml == "test: success\n"


# Generated at 2022-06-23 10:05:58.724649
# Unit test for function do_groupby
def test_do_groupby():
    env = jinja2.Environment()
    f = env.filters['do_groupby']

    # non-list input should throw an exception
    non_list_inputs = [
        "string",
        {"a": "dict"},
    ]
    for input_value in non_list_inputs:
        with pytest.raises(TypeError):
            f(input_value, attribute='dict')

    # empty list
    assert f([], attribute='dict') == []

    def _test_do_groupby(input_list, attribute):
        input_list_copy = deepcopy(input_list)
        result = f(input_list_copy, attribute=attribute)

# Generated at 2022-06-23 10:06:04.965861
# Unit test for function b64decode
def test_b64decode():
    def _test(input_value, expected_output_value):
        actual_output_value = b64decode(input_value)
        assert actual_output_value == expected_output_value, \
            "Expected the value {0!r}, but the actual output is: {1!r}".format(expected_output_value, actual_output_value)

    _test('dGVzdCBtZXNzYWdl', 'test message')
    _test('dGVzdCBtZXNzYWdlLg==', 'test message.')
    _test('dGVzdCBtZXNzYWdlLgo=', 'test message.')
    _test('dGVzdCBtZXNzYWdlLgoK', 'test message..')

    assert not b64decode('---\n')

# Generated at 2022-06-23 10:06:07.606127
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("{ foo: 'bar' }") == {'foo': 'bar'}  # noqa



# Generated at 2022-06-23 10:06:09.103254
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}



# Generated at 2022-06-23 10:06:15.083312
# Unit test for function b64decode
def test_b64decode():
    sample_string = {
        'b64_encoded': 'b3UgdGVzdCB0aGluZ3Mgd2l0aCB0aGUgYmFzZTY0IGVuY29kaW5nIGZ1bmN0aW9uCg==',
        'b64_decoded': 'you test things with the base64 encoding function',
    }
    assert b64decode(sample_string['b64_encoded']) == sample_string['b64_decoded']



# Generated at 2022-06-23 10:06:18.584855
# Unit test for function rand
def test_rand():
    environment = {'_': Dummy()}
    assert rand(environment, 0, 5, 1, seed=1) == 3
    assert rand(environment, [1, 2, 3], seed=1) == 3
    assert rand(environment, [1, 2, 3]) in [1, 2, 3]



# Generated at 2022-06-23 10:06:27.510602
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements_test_val1 == dict_to_list_of_dict_key_value_elements(mydict=dict_to_list_of_dict_key_value_elements_test_dict1)

# Test data for function dict_to_list_of_dict_key_value_elements
dict_to_list_of_dict_key_value_elements_test_dict1 = dict(a='1', b='2', c='3')
dict_to_list_of_dict_key_value_elements_test_val1 = [{'key': 'a', 'value': '1'}, {'key': 'b', 'value': '2'}, {'key': 'c', 'value': '3'}]



# Generated at 2022-06-23 10:06:34.783059
# Unit test for function ternary
def test_ternary():

    # value is None and none_val is provided
    assert ternary(None, 1, 2, none_val=3) == 3

    # value is None but none_val is not provided
    assert ternary(None, 1, 2) == 2

    # value is 0
    assert ternary(0, 1, 2) == 2

    # value is not 0
    assert ternary(1, 1, 2) == 1



# Generated at 2022-06-23 10:06:46.988540
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [1, 2, 3]]) == [1, 2, 1, 2, 3]
    assert flatten([1, 2, [1, 2, 3]], levels=1) == [1, 2, 1, 2, 3]
    assert flatten([1, 2, [1, 2, 3]], levels=0) == [1, 2, [1, 2, 3]]

    class mylist(list):
        pass

    assert flatten((1, 2, mylist([1, 2, 3]))) == [1, 2, 1, 2, 3]

    assert flatten(["foo", "bar"]) == ["foo", "bar"]

# Generated at 2022-06-23 10:06:51.252367
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-07-21 00:00:00", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2018, 7, 21, 0, 0)


# Generated at 2022-06-23 10:06:53.690911
# Unit test for function mandatory
def test_mandatory():
    try:
        var = mandatory(Undefined(name='foo'))
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError("Unit test for mandatory() failed!")



# Generated at 2022-06-23 10:07:04.961614
# Unit test for function regex_replace
def test_regex_replace():
    pattern = r'\[(?P<name>.*?)\]'
    value = "[users:children]"
    replacement = '{{item.name}}'
    _re = re.compile(pattern)
    res = _re.sub(replacement, value)
    assert res == "{{item.name}}"
    value = "[users:vars]"
    replacement = '{{item.name}}'
    res = _re.sub(replacement, value)
    assert res == "{{item.name}}"
    value = "play1"
    replacement = '{{item.name}}'
    res = _re.sub(replacement, value)
    assert res == "play1"


# Generated at 2022-06-23 10:07:06.810267
# Unit test for function do_groupby
def test_do_groupby():
    # Obtained from jinja2 tests/api.py
    assert do_groupby([{'x': 1}, {'x': 2}, {'x': 1}], 'x') == [(1, [{'x': 1}, {'x': 1}]), (2, [{'x': 2}])]



# Generated at 2022-06-23 10:07:09.924532
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/dev/null") == ['/dev/null']
    assert fileglob("/dev/f*") == []
    assert fileglob("/dev/tty") == ['/dev/tty']



# Generated at 2022-06-23 10:07:13.788307
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('abc') == 'YWJj'
    assert b64encode('\n') == 'Cg=='
    assert b64encode('\xFF') == '//8='



# Generated at 2022-06-23 10:07:27.138737
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('hello world', r'(\S+) (\S+)') == 'hello world'
    assert regex_replace('hello world', r'(\S+) (\S+)', '\\2 \\1') == 'world hello'
    assert regex_replace('The quick brown fox jumps over the lazy dog', r'(\w+)', r'<<\1>>') == '<<The>> <<quick>> <<brown>> <<fox>> <<jumps>> <<over>> <<the>> <<lazy>> <<dog>>'
    assert regex_replace('The quick brown fox jumps over the lazy dog', r'(\w+)', r'<<\1>>', ignorecase=True) == '<<The>> <<quick>> <<brown>> <<fox>> <<jumps>> <<over>> <<the>> <<lazy>> <<dog>>'

# Generated at 2022-06-23 10:07:36.250266
# Unit test for function quote

# Generated at 2022-06-23 10:07:39.547896
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(
        {"key1": "val1", "key2": "val2"}, key_name='key', value_name='value') == [
            {"key": "key1", "value": "val1"},
            {"key": "key2", "value": "val2"}]



# Generated at 2022-06-23 10:07:41.566256
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 'b'}], key_name='key', value_name='value') == {'a': 'b'}



# Generated at 2022-06-23 10:07:45.773434
# Unit test for function combine
def test_combine():
    from ansible.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var
    def verify_unsafe_vars(var, unsafe_vars):
        assert not var.vars, "Somethings wrong, unsafe_vars is being set on non-unsafe_var"
        for k, v in var.items():
            if v in unsafe_vars:
                continue
            assert k not in unsafe_vars, "Unexpected unsafe_var in %s" % k
            verify_unsafe_vars(v, unsafe_vars)

# Generated at 2022-06-23 10:07:54.081859
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abcdefg12345', '([a-z]+)([0-9]+)') == 'abcdefg12345'
    assert regex_replace('abcdefg12345', '([a-z]+)([0-9]+)', '\\2\\1') == '12345abcdefg'
    assert regex_replace('abcdEfg12345', '([a-z]+)([0-9]+)', '\\2\\1', ignorecase=True) == '12345Efgabcd'



# Generated at 2022-06-23 10:07:56.341033
# Unit test for function extract
def test_extract():

    testlist = [
        [1, 2],
        [3, 4]
    ]
    assert extract(item=0, container=testlist) == 1
    assert extract(0, testlist) == 1
    assert extract(1, testlist) == [3, 4]
    assert extract(item=1, morekeys=1, container=testlist) == 4



# Generated at 2022-06-23 10:08:03.251580
# Unit test for function to_datetime
def test_to_datetime():
    assert (to_datetime('2013-02-22 20:00:00') == datetime.datetime(2013,2,22,20,0,0))
    assert (to_datetime('2013.02.22 20:00:00', '%Y.%m.%d %H:%M:%S') == datetime.datetime(2013,2,22,20,0,0))
# End unit test.



# Generated at 2022-06-23 10:08:07.256291
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    a = [{'value': 'b', 'key': 'a'}, {'value': 'd', 'key': 'c'}]
    c = [{'value': 'b', 'key': 'a'}, {'value': 'd', 'key': 'c'}, {'value': 'f', 'key': 'e'}]
    b = {'a': 'b', 'c': 'd'}
    d = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert list_of_dict_key_value_elements_to_dict(a) == b
    assert list_of_dict_key_value_elements_to_dict(c) == d



# Generated at 2022-06-23 10:08:15.918493
# Unit test for function get_encrypted_password

# Generated at 2022-06-23 10:08:25.846045
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
[
 [foo, bar],
 {baz: qux}
]
'''
    assert from_yaml(data) == [[u'foo', u'bar'], {u'baz': u'qux'}]
    assert from_yaml(text_type(data)) == [[u'foo', u'bar'], {u'baz': u'qux'}]
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert from_yaml(AnsibleUnicode(data)) == [[u'foo', u'bar'], {u'baz': u'qux'}]



# Generated at 2022-06-23 10:08:30.539797
# Unit test for function to_json
def test_to_json():
    output = to_json({'test_obj': {'test_dict': 'test_value'}}, sort_keys=True, indent=4)
    assert output == '{\n    "test_obj": {\n        "test_dict": "test_value"\n    }\n}'



# Generated at 2022-06-23 10:08:38.135178
# Unit test for function to_nice_json
def test_to_nice_json():
    test_list = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
    # expected, the total string for test list
    expected = '''[
    {
        "id": 1,
        "name": "Alice"
    },
    {
        "id": 2,
        "name": "Bob"
    }
]'''

    # actual value of test list, convert to json by to_nice_json function
    actual = to_nice_json(test_list)
    # assert actual string equals to expected string
    assert actual == expected



# Generated at 2022-06-23 10:08:42.714655
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    list_of_dicts = [{'key': 1, 'value': 'one'}, {'key': 2, 'value': 'two'}, {'key': 3, 'value': 'three'}]
    assert (list_of_dicts == dict_to_list_of_dict_key_value_elements({1: 'one', 2: 'two', 3: 'three'}, key_name='key', value_name='value'))



# Generated at 2022-06-23 10:08:45.761533
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='varname')) is None



# Generated at 2022-06-23 10:08:54.433220
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b'abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert get_hash('abc', 'sha224') == '23097d223405d8228642a477bda255b32aadbce4bda0b3f7e36c9da7'



# Generated at 2022-06-23 10:08:57.598127
# Unit test for function to_yaml
def test_to_yaml():
    assert isinstance(to_yaml({1:2, 3:4}), basestring)
    assert isinstance(to_yaml([7, 8, 9]), basestring)


# Generated at 2022-06-23 10:09:09.113475
# Unit test for function ternary
def test_ternary():

    truthy = list()
    falsy = list()
    nonety= list()

    truthy.append(True)
    truthy.append('abc')
    truthy.append(0)
    truthy.append(1)
    truthy.append(100)
    truthy.append(-100)

    falsy.append(False)
    falsy.append(0.0)
    falsy.append('')
    falsy.append(())
    falsy.append([])
    falsy.append({})
    falsy.append(None)


    nonety.append(None)

    assert ternary(True, 'yes', 'no') == 'yes'
    assert ternary(False, 'yes', 'no') == 'no'
    assert ternary(None, 'yes', 'no')

# Generated at 2022-06-23 10:09:20.801726
# Unit test for function path_join
def test_path_join():
    assert path_join('single_path') == os.path.join('single_path')
    assert path_join(['first_path', 'second_path', None, 'third_path']) == os.path.join('first_path', 'second_path', 'third_path')
    assert path_join([u'first_path', u'second_path', u'third_path']) == os.path.join(u'first_path', u'second_path', u'third_path')
    assert path_join([b'first_path', b'second_path', b'third_path']) == os.path.join(b'first_path', b'second_path', b'third_path')

# Generated at 2022-06-23 10:09:25.198018
# Unit test for function to_nice_json
def test_to_nice_json():
    # Test generating JSON
    v = {'a': 'b', 'c': 'd'}
    assert to_nice_json(v) == '{\n    "a": "b", \n    "c": "d"\n}'


# Generated at 2022-06-23 10:09:34.269307
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('mysecurepassword', 'sha512', salt='saltysalt', salt_size=12, rounds=5000, ident='$6$') == '$6$salty$WxHvJ0lYXf/z4PcJ6eNz6HbN5U5S6/b/6PJiJVk/nR9jVbJzZkwW6fa7vzjNO.WEzbwq3xMk.nFvJY4YXHj4G0'

# Generated at 2022-06-23 10:09:36.157172
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S',0) == '1970-01-01 00:00:00'



# Generated at 2022-06-23 10:09:38.602395
# Unit test for function to_json
def test_to_json():
    assert to_json([1,2,3]) == '[1, 2, 3]'


# Generated at 2022-06-23 10:09:51.798058
# Unit test for function extract
def test_extract():
    assert extract("one", "one") == "one"
    assert extract("one", ["one", 0]) == "one"
    assert extract("one", ["one", "0"]) == "one"
    assert extract("one", [["one", "0"], 1]) == "one"

    assert extract("one", "two") == "two"
    assert extract("one", ["two", "1"]) == "one"
    assert extract("one", ["two", 1]) == "one"
    assert extract("one", [["two", "1"], 0]) == "one"

    assert extract("one", "three", {}) == {}
    assert extract("one", ["three", "2"], {}) == {}
    assert extract("one", ["three", 2], {}) == {}

# Generated at 2022-06-23 10:09:57.542575
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2, 'c': 3}) == [{'value': 1, 'key': 'a'}, {'value': 2, 'key': 'b'}, {'value': 3, 'key': 'c'}]



# Generated at 2022-06-23 10:10:02.398998
# Unit test for function to_nice_json
def test_to_nice_json():
    a = {"test": "one"}
    assert to_nice_json(a) == '{\n    "test": "one"\n}'
    assert to_json(a) == '{"test": "one"}'


# Generated at 2022-06-23 10:10:08.583394
# Unit test for function path_join
def test_path_join():
    assert path_join('a') == 'a'
    assert path_join(['a', 'b']) == 'a/b'
    assert path_join('a/b') == 'a/b'
    assert path_join(['a/b', 'c']) == 'a/b/c'



# Generated at 2022-06-23 10:10:20.436693
# Unit test for function regex_replace
def test_regex_replace():
    text = 'test123test'
    # simple replacement
    assert regex_replace(text, r'test', 'foo') == 'foo123test'
    # partial replacement
    assert regex_replace(text, r'test(?=123)', 'foo') == 'foo123test'
    # regex replacement
    assert regex_replace(text, r'\d+', 'foo') == 'testfoofoo'
    # case insensitive option
    assert regex_replace(text, r'test', 'foo', ignorecase=True) == 'foo123foo'
    # option overrule
    assert regex_replace(text, r'test', 'foo', ignorecase=False) == 'foo123test'
    # multiline option
    text = '''test123
test456'''

# Generated at 2022-06-23 10:10:22.745477
# Unit test for function rand
def test_rand():
    # TODO: better testing!
    assert rand(1, 10) <= 10



# Generated at 2022-06-23 10:10:30.199572
# Unit test for function to_yaml
def test_to_yaml():
    # first a simple list of strings
    lst = [ 'foo', 'bar', 'baz' ]
    assert to_yaml(lst) == "- foo\n- bar\n- baz", "to_yaml should display simple list of strings"
    # now a more complicated dictionary
    dictionary = {"foo":{"bar":"baz"}}
    assert to_yaml(dictionary) == "foo:\n  bar: baz", "to_yaml should display dictionary"


# Generated at 2022-06-23 10:10:40.398209
# Unit test for function do_groupby
def test_do_groupby():
    """Test the do_groupby filter."""
    from jinja2 import Environment

    # A test input
    original_value = [
        {
            'hostname': 'host1',
            'os': 'linux',
            'kernel': '3.9',
        },
        {
            'hostname': 'host2',
            'os': 'linux',
            'kernel': '4.4',
        },
        {
            'hostname': 'host3',
            'os': 'windows',
            'kernel': '6.1',
        },
        {
            'hostname': 'host4',
            'os': 'windows',
            'kernel': '6.1',
        },
    ]

    # Create a jinja2 environment, and add the template filters
    j2_env = Environment()
   

# Generated at 2022-06-23 10:10:48.964683
# Unit test for function b64encode
def test_b64encode():
    from ansible.module_utils import basic
    from os.path import join, dirname, abspath
    import sys

    # Get the test file path
    test_file_path = dirname(abspath(__file__))

    # Import the test module
    test_module_path = join(test_file_path, '..', 'hacking', 'test_b64encode.py')
    test_module = basic._load_module_source('test_b64encode', test_module_path)

    # Initialize unit test module
    test_module.unit_test_init()

    # Run the unit tests
    sys.exit(test_module.run())



# Generated at 2022-06-23 10:10:57.686163
# Unit test for function randomize_list
def test_randomize_list():
    if randomize_list([1, 2, 3]) != [1, 2, 3]:
        raise AssertionError()
    if randomize_list([1, 2, 3], seed=1) != [2, 1, 3]:
        raise AssertionError()
    if randomize_list([1, 2, 3], seed=1) != [2, 1, 3]:
        raise AssertionError()
    if randomize_list([1, 2, 3], seed=2) != [3, 1, 2]:
        raise AssertionError()
    if randomize_list([1, 2, 3], seed=2) != [3, 1, 2]:
        raise AssertionError()
    if randomize_list([1, 2, 3], seed=3) != [2, 3, 1]:
        raise AssertionError()

# Generated at 2022-06-23 10:11:10.421580
# Unit test for function path_join
def test_path_join():
    assert path_join('/') == '/'
    assert path_join('/', '') == '/'
    assert path_join('/', '/') == '/'
    assert path_join('/', 'etc', 'foo') == '/etc/foo'
    assert path_join('/', '/', 'etc', '/', 'foo') == '/etc/foo'
    assert path_join('/', '//', 'etc', '//', '/', 'foo') == '/etc/foo'
    assert path_join('//', '//', 'etc', '//', '/', 'foo') == '/etc/foo'
    assert path_join('//', '//', 'etc', '//', '/', '/foo') == '/foo'

# Generated at 2022-06-23 10:11:14.992261
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'foo', 'value': 'bar'}, {'key': 'spam', 'value': 'eggs'}]) == {'foo': 'bar', 'spam': 'eggs'}



# Generated at 2022-06-23 10:11:23.539813
# Unit test for function from_yaml_all
def test_from_yaml_all():
    '''Test return value of from_yaml_all() filter'''
    assert from_yaml_all('''
- foo: bar
  baz: qux
- foo: baz
  baz: qux
''') == [{u'baz': u'qux', u'foo': u'bar'}, {u'baz': u'qux', u'foo': u'baz'}]
    # Test reading strings with non-ASCII characters
    assert from_yaml_all(u'''
- foo: \u1234bar
  baz: qux
''') == [{u'baz': u'qux', u'foo': u'\u1234bar'}]
    # Test reading non-strings
    assert from_yaml_all({}) == {}
    # Raise exception if

# Generated at 2022-06-23 10:11:27.386371
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'a': ['b', 'c']}) == '''{
    "a": [
        "b",
        "c"
    ]
}'''



# Generated at 2022-06-23 10:11:35.020591
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1, "it works") == 1
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert "it must have a specific error message" in to_text(e)
    try:
        mandatory(AnsibleUndefined, "it must have a specific error message")
    except AnsibleFilterError as e:
        assert "it must have a specific error message" in to_text(e)



# Generated at 2022-06-23 10:11:42.241702
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello', '\\g<0>') == 'hello'
    assert regex_search('hello world', 'hello', '\\0') == 'hello'
    assert regex_search('hello world', 'hello (?P<planet>\w+)', '\\g<planet>') == 'world'
    assert regex_search('hello world', 'hello (?P<planet>\w+)', '\\g<1>') == 'world'
    assert regex_search('hello world', 'hello (\w+) (\w+)', '\\2') == 'world'
    assert regex_search('hello world', 'hello (\w+) (\w+)', '\\2', '\\1') == ['world', 'hello']

# Generated at 2022-06-23 10:11:51.836499
# Unit test for function comment
def test_comment():
    assert comment('Test', style='cblock') == '/*\n * Test\n */'
    assert comment(
        'Test\nwith\nnew\nlines',
        style='plain',
        decoration='/// ') == '# /// Test\n# /// with\n# /// new\n# /// lines'
    assert comment(
        'Test\nwith\nnew\nlines',
        style='plain',
        decoration='/// ',
        prefix_count=0) == '# Test\n# with\n# new\n# lines'
    assert comment(
        'Test\nwith\nnew\nlines',
        style='plain',
        decoration='/// ',
        postfix_count=0) == '# Test\n# with\n# new\n# lines'

# Generated at 2022-06-23 10:12:01.760046
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("some_data") == 'cabd6fa88c6f1dedb2f7a72cad0415ea7c0a9648'
    assert get_hash("some_data", "sha224") == '7b0feee6d65c6f1912b0d0e1c07030f2d7acd8eb1efb7e69b87a87'
    assert get_hash("some_data", "sha256") == 'f1b8a33a7da7373b5ed6f4689698fd5d6e5c6f5e4c56f8df4d4b3df4ce1f83e1'

# Generated at 2022-06-23 10:12:12.960530
# Unit test for function quote
def test_quote():
    _input = u'set option "a" "b"'
    expected_result = u'set option "a" "b"'
    result = quote(_input)
    assert result == expected_result

    _input = u'set option "a b"'
    expected_result = u'"set option \\"a b\\""'
    result = quote(_input)
    assert result == expected_result

    _input = u'set option "a\"b"'
    expected_result = u'set option "a\\"b"'
    result = quote(_input)
    assert result == expected_result

    _input = u'a\'b'
    expected_result = u"'a'\\''b'"
    result = quote(_input)
    assert result == expected_result



# Generated at 2022-06-23 10:12:25.217796
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("foo") == b"Zm9v"
    assert b64encode("foo", encoding="utf-16") == b"Zm9v"
    assert b64encode("foo", encoding="utf-16be") == b"Zm9v"
    assert b64encode("foo", encoding="utf-16le") == b"Zm9v"
    assert b64encode("\x19foo\x18") == b'XGZvb1w='
    assert b64encode("\x19foo\x18", encoding="utf-16") == b"XGZvb1w="
    assert b64encode("\x19foo\x18", encoding="utf-16be") == b"XGZvb1w="

# Generated at 2022-06-23 10:12:31.394821
# Unit test for function rand
def test_rand():
    assert rand(0, 10) >= 0 and rand(0, 10) < 10
    assert rand(0, 10, step=2) % 2 == 0
    assert rand(0, 10, step=2) >= 0 and rand(0, 10, step=2) < 10
    assert rand(0, 100, start=50) >= 50 and rand(0, 100, start=50) < 100
    assert rand(0, 100, step=3, start=50) >= 50 and rand(0, 100, step=3, start=50) < 100
    assert rand(0, 100, start=50, step=3) >= 50 and rand(0, 100, start=50, step=3) < 100
    assert rand(seed=10, end=[1, 2, 3, 4]) in [1, 2, 3, 4]

# Generated at 2022-06-23 10:12:39.013130
# Unit test for function extract
def test_extract():
    env = Environment()
    val1 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    assert extract(env, 'a', val1) == 1
    assert extract(env, 'b', val1) == 2
    assert extract(env, 'c', val1) == {'d': 4, 'e': 5}
    assert extract(env, 'e', val1, 'c') == 5
    assert extract(env, 'a', val1, morekeys=['c']) == 1
    assert extract(env, 'a', val1, morekeys='c') == 1
    assert extract(env, 'e', val1, morekeys=['c', 'd']) == 5



# Generated at 2022-06-23 10:12:49.653297
# Unit test for function comment
def test_comment():
    assert comment('some text') == '# some text'
    assert comment(
        'some\ntext', style='c') == '// some\n// text'
    assert comment(
        'some\ntext', style='cblock') == '/*\n * some\n * text\n */'
    assert comment(
        'some\ntext', style='cblock', decoration='// ') == '/*\n // some\n // text\n */'
    assert comment(
        'some\ntext', style='xml') == '<!--\n - some\n - text\n-->'
    assert comment(
        'some\ntext', style='xml', decoration='<!-- NOTE: ') == '<!--\n <!-- NOTE: some\n <!-- NOTE: text\n-->'

# Generated at 2022-06-23 10:12:57.210809
# Unit test for function regex_escape
def test_regex_escape():
    for regex_type in ['python', 'posix_basic', 'posix_extended']:
        assert regex_escape('', regex_type) == ''
        assert regex_escape('ab', regex_type) == 'ab'
        assert regex_escape('a[]b', regex_type) == 'a\\[\\]b'
        assert regex_escape('a.b', regex_type) == 'a\\.b'
        # In python, only ^ and $ need escaping, but we do all of them here.
        assert regex_escape('^a$', regex_type) == '\\^a\\$'
        assert regex_escape('a*b', regex_type) == 'a\\*b'
        assert regex_escape('a+b', regex_type) == 'a\\+b'

# Generated at 2022-06-23 10:13:06.874981
# Unit test for function comment
def test_comment():

    # Asserts
    assert comment('Sample text') == '# Sample text'
    assert comment('Sample text', decoration='-- ') == '-- Sample text'
    assert comment('Sample text', decoration='') == 'Sample text'
    assert comment('Sample text', newline='\r\n') == '# Sample text'
    assert comment('Sample text', beginning='/*') == '/*\n# Sample text'
    assert comment('Sample text', beginning='/*', end='*/') == '/*\n# Sample text\n*/'
    assert comment('Sample text', prefix='--->') == '--->\n--->Sample text'
    assert comment('Sample text', prefix='--->', prefix_count=2) == '--->\n--->\n--->Sample text'

# Generated at 2022-06-23 10:13:09.532971
# Unit test for function b64encode
def test_b64encode():
    assert 'dGVzdA==' == b64encode('test')
    assert 'dHdv' == b64encode(b'two')
    assert '' == b64encode('')



# Generated at 2022-06-23 10:13:15.374668
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    test_data = [{'key': 'a', 'value': 'b'}, {'key': 'c', 'value': 'd'}]
    result = list_of_dict_key_value_elements_to_dict(test_data)
    assert result == {'a': 'b', 'c': 'd'}



# Generated at 2022-06-23 10:13:19.618161
# Unit test for function path_join
def test_path_join():
    paths = ["one", "two", "three"]
    expected = "one/two/three"
    actual = path_join(paths)
    assert expected == actual
    assert expected == path_join("/".join(paths))
    assert expected == path_join("one")
    assert expected == path_join("one/")



# Generated at 2022-06-23 10:13:23.976994
# Unit test for function to_yaml
def test_to_yaml():
    def test_body(res):
        assert isinstance(res, string_types)
        assert not res.startswith(u'!!python')
        assert len(res) > 0
        assert '\n' in res

    test_body(to_yaml({'a':1}))
    test_body(to_yaml([1]))
    test_body(to_yaml({'a':[1]}))
    test_body(to_yaml('a'))



# Generated at 2022-06-23 10:13:35.839011
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    mydict = {
        AnsibleUnicode('a'): AnsibleUnicode('aa'),
        AnsibleUnicode('b'): AnsibleUnicode('bb'),
        AnsibleUnicode('c'): AnsibleUnicode('cc')
    }
    assert dict_to_list_of_dict_key_value_elements(mydict) == [
        {'key': 'a', 'value': 'aa'},
        {'key': 'b', 'value': 'bb'},
        {'key': 'c', 'value': 'cc'}
    ]


# Generated at 2022-06-23 10:13:47.887875
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    random_list0 = randomize_list(mylist, seed=0)
    random_list1 = randomize_list(mylist, seed=1)
    random_list2 = randomize_list(mylist, seed=2)
    assert random_list0 == [5, 8, 1, 4, 10, 7, 9, 3, 6, 2]
    assert random_list1 == [4, 2, 9, 1, 3, 6, 10, 7, 8, 5]
    assert random_list2 == [4, 9, 5, 10, 6, 2, 3, 8, 7, 1]
    mylist = [1, 2, 3, 4]

# Generated at 2022-06-23 10:13:57.166600
# Unit test for function extract
def test_extract():
    ''' If you change the logic here, the unit tests must be adapted
        (see the tests directory).
    '''
    variables = {
        'a': {'b': {'c': 'd'}, 'c': 'd'},
        'b': {'c': 'd'},
        'c': 'd',
        'd': 'e',
        'e': {'f': {'g': 'h'}},
    }

    # Examples of usage
    assert extract('b', variables['a'], None) == {'c': 'd'}
    assert extract('c', variables['b'], None) == 'd'
    assert extract('d', variables['c'], None) == 'd'
    assert extract('d', variables['d'], None) == 'e'

# Generated at 2022-06-23 10:14:05.773670
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool('yes') == True
    assert to_bool(1) == True
    assert to_bool('on') == True
    assert to_bool('true') == True
    assert to_bool('foo') == False
    assert to_bool(False) == False
    assert to_bool('False') == False
    assert to_bool('Foo') == False
    assert to_bool(None) == None
    assert to_bool('None') == False
test_to_bool.unittest = True



# Generated at 2022-06-23 10:14:11.329217
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(
        {"key1": "value1", "key2": "value2", "key3": "value3"}) ==\
        [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}, {'key': 'key3', 'value': 'value3'}]



# Generated at 2022-06-23 10:14:22.816984
# Unit test for function extract
def test_extract():
    value = {"item1": {"item2": {"item3": {"item4": ["value1", "value2"]}}}}
    assert extract("item1", value) == {"item2": {"item3": {"item4": ["value1", "value2"]}}}
    assert extract("item2", extract("item1", value)) == {"item3": {"item4": ["value1", "value2"]}}
    assert extract("item3", extract("item2", extract("item1", value))) == {"item4": ["value1", "value2"]}
    assert extract("item4", extract("item3", extract("item2", extract("item1", value)))) == ["value1", "value2"]
    assert extract("item2", value, "item1") == {"item3": {"item4": ["value1", "value2"]}}

# Generated at 2022-06-23 10:14:23.994459
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello') == 'aGVsbG8='
    assert b64encode('hello', encoding='latin1') == 'aGVsbG8='


# Generated at 2022-06-23 10:14:26.931509
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo[bar') == 'foo\\[bar'
    assert regex_escape('foo[bar', re_type='posix_basic') == 'foo\\[bar'
    # Test that f"foo{bar}"
    #assert regex_escape('foo{bar}') == 'foo\\{bar\\}'
    # TODO: test regex_type='posix_extended', when posix_extended is implemented



# Generated at 2022-06-23 10:14:35.956237
# Unit test for function strftime
def test_strftime():
    '''Unit test for function strftime'''
    import tests.units.test_count as test_count
    test_count.countTest()
    print('\nTest strftime')
    #print(strftime('%c', time.time()))
    #print(strftime('%c', 1561781605))
    #print(strftime('%Y-%m-%d %H:%M:%S', 1561781605))



# Generated at 2022-06-23 10:14:45.807634
# Unit test for function flatten
def test_flatten():

    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten([[1, 2, 3], [[4, 5, 6], [7, 8, 9]]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten([1, [[2, 3]], [4, 5]]) == [1, [2, 3], 4, 5]
    assert flatten([[1, [2, 3]], [4, 5]]) == [1, [2, 3], 4, 5]

# Generated at 2022-06-23 10:14:57.466389
# Unit test for function to_json
def test_to_json():
    data = {
      "data":{
        "app_server":{
          "description":"App Server",
          "hosts":[
            "appserver"
          ]
        },
        "database":{
          "description":"Database Server",
          "hosts":[
            "dbserver"
          ]
        },
        "lb_server":{
          "description":"Load Balancer",
          "hosts":[
            "lb_server"
          ]
        },
        "monitoring":{
          "description":"Monitoring server",
          "hosts":[
            "monitoring"
          ]
        }
      },
      "inventory_hostname":"lb_server"
    }
    import json
    from ansible.module_utils.common.json import AnsibleJSONEncoder

# Generated at 2022-06-23 10:15:05.962131
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = get_encrypted_password('testpassword', 'sha512', salt='mySalt', salt_size=8, rounds=5000, ident='$6$')
    assert password == '$6$mySalt$4k2XOQoAdV.2D1/jKq7OqGBp/u1GzIPKjNkMubzXlKFt1ZWlOCfRtD7e5BOkKELBN8QGl1Uhc5q3XBGPgvo0Z.'



# Generated at 2022-06-23 10:15:18.802988
# Unit test for function to_uuid

# Generated at 2022-06-23 10:15:26.193945
# Unit test for function to_uuid

# Generated at 2022-06-23 10:15:34.426184
# Unit test for function quote
def test_quote():
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import shlex_quote
    assert quote('{}') == shlex_quote('{}')
    assert quote('hello world') == shlex_quote('hello world')
    assert quote('" hello world"') == shlex_quote('" hello world"')
    assert quote("$PATH") == shlex_quote("$PATH")
    assert quote("'") == shlex_quote("'")
    assert quote(" ") == shlex_quote(" ")
    assert quote(None) == shlex_quote("")
    assert quote(b'{}') == shlex_quote('{}')
    assert quote(b'hello world') == shlex_quote('hello world')
    assert quote(b'" hello world"') == shlex_quote