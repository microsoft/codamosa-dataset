

# Generated at 2022-06-23 10:05:35.168721
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('a string') == 'a string'
    assert from_yaml('1') == 1
    assert from_yaml('1.0') == 1.0
    assert from_yaml('on') is True
    assert from_yaml('off') is False
    assert from_yaml('-') == '-'
    assert from_yaml('1:2:3') == [1,2,3]
    assert from_yaml('{"a":"b"}') == {"a":"b"}
    assert from_yaml(u'\u20ac') == u'\u20ac'
    assert from_yaml('a#b:c\nd:e') == ['d:e']

# Generated at 2022-06-23 10:05:45.377419
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('True') is True
    assert to_bool('False') is False
    assert to_bool('On') is True
    assert to_bool('Off') is False
    assert to_bool('Yes') is True
    assert to_bool('No') is False
   

# Generated at 2022-06-23 10:05:57.067535
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment

    jenv = JinjaEnvironment()
    # Note: The following test is not aware of possible preceding or trailing
    # whitespace, comments, etc in the string.
    result = jenv.from_string('{{ foo | groupby("bar") | list }}').render({
        'foo': [{'baz': 'baz1', 'bar': 'bar1'}, {'baz': 'baz2', 'bar': 'bar2'}, {'baz': 'baz3', 'bar': 'bar1'}]
    })
    assert result == '[[(0, {baz: baz1, bar: bar1}), (2, {baz: baz3, bar: bar1})], [(1, {baz: baz2, bar: bar2})]]'
    #

# Generated at 2022-06-23 10:06:03.064953
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall(u'abc123abc456abc', u'abc') == [u'abc', u'abc', u'abc']
    assert regex_findall(u'abc123abc456abc', u'abc', ignorecase=True) == [u'abc', u'abc', u'abc']
    assert regex_findall(u'abc123ABC456ABC', u'abc', ignorecase=False) == [u'abc']
    assert regex_findall(u'abc123ABC456ABC', u'abc', ignorecase=True) == [u'abc', u'ABC', u'ABC']



# Generated at 2022-06-23 10:06:07.657009
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='key', value_name='value')

    assert result == [
        {'value': 'bar', 'key': 'foo'},
        {'value': 'haha', 'key': 'ha'},
        {'value': 99, 'key': 'adam'},
        {'value': True, 'key': 'eve'},
        {'value': [0, 1, 2], 'key': 'april'}
    ]

    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='name', value_name='attributes')

# Generated at 2022-06-23 10:06:15.740798
# Unit test for function from_yaml
def test_from_yaml():
    '''
    >>> test_from_yaml()
    True
    '''
    # checking for https://github.com/ansible/ansible/issues/16537
    assert(from_yaml(yaml_load_all('{foo: "{{bar}}"}')) == [{'foo': '{{bar}}'}])
    assert(from_yaml("{foo: 'bar'}") == {'foo': 'bar'})
    assert(from_yaml("{foo: \"bar\"}") == {'foo': 'bar'})
    assert(from_yaml("{foo: 'bar\\''}") == {'foo': "bar'"})
    assert(from_yaml("{foo: \"bar\\\"\"}") == {'foo': 'bar"'})

# Generated at 2022-06-23 10:06:22.245511
# Unit test for function quote
def test_quote():
    assert quote(1) == u"1"
    assert quote("1") == u"1"
    assert quote("hello") == u"hello"
    assert quote('"hello"') == u'"\\"hello\\""'
    assert quote('hello world') == u'"hello world"'
    assert quote(1.1) == u"1.1"
    assert quote(1.1 + 2j) == u'"1.1+2j"'
    assert quote(u'hello') == u"hello"
    assert quote(u'\N{SNOWMAN}') == u'\N{SNOWMAN}'
    assert quote(None) == u''
    assert quote(True) == u'True'
    assert quote(False) == u'False'
    assert quote([]) == u"''"

# Generated at 2022-06-23 10:06:33.264938
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('.') == '\\.'
    assert regex_escape('.', re_type='posix_basic') == '\\.'
    assert regex_escape('.', re_type='posix_extended') == '\\.'
    # TODO: verify posix_extended for the other characters
    assert regex_escape('*') == '\\*'
    assert regex_escape('*', re_type='posix_basic') == '\\*'
    assert regex_escape('*', re_type='posix_extended') == '\\*'
    assert regex_escape('[') == '\\['
    assert regex_escape('[', re_type='posix_basic') == '\\['
    assert regex_escape('[', re_type='posix_extended') == '\\['

# Generated at 2022-06-23 10:06:42.437194
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('foo', 'foo') == ['foo']
    assert regex_findall('foo', '[a-z]+') == ['foo']
    assert regex_findall('foo', '(o)') == ['o']
    assert regex_findall('foo', 'f(o)') == ['o']
    assert regex_findall('foo', 'c(.)', multiline=True) == ['o']
    assert regex_findall('foo', 'f(o)', multiline=True) == ['o']
    assert regex_findall('foo', 'c(.)', multiline=False) == []
    assert regex_findall('foo', 'c(.)', ignorecase=True) == []
    assert regex_findall('FOO', 'f(o)', ignorecase=True) == ['o']

# Generated at 2022-06-23 10:06:48.153973
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('{foo}') == '\\{foo\\}'
    assert regex_escape('[foo]', re_type='posix_basic') == '\\[foo\\]'
    assert regex_escape('+foo+', re_type='posix_basic') == '\\+foo\\+'
    assert regex_escape('[foo]', re_type='python') == '\\\\[foo\\\\]'
    assert regex_escape('+foo+', re_type='python') == '\\\\+foo\\\\+'



# Generated at 2022-06-23 10:06:51.578980
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('this string will be encoded') == 'dGhpcyBzdHJpbmcgd2lsbCBiZSBlbmNvZGVk'
    assert b64encode('ümlaute werden auch übertragen') == 'w7xtbGVhdXRlIHdlcmRlbiBhdWNoIMO8dmVyIHTDsHJnZW4='



# Generated at 2022-06-23 10:07:01.226195
# Unit test for function regex_search
def test_regex_search():
    # Test list of matches
    matches = regex_search('abcabcabc', 'abc')
    assert matches == 'abc'

    # Test backref \\1
    matches = regex_search('abcabcabc', 'ab(c)', '\\1')
    assert len(matches) == 1 and matches[0] == 'c'

    # Test backref \\g<digit>
    matches = regex_search('abcabcabc', 'ab(?P<group>c)', '\\g<group>')
    assert len(matches) == 1 and matches[0] == 'c'

    # Test backref \\g<name>
    matches = regex_search('abcabcabc', 'ab(?P<group>c)', '\\g<group>')
    assert len(matches) == 1 and matches[0] == 'c'



# Generated at 2022-06-23 10:07:05.823696
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'foo': 'bar'}) == [{u'key': u'foo', u'value': u'bar'}]
    assert dict_to_list_of_dict_key_value_elements({'foo': 'bar', 'baz': 'qux'}) \
           == [{u'key': u'foo', u'value': u'bar'}, {u'key': u'baz', u'value': u'qux'}]



# Generated at 2022-06-23 10:07:16.795507
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    import jinja2.environment
    env = jinja2.environment.Environment()
    env.filters['groupby'] = do_groupby
    result = env.from_string('''{% for group in [
            { "ints": [1, 1, 2, 3, 4, 5] },
            { "ints": [2, 3, 4, 5, 6, 7] },
            { "ints": [3, 4, 5, 6, 7, 8] }
        ] | groupby('ints') | list %}
    {{ group }}
    {% endfor %}''').render()


# Generated at 2022-06-23 10:07:18.359376
# Unit test for function b64encode
def test_b64encode():
    result = b64encode("hello")
    assert result == "aGVsbG8="



# Generated at 2022-06-23 10:07:32.124014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters is not None
    assert len(filters) > 0


# Generated at 2022-06-23 10:07:33.735708
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None
    assert FilterModule().filters() is not None
    assert FilterModule().filters()["to_uuid"] is not None

# Generated at 2022-06-23 10:07:34.439819
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('YW55') == 'any'



# Generated at 2022-06-23 10:07:46.661204
# Unit test for function flatten
def test_flatten():
    assert flatten([0, 1, 2, 3]) == [0, 1, 2, 3]
    assert flatten([0, [1, 2], 3]) == [0, 1, 2, 3]
    assert flatten([0, [1, [2]], 3]) == [0, 1, [2], 3]
    assert flatten([0, [1, [2]], 3], levels=1) == [0, 1, [2], 3]
    assert flatten([0, [1, [2]], 3], levels=2) == [0, 1, 2, 3]
    assert flatten([0, [1, [2]], 3], levels=3) == [0, 1, 2, 3]

# Generated at 2022-06-23 10:07:58.926559
# Unit test for function randomize_list
def test_randomize_list():
    import copy
    failed = 0
    mylist = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    test_list = copy.copy(mylist)
    shuffle(test_list)
    if randomize_list(mylist) != test_list:
        failed += 1
    # empty list
    if randomize_list([]) != []:
        failed += 1
    # a list with one element
    if randomize_list([0]) != [0]:
        failed += 1
    # a list with a non-list element
    if randomize_list('cat') != 'cat':
        failed += 1
    # a non-list
    if randomize_list(123) != 123:
        failed += 1
    # a list of lists

# Generated at 2022-06-23 10:08:00.592570
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("test: 1") == dict(test=1)



# Generated at 2022-06-23 10:08:09.251513
# Unit test for function fileglob
def test_fileglob():
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    try:
        open(os.path.join(temp_dir, "test1"), "w").close()
        open(os.path.join(temp_dir, "test2"), "w").close()
        assert fileglob(os.path.join(temp_dir, "test?")) == [os.path.join(temp_dir, "test1"), os.path.join(temp_dir, "test2")], fileglob(os.path.join(temp_dir, "test?"))
    finally:
        shutil.rmtree(temp_dir)



# Generated at 2022-06-23 10:08:11.698301
# Unit test for function b64decode
def test_b64decode():
    test_value = 'aHR0cHM6Ly9hdXRoLmdvb2dsZWFwaXMuY29tL2F1dGgvZGlhbG9nL2NvbmZpcm1fc3dhbGxvdw=='
    assert b64decode(test_value) == 'https://auth.googleapis.com/auth/dialog/confirm_swallowing'



# Generated at 2022-06-23 10:08:16.268214
# Unit test for function combine
def test_combine():
    assert combine(dict(a=1,b=2), dict(b=3,c=4)) == dict(a=1,b=3,c=4)
    assert combine(dict(a=1,b=2), dict(b=3,c=4), dict(c=5,d=6)) == dict(a=1,b=3,c=5,d=6)
    assert combine(dict(a=1,b=2), dict(a=3), dict(a=4)) == dict(a=4,b=2)
    assert combine(dict(a=dict(a1=3,a2=4)), dict(a=dict(a2=6)), dict(a=dict(a1=1))) == dict(a=dict(a1=1,a2=6))

# Generated at 2022-06-23 10:08:20.448147
# Unit test for function combine

# Generated at 2022-06-23 10:08:29.734971
# Unit test for function from_yaml_all
def test_from_yaml_all():
    import yaml
    sample = '''
    test
    ---
    test2
    '''
    y = from_yaml_all(sample)
    assert isinstance(y, yaml.constructor.ConstructorError)
    sample = '''
    test
    test2
    '''
    y = from_yaml_all(sample)
    assert isinstance(y, yaml.constructor.ConstructorError)
    sample = '''---
    a: hello
    b: world
    '''
    y = from_yaml_all(sample)
    assert isinstance(y, yaml.loader.SafeLoader)
    sample = '''---
    - a: hello
      b: world
    - a: hello
      b: world
    '''
    y = from_yaml_all(sample)

# Generated at 2022-06-23 10:08:39.555237
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcd', '^abc', '\\g<0>') == 'abc'
    assert regex_search('a b c d e f', '\s[a-z]\s', '\\g<0>') == ' b '
    assert regex_search('a b c d e f', '\s[a-z]\s', '\\g<0>', ignorecase=True) == ' b '
    assert regex_search('a b c d e f', '\s[a-z]\s', '\\g<0>', ignorecase=True) == ' b '
    assert regex_search('a b c d e f', '\n.', '\\g<0>') == None

# Generated at 2022-06-23 10:08:50.242904
# Unit test for function quote
def test_quote():
    assert quote("this is a test") == "'this is a test'"
    assert quote("this is a test'") == "'this is a test\\''"
    assert quote("this is a test 'and'") == "'this is a test \\'and\\''"
    assert quote("this is a test 'and' \\\"another test\\\"") == "'this is a test \\'and\\' \\\"another test\\\"'"
    assert quote("this is a test 'and' \\\"another test\\\" \"\\\"annother one\\\"\"") == "'this is a test \\'and\\' \\\"another test\\\" \\\"\\\"annother one\\\"\\\"'"

# Generated at 2022-06-23 10:08:55.783517
# Unit test for function ternary
def test_ternary():
    assert ternary(None, 1, 2, 3) == 3
    assert ternary(False, 1, 2, 3) == 2
    assert ternary(True, 1, 2, 3) == 1
    assert ternary(0, 1, 2, 3) == 2


# Generated at 2022-06-23 10:09:01.331844
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({'a': 'A'}) == {'a': 'A'}
    assert combine({'a': 'A'}, {'a': 'B'}) == {'a': 'B'}
    assert combine({'a': 'A'}, {'b': 'B'}) == {'a': 'A', 'b': 'B'}
    assert combine({'a': 'A'}, {'a': 'B'}, {'a': 'C'}) == {'a': 'C'}
    assert combine({'a': 'A'}, {'b': 'B'}, {'c': 'C'}) == {'a': 'A', 'b': 'B', 'c': 'C'}

# Generated at 2022-06-23 10:09:10.357612
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('a') == 'a'
    assert regex_escape('a') == 'a'
    assert regex_escape('a', 'posix_basic') == 'a'
    assert regex_escape('.') == '\\.'
    assert regex_escape('.', 'posix_basic') == '\\.'
    assert regex_escape('.', 'posix_extended') == '\\.'
    assert regex_escape('[') == '\\['
    assert regex_escape('[', 'posix_basic') == '\\['
    assert regex_escape('[', 'posix_extended') == '\\['
    assert regex_escape('a$b') == 'a\\$b'
    assert regex_escape('a$b', 'posix_basic') == 'a\\$b'

# Generated at 2022-06-23 10:09:14.646660
# Unit test for function regex_findall
def test_regex_findall():
    value = 'bac123acb'
    regex = r'\w+'
    result = regex_findall(value, regex)
    assert result == ['bac', 'acb']
    # TODO: add more tests


# Generated at 2022-06-23 10:09:20.978846
# Unit test for function from_yaml_all
def test_from_yaml_all():
    input = '''
    - foo
    - bar
    - baz
    '''
    expected = [
        {'foo': None},
        {'bar': None},
        {'baz': None}
    ]

    result = from_yaml_all(input)

    assert result == expected



# Generated at 2022-06-23 10:09:31.572740
# Unit test for function to_nice_json
def test_to_nice_json():
    # Note: For these tests, we cannot use the parameter names used in the implementation
    #       of to_nice_json.  Instead we must match the parameter names in
    #       `json.dumps(<thing>, **kwargs)`.  This is because
    #       the `**kwargs` in this function is a proxy that gets passed on to json.dumps().
    #       This works well for `to_json`, but that function does not have any
    #       parameters that have the same name as `json.dumps` parameters.  So for
    #       `to_nice_json`, we have to define the test input in a different way.
    d = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-23 10:09:38.445773
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("foo bar baz") == 'foo bar baz'
    assert b64decode("YmF6Cg==") == 'baz\n'
    assert b64decode("YmF6Cg==", encoding='ISO-8859-1') == u'baz\n'
    assert b64decode("YmF6Cg==", encoding='utf-16') == u'baz\n'


# Generated at 2022-06-23 10:09:49.748183
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', time.time()) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    try:
        strftime('%Y-%m-%d %H:%M:%S', 'foo')
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-23 10:09:53.746395
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b"this is a test", 'md5') == 'c9a2d88d0eb2cffa83b8d3c8a8a8ad93'
    assert get_hash(b"this is a test", 'sha1') == 'bddd8eedd5523e65ff3ca94b3f9ff92815f967e1'
    assert get_hash(b"this is a test", 'sha224') == '51e928db8abea47770c93eba1df1b55467d8e3716c5a04b33e5c5ee'

# Generated at 2022-06-23 10:10:05.941463
# Unit test for function comment
def test_comment():
    assert comment('test') == 'test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'plain', '-- ') == '-- test'
    assert comment('test', 'cblock', '; ', prefix_count=0) == '/*\n* test\n */'
    assert comment(
        'test\nan other line',
        'cblock',
        '; ') == '/*\n; test\n; an other line\n */'
    assert comment(
        'test\nan other line',
        'cblock',
        '; ',
        decoration=' ') == '/*\n; test\n; an other line\n */'

# Generated at 2022-06-23 10:10:13.678355
# Unit test for function rand
def test_rand():
    # import locally to avoid breaking dependencies when
    # changing how this works
    try:
        from ansible.plugins.loader import filter_loader
        f = filter_loader.get('rand', want_list=True)[1]
        assert f([1, 2, 3], 2) in [1, 2, 3]
        assert f(10, 1, 5, 4) in [1, 5, 9]
        assert f(5, 1) in [1, 2, 3, 4, 5]
        assert f(5) in [0, 1, 2, 3, 4, 5]

        # FIXME: why not just raise an error?
        # with pytest.raises(AnsibleFilterError):
        #    f(5, step=0)
    except ImportError:
        pass



# Generated at 2022-06-23 10:10:19.141845
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo[bar]baz') == 'foo\\[bar\\]baz'
    assert regex_escape('foo[bar]baz', re_type='posix_basic') == 'foo\\[bar\\]baz'
    assert regex_escape('foo[bar]baz', re_type='posix_extended') == 'foo\\[bar\\]baz'



# Generated at 2022-06-23 10:10:32.298585
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # pylint: disable=unused-variable

    # default to sha512_crypt
    assert get_encrypted_password('test') == '$6$aW8UrX6Y$i6UOg1ZUWl8E2QHlhpxiU6v7zW380y8kXFz6iCpMxnFpu1dAiMhD3qT3BQ4s4EGC.9FTYiBcLfZ0iGZrj/1/RV0'

    # weird stuff

# Generated at 2022-06-23 10:10:35.425864
# Unit test for function to_nice_json
def test_to_nice_json():
    json_str = to_nice_json({'a': 1, 'b': 2})
    assert json_str == '{\n    "a": 1,\n    "b": 2\n}'


# Generated at 2022-06-23 10:10:36.766079
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:10:41.968487
# Unit test for function mandatory
def test_mandatory():
    assert NaN == NaN
    assert mandatory(1) == 1
    try:
        mandatory(Undefined())
    except AnsibleFilterError:
        pass
    else:
        raise Exception('Failed')



# Generated at 2022-06-23 10:10:46.720789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # TODO: Implement the test for the method filters of class FilterModule
    # NOTE: The following test requires that a certain environment variable be set at runtime
    # NOTE: use a value for the environment variable that is appropriate for your test
    # assert_equals(expected, FilterModule.filters(self))
    assert False # TODO: update if deemed necessary



# Generated at 2022-06-23 10:10:49.532803
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert issubclass(FilterModule, object)
    assert isinstance(FilterModule.filters(FilterModule()), dict)



# Generated at 2022-06-23 10:10:57.884737
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 'b'}) == [{'key': 'a', 'value': 'b'}]
    assert dict_to_list_of_dict_key_value_elements({'a': 'b', 'c': 'd'}) == [{'key': 'a', 'value': 'b'}, {'key': 'c', 'value': 'd'}]
    assert dict_to_list_of_dict_key_value_elements({'a': 'b', 'c': 'd'}, key_name='n', value_name='v') == [{'n': 'a', 'v': 'b'}, {'n': 'c', 'v': 'd'}]



# Generated at 2022-06-23 10:11:00.780672
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("foo.txt") == ["foo.txt"]
    assert fileglob("non_existent_file") == []



# Generated at 2022-06-23 10:11:13.162034
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # Note: if the attribute filters is defined in the class FilterModule,
    # the function test_FilterModule_filters will not be invoked at all.
    # So we don't need to care about the initialization of the class FilterModule.
    # But why?
    # For more details, see https://stackoverflow.com/questions/36869197/why-is-pytest-not-discovering-a-class-in-a-test-module
    # 
    assert isinstance(fm, FilterModule)
    assert type(fm.filters) == types.FunctionType
    assert fm.filters.__name__ == 'filters'
    assert fm.filters.__qualname__ == 'FilterModule.filters'
    assert len(fm.filters()) == 52
    assert f

# Generated at 2022-06-23 10:11:22.777607
# Unit test for function regex_findall
def test_regex_findall():
    # Test without optional parameters
    resp = regex_findall(value='This is a test', regex='t')
    assert ['t', 't', 't'] == resp
    # Test with optional parameters
    resp = regex_findall(value='This is a test', regex='t', multiline=False, ignorecase=False)
    assert ['t', 't', 't'] == resp
    resp = regex_findall(value='This is a test', regex='t', multiline=False, ignorecase=True)
    assert ['T', 't', 't'] == resp
    resp = regex_findall(value='This is a test', regex='T', multiline=False, ignorecase=True)
    assert ['T', 't', 't'] == resp

# Generated at 2022-06-23 10:11:26.640407
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([3, 2, 1], seed=2) == [1, 3, 2]
    assert randomize_list([3, 2, 1], seed=1) == [1, 3, 2]



# Generated at 2022-06-23 10:11:35.859279
# Unit test for function rand
def test_rand():
    assert rand(None, [1,2,3]) in [1,2,3]
    assert rand(None, 1, 1.9) in [1,2,3]
    assert rand(None, 1, 2, 0.9) in [1,2,3]
    assert rand(None, 2, 0, 1) in [0,2]
    assert rand(None, 2, 0, 2) in [0]
    assert rand(None, 2, 1) in [1,2]
    assert rand(None, 2) in [0,1]



# Generated at 2022-06-23 10:11:51.666473
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2

    # test simple groupby
    template = jinja2.Template('{{ value|groupby(attribute) }}')
    value = [{'attribute': 'foo', 'other': 'bar'},
             {'attribute': 'foo', 'other': 'baz'},
             {'attribute': 'bar', 'other': 'bar'}]
    assert template.render(value=value, attribute='attribute') == str([('foo', [{'attribute': 'foo', 'other': 'bar'},
                                                                               {'attribute': 'foo', 'other': 'baz'}]),
                                                                       ('bar', [{'attribute': 'bar', 'other': 'bar'}])])
    # test simple groupby
    template = jinja2.Template('{{ value|groupby(attribute) }}')


# Generated at 2022-06-23 10:11:54.784378
# Unit test for function regex_escape
def test_regex_escape():
    pass
    #assert regex_escape('no special chars') == 'no special chars'
    #assert regex_escape('[...]') == r'\[\.\.\.\]'



# Generated at 2022-06-23 10:12:04.291763
# Unit test for function ternary
def test_ternary():
    assert ternary(None, 1, 2) == 2
    assert ternary(None, 1, 2, none_val=3) == 3
    assert ternary(False, 1, 2) == 2
    assert ternary(True, 1, 2) == 1
    assert ternary(0, 1, 2) == 2
    assert ternary(1, 1, 2) == 1
    assert ternary("", 1, 2) == 2
    assert ternary("foo", 1, 2) == 1
    assert ternary("False", 1, 2) == 1
    assert ternary("True", 1, 2) == 1
    assert ternary("0", 1, 2) == 1
    assert ternary("1", 1, 2) == 1
    assert ternary(0.1, 1, 2)

# Generated at 2022-06-23 10:12:07.103369
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', 10) == '1970-01-01 00:00:10'


# Generated at 2022-06-23 10:12:16.379419
# Unit test for function rand
def test_rand():
    import pytest

# Generated at 2022-06-23 10:12:19.358425
# Unit test for function fileglob
def test_fileglob():
    pathname = 'README.md'
    assert [g for g in glob.glob(pathname) if os.path.isfile(g)] ==  fileglob(pathname)


# Generated at 2022-06-23 10:12:24.756668
# Unit test for function regex_replace
def test_regex_replace():
    from ansible.parsing.plugin_docs import get_docstring

    f = globals()['regex_replace']
    fn_args, fn_kwargs, _, _, example = get_docstring(f,
        verbose=True,
        style='google')

    assert example[0]['arguments'][0] == "'yes' in 'yes,no'"
    assert example[0]['result'] == "regex_replace(u'yes,no', '[^,]*', 'no')"


# Generated at 2022-06-23 10:12:27.510867
# Unit test for function comment
def test_comment():
    # from test_comment import test_comment
    object = list(test_comment())

    for i in object:
        result = comment(i['text'], i['style'], **i['kw'])
        assert result == i['result']
    return True



# Generated at 2022-06-23 10:12:32.933739
# Unit test for function comment
def test_comment():
    '''
    Testing function comment is done with doctest.
    To run the test, execute in the module folder,
    python -m doctest -v ansible/utils/jinja2/filters.py
    '''
    print(comment.__doc__)
    return True



# Generated at 2022-06-23 10:12:44.920407
# Unit test for function regex_search
def test_regex_search():
    # The first four tests are from the old regex_match function.
    assert regex_search('foo', 'foo')
    assert regex_search('foo', '^foo$')
    assert regex_search('abcdefghi', 'def')
    assert not regex_search('abcdefghi', '^def')
    # Testing new functionality.
    assert regex_search('foo', 'foo', '\\1')
    assert regex_search('foo', '^f(.)o$', '\\1') == ['o']
    assert regex_search('buzz foo buzz', 'foo', '\\g<1>') == ['foo']
    assert regex_search('buzz foo buzz', '(f)oo', '\\1', '\\g<1>') == ['f', 'oo']

# Generated at 2022-06-23 10:12:47.191594
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all('foo: bar') == [{'foo': 'bar'}]



# Generated at 2022-06-23 10:12:52.187810
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None

    assert to_bool('True') is True
    assert to_bool('yes') is True
    assert to_bool('1') is True

    assert to_bool('False') is False
    assert to_bool('no') is False
    assert to_bool('0') is False

    assert to_bool(1) is True
    assert to_bool(0) is False


__to_seq = partial(to_text, nonstring='passthru')



# Generated at 2022-06-23 10:13:00.047749
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    ret = to_nice_yaml([{'a': 'b', 'c': 'd'}, {'e': 'f', 'g': 'h'}])
    assert ret == \
        '- a: b\n' \
        '  c: d\n' \
        '- e: f\n' \
        '  g: h\n'



# Generated at 2022-06-23 10:13:06.652445
# Unit test for function regex_escape
def test_regex_escape():
    test_data = [('abc', 'abc'),
                 ('abc.def', 'abc\.def'),
                 ('abc[def', r'abc\[def'),
                 ('abc(def', r'abc\(def'),
                 ('abc$def', r'abc\$def'),
                 ('abc*def', r'abc\*def'),
                 ('abc$*def', r'abc\$\*def'),
                 ('abc\\def', r'abc\\def')]
    for (input, expected) in test_data:
        actual = regex_escape(input)
        assert actual == expected


# Generated at 2022-06-23 10:13:18.424215
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('True') is True
    assert to_bool('False') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool([]) is False
    assert to_bool('') is False
    assert to_bool(None) is None
    assert to_bool('None') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool('[1,2,3]') is False

# Generated at 2022-06-23 10:13:29.532888
# Unit test for function from_yaml

# Generated at 2022-06-23 10:13:30.433115
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("Hello World", pattern='World', replacement='Galaxy') == "Hello Galaxy"


# Generated at 2022-06-23 10:13:38.869261
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    undef = Undefined('test')
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(None) is None
    assert mandatory(undef) == undef
    try:
        mandatory(undef, 'foo')
        assert False
    except AnsibleFilterError as e:
         assert str(e) == 'foo'
    try:
        mandatory(undef)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'test' not defined."
    try:
        mandatory(undef, msg='foo')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'foo'



# Generated at 2022-06-23 10:13:41.508073
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-23 10:13:52.506219
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('Yes') is True
    assert to_bool('yes') is True
    assert to_bool('YES') is True
    assert to_bool('1') is True
    assert to_bool('True') is True
    assert to_bool('true') is True
    assert to_bool('TRUE') is True
    assert to_bool(True) is True
    assert to_bool('No') is False
    assert to_bool('no') is False
    assert to_bool('NO') is False
    assert to_bool('0') is False
    assert to_bool('False') is False
    assert to_bool('false') is False
    assert to_bool('FALSE') is False
    assert to_bool(False) is False



# Generated at 2022-06-23 10:14:00.513175
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from collections import OrderedDict
    from ansible.module_utils._text import to_bytes
    list_ordered_dict = [
        OrderedDict([('a', ['b'])]),
        OrderedDict([('c', ['d']), ('e', ['f'])])
    ]
    assert yaml.safe_load(to_nice_yaml(list_ordered_dict)) == list_ordered_dict



# Generated at 2022-06-23 10:14:09.813539
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value=u'abc123abc', pattern='123', replacement='X') == 'abcXabc'
    assert regex_replace(value=u'abc123abc', pattern='x', replacement='X') == 'abc123abc'
    assert regex_replace(value=u'abc123abc', pattern=r'\b', replacement='X') == 'Xabc123abcX'
    assert regex_replace(value=u'abc123abc', pattern=r'\b', replacement='X', multiline=False) == 'Xabc123abcX'
    assert regex_replace(value=u'abc123abc', pattern=r'\B', replacement='X') == 'abc123abc'

# Generated at 2022-06-23 10:14:12.646803
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('hello: world') == {'hello': 'world'}


# Generated at 2022-06-23 10:14:23.413375
# Unit test for function rand
def test_rand():
    import types
    env = {}
    seq = [1, 2, 3, 4]

    for i in range(0, 1000):
        rand_value = rand(env, 10, 1, 3)
        assert rand_value % 3 == 1
        assert rand_value >= 1
        assert rand_value <= 10

        rand_value = rand(env, 10, step=3)
        assert rand_value % 3 == 0
        assert rand_value >= 0
        assert rand_value <= 9

        rand_value = rand(env, 10)
        assert rand_value >= 0
        assert rand_value <= 9

        rand_value = rand(env, seed=1234, end=10)
        assert rand_value == 3

        rand_value = rand(env, seq)
        assert rand_value in seq


# Generated at 2022-06-23 10:14:24.447356
# Unit test for function do_groupby
def test_do_groupby():
    """
    Test for do_groupby in ansible.utils.unsafe_proxy
    """
    assert True


# Generated at 2022-06-23 10:14:28.760183
# Unit test for function fileglob
def test_fileglob():
    assert len(fileglob('filter_plugins/*')) == len([g for g in glob.glob('filter_plugins/*') if os.path.isfile(g)])



# Generated at 2022-06-23 10:14:41.089817
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('foo bar') == '1fadc7cf-e240-590b-9e29-ddd61bc56f4c'
    assert to_uuid('foo bar', "361e6d51-faec-444a-9079-341386da8e2e") == '1fadc7cf-e240-590b-9e29-ddd61bc56f4c'
    assert to_uuid('foo bar', uuid.UUID("361e6d51-faec-444a-9079-341386da8e2e")) == '1fadc7cf-e240-590b-9e29-ddd61bc56f4c'

# Generated at 2022-06-23 10:14:45.549422
# Unit test for function to_datetime
def test_to_datetime():
    assert 'datetime.datetime(2014, 6, 12, 0, 0)' == str(to_datetime('2014-06-12 00:00:00'))


# Generated at 2022-06-23 10:14:55.257331
# Unit test for function comment
def test_comment():
    test_comment_plain = """
# Lines after the decorator
# should be indented by one space
# or two spaces.

#  - The decorator itself
#    should not be indented,
#    even though the line below is.
#
#  - The empty lines below the decorator
#    should also be indented
#    as the lines above."""


# Generated at 2022-06-23 10:15:05.046106
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-05-21 16:11:22", format="%Y-%m-%d %H:%M:%S") == \
            datetime.datetime(2018, 5, 21, 16, 11, 22)
    assert to_datetime("2018-05-21", format="%Y-%m-%d") == \
            datetime.datetime(2018, 5, 21)
    assert to_datetime("21-05-18", format="%d-%m-%y") == \
            datetime.datetime(2018, 5, 21)
    assert to_datetime("21:11:22", format="%H:%M:%S") == \
            datetime.datetime(1900, 1, 1, 21, 11, 22)



# Generated at 2022-06-23 10:15:07.816494
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t1 = bool(1)
    assert t1 == "True"
    t2 = md5s("password")
    assert t2 == "5f4dcc3b5aa765d61d8327deb882cf99"


# Generated at 2022-06-23 10:15:20.304467
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    # empty input
    assert not list_of_dict_key_value_elements_to_dict([])

    # input containing an element with the wrong keys
    assert not list_of_dict_key_value_elements_to_dict([{'wrong': 'value'}])
    assert not list_of_dict_key_value_elements_to_dict([{'wrong': 'value', 'key': 'value'}])
    assert not list_of_dict_key_value_elements_to_dict([{'wrong': 'value', 'value': 'value'}])

    # input containing an element with the wrong value types
    assert not list_of_dict_key_value_elements_to_dict([{'key': 'value', 'value': object()}])

    # basic test

# Generated at 2022-06-23 10:15:31.507060
# Unit test for function regex_findall
def test_regex_findall():
    assert not regex_findall("test", ".*")
    assert regex_findall("test", ".*", multiline=True) == ["test"]
    assert regex_findall("test", "(?P<test>tes)", multiline=True) == ["tes"]
    assert regex_findall("test", "(?P<test>tes)", multiline=True,
                         ignorecase=True) == ["tes"]
    assert regex_findall("*", "\\*", multiline=True) == ["*"]
    assert regex_findall("a b c", "\s") == [" ", " "]
    assert regex_findall("a b c", "\s", multiline=True) == [" ", " ", " "]