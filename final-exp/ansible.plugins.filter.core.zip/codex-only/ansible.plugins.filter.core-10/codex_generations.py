

# Generated at 2022-06-23 10:05:31.580526
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(b"hello \t world") == "aGVsbG8gICB3b3JsZA=="
    assert b64encode("hello \t world") == "aGVsbG8gICB3b3JsZA=="
    assert b64encode(u"hello \t world") == "aGVsbG8gICB3b3JsZA=="


# Generated at 2022-06-23 10:05:39.539567
# Unit test for function combine
def test_combine():
    # Test flat dict merging
    dict1 = {'foo': 'bar'}
    dict2 = {'foo': 'baz'}
    dict3 = {'foo': 'baz'}
    dict4 = {'abc': 'xyz'}
    assert combine(dict1, dict2, dict3, dict4) == {'foo': 'baz', 'abc': 'xyz'}

    dict5 = {'a': {'b': '1'}}
    dict6 = {'a': {'c': '2'}}
    assert combine(dict5, dict6) == {'a': {'b': '1', 'c': '2'}}

    dict7 = {'a': {'b': '1'}}
    dict8 = {'a': '2'}

# Generated at 2022-06-23 10:05:51.770163
# Unit test for function subelements
def test_subelements():
    import os
    import sys

    THIS_DIR = os.path.dirname(os.path.realpath(__file__))
    ansible_path = os.path.join(THIS_DIR, os.pardir, os.pardir)
    test_path = os.path.join(THIS_DIR, os.path.basename(os.path.splitext(__file__)[0]))

    sys.path.append(ansible_path)
    from lib.tests.unit import AnsibleModuleTestCase

    module = __import__(test_path, globals(), locals()).SubelementsTest()
    module.squelch = True
    module.run()


# Generated at 2022-06-23 10:05:58.883852
# Unit test for function rand
def test_rand():
    seed1 = 42
    seed2 = 'foo'
    assert rand([], 1, seed=seed1) == 0
    assert rand([], 1, 0, 1, seed=seed1) == 0
    assert rand([], 1, 0, 2, seed=seed1) == 0
    assert rand([], 4, 1, 1, seed=seed1) == 1
    assert rand([], 3, 0, 3, seed=seed1) == 0
    assert rand([], 2, 0, 2, seed=seed1) == 0

    assert rand([], 1, seed=seed2) == 0
    assert rand([], 1, 0, 1, seed=seed2) == 0
    assert rand([], 1, 0, 2, seed=seed2) == 0
    assert rand([], 4, 1, 1, seed=seed2) == 1
    assert rand

# Generated at 2022-06-23 10:06:04.917610
# Unit test for function from_yaml
def test_from_yaml():
    from_yaml_result = from_yaml('{"foo": "bar"}')
    assert from_yaml_result == {"foo": "bar"}, 'from_yaml returned incorrect data'
    from_yaml_result = from_yaml(data={"foo": "bar"})
    assert from_yaml_result == {"foo": "bar"}, 'from_yaml returned incorrect data'
    from_yaml_result = yaml_load(data={"foo": "bar"})
    assert from_yaml_result is None, 'from_yaml returned incorrect data'


# Generated at 2022-06-23 10:06:13.579033
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2, 'c': 3}, {'c': 4}) == {'a': 1, 'b': 2, 'c': 4}
    assert combine({'a': 1, 'b': 2, 'c': 3}, {'d': 4}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'b': 3, 'c': 4}, {'a': 1, 'b': 2}) == {'a': 1, 'b': 2, 'c': 4}

# Generated at 2022-06-23 10:06:20.090771
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Testing filter type 'groupby'
# Case: Request to filter type 'groupby' is passed to function '_do_groupby'

# Generated at 2022-06-23 10:06:31.623542
# Unit test for function quote
def test_quote():
    assert quote('foo bar') == 'foo\\ bar'
    assert quote(u'foo bar') == 'foo\\ bar'
    assert quote(u'echo "foo bar"') == 'echo\\ \\"foo\\ bar\\"'
    assert quote(u'echo "Foo Bar"') == 'echo\\ \\"Foo\\ Bar\\"'
    assert quote(u'sudo echo "Foo Bar"') == 'sudo\\ echo\\ \\"Foo\\ Bar\\"'
    assert quote(u'sudo echo "foo bar"') == 'sudo\\ echo\\ \\"foo\\ bar\\"'
    assert quote(u"sudo echo 'foo bar'") == "sudo\\ echo\\ 'foo\\ bar'"
    assert quote(u'foo bar') == 'foo\\ bar'
    assert quote(u"foo bar") == "foo\\ bar"

# Generated at 2022-06-23 10:06:38.025494
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(b'FOO') == b'Rk9P'
    assert b64encode('FOO') == b'Rk9P'
    assert b64encode(42) == 'NDI='
    assert b64encode(42, encoding='ascii') == 'NDI='
    assert b64encode(u'FOO') == b'Rk9P'
    assert b64encode(u'FAHRTÉN') == b'RkFIRlTDrQ=='
    assert b64encode(u'FAHRTÉN', encoding='latin-1') == b'RkFIRlTDrQ=='

# Generated at 2022-06-23 10:06:48.448435
# Unit test for function get_hash
def test_get_hash():
    # Test default hash type
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    # Test SHA256 hash type
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    # Test invalid hash type
    try:
        get_hash('test', 'sha224')
        assert False
    except AnsibleFilterError as e:
        assert 'unknown hash type' in str(e)
    # Test non-string data (list)

# Generated at 2022-06-23 10:06:53.660692
# Unit test for function from_yaml
def test_from_yaml():
    # x: a non-ascii character which requires utf-8 encoding
    data = u'{ x: ö }'
    # Ensure the wrapper and encoding are removed
    assert from_yaml(data).get('x') == u'ö'



# Generated at 2022-06-23 10:06:59.675553
# Unit test for function rand
def test_rand():
    result = rand(end=10)
    assert(isinstance(result, integer_types))
    assert(0 <= result <= 10)
    # python randrange() doesn't accept float
    result = rand(end=10.0)
    assert(isinstance(result, integer_types))
    assert(0 <= result <= 10)
    assert(rand(end=10, step=2) % 2 == 0)
    assert(rand(end=[3, 2, 1]) in [3, 2, 1])



# Generated at 2022-06-23 10:07:02.680593
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel']}, 'wheel')]



# Generated at 2022-06-23 10:07:08.195727
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    mylist1 = randomize_list(mylist, seed=123)
    mylist2 = randomize_list(mylist, seed=123)
    mylist3 = randomize_list(mylist, seed=124)
    assert mylist1 == mylist2
    assert mylist1 != mylist3



# Generated at 2022-06-23 10:07:19.137442
# Unit test for function to_uuid
def test_to_uuid():
    from ansible.module_utils.six import PY3
    assert to_uuid('foo') == '4be3d920-7515-59fd-8a7e-d04d9e7162bb'
    if PY3:
        assert to_uuid('foo', None) == '4be3d920-7515-59fd-8a7e-d04d9e7162bb'
    assert to_uuid('foo', '00000000-0000-0000-0000-000000000000') == '57f9519a-109c-569e-a1d7-d14b6e9fe6f0'

# Generated at 2022-06-23 10:07:25.911552
# Unit test for function flatten
def test_flatten():
    mylist = [1, 2, [3, 4, 5, [6, 7, 8]]]
    result = flatten(mylist)
    assert result == [1, 2, 3, 4, 5, 6, 7, 8], "expected %s, got %s" % ([1, 2, 3, 4, 5, 6, 7, 8], result)



# Generated at 2022-06-23 10:07:35.920058
# Unit test for function regex_search
def test_regex_search():
    ''' Return a string '''
    assert regex_search('abc123', '\d') == '1'
    assert regex_search('abc123', '\d', '\\g<1>') == ['1', '1']
    assert regex_search('abc123', '\d', '\\1') == ['1']
    assert regex_search('abc123', '\d', '\\g<a>') == ['1']
    assert regex_search('abc123', '\d', '\\13') == ['3']
    assert regex_search('abc123', '\d', '\\g<1>', '\\g<1>') == ['1', '1']
    assert regex_search('abc123', '\d', '\\g<1>', '\\g<13>') == ['1', '3']
    assert regex_search

# Generated at 2022-06-23 10:07:37.578711
# Unit test for function b64decode
def test_b64decode():
    input_data = {'bWFjOiR7bmFtZX0='}
    expected_data = {'mac:$name'}
    output_data = b64decode(*input_data)
    assert expected_data == output_data



# Generated at 2022-06-23 10:07:48.260562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    ''' Unit test for method filters of class FilterModule
    '''
    from nose import SkipTest
    from nose.tools import assert_equal, assert_true
    if jinja2 is None:
        raise SkipTest("missing jinja2")

    f = FilterModule()

    assert_equal('string', f.filters()['type_debug'](u'string'))

    assert_equal("foo", f.filters()['env']('FOO'))

    assert_equal("foo", f.filters()['env']('FOO', 'bar'))

    assert_equal("bar", f.filters()['env']('NOTFOO', 'bar'))

    assert_equal("bar", f.filters()['env']('NOTFOO', 'bar'))


# Generated at 2022-06-23 10:08:01.009222
# Unit test for function to_yaml
def test_to_yaml():
    assert isinstance(to_yaml({'a': 'b'}), text_type)
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml(['a', 'b']) == '- a\n- b\n'

# Generated at 2022-06-23 10:08:10.483107
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo?') == 'foo\?'
    assert regex_escape('foo*') == 'foo\*'
    assert regex_escape('foo+') == 'foo\+'
    assert regex_escape('foo{}') == 'foo\{\}'
    assert regex_escape('foo[bar]') == 'foo\[bar\]'
    assert regex_escape('foo(bar)') == 'foo\(bar\)'
    assert regex_escape('foo.bar') == 'foo\.bar'
    assert regex_escape('foo\\bar') == 'foo\\\\bar'
    assert regex_escape('foo^bar') == 'foo\^bar'
    assert regex_escape('foo$bar') == 'foo\$bar'
    assert regex_escape('foo|bar') == 'foo\|bar'

# Generated at 2022-06-23 10:08:23.318745
# Unit test for function rand
def test_rand():
    sequence_list = [
        [1,2,3,4,5],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6,7],
        [1,2,3,4,5,6,7,8],
        [1,2,3,4,5,6,7,8,9],
    ]
    sequence_step_list = [1,2,3,4]
    sequence_start_end_list = [
        (100,120),
        (100,130),
        (100,140),
        (100,150),
    ]
    seed_list = [
        '1',
        '2',
        '3',
        '4',
        '5',
    ]


# Generated at 2022-06-23 10:08:35.350893
# Unit test for function to_json
def test_to_json():
    json.dumps(None)
    assert to_json(None) == None

    json.dumps(False)
    assert to_json(False) == False

    json.dumps(True)
    assert to_json(True) == True

    json.dumps(0)
    assert to_json(0) == 0

    json.dumps(1)
    assert to_json(1) == 1

    json.dumps(123)
    assert to_json(123) == 123

    json.dumps(1.1)
    assert to_json(1.1) == 1.1

    json.dumps(1.5)
    assert to_json(1.5) == 1.5

    json.dumps(123.5)
    assert to_json(123.5) == 123.5

   

# Generated at 2022-06-23 10:08:36.858417
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    assert o.filters()

# Generated at 2022-06-23 10:08:39.810397
# Unit test for function to_json
def test_to_json():
    d = {"somekey": "somevalue"}
    assert to_json(d) == '{"somekey": "somevalue"}'



# Generated at 2022-06-23 10:08:46.188559
# Unit test for function path_join
def test_path_join():
    paths = ['/etc/ansible', 'roles', 'foo.yaml']
    assert path_join(paths) == '/etc/ansible/roles/foo.yaml'
    paths = ('/etc/ansible', 'roles', 'foo.yaml')
    assert path_join(paths) == '/etc/ansible/roles/foo.yaml'
    paths = '/etc/ansible/roles/foo.yaml'
    assert path_join(paths) == '/etc/ansible/roles/foo.yaml'
    paths = 2
    try:
        path_join(paths)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "should throw AnsibleFilterTypeError exception"


# Generated at 2022-06-23 10:08:48.791784
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    undef = Undefined(name="foo")
    assert(undef is mandatory(undef))



# Generated at 2022-06-23 10:09:01.213964
# Unit test for function regex_escape
def test_regex_escape():
    my_string = r'What\nwhen.why*+^$?()|[]{}-'

# Generated at 2022-06-23 10:09:07.537890
# Unit test for function fileglob
def test_fileglob():
    # Test glob
    assert fileglob("hello.py") == ["hello.py"], "file globbing error"
    # Test match
    assert fileglob("hello.py") != ["hello.py", "hello2.py"], "file globbing error"
    # Test non-match
    assert fileglob("hello2.py") != ["hello.py"], "file globbing error"
    # Test empty return
    assert fileglob("hello3.py") == [], "file globbing error"


# Generated at 2022-06-23 10:09:15.639772
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2001-08-01 12:00:00', '%Y-%m-%d %H:%M:%S') \
           == datetime.datetime(2001, 8, 1, 12, 0, 0)
    try:
        to_datetime('2001-13-01', '%Y-%m-%d')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')


# Generated at 2022-06-23 10:09:28.521734
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 2, 3) == 2, 'Value is True'
    assert ternary(0, 2, 3) == 3, 'Value is False'
    assert ternary("test", 2, 3) == 2, 'Value is non-empty string'
    assert ternary("", 2, 3) == 3, 'Value is an empty string'
    assert ternary([], 2, 3) == 2, 'Value is an empty list'
    assert ternary(None, 2, 3) == 3, 'Value is None'
    assert ternary(None, 2, 3, 'hello') == 'hello', 'Value is None with default value'
    assert ternary(0, 2, 3, 'hello') == 3, 'Value is False with default value'

# Generated at 2022-06-23 10:09:36.530445
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    u = Undefined(name='bar')

    try:
        mandatory(u)
    except AnsibleFilterError:
        pass
    else:
        assert False, "Mandatory failed to fail."

    try:
        mandatory(u, 'Custom error message.')
    except AnsibleFilterError as e:
        if e.message != 'Custom error message.':
            assert False, "Mandatory failed to fail with custom message."
    else:
        assert False, "Mandatory failed to fail."

    try:
        mandatory()
    except AnsibleFilterError as e:
        if e.message != "Mandatory variable '<no-name>' not defined.":
            assert False, "Mandatory failed to fail with default message."

# Generated at 2022-06-23 10:09:42.826825
# Unit test for function get_encrypted_password
def test_get_encrypted_password():

    # Test that we handle options that are not supported by passlib
    # Such as the number of rounds for sha256/sha512.
    # TODO:  Add more examples and an exception for rounds for MD5.
    password = 'password'
    salt = 'salt'
    rounds = 5000
    assert get_encrypted_password(password, hashtype='sha256', salt=salt, rounds=5) == get_encrypted_password(password, hashtype='sha256', salt=salt, rounds=5000)
    assert get_encrypted_password(password, hashtype='sha512', salt=salt, rounds=5) == get_encrypted_password(password, hashtype='sha512', salt=salt, rounds=5000)
    assert get_encrypted_password(password, hashtype='sha256', salt=salt, rounds=5) != get_

# Generated at 2022-06-23 10:09:54.699981
# Unit test for function comment
def test_comment():
    for k in comment_styles:
        s = comment_styles[k]
        assert comment('test', k) == s['beginning'] + '\n' + s['decoration'] + 'test\n' + s['end']
    assert comment('test', 'cblock', decoration='  =  ') == '/**\n *   =  test\n */'
    assert comment('test', 'cblock', end='', decoration='  =  ') == '/**\n *   =  test'
    assert comment('test', 'cblock', beginning='', decoration='  =  ') == ' *   =  test\n */'
    assert comment('test', 'cblock', beginning='', end='', decoration='  =  ') == ' *   =  test'

# Generated at 2022-06-23 10:10:01.648743
# Unit test for function b64decode
def test_b64decode():
  a = "aGVsbG8="
  b = "aGVsbG8="
  c = "d29ybGQ="
  d = "aGVsbG8=d29ybGQ="
  e = "aGVsbG8gd29ybGQ="
  f = "d29ybGQaGVsbG8="
  g = "d29ybGQgaGVsbG8="

  assert b64decode(b) == "hello"
  assert b64decode(d) == "hello"
  assert b64decode(e) == "hello world"
  assert b64decode(f) == "worldhello"
  assert b64decode(g) == "world hello"
  assert b64decode(b+c) == "helloworld"

# Generated at 2022-06-23 10:10:07.669923
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # test normal correct input
    assert from_yaml_all("""
    - foo: 1
    - bar: 2
    """) == [{'foo': 1}, {'bar': 2}]
    # test empty string
    assert from_yaml_all("") is None
    # test invalid YAML
    with pytest.raises(AnsibleFilterError):
        from_yaml_all("{foo: bar}")
    # test non string input
    assert from_yaml_all([]) == []



# Generated at 2022-06-23 10:10:16.439791
# Unit test for function from_yaml_all
def test_from_yaml_all():
    stream = '''
- foo: bar
- foo: baz
'''
    objects = from_yaml_all(stream)
    assert isinstance(objects, list)
    assert len(objects) == 2
    assert isinstance(objects[0], Mapping)
    assert isinstance(objects[1], Mapping)
    assert objects[0]['foo'] == 'bar'
    assert objects[1]['foo'] == 'baz'



# Generated at 2022-06-23 10:10:22.527424
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('hello world', '(\w+) (\w+)', '\\2 \\1') == 'world hello'
    assert regex_replace('hello world', '(\w+) (\w+)', '\\2 \\1', ignorecase=True) == 'world hello'
    assert regex_replace('hello world', '(\w+) (\w+)', '\\2 \\1', multiline=True) == 'world hello'
    assert regex_replace('hello world', '(\w+) (\w+)', '\\2 \\1', ignorecase=True, multiline=True) == 'world hello'



# Generated at 2022-06-23 10:10:33.376756
# Unit test for function to_datetime
def test_to_datetime():
    dt = to_datetime('2016-03-03 10:31:00')
    assert dt.year == 2016
    assert dt.month == 3
    assert dt.day == 3
    assert dt.hour == 10
    assert dt.minute == 31
    assert dt.second == 0

    # Test the format: %Y-%m-%d %H:%M:%S
    dt = to_datetime('2016-03-03T10:31:00Z')
    assert dt.year == 2016
    assert dt.month == 3
    assert dt.day == 3
    assert dt.hour == 10
    assert dt.minute == 31
    assert dt.second == 0

    # Test the format: %Y-%m-%dT%H:%M:%SZ

# Generated at 2022-06-23 10:10:40.767754
# Unit test for function fileglob
def test_fileglob():
    assert ['README.md'] == fileglob('README.md')
    assert ['README.md'] == fileglob('./README.md')
    assert ['README.md'] == fileglob('tests/files/fileglob/README.md')
    assert ['README.md'] == fileglob('tests/files/fileglob/README.md/')
    assert ['README.md'] == fileglob('tests/files/fileglob/README.md/foo.txt')
    assert [] == fileglob('tests/files/fileglob/README.md/fileglob')



# Generated at 2022-06-23 10:10:46.205673
# Unit test for function to_json
def test_to_json():
    assert to_json(["foo", None, 12, 12.2]) == '["foo", null, 12, 12.2]'
    # ensure that json encoding occurs recursively
    assert to_json({"a": ["foo", None, 12, 12.2]}) == '{"a": ["foo", null, 12, 12.2]}'



# Generated at 2022-06-23 10:10:51.093669
# Unit test for function randomize_list
def test_randomize_list():
    mylist = randomize_list([1, 2, 3, 4])
    assert mylist is not [1, 2, 3, 4]
    # Test seed
    mylist = randomize_list([1, 2, 3, 4], seed=10)
    assert mylist == [3, 1, 2, 4]



# Generated at 2022-06-23 10:10:54.496649
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(yaml_load(u'[ {a: 1} ]')) == [{u'a': 1}]
    assert from_yaml(to_text(u'[ {a: 1} ]')) == [{u'a': 1}]



# Generated at 2022-06-23 10:10:59.758566
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('AQID') == "1"
    assert b64decode('YQID') == "a1"
    assert b64decode('AQM=') == "1"
    assert b64decode('YQ==') == "a"



# Generated at 2022-06-23 10:11:11.835048
# Unit test for function from_yaml
def test_from_yaml():
    # Test that from_yaml handles various yaml types correctly:
    class FromYamlTest(object):
        def __init__(self, data, expected):
            self.data = data
            self.expected = expected

    test_cases = [FromYamlTest('foo', 'foo'),
                  FromYamlTest('"foo"', 'foo'),
                  FromYamlTest('123', 123),
                  FromYamlTest('[1, 2, 3]', [1, 2, 3]),
                  FromYamlTest('{"foo": "bar"}', {'foo': 'bar'}),
    ]

    for test_case in test_cases:
        result = from_yaml(test_case.data)

# Generated at 2022-06-23 10:11:21.029338
# Unit test for function regex_replace
def test_regex_replace():
    str_val = to_text('1.2.3.4', errors='surrogate_or_strict', nonstring='simplerepr')
    ipv4_pattern = r'(?:\d{1,3}\.){3}\d{1,3}'
    rv = regex_replace(value=str_val, pattern=ipv4_pattern, replacement=to_text('0.0.0.0'), ignorecase=False, multiline=False)
    if rv != to_text('0.0.0.0'):
        raise AnsibleFilterError('regex_replace returned (%s) expected 0.0.0.0' % rv)
    return True

# Generated at 2022-06-23 10:11:33.946218
# Unit test for function comment
def test_comment():
    assert(comment('') == '# \n')
    assert(comment('', end='EOF') == '# \nEOF')
    assert(comment('', prefix='* ') == '# * \n')
    assert(comment('', prefix='* ', end='EOF') == '# * \nEOF')
    assert(comment('', prefix='* ', end='EOF', newline='\r') == '# * \rEOF')
    assert(comment('', prefix='* ', end='EOF', newline='\r\n') == '# * \r\nEOF')
    assert(comment('', prefix='- ', postfix='-', prefix_count=3, postfix_count=2, end='EOF') == '# - \n# - \n# - \n-EOF')

# Generated at 2022-06-23 10:11:35.547561
# Unit test for function path_join
def test_path_join():
    assert path_join(['/path', 'to', 'file']) == '/path/to/file'
    assert path_join('/path/to/file') == '/path/to/file'



# Generated at 2022-06-23 10:11:49.337992
# Unit test for function regex_search
def test_regex_search():
    '''
    Unit test for function regex_search
    '''
    assert regex_search('abcdef', r'^abc', '\\g<1>') == 'A'
    assert regex_search('abcdef', r'^abc', '\\g<1>', '\\3') == ['A', 'D']
    assert regex_search('abcdef', r'^abc', '\\1') == 'A'
    assert regex_search('abcdef', r'^abc') == 'abc'
    assert regex_search('abcdef', r'^abc', '\\g<9>') == None



# Generated at 2022-06-23 10:11:54.585431
# Unit test for function extract
def test_extract():
    assert extract([1, 2, 3, 4], 1) == 2
    assert extract([{'a': 1}, {'b': 2}, {'c': 3}], {'b': 2}, 'b') == 2
    assert extract([{'a': 1}, {'b': 2}, {'c': 3}], {'b': 2}, 'b', 'b') == 2
    assert extract(['a'], 'a', [{'a': 1}, {'b': 2}, {'c': 3}]) == 1
    assert extract('a', 'a', {'a': 1, 'b': 2, 'c': 3}) == 1



# Generated at 2022-06-23 10:11:59.794643
# Unit test for function strftime
def test_strftime():
    '''strftime (%Y-%m-%d %H:%M:%S) = %Y-%m-%d %H:%M:%S'''
    assert strftime('%Y-%m%d %H:%M:%S') == time.strftime('%Y-%m%d %H:%M:%S', time.localtime())



# Generated at 2022-06-23 10:12:12.442545
# Unit test for function rand
def test_rand():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)


# Generated at 2022-06-23 10:12:17.914192
# Unit test for function do_groupby

# Generated at 2022-06-23 10:12:26.716159
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape("a/b?d.e(f)g[h]i\\j^k{l}m-n+o=p_q$r!s'u~v*w|x:y<z>A0B1C2D3E4F5G6H7I8J9K#L&M") == "a\\/b\\?d\.e\\(f\\)g\\[h\\]i\\\\j\\^k\\{l\\}m\\-n\\+o\\=p\\_q\\$r\\!s\\'u\\~v\\*w\\|x\\:y\\<z\\>A0B1C2D3E4F5G6H7I8J9K\\#L\\&M"

# Generated at 2022-06-23 10:12:36.421699
# Unit test for function to_yaml
def test_to_yaml():
    d = {1: 0, 2: 8, 5: [1, 2, 3, 4]}
    assert to_yaml(d) == "1: 0\n2: 8\n5:\n  - 1\n  - 2\n  - 3\n  - 4\n"
    assert to_yaml(d, default_flow_style=False) == "1: 0\n2: 8\n5:\n- 1\n- 2\n- 3\n- 4\n"
    assert to_yaml(d, default_flow_style=True) == "{1: 0, 2: 8, 5: [1, 2, 3, 4]}"


# Generated at 2022-06-23 10:12:47.819994
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    assert dict_to_list_of_dict_key_value_elements(mydict) == [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}, {'key': 'key3', 'value': 'value3'}]
    assert dict_to_list_of_dict_key_value_elements(mydict, key_name='name', value_name='value') == [{'name': 'key1', 'value': 'value1'}, {'name': 'key2', 'value': 'value2'}, {'name': 'key3', 'value': 'value3'}]
    assert dict_to_list_

# Generated at 2022-06-23 10:12:52.187504
# Unit test for function fileglob
def test_fileglob():
    pathname = '/etc/*.conf'
    actual = fileglob(pathname)
    assert isinstance(actual, list)
    assert len(actual) > 0
    assert all(os.path.isfile(path) for path in actual)
    assert all(path.endswith('.conf') for path in actual)



# Generated at 2022-06-23 10:13:03.184217
# Unit test for function to_nice_json
def test_to_nice_json():
    test_data = {'name': 'test', 'data': [{'ids': [1,2,3]}, {'ids': [4,5,6]}]}
    r = to_nice_json(test_data)
    assert r == '{\n    "data": [\n        {\n            "ids": [\n                1,\n                2,\n                3\n            ]\n        },\n        {\n            "ids": [\n                4,\n                5,\n                6\n            ]\n        }\n    ], \n    "name": "test"\n}'


# Generated at 2022-06-23 10:13:16.299860
# Unit test for function ternary
def test_ternary():
    assert ternary(value=0, true_val='t', false_val='f', none_val='n') == 'f'
    assert ternary(value=1, true_val='t', false_val='f', none_val='n') == 't'
    assert ternary(value=None, true_val='t', false_val='f', none_val='n') == 'n'
    assert ternary(value='', true_val='t', false_val='f') == 'f'
    assert ternary(value='', true_val='t', false_val='f', none_val='n') == 'f'
    assert ternary(value=' ', true_val='t', false_val='f') == 'f'

# Generated at 2022-06-23 10:13:19.580942
# Unit test for function regex_escape
def test_regex_escape():
    import doctest
    doctest.testmod(verbose=True)

_PASSWORD_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

# Generated at 2022-06-23 10:13:32.256147
# Unit test for function do_groupby
def test_do_groupby():
    # To test this we need to inject a mock environment
    # as the function is a filter
    class Environment(object):
        @staticmethod
        def getitem(value, item):
            return value[item]
    env = Environment()
    node = Mock()
    node.name = 'GroupbyTest'

    # Test a dataset from the Ansible User Module

# Generated at 2022-06-23 10:13:33.325426
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:13:38.543887
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.environment import Environment
    from jinja2 import meta

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText as unsafe
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    templar = Templar(loader=None, shared_loader_obj=None)

    env = Environment(extensions=['jinja2.ext.do'])

    source = dedent('''
    {% set seq = [
    {% for i in range(3) %}
        {'v': {{ i }}}
    {% endfor %}
    ] %}
    {{ seq | groupby('v') | list }}
    ''')

    parsed_content = env.parse(source)

# Generated at 2022-06-23 10:13:43.100313
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'foo', 'value': 'bar'},
                                                    {'key': 'baz', 'value': 'qux'}]) == {'foo': 'bar', 'baz': 'qux'}



# Generated at 2022-06-23 10:13:48.610659
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', 1457123456) == '2016-03-08'
    assert strftime('%F', '1457123456') == '2016-03-08'
    assert strftime('%FT%TZ', 1457123456) == '2016-03-08T01:24:16Z'



# Generated at 2022-06-23 10:13:52.504275
# Unit test for function to_yaml
def test_to_yaml():
    c = dict(a="foo",b="bar",c=dict(baz="qux"))
    assert to_yaml(c) == "a: foo\nb: bar\nc:\n  baz: qux\n"


# Generated at 2022-06-23 10:14:05.439880
# Unit test for function extract
def test_extract():
    assert extract(None, 'key', {'key': 'value'}) == 'value'
    assert extract(None, 'key', {'key': {'key2': 'value'}}) == {'key2': 'value'}
    assert extract(None, 'key', {'key': {'key2': 'value'}}, 'key2') == 'value'
    assert extract(None, 'key', {'key': {'key2': 'value'}}, ['key2']) == 'value'
    assert extract(None, 'key', {'key': {'key2': 'value'}}, ['wrongkey', 'key2']) == 'value'
    assert extract(None, 'key', {'key': {'key2': 'value'}}, ['wrongkey', 'wrongkey2']) is None



# Generated at 2022-06-23 10:14:16.260839
# Unit test for function comment
def test_comment():
    # Predefined inputs
    inputs = [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        'Nunc viverra sapien mauris, nec dictum metus lobortis nec.',
        'Integer ac diam finibus, dignissim nunc et, auctor mi.',
        'Duis sed arcu fringilla, varius elit vitae, consectetur elit.',
        'Nulla facilisi. Donec luctus in ex in fringilla.',
        'Sed pretium volutpat dolor, eu feugiat dui faucibus eu.'
    ]

    # Predefined outputs

# Generated at 2022-06-23 10:14:22.147227
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote(True) == u"'True'"
    assert quote('abc') == u"'abc'"
    assert quote('a " x') == u"'a \" x'"
    assert quote('a \' x') == u"'a '\\'' x'"
    assert quote('a \' x') == u"'a '\\'' x'"
    assert quote(b'a \' x') == u"'a '\\'' x'"



# Generated at 2022-06-23 10:14:29.434290
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo', "foo") == "foo"
    try:
        mandatory('foo', "foo") == "bar"
    except AnsibleFilterError as e:
        assert "foo" in str(e)
    else:
        assert 0, "Test should have failed"

    class TestUndefined(object):
        def __init__(self, name=None):
            self._undefined_name = name

    try:
        mandatory(TestUndefined("foo"), "bar")
    except AnsibleFilterError as e:
        assert "Mandatory variable" in str(e) and "foo" in str(e) and "not defined" in str(e)
    else:
        assert 0, "Test should have failed"


# Generated at 2022-06-23 10:14:32.076987
# Unit test for function b64encode
def test_b64encode():
    b64encode("foo bar")
    # test for string that needs encoding
    if sys.version_info[0] == 3:
        b64encode("\u2019")
    else:
        b64encode("\xe2\x80\x99".decode("utf-8"))



# Generated at 2022-06-23 10:14:43.115100
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('a\na', 'a') == ['a', 'a']
    assert regex_findall('a\na', 'a', multiline=True) == ['a', 'a']
    assert regex_findall('a\na', 'a', multiline=False) == ['a']
    assert regex_findall('a\na', '^a') == ['a']
    assert regex_findall('a\na', 'a$') == ['a']
    assert regex_findall('a\na', 'a', multiline=False) == ['a']
    assert regex_findall('a\na', 'a', multiline=True) == ['a', 'a']
    assert regex_findall('a\na', '^a$') == ['']

# Generated at 2022-06-23 10:14:51.571630
# Unit test for function to_json
def test_to_json():
    assert to_json({}) == u'{}'
    assert to_json({1, 2}) == u'[1, 2]'
    assert to_json({u'abc': u'def'}) == u'{"abc": "def"}'
    assert to_json({u'abc': {u'def': u'hij'}}) == u'{"abc": {"def": "hij"}}'
    assert to_json({u'abc': 1, u'def': [2, 3]}) == u'{"def": [2, 3], "abc": 1}'



# Generated at 2022-06-23 10:14:58.428802
# Unit test for function regex_search
def test_regex_search():
    value = "test1234"
    pattern = "[0-9]+"
    assert '1234' == regex_search(value, pattern)
    assert '1234' == regex_search(value, pattern, '\\g<0>')
    assert ['1','2','3','4'] == regex_search(value, pattern, '\\g<0>', '\\g<0>', '\\g<1>', '\\g<2>', '\\g<3>')
    assert '1' == regex_search(value, pattern, '\\1')
    assert '2' == regex_search(value, pattern, '\\2')
    assert '3' == regex_search(value, pattern, '\\3')
    assert '4' == regex_search(value, pattern, '\\4')
    assert ['4','3'] == regex

# Generated at 2022-06-23 10:15:01.940001
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(dict(a=1, b=2), key_name='foo', value_name='bar') == [{'foo': 'a', 'bar': 1}, {'foo': 'b', 'bar': 2}]



# Generated at 2022-06-23 10:15:04.335613
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)

# Generated at 2022-06-23 10:15:11.935172
# Unit test for function to_bool
def test_to_bool():
    test_values = {
        'yes': True,
        'YES': True,
        'Yes': True,
        'True': True,
        'true': True,
        'TRUE': True,
        'on': True,
        'ON': True,
        'On': True,
        '1': True,
        1: True,
        'false': False,
        'FALSE': False,
        'False': False,
        'no': False,
        'NO': False,
        'No': False,
        'off': False,
        'OFF': False,
        'Off': False,
        '0': False,
        0: False,
    }
    for test_value in test_values.keys():
        assert to_bool(test_value) == test_values[test_value]



# Generated at 2022-06-23 10:15:22.557458
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'one1two2three3four4', u'[1-3]+', u'three') == u'onethreetwothreefour4'
    assert regex_replace(b'one1two2three3four4', u'[1-3]+', u'three') == u'onethreetwothreefour4'
    assert regex_replace(u'one1two2three3four4', u'[1-3]+', u'three', ignorecase=True) == u'onethreetwothreefour4'
    assert regex_replace(u'one1two2three3four4', u'[1-3]+', u'three', multiline=True) == u'onethreetwothreefour4'

# Generated at 2022-06-23 10:15:28.024386
# Unit test for function quote
def test_quote():
    assert quote(123) == "123"
    assert quote(True) == "True"
    assert quote(None) == ""
    assert quote([1, 2]) == "[1, 2]"
    assert quote("") == ""
    assert quote("foo") == "foo"
    assert quote("foo bar") == "'foo bar'"
    assert quote("'foo'") == "'\\'foo\\''"

