

# Generated at 2022-06-23 10:05:23.937197
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2019-10-18 10:21:05') == datetime.datetime(year=2019, month=10, day=18, hour=10, minute=21, second=5)


# Generated at 2022-06-23 10:05:35.356158
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key':'name', 'value':'Fred'}, {'key':'occupation', 'value':'Wall Street Trader'}]) == {'name':'Fred', 'occupation':'Wall Street Trader'}
    assert list_of_dict_key_value_elements_to_dict([{'key':'name', 'value':'Fred'}, {'key':'occupation', 'value':'Wall Street Trader'}], key_name='name', value_name='job') == {'Fred':'Wall Street Trader'}

# Generated at 2022-06-23 10:05:40.385518
# Unit test for function extract
def test_extract():
    assert extract('b', [{'a': 'c', 'b': {'c': 1}}, {'a': 'c', 'b': None}]) == [{'c': 1}]



# Generated at 2022-06-23 10:05:50.827438
# Unit test for function regex_replace
def test_regex_replace():
    x = regex_replace(
        "a b c de e f",
        "[a-z]+",
        "0")
    assert x == "0 0 0 0 0 0", x

    x = regex_replace(
        "abcabcabcabc",
        "abc",
        "0",
        False,
        False)
    assert x == "0abcabcabc", x

    x = regex_replace(
        "abcabcabcabc",
        "abc",
        "0",
        True,
        False)
    assert x == "0abcabcabc", x
    return "OK"



# Generated at 2022-06-23 10:05:52.230888
# Unit test for function mandatory
def test_mandatory():

    res = mandatory(
        {'a': 'b'},
        msg='foobar'
    )

    assert 'a' in res
    assert res['a'] == 'b'



# Generated at 2022-06-23 10:05:53.761552
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name=None)) is None



# Generated at 2022-06-23 10:06:01.419453
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(
        {"hello": "world"},
        key_name="key",
        value_name="value",
    ) == [
            {
                "key": "hello",
                "value": "world"
            }
    ]
    assert dict_to_list_of_dict_key_value_elements(
        {"hello": "world"},
        key_name="name",
        value_name="content",
    ) == [
            {
                "name": "hello",
                "content": "world"
            }
    ]



# Generated at 2022-06-23 10:06:09.861927
# Unit test for function ternary
def test_ternary():
    # test type
    assert ternary(True, [], {}) == []
    assert ternary(1, [], {}) == []
    assert ternary(1, "", "") == ""
    assert ternary(1, 1, 1) == 1
    assert ternary(1, [1], [1]) == [1]
    # test true value
    assert ternary(True, 'A', 'B') == 'A'
    assert ternary(True, 'A', 'B', 'C') == 'A'
    assert ternary(1, 'A', 'B', 'C') == 'A'
    assert ternary(1, 'A', 'B') == 'A'
    assert ternary(0, 'A', 'B') == 'B'
    # test false value

# Generated at 2022-06-23 10:06:17.245841
# Unit test for function comment
def test_comment():
    import json
    # Test decorator only
    assert comment(
        text='Decorator only test',
        decoration='@') == '@\n@\nDecorator only test\n@\n'
    # Test prefix and postfix only
    assert comment(
        text='Prefix and postfix test',
        prefix='==',
        postfix='==') == '==\n==\nPrefix and postfix test\n==\n'
    # Test prefix, postfix, and decorator
    assert comment(
        text='Prefix, decorator, and postfix test',
        prefix='==',
        postfix='==',
        decoration='@') == '==\n==\n@Prefix, decorator, and postfix test\n==\n'
    # Test plain comment

# Generated at 2022-06-23 10:06:29.077369
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'l+', '\\g<0>') == 'll'
    assert regex_search('hello world', 'l+', '\\1') == 'll'
    assert regex_search('hello world', 'l+', '\\g<0>', '\\g<1>') == ['ll', 'l']
    assert regex_search('hello world', 'lo', '\\g<0>', '\\g<1>') == ['lo', 'o']
    assert regex_search('hello world', 'lo*', '\\g<0>', '\\g<1>') == ['lo', 'o']



# Generated at 2022-06-23 10:06:37.570574
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'
    assert ternary(1, 'true', 'false') == 'true'
    assert ternary(0, 'true', 'false') == 'false'
    assert ternary('', 'true', 'false') == 'false'



# Generated at 2022-06-23 10:06:48.413553
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b'test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash(u'test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash(b'test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-23 10:06:52.098331
# Unit test for function quote
def test_quote():
    assert quote("A") == "A"
    assert quote("A B") == "'A B'"
    assert quote("A'B") == "'A'\"'\"'B'"



# Generated at 2022-06-23 10:07:04.160522
# Unit test for function flatten
def test_flatten():
    assert None == flatten([[], '[]'])
    assert [] == flatten([[], '[]'], skip_nulls=False)
    assert [1, 2, 3, 4] == flatten([[], [1, 2], '3', [4]])
    assert [1, 2, 3, 4] == flatten([[], [1, 2], '3', [[4]]])

# Generated at 2022-06-23 10:07:13.062087
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2, c=3)) == '''\
a: 1
b: 2
c: 3\
'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}, indent=2) == '''\
a: 1
b: 2
c: 3\
'''
    assert to_nice_yaml({'a': 1, 'b': [{'d': {'e': 3}}], 'c': 3}) == '''\
a: 1
b:
  - d:
      e: 3
c: 3\
'''

# Generated at 2022-06-23 10:07:26.154616
# Unit test for function to_nice_json
def test_to_nice_json():
    for test_case in ['a', 'bc', 'def', 'ghi', 'jklm', 'nopqr', 'stuvwxyz']:
        assert to_nice_json(test_case) == '"%s"' % test_case

    for test_case in ['a'*256, 'bc'*256, 'def'*256, 'ghi'*256, 'jklm'*256, 'nopqr'*256, 'stuvwxyz'*256]:
        assert to_nice_json(test_case) == '"%s"' % test_case

# Generated at 2022-06-23 10:07:35.958088
# Unit test for function comment
def test_comment():
    _template = "- {% set multiline = \"(This is a test)\" %}\n" + \
        "- {{ multiline|comment('# ', decoration='# ', newline='\\n') }}"
    _expected = """- "# (This is a test)"
- # (This is a test)"""
    _result = jinja2.Template(_template).render()
    assert _result == _expected

    _template = "- {% set multiline = \"(This is a test)\" %}\n" + \
        "- {{ multiline|comment('# ', decoration='# ', newline='\\n', prefix='', prefix_count=1) }}"
    _expected = """- "# (This is a test)"
- # (This is a test)"""
    _result = jinja2.Template(_template).render()


# Generated at 2022-06-23 10:07:47.128505
# Unit test for function to_json
def test_to_json():
    assert to_json(dict(
        foo=42,
        bar="It's bar!!",
        baz=[1, 2, 3],
        qux=dict(
            quux="It's quux!!",
            corge=None),
        grault=dict(
            garply="It's garply!!",
            waldo=None))) == json.dumps(dict(
                foo=42,
                bar="It's bar!!",
                baz=[1, 2, 3],
                qux=dict(
                    quux="It's quux!!",
                    corge=None),
                grault=dict(
                    garply="It's garply!!",
                    waldo=None)),
                cls=AnsibleJSONEncoder)



# Generated at 2022-06-23 10:07:59.731694
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    from ansible.module_utils.six import PY3

    if PY3:
        # python3 does not have 'cmp'
        undefined_instance = Undefined('foo', name='foo')
    else:
        undefined_instance = Undefined('foo', name='foo', cmp=None)

    assert mandatory(2) == 2
    assert mandatory(None) == None

    try:
        mandatory(5, msg="test message 5")
        assert False
    except AnsibleFilterError as e:
        assert "test message 5" in str(e)

    try:
        mandatory(undefined_instance)
        assert False
    except AnsibleFilterError as e:
        assert "'foo' not defined" in str(e)



# Generated at 2022-06-23 10:08:04.149976
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('ZQ==') == 'a'
    assert b64decode('YWI=') == 'ab'
    assert b64decode('YWJj') == 'abc'
    assert b64decode('YWJjZA==') == 'abcd'
    assert b64decode('YWJjZGU=') == 'abcde'
    assert b64decode('YWJjZGVm') == 'abcdef'
    assert b64decode('YWJjZGVmZw==') == 'abcdefg'
    assert b64decode('YWJjZGVmZ2g=') == 'abcdefgh'
    assert b64decode('YWJjZGVmZ2hp') == 'abcdefghi'

# Generated at 2022-06-23 10:08:08.655853
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    ''' basic non-edge-case tests '''
    mylist = [{'key': 'k1', 'value': 'v1'}, {'key': 'k2', 'value': 'v2'}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'k1': 'v1', 'k2': 'v2'}
    assert list_of_dict_key_value_elements_to_dict(mylist, key_name='name', value_name='number') == {'k1': 'v1', 'k2': 'v2'}



# Generated at 2022-06-23 10:08:12.968589
# Unit test for function regex_findall
def test_regex_findall():
    assert ["a","b"] == regex_findall("abba", "ab?")
    assert ["a","b"] == regex_findall("abba", "ab?", multiline=True, ignorecase=True)
    assert [("a", "b"),("a", "b")] == regex_findall("a,b\na,b", "(\w+),\w+")



# Generated at 2022-06-23 10:08:19.165900
# Unit test for function randomize_list
def test_randomize_list():

    # Test case: The list is empty
    assert randomize_list([]) == [], "Test case: The list is empty"

    # Test case: The list has only one element
    assert randomize_list([1]) == [1], "Test case: The list has only one element"

    # Test case: The list has more than one element
    r = Random(1)
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == r.sample([1, 2, 3, 4, 5], 5),\
        "Test case: The list has more than one element"

    # Test case: The input list is a set with more than one elements
    r = Random(2)

# Generated at 2022-06-23 10:08:26.410541
# Unit test for function ternary
def test_ternary():
    assert ternary(True, None, None) is None
    assert ternary(False, None, None) is None
    assert ternary(True, 'hello', 'world') == 'hello'
    assert ternary(False, 'hello', 'world') == 'world'
    assert ternary(False, 'hello', 'world', 'boom') == 'world'
    assert ternary(None, 'hello', 'world', 'boom') == 'boom'



# Generated at 2022-06-23 10:08:36.953582
# Unit test for function path_join
def test_path_join():
    assert path_join('a') == 'a'
    assert path_join(['', '/', 'a']) == os.path.join('', '/', 'a')
    assert path_join(['a', 'b', 'c']) == os.path.join('a', 'b', 'c')
    assert path_join(('a', 'b', 'c')) == os.path.join('a', 'b', 'c')
    try:
        path_join(1)
        assert False, "should have raised AnsibleFilterTypeError"
    except AnsibleFilterTypeError:
        pass
    try:
        path_join({})
        assert False, "should have raised AnsibleFilterTypeError"
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-23 10:08:38.899989
# Unit test for function strftime
def test_strftime():
    print(strftime('%Y-%m-%d %H:%M:%S', 1471599999))


# Generated at 2022-06-23 10:08:45.256185
# Unit test for function b64encode
def test_b64encode():
    examples = [
        {
            'input': 'this is a test',
            'output': 'dGhpcyBpcyBhIHRlc3Q=',
            'encoding': None
        },
        {
            'input': b'Le \xc3\xa9t\xc3\xa9 est magnifique!',
            'output': 'TGUgw6nDqcOpIHN0IG1hZ25pZmlxdWUh',
            'encoding': 'iso-8859-1'
        }
    ]

    for example in examples:
        assert b64encode(example['input'], encoding=example['encoding']) == example['output']



# Generated at 2022-06-23 10:08:53.734102
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo/bar') == r'foo\/bar'
    assert regex_escape(r'foo.bar', re_type='python') == r'foo\.bar'
    assert regex_escape(r'foo.bar', re_type='posix_basic') == r'foo\.bar'
    assert regex_escape(r'foo.bar', re_type='foo') == r'foo\.bar'
    assert regex_escape('foo/bar', re_type='posix_basic') == r'foo\/bar'
    assert regex_escape('foo/bar', re_type='python') == r'foo\/bar'
    assert regex_escape(r'foo.bar') == r'foo\.bar'
    assert regex_escape('foo.bar') == r'foo\.bar'



# Generated at 2022-06-23 10:09:02.660465
# Unit test for function regex_search

# Generated at 2022-06-23 10:09:05.270109
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'



# Generated at 2022-06-23 10:09:10.044564
# Unit test for function b64decode
def test_b64decode():
    s = "dGVzdA=="
    assert "test" == b64decode(s)
    s = "dGVzdA"
    assert b64decode(s) == "test"


# Generated at 2022-06-23 10:09:20.285004
# Unit test for function flatten
def test_flatten():
    assert flatten([]) == []
    assert flatten(['1']) == ['1']

    assert flatten(['1', ['2', '3']]) == ['1', '2', '3']

    assert flatten(['1', ['2', ['3']]]) == ['1', '2', '3']

    assert flatten([['1', '2'], '3']) == ['1', '2', '3']

    assert flatten([['1', ['2', ['3']]], '4']) == ['1', '2', '3', '4']

    assert flatten(['1', ['2', ['3']], '4']) == ['1', '2', '3', '4']

    # levels

# Generated at 2022-06-23 10:09:32.568639
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value="Ansible is great",pattern="Ansible",replacement="Galaxy") == "Galaxy is great"
    assert regex_replace(value="Ansible is great",pattern="ansible",replacement="Galaxy") == "Ansible is great"
    assert regex_replace(value="Ansible is great",pattern="ansible",replacement="Galaxy",ignorecase=True) == "Galaxy is great"
    assert regex_replace(value="123ab456def789ghi",pattern="\d+",replacement="XYZ") == "XYZabXYZdefXYZghi"
    assert regex_replace(value="123ab456def789ghi",pattern="\d+",replacement="XYZ",multiline=True) == "XYZabXYZdefXYZghi"


# Generated at 2022-06-23 10:09:45.470049
# Unit test for function extract
def test_extract():
    from jinja2 import DictLoader, Environment
    env = Environment(loader=DictLoader({
        "test_extract.j2": """{{ value }}""",
    }))


# Generated at 2022-06-23 10:09:55.807768
# Unit test for function comment
def test_comment():
    # Random test data
    text = '''This is a test.
This is another test.
This should be the last test.
'''

    # Tests
    assert comment(text) == '''# This is a test.
# This is another test.
# This should be the last test.
'''
    assert comment(text, newline='\r\n') == '''# This is a test.
# This is another test.
# This should be the last test.
'''
    assert comment(text, style='erlang') == '''% This is a test.
% This is another test.
% This should be the last test.
'''
    assert comment(text, style='c') == '''// This is a test.
// This is another test.
// This should be the last test.
'''

# Generated at 2022-06-23 10:10:02.399148
# Unit test for function ternary
def test_ternary():
    assert ternary('foo', 'bar', 'baz') == 'bar'
    assert ternary(False, 'bar', 'baz') == 'baz'
    assert ternary(None, 'bar', 'baz') == 'baz'
    assert ternary(None, 'bar', 'baz', none_val='foo') == 'foo'



# Generated at 2022-06-23 10:10:06.182855
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('foo') == 'Zm9v'



# Generated at 2022-06-23 10:10:09.936717
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('abcd')) == 'abcd'



# Generated at 2022-06-23 10:10:20.782723
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # Use to_nice_yaml() to format data in the style of nice_yaml
    # Set up the data
    data = {
        'name': 'Joe',
        'age': 35,
    }
    # Show that to_nice_yaml() gives the same output as nice_yaml()
    assert to_nice_yaml(data) == 'age: 35\nname: Joe\n'.encode('utf-8')
    # Show that to_nice_yaml() formats hierarchical output the same way as nice_yaml()
    data = {
        'name': {
            'first': 'Joe',
            'last': 'Smith',
        },
        'age': 35,
    }

# Generated at 2022-06-23 10:10:25.244968
# Unit test for function quote
def test_quote():
    assert quote(u"test") == u"test"
    assert quote(u"test test") == u"test\\ test"
    assert quote(u"test' test") == u"test\\'\\ test"



# Generated at 2022-06-23 10:10:27.050799
# Unit test for function subelements
def test_subelements():
    try:
        import nose
    except ImportError:
        raise AssertionError("Unable to execute unit tests without the 'nose' package")
    return nose.runmodule(argv=[__file__, '-v', '-i', 'nose.suite.ContextSuite'])



# Generated at 2022-06-23 10:10:33.827194
# Unit test for function to_datetime
def test_to_datetime():
    test_string = '2013-01-01 00:00:00'
    result = to_datetime(test_string)
    test_datetime = datetime.datetime(2013, 1, 1, 0, 0)
    assert result == test_datetime
    assert isinstance(result, datetime.datetime)
    assert isinstance(to_datetime('invalid_date'), type(None))


# Generated at 2022-06-23 10:10:37.439345
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'one': {'two': 2}}) == "one:\n    two: 2\n"
    assert to_nice_yaml([1,2,3], indent=2) == "- 1\n- 2\n- 3\n"



# Generated at 2022-06-23 10:10:40.322128
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)


# Generated at 2022-06-23 10:10:45.406258
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2

    T = jinja2.Template("""
        {% set x = "E" %}
        {{ x | mandatory }}
    """)
    output = T.render({})
    assert output == "E", "Error in FilterModule.filters"


# Test to_nice_json function

# Generated at 2022-06-23 10:10:55.585592
# Unit test for function regex_search
def test_regex_search():
    string = '192.168.1.1'
    regex = '\d+\.\d+\.\d+\.\d+'
    result = regex_search(string, regex)
    assert result == '192.168.1.1'
    result = regex_search(string, regex, '\\g<0>')
    assert result == ['192.168.1.1']
    result = regex_search(string, regex, '\\2')
    assert result == '168'
    result = regex_search(string, regex, '\\g<2>')
    assert result == ['168']
    result = regex_search(string, regex, '\\2', '\\1')
    assert result == ['168', '192']

# Generated at 2022-06-23 10:10:57.352826
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(1) == '1\n'
# end unit test for function to_yaml


# Generated at 2022-06-23 10:11:01.098928
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{test: 1}') == {'test': 1}
    assert from_yaml('- 1') == [-1]
    assert from_yaml(1) == 1



# Generated at 2022-06-23 10:11:13.598127
# Unit test for function b64encode
def test_b64encode():
    """Test function: b64encode"""
    assert b64encode(u'ansible') == u'YW5zaWJsZQ=='
    assert b64encode(u'ansible', 'latin1') == u'YW5zaWJsZQ=='
    assert b64encode(u'ansible', 'ascii') == u'YW5zaWJsZQ=='
    assert b64encode(u'ansible', 'utf-16') == u'AAoFc2libGU='
    assert b64encode(u'ansible', 'utf-32') == u'AAAAAoFc2libGU='
    assert b64encode(u'ansible', 'utf-32-be') == u'AAAAAoFc2libGU='

# Generated at 2022-06-23 10:11:20.425939
# Unit test for function from_yaml_all
def test_from_yaml_all():
    try:
        import yaml
        test_data_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sanity-filter-test.yml')
        with open(test_data_file, 'r') as stream:
            expected = yaml.load_all(stream)
            actual = from_yaml_all(stream.read())
            assert actual == expected
    except ImportError:
        raise SkipTest('Cannot test sanity filter tests on systems without PyYAML')



# Generated at 2022-06-23 10:11:27.141986
# Unit test for function b64decode
def test_b64decode():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.common.collections import ImmutableDict

    _side_effect = b64decode
    test_cases = [
        (
            ImmutableDict({
                # input
                'string': 'YWJjZGU=',
                # expected
                'result': 'abcde',
            }),
        ),
    ]

    # crypted passwords with sha512crypt
    # test_cases.extend(
    #    (crypt_sha512_input, b64decode)
    #    for crypt_sha512_input in CRYPT_SHA512_TEST_VECTORS
    # )


# Generated at 2022-06-23 10:11:38.565627
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' test function dict_to_list_of_dict_key_value_elements '''
    from ansible.modules.web_infrastructure.junos import dict_to_list_of_dict_key_value_elements
    assert dict_to_list_of_dict_key_value_elements({'a': 1}) == [{'key': u'a', 'value': 1}]
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': [1, 2, 3]}, key_name='k', value_name='v') == [
        {'k': u'a', 'v': 1},
        {'k': u'b', 'v': [1, 2, 3]}
    ]

# Generated at 2022-06-23 10:11:52.439231
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    '''
    >>> mydict = {'a' : 1, 'b' : 2, 'c' : 3}
    >>> result = dict_to_list_of_dict_key_value_elements(mydict)
    >>> result == [ {'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3} ]
    True
    >>> result = dict_to_list_of_dict_key_value_elements(mydict, key_name='name', value_name='number')
    >>> result == [ {'name': 'a', 'number': 1}, {'name': 'b', 'number': 2}, {'name': 'c', 'number': 3} ]
    True
    '''
    pass



# Generated at 2022-06-23 10:11:58.778016
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json(dict(test=123)) == '{\n    "test": 123\n}'
    assert to_nice_json([dict(test=123)]) == '[\n    {\n        "test": 123\n    }\n]'
    assert to_nice_json(text_type('hello world')) == '"hello world"'
# End of unit test for function to_nice_json



# Generated at 2022-06-23 10:12:03.678068
# Unit test for function rand
def test_rand():
    assert rand([1], 2, 1, 1) == 1
    assert rand([1, 2, 3], 3) == 3
    assert rand([1, 2, 3], seed="seed") == 2



# Generated at 2022-06-23 10:12:05.757674
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(['foo', 'bar'], seed='test') == ['bar', 'foo']



# Generated at 2022-06-23 10:12:10.859442
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('True') == True
    assert to_bool('Yes') == True
    assert to_bool('FALSE') == False
    assert to_bool('False') == False
    assert to_bool('0') == False
    assert to_bool('no') == False
    assert to_bool(True) == True
    assert to_bool(False) == False



# Generated at 2022-06-23 10:12:13.050400
# Unit test for function quote
def test_quote():
    assert quote('foo') == u"'foo'"
    assert quote('"foo"') == u'"\\"foo\\""'



# Generated at 2022-06-23 10:12:18.205450
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('foo') is False
    assert to_bool('true') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False



# Generated at 2022-06-23 10:12:26.831662
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    # Check if passing a defined item returns the value
    assert(mandatory('string') == 'string')
    assert(mandatory(['a', 'b', 'c']) == ['a', 'b', 'c'])
    assert(mandatory({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3})

    # Check if passing an undefined item raises an exception
    try:
        mandatory(Undefined)
        assert(False)
    except AnsibleFilterError as e:
        assert(to_native(e) == "Mandatory variable not defined.")

    # Check if passing an undefined item with a name raises an exception

# Generated at 2022-06-23 10:12:33.538672
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('0') == False
    assert to_bool('None') == False
    assert to_bool('') == False
    assert to_bool('foo') == False
    assert to_bool(0) == False
    assert to_bool(1) == True



# Generated at 2022-06-23 10:12:45.532620
# Unit test for function subelements
def test_subelements():
    obj1 = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    obj2 = {"element": {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}}
    assert subelements(obj1, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj2, 'element.groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

# Generated at 2022-06-23 10:12:50.882550
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == '{}'
    assert to_yaml({'a': 1}) == '{a: 1}'
    assert to_yaml({'a': [1,2,3]}, default_flow_style=False) == 'a:\n- 1\n- 2\n- 3'
# -- end unit test for function to_yaml


# Generated at 2022-06-23 10:13:03.568502
# Unit test for function regex_search
def test_regex_search():
    # Test
    rv = regex_search("span", r"sp(an)", r"\g<1>")
    assert rv == "an"

    rv = regex_search("foo span", r"sp(an)", r"\g<1>")
    assert rv == "an"

    rv = regex_search("span", r"sp(an)", r"\g<1>", r"\\g<2>")
    assert rv == ["an"]

    rv = regex_search("span", r"sp(an)", r"\g<1>", r"\\2")
    assert rv == ["an"]

    rv = regex_search("span", r"sp(an)", r"\g<1>", r"\\g<1>")
    assert rv == ["an", "an"]



# Generated at 2022-06-23 10:13:10.207943
# Unit test for function to_nice_json
def test_to_nice_json():
    result = to_nice_json([{'key': '\u8d85\u7ea7\u50bb\u74dc'}])
    assert result == '[\n    {\n        "key": "超级无聊"\n    }\n]'


# Generated at 2022-06-23 10:13:20.053088
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    def _transform(a):
        return yaml.load(to_yaml(a))
    assert _transform({}) == {}
    assert _transform({'a': {'c': {'e': 'g'}, 'b': 'd'}}) == {'a': {'c': {'e': 'g'}, 'b': 'd'}}
    assert _transform({'a': [1, 2, 3]}) == {'a': [1, 2, 3]}
    assert _transform('string') == 'string'
    assert _transform([1,2,3]) == [1,2,3]
    assert _transform(1) == 1
    assert _transform(True) == True
    assert _transform(False) == False
    assert _transform(None) == None

# Generated at 2022-06-23 10:13:33.037431
# Unit test for function b64encode
def test_b64encode():
    # unicode input, utf-8 output
    assert b64encode('\u6211\u5c0d\u4e16\u754c\u8a8d\u8b58') == '6Ieq5Yqo5a6a5LmQ'
    # bytes input, utf-8 output
    assert b64encode(b'\xe6\x88\x91\xe5\xb0\xb1\xe5\xaf\xab\xe4\xb8\x96\xe7\x95\x8c') == '6Ieq5Yqo5a6a5LmQ'
    # unicode input, bytes output

# Generated at 2022-06-23 10:13:35.341602
# Unit test for function to_nice_json
def test_to_nice_json():
    d = {"a": 1, "b": [1, 2, 3]}
    assert to_nice_json(d).startswith('{\n    "a": 1,')


# Generated at 2022-06-23 10:13:47.524278
# Unit test for function mandatory
def test_mandatory():
    from jinja2.environment import Environment

    env = Environment()
    env.filters['mandatory'] = mandatory

    # undefined variable
    template = env.from_string("{{ mandatory(missing) }}")
    try:
        template.render()
    except AnsibleFilterError as e:
        assert "Mandatory variable 'missing' not defined." in to_text(e)
    else:
        assert False, "Failed to detect undefined variable"

    # undefined sub variable
    template = env.from_string("{{ mandatory(test.missing) }}")
    try:
        template.render({"test": None})
    except AnsibleFilterError as e:
        assert "Mandatory variable 'test.missing' not defined." in to_text(e)
    else:
        assert False, "Failed to detect undefined sub variable"

   

# Generated at 2022-06-23 10:13:56.941487
# Unit test for function path_join
def test_path_join():
    import copy
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # remove color from json
    original_json_dump = json.dumps
    def json_dump_filter(v):
        if isinstance(v, Display):
            return v._get_args()[0]
        return v
    json.dumps = lambda data, *args, **kwargs: original_json_dump(data, *args, default=json_dump_filter, **kwargs)

    paths = [ 'foo', ['bar'], ['baz', 'qux'] ]
    expected_results = os.path.join('foo', 'bar', 'baz', 'qux')

    # Test as a filter
    loader = DataLoader()

# Generated at 2022-06-23 10:13:58.679588
# Unit test for function to_nice_json
def test_to_nice_json():
    # Just check that it doesn't crash.
    to_nice_json({})



# Generated at 2022-06-23 10:14:03.004796
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'foo':1, 'bar':[1,2,3]}) == ('bar:\n'
 '- 1\n'
 '- 2\n'
 '- 3\n'
 'foo: 1\n')



# Generated at 2022-06-23 10:14:13.034137
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool(None) == None
    assert to_bool('on') == True
    assert to_bool('off') == False
    assert to_bool('yes') == True
    assert to_bool('no') == False
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool('foo') == False
    assert to_bool('') == False
    assert to_bool(' ') == False


# Generated at 2022-06-23 10:14:23.684452
# Unit test for function subelements
def test_subelements():
    # Test a simple case
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    expected = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups') == expected

    # Test a nested case
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": [{"user": "alice", "key": "/tmp/alice/onekey.pub"}]}]

# Generated at 2022-06-23 10:14:28.100607
# Unit test for function b64decode
def test_b64decode():
    # test ascii
    test_string = b"hello"
    expected_result = b"hello"
    assert b64decode(b64encode(test_string)) == expected_result
    # test non-ascii
    test_string = b"\x8b\x8b"
    expected_result = b"\x8b\x8b"
    assert b64decode(b64encode(test_string)) == expected_result



# Generated at 2022-06-23 10:14:40.850368
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' Test for function dict_to_list_of_dict_key_value_elements '''

    test_dict = {'a': 1, 'b': 2, 'c': 3}
    assert dict_to_list_of_dict_key_value_elements(test_dict, 'key', 'value') == [{'key': 'a', 'value': 1},
                                                                                  {'key': 'b', 'value': 2},
                                                                                  {'key': 'c', 'value': 3}]

    test_dict = {'foo': [], 'bar': [], 'qux': []}

# Generated at 2022-06-23 10:14:52.815217
# Unit test for function to_bool
def test_to_bool():
    ''' Test function to_bool '''
    assert to_bool(None) is None
    assert to_bool(True) is True
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool('True') is True
    assert to_bool(1) is True
    assert to_bool('false') is False
    assert to_bool('False') is False
    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool(0) is False
    assert to_bool('') is False



# Generated at 2022-06-23 10:15:02.115784
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall("aabbcc", r"([a-c]+)", multiline=False, ignorecase=False) == ['aa', 'bb', 'cc']
    assert regex_findall("aabbcc", r"([a-c]+)", multiline=True, ignorecase=False) == ['aabbcc']
    assert regex_findall("aabbcc", r"([a-c]+)", multiline=False, ignorecase=True) == ['aa', 'bb', 'cc']
    assert regex_findall("aabbcc", r"([a-c]+)", multiline=True, ignorecase=True) == ['aabbcc']

# Generated at 2022-06-23 10:15:07.701083
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('mydata') == '6cd3556deb0da54bca060b4c394798390577bcee'
    assert get_hash('fiiilter') == 'd1a222339bcc2c367f7b941f1caf65d4f3474916'
    assert get_hash('fiiilter', hashtype='md5') == 'a21b097276b98aa0e859ceb8bdbf778a'


# Generated at 2022-06-23 10:15:16.428913
# Unit test for function to_bool
def test_to_bool():
    assert(True == to_bool('yes'))
    assert(True == to_bool('1'))
    assert(True == to_bool('true'))
    assert(True == to_bool(1))
    assert(True == to_bool(True))
    assert(False == to_bool(False))
    assert(False == to_bool(0))
    assert(False == to_bool('no'))
    assert(False == to_bool(''))



# Generated at 2022-06-23 10:15:18.888813
# Unit test for function b64encode
def test_b64encode():
    return b64encode('test') == 'dGVzdA=='

# Source: http://stackoverflow.com/a/6618362/1802454

# Generated at 2022-06-23 10:15:22.825512
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)