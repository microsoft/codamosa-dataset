

# Generated at 2022-06-23 10:05:37.299423
# Unit test for function path_join
def test_path_join():
    assert path_join("/tmp/foo") == "/tmp/foo"
    assert path_join("/tmp/foo", "bar", "baz") == "/tmp/foo/bar/baz"
    assert path_join(("/tmp/foo", "bar", "baz")) == "/tmp/foo/bar/baz"
    assert path_join("/tmp/foo", ("bar", "baz")) == "/tmp/foo/bar/baz"
    assert path_join(("/tmp/foo",), ("bar", "baz")) == "/tmp/foo/bar/baz"
    assert path_join(("/tmp/foo",), ("bar",), "baz") == "/tmp/foo/bar/baz"

# Generated at 2022-06-23 10:05:41.143227
# Unit test for function from_yaml_all
def test_from_yaml_all():
    data = '''---
    - one
    - two
---
foo: bar
'''
    assert from_yaml_all(data)[0][0] == 'one'
    assert from_yaml_all(data)[1]['foo'] == 'bar'



# Generated at 2022-06-23 10:05:45.519548
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    mydict = list_of_dict_key_value_elements_to_dict(mylist)
    if mydict != {'a': 1, 'b': 2}:
        print("Failed: Expected %s and got %s" % ({'a': 1, 'b': 2}, mydict))



# Generated at 2022-06-23 10:05:52.902877
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Check the constructor of FilterModule class.
    """
    fm = FilterModule()
    filters = fm.filters()
    assert filters['bool'] == to_bool
    assert filters['to_datetime'] == to_datetime
    assert args.__name__ == 'args'


# Generated at 2022-06-23 10:05:58.304492
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = dict(a=5, b=dict(c=[1,2,3], d='foo'))
    b = '''\
a: 5
b:
    c:
    - 1
    - 2
    - 3
    d: foo'''
    assert to_nice_yaml(a) == b


# Generated at 2022-06-23 10:06:04.809240
# Unit test for function ternary
def test_ternary():
    assert ternary('foo', 'bar', 'baz') == 'bar'
    assert ternary('foo', 'bar', 'baz', 'bop') == 'bar'
    assert ternary(None, 'bar', 'baz', 'bop') == 'bop'
    assert ternary([], 'bar', 'baz', 'bop') == 'baz'
    assert ternary(0, 'bar', 'baz', 'bop') == 'baz'
    assert ternary({}, 'bar', 'baz', 'bop') == 'baz'



# Generated at 2022-06-23 10:06:13.264142
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert [({"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}, 'wheel')] == subelements(obj, 'groups')
    assert [({'authorized': ['/tmp/alice/onekey.pub'], 'name': 'alice', 'groups': ['wheel']}, '/tmp/alice/onekey.pub')] == subelements(obj, 'authorized')
    assert [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'alice')] == subelements(obj, 'name')


# Generated at 2022-06-23 10:06:15.852583
# Unit test for function strftime
def test_strftime():
    assert strftime(second=0, string_format='%Y-%m-%d %H:%M:%S') == "1970-01-01 00:00:00"



# Generated at 2022-06-23 10:06:19.175029
# Unit test for function get_hash
def test_get_hash():
    string = 'test'
    hashvalue = get_hash(data=string,hashtype='sha256')
    assert hashvalue == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'


# Generated at 2022-06-23 10:06:22.340461
# Unit test for function strftime
def test_strftime():
    output = strftime('%Y-%m-%d', second=0)
    assert output == '1970-01-01'



# Generated at 2022-06-23 10:06:28.464744
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert [1, 2, 3] == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}], key_name='key', value_name='value')



# Generated at 2022-06-23 10:06:39.832448
# Unit test for function flatten
def test_flatten():
    assert [1, 2, 3, 4, 5] == flatten([1, 2, 3, 4, 5])
    assert [[1, 2, 3], [4], 5] == flatten([[1, 2, 3], [4], 5], levels=0)
    assert [1, 2, 3, 4, 5] == flatten([[1, 2, 3], [4], 5], levels=1)
    assert [1, 2, 3, 4, 5] == flatten([[1, 2, 3], [4], 5], levels=2)
    assert [1, 2, 3, 4, 5] == flatten([[1, 2, 3], [4], 5], levels=3)

# Generated at 2022-06-23 10:06:41.853603
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1422782763') == '2015-02-03 04:36:03'



# Generated at 2022-06-23 10:06:50.093005
# Unit test for function regex_search
def test_regex_search():
    value1 = "foo"
    value2 = "a b c"

# Generated at 2022-06-23 10:07:00.431834
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(pattern="a", value="a", replacement="b") == "b"
    assert regex_replace(pattern="a", value="a", replacement="b", ignorecase=True) == "b"
    assert regex_replace(pattern="a", value="A", replacement="b", ignorecase=True) == "b"
    assert regex_replace(pattern="a", value="A", replacement="b") == "A"
    assert regex_replace(pattern="a", value="aa", replacement="b", ignorecase=True) == "b"
    assert regex_replace(pattern="a", value="aa", replacement="b", ignorecase=False) == "b"
    assert regex_replace(pattern="a.", value="a\nb", replacement="b", multiline=True) == "b\nb"

# Generated at 2022-06-23 10:07:04.412475
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    data = {'key1': 'value1', 'key2': 'value2'}
    expected_output = [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}]
    assert (dict_to_list_of_dict_key_value_elements(data)) == expected_output



# Generated at 2022-06-23 10:07:05.279073
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('foobar\n') == 'Zm9vYmFyCg=='



# Generated at 2022-06-23 10:07:08.932550
# Unit test for function extract
def test_extract():
    environment = None
    container = {'a': {'b': {'c': 1}}}
    assert 1 == extract(environment, 'c', container, 'b')
    assert 1 == extract(environment, 'c', container, ['b'])
    assert 1 == extract(environment, 'c', container, morekeys=['b'])
    assert container == extract(environment, 'a', container)
    assert container['a'] == extract(environment, 'a', container, 'a')
    assert container['a']['b'] == extract(environment, 'b', container, 'a')
    assert container['a']['b']['c'] == extract(environment, 'c', container, ['a', 'b'])



# Generated at 2022-06-23 10:07:19.403019
# Unit test for function randomize_list
def test_randomize_list():
    mylist1 = [1, 2, 3, 4]
    ansible_list1 = randomize_list(mylist1, seed="ansible")
    py_list1 = randomize_list(mylist1, seed="python")
    assert mylist1 != ansible_list1, "mylist1 and ansible_list1 are expected to be different"
    assert mylist1 != py_list1, "mylist1 and py_list1 are expected to be different"
    assert ansible_list1 == py_list1, "ansible_list1 and py_list1 are expected to be equal"
    mylist2 = ["a", "b", "c"]
    ansible_list2 = randomize_list(mylist2, seed="ansible")

# Generated at 2022-06-23 10:07:30.790042
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar

    class MockEnvironment(object):
        @staticmethod
        def getitem(value, attribute):
            return getattr(value, attribute)

    assert do_groupby(MockEnvironment, [TestNamedTuple("a", 1), TestNamedTuple("b", 1)], "group") == [("a", [TestNamedTuple("a", 1)]), ("b", [TestNamedTuple("b", 1)])]
    assert do_groupby(MockEnvironment, [TestNamedTuple("a", 1), TestNamedTuple("a", 2)], "group") == [("a", [TestNamedTuple("a", 1), TestNamedTuple("a", 2)])]

# Generated at 2022-06-23 10:07:35.132396
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool("yes") == True
    assert to_bool("on") == True
    assert to_bool("1") == True
    assert to_bool("True") == True
    assert to_bool("true") == True
    assert to_bool(False) == False
    assert to_bool("foo") == False



# Generated at 2022-06-23 10:07:41.594710
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.utils import contextfunction
    from jinja2.runtime import Context

    # Create a mock environment and context for the filter to run under
    environment = mock.Mock()
    context = Context(environment)

    # Create a mock jinja2 function which is used by the `groupby` filter
    _do_groupby = mock.Mock()
    _do_groupby.return_value = [('Product A', [dict(type='book'), dict(type='book')]),
                                ('Product B', [dict(type='shirt'), dict(type='shirt')])]
    # decorate the mock with the `contextfunction` so it can be called with a context
    _do_groupby = contextfunction(_do_groupby)

    # Call the do_groupby function to be tested

# Generated at 2022-06-23 10:07:46.861209
# Unit test for function do_groupby
def test_do_groupby():
    groups = do_groupby(None, [{'id':'a', 'val':'1'}, {'id':'b', 'val':'2'}, {'id':'a', 'val':'3'}], 'id')
    assert isinstance(groups, list)
    assert len(groups) == 2
    assert groups[0][0] == 'a'
    assert groups[0][1][0]['val'] == '1'
    assert groups[0][1][1]['val'] == '3'
    assert groups[1][0] == 'b'
    assert groups[1][1][0]['val'] == '2'

# Generated at 2022-06-23 10:07:56.685076
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # Use the same data structure as in test_to_yaml
    ys = [(range(2), {'a': 'b', 'c': range(3)})]
    assert(to_nice_yaml(ys) == '- - [0, 1]\n  - a: b\n    c:\n    - 0\n    - 1\n    - 2\n')
    assert(to_nice_yaml(ys, indent=2) == '- - [0, 1]\n    - a: b\n      c:\n      - 0\n      - 1\n      - 2\n')



# Generated at 2022-06-23 10:08:01.123973
# Unit test for function comment
def test_comment():
    # Function comment() is essentially a string generator.
    # Thus, it is difficult to write a unit test.
    # Here are some usage examples to test the code coverage.

    # Usage 1
    assert comment('Hello world!') == ("""\
# Hello world!""")

    # Usage 2: specify a newline character
    assert comment('Hello world!', newline='') == ("""\
# Hello world!""")

    # Usage 2: specify a newline character
    assert comment('Hello world!', newline='    ') == ("""\
    # Hello world!""")

    # Usage 3: specify a decoration character
    assert comment('Hello world!', decoration='* ') == ("""\
# * Hello world!""")

    # Usage 4: specify different decoration characters for beginning, prefix, and the rest

# Generated at 2022-06-23 10:08:10.543163
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'abc123abc', u'123', u'456') == u'abc456abc'
    assert regex_replace(u'abc123abc', u'123', u'456', ignorecase=True) == u'abc456abc'
    assert regex_replace(u'abc\n123\nabc', u'\n', u'', multiline=True) == u'abc123abc'
    assert regex_replace(u'abc\n123\nabc', u'\n', u'', ignorecase=True) == u'abc\n123\nabc'
    assert regex_replace(u'abc\n123\nabc', u'\n', u'', ignorecase=True, multiline=True) == u'abc123abc'

# Generated at 2022-06-23 10:08:23.313221
# Unit test for function do_groupby
def test_do_groupby():
    class FakeEnvironment():
        def __init__(self, vars=None):
            self._data = vars or {}
        def getitem(self, obj, argument):
            """Required when attribute is not a base type
            """
            return obj[argument]
    my_env = FakeEnvironment({'my_list': [dict(name='bob',age=10),
                                         dict(name='jim',age=10),
                                         dict(name='frank',age=11),
                                         dict(name='frank',age=11)]})
    result = do_groupby(my_env, my_env._data['my_list'], 'age')

# Generated at 2022-06-23 10:08:33.746871
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('test') == 'b5c5e5b5-5c5f-5e4e-b4b0-b5b5b5b5b5b5'
    assert to_uuid('test', 'b4b0b5b5-5c5f-5e4e-b5c5-e5b5b5b5b5b5') == 'b5c5e5b5-5c5f-5e4e-b4b0-b5b5b5b5b5b5'

# Common aliases of to_uuid
uuid = to_uuid
uuid5 = to_uuid



# Generated at 2022-06-23 10:08:38.070468
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'



# Generated at 2022-06-23 10:08:43.974237
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = dict(foo='bar')
    res = dict_to_list_of_dict_key_value_elements(mydict)
    assert(res == [{'key': 'foo', 'value': 'bar'}])

    mydict = dict(foo=dict(bar='baz'))
    res = dict_to_list_of_dict_key_value_elements(mydict, key_name='foo_key', value_name='foo_value')
    assert(res == [{'foo_key': 'foo', 'foo_value': {'bar': 'baz'}}])
# end



# Generated at 2022-06-23 10:08:47.213616
# Unit test for function get_hash
def test_get_hash():
    data = 'Hello world!'
    hashtype = 'md5'
    assert get_hash(data, hashtype) == 'ed076287532e86365e841e92bfc50d8c'



# Generated at 2022-06-23 10:08:52.187691
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    import pytest
    assert 'a' == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}])['a']
    assert 'b' == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}])['b']
    assert 1 == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}])['a']
    assert 2 == list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}])['b']
    assert [None] == list_of_dict_key_

# Generated at 2022-06-23 10:08:58.664212
# Unit test for function mandatory
def test_mandatory():
    assert(mandatory('some value') == 'some value')
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert(to_native(e) == "Mandatory variable 'None' not defined.")
    try:
        mandatory(AnsibleUndefined, "Some message!")
    except AnsibleFilterError as e:
        assert(to_native(e) == "Some message!")



# Generated at 2022-06-23 10:09:07.568608
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine(dict(a=dict(b=1))) == dict(a=dict(b=1))
    assert combine(dict(a=dict(b=1)), dict(a=dict(b=2))) == dict(a=dict(b=2))
    assert (combine(dict(a=dict(b=1, g=dict(h=1, i=2))), dict(a=dict(b=2, g=dict(x=1)))) ==
            dict(a=dict(b=2, g=dict(h=1, i=2, x=1))))

# Generated at 2022-06-23 10:09:13.178069
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-03-11 10:15:10", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2018, 3, 11, 10, 15, 10)



# Generated at 2022-06-23 10:09:27.353989
# Unit test for function randomize_list
def test_randomize_list():
    testlist = [1, 2, 3, 4, 5]
    seed = 1
    result = randomize_list(testlist, seed)
    assert result == [4, 2, 5, 1, 3]
    testlist = (1, 2, 3, 4, 5)
    seed = 1
    result = randomize_list(testlist, seed)
    assert result == (4, 2, 5, 1, 3)
    # test for dicts
    testdict = dict(a=1, b=2, c=3)
    seed = 1
    result = randomize_list(testdict, seed)
    assert result == dict(a=1, b=2, c=3)
    # test for other types
    testobj = 'test'
    seed = 1
    result = randomize_list(testobj, seed)

# Generated at 2022-06-23 10:09:32.499762
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('abcde') == 'abcde'
    assert from_yaml({'a': '123'}) == {'a': '123'}
    assert from_yaml(b'foo: 123\n') == {'foo': 123}



# Generated at 2022-06-23 10:09:34.681082
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('some-string') == 'c29tZS1zdHJpbmc='



# Generated at 2022-06-23 10:09:37.959211
# Unit test for function regex_escape
def test_regex_escape():
    rstring = regex_escape('[]$^*\\.+')
    assert rstring == '\\[\\]\\$\\^\\*\\\\\\.\\+'



# Generated at 2022-06-23 10:09:46.451339
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert list(from_yaml_all("[]")) == []
    assert list(from_yaml_all("[{}]")) == [{}]
    assert list(from_yaml_all("""
- a
- b
- c
-
  d: 1
  e: 2
- &id f
- g
- h
- *id
""")) == ['a', 'b', 'c', {'d': 1, 'e': 2}, 'f', 'g', 'h', 'f']



# Generated at 2022-06-23 10:09:56.346005
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid("", "00000000-0000-0000-0000-000000000000") == 'c1a1a190-722c-11e6-bfdb-001e67caed7c'
    assert to_uuid("a") == 'c1a1a1d4-722c-11e6-b86c-001e67caed7c'
    assert to_uuid("b") == 'c1a1a201-722c-11e6-9036-001e67caed7c'
    assert to_uuid("a b") == 'c1a1a227-722c-11e6-81b6-001e67caed7c'

# Generated at 2022-06-23 10:10:02.999987
# Unit test for function combine
def test_combine():
    assert combine(dict(a=1)) == dict(a=1)
    assert combine(dict(a=1), dict(b=2)) == dict(a=1, b=2)
    assert combine(dict(a=1), dict(a=2)) == dict(a=2)
    assert combine(dict(a=1), dict(a=2, b=2)) == dict(a=2, b=2)
    assert combine(dict(a=1), dict(a=2, b=2), recursive=True) == dict(a=2, b=2)
    assert combine(dict(a=1, b=dict(c=3)), dict(a=2, b=dict(d=4)), recursive=True) == dict(a=2, b=dict(c=3, d=4))

# Generated at 2022-06-23 10:10:10.204702
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 'A'}, {'key': 'b', 'value': 'B'}]
    result = list_of_dict_key_value_elements_to_dict(mylist)
    assert result == {u'a': u'A', u'b': u'B'}
    # Test that it works with non unique keys
    mylist = [{'key': 'a', 'value': 'A1'}, {'key': 'b', 'value': 'B'}, {'key': 'a', 'value': 'A2'}]
    result = list_of_dict_key_value_elements_to_dict(mylist)
    assert result == {u'a': u'A2', u'b': u'B'}
    # Test that it works with

# Generated at 2022-06-23 10:10:13.736579
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'dict': {'from': 'python'}}) == "---\ndict:\n    from: python\n"



# Generated at 2022-06-23 10:10:19.641779
# Unit test for function regex_findall
def test_regex_findall():
    value_input = "version.1.2.3"
    assert regex_findall(value_input, r"version.(\d+)") == [u"1", u"2", u"3"]
    assert regex_findall(value_input, r"version.(\d+\\.\d+)") == [u"1.2.3"]
    assert regex_findall(value_input, r"version.(\d+\.\d+)") == [u"1.2.3"]
    assert regex_findall(value_input, r"version.(\d+)", ignorecase=True) == [u"1", u"2", u"3"]
    assert regex_findall(value_input, r"version.(\d+\\.\d+)", ignorecase=True) == [u"1.2.3"]

# Generated at 2022-06-23 10:10:31.093822
# Unit test for function rand
def test_rand():
    #randomChoice
    assert rand(None, ['a','b','c']) in ['a','b','c']
    #randomChoiceSeed
    seed = 1234567890
    assert rand(None, ['a','b','c'], seed=seed) in ['a','b','c']
    assert rand(None, ['a','b','c'], seed=seed) in ['a','b','c']
    assert rand(None, ['a','b','c'], seed=seed) in ['a','b','c']
    #randomRange
    assert rand(None, 3) in [0,1,2]
    assert rand(None, 2) in [0,1]


# Generated at 2022-06-23 10:10:40.736519
# Unit test for function fileglob
def test_fileglob():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.errors import AnsibleError

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.mock_path = 'ansible.utils.listify_lookup_plugin_terms.os.path'

        def tearDown(self):
            pass

        def test_fileglob(self):
            with patch(self.mock_path) as mock_os_path:
                mock_os_path.glob = lambda x: ['a', 'b', 'c']
                mock_os_path.isfile.side_effect = lambda x: x in ('a', 'b')
                output = fileglob('/tmp')

# Generated at 2022-06-23 10:10:45.767776
# Unit test for function to_nice_json
def test_to_nice_json():
    data = [1, 2, 3, "simple", "test"]
    nice_json = to_nice_json(data, indent=4)
    assert nice_json == '[\n    1,\n    2,\n    3,\n    "simple",\n    "test"\n]'


# Generated at 2022-06-23 10:10:55.910337
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('11 foo', r'\d{2}') == ['11']
    assert regex_findall('foo11foo', r'\d{2}') == ['11']
    assert regex_findall('f11oo', r'\d{2}') == ['11']
    assert regex_findall('11foo', r'\d{2}') == ['11']
    assert regex_findall('af11af', r'\d{2}') == ['11']
    # multiline mode
    assert regex_findall('f11oo\n11', r'\d{2}', multiline=True) == ['11', '11']
    assert regex_findall('f11oo\r11', r'\d{2}', multiline=True) == ['11', '11']

# Generated at 2022-06-23 10:11:08.808555
# Unit test for function path_join
def test_path_join():
    assert path_join([u'/usr', u'bin', u'python']) == u'/usr/bin/python'
    assert path_join(['/usr', 'bin', 'python']) == '/usr/bin/python'
    assert path_join('/usr/bin/python') == '/usr/bin/python'
    assert path_join(u'/usr/bin/python') == u'/usr/bin/python'
    assert path_join([u'/usr', 'bin', 'python']) == u'/usr/bin/python'
    assert path_join(['/usr', u'bin', 'python']) == '/usr/bin/python'
    assert path_join([u'/usr', u'bin', u'python']) == u'/usr/bin/python'


# Generated at 2022-06-23 10:11:16.133894
# Unit test for function path_join
def test_path_join():
    # Test for a string
    paths = '/tmp/a/b'
    assert path_join(paths) == os.path.join(paths)
    # Test for a directory
    paths = ['/tmp', 'a', 'b']
    assert path_join(paths) == os.path.join(*paths)
# Test it
test_path_join()



# Generated at 2022-06-23 10:11:24.340604
# Unit test for function flatten
def test_flatten():
    assert [1, 2, 3] == flatten([1, 2, 3])
    assert [1, 2, 3] == flatten([1, [2], [[3]]])
    assert [1, 2, 3] == flatten([1, [2], [[3]]], skip_nulls=False)
    assert [1, 2, 3] == flatten([1, [None], [[3]]], skip_nulls=False)
    assert [1, 2, 3, [4]] == flatten([1, [2], [[3, [4]]]], skip_nulls=False)
    assert [1, 2, 3] == flatten([1, [2], [[3, [4]]]])

# Generated at 2022-06-23 10:11:28.264785
# Unit test for function from_yaml_all
def test_from_yaml_all():
    data = '''
    - foo
    - bar
    '''
    assert ['foo', 'bar'] == from_yaml_all(data)



# Generated at 2022-06-23 10:11:39.052874
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    environment = JinjaEnvironment()
    template = environment.from_string("{%- set source = [{'a':1,'b':2},{'a':1,'b':3},{'a':2,'b':4}] -%}\n{{ source|groupby('a') }}")
    assert template.render() == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"

    template = environment.from_string("{%- set source = [('a',1,'b',2),('a',1,'b',3),('a',2,'b',4)] -%}\n{{ source|groupby('a') }}")

# Generated at 2022-06-23 10:11:48.601110
# Unit test for function from_yaml
def test_from_yaml():
    # Check that function from_yaml() can load yaml data for a particular
    # hash entry. This hash entry is properly formatted as a yaml string.
    test_data = {'foo': 'bar', 'baz': 'qux'}
    from_yaml_data = from_yaml(to_nice_yaml(test_data))
    assert from_yaml_data == test_data



# Generated at 2022-06-23 10:11:58.862614
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool('True') is True
    assert to_bool(1) is True
    assert to_bool('1') is True
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('false') is False
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('on') is True
    assert to_bool([1, 2]) == [1, 2]
    assert to_bool('') is False
    assert to_bool('1234') is True



# Generated at 2022-06-23 10:12:05.651927
# Unit test for function to_yaml
def test_to_yaml():
    d = { 'foo': 'bar', 'baz': [1, 2, '3'] }
    assert to_yaml(d, default_flow_style=False) == "baz:\n- 1\n- 2\n- '3'\nfoo: bar\n", 'Failed to_yaml test'


# Generated at 2022-06-23 10:12:11.691577
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'



# Generated at 2022-06-23 10:12:20.762976
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid(0) == '361e6d51-faed-55f2-80a2-341386da8e2e'
    assert to_uuid('foo') == 'e15c27d3-e72a-5878-8c6b-420e9f1a2d0a'
    assert to_uuid('foo', to_native(UUID_NAMESPACE_ANSIBLE)) == 'e15c27d3-e72a-5878-8c6b-420e9f1a2d0a'
    assert to_uuid('foo', to_native(UUID_NAMESPACE_ANSIBLE).replace('-', '')) == 'e15c27d3-e72a-5878-8c6b-420e9f1a2d0a'

# Generated at 2022-06-23 10:12:27.943947
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=1) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=2) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=3) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-23 10:12:34.606451
# Unit test for function path_join
def test_path_join():
    ''' test path_join'''
    assert path_join(['a', 'b', 'c']) == 'a/b/c'
    assert path_join('a/b/c') == 'a/b/c'
    try:
        path_join(dict(a=1))
        assert False, "should have raised an exception"
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-23 10:12:45.689759
# Unit test for function from_yaml_all
def test_from_yaml_all():
    d = from_yaml_all("""
    - one
    - two
    - three
    """)
    assert d == [u'one', u'two', u'three']
    assert isinstance(d, list)

    d = from_yaml_all(u"""
    - one
    - two
    - three
    """)
    assert d == [u'one', u'two', u'three']
    assert isinstance(d, list)

    d = from_yaml_all(b"""
    - one
    - two
    - three
    """)
    assert d == [u'one', u'two', u'three']
    assert isinstance(d, list)



# Generated at 2022-06-23 10:12:50.358879
# Unit test for function from_yaml_all
def test_from_yaml_all():
    test_yaml = """
    - a: alice
      b: bob
    - a: adam
      b: barney
    """
    # from_yaml_all should return a list of dictionaries
    assert from_yaml_all(test_yaml)[0]['a'] == "alice"



# Generated at 2022-06-23 10:12:53.845899
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo.bar[1]') == 'foo\\.bar\\[1\\]'
    assert regex_escape('foo.bar[1]', re_type='posix_basic') == 'foo\\.bar\\[1\\]'


# Use str.format as a runner for tests

# Generated at 2022-06-23 10:13:00.310640
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('   foo  ') == '   foo  '
    assert regex_replace('abc123abc', pattern='[0-9]+') == 'abcabc'
    assert regex_replace('abc123abc', pattern='[0-9]+', replacement='#') == 'abc#abc'



# Generated at 2022-06-23 10:13:13.768521
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # Test data contains a single document, and a multi-document sequence.
    test_data1 = """---
    - foo
    - bar
    ---
    - baz
    - qux
    """
    # A single document should be returned as a single-item list
    assert(isinstance(from_yaml_all(test_data1), list))
    assert(len(from_yaml_all(test_data1)) == 1)
    assert(from_yaml_all(test_data1)[0] == from_yaml(test_data1))
    # We can't just do the same thing with a blank list, because the
    # CSafeLoader eats blank lines, so the blank list would yield
    # multiple documents (the same as the test data)
    blank_list = []

# Generated at 2022-06-23 10:13:18.548106
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert isinstance(from_yaml_all("---\n- { key: value }"), list)
    assert isinstance(from_yaml_all("- { key: value }\n- { key: value }"), list)
    assert isinstance(from_yaml_all("{ key: value }\n{ key: value }"), list)



# Generated at 2022-06-23 10:13:22.879526
# Unit test for function combine
def test_combine():
    assert combine({'foo': 'bar'}) == {'foo': 'bar'}
    assert combine({'foo': 'bar'}, recursive=True) == {'foo': 'bar'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}) == {'foo': 'baz'}
    assert combine({'foo': 'bar'}, {'foo': 'baz'}, recursive=True) == {'foo': 'baz'}
    assert combine({'foo': 'bar'}, {'baz': 'qux'}) == {'foo': 'bar', 'baz': 'qux'}
    assert combine({'foo': 'bar'}, {'baz': 'qux'}, recursive=True) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 10:13:34.909408
# Unit test for function rand
def test_rand():
    assert rand(None, 0, 10) in list(range(0, 10))
    assert rand(None, 0, 10, 2) in list(range(0, 10, 2))
    assert rand(None, list(range(0, 10))) in list(range(0, 10))
    try:
        assert rand(None, 0, 10, 2, seed=1234) in list(range(0, 10, 2))
    except AssertionError as e:
        # We want to make sure that AssertionError is coming from the actual assert
        # statement. If it doesn't, we want to raise the real error.
        if "assert" not in str(e):
            reraise(*sys.exc_info())
        assert rand(None, 0, 10, 2, seed=1234) in list(range(0, 10, 2))

# Generated at 2022-06-23 10:13:40.469358
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", 1444428500) == '2015-10-07 15:55:00'
    assert strftime("%Y-%m-%d %H:%M:%S") != '2015-10-07 15:55:00'


# Generated at 2022-06-23 10:13:51.344450
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid(b"test") == u"e721a4a4-9a4b-5496-8a01-fb3870c878c3"
    assert to_uuid("test", namespace=UUID_NAMESPACE_ANSIBLE) == u"e721a4a4-9a4b-5496-8a01-fb3870c878c3"
    assert to_uuid("test", namespace=u"361E6D51-FAEC-444A-9079-341386DA8E2E") == u"e721a4a4-9a4b-5496-8a01-fb3870c878c3"



# Generated at 2022-06-23 10:13:54.103605
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2, c=3)) == to_text('''\
a: 1
b: 2
c: 3
''')


# Generated at 2022-06-23 10:13:55.971837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print(FilterModule.filters().keys())
    pass

# Generated at 2022-06-23 10:13:59.123472
# Unit test for function regex_findall
def test_regex_findall():
    regex_findall("[0-9]+", "[0-9]+")
    regex_findall("[0-9]+", "[0-9]+", ignorecase=True)
    regex_findall("[0-9]+", "[0-9]+", multiline=True)
    regex_findall("[0-9]+", "[0-9]+", ignorecase=True, multiline=True)


# Generated at 2022-06-23 10:14:04.809309
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('VGhlcmUgaXMgbm8gc2FmZXIgcGxhY2UgaW4gdGhlIHdvcmxk') == 'There is no safer place in the world'
    assert b64decode('VGhlcmUgaXMgbm8gc2FmZXIgcGxhY2UgaW4gdGhlIHdvcmxk', 'ascii') == 'There is no safer place in the world'
    assert b64decode('VGhlcmUgaXMgbm8gc2FmZXIgcGxhY2UgaW4gdGhlIHdvcmxk', 'iso-8859-15') == 'There is no safer place in the world'

# Generated at 2022-06-23 10:14:15.228832
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # Test input date
    data = {
      "name": "Foo",
      "role": "Bar",
      "uid": 123,
      "details": {
        "name": "Foo",
        "uid": 123
      },
      "list": ["item 0", "item 1"]
    }
    # Validate the test input
    assert isinstance(data, dict)
    # Format data as yaml
    yaml_string = to_nice_yaml(data)
    assert isinstance(yaml_string, str)
    # Load the yaml back into  python
    yaml_dict = yaml.load(text_type(yaml_string), Loader=yaml.loader.SafeLoader)
    assert isinstance(yaml_dict, dict)
    # Compare the stringified python dictionary to the original dictionary


# Generated at 2022-06-23 10:14:25.303352
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'a': 2, 'c': 3}, list_merge='append') == {'a': 1, 'b': 2, 'c': 3}
    assert combine({'a': 1, 'b': 2}, {'a': [2]}, list_merge='append') == {'a': [2, 1], 'b': 2}
    assert combine({'a': 1, 'b': 2}, {'a': [2]}, list_merge='replace') == {'a': [2], 'b': 2}
    assert combine({'a': 1, 'b': [1, 2]}, {'a': 2, 'b': [3, 4]}, list_merge='append') == {'a': 1, 'b': [1, 2, 3, 4]}
   

# Generated at 2022-06-23 10:14:27.189620
# Unit test for function path_join
def test_path_join():
    assert path_join('/usr/local/bin') == '/usr/local/bin' and path_join('/usr/local', 'bin') == '/usr/local/bin'



# Generated at 2022-06-23 10:14:29.574610
# Unit test for function get_hash
def test_get_hash():
    import types
    assert isinstance(get_hash('test'), types.StringType)
    assert isinstance(get_hash('test', 'sha256'), types.StringType)
    assert isinstance(get_hash('test', 'sha1'), types.StringType)



# Generated at 2022-06-23 10:14:34.337949
# Unit test for function rand
def test_rand():
    assert rand(1, 10) >= 1
    assert rand(1, 10) < 10
    assert rand(10, 1, -1) <= 10
    assert rand(10, 1, -1) > 1
    assert rand(1, 10, 2) >= 1
    assert rand(1, 10, 2) < 10
    assert rand(10, 1, -2) <= 10
    assert rand(10, 1, -2) > 1
    assert rand([2, 4]) in [2, 4]
    assert rand([2, 4], seed=1) in [2, 4]
    assert rand([2, 4], seed=1) not in [2, 4]



# Generated at 2022-06-23 10:14:38.168367
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('True') is True
    assert to_bool('true') is True
    assert to_bool('TRUE') is True
    assert to_bool('1') is True
    assert to_bool(1) is True
    assert to_bool(True) is True
    assert to_bool('False') is False
    assert to_bool('false') is False
    assert to_bool('FALSE') is False
    assert to_bool('0') is False
    assert to_bool(0) is False
    assert to_bool(None) is None
    assert to_bool(False) is False



# Generated at 2022-06-23 10:14:39.329316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.errors import AnsibleFil

# Generated at 2022-06-23 10:14:45.647202
# Unit test for function to_json
def test_to_json():
    assert(isinstance(to_json(None), text_type))
    assert(isinstance(to_json(''), text_type))
    assert(isinstance(to_json("foo"), text_type))
    assert(isinstance(to_json(1), text_type))
    assert(isinstance(to_json(1.1), text_type))
    assert(isinstance(to_json({}), text_type))
    assert(isinstance(to_json({'foo': 'bar'}), text_type))
    assert(isinstance(to_json({'foo': ['bar', 'baz']}), text_type))
    assert(isinstance(to_json([1,2,3]), text_type))
    assert(isinstance(to_json(True), text_type))

# Generated at 2022-06-23 10:14:55.289918
# Unit test for function from_yaml

# Generated at 2022-06-23 10:14:59.133588
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(u'abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert get_hash(u'', hashtype='md5') == 'd41d8cd98f00b204e9800998ecf8427e'



# Generated at 2022-06-23 10:15:07.206777
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    data = {"mylist": [
        "one",
        "two",
        "three"
    ], "mysubdict": {
        "one": 1,
        "two": 2,
        "three": 3
    }, "mystr": "hello", "myint": 1, "myfloat": 1.1}
    result = to_nice_yaml(data)
    assert result == '''\
myfloat: 1.1
myint: 1
mylist:
  - one
  - two
  - three
mystr: hello
mysubdict:
  one: 1
  three: 3
  two: 2
'''


# Generated at 2022-06-23 10:15:17.867401
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    from collections import OrderedDict # OrderedDict preserves order

    data = OrderedDict()
    data['a'] = 'first'
    data['b'] = 'second'
    data['c'] = 'third'

    t = dict_to_list_of_dict_key_value_elements(data)
    assert t == [{'key': 'a', 'value': 'first'}, {'key': 'b', 'value': 'second'}, {'key': 'c', 'value': 'third'}], \
        "dict_to_list_of_dict_key_value_elements() failed"



# Generated at 2022-06-23 10:15:25.175983
# Unit test for function fileglob
def test_fileglob():
    # Create test directory
    dir = __file__ + '_test_fileglob'
    os.mkdir(dir)
    os.mkdir(dir + '/foo')
    # Create test files
    file = open(dir + '/file', 'w')
    file.close()
    file = open(dir + '/foo/file', 'w')
    file.close()
    # Execute test
    assert(sorted(fileglob(dir + '/*')) == [dir + '/file'])
    # Cleanup
    os.remove(dir + '/file')
    os.remove(dir + '/foo/file')
    os.rmdir(dir + '/foo')
    os.rmdir(dir)


# Generated at 2022-06-23 10:15:27.720405
# Unit test for function ternary
def test_ternary():
    assert True == ternary(True, True, False)
    assert False == ternary(False, True, False)