

# Generated at 2022-06-23 10:05:33.741875
# Unit test for function combine
def test_combine():
    data = {
        'a': '1',
        'b': '2',
        'c': '3',
        'd': {
            'd1': '4',
            'd2': '5'
        }
    }
    data2 = {
        'a': '11',
        'b': '22',
        'd': {
            'd1': '44',
            'd3': '55'
        },
        'e': '66'
    }


# Generated at 2022-06-23 10:05:41.219731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from . import TestModuleFilters
    # Test with and without explicit self
    # Because of 'self' our methods are not always functions.

    # Test with self implicit
    t = TestModuleFilters()
    for k in t.filters().keys():
        globals()['test_' + k]()

    # Test with self explicit
    for k in t.filters().keys():
        globals()['test_' + k](t)



# Generated at 2022-06-23 10:05:48.795987
# Unit test for function mandatory
def test_mandatory():
    # Pass
    mandatory(1)
    # Fail
    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError:
        assert True
    # Pass with exception message
    try:
        mandatory(Undefined(), "Custom message")
        assert False
    except AnsibleFilterError as e:
        assert "Custom message" == e.message
# End unit test



# Generated at 2022-06-23 10:05:51.022921
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4], seed=None) == [2, 4, 3, 1]



# Generated at 2022-06-23 10:05:58.507193
# Unit test for function strftime
def test_strftime():
    res = strftime("%Y-%m-%d %H:%M:%S", second=1424164389)
    assert res == "2015-02-19 06:39:49"
    res = strftime("%Y-%m-%d %H:%M:%S", second=1424164389.345)
    assert res == "2015-02-19 06:39:49"
    res = strftime("%Y-%m-%d %H:%M:%S", second=1424164389.999)
    assert res == "2015-02-19 06:39:50"
    try:
        strftime("%Y-%m-%d %H:%M:%S", second="ABC")
        assert False
    except Exception:
        assert True

# Generated at 2022-06-23 10:06:00.101961
# Unit test for function do_groupby
def test_do_groupby():
    assert do_groupby([{'name': 'a'}, {'name': 'b'}], 'name') == [('a', [{'name': 'a'}]), ('b', [{'name': 'b'}])]


# Generated at 2022-06-23 10:06:05.411038
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('ABC123', '^ABC\d{3}$') == 'ABC123'
    assert regex_search('ABC123', '^ABC(\d{3})$', '\\1') == '123'
    assert regex_search('ABC123', '^ABC(\d{3})$', '\\g<1>') == '123'
    assert regex_search('ABC123', '^ABC(\d{3})$', '\\g<1>', '\\1') == ['123', '123']
    assert regex_search('ABC123', '^ABC(\d{3})$', '\\2') == []
    assert regex_search('ABC123', '^ABC(\d{3})$', '\\1', '\\2') == ['123']



# Generated at 2022-06-23 10:06:09.776673
# Unit test for function fileglob
def test_fileglob():
    # create a file
    pathname = ""
    with open(pathname, "w+") as text_file:
        text_file.write("Content")
        text_file.close()
    # run unit test
    assert any(pathname in file for file in fileglob(pathname))
    # remove file
    os.remove(pathname)


# Generated at 2022-06-23 10:06:11.593783
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test for method filters of class FilterModule'''
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-23 10:06:16.674122
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('my data', 'md5') == 'dffd6021bb2bd5b0af676290809ec3a53191dd81'
    assert get_hash('my data', 'sha1') == 'f1d2d2f924e986ac86fdf7b36c94bcdf32beec15'
    assert get_hash('my data', 'sha256') == '5a88d79a0c5f5ed5f8d7a9e86699748d7a3a3c857e59bdb76c7e7e83f32d087d'



# Generated at 2022-06-23 10:06:28.348847
# Unit test for function randomize_list
def test_randomize_list():
    cases = [
        (['a', 'b', 'c'], None),
        ([], None),
        ([0], None),
        ([0], 'a'),
        (['a'], None),
        (['a'], 'a'),
        (['a', 'b', 'c'], 'a'),
        (['a', 'b', 'c'], 'b'),
    ]

    for (input_value, seed) in cases:
        expected = sorted(input_value)
        result = sorted(randomize_list(input_value, seed))
        assert result == expected



# Generated at 2022-06-23 10:06:39.673560
# Unit test for function rand
def test_rand():
    env = Environment()

    # Test random choice from a sequence
    seq = list(range(3))
    assert rand(env, seq) in seq
    assert rand(env, seq, seed=1) in seq
    assert rand(env, seq, seed=1) == rand(env, seq, seed=1)

    # Test random number generation
    assert rand(env, 5) >= 0 and rand(env, 5) < 5
    assert rand(env, 5, seed=1) == 3
    assert rand(env, 5, seed=1) == rand(env, 5, seed=1)
    assert rand(env, 5, seed=1) != rand(env, 5, seed=2)
    assert rand(env, 3, 6) >= 3 and rand(env, 3, 6) < 6

# Generated at 2022-06-23 10:06:47.468158
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    # Test for with msg
    try:
        mandatory(Undefined('a'), '{{ a }} is undefined')
        raise AssertionError('Expected AnsibleFilterError')
    except AnsibleFilterError as e:
        assert str(e) == "{{ a }} is undefined"
    # Test for without msg
    try:
        mandatory(Undefined('a'))
        raise AssertionError('Expected AnsibleFilterError')
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'a' not defined."



# Generated at 2022-06-23 10:06:54.547594
# Unit test for function to_bool
def test_to_bool():
    f = to_bool
    assert f(None) is None
    assert f(True) is True
    assert f(False) is False
    assert f(0) is False
    assert f(1) is True
    assert f('1') is True
    assert f('0') is False
    assert f('false') is False
    assert f('true') is False
    assert f('yes') is True
    assert f('no') is False


# Generated at 2022-06-23 10:07:03.293195
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'qux'}]) == {'foo': 'bar', 'baz': 'qux'}
    assert list_of_dict_key_value_elements_to_dict([{'value': 'bar', 'key': 'foo'}, {'value': 'qux', 'key': 'baz'}]) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 10:07:05.858664
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'


# Generated at 2022-06-23 10:07:08.747220
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 2, 3) == 2
    assert ternary(False, 2, 3) == 3
    assert ternary(None, 'a', 'b', 'none') == 'none'



# Generated at 2022-06-23 10:07:14.709018
# Unit test for function extract
def test_extract():

    container = {
        'foo': {
            'bar': {
                0: 'baz'
            }
        }
    }

    assert 'baz' == extract('bar', container)
    assert 'baz' == extract('bar', container, 0)
    assert 'baz' == extract('foo', container, ['bar', 0])


# Generated at 2022-06-23 10:07:21.889189
# Unit test for function extract
def test_extract():
    from jinja2 import DictEnvironment

    def pytest_funcarg__env(request):
        env = DictEnvironment()
        env.extend(dict(
            extract=extract,
        ))
        return env


# Generated at 2022-06-23 10:07:31.791180
# Unit test for function to_uuid
def test_to_uuid():
    u1 = to_uuid('127.0.0.1')
    assert u1 == '95fb368e-6ec1-5956-a0a5-611c7095e5f6'
    assert isinstance(u1, text_type)
    u2 = to_uuid('127.0.0.1', namespace=u1)
    assert u2 == '5a7d5fe5-5dac-5c2a-a8a1-eafd34fe49c0'
    assert u1 != u2



# Generated at 2022-06-23 10:07:37.496975
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()

    # Commenting tests for now, as we do not use the method in
    # Ansible and the method is deprecated in Jinja2 >= 2.9.
    # ------------------------
    # Test comment filters
    # ------------------------
    #
    # assert f.filters()['comment']('Hello world!') == '# Hello world!'
    # assert f.filters()['comment']('Hello world!', style='erlang') == '% Hello world!'
    # assert f.filters()['comment']('Hello world!', style='c') == '// Hello world!'
    # assert f.filters()['comment']('Hello world!', style='cblock') == '/*\n * Hello world!\n */'
    # assert f.filters()['comment']('Hello world!', style='xml') == '<!--

# Generated at 2022-06-23 10:07:48.162807
# Unit test for function regex_replace
def test_regex_replace():
    '''Unit test for function "regex_replace".'''
    assert regex_replace(pattern='-', replacement=' ', value='foo-bar-baz') == 'foo bar baz'
    assert regex_replace(pattern='-', replacement=' ', value='foo-bar-baz', ignorecase=True) == 'foo bar baz'
    assert regex_replace(pattern='-', replacement=' ', value='foo-bar-baz', multiline=True) == 'foo bar baz'
    assert regex_replace(pattern='-', replacement=' ', value='foo-bar-baz', multiline=True, ignorecase=True) == 'foo bar baz'
    # check for type conversion
    assert regex_replace(pattern='bar', replacement='foo', value=['bar', 'baz']) == 'foo'
    assert regex_replace

# Generated at 2022-06-23 10:07:57.013925
# Unit test for function from_yaml_all
def test_from_yaml_all():
    f = from_yaml_all
    assert isinstance(f([]), list)
    assert isinstance(f({}), dict)
    assert isinstance(f(''), dict)
    assert isinstance(f('---\n'), dict)
    assert isinstance(f('---\n{}'), dict)
    assert isinstance(f('---\n{}\n---\n'), list)
    assert isinstance(f('---\n{}\n---\n{}'), list)



# Generated at 2022-06-23 10:08:06.707119
# Unit test for function rand
def test_rand():
    """
    This unit test requires:
        - pytest
    """
    from jinja2 import Environment
    env = Environment()
    env.filters['rand'] = rand

    assert rand(end=4, seed=42) == 2
    assert rand(environment=env, end=4, seed=42) == 2
    assert rand(end=4, start=2, seed=42) == 3
    assert rand(end=4, start=2, step=2, seed=42) == 2
    assert rand(end=[3, 2, 1], seed=42) == 3
    assert rand(environment=env, end=[3, 2, 1], seed=42) == 3



# Generated at 2022-06-23 10:08:12.651514
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = 's3cr3t'
    hashtype = 'sha512'
    salt = 'T'  # default 2 char salt
    salt_size = None
    rounds = None
    ident = None
    try:
        assert get_encrypted_password(password, hashtype) == get_encrypted_password(password, hashtype=hashtype, salt=salt, salt_size=salt_size, rounds=rounds, ident=ident)
    except Exception as e:
        assert False, to_text(e)



# Generated at 2022-06-23 10:08:18.618663
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
  mylist = [{'key': 'name', 'value': 'bob'}, {'key': 'age', 'value': '20'}]
  mydict = list_of_dict_key_value_elements_to_dict(mylist)
  assert mydict == {'name': 'bob', 'age': '20'}



# Generated at 2022-06-23 10:08:28.908315
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': "key1", 'value': 'value1'}, {'key': "key2", 'value': 'value2'}]
    mydict = {"key1": 'value1', "key2": 'value2'}
    assert (list_of_dict_key_value_elements_to_dict(mylist) == mydict)
    mylist = [{'KEy': "key1", 'VaLUe': 'value1'}, {'KEy': "key2", 'VaLUe': 'value2'}]
    assert (list_of_dict_key_value_elements_to_dict(mylist, 'KEy', 'VaLUe') == mydict)



# Generated at 2022-06-23 10:08:37.182549
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # test filters method
    fltrs = FilterModule().filters()
    assert 'b64encode' in fltrs
    assert 'b64decode' in fltrs
    assert 'to_json' in fltrs
    assert 'from_json' in fltrs
    assert 'to_yaml' in fltrs
    assert 'from_yaml' in fltrs
    assert 'to_datetime' in fltrs
    assert 'quote' in fltrs
    assert 'md5' in fltrs
    assert 'sha1' in fltrs
    assert 'checksum' in fltrs

# Generated at 2022-06-23 10:08:41.080936
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'foo': 'bar', 'baz': 'quux'}
    result = dict_to_list_of_dict_key_value_elements(mydict)
    assert result == [{'key': 'foo', 'value': 'bar'}, {'key': 'baz', 'value': 'quux'}]



# Generated at 2022-06-23 10:08:51.296323
# Unit test for function get_encrypted_password

# Generated at 2022-06-23 10:08:59.370371
# Unit test for function subelements
def test_subelements():
    obj = [
        {'name': 'alice', 'groups': ['wheel', 'staff'], 'authorized': ['/tmp/alice/onekey.pub'], 'attr': {'fingerprint': '00:11:22:33:44:55:66:77:88:99:aa:bb:cc:dd:ee:ff'}},
        {'name': 'bob', 'groups': ['wheel', 'othergroup'], 'authorized': ['/tmp/bob/twokeys.pub'], 'attr': {'fingerprint': '00:11:22:33:44:55:66:77:88:99:aa:bb:cc:dd:ee:00'}}
    ]

# Generated at 2022-06-23 10:09:03.855980
# Unit test for function b64encode
def test_b64encode():
    assert b64encode("hello world", encoding='utf-8') == u'aGVsbG8gd29ybGQ='
    assert b64encode("hello world", encoding='latin-1') == u'aGVsbG8gd29ybGQ='



# Generated at 2022-06-23 10:09:17.933765
# Unit test for function to_nice_json
def test_to_nice_json():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    obj = dict(one=1, two=2, three=3, four=4, five=5)
    assert to_nice_json(obj) == '{\n    "five": 5, \n    "four": 4, \n    "one": 1, \n    "three": 3, \n    "two": 2\n}'

    obj = dict(test=[dict(test=dict(test=[1, 2, 3]))])
    assert to_nice_json(obj) == '{\n    "test": [\n        {\n            "test": {\n                "test": [\n                    1, \n                    2, \n                    3\n                ]\n            }\n        }\n    ]\n}'


# Generated at 2022-06-23 10:09:27.004440
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_dict = {"Hello": {"world": 1, "ansible": "2.0"}}
    nice_yaml = to_nice_yaml(test_dict)
    assert(nice_yaml == "Hello:\n    world: 1\n    ansible: 2.0\n")

    nice_yaml = to_yaml(test_dict)
    transformed = yaml.load(nice_yaml, Loader=AnsibleLoader)
    assert(transformed == test_dict)



# Generated at 2022-06-23 10:09:33.259557
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool(None) == None
    assert to_bool('yes') == True
    assert to_bool('no') == False
    assert to_bool('on') == True
    assert to_bool('off') == False
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool('foo') == False
test_to_bool()


# Generated at 2022-06-23 10:09:46.288163
# Unit test for function b64decode
def test_b64decode():
    # Unit tests for b64decode.
    # NOTE:  These unit tests are slightly different than the implementation in
    # filters/core.py.  However, both functions return the same result.
    #
    # The implementation in filters/core.py uses the following in order to avoid
    # incompatible type errors:
    #     string = to_bytes(string, errors='surrogate_or_strict')
    #
    # The implementation here uses the following in order to avoid
    # incompatible type errors:
    #     string = to_native(string, errors='strict', nonstring='simplerepr')
    #
    # Both approaches return the same result.
    #
    # This was reported as GH-22042.
    assert b64decode(b64encode('test')) == 'test'

# Generated at 2022-06-23 10:09:55.186788
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('abc') == 'abc'
    assert regex_escape('a.b') == 'a\\.b'
    assert regex_escape('a$b') == 'a\\$b'
    assert regex_escape('a*b') == 'a\\*b'
    assert regex_escape('a[b') == 'a\\[b'
    assert regex_escape('a]b') == 'a\\]b'
    assert regex_escape('a^b') == 'a\\^b'
    assert regex_escape('a(b') == 'a\\(b'
    assert regex_escape('a)b') == 'a\\)b'



# Generated at 2022-06-23 10:10:00.095544
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}] == dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2})



# Generated at 2022-06-23 10:10:08.916865
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    # test null list
    assert None == list_of_dict_key_value_elements_to_dict([])
    # test one item
    assert {'key1': 'value1'} == list_of_dict_key_value_elements_to_dict([{'key': 'key1', 'value': 'value1'}])
    # test two items
    assert {'key1': 'value1', 'key2': 'value2'} == list_of_dict_key_value_elements_to_dict([{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}])
    # test two items, with a different key label
    assert {'key1': 'value1', 'key2': 'value2'} == list_of_dict

# Generated at 2022-06-23 10:10:20.552641
# Unit test for function path_join
def test_path_join():
    assert os.path.join('foo', 'bar', 'baz') == path_join(['foo', 'bar', 'baz'])
    assert os.path.join('foo', 'bar', 'baz') == path_join('foo/bar/baz')
    assert os.path.join('foo', 'bar', 'baz') == path_join('foo/bar', 'baz')
    assert os.path.join('foo', 'bar', 'baz') == path_join('foo', 'bar/baz')
    assert os.path.join('foo', 'bar', 'baz') == path_join('foo/bar', 'baz')
    assert os.path.join('foo', 'bar', 'baz') == path_join('foo', 'bar/baz')

# Generated at 2022-06-23 10:10:29.425161
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'.*{}[]?+$^()|\/') == r'\.\*\{\}\[\]\?\+\$\^\(\)\|\\/'
    assert regex_escape(r'[]') == r'\[\]'
    assert regex_escape(r'[.*]', re_type='posix_basic') == r'\[\.\*\]'
    assert regex_escape(r'[.*]', re_type='posix_extended') == r'\[\.\*\]'



# Generated at 2022-06-23 10:10:36.780542
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime(to_datetime("2016-06-21", "%Y-%m-%d"), "%Y-%m-%d") == "2016-06-21"
    assert to_datetime(to_datetime("2016/06/21", "%Y/%m/%d"), "%Y-%m-%d") == "2016-06-21"
    assert to_datetime(to_datetime("21-06-2016", "%d-%m-%Y"), "%Y-%m-%d") == "2016-06-21"
    assert to_datetime(to_datetime("21-06-16", "%d-%m-%y"), "%Y-%m-%d") == "2016-06-21"

# Generated at 2022-06-23 10:10:42.016680
# Unit test for function path_join
def test_path_join():
    assert path_join(['a', 'b', 'c']) == 'a/b/c'
    assert path_join('a/b/c') == 'a/b/c'



# Generated at 2022-06-23 10:10:51.160178
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    ''' Test to_nice_yaml '''
    d = dict(x=list(range(1000)))

# Generated at 2022-06-23 10:11:03.938192
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'{foo: bar}') == {u'foo': u'bar'}
    assert from_yaml('{foo: bar}') == {u'foo': u'bar'}
    assert from_yaml('{foo: bar}') == {u'foo': u'bar'}
    assert from_yaml(b'{foo: bar}') == {u'foo': u'bar'}
    assert from_yaml(b'!a \xF0\x9F\x8D\xA2') == u'\U0001f52a'
    assert from_yaml(b'---\nfoo: bar\n') == {u'foo': u'bar'}

# Generated at 2022-06-23 10:11:15.836736
# Unit test for function get_hash
def test_get_hash():
    # Test supported hashes
    assert get_hash('foo') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert get_hash('foo', hashtype='md5') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert get_hash('foo', hashtype='sha1') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert get_hash('foo', hashtype='sha224') == 'fea8c86f72d88c6e81fea2a48c856b6d7b6fc9f9070895d1ba36555'

# Generated at 2022-06-23 10:11:24.163275
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'python.re') == 'python\\.re'
    assert regex_escape(r'foo[bar]baz.') == 'foo\\[bar\\]baz\\.'
    assert regex_escape(r'foo(bar)baz.') == 'foo\\(bar\\)baz\\.'
    assert regex_escape(r'foo{bar}baz.') == 'foo\\{bar\\}baz\\.'
    assert regex_escape(r'foo$baz.') == 'foo\\$baz\\.'
    assert regex_escape(r'foo^baz.') == 'foo\\^baz\\.'
    assert regex_escape(r'foo|baz.') == 'foo\\|baz\\.'

# Generated at 2022-06-23 10:11:36.862355
# Unit test for function to_bool
def test_to_bool():
    assert to_bool("red") == False
    assert to_bool("blue") == False
    assert to_bool("1") == True
    assert to_bool("0") == False
    assert to_bool("true") == True
    assert to_bool("false") == False
    assert to_bool("") == False
    assert to_bool(" ") == False
    assert to_bool("  ") == False
    assert to_bool("yes") == True
    assert to_bool("no") == False
    assert to_bool("on") == True
    assert to_bool("off") == False
    assert to_bool("y") == True
    assert to_bool("n") == False
    assert to_bool(0) == False
    assert to_bool(1) == True
    assert to_bool(2) == True
   

# Generated at 2022-06-23 10:11:51.765649
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha224') == '90a3ed9e32b2aaf4c61c410eb925426119e1a9dc53d4286ade99a809'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-23 10:11:54.489189
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'/\?*+[^]') == r'\/\\\?\*\+\[\^\]'


# Generated at 2022-06-23 10:12:04.099213
# Unit test for function randomize_list
def test_randomize_list():
    from collections import OrderedDict, namedtuple

    # test edge case
    types = [None, 0, 1, 1.0, "", "1", u'\u2713',
             dict(), list(), tuple(), set(), frozenset(),
             OrderedDict([(1, 2), (3, 4)]),
             namedtuple('T', 'a, b')(1, 2)]
    seed = "randomize_list test"
    for thing in types:
        if randomize_list(thing, seed) is not thing:
            raise AssertionError('randomize_list failed converting: %s' % thing)

    # test randomization
    mylist = list(range(10000))
    mylist2 = randomize_list(mylist, seed)

# Generated at 2022-06-23 10:12:11.081155
# Unit test for function regex_findall
def test_regex_findall():
    test_cases = [(["foo", "bar", "baz", "foo"], "foo"),
                  (["foo", "bo", "bazbazbar", "foo"], "baz"),
                  (["foo", "foo", "foo", "foo"], "bar"),
                  (["a \\n b", "c \\n d"], "\n")]
    for expected, case in test_cases:
        assert regex_findall(case, r"(\w+|\s+)") == expected



# Generated at 2022-06-23 10:12:13.967493
# Unit test for function fileglob
def test_fileglob():
    assert ['tmp/foo1'] == fileglob('tmp/foo1')
    assert [] == fileglob('tmp/notfound')
    assert ['tmp/foo1'] == fileglob('tmp/*1')



# Generated at 2022-06-23 10:12:20.371985
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
foo:
  - {a: 1, b: 2}
  - {a: 3, b: 4}
'''
    assert from_yaml(data) == {'foo': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]}



# Generated at 2022-06-23 10:12:26.245487
# Unit test for function path_join
def test_path_join():
    assert path_join("foo") == os.path.join("foo"), "Failed to join single path"
    assert path_join(["foo", "bar"]) == os.path.join("foo", "bar"), "Failed to join list"
    try:
        path_join([1, 2])
        raise Exception("Should raise an exception if list contains non-string items")
    except AnsibleFilterTypeError:
        pass
    except Exception as e:
        raise Exception("Raised incorrect type of exception for non-string list: %s" % e)



# Generated at 2022-06-23 10:12:36.267318
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/etc/*") == [g for g in glob.glob("/etc/*") if os.path.isfile(g)]
    assert fileglob("/etc/shadow") == [g for g in glob.glob("/etc/shadow") if os.path.isfile(g)]
    assert fileglob("/etc/pam.conf") == [g for g in glob.glob("/etc/pam.conf") if os.path.isfile(g)]
    assert fileglob("/this/path/does/not/exist") == []
    assert fileglob("/etc/") == []


# TODO: Remove me in 2.12

# Generated at 2022-06-23 10:12:42.666045
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool(None) == None
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool('True') == True
    assert to_bool('False') == False



# Generated at 2022-06-23 10:12:50.949411
# Unit test for function to_datetime
def test_to_datetime():
    string = '2018-12-17 12:12:12'
    format = '%Y-%m-%d %H:%M:%S'
    assert (to_datetime(string=string, format=format) == datetime.datetime(2018, 12, 17, 12, 12, 12))
    string = '2018-12-17 12:12'
    format = '%Y-%m-%d %H:%M'
    assert (to_datetime(string=string, format=format) == datetime.datetime(2018, 12, 17, 12, 12))
    string = '2018-12-17 12'
    format = '%Y-%m-%d %H'

# Generated at 2022-06-23 10:12:53.895705
# Unit test for function to_json
def test_to_json():
    assert to_json({'name': '"Johnny"', 'age': 12}) == '{"age": 12, "name": "\\"Johnny\\""}'



# Generated at 2022-06-23 10:13:05.000121
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'alice': 'wonder', 'bob': 'builder'}) == [{'key': 'alice', 'value': 'wonder'}, {'key': 'bob', 'value': 'builder'}]
    assert dict_to_list_of_dict_key_value_elements({'alice': 'wonder', 'bob': 'builder'}, 'foo', 'bar') == [{'foo': 'alice', 'bar': 'wonder'}, {'foo': 'bob', 'bar': 'builder'}]
    # TODO: Add tests for the not isinstance(mydict, Mapping) case so we catch regressions with dict2items


# Generated at 2022-06-23 10:13:17.445786
# Unit test for function regex_replace
def test_regex_replace():
    ''' test regex_replace function '''
    assert regex_replace('hello, world', '^(\w+), (\w+)$', '\\2, \\1') == 'world, hello'
    assert regex_replace('hello, world', r'(?P<greeting>\w+), (?P<location>\w+)', '\\g<location>, \\g<greeting>') == 'world, hello'
    assert regex_replace('abbbcdddde', '(.)\\1+', '\\1') == 'abcde'
    assert regex_replace('abbbcdddde', '(.)\\1+', '\\1', ignorecase=True) == 'abcde'
    assert regex_replace('abbbcdddde', '(.)\\1+', '\\1', ignorecase=False) == 'abcde'
    assert regex

# Generated at 2022-06-23 10:13:23.593520
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ test_FilterModule_filters
    """
    module = FilterModule()
    funcs = module.filters()
    assert funcs['groupby'] == do_groupby
    assert funcs['b64decode'] == b64decode
    assert funcs['b64encode'] == b64encode
    assert funcs['to_uuid'] == to_uuid
    assert funcs['to_json'] == to_json
    assert funcs['to_nice_json'] == to_nice_json
    assert funcs['from_json'] == from_json
    assert funcs['to_yaml'] == to_yaml
    assert funcs['to_nice_yaml'] == to_nice_yaml
    assert funcs['from_yaml'] == from_yaml

# Generated at 2022-06-23 10:13:35.499896
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(pattern='(\w+)', replacement='', value='Hello World!') == ''
    assert regex_replace(pattern='(\w+)', replacement='\1-\1', value='Hello World!') == 'Hello-Hello World-World!'
    assert regex_replace(pattern='(\w+)', replacement='\1-\1', value='Hello, World!') == 'Hello-Hello, World-World!'
    assert regex_replace(pattern='(\w+)\s*(.*)', replacement='\2 \1', value='Hello World!') == 'World! Hello'
    assert regex_replace(pattern='Hello', replacement='Bye', value='Hello World!') == 'Bye World!'
    assert regex_replace(pattern='Hello', replacement='Bye', value='Hello, World!') == 'Bye, World!'
    assert regex_replace

# Generated at 2022-06-23 10:13:44.197249
# Unit test for function path_join
def test_path_join():
    assert path_join('/abc') == '/abc'
    assert path_join(['/abc', '/def']) == '/abc/def'
    assert path_join(['/abc', 'def']) == '/abc/def'
    assert path_join(['/abc', 'def/']) == '/abc/def'
    try:
        path_join(['/abc', 4])
        assert False
    except AnsibleFilterTypeError:
        pass
    try:
        path_join(4)
        assert False
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-23 10:13:55.177613
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('ansible') == '6f10d639-4d4a-52e7-b97e-dc78a93f403b'
    assert to_uuid('ansible', '6f10d639-4d4a-52e7-b97e-dc78a93f403a') == 'a06a8b44-c7a2-5b2c-9a9b-8c7e1d65d0ea'
    assert to_uuid('ansible', 'a06a8b44-c7a2-5b2c-9a9b-8c7e1d65d0ea') == '6f10d639-4d4a-52e7-b97e-dc78a93f403b'



# Generated at 2022-06-23 10:14:02.648608
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("foo", "sha1") == hashlib.sha1("foo".encode('utf-8')).hexdigest()
    assert get_hash("foo", "sha256") == hashlib.sha256("foo".encode('utf-8')).hexdigest()
    assert get_hash("foo", "sha512") == hashlib.sha512("foo".encode('utf-8')).hexdigest()



# Generated at 2022-06-23 10:14:07.321955
# Unit test for function comment
def test_comment():
    assert comment("comment line 1\ncomment line 2", decoration=';', prefix_count=-1) == ";comment line 1\n;comment line 2"


# ------ end Jinja2 filters ------



# Generated at 2022-06-23 10:14:18.408100
# Unit test for function to_nice_json
def test_to_nice_json():
    # Test for string
    str = '{"foo": 123, "bar": "baz"}'
    assert to_nice_json(str) == '{\n    "bar": "baz", \n    "foo": 123\n}'

    # Test for dictionary
    dictionary = {"foo": 123, "bar": "baz"}
    assert to_nice_json(dictionary) == '{\n    "bar": "baz", \n    "foo": 123\n}'

    # Test for list
    list = ["foo", "bar"]
    assert to_nice_json(list) == '[\n    "foo", \n    "bar"\n]'

    # Test for tuple
    tuple = ("foo", "bar")

# Generated at 2022-06-23 10:14:24.946037
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():

    # With a single key
    assert dict_to_list_of_dict_key_value_elements({'a': 1}, 'key', 'value') == [{'key': 'a', 'value': 1}]

    # With multiple keys
    result = dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2, 'c': 3}, 'key', 'value')
    assert result == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}]



# Generated at 2022-06-23 10:14:39.329074
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('', '', '', False, False) == ''
    assert regex_replace('', '', '', False, True) == ''
    assert regex_replace('', '', '', True, False) == ''
    assert regex_replace('', '', '', True, True) == ''
    assert regex_replace('', 'foo', '', False, False) == ''
    assert regex_replace('', 'bar', '', False, True) == ''
    assert regex_replace('', '[a-z]+', '', False, False) == ''
    assert regex_replace('', 'a.*z', '', False, False) == ''
    assert regex_replace('', 'a.*z', '', False, True) == ''
    assert regex_replace('', '[a-z]+', '', False, True) == ''
    assert regex

# Generated at 2022-06-23 10:14:45.665450
# Unit test for function to_uuid

# Generated at 2022-06-23 10:14:57.114019
# Unit test for function quote
def test_quote():
    assert quote('abc') == u"'abc'"
    assert quote('"abc"') == u"'" + '"abc"' + u"'"
    assert quote("A=C B='C'") == u"'A=C B='\''C'\'''"
    assert quote("A=C B='C'", quote_type='double') == u'"A=C B=\'C\'"'
    assert quote(None) == u"''"
    assert quote('') == u"''"
    assert quote(1) == u"'1'"
    assert quote(True) == u"'True'"
    assert quote(False) == u"'False'"
    assert quote([1, 2]) == u"'[1, 2]'"
    assert quote({u'a': u'b'}) == u"'{u'a': u'b'}'"

# Generated at 2022-06-23 10:15:07.135167
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('foo') == 'foo'
    assert b64decode('QQ==') == 'A'
    assert b64decode('YQ==') == 'a'
    assert b64decode('Zg==') == 'f'
    assert b64decode('Zm8=') == 'fo'
    assert b64decode('Zm9v') == 'foo'
    assert b64decode('Zm9vYg==') == 'foob'
    assert b64decode('Zm9vYmE=') == 'fooba'
    assert b64decode('Zm9vYmFy') == 'foobar'



# Generated at 2022-06-23 10:15:17.097417
# Unit test for function from_yaml
def test_from_yaml():
    yaml_data = '''---
replace:
- server.name
- server.description
- server.ip
- server.proxy
- server.notify_email
'''
    expected_data = {
        'replace': [
            'server.name',
            'server.description',
            'server.ip',
            'server.proxy',
            'server.notify_email',
        ],
    }
    from_yaml_data = from_yaml(yaml_data)
    assert from_yaml_data == expected_data



# Generated at 2022-06-23 10:15:29.693926
# Unit test for function flatten
def test_flatten():
    assert flatten([1,2,3]) == [1,2,3]
    assert flatten([[1,2],3]) == [1,2,3]
    assert flatten([[1,[2,3]],4]) == [1,2,3,4]
    assert flatten([1,[2,[3]]],2) == [1,2,3]

    # test if nulls removed
    assert flatten([1,2,None,3]) == [1,2,3]
    assert flatten([1,2,[3,None]]) == [1,2,3]

    # test if nulls not removed
    assert flatten([1,2,None,3], skip_nulls=False) == [1,2,None,3]