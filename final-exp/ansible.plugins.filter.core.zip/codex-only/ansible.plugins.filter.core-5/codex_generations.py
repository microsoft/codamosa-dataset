

# Generated at 2022-06-23 10:05:35.455509
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc3def', 'abc', '\\g<1>') == 'abc'
    assert regex_search('abc3def', 'abc', '\\g<0>') == 'abc'
    assert regex_search('abc3def', 'abc', '\\1') == 'abc'
    assert regex_search('abc3def', 'abc', '\\0') == 'abc'
    assert regex_search('abc3def', '3', '\\1') == '3'
    assert regex_search('abc3def', 'abc', '\\g<0>', '\\g<1>') == ['abc', 'abc']
    assert regex_search('abc3def', 'abc', '\\g<0>', '\\g<2>') == ['abc', 'def']

# Generated at 2022-06-23 10:05:42.539180
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("abc", "^b", "def") == "abc"
    assert regex_replace("abc", "^a", "def") == "defbc"
    assert regex_replace("abc", "c$", "def") == "abdef"
    assert regex_replace("123", "23", "456") == "1456"
    assert regex_replace("123", "^123", "456") == "456"



# Generated at 2022-06-23 10:05:48.478844
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abcdefg', pattern='def', replacement='xyz', ignorecase=False, multiline=False) == 'abcxyzg'
    assert regex_replace('abcdefg', pattern='def', replacement='xyz', ignorecase=True, multiline=False) == 'abcxyzg'


# Generated at 2022-06-23 10:05:57.375165
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader, Environment

    # Set up jinja2 environment
    env = Environment(loader=DictLoader({
        'test.j2': '{{ items | do_groupby("foo") | list }}',
    }))
    template = env.get_template('test.j2')

    # Run the template
    template_output = template.render(dict(
        items=[
            dict(foo='bar', baz='qux'),
            dict(foo='bar', baz='quux')
        ]
    ))

    import json
    expected_output = json.dumps([
        [
            ('bar', [dict(foo='bar', baz='qux'), dict(foo='bar', baz='quux')])
        ]
    ])

    # Assert the output matches what we expect


# Generated at 2022-06-23 10:06:00.624637
# Unit test for function quote
def test_quote():
    assert quote(None) == u''
    assert quote(u'echo "Hello World"') == u'"echo \\"Hello World\\""'
    assert quote('echo "Hello World"') == u'"echo \\"Hello World\\""'



# Generated at 2022-06-23 10:06:03.724238
# Unit test for function path_join
def test_path_join():
    assert path_join('/a/b/c') == '/a/b/c'
    assert path_join('/a/b', 'c') == '/a/b/c'
    assert path_join('/a', 'b', 'c') == '/a/b/c'
    assert path_join(['/a', 'b', 'c']) == '/a/b/c'
    assert path_join('/a', ['b', 'c']) == '/a/b/c'



# Generated at 2022-06-23 10:06:15.192386
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha224') == '9c1185a5c5e9fc54612808977ee8f548b2258d31'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-23 10:06:18.377258
# Unit test for function to_uuid
def test_to_uuid():
    uuid_string1 = to_uuid('test')
    uuid_string2 = to_uuid('test')
    uuid_string3 = to_uuid('test', 'test')
    uuid_string4 = to_uuid('test', 'test')
    assert uuid_string1 == uuid_string2
    assert uuid_string3 == uuid_string4



# Generated at 2022-06-23 10:06:21.698851
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = 'mypassword'
    for hashtype in ['md5', 'blowfish', 'sha256', 'sha512']:
        enc_password = get_encrypted_password(password, hashtype=hashtype)
        assert(enc_password)
        match = get_encrypted_password(password, hashtype=hashtype, ident=enc_password[:3])
        assert(match == enc_password)


# Generated at 2022-06-23 10:06:26.940119
# Unit test for function path_join
def test_path_join():
    assert path_join("a") == "a"
    assert path_join("a", "b") == "a/b"
    assert path_join("a", "b", "c") == "a/b/c"
    assert path_join(("a", "b", "c")) == "a/b/c"
    assert path_join("a/b/c") == "a/b/c"



# Generated at 2022-06-23 10:06:30.745063
# Unit test for function strftime
def test_strftime():
    test_value = 123456789
    assert strftime('%Y-%m-%d', second=test_value) == '1973-11-29'
    assert strftime('%s', second=test_value) == '123456789'



# Generated at 2022-06-23 10:06:40.861909
# Unit test for function flatten
def test_flatten():
    assert flatten([1,2,3]) == [1,2,3]
    assert flatten([[1,2],3]) == [1,2,3]
    assert flatten([1,[2,3]]) == [1,2,3]
    assert flatten([[1,2],[3]]) == [1,2,3]
    assert flatten([['a','b'],['c','d']]) == ['a','b','c','d']
    assert flatten([[1,2,[3,4]],5]) == [1,2,3,4,5]
    assert flatten([[1,2,[3,4]],5],levels=1) == [1,2,[3,4],5]

# Generated at 2022-06-23 10:06:41.867903
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule



# Generated at 2022-06-23 10:06:46.122237
# Unit test for function strftime
def test_strftime():
    time_string = strftime('%Y-%m-%d %H:%M:%S', '1467326822')
    assert time_string == '2016-07-05 08:20:22', "strftime filter returned %s when it should have returned: 2015-05-02 16:19:13" % time_string



# Generated at 2022-06-23 10:06:51.413615
# Unit test for function to_json
def test_to_json():
    assert json.loads(to_json([1, 2, 3])) == [1, 2, 3]
    assert json.loads(to_json({"a": "b"})) == {"a": "b"}
    assert json.loads(to_json({"a": {"b": "c"}})) == {"a": {"b": "c"}}



# Generated at 2022-06-23 10:07:03.044672
# Unit test for function randomize_list
def test_randomize_list():
    class TestException(Exception):
        pass
    list_one = "abcd12345"
    list_two = ['a', 'b', 'c', 'd', '1', '2', '3', '4', '5']
    list_three = ['a', 'b', 'c', 'd', 1, 2, 3, 4, 5]
    list_four = ['a', 'b', 'c', 'd', '1', '2', '3', '4', '5']
    list_five = ['a', 'b', 'c', 'd', '1', '2', '3', '4', '5']
    # Test with string
    result = randomize_list(list_one)
    assert len(result) == len(list_one)
    # Test with list of string

# Generated at 2022-06-23 10:07:12.437309
# Unit test for function rand
def test_rand():
    ansible_vars = dict(
        generate_seed=123456789,
        random_iterable=['a', 'b', 'c'],
        random_int=rand,
    )
    ansible_env = dict(
        ansible_vars=ansible_vars,
    )
    assert rand.env is None
    # returns a random int between 0 and 1000, step 1
    assert rand(ansible_env, 1000) == 616
    # returns a random int between 0 and 1000, step 2
    assert rand(ansible_env, 1000, step=2) == 4
    # returns a random int between 100 and 1000, step 2
    assert rand(ansible_env, 1000, 100, 2) == 602
    # returns a random element from a list

# Generated at 2022-06-23 10:07:20.744596
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('0.5') == '0\\.5'
    assert regex_escape('[ab]') == '\\[ab\\]'
    assert regex_escape('a.bc') == 'a\\.bc'
    assert regex_escape('ab^') == 'ab\\^'
    assert regex_escape('ab$') == 'ab\\$'
    assert regex_escape('a.*b') == 'a\\.\\*b'
    assert regex_escape('a(bc)') == 'a\\(bc\\)'
    assert regex_escape(r'a\+b') == 'a\\\\\\+b'
    assert regex_escape('a\\b') == r'a\\b'
    assert regex_escape('a\\\nb') == r'a\\\\\nb'


# Generated at 2022-06-23 10:07:33.381026
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' Tests the dict_to_list_of_dict_key_value_elements filter. '''

    # Tests with valid inputs
    assert dict_to_list_of_dict_key_value_elements({'key': 'value'}) == [{'key': 'key', 'value': 'value'}]
    assert dict_to_list_of_dict_key_value_elements({'key': 'value'}, 'key', 'value') == [{'key': 'key', 'value': 'value'}]
    assert dict_to_list_of_dict_key_value_elements({'key': 'value'}, value_name='value', key_name='key') == [{'key': 'key', 'value': 'value'}]
    assert dict_to_list_of_dict_key_value_

# Generated at 2022-06-23 10:07:40.453659
# Unit test for function randomize_list
def test_randomize_list():
    from ansible.module_utils.six.moves import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None, variables={})
    result = randomize_list(mylist=["a", "b", "c", "d", "e", "f", "g"], seed="Test1234")
    assert result == [u'b', u'c', u'f', u'g', u'a', u'd', u'e']
    result = randomize_list(mylist=templar._unwrap_variables([AnsibleUnsafeText(u"{{mylist}}")], wrap_toplevel=False)[0], seed="Test1234")


# Generated at 2022-06-23 10:07:47.048984
# Unit test for function path_join
def test_path_join():
    assert path_join('/', 'tmp', 'something') == path_join(['/', 'tmp', 'something']) == os.path.join('/', 'tmp', 'something')
    assert path_join('/tmp', '/something') == path_join(['/tmp', '/something']) == os.path.join('/tmp', '/something')
    assert path_join('/tmp/', '/something') == path_join(['/tmp/', '/something']) == os.path.join('/tmp/', '/something')



# Generated at 2022-06-23 10:07:49.565089
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("hello", hashtype='md5') == "5d41402abc4b2a76b9719d911017c592"



# Generated at 2022-06-23 10:07:50.554695
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-23 10:07:56.733211
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # Test walking through a list
    test_data = """
    - foo: bar
    - baz:
      - quux: quuux
      - quuuuux: quuuuuux
    """
    for data in from_yaml_all(test_data):
        assert 'foo' in data or 'baz' in data



# Generated at 2022-06-23 10:08:00.016300
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("test1") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"


# Generated at 2022-06-23 10:08:10.155199
# Unit test for function regex_escape

# Generated at 2022-06-23 10:08:13.421447
# Unit test for function mandatory
def test_mandatory():
    '''not throwing error'''
    assert mandatory([1, 2]) == [1, 2]
    assert mandatory(True) is True
    assert 'Mandatory variable' in mandatory()



# Generated at 2022-06-23 10:08:18.243881
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2017-05-11 18:31:00', '%Y-%m-%d %H:%M:%S') == datetime.datetime(2017, 5, 11, 18, 31)


# Generated at 2022-06-23 10:08:27.449886
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('', 'python') == ''
    assert regex_escape('foo', 'python') == 'foo'
    assert regex_escape('foo(', 'python') == 'foo\\('
    assert regex_escape('foo.', 'python') == 'foo\\.'
    assert regex_escape('foo^', 'python') == 'foo\\^'
    assert regex_escape('foo$', 'python') == 'foo\\$'
    assert regex_escape('foo*', 'python') == 'foo\\*'
    assert regex_escape('foo+', 'python') == 'foo\\+'
    assert regex_escape('foo?', 'python') == 'foo\\?'
    assert regex_escape('foo[', 'python') == 'foo\\['
    assert regex_escape('foo]', 'python') == 'foo\\]'
    assert regex_

# Generated at 2022-06-23 10:08:30.028152
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'foo', 'b': 'bar'}) == '{a: foo, b: bar}\n'



# Generated at 2022-06-23 10:08:32.606679
# Unit test for function b64decode
def test_b64decode():
    test_string = 'YW55IGNhcm5hbCBwbGVhcw=='
    assert(b64decode(test_string) == 'any carnal pleas')



# Generated at 2022-06-23 10:08:36.421209
# Unit test for function from_yaml_all
def test_from_yaml_all():
    ''' Test from_yaml_all'''
    assert from_yaml_all('''---
    - {a: 1}
    - {a: 2}
    ''') == [{'a': 1}, {'a': 2}]



# Generated at 2022-06-23 10:08:43.378017
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    ret = subelements(obj, 'groups')
    assert ret == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-23 10:08:48.527432
# Unit test for function get_hash
def test_get_hash():
    # Test that sha1 hashing works as expected
    assert get_hash('My data', 'sha1') == hashlib.new('sha1', b'My data').hexdigest()
    # Test that md5 hashing works as expected
    assert get_hash('My data', 'md5') == hashlib.new('md5', b'My data').hexdigest()



# Generated at 2022-06-23 10:08:59.513369
# Unit test for function quote
def test_quote():
    assert quote("foo") == "foo"
    assert quote("foo bar") == "foo bar"
    assert quote("foo's bar") == "foo's bar"
    assert quote("foo\"bar") == 'foo"bar'
    assert quote("'") == "''"
    assert quote("$foo") == "$foo"
    assert quote("${foo}") == "${foo}"
    assert quote("$$foo") == "$$foo"
    assert quote("%foo") == "%foo"
    assert quote("'${foo}'") == "''${foo}''"
    assert quote("'%foo'") == "''%foo''"



# Generated at 2022-06-23 10:09:09.465532
# Unit test for function from_yaml_all

# Generated at 2022-06-23 10:09:15.717571
# Unit test for function do_groupby
def test_do_groupby():
    env = DummyEnvironment()
    env.filters = ansible_filters
    apps = [
        {'name': 'app1', 'version': '1.0'},
        {'name': 'app1', 'version': '1.1'},
        {'name': 'app2', 'version': '2.0'},
    ]
    grouped = do_groupby(env, apps, 'name')
    assert list(grouped[0]) == ('app1', [{'name': 'app1', 'version': '1.0'}, {'name': 'app1', 'version': '1.1'}])
    assert list(grouped[1]) == ('app2', [{'name': 'app2', 'version': '2.0'}])
# END unit test for function do_groupby


#

# Generated at 2022-06-23 10:09:22.600292
# Unit test for function to_nice_json
def test_to_nice_json():
    ''' Test function to_nice_json '''
    assert "[" == to_nice_json([], indent=0)[0]
    assert "{" == to_nice_json({}, indent=0)[0]
    assert '\n' == to_nice_json({}, indent=0)[1]
    assert '"1":' in to_nice_json({'1': 1}, indent=0)
    assert ' ' not in to_nice_json({'1': 1}, indent=0)
    assert '\n  ' in to_nice_json({'1': 1}, indent=2)



# Generated at 2022-06-23 10:09:32.915163
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("Hello World","World") == 'World'
    assert regex_search("Hello World",'\\s', '\\g<0>') == [' ']
    assert regex_search("Hello World",'\\s', '\\g<0>', '\\g<0>') == [' ', ' ']
    assert regex_search("Hello World",'\\s', '\\1', '\\1') == [' ', ' ']
    assert regex_search("Hello World",'\\s', '\\1') == ['1']
    assert regex_search("Hello World",'\\s', '\\g<foo>') == []
    assert regex_search("Hello World",'\\s', '\\g<1>') == []



# Generated at 2022-06-23 10:09:37.201838
# Unit test for function rand
def test_rand():
    assert rand(range(1,49), seed=1) == 37
    assert rand(start=3, end=11, step=2, seed=1) == 5
    assert rand(xrange(49), seed=1) == 37



# Generated at 2022-06-23 10:09:50.689588
# Unit test for function combine
def test_combine():
    d1 = dict(a=1, b=2)
    d2 = dict(b=22, c=33)
    d3 = dict(c=333, d=4)
    d4 = dict(d=44)

    assert combine(d1, d2, d3, d4, list_merge='replace') == dict(a=1, b=22, c=333, d=44)
    assert combine(d1, d2, d3, d4, list_merge='append') == dict(a=1, b=[2, 22], c=[33, 333], d=[4, 44])

# Generated at 2022-06-23 10:10:02.888062
# Unit test for function subelements
def test_subelements():
    assert subelements({"name": "alice", "groups": ["wheel"]}, 'groups') == [({'name': 'alice', 'groups': ['wheel']}, 'wheel')]
    assert subelements({"name": "alice", "groups": ["wheel"]}, ['groups']) == [({'name': 'alice', 'groups': ['wheel']}, 'wheel')]
    assert subelements([{"name": "alice", "groups": ["wheel"]}, {"name": "bob", "groups": ["wheel", "other"]}], 'groups') == [
        ({'name': 'alice', 'groups': ['wheel']}, 'wheel'), ({'name': 'bob', 'groups': ['wheel', 'other']}, 'wheel'), ({'name': 'bob', 'groups': ['wheel', 'other']}, 'other')]
   

# Generated at 2022-06-23 10:10:09.771310
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote(u'') == u"''"
    assert quote(u'foo') == u"'foo'"
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote(u'foo bar baz') == u"'foo bar baz'"
    assert quote(u"foo'bar") == u"'foo'\\''bar'"



# Generated at 2022-06-23 10:10:20.703181
# Unit test for function flatten
def test_flatten():
    data = [['a', 'b', 'c']]
    assert flatten(data) == ['a', 'b', 'c']
    data.append(['d', 'e', 'f'])
    assert flatten(data) == ['a', 'b', 'c', 'd', 'e', 'f']
    data = [{'foo': 'bar'}, {'biz': 'baz'}]
    assert flatten(data) == [{'foo': 'bar'}, {'biz': 'baz'}]
    data.append([{'super': 'duper'}])
    assert flatten(data) == [{'foo': 'bar'}, {'biz': 'baz'}, [{'super': 'duper'}]]
    data = [1, 2, 3]
    assert flatten(data)

# Generated at 2022-06-23 10:10:33.356556
# Unit test for function comment
def test_comment():
    # Test 'c' style
    assert comment(
        text='This is a test',
        style='c') == "// This is a test"
    assert comment(
        text='This is a test\nwith two lines',
        style='c') == "// This is a test\n// with two lines"
    assert comment(
        text='This is a test\nwith two lines',
        style='c',
        decoration='//* ') == "//* This is a test\n//* with two lines"
    assert comment(
        text='This is a test\nwith two lines',
        style='c',
        decoration='//* ',
        prefix='') == "//* This is a test\n//* with two lines"

# Generated at 2022-06-23 10:10:37.661971
# Unit test for function randomize_list
def test_randomize_list():
    import random
    # Ensure the randomize_list function is NOT a noop
    for i in range(100):
        mylist = [1, 2, 3]
        randomize_list(mylist, seed=random.randint(0, 100000))
        assert mylist != [1, 2, 3]



# Generated at 2022-06-23 10:10:42.069140
# Unit test for function strftime
def test_strftime():
    assert strftime("%H:%M", "3600") == "01:00"
    assert strftime("%H:%M") is not None


# Generated at 2022-06-23 10:10:48.744360
# Unit test for function path_join
def test_path_join():
    assert 'path/to/file.txt' == path_join('path/to', 'file.txt')
    assert 'path/to/file.txt' == path_join(['path/to', 'file.txt'])
    assert 'path/to/file.txt' == path_join('path/to/', ['file.', 'txt'])



# Generated at 2022-06-23 10:10:55.248462
# Unit test for function fileglob
def test_fileglob():
    files = fileglob('/etc/*.conf')
    assert(isinstance(files, list))
    for f in ('/etc/ansible.cfg', '/etc/hosts', '/etc/resolv.conf'):
        assert(f in files)
    assert('/etc/fstab' not in files)
    files = fileglob('/etc/ansible/ansible.cfg')
    assert(isinstance(files, list))
    assert('/etc/ansible/ansible.cfg' in files)
    assert(len(files) == 1)



# Generated at 2022-06-23 10:11:04.753650
# Unit test for function regex_search
def test_regex_search():
    value = "10.10.46.14"
    ipv4 = "(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"
    pattern = "^%s$" % ipv4
    ret = regex_search(value, pattern)
    assert ret == "10.10.46.14"


# Generated at 2022-06-23 10:11:05.939432
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert issubclass(FilterModule, object)

# Generated at 2022-06-23 10:11:14.760834
# Unit test for function regex_escape
def test_regex_escape():
    assert_equal(regex_escape('abcd'), 'abcd')
    assert_equal(regex_escape('a[]b.c*d^$\\e'), 'a\\[\\]b\\.c\\*d\\^\\$\\\\e')
    # also test the legacy re_escape() name for the function
    assert_equal(re_escape('abcd'), 'abcd')
    assert_equal(re_escape('a[]b.c*d^$\\e'), 'a\\[\\]b\\.c\\*d\\^\\$\\\\e')


# Generated at 2022-06-23 10:11:23.656112
# Unit test for function do_groupby
def test_do_groupby():
    import pytest
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template import ansible_jinja2_environment

    env = Environment(extensions=ansible_jinja2_environment.DEFAULT_EXTENSIONS)
    env.globals['do_groupby'] = do_groupby

    template = '{{ [{1,2,3},{4,5,6},{7,8,9}] | do_groupby(attribute="0") }}'
    with pytest.raises(UndefinedError):
        env.from_string(template).render()

    env.globals['do_groupby'] = _do_groupby

# Generated at 2022-06-23 10:11:26.742364
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a':1, 'b':2}) == '{a: 1, b: 2}\n'


# Generated at 2022-06-23 10:11:31.583063
# Unit test for function quote
def test_quote():

    assert quote('abc') == 'abc'
    assert quote('a b c') == "'a b c'"
    assert quote('a"b\'c') == "'a\"b'\\''c'"
    assert quote('') == "''"
    assert quote('"') == "\""



# Generated at 2022-06-23 10:11:40.606559
# Unit test for function from_yaml_all
def test_from_yaml_all():
    complex_yaml="""
legend:
  a: 'value of a'
  b: 'value of b'
  c: 'value of c'
section:
  -
    a: 'value of a'
    b: 'value of b'
    c: 'value of c'
  -
    a: 'value of a'
    b: 'value of b'
    c: 'value of c'
  -
    a: 'value of a'
    b: 'value of b'
    c: 'value of c'
    """
    yaml_list = from_yaml_all(complex_yaml)
    assert True == is_sequence(yaml_list)
    assert len(yaml_list) == 3



# Generated at 2022-06-23 10:11:49.181805
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    """Test for list_of_dict_key_value_elements_to_dict."""
    with pytest.raises(AnsibleFilterTypeError) as e:
        list_of_dict_key_value_elements_to_dict(1)
    assert "list" in to_text(e)

    assert list_of_dict_key_value_elements_to_dict([{
        "key": "foo",
        "value": {
            "bar": "baz"
        }
    }]) == {"foo": {"bar": "baz"}}



# Generated at 2022-06-23 10:11:56.372260
# Unit test for function randomize_list
def test_randomize_list():
    # test with a seed
    list1 = randomize_list(range(0, 9), 12345)
    list2 = randomize_list(range(0, 9), 12345)
    assert list1 == list2
    # test with no seed
    list1 = randomize_list(range(0, 9))
    list2 = randomize_list(range(0, 9))
    assert list1 != list2



# Generated at 2022-06-23 10:12:00.562348
# Unit test for function subelements

# Generated at 2022-06-23 10:12:10.913362
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import test.support
    from ansible.module_utils import basic

    from ansible.module_utils.six import PY3, string_types

    mod = FilterModule()
    for filter in mod.filters():
        print("Trying %s" % (filter))
        func = mod.filters()[filter]
        if filter[0] == "_":
            continue
        elif filter in ('quote', 'to_nice_json', 'to_yaml', 'to_nice_yaml', 'regex_replace', 'regex_search', 'regex_findall'):
            if PY3 and func in (quote, to_nice_json):
                # quote() and to_nice_json() require native strings on Python 3
                pyfunc = getattr(__builtins__, filter)
                test.support.run_

# Generated at 2022-06-23 10:12:20.149072
# Unit test for function regex_search

# Generated at 2022-06-23 10:12:22.072840
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-23 10:12:35.211441
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all('{"foo" : "bar"}\n---\n- "test"') == [{"foo": "bar"}, ["test"]]
    assert from_yaml_all("{'foo' : 'bar'}\n---\n- 'test'") == [{"foo": "bar"}, ["test"]]
    assert from_yaml_all("{foo : bar}\n---\n- test") == [{"foo": "bar"}, ["test"]]
    assert from_yaml_all("{foo : bar}\n---\n- test") == [{"foo": "bar"}, ["test"]]
    assert from_yaml_all("[foo, bar]\n---\n- test") == [["foo", "bar"], ["test"]]

# Generated at 2022-06-23 10:12:40.024181
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [3, 5, 8]
    assert len(randomize_list(mylist)) == len(mylist)
    assert len(randomize_list(mylist,seed=123)) == len(mylist)



# Generated at 2022-06-23 10:12:43.440646
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d") == "2016-06-11"



# Generated at 2022-06-23 10:12:53.577562
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    from collections import OrderedDict
    from jinja2.runtime import StrictUndefined

    # List of tests.  Each test is a list with:
    #   * Input arg to list_of_dict_key_value_elements_to_dict
    #   * Expected output
    #   * (optionally) Exception to be raised

# Generated at 2022-06-23 10:13:00.259492
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict(
        [{'key': 'name', 'value': 'Jill'}, {'key': 'age', 'value': '54'}]
    ) == {'age': '54', 'name': 'Jill'}



# Generated at 2022-06-23 10:13:13.680940
# Unit test for function to_json
def test_to_json():
    value = {'a': 1, 'b': 2}
    assert json.loads(to_json(value)) == value

    value = ['a', 'b']
    assert json.loads(to_json(value)) == value

    assert to_json(True) == 'true'

    assert to_json(0) == '0'
    assert to_json(1) == '1'

    assert to_json('0') == '"0"'
    assert to_json('1') == '"1"'

    assert to_json(None) == 'null'

    value = {'a': 1, 'b': None}
    assert to_json(value) == '{"a": 1, "b": null}'

    value = ['a', 'b', None]

# Generated at 2022-06-23 10:13:20.952616
# Unit test for function get_hash
def test_get_hash():
    import os
    with open('/root/.travis/job_stages', 'r') as file_1:
        print(get_hash(file_1.read(), 'md5'))

    with open('/root/.travis/job_stages', 'r') as file_2:
        print(get_hash(file_2.read(), 'sha1'))

    with open('/root/.travis/job_stages', 'r') as file_3:
        print(get_hash(file_3.read(), 'sha256'))
        
    print(get_hash('test.txt'))



# Generated at 2022-06-23 10:13:23.894594
# Unit test for function combine
def test_combine():
    c = combine({
        "sources": [
            "one",
            "two",
            "three"
        ],
        "dict": {
            "inner": "one"
        }
    }, {
        "sources": [
            "four"
        ],
        "dict": {
            "inner": "two"
        }
    })
    print(c)

test_combine()



# Generated at 2022-06-23 10:13:31.757360
# Unit test for function ternary
def test_ternary():
    ''' Unit Tests '''
    # Test None and none_val is not None
    if not ternary(None, "true", "false", "none") == "none":
        return 1

    # Test True value
    if not ternary(True, "true", "false") == "true":
        return 1

    # Test False value
    if not ternary(False, "true", "false") == "false":
        return 1



# Generated at 2022-06-23 10:13:34.365696
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of FilterModule
    filters = FilterModule()
    # Test if it returns a dictionary
    assert isinstance(filter, Mapping)



# Generated at 2022-06-23 10:13:46.022551
# Unit test for function extract
def test_extract():
    environment = DummyEnvironment(strict=False)
    assert extract(environment, 'a', {'a': {'b': {'c': 'd'}}}, morekeys='b') == {'c': 'd'}
    assert extract(environment, 'a', {'a': {'b': {'c': 'd'}}}, morekeys=['b']) == {'c': 'd'}
    assert extract(environment, 'a', {'a': {'b': {'c': 'd'}}}, morekeys=['b', 'c']) == 'd'
    assert extract(environment, 'a', {'a': {'b': {'c': 'd'}}}, morekeys=['b', 'c', 'd']) == Undefined



# Generated at 2022-06-23 10:13:56.068925
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("12345", "^\\d+$") == "12345"
    assert regex_search("12345", "^\\d+$", "\\1") == "5"
    assert regex_search("12345", "^(\\d+)$", "\\g<1>") == "12345"
    assert regex_search("12345", "^(\\d+)$", "\\g<1>", "\\g<1>") == ["12345", "12345"]
    assert regex_search("Jason", "^J(\\w+)n$", "\\g<1>") == "aso"
    assert regex_search("Jason", "^J(\\w+)n$", "\\g<1>", ignorecase=True) == "aso"

# Generated at 2022-06-23 10:13:57.379467
# Unit test for function from_yaml
def test_from_yaml():
    assert [] == from_yaml("[]")



# Generated at 2022-06-23 10:14:03.214782
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('kkk') == 'a2tr'
    assert b64encode('kkk', 'ascii') == 'a2tr'
    assert b64encode('kkk', 'utf-8') == 'a2tr'
    assert b64encode('kkk', 'utf-16') == 'BA0I'



# Generated at 2022-06-23 10:14:09.592444
# Unit test for function flatten
def test_flatten():
    seq = [1, 2, [3, 4, 5, None], [6, 7, [8, 9]]]
    assert flatten(seq) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten(seq, levels=1) == [1, 2, 3, 4, 5, 6, 7, [8, 9]]



# Generated at 2022-06-23 10:14:21.273124
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall("the cow jumped", r"the") == ['the']
    assert regex_findall("the cow jumped", r"the", ignorecase=True) == ['the']
    assert regex_findall("the cow jumped", r"the", ignorecase=True) == ['the']
    assert regex_findall("the cow jumped", r"jumped") == ['jumped']
    assert regex_findall("", r"") == ['']

    # the following test is from https://github.com/ansible/ansible/issues/19349
    # regex_findall("A\nB\nC", ".")
    assert regex_findall("A\nB\nC", ".", multiline=True) == ['A', 'B', 'C']


# Generated at 2022-06-23 10:14:28.168248
# Unit test for function to_nice_json
def test_to_nice_json():
  a = {'a': {'b': 'c', 'e': 'f'}, 'g': [1,2,3], 'h': {'i': [1,2], 'j': 'k'}}
  b = u"{\n    \"a\": {\n        \"b\": \"c\", \n        \"e\": \"f\"\n    }, \n    \"g\": [\n        1, \n        2, \n        3\n    ], \n    \"h\": {\n        \"i\": [\n            1, \n            2\n        ], \n        \"j\": \"k\"\n    }\n}"
  assert(to_nice_json(a) == b)
  return True



# Generated at 2022-06-23 10:14:30.703148
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('string\nwith\nnewlines', r'\w+') == ['string', 'with', 'newlines']
    assert regex_findall('string\nwith\nnewlines', r'\w+', multiline=True) == ['string', 'with', 'newlines']



# Generated at 2022-06-23 10:14:42.339389
# Unit test for function randomize_list
def test_randomize_list():
    '''
    Validate that function randomize_list returns a list of a random order
    of the original list; that the length of the resulting list is identical
    to the original list; and, that the result is not deterministic (i.e. using
    the same "seed" results in a different ordering of the list).
    :return:
    '''
    mylist = [0, 1, 2, 3, 4]
    mylist_duplicate = [0, 1, 2, 3, 4]
    result_list_1 = randomize_list(mylist)
    result_list_2 = randomize_list(mylist, seed=1)
    assert len(result_list_1) == len(mylist)
    assert result_list_1 != mylist
    assert result_list_2 != mylist

# Generated at 2022-06-23 10:14:48.518117
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(None, 1, 2) == 2
    assert ternary(True, 1, 2, 3) == 1
    assert ternary(None, 1, 2, 3) == 3



# Generated at 2022-06-23 10:14:50.596757
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', '1462805540') == '2016-05-10'



# Generated at 2022-06-23 10:15:00.514258
# Unit test for function b64encode
def test_b64encode():
    text = 'this is a test string'
    expected_result = 'dGhpcyBpcyBhIHRlc3Qgc3RyaW5n' # noqa
    actual_result = b64encode(text)
    assert actual_result == expected_result
    text = 'this is a test string \x00with null bytes'
    expected_result = 'dGhpcyBpcyBhIHRlc3Qgc3RyaW5nIH4gd2l0aCBudWxsIGJ5dGVz' # noqa
    actual_result = b64encode(text)
    assert actual_result == expected_result
    text = u'this is a test string'
    expected_result = 'dGhpcyBpcyBhIHRlc3Qgc3RyaW5n' # noqa

# Generated at 2022-06-23 10:15:09.514666
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

    obj = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, ['authorized']) == [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]


# Generated at 2022-06-23 10:15:13.531639
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    expected_dict = [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}]
    assert dict_to_list_of_dict_key_value_elements(test_dict) == expected_dict
    assert dict_to_list_of_dict_key_value_elements({}) == []



# Generated at 2022-06-23 10:15:15.259204
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(foo='bar')) == 'foo: bar\n'


# Generated at 2022-06-23 10:15:23.886316
# Unit test for function rand
def test_rand():
    assert rand(10) in range(10)
    assert rand(0, 10) in range(10)
    assert rand(0, 10, 1) in range(10)
    assert rand(0, 10, step=1) in range(10)
    assert rand(0, 10, 2) in [0, 2, 4, 6, 8]
    assert rand(0, 10, step=2) in [0, 2, 4, 6, 8]
    assert rand([1, 2, 3]) in [1, 2, 3]
    assert rand(0, [1, 2, 3]) in [1, 2, 3]
    assert rand(0, [1, 2, 3], step=1) in [1, 2, 3]
    assert rand(0, [1, 2, 3], 1) in [1, 2, 3]


# Generated at 2022-06-23 10:15:28.425500
# Unit test for function to_bool
def test_to_bool():
    assert to_bool("yes") == True
    assert to_bool("no") == False
    assert to_bool("True") == True
    assert to_bool("False") == False
    assert to_bool("1") == True
    assert to_bool("0") == False
    assert to_bool("") == False
    assert to_bool("foo") == False
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool(None) == False
    assert to_bool([]) == False
    assert to_bool([1,2,3]) == True
    assert to_bool("True") == True
