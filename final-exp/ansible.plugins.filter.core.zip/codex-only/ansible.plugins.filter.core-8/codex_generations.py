

# Generated at 2022-06-23 10:05:27.878381
# Unit test for function to_yaml
def test_to_yaml():

    assert to_yaml({'foo':'bar'}) == "foo: bar\n"



# Generated at 2022-06-23 10:05:36.868056
# Unit test for function combine
def test_combine():
    import unittest
    import ansible.errors
    class TestCombine(unittest.TestCase):
        def test_combine_basics(self):
            # Test basics.
            # Test combine with one or several empty dicts.
            # Test combine with dicts having keys in common and dicts having no keys in
            # common.
            # Test combine with dicts having various values.

            self.assertDictEqual(combine([{}]), {})
            self.assertDictEqual(combine([{}, {}]), {})
            self.assertDictEqual(combine([{}, {}, {}]), {})
            self.assertDictEqual(combine({}), {})
            self.assertDictEqual(combine({}, {}), {})

# Generated at 2022-06-23 10:05:45.716891
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('1?2*3', '\?', '5', ignorecase=False) == '1?2*3'
    assert regex_replace('1a2b3c', 'a', '4') == '142b3c'
    assert regex_replace('1 a 2 b 3 c', '\s+', '', ignorecase=False) == '1a2b3c'
    assert regex_replace('1?2*3', '\?', '5', ignorecase=False) == '1?2*3'
    assert regex_replace('1?2*3', '\?', '5', ignorecase=True) == '152*3'
    assert regex_replace('1?2*3', '*', '5', ignorecase=False) == '1?253'

# Generated at 2022-06-23 10:05:55.463804
# Unit test for function combine
def test_combine():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system
    import ansible.module_utils
    import ansible.module_utils.six
    import ansible.module_utils.six.moves

    # Constructor
    filter = filters.Filters()

    # Test values

# Generated at 2022-06-23 10:06:04.237273
# Unit test for function regex_escape
def test_regex_escape():
    strings = dict(
        backslash=r'foo\bar',
        ast=r'foo*bar',
        dot=r'foo.bar',
        brack=r'foo[bar',
        caret=r' foo^bar ',
        dollar=r'foo$bar',
        paren=r'foo(bar',
        plus=r'foo+bar',
        question=r'foo?bar',
        pipe=r'foo|bar',
        obfuscated=r' $*[?|^()+{ }.',
        empty='',
        none=None,
        int=123,
    )
    for string_name, string in strings.items():
        for re_type in ['python', 'posix_basic']:
            escaped = regex_escape(string, re_type=re_type)
           

# Generated at 2022-06-23 10:06:14.917821
# Unit test for function to_bool
def test_to_bool():
    # True
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool("1") is True
    assert to_bool("true") is True
    assert to_bool(1) is True
    assert to_bool(True) is True
    # False
    assert to_bool("no") is False
    assert to_bool("off") is False
    assert to_bool("0") is False
    assert to_bool("false") is False
    assert to_bool(0) is False
    assert to_bool(None) is False
    assert to_bool(False) is False
    assert to_bool("") is False
    assert to_bool([]) is False
    assert to_bool({}) is False



# Generated at 2022-06-23 10:06:20.683936
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined, msg="Custom message")
    except AnsibleFilterError as e:
        assert e.message == 'Custom message'
        assert e.orig_exc is None
    else:
        assert False, "Mandatory filter should have raised AnsibleFilterError"

    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert e.message == 'Mandatory variable not defined.'
        assert e.orig_exc is None
    else:
        assert False, "Mandatory filter should have raised AnsibleFilterError"



# Generated at 2022-06-23 10:06:32.203109
# Unit test for function rand
def test_rand():
    if sys.version_info.major > 2:
        # Python 3.6 added a new argument to Random:
        # https://github.com/python/cpython/commit/22febbb82c404a47a3df3c8ec55839e2901c79f6
        class FakeRandom(Random):
            def __init__(self, *args, **kwargs):
                Random.__init__(self)
        FakeRandom(seed=1).choice(['foo', 'bar', 'baz'])

    environment = DummyEnvironment()
    assert rand(environment, 10) in list(range(10))
    assert rand(environment, 1, 10, 2) in list(range(1, 10, 2))

# Generated at 2022-06-23 10:06:36.270536
# Unit test for function strftime
def test_strftime():
    assert strftime(string_format='%Y', second='1587763525') == '2020'
    assert strftime(string_format='%Y%m%d', second='1587763525') == '20200305'



# Generated at 2022-06-23 10:06:47.818899
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    passwd = to_bytes('password')
    assert get_encrypted_password(passwd, 'md5') == b'$1$abcdefgh$O7P9uK8VdX6MgT6TJRJjK/'
    assert get_encrypted_password(passwd, 'blowfish') == b'$2y$12$abcdefghijklmnopqrstuu'
    assert get_encrypted_password(passwd, 'sha256') == b'$5$abcdefghijklmno$D4YRXz.EcQlXV.K0Jq1LQszDQ2yoO3zR6wqy7nh1x84'

# Generated at 2022-06-23 10:06:58.296039
# Unit test for function to_bool
def test_to_bool():
    assert to_bool("True") is True
    assert to_bool("FALSE") is False
    assert to_bool("true") is True
    assert to_bool("FALSE") is False
    assert to_bool("yes") is True
    assert to_bool("no") is False
    assert to_bool("y") is True
    assert to_bool("n") is False
    assert to_bool("1") is True
    assert to_bool("0") is False
    assert to_bool("on") is True
    assert to_bool("off") is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(True) is True
    assert to_bool(False) is False



# Generated at 2022-06-23 10:07:09.185969
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('hello', '(l+)', multiline=True, ignorecase=True) == ['ll']
    assert regex_findall('hello', '(l+)', multiline=True, ignorecase=True) == ['ll']
    assert regex_findall('hello', '(l+)', multiline=False, ignorecase=False) == ['ll']
    assert regex_findall('abcdabcdabcd', '(ab)', multiline=True, ignorecase=True) == ['ab', 'ab', 'ab']
    assert regex_findall('abcdabcdabcd', '(ab)', multiline=False, ignorecase=True) == ['ab']
    assert regex_findall('abcdabcdabcd', '(ab)', multiline=False, ignorecase=False) == ['ab']
    assert regex_

# Generated at 2022-06-23 10:07:13.744107
# Unit test for function strftime
def test_strftime():
    # This is to ensure backcompat with previous behavior, with this
    # patch strftime returns a unicode object, without it returns a
    # byte object.
    assert isinstance(strftime("%Y"), unicode)



# Generated at 2022-06-23 10:07:20.277147
# Unit test for function to_datetime
def test_to_datetime():
    time = to_datetime("2020-03-14 03:14:15", "%Y-%m-%d %H:%M:%S")
    assert time.year == 2020
    assert time.month == 3
    assert time.day == 14
    assert time.hour == 3
    assert time.minute == 14
    assert time.second == 15


# Generated at 2022-06-23 10:07:30.990431
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(u'abc', 'abc') == u'abc'
    assert regex_search(u'xyz', 'abc') == None
    assert regex_search(u'abc', 'a(b)c') == [u'b']
    assert regex_search(u'abc', 'a(b)c', '\\g<1>') == [u'b']
    assert regex_search(u'abc', 'a(b)c', '\\g<1>', '\\g<0>') == [u'b', u'abc']
    assert regex_search(u'abc', '(a)(b)c', '\\2', '\\1') == [u'b', u'a']

# Generated at 2022-06-23 10:07:35.638646
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('Hello, 123', r'\d+', '456') == 'Hello, 456'
    assert regex_replace('Hello, 123', r'(?i)\d+', '456') == 'Hello, 456'
    assert regex_replace('Hello, 123', r'(?i)\d+', '456', ignorecase=True) == 'Hello, 456'
    assert regex_replace('Hello, 123', r'(?i)\d+', '456', multiline=True) == 'Hello, 456'



# Generated at 2022-06-23 10:07:47.278157
# Unit test for function to_uuid
def test_to_uuid():
    import uuid
    assert to_uuid('foo') == uuid.uuid5(UUID_NAMESPACE_ANSIBLE, 'foo')
    assert to_uuid('foo', '2BC1F0C7-C76D-4A92-AFD6-124057B1F85D') == uuid.uuid5(uuid.UUID('2BC1F0C7-C76D-4A92-AFD6-124057B1F85D'), 'foo')

# Generated at 2022-06-23 10:07:59.898998
# Unit test for function to_uuid
def test_to_uuid():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    assert to_uuid(AnsibleUnsafeText(b"hello world")) == u'5df5be1a-0eff-5e3b-8f0e-8c9d9a9a4827'
    assert to_uuid(AnsibleUnsafeText(b"hello world"), uuid.UUID('361E6D51-FAEC-444A-9079-341386DA8E2B')) == u'c7d26144-9f59-5b21-8085-aad203087ab7'

# Generated at 2022-06-23 10:08:06.462278
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo+\*') == r'foo\+\\\*'
    assert regex_escape(r'foo+\*', re_type='posix_basic') == r'foo\+\\\*'
    assert regex_escape(r'foo+\*', re_type='posix_extended') == r'foo\+\\\*'  # Behaviour undefined, but this is the best guess



# Generated at 2022-06-23 10:08:15.207661
# Unit test for function regex_findall
def test_regex_findall():

    # Test 1
    value = "This is the text to search in.  It can have multiple lines.  There are currently 20 words."
    regex = r"\b\S+\b"
    result = regex_findall(value, regex)
    assert(result == ['This', 'is', 'the', 'text', 'to', 'search', 'in.', 'It', 'can', 'have', 'multiple', 'lines.', 'There', 'are', 'currently', '20', 'words.'])

    # Test 2
    value = "This is the text to search in.  It can have multiple lines.  There are currently 20 words."
    regex = r"\bW\S+\b"
    result = regex_findall(value, regex, ignorecase=True)
    assert(result == ['words.'])

    # Test 3


# Generated at 2022-06-23 10:08:24.762552
# Unit test for function to_uuid
def test_to_uuid():
    # A UUID should have five components separated by hyphens
    # Every component should be the same length
    hyphens_lengths = re.compile(r"^(?:(\w{8})-(\w{4})-(\w{4})-(\w{4})-(\w{12}))$")
    x = "363f19ca-92a7-5a77-b9e9-e8f8fb7d1dd0"
    assert re.match(hyphens_lengths, to_uuid(x)), "%s does not match the UUID format" % x

# Generated at 2022-06-23 10:08:34.018506
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'a': 1, 'b': 2, 'c': 3}
    list_of_dict = dict_to_list_of_dict_key_value_elements(mydict)
    assert list_of_dict[0]['key'] == 'a'
    assert list_of_dict[0]['value'] == 1
    assert list_of_dict[1]['key'] == 'b'
    assert list_of_dict[1]['value'] == 2
    assert list_of_dict[2]['key'] == 'c'
    assert list_of_dict[2]['value'] == 3


# Generated at 2022-06-23 10:08:46.722145
# Unit test for function quote
def test_quote():
    values = (
        # (input, output),
        ("a'b", r'"a\'b"'),
        (u"a'b", r'"a\'b"'),
        ({"a": "'"}, r'"{\'a\': "\'"}"'),
        ([{"a": "'"}], r'"\[{\'a\': "\'"}]"'),
        (("a", "'"), r'"\(\'a\', "\'")"'),
        (("a", "b"), r'"\(\'a\', \'b\)'),
        ("a\"b", r'"a\"b"'),
        (u'\xA2', r'"\xa2"'),
        ('\xA2', r'"\xa2"'),
    )
    for (i, o) in values:
        assert o == quote(i)



# Generated at 2022-06-23 10:08:56.117078
# Unit test for function combine
def test_combine():
    '''
    Make sure that all arguments are merged as expected.

    '''
    testdict = {
        1: {'a': 'a', 'b': 'b'},
        2: {'b': 'B', 'c': 'c'},
        3: {'c': 'C', 'd': 'd'},
    }

    testlist = [
        {'a': 'A', 'b': 'b'},
        {'b': 'B', 'c': 'c'},
        {'c': 'C', 'd': 'd'},
    ]

    result = combine(testdict[1], testdict[2], testdict[3])
    resultlist = combine(testlist[0], testlist[1], testlist[2])


# Generated at 2022-06-23 10:09:01.266603
# Unit test for function from_yaml
def test_from_yaml():
    assert [] == from_yaml("[]")
    assert [{}, 1, 2] == from_yaml("[{}, 1, 2]")

# Generated at 2022-06-23 10:09:15.149299
# Unit test for function combine
def test_combine():
    assert combine({}, {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1, 'b': 2}, {}) == {'a': 1, 'b': 2}
    assert combine({'a': {'b': 1}}, {'a': {'c': 2}}) == {'a': {'b': 1, 'c': 2}}
    assert combine({'a': {'b': 1}}, {'a': {'b': 2}}) == {'a': {'b': 2}}

# Generated at 2022-06-23 10:09:28.431728
# Unit test for function get_hash
def test_get_hash():
    assert(get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')
    assert(get_hash('test', hashtype='md5') == '098f6bcd4621d373cade4e832627b4f6')
    assert(get_hash('test', hashtype='sha256')
           == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08')

# Generated at 2022-06-23 10:09:36.470939
# Unit test for function randomize_list
def test_randomize_list():
    from ansible.module_utils import basic
    reference_list = [1, 2, 3, 4, 5, 6, 7]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7], seed=1) == [1, 2, 7, 5, 6, 3, 4], 'test failed, shuffle not work with seed'
    assert randomize_list([1, 2, 3, 4, 5, 6, 7], seed=2) == [6, 1, 3, 2, 7, 4, 5], 'test failed, shuffle not work with seed'

# Generated at 2022-06-23 10:09:50.220182
# Unit test for function b64decode
def test_b64decode():
    assert(b64decode(b64encode('hello')) == 'hello')
    assert(b64decode(b64encode('hello', 'ascii'), 'ascii') == 'hello')
    assert(b64decode(b64encode(u'\u0105\u0106'), 'latin1') == u'\u0105\u0106')
    assert(b64encode(b'hello') == b'aGVsbG8=')
    assert(b64encode(b'hello', 'ascii') == b'aGVsbG8=')
    assert(b64decode(b64encode(b'\xe5\xe6'), 'iso-8859-1') == b'\xe5\xe6')


# Generated at 2022-06-23 10:09:51.874558
# Unit test for function to_json
def test_to_json():
    assert to_json([1, 2, 3]) == '[1, 2, 3]'
    assert to_json({"a": 1}) == '{"a": 1}'



# Generated at 2022-06-23 10:09:59.165717
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('foo') is False
    assert to_bool('1') is True
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None



# Generated at 2022-06-23 10:10:04.251537
# Unit test for function ternary
def test_ternary():
    return [
        (True, 'Yes', 'No') == ternary(1, 'Yes', 'No'),
        (True, 'Yes', 'No') == ternary('a', 'Yes', 'No'),
        (False, 'Yes', 'No') == ternary(None, 'Yes', 'No'),
    ]



# Generated at 2022-06-23 10:10:06.138249
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(["a", "b", "c"], seed=0) == ['b', 'c', 'a']



# Generated at 2022-06-23 10:10:11.677047
# Unit test for function to_nice_json
def test_to_nice_json():
    '''Test to_nice_json'''
    random_data = Random().randint(0, 99)
    actual_result = to_nice_json({"data": random_data})
    print('Actual Result: %s' % actual_result)
    print('Expected Result: %s' % '{\n    "data": %d\n}' % random_data)
    assert actual_result == '{\n    "data": %d\n}' % random_data
    # assert actual_result == "hello"


# Generated at 2022-06-23 10:10:21.761393
# Unit test for function combine
def test_combine():
    class Test(object):
        def __init__(self, data, undefined_name=None):
            self.data = data
            self.undefined_name = undefined_name

        def __str__(self):
            if self.undefined_name:
                return str(self.undefined_name)
            return self.data

        def __repr__(self):
            return self.__str__()

    class TestUndefined(Test):
        def __init__(self, undefined_name=None):
            super(TestUndefined, self).__init__("{}", undefined_name)

    test = Test("test")
    test_undefined = TestUndefined("test")

    assert combine() == {}
    assert combine(None) == {}
    assert combine([test]) == test

# Generated at 2022-06-23 10:10:33.375912
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = dict(a='a_value', b='b_value', c='c_value', d='d_value')
    key_name = 'key'
    value_name = 'value'
    ret = dict_to_list_of_dict_key_value_elements(mydict, key_name, value_name)
    assert ret == [{key_name: 'a', value_name: 'a_value'},
                   {key_name: 'b', value_name: 'b_value'},
                   {key_name: 'c', value_name: 'c_value'},
                   {key_name: 'd', value_name: 'd_value'}]
    for item in ret:
        assert key_name in item
        assert value_name in item
        assert item[key_name] in my

# Generated at 2022-06-23 10:10:39.912893
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_data = dict(
        null=None,
        string="simple_string",
        integer=1,
        float=1.0,
        list=[1, "two"],
        dict=dict(
            integer=1,
            float=1.0,
            string="simple_string",
            list=[1, "two"]
        )
    )

    nice_yaml = to_nice_yaml(test_data)

    data = yaml.safe_load(nice_yaml)

    assert data == test_data



# Generated at 2022-06-23 10:10:45.775934
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-05-23 00:21:34", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2018, 5, 23, 0, 21, 34)
    assert to_datetime("2018-05-29", "%Y-%m-%d") == datetime.datetime(2018, 5, 29, 0, 0)



# Generated at 2022-06-23 10:10:51.014607
# Unit test for function from_yaml
def test_from_yaml():
    data = "{foo: bar}"
    assert from_yaml(data) == {"foo": "bar"}
    data = """
    foo: bar
    """
    assert from_yaml(data) == {"foo": "bar"}
    data = u"{foo: bar}"
    assert from_yaml(data) == {"foo": "bar"}



# Generated at 2022-06-23 10:10:57.156572
# Unit test for function b64encode
def test_b64encode():
    string = 'test string'
    utf8_result = b64encode(string)
    assert utf8_result == 'dGVzdCBzdHJpbmc='

    utf16_result = b64encode(string, encoding='utf-16-le')
    assert utf16_result == 'CQDGAAoAbgAGAAY='



# Generated at 2022-06-23 10:11:09.862745
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    passw = 'mysecretpassword'

    assert get_encrypted_password(passw, 'sha512') == '$6$rounds=4096$LNdAQM2X9hSYrBRH$yayc6vlB/nU5v5q3w6LZc6aY640Lm9R6xJFQa1Pl6dInm6zG1bwD8KJhZL2npZfv26jKrWgxlf6yJH0yEFX5U.'

# Generated at 2022-06-23 10:11:16.567465
# Unit test for function extract
def test_extract():
    env = Environment()
    assert extract(env, 'a', {'a': {'b': 1}}) == {'b': 1}
    assert extract(env, 'a', {'a': {'b': 1}}, 'b') == 1
    assert extract(env, 'a', {'a': {'b': 1}}, ['b']) == 1



# Generated at 2022-06-23 10:11:19.772415
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert to_nice_yaml({u"test": AnsibleUnsafeText(u'a\nbc')}) == u"{test: 'a\\nbc'}"



# Generated at 2022-06-23 10:11:22.636564
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', second=1480422900.89) == '2016-11-23 11:18:20'
    assert strftime('%B %d, %Y', second=1480422900.89) == 'November 23, 2016'



# Generated at 2022-06-23 10:11:27.647438
# Unit test for function randomize_list
def test_randomize_list():
    seq_size = 5
    for seed in [None, 10]:
        assert len(randomize_list(range(seq_size), seed)) == seq_size
        if seed is None:
            assert randomize_list(range(seq_size), seed) != randomize_list(range(seq_size), seed)



# Generated at 2022-06-23 10:11:33.118793
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("1234", encoding='utf-8') == "1234"
    assert b64decode("MTIzNA==", encoding='utf-8') == "1234"
    assert b64decode("MTIzNA=", encoding='utf-8') == "1234"
    assert b64decode("MTIzNA", encoding='utf-8') == "1234"
    assert b64decode("MTIzNA==", encoding='utf-16') == u"1234"
    assert b64decode("ABCDEF==", encoding='utf-16') == u"\u0041\u0042\u0043\u0044\u0045\u0046"

# Generated at 2022-06-23 10:11:39.501439
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('0') == '0'
    assert mandatory(0) == 0
    try:
        mandatory(False)
    except AnsibleFilterError as e:
        result = True
        assert to_text(e) == "Mandatory variable not defined."
    assert result

    try:
        mandatory(False, "test")
    except AnsibleFilterError as e:
        result = True
        assert to_text(e) == "test"
    assert result

    # should not fail
    assert mandatory(AnsibleUndefined("foo")) is None



# Generated at 2022-06-23 10:11:50.223200
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    expected = [
        {u'key': 'key1', u'value': 'value1'},
        {u'key': 'key3', u'value': 'value3'},
        {u'key': 'key2', u'value': 'value2'}
    ]
    observed = dict_to_list_of_dict_key_value_elements(mydict)
    assert_equal(observed, expected)

    # test with a non dict input
    mydict = 'test'
    with raises(AnsibleFilterTypeError):
        dict_to_list_of_dict_key_value_elements(mydict)



# Generated at 2022-06-23 10:11:56.372607
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    ''' Test the to_nice_yaml filters '''
    assert '''
a:
    aa: 1
    bb: 2
b:
    cc: 3
    dd: 4
''' == to_nice_yaml({'a': {'aa': 1, 'bb': 2}, 'b': {'cc': 3, 'dd': 4}})



# Generated at 2022-06-23 10:12:09.222504
# Unit test for function rand
def test_rand():
    assert 3 == rand(None, 4)
    assert 0 == rand(None, 4, 0, 1)
    assert 2 == rand(None, 4, 2, 1)
    assert [1, 2, 3] == sorted(rand(None, 4, 0, 2) for _ in range(100))
    assert 'ab' == rand(None, 'abc')
    assert ['a', 'b', 'c'] == sorted(rand(None, 'abc') for _ in range(100))
    assert rand(None, 'abc', step=1, seed=1) == 'a'
    assert rand(None, 'abc', step=1, seed=2) == 'b'
    assert rand(None, 'abc', step=1, seed=3) == 'c'

# Generated at 2022-06-23 10:12:18.204885
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    test_dict = {'test': '{{ 1 }}', 'test2': '{{ 1 | int }}'}
    templar = Templar(None)
    templar.set_available_variables(dict(test={'test': 1}))
    result = templar.template(test_dict)
    assert to_nice_yaml(result) == to_nice_yaml({'test': 1, 'test2': 1})
    assert to_nice_yaml({'test': 1, 'test2': {'test3': 2}}) == "test: 1\ntest2:\n    test3: 2\n"



# Generated at 2022-06-23 10:12:26.412753
# Unit test for function flatten
def test_flatten():
    assert flatten([[1, 2], 3, 4, [5, 6]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=1) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=2) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=3) == [1, 2, 3, 4, 5, 6]
    assert flatten([[[1, 2]], 3, 4, [[5, 6]]], levels=2) == [[1, 2], 3, 4, [5, 6]]

# Generated at 2022-06-23 10:12:32.377631
# Unit test for function randomize_list
def test_randomize_list():
    '''
    randomize_list: Return an array with the same elements
    in random order.
    '''
    mylist = ['a', 'b', 'c']
    random_list = randomize_list(mylist)
    assert set(mylist) == set(random_list)



# Generated at 2022-06-23 10:12:44.276693
# Unit test for function from_yaml
def test_from_yaml():
    # The tests that test the filter from_yaml
    # must be placed in this function.
    # The name of the function must start with "test_" to be executed
    # In this case, I call it test_from_yaml, so that it is executed
    # when all tests are ran.
    # Most of the tests copied from test_template.py
    def test_dict(template_name, test_cases, should_fail=False):
        if template_name.endswith('.j2'):
            template_name = template_name[:-3]

        test_files_dir = os.path.join(os.path.dirname(__file__), 'filter_tests')
        template_file = os.path.join(test_files_dir, template_name + '.j2')


# Generated at 2022-06-23 10:12:54.288199
# Unit test for function flatten
def test_flatten():
    assert flatten([]) == []
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [3, [4, 5], 6], 7]) == [1, 2, 3, [4, 5], 6, 7]
    assert flatten([[1], 2, [3, [4, 5], 6], 7]) == [1, 2, 3, [4, 5], 6, 7]
    assert flatten([[1], 2, [3, [4, 5], 6], [7]]) == [1, 2, 3, [4, 5], 6, 7]
    assert flatten([[1], 2, [3, [4, 5], 6], [7]]) == [1, 2, 3, [4, 5], 6, 7]

# Generated at 2022-06-23 10:13:01.254224
# Unit test for function ternary
def test_ternary():
    assert ternary(True, "a", "b") == "a"
    assert ternary(False, "a", "b") == "b"
    assert ternary(None, "a", "b") == "b"
    assert ternary(None, "a", "b", "c") == "c"
test_ternary()



# Generated at 2022-06-23 10:13:14.616188
# Unit test for function to_nice_yaml

# Generated at 2022-06-23 10:13:16.172576
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('foo:bar') == 'Zm9vOmJhcg=='



# Generated at 2022-06-23 10:13:23.756262
# Unit test for function comment
def test_comment():
    def assertCommentEqual(text, expected, style='plain', **kwargs):
        actual = comment(text, style, **kwargs)
        assert actual == expected, "%s != %s" % (text, expected)

    assertCommentEqual('Text.', '# Text.')
    assertCommentEqual('Text with multiple lines.\nSecond line.', '# Text with multiple lines.\n# Second line.')
    assertCommentEqual('Text with multiple lines.\nSecond line.', '# Text with multiple lines.\n#\n# Second line.', prefix_count=2)
    assertCommentEqual('Text with multiple lines.\nSecond line.', '# Text with multiple lines.\n# Second line.', decoration='## ')

# Generated at 2022-06-23 10:13:25.335366
# Unit test for function path_join
def test_path_join():
    assert path_join(["/tmp/path", "test"]) == "/tmp/path/test"
    assert path_join("/tmp/path") == "/tmp/path"



# Generated at 2022-06-23 10:13:28.117103
# Unit test for function extract
def test_extract():

    this = {'a': {'b': {'c': 0}, 'd': None, 'e': [{'f': 1}, {'f': 2}, {'f': 3}]}}
    assert extract('c', this['a']['b']) == 0
    assert extract('d', this['a']) is None
    assert extract('e', this['a'], morekeys=[1, 'f']) == 2



# Generated at 2022-06-23 10:13:38.142494
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo\bar') == r'foo\\bar'
    assert regex_escape(r'foo*bar') == r'foo\*bar'
    assert regex_escape(r'foo|bar') == r'foo\|bar'
    assert regex_escape(r'foo^bar') == r'foo\^bar'
    assert regex_escape(r'foo.bar') == r'foo\.bar'
    assert regex_escape(r'foo$bar') == r'foo\$bar'
    assert regex_escape(r'foo+bar') == r'foo\+bar'
    assert regex_escape(r'foo?bar') == r'foo\?bar'
    assert regex_escape(r'foo(bar)') == r'foo\(bar\)'

# Generated at 2022-06-23 10:13:48.705544
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = dict(a=1, b=2)
    result = dict_to_list_of_dict_key_value_elements(mydict)
    assert len(result) == 2
    assert result[0] == dict(key='a', value=1)
    assert result[1] == dict(key='b', value=2)
    result = dict_to_list_of_dict_key_value_elements(mydict, key_name='k', value_name='v')
    assert len(result) == 2
    assert result[0] == dict(k='a', v=1)
    assert result[1] == dict(k='b', v=2)


# Generated at 2022-06-23 10:13:49.923917
# Unit test for function regex_findall
def test_regex_findall():
  assert regex_findall('1234567890', '[0-9]+') == ['1234567890']



# Generated at 2022-06-23 10:13:52.040575
# Unit test for function path_join
def test_path_join():
    assert path_join(['path1', 'path2']) == 'path1/path2'
    assert path_join(['path1', '/path2']) == 'path1/path2'
    assert path_join('path1/path2') == 'path1/path2'
    assert path_join('path1//path2') == 'path1/path2'



# Generated at 2022-06-23 10:14:02.863148
# Unit test for function to_datetime
def test_to_datetime():
    timestamp = "2004-03-01 00:00:00"
    dt = datetime.datetime(2004, 3, 1, 0, 0, 0)
    assert to_datetime(timestamp) == dt
    assert to_datetime(timestamp, format="%Y-%m-%d %H:%M:%S") == dt
    # Now check that an error is thrown if an incompatible format is provided
    try:
        to_datetime(timestamp, format="not a valid format")
    except ValueError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 10:14:05.177757
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({"a": 1, "b": 2}) == "a: 1\nb: 2\n"


# Generated at 2022-06-23 10:14:11.098628
# Unit test for function ternary
def test_ternary():
    true_val = 'this is true'
    false_val = 'this is false'
    none_val = 'this is none'
    assert ternary(True, true_val, false_val, none_val) is true_val
    assert ternary(False, true_val, false_val, none_val) is false_val
    assert ternary(None, true_val, false_val, none_val) is none_val



# Generated at 2022-06-23 10:14:22.527760
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({}) == '{}\n'
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b', 'c': 'd'}) == '{a: b, c: d}\n'
    assert to_yaml({'a': 'b, c: d'}, default_flow_style=False) == '{a: "b, c: d"}\n'
    assert to_yaml(['a', 'b, c: d'], default_flow_style=False) == '- a\n- "b, c: d"\n'

# Generated at 2022-06-23 10:14:26.532382
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('01/01/2000', format='%d/%m/%Y').year == 2000
    assert to_datetime('01-01-2000', format='%m-%d-%Y').month == 1
    assert to_datetime('01/01/2000', format='%d/%m/%Y').day == 1
    assert to_datetime('01/01/2000 00:01:00', format='%d/%m/%Y %H:%M:%S').minute == 1



# Generated at 2022-06-23 10:14:40.637556
# Unit test for function to_json
def test_to_json():
    assert to_json({'a': 10}) == '{"a": 10}'
    assert to_json({"a": 10}) == '{"a": 10}'
    assert to_json(u"unic\xe8") == u'"unic\u00e8"'
    assert to_json(u'unic\xe8') == u'"unic\u00e8"'
    assert to_json(u'unic\u1234') == u'"unic\u1234"'
    assert to_json(u'unic\U00012345') == u'"unic\U00012345"'
    assert to_json(u'unic\U00012345'.encode('utf-16be')) == u'"unic\U00012345"'
    assert to_json(u'unic\U00012345'.encode('utf-16le')) == u

# Generated at 2022-06-23 10:14:44.667414
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes')
    assert not to_bool(None)
    assert not to_bool('off')



# Generated at 2022-06-23 10:14:54.700683
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ['/tmp/alice/onekey.pub']}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements

# Generated at 2022-06-23 10:15:07.134853
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == r'foo'
    assert regex_escape('[foo]') == r'\[foo\]'
    assert regex_escape('\n') == r'\\n'
    assert regex_escape('\t') == r'\\t'
    assert regex_escape('\r') == r'\\r'
    assert regex_escape('\a') == r'\\a'
    assert regex_escape('(foo)') == r'\(foo\)'
    assert regex_escape('{foo}') == r'\{foo\}'
    assert regex_escape('(.*)') == r'\(\.\*\)'
    assert regex_escape('{0,1}') == r'\{0,1\}'
    assert regex_escape('foo\\bar') == r'foo\\bar'


# Generated at 2022-06-23 10:15:16.020925
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('abcd') == 'abcd'
    assert regex_escape('a.b[c:d]') == 'a\\.b\\[c\\:d\\]'
    assert regex_escape('a*b?c.', re_type='posix_basic') == 'a\\*b\\?c\\.'
    assert regex_escape('a*b?c.', re_type='python') == 'a\\*b\\?c\\.'

# Generated at 2022-06-23 10:15:23.764409
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml({'foo': 'bar'}) == {'foo': 'bar'}
    assert from_yaml('{"foo": "bar"}') == {'foo': 'bar'}
    assert from_yaml('foo: bar') == {'foo': 'bar'}


# Generated at 2022-06-23 10:15:32.999615
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password(
        password='password',
        hashtype='md5',
        salt='salt',
        salt_size=6,
        rounds=5000,
        ident='$1$'
    ) == '$1$salt$ED5mPp/nZw5.W/VKhmhVY1'

    assert get_encrypted_password(
        password='password',
        hashtype='sha256',
        salt='salt',
        salt_size=16,
        rounds=5000,
        ident='$5$'
    ) == '$5$salt$YumUBYCvuk8aOg/5O5j5p5DZw5hyZADW/6BmHbPN/d6'
