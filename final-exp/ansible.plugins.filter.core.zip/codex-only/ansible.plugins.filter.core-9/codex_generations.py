

# Generated at 2022-06-23 10:05:31.513355
# Unit test for function regex_replace
def test_regex_replace():  # pylint: disable=R0201
    assert regex_replace(r'\r\n', r'\r\n', r'\n') == r'\n'
    assert regex_replace(r'\r\n', r'\r\n', r'\n', ignorecase=True) == r'\n'
    assert regex_replace(r'\r\n', r'\r\n', r'\n', multiline=True) == r'\n'



# Generated at 2022-06-23 10:05:42.261788
# Unit test for function to_yaml
def test_to_yaml():
    t = {
        'a': 1,
        'b': 'foo',
        'c': [1, 2, 3]
    }
    assert to_yaml(t) == '''\
a: 1
b: foo
c: [1, 2, 3]
'''

    t = {
        'a': 1,
        'b': 'foo',
        'c': [1, 2, 3]
    }
    assert to_yaml(t, default_flow_style=False) == '''\
a: 1
b: foo
c:
  - 1
  - 2
  - 3
'''


# Generated at 2022-06-23 10:05:44.488302
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({"test": [{"test": 2}]}) == '{\n    "test": [\n        {\n            "test": 2\n        }\n    ]\n}'
# End unit test



# Generated at 2022-06-23 10:05:55.017851
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # Note: it is expected that we use get_encrypted_password() with hexdigest, not checksum
    assert passlib_or_crypt('f00bar', 'sha512_crypt') == "$6$rounds=656000$TtNgNQ2S0GeTzHsx$XIRZ4m/gE/4aBImBwPeupyIgsYlEenl3mOoL2Iz91jR7SL0JbO8tKgAOKyGjQlYTtTlDtHLKjPZ9b4C4H4WhE1"

# Generated at 2022-06-23 10:05:59.521796
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    """unit test for list_of_dict_key_value_elements_to_dict"""
    mylist = [
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2},
    ]

    result = list_of_dict_key_value_elements_to_dict(mylist)
    assert result == {'a': 1, 'b': 2}

    result = list_of_dict_key_value_elements_to_dict(mylist, 'key', 'value')
    assert result == {'a': 1, 'b': 2}

    result = list_of_dict_key_value_elements_to_dict(mylist, 'name', 'value')
    assert result == {'a': 1, 'b': 2}

    result = list_of_

# Generated at 2022-06-23 10:06:05.948653
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('SGVsbG8gV29ybGQ=') == 'Hello World'
    assert b64decode('SGVsbG8gV29ybGQ=', encoding='ascii') == 'Hello World'
    with pytest.raises(UnicodeDecodeError):
        b64decode('SGVsbG8gV29ybGQ=', encoding='utf-16')
    assert b64decode('wqM=') == b'\U0001F622'
    assert b64decode('wqM=', encoding='ascii') == b'\U0001F622'
    assert b64decode('wqM=', encoding='utf-16') == '😢'

# Generated at 2022-06-23 10:06:13.310493
# Unit test for function regex_escape
def test_regex_escape():
    '''Unit test for function regex_escape'''
    assert regex_escape('[a.c]', 'python') == r'\[a\.c\]'
    assert regex_escape('[a.c]', 'posix_basic') == r'\[a\.c\]'
    assert regex_escape('[]') == r'\[\]'
    assert regex_escape('.') == r'\.'
    assert regex_escape('^') == r'\^'
    assert regex_escape('$') == r'\$'
    assert regex_escape('*') == r'\*'
    assert regex_escape('\\') == r'\\'


# Generated at 2022-06-23 10:06:23.365038
# Unit test for function b64decode
def test_b64decode():
  param = 'hello world'
  param_enc = to_text(base64.b64encode(to_bytes(param, encoding='utf-8', errors='surrogate_or_strict')))

# Generated at 2022-06-23 10:06:28.524460
# Unit test for function to_nice_json
def test_to_nice_json():
    datastructure = {
        b"foo": b"bar",
        u"baz": u"frotz\u2122"
    }
    actual = to_nice_json(datastructure)
    assert json.loads(actual) == datastructure



# Generated at 2022-06-23 10:06:32.311726
# Unit test for function fileglob
def test_fileglob():
   pathname = '/var/log/*.log'
   results = fileglob(pathname)
   assert results == [g for g in glob.glob(pathname)]



# Generated at 2022-06-23 10:06:35.928397
# Unit test for function to_datetime
def test_to_datetime():
    assert isinstance(to_datetime('2014-02-27 12:08:50', "%Y-%m-%d %H:%M:%S"), datetime.datetime)



# Generated at 2022-06-23 10:06:40.897458
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_var = {'key1': {'key2': {'key3': ['value1', 'value2']}}, 'key4': 'value3'}
    result = to_nice_yaml(test_var)
    assert isinstance(result, str)
    assert result == "key1:\n  key2:\n    key3:\n    - value1\n    - value2\nkey4: value3\n"


# Generated at 2022-06-23 10:06:47.819675
# Unit test for function quote
def test_quote():
    assert quote(u"hello world") == u"'hello world'"
    assert quote(u"hello' world") == u"'hello'\\'' world'"
    assert quote(u"hello; world") == u"'hello; world'"
    assert quote(u"hello \" world") == u"'hello \" world'"
    assert quote(u"hello\\ world") == u"'hello\\ world'"
    assert quote(u"hello world\xfd") == u"'hello world\xfd'"
    assert quote(u"hello world\xfd", safe=u"\xfd") == u"'hello world\xfd'"



# Generated at 2022-06-23 10:06:54.205888
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    expected_results = [({"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}, 'wheel')]
    assert expected_results == subelements(obj, 'groups')



# Generated at 2022-06-23 10:07:02.142597
# Unit test for function regex_escape
def test_regex_escape():
    def check(x):
        assert regex_escape(x, 'python') == regex_escape(x, 'posix_basic')

    check('abcdef')
    check('[[.!$&*^#]]')
    check('\\a')
    check('\\\\a')
    check('[\\]a')
    check('\\\\\\a')
    check(']]a\\')
    check('\\\\\\]]a\\')



# Generated at 2022-06-23 10:07:11.787146
# Unit test for function combine
def test_combine():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from . import runner

    test = runner.Runner(
        module_name='dict',
        module_args='',
        module_kwargs=dict(a=1),
        pattern='all',
        forks=10,
    )

    test.set_inventory(None)
    test.run()
    host_vars = test.get_host_vars()['localhost']
    assert isinstance(host_vars, AnsibleMapping)

    d = dict(a=1, b=1)
    e = dict(a=2, b=2)
    result = combine(d, e)
    assert 'a' in result
    assert result['a'] == 2

    d = dict(a=dict(b=1))

# Generated at 2022-06-23 10:07:20.518394
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo', 'python') == 'foo'
    assert regex_escape('foo', 'posix_basic') == 'foo'
    assert regex_escape('foo', 'posix_extended') == 'foo'

    assert regex_escape('.', 'python') == '\\.'
    assert regex_escape('*', 'python') == '\\*'
    assert regex_escape('+', 'python') == '\\+'
    assert regex_escape('?', 'python') == '\\?'
    assert regex_escape('|', 'python') == '\\|'
    assert regex_escape('(', 'python') == '\\('
    assert regex_escape(')', 'python') == '\\)'
    assert regex_escape('[', 'python') == '\\['

# Generated at 2022-06-23 10:07:32.930582
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool("True") is True
    assert to_bool("False") is False
    assert to_bool("true") is True
    assert to_bool("false") is False
    assert to_bool("Yes") is True
    assert to_bool("No") is False
    assert to_bool("yes") is True
    assert to_bool("no") is False
    assert to_bool("1") is True
    assert to_bool("0") is False
    assert to_bool("On") is True
    assert to_bool("Off") is False
    assert to_bool("on") is True
    assert to_bool("off") is False



# Generated at 2022-06-23 10:07:36.355856
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json(["foo", {"bar":["baz", None, 1.0, 2]}]) == '''[
    "foo",
    {
        "bar": [
            "baz",
            null,
            1.0,
            2
        ]
    }
]'''



# Generated at 2022-06-23 10:07:45.665242
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(dict(a=1,b=2,c=3)) == u'{a: 1, b: 2, c: 3}\n'
    assert to_yaml(dict(a=1,b=2,c=3), default_flow_style=False) == u'a: 1\nb: 2\nc: 3\n'
    assert to_yaml(dict(a=dict(a=1,b=2,c=3)), default_flow_style=False) == u'a:\n    a: 1\n    b: 2\n    c: 3\n'


# Generated at 2022-06-23 10:07:48.626988
# Unit test for function to_yaml
def test_to_yaml():
    # There are no tests for function to_yaml but the test_jinja2_filters test
    # module contains a unit test that involves to_yaml
    pass

# Shared Filters


# Generated at 2022-06-23 10:08:01.250763
# Unit test for function to_uuid
def test_to_uuid():
    assert '361e6d51-faec-444a-9079-341386da8e2e' == to_uuid('foo')
    assert '361e6d51-faec-444a-9079-341386da8e2e' == to_uuid('foo', namespace='361e6d51-faec-444a-9079-341386da8e2e')
    assert '361e6d51-faec-444a-9079-341386da8e2e' == to_uuid('foo', namespace='361e6d51faec4449079341386da8e2e')

# Generated at 2022-06-23 10:08:04.670949
# Unit test for function rand
def test_rand():
    assert rand(1, 0, 100, seed=1) == 73
    assert rand(1, 0, 100, seed=2) == 18
    assert rand([1,2], seed=1) == 2



# Generated at 2022-06-23 10:08:13.046507
# Unit test for function do_groupby
def test_do_groupby():
    """Unit test for function do_groupby"""
    environment = Environment()
    value = [{'group_name': 'a', 'val': 1}, {'group_name': 'a', 'val': 2}, {'group_name': 'a', 'val': 2}]
    attribute = 'group_name'
    grouped_ins = do_groupby(environment, value, attribute)
    assert len(grouped_ins) == 1
    group = grouped_ins[0]
    assert group[0] == 'a'
    assert len(group[1]) == 3
    assert group[1][0]['val'] == 1
    assert group[1][1]['val'] == 2
    assert group[1][2]['val'] == 2



# Generated at 2022-06-23 10:08:14.686036
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    module, tests = doctest.testmod()
    assert tests == 0

if __name__ == "__main__":
    import doctest
    module, tests = doctest.testmod()
    print('%s' % module)

# Generated at 2022-06-23 10:08:21.340179
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'key1': 'val1', 'key2': 'val2'}, 'k', 'v') == [{'k': 'key1', 'v': 'val1'}, {'k': 'key2', 'v': 'val2'}]



# Generated at 2022-06-23 10:08:27.561780
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None

    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool(1) is True

    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool(0) is False


# Generated at 2022-06-23 10:08:30.182313
# Unit test for function fileglob
def test_fileglob():
    ''' fileglob should return a list of files when passed a file glob '''
    assert fileglob('/etc/*')



# Generated at 2022-06-23 10:08:31.951854
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('one and two', 'one and two') == ['one and two']


# Generated at 2022-06-23 10:08:35.355056
# Unit test for function to_json
def test_to_json():
    '''
    This is a unit test for the function to_json
    '''
    string = to_json(dict(a=2, b='test'))
    assert string == '{"a": 2, "b": "test"}'

# Generated at 2022-06-23 10:08:43.655382
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value="foobar", pattern=r"foo", replacement="baz") == "bazbar"
    assert regex_replace(value="foobar", pattern=r"foo", replacement="baz", ignorecase=True) == "bazbar"
    assert regex_replace(value="foobar", pattern=r"foo", replacement="baz", multiline=True) == "bazbar"
    assert regex_replace(value="foobar", pattern=r"foo", replacement="baz", ignorecase=True, multiline=True) == "bazbar"

    assert regex_replace(value="a foo bar", pattern=r"foo", replacement="baz") == "a baz bar"

# Generated at 2022-06-23 10:08:53.612485
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == '- 1\n- 2\n- 3\n'
    assert to_yaml({'1': 1, '2': 2, '3': 3}) == '1: 1\n2: 2\n3: 3\n'
    assert to_yaml({'a': {'b': {'c': 1}, 'd': 2}, 'b': [3, 4, 5]}) == 'a:\n  b:\n    c: 1\n  d: 2\nb:\n- 3\n- 4\n- 5\n'



# Generated at 2022-06-23 10:09:01.472112
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    print("Testing dict_to_list_of_dict_key_value_elements...")
    c = {'var1': 'value1', 'var2': 'value2'}
    r = dict_to_list_of_dict_key_value_elements(c)
    assert r == [{'key': 'var1', 'value': 'value1'}, {'key': 'var2', 'value': 'value2'}]
    print("SUCCESS")
test_dict_to_list_of_dict_key_value_elements()



# Generated at 2022-06-23 10:09:03.030949
# Unit test for function extract
def test_extract():
    import pytest
    testhash = {'a': 'b', 'c': {'d': 'e'}}
    assert 'b' == extract("a", testhash)
    assert 'e' == extract("c", testhash, "d")



# Generated at 2022-06-23 10:09:09.535351
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'[1, "foo", false]') == [1, "foo", False]
    assert from_yaml(b'[1, "foo", false]') == [1, "foo", False]
    assert from_yaml(u'[1, "foo", false]') == [1, "foo", False]
    assert from_yaml(b'[1, "foo", false]') == [1, "foo", False]
    assert from_yaml(u'[1, "foo", false]') == [1, "foo", False]



# Generated at 2022-06-23 10:09:15.757438
# Unit test for function do_groupby
def test_do_groupby():

    data = [
        {
            'age': 42,
            'name': 'Brian'
        },
        {
            'age': 52,
            'name': 'Sue'
        },
        {
            'age': 52,
            'name': 'Steve'
        },
        {
            'age': 42,
            'name': 'Lary'
        }
    ]
    # The result is identical to the result of the jinja2 implementation,
    # but each namedtuple is cast as a tuple, so the repr of the object is
    # parseable

# Generated at 2022-06-23 10:09:20.570334
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader
    from ansible.template import Jinja2Template
    env = Jinja2Template(DictLoader(), {}, None, None, None).env
    a = [{'a': 1, 'b': 1, 'c': 1}, {'a': 1, 'b': 2, 'c': 2}, {'a': 2, 'b': 3, 'c': 3}]
    def test_do_groupby(a, k):
        return do_groupby(env, a, k)
    assert test_do_groupby(a, 'a') == [[(1, 2), [(1, 1, 1), (1, 2, 2)]], [(2, 3), [(2, 3, 3)]]]

# Generated at 2022-06-23 10:09:27.305423
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    l = [
        {'key': 'foo', 'value': 'bar'},
        {'key': 'fooz', 'value': 'baz'},
        {'key': 'beep', 'value': 'boop'},
    ]
    d = list_of_dict_key_value_elements_to_dict(l)
    assert d == dict(foo='bar', fooz='baz', beep='boop')



# Generated at 2022-06-23 10:09:33.517664
# Unit test for function from_yaml_all
def test_from_yaml_all():
    multiline_data = '''[
        {
            "key1": "value1",
            "key2": "value2"
        },
        {
            "key3": "value3",
            "key4": "value4"
        }
    ]'''
    assert(len(from_yaml_all(multiline_data)) == 2)



# Generated at 2022-06-23 10:09:46.607418
# Unit test for function combine
def test_combine():
    # check that the same result is returned with an array or a list of parameters
    data = [dict(a=1, b=2, c=[3, 4], d=dict(e=5, f=6)), dict(b=2, c=[9, 9], d=dict(f=10))]
    assert combine(data) == combine(*data)

    # multiple level dictionnary
    assert combine(data) == dict(a=1, b=2, c=[9, 9], d=dict(e=5, f=10))
    assert combine(data, recursive=True) == dict(a=1, b=2, c=[9, 9], d=dict(e=5, f=10))

    # multiple level list (do not merge, just replace)

# Generated at 2022-06-23 10:09:53.054757
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    # test case: convert the result of a dict2items filter to a dictionary
    mydict = {'a': 1, 'b': 2, 'c': 3}
    mydict_converted = list_of_dict_key_value_elements_to_dict(dict_to_list_of_dict_key_value_elements(mydict))
    assert mydict == mydict_converted

# Generated at 2022-06-23 10:10:00.172861
# Unit test for function to_uuid
def test_to_uuid():
    string = uuid.uuid4()
    result = to_uuid(string, namespace=UUID_NAMESPACE_ANSIBLE)
    assert isinstance(result, string_types)
    assert result.startswith(text_type(UUID_NAMESPACE_ANSIBLE))
    assert string.hex in result



# Generated at 2022-06-23 10:10:05.088191
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo", 'foo') == 'foo'
    assert regex_search("foo", 'foo', '\\g<0>') == 'foo'
    assert regex_search("foo", 'foo', '\\0') == 'foo'
    assert regex_search("foo", 'foo', '\\1') == None
    assert regex_search("foo", 'foo', '\\g<1>') == None
    assert regex_search("foo", 'foo', '\\g<0>', '\\g<0>', '\\1') == ['foo', 'foo', None]
    assert regex_search("foo", 'f(oo)', '\\g<0>', '\\g<1>') == ['foo', 'oo']

# Generated at 2022-06-23 10:10:08.062944
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json([{'one': 1, 'two': 2, 'three': 3}]) == '[\n    {\n        "one": 1,\n        "two": 2,\n        "three": 3\n    }\n]'



# Generated at 2022-06-23 10:10:17.259217
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2, 'c': 3}) == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}]
    assert dict_to_list_of_dict_key_value_elements(dict(a=1), 'k', 'v') == [dict(k='a', v=1)]
    return



# Generated at 2022-06-23 10:10:20.640602
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello world') == 'aGVsbG8gd29ybGQ='



# Generated at 2022-06-23 10:10:27.882443
# Unit test for function strftime
def test_strftime():
    '''
    Test function strftime
    '''
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%Y', second=0) == time.strftime('%Y', time.localtime(0))
    assert strftime('%Y-%m-%d', second=0) == time.strftime('%Y-%m-%d', time.localtime(0))



# Generated at 2022-06-23 10:10:37.397043
# Unit test for function rand
def test_rand():
    test_env = Environment()
    test_env.filters.update(whitelist_internal('test_rand'))
    assert rand(test_env, 5) >= 0 and rand(test_env, 5) < 5
    assert rand(test_env, 5, seed=123) == 2
    assert rand(test_env, 5, 2) >= 2 and rand(test_env, 5, 2) < 5
    assert rand(test_env, 5, step=2) % 2 == 0
    assert rand(test_env, [1, 2, 3]) in [1, 2 ,3]
    assert rand(test_env, [1, 2, 3], seed=123) == 2



# Generated at 2022-06-23 10:10:46.461386
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('Testing, testing, 123...') == 'VGVzdGluZywgdGVzdGluZywgMTIzLi4u'
    assert b64encode('Проверка, проверка, тест...') == '0J/RgNC40LLQtdCy0YHRjywg0J/RgNC40LLQtdCy0YHRjywg0LrQu9Cw0YHRjy4uLg=='



# Generated at 2022-06-23 10:10:56.426699
# Unit test for function to_nice_json
def test_to_nice_json():
    # The error 'null' is None in Python is not JSON serializable
    assert to_nice_json(None) == 'null'
    # Error 'datetime.datetime(2014, 6, 12, 12, 4, 41, 190047) is not JSON serializable'
    assert to_nice_json(datetime.datetime.now()) == 'null'
    # Error 'set([1, 2]) is not JSON serializable'
    assert to_nice_json([1,2]) == '[1, 2]'
    assert to_nice_json({'a':1, 'b':2}) == '{"a": 1, "b": 2}'
    assert to_nice_json(dict()) == '{}'

# ------------------------------
# Jinja2 Filter documentation
# ------------------------------

# Extend list of jinja2 filter documentation for Ansible

# Generated at 2022-06-23 10:11:00.269465
# Unit test for function do_groupby
def test_do_groupby():
    group_list = [
        {'name': 'barney', 'age': 36, 'active': True},
        {'name': 'fred', 'age': 40, 'active': False},
        {'name': 'barney', 'age': 26, 'active': True},
    ]
    assert do_groupby(group_list, 'name') == [
        ('barney', [
            {'name': 'barney', 'age': 36, 'active': True},
            {'name': 'barney', 'age': 26, 'active': True}
        ]),
        ('fred', [
            {'name': 'fred', 'age': 40, 'active': False}
        ]),
    ]



# Generated at 2022-06-23 10:11:12.172835
# Unit test for function path_join
def test_path_join():
    assert path_join('a') == os.path.join('a')
    assert path_join(['a']) == os.path.join('a')
    assert path_join(['a','b']) == os.path.join('a','b')
    assert path_join(['a','b','c']) == os.path.join('a','b','c')
    # Test with trailing slash
    assert path_join('/a/') == os.path.join('/a')
    assert path_join(['/a/']) == os.path.join('/a')
    assert path_join(['/a/','/b/']) == os.path.join('/a','/b')

# Generated at 2022-06-23 10:11:14.089395
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule.filters(FilterModule())) == 61


# Generated at 2022-06-23 10:11:23.115055
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements(dict(a=1, b=2)) == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    assert dict_to_list_of_dict_key_value_elements(dict(a=1, b=2), key_name='name', value_name='age') == [{'name': 'a', 'age': 1}, {'name': 'b', 'age': 2}]
    assert dict_to_list_of_dict_key_value_elements(dict(a=1, b=2), key_name='name') == [{'name': 'a', 'value': 1}, {'name': 'b', 'value': 2}]
    assert dict_to_list_of_

# Generated at 2022-06-23 10:11:26.282515
# Unit test for function b64encode
def test_b64encode():
    # From http://de.wikipedia.org/wiki/Base64
    assert b64encode('Man') == 'TWFu'



# Generated at 2022-06-23 10:11:36.609954
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json(None) == 'null'
    assert to_nice_json(True) == 'true'
    assert to_nice_json(False) == 'false'
    assert to_nice_json(42) == '42'
    assert to_nice_json(u'foo') == '"foo"'
    assert to_nice_json([u'foo', {u'bar': u'baz'}]) == '[\n    "foo",\n    {\n        "bar": "baz"\n    }\n]'
    assert to_nice_json({u'foo': u'bar'}) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-23 10:11:48.815690
# Unit test for function to_datetime
def test_to_datetime():
    string1 = "2014-11-28 16:15:59"
    dt = to_datetime(string1)
    assert dt.strftime("%Y-%m-%d %H:%M:%S") == string1 
    string2 = "2014/11/28 16:15:59"
    format2 = "%Y/%m/%d %H:%M:%S"
    dt2 = to_datetime(string2, format2)
    assert dt.strftime(format2) == string2


# Generated at 2022-06-23 10:11:53.042812
# Unit test for function quote
def test_quote():
    assert quote("a b c") == "'a b c'"
    assert quote("'a b c'") == "'\"'\"'a b c'\"'\"'"
    assert quote(None) == "''"



# Generated at 2022-06-23 10:11:54.941351
# Unit test for function path_join
def test_path_join():
    paths = ['foo', 'bar']
    result = path_join(paths)
    assert result == os.path.join(paths), "path_join() should return {} but returned {}".format(os.path.join(paths), result)



# Generated at 2022-06-23 10:11:58.130325
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'



# Generated at 2022-06-23 10:12:05.103361
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'yes', 'no') == 'yes'
    assert ternary(False, 'yes', 'no') == 'no'
    assert ternary(True, 'yes', 'no', 'maybe') == 'yes'
    assert ternary(None, 'yes', 'no', 'maybe') == 'maybe'



# Generated at 2022-06-23 10:12:09.104461
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': {'b': [1, 2, 3]}}) == (
        "a:\n"
        "  b:\n"
        "  - 1\n"
        "  - 2\n"
        "  - 3\n")


# Generated at 2022-06-23 10:12:12.442889
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert(to_nice_yaml(dict(a=1, b=2), indent=2) == '''{
  a: 1
  b: 2
}
''')
test_to_nice_yaml()



# Generated at 2022-06-23 10:12:21.472630
# Unit test for function get_encrypted_password

# Generated at 2022-06-23 10:12:33.439488
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    '''
    dict2items:
    >>> from ansible.template import Templar
    >>> t = Templar(loader=DictDataLoader({}))
    >>> items = t.template("{{ mydict | dict2items }}")
    >>> print(items)
    [{'key': 'a', 'value': '1'}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 'three'}]

    items2dict:
    >>> mydict = t.template("{{ items | items2dict }}")
    >>> print(mydict)
    {'a': '1', 'c': 'three', 'b': 2}
    '''



# Generated at 2022-06-23 10:12:42.145769
# Unit test for function ternary
def test_ternary():
    assert ternary(True, "1", "0") == "1"
    assert ternary(False, "1", "0") == "0"
    assert ternary(None, "1", "0") == "0"
    assert ternary(True, "1", "0", none_val="2") == "1"
    assert ternary(False, "1", "0", none_val="2") == "0"
    assert ternary(None, "1", "0", none_val="2") == "2"



# Generated at 2022-06-23 10:12:43.870944
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(u'123abc\n') == u'123abc'



# Generated at 2022-06-23 10:12:51.520069
# Unit test for function regex_findall
def test_regex_findall():

    testwords = '''
    regex_replace:
      - The regex_replace Jinja2 filter replaces all occurrences of a pattern in a string with a replacement.
    '''

    testwords_yaml = '''
    regex_replace:
      - The regex_replace Jinja2 filter replaces all occurrences of a pattern in a string with a replacement.
    '''

    possiblewords = [
        'findall', 'finditer', 'match', 'split', 'sub', 'subn', 'template'
    ]

    multiline = True
    ignorecase = False
    expect = [
        'findall', 'finditer', 'match', 'split', 'sub', 'subn', 'template'
    ]
    result = []
    regex = r'^[\s-]*(regex_\w+)[\s:]'

    result

# Generated at 2022-06-23 10:12:54.836953
# Unit test for function randomize_list
def test_randomize_list():
    list1 = ['foo', 'bar', 'baz', 'qux', None]
    list2 = ['foo', 'bar', 'baz', 'qux', None]
    if randomize_list(list1) == list2:
        raise AssertionError('Failed randomize_list()')



# Generated at 2022-06-23 10:13:02.525484
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    undef = Undefined('foo')
    assert mandatory(1) == 1
    try:
        mandatory(undef)
        assert False
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_text(e)
    try:
        mandatory(undef, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == 'foo'



# Generated at 2022-06-23 10:13:08.354837
# Unit test for function do_groupby
def test_do_groupby():
    env = ansible.template.environment.Environment()
    f = ansible.utils.template.AnsibleJ2TemplateModule()
    mylist = [
        {'foo': 1, 'bar': 'a'},
        {'foo': 1, 'bar': 'b'},
        {'foo': 2, 'bar': 'c'},
        {'foo': 3, 'bar': 'a'}
    ]
    result = f.do_groupby(mylist, 'foo')
    assert result == [sorted(item) for item in _do_groupby(env, mylist, 'foo')]



# Generated at 2022-06-23 10:13:13.353186
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('test') == 'dGVzdA=='
    assert b64encode('test', encoding='utf-16') == 'dABlAHMAdAA='



# Generated at 2022-06-23 10:13:18.447954
# Unit test for function subelements
def test_subelements():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # generic test-cases

# Generated at 2022-06-23 10:13:22.914660
# Unit test for function ternary
def test_ternary():
    ''' test_ternary() ... unit test for function ternary '''
    assert ternary('', 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false') == 'false'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary('', 'true', 'false', 'none') == 'none'



# Generated at 2022-06-23 10:13:29.532685
# Unit test for function to_bool
def test_to_bool():
    true_values = [True, 1, '1', 'True', 'true', 'yes', 'on']
    false_values = [False, 0, '0', 'False', 'false', 'no', 'off']

    for value in true_values:
        assert(to_bool(value) is True)

    for value in false_values:
        assert(to_bool(value) is False)



# Generated at 2022-06-23 10:13:36.597350
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # True if the password contains the hash part and the salt part.
    def is_hashed(result):
        if isinstance(result, string_types):
            return len(result.split('$')) >= 3
        else:
            return False
    assert is_hashed(get_encrypted_password('foo'))
    assert is_hashed(get_encrypted_password('foo', 'sha512'))
    assert is_hashed(get_encrypted_password('foo', 'md5'))



# Generated at 2022-06-23 10:13:39.442239
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# -------------------------------------------------------------------------
# Ansible filters
# -------------------------------------------------------------------------

# Generated at 2022-06-23 10:13:51.528652
# Unit test for function from_yaml
def test_from_yaml():
    test1 = """
    - hosts: all
      vars:
        - test:
            key: value
    """
    result = from_yaml(test1)
    assert result == [{u'hosts': u'all', u'vars': [{u'test': {u'key': u'value'}}]}], 'from_yaml failed on "{{ test1 | from_yaml }}"'
    test2 = """
    ---
    - hosts: all
      vars:
        - test:
            key: value
    """
    result = from_yaml(test2)

# Generated at 2022-06-23 10:13:54.549816
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([3, 'ok', 'yes']) == [3, 'ok', 'yes']
    assert randomize_list([3, 'ok', 'yes'], 9) == [3, 'yes', 'ok']



# Generated at 2022-06-23 10:14:00.747377
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('4444444444444444444444444444444444444444444444444444444444444444444444444444444444444')) == '4444444444444444444444444444444444444444444444444444444444444444444444444444444444444'

# Generated at 2022-06-23 10:14:05.523057
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters.__doc__ == FilterModule.filters.__doc__
    assert FilterModule.filters.__name__ == FilterModule.filters.__name__
    assert FilterModule.filters.__qualname__ == FilterModule.filters.__qualname__
    assert FilterModule.filters.__ge

# Generated at 2022-06-23 10:14:07.635368
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', second=1415186790) == '2014-11-02'


# Generated at 2022-06-23 10:14:19.992576
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    results = []

    results.append(list_of_dict_key_value_elements_to_dict(
        [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2})
    results.append(list_of_dict_key_value_elements_to_dict(
        [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'a', 'value': 3}]) == {'a': 3, 'b': 2})

# Generated at 2022-06-23 10:14:22.481416
# Unit test for function from_yaml
def test_from_yaml():
    data = dict(a='b', c='d')
    assert data == from_yaml(to_yaml(data))

# Generated at 2022-06-23 10:14:35.956624
# Unit test for function comment
def test_comment():
    assert (comment('', style='plain') == '# ')
    assert (comment('') == '# ')
    assert (comment('foo') == '# foo')
    assert (comment('foo bar') == '# foo bar')
    assert (comment('foo bar', prefix='// ') == '// foo bar')
    assert (comment('foo\nbar') == "# foo\n# bar")
    assert (comment('foo\nbar', style='cblock') == "/*\n * foo\n * bar\n */")
    assert (comment('foo\nbar', style='xml') == '<!--\n - foo\n - bar\n-->')
    assert (comment('foo\nbar', prefix='// ', postfix=' -- ') == "// foo\n// -- bar\n// -- ")



# Generated at 2022-06-23 10:14:41.240060
# Unit test for function to_yaml
def test_to_yaml():
    try:
        assert to_yaml({'foo': 'bar', 'baz': ['bam']}) == "foo: bar\nbaz:\n- bam\n"
    except TypeError:
        assert to_yaml({'foo': 'bar', 'baz': ['bam']}) == "foo: bar\nbaz:\n- bam\n...\n"



# Generated at 2022-06-23 10:14:47.478484
# Unit test for function subelements
def test_subelements():
    data = [{'a': {'b': {'c': [1, 2]}}}]
    result = subelements(data, ['a', 'b', 'c'])
    assert result == [(data[0], 1), (data[0], 2)]



# Generated at 2022-06-23 10:14:57.023588
# Unit test for function to_nice_json
def test_to_nice_json():
    result1 = to_nice_json({1: "a", 2: "b", 3: "c"})
    result2 = to_nice_json({1: "a", 2: "b ", "c": {6: "d ", 5: 4}})
    assert result1 == '{\n    "1": "a", \n    "2": "b", \n    "3": "c"\n}'
    assert result2 == '{\n    "1": "a", \n    "2": "b ", \n    "c": {\n        "5": 4, \n        "6": "d " \n    }\n}'



# Generated at 2022-06-23 10:15:03.118956
# Unit test for function to_datetime
def test_to_datetime():
    """
    Returns OK if the unit test passes
    """

# Generated at 2022-06-23 10:15:06.039419
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'



# Generated at 2022-06-23 10:15:18.931307
# Unit test for function rand
def test_rand():
    import ansible.constants as C
    if C.DEFAULT_RANDOM_SEED != None:
        seed = C.DEFAULT_RANDOM_SEED
    else:
        seed = 12345
    r = Random(seed)
    # test integer
    value = rand(5)
    if not type(value) is int:
        raise AssertionError('value is not an integer')
    if value < 0 or value > 4:
        raise AssertionError('value is not in correct range')
    # test integer with start and step
    value = rand(5, start=3, step=2)
    if not type(value) is int:
        raise AssertionError('value is not an integer')
    if value < 3 or value > 5:
        raise AssertionError('value is not in correct range')

# Generated at 2022-06-23 10:15:24.472577
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel']}, 'wheel')]

