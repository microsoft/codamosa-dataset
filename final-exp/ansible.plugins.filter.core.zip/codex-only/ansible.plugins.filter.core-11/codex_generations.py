

# Generated at 2022-06-23 10:05:33.869927
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2], 3]) == [1, 2, 3]
    assert flatten([[1, [2, [3]]], 4]) == [1, 2, 3, 4]
    assert flatten([[[[[[[1]]]]]], [[[[[[2]]]]]]]) == [1, 2]
    assert flatten([[[[1, 2], 3]], 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 10:05:45.152619
# Unit test for function flatten
def test_flatten():
    assert flatten([[1, 2], 3, 4, [5, 6]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=1) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=2) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], levels=3) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2], 3, 4, [5, 6]], 1) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-23 10:05:54.626146
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('abc') == 'YWJj'
    assert b64encode('abc', 'latin1') == 'YWJj'
    assert b64encode('😬') == '8J+YhQ=='
    assert b64encode('😬', 'latin1') == '8J+YhQ=='
    assert b64encode('\xff') == '//8='
    assert b64encode('\xff', 'latin1') == '//8='



# Generated at 2022-06-23 10:06:03.432103
# Unit test for function regex_escape
def test_regex_escape():
    from ansible.module_utils.common.text.converters import to_str

    for i in range(0, 256):
        # python supports all ascii characters, so we only need to test escaping
        # for characters less than 128.  For a full implementation of all
        # regex_escape, we'd need to do the full 256, but that'll cause test
        # failures as re.escape doesn't support all POSIX regexes, and will
        # escape all characters less than 256.
        if i < 128:
            s = chr(i)
            assert regex_escape(s) == re.escape(s)
        # We test all characters less than 256 because regex_replace, the
        # function that regex_escape uses, supports all of unicode, not just
        # ascii.

# Generated at 2022-06-23 10:06:11.997902
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('Hello world', 'world') == ['world']
    assert regex_findall('Hello world', 'world$') == []
    assert regex_findall('Hello world', 'Hello') == ['Hello']
    assert regex_findall('Hello world, Hello world', 'world') == ['world', 'world']
    assert regex_findall('Hello world, Hello world', 'world$') == ['world']
    assert regex_findall('Hello world, Hello world', '^Hello') == ['Hello', 'Hello']
    assert regex_findall('Hello world, Hello world', '^world') == []
    assert regex_findall('Hello world, Hello world', 'Hello') == ['Hello', 'Hello']
    assert regex_findall('Hello world, Hello world', 'o') == ['o', 'o']

# Generated at 2022-06-23 10:06:18.346322
# Unit test for function quote
def test_quote():
    assert quote('foo bar') == u"'foo bar'"
    assert quote('foo\'bar') == u"'foo'\\''bar'"
    assert quote(u'foo\'bar') == u"'foo'\\''bar'"
    assert quote('foo "bar"') == u"'foo \"bar\"'"
    assert quote('foo\' "bar" ') == u"'foo'\\'' \"bar\" '"
    assert quote(u'foo\' "bar" ') == u"'foo'\\'' \"bar\" '"
    assert quote(None) == u"''"
    assert quote(b'foo bar') == u"'foo bar'"
    assert quote(b'foo\'bar') == u"'foo'\\''bar'"
    assert quote(b'foo "bar"') == u"'foo \"bar\"'"

# Generated at 2022-06-23 10:06:22.884355
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict(
        [
            {'key': 'one', 'value': 1},
            {'key': 'two', 'value': 2},
            {'key': 'three', 'value': 3},
        ]
    ) == {'one': 1, 'two': 2, 'three': 3}



# Generated at 2022-06-23 10:06:26.677881
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("bar") == "bar"
    assert from_yaml("'bar'") == 'bar'
    assert from_yaml("true") == True
    assert from_yaml("false") == False
    assert from_yaml("{}") == {}
    assert from_yaml("") == ""



# Generated at 2022-06-23 10:06:31.303871
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    given = {'a': '1', 'b': 2, 3: 'd'}

    expected = [{'key': 'a', 'value': '1'}, {'key': 'b', 'value': 2}, {'key': 3, 'value': 'd'}]
    assert dict_to_list_of_dict_key_value_elements(given) == expected
    assert dict_to_list_of_dict_key_value_elements(given, 'k', 'v') == [{'k': 'a', 'v': '1'}, {'k': 'b', 'v': 2},
                                                                       {'k': 3, 'v': 'd'}]



# Generated at 2022-06-23 10:06:37.848139
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule().filters()) == dict

# Generated at 2022-06-23 10:06:48.413728
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('', encoding='utf-8') == '', "Empty string returns empty string"
    assert b64encode('Hello World', encoding='utf-8') == 'SGVsbG8gV29ybGQ', "Hello World returns base64 string"
    assert b64encode('Hello World', encoding='ascii') == 'SGVsbG8gV29ybGQ', "Hello World returns base64 string"
    try:
        b64encode('Hello World', encoding='notreallyanencoding')
        assert False, "Invalid encoding raises exception"
    except Exception as e:
        assert True, "Invalid encoding raises exception"

# Generated at 2022-06-23 10:06:55.556718
# Unit test for function rand
def test_rand():
    assert rand([1, 2], seed='test') == 1
    assert rand([1, 2], seed=1) == 1
    assert rand([1, 2], seed=2) == 2
    assert rand(2, seed=3) == 0
    assert rand(2, seed=4) == 1
    assert rand(1, 2, seed=5) == 1
    assert rand(1, 2, 3, seed=6) == 1



# Generated at 2022-06-23 10:07:06.503116
# Unit test for function to_bool
def test_to_bool():
    assert True == to_bool(True)
    assert False == to_bool(False)
    assert True == to_bool(1)
    assert False == to_bool(0)
    assert False == to_bool("0")
    assert True == to_bool("1")
    assert False == to_bool("False")
    assert True == to_bool("True")
    assert False == to_bool("false")
    assert True == to_bool("true")
    assert False == to_bool("FALSE")
    assert True == to_bool("TRUE")
    assert False == to_bool("foo")
    assert False == to_bool("")
    assert True == to_bool(" ")



# Generated at 2022-06-23 10:07:13.884934
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('*.py') == ['ansible/module_utils/common/utils.py',
                                'ansible/module_utils/common/text.py',
                                'ansible/module_utils/common/collections.py',
                                'ansible/module_utils/parsing/dataloader.py']
    assert fileglob('fileglob*') == ['ansible/module_utils/common/utils.py']



# Generated at 2022-06-23 10:07:21.531037
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.errors as errors
    fm = FilterModule()
    assert fm != None

    # b64encode
    assert fm.filters()['b64encode']("JAC") == "SkhD"
    # b64decode
    assert fm.filters()['b64decode']("SkhD") == "JAC"

    # uuid
    assert fm.filters()['to_uuid'](['a', 'b', 'c']) == "61-62-63"
    assert fm.filters()['to_uuid'](100) == "100"

    # json
    assert fm.filters()['to_json']({"a": 1}) == '{"a": 1}'

# Generated at 2022-06-23 10:07:25.528874
# Unit test for function to_json
def test_to_json():
    assert to_json(1) == '1'
    assert to_json(1.1) == '1.1'
    assert to_json(True) == 'true'



# Generated at 2022-06-23 10:07:35.920100
# Unit test for function comment
def test_comment():
    msg = "Hello World"

    # No param
    assert comment(msg) == "# Hello World"

    # C-style block comment, one newline and one decoration prefix
    assert comment(msg, 'cblock', newline='\r\n', decoration='// ', prefix_count=1, postfix_count=0) == "/*\r\n// Hello World\r\n*/"

    # Custom decoration with newline, two decoration postfixes
    assert comment(msg, decoration="### ", postfix_count=2) == "# ### Hello World### "

    # Custom prefix with newline, one decoration postfix
    assert comment(msg, prefix="### ", postfix_count=1) == "### Hello World# "

    # Custom postfix (without newline), one decoration prefix, end

# Generated at 2022-06-23 10:07:45.375867
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall("FOO bar BAR", regex='[fb]ar') == ['bar', 'bar']
    assert regex_findall("FOO bar BAR", regex='[fb]ar', ignorecase=True) == ['FOO', 'bar', 'BAR']
    assert regex_findall("FOO bar BAR", regex='[fb]ar', multiline=True) == ['FOO', 'bar', 'BAR']
    assert regex_findall("FOO bar BAR", regex='[fb]ar', ignorecase=True, multiline=True) == ['FOO', 'bar', 'BAR']


# Generated at 2022-06-23 10:07:58.059702
# Unit test for function rand
def test_rand():
    # We are testing the random filter with a fixed seed.
    seed = 1
    tests = (
        (5,),
        (5, 10,),
        (5, 0, -1,),
        (5, 0, 1,),
        (5, 1, 1,),
        (5, 1, 2,),
        (5, 0, 1, seed),
        (5, 1, 1, seed),
        (5, 1, 2, seed),
        (['a', 'b', 'c', 'd', 'e'],),
        (['a', 'b', 'c', 'd', 'e'], seed),
    )

# Generated at 2022-06-23 10:08:06.586120
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2017-06-01 01:00:00') == datetime.datetime(2017, 6, 1, 1, 0, 0)
    assert to_datetime('2017-06-01 01:00:00', '%Y-%m-%d %H:%M:%S') == datetime.datetime(2017, 6, 1, 1, 0, 0)
    assert to_datetime('2017-06-01', '%Y-%m-%d') == datetime.datetime(2017, 6, 1, 0, 0, 0)


# Generated at 2022-06-23 10:08:15.359452
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('string') == 'c3RyaW5n'
    assert b64encode(u'string') == 'c3RyaW5n'
    assert b64encode('string', 'us-ascii') == 'c3RyaW5n'
    assert b64encode('string', 'latin-1') == 'c3RyaW5n'
    assert b64encode('string', 'iso-8859-1') == 'c3RyaW5n'
    assert b64encode(u'\u00e9') == 'w6k='
    assert b64encode(u'\u00e9', 'us-ascii') == 'w6k='

# Generated at 2022-06-23 10:08:26.608145
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('{}') == {}
    assert from_yaml('[]') == []
    assert from_yaml('42') == 42
    assert from_yaml('42.0') == 42.0
    assert from_yaml('value') == 'value'
    assert from_yaml('true') == True
    assert from_yaml('false') == False
    assert from_yaml('null') == None
    assert from_yaml('a: 1') == {'a': 1}
    assert from_yaml('a: 1.0') == {'a': 1.0}
    assert from_yaml('a: [1, 2]') == {'a': [1, 2]}
    assert from_yaml('a: {b: c}') == {'a': {'b': 'c'}}

# Generated at 2022-06-23 10:08:37.136376
# Unit test for function path_join

# Generated at 2022-06-23 10:08:39.475615
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict(
        [{'key': 'a', 'value': 1}]) == {'a': 1}



# Generated at 2022-06-23 10:08:50.206390
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # Test with hashtype as blowfish and ident=2a
    blowfish_passwd = get_encrypted_password('mypassword', hashtype='blowfish', ident='2a')
    assert blowfish_passwd == '$2a$05$E9a0h1MV7mJOJkwP/Z7Jd.nW.2nPuSDz.cvI7XcB.sRt827NtjC2e'
    # Test with hashtype as sha256
    sha256_passwd = get_encrypted_password('mypassword', hashtype='sha256')

# Generated at 2022-06-23 10:08:58.659724
# Unit test for function comment
def test_comment():
    assert comment('foo bar', style='plain') == '# foo bar'
    assert comment('foo bar', style='c') == '// foo bar'
    assert comment('foo bar') == '# foo bar'
    assert comment('foo bar', style='xml') == '<!--\n - foo bar\n-->'
    assert comment('foo bar', style='xml', decoration='- ') == '<!--\n- foo bar\n-->'
    assert comment('foo\nbar', style='xml', decoration='- ') == '<!--\n- foo\n- bar\n-->'
    assert comment('foo\nbar', style='xml', decoration='- ', end='/') == '<!--\n- foo\n- bar\n/'
    assert comment('foo\nbar', newline='<NL>', decoration='- ')

# Generated at 2022-06-23 10:09:02.899286
# Unit test for function strftime
def test_strftime():
   assert strftime("%Y-%m-%dT%H:%M:%SZ", 1318781876.0) == "2011-10-07T12:17:56Z"


# Generated at 2022-06-23 10:09:05.094285
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1,2,3,4,5]) != [1,2,3,4,5]



# Generated at 2022-06-23 10:09:11.627254
# Unit test for function strftime
def test_strftime():
    '''
    Test strftime filter
    first test if it's able to get the current date/time,
    then test if it's able to get the date/time based on an epoch value
    '''
    assert strftime("%Y-%m-%d") == time.strftime("%Y-%m-%d")
    epoch = '1568342406'
    assert strftime("%Y-%m-%d", epoch) == time.strftime("%Y-%m-%d", time.localtime(float(epoch)))

# TODO: phase out date_diff to use date_timezone.diff instead

# Generated at 2022-06-23 10:09:19.607149
# Unit test for function regex_replace
def test_regex_replace():
    assert 'ABBCCCD' == regex_replace('abcdabcdabbcdabbbcdabbbbcd', r'ab+?cd', 'ABBCCCD', ignorecase=False, multiline=False)
    assert 'AbbcCcd' == regex_replace('abcdabcdabbcdabbbcdabbbbcd', r'ab+?cd', 'ABBCCCD', ignorecase=True, multiline=False)
    assert 'ABBCCCD' == regex_replace('abCdabcd\nabcd\nabbcd\nabbbcd\nabbbbcd', r'ab+?cd', 'ABBCCCD', ignorecase=False, multiline=True)



# Generated at 2022-06-23 10:09:32.185461
# Unit test for function rand
def test_rand():
    import math
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2 import DictRuntimeError
    from jinja2.environment import Environment
    env = Environment()
    env.filters['rand'] = rand
    # Test integer
    assert rand(env, 4) in (0, 1, 2, 3)
    assert rand(env, 10) in range(10)
    assert rand(env, 0) == 0
    assert rand(env, 1) == 0
    assert rand(env, 4, 2) in (2, 3)
    assert rand(env, 0, 10) == 0
    assert rand(env, 0, 10, 2) == 0
    assert rand(env, 100, step=10) in range(0, 100, 10)

# Generated at 2022-06-23 10:09:44.967046
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    orig_list = [{"this": "that"}, {"0": "1", "foo": "1"}]
    orig_dict = {"this": "that", "these": "those", "0": "1"}
    orig_str = "this is a string"
    orig_int = 4
    orig_none = None

    assert to_nice_yaml(orig_list) == to_yaml(orig_list)
    assert to_nice_yaml(orig_dict) == to_yaml(orig_dict)
    assert to_nice_yaml(orig_str) == to_yaml(orig_str)
    assert to_nice_yaml(orig_int) == to_yaml(orig_int)
    assert to_nice_yaml(orig_none) == to_yaml(orig_none)

    # test

# Generated at 2022-06-23 10:09:50.365964
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo: bar') == {'foo': 'bar'}
    assert from_yaml(u'foo: bar') == {u'foo': u'bar'}
    assert from_yaml(['foo', 'bar']) == ['foo', 'bar']



# Generated at 2022-06-23 10:09:57.356547
# Unit test for function to_json
def test_to_json():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    assert json.loads(to_json({'foo': 'bar'})) == {'foo': 'bar'}
    assert json.loads(to_json({'foo': 'bar'})) == {'foo': 'bar'}
    assert json.loads(to_json(['foo', 'bar'])) == ['foo', 'bar']
    assert json.loads(to_json(['foo', 'bar'])) == ['foo', 'bar']
    assert json.loads(to_json('foo')) == 'foo'
    assert json.loads(to_json('foo')) == 'foo'


test_to_json()
del test_to_json



# Generated at 2022-06-23 10:10:07.959958
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2014-01-01 00:00:00") == datetime.datetime(2014, 1, 1, 0, 0)
    assert to_datetime("2014-01-01 00:00:00", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2014, 1, 1, 0, 0)
    assert to_datetime("2014-01-01 00:00:00 UTC") == datetime.datetime(2014, 1, 1, 0, 0)
    assert to_datetime("2014-01-01 00:00:00 UTC", "%Y-%m-%d %H:%M:%S %Z") == datetime.datetime(2014, 1, 1, 0, 0)

# Generated at 2022-06-23 10:10:16.482035
# Unit test for function to_nice_json
def test_to_nice_json():
    test_data = [
        (
            [],
            "[\n    \n]"
        ),
        (
            {},
            "{\n    \n}"
        ),
        (
            "",
            "\"\""
        ),
        (
            "foo",
            "\"foo\""
        )
    ]
    for data, expected in test_data:
        assert to_nice_json(data) == expected



# Generated at 2022-06-23 10:10:18.832363
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all('[foo, bar, {baz: foo}]') == ['foo', 'bar', {u'baz': 'foo'}]



# Generated at 2022-06-23 10:10:29.026774
# Unit test for function path_join
def test_path_join():
    assert path_join(['foo', 'bar', 'baz']) == os.path.join('foo', 'bar', 'baz')
    assert path_join('foo/bar/baz') == os.path.join('foo/bar/baz')
    assert path_join([u'foo', u'bar', u'baz']) == os.path.join(u'foo', u'bar', u'baz')
    assert path_join(u'foo/bar/baz') == os.path.join(u'foo/bar/baz')
    assert path_join([u'ÄÄÄ', u'ßßß', u'ÖÖÖ']) == os.path.join(u'ÄÄÄ', u'ßßß', u'ÖÖÖ')
   

# Generated at 2022-06-23 10:10:32.108760
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}



# Generated at 2022-06-23 10:10:36.001994
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 'b', 'c': 'd'}) == [{'key': 'a', 'value': 'b'}, {'key': 'c', 'value': 'd'}]



# Generated at 2022-06-23 10:10:39.139248
# Unit test for function to_yaml
def test_to_yaml():
    print(to_yaml([1, 2, {'a': 'A', 'b': ['X', 'Y', 'Z'], 'c': {'deep1': {'deep2': {'deep3' : 'DEEP'}}}}, 4, 5]))


# Generated at 2022-06-23 10:10:49.816240
# Unit test for function comment
def test_comment():
    # Valid use cases
    assert "".join(
        comment(
            text="comment",
            style='plain')) == "# comment\n"
    assert "".join(
        comment(
            text="comment",
            style='erlang')) == "% comment\n"
    assert "".join(
        comment(
            text="comment",
            style='c')) == "// comment\n"
    assert "".join(
        comment(
            text="comment",
            style='cblock')) == "/*\n * comment\n */\n"
    assert "".join(
        comment(
            text="comment",
            style='xml')) == "<!--\n - comment\n-->\n"

    # Invalid use cases

# Generated at 2022-06-23 10:10:54.288497
# Unit test for function to_bool
def test_to_bool():
    e = {
        '0': False,
        '1': True,
        '0.0': False,
        '1.0': True,
        'false': False,
        'true': True,
        'No': False,
        'YES': True,
        'n': False,
        'y': True,
        'ok': True,
        'KO': False,
        '': False,
        'none': False,
        'None': False,
    }
    for v in e:
        a = to_bool(v)
        b = e.get(v)
        if a != b:
            print("to_bool(%s) returned %s instead of %s" % (v, a, b))
            sys.exit(1)



# Generated at 2022-06-23 10:11:07.606138
# Unit test for function regex_search
def test_regex_search():
    # Test if the function works with a backreference
    a = '"hello world"'
    b = '"-f \\"hello world\\""'
    result = regex_search(a, r'"(.*)"', '\\g<1>')
    assert b == result
    # Test if the function works with several backreferences
    a = '"hello world"'
    b = '"-f \\"hello world\\""'
    result = regex_search(a, r'"(.*)"', '\\g<1>')
    assert b == result
    # Test if the function works with a backreference and a group
    a = '"hello world"'
    b = '"-f \\"hello world\\""'
    result = regex_search(a, r'"(.*)"', '\\g<1>')
    assert b == result
    # Test

# Generated at 2022-06-23 10:11:19.459921
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    dict1 = dict(a=1, b=2, c=3)
    dict2 = dict_to_list_of_dict_key_value_elements(dict1)
    dict3 = dict_to_list_of_dict_key_value_elements(dict1, key_name='foo', value_name='bar')
    assert(len(dict3) == 3)
    assert(dict3[0]['foo'] == 'a' and dict3[0]['bar'] == 1)
    assert(dict3[1]['foo'] == 'b' and dict3[1]['bar'] == 2)
    assert(dict3[2]['foo'] == 'c' and dict3[2]['bar'] == 3)

# Generated at 2022-06-23 10:11:30.029392
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    test_dict = {'key1': 'value1', 'key2': ['value2', 'value2_1'], 'key3': {'value3', 'value3_1'}}
    result = dict_to_list_of_dict_key_value_elements(test_dict, 'key', 'value')
    assert result == [{'key': 'key1', 'value': 'value1'},
                      {'key': 'key2', 'value': ['value2', 'value2_1']},
                      {'key': 'key3', 'value': {'value3', 'value3_1'}}]


# Generated at 2022-06-23 10:11:31.077898
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(object()) == object()



# Generated at 2022-06-23 10:11:35.746844
# Unit test for function extract
def test_extract():
    from ansible.vars.unsafe_proxy import make_unsafe_proxy
    env = Environment()
    assert "bar" == extract(env, "foo", make_unsafe_proxy({"foo": "bar"}))
    assert "bar" == extract(env, "foo", make_unsafe_proxy({u"foo": "bar"}))
    assert "bar" == extract(env, "foo", make_unsafe_proxy({"foo": "bar", "bar": "foo"}))
    assert "bar" == extract(env, "foo", {"foo": "bar"})
    assert "bar" == extract(env, "foo", {"foo": "bar", "bar": "foo"})
    assert "bar" == extract(env, "baz", {"foo": {"bar": "baz"}}, "foo")
    assert "bar"

# Generated at 2022-06-23 10:11:51.021981
# Unit test for function ternary
def test_ternary():
    assert ternary('a', 'b', 'c') == 'b'
    assert ternary(None, 'b', 'c') == 'c'
    assert ternary(None, 'b', 'c', none_val='d') == 'd'
    assert ternary(0, 'b', 'c') == 'c'
    assert ternary(True, 'b', 'c') == 'b'
    assert ternary(False, 'b', 'c') == 'c'
    assert ternary('', 'b', 'c') == 'c'
    assert ternary([], 'b', 'c') == 'b'
    assert ternary([0], 'b', 'c') == 'b'



# Generated at 2022-06-23 10:11:57.134124
# Unit test for function quote
def test_quote():
    """ test_quote
    test quote function
    """
    assert quote(u'"abc') == u"'" + u'\\"' + u'abc\''
    assert quote(u'abc"') == u'"' + u'abc\\"' + u'"'
    assert quote(u'<abc>') == u'"' + u'<abc>' + u'"'



# Generated at 2022-06-23 10:12:03.624275
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('$1', 'python') == '\\$1'
    assert regex_escape('$1', 'posix_basic') == '\\$1'
    try:
        regex_escape('$1', 'posix_extended')
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-23 10:12:14.000962
# Unit test for function rand
def test_rand():
    assert rand(end=10) in range(10)
    assert rand(end=10, seed=1) in range(10)
    assert rand(end=10, seed='FOOBAR') in range(10)
    assert rand(end=[1, 2, 3]) in [1, 2, 3]
    assert rand(end=10, start=5) in range(5, 10)
    assert rand(end=10, step=2) in [0, 2, 4, 6, 8]
    assert rand(end=10, start=5, step=2) in [5, 7, 9]
    try:
        rand(end=10, start=5, step=0)
        assert False, 'rand should have raised exception'
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:12:19.693396
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('hello world', 'hello (\w+)', 'bye \\1') == 'bye world'
    assert regex_replace('hello world', '(\w+) (\w+)', '\\2 \\1') == 'world hello'



# Generated at 2022-06-23 10:12:25.323822
# Unit test for function path_join
def test_path_join():
    '''
    >>> path_join(['/', 'etc', 'services'])
    '/etc/services'

    >>> path_join('/etc/services')
    '/etc/services'

    >>> path_join(1)
    Traceback (most recent call last):
        ...
    AnsibleFilterTypeError: |path_join expects string or sequence, got <type 'int'> instead.
    '''
    # Unit test will only test the Parser
    pass



# Generated at 2022-06-23 10:12:37.397291
# Unit test for function flatten
def test_flatten():
    mylist = [3, 4, [5, 6, 7], [8, 9, [10, 11, 12]]]
    result = [3, 4, 5, 6, 7, 8, 9, [10, 11, 12]]
    assert flatten(mylist, levels=1) == result

    result = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    assert flatten(mylist, levels=2) == result

    result = [3, 4, 5, 6, 7, 8, 9, [10, 11, 12]]
    assert flatten(mylist, levels=3) == result

    result = [3, 4, 5, 6, 7, 8, 9, [10, 11, 12]]
    assert flatten(mylist) == result


# Generated at 2022-06-23 10:12:48.220428
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test if md5 filter works correctly
    assert md5s("some string") == '2f8e3c9b2ac09dff7c982966bc07f891'
    assert md5s(b"some string") == '2f8e3c9b2ac09dff7c982966bc07f891'
    assert md5s(u"some string") == '2f8e3c9b2ac09dff7c982966bc07f891'
    # Test if checksum filter works correctly
    assert checksum_s("some string") == 'b6113e0ce35ef57d87b04b8d4eb4e80f22a041c4'

# Generated at 2022-06-23 10:12:56.331099
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("Hello") == 'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert get_hash("Hello", "md5") == '5d41402abc4b2a76b9719d911017c592'
    assert get_hash("Hello", "sha256") == '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'

# Generated at 2022-06-23 10:13:06.455188
# Unit test for function to_bool
def test_to_bool():
    ''' test_to_bool() function unit test'''
    # Test cases
    test_cases = [
        (None, None),
        (False, False),
        (True, True),
        ('Yes', True),
        ('yes', True),
        ('YES', True),
        ('on', True),
        ('ON', True),
        ('On', True),
        ('OFF', False),
        ('off', False),
        ('1', True),
        ('True', True),
        ('0', False),
        ('False', False),
        (0, False),
        (1, True),
        ('', False),
        ('random string', False),
        (1.5, False),
        (-1, False),
        (1.0, True),
        (0.0, False)
    ]


# Generated at 2022-06-23 10:13:13.360254
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4]
    seed = 42
    assert randomize_list(mylist, seed) == [2, 1, 4, 3]
    assert randomize_list(mylist) != mylist
    assert randomize_list(mylist) == mylist
    assert randomize_list(mylist, seed) != [1, 2, 3, 4]



# Generated at 2022-06-23 10:13:22.302167
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type

    assert from_yaml(1) == 1
    assert from_yaml('1') == 1
    assert from_yaml('[1, 2, 3]') == [1, 2, 3]
    assert from_yaml('{"key": "value"}') == {u'key': u'value'}
    assert isinstance(from_yaml('{"key": "value"}'), Mapping)
    assert isinstance(from_yaml('key: value'), Mapping)
    assert isinstance(from_yaml('key: value')[u'key'], text_type)
    assert isinstance(from_yaml('key: "value"'), Mapping)

# Generated at 2022-06-23 10:13:34.664951
# Unit test for function rand
def test_rand():
    environment = None
    end = 10
    start = 1
    step = 2
    seed = None
    n = rand(environment, end, start, step, seed)
    assert n >= 1 and n < 10 and n % 2 == 1
    seed = 1
    n = rand(environment, end, start, step, seed)
    assert n >= 1 and n < 10 and n % 2 == 1
    assert n == rand(environment, end, start, step, seed)
    end = [1, 2, 3]
    n = rand(environment, end, start, step, seed)
    assert n in end
    seed = 1
    n = rand(environment, end, start, step, seed)
    assert n in end
    assert n == rand(environment, end, start, step, seed)

# Generated at 2022-06-23 10:13:46.789808
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('aGVsbG8gd29ybGQK') == 'hello world\n'
    assert b64decode('aHR0cHM6Cg==') == 'https:\n'
    assert b64decode('') == ''
    assert b64decode(u'aGVsbG8gd29ybGQK') == 'hello world\n'
    assert b64decode(u'aHR0cHM6Cg==') == 'https:\n'
    assert b64decode(u'') == ''
    assert b64decode('YQ==') == 'a'
    assert b64decode(u'YQ==') == 'a'
    assert b64decode(u'YQ==') == 'a'

# Generated at 2022-06-23 10:13:53.720280
# Unit test for function fileglob
def test_fileglob():
    # use a temp dir that does not end with a / to test the matching of
    # basename
    path = os.environ['HOME']
    if path.endswith('/'):
        path = os.environ['HOME'] = os.environ['HOME'][:-1]
    assert fileglob(path + '/.*') == fileglob(os.environ['HOME'] + '/.*')

# -----------------------------------------------------------------------------
# GENERATORS



# Generated at 2022-06-23 10:14:06.278199
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo') == 'foo'
    assert regex_escape(r'foo$bar') == 'foo\\$bar'
    assert regex_escape(r'foo$bar', re_type='posix_basic') == 'foo\\$bar'
    assert regex_escape(r'foo?bar') == 'foo\\?bar'
    assert regex_escape(r'foo?bar', re_type='posix_basic') == 'foo?bar'
    assert regex_escape(r'foo+bar') == 'foo\\+bar'
    assert regex_escape(r'foo+bar', re_type='posix_basic') == 'foo\\+bar'
    assert regex_escape(r'foo.bar') == 'foo\\.bar'

# Generated at 2022-06-23 10:14:08.000857
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all("--- []\n--- {}\n--- 1") == [[], {}, 1]



# Generated at 2022-06-23 10:14:11.170918
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)


# Generated at 2022-06-23 10:14:21.070930
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(mylist=[], seed=1) == []
    assert randomize_list(mylist="", seed=1) == ""
    assert randomize_list(mylist=["a"], seed=1) == ["a"]
    assert randomize_list(mylist=["a", "b"], seed=1) == ["a", "b"]
    assert randomize_list(mylist=["a", "b", "c"], seed=1) == ["a", "c", "b"]
    assert randomize_list(mylist=["a", "b", "c", "d"], seed=1) == ["c", "a", "b", "d"]



# Generated at 2022-06-23 10:14:25.024963
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({"one": 1, "two": 2, "three": 3}) == [
        {'key': 'one', 'value': 1},
        {'key': 'two', 'value': 2},
        {'key': 'three', 'value': 3}
    ]



# Generated at 2022-06-23 10:14:39.485545
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3}) == {'a': 1, 'b': 3}
    assert combine({'a': 1, 'b': 2}, {'c': 1}) == {'a': 1, 'b': 2, 'c': 1}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 1}) == {'a': 1, 'b': 3, 'c': 1}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 1}, {'b': 2, 'd': 3}) == {'a': 1, 'b': 2, 'c': 1, 'd': 3}

# Generated at 2022-06-23 10:14:51.577492
# Unit test for function extract
def test_extract():
    assert extract("mykey", {"mykey": 1}) == 1
    assert extract("mykey", {"mykey": 1}, None) == 1
    assert extract("mykey", {"mykey": 1}, []) == 1
    assert extract("mykey", {"mykey": 1}, {"otherkey": 2}) == 1
    assert extract("mykey", {"mykey": 1}, {"otherkey": 2}, morekeys=None) == 1
    assert extract("mykey", {"mykey": 1}, {"mykey": 2}, morekeys=None) == 1
    assert extract("mykey", {"mykey": 1}, {"mykey": 2}, []) == 1
    assert extract("mykey", {"mykey": 1}, {"mykey": 2}, [], morekeys=None) == 1

# Generated at 2022-06-23 10:14:59.173072
# Unit test for function rand
def test_rand():
    # Non-integers
    assert rand([1, 2, 3], seed=1) == 1
    # 0, 1, 2
    assert rand(3, seed=2) in [0, 1, 2]
    # 1, 2, 3
    assert rand(1, 3, seed=3) in [1, 2, 3]
    # 1, 4
    assert rand(1, 5, 3, seed=4) in [1, 4]
    # 1, 3, 5
    assert rand(1, 6, 2, seed=5) in [1, 3, 5]



# Generated at 2022-06-23 10:15:08.397108
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u"{ foo: bar }") == {u"foo": u"bar"}
    assert from_yaml(u"{ foo: 'bar' }") == {u"foo": u"bar"}
    assert from_yaml(u"{ foo: 1 }") == {u"foo": 1}
    assert from_yaml(u"{ foo: null }") == {u"foo": None}
    assert from_yaml(u"{ foo: True }") == {u"foo": True}
    assert from_yaml(u"{ foo: False }") == {u"foo": False}
    assert from_yaml(u"{ foo: -1 }") == {u"foo": -1}

# Generated at 2022-06-23 10:15:15.304329
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment

    # Generate a groupby array
    groupby_list = [
        {'id': 1, 'first': 'John', 'last': 'Doe', 'age': 30},
        {'id': 2, 'first': 'Jane', 'last': 'Doe', 'age': 25},
        {'id': 3, 'first': 'Joe', 'last': 'Dirt', 'age': 25},
        {'id': 4, 'first': 'Joe', 'last': 'Shmoe', 'age': 30},
        {'id': 5, 'first': 'Jane', 'last': 'Doe', 'age': 30},
        {'id': 6, 'first': 'John', 'last': 'Smith', 'age': 25}
    ]

    # Create an environment
    env = Environment()

    #

# Generated at 2022-06-23 10:15:23.946751
# Unit test for function flatten
def test_flatten():
    def assert_flatten(testinput, expected, levels=None, skip_nulls=True):
        result = flatten(testinput, levels, skip_nulls)
        assert result == expected, "flatten: %r != %r" % (result, expected)

    assert_flatten([], [])
    assert_flatten([1, 2, 3], [1, 2, 3])
    assert_flatten([1, 2, [3, 4]], [1, 2, 3, 4])
    assert_flatten([[1, 2], [3, 4]], [1, 2, 3, 4])
    assert_flatten([[[1, 2], [3, 4]], 5, 6], [1, 2, 3, 4, 5, 6])
