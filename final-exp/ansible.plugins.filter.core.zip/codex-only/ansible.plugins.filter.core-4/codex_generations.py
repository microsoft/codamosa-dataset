

# Generated at 2022-06-23 10:05:37.381848
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()

    assert isinstance(filters, dict)

    assert 'to_yaml' in filters
    assert filters['to_yaml'] == to_yaml

    assert 'from_yaml' in filters
    assert filters['from_yaml'] == from_yaml

    assert 'from_yaml_all' in filters
    assert filters['from_yaml_all'] == from_yaml_all

    assert 'to_json' in filters
    assert filters['to_json'] == to_json

    assert 'from_json' in filters
    assert filters['from_json'] == json.loads

    assert 'to_nice_yaml' in filters
    assert filters['to_nice_yaml'] == to_nice_yaml


# Generated at 2022-06-23 10:05:42.029533
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar[baz]') == 'foo\\.bar\\[baz\\]'
    assert regex_escape('foo.bar[baz]', re_type='posix_basic') == 'foo\\.bar\\[baz\\]'



# Generated at 2022-06-23 10:05:53.990187
# Unit test for function mandatory
def test_mandatory():
    env = {'string': 'foo', 'foo': {'bar': 'baz'}, 'undefined': AnsibleUndefined}
    env_missing = {'string': 'foo', 'foo': {'bar': 'baz'}, 'undefined': AnsibleUndefined}
    assert mandatory('foo', env) == 'foo'
    try:
        mandatory('undefined', env)
        assert False, 'exception not raised'
    except AnsibleFilterError:
        pass
    try:
        mandatory('undefined', env_missing)
        assert False, 'exception not raised'
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'undefined' not defined."

# Generated at 2022-06-23 10:06:00.949818
# Unit test for function combine
def test_combine():
    dictionary1 = {"key1": 1, "key2": 2, "key3": 3}
    dictionary2 = {"key4": 4, "key5": 5, "key6": 6}
    result = combine(dictionary2, dictionary1)
    keys = result.keys()
    assert "key1" in keys
    assert "key2" in keys
    assert "key3" in keys
    assert "key4" in keys
    assert "key5" in keys
    assert "key6" in keys



# Generated at 2022-06-23 10:06:07.373390
# Unit test for function b64decode
def test_b64decode():
    # Test a string
    assert b64decode(b64encode('a')) == 'a'
    # Test a utf-8 string and non-default encoding
    assert b64decode(b64encode('\u041a\u0430\u043a \u0436\u0438\u0432\u0435\u0442', encoding='utf-8'), encoding='utf-8') == '\u041a\u0430\u043a \u0436\u0438\u0432\u0435\u0442'
    # Test a unicode string

# Generated at 2022-06-23 10:06:16.893083
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory('foo') == 'foo'
    assert mandatory(['foo']) == ['foo']
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory()
        pytest.fail('should not get here')
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_native(e)

    try:
        mandatory(foo)
        pytest.fail('should not get here')
    except NameError:
        pass

    try:
        mandatory(msg='foo')
        pytest.fail('should not get here')
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'


# Generated at 2022-06-23 10:06:23.513421
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    yaml_content = to_nice_yaml({"a": 1, "b": {"a": 2, "b": 3}})
    assert yaml_content == textwrap.dedent(
        """\
        a: 1
        b:
          a: 2
          b: 3
        """)


# Generated at 2022-06-23 10:06:27.896082
# Unit test for function b64decode
def test_b64decode():
    import base64
    assert b64decode(b64decode(u'YW55IGNhcm5hbCBwbGVhcw==')) == u'any carnal pleas'



# Generated at 2022-06-23 10:06:35.992281
# Unit test for function ternary
def test_ternary():
    assert not ternary(0, ['a', 'b'], ['c', 'd'])
    assert not ternary(0, {'a': 'b'}, ['c', 'd'])
    assert ternary(1, ['a', 'b'], ['c', 'd']) == ['a', 'b']
    assert ternary(1, {'a': 'b'}, ['c', 'd']) == {'a': 'b'}
    assert not ternary(0, 1, 2) == 1
    assert ternary(1, 1, 2) == 1
    assert ternary(0, 1, 2) == 2
    assert ternary(1, True, False) is True
    assert ternary(False, True, False) is False

# Generated at 2022-06-23 10:06:41.163834
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}, {"name": "bob", "groups": ["nonadmin"], "authorized": ["/tmp/bob/onekey.pub"]}]

# Generated at 2022-06-23 10:06:49.615850
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(u'hello') == u'hello'
    assert from_yaml(b'hello') == u'hello'
    assert from_yaml(u'\x80') == u'\ufffd'
    assert from_yaml(b'\x80') == u'\ufffd'

    class EvilString(str):
        def __mod__(self, args):
            raise Exception()
    evil = EvilString('<%s>')
    assert from_yaml(evil) == evil
    assert from_yaml(evil.encode()) == u'<%s>'

    class NotUnicode(str):
        def __add__(self, other):
            return NotUnicode(super(NotUnicode, self).__add__(other))


# Generated at 2022-06-23 10:06:54.644534
# Unit test for function to_nice_json
def test_to_nice_json():
    assert """{
    "foo": "bar",
    "baz": {
        "baa": "bee"
    }
}""" == to_nice_json({'baz': {'baa': 'bee'}, 'foo': 'bar'})



# Generated at 2022-06-23 10:07:02.584455
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert get_hash('foobar', 'sha256') == 'c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2'
    assert get_hash('foobar', 'unknown') == ''



# Generated at 2022-06-23 10:07:12.122190
# Unit test for function regex_replace
def test_regex_replace():
    # Replace all '-' with ';;;' in the given string and return the result
    result = regex_replace(
        value="ansible-1.9.1-1.el7.noarch.rpm",
        pattern="-",
        replacement=";;;"
    )
    assert result == 'ansible;;;1.9.1;;;1.el7.noarch.rpm'
    # Replace all '-' with ';;;' in the given string and return the result;
    # the given value and replacement are both unicode
    result = regex_replace(
        value=u"ansible-1.9.1-1.el7.noarch.rpm",
        pattern=u"-",
        replacement=u";;;"
    )

# Generated at 2022-06-23 10:07:15.060246
# Unit test for function comment
def test_comment():
    r = comment(
        "Comment text.",
        style='cblock',
        newline='\n',
        prefix='<!--',
        prefix_count=2,
        decoration='//',
        postfix='//',
        postfix_count=3,
        end='-->')
    assert r == (
        "<!--\n"
        "//\n"
        "//\n"
        "// Comment text.\n"
        "//\n"
        "//\n"
        "//-->")



# Generated at 2022-06-23 10:07:28.628087
# Unit test for function flatten
def test_flatten():
    assert flatten([1, [2, 3], [4, 5, [6, 7]], 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten([1, [2, 3], [4, 5, [6, 7]], 8, 9], levels=1) == [1, 2, 3, 4, 5, [6, 7], 8, 9]
    assert flatten([1, [2, 3], [4, 5, [6, 7]], 8, 9], levels=2) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 10:07:36.533993
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.errors import AnsibleFilterTypeError, AnsibleFilterError
    from ansible.template import JinjaEnvironment, AnsibleEnvironment
    from ansible.module_utils.six import PY3, string_types
    env = JinjaEnvironment()
    ans_env = AnsibleEnvironment(loader=DictLoader(dict()))
    fm = FilterModule()
    fm_filters = fm.filters()
    mylist = []

# Generated at 2022-06-23 10:07:45.118292
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(None)
        raise Exception("Should have raised an exception")
    except AnsibleFilterError:
        pass

    try:
        mandatory(None, "Test error message")
        raise Exception("Should have raised an exception")
    except AnsibleFilterError as e:
        assert "Test error message" == str(e)

    try:
        mandatory(AnsibleUndefined("foo"))
        raise Exception("Should have raised an exception")
    except AnsibleFilterError as e:
        assert "'foo' " in str(e)


# Generated at 2022-06-23 10:07:51.322651
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    v = dict(a='abc', b='bce', c=dict(x='x', y='y', z='z'))
    result = to_nice_yaml(v, indent=0)
    expected = """a: abc
b: bce
c:
    x: x
    y: y
    z: z
"""
    assert result == expected



# Generated at 2022-06-23 10:08:02.680227
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('?num=5&colour=red') == '\\?num=5\\&colour=red'
    assert regex_escape('abc$def') == 'abc\\$def'
    assert regex_escape('abc[def') == 'abc\\[def'
    assert regex_escape('abc.def') == 'abc\\.def'
    assert regex_escape('abc\\def') == 'abc\\\\def'
    assert regex_escape('abc^def') == 'abc\\^def'
    assert regex_escape(r'abc*def') == 'abc\\*def'
    assert regex_escape('abc(def') == 'abc\\(def'
    assert regex_escape('abc)def') == 'abc\\)def'
    assert regex_escape('abc|def') == 'abc\\|def'

# Generated at 2022-06-23 10:08:11.597025
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    result = dict_to_list_of_dict_key_value_elements(data)

    assert len(result) == 4
    assert result[0] == {'key': 'key1', 'value': 'value1'}
    assert result[1] == {'key': 'key2', 'value': 'value2'}
    assert result[2] == {'key': 'key3', 'value': 'value3'}
    assert result[3] == {'key': 'key4', 'value': 'value4'}


# Generated at 2022-06-23 10:08:13.046749
# Unit test for function b64decode
def test_b64decode():
    res = b64decode("dGVzdA==")
    assert res == "test"
    res = b64decode("dGVzdA==", encoding='ascii')
    assert res == "test"



# Generated at 2022-06-23 10:08:19.208184
# Unit test for function to_datetime
def test_to_datetime():
    dtstr = "2013-12-06 09:12:24"
    assert to_datetime("bad input") is None
    assert to_datetime("bad input", "%Y-%m-%d %H:%M:%S") is None
    assert to_datetime(dtstr) == datetime.datetime(2013, 12, 6, 9, 12, 24)
    assert to_datetime(dtstr, "%Y-%m-%d %H:%M:%S") == datetime.datetime(2013, 12, 6, 9, 12, 24)
    assert to_datetime(dtstr, "%Yx%m-%d %H:%M:%S") is None
    assert to_datetime(dtstr[:10]) == datetime.datetime(2013, 12, 6, 0, 0)


# Generated at 2022-06-23 10:08:20.484899
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()

# Generated at 2022-06-23 10:08:28.291461
# Unit test for function quote
def test_quote():
    assert quote("''") == u"''\\'''"
    assert quote("'") == u"''\\'''"
    assert quote("foo") == u"foo"
    assert quote("foo bar") == u"foo\\ bar"
    assert quote("foo'bar") == u"foo'bar"
    assert quote("foo bar's") == u"foo\\ bar'\\''s"
    assert quote("foo bar's'") == u"foo\\ bar'\\''s'\\'''"



# Generated at 2022-06-23 10:08:31.438529
# Unit test for function ternary
def test_ternary():
    assert ternary(None, 1, 2, 3) == 3
    assert ternary('', 1, 2) == 2
    assert ternary('XYZ', 1, 2) == 1



# Generated at 2022-06-23 10:08:33.929173
# Unit test for function get_hash
def test_get_hash():
  assert get_hash("hello") == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'


# Generated at 2022-06-23 10:08:42.750854
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'hi') == r'hi'
    assert regex_escape(r'hi.*') == r'hi\.*'
    assert regex_escape(r'hi.^') == r'hi\.\^'
    assert regex_escape(r'hi.[$*\\') == r'hi\.\[\$\*\\\\'
    assert regex_escape(r'hi..', re_type='posix_basic') == r'hi\.\.'
    assert regex_escape(r'hi.^', re_type='posix_basic') == r'hi\.\^'
    assert regex_escape(r'hi.^(.*)\\', re_type='posix_basic') == r'hi\.\^\(\.\*\)\\\\'

# Generated at 2022-06-23 10:08:45.101072
# Unit test for function extract
def test_extract():
    input = {
        'aaa': {'bbb': {'ccc': 1}},
        'ddd': 2
    }
    output1 = 1
    output2 = 2
    assert extract('ccc', input) == output1
    assert extract('ccc', input, ['bbb','aaa']) == output1
    assert extract('ddd', input) == output2


# Generated at 2022-06-23 10:08:53.609950
# Unit test for function to_nice_json
def test_to_nice_json():
    # TODO: move this test to unit/utils/test_template.py
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert to_nice_json({}) == '{}'

    if PY3:
        assert to_nice_json(False) == 'false'
        assert to_nice_json(True) == 'true'
    else:
        assert to_nice_json(False) == 'false'
        assert to_nice_json(True) == 'true'

# Generated at 2022-06-23 10:09:02.561614
# Unit test for function quote
def test_quote():
    assert quote(None) == u""
    assert quote("") == u""
    assert quote("String") == u"'String'"
    assert quote("String with spaces") == u"'String with spaces'"
    assert quote("String with single ' quote") == u"'String with single '\\'' quote'"
    assert quote("String with double \" quote") == u"'String with double \\\" quote'"
    assert quote("String with $dollar") == u"'String with $dollar'"
    assert quote("String with single ' quote and spaces") == u"'String with single '\\'' quote and spaces'"
    assert quote("String with $dollar and spaces") == u"'String with $dollar and spaces'"
    assert quote("String with double \" quote and spaces") == u"'String with double \\\" quote and spaces'"
    assert quote("String with single ' quote and double \" quote") == u

# Generated at 2022-06-23 10:09:08.607832
# Unit test for function fileglob
def test_fileglob():
    pathname = "./fileglob.txt"
    if not os.path.exists(pathname):
        f = open(pathname, "w")
        f.write("fileglob.txt")
        f.close()
    else:
        raise AnsibleFilterError('Test file glob error')
    res = fileglob(pathname)
    os.remove(pathname)
    if res == [pathname] and len(res) == 1:
        return True
    else:
        return False



# Generated at 2022-06-23 10:09:16.859838
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():

    mylist = [
        {'key': 'key_1', 'value': 'value_1'},
        {'key': 'key_2', 'value': 'value_2'},
    ]
    key_name = 'key'
    value_name = 'value'
    result = list_of_dict_key_value_elements_to_dict(mylist=mylist, key_name=key_name, value_name=value_name)
    assert result == {'key_1': 'value_1', 'key_2': 'value_2'}
test_list_of_dict_key_value_elements_to_dict()



# Generated at 2022-06-23 10:09:25.481021
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    yaml_str = to_nice_yaml({"key1": "value1",
                             "key2": {"subkey1": "subvalue1",
                                      "subkey2": "subvalue2"
                             }
                            })
    print(yaml_str)
    assert yaml_str == '''key1: value1
key2:
    subkey1: subvalue1
    subkey2: subvalue2
'''
# test
#test_to_nice_yaml()


# Generated at 2022-06-23 10:09:27.858931
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-23 10:09:30.178550
# Unit test for function fileglob
def test_fileglob():
    files = fileglob("/usr/bin/*sh")
    assert(isinstance(files, list))
    assert("/usr/bin/bash" in files)



# Generated at 2022-06-23 10:09:35.887389
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("test data", "sha1") == "f27b5184b9f28dafb8e5ed5a5da43d7fc2b23e5f"
    try:
        get_hash("test data", "nonexistent-hash")
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

# avoid shadowing builtin "filter"

# Generated at 2022-06-23 10:09:42.774159
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5], 12345) == [2, 3, 1, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list(range(10), 12345) == [6, 5, 9, 2, 8, 3, 7, 4, 0, 1]



# Generated at 2022-06-23 10:09:53.139052
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}]
    mydict = list_of_dict_key_value_elements_to_dict(mylist, key_name='key', value_name='value')
    expected = {'a': 1, 'b': 2, 'c': 3}
    if mydict != expected:
        raise AssertionError("function list_of_dict_key_value_elements_to_dict did not work as expected: expected %s, got %s" % (expected, mydict))



# Generated at 2022-06-23 10:10:00.334900
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import json
    import os
    import os.path
    import random
    import string
    import textwrap

    import pytest

    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.module_utils.six import string_types, text_type
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import to_unsafe_text


    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # use a new (random) vault secret and password for each test,
    # so that vault encrypted strings don't collide between tests

# Generated at 2022-06-23 10:10:02.668876
# Unit test for function comment
def test_comment():
    import inspect
    # Retrieve comment and docstring
    docstring = inspect.getdoc(comment)
    # Return substrings from the docstring
    return docstring.split('Returns:')[1].split('\n')[1].strip(' ')



# Generated at 2022-06-23 10:10:12.726866
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 42}}) == {'b': 42}
    assert extract('a', {'a': {'b': 42}}, []) == {'b': 42}
    assert extract('a', {'a': {'b': 42}}, 'b') == 42
    assert extract('a', {'a': {'b': 42}}, ['b']) == 42
    assert extract('a', {'a': {'b': [{'c': 1}, {'c': 2}]}}, 'b', 'c') == [1, 2]
    assert extract('a', {'a': {'b': [{'c': 1}, {'c': 2}]}}, ['b'], ['c']) == [1, 2]



# Generated at 2022-06-23 10:10:16.254080
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/*/*') != []
    assert glob.glob('/etc/*/*') != []
    assert fileglob('/etc/shadow') == []



# Generated at 2022-06-23 10:10:23.623381
# Unit test for function flatten
def test_flatten():

    # Test with a simple list
    list1 = ['foo', 'bar', 'baz', 'qux']
    result = flatten(list1)
    expected = list1
    assert result == expected

    # Test with a simple dict
    dict1 = dict(foo='bar', bar='baz', baz='qux')
    result = flatten(dict1)
    assert isinstance(result, list)

    # Test with a simple dict
    dict1 = dict(foo=1, bar=2, baz=3)
    result = flatten(dict1)
    assert isinstance(result, list)

    # Test with a simple dict
    dict1 = dict(foo=None, bar=2, baz=3)
    result = flatten(dict1)
    assert isinstance(result, list)

    # Test with

# Generated at 2022-06-23 10:10:30.475175
# Unit test for function regex_escape
def test_regex_escape():
    test_string_py = r'.*[\^$.|?*+()'
    test_string_posix_basic = r'.*[\^$.|?*+('
    assert regex_escape(test_string_py, 'python') == test_string_py
    assert regex_escape(test_string_posix_basic, 'posix_basic') == r'.\*\[\\\^\$\.\|\?\*\+\('


# Generated at 2022-06-23 10:10:33.020309
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_ = FilterModule.filters.__func__(FilterModule())

    assert isinstance(filters_, dict)

# Generated at 2022-06-23 10:10:38.767291
# Unit test for function from_yaml_all
def test_from_yaml_all():
    from io import StringIO
    test = '\n'.join([
        '- foo',
        '- bar',
        '- baz',
        '- bat'
    ])
    assert list(from_yaml_all(test)) == ['foo', 'bar', 'baz', 'bat']
    yamlfile = StringIO(test)
    assert list(from_yaml_all(yamlfile)) == ['foo', 'bar', 'baz', 'bat']



# Generated at 2022-06-23 10:10:49.778785
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([[1], [2, 3]]) == [1, 2, 3]
    assert flatten([[[1]], [2, 3]]) == [[1], 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, [3]]
    assert flatten([1, [2, [3]], [[4]]]) == [1, 2, [3], [4]]
    assert flatten([1, [[2], [3]], [4]]) == [1, [2], [3], 4]

# Generated at 2022-06-23 10:10:59.004717
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'x', 'y') == 'x'
    assert ternary(True, 'x', 'y') == 'x'
    assert ternary('X', 'x', 'y') == 'x'
    assert ternary(False, 'x', 'y') == 'y'
    assert ternary(0, 'x', 'y') == 'y'
    assert ternary(None, 'x', 'y') == 'y'
    assert ternary(0, 'x', 'y', 'z') == 'z'
    return True
test_ternary.anytest = True



# Generated at 2022-06-23 10:11:02.923443
# Unit test for function to_yaml
def test_to_yaml():
    '''Unit test for function to_yaml'''
    assert '{ hello: world }\n' == to_yaml([{ 'hello': 'world' }] )
    assert '73\n' == to_yaml(73)

# Generated at 2022-06-23 10:11:05.354443
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo: bar") == dict(foo="bar")
    data = from_yaml("""
    foo: bar
    baz:
        - 1
        - 2
        - 3
    """)
    assert data == dict(
        foo="bar",
        baz=[
            1,
            2,
            3,
        ],
    )



# Generated at 2022-06-23 10:11:09.113881
# Unit test for function to_nice_json
def test_to_nice_json():
    """ Unit tests for function "to_nice_json"
        (1) Function to_nice_json should ensure that a number is converted to a string
    """
    def do(a):
        return to_nice_json(a)
    assert do({1: 2}) == '{\n    "1": 2\n}'



# Generated at 2022-06-23 10:11:21.106753
# Unit test for function extract
def test_extract():
    env = DummyEnvironment()

    # Check if we can extract an item from a dict
    container = dict(item1=dict(item2=dict(item3='value')))
    assert extract(env, 'item1.item2.item3', container) == 'value'

    # Check if we can extract an item from a dict using extra keys
    container = dict(item1=dict(item2=dict(item3='value')))
    assert extract(env, 'item1', container, 'item2.item3') == 'value'

    # Check if we can extract an item from a list
    container = [dict(item1=dict(item2=dict(item3='value')))]
    assert extract(env, 0, container, 'item1.item2.item3') == 'value'

    # Check if we can extract an item

# Generated at 2022-06-23 10:11:28.742271
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('["foo", "bar"]') == ["foo", "bar"]
    assert from_yaml('{"foo": "bar"}') == {"foo": "bar"}
    assert from_yaml('foo: bar') == {"foo": "bar"}
    assert from_yaml('--- [foo, bar]') == ["foo", "bar"]
    assert from_yaml('---\n- foo\n- bar') == ["foo", "bar"]


# Generated at 2022-06-23 10:11:32.308724
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'chocolate': 'cake', 'frosting': 'sugar and butter'}
    expect = [{'key': 'frosting', 'value': 'sugar and butter'}, {'key': 'chocolate', 'value': 'cake'}]
    actual = dict_to_list_of_dict_key_value_elements(mydict)
    assert actual == expect, "Expected: %s, got %s" % (expect, actual)



# Generated at 2022-06-23 10:11:41.201030
# Unit test for function to_uuid
def test_to_uuid():
    """
    The following tests ensure that the function `to_uuid` behaves as expected

    >>> test_to_uuid()
    """
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six.moves import cStringIO as StringIO

    TestCase = namedtuple('TestCase', ['description', 'input', 'namespace', 'expected'])


# Generated at 2022-06-23 10:11:48.446703
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'happy', 'sad') == 'happy'
    assert ternary(False, 'happy', 'sad') == 'sad'
    assert ternary(None, 'happy', 'sad', 'fatal') == 'fatal'
    assert ternary("", 'happy', 'sad', 'fatal') == 'sad'
    assert ternary("non-empty", 'happy', 'sad', 'fatal') == 'happy'



# Generated at 2022-06-23 10:12:00.298914
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('test') == 'test'
    assert regex_escape('42') == '42'
    assert regex_escape('test^text') == 'test\\^text'
    assert regex_escape('test\\text') == 'test\\\\text'
    assert regex_escape('test*text') == 'test\\*text'
    assert regex_escape('test+text') == 'test\\+text'
    assert regex_escape('test?text') == 'test\\?text'
    assert regex_escape('test|text') == 'test\\|text'
    assert regex_escape('test[text]') == 'test\\[text\\]'
    assert regex_escape('test{text}') == 'test\\{text\\}'
    assert regex_escape('test(text)') == 'test\\(text\\)'
    assert regex_escape

# Generated at 2022-06-23 10:12:06.469979
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u'abc') == u'YWJj'
    assert b64encode(u'abc\u20ac') == u'YWLigKI='
    assert b64encode(u'abc\u20ac', 'latin-1') == u'YWLigKI='



# Generated at 2022-06-23 10:12:15.949584
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    print("Testing to_nice_yaml")
    base = {
            "hostname": "localhost",
            "ip": "127.0.0.1",
            "services": [ "httpd", "puppetmaster", "foreman" ],
            "environment": {"dev", "staging", "prod"}
            }
    assert to_nice_yaml(base) == """services:
- httpd
- puppetmaster
- foreman
environment:
- prod
- staging
- dev
ip: 127.0.0.1
hostname: localhost
"""

# Generated at 2022-06-23 10:12:20.174898
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    sample = [
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2}
    ]
    expected = {'a': 1, 'b': 2}
    actual = list_of_dict_key_value_elements_to_dict(sample)
    assert actual == expected, "items2dict: unexpected conversion returned"
    sample = [{'foo': 'a', 'bar': 1}, {'foo': 'b', 'bar': 2}]
    expected = {'a': 1, 'b': 2}
    actual = list_of_dict_key_value_elements_to_dict(sample, key_name='foo', value_name='bar')
    assert actual == expected, "items2dict: unexpected conversion returned"

# Generated at 2022-06-23 10:12:27.571530
# Unit test for function regex_findall

# Generated at 2022-06-23 10:12:32.091232
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(1, 1, 2) == 1
    assert ternary('foo', 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(0, 1, 2) == 2
    assert ternary({}, 1, 2) == 1
    assert ternary((), 1, 2) == 1
    assert ternary([], 1, 2) == 1
    assert ternary(None, 1, 2) == 2
    assert ternary(None, 1, 2, 3) == 3



# Generated at 2022-06-23 10:12:39.595760
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_value1 = ['hello', 'goodbye', 'before']
    assert to_nice_yaml(test_value1, indent=4) == '- hello\n- goodbye\n- before\n'
    # Test a specified indent level
    assert to_nice_yaml(test_value1, indent=8) == '        - hello\n        - goodbye\n        - before\n'


# Generated at 2022-06-23 10:12:46.058361
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall(value='1,2,3,4', regex='\d+(?=,|$)') == ['1', '2', '3', '4']
    assert regex_findall(value='a1bc2de3f', regex='\d+', ignorecase=True) == ['1', '2', '3']
    assert regex_findall(value='abcd efgh', regex='\w+', multiline=True) == ['abcd', 'efgh']



# Generated at 2022-06-23 10:12:50.970160
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    test_dict = dict(ansible=1, cool=2)
    test_result = dict_to_list_of_dict_key_value_elements(test_dict)
    assert test_result == [{'key':'ansible', 'value':1}, {'key':'cool', 'value':2}]



# Generated at 2022-06-23 10:13:03.694093
# Unit test for function randomize_list
def test_randomize_list():
    '''
    Unit test for function randomize_list
    '''

    #
    # Helper functions
    #

    def is_permutation(l):
        '''
        Return True if the list of integers 1..N is a permutation of the list l.
        '''
        return set(l) == set(range(min(l), max(l) + 1))

    def is_list_of_lists_of_permutations(l):
        '''
        Return True if every element of l is a list of integers 1..N and
        is a permutation of 1..N.
        '''
        if not isinstance(l, list):
            return False
        else:
            return all(is_permutation(x) for x in l)


# Generated at 2022-06-23 10:13:16.698943
# Unit test for function to_bool
def test_to_bool():
    true_strings = ('yes', 'on', '1', 'true', 1)
    false_strings = ('no', 'off', '0', 'false', 0)
    for x in true_strings:
        assert to_bool(x) is True
    for x in false_strings:
        assert to_bool(x) is False
    assert to_bool('foo') is False
    assert to_bool('') is False
    assert to_bool([1]) is True
    assert to_bool(['foo']) is True
    assert to_bool([]) is False
    assert to_bool(0) is False
    assert to_bool(1) is True
    assert to_bool(None) is None
    assert to_bool(True) is True
    assert to_bool(False) is False
# end unit test


# Generated at 2022-06-23 10:13:20.204742
# Unit test for function to_bool
def test_to_bool():
    # test result of a True
    result = to_bool(1)
    assert result == True

    # test result of a False
    result = to_bool(0)
    assert result == False

    # test result of a None
    result = to_bool(None)
    assert result == None


# Generated at 2022-06-23 10:13:26.363021
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    # merge can take multiple dict as argument
    assert combine({'a': 1}, {'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}
    assert combine({'a': 1}, {'b': 2}, {'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    # and even a list

# Generated at 2022-06-23 10:13:33.464981
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("hello world", "hello") == "hello"
    assert regex_search("hello world", "hello", "\\g<1>") == ["hello", "world"]
    assert regex_search("hello world", "hello", "\\g<1>", "\\g<2>") == ["hello", "world"]
    assert regex_search("hello world", "hello", "\\1", "\\2") == ["hello", "world"]



# Generated at 2022-06-23 10:13:36.101875
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('test')) == u'test'



# Generated at 2022-06-23 10:13:42.338019
# Unit test for function comment
def test_comment():
    assert comment("This is a test text", 'plain') == "# This is a test text"
    assert comment("This is a test text", 'erlang') == "% This is a test text"
    assert comment(
        "This is a test text", 'erlang', decoration="#") == "# This is a test text"
    assert comment("This is a test text", 'c') == "// This is a test text"
    assert comment("This is a test text",
                   'cblock', decoration=" * ", prefix_count=2) == "/**\n * *  This is a test text\n */"
    assert comment("This is a test text", 'xml') == "<!--\n - This is a test text\n-->"

# Generated at 2022-06-23 10:13:47.966336
# Unit test for function do_groupby
def test_do_groupby():
    env = jinja2.Environment()
    result = do_groupby(env, [{'name': 'g1'}, {'name': 'g2'}, {'name': 'g1'}], attribute='name')
    assert(2 == len(result))
    assert('g1' == result[0][0])
    assert('g2' == result[1][0])



# Generated at 2022-06-23 10:13:57.219176
# Unit test for function flatten
def test_flatten():

    # Test basic single-element flatten
    assert flatten(["a", "b", "c"]) == ["a", "b", "c"]
    # Test a double-nested list, with no recurssion
    assert flatten([["a"], ["b", "c"]]) == ["a", "b", "c"]
    # Test a double-nested list, with one level of recurssion
    assert flatten([["a"], ["b", "c"]], levels=1) == ["a", "b", "c"]
    # Test a list with non-string elements
    assert flatten([["a"], 1]) == ["a", 1]
    # Test a double-nested list, with two levels of recursion
    assert flatten([[1, 2, [3]], [4, 5, 6]], levels=2)

# Generated at 2022-06-23 10:14:02.146899
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1, msg="Error message") == 1
    try:
        assert mandatory(Undefined(name='dummy'))
        assert False, "This should have been an exception"
    except AnsibleFilterError:
        # test passed
        assert True
    try:
        assert mandatory(Undefined(name='dummy'), msg="Error message")
        assert False, "This should have been an exception"
    except AnsibleFilterError:
        # test passed
        assert True
    try:
        assert mandatory(Undefined(name=None))
        assert False, "This should have been an exception"
    except AnsibleFilterError:
        # test passed
        assert True


# Generated at 2022-06-23 10:14:06.360659
# Unit test for function combine
def test_combine():
    d0 = {}
    d1 = {'a': 1, 'b': 2}
    d2 = {'c': 3}
    d3 = {'c': 4, 'd': 5}
    d4 = [4, 5, 6]
    d5 = {'a': 4, 'e': 5, 'b': 6}

    # test with various combinations of input
    # use yaml because it will order the dict keys
    d = combine(d0, d1, d2, d3)
    assert to_yaml(d) == '{a: 1, b: 2, c: 4, d: 5}'
    d = combine(d1, d2, d3, d0)
    assert to_yaml(d) == '{a: 1, b: 2, c: 4, d: 5}'

# Generated at 2022-06-23 10:14:08.083974
# Unit test for function get_hash
def test_get_hash():
    try:
        reload(sys).setdefaultencoding("utf-8")
    except AttributeError:
        pass
    x = get_hash('helloworld', 'md5')
    assert x == 'fc5e038d38a57032085441e7fe7010b0'


# Generated at 2022-06-23 10:14:18.930424
# Unit test for function flatten
def test_flatten():
    assert flatten([]) == []
    assert flatten([[], []]) == []
    assert flatten(["a"]) == ["a"]
    assert flatten(["a", "b"]) == ["a", "b"]
    assert flatten({"a": "b"}) == [{"a": "b"}]
    assert flatten([["a"], [{"b": "b"}], "c"]) == ["a", {"b": "b"}, "c"]
    assert flatten([["a"], [{"b": "b"}], "c"], 1) == [["a"], [{"b": "b"}], "c"]
    assert flatten([["a"], [{"b": "b"}], "c"], 2) == ["a", {"b": "b"}, "c"]

# Generated at 2022-06-23 10:14:24.069757
# Unit test for function quote
def test_quote():
    assert quote("foo") == "'foo'"
    assert quote("foo bar") == "'foo bar'"
    assert quote("'foo' 'bar'") == "''\\'foo'\\' '\\'bar'\\''"
    assert quote("\\") == "'\\\\'"
    assert quote("\t") == r"'\t'"
    assert quote("\n") == r"'\n'"
    assert quote(u"\u1234") == u"'\u1234'"



# Generated at 2022-06-23 10:14:29.482668
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('True')
    assert to_bool('true')
    assert to_bool('TRUE')
    assert to_bool('yes')
    assert to_bool('YES')
    assert to_bool('on')
    assert to_bool('ON')
    assert to_bool('1')
    assert to_bool(1)
    assert to_bool(True)

    assert not to_bool(False)
    assert not to_bool('false')
    assert not to_bool('off')
    assert not to_bool('n')
    assert not to_bool('no')
    assert not to_bool(0)
    assert not to_bool('')
    assert not to_bool(None)



# Generated at 2022-06-23 10:14:33.872134
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    import os
    import sys
    import tempfile
    import subprocess
    cmd_yamllint = 'yamllint -f parsable -'
    test_yaml_string = """
    - id: key
      name: TestName
    """
    fd, tmp_file = tempfile.mkstemp()
    os.write(fd, to_bytes(test_yaml_string))
    os.close(fd)
    cmd = 'cat {0} | {1}'.format(tmp_file, cmd_yamllint)
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    output, error = process.communicate()
    os.remove(tmp_file)
    assert process.returncode == 0


# Generated at 2022-06-23 10:14:43.312874
# Unit test for function regex_search
def test_regex_search():
  assert regex_search('this is a test', '(is|is a)') == 'is'
  assert regex_search('this is a test', r'(?P<match>^\w+\s\w+\s\w+\s\w+)', '\\g<match>') == 'this is a test'
  assert regex_search('this is a test', r'(^\w+\s\w+\s\w+\s\w+)', '\\1') == 'this is a test'
  assert regex_search('this is a test', r'(?P<match>^\w+\s\w+\s\w+\s\w+)', '\\g<match>') == 'this is a test'



# Generated at 2022-06-23 10:14:53.304892
# Unit test for function fileglob
def test_fileglob():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile() as tmpf:
        assert fileglob(tmpf.name) == [tmpf.name]

        # Test globbing in a directory
        tmpd = tempfile.mkdtemp()
        try:
            assert fileglob(tmpd + '/*') == []

            for i in range(10):
                with tempfile.NamedTemporaryFile(dir=tmpd):
                    pass

            fglob = fileglob(tmpd + '/*')
            assert len(fglob) == 10
            for fn in fglob:
                assert os.path.isfile(fn)
        finally:
            os.rmdir(tmpd)


# Generated at 2022-06-23 10:14:53.867238
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:14:57.969645
# Unit test for function from_yaml
def test_from_yaml():
    # Need to verify yaml strings are read,
    # but also accept non-strings.
    assert from_yaml('a') == 'a'
    assert from_yaml('a: 1') == {'a': 1}
    assert from_yaml({'a': 1}) == {'a': 1}



# Generated at 2022-06-23 10:15:03.329442
# Unit test for function to_datetime
def test_to_datetime():
    test_date = to_datetime('2019-06-29 18:00:00')
    if test_date != datetime.datetime(2019, 6, 29, 18, 0, 0):
        raise AssertionError("test_to_datetime failed")



# Generated at 2022-06-23 10:15:08.512853
# Unit test for function strftime
def test_strftime():
    assert strftime("%A %B %d %H:%M:%S %Y", "1396310796") == 'Thursday April 03 12:33:16 2014'
    assert strftime("%A %B %d %H:%M:%S %Y", 1396310796) == 'Thursday April 03 12:33:16 2014'
    assert strftime("%A %B %d %H:%M:%S %Y") == time.strftime("%A %B %d %H:%M:%S %Y")



# Generated at 2022-06-23 10:15:15.114979
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'a': 'AAA', 'b': 'BBB'}
    r = dict_to_list_of_dict_key_value_elements(mydict)
    assert r == [{'key': 'a', 'value': 'AAA'}, {'key': 'b', 'value': 'BBB'}], r



# Generated at 2022-06-23 10:15:18.974813
# Unit test for function regex_findall
def test_regex_findall():
    test = '<span class="SOME_STUFF">the value is \((.*)\)</span>'
    value = '<span class="SOME_STUFF">the value is (3.04)</span>'
    expected = ['3.04']
    assert regex_findall(value, test) == expected


# Generated at 2022-06-23 10:15:31.111975
# Unit test for function flatten
def test_flatten():
    _test_flatten = flatten
    mylist = [1, 2, 3, [4, 5, 6], 7, [8, [9, [10, 11], 12]]]

    assert _test_flatten(mylist) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], \
        "Error, basic flatten() result expected: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] got: %s" % _test_flatten(mylist)
