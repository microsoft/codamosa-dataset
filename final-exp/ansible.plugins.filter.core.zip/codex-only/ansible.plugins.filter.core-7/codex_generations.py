

# Generated at 2022-06-23 10:05:34.101522
# Unit test for function combine
def test_combine():
    # Test combine: nothing passed.
    result = combine()
    assert result == {}

    # Test combine: one dict passed.
    result = combine({})
    assert result == {}

    # Test combine: multiple dicts passed.
    result = combine({}, {})
    assert result == {}

    # Test combine: replace list in result with list from passed dict.
    result = combine({'key': [1, 2]}, {'key': [3, 4]})
    assert result == {'key': [3, 4]}

    # Test combine: replace list with non-list in result.
    result = combine({'key': [1, 2]}, {'key': 3})
    assert result == {'key': 3}

    # Test combine: replace non-list in result with list.

# Generated at 2022-06-23 10:05:39.135007
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    for password, hashtype in [('password', 'md5'), ('password', 'blowfish'), ('password', 'sha256'), ('password', 'sha512')]:
        p = get_encrypted_password(password, hashtype)
        assert isinstance(p, AnsibleUnsafeText)
        assert get_encrypted_password(password, hashtype) == get_encrypted_password(password, hashtype)



# Generated at 2022-06-23 10:05:52.521435
# Unit test for function flatten

# Generated at 2022-06-23 10:05:57.375362
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ret = dict_to_list_of_dict_key_value_elements({'a': 1, 3: 'four'})
    assert ret == [{'key': 'a', 'value': 1}, {'key': 3, 'value': 'four'}]



# Generated at 2022-06-23 10:06:01.858907
# Unit test for function from_yaml_all
def test_from_yaml_all():
    data = '''
- foo: bar
  baz: 42
- foo: bar2
  baz: 43
'''
    result = list(from_yaml_all(data))
    assert result == [
        {'baz': 42, 'foo': 'bar'},
        {'baz': 43, 'foo': 'bar2'}
    ]
    assert from_yaml_all(data) is not from_yaml_all(data)



# Generated at 2022-06-23 10:06:06.354622
# Unit test for function quote
def test_quote():
    assert quote(None) == u''
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote('foo bar') == u"'foo bar'"
    assert quote(u'foo bar') == u"'foo bar'"
    assert quote(u"I'm bar") == u"'I'\\''m bar'"
    assert quote(u"I've got bar") == u"'I'\\''ve got bar'"
    assert quote(u"I've got 'bar'") == u"'I'\\''ve got \\''bar\\'''"


# Generated at 2022-06-23 10:06:10.508684
# Unit test for function do_groupby
def test_do_groupby():
    # Returns a list of tuples after the do_groupby filter is applied.
    # The jinja filter itself returns a list of named tuples.
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()

    countries = [
        {'country': 'UK', 'continent': 'Europe', 'population': 12},
        {'country': 'France', 'continent': 'Europe', 'population': 8},
        {'country': 'China', 'continent': 'Asia', 'population': 14},
        {'country': 'USA', 'continent': 'North America', 'population': 5}
    ]

    groupby_filter = env.filters.get('groupby')
    assert groupby_filter
    grouped = groupby_filter(countries, 'continent')

    assert grouped

# Generated at 2022-06-23 10:06:11.900212
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('some string äöü') == 'c29tZSBzdHJpbmcgw6TDtsO8'


# Generated at 2022-06-23 10:06:15.741063
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2019-05-08 11:08:51') == datetime.datetime(2019, 5, 8, 11, 8, 51)
    assert to_datetime('2019-05-08 11:08:51', "%d/%m/%Y %H:%M:%S") == datetime.datetime(2019, 5, 8, 11, 8, 51)


# Generated at 2022-06-23 10:06:16.591515
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return fm

# Generated at 2022-06-23 10:06:30.246301
# Unit test for function to_nice_json
def test_to_nice_json():
    data = {'hello': 'world'}
    assert to_native(to_nice_json(data)) == '{\n    "hello": "world"\n}'
    assert to_native(to_nice_json(data, indent=4)) == '{\n    "hello": "world"\n}'
    assert to_native(to_nice_json(data, indent='\t')) == '{\n\t"hello": "world"\n}'
    assert to_native(to_nice_json(data, sort_keys=True)) == '{\n    "hello": "world"\n}'
    assert to_native(to_nice_json(data, sort_keys=False)) == '{\n    "hello": "world"\n}'



# Generated at 2022-06-23 10:06:32.939520
# Unit test for function to_json
def test_to_json():
    assert to_json(3.14) == '3.14'
    assert to_json('hello') == '"hello"'



# Generated at 2022-06-23 10:06:42.194470
# Unit test for function strftime
def test_strftime():
    assert strftime('%H:%M', 1411955631.3721559) == '12:13'
    assert strftime('%H:%M %Z', 1411955631.3721559) == '12:13 CST'
    assert strftime('%H:%M %z', 1411955631.3721559) == '12:13 -0600'
    assert strftime('%Y%m%d%H%M%S', 1411955631.3721559) == '20141125121331'
    assert strftime('%Y-%m-%d', 1411955631.3721559) == '2014-11-25'
    assert strftime('%a, %d %b %Y %H:%M:%S GMT') is not None

# Generated at 2022-06-23 10:06:44.645741
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert list(from_yaml_all('''
foo: 1
bar: 2
''')) == [{'foo': 1, 'bar': 2}]


# Generated at 2022-06-23 10:06:48.881329
# Unit test for function path_join
def test_path_join():
    ''' Unit test for path_join'''
    paths = ['test1', 'test2', '/test3', 'test4/']
    test_paths = path_join(paths)
    assert test_paths == 'test1/test2/test3/test4/'
    paths = '/test1//test2//test3/test4/'
    test_paths = path_join(paths)
    assert test_paths == '/test1/test2/test3/test4/'
    paths = '/test1/test2/test3/test4/'
    test_paths = path_join(paths)
    assert test_paths == '/test1/test2/test3/test4/'


# Generated at 2022-06-23 10:06:55.712898
# Unit test for function combine
def test_combine():
    assert combine({"foo": "bar"}, {"bar": "baz"}) == {"foo": "bar", "bar": "baz"}
    assert combine({"foo": {"bar": "baz"}}, {"foo": {"bar": "biz"}}) == {"foo": {"bar": "biz"}}
    assert combine({"foo": "bar"}, {"foo": "bar"}) == {"foo": "bar"}

    # the list merging works with the default "replace" strategy
    assert combine({"foo": ["bar", "baz"]}, {"foo": ["biz"]}) == {"foo": ["biz"]}

    # test with non-dict/list as input (should be ignored)
    assert combine({"foo": 1}, {"foo": 2}) == {"foo": 1}

# Generated at 2022-06-23 10:07:02.498109
# Unit test for function to_nice_json
def test_to_nice_json():
    json_data = {
        "a": {
            "b": "c"
        },
        "d": "e"
    }
    assert to_nice_json(json_data) == to_text("{\n    \"a\": {\n        \"b\": \"c\"\n    },\n    \"d\": \"e\"\n}")


# Generated at 2022-06-23 10:07:12.045051
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('test') == '361e6d50-faed-444a-9079-341386da8e2e'
    assert to_uuid('test', '100a6e8c-deef-49df-99f6-b6a8a3f3d723') == \
        '7f8a1918-c0d5-5e0a-8f74-c6d5a6ec5a1a'
    assert to_uuid('test', uuid.UUID('100a6e8c-deef-49df-99f6-b6a8a3f3d723')) == \
        '7f8a1918-c0d5-5e0a-8f74-c6d5a6ec5a1a'


# Generated at 2022-06-23 10:07:20.604815
# Unit test for function rand
def test_rand():
    # is repeatable
    assert rand([1, 2, 3], seed=1) == 2
    assert rand([1, 2, 3], seed=1) == 2
    # end only, as in Ansible <= 2.4
    assert rand(10) < 10
    assert rand(10) < 10
    # end and start, as in Ansible >= 2.5
    assert 1 <= rand(1, 10) < 10
    assert 1 <= rand(1, 10) < 10
    # end and start and step, as in Ansible >= 2.5
    assert 1 <= rand(1, 10, 2) <= 5
    assert 1 <= rand(1, 10, 2) <= 5

    error = None
    try:
        rand(10, 5, 0)
    except AnsibleFilterError as e:
        error = e

# Generated at 2022-06-23 10:07:33.285082
# Unit test for function from_yaml_all
def test_from_yaml_all():
    def compare(v, e):
        try:
            # This will throw an exception if v!=e
            assert v == e
            return True
        except Exception as ex:
            return ex

    test_data = """
        - first
        - second
        - third
        """
    expected = ["first", "second", "third"]
    actual = from_yaml_all(test_data)
    assert len(actual) == 3, compare("length", 3)
    assert len(actual[0]) == 1, compare("length", 1)
    assert compare(actual[0][0], expected[0])
    assert len(actual[1]) == 1, compare("length", 1)
    assert compare(actual[1][0], expected[1])
    assert len(actual[2]) == 1, compare("length", 1)

# Generated at 2022-06-23 10:07:35.802858
# Unit test for function comment
def test_comment():
    import tests_data.test_comment
    for test in tests_data.test_comment.test_comment:
        assert test[0] == comment(test[1], **test[2])



# Generated at 2022-06-23 10:07:47.351615
# Unit test for function quote
def test_quote():
    from ansible.module_utils.basic import AnsibleModule
    # test single argument
    assert quote('a') == u'a'
    # test multiple argument
    assert quote('a', 'b', 'c') == u'a, b, c'
    # test double quote character
    assert quote('a"b') == u'"a\\\\"b"'
    # test backslash character
    assert quote('a\\b') == u'"a\\\\b"'
    assert quote('a\\\\b') == u'"a\\\\\\\\\\\\b"'
    # test single quote character
    assert quote("a'b") == u"""'a'"b'"""
    assert quote("a''b") == u"""'a'"'"'"b'"""
    # test mix character
    assert quote("a\\'b") == u"""'a\\'"'"'"b'"""


# Generated at 2022-06-23 10:07:50.204491
# Unit test for function path_join
def test_path_join():
    assert 'foo/bar/baz' == path_join('foo/bar', 'baz')
    assert 'foo/bar/baz' == path_join(('foo/bar', 'baz'))
    assert 'foo/baz' == path_join(('foo', '', 'baz'))



# Generated at 2022-06-23 10:07:53.664692
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({"a": "b"}, indent=2) == "{\n  a: b\n}\n"



# Generated at 2022-06-23 10:08:03.610981
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test\nsecond line') == '# test\n# second line'
    assert comment('test\\nsecond line') == '# test\\nsecond line'
    assert comment(
        'test\nsecond line',
        newline='\n',
        prefix='# ',
        prefix_count=1) == '# test\n# second line'
    assert comment(
        'test\nsecond line',
        newline='\n',
        prefix='# ',
        prefix_count=1,
        decoration='') == '# test\n# second line'

# Generated at 2022-06-23 10:08:09.547353
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(["foo", "bar", "baz"]) != ["foo", "bar", "baz"]
    assert randomize_list(["foo", "bar", "baz"], 1) != randomize_list(["foo", "bar", "baz"], 2)
    assert randomize_list([], 1) == randomize_list([], 2)
    assert randomize_list([1, 2, 3, 4], 1) != randomize_list([1, 2, 3, 4], 2)



# Generated at 2022-06-23 10:08:13.508646
# Unit test for function randomize_list
def test_randomize_list():
    mylist1 = ['a', 'b', 'c', 'd']
    mylist2 = randomize_list(mylist=mylist1, seed=1)
    assert mylist2 == ['d', 'a', 'c', 'b']
    assert mylist1 != mylist2
    try:
        mylist1 = ['a', 'b', 'c', 'd']
        mylist2 = randomize_list(mylist=mylist1, seed='blah')
    except Exception:
        pass
    else:
        raise AssertionError("Expected exception")



# Generated at 2022-06-23 10:08:15.118035
# Unit test for function b64decode
def test_b64decode():
    real_value = b64decode('Q2hYWlByQ2dpU3Z3U0E9PQ==')
    expected_value = 'ChXZPrCgiSvwSA=='
    assert real_value == expected_value


# Generated at 2022-06-23 10:08:19.485477
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('\\w+') == '\\\\w\\+'
    assert regex_escape('\\w+', re_type='posix_basic') == '\\\\w+'



# Generated at 2022-06-23 10:08:28.221487
# Unit test for function strftime
def test_strftime():
    date = strftime('%Y-%m-%d %H:%M:%S', second=0)
    assert date == '1970-01-01 00:00:00'
    date = strftime('%Y-%m-%d %H:%M:%S', second=2)
    assert date == '1970-01-01 00:00:02'
    date = strftime('%Y-%m-%d %H:%M:%S', second=46)
    assert date == '1970-01-01 00:00:46'
    date = strftime('%Y-%m-%d %H:%M:%S', second='0')
    assert date == '1970-01-01 00:00:00'

# Generated at 2022-06-23 10:08:38.309861
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = "mynameisnomedo"
    # md5
    assert get_encrypted_password(password, 'md5') == '$1$salt$AmMkS5p5obWbJY5vamQg0.'

    # blowfish
    assert get_encrypted_password(password, 'blowfish') == "$2b$12$rounds=12000$salt$8wA7Vpvq3uyuIt7esG8/OOuV7vYkDpdPZ7xM8MwWDCN"

    # sha256

# Generated at 2022-06-23 10:08:49.458571
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='', pattern='', replacement='') == ''
    assert regex_replace(value=' ', pattern=' ', replacement='') == ''
    assert regex_replace(value='text with spaces', pattern=' ', replacement='') == 'textwithspaces'
    assert regex_replace(value='text with spaces', pattern=' ', replacement='_') == 'text_with_spaces'
    assert regex_replace(value='text with spaces', pattern='\s+', replacement='_') == 'text_with_spaces'
    assert regex_replace(value='10.0.0.1', pattern='\.', replacement='-') == '10-0-0-1'
    assert regex_replace(value='text with spaces', pattern='(\w+)', replacement='\\1_') == 'text_ text_ with_ spaces_'
   

# Generated at 2022-06-23 10:08:56.044581
# Unit test for function from_yaml
def test_from_yaml():
    data = {
        'a': 'b',
        'c': {
            'd': 'e',
        },
        'f': {
            'g': 'h',
        },
    }
    res = from_yaml(to_yaml(data))
    assert data == res



# Generated at 2022-06-23 10:09:03.154301
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 5, 3) == 5
    assert ternary(0, 5, 3) == 3
    assert ternary(None, 5, 3) == 3
    assert ternary(None, 5, 3, None) == None
    assert ternary(4, 5, 3) == 5


# Generated at 2022-06-23 10:09:07.589102
# Unit test for function extract
def test_extract():
    """
    extract:
      - 'item_name'
      - dict
      - [ 'key1', 'key2', 'key3' ]
    """
    vars = {
        'dict': {
            'key1': {
                'key2': {
                    'key3': 'value3'
                }
            }
        }
    }
    assert 'value3' == extract('item_name', vars['dict'], [ 'key1', 'key2', 'key3' ])



# Generated at 2022-06-23 10:09:19.219262
# Unit test for function flatten
def test_flatten():
    # Test data 1, levels=0
    mylist = [
        1,
        2,
        3,
        [4, 5],
        [6, [7, 8, 9]],
        0,
        [],
        [1, [2, [3, [4, [5, [6, [7, [8, [9]]]]]]]]]
    ]
    assert flatten(mylist, levels=0) == mylist
    # Test data 1, levels=1
    assert flatten(mylist, levels=1) == [
        1, 2, 3, 4, 5, 6, [7, 8, 9], 0, [], 1, [2, [3, [4, [5, [6, [7, [8, [9]]]]]]]]
    ]
    # Test data 1, levels=2

# Generated at 2022-06-23 10:09:31.907696
# Unit test for function quote

# Generated at 2022-06-23 10:09:39.815300
# Unit test for function from_yaml_all
def test_from_yaml_all():
    yaml_tests = [
        # (input, expected_output)
        ('key: value', [{'key': 'value'}]),
        ('[1,2,3]', [[1, 2, 3]]),
        ('---\nkey: value\n---\n[1,2,3]', [{'key': 'value'}, [1, 2, 3]]),
    ]
    for inp, exp in yaml_tests:
        assert from_yaml_all(inp) == exp



# Generated at 2022-06-23 10:09:41.355316
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:09:53.737320
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('.') == '\\.'
    assert regex_escape(r'[].', re_type='posix_basic') == r'\[\]\.'
    assert regex_escape(r'', re_type='posix_basic') == r''
    assert regex_escape(r'$', re_type='posix_basic') == r'\$'
    assert regex_escape(r'.*', re_type='posix_basic') == r'\.*'
    assert regex_escape(r'[.*]', re_type='posix_basic') == r'\[\.\*\]'
    assert regex_escape(r'.', re_type='python') == r'\.'
    assert regex_escape(r'', re_type='python') == r''

# Generated at 2022-06-23 10:10:00.030893
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2})
    assert to_yaml(['a', 'b'])
    assert to_yaml('foo') == 'foo\n...\n'
    assert to_yaml('foo') != 'foo\n...'


# Generated at 2022-06-23 10:10:08.896032
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote(u"abc") == u"'abc'"
    assert quote(u"a'b'c") == u"'a'\"'\"'b'\"'\"'c'"
    assert quote(u"a'b'c", u"'") == u"'''a'\"'\"'b'\"'\"'c'''"
    assert quote(u"a'b'c", u"\"") == u"'a'\"'\"'b'\"'\"'c'"
    assert quote(u"a'b'c", [u"'", u'"']) == u"'''a'\"'\"'b'\"'\"'c'''"
    assert quote(u"a\"b\"c", [u"'", u'"']) == u"'a\"b\"c'"


# Generated at 2022-06-23 10:10:12.090870
# Unit test for function quote
def test_quote():
    assert quote('{}') == '"{}"'
    assert quote('a b c') == '\'a b c\''



# Generated at 2022-06-23 10:10:16.273254
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictEnvironment, StrictUndefined, contextfilter

    @contextfilter
    def do_groupby(context, value, attribute):
        return _do_groupby(context, value, attribute)

    env = DictEnvironment(undefined=StrictUndefined)
    env.filters['do_groupby'] = do_groupby
    env.tests['uuid'] = uuid.uuid4

    d_values = ['b', 'c', 'a']
    d_uuid = uuid.uuid4()
    d_uuid2 = uuid.uuid4()
    d_uuid3 = uuid.uuid4()


# Generated at 2022-06-23 10:10:19.993162
# Unit test for function to_json
def test_to_json():
    assert to_json(1) == json.dumps(1, cls=AnsibleJSONEncoder)
    assert to_json('{"a":1}') == json.dumps('{"a":1}', cls=AnsibleJSONEncoder)
# Test for filter to_json module_utils.collections

# Generated at 2022-06-23 10:10:32.901504
# Unit test for function flatten
def test_flatten():

    # Test one level without recursion
    mylist = [1, 2, [3, 4], 5, 6, [7, [8, 9]]]
    result = flatten(mylist, levels=1)
    assert result == [1, 2, 3, 4, 5, 6, 7, [8, 9]]

    # Test two levels of recursion (-1 is infinite depth)
    mylist = [1, 2, [3, 4], 5, 6, [7, [8, 9]]]
    result = flatten(mylist, levels=-1)
    assert result == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    result = flatten(mylist, levels=2)
    assert result == [1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test string

# Generated at 2022-06-23 10:10:39.247329
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    dict_to_list_of_dict_key_value_elements({'a': 'b'})
    dict_to_list_of_dict_key_value_elements({'a': 'b'}, key_name='mykey', value_name='myvalue')
    dict_to_list_of_dict_key_value_elements(dict(a='b', b='c'))
    dict_to_list_of_dict_key_value_elements("string")



# Generated at 2022-06-23 10:10:43.091490
# Unit test for function strftime
def test_strftime():
    assert strftime('%d/%m/%Y', '1426295200.1234') == '28/03/2015'
    assert strftime('%d/%m/%Y', '1426295200') == '28/03/2015'
    assert strftime('%d/%m/%Y', '1426295200.1234') == '28/03/2015'
    assert strftime('%d/%m/%Y') == '%d/%m/%Y'
    assert strftime('%d/%m/%Y', 0) == '01/01/1970'
    assert strftime('%d/%m/%Y %H', 0) == '01/01/1970 00'

# Generated at 2022-06-23 10:10:52.656698
# Unit test for function extract
def test_extract():
    """
    Test for extract
    """
    from ansible.plugins.filter import core

    my_dict = {"key": {"key": {"key": [1, 2, 3]}}}
    test_extract = core._filter_loader.filters()["extract"]
    assert test_extract(my_dict, 'key', my_dict) == my_dict['key']
    assert test_extract(my_dict, 'key', my_dict, 'key') == my_dict['key']['key']
    # Check if multiple morekeys are supported
    assert test_extract(my_dict, 'key', my_dict, ['key', 'key']) == my_dict['key']['key']['key']
    assert test_extract(my_dict, 'key', my_dict, 'key', 'key')

# Generated at 2022-06-23 10:11:00.195969
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert list(from_yaml_all('- foo\n- bar')) == ['foo', 'bar']
    assert list(from_yaml_all('- foo\n- bar\n- baz')) == ['foo', 'bar', 'baz']
    assert list(from_yaml_all('-\n foo\n- bar')) == [{'foo': None}, 'bar']
    assert list(from_yaml_all('-\n foo\n- bar\n-\n baz')) == [{'foo': None}, 'bar', {'baz': None}]
    assert list(from_yaml_all('- foo\n- bar\n-\n baz')) == ['foo', 'bar', {'baz': None}]

# Generated at 2022-06-23 10:11:06.480534
# Unit test for function to_bool
def test_to_bool():
    ''' Unit test for function to_bool '''
    assert to_bool("True") is True
    assert to_bool("true") is True
    assert to_bool("1") is True
    assert to_bool("false") is False
    assert to_bool("False") is False
    assert to_bool("0") is False
    assert to_bool("string") is False



# Generated at 2022-06-23 10:11:18.490055
# Unit test for function get_encrypted_password

# Generated at 2022-06-23 10:11:27.106354
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'a.b') == 'a\\.b'
    assert regex_escape(r'a.b', re_type='posix_basic') == 'a\\.b'
    # posix_extended is not yet implemented, so this should throw an error
    try:
        regex_escape(r'a.b', re_type='posix_extended')
        assert False
    except AnsibleFilterError:
        assert True



# Generated at 2022-06-23 10:11:31.263189
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for the constructor of class FilterModule

        :return: success | failure
        :rtype: boolean
    '''

    # simple test of constructor
    test = FilterModule()

    return True

# Unit test

# Generated at 2022-06-23 10:11:40.887605
# Unit test for function to_uuid
def test_to_uuid():
    namespaced_uuid = uuid.UUID('bf1b4e53-4c90-4ccb-9d54-3c3dc2a2a8c7')
    assert to_uuid('foo', namespaced_uuid) == '91555cc1-a800-5b8d-8d06-a40081ffbfa9'
    assert to_uuid('foo', 'bf1b4e53-4c90-4ccb-9d54-3c3dc2a2a8c7') == '91555cc1-a800-5b8d-8d06-a40081ffbfa9'

# Generated at 2022-06-23 10:11:49.728549
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('test') == 'test'
    assert regex_escape('foo(bar') == 'foo\\(bar'
    assert regex_escape('foo[0-9]bar') == 'foo\\[0\\-9\\]bar'
    assert regex_escape('foo$bar') == 'foo\\$bar'
    assert regex_escape('foo*bar') == 'foo\\*bar'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo\\bar') == 'foo\\\\bar'
    assert regex_escape('foo^bar') == 'foo\\^bar'


# Generated at 2022-06-23 10:11:52.969359
# Unit test for function randomize_list
def test_randomize_list():
    import random
    assert randomize_list(range(10), seed=234) == randomize_list(range(10), seed=234)
    assert randomize_list(range(10)) != randomize_list(range(10))
    random.seed(234)
    assert randomize_list(range(10), seed=234) == list(random.sample(range(10), 10))


# Generated at 2022-06-23 10:12:02.534672
# Unit test for function rand
def test_rand():
    for test_val in [rand, partial(rand, seed=1)]:
        assert test_val([1, 2, 3]) in [1, 2, 3]
        assert test_val(10) in list(range(10))
        assert test_val(3, 6) in [3, 4, 5, 6]
        assert test_val(0, 10, 2) in [0, 2, 4, 6, 8, 10]
        assert test_val(0, 10, step=2) in [0, 2, 4, 6, 8, 10]
        assert test_val(1, end=3, step=2) in [1, 3]
        assert test_val(end=3, step=2) in [0, 2]
        assert test_val(1, 3, 2) in [1, 3]
        assert test

# Generated at 2022-06-23 10:12:13.698651
# Unit test for function extract
def test_extract():
    from ansible.errors import AnsibleUndefinedVariable
    from jinja2 import DictRuntimeUndefined

    r = extract(None, 'a', {'a': 'test'})
    assert r == 'test', r

    r = extract(None, 4, [1, 2, 3, 4, 5, 6])
    assert r == 5, r

    r = extract(None, 4, [1, 2, 3, 4, 5, 6], 2)
    assert r == 3, r

    r = extract(None, 'a', {}, 'b')
    assert isinstance(r, AnsibleUndefinedVariable), r

    r = extract(None, 'a', DictRuntimeUndefined('a', 'b'))
    assert r == DictRuntimeUndefined('a', 'b'), r

# Generated at 2022-06-23 10:12:23.003077
# Unit test for function to_yaml
def test_to_yaml():
    assert (to_yaml({"a": 1, "b": "2"}) == '{a: 1, b: "2"}\n')
    assert (to_yaml({"a": 1, "b": "2"}, default_flow_style=True) == "{a: 1, b: '2'}\n")
    assert (to_yaml({"a": 1, "b": "2"}, default_flow_style=False) == '{a: 1, b: "2"}\n')



# Generated at 2022-06-23 10:12:24.537961
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None



# Generated at 2022-06-23 10:12:33.584244
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d", 0) == "1970-01-01"
    assert strftime("%Y%m%d-%H%M%S", 0) == "19700101-000000"
    assert strftime("%Y%m%d-%H%M%S", 0) == "19700101-000000"
    assert strftime("%Y%m%d-%H%M%S", 1000000000) == "2000-09-26-163800"



# Generated at 2022-06-23 10:12:45.533057
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
  from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
  assert to_nice_yaml([1, 2]) == "[1, 2]\n"
  assert to_nice_yaml(dict(a=1, b=2)) == "{a: 1, b: 2}\n"
  assert to_nice_yaml(dict(a=1, b=2), indent=8) == "{a: 1, b: 2}\n"
  assert to_nice_yaml(dict(a=dict(aa=1), b=2)) == "{a: {aa: 1}, b: 2}\n"
  assert to_nice_yaml(dict(a=dict(aa=1), b=2), indent=8) == "{a: {aa: 1}, b: 2}\n"

# Generated at 2022-06-23 10:12:54.999940
# Unit test for function regex_findall
def test_regex_findall():
    from ansible.module_utils import basic
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.template.jinja2 import AnsibleJ2Template
    args = dict(
        value=UnsafeProxy(u'Foo and foo, bar bar bar', is_text=True, cu=None),
        regex=u'bar',
    )
    kwargs = dict(
        multiline=False,
        ignorecase=False,
    )
    template = AnsibleJ2Template('{{ "Foo and foo, bar bar bar" | regex_findall("bar") }}')
    assert template.render({}) == '["bar", "bar", "bar"]'

# Generated at 2022-06-23 10:12:57.569718
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('1234', r'(\d+)', '\\1') == '1234'



# Generated at 2022-06-23 10:13:02.481539
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ds_test_utils import run_test_module
    failed, total = run_test_module(FilterModule, globals(), verbose=False)
    assert failed == 0, "failed to pass all tests"


if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-23 10:13:15.743865
# Unit test for function regex_findall
def test_regex_findall():

    # Findall with string
    find = regex_findall('abcdabcabcabcabcabcabcabcabcabc', 'abc')
    assert find == ['abc', 'abc', 'abc', 'abc', 'abc', 'abc', 'abc', 'abc']

    # Findall with list
    find = regex_findall(['abcd', 'abc', 'abc'], 'abc')
    assert find == ['abc', 'abc', 'abc']

    # Multiline
    find = regex_findall('abc\ndef', 'abc', multiline=True)
    assert find == ['abc', 'abc']

    # Multiline with list
    find = regex_findall(['abc\ndef'], 'abc', multiline=True)
    assert find == ['abc']

    # Ignorecase

# Generated at 2022-06-23 10:13:21.036016
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('.') == '\\.'
    assert regex_escape('foo', 'posix_basic') == 'foo'
    assert regex_escape('.', 'posix_basic') == '\\.'
    assert regex_escape('"foo.bar"') == '\\"foo\\.bar\\"'
    assert regex_escape('"foo.bar"', 'posix_basic') == '\\"foo\\.bar\\"'
    assert regex_escape('"foo.bar"', 'posix_extended') == '\\"foo\\.bar\\"'



# Generated at 2022-06-23 10:13:24.331109
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    '''
    This function tests the list_of_dict_key_value_elements_to_dict function
    '''

    assert list_of_dict_key_value_elements_to_dict([
        {"key": "one", "value": "1"},
        {"key": "two", "value": "2"},
        {"key": "three", "value": "3"}
    ]) == {"one": "1", "two": "2", "three": "3"}



# Generated at 2022-06-23 10:13:29.690795
# Unit test for function combine
def test_combine():
    import collections
    import datetime
    import json
    import uuid
    import types

    # create a dict object with some random example data

# Generated at 2022-06-23 10:13:40.313134
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # Test password encryptions, supported by passlib, we can check passwords returned by get_encrypted_password
    # with passlib and check for a valid password match
    import passlib

    # Test md5_crypt
    test_password = "abcdefghi"
    assert passlib.hash.md5_crypt.verify(test_password, get_encrypted_password(test_password, "md5")) is True

    # Test sha256_crypt
    # sha256_crypt.verify takes salt as the 3rd argument, that is the string after the first '$' in the hash returned
    # by get_encrypted_password

# Generated at 2022-06-23 10:13:48.551525
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'name', 'value': 'bob'}, {'key': 'age', 'value': 10}]
    result = list_of_dict_key_value_elements_to_dict(mylist)
    assert type(result) is dict, \
        "Returned type is '%s' instead of 'dict'" % type(result)
    assert 'name' in result and result['name'] == 'bob', \
        "Returned dict does not contain key 'name'"
    assert 'age' in result and result['age'] == 10, \
        "Returned dict does not contain key 'age'"



# Generated at 2022-06-23 10:13:50.915475
# Unit test for function quote
def test_quote():
    assert quote('test') == "test"
    assert quote('test\n') == "'test\n'"



# Generated at 2022-06-23 10:13:58.577469
# Unit test for function path_join
def test_path_join():
    assert path_join('../some/file') == '../some/file'
    assert path_join(['../some', 'file']) == '../some/file'
    assert path_join(('../some', 'file')) == '../some/file'
    assert path_join(u'../some/file') == '../some/file'



# Generated at 2022-06-23 10:14:04.386492
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3, [4, 5, [6, 7], []]]) == [1, 2, 3, 4, 5, 6, 7]
    assert flatten([1, 2, 3, [4, 5, [6, 7], []]], levels=1) == [1, 2, 3, 4, 5, [6, 7], []]
    assert flatten([1, 2, 3, [4, 5, [6, 7], []]], levels=2) == [1, 2, 3, 4, 5, 6, 7]
    assert flatten(['a', [], 'b'], skip_nulls=False) == ['a', None, 'b']
    assert flatten(['a', [], 'b'], skip_nulls=True) == ['a', 'b']



# Generated at 2022-06-23 10:14:15.148357
# Unit test for function flatten
def test_flatten():
    assert flatten([0, 1, 2]) == [0, 1, 2]
    assert flatten([0, [1, 2]]) == [0, 1, 2]
    assert flatten([0, [[1], 2]]) == [0, [1], 2]
    assert flatten([0, [[1], 2], 3]) == [0, [1], 2, 3]
    assert flatten([0, [1, [2, 3, [4, 5]]]]) == [0, 1, 2, 3, [4, 5]]
    assert flatten([[0, 1], 2, [3, 4], [5, [6, 7]], 8, 9, 10]) == [0, 1, 2, 3, 4, 5, [6, 7], 8, 9, 10]

# Generated at 2022-06-23 10:14:24.998033
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'fo') == 'fo'
    assert regex_search('foo', r'(fo)') == 'fo'
    assert regex_search('foo', r'(fo)+') == 'fo'
    assert regex_search('hello world', r'world') == 'world'
    assert regex_search('hello world', r'world', '\\g<0>') == 'world'
    assert regex_search('hello world', r'hello (\w+)', '\\1') == 'world'
    assert regex_search('hello world', r'hello (\w+)', '\\g<1>') == 'world'
    assert regex_search('hello world', r'hello (?P<who>\w+)', '\\g<who>') == 'world'

# Generated at 2022-06-23 10:14:31.111580
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(u'string') == u'string\n...\n'
    assert to_yaml(u'test\\ttest') == u'test\\ttest\n...\n'
    assert to_yaml(u'\"test\"') == u'"test"\n...\n'
    assert to_yaml(u'\"test') == u'"test"\n...\n'
    assert to_yaml(u"test'") == u"test'\n...\n"
    assert to_yaml({u'a': 5, u'b': 6}) == u'{a: 5, b: 6}\n...\n'

# Generated at 2022-06-23 10:14:39.031794
# Unit test for function from_yaml_all
def test_from_yaml_all():
    yaml_str = """
- thing1: value
- thing2: value
"""
    correct_list = [{"thing1": "value"}, {"thing2": "value"}]
    assert from_yaml_all(yaml_str) == correct_list
    # Test that yaml_str is not modified by from_yaml_all
    assert yaml_str == """
- thing1: value
- thing2: value
"""


# Generated at 2022-06-23 10:14:42.204105
# Unit test for function strftime
def test_strftime():
    assert strftime("Hello %Y") == time.strftime("Hello %Y")
    assert strftime("Hello %Y", second='1433547522.5') == time.strftime("Hello %Y", time.localtime('1433547522.5'))


# Generated at 2022-06-23 10:14:51.477232
# Unit test for function strftime
def test_strftime():
    import datetime
    now = datetime.datetime.now()
    assert strftime("%Y-%m-%d") == now.strftime("%Y-%m-%d")
    assert strftime("%Y-%m-%d %H:%M:%S") == now.strftime("%Y-%m-%d %H:%M:%S")
    assert strftime("%Y-%m-%d %H:%M:%S", 0) == time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(0))



# Generated at 2022-06-23 10:14:56.913467
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("test", "sha1") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert get_hash("test", "sha256") == "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
    assert get_hash("test", "md5") == "098f6bcd4621d373cade4e832627b4f6"


# Generated at 2022-06-23 10:15:02.014409
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("c3VyZm9yZg==") == "surforge"
    assert b64decode("c3VyZm9yZg==", encoding="ascii") == "surforge"
    assert b64decode("c3VyZm9yZg==", encoding="utf-8") == "surforge"
    assert b64decode("c3U=", encoding="utf-8") == "su"
    # This is the only case which is different on Python 2 and 3
    # Python 2 expect an UTF-8 encoded string but returns a string of
    # bytes. Python 3 expects a string of bytes and returns an UTF-8 encoded
    # string.
    # This is because b64decode() on Python 2 and 3 need a string of bytes as
    # argument, not a UTF-8 encoded

# Generated at 2022-06-23 10:15:05.251790
# Unit test for function regex_findall
def test_regex_findall():
    assert ['ab'] == regex_findall('abc', 'ab')
    assert ['ab'] == regex_findall('abc', 'ab', ignorecase=True)
    assert [] == regex_findall('abc', 'bd')



# Generated at 2022-06-23 10:15:12.409457
# Unit test for function flatten
def test_flatten():
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-23 10:15:18.753383
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    test_list = \
        [
            {
                'key': 'k1',
                'value': 'v1'
            },
            {
                'key': 'k2',
                'value': 'v2'
            }
        ]
    expected_result = \
        {
            'k1': 'v1',
            'k2': 'v2'
        }
    assert list_of_dict_key_value_elements_to_dict(test_list) == expected_result



# Generated at 2022-06-23 10:15:24.780655
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != randomize_list([1, 2, 3, 4, 5], seed=1)
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == randomize_list([1, 2, 3, 4, 5], seed=1)
    assert randomize_list([1, 2, 3, 4, 5]) != randomize_list([1, 2, 3, 4, 5])



# Generated at 2022-06-23 10:15:33.742766
# Unit test for function combine
def test_combine():
    assert combine(dict(a=42, b=43, c=44)) == dict(a=42, b=43, c=44)
    assert combine(dict(b=43), dict(a=42, b=43, c=44)) == dict(a=42, b=43, c=44)
    assert combine(dict(a=42, c=44), dict(a=42, b=43, c=44)) == dict(a=42, b=43, c=44)
    assert combine(dict(a=42, b=43, c=44), dict(a=42, b=43, c=44)) == dict(a=42, b=43, c=44)