

# Generated at 2022-06-25 09:09:47.176344
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = {'a': {'b': 1, 'c': 2}, 'b': 2}
    result = to_nice_yaml(a)
    assert result == '''{a: {b: 1, c: 2}, b: 2}
'''

    a = {'a': {'b': {'c': 'd'}}}
    result = to_nice_yaml(a)
    assert result == '''{a: {b: {c: d}}}
'''



# Generated at 2022-06-25 09:09:56.165428
# Unit test for function regex_search
def test_regex_search():
    testcase = ["hello world hello world hello world", "hello world (hello world) hello world", "hello world hello world", "hello world, hello world", "hello world\nhello world\nhello world", "hello world\nhello world\n", "hello world\nhello world\nhello world\nhello world", "hello world\nhello world\nhello world\n", "hello world\nhello world\n\n", "hello world\nhello world\n\nhello world", "hello world\nhello world\n\nhello world\nhello world", "hello world\nhello world\n\nhello world\n", "hello world\nhello world\n\nhello world\n\n", "hello world", "hello world\n", "hello world\n\n", "hello world\nhello world"]

    ret = []

# Generated at 2022-06-25 09:10:08.587683
# Unit test for function combine
def test_combine():
    dictionaries = [{'a': 'foo'}, {'a': 'bar'}]
    result = combine(dictionaries)
    assert result == {'a': 'foo'}
    dictionaries = [{'a': 'foo'}, {'b': {'a': 'bar'}}]
    result = combine(dictionaries)
    assert result == {'a': 'foo', 'b': {'a': 'bar'}}
    dictionaries = [{'a': 'foo'}, {'b': {'a': {'c': 'bar'}}}, {'b': {'a': [1, 2, 3]}}]
    result = combine(dictionaries, recursive=True)
    assert result == {'a': 'foo', 'b': {'a': {'c': 'bar'}}}

# Generated at 2022-06-25 09:10:10.380828
# Unit test for function fileglob
def test_fileglob():
    fg = fileglob()
    assert fg == '9wO^q)uYJ\t9-mR:b*'



# Generated at 2022-06-25 09:10:11.804156
# Unit test for function mandatory
def test_mandatory():
    args = {"a": "a"}
    res = mandatory(**args)
    print(res)


# Generated at 2022-06-25 09:10:15.092108
# Unit test for function subelements
def test_subelements():
    print('Testing function subelements')
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements = 'groups'
    output = subelements(obj, subelements)
    print("Output:")
    print(output)
    return output


# Generated at 2022-06-25 09:10:16.620881
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements(obj, 'groups')


# Generated at 2022-06-25 09:10:18.985585
# Unit test for function fileglob
def test_fileglob():
    fileglob_1 = fileglob()
    print(fileglob_1)
    assert fileglob_1 != None, "Return value should not be empty"


# Generated at 2022-06-25 09:10:26.657782
# Unit test for function strftime
def test_strftime():
    from re import match as re_match
    assert strftime("%Y-%m-%d %H:%M:%S") == time.strftime("%Y-%m-%d %H:%M:%S")
    assert strftime("%Y-%m-%d %H:%M:%S", second=1234) == time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(1234))
    if sys.version_info.major >= 3:
        assert re_match("\d{4}-\d{2}-\d{2}", strftime("%Y-%m-%d"))
        assert re_match("\d{2}:\d{2}:\d{2}", strftime("%H:%M:%S"))

# Generated at 2022-06-25 09:10:32.799155
# Unit test for function regex_escape
def test_regex_escape():
    res = regex_escape('[a-z.*]', 'python')
    assert(res == r'\[a\-z\.\*\]')
    res = regex_escape('[a-z.*]', 'posix_basic')
    assert(res == r'\[a\-z\.*\]')
    res = regex_escape('[a-z.*]', 'posix_extended')
    assert(res == r'\[a\-z\.\*\]')


# Generated at 2022-06-25 09:10:53.016865
# Unit test for function subelements
def test_subelements():
    obj = [
        {
            "name": "alice",
            "groups": [
                "wheel"
            ],
            "authorized": [
                "/tmp/alice/onekey.pub"
            ]
        }
    ]
    subelements(obj, 'groups')



# Generated at 2022-06-25 09:10:54.462073
# Unit test for function extract
def test_extract():
    var_0 = extract()


# Generated at 2022-06-25 09:11:00.667957
# Unit test for function fileglob
def test_fileglob():
    try:
        fileglob_test = fileglob
    except NameError:
        fileglob_test = None
    assert fileglob_test
    assert fileglob_test(), "test_case_0"



# Generated at 2022-06-25 09:11:02.118130
# Unit test for function flatten
def test_flatten():
    assert(flatten([1, 2, 3]) == [1, 2, 3])


# Generated at 2022-06-25 09:11:04.863496
# Unit test for function fileglob
def test_fileglob():
    # test_case_0
    f = open("fileglob.yml",'w')
    var = fileglob("[a-z]")
    f.write(var)
    f.close()


# Generated at 2022-06-25 09:11:05.827875
# Unit test for function fileglob
def test_fileglob():
    assert fileglob(pathname)


# Generated at 2022-06-25 09:11:16.017291
# Unit test for function do_groupby
def test_do_groupby():
    import ansible.template.safe_eval
    # Test case 0
    var_0 = 'a'
    var_1 = 'b'
    var_2 = 'c'
    var_3 = [var_0, var_1, var_2]
    var_4 = 'key'
    var_5 = [{var_4 : var_0}, {var_4 : var_1}, {var_4 : var_2}, {var_4 : var_0}, {var_4 : var_1}, {var_4 : var_2}]

# Generated at 2022-06-25 09:11:20.145028
# Unit test for function do_groupby
def test_do_groupby():
    var_0 = do_groupby()


# Generated at 2022-06-25 09:11:22.862297
# Unit test for function do_groupby
def test_do_groupby():
    # Test case 0
    var_0 = [{'group': 'g1', 'value': 'vi'}, {'group': 'g1', 'value': 'v1'}, {'group': 'g2', 'value': 'v2'}]
    var_1 = 'group'
    test_case_0(var_0, var_1)



# Generated at 2022-06-25 09:11:24.288026
# Unit test for function strftime
def test_strftime():
    '''test_strftime.py'''
    var_0 = strftime(string_format='%Y-%m-%d %H:%M:%S', second=0)
    assert var_0 == '1970-01-01 00:00:00'


# Generated at 2022-06-25 09:11:39.349694
# Unit test for function to_bool
def test_to_bool():
    if to_bool(1) != True:
        return False

    if to_bool('True') != True:
        return False

    if to_bool('true') != True:
        return False

    if to_bool('yes') != True:
        return False

    if to_bool('Yes') != True:
        return False

    if to_bool('on') != True:
        return False

    if to_bool('ON') != True:
        return False

    if to_bool(0) != False:
        return False

    if to_bool('false') != False:
        return False

    if to_bool('False') != False:
        return False

    if to_bool('no') != False:
        return False

    if to_bool('No') != False:
        return False


# Generated at 2022-06-25 09:11:51.139040
# Unit test for function fileglob
def test_fileglob():
    os.chdir('/home/gridsan/groups/Duke_Ansible/Projects/ansible/playbook/roles/test_role/tests/')
    var_0 = list()
    var_1 = fileglob('Dockerfile.j2')
    var_0.append(var_1)
    var_1 = fileglob('files/zlib.sh')
    var_0.append(var_1)
    var_1 = fileglob('tasks/main.yml')
    var_0.append(var_1)
    var_1 = fileglob('templates/Dockerfile.j2')
    var_0.append(var_1)
    var_1 = fileglob('templates/zlib.sh.j2')

# Generated at 2022-06-25 09:12:01.564345
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'test': ['a', 'b', 'c']}) == "test:\n" + "    - a\n" + "    - b\n" + "    - c\n"
    assert to_nice_yaml({'test': 'test'}) == "test: test\n"
    assert to_nice_yaml({'test': u'\u2022'}) == u"test: \u2022\n"
    assert to_nice_yaml({'test': u'\u2022'}, allow_unicode=False) == "test: '\\u2022'\n"
    assert to_nice_yaml([1,2,3]) == "- 1\n" + "- 2\n" + "- 3\n"

# Generated at 2022-06-25 09:12:02.819191
# Unit test for function fileglob
def test_fileglob():
    var_0 = os.path.isfile()


# Generated at 2022-06-25 09:12:04.512607
# Unit test for function do_groupby
def test_do_groupby():
    var_0 = fileglob()
    test_val = do_groupby(var_0)
    # Checks if expected result matches our computed result
    assert test_val == test_val


# Generated at 2022-06-25 09:12:06.806385
# Unit test for function fileglob
def test_fileglob():
    assert True


# Generated at 2022-06-25 09:12:10.917876
# Unit test for function do_groupby
def test_do_groupby():
    dict1 = dict(b='val1', a='val2', c='val3')
    dict2 = dict(b='val1', d='val2', e='val3')
    dict3 = dict(b='val1', e='val2', f='val3')
    list_of_dicts = [dict1, dict2, dict3]

    for my_dict in list_of_dicts:
        for k, v in my_dict.items():
            if k == 'b':
                res_dict = {'gk': v}
                res_dict.update(my_dict)
                print(res_dict)
            print(k)

# Unit test

# Generated at 2022-06-25 09:12:13.313309
# Unit test for function randomize_list
def test_randomize_list():
    r = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    r_test = randomize_list(r, 'ansible')
    print(r_test)



# Generated at 2022-06-25 09:12:20.992725
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('somestring', 'ome') == 'ome'
    assert regex_search('somestring', '^s(ome)') == 'ome'
    assert regex_search('somestring', '^s(ome)', '\\1') == 'ome'
    assert regex_search('somestring', '^s(ome)', '\\g<1>') == 'ome'
    assert regex_search('somestring', '^s(o(me))', '\\1', '\\2') == ['ome', 'me']
    assert regex_search('somestring', '^s(o(me))', '\\g<1>', '\\g<2>') == ['ome', 'me']

# Generated at 2022-06-25 09:12:25.157950
# Unit test for function get_hash
def test_get_hash():
    var_1 = b'\x02\x02\x02\x02\x02\x02'
    res = get_hash(var_1)
    ans = '96e8ef55c522d9f9ddc0f1f8208cf5c6818103f5'
    assert res == ans, "Test case 0 failed: <{}> != <{}>".format(res, ans)
    pass

# Generated at 2022-06-25 09:12:35.976940
# Unit test for function do_groupby
def test_do_groupby():
    env = Environment()
    env.filters['groupby'] = do_groupby
    template = Template("""{% set foo = [{'name': 'alice', 'uid': '1003'}, {'name': 'bob', 'uid': '1004'}, {'name': 'carol', 'uid': '1005'}] | groupby('uid') %}
{{ foo | map('reject', attribute='key') | list | first(attribute='name') | sort }}""", environment=env)
    output = 'alice carol bob'
    assert output == template.render()


# Generated at 2022-06-25 09:12:42.662544
# Unit test for function do_groupby
def test_do_groupby():
    ansible_result = True

    # Testing with valid String / no args
    var_s = b'This is a test string'
    var_s = to_native(var_s)
    var = do_groupby(ansible_result, var_s, None)

# Generated at 2022-06-25 09:12:43.928034
# Unit test for function strftime
def test_strftime():
    # TODO: Fix time format parameter so this test works correctly
    # example_strftime = strftime(string_format, second=None)
    # assert example_strftime == "expected"
    assert 1 == 1


# Generated at 2022-06-25 09:12:53.531224
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory()
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'
    try:
        mandatory(msg='Custom error msg')
    except AnsibleFilterError as e:
        assert str(e) == 'Custom error msg'



# Generated at 2022-06-25 09:12:55.251338
# Unit test for function do_groupby
def test_do_groupby():
    # Test if the result of function do_groupby matches the expected one.
    var_0 = do_groupby()

# Generated at 2022-06-25 09:13:02.694971
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory(1)

# Generated at 2022-06-25 09:13:03.968877
# Unit test for function fileglob
def test_fileglob():
    result = fileglob()
    assert result is None, 'Expected None'



# Generated at 2022-06-25 09:13:09.177307
# Unit test for function to_bool
def test_to_bool():
    some_str = 'yes'
    assert to_bool(some_str)
    some_str = 'no'
    assert not to_bool(some_str)

    some_bool = True
    assert to_bool(some_bool)
    some_bool = False
    assert not to_bool(some_bool)

    some_int = 0
    assert not to_bool(some_int)
    some_int = 1
    assert to_bool(some_int)



# Generated at 2022-06-25 09:13:12.738137
# Unit test for function subelements
def test_subelements():
    # Input parameters
    obj = []
    subelements = ''
    skip_missing = False
    # Expected return value
    expected = ''
    # Actual return value
    actual = subelements(obj, subelements, skip_missing)
    # Unit test assertion
    assert expected == actual


# Generated at 2022-06-25 09:13:17.394046
# Unit test for function to_yaml
def test_to_yaml():
    var_0 = {'key1': {'key1': 'value1', 'key2': ['value_list_0', 'value_list_1']}, 'key2': {'key3': 'value3', 'key4': ['value_list_0', 'value_list_1']}}
    dummy_0 = to_yaml(var_0)
    display.info("Dummy_0[key1][key2][0] is {1}".format(var_0, dummy_0))


# Generated at 2022-06-25 09:13:35.893718
# Unit test for function comment
def test_comment():
    start_time = time.time()

    # Case 0:
    # Input:
    text = "You can use the comment filter to add comments to a template. For example, the following example shows how to add a general comment: {{ \"This is a comment.\" | comment }} The output is: {# This is a comment. #} In addition to {# plain #} comments, Ansible supports adding comments in several other styles. For example, the XML comment filter looks like this: {{ \"This is a comment.\" | comment(style=\"xml\") }} It produces the following output: <!-- This is a comment. --> Other comment styles include Erlang, C, and C-style blocks. To see the complete list of available styles, run the following command: ansible-doc jinja2.comment The examples in this section assume that you have the following variables defined in a playbook: "

# Generated at 2022-06-25 09:13:37.188897
# Unit test for function do_groupby
def test_do_groupby():
    result = do_groupby({}, )
    assert result is None


# Generated at 2022-06-25 09:13:41.062436
# Unit test for function fileglob
def test_fileglob():
    var_1 = "test_data/test_fileglob/test_fileglob_test.txt"
    var_1 = fileglob(var_1)
    var_1 = to_nice_yaml(var_1)
    print(var_1)
    assert var_1 == '[ test_data/test_fileglob/test_fileglob_test.txt ]\n'



# Generated at 2022-06-25 09:13:48.592730
# Unit test for function regex_search
def test_regex_search():
    # Test method with a valid argument
    try:
        value = 'test01'
        regex = 'test01'
        assert regex_search(value, regex, '\\g<1>') == 'test01'
    except Exception as e:
        print("test_regex_search - FAILED")
        raise

    print("test_regex_search - SUCCESS")



# Generated at 2022-06-25 09:13:49.815495
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()


# Generated at 2022-06-25 09:13:52.732693
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/boot/*.conf') == ['/boot/grub.cfg', '/boot/grub2.cfg']


# Generated at 2022-06-25 09:13:55.751820
# Unit test for function extract
def test_extract():
    var_0 = {"big": "small"}
    var_1 = extract("big", var_0)

# Generated at 2022-06-25 09:14:06.851272
# Unit test for function do_groupby
def test_do_groupby():
    # Test for do_groupby with argument value=var_0 and attribute=var_1
    var_0 = ['1', '2', '2', '3', '3', '3']
    var_1 = "len"
    assert do_groupby(var_0, var_1) == [['2', '2'], ['3', '3', '3'], ['1']]
    # Test for do_groupby with argument value=var_0 and attribute=var_1
    var_0 = ['2', '2', '3', '1', '1']
    var_1 = "len"
    assert do_groupby(var_0, var_1) == [['2', '2'], ['1', '1'], ['3']]
    # Test for do_groupby with argument value=var_0 and attribute

# Generated at 2022-06-25 09:14:13.392170
# Unit test for function rand
def test_rand():
    """Test rand function"""
    try:
        # Test case for rand function.
        test_case_0()
    except Exception as e:
        print (e)
    finally:
        print ("Test case for rand function done successfully")


# Generated at 2022-06-25 09:14:15.752655
# Unit test for function mandatory
def test_mandatory():
    assert to_native(mandatory(None, msg="msg")) == "msg"
    assert to_native(mandatory(0, msg="msg")) == 0



# Generated at 2022-06-25 09:14:30.206218
# Unit test for function fileglob
def test_fileglob():
    mock_path = "/home/ansible/test"
    ansible_file_type = ['test_config.txt', 'test_config.yml', 'test_config.yaml', 'test_config.json','test_config.conf']
    for files_type in ansible_file_type:
        files = str(mock_path)+'/'+str(files_type)
        list_of_files= fileglob(files)
        print("Files",list_of_files)
        if '*.txt' in files:
            print("Expected output is ", files_type, "Actual output is", list_of_files)
        else:
            print("Expected output is ", [], "Actual output is", list_of_files)


# Generated at 2022-06-25 09:14:31.238750
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()


# Generated at 2022-06-25 09:14:39.211506
# Unit test for function subelements
def test_subelements():
    # Given
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements = "groups"

    # When
    result = subelements(obj, subelements)

    # Then
    assert result == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]


# Generated at 2022-06-25 09:14:50.788906
# Unit test for function comment
def test_comment():

    import textwrap
    import pprint

    # ----------------------------
    # Default
    # ----------------------------
    # Simple comment
    default_text = "This is a simple text"
    assert comment(default_text) == "# This is a simple text"

    # Multiline comment
    default_text = "This is a simple\nmultiline text"
    assert comment(default_text) == "# This is a simple\n# multiline text"

    # ----------------------------
    # C-style
    # ----------------------------
    # Simple comment
    c_text = "This is a simple text"
    assert comment(c_text, style='c') == "// This is a simple text"

    # Multiline comment
    c_text = "This is a simple\nmultiline text"

# Generated at 2022-06-25 09:14:56.019348
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.tests import TemplateTestCase
    from jinja2_ansible_filters import AnsibleJ2Plugin

    import unittest

    class DoGroupbyTestCase(TemplateTestCase):
        def setUp(self):
            super(DoGroupbyTestCase, self).setUp()
            self.env = Environment(extensions=[AnsibleJ2Plugin])


# Generated at 2022-06-25 09:14:56.819163
# Unit test for function do_groupby
def test_do_groupby():
    var_0 = do_groupby()


# Generated at 2022-06-25 09:15:01.150640
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("*.txt") == ['test.txt']


# Generated at 2022-06-25 09:15:13.375214
# Unit test for function subelements
def test_subelements():
    from ansible.compat import six

    # Test 1
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements = 'groups'
    ret = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, subelements) == ret

    # Test 2
    obj1 = [{
        'a': {
            'b': {
                'c': [{
                    'd': 'e',
                    'f': 'g'
                }]
            }
        }
    }]
    subelements1 = 'a.b.c'

# Generated at 2022-06-25 09:15:25.405111
# Unit test for function comment
def test_comment():
    # All the default parameters
    assert comment('This is a sample text.') == '# This is a sample text.'

    # Custom decorator
    assert comment('This is a sample text.',
                   decoration='~ ') == '~ This is a sample text.'

    # Prefix count
    assert comment('This is a sample text.',
                   prefix_count=2) == '# \n# This is a sample text.'

    # Postfix count
    assert comment('This is a sample text.',
                   postfix_count=2) == '# This is a sample text.\n# '

    # Extra empty line in the end
    assert comment('This is a sample text.',
                   postfix_count=2,
                   postfix='\n') == '# This is a sample text.\n# \n'

    # End string
   

# Generated at 2022-06-25 09:15:32.160079
# Unit test for function subelements
def test_subelements():

    # Test 1
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements = 'groups'
    expected_result = "ERROR"
    actual_result = subelements(obj, subelements, skip_missing=True)
    print(actual_result)
    print('expected_result: {}'.format(expected_result))
    print('actual_result: {}'.format(actual_result))
    print('invoke jinja2 template:')
    actual_result_jinja2 = subelements(obj, subelements, skip_missing=True)
    print(actual_result_jinja2)
    print('expected_result: {}'.format(expected_result))

# Generated at 2022-06-25 09:15:37.700494
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()



# Generated at 2022-06-25 09:15:50.509960
# Unit test for function do_groupby
def test_do_groupby():
    """ Unit test for do_groupby filter in ansible filters/jinja2_filters.py

    Checks that we return nothing on no-arg call
    Checks that list with no args returns same list
    Checks that dict with no args returns same dict
    Checks that list-of-dicts with no args returns same list
    Checks that list-of-dicts with a key returns an aggregated list
    Checks that list-of-dicts with key that doesn't exist returns empty list
    Checks that list-of-dicts with bad key returns an empty list
    """
    from collections import namedtuple

    # Setup some test data

# Generated at 2022-06-25 09:15:59.675846
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    from ansible.module_utils.six import PY3
    import uuid
    fake_uuid = uuid.UUID('4de4a0bd-e2e1-4cff-a595-404489923963')
    if PY3:
        from collections.abc import Mapping
    else:
        from collections import Mapping

    test_var = 'test_val'
    test_dict = {'test': 'test_val'}
    test_list = ['test_val']
    test_int = 1
    test_float = 1.5
    test_bool = True
    test_none = None
    test_undefined = Undefined()

    # Test successful application of 'mandatory' filter

# Generated at 2022-06-25 09:16:03.478995
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo", "bar") is None



# Generated at 2022-06-25 09:16:04.286964
# Unit test for function combine
def test_combine():
    var_0 = combine()


# Generated at 2022-06-25 09:16:06.914049
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()
    assert(bool(filters))
    for k,v in filters.items():
        assert(isinstance(k, (str, unicode)))
        assert(isinstance(v, (partial, types.FunctionType)))


# Generated at 2022-06-25 09:16:13.074488
# Unit test for function fileglob
def test_fileglob():
    var_0 = fileglob("/home/smbuser/smb/ansible/myfile")
    assert (len(var_0) == 1)
    assert (var_0[0] == "/home/smbuser/smb/ansible/myfile")



# Generated at 2022-06-25 09:16:25.199903
# Unit test for function subelements
def test_subelements():
    # Test Case 1
    # Test Case 2
    # Test Case 3
    test_case_1_obj = [{'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}]
    test_case_1_subelements = 'groups'
    test_case_1_expected = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

    # Verify that the test case worked
    print("")
    print("Test Case 1")
    print("----------")
    print("Obj: ", test_case_1_obj)
    print("Subelements: ", test_case_1_subelements)
    print("Expected: ", test_case_1_expected)

# Generated at 2022-06-25 09:16:30.117903
# Unit test for function get_hash
def test_get_hash():
    assert (get_hash("Hello World!") == "2ef7bde608ce5404e97d5f042f95f89f1c232871")
    assert (get_hash("Hello World!", hashtype="md5") == "ed076287532e86365e841e92bfc50d8c")


# Generated at 2022-06-25 09:16:33.284912
# Unit test for function regex_search
def test_regex_search():
    value = u"This is awesome"
    regex = u"(.*) is (.*)"
    args = []
    args.append(u'\g<2> \g<1>')
    print(regex_search(value, regex, *args))


# Generated at 2022-06-25 09:16:46.700249
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_0 = "var_0"
    var_1 = "var_1"
    var_2 = "var_2"
    var_3 = "var_3"
    var_4 = {"var_4": {"var_4": "var_4"}}
    var_5 = {"var_5": {"var_5": "var_5"}}
    var_6 = {"var_6": {"var_6": "var_6"}}
    var_7 = "var_7"
    var_8 = "var_8"
    var_9 = "var_9"
    var_10 = "var_10"
    var_11 = "var_11"
    var_12 = "var_12"
    var_13 = "var_13"
    var_14 = "var_14"
   

# Generated at 2022-06-25 09:16:48.469612
# Unit test for function mandatory
def test_mandatory():
    try:
        var_0 = mandatory()
    except AnsibleFilterError as e:
        return True
    else:
        raise Exception('returned a non-false value: %s' % var_0)



# Generated at 2022-06-25 09:16:49.592828
# Unit test for function fileglob
def test_fileglob():
    assert fileglob(pathname="test") == None


# Generated at 2022-06-25 09:16:53.566935
# Unit test for function mandatory
def test_mandatory():
    try:
        # Do not pass value for mandatory parameter 'a'.
        mandatory()
    except TypeError:
        pass
    else:
        assert False, "expected an exception"


# Generated at 2022-06-25 09:17:03.032414
# Unit test for function mandatory
def test_mandatory():

    var_0 = mandatory(None)
    assert(var_0 is None), 'Failed to assert that var_0 is None'

    var_1 = mandatory(None, None)
    assert(var_1 is None), 'Failed to assert that var_1 is None'

    var_2 = mandatory('foo', None)
    assert(var_2 == 'foo'), "Failed to assert that var_2 is 'foo'"

    var_3 = mandatory(None, 'foo')
    assert(var_3 is None), 'Failed to assert that var_3 is None'

    var_4 = mandatory('foo', 'foo')
    assert(var_4 == 'foo'), "Failed to assert that var_4 is 'foo'"


# Generated at 2022-06-25 09:17:06.806768
# Unit test for function randomize_list
def test_randomize_list():
    var_0 = 0
    var_1 = ""
    var_2 = [var_0]

    if randomize_list(mylist=var_2) == var_2:
        var_1 = "Success"
    else:
        var_1 = "Failure"
    print("{} - randomize_list: {}".format(var_1, var_2))



# Generated at 2022-06-25 09:17:12.645007
# Unit test for function mandatory
def test_mandatory():

    from ansible.template import Templar

    template_results = False
    if template_results:
        t = Templar(loader=None, variables={})
        t.available_variables = { 'foo': 'bar' }

        assert t.template('{{ foo }}') == 'bar'
        try:
            t.template('{{ bar }}')
        except AnsibleFilterError as e:
            assert 'foo' in str(e)
        else:
            assert False, 'bar did not raise the expected error'


# Generated at 2022-06-25 09:17:22.516630
# Unit test for function comment
def test_comment():
    assert comment("blabla") == "# blabla"
    assert comment(" simple \n test", style='erlang') == "% simple\n% test"
    assert comment("simple\ntest", decoration='// ') == "// simple\n// test"
    assert comment("simple\ntest", style='c') == "// simple\n// test"
    assert comment(" simple \n test", style='cblock') == "/*\n * simple\n * test\n */"
    assert comment("simple\ntest", style='cblock') == "/*\n * simple\n * test\n */"
    assert comment(" simple \n test", style='cblock', prefix_count=2, decoration='-- ') == "/*\n * -- simple\n * -- test\n */"

# Generated at 2022-06-25 09:17:24.231852
# Unit test for function extract
def test_extract():
    assert(extract({'a': {'b': {'c': 'd'}}}, 'c', {'a': {'b': {'c': 'd'}}}) == 'd')


# Generated at 2022-06-25 09:17:27.352733
# Unit test for function fileglob
def test_fileglob():
    # Test case0
    var_0 = ['test.txt', 'test.py']
    assert fileglob('test*') == var_0, 'Failed fileglob test case0'



# Generated at 2022-06-25 09:17:32.844390
# Unit test for function regex_search
def test_regex_search():
    if regex_search(u'foo', u'foo'):
        return True
    else:
        return False


# Generated at 2022-06-25 09:17:39.076753
# Unit test for function fileglob
def test_fileglob():
    assert len(fileglob('/Users/kswamy/dev/msm-ansible/filter_plugins/*')) > 0
    assert len(fileglob('/Users/kswamy/dev/msm-ansible/filter_plugins/sdfsdfsdfsdfsdf')) == 0


# Generated at 2022-06-25 09:17:42.792317
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('any string') == 'any string'


# Generated at 2022-06-25 09:17:50.925969
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("abcdefg", "abc") == "abc"
    assert regex_search("aBcDeFg", "aBc", ignorecase=True) == "aBc"
    assert regex_search("abcdefg", "def") == "def"
    assert regex_search("ab defg", "def", multiline=True) == "def"
    assert regex_search("abcdefg", "^a") == "a"
    assert regex_search("abcdefg", "g$") == "g"
    assert regex_search("abcdefg", "^abc") == "abc"
    assert regex_search("abcdefg", "defg$") == "defg"
    assert regex_search("abcdefg", "(?P<name>abc)") == "abc"

# Generated at 2022-06-25 09:17:58.954065
# Unit test for function fileglob
def test_fileglob():
    def check(expected, pathname):
        result = fileglob(pathname)

        assert result == expected, \
            "expected %r, got %r" % (expected, result)

    check(['/etc/hosts'], '/etc/*')
    check(['/etc/hostsq'], '/etc/*q')
    check([], '/etc/hosts')
    check(['/etc/hosts'], '/etc/hosts')


# Generated at 2022-06-25 09:18:04.028280
# Unit test for function mandatory
def test_mandatory():

    # Test for simple case where the default argument is provided and should be returned
    if(mandatory() != None):
        print("Error in test_mandatory, test case #0")
    var_1 = "error"
    # Test for case where no argument is provided but one is required
    try:
        mandatory(var_1)
    except AnsibleFilterError as e:
        if(to_text(e) != "The ``mandatory`` filter requires at least one argument."):
            print("Error in test_mandatory, test case #1")



# Generated at 2022-06-25 09:18:09.123182
# Unit test for function do_groupby
def test_do_groupby():
    # Mocking jinja2.filters.do_groupby
    def mock_groupby(environment, value, attribute):
        return value
    # Mocking AnsibleModule to return an empty dict
    class EmptyAnsibleModule:
        params = dict()
    # Mocking ansible.utils.unsafe_proxy.AnsibleUnsafeText to return the value of what it's passed
    class UnsafeString:
        def __init__(self, text):
            self.text = text

        def __repr__(self):
            return repr(self.text)

    import sys
    import __builtin__
    # Mocking jinja2.filters.do_groupby to return value
    sys.modules['ansible'] = __builtin__
    __builtin__.__import__ = mock_groupby
    #

# Generated at 2022-06-25 09:18:11.745124
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None


# Generated at 2022-06-25 09:18:23.349500
# Unit test for function regex_search
def test_regex_search():
    if not os.path.isfile('/usr/bin/python'):
        print("SKIP: '/usr/bin/python' not found.")
        return True

    # No arguments
    var = regex_search("bar", "foo")

    # Invalid regex
    with pytest.raises(AnsibleFilterError):
        regex_search("bar", "(foo")

    # Ignoring case
    var = regex_search("fooBAR", "bar", ignorecase=True)

    # Multiline
    var = regex_search("foo\nbar", "bar", multiline=True)

    # Single backref
    var = regex_search("foo\nbar", "bar", "\\1")

    # Multi backref
    var = regex_search("foo\nbar", "bar", "\\1", "\\2")



# Generated at 2022-06-25 09:18:27.567021
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('Aaaaaaaaaa', 'A', '\\g<0>') == 'A'
    assert regex_search('Aaaaaaaaaa', 'a', '\\g<0>') == 'a'
    assert regex_search('Aaaaaaaaaa', 'a', '\\1') == 'a'
    assert regex_search('Aaaaaaaaaa', 'a', '\\2') == None
    assert regex_search('Aaaaaaaaaa', 'a', '\\g<2>') == None
    assert regex_search('Aaaaaaaaaa', 'a', '\\g<999>') == None



# Generated at 2022-06-25 09:18:36.966456
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("test.txt") == ["test.txt"], "File name is not same"
    assert fileglob("test.txt") != ["test.txt", "test.txt"], "File name is not same"


# Generated at 2022-06-25 09:18:46.401693
# Unit test for function mandatory
def test_mandatory():
    # Test with simple string param
    assert mandatory('test_string') == 'test_string'

    # Test with simple int param
    assert mandatory(15) == 15

    # Test with array param
    assert mandatory(['test_string', 'another_string']) == ['test_string', 'another_string']

    # Test with dict param
    assert mandatory({'key1': 'value1', 'key2': 'value2'}) == {'key1': 'value1', 'key2': 'value2'}

    # Test with None param
    try:
        mandatory(None)
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)
        assert e.message == "Mandatory variable 'None' not defined."



# Generated at 2022-06-25 09:18:54.254032
# Unit test for function regex_search
def test_regex_search():
    var_0 = 'a the quick brown fox jumped over the lazy dog'.split()
    expected_0 = ['the quick brown fox', 'the lazy dog']

# Generated at 2022-06-25 09:18:55.304798
# Unit test for function fileglob
def test_fileglob():
    var_0 = fileglob()
    print(var_0)



# Generated at 2022-06-25 09:18:59.418699
# Unit test for function do_groupby
def test_do_groupby():
    import json

    for test in tests:
        print (json.dumps({
                              "name": test["name"],
                              "data": do_groupby(test["data"], test["attribute"]),
                          }, indent=2))


# Generated at 2022-06-25 09:19:12.358598
# Unit test for function do_groupby
def test_do_groupby():
    f = do_groupby
    var_0 = [
        {'category': 'one', 'item': 'a'},
        {'category': 'two', 'item': 'b'},
        {'category': 'two', 'item': 'c'}
    ]
    var_1 = 'category'
    var_2 = [
        ('one', [{u'category': u'one', u'item': u'a'}]),
        ('two', [{u'category': u'two', u'item': u'b'}, {u'category': u'two', u'item': u'c'}])
    ]
    assert f(var_0, var_1) == var_2, "Failed do_groupby(var_0, var_1)"


# Generated at 2022-06-25 09:19:14.747916
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory()
    except TypeError as e:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 09:19:19.119226
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("Ahmed", "Ahmed") == 'Ahmed'
    assert regex_search("Ahmed", "Ahmed", '\\g<0>') == ['Ahmed']
    assert regex_search("Ahmed", "Ahmed", '\\0') == 'Ahmed'
    assert regex_search("I love apples", "I love (\w+)", '\\g<1>') == ['apples']


# Generated at 2022-06-25 09:19:25.811339
# Unit test for function extract
def test_extract():
    action_list = []
    # Test: input: {'container': 'dict', 'item': 'key', 'morekeys': ['a', 'b']}
    var = {'container': {'key': 'val'}, 'item': 'key', 'morekeys': [1, 1.1, '1']}
    action_list.append((var['container'], var['item'], var['morekeys'], 'val'))
    # Test: input: {'container': 'dict', 'item': 'key', 'morekeys': []}
    var = {'container': {'key': 'val'}, 'item': 'key', 'morekeys': []}
    action_list.append((var['container'], var['item'], var['morekeys'], 'val'))
    # Test: input: {'container': 'dict', '