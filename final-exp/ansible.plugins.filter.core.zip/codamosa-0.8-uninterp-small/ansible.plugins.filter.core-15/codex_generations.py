

# Generated at 2022-06-25 09:09:46.154493
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("Hello, world!", "^.*$", "Goodbye, world!") == "Goodbye, world!"
    assert regex_replace("Hello, world!", "^.*$", "Goodbye, world!", "True", "True") == "Goodbye, world!"


# Generated at 2022-06-25 09:09:54.171220
# Unit test for function fileglob
def test_fileglob():
    assert(fileglob("/Users/emile/git/ansible/lib/ansible/modules/cloud/amazon/ec2.py") == "/Users/emile/git/ansible/lib/ansible/modules/cloud/amazon/ec2.py")
    assert(fileglob("/Users/emile/git/ansible/lib/ansible/modules/cloud/amazon/s3.py") == "/Users/emile/git/ansible/lib/ansible/modules/cloud/amazon/s3.py")
    assert(fileglob("test") == "test")


# Generated at 2022-06-25 09:09:59.432603
# Unit test for function regex_escape
def test_regex_escape():
    var_0 = "Rajashree"
    print(var_0)
    var_1 = to_text(var_0)
    print(var_1)
    var_1 = re.escape(var_1)
    print("Escaped String: ", var_1)
    var_1 = regex_escape("Rajashree", re_type='python')
    print("Escaped String: ", var_1)
    var_1 = regex_escape("Rajashree", re_type='posix_basic')
    print("Escaped String: ", var_1)
    var_1 = regex_escape("Rajashree", re_type='posix_extended')
    print("Escaped String: ", var_1)


# Generated at 2022-06-25 09:10:03.800037
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(pattern=r"^(.*?)\s", value="test string") == "string"
    assert regex_replace(pattern=r"^(.*?)(\s)", replacement="\\2", value="test string") == " test"
    


# Generated at 2022-06-25 09:10:05.103454
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()


# Generated at 2022-06-25 09:10:14.819159
# Unit test for function regex_search
def test_regex_search():
    # Ensure that a regex matches the input and that the search function returns the correct value
    value = 'This string has two different words'
    regex = 'string'
    assert(regex_search(value, regex) == 'string')
    # Ensure that the ignorecase parameter picks up a match
    value = 'This string has two different words'
    regex = 'String'
    assert(regex_search(value, regex, ignorecase = True) == 'String')
    # Ensure that the correct keyword argument will be ignored
    value = 'This string has two different words'
    regex = 'String'
    assert(regex_search(value, regex, ignorecase = False) != 'String')
    # Ensure that the regex will always return a string if it matches
    value = 2
    regex = '^\d+$'

# Generated at 2022-06-25 09:10:23.126507
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1,2,3]) in ([1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,2,1],[3,1,2])
    assert randomize_list([1,2,3], seed='foo') in ([1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,2,1],[3,1,2])
    assert randomize_list([1,2,3], seed='foo') == ([1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,2,1],[3,1,2])[0]


# Generated at 2022-06-25 09:10:30.377641
# Unit test for function regex_search
def test_regex_search():
    # Test case for function regex_search
    # Perform re.search and return the list of matches or a backref
    # UNKNOWN ERROR: The first argument is of type 'unicode', but the variable is of type 'str'
    # UNKNOWN ERROR: The second argument is of type 're.Pattern', but the variable is of type 'str'
    print(regex_search(u"", "(\S+)", "\\1"))
    print(regex_search(u"", "a", "\\1"))
    print(regex_search(u"", "(\S+)", "\\g<1>"))
    print(regex_search(u"1", "(\S+)", "\\g<1>"))
    print(regex_search(u"1", "(\S+)", "\\1"))

# Generated at 2022-06-25 09:10:34.357134
# Unit test for function comment
def test_comment():
    for test in TEST_CASES:
        expected = test['expected']
        actual = comment(text=test['input'],
                         style=test['style'],
                         beginning=test.get('beginning'),
                         decoration=test.get('decoration'),
                         prefix=test.get('prefix'),
                         prefix_count=test.get('prefix_count'),
                         postfix=test.get('postfix'),
                         postfix_count=test.get('postfix_count'),
                         end=test.get('end'))
        print(test, "EXPECTED:", repr(expected), repr(actual))
        assert actual == expected



# Generated at 2022-06-25 09:10:38.094926
# Unit test for function regex_search
def test_regex_search():
    var_0 = regex_search("/Users/mrhandsome/ansible/test/test.txt", r"^\/Users\/(\w+)\/ansible\/")


# Generated at 2022-06-25 09:10:49.257108
# Unit test for function fileglob
def test_fileglob():
    print(fileglob('/home/vagrant/sample-inventory'))


# Generated at 2022-06-25 09:10:53.510972
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%y-%m-%d') == time.strftime('%y-%m-%d')
    assert strftime('%a, %B %d, %Y') == time.strftime('%a, %B %d, %Y')
    assert strftime('%c') == time.strftime('%c')
    assert strftime('%d.%m.%Y') == time.strftime('%d.%m.%Y')
    assert strftime('%I:%M:%S %p') == time.strftime('%I:%M:%S %p')
    assert strftime('%H:%M') == time.strftime('%H:%M')

# Generated at 2022-06-25 09:10:59.529856
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Perform some basic tests
    var_0 = FilterModule().filters()

# Generated at 2022-06-25 09:11:09.400021
# Unit test for function ternary
def test_ternary():
    print("-" * 20 + " START: test_ternary" + "-" * 20)
    var_x = "a"

    # when value is True
    var_ret = ternary(var_x, "a is True", "a is not True")
    print(var_ret)

    # when value is False
    var_ret = ternary(False, "a is True", "a is not True")
    print(var_ret)


    # Another way to use ternary function
    var_x = "b"
    var_ret = ternary(var_x, "a is True", "a is not True", "a is None")
    print(var_ret)
    print("-" * 20 + " END: test_ternary" + "-" * 20)


# Generated at 2022-06-25 09:11:13.280153
# Unit test for function fileglob
def test_fileglob():
    var_0 = fileglob("/etc/lsb-release")


# Generated at 2022-06-25 09:11:21.365037
# Unit test for function regex_search
def test_regex_search():
    print('Test begins')
    var_1 = regex_search('this is a test', r'\w+')
    var_2 = regex_search('this is a test', r'\w+', '\\g<0>')
    var_3 = regex_search('this is a test', r'\w+', '\\g<0>', '\\g<0>')
    var_4 = regex_search('this is a test', r'\w+', '\\g<0>', '\\1')
    var_5 = regex_search('this is a test', r'\w+', '\\1')

    var_6 = regex_search('Alternating case', r'AL\w+', ignorecase=True)
    var_7 = regex_search('Alternating case', r'AL\w+')
    var_8

# Generated at 2022-06-25 09:11:22.799944
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(1)
    except AnsibleFilterError as ex:
        assert ex.message == "Mandatory variable '1' not defined."


# Generated at 2022-06-25 09:11:30.095904
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}, {"name": "bob", "groups": ["wheel", "dev"], "authorized": ["/tmp/bob/onekey.pub", "/tmp/bob/twokey.pub"]}]
    subelements = 'groups'

# Generated at 2022-06-25 09:11:37.436048
# Unit test for function regex_escape
def test_regex_escape():
    string = "a.bc[de]f*h^ij$kl\\m(no)p?q{rs}t|uvw"
    escaped_string = regex_escape(string)
    if escaped_string == "a\\.bc\\[de\\]f\\*h\\^ij\\$kl\\\\m\\(no\\)p\\?q\\{rs\\}t\\|uvw":
        print("test_regex_escape: Success")
        return True
    else:
        print("test_regex_escape: Failure")
        return False



# Generated at 2022-06-25 09:11:42.825996
# Unit test for function fileglob
def test_fileglob():
    try:
        result = fileglob("/Users/vishnuk/test_invalid_file.txt")
        if result != None:
            print("test_fileglob - Passed")
        else:
            print("test_fileglob - Failed")
    except AnsibleFilterError:
        result = "Exception Caught"
        print("test_fileglob - Passed")


# Generated at 2022-06-25 09:11:53.045697
# Unit test for function fileglob
def test_fileglob():
    pass
    #assert fileglob('/home/honor/dev-ansible/lib/ansible/modules/system/setup.py') == ''


# Generated at 2022-06-25 09:12:03.119602
# Unit test for function regex_search
def test_regex_search():
    var_0 = regex_search('a', 'a', '\\g<1>')
    assert var_0 == 'a'
    var_1 = regex_search('a', 'a', '\\g<2>')
    assert var_1 == 'a'
    var_2 = regex_search('a', 'a', '\\0')
    assert var_2 == 'a'
    var_3 = regex_search('a', 'a', '\\1')
    assert var_3 == 'a'
    var_4 = regex_search('a1a2a3', 'a\d', '\\g<0>')
    assert var_4 == 'a1'
    var_5 = regex_search('a1a2a3', 'a\d', '\\0', '\\1')

# Generated at 2022-06-25 09:12:05.208612
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar

    test_case = {'foo': 'bar'}
    templar = Templar()
    t = templar.template(test_case, convert_bare=True)
    assert t == {'foo': 'bar'}



# Generated at 2022-06-25 09:12:08.617861
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('http://www.example.com', 'python') is not None
    assert combine(1, '', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None
    assert combine(1, ',', '') is not None



# Generated at 2022-06-25 09:12:15.510460
# Unit test for function comment
def test_comment():
    print(comment('Simple comment\nMultiline comment', style='c'))
    print(comment('Simple comment\nMultiline comment', style='cblock'))
    print(comment('Simple comment\nMultiline comment', decoration='//>>> ', style='plain'))
    print(comment('Simple comment\nMultiline comment', decoration='//>>> ', style='erlang', prefix='####'))
    print(comment('Simple comment\nMultiline comment', decoration='//>>> ', style='plain', prefix='####', prefix_count=2, postfix='@@@@', postfix_count=3, end='END'))
    print(comment('Simple comment', style='xml'))
    print(comment('Simple comment', style='xml', prefix='@@@'))

# Generated at 2022-06-25 09:12:25.788962
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    res = subelements(obj, "groups")
    assert isinstance(res, list)
    assert len(res) == 1
    assert res == [(obj[0], 'wheel')]

    # test failure modes
    obj = [{'a': {'b': {'c': ['d', 'e']}}}]
    # dotted path is not a list
    with pytest.raises(AnsibleFilterError):
        subelements(obj, "a.b.c.d")
    # dotted path's last element is not a list
    with pytest.raises(AnsibleFilterError):
        subelements(obj, "a.b.c")
    # missing element

# Generated at 2022-06-25 09:12:26.672614
# Unit test for function mandatory
def test_mandatory():
    var_1 = mandatory({})
    assert var_1 == {}


# Generated at 2022-06-25 09:12:29.441661
# Unit test for function randomize_list
def test_randomize_list():
    var_0 = randomize_list([1, 2, 3])
    assert var_0 == [1, 2, 3], "randomize_list() should return [1, 2, 3]"


# Generated at 2022-06-25 09:12:31.208122
# Unit test for function regex_search
def test_regex_search():
    in_str = "hello world"
    regex = "w.*d"
    assert regex_search(in_str, regex) == 'world'


# Generated at 2022-06-25 09:12:33.598376
# Unit test for function extract
def test_extract():
    var_0 = extract('1', {'a': {'b': {'1': 'unit test value'}}})


# Generated at 2022-06-25 09:12:42.771241
# Unit test for function mandatory
def test_mandatory():
    # Ensure that a variable must be defined

    # Test with the following values:
    # a = default
    # msg = None
    mandatory('default', 'default')

    result = mandatory('default', None)
    assert result == 'default'
    result = mandatory('default', None)
    assert result == 'default'


# Generated at 2022-06-25 09:12:46.455110
# Unit test for function get_hash
def test_get_hash():
    test_data = "test123"
    print(get_hash(test_data, 'md5'))
    print(get_hash(test_data, 'sha1'))
    print(get_hash(test_data, 'sha256'))


# Generated at 2022-06-25 09:12:54.539430
# Unit test for function subelements
def test_subelements():
    # Test 1
    obj = [{'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}]
    assert(subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')])


# Generated at 2022-06-25 09:12:57.128043
# Unit test for function mandatory
def test_mandatory():
    # Set up mock object
    class Undefined():
        _undefined_name = None

    # Test case with valid values
    var_0 = mandatory(Undefined(), msg="")
    assert var_0 is None
# End of unit test



# Generated at 2022-06-25 09:13:07.350200
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("find this", "find this") == "find this"
    assert regex_search("find this", "this", "\\g<1>") == "find"
    assert regex_search("find this", "\\bthis", "\\g<1>") == "find"
    assert regex_search("find this this", "this", "\\g<1>") == "find"
    assert regex_search("find (this) this", "\\((this)\\)", "\\g<1>") == ["this"]


# Generated at 2022-06-25 09:13:13.492227
# Unit test for function mandatory
def test_mandatory():
    # Test case 0
    try:
        assert test_case_0()
        print('OK')
    except Exception:
        print('ERROR')
    # Test case 1
    try:
        assert test_case_1()
        print('OK')
    except Exception:
        print('ERROR')



# Generated at 2022-06-25 09:13:22.877264
# Unit test for function do_groupby

# Generated at 2022-06-25 09:13:24.673577
# Unit test for function fileglob
def test_fileglob():
    var_0 = fileglob('/Users/nathan/ansible/demo_playbook/demo_playbook/roles/flask/files/server.pem')
    print(var_0)


# Generated at 2022-06-25 09:13:26.458742
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('lalala', 'l{2}')=='lla'


# Generated at 2022-06-25 09:13:37.841340
# Unit test for function regex_search
def test_regex_search():
    # test_regex_search(value='aaa-bbb-ccc-ddd', regex='aaa\-(.*)', ignorecase=True)
    assert regex_search('aaa-bbb-ccc-ddd', 'aaa\-(.*)', 1) == 'bbb'
    assert regex_search('aaa-bbb-ccc-ddd', 'aaa\-(.*)', '\\g<1>') == 'bbb'
    assert regex_search('aaa-bbb-ccc-ddd', 'aaa\-(.*)', '\\1') == 'bbb'
    # test_regex_search(value='aaa-bbb-ccc-ddd', regex='aaa\-(.*)ccc\-(.*)ddd', ignorecase=True)

# Generated at 2022-06-25 09:13:42.682175
# Unit test for function do_groupby
def test_do_groupby():
    func = do_groupby
    # no code here
    return func



# Generated at 2022-06-25 09:13:54.134879
# Unit test for function regex_search
def test_regex_search():
    var_0 = to_text('The quick brown fox jumps over the lazy dog')
    var_1 = to_text('The (\\w+) brown (\\w+)')
    var_3 = regex_search(var_0, var_1)
    var_4 = to_text('The quick brown fox jumps over the lazy dog')
    var_5 = to_text('The (\\w+) brown (\\w+)')
    var_6 = to_text('\\g<1>')
    var_7 = to_text('\\g<2>')
    var_8 = regex_search(var_4, var_5, var_6, var_7)
    var_9 = to_text('The quick brown fox jumps over the lazy dog')
    var_10 = to_text('The (\\w+) brown (\\w+)')


# Generated at 2022-06-25 09:14:04.693437
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_0 = {"a": "b"}
    to_nice_yaml(var_0)
    var_1 = {"a": "b", "c": "d"}
    to_nice_yaml(var_1)
    var_2 = [{"a": "b"}, {"c": "d"}]
    to_nice_yaml(var_2)
    var_3 = [{"a": "b"}, {"c": "d"}, {"e": "f"}]
    to_nice_yaml(var_3)
    var_4 = {"a": "b", "c": "d", "e": "f"}
    to_nice_yaml(var_4)


# Generated at 2022-06-25 09:14:06.174674
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()
    var_1 = mandatory(12)
    var_2 = mandatory('test', 'message')



# Generated at 2022-06-25 09:14:10.501488
# Unit test for function randomize_list
def test_randomize_list():
    var_1 = randomize_list(mylist="Apple", seed=None)
    assert(var_1 == "Apple") is True


# Generated at 2022-06-25 09:14:12.654208
# Unit test for function fileglob
def test_fileglob():
    var_0=fileglob('*')


# Generated at 2022-06-25 09:14:17.398812
# Unit test for function fileglob
def test_fileglob():
    import unittest
    import os.path
    import glob

    pathname = 'test/*.log'
    class Testfileglob(unittest.TestCase):
        def test_case_0(self):
            self.assertEqual(glob.glob(pathname), fileglob(pathname))
   
    unittest.main()


# Generated at 2022-06-25 09:14:24.304244
# Unit test for function mandatory
def test_mandatory():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import AnsibleMapping, AnsibleSequence
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.template import AnsibleEnvironment, AnsibleUndefined

    def template(template_string, vars_dict=dict(), fail_on_undefined=False):
        env = AnsibleEnvironment(loader=None)
        template_data = env.from_string(template_string)
        new_vars_dict = AnsibleMapping()
        var_list = list()
        for var in vars_dict:
            new_vars_dict[to_text(var)] = ansible_safe_eval(to_text(vars_dict[var]))

        res = template

# Generated at 2022-06-25 09:14:27.411757
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('1234567890', r'\d\d\d', '\\3') == '345'
    assert regex_search('1234567890', r'\d\d\d', '\\g<3>') == '345'


# Generated at 2022-06-25 09:14:32.050936
# Unit test for function flatten
def test_flatten():
    print(flatten(['foo', 'bar', 'baz', ['one', 'two', 'three'], 'qux', 'quux']))
    print(flatten(3))
    print(flatten([[3, 4], [5, 6]]))


# Generated at 2022-06-25 09:14:46.394962
# Unit test for function do_groupby
def test_do_groupby():
    # Values to test do_groupby
    test_values = [
        ("test1", "test2"),
        ("test3", "test4"),
        ("test5", "test6"),
        ("test5", "test7")
    ]

    # Call function to test
    result = do_groupby(None, test_values, 1)

    # Assert expected result
    expected_result = [
        ('test2', [('test1', 'test2')]),
        ('test4', [('test3', 'test4')]),
        ('test6', [('test5', 'test6')]),
        ('test7', [('test5', 'test7')])
    ]

    assert result == expected_result



# Generated at 2022-06-25 09:14:55.909400
# Unit test for function regex_escape
def test_regex_escape():
    print("\n\n## test_regex_escape ##\n")
    # test_case 0
    var_0 = regex_escape("This is a regex string")
    print("Input to function regex_escape: [This is a regex string]\n\nOutput of function regex_escape: %s" % var_0)
    # test_case 1
    var_0 = regex_escape("This is another regex string")
    print("Input to function regex_escape: [This is another regex string]\n\nOutput of function regex_escape: %s" % var_0)
    # test_case 2

# Generated at 2022-06-25 09:15:04.616486
# Unit test for function do_groupby
def test_do_groupby():
    # Input parameters tests
    args = [
        # Test cases for when var_0 == 'foo'
        ["foo", ["var_0", "var_1"]],
        ["foo", ("var_0", "var_1")],
    ]
    for arg in args:
        # Argument 1
        print("\nTesting with: %s" % arg)

        # Call the function
        do_groupby(*arg)

    # Execute the function
    function_output = do_groupby(*arg)

    # Evaluate the function output
    assert function_output is None, "Output is of unexpected type %s, should be None" % type(function_output)


# Generated at 2022-06-25 09:15:06.530033
# Unit test for function mandatory
def test_mandatory():
    # Mandatory variable 'var_0' not defined
    assert(mandatory(var_0) == None)


# Generated at 2022-06-25 09:15:15.312823
# Unit test for function mandatory
def test_mandatory():
    # Test correct value
    assert mandatory('One') == 'One'

    try:
        # Test Undefined
        mandatory(None)
    except AnsibleFilterError as exc:
        assert str(exc) == "Mandatory variable  not defined."

    # Test Undefined with a name
    try:
        mandatory(None, msg="Custom error message")
    except AnsibleFilterError as exc:
        assert str(exc) == "Custom error message"



# Generated at 2022-06-25 09:15:23.335597
# Unit test for function comment
def test_comment():
    u''' Test for comment '''
    assert(comment("Hello World, I am a comment") ==
           "# Hello World, I am a comment")
    assert(comment("Hello World, I am a comment", "plain") ==
           "# Hello World, I am a comment")
    assert(comment("Hello World, I am a comment", "erlang") ==
           "% Hello World, I am a comment")
    assert(comment("Hello World, I am a comment", "c") ==
           "// Hello World, I am a comment")
    assert(comment("Hello World, I am a comment", "cblock") ==
           "/*\n * Hello World, I am a comment\n */")
    assert(comment("Hello World, I am a comment", "xml") ==
           "<!--\n - Hello World, I am a comment\n-->")
   

# Generated at 2022-06-25 09:15:31.434705
# Unit test for function strftime
def test_strftime():
    data = [
        {
            'input': {
                'string_format': "%Y-%m-%d",
                'second': "1598393390",
            },
            'result': "2020-08-26"
        },
        {
            'input': {
                'string_format': "%Y-%m-%d %H:%M:%S",
                'second': "1598393390",
            },
            'result': "2020-08-26 15:03:10"
        },
        {
            'input': {
                'string_format': "%Y/%m/%d %H:%M:%S",
                'second': "1598393390",
            },
            'result': "2020/08/26 15:03:10"
        },
    ]


# Generated at 2022-06-25 09:15:42.987726
# Unit test for function mandatory
def test_mandatory():
    from ansible.plugins.filter.core import mandatory
    from jinja2.environment import Environment
    from jinja2 import StrictUndefined
    from ansible.template.safe_eval import safe_eval

    undefined = StrictUndefined(msg="AnsibleUndefined: '{{ missing }}'")
    env = Environment(undefined=undefined)
    env.filters['mandatory'] = mandatory
    # test case 1
    var_1 = {}
    var_1 = env.from_string("{{ var_1 | mandatory }}").render(var_1=var_1)
    # assert equal
    print('test_case_1: %s' % var_1)
    # test case 2
    var_1 = {'missing': ''}
    var_2 = "AnsibleUndefined: '{{ missing }}'"

# Generated at 2022-06-25 09:15:54.533818
# Unit test for function mandatory
def test_mandatory():
    var = None
    msg = "Mandatory msg not defined."

    # Test with no arguments
    try:
        mandatory()
        assert False, "Should have raised an AnsibleFilterError."
    except AnsibleFilterError:
        pass

    # Test with one argument
    try:
        mandatory("")
    except:
        assert False, "Should NOT have raised an AnsibleFilterError."

    # Teast with two arguments
    try:
        mandatory("", msg)
    except:
        assert False, "Should NOT have raised an AnsibleFilterError."

    # Test with bad argument
    try:
        mandatory("", msg)
        assert False, "Should have raised an AnsibleFilterError."
    except AnsibleFilterError as e:
        assert str(e) == msg



# Generated at 2022-06-25 09:15:56.354215
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    mandatory(a=None)
    # assert_equal is not defined


# Generated at 2022-06-25 09:16:06.604079
# Unit test for function do_groupby
def test_do_groupby():
    # Init var_0
    var_0 = None
    try:
        # Call function do_groupby
        var_0 = do_groupby(var_0)
    except Exception as e:
        # Print error message
        print(str(e))
    finally:
        # Clear any pending exceptions on exit
        clear_exception()


# Generated at 2022-06-25 09:16:07.706972
# Unit test for function mandatory
def test_mandatory():
    var_0 = combine()
    mandatory(var_0)


# Generated at 2022-06-25 09:16:12.048357
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(test_case_0())
    except AnsibleFilterError as e:
        print("Error: " + to_text(e))
 


# Generated at 2022-06-25 09:16:16.085153
# Unit test for function flatten
def test_flatten():
    mylist = ['item1', 'item2', [1,2,['a','b'],3], 'item4', 'item5', ['item1', 'item2', [1, 2, ['cat', 'dog']]]]
    result = flatten(mylist, levels=1)
    expected = ['item1', 'item2', 1, 2, ['a', 'b'], 3, 'item4', 'item5', 'item1', 'item2', 1, 2, ['cat', 'dog']]
    if result == expected:
        print("Success!")
        return True
    else:
        var_0 = flatten()
        if result == expected:
            print("Success!")
            return True
        else:
            print('Failure!')
            return False


# Generated at 2022-06-25 09:16:28.655524
# Unit test for function mandatory

# Generated at 2022-06-25 09:16:30.693537
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(int(ansible_facts['ansible_all_ipv4_addresses'][0]), "msg") == var_0


# Generated at 2022-06-25 09:16:41.565560
# Unit test for function regex_search
def test_regex_search():
    # test positive
    assert [x for x in regex_search(value='abcabcabcabcabcabcabcabcabcabc', regex='a.{2}c')] == ['abc']
    assert [x for x in regex_search(value='abcabcabcabcabcabcabcabcabcabc', regex='a.{2}c', ignorecase=False)] == ['abc']
    assert [x for x in regex_search(value='abcabcabcabcabcabcabcabcabcabc', regex='a.{2}c', ignorecase=True)] == ['abc']

    # test negative
    assert [x for x in regex_search(value='abcabcabcabcabcabcabcabcabcabc', regex='a.{2}c', multiline=True)] == []

# Generated at 2022-06-25 09:16:53.010541
# Unit test for function flatten
def test_flatten():
    var_1 = [1, 2, 3, 4]
    var_2 = [[1, 2], 3, [4, 5]]
    var_3 = [0, 1, 2, 3, [4, 5, 6], 7, 8, 9]
    var_4 = [0, 1, 2, [3, [4, 5, 6], [7, 8, [9]]]]
    var_5 = [10, [[[[20, [30]]], [[40, [50]]], [[60, [70]]]]]]
    var_6 = 1
    var_7 = ['abc', 'def', 'ghi', 'jkl', ['mno', 'pqr', 'stu', 'vwx', ['yza', 'bcd', 'efg']]]

# Generated at 2022-06-25 09:16:54.704461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Check of return type
    assert(isinstance(FilterModule.filters(FilterModule), dict))
    # Test with 0 args
    assert(test_case_0())



if __name__ == "__main__":
    test_FilterModule_filters()

# Generated at 2022-06-25 09:17:04.413050
# Unit test for function mandatory
def test_mandatory():
    msg_0 = "Test message"
    exc_0 = AnsibleFilterError(msg_0)
    assert exc_0.message == msg_0
    assert exc_0.orig_exc is None
    exc_1 = None
    try:
        mandatory(exc_1)
    except AnsibleFilterError as e:
        exc_1 = e
    assert exc_1 is not None
    assert exc_1.message == "Mandatory variable '' not defined."
    assert exc_1.orig_exc is None
    exc_2 = None
    try:
        mandatory(exc_2, msg_0)
    except AnsibleFilterError as e:
        exc_2 = e
    assert exc_2 is not None
    assert exc_2.message == msg_0
    assert exc_2.orig_exc is None
    # Tests

# Generated at 2022-06-25 09:17:15.084073
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory()
        assert False, "Expected exception"
    except:
        assert True


# Generated at 2022-06-25 09:17:17.935373
# Unit test for function regex_search
def test_regex_search():
    var_0 = regex_search(value=u'',pattern=u'',ignorecase=False,multiline=False)


# Generated at 2022-06-25 09:17:19.736307
# Unit test for function mandatory
def test_mandatory():
    var_0 = AnsibleUndefined(to_text('UNDEFINED_VARIABLE'))
    mandatory(var_0, to_text('UNDEFINED_VARIABLE'))


# Generated at 2022-06-25 09:17:30.089377
# Unit test for function regex_search
def test_regex_search():
    value_0 = 'JavaScript is a high-level, dynamic, untyped, and interpreted programming language.'
    regex_0 = '^J.*'
    assert regex_search(value_0, regex_0) == 'JavaScript'

    value_1 = 'JavaScript is a high-level, dynamic, untyped, and interpreted programming language.'
    regex_1 = '^[a-zA-Z]+'
    assert regex_search(value_1, regex_1, '\\g<0>') == 'JavaScript'

    value_2 = 'JavaScript is a high-level, dynamic, untyped, and interpreted programming language.'
    regex_2 = '^[a-zA-Z]+'
    assert regex_search(value_2, regex_2, '\\0') == 'JavaScript'


# Generated at 2022-06-25 09:17:31.647326
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 09:17:34.539186
# Unit test for function subelements
def test_subelements():
    obj1 = [{
        'name': 'alice',
        'groups': ['wheel'],
        'authorized': ['/tmp/alice/onekey.pub']
    }]
    subelements(obj1, 'groups')



# Generated at 2022-06-25 09:17:40.988411
# Unit test for function regex_search
def test_regex_search():
    # pylint: disable=redefined-outer-name
    var_0 = "abc"
    var_1 = "123"
    var_2 = "123"
    var_3 = "abc"
    var_4 = "123"
    var_5 = "123"
    var_6 = "abc"
    var_7 = "123"
    var_8 = "123"
    var_9 = "abc"
    var_10 = "123"
    var_11 = "123"
    var_12 = "abc"
    var_13 = "123"
    var_14 = "123"
    var_15 = "abc"
    var_16 = "123"
    var_17 = "123"
    var_18 = "abc"
    var_19 = "123"
    var_20

# Generated at 2022-06-25 09:17:42.625373
# Unit test for function regex_escape
def test_regex_escape():
    test_case_1(regex_escape)
    test_case_2(regex_escape)


# Generated at 2022-06-25 09:17:44.989433
# Unit test for function mandatory
def test_mandatory():
    msg = "Mandatory variable 'var_0' not defined."
    try:
        mandatory("var_0")
    except AnsibleFilterError as e:
        assert msg == str(e)


# Generated at 2022-06-25 09:17:55.377022
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    data = {
        "foo": {
            "bar": [
                1,
                2,
                3
            ],
            "baz": {
                "foo": [
                    1,
                    2,
                    3
                ],
                "bar": "hello\nworld",
                "another_key": 1234,
                "last_key": "fizbuzz"
            }
        }
    }
    actual = to_nice_yaml(data)
    expected = u"""foo:
  bar:
  - 1
  - 2
  - 3
  baz:
    foo:
    - 1
    - 2
    - 3
    bar: hello
      world
    another_key: 1234
    last_key: fizbuzz
"""
    assert actual == expected



# Generated at 2022-06-25 09:18:13.819337
# Unit test for function extract
def test_extract():
    var_0 = dict(a=dict(b=1))
    a = extract('a', var_0, morekeys='b')
    assert(a == 1)


# Generated at 2022-06-25 09:18:16.364261
# Unit test for function get_hash
def test_get_hash():
    var_0 = get_hash("Test String")
    var_1 = get_hash("Test String", "md5")
    var_2 = get_hash("Test String", "sha256")


# Generated at 2022-06-25 09:18:24.410043
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert to_nice_yaml({'key': 'value'}) == u"{key: value}\n"

# Generated at 2022-06-25 09:18:29.879142
# Unit test for function regex_escape
def test_regex_escape():
    print(regex_escape('a(b)c.d$e*f\\g', re_type='python'))
    print(regex_escape('a(b)c.d$e*f\\g', re_type='posix_basic'))


# Generated at 2022-06-25 09:18:31.288555
# Unit test for function regex_escape
def test_regex_escape():
    var_0 = regex_escape()

# Generated at 2022-06-25 09:18:39.185637
# Unit test for function mandatory
def test_mandatory():

    # check the idempotence of mandatory
    var_0 = mandatory(var_0)
    assert not isinstance(var_0, Undefined)

    # check the idempotence of mandatory
    var_1 = mandatory(var_0, msg = 'msg')
    assert not isinstance(var_1, Undefined)

    # check the idempotence of mandatory
    var_2 = mandatory(var_0, msg = None)
    assert not isinstance(var_2, Undefined)



# Generated at 2022-06-25 09:18:48.755957
# Unit test for function do_groupby
def test_do_groupby():
    var_1 = {'vars': {'k': 1, 'j': 1, 'i': 1}, 'a': 1, 'pkg': {'y': 1, 'x': 1, 'z': 1}, 'b': 1, 'c': 1, 'd': 1, 'e': 1, 'f': 1, 'g': 1, 'h': 1}

    var_1 = do_groupby(var_1, "key")

    assert var_1 == [('a', 1), ('b', 1), ('c', 1), ('d', 1), ('e', 1), ('f', 1), ('g', 1), ('h', 1), ('i', 1), ('j', 1), ('k', 1), ('x', 1), ('y', 1), ('z', 1)]


# Generated at 2022-06-25 09:18:50.462686
# Unit test for function mandatory
def test_mandatory():
    print("testing test_mandatory")
    var_0 = mandatory(0, msg='this is test_case_0')
    test_case_0 = var_0


# Generated at 2022-06-25 09:18:53.592716
# Unit test for function regex_search
def test_regex_search():
    var_1 = ' 123'
    var_2 = '\d+'
    var_3 = regex_search(var_1, var_2)
    print('{}'.format(var_3))


# Generated at 2022-06-25 09:19:04.908401
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    mylist = randomize_list(mylist, seed=29)
    assert mylist == [4, 5, 2, 1, 3]

    mylist = [1, 2, 3, 4, 5]
    mylist = randomize_list(mylist)