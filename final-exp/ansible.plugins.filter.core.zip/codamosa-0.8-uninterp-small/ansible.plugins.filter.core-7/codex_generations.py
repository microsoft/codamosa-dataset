

# Generated at 2022-06-25 09:10:05.702391
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('var') == 'var'
    assert mandatory('var', msg='msg') == 'var'


# Generated at 2022-06-25 09:10:09.665623
# Unit test for function regex_search
def test_regex_search():
    var_0 = regex_search("Hello world", "(.+) (.+)")
    assert var_0 == "Hello world"



# Generated at 2022-06-25 09:10:13.114343
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    a=Undefined(name='a')
    var_0 = mandatory(a)
    a = None
    var_1 = mandatory(a)
    a = 'abcdefghijklmnopqrstuvwxyz'
    var_2 = mandatory(a)


# Generated at 2022-06-25 09:10:23.346497
# Unit test for function mandatory

# Generated at 2022-06-25 09:10:34.904621
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    expected = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    result = subelements(obj, 'groups')
    assert result == expected, "%s != %s" % (result, expected)

    obj = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub"]}]
    expected = []
    result = subelements(obj, 'groups')
    assert result == expected, "%s != %s" % (result, expected)


# Generated at 2022-06-25 09:10:44.025956
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory()
        # catch exception
        fail()
    except AnsibleFilterError as e:
        eq('Mandatory variable not defined.', e.message)
    eq(None, mandatory(None))
    var_1 = {'a': 1, 'b': 2}
    eq(var_1['a'], mandatory(var_1['a']))
    eq(var_1['b'], mandatory(var_1['b']))
    eq(var_1['c'], mandatory(var_1['c'], msg='Custom error'))


# Generated at 2022-06-25 09:10:53.372979
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("/d/a/b/c", ".*/(.*)") == 'c'
    assert regex_search("/d/a/b/c", ".*/(.*)", "\\g<1>") == 'c'
    assert regex_search("/d/a/b/c", ".*/(.*)", "\\1") == 'c'


# Generated at 2022-06-25 09:11:04.849058
# Unit test for function strftime
def test_strftime():
    var_1 = strftime(string_format='', second='var_0')
    assert var_1 == '', 'Validate when string_format and second are empty'
    var_1 = strftime(string_format='var_0', second='')
    assert var_1 == '', 'Validate when string_format is not empty and second is empty'
    var_1 = strftime(string_format='', second='var_0')
    assert var_1 == '', 'Validate when string_format is empty and second is not empty'
    var_1 = strftime(string_format='var_0', second='var_0')
    assert var_1 == '', 'Validate when string_format and second are not empty'
    var_1 = strftime(string_format='var_0', second='var_0')
   

# Generated at 2022-06-25 09:11:15.301231
# Unit test for function do_groupby
def test_do_groupby():

    class TestEnvironment(Environment):
        pass

    testEnv = TestEnvironment()

    class TestAttr(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return "%s('%s')" % (self.__class__.__name__, self.value)

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

        def __ne__(self, other):
            return not self.__eq__(other)

        def __hash__(self):
            return hash(self.__repr__())

        def __getattr__(self, name):
            raise AnsibleFilterError("cannot access '%s'" % name)

    class TestAttrOther(TestAttr):
        pass


# Generated at 2022-06-25 09:11:19.725992
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_0 = combine()
    var_0 = to_nice_yaml()


# Generated at 2022-06-25 09:11:32.464950
# Unit test for function to_yaml
def test_to_yaml():
    var_0 = {'a': 'b'}
    var_1 = combine(var_0, 'foo')
    assert isinstance(var_1, str)
    assert var_1 == "a\nb"


# Generated at 2022-06-25 09:11:41.561020
# Unit test for function strftime
def test_strftime():
    try:
        strftime()
    except TypeError:
        print("Function strftime takes at least 1 argument (0 given)")
    try:
        strftime("%Y-%m-%d %H:%M:%S")
    except TypeError:
        print("Function strftime takes at least 1 argument (1 given)")

# TODO add unit test for strptime


# Generated at 2022-06-25 09:11:51.929504
# Unit test for function fileglob
def test_fileglob():
    cwd = os.getcwd()
    os.chdir('test/test_filter_plugins')

    # os.chdir(os.path.dirname(__file__))
    test_files = ['test.yml', 'test2.yml', 'another_test.yml']
    new_files = fileglob('*test*.yml')

    assert len(new_files) == len(test_files), "Error: fileglob: Length of test directory contents and new files are not equal."
    assert new_files == test_files, "Error: fileglob: Test directory contents and new files are not equal."

    os.chdir('..')
    os.chdir('..')
    os.chdir(cwd)



# Generated at 2022-06-25 09:12:02.440735
# Unit test for function get_hash
def test_get_hash():
    print('get_hash...')

    # Test successful creation if valid hash function
    hashtype = 'sha256'
    str_0 = get_hash('Test String', hashtype)
    if str_0 != '88d55e60ea8eb0b89649d6574a9c9a2640f87904d20b3f3c7e3e8eba3e0cb3a3':
        print('FAILED: get_hash')
        return

    # test that it fails on invalid hash function
    hashtype = 'abc123'
    try:
        str_0 = get_hash('Test String', hashtype)
    except Exception:
        pass
    else:
        print('FAILED: get_hash')
        return

    print('PASSED: get_hash')



# Generated at 2022-06-25 09:12:11.176382
# Unit test for function mandatory
def test_mandatory():
    try:
        test_case_0()
    except AnsibleFilterError as e:
        pass
    except Exception as e:
        raise Exception('%s: %s (%s) throws an exception' % (test_case_0.__name__, 'mandatory', 'None'))
    else:
        raise Exception('%s: %s (%s) is expected to throw an exception' % (test_case_0.__name__, 'mandatory', 'None'))


# Generated at 2022-06-25 09:12:20.871624
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(value='hello', regex='[a-z]') is None
    assert regex_search(value='hello', regex='[a-z]*') == 'hello'
    assert regex_search(value='hello', regex='[a-z]*', ignorecase=True) == 'hello'
    assert regex_search(value='hello', regex='[A-Z]*') is None
    assert regex_search(value='hello', regex='[a-z]*', ignorecase=True) == 'hello'
    assert regex_search(value='Hello', regex='[a-z]*', ignorecase=True) == 'Hello'
    assert regex_search(value='Hello', regex='[a-z]*') is None
    assert regex_search(value='hello', regex='[a-z]+') == 'hello'


# Generated at 2022-06-25 09:12:23.293112
# Unit test for function mandatory
def test_mandatory():
    # Write code here to test "raise AnsibleFilterError"
    # Write code here to test "if isinstance(a, Undefined):"
    pass


# Generated at 2022-06-25 09:12:24.419375
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(var_0, msg='TEST')


# Generated at 2022-06-25 09:12:27.321548
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_1 = {u'name': u'Unix', u'id': 1}
    var_1 = to_nice_yaml(var_1)
    var_2 = "name: Unix\nid: 1\n"
    var_3 = var_1 == var_2
    var_3 = to_nice_yaml(var_3)
    return var_3


# Generated at 2022-06-25 09:12:31.814896
# Unit test for function fileglob
def test_fileglob():
    pathname = "../files/*"
    expected_return = [os.path.join(os.path.dirname(os.path.realpath(__file__)), '../files/file1.txt'), os.path.join(os.path.dirname(os.path.realpath(__file__)), '../files/file2.txt')]
    assert (fileglob(pathname) == expected_return)


# Generated at 2022-06-25 09:12:39.536290
# Unit test for function fileglob
def test_fileglob():
    with pytest.raises(AnsibleFilterError, match="supports single argument only"):
        fileglob("")
        var_1 = combine()


# Generated at 2022-06-25 09:12:42.641612
# Unit test for function mandatory
def test_mandatory():
    # Test basic input
    var_1 = mandatory(42, 'test')
    assert(var_1 == 42)
    # Test basic output
    var_2 = mandatory(42, 'test')
    assert(var_2 == 42)



# Generated at 2022-06-25 09:12:46.949928
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/path/to/file")


# Generated at 2022-06-25 09:12:54.612621
# Unit test for function comment
def test_comment():
    text = "Foo fail."
    style = 'plain'
    result = comment(text, style)
    print(result)

    text = "Foo fail."
    style = 'erlang'
    result = comment(text, style)
    print(result)

    text = "Foo fail."
    style = 'c'
    result = comment(text, style)
    print(result)



# Generated at 2022-06-25 09:13:01.788202
# Unit test for function extract
def test_extract():
    assert 1 == extract(1, 'bar', {'foo': {'bar': 1}})
    assert 1 == extract(1, 'bar', {'foo': {'bar': 1}}, 'foo')
    assert 1 == extract(1, 'bar', {'foo': {'bar': 1}}, ['foo'])
    assert {'moo': 1} == extract(1, 'zoo', {'foo': {'bar': 1, 'zoo': {'moo': 1}}}, 'foo')
    assert ['moo', 1] == extract(1, 'zoo', {'foo': {'bar': 1, 'zoo': {'moo': 1}}}, ['foo', 'zoo'])

# Generated at 2022-06-25 09:13:04.053699
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory("string")
    var_1 = mandatory("string", exception("string"))


# Generated at 2022-06-25 09:13:07.085407
# Unit test for function regex_replace
def test_regex_replace():
    actual_return = regex_replace(value='abcdefg', pattern='abc', replacement='xyz', ignorecase=False, multiline=False)
    expect_return = 'xyzdefg'
    assert expect_return == actual_return


# Generated at 2022-06-25 09:13:17.644063
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_0 = dict()
    var_0["key_01"] = "data_01"
    var_0["key_02"] = "data_02"
    var_0["key_03"] = "data_03"
    var_0["key_04"] = "data_04"
    var_1 = to_nice_yaml( var_0 )
    var_0 = dict()
    var_0["key_01"] = "data_01"
    var_0["key_02"] = "data_02"
    var_0["key_03"] = "data_03"
    var_0["key_04"] = "data_04"
    var_2 = to_yaml( var_0 )
    return (var_1, var_2)

# Generated at 2022-06-25 09:13:24.522568
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    var_1 = {}
    var_1['type'] = "{{ 'qa' if ctx.config.try_get('env') == 'qa' else ctx.config.try_get('env') }}"
    var_1['port'] = {'5672': '{{ ctx.AMQ_PORT_DEFAULT }}'}

    print(to_nice_yaml(var_1))


# Generated at 2022-06-25 09:13:36.504224
# Unit test for function subelements
def test_subelements():
    obj_0 = [{'name': 'alice', 'groups': ['wheel', 'ssh'],
              'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'groups': ['wheel', 'users'],
              'authorized': ['/tmp/bob/userkey.pub']}]
    result = subelements(obj_0, 'groups')
    if 'wheel' in result and 'users' in result and 'ssh' in result:
        var_0 = True
        print(var_0)
    else:
        var_0 = False
        print(var_0)

    result = subelements(var_0, 'authorized')
    if '/tmp/alice/onekey.pub' in result:
        var_

# Generated at 2022-06-25 09:13:45.840631
# Unit test for function regex_escape
def test_regex_escape():
    var_1 = to_text("", errors='surrogate_or_strict', nonstring='simplerepr')
    var_2 = regex_replace(var_1, r'([].[^$*\\])', r'\\\1')
    assert var_2 == '', 'Expected regex_escape to return \'\' but instead returned ' + var_2

    var_3 = to_text("   ", errors='surrogate_or_strict', nonstring='simplerepr')
    var_4 = regex_replace(var_3, r'([].[^$*\\])', r'\\\1')
    assert var_4 == '   ', 'Expected regex_escape to return \'   \' but instead returned ' + var_4


# Generated at 2022-06-25 09:13:51.137780
# Unit test for function to_yaml
def test_to_yaml():
    test_data = {'a': 1, 'b': {'c': 'string'}, 'c': [1, 2, 3]}
    test_result = to_yaml(test_data)
    assert test_result == u'a: 1\nb:\n  c: string\nc:\n- 1\n- 2\n- 3\n', \
        test_result


# Generated at 2022-06-25 09:14:02.405365
# Unit test for function fileglob
def test_fileglob():
    pathname = "C:\\Program Files\\Microsoft Visual Studio\\\\msdn.microsoft.com\\en-us\\library\\windows\\desktop\\\\dn633971(v=vs.85).aspx"
    result = fileglob(pathname)
    assert result == ['C:\\Program Files\\Microsoft Visual Studio\\\\msdn.microsoft.com\\en-us\\library\\windows\\desktop\\\\dn633971(v=vs.85).aspx'], "'%s' should be '%s'" % ("C:\\Program Files\\Microsoft Visual Studio\\\\msdn.microsoft.com\\en-us\\library\\windows\\desktop\\\\dn633971(v=vs.85).aspx", "C:\\Program Files\\Microsoft Visual Studio\\\\msdn.microsoft.com\\en-us\\library\\windows\\desktop\\\\dn633971(v=vs.85).aspx")


# Generated at 2022-06-25 09:14:06.281581
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('*') == []
    assert fileglob('non_existent') == []
    assert fileglob('/etc/passwd') == ['/etc/passwd']


# Generated at 2022-06-25 09:14:07.129375
# Unit test for function regex_search
def test_regex_search():
    var_0 = regex_search()


# Generated at 2022-06-25 09:14:14.722432
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment

    env = Environment()
    env.filters['groupby'] = do_groupby

    my_list = [
        {'first_name': 'A', 'last_name': 'B'},
        {'first_name': 'C', 'last_name': 'D'},
        {'first_name': 'E', 'last_name': 'F'},
    ]
    assert len(env.from_string("{{ my_list|groupby('first_name') }}").render(my_list=my_list)) > 0



# Generated at 2022-06-25 09:14:20.037338
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    res_0 = ""
    var_0 = []
    res_0 = to_nice_yaml(var_0)
    assert res_0 == ""



# Generated at 2022-06-25 09:14:30.511067
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foobar', 'f.*r') == 'foobar'
    assert regex_search('foobar', 'f.*r', '\\g<0>') == 'foobar'
    assert regex_search('foobar', '(foo)(bar)', '\\g<0>', '\\g<1>', '\\g<2>') == ['foobar', 'foo', 'bar']
    assert regex_search('abcabcabc', '(abc)abcabc') == 'abcabcabc'
    assert regex_search('abcabcabc', '(abc)abcabc', '\\g<1>') == ['abc']
    assert regex_search('foobar', 'f.*bar') == 'foobar'
    assert regex_search('foobar', 'f.*bar', '\\g<0>') == 'foobar'

# Generated at 2022-06-25 09:14:41.984625
# Unit test for function fileglob
def test_fileglob():
    var_0 = fileglob("abc")
    if var_0 is None:
        print("The value is not as expected")
        return False
    elif var_0 != []:
        print("The value is not as expected")
        return False

    var_1 = fileglob("/Users/mattd/dev/mattd-tasks/ansible_tasks/ansible_task1/test.py")
    if var_1 is None:
        print("The value is not as expected")
        return False
    elif var_1 != ["/Users/mattd/dev/mattd-tasks/ansible_tasks/ansible_task1/test.py"]:
        print("The value is not as expected")
        return False

    return True


# Generated at 2022-06-25 09:14:47.110630
# Unit test for function strftime
def test_strftime():
    try:
        assert strftime("%Y-%m-%d", time.localtime(time.time())) == time.strftime("%Y-%m-%d", time.localtime(time.time()))
    except AssertionError:
        raise AssertionError("strftime failed to create correct date string")


# Generated at 2022-06-25 09:15:00.902647
# Unit test for function regex_escape

# Generated at 2022-06-25 09:15:13.193540
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape("'$*[]") == "\\'\\$\\*\\[\\]"
    assert regex_escape("ab.cd") == "ab\\.cd"
    assert regex_escape("ab.cd", re_type='posix_basic') == "ab\\.cd"
    assert regex_escape("re$*t[]") == "re\\$\\*t\\[\\]"
    assert regex_escape("re$*t[]", re_type='posix_basic') == "re\\$\\*t\\[\\]"
    with pytest.raises(AnsibleFilterError) as excinfo:
        regex_escape("re$*t[]", re_type='posix_extended')
    assert 'Regex type (posix_extended) not yet implemented' in str(excinfo.value)

# Generated at 2022-06-25 09:15:17.344638
# Unit test for function do_groupby
def test_do_groupby():
    """Test the do_groupby filter with a list of integers and a lambda
    attribute.
    """
    my_list = [1, 2, 2, 3, 4]
    my_list_attrib = lambda num: num % 2
    expected_result = [(1, [1, 3]), (0, [2, 2, 4])]

    result = do_groupby(my_list, my_list_attrib)
    assert result == expected_result, \
        'Expected result: %s. Result returned: %s' % (expected_result, result)


# Generated at 2022-06-25 09:15:29.472931
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({"a": 1}) == "a: 1\n"
    assert to_yaml({"a": 1}, default_flow_style=True) == "{a: 1}"
    assert to_yaml([1, 2, 3], default_flow_style=False) == "- 1\n- 2\n- 3\n"
    assert to_yaml({"a": [1, 2, 3]}, default_flow_style=True) == "{a: [1, 2, 3]}"
    assert to_yaml({"a": [1, 2, 3]}, default_flow_style=False) == "a:\n- 1\n- 2\n- 3\n"
    

# Generated at 2022-06-25 09:15:35.559177
# Unit test for function comment
def test_comment():
    assert comment('test', style='plain') == '# test'
    assert comment('test', style='erlang') == '% test'
    assert comment('test', style='c') == '// test'
    assert comment('test', style='cblock') == '/* \n * test \n */'
    assert comment('test', style='xml') == '<!-- \n - test \n-->'
    assert comment('test', style='plain', decoration='// ') == '// test'
    assert comment('test', style='c', decoration='// ') == '// test'
    assert comment('test', style='cblock', decoration='// ') == '/* \n // test \n */'
    assert comment('test', style='cblock', prefix='// ') == '/* \n // test \n */'

# Generated at 2022-06-25 09:15:42.444756
# Unit test for function regex_search
def test_regex_search():
    """test for regex_search"""
    value = "\"test\""
    regex = '"(\S+)"'
    assert regex_search(value, regex, '0') == "\"test\""
    assert regex_search(value, regex, '1') == "test"
    assert regex_search(value, regex, '\\1') == "test"
    assert regex_search(value, regex, '\\g<1>') == "test"


# Generated at 2022-06-25 09:15:43.022408
# Unit test for function extract
def test_extract():
    var_0 = extract()


# Generated at 2022-06-25 09:15:52.279847
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    items = {
        "a": 1,
        "b": (1, 2),
        "c": {"a": 1}
    }
    print("Input items: " + str(items))
    print("Expected output: ")
    print("{a: 1,\n b: [1, 2],\n c: {a: 1}\n}\n")
    print("Actual output: " + str(to_nice_yaml(items)) + "\n")
    assert to_nice_yaml(items) is not None

test_case_0()
test_to_nice_yaml()

# Generated at 2022-06-25 09:15:53.811198
# Unit test for function do_groupby
def test_do_groupby():
    import doctest
    doctest.testmod(name='do_groupby',
                    verbose=False,
                    optionflags=doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-25 09:16:00.457943
# Unit test for function regex_search

# Generated at 2022-06-25 09:16:10.698877
# Unit test for function randomize_list
def test_randomize_list():
    var_0 = randomize_list()


# Generated at 2022-06-25 09:16:15.670147
# Unit test for function extract
def test_extract():
    text = "A B C"

# Generated at 2022-06-25 09:16:23.185938
# Unit test for function regex_search
def test_regex_search():
    # Test 1
    var_1 = "myemail@website.com"
    var_2 = "(.+@.+)\.(.+)"
    var_3 = '\\g<1>'
    var_4 = '\\g<2>'
    result = regex_search(var_1, var_2, var_3, var_4)
    assert result == 'myemail', result
    # Test 2
    var_5 = "myemail@website.com"
    var_6 = "(.+@.+)\.(.+)"
    var_7 = '\\g<2>'
    result = regex_search(var_5, var_6, var_7)
    assert result == 'website', result


# Generated at 2022-06-25 09:16:25.046359
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('./Testing/TestFile.txt') == ['./Testing/TestFile.txt']


# Generated at 2022-06-25 09:16:27.339717
# Unit test for function strftime
def test_strftime():
    var_5 = strftime()
    assert var_5 == ""
# ------------------------------------------------



# Generated at 2022-06-25 09:16:33.533151
# Unit test for function extract
def test_extract():

    # Run the module
    with pytest.raises(TypeError):
        extract()

    test_container = {
        'num': 1,
        'text': 'ABC',
        'list': ['A', 'B', 'C'],
        'dict': {
            'A': 'a',
            'B': 'b',
            'C': 'c'
        },
    }

    assert extract(test_container, 'num', test_container) == 1
    assert extract(test_container, 'text', test_container) == 'ABC'
    assert extract(test_container, 'list', test_container) == ['A', 'B', 'C']
    assert extract(test_container, 'dict', test_container) == {'A': 'a', 'B': 'b', 'C': 'c'}
    assert extract

# Generated at 2022-06-25 09:16:36.344000
# Unit test for function subelements
def test_subelements():
    var_0 = subelements()


# Generated at 2022-06-25 09:16:41.412935
# Unit test for function mandatory
def test_mandatory():
    import pytest
    import ansible
    with pytest.raises(AnsibleFilterError):
        mandatory(ansible.constants._UNDEFINED)



# Generated at 2022-06-25 09:16:44.610297
# Unit test for function mandatory
def test_mandatory():
    from jinja2.nodes import Const
    from jinja2.runtime import Undefined
    var_0 = to_text('Mandatory variable \'obj\' not defined.')
    var_1 = Const('obj')
    var_2 = Undefined(name='obj')
    var_3 = mandatory(var_2)



# Generated at 2022-06-25 09:16:49.817344
# Unit test for function do_groupby
def test_do_groupby():
    assert do_groupby({}, {}, {'a': 'b'}) == [(None, {'a': 'b'})], 'Value expected: [(None, {u\'a\': u\'b\'})] = do_groupby({}, {}, {\'a\': \'b\'})'

# Generated at 2022-06-25 09:16:59.596212
# Unit test for function extract
def test_extract():
    global env
    env = Environment.from_string('{{ extract(1, [1,2], [3,4]) }}')
    assert env.from_string('{{ extract(1, [1,2], [3,4]) }}').render() == '2'
    assert env.from_string('{{ extract(1, [1,2], [3,4]) }}').render() == '2'


# Generated at 2022-06-25 09:17:03.691577
# Unit test for function fileglob
def test_fileglob():
    pathname = "*.txt"
    result = fileglob(pathname)
    assert result == []


# Generated at 2022-06-25 09:17:07.095574
# Unit test for function subelements
def test_subelements():
    ret_0 = subelements()
    return ret_0


# Generated at 2022-06-25 09:17:08.887273
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory(0)
    var_1 = mandatory(1)
    print(var_0)
    print(var_1)

# Generated at 2022-06-25 09:17:12.232475
# Unit test for function to_yaml
def test_to_yaml():
    input = ['a', 'b']
    expected = '- a\n- b\n'

    actual = to_yaml(input)
    if actual != expected:
        raise AssertionError


# Generated at 2022-06-25 09:17:16.802123
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(None, msg="msg_0")
    except AnsibleFilterError as err:
        assert err.message == 'Mandatory variable not defined.'


# Generated at 2022-06-25 09:17:19.495053
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(version=None, ansible_version=None) is None


# Generated at 2022-06-25 09:17:29.830676
# Unit test for function mandatory
def test_mandatory():
    # Test with default parameters
    assert(mandatory(5) == 5)
    # Test with default parameters
    assert(mandatory(5.0) == 5.0)
    # Test with default parameters
    assert(mandatory('string') == 'string')
    # Test with default parameters
    assert(mandatory(True) == True)
    # Test with default parameters
    assert(mandatory(False) == False)
    # Test with default parameters
    assert(mandatory(range(0,1)) == range(0,1))
    # Test with default parameters
    assert(mandatory([1,2,3]) == [1,2,3])
    # Test with default parameters
    assert(mandatory((1,2,3)) == (1,2,3))
    # Test with default parameters

# Generated at 2022-06-25 09:17:36.896135
# Unit test for function extract
def test_extract():
    assert extract(1, [1, 2, 3]) == [1, 2, 3]
    assert extract('key1', {'key1': 1, 'key2': 2, 'key3': 3}) == 1
    assert extract('key1', {'key1': [1, 2, 3], 'key2': 4, 'key3': 5}, 'key2') == 2
    assert extract('key2', {'key1': [1, 2, 3], 'key2': [4, 5, 6], 'key3': 7}) == [4, 5, 6]
    assert extract('key1', {'key1': {'key2': {'key3': 8}}}, 'key2', 'key3') == 8



# Generated at 2022-06-25 09:17:40.725721
# Unit test for function randomize_list
def test_randomize_list():
    failed = False
    try:
        mylist = ['one', 'two', 'three']
        randomize_list(mylist)
    except Exception as e:
        print(e)
        failed = True
    if not failed:
        print("randomize_list() - Success")


# Generated at 2022-06-25 09:17:53.047992
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('', '') == ''
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\1') == 'h'
    assert regex_search('hello world', 'hello', '\\g<1>') == 'h'
    assert regex_search('hello world', 'hello', '\\1', '\\1') == ['h', 'h']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<1>') == ['h', 'h']
    assert regex_search('HELLO world', 'hello', ignorecase=True) == 'hello'
    assert regex_search('HELLO world', 'hello', '\\1', ignorecase=True) == ['h']

# Generated at 2022-06-25 09:18:02.307538
# Unit test for function extract

# Generated at 2022-06-25 09:18:10.127657
# Unit test for function get_hash
def test_get_hash():
    var_1 = 'this is my string'
    expected = 'b62c725ddc952f8d7c964ed6f2e6c322c58de185'
    actual = get_hash(var_1)
    if actual != expected:
        raise AssertionError(
            'Hash of (%s) != (%s)' % (var_1, expected))


# Generated at 2022-06-25 09:18:12.167451
# Unit test for function mandatory
def test_mandatory():
    var_1 = mandatory()
    assert var_1 == 10


# Generated at 2022-06-25 09:18:23.702647
# Unit test for function extract

# Generated at 2022-06-25 09:18:29.145946
# Unit test for function strftime
def test_strftime():
    # Case 1:
    var_1 = strftime('%Y-%m-%d %H:%M:%S')
    print(var_1)
    print('\n')


# Generated at 2022-06-25 09:18:29.665921
# Unit test for function mandatory
def test_mandatory():
    mandatory()



# Generated at 2022-06-25 09:18:35.388366
# Unit test for function mandatory
def test_mandatory():
    # Test preparation: create a string with a variable
    template = "{% set var_0 = regex_replace('', '') %} {{ var_0 }}"
    # Run the Jinja2 template which sets the variable var_1 through regex_replace()
    template_obj = Environment().from_string(template)
    result = template_obj.render()
    # Use the unit test function to see if the variable has been set to a non-empty string
    assert isinstance(var_0, string_types)
    assert len(var_0) > 0
    assert var_0 == 'some_value'


# Generated at 2022-06-25 09:18:37.907156
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()


# Generated at 2022-06-25 09:18:40.197673
# Unit test for function mandatory
def test_mandatory():
    var_0 = regex_replace()

    f = mandatory.__get__(var_0, regex_replace)
    assert f() is None



# Generated at 2022-06-25 09:18:59.213857
# Unit test for function mandatory
def test_mandatory():
    var_0 = to_text('1')
    try:
        mandatory(var_0)
    except AnsibleFilterError:
        assert True
        return
    assert False


# Generated at 2022-06-25 09:19:06.525864
# Unit test for function mandatory
def test_mandatory():
    if mandatory(None) != None:
        return False
    if mandatory(True) != True:
        return False
    if mandatory(False) != False:
        return False
    if mandatory(0) != 0:
        return False
    if mandatory(0.0) != 0.0:
        return False
    if mandatory("") != "":
        return False
    if mandatory("abcd") != "abcd":
        return False
    if mandatory({"a":1, "b":2}) != {"a":1, "b":2}:
        return False
    if mandatory({"a":1, "b":2}) != {"a":1, "b":2}:
        return False
    if mandatory(["a", 1, "b", 2]) != ["a", 1, "b", 2]:
        return False
    return True



# Generated at 2022-06-25 09:19:12.269157
# Unit test for function regex_search
def test_regex_search():
    # Test format string
    value = '00:00:00:00:00:01'
    regex = '^(?P<mac>\w\w:\w\w:\w\w:\w\w:\w\w:\w\w)$'
    assert regex_search(value, regex,
        '\\g<mac>') == '00:00:00:00:00:01'


# Generated at 2022-06-25 09:19:16.974599
# Unit test for function mandatory
def test_mandatory():
    try:
        ansible = mandatory(None, msg='test_case_0')
    except AnsibleFilterError as e:
        return str(e) == "Mandatory variable 'msg' not defined."

    ansible = mandatory('none', msg='test_case_1')
    return ansible == 'none'



# Generated at 2022-06-25 09:19:20.073500
# Unit test for function regex_search
def test_regex_search():
    ''' Test regex_search'''
    var_0 = regex_search('ACMECorp', pattern='corp', ignorecase=True)
    print(var_0)

if __name__ == '__main__':
    test_regex_search()

# Generated at 2022-06-25 09:19:24.590077
# Unit test for function mandatory
def test_mandatory():
    var_0 = mandatory()
