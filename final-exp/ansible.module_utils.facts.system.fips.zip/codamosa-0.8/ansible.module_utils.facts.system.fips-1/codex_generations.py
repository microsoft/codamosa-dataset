

# Generated at 2022-06-11 04:38:47.243129
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test normal path and return correct value
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-11 04:38:49.658528
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    fips_facts_list = fips_facts.collect()
    assert 'fips' in fips_facts_list

# Generated at 2022-06-11 04:38:51.707970
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-11 04:38:58.193872
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # When fips_enabled sysfs file exist
    def mock_get_file_content(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return None
    module = None
    collected_facts = {}
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.get_file_content = mock_get_file_content

    # Then
    # fips is set to True
    fips_facts = fips_fact_collector.collect(module, collected_facts)
    assert fips_facts == {'fips': True}

    # When fips_enabled sysfs file doesn't exist

# Generated at 2022-06-11 04:39:01.522835
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup test
    test_collector = FipsFactCollector()

    # Exercise collect method
    result = test_collector.collect()

    # Verify test
    assert result['fips'] is not None

# Generated at 2022-06-11 04:39:02.852547
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect()

# Generated at 2022-06-11 04:39:13.096877
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.platform = 'Linux'
    fips_fact_collector._read_file_content = lambda x: '0'
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

    fips_fact_collector._read_file_content = lambda x: '1'
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

    fips_fact_collector._read_file_content = lambda x: ''
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

    fips_fact_collector = FipsFactCollector

# Generated at 2022-06-11 04:39:18.236433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_content = '1'
    fips_facts = {}
    fips_facts['fips'] = True
    fips = FipsFactCollector()
    fips.collect(None, None)
    assert fips.collect_func is None
    assert fips.fetch_func is None
    assert fips.name == 'fips'
    assert fips._fact_ids == set()
    assert fips.collect(None, None) == fips_facts

# Generated at 2022-06-11 04:39:25.344634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Construct class with mocked object
    fips_fact_collector = FipsFactCollector()

    # Test method collect without 'fips' config
    fips_facts = fips_fact_collector.collect(collected_facts=None)

    # Assert test
    assert fips_facts['fips'] == False

    # Test method collect with 'fips' config
    fips_facts = fips_fact_collector.collect(collected_facts={'fips': True})

    # Assert test
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:39:26.653892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector(None)
    assert len(obj.collect()) >= 1

# Generated at 2022-06-11 04:39:36.614531
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    with patch('ansible.module_utils.facts.collector.get_file_content',
               side_effect=['1', None]):
        fips_fact_collector = FipsFactCollector()
        assert fips_fact_collector.collect() == {'fips': True}
        assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:39:38.082907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    result = ffc.collect(None, None)
    assert 'fips' in result.keys()

# Generated at 2022-06-11 04:39:44.155696
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = '1'
    # create a mock_open object
    mock_open = mock.mock_open(read_data=fips_data)
    mock_open.return_value.read.side_effect = [fips_data]
    # Assign it to `builtins.open`
    module = mock.MagicMock()
    module.open = mock_open
    module.file.read.side_effect = [fips_data]
    with mock.patch.object(FipsFactCollector, '_get_file_content') as mock_get_file_content:
        mock_get_file_content.return_value = fips_data
        FipsFactCollector().collect()
    # Test
    assert module.open.call_count == 1
    assert module.file.read.call_

# Generated at 2022-06-11 04:39:47.016360
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc._fact_ids == set(['fips'])
    facts = ffc.collect()
    assert facts == {'fips': False}

# Generated at 2022-06-11 04:39:47.959253
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass


# Generated at 2022-06-11 04:39:52.062259
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Generate input for method collect of class FipsFactCollector
    module = None
    collected_facts = None
    fips_facts = FipsFactCollector()
    if fips_facts.collect(module=module, collected_facts=collected_facts):
        assert True
    else:
        assert False

# Generated at 2022-06-11 04:39:53.487811
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert 'fips' in collector.collect()

# Generated at 2022-06-11 04:39:54.518587
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {}

# Generated at 2022-06-11 04:40:03.978217
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import mock
    import os
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule():
        pass

    testmodule = TestModule
    testmodule.params = {}

    test_fips_collector = FipsFactCollector(module=testmodule)

    # Set the effect for the get_file_content method. Content will
    # be fips data if filename is /proc/sys/crypto/fips_enabled
    # otherwise content = 'foo' (filename too long)

# Generated at 2022-06-11 04:40:06.738663
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsCollector = FipsFactCollector()
    fixture_file_name = 'crypto_fips_enabled.txt'
    fips_facts = fipsCollector.collect(collected_facts={'fips': 'false'})
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:40:12.148270
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.system import FipsFactCollector
    ffc = FipsFactCollector()
    assert ffc.collect()

# Generated at 2022-06-11 04:40:22.836900
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()

    # test when fips is enabled
    get_file_content = FipsFactCollector.get_file_content
    def mock_get_file_content(file):
        return '1'
    FipsFactCollector.get_file_content = mock_get_file_content
    fips_facts = collector.collect(None, None)
    assert fips_facts == dict(fips=True)
    FipsFactCollector.get_file_content = get_file_content

    # test when not fips is enabled
    get_file_content = FipsFactCollector.get_file_content
    def mock_get_file_content(file):
        return '0'
    FipsFactCollector.get_file_content = mock_get_file_content
    fips

# Generated at 2022-06-11 04:40:25.569170
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    assert test_obj.collect()['fips'] == False
    
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-11 04:40:27.623328
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == {'fips':False}

# Generated at 2022-06-11 04:40:30.088993
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids = set()
    fips_facts = FipsFactCollector.collect(collected_facts=None)
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:40:33.609738
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    assert 'fips' in Collector.get_facts(fips_fact_collector).keys(), 'Fips facts are not collected'

# Generated at 2022-06-11 04:40:37.148156
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    my_fips = FipsFactCollector()
    fips_facts = my_fips.collect()
    if fips_facts['fips']:
        assert True, "FIPS mode is enabled"
    else:
        assert False, "FIPS mode is not enabled"

# Generated at 2022-06-11 04:40:38.476074
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    F = FipsFactCollector()
    assert F.collect() # Does not return None

# Generated at 2022-06-11 04:40:42.026545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    validate the collect function of FipsFactCollector
    """
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect() == {'fips': False}
    # TODO: mock /proc/sys/crypto/fips_enabled and confirm behaviour

# Generated at 2022-06-11 04:40:44.360348
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector =  FipsFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'fips' in facts.keys()

# Generated at 2022-06-11 04:40:56.739195
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts_obj = FipsFactCollector()
    # Test with a FIPS enabled system
    fips_facts = facts_obj.collect({}, {})
    assert fips_facts['fips'] == True
    assert type(fips_facts['fips']) is bool
    # Test with a non FIPS enabled system
    fips_facts = facts_obj.collect({}, {})
    assert fips_facts['fips'] == False
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-11 04:40:59.546791
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsCollector = FipsFactCollector()
    fips_facts = fipsCollector.collect()
    assert fips_facts == {'fips': False} or fips_facts == {'fips': True}

# Generated at 2022-06-11 04:41:02.584800
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''
    fact_collector = FipsFactCollector()
    fips_fact = fact_collector.collect()
    assert type(fips_fact) is dict

# Generated at 2022-06-11 04:41:04.690578
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-11 04:41:12.369443
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector.collect(), dict)
    assert isinstance(fips_fact_collector.collect({'ansible_processors': {'*': {'model': 'unknown'}}}), dict)
    assert 'fips' in fips_fact_collector.collect({'ansible_processors': {'*': {'model': 'unknown'}}}).keys()
    assert isinstance(fips_fact_collector.collect({'ansible_processors': {'*': {'model': 'unknown'}}}).get('fips'), bool)

# Generated at 2022-06-11 04:41:17.087349
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import tempfile
    fips = FipsFactCollector()
    file = tempfile.NamedTemporaryFile()
    file.write((u'1').encode('utf-8'))
    file.seek(0)
    facts = fips.collect(collected_facts={}, module={})
    assert facts['fips'] == True
    file.close()

# Generated at 2022-06-11 04:41:18.006201
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:21.397123
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Expected results:
    expected_results = {
        'fips': True
    }
    # Collect the facts:
    fips = FipsFactCollector()
    actual_results = fips.collect()
    # Assertion:
    assert actual_results == expected_results

# Generated at 2022-06-11 04:41:22.897922
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:41:25.043725
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()

    assert result['ansible_facts']['fips'] == False

# Generated at 2022-06-11 04:41:40.196336
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    fips_facts['fips'] = True
    fips_facts['fips'] = False

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:41:41.996066
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:43.875941
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False, "fips_facts['fips'] should be False"

# Generated at 2022-06-11 04:41:49.211256
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected = { "fips": False }
    file_content = ""
    mock_get_file_content = MagicMock(return_value=file_content)
    with patch.multiple(FipsFactCollector, get_file_content=mock_get_file_content):
        assert FipsFactCollector().collect() == expected

    expected = { "fips": True }
    file_content = "1"
    mock_get_file_content = MagicMock(return_value=file_content)
    with patch.multiple(FipsFactCollector, get_file_content=mock_get_file_content):
        assert FipsFactCollector().collect() == expected

# Generated at 2022-06-11 04:41:57.120716
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    file_content = """1"""
    file_dict = {'/proc/sys/crypto/fips_enabled': file_content}
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect(file_dict=file_dict)
    assert fips_fact_collector.name == 'fips'
    assert file_dict['/proc/sys/crypto/fips_enabled'] == '1'
    assert fips_fact_collector.read_file('/proc/sys/crypto/fips_enabled') == '1'
    assert fips_fact_collector.collect()['fips'] == True


# Generated at 2022-06-11 04:41:58.675168
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-11 04:42:01.322820
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-11 04:42:07.565844
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''
    fips_facts = FipsFactCollector()
    test_facts = {'fips': True}
    fips_facts.get_file_content = lambda x: '1'
    assert fips_facts.collect() == test_facts
    test_facts = {'fips': False}
    fips_facts.get_file_content = lambda x: ''
    assert fips_facts.collect() == test_facts

# Generated at 2022-06-11 04:42:16.244111
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ''' Unit test for method collect of class FipsFactCollector'''
    def get_file_content(filename):
        '''Stub for module get_file_content'''
        return '1'

    module = None
    collected_facts = None
    fips_facts_collector = FipsFactCollector()
    fips_facts_collector.get_file_content = get_file_content
    fips_facts = fips_facts_collector.collect(module, collected_facts)
    if fips_facts['fips']:
        print("fips_facts is {0}".format(fips_facts))
        print("fips_facts['fips'] is True")
    else:
        print("fips_facts is {0}".format(fips_facts))

# Generated at 2022-06-11 04:42:20.670563
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fake_fact_collector = FipsFactCollector()
    fake_data = b'1'
    fake_facts = {
        'fips': False,
    }

    # Test the case where fips is enabled
    fake_fact_collector.readfile = lambda path: fake_data
    facts = fake_fact_collector.collect(collected_facts=fake_facts)
    assert facts['fips'] == True
    fake_facts = {
        'fips': False,
    }

    # Test the case where fips is not enabled
    fake_data = b'0'
    facts = fake_fact_collector.collect(collected_facts=fake_facts)
    assert facts['fips'] == False

# Generated at 2022-06-11 04:42:50.172084
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fac_col = FipsFactCollector()
    fips_facts = fips_fac_col.collect()
    assert fips_facts.get('fips') == False

# Generated at 2022-06-11 04:42:57.018728
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup mockansible module
    module = MockAnsibleModule()

    # Create a mock FipsFactCollector
    fipsFactCollector = FipsFactCollector()

    # Mock the get_file_content method to always return 1
    fipsFactCollector.get_file_content = Mock(return_value=1)

    # Perform the collect method
    fips_facts = fipsFactCollector.collect()

    # Assert that the fips key exists in the fips_facts dictionary
    assert 'fips' in fips_facts

    # Assert that the fips key has a True value
    assert fips_facts['fips'] is True


# Generated at 2022-06-11 04:43:06.556272
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    sys_fips_file = '/proc/sys/crypto/fips_enabled'
    
    _module_mock = MagicMock()
    _module_mock.params = {'gather_subset': ['all']}
    _module_mock.get_bin_path.return_value = None
    
    _collector = FipsFactCollector()
    
    # Test case: When 
    #  class member sys_fips_file is set to 'None'
    #  and method get_file_content is
    #   returned None for parameter '/proc/sys/crypto/fips_enabled'
    # Then
    #  return fact 'fips': False
    _collector.sys_fips_file = None

# Generated at 2022-06-11 04:43:09.956520
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    FipsFactCollector_obj = FipsFactCollector()
    expected_dict = {'fips': False}
    actual_dict = FipsFactCollector_obj.collect(module, collected_facts)
    assert actual_dict == expected_dict

# Generated at 2022-06-11 04:43:11.434497
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': True}

# Generated at 2022-06-11 04:43:19.874953
# Unit test for method collect of class FipsFactCollector

# Generated at 2022-06-11 04:43:22.147384
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    result = FipsFactCollector_obj.collect()
    assert result['fips'] == True


# Generated at 2022-06-11 04:43:24.028555
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """This unit test provides code coverage for the method FipsFactCollector.collect"""
    from ansible.module_utils.facts import collector
    fips_collector = collector.collect('fips')
    assert type(fips_collector) == dict
    assert fips_collector['fips'] == False


# Generated at 2022-06-11 04:43:26.683143
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    ansible_facts = {}
    fips_facts = fips.collect(collected_facts=ansible_facts)
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:43:28.258052
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': True}

# Generated at 2022-06-11 04:44:35.315660
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  fips_collector = FipsFactCollector()
  assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:44:38.341559
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test fips_facts
    fips_facts = FipsFactCollector().collect()

    assert fips_facts == {} or fips_facts['fips'] is False or fips_facts['fips'] is True

# Generated at 2022-06-11 04:44:39.445053
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-11 04:44:41.461587
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert not c.collect()
    c._content = {'fips': True}
    assert c.collect()


# Generated at 2022-06-11 04:44:44.263859
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-11 04:44:52.514779
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Ensure fips is False when /proc/sys/crypto/fips_enabled is absent
    data = {'/proc/sys/crypto/fips_enabled': None}
    result = FipsFactCollector.collect(data=data)
    assert 'fips' in result
    assert result['fips'] is False

    # Ensure fips is False when /proc/sys/crypto/fips_enabled is present
    # but empty.
    data = {'/proc/sys/crypto/fips_enabled': ''}
    result = FipsFactCollector.collect(data=data)
    assert 'fips' in result
    assert result['fips'] is False

    # Ensure fips is False when /proc/sys/crypto/fips_enabled is non-empty
    # but the content is not 1.
    data

# Generated at 2022-06-11 04:45:02.231429
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    # Initialize the collector
    ansible_collector = Collector()
    # Initialize the class used for testing
    testClass=FipsFactCollector(ansible_collector)

    # Use the "uname -s" output to determine if the system is a Linux
    if 'Linux' in ansible_collector.get_file_content('/proc/version'):

        def get_file_content_side_effect(file_name):
            data = None
            if file_name == '/proc/sys/crypto/fips_enabled':
                data = to_bytes('1')
            return data


# Generated at 2022-06-11 04:45:05.463834
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ansible_module = AnsibleModule()
    fips_fact_collector = FipsFactCollector(ansible_module.set_fact)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:45:09.589963
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    FipsFactCollector_obj = FipsFactCollector()
    fips = FipsFactCollector_obj.collect(module, collected_facts)
    assert fips.get('fips') == False

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:45:11.179222
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with a system in fips mode
    fipsFactCollector = FipsFactCollector()
    result = fipsFactCollector.collect()
    assert result.get('fips') == True


# Generated at 2022-06-11 04:47:44.377823
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': 'False'}

# Generated at 2022-06-11 04:47:45.430045
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    ret = fc.collect()
    assert 'fips' in ret

# Generated at 2022-06-11 04:47:49.584642
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set of known fips facts
    fips_facts = set([
        'fips',
    ])

    # Create instance of FipsFactCollector to gather fips facts
    fips_fact_collector = FipsFactCollector()

    # Attempt to gather fips facts
    fips_facts_gathered = fips_fact_collector.collect()

    # Assert fips facts were gathered
    assert set(fips_facts_gathered.keys()).issuperset(fips_facts)

# Generated at 2022-06-11 04:47:56.641131
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    import pytest

    class MyFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    # mock class
    class MockModule(object):
        def __init__(self, arg1, arg2):
            self.params = arg1
            self.params['test_var'] = arg2
            self.fail_json = self.fail_json_mock

        def fail_json_mock(self, *args, **kwargs):
            return args[0]

    # mock get_file_content

# Generated at 2022-06-11 04:48:01.475680
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()

    # no fips setting
    content = {'crypto': {'fips_enabled': '0'}}
    result = ffc.collect(None, content)
    assert result['fips'] is False

    # fips is set
    content = {'crypto': {'fips_enabled': '1'}}
    result = ffc.collect(None, content)
    assert result['fips'] is True

# Generated at 2022-06-11 04:48:02.984330
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector({}).collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-11 04:48:06.729682
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_facts_result = FipsFactCollector_obj.collect()
    fips_facts_expected_result = {
        'fips': False
    }
    assert fips_facts_result == fips_facts_expected_result, "Test for FipsFactCollector collect method failed!"

# Generated at 2022-06-11 04:48:08.276884
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect() == { 'fips': False }

# Generated at 2022-06-11 04:48:09.091554
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect({}, None)

# Generated at 2022-06-11 04:48:11.095540
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.collect() == {'fips': False}
