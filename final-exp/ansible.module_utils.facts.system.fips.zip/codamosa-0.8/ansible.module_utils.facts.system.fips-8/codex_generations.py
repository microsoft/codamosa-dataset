

# Generated at 2022-06-11 04:38:46.252515
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector.collect()
    assert result == {
        'fips': True
    }

# Generated at 2022-06-11 04:38:48.079090
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:38:51.286595
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect(): # pylint: disable=invalid-name
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['fips'] is False

# Generated at 2022-06-11 04:38:52.924847
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-11 04:38:54.334451
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect()['fips'] == False

# Generated at 2022-06-11 04:38:55.565048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-11 04:39:05.848539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    fipsfc = FipsFactCollector()

    # Check if fips is False when data is 0
    data = [0]
    old_fc = fipsfc.get_file_content
    fipsfc.get_file_content = lambda x: data.pop()
    collected_facts = {}
    assert fipsfc.collect(collected_facts=collected_facts) == {'fips': False}
    fipsfc.get_file_content = old_fc

    # Check if fips is True when data is 1
    data = [1]
    old_fc = fipsfc.get_file_content
    fipsfc.get_file_content = lambda x: data.pop()
    collected_facts = {}

# Generated at 2022-06-11 04:39:14.799240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector."""

    # No FIPS
    def __get_file_content(path):
        return '0'

    fips_fact_collector = FipsFactCollector()
    fact = fips_fact_collector.collect(get_file_content=__get_file_content)
    assert fact['fips'] == False
 
    # FIPS
    def __get_file_content(path):
        return '1'

    fips_fact_collector = FipsFactCollector()
    fact = fips_fact_collector.collect(get_file_content=__get_file_content)
    assert fact['fips'] == True

# Generated at 2022-06-11 04:39:16.348178
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect() == {'fips': False}

# Generated at 2022-06-11 04:39:22.012541
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create the object that will be tested
    fips_fact_collector = FipsFactCollector()
    # The fips fact is retrieved from the /proc/sys/crypto/fips_enabled file
    facts = fips_fact_collector.collect()
    # The facts dictionary should only have one entry in it
    assert len(facts) == 1
    # and that fact should be fips, and should be identifiable as a boolean
    assert facts['fips'] is False or facts['fips'] is True


# Generated at 2022-06-11 04:39:27.376729
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    fips_facts = fipsFactCollector.collect()
    assert fips_facts == {'fips': False}

# Generated at 2022-06-11 04:39:33.021719
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content

    data = get_file_content('../data/fips_enabled')
    with open("/proc/sys/crypto/fips_enabled", "w") as file:
        file.write(data)

    fipsFactCollector = FipsFactCollector()
    result = fipsFactCollector.collect()
    assert result == {'fips': True}

# Generated at 2022-06-11 04:39:35.581455
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert 'fips' in facts
    assert facts['fips'] in [True, False]

# Generated at 2022-06-11 04:39:38.996619
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    facts = fips_fact.collect()
    assert facts['fips'] == False
    facts = fips_fact.collect(collected_facts={})
    assert facts['fips'] == False

if __name__ == '__main__':
    print('Loading gathered_facts')

# Generated at 2022-06-11 04:39:39.702798
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect()

# Generated at 2022-06-11 04:39:47.957806
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class MockModule:
        pass
    class MockCollector:
        def __init__(self, contents):
            self.contents = contents
        def read(self):
            return self.contents
    x = FipsFactCollector()
    m = MockModule()
    good_return = {
        'fips': True,
    }
    bad_return = {
        'fips': False,
    }
    m.get_file_content = lambda x: MockCollector('1')
    assert x.collect(m) == good_return
    m.get_file_content = lambda x: MockCollector('0')
    assert x.collect(m) == bad_return

# Generated at 2022-06-11 04:39:58.237879
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_fips
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_fips
    import os
    import pytest
    def collect(self, module=None, collected_facts=None):
        return {'fips': True}

    def get_file_content(file):
        return '1'

    with pytest.raises(AttributeError):
        ansible_fips

    ansible_collector.collect_fips_facts = collect
    ansible_collected_fips = ansible_collector.collect(None, ansible_collected_fips)

    assert ansible_collected_fips['fips'] == True


# Generated at 2022-06-11 04:39:59.869990
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:07.422448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Unit test for method collect of class FipsFactCollector """
    # NOTE: use get_file_content to get the same result
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    FactCollector.collectors = []
    FactCollector.collectors.append(Collector('FipsFactCollector', 'fips'))
    fips_facts = FactCollector.get_facts(None, {}, {})
    assert fips_facts['fips'] == get_file_content('/proc/sys/crypto/fips_enabled') == '1'

# Generated at 2022-06-11 04:40:17.497501
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.utils as utils
    import mock
    import collections

    def test_fips_collector(test_module=None,test_collected_facts=None):
        tcollected_facts = collections.OrderedDict()
        tfips_facts = collections.OrderedDict()
        tfips_facts['fips'] = False
        test_data = utils.get_file_content('/proc/sys/crypto/fips_enabled')
        if test_data and test_data == '1':
            tfips_facts['fips'] = True
        tcollected_

# Generated at 2022-06-11 04:40:28.457071
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    import os
    import tempfile

    temp_fd, temp_path = tempfile.mkstemp()
  
    f = os.fdopen(temp_fd, 'wb')
    f.write(to_bytes(b"1"))
    f.close()

    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False

    fact_collector = FactCollector(None, None, list())
    fips_collector = FipsFactCollector(None, fact_collector, None)


# Generated at 2022-06-11 04:40:30.010236
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert not fips.collect()['fips']

# Generated at 2022-06-11 04:40:32.515547
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert isinstance(result, dict)


# Unit test that there is not an exception thrown due to get_file_content method
# not being called

# Generated at 2022-06-11 04:40:35.204545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips = FipsFactCollector()

    fips.files['/proc/sys/crypto/fips_enabled'] = "1"

    assert fips.collect() == {'fips': True}

# Generated at 2022-06-11 04:40:38.060347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Unit test for method collect of class FipsFactCollector
    '''
    fips_facts = FipsFactCollector()
    assert fips_facts.collect()['fips'] == False

# Generated at 2022-06-11 04:40:40.329876
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids.add('fips')
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-11 04:40:45.251977
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    test_fips_collector = FipsFactCollector()
    test_fips_collector.file_exists = lambda x: True
    test_fips_collector.get_file_content = lambda x: '0'

    # Act
    fips_facts = test_fips_collector.collect()

    # Assert
    assert(fips_facts['fips'] == False)


# Generated at 2022-06-11 04:40:47.059545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfc = FipsFactCollector()

    # Test default return value
    assert fipsfc.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:50.160669
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    fips_collector = FipsFactCollector()
    # Execute method collect of class FipsFactCollector
    result = fips_collector.collect()
    assert result is not None
# end of test_FipsFactCollector_collect()



# Generated at 2022-06-11 04:40:52.040569
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect()['fips'] is False  # pylint: disable=unsubscriptable-object

# Generated at 2022-06-11 04:41:07.180140
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fallback = {'fips': False}
    fips_true = {'fips': True}

    # Case where file does not exist - return fallback value
    fc = FipsFactCollector()
    mocked_get_file_content = lambda x: None
    fc.get_file_content = mocked_get_file_content
    assert fc.collect() == fips_fallback

    # Case where file exists but contains bad data - return fallback value
    fc = FipsFactCollector()
    mocked_get_file_content = lambda x: 'bad data'
    fc.get_file_content = mocked_get_file_content
    assert fc.collect() == fips_fallback

    # Case where file exists and contains '0' - return fallback value
    fc = Fips

# Generated at 2022-06-11 04:41:09.139135
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    _FipsFactCollector = FipsFactCollector()
    assert {} == _FipsFactCollector.collect()


# Generated at 2022-06-11 04:41:13.055379
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('fips/proc_sys_crypto_fips_enabled', 'r') as mock_fips_enabled:
        mock_collector = FipsFactCollector()
        assert mock_collector.collect({}, {})['fips'] == False, "fips should be false"


# Generated at 2022-06-11 04:41:18.201247
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    # On my system I have FIPS enabled, so the 'fips' key would contain
    # a boolean value of 'True'
    test = fips_fact.collect()
    assert isinstance(test, dict)
    assert 'fips' in test
    assert isinstance(test['fips'], bool)

# Generated at 2022-06-11 04:41:20.376900
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFact = FipsFactCollector()
    fips=fipsFact.collect()
    assert fips['fips'] == False

# Generated at 2022-06-11 04:41:21.577240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    gen = FipsFactCollector()
    assert gen.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:29.210873
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import TestAnsibleModule
    TestAnsibleModule().patch_common_return_values()
    TestAnsibleModule().patch_collection_default()
    TestAnsibleModule().patch_get_file_content()
    TestAnsibleModule().patch_get_distribution()
    TestAnsibleModule().patch_get_distribution_release()
    TestAnsibleModule().patch_get_os_type()

    fips_facts = FipsFactCollector.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-11 04:41:29.726163
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:41:38.491802
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Check that fips_facts is populated properly when fips is enabled
    test_FipsFactCollector = FipsFactCollector()
    # When fips is enabled in the system then fips_facts['fips'] must
    # be true
    test_FipsFactCollector.get_file_content = lambda x: '1'
    fips_facts = test_FipsFactCollector.collect()
    if fips_facts['fips'] is False:
        raise Exception('fips_facts is not populated properly')

    # Check that fips_facts is populated properly when fips is not enabled
    test_FipsFactCollector = FipsFactCollector()
    # When fips is enabled in the system then fips_facts['fips'] must
    # be true
    test_FipsFactCollector.get_file_

# Generated at 2022-06-11 04:41:40.726159
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect(collected_facts={})
    assert result['fips'] == False

# Generated at 2022-06-11 04:41:48.866623
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_result = fips.collect()
    if fips_result.values()[0] == True:
       assert True
    else:
       assert False

# Generated at 2022-06-11 04:41:52.660449
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module = None
    fips_fact_collector._collector = None
    fips_facts = fips_fact_collector.collect(module=None, collected_facts=None)
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:41:54.047971
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:41:56.017073
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert not fips_fc.fips

# Generated at 2022-06-11 04:42:02.611966
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Setup an object of FipsFactCollector class
    fips_fact_collector = FipsFactCollector()

    # lookup a colleted_facts that is populated by FipsFactCollector
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] == False
    # TODO: make a mock of /proc/sys/crypto/fips_enabled file for this test to pass
    # assert collected_facts['fips'] == True

# Generated at 2022-06-11 04:42:09.287775
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # fips_enabled = os.environ.get('FIPS_ENABLED', 'no')

    fips_enabled = '1'
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write(fips_enabled)

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()

    if fips_enabled == '1':
        assert fips_facts['fips'] == True
    else:
        assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:42:12.390333
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class MockModuleUtilsFactsUtils:
        pass

    class MockCollectorUtils:
        pass

    fips_content = MockModuleUtilsFactsUtils()
    collector_utils = MockCollectorUtils()
    fips_collector = FipsFactCollector(fips_content, collector_utils)
    assert fips_collector.collect() == {}

# Generated at 2022-06-11 04:42:21.658878
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.network.fips import FipsFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    connection = MagicMock()
    connection.get_file_content.return_value = to_bytes('1')

    fips = FipsFactCollector()
    fips.connection = connection
    fips.collect()
    fips.collect()
    fips.collect()
    fips.collect()
    
    assert connection.get_file_content.call_count == 1
    assert fips.__class__ == FipsFactCollector

# Generated at 2022-06-11 04:42:23.515565
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_facts = FipsFactCollector_obj.collect()
    assert fips_facts

# Generated at 2022-06-11 04:42:26.200665
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create a FipsFactCollector instance
    fipsfactcollector_instance = FipsFactCollector()

    assert fipsfactcollector_instance is not None
    assert fipsfactcollector_instance.collect() == { 'fips' : False }

# Generated at 2022-06-11 04:42:41.308243
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect()

    assert fips_facts['fips'] is False

# Generated at 2022-06-11 04:42:42.659008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect()['fips']

# Generated at 2022-06-11 04:42:44.117190
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    assert(result == {'fips': False})

# Generated at 2022-06-11 04:42:48.854662
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    fips_facts = FipsFactCollector.collect(None)
    assert fips_facts['fips'] is False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert fips_facts['fips'] is True

# Generated at 2022-06-11 04:42:51.939113
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_factcollector = FipsFactCollector()
    fips_collector_return_value=fips_factcollector.collect()
    fips_status=fips_collector_return_value['fips']
    assert fips_status == False

# Generated at 2022-06-11 04:42:54.420312
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    module = Mock()
    collected_facts = Mock()
    fips_facts = collector.collect(module=module, collected_facts=collected_facts)
    assert fips_facts == {"fips": False}

# Generated at 2022-06-11 04:43:03.725366
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # (1) Test-cases with valid inputs
    # Test case 1: test_result_positive
    #      Inputs:
    #          Contents of /proc/sys/crypto/fips_enabled: 1
    #      Expected Outputs:
    #          {'fips': True}
    test_case_1 = {
        'inputs': {
            'proc_content': "1"
        },
        'expected_outputs': {
            'fips_facts': {
                'fips': True
            }
        }
    }

    # Test case 2: test_result_negative
    #      Inputs:
    #          Contents of /proc/sys/crypto/fips_enabled: 0
    #      Expected Outputs:
    #          {'fips': False}
    test_case_2

# Generated at 2022-06-11 04:43:11.028959
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content_dummy(file_name):
        yield file_name == '/proc/sys/crypto/fips_enabled'
        yield '1'

    # NOTE: mock is used to mock object for testing, we should not use mock for production code
    from mock import patch

    with patch.object(FipsFactCollector, 'get_file_content', get_file_content_dummy):
        fips_fact_collector = FipsFactCollector()
        fips_facts = fips_fact_collector.collect()
        expected_fips_facts = {
            'fips': True
        }
        assert fips_facts == expected_fips_facts

# Generated at 2022-06-11 04:43:13.197165
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfactcollector_obj = FipsFactCollector()
    assert not fipsfactcollector_obj.collect()
    del fipsfactcollector_obj


# Generated at 2022-06-11 04:43:15.869636
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('/proc/sys/crypto/fips_enabled', mode='w') as f:
        f.write('1')

    collector = FipsFactCollector()
    fips = collector.collect()
    assert fips['fips'] == True

# Generated at 2022-06-11 04:43:51.797525
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    non_fips_content = '''\
0
'''
    fips_content = '''\
1
'''

    import mock
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    mocked_open = mock.mock_open(read_data=fips_content)
    FipsFactCollector.FACT_FILE = 'fips_enabled'

    with mock.patch.object(FipsFactCollector, '_read_file_on_system', return_value=non_fips_content):
        ffc = FipsFactCollector()
        fips_facts = ffc.collect()
        assert isinstance(fips_facts['fips'], bool)
        assert not fips_facts['fips']


# Generated at 2022-06-11 04:43:53.309754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    facts = fc.collect()
    assert facts['fips'] == False


# Generated at 2022-06-11 04:43:54.617540
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert(f.collect()['fips'] == False)

# Generated at 2022-06-11 04:43:59.886795
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    fips_coll = FipsFactCollector()
    get_file_content = MagicMock(return_value='1')
    fips_coll.get_file_content = get_file_content
    # Call method collect of class FipsFactCollector
    fips_facts = fips_coll.collect()
    assert fips_facts == {'fips': True}

# Generated at 2022-06-11 04:44:06.942390
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test function for ansible.module_utils.facts.system.fips.FipsFactCollector.collect
    """
    def content_of_file(file_path):
        if file_path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return ''

    example_dict = {'fips': False}
    m_get_file_content = 'ansible.module_utils.facts.utils.get_file_content'
    with mock.patch(m_get_file_content) as m_get_file_content:
        m_get_file_content.side_effect = content_of_file
        fipsc = FipsFactCollector()
        result = fipsc.collect()
        assert result == example_dict

    # ensure that false is returned if proc file does not

# Generated at 2022-06-11 04:44:08.945688
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class_obj = FipsFactCollector()
    fips_facts = class_obj.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:44:10.148907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    collector = FipsFactCollector()

    results = collector.collect()
    assert results == {'fips': False}

# Generated at 2022-06-11 04:44:12.948977
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class Module:
        pass

    # testing for FIPS mode
    module = Module()
    result = FipsFactCollector(module).collect()
    assert result['fips'] == False

    # testing for non-FIPS mode
    result = FipsFactCollector(module).collect()
    assert result['fips'] == False

# Generated at 2022-06-11 04:44:15.741827
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert type(fips_facts) == dict
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) == bool

# Generated at 2022-06-11 04:44:25.197124
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.system.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    import pytest
    import os

    class mock_get_file_content():
        def __init__(self, content=""):
            self.content = content

        def __call__(self, path):
            return self.content

    def mock_open(content=""):
        return mock_get_file_content(content)

    def mock_os_stat_exists(fname):
        return True

    def mock_get_file_content_raise(path):
        raise OSError

    monkeypatch = pytest.monkeypatch()
    fips_fact = Fips

# Generated at 2022-06-11 04:45:25.228857
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:25.712752
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:45:29.152761
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.collect') as collect_mock:
        fips_facts = FipsFactCollector.collect()

    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:45:30.548340
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect()['fips'] == False

# Generated at 2022-06-11 04:45:32.042340
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    FipsFactCollector.collect()

# Generated at 2022-06-11 04:45:34.900336
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect()['fips'] == False
    fc = FipsFactCollector(content={'/proc/sys/crypto/fips_enabled': '1'})
    assert fc.collect()['fips'] == True

# Generated at 2022-06-11 04:45:36.050818
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}


# Generated at 2022-06-11 04:45:40.528841
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test the FipsFactCollector.collect method"""

    # Create the instance to test
    fips_fc = FipsFactCollector()

    # The collected_facts are not set
    assert fips_fc.collect(collected_facts=None) == {'fips': False}

    # The fips is set
    fips_fc.collect_file_lines = {'/proc/sys/crypto/fips_enabled': '1'}
    assert fips_fc.collect(collected_facts=None) == {'fips': True}

# Generated at 2022-06-11 04:45:40.948685
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:45:43.007218
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-11 04:48:11.915178
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_facts = FipsFactCollector_obj.collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-11 04:48:13.934142
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector(None)
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-11 04:48:15.076015
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert 'fips' in FipsFactCollector().collect()

# Generated at 2022-06-11 04:48:16.785165
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {u'fips': False}
    assert FipsFactCollector.collect() == fips_facts


# Generated at 2022-06-11 04:48:18.505913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-11 04:48:26.116818
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_module
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os.path

    def mock_get_file_content(file_name):
        if file_name == '/proc/sys/crypto/fips_enabled':
            return '1'

    saved_get_file_content = FipsFactCollector.get_file_content
    FipsFactCollector.get_file_content = mock_get_file_content

    try:
        result = collector_module.collect(FipsFactCollector, None)
        assert result == {'fips': True}
    finally:
        FipsFactCollector.get_file_content

# Generated at 2022-06-11 04:48:26.963586
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == { "fips": False }

# Generated at 2022-06-11 04:48:35.187822
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_fips_true = '''
    # cat /proc/sys/crypto/fips_enabled
    1
    #
    '''

    test_fips_false = '''
    # cat /proc/sys/crypto/fips_enabled
    0
    #
    '''

    default_collect_input_args = dict(
        module=None,
        collected_facts=dict()
    )

    fips_args_true = dict(
        stdout=test_fips_true
    )

    fips_args_false = dict(
        stdout=test_fips_false
    )

    expected_fips_true = dict(
        fips=True
    )

    expected_fips_false = dict(
        fips=False
    )

    fips_collector

# Generated at 2022-06-11 04:48:39.595100
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector(None)

    # Arrange
    def mock_get_file_content(file_location):
        file_content = '1'
        return file_content

    # Act
    fips_collector.get_file_content = mock_get_file_content
    fips_facts = fips_collector.collect()

    # Assert
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:48:41.504916
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    fips_facts = fips_fact_collector.collect()

    assert fips_facts['fips'] == False