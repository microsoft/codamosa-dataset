

# Generated at 2022-06-11 04:38:45.333279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-11 04:38:54.333916
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()

    # Test 1: data is populated and 'fips' should be True
    tmp = ['1\n']
    ffc.module.get_bin_path = lambda x: ''
    ffc.module.check_mode = False
    ffc.read_file = lambda x: tmp.pop()

    assert ffc.collect() == {'fips': True}

    # Test 2: data is populated and 'fips' should be False
    tmp = ['0\n']
    ffc.module.get_bin_path = lambda x: ''
    ffc.module.check_mode = False
    ffc.read_file = lambda x: tmp.pop()

    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-11 04:38:56.298444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    obj = FipsFactCollector()
    obj.collect(module, collected_facts)

# Generated at 2022-06-11 04:39:01.096866
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = '1'
    test_obj = FipsFactCollector()
    path = '/proc/sys/crypto/fips_enabled'
    test_obj.read_file = lambda x, encoding=None: fips_data
    res_data = { 'fips': True }
    assert res_data == test_obj.collect()

# Generated at 2022-06-11 04:39:03.180956
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-11 04:39:05.435382
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# vim: expandtab:ts=4:sw=4

# Generated at 2022-06-11 04:39:09.802136
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test with a real file, bad cases will raise exception """
    from ansible.module_utils.facts import collector
    FipsFactCollector = collector.get_collector('fips')
    fips_facts = FipsFactCollector().collect()
    assert not fips_facts['fips']

# Generated at 2022-06-11 04:39:18.547926
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()

    # Test method with /proc/sys/crypto/fips_enabled file present, but
    # no content in it
    fake_path_empty_file = '/tmp/fips_enabled_no_content'
    with open(fake_path_empty_file, 'w'):
        # create an empty file
        pass
    result = fact_collector.collect(module=None, collected_facts=None)
    assert result == {'fips': False}
    result = fact_collector.collect(module=None, collected_facts=None)
    assert result == {'fips': False}

    # Test method with /proc/sys/crypto/fips_enabled file present, but
    # content is '0'
    fake_path_file_with_content_0

# Generated at 2022-06-11 04:39:20.133299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] is False

# Generated at 2022-06-11 04:39:21.396989
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-11 04:39:26.795659
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    FipsFactCollector.name = 'fips'
    FipsFactCollector._fact_ids = set()
    FipsFactCollector.collect()
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:39:29.361981
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()

    # When
    fips_facts = test_obj.collect()

    # Then
    assert fips_facts.get('fips')

# Generated at 2022-06-11 04:39:32.625196
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class MockModule(object):
        pass
    module = MockModule()
    fips_collector = FipsFactCollector(module)
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:39:36.575043
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert isinstance(fips_fc.collect(), dict)
    if fips_fc.collect()['fips']:
        assert fips_fc.collect()['fips'] == True
    else:
        assert fips_fc.collect()['fips'] == False

# Generated at 2022-06-11 04:39:39.316165
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    contents = get_file_content('/proc/sys/crypto/fips_enabled')
    if contents == '1':
        assert facts['fips']
    else:
        assert not facts['fips']

# Generated at 2022-06-11 04:39:43.292356
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: file is not created
    ff = FipsFactCollector()
    f_facts = ff.collect()
    assert isinstance(f_facts, dict)
    assert not f_facts.get('fips')
    for fact in ['fips']:
        assert fact not in ff._fact_ids

# Generated at 2022-06-11 04:39:45.378072
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
        Test collect method of FipsFactCollector
    '''
    assert FipsFactCollector().collect()['fips'] == False

# Generated at 2022-06-11 04:39:48.369147
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts_data = fact_collector.collect()
    assert('fips' in facts_data)
    assert(facts_data['fips'] == False)

# Generated at 2022-06-11 04:39:50.936904
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_test_collector = FipsFactCollector()
    facts = fips_test_collector.collect(None, None)
    assert facts['fips'] == False

# Generated at 2022-06-11 04:39:55.062203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect(module=None, collected_facts=None)
    # assert fips state
    assert 'fips' in collected_facts
    assert isinstance(collected_facts['fips'], bool)

# Generated at 2022-06-11 04:40:04.413804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    fips_fact_collector._module = type('', (), {'run_command':run_command})
    fips_fact_collector._module.params = {}

    res = fips_fact_collector.collect(None, None)

    assert 'fips' in res
    assert res['fips'] == False

    # Test response for fips_enabled == 1
    res = fips_fact_collector.collect(None, None)

    assert 'fips' in res
    assert res['fips'] == True

# Generated at 2022-06-11 04:40:09.562279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # If the fips_enabled file returns the value 1, Ansible should consider the
    # system to be in fips mode.
    fake_file = '1\n'
    fips_facts = FipsFactCollector.collect(None, fake_file)
    assert fips_facts['fips'] == True

    # If the fips_enabled file returns empty or any value other than 1, Ansible
    # should consider the system not to be in fips mode.
    expected_fips_facts = {'fips': False}
    for fake_file in ['', '2\n']:
        fips_facts = FipsFactCollector.collect(None, fake_file)
        assert fips_facts == expected_fips_facts

# Generated at 2022-06-11 04:40:20.376203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_open_if_exists
    import ansible.module_utils.facts.collectors.fips

    MockModule = mock_module(ansible.module_utils.facts.collectors.fips)

    mock_open = mock_open_if_exists(data='0')

    with mock.patch('ansible.module_utils.facts.collectors.fips.open', mock_open, create=True):
        with mock.patch.object(MockModule, 'open_if_exists') as mock_open_if_exists:
            mock_open_if_exists.return_value = False
            collector = FipsFactCollector()

# Generated at 2022-06-11 04:40:22.419764
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-11 04:40:28.141179
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    fips_fc = FipsFactCollector()
    fips_fc.collect()
    assert 'fips' in Collector.collected_facts['ansible_local']['fips']
    assert Collector.collected_facts['ansible_local']['fips']['fips'] == False
    fips_fc._read_file = lambda x: '1'
    fips_fc.collect()
    assert Collector.collected_facts['ansible_local']['fips']['fips'] == True

# Generated at 2022-06-11 04:40:30.369107
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect(None, {})
    assert type(facts['fips']) == bool

# Generated at 2022-06-11 04:40:31.903040
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = FipsFactCollector().collect()
    assert collected_facts['fips'] in (True, False)

# Generated at 2022-06-11 04:40:33.784891
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = FipsFactCollector().collect()
    assert isinstance(fips_data['fips'], bool)

# Generated at 2022-06-11 04:40:36.565954
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    fips_facts = fips_facts_collector.collect()
    assert 'fips' in fips_facts.keys()

# Generated at 2022-06-11 04:40:39.343619
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {'fips': False}
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-11 04:40:49.354963
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collector.get_file_content = mock_get_file_content
    fips_facts = collector.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts.keys()
    assert type(fips_facts['fips']) is bool

# mock for method get_file_content of class FipsFactCollector

# Generated at 2022-06-11 04:40:58.924784
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = ansible_module_mock
    mock_module.params = {}

    mock_collector = FipsFactCollector()

    def get_file_content_side_effect(arg):
        if arg == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return None

    mock_get_file_content = mock.Mock(side_effect=get_file_content_side_effect)
    with mock.patch('ansible.module_utils.facts.collector.FactsCollector._get_file_content', mock_get_file_content):
        fips_facts = mock_collector.collect(mock_module)
        assert fips_facts['fips'] == True


# Generated at 2022-06-11 04:41:00.521913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:05.229009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector.
    """
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert 'fips' in collected_facts.keys()
    assert isinstance(collected_facts['fips'], bool)

# Generated at 2022-06-11 04:41:08.101673
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize
    test_obj = FipsFactCollector()
    # Execute code to be tested
    result = test_obj.collect()
    # Verify the result
    assert result == {'fips': False}

# Generated at 2022-06-11 04:41:10.297388
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    output = FipsFactCollector._collect(FipsFactCollector())
    assert output == { 'fips': False }


# Generated at 2022-06-11 04:41:20.215551
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectFactsModule
    from ansible.module_utils.facts.oem.hardware.fips import FipsFactCollector
    import os
    import os.path
    import sys

    class MockModule(CollectFactsModule):
        def __init__(self):
            super(MockModule, self).__init__()
            self.tmpdir = tempfile.mkdtemp()
            self.collect_facts = True

        def run(self, *args, **kwargs):
            return {
                'fips': False,
            }

        def exit_json(self, *args, **kwargs):
            try:
                shutil.rmtree(self.tmpdir)
            except OSError:
                pass


# Generated at 2022-06-11 04:41:26.189870
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with patch('ansible.module_utils.facts.collector.get_file_content') as mock:

        mock.return_value='0'
        sut = FipsFactCollector(None, None)
        actual = sut.collect(None, None)
        expected = {'fips': False}
        assert expected == actual

        mock.return_value='1'
        sut = FipsFactCollector(None, None)
        actual = sut.collect(None, None)
        expected = {'fips': True}
        assert expected == actual

# Generated at 2022-06-11 04:41:27.335221
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert {'fips': False} == FipsFactCollector().collect()

# Generated at 2022-06-11 04:41:28.505209
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    print(fc.collect())

# Generated at 2022-06-11 04:41:39.366586
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = dict()
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert type(fips_facts.keys()) is list
    assert fips_facts.keys() == ['fips']
    assert fips_facts['fips'] == False or fips_facts['fips'] == True

# Generated at 2022-06-11 04:41:40.834468
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    assert fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:41.929603
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test to collect fips fact
    """
    this_test = FipsFactCollector()
    assert this_test.collect()

# Generated at 2022-06-11 04:41:46.925388
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test when FIPS is enabled
    testdata = "1"
    def get_file_content_stub(path):
        return testdata

    FipsFactCollector.get_file_content = get_file_content_stub
    collected_facts = FipsFactCollector().collect()
    assert collected_facts['fips'] == True

    # Test when FIPS is not enabled
    testdata = "0"
    collected_facts = FipsFactCollector().collect()
    assert collected_facts['fips'] == False

# Generated at 2022-06-11 04:41:48.705433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:49.189342
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:41:58.432350
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize class _fact_ids
    FipsFactCollector._fact_ids = set()
    
    # Rule 1: Value of /proc/sys/crypto/fips_enabled is 0, return fips = False
    fips_fact_collector = FipsFactCollector()
    fs = {'/proc/sys/crypto/fips_enabled': '0'}
    facts = fips_fact_collector.collect(None, None, fs)
    expected_facts = {'fips': False}
    assert facts == expected_facts

    # Rule 2: Value of /proc/sys/crypto/fips_enabled is 1, return fips = True
    fips_fact_collector = FipsFactCollector()
    fs = {'/proc/sys/crypto/fips_enabled': '1'}


# Generated at 2022-06-11 04:42:05.558677
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect function"""
    # Module to unit test
    import ansible.module_utils.facts.collector

    # Unit test collector
    collector = FipsFactCollector(
        module=None,
        collected_facts=None
    )

    # Test collect
    fips_facts = collector.collect()

    # Assertions
    assert fips_facts is not None
    assert isinstance(fips_facts, dict)
    assert fips_facts['fips'] is False

# Generated at 2022-06-11 04:42:07.724434
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # Using assert_equal as mock patch doesn't work
    # assert_equals
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:42:16.441848
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    from ansible.module_utils.facts.collectors.fips import get_file_content

    def get_file_content_side_effect(path):
        return path_to_content.get(path)

    path_to_content = {}
    utils.get_file_content = get_file_content_side_effect

    path_to_content['/proc/sys/crypto/fips_enabled'] = b'0'

   

# Generated at 2022-06-11 04:42:30.388343
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_FipsFactCollector = FipsFactCollector()
    assert test_FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-11 04:42:31.553541
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {
        'fips': False
    }

# Generated at 2022-06-11 04:42:40.593196
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # We are not able to easily test a real non fips system and
    # even if we were, a real system would shadow the fake /proc/sys/crypto/fips_enabled
    # file.  Instead we test the case where the fake file is modified to
    # contain a valid fips=1 value which should set the fips fact to True
    # and then test the case where it is modified to contain any other value
    # which should set the fips fact to False
    collector.module = True
    collector.module.file_exists = lambda x: True
    collector.module.get_file_content = lambda x: "1"
    fips_facts = collector.collect()
    assert(fips_facts['fips'] == True)

# Generated at 2022-06-11 04:42:45.284027
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create object
    fips_fact_collector = FipsFactCollector()
    # create mock module object
    module_mock = type('module_mock', (), {
        'exit_json': lambda x: None,
    })

    # run collect
    result = fips_fact_collector.collect(module=module_mock)

    # assert
    assert result == {'fips': False}

# Generated at 2022-06-11 04:42:53.269876
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FipsFactCollector
    import mock

    mock_open = mock.mock_open(read_data='1')
    test_obj = FipsFactCollector()

    with mock.patch('ansible.module_utils.facts.utils.open', mock_open, create=True):
        result = test_obj.collect()
        assert type(result) == dict
        assert result['fips'] == True

    mock_open = mock.mock_open(read_data='0')
    test_obj = FipsFactCollector()

    with mock.patch('ansible.module_utils.facts.utils.open', mock_open, create=True):
        result = test_obj.collect()
        assert type(result) == dict
        assert result['fips'] == False

# Generated at 2022-06-11 04:42:55.402990
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:42:59.270995
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Returns ansible_facts
    :return:
    """
    facter = FipsFactCollector()
    ansible_facts_facter =  facter.facter()
    assert isinstance(ansible_facts_facter, dict)
    assert ansible_facts_facter['ansible_fips'] == False

# Generated at 2022-06-11 04:43:05.187689
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m = __name__ + '.test_FipsFactCollector_collect'
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-11 04:43:13.418802
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # In fips mode
    fips_facts = {
        'fips': True,
    }

    # Not in fips mode
    non_fips_facts = {
        'fips': False,
    }

    fc = FipsFactCollector()
    fc.collect_fn = lambda: {'fips': fc.get_fips_enabled()}
    for key in fips_facts:
        assert fips_facts[key] == fc.collect()[key], \
            'Failed to get facts for fips in mode'
    fc.collect_fn = lambda: {'fips': not fc.get_fips_enabled()}

# Generated at 2022-06-11 04:43:17.088689
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._load_cache = BaseFactCollector._load_cache
    FipsFactCollector._write_cache = BaseFactCollector._write_cache
    FipsFactCollector.get_file_content = get_file_content
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:43:49.582436
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    returned_facts = fips_fact_collector.collect()
    fips_fact = returned_facts['fips']
    assert fips_fact == True or fips_fact == False

# Generated at 2022-06-11 04:43:50.864668
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == { 'fips' : False }

# Generated at 2022-06-11 04:43:56.751594
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def mock_get_file_content(file_name):
        if file_name == "/proc/sys/crypto/fips_enabled":
            return "1"
        else:
            return ""
    mock_module = type('module', (object,), {})()
    mock_module.get_file_content = mock_get_file_content
    fipsfc = FipsFactCollector()
    mock_collector_facts = {
        "fips": "test_fips",
    }
    fips_facts = fipsfc.collect(mock_module, mock_collector_facts)
    assert fips_facts['fips'] == True


# Generated at 2022-06-11 04:44:04.171590
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import sys
    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.fips import FipsFactCollector

    collector = FipsFactCollector()

    def get_file_content_mock(file_path):
        return '1'

    # Test when fips_enabled == 1
    get_file_content_real = get_file_content
    get_file_content.side_effect = get_file_content_mock

    fips = collector.collect()

    get_file_content = get_file_content_real

    assert fips['fips'] == True

    # Test when fips_enabled != 1

# Generated at 2022-06-11 04:44:06.296627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = object
    collected_facts = {}

    fips_facts = FipsFactCollector()
    result = fips_facts.collect(module, collected_facts)

    assert result['fips'] is False

# Generated at 2022-06-11 04:44:08.823261
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_instance = FipsFactCollector()
    result = fips_instance.collect(module=None, collected_facts=None)
    assert isinstance(result, dict)
    assert 'fips' in result
    assert isinstance(result['fips'], bool)

# Generated at 2022-06-11 04:44:10.298793
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    facts = fc.collect()
    assert facts['fips'] == False


# Generated at 2022-06-11 04:44:13.376301
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with file exists
    collector = FipsFactCollector()
    collector._get_file_content = lambda x: 1
    assert collector.collect() == {'fips': True}
    # Test with file does not exists
    collector = FipsFactCollector()
    collector._get_file_content = lambda x: None
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:44:15.271960
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert facts['fips'] is False

# Generated at 2022-06-11 04:44:18.141852
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture = FipsFactCollector()
    with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.collect', return_value = {}):
        assert fixture.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:22.558482
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = NopModule()
    theFactCollector = FipsFactCollector(module=module)
    assert theFactCollector.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:23.845086
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector({}, {})
    assert fc.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:32.718508
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        delattr(FipsFactCollector, '_fact_ids')
    except AttributeError:
        pass

    collected_facts = {}

    def get_file_content_mock(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'

    monkeypatch.setattr(FipsFactCollector, '_get_file_content', get_file_content_mock)

    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts['fips']

    def get_file_content_mock_2(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '0'


# Generated at 2022-06-11 04:45:33.900966
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsCollector = FipsFactCollector()
    FipsCollector.collect()

# Generated at 2022-06-11 04:45:35.295878
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': True}

# Generated at 2022-06-11 04:45:39.702973
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()
    fips_fact_collector = FipsFactCollector()
    facts_collector.add_collector(fips_fact_collector)
    my_facts = facts_collector.collect(module=None,
                                       collected_facts=None)
    assert(my_facts['ansible_fips'])

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-11 04:45:41.057095
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips = fips.collect()
    assert fips == {'fips': False}


# Generated at 2022-06-11 04:45:45.769315
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # NOTE: set fact ids to prevent skip
    collector._fact_ids = set(['fips'])
    # NOTE: set module to None to skip check
    collector.collect(module=None, collected_facts=None)
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-11 04:45:46.954283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:47.870762
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect() is not None

# Generated at 2022-06-11 04:48:25.607317
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import tempfile

    from textwrap import dedent

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts import collector

    collector._FACT_CACHE = {}

    # Create temporary file
    with tempfile.NamedTemporaryFile(delete=False) as tmp_f:
        tmp_f.write(dedent("""
            1
        """))
        filename = tmp_f.name

    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, BaseFactCollector)

    # Test fips file is empty
    os.remove(filename)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] is False

   

# Generated at 2022-06-11 04:48:27.423125
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    collected_facts = {}
    fips_collector.collect(collected_facts=collected_facts)
    assert 'fips' in collected_facts

# Generated at 2022-06-11 04:48:29.243977
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect()['fips'] == False
    assert collector.collect()['fips'] == True

# Generated at 2022-06-11 04:48:34.510426
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips = FipsFactCollector()
    fips_facts = {}

    # On a system without a FIPS /proc/sys/crypto/fips_enabled
    fips_facts = fips.collect()
    assert fips_facts['fips'] == False

    # On a system with FIPS enabled, /proc/sys/crypto/fips_enabled will have a 1
    fips_facts = fips.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:48:35.002495
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:48:42.459228
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test that we correctly determine the FIPS states of the system
    """
    def managed_get_file_content(filename, content=None):
        '''
        Override get_file_content so we can check what call is
        made and simulate failures.
        '''
        assert filename == '/proc/sys/crypto/fips_enabled'
        if content is None:
            return None
        elif content == '1':
            return content
        elif content == '0':
            return content
        else:
            raise Exception

    facts_collector = FipsFactCollector()
    facts_collector._get_file_content = managed_get_file_content

    result = facts_collector.collect(None, None)
    assert result['fips'] is False
