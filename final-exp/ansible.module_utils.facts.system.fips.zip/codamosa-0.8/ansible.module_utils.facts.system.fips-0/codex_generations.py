

# Generated at 2022-06-11 04:38:48.938024
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_data = {
        "ansible_facts": {
            "fips": True
        },
        "changed": False
    }

    fips = FipsFactCollector()
    assert fips.collect() == fixture_data['ansible_facts']

# Generated at 2022-06-11 04:38:55.085813
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_list = [
        'fips: false',
        'fips: true'
    ]
    for fips in fips_list:
        fips_fact = fips.split(':')
        FipsFactCollector._read_file = mock_read_file(fips_fact[1])
        fips_facts = FipsFactCollector().collect()
        assert fips_facts == {'fips': fips_fact[1].strip() == 'true'}


# Generated at 2022-06-11 04:38:57.136031
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect(None, None)
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:38:58.966338
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-11 04:39:09.461176
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Create instance of class
    m = FipsFactCollector()
    assert(m is not None)

    # Mock get_file_content
    original_get_file_content = get_file_content
    def mock_get_file_content(file_name):
        if file_name == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return original_get_file_content(file_name)

    get_file_content = mock_get_file_content

    # Test when file exists (fips is enabled)
    assert(m.collect().get('fips') is True)

    # Mock get_file_content
    original_get_file_content = get_file_content

# Generated at 2022-06-11 04:39:14.600841
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    ff = FipsFactCollector()

    # Test with no content in fips_enabled
    data = ff.collect(module=None, collected_facts=None)
    assert data['fips'] == False

    # Test with content in fips_enabled
    data = ff.collect(module=None, collected_facts=None)
    assert data['fips'] == True

# Generated at 2022-06-11 04:39:16.189240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect()
    # name
    assert facts['fips'] in (True, False)

# Generated at 2022-06-11 04:39:17.873144
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips'] == 0

# Generated at 2022-06-11 04:39:19.827311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfactcollector = FipsFactCollector()
    assert fipsfactcollector.collect() == dict(fips=False)

# Generated at 2022-06-11 04:39:22.267590
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    result = f.collect()
    assert isinstance(result, dict)
    assert result == {'fips': False}

# Generated at 2022-06-11 04:39:27.093868
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()

    assert fips_facts.collect()['fips'] == False

# Generated at 2022-06-11 04:39:29.604572
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    target = FipsFactCollector()
    result = target.collect()

    assert isinstance(result, dict)
    assert result['fips'] == False


# Generated at 2022-06-11 04:39:32.869734
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModuleMock()
    # NOTE: 'fips' is populated even if it is not set
    fips_facts = FipsFactCollector(module).collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:39:36.091255
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = {}
    collected_facts = {}
    fips_obj = FipsFactCollector()
    fips_facts = fips_obj.collect(module, collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:39:44.477745
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    
    with patch('ansible.module_utils.facts.collector.FactsCollector') as FactsCollector_mock:
        with patch('ansible.module_utils.facts.utils.get_file_content') as get_file_content_mock:
            # Set up mocks
            instance = FactsCollector_mock.return_value
            instance._fact_cache = {}
            get_file_content_mock.return_value = '0'
            # Invoke module with valid arguments
            result = FipsFactCollector(instance).collect()

            # Assert conditions on return value
            assert result == {'fips': False}

            # Assert conditions on

# Generated at 2022-06-11 04:39:46.603769
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mod = None
    coll_facts = None
    obj = FipsFactCollector()
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-11 04:39:49.988847
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids.clear()
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert set(fips_facts.keys()) == set(['fips'])

# Generated at 2022-06-11 04:39:54.938392
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a new instance of class FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # Try method collect of class FipsFactCollector
    # It returns the dictionary "fips_facts", with the key-value pair
    # 'fips': False
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:02.799318
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {}
    data = {'/proc/sys/crypto/fips_enabled': '1'}
    fips_fact_collector.set_read_file_data(data)
    assert fips_fact_collector.collect() == {'fips': True}
    data = {'/proc/sys/crypto/fips_enabled': '0'}
    fips_fact_collector.set_read_file_data(data)
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:04.278582
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_file = '''
#!/bin/sh
exit 0
'''
    FipsFactCollector.test(test_file)

# Generated at 2022-06-11 04:40:09.131789
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector()
    facts_dict = facts.collect()
    assert facts_dict['fips'] is False


# Generated at 2022-06-11 04:40:13.483915
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:40:18.873867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test for method FipsFactCollector.collect
    """
    # Initialize
    fips_fact_collector_ins = FipsFactCollector()
    # Test should return true if file does not exist
    result = fips_fact_collector_ins.collect()
    assert result["fips"] == True


# Generated at 2022-06-11 04:40:22.874956
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Collect output from the class method collect of class
    # FipsFactCollector.
    fc = FipsFactCollector()
    collected_facts = fc.collect()

    # Check for expected output.
    assert 'fips' in collected_facts
    assert collected_facts['fips'] in [False, True]

# Generated at 2022-06-11 04:40:24.389651
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    assert fact_collector.collect()


# Generated at 2022-06-11 04:40:26.731710
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    # fc.collect is a classmethod and can be called directly
    collected_facts = fc.collect()
    assert collected_facts['fips'] == False

# Generated at 2022-06-11 04:40:28.710005
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts == {'fips': False}


# Generated at 2022-06-11 04:40:30.874757
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    result = f.collect()
    assert 'fips' in result.keys()
    assert isinstance(result['fips'], bool)

# Generated at 2022-06-11 04:40:34.494227
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def mock_open(arg):
        return open(arg, 'r')
    module = None
    facts = None
    FipsFactCollector.open = mock_open
    f = FipsFactCollector()
    facts = f.collect(module, facts)
    assert facts['fips'] == False

# Generated at 2022-06-11 04:40:38.063608
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test if FipsFactCollector method collect returns what it is expected to return
    """
    fips_facts = FipsFactCollector()
    results = fips_facts.collect()
    assert type(results) == dict
    assert 'fips' in results

# Generated at 2022-06-11 04:40:45.514344
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfact = FipsFactCollector()
    facts = fipsfact.collect()
    assert facts['fips'] == False

# Generated at 2022-06-11 04:40:46.782796
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:50.033270
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockCollectedFacts(object):
        def __init__(self):
            self.data = {}

    my_obj = FipsFactCollector()
    my_obj.collect(MockModule(), MockCollectedFacts())
    assert my_obj.name == 'fips'

# Generated at 2022-06-11 04:40:52.367341
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    # NOTE: the get_file_content method is not mocked out by Ansible
    fips_fact_collector = FipsFactCollector()
    # Act
    result = fips_fact_collector.collect()
    # Assert
    assert 'fips' in result
    assert result['fips'] == False

# Generated at 2022-06-11 04:40:53.256726
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-11 04:41:00.973642
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector import FactsCollector

    collector = Collector(ModuleFactCollector(None))
    fips_collector = collector.get_collector('fips')

    expected_fips_fact = {'fips': False}
    fips_facts = fips_collector.collect()
    assert fips_facts == expected_fips_fact

    facts = FactsCollector(None).collect()
    assert facts['fips'] == expected_fips_fact['fips']

# Generated at 2022-06-11 04:41:01.508130
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:41:03.713290
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert 'fips' in result
    assert isinstance(result['fips'], bool)

# Generated at 2022-06-11 04:41:04.642563
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-11 04:41:11.643291
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #This test is for macOS and should return an empty dictionary.
    for platform in ('Darwin'):
        module = mock_module_for_linux(platform)
        fips = FipsFactCollector(module)
        assert(fips.collect() == {})

    #This test is for linux and should return a dictionary with fips.
    for platform in ('Linux'):
        module = mock_module_for_linux(platform)
        fips = FipsFactCollector(module)
        assert(fips.collect() == {'fips': True})


# Generated at 2022-06-11 04:41:19.749630
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 04:41:20.969246
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:21.672253
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-11 04:41:27.374363
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collect_function = FipsFactCollector().collect
    test_data = [
        {
            'fips_enabled': '0',
            'expect': False,
        },
        {
            'fips_enabled': '1',
            'expect': True,
        },
    ]
    for test in test_data:
        res_facts = collect_function({'fips_enabled': test['fips_enabled']})
        assert res_facts['fips'] == test['expect']

# Generated at 2022-06-11 04:41:29.569064
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize class definition
    fips_collector = FipsFactCollector()

    # Test
    assert type(fips_collector.collect()) is dict

# Generated at 2022-06-11 04:41:30.728676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-11 04:41:31.545980
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-11 04:41:40.399981
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    def mock_get_file_content(*args, **kwargs):
        return "1"
    FipsFactCollector._fact_ids.add('fips')
    get_file_content = mock_get_file_content
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect() == {'fips': True}

    def mock_get_file_content(*args, **kwargs):
        return "2"
    FipsFactCollector._fact_ids.add('fips')
    get_file_content = mock_get_file_content
    fips_facts_collector = F

# Generated at 2022-06-11 04:41:46.987311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    my_collector = FipsFactCollector()
    my_collector._module = None
    my_collector._file_cache = {}
    my_collector._file_cache['/proc/sys/crypto/fips_enabled'] = '0'
    assert my_collector.collect() == {'fips': False}
    my_collector._file_cache['/proc/sys/crypto/fips_enabled'] = '1'
    assert my_collector.collect() == {'fips': True}
    my_collector._file_cache['/proc/sys/crypto/fips_enabled'] = 'blah'
    assert my_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:41:55.972356
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Init
    test_arg_spec = dict()
    test_module = MagicMock(argument_spec=test_arg_spec)
    test_collected_facts = {'ansible_system': 'Linux'}
    test_data = ['1']

    # Mocking
    mock_get_file_content = MagicMock(side_effect=[test_data, ''])

    # Test
    with patch.object(FipsFactCollector, '_get_file_content', mock_get_file_content):
        test_fips_collector = FipsFactCollector()
        test_fips_collector.collect(test_module, test_collected_facts)
        assert_equal(test_collected_facts, {'ansible_system': 'Linux', 'fips': True})

        test_fips_

# Generated at 2022-06-11 04:42:16.863288
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import tempfile
    import os
    import shutil
    import json
    import textwrap

    def test_FipsFactCollector_collect_helper(fips_file_contents):
        tmpdir = tempfile.mkdtemp()
        data_dir = '%s/proc/sys/crypto' % tmpdir
        os.makedirs(data_dir)

        with open('%s/fips_enabled' % data_dir, 'w') as fl:
            fl.write(fips_file_contents)

        try:
            from ansible.module_utils.facts import collectors
            c = collectors.get_collector('fips')
            result = c.collect()
            assert result == {'fips': True}
        finally:
            shutil.rmtree(tmpdir)

    # Test

# Generated at 2022-06-11 04:42:22.884642
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test the class constructor
    try:
        ffc = FipsFactCollector()
    except AttributeError:
        assert(False)
    else:
        if ffc.name != 'fips':
            assert(False)
        if ffc._fact_ids != set():
            assert(False)

    # Test the collect method
    ffc = FipsFactCollector()
    fips_facts = ffc.collect()
    if fips_facts != {} and fips_facts['fips'] == False:
        assert(False)

# Generated at 2022-06-11 04:42:25.870246
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector('foo')
    collected_facts = {}
    result = fact_collector.collect(collected_facts=collected_facts)
    assert "fips" in result
    assert isinstance(result["fips"], bool)

# Generated at 2022-06-11 04:42:31.697074
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # set up mock
    mock_get_file_content = fips_fact_collector.get_file_content = Mock()
    mock_get_file_content.return_value = "1"

    # call method collect
    fips_facts = fips_fact_collector.collect()
    
    # validate results
    assert fips_facts
    assert fips_facts['fips']
    assert fips_fact_collector._fact_ids == {'fips'}

# Generated at 2022-06-11 04:42:34.312965
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    facts = fips_facts_collector.collect()
    assert facts['fips'] == False
    assert facts.get('module_setup', None) == False

# Generated at 2022-06-11 04:42:34.794421
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-11 04:42:38.552510
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert type(result) is dict
    assert len(result) == 1
    assert type(result['fips']) == bool

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 04:42:40.368094
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector

    fc = FipsFactCollector()
    asse

# Generated at 2022-06-11 04:42:41.966598
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-11 04:42:47.771108
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    assert fips_obj.collect() == {'fips': False}
    fips_obj._module.get_bin_path = lambda _: "."
    fips_obj._module.run_command = lambda _: (0, "1", None)
    assert fips_obj.collect() == {'fips': True}
    fips_obj._module.run_command = lambda _: (0, "0", None)
    assert fips_obj.collect() == {'fips': False}

# Generated at 2022-06-11 04:43:16.366683
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts={'fips': False}
    obj = FipsFactCollector()
    obj.collect()
    fips_facts = obj.collect(obj)
    assert fips_facts.get('fips') == False

# Generated at 2022-06-11 04:43:17.633845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-11 04:43:18.452186
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    res = fips_fact_collector.collect()
    assert res == {}

# Generated at 2022-06-11 04:43:21.680537
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = 1
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector.collect(fips_facts) == fips_facts

# Generated at 2022-06-11 04:43:23.408292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    res = test_obj.collect()
    assert res is not None

# Generated at 2022-06-11 04:43:26.326053
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {'secure_mode': [], 'fips': []}
    assert fact_collector.collect(collected_facts=collected_facts) == {'fips': False}

# Generated at 2022-06-11 04:43:27.992820
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts['fips'] == True

# Generated at 2022-06-11 04:43:30.157166
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fips_facts = fc.collect()
    assert type(fips_facts['fips']) is bool


# Generated at 2022-06-11 04:43:31.692505
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-11 04:43:32.494400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-11 04:44:44.837327
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # test with fips not set
    FipsFactCollector._fact_ids = set()
    FipsFactCollector._collect = lambda self: False
    collected_facts = {}
    expected_result = {'fips': False}
    result = FipsFactCollector().collect(collected_facts=collected_facts)
    assert result == expected_result
    # test with fips set
    FipsFactCollector._collect = lambda self: True
    result = FipsFactCollector().collect(collected_facts=collected_facts)
    expected_result = {'fips': True}
    assert result == expected_result

# Generated at 2022-06-11 04:44:48.707413
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_mock = {'fips':False}
    set_module_args({})
    with pytest.raises(AnsibleExitJson) as result:
        FipsFactCollector().collect(module=None, collected_facts=None)
    assert result.value.args[0]['ansible_facts'] == fips_mock

# Generated at 2022-06-11 04:44:51.580016
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # set up
    passed_module = None
    passed_collected_facts = None
    expected_fips = True
    
    # exercise
    result = FipsFactCollector().collect(passed_module, passed_collected_facts)
    
    # verify
    assert result['fips'] == expected_fips


# Generated at 2022-06-11 04:44:53.889292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts['fips'] is False

# vim:set et sts=4 ts=4 tw=0:

# Generated at 2022-06-11 04:44:56.788500
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts_dict = fips_collector.collect()
    assert fips_facts_dict['fips'] is False

# Generated at 2022-06-11 04:45:00.310036
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_col = FipsFactCollector()
    # Set fips_facts to {'module': None, 'collected_facts': None}
    fips_facts = fips_fact_col.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:45:03.591596
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert "fips" in collected_facts
    assert collected_facts["fips"] == False or collected_facts["fips"] == True

# Generated at 2022-06-11 04:45:05.369545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert 'fips' in result

# Generated at 2022-06-11 04:45:08.542408
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    collected_facts = {}
    expected = {'fips': True}
    fips.collect(collected_facts=collected_facts)
    assert collected_facts == expected

# Generated at 2022-06-11 04:45:10.870814
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips = collector.collect()
    assert fips is not None
    assert 'fips' in fips
    assert type(fips['fips']) == bool

# Generated at 2022-06-11 04:47:45.509080
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    fips_fact_collector = FipsFactCollector()
    ansible_module = basic.AnsibleModule(argument_spec={})
    fips_facts = fips_fact_collector.collect(module=ansible_module)
    assert isinstance(fips_facts, dict)

# Generated at 2022-06-11 04:47:46.764876
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:47:51.699336
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import FactsParseException

    # The following two statements allow us to mock the AnsibleModule in a
    # way that is compatible with both Ansible 2.x and Ansible 2.3.
    import ansible.module_utils.facts.ansible_facts.module_utils.facts
    facts_module = ansible.module_utils.facts.ansible_facts.module_utils.facts
    module = getattr(facts_module, 'AnsibleModule')()

    # We need to create an instance of our FactCollector, which we can only
    # do by calling the static method create() of the FactCollector class.
    fc = FactCollector.create(module, set(['fips']))

    # Collect facts


# Generated at 2022-06-11 04:47:53.586889
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_collector = FipsFactCollector()
    returned_result = fips_collector.collect()

    assert returned_result['fips'] == True

# Generated at 2022-06-11 04:47:56.959932
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # get instance of FipsFactCollector
    ffc = FipsFactCollector(None, None)

    # get output of collect (iterator)
    output = ffc.collect()

    # get result from output
    result = next(output)

    # expected value
    expected = { 'fips': False }

    assert result == expected

# Generated at 2022-06-11 04:48:05.273663
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Read the content of fips_enabled file
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    # Create an instance of class FipsFactCollector
    fips_collector = FipsFactCollector()

    # Test that fips is True if 'fips_enabled' has the value '1'
    if data and data == '1':
        assert fips_collector.collect()['fips'] == True
    # Test that fips is False if 'fips_enabled' has the value '0'
    elif data and data == '0':
        assert fips_collector.collect()['fips'] == False
    # Test that fips is False if 'fips_enabled' file is empty    
    else:
        assert fips_collector.collect()['fips']

# Generated at 2022-06-11 04:48:13.842444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    inp = '''This content is irrelevant'''
    facts = {}

    # get_file_content should be called once
    etalon_return_value = False
    etalon_call_args = (
        '', '/proc/sys/crypto/fips_enabled', '', '', {}
    )
    etalon_call_kwargs = {}
    def get_file_content_side_effect(*args, **kwargs):
        assert etalon_call_args == args
        assert etalon_call_kwargs == kwargs
        return '1'

    monkeypatch.setattr(
        'ansible.module_utils.facts.utils.get_file_content',
        get_file_content_side_effect
    )

    instance = FipsFactCollector()

# Generated at 2022-06-11 04:48:17.422400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # unit test for method collect of class FipsFactCollector
    def test_func(s):
        return s.replace('\n', '')

    collector = FipsFactCollector()
    output = collector.collect(collected_facts={'fips': False})

    assert output['fips'] is False, 'Failed Test: Output did not match expected'

# Generated at 2022-06-11 04:48:23.315066
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.collector import DummyCollector

    dummyCollector = DummyCollector()
    assert dummyCollector.collected_facts == {}
    dummyModule = DummyModule(
        params=dict(),
        ansible_facts=dict()
    )
    fipsFactCollector = FipsFactCollector()
    an_object = fipsFactCollector.collect(dummyModule, dummyCollector.collected_facts)
    assert an_object == {'fips':False}

# Generated at 2022-06-11 04:48:25.206274
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect()
    assert result
    assert result['fips'] is False