

# Generated at 2022-06-11 04:38:48.976578
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test to check if method collect for class FipsFactCollector works as
    expected when /proc/sys/crypto/fips_enabled content is 1"""
    mock_module = Mock()
    mock_module.get_bin_path.return_value = True
    mock_module.run_command.return_value = (0, 1, '')
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect(module=mock_module)
    assert 'fips' in result
    assert result['fips'] == True


# Generated at 2022-06-11 04:38:54.015331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create generic object for FipsFactCollector class
    fipsfactcollector = FipsFactCollector()

    # Check if fips is enabled
    fips = fipsfactcollector.collect()
    print(fips)

# Main function
if __name__ == '__main__':
    # Unit test for method collect of class FipsFactCollector
    test_FipsFactCollector_collect()

# Generated at 2022-06-11 04:38:56.344006
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert((fips_facts['fips'] == False) or (fips_facts['fips'] == True))

# Generated at 2022-06-11 04:38:57.674928
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    pass

# Generated at 2022-06-11 04:39:07.300989
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    import os

    test_file_name = '/tmp/fips_test_file'
    test_file_content = '1'
    test_file = open(test_file_name, 'w')
    test_file.write(test_file_content)
    test_file.close()

    FipsFactCollector._fact_ids.add('fips')
    fact_collector = FactCollector()
    fips_fact_collector = FipsFactCollector(fact_collector)
    result = fips_fact_collector.collect()
    os.remove(test_file_name)
    assert result == {u'fips': True}

# Generated at 2022-06-11 04:39:10.133099
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts_collector = FipsFactCollector()
    all_facts = facts_collector.collect()
    assert isinstance(all_facts['fips'], bool)


# Generated at 2022-06-11 04:39:16.853849
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    sys_fips= open('/proc/sys/crypto/fips_enabled', 'w')
    sys_fips.write("1")
    sys_fips.close()
    assert fips_fact.collect() == {'fips': True}
    
    sys_fips= open('/proc/sys/crypto/fips_enabled', 'w')
    sys_fips.write("0")
    sys_fips.close()
    assert fips_fact.collect() == {'fips': False}

# Generated at 2022-06-11 04:39:18.056735
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert(FipsFactCollector().collect()['fips'] is False)



# Generated at 2022-06-11 04:39:21.114876
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_fact_collector = FipsFactCollector()
    collected_facts = {}
    collected_facts = {'ansible_fips': False}
    assert test_fact_collector.collect(collected_facts) == {'fips': False}

# Generated at 2022-06-11 04:39:26.511723
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    test_module = None
    test_collect_facts = None
    test_obj = FipsFactCollector()
    assert type(test_obj.collect(test_module, test_collect_facts)) is dict
    assert 'fips' in test_obj.collect(test_module, test_collect_facts)
    assert type(test_obj.collect(test_module, test_collect_facts)['fips']) is bool

# Generated at 2022-06-11 04:39:30.678485
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert isinstance(fips_facts,dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:39:39.677707
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = Mock()
    module.params = {}
    temp_fips_enabled = "/tmp/fips_enabled"
    mocked_collect = Mock()
    mocked_collect.attach_mock(Mock(), "get_file_content")
    mocked_collect.return_value = False

    with patch("ansible.module_utils.facts.collector.get_file_content", mocked_collect):
        FipsFactCollector().collect(module=module)
        assert mocked_collect.mock_calls == [call.get_file_content('/proc/sys/crypto/fips_enabled'), call.get_file_content().decode('utf-8')]

    with open(temp_fips_enabled, 'w') as f:
        f.write('0')
    module.params = {}
    mocked_collect

# Generated at 2022-06-11 04:39:45.966664
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    # Test if fips is set to true
    fips_facts_collector.get_file_content = lambda x: '1'
    assert fips_facts_collector.collect() == {'fips': True}
    # Test if fips is set to false
    fips_facts_collector.get_file_content = lambda x: '0'
    assert fips_facts_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:39:52.889906
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content_mock(path):
        if path == "/proc/sys/crypto/fips_enabled":
            return "1"
        else:
            return None

    module_mock = {}
    fips_collector_obj = FipsFactCollector()
    fips_collector_obj.get_file_content = get_file_content_mock
    collected_facts = fips_collector_obj.collect(module_mock, {})

    assert collected_facts == {'fips': True}

# Generated at 2022-06-11 04:40:02.719896
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Mock module
    class MockModule(object):
        pass
    test_module = MockModule()

    # Mock collected_facts
    class MockFactCollector(object):
        pass
    test_fact_collector = MockFactCollector()
    test_fact_collector.collected_facts = dict()

    # Test the return of the collect method when fips = False
    def mock_get_file_content(input_path):
        return "0"

    test_fips_fact_class = FipsFactCollector(test_module)
    test_fips_fact_class.get_file_content = mock_get_file_content
    test_fips_fact_class.collect(test_module, test_fact_collector)
    assert test_fact_collector.collected_facts['fips'] == False

# Generated at 2022-06-11 04:40:05.822597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict), "FipsFactCollector should return a dict"
    assert 'fips' in facts, "The returned dict should contain a 'data' key"
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-11 04:40:09.889404
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}
    fips_fact_collector._module.get_file_content = lambda path: '1'
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-11 04:40:12.008324
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:15.762641
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils._text import to_bytes
    collector = FipsFactCollector()
    result = collector.collect()
    assert result["fips"] == False

# Generated at 2022-06-11 04:40:23.873583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    collector = FipsFactCollector()
    module = None
    collected_facts = None
    # Act
    facts = collector.collect(module, collected_facts)
    # Assert
    assert type(facts) == dict, 'Expected type of return was a dictionary but got {0}'.format(type(facts))
    assert 'fips' in facts, 'Expected fips to be in the dictionary but it is not'
    assert type(facts['fips']) == bool, 'Expected type of the fips value in the dictionary to be boolean but got {0}'.format(type(facts['fips']))

# Generated at 2022-06-11 04:40:29.377475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    my_obj = FipsFactCollector()
    Collector.collectors['fips'] = my_obj

    assert my_obj.collect() == {'fips': False}

# Generated at 2022-06-11 04:40:36.059356
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create object of class to test
    test_obj = FipsFactCollector(None, None, None)

    # create fake data to pass to the method
    test_data = {'fips' : False}

    # return the fake data
    test_obj.get_file_content = lambda x: {'/proc/sys/crypto/fips_enabled' : '1'}

    # call the method with the fake data
    result = test_obj.collect(collected_facts=test_data)

    assert result == {'fips': True}, 'method collect of class FipsFactCollector returns incorrect data'

# Generated at 2022-06-11 04:40:38.200710
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    fips_facts = f.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-11 04:40:43.866727
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    def get_file_content_mock(file):
        if file == '/proc/sys/crypto/fips_enabled':
            return '1'
        return ''

    FipsFactCollector._get_file_content = get_file_content_mock

    fips_fc = FipsFactCollector()
    fips_facts = fips_fc.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-11 04:40:45.673417
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect()
    if facts['fips']:
        assert isinstance(facts['fips'], bool)

# Generated at 2022-06-11 04:40:47.430371
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_value = FipsFactCollector().collect()
    assert fips_value['fips'] is False or fips_value['fips'] is True

# Generated at 2022-06-11 04:40:56.453556
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Unit test for method collect with not fips enabled
    def test_FipsFactCollector_collect_on_not_fips_enabled(mocker):
        test_fips = False
        test_data = None
        mocker.patch('ansible.module_utils.facts.utils.get_file_content', return_value=test_data)
        collector = FipsFactCollector()
        collected_facts = collector.collect(module=None, collected_facts=None)
        assert collected_facts == {'fips': test_fips}

    # Unit test for method collect with fips enabled
    def test_FipsFactCollector_collect_on_fips_enabled(mocker):
        test_fips = True
        test_data = '1'

# Generated at 2022-06-11 04:40:58.206097
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    result = fips.collect()
    assert result['fips'] == False

# Generated at 2022-06-11 04:41:03.405575
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect(collected_facts=None)
    assert collected_facts['fips'] == False

    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect(collected_facts=None)
    assert collected_facts['fips'] == False



# Generated at 2022-06-11 04:41:08.145359
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = {}
    returned_facts = collector.collect(collected_facts=collected_facts)
    assert returned_facts['fips']
    assert 'fips' in collected_facts
    assert collected_facts['fips'] == returned_facts['fips']

# Test case for class FipsFactCollector

# Generated at 2022-06-11 04:41:14.846937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-11 04:41:20.536312
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class mock_module:
        def __init__(self, **kwargs):
            self.params = kwargs

    class mock_os:
        def __init__(self, **kwargs):
            self.params = kwargs

    facts = FipsFactCollector().collect(module=mock_module(), collected_facts=mock_os())
    assert facts['fips'] is False

# Generated at 2022-06-11 04:41:27.868253
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Method collect of class FipsFactCollector should return the expected values
    """
    # Test fips_facts when fips mode is off
    fips_facts_off_expected = { 'fips': False }
    fips_facts_off_actual = FipsFactCollector().collect()
    assert( fips_facts_off_actual == fips_facts_off_expected )

    # Test fips_facts when fips mode is on
    fips_facts_on_expected = {'fips': True}
    fips_facts_on_actual = FipsFactCollector().collect()
    assert( fips_facts_on_actual == fips_facts_on_expected )

# Generated at 2022-06-11 04:41:30.107779
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    test_data = {'fips': False}
    output = fips.collect()
    assert output == test_data

# Generated at 2022-06-11 04:41:38.868076
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    fips_test_data = to_text("""
        [fips@localhost tmp]$ sudo cat /proc/sys/crypto/fips_enabled
        1
        [fips@localhost tmp]$ sudo cat /proc/sys/crypto/fips_enabled
        0
    """)
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    collector = FipsFactCollector(module=module)
# TODO: currently the collector is getting the file over the network
#       when testing, the local cached version should be used
#      

# Generated at 2022-06-11 04:41:42.343393
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    expected = {}
    expected['ansible_facts']['fips'] = False
    result = f.collect(collected_facts=collected_facts)
    assert result == expected

# Generated at 2022-06-11 04:41:48.931441
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # start of the test
    testSystem_start = {
        'fips': False,
    }
    # end of the test
    testSystem_end = {
        'fips': True,
    }
    # command used to check FIPS mode in a system
    fips_command = 'cat /proc/sys/crypto/fips_enabled'

    # empty dictionary to store all the system facts
    collected_facts = {}
    # initialize the FipsFactCollector
    fips_collector = FipsFactCollector()
    # run the collect method of the FipsFactCollector
    collected_facts = fips_collector.collect()
    # if the start and the end state of the system match
    # assert that the system is in FIPS mode

# Generated at 2022-06-11 04:41:50.873223
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert isinstance(ffc, BaseFactCollector)
    assert ffc.name == 'fips'
    assert ffc.collect()

# Generated at 2022-06-11 04:42:01.022181
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import unittest
    from ansible.module_utils.facts.collector import Facts

    from ansible.module_utils.facts.collectors.fips import FipsFactCollector

    test_dir = os.path.dirname(os.path.realpath(__file__))
    mock_dir = os.path.join(test_dir, 'mock')

    class MockFacts():
        def __init__(self):
            self._data = {}

        def __setitem__(self, key, value):
            self._data[key] = value

        def __getitem__(self, key):
            return self._data[key]


# Generated at 2022-06-11 04:42:03.699032
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-11 04:42:12.603183
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector
    # Test the case when fips is not enabled
    test_dict = {'fips': False}
    assert (collector.collect() == test_dict)
    # Test the case when fips is enabled
    test_dict = {'fips': True}
    assert (collector.collect() == test_dict)

# Generated at 2022-06-11 04:42:14.663058
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    assert 'fips' in facts
    assert facts['fips'] is False

# Generated at 2022-06-11 04:42:16.862958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {
        'fips': False
    }

# Generated at 2022-06-11 04:42:18.615394
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj_test = FipsFactCollector()
    assert isinstance(obj_test.collect(), dict)

# Generated at 2022-06-11 04:42:21.182216
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    ansible_facts = dict()
    res = test_obj.collect(collected_facts=ansible_facts)
    assert res['fips'] == False

# Generated at 2022-06-11 04:42:25.501777
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    file_data_mock = (
        '1',
        ''
        )
    with patch('ansible.module_utils.facts.utils.get_file_content',
               side_effect=file_data_mock):
        fips_facts = fips_fact_collector.collect()
        assert fips_facts['fips'] == True

        fips_facts = fips_fact_collector.collect()
        assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:42:29.251009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-11 04:42:33.851782
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test FipsFactCollector.collect
    """
    assert test_FipsFactCollector_collect.__doc__

    # test with all values set
    module = None
    collected_facts = None
    fact_collector = FipsFactCollector()
    result = fact_collector.collect(module, collected_facts)
    assert result['fips'] in (False, True)

# Generated at 2022-06-11 04:42:37.483018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    # I am not sure how to test this in a unit test.
    # The value will not be the same if I am not running in FIPS mode
    assert fips_facts is not None

# Generated at 2022-06-11 04:42:39.439209
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    fips_obj.collect()
    assert fips_obj.name == 'fips'

# Generated at 2022-06-11 04:42:58.445356
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result['fips'] == False

    fips_fact_collector._file_contents = {
            '/proc/sys/crypto/fips_enabled': '1'
        }
    result = fips_fact_collector.collect()
    assert result['fips'] == True

# Generated at 2022-06-11 04:43:00.519753
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert (fips_facts.collect() == {'fips': False})

# Generated at 2022-06-11 04:43:02.815969
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': False}

# vim: set expandtab:

# Generated at 2022-06-11 04:43:09.864214
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class fs:
        def read(self):
            return '1'

    class Factory:
        def get_file_content(path):
            if path == '/proc/sys/crypto/fips_enabled':
                return fs()
            else:
                return None

    x = FipsFactCollector(Factory())
    f_name = 'fips'
    f_value = x.collect()
    assert f_name in f_value, "fact is missing from the return set"
    assert f_value[f_name], "Fact %s returned value %s but expected 1" % (f_name, f_value[f_name])

# Generated at 2022-06-11 04:43:11.984917
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    result = f.collect()
    assert 'fips' in result
    assert result['fips'] == False

# Generated at 2022-06-11 04:43:15.010008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import ansible.module_utils.facts.collectors.fips as fips_collector
    m = fips_collector
    fips = m.FipsFactCollector()
    f = fips.collect()
    assert f['fips'] == False

# Generated at 2022-06-11 04:43:18.773625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    all_facts = {'user_id': 'some_user', 'host': 'some_host'}
    fips_collector.collect(collected_facts=all_facts)
    assert all_facts['fips'] == 'some_string'

# Generated at 2022-06-11 04:43:20.210116
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-11 04:43:24.217376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test for case where method collect of class FipsFactCollector returns
    # value of fips as False as fips_enabled file is not present
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect()['fips'] == False

    # Test for case where method collect of class FipsFactCollector returns
    # value of fips as True as fips_enabled file is present and its contents
    # value is 1
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect()['fips'] == True

    # Test for case where method collect of class FipsFactCollector returns
    # value of fips as False as fips_enabled file is present and its contents
    # value is not 1
    fips_facts_collect

# Generated at 2022-06-11 04:43:31.202873
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible_collections.cloud.common.plugins.module_utils.facts.collectors.system.fips import FipsFactCollector
    result = FipsFactCollector.collect()
    assert result['fips'] == False
    result = FipsFactCollector.collect(False)
    assert result['fips'] == False
    result = FipsFactCollector.collect(True)
    assert result['fips'] == True
    result = FipsFactCollector.collect("True")
    assert result['fips'] == True
    result = FipsFactCollector.collect("False")
    assert result['fips'] == False

# Generated at 2022-06-11 04:44:08.618397
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_context_mock
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import mock

    assert_equal = mock.Mock()
    assert_equal.assert_called_with({'fips': False})

    # Test collect returns False when file "/proc/sys/crypto/fips_enabled"
    # contains "0"
    json_str = '''{
        "/proc/sys/crypto/fips_enabled": "0"
    }'''


# Generated at 2022-06-11 04:44:12.715596
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print("Test method collect of class FipsFactCollector.\n")
    fips_facts = {}
    fips_facts['fips'] = False

    fips_collector = FipsFactCollector()
    fips_collector._get_file_content = mock_get_file_content
    assert fips_collector.collect(collected_facts=fips_facts) == {'fips': True}

# Mock method to return a fake content for /proc/sys/crypto/fips_enabled

# Generated at 2022-06-11 04:44:16.980702
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """This is a unit test for `FipsFactCollector.collect` method."""

    # Define an instance of class FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    # Call the method under test
    facts = fips_fact_collector.collect()
    # Assertions
    assert type(facts) is dict
    assert 'fips' in facts
    assert type(facts['fips']) is bool

# Generated at 2022-06-11 04:44:22.101975
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipscollector = FipsFactCollector()
    fipscollector._fetch_file_lines = lambda x: [1]
    fips_facts = fipscollector.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] == True


# Generated at 2022-06-11 04:44:29.985812
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import os
    import json
    import shutil
    from ansible.module_utils.facts import collector

    testdata = [
        ('/proc/sys/crypto/fips_enabled', '1')
    ]

    collector._create_tmp_dir_if_needed()
    collector._tmp_dir = os.path.join(os.getcwd(), ".tmp_test_ansible_fact_collector")
    collector._clean_old_tmp_files()

    for source_file, content in testdata:
        try:
            target_file = os.path.join(collector._tmp_dir, source_file.strip('/').replace('/', '_'))
            os.makedirs(os.path.dirname(target_file))
        except OSError:
            pass

       

# Generated at 2022-06-11 04:44:32.901240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.set_fs_location('../ansible/test/units/module_utils/facts/filesystem')
    fips_collector.collect()
    assert fips_collector.facts['fips'] == True

# Generated at 2022-06-11 04:44:37.264144
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    # none is passed to collect method
    # as the module argument is not required
    # to collect facts of fips module
    # The following are the facts after collecting fips fact
    #   fips: False
    fips_facts = fact_collector.collect(None)
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:44:39.128412
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts_dict = collector.collect()
    assert(isinstance(facts_dict, dict))

# Generated at 2022-06-11 04:44:40.779550
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    it = FipsFactCollector()
    it._module = object()

    assert it.collect() == {'fips': True}

# Generated at 2022-06-11 04:44:46.452576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Unit test for method collect of class FipsFactCollector """
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    return fips_facts


# Generated at 2022-06-11 04:45:49.923822
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_instance = FipsFactCollector()
    assert FipsFactCollector_instance.collect() == {'fips': False}

# Generated at 2022-06-11 04:45:53.785489
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    module = 'ansible_fips_facts'
    exception = AnsibleParserError()
    fact = FipsFactCollector()
    collected_facts = {}
    fips_facts = {}
    if fips_facts['fips']:
        assert fips_facts == fact.collect(module, collected_facts)
    else:
        assert fips_facts == fact.collect(module, collected_facts)

# Generated at 2022-06-11 04:45:55.570542
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert 'fips' in facts
    assert type(facts['fips']) is bool

# Generated at 2022-06-11 04:45:57.594128
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect(collected_facts={})
    assert result['fips'] == False


# Generated at 2022-06-11 04:46:00.389574
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts is not None
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts.keys()
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-11 04:46:01.640761
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect(None) == {'fips': False}

# Generated at 2022-06-11 04:46:03.130889
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-11 04:46:05.754521
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # fips_facts is a dictionary and indexed by 'fips'
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips'] == True or fips_facts['fips'] == False

# Generated at 2022-06-11 04:46:09.032148
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfc = FipsFactCollector()
    fipsfc._module = None
    fipsfc._read_file = lambda x, y: '1'
    assert fipsfc.collect() == {'fips': True}

    fipsfc._read_file = lambda x, y: '2'
    assert fipsfc.collect() == {'fips': False}

# Generated at 2022-06-11 04:46:11.198452
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Collect facts without fips file
    FipsFactCollector().collect()

    # Collect facts with fips file
    FipsFactCollector().collect({'/proc/sys/crypto/fips_enabled': '1'})

# Generated at 2022-06-11 04:48:35.756149
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert isinstance(fips_facts.collect(), dict)

# Generated at 2022-06-11 04:48:43.165365
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test that it returns fips=False when file does not exist
    fc = FipsFactCollector()
    assert fc.get_files_to_inspect() == ['/proc/sys/crypto/fips_enabled']
    fc.content = {'/proc/sys/crypto/fips_enabled': ''}
    fips_facts = fc.collect()
    assert fips_facts['fips'] == False

    # Test that it returns fips=False when file content is 0
    fc = FipsFactCollector()
    assert fc.get_files_to_inspect() == ['/proc/sys/crypto/fips_enabled']
    fc.content = {'/proc/sys/crypto/fips_enabled': '0'}
    fips_facts = fc.collect()
