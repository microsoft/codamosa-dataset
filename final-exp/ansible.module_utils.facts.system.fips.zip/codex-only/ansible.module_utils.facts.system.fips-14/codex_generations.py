

# Generated at 2022-06-23 01:08:45.657398
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect()['fips'] == False

# Generated at 2022-06-23 01:08:47.139620
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts is not None

# Generated at 2022-06-23 01:08:50.126018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module.run_command = lambda cmd, check_rc=True: (0, '1', '')
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips']

# Generated at 2022-06-23 01:08:55.744856
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()

    fips_collector.collect_now = lambda: {
        'fips': True,
    }

    assert fips_collector.collect() == {
        'fips': True,
    }


# Generated at 2022-06-23 01:09:03.300079
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:09:04.730179
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-23 01:09:05.665549
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:15.065982
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a test object
    fips_collector = FipsFactCollector()
    path = "tests/unittests/module_utils/ansible_test_fips_enabled"
    # Create a test object
    fips_collector = FipsFactCollector()
    # Use the object to read the file for the tests
    fips_facts = fips_collector.collect(path)
    # Check that the fips fact is correctly set to yes
    assert fips_facts['fips'] == True

# Generated at 2022-06-23 01:09:19.077539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = {}
    result['fips'] = collector.collect()
    assert result['fips'] is not None
    assert result['fips'] in [True, False]

# Generated at 2022-06-23 01:09:29.041003
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    try:
        sys.modules['__main__'].__file__
    except AttributeError:
        import os
        import __main__
        __main__.__file__ = os.path.join(os.path.dirname(__file__), 'fips.py')

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector

    BaseFactCollector.setup_cache()
    get_file_content = lambda *args, **kwargs: '1'
    assert FipsFactCollector().collect() == {'fips': True}

# Generated at 2022-06-23 01:09:32.051098
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # arrange
    fips_mock = FipsFactCollector()
    # act
    result = fips_mock.collect()
    # assert
    assert 'fips' in result
    assert type(result['fips']) is bool
#

# Generated at 2022-06-23 01:09:34.176596
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:09:35.256265
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x

# Generated at 2022-06-23 01:09:37.752372
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector(None, 'test')
    assert obj.name == 'test'

# Generated at 2022-06-23 01:09:39.564412
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector()
    facts_to_check = {'fips' : False}
    assert facts.collect() == facts_to_check

# Generated at 2022-06-23 01:09:40.933675
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:09:42.641785
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    result = FipsFactCollector()
    assert result is not None

# Generated at 2022-06-23 01:09:47.004293
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert isinstance(fips_facts._fact_ids, set)
    assert fips_facts._fact_ids == set()
    assert fips_facts.collect() == {'fips': False}

# Generated at 2022-06-23 01:09:48.803217
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_handler = FipsFactCollector()
    assert fips_handler.name == 'fips'

# Generated at 2022-06-23 01:09:58.013551
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # emulated data
    DATA = '1'

    # create test function with logic to manipulate 'open' function
    def test_open(name, mode='r', buffering=1):
        if name == '/proc/sys/crypto/fips_enabled':
            return DATA
        else:
            return open(name, mode, buffering)

    # mock 'open' function
    oldopen = FipsFactCollector.open
    FipsFactCollector.open = test_open

    # test 'collect' method
    actual = FipsFactCollector().collect()

    # restore 'open' function
    FipsFactCollector.open = oldopen

    # assert results
    assert actual == {'fips': True}

# Generated at 2022-06-23 01:10:04.477752
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactsCollectionError
    Fips_FactCollector = FipsFactCollector()
    assert Fips_FactCollector.collect() == {'fips': False}
    assert Fips_FactCollector.name == 'fips'

    with pytest.raises(FactsCollectionError):
        Fips_FactCollector.collect(module=None, collected_facts="None")

# Generated at 2022-06-23 01:10:07.978938
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert isinstance(FipsFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:10:11.163911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create mocks
    module = None
    collected_facts = {}

    # Create a FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # Execute method collect
    fips_info = fips_fact_collector.collect(module, collected_facts)

    # Assert that the method returns the expected result
    assert isinstance(fips_info, dict)

# Generated at 2022-06-23 01:10:13.369128
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:10:24.873939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Method: collect
    Input:
        collected_facts - empty dictionary
    Output:
        fips_facts - dictionary with fips: True
            if file /proc/sys/crypto/fips_enabled contains '1'
            else fips: False
    """
    data = '1'
    fips_facts = {'fips': True}
    FipsFactCollector._get_file_content = lambda x: data
    f = FipsFactCollector()
    assert f.collect() == fips_facts

    data = ''
    fips_facts = {'fips': False}
    FipsFactCollector._get_file_content = lambda x: data
    f = FipsFactCollector()
    assert f.collect() == fips_facts

# Generated at 2022-06-23 01:10:34.518658
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_plugin_classes
    from types import ModuleType
    import os

    FipsFactCollector.name = 'fips'

    module = ModuleType('ansible_collected_facts')
    module.__file__ = 'test/unit/module_utils/facts/collector/ansible_collected_facts.py'
    sys_modules_save = sys.modules
    sys.modules = {
        'ansible_collected_facts': module,
        'ansible_collected_facts.plugins.fips': FipsFactCollector()
    }

    if os.path.exists('/proc/sys/crypto/fips_enabled'):
        results = collector_plugin_classes['fips'].collect()
        assert type(results) == dict

# Generated at 2022-06-23 01:10:36.649442
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert 'fips' in result
    assert result['fips'] in [True, False]

# Generated at 2022-06-23 01:10:45.613827
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collectors = [
        {
            'collector': 'FipsFactCollector',
            'conditions': [],
            'expected_facts': {
                'fips': False,
            },
        },
        {
            'collector': 'FipsFactCollector',
            'conditions': [],
            'file_contents': {
                '/proc/sys/crypto/fips_enabled': '1',
            },
            'expected_facts': {
                'fips': True,
            },
        },
    ]
    for item in collectors:
        obj = FipsFactCollector(None, None)
        facts = obj.collect(collected_facts=None, module=None, file_contents=item['file_contents'])
        assert facts == item['expected_facts']

# Generated at 2022-06-23 01:10:46.329418
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:10:47.812315
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:10:50.372757
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact is not None
    assert fact.name == 'fips'
    assert fact._fact_ids == set()



# Generated at 2022-06-23 01:10:54.674329
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()

    fipsFactCollector = FipsFactCollector()
    facts_collector.add_collector(fipsFactCollector)
    assert fipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:10:56.243403
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector()

# Generated at 2022-06-23 01:10:58.272562
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:11:01.261483
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert 'fips' in facts
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-23 01:11:03.314327
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'


# Generated at 2022-06-23 01:11:05.277113
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert 'fips' in result

# Generated at 2022-06-23 01:11:08.839665
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert ('fips' in fips_facts) and isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:11:15.417779
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.name = 'fips'
    fips_collector._fact_ids = set()

    fips_collector.collect()
    fips_facts = fips_collector.collect()
    assert set(fips_facts.keys()) == set(['fips']), \
        'Expected fips_facts keys to be same as test value'

# Generated at 2022-06-23 01:11:18.617324
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:11:20.264926
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:11:21.698261
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
        obj = FipsFactCollector()
        assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:24.326654
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'
    assert fact.collect()['fips'] == False

# Generated at 2022-06-23 01:11:25.745957
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {
        'fips': False
    }

# Generated at 2022-06-23 01:11:30.472505
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assertions = [('/proc/sys/crypto/fips_enabled', b'0')]
    facts = collector.collect(collected_facts=[], module_loader=None)
    assert facts['fips'] is False
    assertions = [('/proc/sys/crypto/fips_enabled', b'1')]
    facts = collector.collect(collected_facts=[], module_loader=None)
    assert facts['fips'] is True

# Generated at 2022-06-23 01:11:38.656039
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FakeModule = type('FakeModule', (object,),
                      {'get_file_content': lambda x: '1'})
    FakeCollector = type('FakeCollector', (object,),
                         {'collect': lambda x, y: {}})
    ffc = FipsFactCollector()
    ffc.collect(FakeModule(),
                collected_facts={'collectors': {'fake': FakeCollector()}})
    assert type(ffc.fact) is dict
    assert ffc.fact['fips'] is True, \
        "Wrong fips: %r" % ffc.fact['fips']

# Generated at 2022-06-23 01:11:39.613355
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:48.656781
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = type('module', (), {})
    class mock_open:
        class Data(object):
            read = ""
        def __init__(self, path):
            self.path = path
        def __enter__(self):
            return self.Data()
        def __exit__(self, type, value, traceback):
            pass
    def mock_get_file_content(path):
        if path == "/proc/sys/crypto/fips_enabled":
            return "1"
        return None
    FipsFactCollector._open = mock_open
    FipsFactCollector._get_file_content = mock_get_file_content
    collector = FipsFactCollector(module)
    facts = collector.collect()
    assert facts == {'fips': True}

# Generated at 2022-06-23 01:11:53.228741
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollectorTest = FipsFactCollector()
    FipsFactDict = FipsFactCollectorTest.collect()

    assert 'fips' in FipsFactDict
    assert isinstance(FipsFactDict.get('fips'), bool)

# Generated at 2022-06-23 01:11:56.788074
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()



# Generated at 2022-06-23 01:11:59.519449
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   fips_obj = FipsFactCollector()
   assert fips_obj.name == 'fips'


# Generated at 2022-06-23 01:12:02.035427
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:12:10.398366
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_mock = FipsFactCollector()

    # Test fips enabled
    with open("/proc/sys/crypto/fips_enabled", 'w') as the_file:
        the_file.write("1")
    fips_mock.collect()
    assert fips_mock.collect().get("fips")

    # Test fips disabled
    with open("/proc/sys/crypto/fips_enabled", 'w') as the_file:
        the_file.write("0")
    fips_mock.collect()
    assert fips_mock.collect().get("fips") == False

# Generated at 2022-06-23 01:12:12.085106
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()

    assert fips_facts['fips'] is True

# Generated at 2022-06-23 01:12:14.364229
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector.priority == 10


# Generated at 2022-06-23 01:12:18.958132
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module, mock_collector = {}, {}
    MockFacts = FipsFactCollector.collect(mock_module, mock_collector)
    assert MockFacts['fips'] is False

# Generated at 2022-06-23 01:12:23.314296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #given
    _instance = FipsFactCollector()

    #when
    data = _instance.collect()

    #then
    assert isinstance(data, dict)
    assert data.get('fips') == False


# Generated at 2022-06-23 01:12:24.814488
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:12:32.832425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a new FipsFactCollector instance
    fips_collector = FipsFactCollector()
    # Check if the instance is correctly initilized
    assert(isinstance(fips_collector, FipsFactCollector))
    assert(fips_collector.name == 'fips')
    assert(fips_collector._fact_ids == set())
    # Call the collect method of the instance
    fips_facts = fips_collector.collect()
    # Check if it correctly returned the fact
    assert(isinstance(fips_facts, dict))
    assert('fips' in fips_facts)
    assert(isinstance(fips_facts['fips'], bool))

# Generated at 2022-06-23 01:12:36.977770
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfc = FipsFactCollector()
    assert fipsfc.name == 'fips'
    assert not fipsfc._fact_ids


# Generated at 2022-06-23 01:12:39.143393
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:12:41.791484
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:12:52.402932
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    content = '1'
    module = None
    collected_facts = None
    fips_test = FipsFactCollector()

    def mock_get_file_content(file_name):
        return content

    fips_test.get_file_content = mock_get_file_content
    assert fips_test.collect(module, collected_facts) == {'fips': True}

    content = '0'
    module = None
    collected_facts = None
    fips_test = FipsFactCollector()

    def mock_get_file_content(file_name):
        return content

    fips_test.get_file_content = mock_get_file_content
    assert fips_test.collect(module, collected_facts) == {'fips': False}

# test that the fips

# Generated at 2022-06-23 01:12:55.077027
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Unit test for constructor of class FipsFactCollector
    """
    fips_col = FipsFactCollector()
    assert fips_col.name == 'fips'
    assert fips_col._fact_ids == set()


# Generated at 2022-06-23 01:12:56.582495
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Performing test of constructor of class FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

# Generated at 2022-06-23 01:13:03.638914
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import get_file_content

    collector = FipsFactCollector()
    facts = {}
    with pytest.raises(TypeError):
        collector.collect(collected_facts=facts)

    import mock
    with mock.patch('ansible.module_utils.facts.collector.get_file_content'):
        get_file_content.return_value = '1'
        facts = collector._collect()

    # This is the test
    assert facts['fips'] is True


# Generated at 2022-06-23 01:13:04.260279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:13:05.553270
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:13:08.550500
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert 'fips' in fips_facts.collect()

# Generated at 2022-06-23 01:13:09.110275
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:13:10.878242
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:13:13.422652
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}



# Generated at 2022-06-23 01:13:15.496971
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()

    assert f.collect() == {'fips': False} or {'fips': True}

# Generated at 2022-06-23 01:13:17.180583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f=FipsFactCollector()
    f.collect()

# Generated at 2022-06-23 01:13:19.886811
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_dict = {'fips': False}
    fips_obj = FipsFactCollector()
    assert fips_obj.collect() == fips_dict

# Generated at 2022-06-23 01:13:22.525181
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:13:23.840343
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:34.682629
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    module = get_module_mock()
    collected_facts = {}

    collector = FipsFactCollector()

    # Test with a file with valid content
    with patch('ansible.module_utils.facts.collector.FipsFactCollector.get_file_content', return_value='1'):
        facts = collector.collect(module, collected_facts)
        assert facts['fips'] == True
    
    # Test with a file with invalid content
    with patch('ansible.module_utils.facts.collector.FipsFactCollector.get_file_content', return_value='test'):
        facts = collector.collect(module, collected_facts)
        assert facts['fips'] == False
    
    # Test without file content

# Generated at 2022-06-23 01:13:38.640272
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    # test for fips=True
    fips.collect() == True


# Generated at 2022-06-23 01:13:40.585461
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert isinstance(obj, FipsFactCollector)


# Generated at 2022-06-23 01:13:42.210604
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:43.832844
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert isinstance(obj, FipsFactCollector)

# Generated at 2022-06-23 01:13:45.085386
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:55.171907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Check on system where FIPS is not enabled
    test_obj = FipsFactCollector()
    collected_facts = test_obj.collect()
    assert type(collected_facts) is dict
    assert 'fips' in collected_facts
    assert not collected_facts['fips']

    # Check that on a system where FIPS is enabled
    test_obj.file_content['/proc/sys/crypto/fips_enabled'] = '1'
    collected_facts = test_obj.collect()
    assert type(collected_facts) is dict
    assert 'fips' in collected_facts
    assert collected_facts['fips']

    # Check that on a system where FIPS is enabled but /proc/sys/crypto/fips_enabled is not populated

# Generated at 2022-06-23 01:13:58.267096
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:01.320759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfactcollector = FipsFactCollector()
    assert fipsfactcollector.collect() is not {}
    assert 'fips' in fipsfactcollector.collect()

# Generated at 2022-06-23 01:14:03.670735
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == "fips"
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:14:06.004125
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    result = test_obj.collect()
    assert result["fips"] == False

# Generated at 2022-06-23 01:14:10.879860
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Make sure we get the right fips facts
    """
    FACT_DATA = {'fips': False}
    fips = FipsFactCollector()
    assert fips.collect() == FACT_DATA

# Generated at 2022-06-23 01:14:13.686008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:14:16.972155
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:14:19.914281
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f=FipsFactCollector()
    assert f.name == 'fips'



# Generated at 2022-06-23 01:14:21.848973
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:14:24.299948
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Unit test that verifies the file /proc/sys/crypto/fips_enabled is read correctly
    #
    # Arrange
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:14:27.018887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    # Test if all methods in class FipsFactCollector are invoked.
    assert f.collect()

# Generated at 2022-06-23 01:14:29.194373
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()


# Generated at 2022-06-23 01:14:31.537680
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj1 = FipsFactCollector()
    assert obj1.name == 'fips'
    obj1.collect()

# Generated at 2022-06-23 01:14:33.352344
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:14:35.135332
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:14:37.594103
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:14:39.663031
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:14:41.985224
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:14:45.914727
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:48.066574
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:14:50.122497
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:14:52.574483
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test = FipsFactCollector()
    assert test.collect() == { 'fips': False }


# Generated at 2022-06-23 01:14:55.840548
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # NOTE: assumes the module_utils/facts/utils.py function
    # get_file_content has been unit tested
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:14:56.835072
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  FipsFactCollector()

# Generated at 2022-06-23 01:14:58.259516
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert(FipsFactCollector.collect()['fips'] == False)

# Generated at 2022-06-23 01:15:00.180509
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    data = fips.collect()

    assert data['fips']

# Generated at 2022-06-23 01:15:01.577559
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-23 01:15:04.996855
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = AnsibleModule()
    fips_obj = FipsFactCollector(module=module)
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == {'fips'}


# Generated at 2022-06-23 01:15:08.965733
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()
    assert fact_collector.collect()
    fact_collector.get_fact_names()


# Generated at 2022-06-23 01:15:11.468026
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    # try without argument
    assert ffc.collect()['fips'] == False


# Generated at 2022-06-23 01:15:13.365297
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == False

# Generated at 2022-06-23 01:15:15.397518
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    gfc = FipsFactCollector()
    assert gfc.name == "fips"

# Generated at 2022-06-23 01:15:18.201529
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:15:20.183811
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect()
    assert facts
    assert len(facts) == 1
    assert facts['fips']

# Generated at 2022-06-23 01:15:25.873188
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_test = FipsFactCollector()
    # Should be named "fips"
    assert fips_test.name == 'fips'
    # Should contain the fact "fips"
    assert 'fips' in fips_test.collect()


# Generated at 2022-06-23 01:15:28.710617
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_collector = FipsFactCollector()
    test_facts = test_collector.collect()
    assert 'fips' in test_facts
    assert isinstance(test_facts['fips'], bool)

# Generated at 2022-06-23 01:15:31.473958
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:15:36.513045
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0



# Generated at 2022-06-23 01:15:40.177583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = dict()
    # Should return a dict of the FIPS setting for the system
    assert collector.collect(collected_facts=collected_facts) == {'fips': False}
    collector._file_cache.clear()

# Generated at 2022-06-23 01:15:49.442602
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
# Testing with no content in /proc/sys/crypto/fips_enabled
    content = ""
    get_file_content_orig = FipsFactCollector.get_file_content

    def side_effect(*args, **kwargs):
        if args[0] == '/proc/sys/crypto/fips_enabled':
            return content
        return get_file_content_orig(*args, **kwargs)

    FipsFactCollector.get_file_content = side_effect
    module = "module"
    collected_facts = "facts"
    result = FipsFactCollector().collect(module, collected_facts)
    assert result['fips'] == False

# Testing with content "1" in /proc/sys/crypto/fips_enabled
    content = "1"

# Generated at 2022-06-23 01:15:57.565025
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}

    # NOTE: this is populated even if it is not set
    fips_facts['fips'] = False

    # Data is not set
    collected_facts = {}
    data = None
    if data and data == '1':
        fips_facts['fips'] = True
    assert fips_facts == FipsFactCollector().collect(collected_facts)

    # Data is set but does not equal 1
    data = 'test'
    if data and data == '1':
        fips_facts['fips'] = True
    assert fips_facts == FipsFactCollector().collect(collected_facts)

    # Data is set but and equals 1
    data = '1'
    if data and data == '1':
        fips_facts['fips'] = True
    assert f

# Generated at 2022-06-23 01:16:01.505460
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:16:03.381911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    data = fips_fc.collect()
    assert data == {}

# Generated at 2022-06-23 01:16:06.302369
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert ('fips' in facts), "Failed to find fact 'fips' in %s" % facts

# Generated at 2022-06-23 01:16:09.111916
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:10.089491
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:16:20.722796
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # patch open to return some content
    with patch('ansible.module_utils.facts.collectors.fips.get_file_content') as mock_open:
        mock_open.return_value = '1'

        # instantiate class
        fips_fact_collector = FipsFactCollector()
        # call collect
        fips = fips_fact_collector.collect()
        # assert
        assert fips['fips'] == True

        # patch open to return some content
        with patch('ansible.module_utils.facts.collectors.fips.get_file_content') as mock_open:
            mock_open.return_value = '0'

            # call collect again
            fips = fips_fact_collector.collect()
            # assert
            assert fips['fips'] == None

# Generated at 2022-06-23 01:16:25.627059
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test valid output
    fips_fd = FipsFactCollector()
    fips_facts = fips_fd.collect()
    assert isinstance(fips_facts, dict)
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:16:28.244611
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts import Collector
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, Collector)

# Generated at 2022-06-23 01:16:30.967729
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:31.819874
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:16:33.288092
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected = 'fips'
    facts = FipsFactCollector()
    assert facts.name == expected

# Generated at 2022-06-23 01:16:35.554176
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector()
    assert facts.name == 'fips'
    assert facts._fact_ids == set()

# Generated at 2022-06-23 01:16:42.660746
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactsCollector
    from ansible.module_utils import basic
    import os
    import io
    import pytest
    import tempfile

    tmpdir = tempfile.gettempdir()
    filename = os.path.join(tmpdir, 'fips_enabled')

    fips = FipsFactCollector()
    afc = AnsibleFactsCollector(None, module_obj=basic)

    # Create a temporary file
    fh = io.open(filename, 'w')
    fh.write(u'1')
    fh.close()

    # Check if fips mode is enabled

# Generated at 2022-06-23 01:16:47.052759
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    if(fips.name != 'fips'):
        raise AssertionError('FipsFactCollector name should have been fips, not %s.' %fips.name)
    
# vim: expandtab filetype=python

# Generated at 2022-06-23 01:16:49.461120
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['fips'] == False

# Generated at 2022-06-23 01:16:52.052427
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:54.267340
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facter = FipsFactCollector()
    assert facter.name == 'fips'
    assert facter._fact_ids == set()

# Generated at 2022-06-23 01:16:56.516155
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_mock = {
        'fips': False
    }
    fips = FipsFactCollector()
    assert fips_mock == fips.collect()

# Generated at 2022-06-23 01:16:58.585155
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:17:07.723564
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup an 'Fips' fact collector
    fact_collector_instance = FipsFactCollector()

    # Create a stub module
    class StubModule(object):
        pass
    module = StubModule()

    # Create a stub file
    class StubFile(object):
        def __init__(self, content):
            self.content = content
        def read(self):
            return self.content
    mock_file = StubFile("somedata")

    # Create a stub facts
    collected_facts = {}
    collected_facts['fips'] = False

    # Create a stub open function
    def my_open(path):
        if path == "/proc/sys/crypto/fips_enabled" and mock_file is not None:
            return mock_file
        else:
            return None
    # Replace built-in open

# Generated at 2022-06-23 01:17:10.117304
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-23 01:17:12.879194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    facts = collector.collect(BaseFactCollector)
    assert facts['fips'] is not None

# Generated at 2022-06-23 01:17:15.464501
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set(['fips'])


# Generated at 2022-06-23 01:17:17.407351
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts_collector = FipsFactCollector()
    result = facts_collector.collect(None, None)

    assert isinstance(result, dict)

# Generated at 2022-06-23 01:17:23.480215
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_mock = None
    collected_facts_mock = None

    FipsFactCollector_instance = FipsFactCollector()
    assert type(FipsFactCollector_instance) == FipsFactCollector
    assert FipsFactCollector_instance.name == 'fips'
    assert FipsFactCollector_instance._fact_ids == set()

    fips_facts = FipsFactCollector_instance.collect(module_mock, collected_facts_mock)
    assert type(fips_facts) == dict
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:17:25.069473
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:17:26.426328
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    assert fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:29.542450
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ansible_fips = FipsFactCollector()
    result = ansible_fips.collect()
    assert result['fips'] == FipsFactCollector().collect()['fips']

# Generated at 2022-06-23 01:17:30.746354
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:17:31.707313
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:17:34.282639
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:17:38.363005
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:17:43.419221
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert 'fips' in fips_facts
    if fips_facts['fips'] == True:
        assert fips_facts['fips'] == True
    else: 
        assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:17:44.788827
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert repr(FipsFactCollector)

# Generated at 2022-06-23 01:17:45.845911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:17:48.059200
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert 'fips' in collector.collect()

# Generated at 2022-06-23 01:17:51.002507
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:17:55.170309
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_test = FipsFactCollector()
    assert repr(fips_test)
    assert fips_test.name == 'fips'
    assert fips_test.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:58.133380
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert 'fips' == fips.name

# Generated at 2022-06-23 01:18:00.522227
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    actual = fact_collector.collect()
    assert actual == {'fips': False}

# Generated at 2022-06-23 01:18:02.649906
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:18:05.088585
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    # NOTE: module.run_command not mocked
    obj = FipsFactCollector(module=module)
    obj.collect()

# Generated at 2022-06-23 01:18:07.072850
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'


# Generated at 2022-06-23 01:18:08.394559
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {
        'fips': False
    }

# Generated at 2022-06-23 01:18:11.932332
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    def fakegetfilecontent(path):
        return '1'

    module = FakeModule()

    FipsFactCollector.collect_method = fakegetfilecontent
    fips_facts = FipsFactCollector().collect(module=module)

    assert fips_facts is not None
    assert fips_facts['fips'] is True


# Generated at 2022-06-23 01:18:18.738347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}

    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect(module=module,
                                        collected_facts=collected_facts)
    assert 'fips' in fips_facts
    if fips_facts['fips']:
        assert fips_facts['fips'] == True
    else:
        assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:18:20.312782
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() \
        == {'fips': False}

# Generated at 2022-06-23 01:18:21.206620
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:18:23.672309
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:18:35.588500
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    hostvars = {}
    hostvars['ansible_facts'] = {}

    # host is FIPS enabled
    host = FipsFactCollector()
    hostvars['ansible_facts']['fips'] = True
    assert host.collect(collected_facts=hostvars['ansible_facts']) == {'fips': True}

    # host is NOT FIPS enabled
    host = FipsFactCollector()
    hostvars['ansible_facts']['fips'] = False
    assert host.collect(collected_facts=hostvars['ansible_facts']) == {'fips': False}

# Generated at 2022-06-23 01:18:37.975722
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'
    assert isinstance(fact._fact_ids, set)


# Generated at 2022-06-23 01:18:40.132927
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:18:42.186393
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()

# Generated at 2022-06-23 01:18:43.772160
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = None
    collected_facts = None
    fips_fc = FipsFactCollector()
    assert (fips_fc.name == 'fips')

# Generated at 2022-06-23 01:18:45.758744
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facter = FipsFactCollector()
    assert facter.name == 'fips'
    assert facter._fact_ids == set()
    