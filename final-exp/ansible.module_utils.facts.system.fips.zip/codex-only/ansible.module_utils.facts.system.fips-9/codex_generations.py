

# Generated at 2022-06-23 01:08:46.538849
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_module = FipsFactCollector()
    assert FipsFactCollector_module.collect() == {'fips': False}

# Generated at 2022-06-23 01:08:48.211717
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect().get('fips') == False

# Generated at 2022-06-23 01:08:51.985276
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    gf = FipsFactCollector()
    assert gf.collect() is not None
    assert gf.name == 'fips'

# Generated at 2022-06-23 01:08:54.445588
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

    f.collect()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:08:55.837609
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect()['fips'] == False

# Generated at 2022-06-23 01:08:57.258716
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:08:59.407297
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:09:04.601799
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:09:08.003146
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert len(ffc._fact_ids) == 1
    assert 'fips' in ffc._fact_ids


# Generated at 2022-06-23 01:09:12.438365
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-23 01:09:13.488979
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:09:14.437757
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect()

# Generated at 2022-06-23 01:09:19.569462
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create a dictionary of test arguments
    test_args = {}
    # populate test arguments
    test_args['module'] = None
    test_args['collected_facts'] = None
    # create a FipsFactCollector object
    fi = FipsFactCollector()
    # obtain result of method collect of FipsFactCollector class
    result = fi.collect(**test_args)
    assert isinstance(result,dict)

# Generated at 2022-06-23 01:09:23.142044
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:25.746944
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   fipsfactCollector = FipsFactCollector()
   assert fipsfactCollector.name == 'fips'

# Generated at 2022-06-23 01:09:29.200638
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:31.468436
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert 'fips' in facts
    assert facts['fips'] == False

# Generated at 2022-06-23 01:09:33.669839
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:09:34.774296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() is not None

# Generated at 2022-06-23 01:09:37.293187
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()

    assert fips_collector is not None

# Generated at 2022-06-23 01:09:39.898484
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    c = FipsFactCollector()
    assert c.name == 'fips'
    assert repr(c._fact_ids) == repr(set())


# Generated at 2022-06-23 01:09:41.334559
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:09:44.808847
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:48.656259
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Unit test for constructor of class FipsFactCollector"""
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    assert isinstance(fips_fact_collector.name, str)



# Generated at 2022-06-23 01:09:50.236497
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    f.collect()

# Generated at 2022-06-23 01:09:54.817691
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect(module=None, collected_facts=None)
    if isinstance(result, dict) and 'fips' in result:
        assert result['fips'] == False or result['fips'] == True
    else:
        assert False

# Generated at 2022-06-23 01:09:59.634948
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector =  FipsFactCollector()

    # Unit test for method collect of class FipsFactCollector
    def test_FipsFactCollector_collect(self):
        fact_collector =  FipsFactCollector()
        fact_collector.collect()

    kwargs = { "module": 'module', "collected_facts": 'fact' }
    fact_collector.collect(**kwargs)

# Generated at 2022-06-23 01:10:01.039518
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:10:04.498576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    module = None
    collected_facts = None
    fips_facts = collector.collect(module, collected_facts)
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:10:06.708604
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    facts = f.collect()
    assert facts['fips'] == False

# Generated at 2022-06-23 01:10:16.297248
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import Collector
    fips_fact_collector = FipsFactCollector()
    fact_collector = Collector()
    fact_collector._load_collectors({'fips': fips_fact_collector})
    fips_facts = {'fips': False}
    with pytest.helpers.mocked_open(data="0") as mocked_open:
        result = fact_collector.collect(module=None, collected_facts=None)
        assert isinstance(result, dict)
        assert result == fips_facts
        mocked_open.assert_called_once_with('/proc/sys/crypto/fips_enabled')
        assert result.get('fips') == False
    fips_facts = {'fips': True}

# Generated at 2022-06-23 01:10:27.732991
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Return a fact dict of the FIPS mode of the system.
    """
    FipsFactCollector._fact_ids = set()

    # If file exists and content is 1, FIPS mode enabled
    get_file_content_mock = lambda x: '1'
    FipsFactCollector.get_file_content = get_file_content_mock
    fc = FipsFactCollector()
    res = fc.collect()
    assert res == {'fips': True}

    # If file exists and content is not 1, FIPS mode disabled
    get_file_content_mock = lambda x: '0'
    FipsFactCollector.get_file_content = get_file_content_mock
    fc = FipsFactCollector()
    res = fc.collect()

# Generated at 2022-06-23 01:10:35.427584
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    import pytest_mock
    def mock_file_content(path, cache):
        return '1'
    monkeypatch = pytest.helpers.monkeypatch()
    monkeypatch.setattr(FipsFactCollector,'_get_file_content',mock_file_content)
    fips_facts = FipsFactCollector.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] == True
#===== End of Unit test for method collect of class FipsFactCollector=====

# Generated at 2022-06-23 01:10:39.858356
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips', 'test_FipsFactCollector assert #1 has failed.'
    assert fips_collector._fact_ids == set(), 'test_FipsFactCollector assert #2 has failed.'


# Generated at 2022-06-23 01:10:41.792939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    result = fips.collect()
    assert result['fips'] is False

# Generated at 2022-06-23 01:10:46.463402
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector._fact_ids


# Generated at 2022-06-23 01:10:47.112942
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:48.507079
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector()
    assert facts.name == 'fips'

# Generated at 2022-06-23 01:10:50.273935
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == "fips"

# Generated at 2022-06-23 01:10:50.850100
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:51.426631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:52.962213
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-23 01:10:53.878467
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()


# Generated at 2022-06-23 01:10:59.079934
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsc = FipsFactCollector()

    fipsc._module = {'run_command': lambda args: '1'}
    assert fipsc.collect(None, None) == {'fips': True}

    fipsc._module = {'run_command': lambda args: '0'}
    assert fipsc.collect(None, None) == {'fips': False}

# Generated at 2022-06-23 01:11:02.014467
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set((fips_fact.name,))

# Generated at 2022-06-23 01:11:04.101067
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:07.717497
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert not x._fact_ids
    assert x.collect() == { 'fips': False }

# Generated at 2022-06-23 01:11:09.528398
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:11:12.454160
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    result = fips_facts.collect(None, None)
    assert 'fips' in result
    assert result['fips'] == False or result['fips'] == True

# Generated at 2022-06-23 01:11:19.990633
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.file_exists = lambda x: True
    fips_fact_collector.get_file_content = lambda x: '0'
    assert fips_fact_collector.collect() == {'fips': False}
    fips_fact_collector.get_file_content = lambda x: '1'
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:11:21.809890
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:11:23.240048
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"

# Generated at 2022-06-23 01:11:26.266687
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test collect method of FipsFactCollector class
    """
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-23 01:11:29.520642
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create FipsFactCollector and call collect method
    fc = FipsFactCollector()
    test_dict = fc.collect()

    # Check returned dict
    assert isinstance(test_dict, dict)
    assert 'fips' in test_dict

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 01:11:35.198353
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == {'fips'}
    assert FipsFactCollector.collect() == {'fips': False}
    assert FipsFactCollector.collect(module=None, collected_facts=None) == {'fips': False}
# End of unit test

# Generated at 2022-06-23 01:11:37.573106
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    o = FipsFactCollector()
    assert o.name == 'fips'
    assert o._fact_ids == set()
    assert o.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:39.241077
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector.collect() is not None

# Generated at 2022-06-23 01:11:41.364128
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact
    assert fact.name == 'fips'
    assert fact._fact_ids == set()

# Generated at 2022-06-23 01:11:43.096398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:11:45.637118
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert isinstance(collector, FipsFactCollector)
    assert collector.name == 'fips'
    assert not collector._fact_ids


# Generated at 2022-06-23 01:11:47.772831
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:11:55.106672
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup - Mock the openssl_binary
    fact_collector = FipsFactCollector()

    # Test - Return true
    fact_collector.get_file_content = lambda x: "1"
    facts = fact_collector.collect()
    assert facts['fips'] == True

    # Test - Return false
    fact_collector.get_file_content = lambda x: ""
    facts = fact_collector.collect()
    assert facts['fips'] == False

    fact_collector.get_file_content = lambda x: "0"
    facts = fact_collector.collect()
    assert facts['fips'] == False

    fact_collector.get_file_content = lambda x: "Unknown"
    facts = fact_collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-23 01:12:00.786987
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    mock_facts = {}
    fips_facts = fips_fact_collector.collect(collected_facts=mock_facts)
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:12:03.254215
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'
    assert 'fips' in fact._fact_ids

# Generated at 2022-06-23 01:12:04.414531
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()


# Generated at 2022-06-23 01:12:07.614009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    assert type(fips_facts_collector) == FipsFactCollector
    assert fips_facts_collector.name == 'fips'
    assert type(fips_facts_collector._fact_ids) == set
    assert type(fips_facts_collector.collect()) == dict


# Generated at 2022-06-23 01:12:10.300253
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:12:12.344157
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips' : False}

# Generated at 2022-06-23 01:12:13.457297
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:12:16.981015
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set up mock FipsFactCollector object
    mock_class = type('FipsFactCollector', (object,), {
        'collect':FipsFactCollector.collect
    })
    mock_obj = mock_class()

    # Execute the method under test
    result = mock_obj.collect()

    # Assert that the result is what we expect
    assert result == {'fips': False}

# Generated at 2022-06-23 01:12:19.339341
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    assert fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:12:21.458402
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    x = FipsFactCollector()
    x.collect()

# Generated at 2022-06-23 01:12:22.521460
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:25.145750
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

    assert fact_collector.__class__.__name__ == 'FipsFactCollector'


# Generated at 2022-06-23 01:12:27.992382
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-23 01:12:31.125698
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfact = FipsFactCollector()
    assert fipsfact
    assert fipsfact.name == 'fips'
    assert fipsfact._fact_ids == set()
    assert fipsfact.collect() == {'fips': False}

# Generated at 2022-06-23 01:12:32.909327
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert facts['fips'] is False

# Generated at 2022-06-23 01:12:33.766697
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:12:39.804713
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_system = FipsFactCollector()

    test_system.get_file_content = lambda x: 1
    assert test_system.collect() == {'fips': True}

    test_system.get_file_content = lambda x: 0
    assert test_system.collect() == {'fips': False}

# Generated at 2022-06-23 01:12:50.548355
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.fact import Fact
    import collections
    import os

    # Create object for class FipsFactCollector
    FipsFactCol_obj = FipsFactCollector()
    FipsFactCol_obj.collector = Collector()
    FipsFactCol_obj.collector.module_setup = True
    FipsFactCol_obj.collector.facts = collections.defaultdict(Fact)
    setattr(FipsFactCol_obj.collector, '_file_contents', collections.defaultdict(str))
    setattr(FipsFactCol_obj.collector, 'file_exists', collections.defaultdict(bool))

    # Create object for

# Generated at 2022-06-23 01:12:52.006589
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    x = FipsFactCollector()
    assert 'fips' in x._fact_ids

# Generated at 2022-06-23 01:12:54.268472
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == { 'fips': False }

# Generated at 2022-06-23 01:12:55.825735
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-23 01:12:57.321195
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:12:58.912517
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:13:00.823832
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_dict = FipsFactCollector.collect(collected_facts={})
    assert facts_dict is not None

# Generated at 2022-06-23 01:13:03.602306
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    result = FipsFactCollector.collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:13:06.867169
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    fips_facts = c.collect()
    assert isinstance(fips_facts, dict)
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:13:09.866697
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:13:11.221873
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:13:12.895695
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    fips_obj.collect()

# Generated at 2022-06-23 01:13:15.014259
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    data = FipsFactCollector().collect()
    assert data == {'fips':False}, "data = %s" % data


# Generated at 2022-06-23 01:13:17.546121
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'


# Generated at 2022-06-23 01:13:18.602467
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# Generated at 2022-06-23 01:13:20.862210
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert facts == {'fips': False}, "test_FipsFactCollector_collect failed"

# Generated at 2022-06-23 01:13:23.143889
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    with open('fips_enabled.txt', 'w') as f:
        f.write('1')
    assert fips_fact.collect() == {'fips': True}

# Generated at 2022-06-23 01:13:27.032529
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:30.068175
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-23 01:13:31.353075
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'

# Generated at 2022-06-23 01:13:35.629602
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:47.621565
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    # Create an instance FipsFactCollector
    get_file_content_mock = get_file_content
    get_file_content_mock.return_value = '1'
    ffc = FipsFactCollector()
    # Change the state of member variables of class FactsCollector
    FactsCollector._collectors['fips'] = ffc
    # Create an instance of AnsibleModule and set collected_facts to an empty
    # dictionary
    ansible_module = ansible_collector
    ansible_module.col

# Generated at 2022-06-23 01:13:52.626693
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    mock_module = MagicMock(return_value=None)
    mock_collected_facts = {}
    returned_fips_facts = FipsFactCollector_obj.collect(mock_module, mock_collected_facts)
    assert returned_fips_facts['fips'] is False

# Generated at 2022-06-23 01:13:55.094530
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()
    assert collector.collector == 'FipsFactCollector'


# Generated at 2022-06-23 01:13:57.286771
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == False

# Generated at 2022-06-23 01:14:01.819759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_FipsFactCollector = FipsFactCollector(None)
    result = test_FipsFactCollector.collect()
    assert "fips" in result
    assert isinstance(result['fips'], bool)
    assert result.get('fips') is False

# Generated at 2022-06-23 01:14:04.672249
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_obj = FipsFactCollector()
    assert my_obj.name == 'fips'
    assert len(my_obj._fact_ids) == 0


# Generated at 2022-06-23 01:14:16.235613
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    import io
    import tempfile
    import pytest

    fips_true_data = u'1\n'
    fips_false_data = u'0\n'
    fips_empty_data = u'\n'
    fips_non_binary_data = u'2\n'
    fips_not_content_data = u'\nnot content\n'

    @pytest.fixture
    def module(self):
        return mock.MagicMock()

    @pytest.fixture
    def CollectorClass(self):
        return Collector


# Generated at 2022-06-23 01:14:17.532398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 01:14:27.344633
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create FipsFactCollector object
    ffc = FipsFactCollector()

    # create mock object for module
    class Module:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = list()

    # create mock object for collected facts
    class CollectedFacts:
        def __init__(self):
            self._collected_facts = dict()

        def get_collected_facts(self):
            return self._collected_facts

    # create CollectedFacts object
    cf = CollectedFacts()

    # run collect method
    try:
        ffc.collect(Module(), cf.get_collected_facts())
    except SystemExit:
        pass

    # If run in "fips" mode, the file /proc/sys/crypto

# Generated at 2022-06-23 01:14:29.490438
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    collector_name = fips_collector.name
    assert collector_name == 'fips'

# Generated at 2022-06-23 01:14:30.449614
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:14:32.758975
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert len(ffc.collect()) != 0

# Generated at 2022-06-23 01:14:34.936362
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Unit test for constructor of class FipsFactCollector
    """
    foo1 = FipsFactCollector()
    assert foo1 is not None

# Generated at 2022-06-23 01:14:37.391032
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:14:39.181416
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:14:41.349857
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert len(fips_facts._fact_ids) == 0

# Generated at 2022-06-23 01:14:48.068764
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test if a file is populated with a result that matches expected result
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert(FipsFactCollector().collect() == fips_facts)

# Generated at 2022-06-23 01:14:53.053759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, FipsFactCollector)
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector.collect()

# Generated at 2022-06-23 01:14:57.085133
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  fipsFacCol = FipsFactCollector()
  ans = fipsFacCol.collect()
  assert ans['fips'] == False

# Test that the FipsFactCollector class is a subclass of BaseFactCollector
assert issubclass(FipsFactCollector, BaseFactCollector)

# Generated at 2022-06-23 01:14:59.699862
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:15:01.920973
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert set() == fc._fact_ids

# Generated at 2022-06-23 01:15:04.255478
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Function to collect fips facts

# Generated at 2022-06-23 01:15:09.764540
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ test collect method of FipsFactCollector """
    def _mock_get_file_content(file_path):
        def_false = '0'
        def_true = '1'
        if file_path == '/proc/sys/crypto/fips_enabled':
            return def_false
        else:
            return None
    fact_collector = FipsFactCollector()
    fact_collector._get_file_content = _mock_get_file_content
    facts = fact_collector.collect()
    assert 'fips' in facts and facts['fips']==False

# Generated at 2022-06-23 01:15:11.846675
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect()
    assert not ffc.collect()

# Generated at 2022-06-23 01:15:14.446628
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.collect(None, None) == {
        'fips': False
    }

# Generated at 2022-06-23 01:15:17.439588
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Verify that dict returned by constructor is what we expect
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:15:18.845978
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:15:21.460051
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f=FipsFactCollector()
    content = f._read_file('/proc/sys/crypto/fips_enabled','r')
    assert content == f.collect()

# Generated at 2022-06-23 01:15:23.861714
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_obj = FipsFactCollector()
    assert facts_obj.name == 'fips'
    assert facts_obj._fact_ids == set()


# Generated at 2022-06-23 01:15:26.654201
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector(None)
    facts_dict = collector.collect()
    assert 'fips' in facts_dict
    assert type(facts_dict['fips']) == bool

# Generated at 2022-06-23 01:15:30.361580
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_instance = FipsFactCollector()
    assert fips_instance.name == 'fips'


# Generated at 2022-06-23 01:15:40.934485
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    test_fips = FipsFactCollector()

    # Assert that fips = False because /proc/sys/crypto/fips_enabled contain
    # value 0
    test_fc = test_fips.collect(collected_facts={'fips': 0})
    D = False
    assert(test_fc.get('fips') == D)

    # Assert that fips = True because /proc/sys/crypto/fips_enabled contain
    # value 1
    test_fc = test_fips.collect(collected_facts={'fips': 1})
    D = True
    assert(test_fc.get('fips') == D)

# Generated at 2022-06-23 01:15:43.885560
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids = set()
    fips = {'fips': False}
    assert(FipsFactCollector.collect() == fips)

# Generated at 2022-06-23 01:15:46.242123
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector_obj = FipsFactCollector()
    assert fact_collector_obj.name == 'fips'
    assert fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:15:51.371772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModuleMock()
    fips_fact_collector = FipsFactCollector(module=module, collected_facts=None)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:15:54.121802
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts_dict = collector.collect()
    assert 'fips' in facts_dict

# Generated at 2022-06-23 01:15:57.743708
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:15:59.641718
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:16:01.974196
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:16:03.771311
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  fips_fact = FipsFactCollector()
  assert(fips_fact.name == 'fips')

# Generated at 2022-06-23 01:16:07.049004
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ansible_module = None
    set_module_args = None
    collected_facts = {'fips': False}
    f = FipsFactCollector()
    assert f.collect(ansible_module, collected_facts) == collected_facts

# Generated at 2022-06-23 01:16:09.892095
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:15.830260
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips_facts = fips_fact.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    fips_state = fips_facts['fips']
    assert isinstance(fips_state, bool)
    assert fips_state == False

# Generated at 2022-06-23 01:16:17.177588
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert result.get('fips') is True



# Generated at 2022-06-23 01:16:19.661064
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {}
    collected_facts['ansible_local'] = {}

    FipsFactCollector.collect(module=None, collected_facts=collected_facts)

# Generated at 2022-06-23 01:16:22.643970
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:16:24.713050
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test = FipsFactCollector()
    data = test.collect()
    assert data['fips'] is False
    return

# Generated at 2022-06-23 01:16:26.902710
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    test_obj = FipsFactCollector()
    test_obj.collect()
    assert test_obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:28.512324
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:34.732967
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Input data
    content = """# FIPS mode enabled status
0
"""
    # Expected output
    expected_value = {
        'fips': False
    }
    # Run the test
    FipsFactCollector.collect(collector=FipsFactCollector, module=None, collected_facts=None)
    # Check the results
    get_file_content.assert_called_once_with('/proc/sys/crypto/fips_enabled')
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:16:41.057435
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Define a mock for the get_file_content method call
    def mock_get_file_content(file_name):
        if file_name == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return ''

    # Declare a test-specific module object
    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, msg):
            self.exit_args = msg

    # Define a global function to be mocked
    module = MockModule(root_helper='sudo')

    # Initialize a global instance of the object
    fips_fact_collector = FipsFactCollector()

    # Change the default value of a module parameter to force a specific path
    fips_fact_collect

# Generated at 2022-06-23 01:16:44.769965
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Arrange
    fips_fact_collector = FipsFactCollector()

    # Act and Assert
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:47.723325
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test case for the method collect of class FipsFactCollector
    """
    fips_facts = FipsFactCollector().collect()

    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:16:50.841203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    MockModule = type('MockModule', (object,), {'exit_json': lambda self, **kwargs: None})
    m = MockModule()
    c = FipsFactCollector()
    c.collect(m, {})

# Generated at 2022-06-23 01:16:54.482413
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector
    assert FipsFactCollector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:59.184419
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.get_facts() == dict(fips=False)
    collector = FipsFactCollector()
    get_file_content_mock = collector._get_file_content
    get_file_content_mock.return_value = '1'
    assert collector.get_facts() == dict(fips=True)

# Generated at 2022-06-23 01:17:01.730856
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create instance of FipsFactCollector
    fips_facts = FipsFactCollector()

    # Assert that fips fact collector has been created
    assert fips_facts is not None


# Generated at 2022-06-23 01:17:04.600901
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:17:13.484481
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module = Mock()
    fips_fact_collector._module.run_command = Mock(
        return_value = (0, "1", ""))
    fips_facts = fips_fact_collector.collect()
    assert fips_facts is not None
    fipssysinfo = fips_facts['fips']
    assert fipssysinfo == True
    fips_fact_collector._module.run_command.assert_called_once_with('cat /proc/sys/crypto/fips_enabled')


# Generated at 2022-06-23 01:17:16.449931
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    assert fips_collector.name == 'fips'

if __name__ == '__main__':
    test_FipsFactCollector_collect()

# Generated at 2022-06-23 01:17:18.754281
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:17:20.520845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    fips_fc.collect()

# Generated at 2022-06-23 01:17:22.258633
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test for constructor of class FipsFactCollector
    # Assertion error when an object is not created
    FipsFactCollector()

# Generated at 2022-06-23 01:17:30.674870
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Return a fact for FIPS mode enabled

    The method 'collect' from FipsFactCollector class should return
    a string 'True' if the system is in FIPS mode, false otherwise.
    """
    import os
    import tempfile
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.collector import Facts

    # Test if the system is not in FIPS mode
    with tempfile.NamedTemporaryFile(mode='wt') as f:
        f.write('0')
        f.flush()

        fips_fact_collector = FipsFactCollector()
        collected_facts = Facts()
        fips_fact_collector.collect(collected_facts=collected_facts)

        assert fips_fact_collector.name == 'fips'
        assert collected_

# Generated at 2022-06-23 01:17:40.171309
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test method collect of class FipsFactCollector
    """
    # Build test classes
    class MockModule:
        def __init__(self):
            self.params = {}

    class MockFile:
        def __init__(self):
            self.contents = None

        def __call__(self, file_path):
            return self

        def read(self):
            return self.contents

    mock_module = MockModule()
    mock_file = MockFile()

    # Test where /proc/sys/crypto/fips_enabled returns 0
    mock_file.contents = '0'
    fips_fact_collector = FipsFactCollector(mock_module)
    assert fips_fact_collector.collect() == {'fips': False}

    # Test where /proc/sys

# Generated at 2022-06-23 01:17:43.662570
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Tests constructor of FipsFactCollector class.
    """
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:46.582899
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    res = ffc.collect()
    assert res['fips'] == False or isinstance(res['fips'], int) or res['fips'] == True

# Generated at 2022-06-23 01:17:51.702476
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-23 01:17:56.013842
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Unit test for FipsFactCollector class constructor"""
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact.collector == '_collect_fips_info'

# Generated at 2022-06-23 01:17:58.600858
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert isinstance(x, FipsFactCollector)

# Generated at 2022-06-23 01:18:01.855177
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()
    assert fips_fc._platform == 'Generic'

# Generated at 2022-06-23 01:18:05.276858
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids

# Generated at 2022-06-23 01:18:12.038292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc is not None
    fips_fc._module = None
    fips_fc._collected_facts = {}
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    result = fips_fc.collect()
    assert result is not None
    assert type(result) is dict
    assert len(result) == 1
    assert 'fips' in result
    print("Default: ", result['fips'])
    if data == '1':
        assert result['fips'] is True
    else:
        assert result['fips'] is False

# Generated at 2022-06-23 01:18:15.059887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'

# Generated at 2022-06-23 01:18:17.946939
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:18:28.729044
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a instance of class FipsFactCollector
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] is False
    # Set the content of file /proc/sys/crypto/fips_enabled to 1
    fp_content = '1'
    # Verify default value of fips is the same as the value of file
    # /proc/sys/crypto/fips_enabled
    assert fips_facts['fips'] == (fp_content == '1')

# Generated at 2022-06-23 01:18:31.671945
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert isinstance(fips_facts, dict)

# Generated at 2022-06-23 01:18:34.498816
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    facts = FipsFactCollector().collect(module, collected_facts)
    assert facts['fips'] == False

# Generated at 2022-06-23 01:18:35.995892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:18:38.259213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = {'fips': False}
    assert fips_fact_collector.collect() == facts

# Generated at 2022-06-23 01:18:46.729272
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Test 1
    fips_state = False
    base_collector = BaseFactCollector
    base_collector.get_file_content = lambda x: '1'
    fc = FipsFactCollector(base_collector)
    collected_facts = { 'ansible_fips': fips_state }
    fips_facts = fc.collect(collected_facts=collected_facts)
    assert fips_facts['fips'] == True

    # Test 2
    fips_state = True
    base_collector = BaseFactCollector
    base_collector.get_file_content = lambda x: '0'
    fc = FipsFactCollector(base_collector)
    collected_facts = { 'ansible_fips': fips_state }
    fips_facts = fc