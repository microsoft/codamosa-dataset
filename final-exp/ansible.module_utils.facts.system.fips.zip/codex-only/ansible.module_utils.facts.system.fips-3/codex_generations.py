

# Generated at 2022-06-23 01:08:51.579911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_dict = {'fips': False}
    fc = FipsFactCollector()
    # When file does not exist then 'fips' should be False
    result_dict = fc.collect(collected_facts=None)
    assert result_dict == fips_dict

    # When file exists and fips is not enabled then 'fips' should be False
    fc.get_file_content = lambda x: 0
    result_dict = fc.collect(collected_facts=None)
    assert result_dict == fips_dict

    # When file exists and fips is enabled then 'fips' should be True
    fc.get_file_content = lambda x: 1
    fips_dict = {'fips': True}
    result_dict = fc.collect(collected_facts=None)

# Generated at 2022-06-23 01:08:54.587796
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:08:55.702728
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:08:57.561636
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj is not None


# Generated at 2022-06-23 01:08:58.562551
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:00.223364
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'

# Generated at 2022-06-23 01:09:08.943613
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Tests if fips is false when /proc/sys/crypto/fips_enabled is
    # absent since it is not present on Red Hat 7 and below
    assert fips_fact_collector.collect()['fips'] == False
    # Tests if fips is true when /proc/sys/crypto/fips_enabled is 1
    # This is for Red Hat 8 and above
    assert fips_fact_collector.collect()['fips'] == True

# Generated at 2022-06-23 01:09:19.788576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_util_loader
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    module_mock = mock_module_util_loader()
    module_mock.get_file_content.return_value = None
    ffc = FipsFactCollector(module=module_mock)
    assert isinstance(ffc, BaseFactCollector)
    assert ffc.name == 'fips'
    expected = {'fips': False}
    assert ffc.collect() == expected

    module_mock.get_file_content.return_value = '1'

# Generated at 2022-06-23 01:09:21.648527
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:09:24.480201
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    factCollector = FipsFactCollector()
    factCollector.collect()
    assert 'fips' in factCollector._fact_ids
    assert factCollector._fact_ids.__len__()==1

# Generated at 2022-06-23 01:09:25.669421
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-23 01:09:28.213029
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert result['fips'] is False


# Generated at 2022-06-23 01:09:32.084007
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a new object of type FipsFactCollector
    ff = FipsFactCollector()
    # Get the collect method
    col = ff.collect()
    # Check if it is a dictionary type and if it has a key 'fips'
    assert(type(col) == dict and 'fips' in col)

# Generated at 2022-06-23 01:09:36.318235
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert isinstance(fips_fc, FipsFactCollector)
    assert 'fips' == fips_fc.name
    assert not bool(fips_fc._fact_ids)


# Generated at 2022-06-23 01:09:38.813543
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'


# Generated at 2022-06-23 01:09:44.502514
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector({})
    collected_facts = {}
    # Test with fips mode enabled
    fips_fc.collect(collected_facts=collected_facts)
    assert collected_facts['crypto']['fips']

    # Test with fips mode enabled
    fips_fc.collect(collected_facts=collected_facts)
    assert 'fips' in collected_facts

# Generated at 2022-06-23 01:09:47.107014
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #Create an instance of the class FipsFactCollector
    fipsFactCollector = FipsFactCollector()
    collected_fact = fipsFactCollector.collect()
    assert collected_fact
    assert collected_fact["fips"] == False

# Generated at 2022-06-23 01:09:47.849290
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:50.473615
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:51.496943
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:09:52.610478
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:57.692340
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert isinstance(fact_collector, FipsFactCollector)
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids is not None
    assert fact_collector.title == 'FIPS Enabled facts'
    assert fact_collector.description == ''

# Generated at 2022-06-23 01:10:03.178164
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    fips_collector = FipsFactCollector()

    # Generate the facts from the method collect
    ansible_facts = fips_collector.collect()

    # Check that the ansible_facts generated are correct
    assert ansible_facts['fips'] == False

# Generated at 2022-06-23 01:10:06.570722
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids is not None

# Generated at 2022-06-23 01:10:09.593815
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = { 'fips': False }

    fips_collection = FipsFactCollector
    fips_collection.collect = MagicMock(return_value=fips_facts)

# Generated at 2022-06-23 01:10:11.651811
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'


# Generated at 2022-06-23 01:10:15.424262
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids = set()
    FipsFactCollector._fact_id = set()
    assert FipsFactCollector.collect(None, None)

# Generated at 2022-06-23 01:10:18.241487
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert 'fips' == fips_facts.name
    assert set() == fips_facts._fact_ids

# Generated at 2022-06-23 01:10:20.461777
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    print(fips_facts)

# Generated at 2022-06-23 01:10:21.954039
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest

    assert FipsFactCollector.collect() == pytest

# Generated at 2022-06-23 01:10:26.798198
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    collected_facts = dict()
    collected_facts = fips_facts_collector.collect(collected_facts=collected_facts)

    assert 'fips' in collected_facts
    assert collected_facts['fips'] is False or collected_facts['fips'] is True

# Generated at 2022-06-23 01:10:28.938488
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-23 01:10:29.915426
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:10:34.631760
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    fips_fact_collector = FipsFactCollector()

    # Act
    result = fips_fact_collector.collect()

    # Assert
    assert type(result) == dict
    assert 'fips' in result


# Generated at 2022-06-23 01:10:35.570511
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:10:37.580068
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = {'fips': False}
    assert fips.collect() == fips_facts

# Generated at 2022-06-23 01:10:42.579126
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_FipsFactCollector = FipsFactCollector()
    test_collected_facts = {}
    test_method_collect_ans = {'fips': False}
    method_collect_ans = test_FipsFactCollector.collect(collected_facts=test_collected_facts)
    assert test_method_collect_ans == method_collect_ans

# Generated at 2022-06-23 01:10:52.705076
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # gather_subset: all
    # filter: *
    # gather_network_resources: no
    FipsFactCollector_ins = FipsFactCollector()

    # normal check
    fips_facts = FipsFactCollector_ins.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts.keys()

    # check for when fips is set
    fips_facts['fips'] = False
    fips_facts = FipsFactCollector_ins.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts.keys()
    assert fips_facts['fips'] is True

# Generated at 2022-06-23 01:10:54.589001
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 01:10:57.200511
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:10:59.459545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    FipsFactCollector().collect(module=module)

# Generated at 2022-06-23 01:11:02.216918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_module = {"fips": False}
    fips_facts = FipsFactCollector().collect()
    assert(fips_facts == test_module)

# Generated at 2022-06-23 01:11:04.100680
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'


# Generated at 2022-06-23 01:11:07.318669
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:11:09.922510
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:11:17.962211
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create object instance of class FipsFactCollector
    test_obj = FipsFactCollector()

    # Set up a test of collect method
    # Create the state dictionary
    test_obj.state = {
        'fips': False
    }
    # Create the module_name dictionary
    module_name = {}

    # Create the collected_facts dictionary
    collected_facts = {}

    # Unit test the collect method of class FipsFactCollector
    assert test_obj.collect(module_name, collected_facts) == {
        'fips': False
    }

# Generated at 2022-06-23 01:11:21.153040
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect(None, None)
    assert result['fips'] is False


# Generated at 2022-06-23 01:11:24.736622
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    collected_facts = {}
    collected_facts['fips'] = False
    assert fc.collect(collected_facts=collected_facts) == {'fips': False}

# Generated at 2022-06-23 01:11:26.845203
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name =='fips'

# Generated at 2022-06-23 01:11:32.863289
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write('0')
    assert FipsFactCollector().collect() == {'fips': False}

    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write('1')
    assert FipsFactCollector().collect() == {'fips': True}


# Generated at 2022-06-23 01:11:35.866196
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:11:38.610147
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert isinstance(FipsFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:11:48.073238
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_data = [{'ansible_architecture': 'x86_64',
                     'ansible_distribution': 'CentOS',
                     'ansible_distribution_file_parsed': True,
                     'ansible_distribution_file_path':  '',
                     'ansible_distribution_file_variety': 'RedHat',
                     'ansible_distribution_major_version': '7',
                     'ansible_distribution_release': 'Core',
                     'ansible_distribution_version': '7',
                     'ansible_fips': False,
                     'ansible_machine': 'x86_64',
                     'ansible_os_family': 'RedHat'}]

    assert FipsFactCollector().collect(module=None) == fixture_data[0]

# Generated at 2022-06-23 01:11:54.942904
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case 1
    # Test when file /proc/sys/crypto/fips_enabled does not exist
    from ansible.module_utils.facts.collector import FipsFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactsCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_FipsFactCollector = FipsFactCollector()
    test_FipsFactCollector.name = 'fips'

    AnsibleFactsCollector_obj = AnsibleFactsCollector()
    AnsibleFactsCollector_obj.collector_list = ['fips']
    AnsibleFactsCollector_obj.collector_objects_list = [test_FipsFactCollector]


# Generated at 2022-06-23 01:11:57.211925
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:12:05.582702
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test case to run collect method of class FipsFactCollector """

    # Test 1: option fips test with the valid file content
    test_1 = {'fips': True}
    collector = FipsFactCollector()
    data = collector.collect()
    assert data['fips'] == test_1['fips']

    # Test 2: option fips test with the empty file content
    test_2 = {'fips': False}
    collector = FipsFactCollector()
    data = collector.collect()
    assert data['fips'] == test_2['fips']

# Generated at 2022-06-23 01:12:11.347939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = type('module', (object,), {})()
    mock_module.params = {'gather_subset': ['!all', 'fips']}
    mock_module.check_mode = False
    ffc_obj = FipsFactCollector(mock_module)
    assert ffc_obj
    res = ffc_obj.collect()
    assert 'fips' in res
    assert res['fips'] == False

# Generated at 2022-06-23 01:12:14.070222
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-23 01:12:17.797582
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    values = list(result['fips'].values())
    assert values[0] == False


# Generated at 2022-06-23 01:12:21.962589
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:12:26.469652
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    # create context manager for patching open
    from mock import patch, mock_open
    with patch.object(FipsFactCollector, 'collect', return_value={'fips': False}):
        r = fips_fc.collect()
        assert r == {'fips': False}

# Generated at 2022-06-23 01:12:27.396900
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector

# Generated at 2022-06-23 01:12:30.670527
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect()
    assert(facts['fips'] != True)

# Generated at 2022-06-23 01:12:37.854677
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Unit test for method collect of class FipsFactCollector
        Test the result from a true condition
    """
    class MockFileContent:
        def __init__(self, mock_value):
            self.value = mock_value

        def read(self):
            return self.value

    # Note: We mock lines in order to avoid 'wget' command call.
    mock_lines = ['data']

    FipsFactCollector.FACT_SUBSETS = {'all': set()}
    FipsFactCollector.COLLECTION_PERSISTENT = 1
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts == '{"fips": false}'
    
    FipsFactCollector.FACT_SUBSETS = {'all': set()}
    FipsFactCollect

# Generated at 2022-06-23 01:12:42.585285
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Unit test to check the initializer of class FipsFactCollector.
    """
    fips_obj = FipsFactCollector()
    #Checking for empty name and fact_ids
    assert fips_obj.name == 'fips'
    assert not fips_obj._fact_ids

# Generated at 2022-06-23 01:12:43.631902
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   assert FipsFactCollector(None) != None

# Generated at 2022-06-23 01:12:46.859591
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:12:49.848816
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:12:51.476091
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert result == {'fips': False}

# Generated at 2022-06-23 01:12:53.354213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect()['fips'] == False

# Generated at 2022-06-23 01:12:54.971820
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts.collect()['fips']

# Generated at 2022-06-23 01:13:04.717152
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case 1: test method collect with fips is disabled on system
    content = '0'
    fips_facts = {'fips': False}
    open_mock = mock.mock_open(read_data=content)
    with mock.patch('ansible.module_utils.facts.collector.FipsFactCollector.open', open_mock, create=True):
        fips_facts_instance = FipsFactCollector()
        fips_facts_retval = fips_facts_instance.collect()
        assert fips_facts_retval == fips_facts
    # Test case 2: test method collect with fips is enabled on system
    content = '1'
    fips_facts = {'fips': True}

# Generated at 2022-06-23 01:13:08.095216
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:10.226448
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-23 01:13:11.564616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:13:13.590769
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect()
    assert facts['fips'] == True or facts['fips'] == False

# Generated at 2022-06-23 01:13:20.682172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Create a mock FileModule
    class FIPSModule(object):
        pass

    mock_module = FIPSModule()
    mock_module._name = "ansible_facts"
    mock_module._file_name = "/proc/sys/crypto/fips_enabled"

    # Set the contents which will be returned by FileModule.get_file_content
    contents = "1"
    mock_module.get_file_content = lambda _: contents

    collector = FipsFactCollector(mock_module)
    facts = collector.collect()
    assert len(facts) == 1
    assert facts['fips']


# Generated at 2022-06-23 01:13:23.033812
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Construct a FipsFactCollector
    fips_obj = FipsFactCollector()

    # Test name
    assert fips_obj.name == "fips"

    # Test name
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-23 01:13:25.163476
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert(isinstance(fips_fact_collector.collect(), dict) == True)

# Generated at 2022-06-23 01:13:33.530357
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class mock_module:
        pass

    class mock_collector:
        def __init__(self,name):
            self.name = name
            self._fact_ids = set()
        def fact_already_collected(self, data):
            return False
        def get_collected_facts(self):
            return {}

    fips_collector = FipsFactCollector(mock_collector('fips'))
    collected_facts = fips_collector.collect(mock_module())
    #print(collected_facts['fips'])
    assert collected_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:13:39.178110
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test constructor of class FipsFactCollector
    fact_collector = FipsFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fips'
    assert fact_collector.collect() is not None
    assert not fact_collector.collect()['fips']

# Generated at 2022-06-23 01:13:44.156305
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # FipsFactCollector object
    FFC = FipsFactCollector()

    # Call collect method of FipsFactCollector object to get fips facts
    fips_facts = FFC.collect()

    # Assert facts
    assert fips_facts is not None
    assert fips_facts == {'fips':True}

# Generated at 2022-06-23 01:13:46.284501
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:13:49.019627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print('Testing collect()')
    my_collector = FipsFactCollector()
    my_collector.collect()
    assert my_collector.name == 'fips'

# Generated at 2022-06-23 01:13:51.715918
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    if obj is not None:
        print("Test successful")
    else:
        print("Test unsuccessful")


# Generated at 2022-06-23 01:14:00.519391
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup test
    testargs = {}
    testargs['ansible_module_instance'] = object
    testargs['ansible_module_instance'].tmpdir = 'tmpdir1'
    import ansible.module_utils.facts.collectors.fips.test_fips_collector
    from ansible.module_utils.facts.collectors.fips.test_fips_collector import (
        open_mock)
    ansible.module_utils.facts.collectors.fips.test_fips_collector.open_mock =\
        lambda n, m: open(n.replace('tmpdir1', 'fips_collector'), m)


# Generated at 2022-06-23 01:14:02.489680
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:14:05.394860
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    a = FipsFactCollector()
    assert 'fips' == a.name
    assert isinstance(a._fact_ids, set)


# Generated at 2022-06-23 01:14:09.080770
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set(['fips'])


# Generated at 2022-06-23 01:14:11.046595
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector is not None

# Generated at 2022-06-23 01:14:22.589220
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_fips_collector = FipsFactCollector()
    fact_fips_collector._module = None

    # check if the fips_enabled file exists
    fact_fips_collector._get_file_content = lambda x: x
    assert fact_fips_collector.collect() == {'fips': '/proc/sys/crypto/fips_enabled'}
    fact_fips_collector._get_file_content = lambda x: x if x == '/proc/sys/crypto/fips_enabled' else None

    # check if the fips_enabled file content is '1'
    fact_fips_collector._get_file_content = lambda x: '1'
    assert fact_fips_collector.collect() == {'fips': True}
    fact_fips_collector

# Generated at 2022-06-23 01:14:24.475767
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect(collected_facts=None) == {'fips': False}

# Generated at 2022-06-23 01:14:27.103228
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:14:29.638060
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:14:31.993834
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == "fips"

# Generated at 2022-06-23 01:14:34.981792
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected = {'fips': True}
    fips = FipsFactCollector()
    fips.collect()
    assert expected == fips.get_facts()
    assert dict == type(fips.get_facts())

# Generated at 2022-06-23 01:14:37.009833
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    pass

# Generated at 2022-06-23 01:14:39.081969
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 0

# Generated at 2022-06-23 01:14:40.966027
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    # check empty list of fact_ids
    assert(x.fact_ids == set())

# Generated at 2022-06-23 01:14:43.906787
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids

# Generated at 2022-06-23 01:14:46.431803
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'



# Generated at 2022-06-23 01:14:47.642708
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:14:49.281528
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'

# Generated at 2022-06-23 01:14:56.421384
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    file_content = '1'

    def getMockedFileContent(path):
        # Mock get_file_content, which loads in /proc/sys/crypto/fips_enabled
        # and returns "1" or "0", to use the string set above
        return file_content
    collector = FipsFactCollector()
    collector.get_file_content = getMockedFileContent
    fips_facts = collector.collect()

    assert fips_facts == {
        'fips': True
    }

# Generated at 2022-06-23 01:14:59.446808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test constructor of FipsFactCollector class"""
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:15:01.626753
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-23 01:15:04.008995
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert 'fips' in fips_collector._fact_ids

# Generated at 2022-06-23 01:15:05.558903
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector().collect()
    assert 'fips' in facts
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-23 01:15:07.755983
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m = FipsFactCollector()
    result = m.collect()
    assert isinstance(result, dict)
    assert 'fips' in result

# Generated at 2022-06-23 01:15:09.238035
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:15:14.622048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Read data from file
    def get_file_content_mock(path):
        content = b"1"
        return content
    # Use the module_utils instance
    setattr(FipsFactCollector, 'get_file_content', get_file_content_mock)
    fips_facts = FipsFactCollector()
    # When collect method is called, then get_file_content is called
    ret = fips_facts.collect()
    # Assert number of elements
    assert len(ret) == 1
    # Assert the key fips
    assert 'fips' in ret
    # Assert the value of the key fips
    assert ret['fips'] == True

# Generated at 2022-06-23 01:15:16.336880
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:15:18.738846
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:15:20.938363
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:15:24.066150
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_fact_ids = set(['fips'])
    actual_collector = FipsFactCollector()
    actual_fact_ids = actual_collector._fact_ids
    assert actual_fact_ids == expected_fact_ids

# Generated at 2022-06-23 01:15:26.296493
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:15:28.248511
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Testing constructor
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector.version is None

# Generated at 2022-06-23 01:15:30.428686
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-23 01:15:34.408880
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips']

# Generated at 2022-06-23 01:15:36.686800
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:15:39.222339
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts == {'fips': True}


# Generated at 2022-06-23 01:15:45.590376
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert type(FipsFactCollector(None, None)) == FipsFactCollector
    assert 'fips' in FipsFactCollector(None, None).collect()
    assert type(FipsFactCollector(None, None).collect()['fips']) is bool
    assert FipsFactCollector.name in FipsFactCollector(None, None).collect()

# Generated at 2022-06-23 01:15:54.205289
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips', \
        'did not get expected value from fips_facts.name'
    assert fips_facts.collector == 'FipsFactCollector', \
        'did not get expected value from fips_facts.collector'
    assert fips_facts._fact_ids == set(), \
        'did not get expected value from fips_facts._fact_ids'


# Generated at 2022-06-23 01:15:57.817358
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collection = FipsFactCollector()
    assert fips_collection.name == 'fips'

# Generated at 2022-06-23 01:16:00.053174
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:16:01.794581
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'


# Generated at 2022-06-23 01:16:03.843754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert not fips_facts['fips']

# Generated at 2022-06-23 01:16:14.630822
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup the module and facts class
    module = AnsibleModule(argument_spec={})
    # prepend an empty string to sys.path, so we can import the right fc_gather_kernel_facts module
    sys.path.insert(0, '')
    import fc_gather_kernel_facts
    # delete the empty string from sys.path, so no other module accidentally imports the wrong one
    del sys.path[0]
    fc_gather_kernel_facts.FactsCollector._get_file_content = get_file_content
    facts_collector = fc_gather_kernel_facts.FactsCollector()

    fips_fact_collector = FipsFactCollector()

    # Get results

# Generated at 2022-06-23 01:16:15.824261
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert set(FipsFactCollector(None, None)._fact_ids) == set(['fips'])

# Generated at 2022-06-23 01:16:18.798587
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:19.820179
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:16:23.384511
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips.collected_facts
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:16:25.276350
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:16:33.692367
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Arrange
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.utils import get_file_content

    module = None

    collected_facts = None

    fips_fact_collector = FipsFactCollector()

    data = to_bytes('1')

    # Act
    get_file_content_return = get_file_content('/proc/sys/crypto/fips_enabled')

    # Assert
    get_file_content.assert_called_once_with('/proc/sys/crypto/fips_enabled')
    assert get_file_content_return == data


# Generated at 2022-06-23 01:16:40.476357
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    assert Collector.get_fact_collector('fips')
    fips_facts_collector = Collector.get_fact_collector('fips')
    # create a fake module that has a method that returns expected data, for the method get_file_content()
    class FakeModule(object):
        def get_file_content(self, path):
            if path == '/proc/sys/crypto/fips_enabled':
                return '1'

    # fips_facts_collector.collect() returns a dict which can be asserted against
    fips_facts = fips_facts_collector.collect(FakeModule())

    assert fips_facts['fips']

# Generated at 2022-06-23 01:16:43.385780
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    c = FipsFactCollector()
    assert c.name == 'fips'
    assert c._fact_ids == set()
    assert c.collect(module=None, collected_facts=None)['fips'] == False

# Generated at 2022-06-23 01:16:46.084592
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:16:48.865131
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # try to execute the constructor of class FipsFactCollector
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:16:49.936607
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Constructor should not fail
    FipsFactCollector()

# Generated at 2022-06-23 01:16:55.563086
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m_get_file_content = FipsFactCollector.get_file_content
    FipsFactCollector.get_file_content = lambda self, x: '1'
    test = FipsFactCollector()
    assert test.collect() == {'fips': True}
    FipsFactCollector.get_file_content = m_get_file_content

# Generated at 2022-06-23 01:17:02.649371
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class ModuleMock:
        def __init__(self):
            self.params = {
                'module_setup.fips': {
                    'fips': False,
                },
            }

    class CollectedFactsMock:
        def __init__(self):
            self.fips = {
                'fips': False,
            }

    module_Mock = ModuleMock()
    collectedFactsMock = CollectedFactsMock()
    fips_FactCollector = FipsFactCollector(module_Mock, collectedFactsMock)

    def get_file_content_fips_setup(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return '0'

    fips_FactCollector.get_file_content = get

# Generated at 2022-06-23 01:17:03.761611
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector


# Generated at 2022-06-23 01:17:05.334694
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfact_collector = FipsFactCollector()
    assert fipsfact_collector is not None

# Generated at 2022-06-23 01:17:06.982210
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fs = FipsFactCollector()
    fs.collect()

# Generated at 2022-06-23 01:17:08.765461
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    result = test_obj.collect()
    assert type(result) is dict

# Generated at 2022-06-23 01:17:12.637549
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:15.660338
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:17:26.256127
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    FipsFactCollector.collect = FipsFactCollector._collect
    fc = FipsFactCollector()
    # test that collect returns a dict
    assert isinstance(fc.collect(),dict)
    Collector.get_file_content = lambda x: to_bytes('1')
    wrapped_false = True
    FipsFactCollector.collect = lambda x,y: {'fips':False}
    assert fc.collect() == {'fips':False}
    Collector.get_file_content = lambda x: to_bytes('0')
    assert fc.collect() == {'fips':False}
    Collector.get_file_content = lambda x: to_bytes('1')
   

# Generated at 2022-06-23 01:17:37.390910
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    # Test for a fips enabled system
    fips.read_file_content = lambda filename: "1"
    collected_facts = {}
    ansible_facts = fips.collect(collected_facts=collected_facts)
    assert ansible_facts['fips'] is True
    # Test for a fips disabled system
    fips.read_file_content = lambda filename: "0"
    ansible_facts = fips.collect(collected_facts=collected_facts)
    assert ansible_facts['fips'] is False
    # Test for an invalid file name
    fips.read_file_content = lambda filename: "not an existing file"
    ansible_facts = fips.collect(collected_facts=collected_facts)
    assert ansible_facts

# Generated at 2022-06-23 01:17:41.011188
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert isinstance(obj, FipsFactCollector)
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:17:43.273453
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:17:46.561377
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_collect = FipsFactCollector()
    assert FipsFactCollector_collect.collect() == {'fips': True}


# Generated at 2022-06-23 01:17:54.738243
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_contents = "1"
    module_mock = Mock(return_value=fips_contents)
    get_file_content_mock = Mock(side_effect=module_mock)

    fips_fact_collector = FipsFactCollector()
    with patch.object(fips_fact_collector, 'get_file_content', get_file_content_mock):
        fips_facts = fips_fact_collector.collect()

    assert fips_facts['fips'] == True

    get_file_content_mock.reset_mock()
    fips_contents = "0"
    module_mock = Mock(return_value=fips_contents)
    get_file_content_mock = Mock(side_effect=module_mock)

    f

# Generated at 2022-06-23 01:17:59.772492
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Unit test for constructor of class FipsFactCollector"""
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:18:00.832904
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()
    assert isinstance(fc.collect(), dict)

# Generated at 2022-06-23 01:18:05.362627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Call method collect of class FipsFactCollector
    fips = FipsFactCollector()
    fips_result = fips.collect()

    assert fips_result['fips'] == False
    assert 'fips' in fips_result

# Generated at 2022-06-23 01:18:08.472995
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    test_facts = collector.collect()
    print(test_facts)
    assert isinstance(test_facts, dict)
    if isinstance(test_facts, dict):
        assert 'fips' in test_facts

# Generated at 2022-06-23 01:18:09.361944
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:18:13.610132
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector._fact_ids


# Generated at 2022-06-23 01:18:17.192249
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    collected_facts = fips_fact_collector.collect(None, collected_facts)
    print(collected_facts)

# Generated at 2022-06-23 01:18:18.523053
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:18:27.532759
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Instance of class FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    # Assert name of FipsFactCollector class
    assert fips_fact_collector.name == 'fips'
    # Assert _fact_ids of FipsFactCollector class
    assert fips_fact_collector._fact_ids == set()
    # Assert collect() of FipsFactCollector class

# Generated at 2022-06-23 01:18:31.321165
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:18:34.671086
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    result = fips_facts.collect()
    assert result['fips'] is False

# Generated at 2022-06-23 01:18:37.658491
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()


# Generated at 2022-06-23 01:18:39.483843
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a FipsFactCollector object
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:18:47.673051
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Unit test for method collect of class FipsFactCollector
    # Checking if fips mode is detected when it is not enabled
    def test_fips_not_present_returns_false():
        fake_module = type('module', (object,), {})()
        fake_module.get_file_content = lambda x: '0'
        ff = FipsFactCollector()
        facts = ff.collect(module=fake_module)
        print(facts)
        assert facts == {'fips': False}

    # Unit test for method collect of class FipsFactCollector
    # Checking if fips mode is detected when it is not enabled
    def test_fips_present_returns_true():
        fake_module = type('module', (object,), {})()