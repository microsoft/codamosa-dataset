

# Generated at 2022-06-23 01:08:47.758775
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector_instance = FipsFactCollector()
    result = fips_collector_instance.collect(collected_facts={})
    assert result == {'fips': False}

# Generated at 2022-06-23 01:08:49.605633
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-23 01:08:54.033926
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == "fips"
    assert fips_facts._fact_ids == set()


# Generated at 2022-06-23 01:09:01.960272
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #Set the required variables for testing the method
    fips_file = '/proc/sys/crypto/fips_enabled'
    fips_file_content = '1'
    fips_fact_collector = FipsFactCollector()
    #The method collect should build the expected return value
    expected_result = {'fips': True}
    #mock the method get_file_content to return the file content
    fips_fact_collector._module.get_file_content = lambda x: fips_file_content
    #call the method and check if the result is the expected
    assert fips_fact_collector.collect() == expected_result

# Generated at 2022-06-23 01:09:04.616482
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:09.223092
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.__class__.name == 'fips'   # test name property

# Generated at 2022-06-23 01:09:13.602018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect(None, None)
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:09:18.090790
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-23 01:09:28.161397
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class MockFile(object):
        def __init__(self, name, content):
            self._name = name
            self._contents = content

        def read(self):
            return self._contents

        def __repr__(self):
            return self._name

    import os
    import tempfile

    f, path = tempfile.mkstemp()
    fd = os.fdopen(f, 'w')
    fd.write('1\n')
    fd.close()

# Generated at 2022-06-23 01:09:30.345433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FipsFactCollector

    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-23 01:09:36.717623
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollectorCache
    from os.path import isfile
    cache = FactCollectorCache()
    cache.collectors = []
    cache.collectors.append(FipsFactCollector())
    collected_facts = cache.collect(module=None)
    if not isfile('/proc/sys/crypto/fips_enabled'):
        assert collected_facts['fips'] == False
    else:
        with open('/proc/sys/crypto/fips_enabled', 'r+') as file:
            data = file.readlines()
            assert len(data) == 1
            if data[0] == '1':
                assert collected_facts['fips'] == True
            else:
                assert collected_facts['fips'] == False

# Generated at 2022-06-23 01:09:40.962180
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Init FipsFactCollector
    fips_collector_obj = FipsFactCollector()

    # Call the collect method
    retrieved_fips_facts = fips_collector_obj.collect()

    # Now check if the fips facts is false
    assert retrieved_fips_facts['fips'] == False

# Generated at 2022-06-23 01:09:47.661458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""
    import ansible.utils.template as template
    templar = template.Templar(loader=None)
    m = FipsFactCollector()
    d = m.collect()
    templar.template(d)
    # TODO: Add a proper unit test here
    # https://docs.ansible.com/ansible/dev_guide/testing_units.html#testing-units-modules

# Generated at 2022-06-23 01:09:48.979185
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    cf = FipsFactCollector()
    assert cf.collect() == {'fips': False}

# Generated at 2022-06-23 01:09:50.992958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create instance of FipsFactCollector and run collect()
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:09:51.602770
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:53.550303
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-23 01:09:56.991216
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert isinstance(obj, FipsFactCollector)
    assert isinstance(obj.name, str)
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-23 01:10:00.212611
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a FipsFactCollector object
    fips_collector_obj = FipsFactCollector()

    # Call method collect
    result = fips_collector_obj.collect()

    # Check that method collect returned a dict
    assert(isinstance(result, dict))
    assert('fips' in result)

# Generated at 2022-06-23 01:10:02.440939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    instance = FipsFactCollector()

    assert instance.collect() == {'fips': False}

# Generated at 2022-06-23 01:10:04.592246
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_collector = FipsFactCollector()
    my_facts = fips_collector.collect()

    assert my_facts['fips'] == False

# Generated at 2022-06-23 01:10:07.980832
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:10:10.188349
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:10:19.742746
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.sys_info.distribution.freebsd import FreeBsdDistribution
    from ansible.module_utils.facts.sys_info.distribution.redhat import RedHatDistribution
    from ansible.module_utils.facts.sys_info.distribution.sles import SuseDistribution
    from ansible.module_utils.facts.sys_info.distribution.ubuntu import UbuntuDistribution
    from ansible.module_utils.facts.sys_info.distribution.alpine import AlpineLinuxDistribution

    # mock /proc/sys/crypto/fips_enabled
    get_file_content_mock = lambda arg: arg.endswith

# Generated at 2022-06-23 01:10:22.335684
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class Module():
        def __init__(self):
            self.params = {}

    fips_collector = FipsFactCollector()
    result = fips_collector.collect(module=Module())
    assert 'fips' in result.keys()

# Generated at 2022-06-23 01:10:27.124653
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = {
        "/proc/sys/crypto/fips_enabled": "1"
    }

    fips_facts = FipsFactCollector()

    result = fips_facts.collect(collected_facts={}, module=MockModule(data=data))
    assert result['fips'] is True


# Generated at 2022-06-23 01:10:28.889604
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:10:40.093863
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    import os
    import tempfile

    test_file_content = '1'
    tf = tempfile.mktemp(dir=os.environ.get('HOME'), prefix='test_fips')
    f = open(tf, "w")
    f.write(test_file_content)
    f.close()

    ff = FipsFactCollector()
    fact = ff.collect(collected_facts={})
    assert fact['fips'] == True

    f = open(tf, "w")
    f.write('0')
    f.close()

    ff = FipsFactCollector()
    fact = ff.collect(collected_facts={})
    assert fact

# Generated at 2022-06-23 01:10:48.013928
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file_data = "1"
    fips_fact_collector = FipsFactCollector(module=None, collected_facts=None)
    # Mock the get_file_content method of fips_fact_collector with fips_file_data as the return value
    fips_fact_collector.get_file_content = lambda: fips_file_data
    # Testing collect method of FipsFactCollector class
    assert fips_fact_collector.collect() == {"fips": True}

# Generated at 2022-06-23 01:10:52.966048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    print("fips_fact_collector = ")
    print(fips_fact_collector)
    fips_facts = fips_fact_collector.collect()
    print("fips_facts = ")
    print(fips_facts)


# Generated at 2022-06-23 01:10:56.714497
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()

    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:10:59.887486
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:11:01.738501
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect()['fips']

# Generated at 2022-06-23 01:11:05.412581
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    verify that collect method populates the fips facts
    '''
    fips_module = FipsFactCollector()
    fips_facts = fips_module.collect()
    assert 'fips' in fips_facts

    # verify that 'fips' is populated as a string
    assert fips_facts['fips'] != None

# Generated at 2022-06-23 01:11:07.766593
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == {"fips"}

# Generated at 2022-06-23 01:11:10.727730
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Instantiate an instance of FipsFactCollector
    fips = FipsFactCollector()

    # Call collect method of FipsFactCollector
    fact = fips.collect()
    assert fact['fips'] == False

# Generated at 2022-06-23 01:11:12.947461
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:11:15.843754
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_info = FipsFactCollector()
    assert FipsFactCollector is not None

# Generated at 2022-06-23 01:11:17.615533
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsc = FipsFactCollector()
    facts = fipsc.collect()

# Generated at 2022-06-23 01:11:23.627440
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fixture = FipsFactCollector()
    assert isinstance(fixture, FipsFactCollector)
    assert fixture.name == 'fips'
    assert fixture._fact_ids == set()

    fixture = FipsFactCollector(name='fips')
    assert isinstance(fixture, FipsFactCollector)
    assert fixture.name == 'fips'
    assert fixture._fact_ids == set()

# Generated at 2022-06-23 01:11:27.072088
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfactcollector = FipsFactCollector()
    collected_facts = {}
    fipsfactcollector.collect(collected_facts=collected_facts)
    assert collected_facts['fips'] == False

# Generated at 2022-06-23 01:11:28.110922
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:30.674105
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:11:33.359219
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name=='fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:11:35.802556
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_obj = FipsFactCollector()
    assert my_obj.name == 'fips'
    assert my_obj._fact_ids == set()


# Generated at 2022-06-23 01:11:41.553227
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # In real life, this mock will be a call to the AnsibleModule,
    # and we will populate it with the parameters it needs to call the
    # system and return the facts.
    mock_module_args = {}
    test_fips_fact_collector = FipsFactCollector()
    fips_facts = test_fips_fact_collector.collect(mock_module_args, None)
    assert fips_facts == {'fips': False}

# Generated at 2022-06-23 01:11:42.411162
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector(None)


# Generated at 2022-06-23 01:11:44.117746
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert(fips_collector is not None)

# Generated at 2022-06-23 01:11:47.261517
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_facts = dict()
    fips_facts['fips'] = False
    fc = FipsFactCollector()
    assert fips_facts == fc.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-23 01:11:49.348376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:11:54.740230
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = Mock()
    collected_facts = Mock()
    fact = "fips_fact"
    collector = FipsFactCollector()
    assert collector.collect(module, collected_facts)[fact]

# Generated at 2022-06-23 01:11:56.907038
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert 'fips' in obj._fact_ids


# Generated at 2022-06-23 01:12:02.742256
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Unit test for the constructor of the class FipsFactCollector
    assert FipsFactCollector.name == 'fips'
    assert isinstance(FipsFactCollector._fact_ids, set)
    assert len(FipsFactCollector._fact_ids) == 0
    assert FipsFactCollector.collect.__doc__ == BaseFactCollector.collect.__doc__

# Generated at 2022-06-23 01:12:05.526269
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture = FipsFactCollector()

    fips_val = fixture.collect(collected_facts={})

    assert fips_val == {
        'fips': False
    }

# Generated at 2022-06-23 01:12:11.302666
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect()
    The FipsFactCollector.collect() should return a dict with key=value
    """
    # create a FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    # call the collect method
    fips_facts_dict = fips_fact_collector.collect()
    # check the returned dict
    assert fips_facts_dict == {'fips': False}

# Generated at 2022-06-23 01:12:13.761879
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector({}, None)
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:12:18.121618
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    '''Unit test for constructor of FipsFactCollector'''
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:12:20.977370
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj=FipsFactCollector()
    print(obj.name)

# Generated at 2022-06-23 01:12:23.799055
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:12:31.165907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    This method unit test the FipsFactCollector collect method.
    '''
    import os
    os.system('echo -n 1 > /proc/sys/crypto/fips_enabled')
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True
    os.system('echo -n 0 > /proc/sys/crypto/fips_enabled')
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:12:33.546770
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector(None)
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:12:37.468713
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-23 01:12:42.677081
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    fips_collector = FipsFactCollector()
    result = fips_collector.collect()
    if data == '1':
        assert result['fips']
    else:
        assert result['fips'] == False


# Generated at 2022-06-23 01:12:46.368546
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == "fips"
    assert fips._fact_ids == set()
    assert fips.collect(module=None, collected_facts=None) == {'fips': False}

# Generated at 2022-06-23 01:12:48.864106
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == "fips"
    assert isinstance(x.collect(), dict)

# Generated at 2022-06-23 01:12:52.304734
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    fips_fact = fips_fact_collector.collect()

    assert 'fips' in fips_fact
    assert isinstance(fips_fact['fips'], bool)

# Generated at 2022-06-23 01:12:54.408888
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    assert fips_collector.fact_ids == ['fips']

# Generated at 2022-06-23 01:12:56.649323
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    testobj = FipsFactCollector()
    fips_facts = testobj.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:12:57.764440
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-23 01:12:59.522825
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'


# Generated at 2022-06-23 01:13:03.460742
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    l_fips_fact = FipsFactCollector()
    test_fips_fact = l_fips_fact.collect()
    assert 'fips' in test_fips_fact
    assert test_fips_fact['fips'] == False

# Generated at 2022-06-23 01:13:04.388421
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:08.750475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    test_FipsFactCollector_collect
    """
    fips_collector = FipsFactCollector()
    fips_collector.collect(collected_facts=None)
    module = None
    assert not fips_collector.collect(module, collected_facts=None)['fips']

# Generated at 2022-06-23 01:13:10.937369
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:14.284994
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert len(fips_facts._fact_ids) == 0


# Generated at 2022-06-23 01:13:17.437636
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

    assert 'fips' in FactCollector.collected_facts

# Generated at 2022-06-23 01:13:19.739144
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:13:21.961314
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert 'fips' in fips._fact_ids

# Generated at 2022-06-23 01:13:25.249388
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector_class = FipsFactCollector
    fact_collector_instance = FipsFactCollector()
    assert fact_collector_class == fact_collector_instance.__class__

# Generated at 2022-06-23 01:13:31.434112
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    import os
    import tempfile

    # Create a fake file
    fd, name = tempfile.mkstemp()
    os.write(fd, b'1')
    os.close(fd)

    # Test
    ffc = FipsFactCollector()
    assert ffc.collect()['fips'] == True

    # Remove fake file
    os.remove(name)

# Generated at 2022-06-23 01:13:35.628080
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize instance of FipsFactCollector
    test_obj = FipsFactCollector()

    # Call method collect of FipsFactCollector class
    test_obj.collect()

    assert test_obj._fact_ids == set()

# Generated at 2022-06-23 01:13:37.764617
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:13:43.725091
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect({}, {})
    assert isinstance(result, dict), 'FipsFactCollector.collect must return a dict'
    assert 'fips' in result, 'FipsFactCollector.collect must return a dict containing "fips"'
    assert isinstance(result['fips'], bool), 'FipsFactCollector.collect must return a dict with "fips" a boolean'

# Generated at 2022-06-23 01:13:46.285158
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert 'fips' in facts

# Generated at 2022-06-23 01:13:47.783999
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    obj.collect()

# Generated at 2022-06-23 01:13:49.676667
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    fips_fc.collect()

# Generated at 2022-06-23 01:13:50.623600
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:13:52.482339
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}


# Generated at 2022-06-23 01:13:57.449153
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # GIVEN
    collector_mock = FipsFactCollector()

    # WHEN
    result = collector_mock.collect()

    # THEN
    assert result == {'fips': False}


# Generated at 2022-06-23 01:14:01.230357
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    # Expecting name to be fips
    assert obj.name == "fips"
    # Expecting fact_ids to be empty
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:14:03.531209
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc.collect() == dict(fips=False)

# Generated at 2022-06-23 01:14:04.331283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:14:09.317231
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = {}
    collected_facts['fips'] = False
    data = "1"
    # Return positive result
    assert collector.collect(collected_facts=collected_facts, data=data)
    assert collected_facts['fips'] == True

# Generated at 2022-06-23 01:14:14.508184
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Collect FIPS fact
    tco = FipsFactCollector()
    fips_facts = tco.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-23 01:14:19.069548
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fips_fact_collector_obj = FipsFactCollector()
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert fips_fact_collector_obj.name == 'fips'
    assert fips_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:14:23.353404
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test the constructor of the FipsFactCollector class"""
    # Instantiation of the class
    obj = FipsFactCollector()
    # Verification of the attributes
    assert obj.name == 'fips'
    assert obj.collect_methods == ['collect']
    assert obj.priority == 60

# Generated at 2022-06-23 01:14:32.905000
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # GIVEN a Fips fact collector
    fact_collector = FipsFactCollector
    fact_collector._fact_ids = set()
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    module_mock = None
    facts_mock = None
    # WHEN collecting facts
    fact_collector.collect(module_mock, facts_mock)
    # THEN the facts should be returned
    if data and data == '1':
        assert fact_collector._fact_ids.add("fips") == True
    else:
        assert fact_collector._fact_ids.add("fips") == False

# Generated at 2022-06-23 01:14:36.915140
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Check default values of _name and _fact_ids
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:14:40.066770
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Test 1: simple test to verify fips state
    result = fips_fact_collector.collect()

    assert result['fips'] is False or result['fips'] is True

# Generated at 2022-06-23 01:14:43.906561
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:14:47.893462
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create object of FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # Check for the instance of class FipsFactCollector

# Generated at 2022-06-23 01:14:51.244232
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert len(fips_facts) == 1
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:14:53.053156
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()


# Generated at 2022-06-23 01:15:03.387182
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import utils
    FipsFactCollector._get_file_content = utils.get_file_content
    input_data = b'1'
    output_data = {'fips': True}
    test_obj = FipsFactCollector()
    assert test_obj.collect() == output_data
    test_obj._get_file_content = lambda x: input_data
    assert test_obj.collect() == output_data
    input_data = b'0'
    output_data = {'fips': False}
    test_obj = FipsFactCollector()
    assert test_obj.collect() == output_data
    test_obj._get_file_content = lambda x: input_data
    assert test_obj.collect() == output_data

# Generated at 2022-06-23 01:15:06.617656
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '1')
    collected_facts = {}
    fips_collector = FipsFactCollector()

    fips_collector.collect(module=mock_module, collected_facts=collected_facts)

    assert collected_facts['fips'] is True

# Generated at 2022-06-23 01:15:09.184589
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:15:11.252641
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] is False

# Generated at 2022-06-23 01:15:13.558587
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert isinstance(FipsFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:15:16.464868
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = None
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] != None

# Generated at 2022-06-23 01:15:17.742928
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:15:21.506189
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector({})
    collected_facts = {}
    fips_facts = {'fips': False}
    collector.collect(collected_facts=collected_facts)
    assert (fips_facts['fips'] == collected_facts['fips'])

# Generated at 2022-06-23 01:15:24.557312
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector."""
    test_class_obj = FipsFactCollector()
    data = test_class_obj.collect(collected_facts={})
    assert data['fips'] == False

# Generated at 2022-06-23 01:15:27.428493
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    module = None
    collected_facts = dict()

    collector = FipsFactCollector(module=module, collected_facts=collected_facts)

    assert collector.collect() == {'fips':False}

# Generated at 2022-06-23 01:15:28.787866
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:15:31.541270
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # fips fact collector
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc.collect()

# Generated at 2022-06-23 01:15:35.792836
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == "fips"
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:15:37.776385
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Check if instances of FipsFactCollector can be created."""
    FipsFactCollector()

# Generated at 2022-06-23 01:15:39.918918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': True}

# Generated at 2022-06-23 01:15:49.191943
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class MockModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

# Generated at 2022-06-23 01:15:51.805711
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:15:54.408323
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:15:58.364001
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:04.219366
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids
    assert fips.collect.__module__ == 'ansible.module_utils.facts.system.fips'

# Generated at 2022-06-23 01:16:07.544889
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == "fips"
    assert fact._fact_ids == set()

# Generated at 2022-06-23 01:16:09.274678
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:16:11.083586
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:17.797819
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()
    assert f.collect(collected_facts={"fips": False}) == {'fips': True}
    assert f.collect(collected_facts={"fips": False}) == {'fips': False}
    assert f.collect(collected_facts={"fips": True}) == {'fips': False}

# Generated at 2022-06-23 01:16:21.673555
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:24.554959
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert 'fips' in result
    assert not result['fips']

# Generated at 2022-06-23 01:16:28.275592
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # initialize fips collector
    fips_collector = FipsFactCollector()
    fips_collector.collect()

    # verify collect function returns expected values
    assert fips_collector.name == 'fips'
    assert not fips_collector._fact_ids

# Generated at 2022-06-23 01:16:33.456836
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    # The set is empty if we try to access the value of the attribute
    assert len(fc._fact_ids) == 0
    # The set is populated once we try to collect data
    fc.collect()
    assert len(fc._fact_ids) == 1
    assert fc._fact_ids == set(['fips'])

# Generated at 2022-06-23 01:16:34.884678
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips' and f._fact_ids == set()

# Generated at 2022-06-23 01:16:36.586499
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

    # Unit test for 'name' of class FipsFactCollector
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:40.885125
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  fact_collector = FipsFactCollector()
  assert(fact_collector.name == "fips")


# Generated at 2022-06-23 01:16:51.964027
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create instance of FipsFactCollector
    fips_collector = FipsFactCollector()

    # Create a dictionary called result with the keys:
    # fips
    result = {'fips': False}

    # Create a dictionary called facts with the keys:
    # ansible_fips
    facts = {}

    # Call the method collect of FipsFactCollector with parameters module equal to None and
    # collected_facts equal to facts
    # Assign the value returned by the method collect of FipsFactCollector with parameters
    # module equal to None and collected_facts equal to facts to the variable fips_value
    fips_value = fips_collector.collect(module=None, collected_facts=None)

    # Compare fips_value and result, return True if they are equal and return False if they are not equal
   

# Generated at 2022-06-23 01:16:56.556717
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert isinstance(fips_fact_collector._fact_ids, set)
    assert not fips_fact_collector._fact_ids
    assert fips_fact_collector.collect() == {"fips" : False}

# Generated at 2022-06-23 01:17:00.104617
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

#Unit test for collect function of class FipsFactCollector

# Generated at 2022-06-23 01:17:07.722400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.tests.unit.module_utils.facts.test_utils import get_module
    module = get_module()
    # Mock the method get_file_content of class BaseFactCollector
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.BaseFactCollector.get_file_content = lambda self, file_name: "1"
    collector = FipsFactCollector(module=module)
    # Call the collect method of class FipsFactCollector
    result = collector.collect()
    # Check that the result is True
    assert result == {'fips': True}


# Generated at 2022-06-23 01:17:09.968271
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f.collect() == { 'fips': False }

# Generated at 2022-06-23 01:17:13.285773
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == {'fips'}
    assert f.collect()['fips'] == False

# Generated at 2022-06-23 01:17:14.260379
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:17:16.582741
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:17:27.111804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fs = {}
    fs['/proc/sys/crypto/fips_enabled'] = '1'
    ansible_module = Mock(filesystem=fs)
    fips_collector = FipsFactCollector(ansible_module)
    assert fips_collector.collect() == {'fips': True}
    fs['/proc/sys/crypto/fips_enabled'] = '0'
    fips_collector = FipsFactCollector(ansible_module)
    assert fips_collector.collect() == {'fips': False}
    fs['/proc/sys/crypto/fips_enabled'] = ''
    fips_collector = FipsFactCollector(ansible_module)
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:28.544458
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips


# Generated at 2022-06-23 01:17:32.738713
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup parameters
    module = None
    collected_facts = None

    # Execute the method under test
    x = FipsFactCollector()
    ans = x.collect(module, collected_facts)

    # Verify the results
    assert ans['fips'] == True

# Generated at 2022-06-23 01:17:34.521127
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'


# Generated at 2022-06-23 01:17:38.626826
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name is not None
    assert fips._fact_ids is not None
    fips_facts = fips.collect()
    assert fips_facts['fips'] is True or False

# Generated at 2022-06-23 01:17:43.256000
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    fips_facts = {'fips': True}
    fips_fact_collector = FipsFactCollector()
    # check if the collector returns expected result
    assert fips_fact_collector.collect() == fips_facts, \
        "FipsFactCollector.collect() returned unexpected result"

# Generated at 2022-06-23 01:17:52.153548
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector_instance
    module = basic.AnsibleModule(argument_spec={})
    module._debug = False
    module.exit_json = lambda: None
    fc = get_collector_instance("FipsFactCollector")
    fips_facts = fc.collect(module=module)
    assert fips_facts is not None
    assert 'fips' in fips_facts
    assert fips_facts['fips'] == False
    fc._tmpdir = to_bytes("/tmp/ansible_fips_test")
    fc.set_fs_attributes()

# Generated at 2022-06-23 01:17:54.793107
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    fipsFactCollector.collect()

# Generated at 2022-06-23 01:18:00.212325
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts_data = {
        "fips" : True,
        "foo":"bar"
    }
    assert collector.collect(collected_facts=facts_data) == {'fips': True}

# Generated at 2022-06-23 01:18:04.372657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = {}
    result = {}
    result['fips'] = False
    assert collector.collect(collected_facts) == result


# Generated at 2022-06-23 01:18:06.735699
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    res = fips_fact_collector.collect()
    assert('fips' in res)

# Generated at 2022-06-23 01:18:08.264425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector()
    assert facts.collect().get('fips') == False

# Generated at 2022-06-23 01:18:10.975911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ft = FipsFactCollector()
    result = ft.collect()
    expected = {'fips': False}
    assert result == expected, "Result is %s which is not as expected: %s" % (result, expected)

# Generated at 2022-06-23 01:18:17.285798
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def mock_get_file_content(path):
        return '1'

    module = AnsibleModule()
    fact_collector = FipsFactCollector()
    fact_collector.get_file_content = mock_get_file_content

    fips_facts = fact_collector.collect(module=module)
    assert fips_facts['fips'] == True



# Generated at 2022-06-23 01:18:19.242919
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert len(obj._fact_ids) == 0


# Generated at 2022-06-23 01:18:22.290329
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips not in fips._fact_ids
    assert isinstance(fips, FipsFactCollector)

# Generated at 2022-06-23 01:18:24.433509
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()



# Generated at 2022-06-23 01:18:31.370339
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' == fips_facts['ansible_facts']['fips']
    assert 'fips' in fips_facts['ansible_facts']

# Generated at 2022-06-23 01:18:32.831151
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # noinspection PyTypeChecker
    FipsFactCollector()

# Generated at 2022-06-23 01:18:35.589645
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    TestFipsFactCollector = FipsFactCollector()
    TestFipsFactCollector.collect()
    assert TestFipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:37.329547
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:18:39.483914
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:18:42.176951
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector() 
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:18:45.723380
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = True
    fips_fc = FipsFactCollector()
    assert (fips_fc.collect() == fips_facts)
    fips_facts['fips'] = False
    assert (fips_fc.collect() == fips_facts)