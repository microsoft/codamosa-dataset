

# Generated at 2022-06-23 01:08:47.758804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    result = FipsFactCollector_obj.collect()
    assert(result['fips'] == True)

# Generated at 2022-06-23 01:08:50.036019
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert not fips_fact_collector.collect()

# Generated at 2022-06-23 01:08:53.502540
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    o = FipsFactCollector()
    assert o.name == 'fips'


# Generated at 2022-06-23 01:08:54.545364
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:08:58.416336
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert isinstance(instance, FipsFactCollector)
    assert instance.name == 'fips'
    assert len(instance._fact_ids) == 1
    assert instance._fact_ids.pop() == 'fips'

# Generated at 2022-06-23 01:09:05.311172
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    in_mem_data = {}
    FipsFactCollector(in_mem_data=in_mem_data)
    print ("FipsFactCollector constructor test passes")


# Generated at 2022-06-23 01:09:10.335819
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print("Testing FipsFactCollector")
    fips_facts = FipsFactCollector().collect()
    print("Facts: %s" %(fips_facts))
    assert type(fips_facts) == dict
    assert type(fips_facts['fips']) == bool

if __name__ == '__main__':
    print("Testing FipsFactCollector")
    test_FipsFactCollector_collect()

# Generated at 2022-06-23 01:09:13.069274
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:09:16.553324
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test of method FipsFactCollector.collect."""
    params = dict()
    fips_fact_collector = FipsFactCollector()
    assert not fips_fact_collector.collect(params)

# Generated at 2022-06-23 01:09:17.818839
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:20.135939
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == {"fips"}

# Generated at 2022-06-23 01:09:22.237548
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:09:23.975963
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'


# Generated at 2022-06-23 01:09:25.068615
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector()

# Generated at 2022-06-23 01:09:26.913158
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFact = FipsFactCollector()
    fipsFact.collect()

# Generated at 2022-06-23 01:09:29.519231
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    data = fips_facts.collect()
    assert not data['fips'] or isinstance(data['fips'], bool)

# Generated at 2022-06-23 01:09:31.329605
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert len(fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:09:32.752529
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:39.531783
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector

    # setup test
    test_collector = FipsFactCollector()
    test_facts_dict = {}

    # run test
    result = test_collector.collect(collected_facts=test_facts_dict)
    assert result == 'fips' in test_facts_dict

# Generated at 2022-06-23 01:09:43.605355
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    result = fips_fact_collector.collect(module=None, collected_facts=collected_facts)
    assert result['fips'] is True or False

# Generated at 2022-06-23 01:09:46.345599
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert len(fips._fact_ids) == 0


# Generated at 2022-06-23 01:09:52.817048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector

    def mock_get_file_content(*args, **kwargs):
        return '1'

    def mock_get_file_content_fail(*args, **kwargs):
        raise Exception('exception during get_file_content')

    def mock_get_file_content_no_exist(*args, **kwargs):
        raise IOError('No such file or directory')

    get_file_content_original = get_file_content
    get_file_content.side_effect = mock_get_file_content
    args = {}
    F

# Generated at 2022-06-23 01:10:01.529248
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector

    def get_file_content_mock_return(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return None

    get_file_content_mock_original = get_file_content
    get_file_content.side_effect = get_file_content_mock_return

    fips_facts_collector = FipsFactCollector()
    fips_facts = fips_facts_collector.collect()
    assert fips_facts == {
        'fips': True
    }
    get_file_content = get_file_content_mock_original

# Generated at 2022-06-23 01:10:03.269927
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts["fips"] == False

# Generated at 2022-06-23 01:10:07.200159
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    args = {'module': None, 'collected_facts': None}
    f = FipsFactCollector()
    result = f.collect(**args)
    assert result['fips'] is True

# Generated at 2022-06-23 01:10:12.454991
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ unit testing for 'collect' method of class FipsFactCollector"""
    fact_collection = {'system': {'fips': True}}
    test_fact_collector = FipsFactCollector()
    assert test_fact_collector.collect(collected_facts=fact_collection) == {'fips': True}
    fact_collection = {'system': {'fips': False}}
    test_fact_collector = FipsFactCollector()
    assert test_fact_collector.collect(collected_facts=fact_collection) == {'fips': False}

# Generated at 2022-06-23 01:10:21.619276
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()

    # NOTE: mock up a module object
    class TestModule:
        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json')

    tm = TestModule()

    collected_facts = {}
    collected_facts['fips'] = False  # NOTE: See __init__ of BaseFactCollector

    # NOTE: mock up the _read_file() method
    def _read_file(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return None
    fc._read_file = _read_file

    from ansible.module_utils.facts.collector import BaseFactCollector
    # NOTE: mock up the read_file() method for BaseFactCollector and all its
    #      

# Generated at 2022-06-23 01:10:23.549986
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:10:26.697880
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_mock = FipsFactCollector()
    fips_mock.get_file_content = MagicMock(return_value='1')
    assert True == fips_mock.collect()['fips']

# Generated at 2022-06-23 01:10:29.672825
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:10:33.382991
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 1

# Generated at 2022-06-23 01:10:43.371477
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactManager

    # Create a fact manager
    fact_manager = FactManager(collected_facts=dict())
    # Create a FipsFactCollector
    collector = FipsFactCollector(manager=fact_manager)
    # Handle case that data is not present
    assert(collector.collect() == dict(fips=False))
    # Handle case that data is present
    # Use class Collector to handle fact being cached
    # We can't directly call its method collect
    # as it has different signature than FipsFactCollector
    # and it is not intended to be called from outside
    assert(Collector.collect(collector, collected_facts={'fips': False}) == dict(fips=True))

# Generated at 2022-06-23 01:10:47.111376
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert set(fips_collector._fact_ids) == set()


# Generated at 2022-06-23 01:10:49.564419
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector
    assert isinstance(collector, FipsFactCollector)

# Generated at 2022-06-23 01:10:54.050615
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    test_obj = FipsFactCollector()
    assert test_obj.name == 'fips'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-23 01:10:55.492479
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector is not None


# Generated at 2022-06-23 01:11:00.027140
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts['fips']


# Generated at 2022-06-23 01:11:01.867901
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:11:05.748661
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ff = FipsFactCollector()
    assert ff.name == 'fips'
    assert not ff._fact_ids
    assert ff.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:08.068196
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:11:09.865848
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
     fips_facts = FipsFactCollector()
     assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:11:20.455390
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Test with a fake file that has fips enabled
    collected_facts = { "ansible_pkg_mgr" : "yum" }
    module = MagicMock(params={"gather_subset": ['all']}, check_mode=False)
    facts = fips_fact_collector.collect(module, collected_facts)
    assert isinstance(facts, dict)
    assert facts['fips'] is True

    # Test with a fake file that has fips disabled
    collected_facts = { "ansible_pkg_mgr" : "yum" }
    module = MagicMock(params={"gather_subset": ['all']}, check_mode=False)
    fips_fact_collector._content = ""
    facts = fips_

# Generated at 2022-06-23 01:11:23.523918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert fips_facts
    assert fips_facts['fips'] is False

# Generated at 2022-06-23 01:11:25.407845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:11:27.116439
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.__class__.__name__ == "FipsFactCollector"

# Generated at 2022-06-23 01:11:32.207338
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    def get_file_content_mock(file_name):
        if file_name == '/proc/sys/crypto/fips_enabled':
            return '1'
    FipsFactCollector.get_file_content = get_file_content_mock
    assert FipsFactCollector.collect() == {'fips': True}


# Generated at 2022-06-23 01:11:35.580073
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected_fips_facts = {'fips': False}

    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == expected_fips_facts['fips']


# Generated at 2022-06-23 01:11:40.179478
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create an instance of FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # call method collect of class FipsFactCollector
    # with appropriate arguments
    fips_facts = FipsFactCollector.collect()

    # assert if the required value is received in the result
    assert fips_facts['fips'] == False


# Generated at 2022-06-23 01:11:43.049122
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert 'fips' in fips_facts._fact_ids

# Generated at 2022-06-23 01:11:44.339016
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'

# Generated at 2022-06-23 01:11:51.071624
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content, search_focus_data

    result = FipsFactCollector().collect()
    assert result == { "fips": False }
    with open('/proc/sys/crypto/fips_enabled','w') as f:
        f.write('1')
    result = FipsFactCollector().collect()
    assert result == { "fips": True }

# Generated at 2022-06-23 01:11:55.065900
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:11:58.056446
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:11:59.913955
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    # Module has been mocked for the test, and the rest of the class
    # does not have any useful methods.
    pass

# Generated at 2022-06-23 01:12:02.034801
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    o = FipsFactCollector()
    assert o.name == 'fips'
    assert not o._fact_ids

# Generated at 2022-06-23 01:12:04.365554
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:12:07.366626
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:12:08.466524
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:10.202857
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:12:12.370198
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert 'fips' == fips_collector.name

# Generated at 2022-06-23 01:12:15.051090
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {}
    collected_facts = fact_collector.collect(None, collected_facts)
    assert collected_facts['fips'] == False


# Generated at 2022-06-23 01:12:19.178875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts



# Generated at 2022-06-23 01:12:28.352863
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a FipsFactCollector instance and call collect
    fips_fc = FipsFactCollector()
    fips_facts = fips_fc.collect()
    # Check the result
    assert fips_facts is not None
    assert fips_facts['fips'] is False
    # Write the correct data
    with open('/proc/sys/crypto/fips_enabled', 'w') as fp:
        fp.write('1\n')
    # Call collect again
    fips_facts = fips_fc.collect()
    # Check the result again
    assert fips_facts is not None
    assert fips_facts['fips'] is True

# Generated at 2022-06-23 01:12:32.083806
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector_class = FipsFactCollector()
    assert(fips_collector_class.name == 'fips')
    assert(len(fips_collector_class._fact_ids) == 0)
    assert(fips_collector_class.collect().get('fips') == False)

# Generated at 2022-06-23 01:12:35.348906
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-23 01:12:38.117254
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert isinstance(obj._fact_ids, set) == True

# Generated at 2022-06-23 01:12:39.391474
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:47.233521
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    ffc = FipsFactCollector()

    # Create a dictionary to store the value of fips
    fips_facts = {}

    # Create an empty dictionary to hold the results
    collected_facts = {}

    # Call collect method of FipsFactCollector
    fips_facts = ffc.collect(collected_facts=collected_facts)

    # Assert that the result returned is correct
    assert fips_facts['fips'] == False or fips_facts['fips'] == True


# Generated at 2022-06-23 01:12:48.909824
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collect_fips_facts = FipsFactCollector()
    assert collect_fips_facts.collect()[0]['fips'] == False

# Generated at 2022-06-23 01:12:51.557158
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create instance of class FipsFactCollector
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:12:54.628553
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    a_FipsFactCollector = FipsFactCollector()
    assert hasattr(a_FipsFactCollector, 'name')
    assert a_FipsFactCollector.name == "fips"


# Generated at 2022-06-23 01:12:56.843193
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    fips_facts = fips_obj.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:13:00.304075
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:13:03.829916
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids is not None
    assert not ffc._fact_ids

test_FipsFactCollector()

# Generated at 2022-06-23 01:13:05.466130
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    result = FipsFactCollector()
    assert result != None
    assert result.name == 'fips'

# Generated at 2022-06-23 01:13:08.214627
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsCollector = FipsFactCollector()
    assert fipsCollector.name == 'fips'
    assert fipsCollector._fact_ids == set()

# Generated at 2022-06-23 01:13:10.727099
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:13:13.169679
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector_test_instance = FipsFactCollector()
    assert fips_fact_collector_test_instance is not None

# Generated at 2022-06-23 01:13:17.660444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    fips_facts = Collector().collect(['fips'])
    assert fips_facts['fips'] is False
    fips_fact = FipsFactCollector()
    fips_facts = fips_fact.collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-23 01:13:21.563986
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert isinstance(fips._fact_ids, set)
    assert fips._fact_ids == set()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:22.962808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fip = FipsFactCollector()
    assert fip.name == 'fips'

# Generated at 2022-06-23 01:13:25.076725
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:13:31.049597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    fact_collector = FipsFactCollector()

    # Call method collect of class FipsFactCollector with module as None
    fips_facts = fact_collector.collect(collected_facts=None)

    # Check if fips is false
    assert fips_facts['fips'] == "False"

# Generated at 2022-06-23 01:13:39.398657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('/proc/sys/crypto/fips_enabled', 'wb') as f:
        f.write(b'1')
        f.flush()
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == True
    with open('/proc/sys/crypto/fips_enabled', 'wb') as f:
        f.write(b'0')
        f.flush()
    assert fips.collect()['fips'] == False

# Generated at 2022-06-23 01:13:41.332358
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:43.297657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:13:50.404601
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()

    # No FIPS
    fips_facts = FipsFactCollector_obj.collect()
    assert fips_facts['fips'] == False

    # FIPS
    mock_content = {'get_file_content': lambda filename: '1'}
    fips_facts = FipsFactCollector_obj.collect(collected_facts=mock_content)
    assert fips_facts['fips'] == True


# Generated at 2022-06-23 01:13:53.056477
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    test_facts = {'fips': False}
    test_facts['fips'] = True
    assert c.collect() == test_facts

# Generated at 2022-06-23 01:14:05.182590
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Mock module_utils.facts.utils.get_file_content. The mock_module is
    # needed to get access to the global variables inside
    # ansible.module_utils.basic.AnsibleModule.
    # The get_file_content function is a closure, so it is not possible to
    # directly assign to the function variable.
    from ansible.module_utils.facts import utils
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(argument_spec={})

    # Mock dict to always return the same content
    data = '0'
    get_file_content_mock = {
        '/proc/sys/crypto/fips_enabled': data
    }

# Generated at 2022-06-23 01:14:08.710008
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Tests for collect()

# Generated at 2022-06-23 01:14:12.764335
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] == False

    return True

# Generated at 2022-06-23 01:14:14.490381
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-23 01:14:19.069638
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Calling with no data
    module = None
    collected_facts = {}
    ffc = FipsFactCollector()
    ffc.collect(module, collected_facts)

    fips = collected_facts['fips']

    # If true, the system is in fips mode
    assert(isinstance(fips, bool))

# Generated at 2022-06-23 01:14:21.846798
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = dict(fips=False)

    c = FipsFactCollector()
    data = c.collect()

    assert data == fips_facts

# Generated at 2022-06-23 01:14:23.615721
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    src = FipsFactCollector()
    facts = src.collect()
    assert facts['fips']

# Generated at 2022-06-23 01:14:24.982047
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:14:26.792883
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:14:29.738779
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

# Static function that returns the facts collected by a FipsFactCollector

# Generated at 2022-06-23 01:14:34.064206
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    Collector.get_file_content = get_file_content
    test_obj.collect()

# Generated at 2022-06-23 01:14:36.529649
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-23 01:14:37.483291
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector() is not None

# Generated at 2022-06-23 01:14:38.480513
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:14:40.423867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_ins = FipsFactCollector()
    assert FipsFactCollector_ins.collect() == {'fips': True}

# Generated at 2022-06-23 01:14:43.798759
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-23 01:14:47.756517
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector._fact_ids == set([])


# Generated at 2022-06-23 01:14:49.844559
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect(collected_facts=dict())["fips"] == False

# Generated at 2022-06-23 01:14:54.091864
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # test object creation
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, FipsFactCollector)
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:14:55.687474
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert(obj.name == 'fips')

# Generated at 2022-06-23 01:14:57.085351
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name
    assert FipsFactCollector._fact_ids

# Generated at 2022-06-23 01:14:59.703865
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'
    assert facts_collector._fact_ids == set()


# Generated at 2022-06-23 01:15:03.039448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = {}
    cfacts = {}
    fips = FipsFactCollector()
    result = fips.collect(module, cfacts)
    assert result is not None
    assert result['fips'] is not None

# Generated at 2022-06-23 01:15:05.082048
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:15:05.728622
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:15:07.478377
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert 'fips' in f._fact_ids

# Generated at 2022-06-23 01:15:18.311513
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with /proc/sys/crypto/fips_enabled which indicates not in fips mode
    fipsCollector = FipsFactCollector()
    data = "0"
    fipsCollector.get_file_content = lambda x: data
    results = fipsCollector.collect()
    
    if(results['fips'] != False):
        raise AssertionError("Incorrect value for fips")

    # Test with /proc/sys/crypto/fips_enabled which indicates in fips mode
    fipsCollector = FipsFactCollector()
    data = "1"
    fipsCollector.get_file_content = lambda x: data
    results = fipsCollector.collect()
    

# Generated at 2022-06-23 01:15:20.554352
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:15:25.327239
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_fips = True
    fips = FipsFactCollector()
    assert fips.name == 'fips', 'Expected Fips but got {0}'.format(fips.name)
    assert not fips._fact_ids, 'Expected empty _fact_ids'
    assert fips.collect()['fips'] == expected_fips, 'Expected Fips to be ' + str(expected_fips)

# Generated at 2022-06-23 01:15:35.640331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from types import MethodType
    import os
    import tempfile

    def mock_get_file_content(path):
        return '1'

    temp_file_path = os.path.join(tempfile.gettempdir(), "test_file")
    with open(temp_file_path, "w") as temp_file:
        temp_file.write('1')

    base_fact_collector = BaseFactCollector()

    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, BaseFactCollector)

# Generated at 2022-06-23 01:15:39.222227
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m = FipsFactCollector()
    output = m.collect()
    assert isinstance(output, dict)
    assert 'fips' in output
    assert isinstance(output['fips'], bool)


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 01:15:44.092143
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # construct FipsFactCollector object
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    assert isinstance(fips_fact_collector._fact_ids, set)
    assert fips_fact_collector.name == 'fips'



# Generated at 2022-06-23 01:15:52.722329
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create a FipsFactCollector object
    fips_collector = FipsFactCollector()

    # create facts
    facts = {
        'fips': False
    }

    # get the facts
    # as fips is not set, false should be returned
    new_facts = fips_collector.collect(collected_facts=facts)
    assert new_facts['fips'] is False

    # set the fips file to return a '1'
    fips_collector._get_file_content = lambda: '1'

    # get the facts again
    # as fips is now set, true should be returned
    new_facts = fips_collector.collect(collected_facts=new_facts)
    assert new_facts['fips'] is True

# Generated at 2022-06-23 01:16:01.024005
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector.fact_ids() == set()
    with open('tests/unit/module_utils/facts/files/fips_enabled') as f:
        fips_enabled_file_content = f.read()
    with open('tests/unit/module_utils/facts/files/empty_file') as f:
        empty_file_content = f.read()
    with open('tests/unit/module_utils/facts/files/fips_enabled', 'w') as f:
        f.write(fips_enabled_file_content)
    assert fact_collector.collect()['fips'] == True

# Generated at 2022-06-23 01:16:11.084347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class MockModule(object):
        pass

    class MockCollector(object):
        def __init__(self):
            self.entries = {}

        def collect(self, module=None, collected_facts=None):
            collected_facts = dict()
            collected_facts['test_somename'] = self.entries
            return collected_facts

    # Initialize mocks
    module = MockModule()
    collected_facts = dict()

    # Instantiate the FipsFactCollector class
    fips_fact_collector = FipsFactCollector()

    # Initialize the MockCollector
    mock_collector = MockCollector()

    # Assign a value to the mock_collector
    mock_collector.entries = 'fips=True'

    # Collect Fips facts
    result = fips_fact_

# Generated at 2022-06-23 01:16:15.436838
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    facts = fips_fact_collector.collect(collected_facts=collected_facts)
    assert facts['fips'] == False

# Generated at 2022-06-23 01:16:19.150863
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips.collect()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()
    assert fips.collect()['fips'] == False
    assert fips.collect()['fips'] == True

# Generated at 2022-06-23 01:16:21.738552
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector_obj = FipsFactCollector({})
    fact_collector_obj.collect()

# Generated at 2022-06-23 01:16:23.319681
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-23 01:16:26.277694
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector._fact_ids == set()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:28.396907
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None


# Generated at 2022-06-23 01:16:30.363563
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert type(fips_facts) == dict

# Generated at 2022-06-23 01:16:32.163938
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'

# Generated at 2022-06-23 01:16:35.223054
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsObj = FipsFactCollector()
    assert fipsObj.name == 'fips'
    assert fipsObj._fact_ids == set()


# Generated at 2022-06-23 01:16:38.063712
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    print('Starting test_FipsFactCollector')
    x = FipsFactCollector()
    if isinstance(x, FipsFactCollector) and hasattr(x,'name'):
        print('It was successfuly created')
    else:
        print('It was not created')


# Generated at 2022-06-23 01:16:43.703685
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Return fips fact that is being collected by FipsFactCollector class
    """
    fips_facts_collector = FipsFactCollector()
    fips_facts = fips_facts_collector.collect()
    facts_keys = set(fips_facts.keys())
    assert facts_keys == fips_facts_collector._fact_ids

# Generated at 2022-06-23 01:16:48.589386
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    expected = {'fips': False}
    collected_facts = {}
    result = collector.collect(collected_facts=collected_facts)
    assert expected == result
    #expected = set(['fips'])
    #assert expected == collector._fact_ids


# Generated at 2022-06-23 01:16:50.227880
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    results = ffc.collect()

    assert results['fips'] is True

# Generated at 2022-06-23 01:16:54.572453
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector(module=None, collected_facts={})
    fips_facts = fips_fact_collector.collect(module=None, collected_facts={})
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:16:59.847788
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # mock a FipsFactCollector object
    FipsFactCollector_obj = FipsFactCollector()
    # call method collect
    FipsFactCollector_obj.collect()

    # mock a FipsFactCollector object with fips_enabled
    FipsFactCollector_obj = FipsFactCollector()
    FipsFactCollector_obj.fips_enabled = True
    # call method collect
    FipsFactCollector_obj.collect()

# Generated at 2022-06-23 01:17:00.636803
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:17:11.116017
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    from ansible.module_utils.facts.utils import get_file_content

    class mock_module:
        def __init__(self):
            self.params = {}

    class mock_get_file_content_func:
        def __init__(self):
            self.count = 0

    def test_get_file_content_func(file):
        mock_get_file_content_func.count += 1
        if mock_get_file_content_func.count == 1:
            return '1'
        elif mock_get_file_content_func.count == 2:
            return '2'
        else:
            return

    saved_get_file_content = get_file_content
    get_file_content = test_get_file_content_func

    fips_obj = FipsFactCollector()

# Generated at 2022-06-23 01:17:13.865528
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:18.163296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = type('module', (object,), {'run_command': lambda _: b'0'})
    facts = FipsFactCollector().collect(module=mock_module)
    assert facts['fips'] is False

# Generated at 2022-06-23 01:17:20.773360
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:17:22.305077
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:17:24.155866
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:17:26.306289
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_fips_facts = {
        "fips": False
    }
    assert FipsFactCollector().collect() == expected_fips_facts

# Generated at 2022-06-23 01:17:28.410242
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)



# Generated at 2022-06-23 01:17:38.615436
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Prepare mock values
    get_file_content_return_value = '1'
    # If fips_enabled file exists and is equal to 1.
    fips_collector = FipsFactCollector()
    fips_collector.get_file_content = lambda x: get_file_content_return_value
    result = fips_collector.collect()
    assert result['fips']

    # If fips_enabled file does not exist.
    get_file_content_return_value = None
    result = fips_collector.collect()
    assert not result['fips']

    # If fips_enabled file is not equal to 1.
    get_file_content_return_value = '0'
    result = fips_collector.collect()
    assert not result['fips']

# Generated at 2022-06-23 01:17:40.349179
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector()._fact_ids == set()


# Generated at 2022-06-23 01:17:41.363339
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:17:42.406691
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:17:53.350125
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock

    import ansible.module_utils.facts.collectors.system.fips as fips

    # Instantiate a class object
    fips_fact_collector=fips.FipsFactCollector()

    # Read the json file in test/units/facts/files
    content = get_file_content('tests/unit/facts/files/fips_enabled')
    # mock lstat
    lstat_mock = mock.mock_open(read_data=content)
    lstat_mock.return_value.st_mode = 33204
    lstat_mock.return_value.st_size = 78
    lstat_mock.return_value.st_mtime = 1598767912.0



# Generated at 2022-06-23 01:17:57.357874
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    myCollector = FipsFactCollector()
    assert myCollector.collect().get('fips') is not None
# END Unit test for method collect of class FipsFactCollector

# Generated at 2022-06-23 01:18:03.402172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialization
    fips_fc = FipsFactCollector()
    # positive case
    # 1. non-empty file content
    ret = fips_fc.collect()
    assert(ret.get('fips') == True)
    # 2. empty file content
    fips_fc.get_file_content = lambda path: ''
    ret = fips_fc.collect()
    assert(ret.get('fips') == False)

# Generated at 2022-06-23 01:18:06.790840
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('/proc/sys/crypto/fips_enabled', 'w+') as file:
        file.write('1')
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts['fips'] == True

# Generated at 2022-06-23 01:18:08.432050
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    x = FipsFactCollector()
    assert(x.collect()['fips'] == False)

# Generated at 2022-06-23 01:18:13.278472
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None,\
        "Failed to create an instance of FipsFactCollector"
    assert fips_fact_collector.name == "fips",\
        "Failed to set correct name for FipsFactCollector"
    assert fips_fact_collector._fact_ids == set(),\
        "Failed to set _fact_ids as empty set for FipsFactCollector"

# Generated at 2022-06-23 01:18:22.795934
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = {}

    # NOTE: If a test is failing, you need to enable:
    # /proc/sys/crypto/fips_enabled

    # Test when crypto/fips_enabled does not exist
    collected_facts = collector.collect()
    assert collected_facts['fips'] is False

    # Test when crypto/fips_enabled exists and is not set
    get_file_content = lambda file: '0'
    collected_facts = collector.collect()
    assert collected_facts['fips'] is False

    # Test when crypto/fips_enabled exists and is set
    get_file_content = lambda file: '1'
    collected_facts = collector.collect()
    assert collected_facts['fips'] is True

# Generated at 2022-06-23 01:18:28.262974
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    data = fips_collector.collect()
    assert isinstance(data['fips'], bool)

# Generated at 2022-06-23 01:18:31.824453
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    expected_result = {'fips': True}
    result = fips_fact_collector.collect()
    assert result == expected_result

# Generated at 2022-06-23 01:18:41.895129
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils._text import to_bytes

    # Fake module
    module = type('', (), {})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Fake collected_facts
    collected_facts = {}

    # Mock the get_file_content method
    with patch.multiple(
        'ansible.module_utils.facts.utils',
        get_file_content=MagicMock(side_effect=['1', '0', '', None])
    ):
        # Create an instance of the FipsFactCollector class
        ffc = FipsFactCollector()

        # Create a facts with fips=True
        fips_facts = {'fips': True}

        # Test collect with /proc/sys/crypto/fips_enabled content is '1'

# Generated at 2022-06-23 01:18:43.738112
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}