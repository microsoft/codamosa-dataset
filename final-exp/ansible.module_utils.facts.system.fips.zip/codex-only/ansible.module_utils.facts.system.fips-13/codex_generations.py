

# Generated at 2022-06-23 01:08:46.702584
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfact_collector_obj = FipsFactCollector()
    assert fipsfact_collector_obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:08:50.030501
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert hasattr(FipsFactCollector, '_fact_ids')
    assert hasattr(FipsFactCollector, 'collect')
    assert hasattr(FipsFactCollector, 'name')

# Generated at 2022-06-23 01:08:51.990588
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert True

# Generated at 2022-06-23 01:09:00.979500
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            test_binaries = {
                'cat': 'cat',
            }

        def run_command(self, *args, **kwargs):
            return 0, None, None

    collector.get_file_content = get_file_content
    collector.BaseFactCollector.get_bin_path = BaseFactCollector.get_bin_path
    module = basic.Ans

# Generated at 2022-06-23 01:09:03.647209
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:09:06.879335
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_fips_fact_collector = FipsFactCollector()
    collected_facts = test_fips_fact_collector.collect()
    assert collected_facts.get('fips') is not None

# Generated at 2022-06-23 01:09:14.710615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # It should work fine if the file exists and its contents are correct.
    loaded_facts = collector.collect(collected_facts={})
    assert collected_facts == { 'fips': True }
    # If the file does not exist, it should return this.
    loaded_facts = collector.collect(collected_facts={})
    assert collected_facts == { 'fips': False }

# Generated at 2022-06-23 01:09:17.686847
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:20.404318
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    returned_facts = ffc.collect()
    assert isinstance(returned_facts, dict)
    assert returned_facts['fips'] == False

# Generated at 2022-06-23 01:09:23.235502
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:26.912660
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    for key in ('fips',):
        assert key in fips_facts

# Generated at 2022-06-23 01:09:29.142239
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:09:33.263500
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts_dict = fips_collector.collect()
    assert isinstance(facts_dict, dict), 'Fips collector did not return a dictionary'
    assert 'fips' in facts_dict, 'Fips collector did not return key fips'
    assert facts_dict['fips'] == False, 'Fips collector did not return False'

# Generated at 2022-06-23 01:09:35.536411
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfact_collector = FipsFactCollector()
    assert fipsfact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:09:38.911779
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert isinstance(fc._fact_ids, set)


# Generated at 2022-06-23 01:09:41.735896
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids is not None
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:09:44.809079
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    res = fact_collector.collect()
    assert res['fips'] == False
    assert '_fact_ids' in res

# Generated at 2022-06-23 01:09:50.788908
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_module = type('module', (object,), {'params': {}})
    fips_facts = FipsFactCollector(fips_module)

    assert type(fips_facts) == FipsFactCollector
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()
    assert hasattr(fips_facts, 'collect')
    assert callable(fips_facts.collect)

# Generated at 2022-06-23 01:09:51.801825
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:09:52.984471
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:55.387848
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == "fips"
    assert str(type(collector._fact_ids)) == "<type 'set'>"

# Generated at 2022-06-23 01:09:58.822290
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect = lambda: {
        'fips': True
    }
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] is True

# Generated at 2022-06-23 01:10:00.172435
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    testobj = FipsFactCollector()
    assert testobj.name == 'fips'


# Generated at 2022-06-23 01:10:01.126031
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    x = FipsFactCollector()
    assert x

# Generated at 2022-06-23 01:10:04.591489
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:10:05.994727
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == { 'fips' : False }


# Generated at 2022-06-23 01:10:08.612088
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    #assert 'fips' in fips_facts.collect()
# test_FipsFactCollector()

# Generated at 2022-06-23 01:10:09.230346
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:10:10.879506
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:10:12.215384
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:10:18.318309
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    # This is what is returned if /proc/sys/crypto/fips_enabled contents are empty
    assert fact_collector.collect() == fips_facts
    # This is what is returned if /proc/sys/crypto/fips_enabled contents are '1'
    assert fact_collector.collect(collected_facts={'fips_enabled': '1'}) == {'fips': True}

# Generated at 2022-06-23 01:10:20.524391
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:10:21.659521
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:10:23.843410
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest

    m_open = mock_open(read_data='1')
    mock_open.return_value = m_open

    with pytest.raises(IOError):
        f = FipsFactCollector()
        f.collect()

# Generated at 2022-06-23 01:10:25.780143
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:10:35.019128
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    ansible_module = basic.AnsibleModule(argument_spec={})
    ansible_module._load_params()
    facts_collector = collector.get_collector(ansible_module)
    collector = FipsFactCollector(ansible_module)
    facts_collector.collect(collector)
    fact = ansible_module.exit_json()

    assert 'fips' in fact['ansible_facts']
    assert 'fips' in fact['ansible_facts']['fips']

# Generated at 2022-06-23 01:10:36.707195
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    a = FipsFactCollector()
    assert a.collect() == {u'fips': False}

# Generated at 2022-06-23 01:10:45.682141
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Instead of mocking the collect method call, the mock is set on the called
    # method get_file_content
    class MockFipsFactCollector(FipsFactCollector):
        def __init__(self, *args):
            pass

    mock_file_content = '1'
    facts = {}
    mock_collector = MockFipsFactCollector()
    old_get_file_content = get_file_content
    get_file_content = lambda x: mock_file_content
    fips_facts = mock_collector.collect(collected_facts=facts)
    assert fips_facts['fips'] is True
    mock_file_content = '0'
    fips_facts = mock_collector.collect(collected_facts=facts)
    assert fips_facts['fips'] is False
   

# Generated at 2022-06-23 01:10:47.169572
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_factCollector = FipsFactCollector()
    assert isinstance(fips_factCollector, FipsFactCollector)


# Generated at 2022-06-23 01:10:50.893132
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert isinstance(fact_collector, FipsFactCollector)
    assert fact_collector.name == 'fips'
    assert len(fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:10:53.112259
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips': True}

# Generated at 2022-06-23 01:10:55.869544
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_facts = FipsFactCollector_obj.collect()
    assert fips_facts['fips'] == False or fips_facts['fips'] == True

# Generated at 2022-06-23 01:10:59.944820
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:11:02.304490
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:06.198275
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    settings = {'gather_subset': ['all']}
    collector = FipsFactCollector(settings)
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:11:09.331498
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_constructed = FipsFactCollector()
    assert fips_constructed.name == 'fips'
    assert fips_constructed._fact_ids == {'fips'}


# Generated at 2022-06-23 01:11:11.098748
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:11:13.784705
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_module = FipsFactCollector()
    assert fips_module.name == 'fips'


# Generated at 2022-06-23 01:11:14.764483
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:11:17.065127
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:11:20.195934
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_fact = fips.collect()
    assert fips_fact['fips'] is True or fips_fact['fips'] is False

# Generated at 2022-06-23 01:11:22.088499
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector is not None


# Generated at 2022-06-23 01:11:24.788913
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None


# Generated at 2022-06-23 01:11:27.462932
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:11:36.101182
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector._module = MockModule()
    fips_collector._module.params = {}
    fips_collector._file_exists = lambda f: True
    fips_collector._get_file_content = lambda f: '1'
    assert fips_collector.collect() == {
        'fips': True
    }
    fips_collector._file_exists = lambda f: False
    assert fips_collector.collect() == {
        'fips': False
    }


# Generated at 2022-06-23 01:11:42.637584
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    data = '1\n'
    fips_obj.set_fs_content({'proc/sys/crypto/fips_enabled': data})
    assert not fips_obj.retrieve()['fips']

    fips_obj = FipsFactCollector()
    data = '1'
    fips_obj.set_fs_content({'proc/sys/crypto/fips_enabled': data})
    assert fips_obj.retrieve()['fips']

# Generated at 2022-06-23 01:11:44.703522
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:11:46.051360
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips', 'name should be fips'

# Generated at 2022-06-23 01:11:48.072690
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert instance.name == 'fips'
    assert instance._fact_ids == set()



# Generated at 2022-06-23 01:11:54.163128
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collection import FactsCollectionManager
    from ansible.module_utils.facts.collectors.generic.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(file):
        if file == "/proc/sys/crypto/fips_enabled" :
            return "1"
        raise IOError()

    def mock_FactsCollectionManager():
        return dict()

    get_file_content = mock_get_file_content
    FactsCollectionManager = mock_FactsCollectionManager
    fips_col = FipsFactCollector()
    res = fips_col.collect()
    assert res == {u'fips': True}


# Generated at 2022-06-23 01:11:57.613297
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModuleStub()
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect(module=module)
    assert result is not None

# Unit test AnsibleModule class

# Generated at 2022-06-23 01:12:02.441095
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector_obj = FipsFactCollector()
    assert fips_fact_collector_obj.name == 'fips'
    # assert fips_fact_collector_obj._fact_ids == set()
    assert fips_fact_collector_obj.collect()['fips'] == False

# Generated at 2022-06-23 01:12:05.989074
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact.__doc__ is not None
    assert fips_fact.__doc__ != ''


# Generated at 2022-06-23 01:12:08.665823
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] is False

# Generated at 2022-06-23 01:12:11.903775
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create an instance of FipsFactCollector and call collect
    ff = FipsFactCollector()
    f_facts = ff.collect()
    assert f_facts is not None
    assert f_facts['fips'] is False

# Generated at 2022-06-23 01:12:17.349676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''

    # Test case when fips_enabled is 1
    test_module = mock.Mock()
    test_collector = FipsFactCollector(test_module)
    test_module.get_file_content.return_value = "1"

    results = test_collector.collect()
    assert results['fips'] is True

    # Test case when fips_enabled is 0
    test_module.get_file_content.return_value = "0"
    results = test_collector.collect()
    assert results['fips'] is False

# Generated at 2022-06-23 01:12:18.844406
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:12:29.819841
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # I need to mock module.run_command, but this is not possible in the method
    # run_command of the module helper, because it is a method of a module object,
    # not a class object.
    # As a workaround I create a new class with the method I want to mock.

    class myModule(object):
        def run_command(self, cmd):
            return cmd

    # I expect a mocked version of the module with run_command method
    # I expect a dictionary with the result of the read of /proc/sys/crypto/fips_enabled
    # with content '1' and the key fips_fact with value 'true'
    fips_enabled = FipsFactCollector()
    result = fips_enabled.collect(myModule(), {})
    assert result == {'fips': True}

# Unit test

# Generated at 2022-06-23 01:12:30.805907
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:31.644854
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:12:34.575141
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    C = FipsFactCollector()
    collected_facts = dict()
    facts = C.collect(module=None, collected_facts=collected_facts)
    assert isinstance(facts, dict)
    assert 'fips' in facts
    assert facts['fips'] == False

# Generated at 2022-06-23 01:12:41.237308
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    data = '1'
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == True

# Unit test to check FipsFactCollector class attributes

# Generated at 2022-06-23 01:12:44.062672
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfc = FipsFactCollector()
    assert fipsfc.name == 'fips'
    assert fipsfc._fact_ids == set()


# Generated at 2022-06-23 01:12:46.690388
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-23 01:12:49.885810
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] == False

# vim:expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-23 01:12:50.826526
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:53.506669
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {
        'fips': False
    }

# Generated at 2022-06-23 01:12:54.524405
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:12:57.051581
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:12:59.783732
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()

    # For now, just test it doesn't raise an exception
    fips.collect()

# Generated at 2022-06-23 01:13:05.511072
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fake_content = '1\n'
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module = None
    fips_fact_collector._collected_facts = None
    fips_fact_collector._get_file_content = lambda path: fake_content
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:13:07.038350
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:13:10.397331
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector
    assert fips_collector.name == 'fips'
    assert len(fips_collector._fact_ids) == 0


# Generated at 2022-06-23 01:13:11.368819
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:14.257304
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:13:16.704668
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc.priority == 50

# Generated at 2022-06-23 01:13:20.211808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips', \
        "Fips fact collector name is wrong"
    assert type(fips_fact_collector._fact_ids) == set, \
        "Fips fact collector '_fact_ids' is not a set"

# Generated at 2022-06-23 01:13:22.335207
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    global FipsFactCollector
    fact_collector_class = FipsFactCollector()
    assert fact_collector_class.name == 'fips'
    assert fact_collector_class._fact_ids == set()

# Generated at 2022-06-23 01:13:25.640531
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:13:28.433362
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collect_obj = FipsFactCollector()
    assert collect_obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:13:31.717752
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert isinstance(instance, FipsFactCollector)
    assert instance.name == 'fips'
    assert instance.facts == {'fips': '', }



# Generated at 2022-06-23 01:13:40.150883
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Check that fact about system fips is returned with expected value"""
    def open_mock(self, filename, *args, **kwargs):
        if filename == '/proc/sys/crypto/fips_enabled':
            return [b'1']
    FipsFactCollector._open = open_mock

    fips_collector = FipsFactCollector()
    result = fips_collector.collect()

    assert result
    assert 'fips' in result
    assert result['fips'] == True

# Generated at 2022-06-23 01:13:50.356444
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test for FipsFactCollector when fips is enabled
    my_obj = FipsFactCollector()
    assert my_obj.name == 'fips'
    assert my_obj._fact_ids == set()
    assert my_obj.collect(module = None, collected_facts = {'fips' : True}) == {'fips' : True}
    # Test for FipsFactCollector when fips is not enabled
    my_obj1 = FipsFactCollector()
    assert my_obj1.name == 'fips'
    assert my_obj1._fact_ids == set()
    assert my_obj1.collect(module = None, collected_facts = {'fips' : False}) == {'fips' : False}

# Generated at 2022-06-23 01:13:53.927105
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect(module=module, collected_facts=collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:13:57.520807
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfc = FipsFactCollector()
    result = fipsfc.collect(collected_facts={})
    assert result.get('fips') == False

# Generated at 2022-06-23 01:14:00.900963
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector._fact_ids == set()
    assert not fips_fact_collector.collect()

# Generated at 2022-06-23 01:14:07.200849
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content_mock(filename):
        assert filename == '/proc/sys/crypto/fips_enabled'
        return '1'

    collector = FipsFactCollector()
    assert collector.collect(get_file_content=get_file_content_mock) == {'fips': True}

    collector = FipsFactCollector()
    assert collector.collect(get_file_content=None) == {'fips': False}

# Generated at 2022-06-23 01:14:08.639185
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:14:16.783590
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.utils import set_module_args
    set_module_args({})
    fips_facts = collector_registry['fips'].collector.collect()['fips']
    facts = Facts()
    facts_dict = facts.get_facts()
    assert fips_facts == facts_dict['fips']


# Generated at 2022-06-23 01:14:21.208798
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:14:23.700416
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips_result = fips_fact.collect()
    assert fips_result['fips'] == False

# Generated at 2022-06-23 01:14:33.638921
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Test FipsFactCollector.collect by generating test data and checking if the
    collector returns what is expected
    '''

    fips_fact_collector = FipsFactCollector('/proc/sys/crypto/fips_enabled',
                                            'fips')

    fips_fact_collector.files['/proc/sys/crypto/fips_enabled'] = '0'
    assert fips_fact_collector.collect() == {'fips': False}

    fips_fact_collector.files['/proc/sys/crypto/fips_enabled'] = '1'
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:14:36.092452
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    o = FipsFactCollector()
    assert o._fact_ids == set()
    assert o.name == 'fips'

# Generated at 2022-06-23 01:14:39.317325
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    # validate that a fips fact was added to fact ids
    assert 'fips' in fips_fact_collector._fact_ids

# Generated at 2022-06-23 01:14:51.461918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from os.path import join
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    mock_open = join('ansible', 'module_utils', 'facts', 'collector', 'fips.py')
    mock_open_data = join('ansible', 'module_utils', 'facts', 'collector', 'fips')
    with open(mock_open) as f:
        content = f.read()
    if b'Fuction test' not in content:
        content += '\n# Fuction test'
        content += '\nfrom os.path import join'

# Generated at 2022-06-23 01:14:53.747781
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}


# Generated at 2022-06-23 01:14:56.586764
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts.get('fips') is not None

# Generated at 2022-06-23 01:15:01.970612
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # setup
    import ansible.module_utils.facts.collectors.fips as fips_collector
    fips_collector.get_file_content = lambda x: '1'
    test_object = fips_collector.FipsFactCollector()
    # exercise
    result = test_object.collect()
    # verify
    assert result.get('fips', None) is True


# Generated at 2022-06-23 01:15:03.130940
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name is not None

# Generated at 2022-06-23 01:15:04.451111
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert(obj.name == 'fips')

# Generated at 2022-06-23 01:15:06.901245
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:15:09.993592
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Fips is a module designed to check if a system is in 'fips' mode.
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:15:16.697186
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()

    # Mock module
    module = type('module', tuple(), {})()

    # Mock file content
    content = '1'

    # Mock get_file_content
    fips_collector.get_file_content = type('file_content', tuple(), {})
    fips_collector.get_file_content.return_value = content

    assert fips_collector.collect(module=module) == {"fips": True}

# Generated at 2022-06-23 01:15:18.640949
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

# Generated at 2022-06-23 01:15:28.087699
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False

    data = "/proc/sys/crypto/fips_enabled"
    content = '1'

    def mock_get_file_content(file):
        if file == data:
            return content
        else:
            return ""

    import __builtin__
    if not hasattr(__builtin__, '__original_open'):
        __builtin__.__original_open = __builtin__.open

    def mock_open(*args, **kwargs):
        fd = __builtin__.__original_open(data, *args, **kwargs)
        return fd

    __builtin__.open = mock_open
    __builtin__.get_file_content

# Generated at 2022-06-23 01:15:31.300497
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector_obj = FipsFactCollector()
    assert fips_collector_obj.name == 'fips'
    assert fips_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:15:36.428266
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Generate a test case to test the constructor of class FipsFactCollector
    """
    collect = FipsFactCollector(None)
    assert collect.name == 'fips'
    assert set() == collect._fact_ids

# Generated at 2022-06-23 01:15:40.880777
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 0
    assert FipsFactCollector.collect() == {'fips': False}
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:15:43.668446
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect({}, {})

    assert fips_facts['fips'] is True


# Generated at 2022-06-23 01:15:46.060632
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:15:51.264691
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test the collect function of FipsFactCollector
    """

    # Create a instance of the FipsFactCollector class
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:15:54.970376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    test_collect = fips_fact_collector.collect(None, None)
    assert test_collect == {'fips': False}

# Generated at 2022-06-23 01:15:59.045489
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:16:01.918564
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:16:09.403161
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = '1'
    set_module_args(dict(
        content=data
    ))
    module = AnsibleModule(
        argument_spec=module.argument_spec,
        supports_check_mode=module.supports_check_mode,
        add_file_common_args=False,
    )

    fips_collected_facts = dict(
        fips=True
    )
    result = dict(
        changed=True
    )

    fipscollector = FipsFactCollector()
    facts = fipscollector.collect(module)
    assert facts == fips_collected_facts

# Generated at 2022-06-23 01:16:10.439603
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()

# Generated at 2022-06-23 01:16:12.402026
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj is not None

# Generated at 2022-06-23 01:16:15.334692
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector
    assert fips_fc.name == 'fips'
    assert fips_fc.collect()['fips'] == False

# Generated at 2022-06-23 01:16:18.595415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {'ansible_module_mock': True}
    fips_facts = fact_collector.collect(collected_facts=collected_facts)
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:16:21.622201
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.__class__.__name__ == 'FipsFactCollector'


# Generated at 2022-06-23 01:16:24.520399
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert('fips' in result)

# Generated at 2022-06-23 01:16:30.001174
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Given an instance of FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    # When I call method collect
    fips_facts = fips_fact_collector.collect()
    # Then facts should be equal to expected output
    assert fips_facts == {'fips': False}

test_FipsFactCollector_collect()

# vim: expandtab filetype=python

# Generated at 2022-06-23 01:16:33.443690
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert len(fc._fact_ids) == 0
    assert fc.collect(collected_facts=dict())['fips'] == False

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-23 01:16:35.064167
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:16:35.560467
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:16:37.536524
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids is not None

# Generated at 2022-06-23 01:16:39.339880
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:16:42.004583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector(None)
    assert fact_collector.collect() == {"fips": True}

# Generated at 2022-06-23 01:16:45.663920
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:16:49.943449
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    myObj = FipsFactCollector()

    assert hasattr(myObj, 'name')
    assert hasattr(myObj, '_fact_ids')
    assert isinstance(myObj.name, str)
    assert isinstance(myObj._fact_ids, set)
    assert myObj.name == 'fips'


# Generated at 2022-06-23 01:16:56.238664
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()

    #test with /proc/sys/crypto/fips_enabled content
    ffc.get_file_content = lambda path: "1"
    assert ffc.collect() == {'fips': True}

    #test without /proc/sys/crypto/fips_enabled content
    ffc.get_file_content = lambda path: None
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:56.952461
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:16:59.503314
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"


# Generated at 2022-06-23 01:17:00.608277
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fi

# Generated at 2022-06-23 01:17:04.365582
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:06.745261
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert instance.name == 'fips'
    assert instance._fact_ids == set()

# Generated at 2022-06-23 01:17:07.770203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:17:12.827592
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Given FipsFactCollector object
    fips_collector = FipsFactCollector()

    # When execute method collect
    result = fips_collector.collect()

    # Then result is a dict
    assert isinstance(result, dict)
    # And dict contains fips key
    assert result.has_key('fips')

# Generated at 2022-06-23 01:17:15.433070
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == "fips"
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:17:18.137609
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:17:18.756679
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert(True)

# Generated at 2022-06-23 01:17:22.195973
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:17:28.653290
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  import sys
  from ansible.module_utils.facts.collector import BaseFactCollector
  from ansible.module_utils.facts.utils import get_file_content
  _collector = FipsFactCollector("fips", set())
  assert isinstance(_collector, FipsFactCollector)
  assert isinstance(_collector, BaseFactCollector)
  assert _collector.name == "fips"
  assert _collector._fact_ids == set()
  assert _collector.collect() == {'fips':False}


# Generated at 2022-06-23 01:17:31.750037
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()
    assert obj.collect() == { 'fips': False }

# Generated at 2022-06-23 01:17:33.031264
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-23 01:17:35.926192
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'

# Generated at 2022-06-23 01:17:39.038574
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:49.111376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize the FipsCollector Class
    fips_collector_obj = FipsFactCollector()

    # Write a sample data for fips
    fips_file = '/proc/sys/crypto/fips_enabled'
    f = open(fips_file, "w")
    f.write('0')
    f.close()
    # Initialize the class variables
    fips_collector_obj.name = 'test_fips'
    fips_collector_obj._fact_ids = set()

    # Call the collect method
    collected_facts = fips_collector_obj.collect()

    # Assert if the fact fips is collected

# Generated at 2022-06-23 01:17:52.239592
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool
    assert fips_facts['fips'] == False or fips_facts['fips'] == True


# Generated at 2022-06-23 01:17:55.829851
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    data = fips_collector.collect()
    if data[u'fips'] == False:
        assert True
    else:
        assert False

# Generated at 2022-06-23 01:18:00.361300
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collected_facts = FipsFactCollector()
    facts = fips_collected_facts.collect()
    assert isinstance(facts, dict)
    assert 'fips' in facts
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-23 01:18:01.308830
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect(None, None)

# Generated at 2022-06-23 01:18:01.911068
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:18:05.317033
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector
    assert fips_collector.collect() is not None

# Generated at 2022-06-23 01:18:08.386425
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Constructor of class FipsFactCollector
    """
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:18:10.214091
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == { 'fips' : False }

# Generated at 2022-06-23 01:18:11.594018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:14.784387
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:18:16.324256
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    assert fips_obj.collect()['fips'] == False

# Generated at 2022-06-23 01:18:20.770844
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = mock.Mock()
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector.collect(module) == fips_facts

# Generated at 2022-06-23 01:18:23.349117
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f_facts = FipsFactCollector()
    assert f_facts.name == 'fips'
    assert set() == f_facts._fact_ids


# Generated at 2022-06-23 01:18:27.276057
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    ansible_fips_facts = fips_facts_collector.collect()
    assert ansible_fips_facts['fips'] is False

# Generated at 2022-06-23 01:18:30.388859
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: 1 is not populated in fips, but should always be set
    assert FipsFactCollector().collect()['fips'] is False

# Generated at 2022-06-23 01:18:34.113044
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    m_collector = __import__('ansible.module_utils.facts.fips', globals(), locals(), ['FipsFactCollector'], -1)
    if 'fips' not in collector_registry._fact_collectors:
        collector_registry.register(m_collector.FipsFactCollector)
    collector = collector_registry.get_collector('fips')
    assert collector.collect()

# Generated at 2022-06-23 01:18:36.379913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == dict()

# Generated at 2022-06-23 01:18:37.576747
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert 'fips' in result

# Generated at 2022-06-23 01:18:46.166815
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test if __init__ is called correctly
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

    fips_facts = { 'fips': False }
    # Test when data is None
    m_module = mock.MagicMock()
    m_module.params = {}
    m_get_file_content = mock.MagicMock(return_value=None)
    with mock.patch.object(fips, '_read_file_to_string') as m_read_file_to_string:
        m_read_file_to_string.side_effect = m_get_file_content
        assert fips.collect(module=m_module) == fips_facts

    # Test when data is an empty string
    m_