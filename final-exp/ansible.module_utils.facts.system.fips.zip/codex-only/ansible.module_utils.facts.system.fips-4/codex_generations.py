

# Generated at 2022-06-23 01:08:46.082486
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect()
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-23 01:08:48.149847
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:08:56.855087
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected = {'fips': False}
    FipsFactCollector._read_file = lambda self, path: ''
    result = FipsFactCollector().collect()
    assert result == expected

    expected = {'fips': True}
    FipsFactCollector._read_file = lambda self, path: '1'
    result = FipsFactCollector().collect()
    assert result == expected

if __name__ == '__main__':
    test_FipsFactCollector_collect()

# Generated at 2022-06-23 01:09:05.927187
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''

    collector = FipsFactCollector()

    # If there is no fips_enabled file, no fips fact is returned
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data:
        fips_enabled_content = data
    else:
        fips_enabled_content = '1'

    # Mock the get_file_content function
    def mocked_get_file_content(*args, **kwargs):
        for arg in args:
            if arg == '/proc/sys/crypto/fips_enabled':
                return fips_enabled_content

    return_value = collector.collect(None)

    # Look if the returned fips fact is correct

# Generated at 2022-06-23 01:09:13.733920
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_c = FipsFactCollector()
    FipsFactCollector_c._module = None
    FipsFactCollector_c._collected_facts = None
    FipsFactCollector_c._module = None
    FipsFactCollector_c._collected_facts = None
    FipsFactCollector_c.collect()


# Generated at 2022-06-23 01:09:22.254943
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class ModuleStub(object):
        module = ModuleStub

        def get_bin_path(name, opts=None, required=False):
            return '/bin/%s' % (name)

    class AnsibleModuleStub(object):
        params = {}

        def __init__(self):
            self.module = ModuleStub()

    # Set return values for module.run_command
    # command = /bin/lsmod
    # rc = 0

# Generated at 2022-06-23 01:09:23.922194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact = FipsFactCollector()
    assert fact.name == 'fips'

# Generated at 2022-06-23 01:09:26.588749
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:09:30.665276
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-23 01:09:33.952199
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector is not None


# Generated at 2022-06-23 01:09:38.219395
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == "fips"
    assert fips_facts._fact_ids == set()
    assert isinstance(fips_facts, BaseFactCollector)

# Generated at 2022-06-23 01:09:41.837664
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector_obj = FipsFactCollector()
    assert isinstance(fips_fact_collector_obj, FipsFactCollector)
    assert fips_fact_collector_obj.name == 'fips'
    assert fips_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:09:44.507813
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-23 01:09:45.646470
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips

# Generated at 2022-06-23 01:09:47.606266
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Simple test
    module = DummyModule()
    result = FipsFactCollector.collect(module=module)
    assert result == {'fips': False}


# Generated at 2022-06-23 01:09:48.212449
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:49.589095
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips.collect()

# Generated at 2022-06-23 01:09:52.763394
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect().get('fips') == False, "The fips should be False."

# Generated at 2022-06-23 01:09:58.748494
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector import get_collector_instance

    CollectorSubClass = get_collector_instance(
        'FipsFactCollector',
        collector_registry=collector_registry
    )


    test_obj = CollectorSubClass()

    fips_facts = test_obj.collect()

    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:10:01.360304
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert(collector.name == 'fips')
    assert(collector._fact_ids == set())
    assert(isinstance(collector._fact_ids, set))


# Generated at 2022-06-23 01:10:05.643089
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj.collect() == {'fips': False}
    assert fips_obj._fact_ids == set()

# Generated at 2022-06-23 01:10:11.428314
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Creating a simple class object which is used to call method collect
    test_obj = FipsFactCollector({})
    # Mocking a class method
    with patch('ansible.module_utils.facts.collector.get_file_content') as get_file_content_mock:
        # Returning the mock when a method is called
        get_file_content_mock.return_value = '1'
        result = test_obj.collect()
        assert(result['fips'] == True)
        get_file_content_mock.return_value = '0'
        result = test_obj.collect()
        assert(result['fips'] == False)

# Generated at 2022-06-23 01:10:15.023458
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_obj = FipsFactCollector()
    assert not facts_obj.collect()
    assert not facts_obj.collect(collected_facts=None)


# Generated at 2022-06-23 01:10:16.917086
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_host = FipsFactCollector()
    facts = test_host.collect()
    assert facts == {}

# Generated at 2022-06-23 01:10:28.277375
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class mock_BaseFactCollector:
        module = None
        collected_facts = None

    class mock_get_file_content:
        def __init__(self, filepath, params=None):
            self.filepath = filepath
            self.params = params
        def return_file_content(self):
            if self.filepath == '/proc/sys/crypto/fips_enabled':
                return 1
            else:
                return 0

    actual_output = mock_BaseFactCollector()
    expected_output = mock_BaseFactCollector()
    expected_output.collected_facts = {'fips':True}

    fips_collector = FipsFactCollector()
    fips_collector.get_file_content = mock_get_file_content
    actual_output.collected_facts = f

# Generated at 2022-06-23 01:10:30.147726
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'

# Generated at 2022-06-23 01:10:36.663505
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    test_facts = fact_collector.collect()
    assert test_facts is None or isinstance(test_facts, dict), \
        'FipsFactCollector did not return a dictionary'
    if test_facts is not None:
        assert isinstance(test_facts.get('fips', None), bool), \
            'FipsFactCollector did not return a fips value'

# Generated at 2022-06-23 01:10:39.682469
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test that FipsFactCollector is a subclass of BaseFactCollector
    assert issubclass(FipsFactCollector, BaseFactCollector)


# Generated at 2022-06-23 01:10:43.577860
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    assert set(['fips']) == fips_fact_collector._fact_ids

# Generated at 2022-06-23 01:10:46.466671
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:10:48.304430
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFact = FipsFactCollector()
    assert fipsFact.name == 'fips'

# Generated at 2022-06-23 01:10:49.707298
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector, BaseFactCollector)

# Generated at 2022-06-23 01:10:53.110899
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:10:55.493927
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:10:58.028837
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts['fips'] is False

# Generated at 2022-06-23 01:11:00.165027
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()

# Generated at 2022-06-23 01:11:04.375364
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-23 01:11:06.705205
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'

# Generated at 2022-06-23 01:11:07.828568
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:08.839519
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:10.583666
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test:
    #   - creating an object of the class FipsFactCollector
    assert FipsFactCollector()

# Generated at 2022-06-23 01:11:16.798439
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    fips_fact_collector = FipsFactCollector()
    facts_dict = FactsCollector(None).get_facts()
    fips_facts_dict = fips_fact_collector.collect(None, facts_dict)
    assert fips_facts_dict['fips'] == False

# Generated at 2022-06-23 01:11:27.856275
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ansible_module = MagicMock()
    ansible_module.params = lambda: {'gather_subset': ['!all', 'fips']}

    mock_collector = MagicMock(
        spec=FipsFactCollector,
        name='FipsFactCollector',
    )
    FipsFactCollector.__new__.return_value = mock_collector

    mock_collector.collect.return_value = {'fips': True}

    fips_facts_module = FipsFacts(ansible_module)
    fips_facts_module.populate()
    fips_facts_module.run()

    assert ansible_module.exit_json.called

# Generated at 2022-06-23 01:11:31.128628
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:11:34.152908
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # No need to test if the system is in FIPS mode or not, as it is tested by test_module_plat.py
    pass



# Generated at 2022-06-23 01:11:36.882391
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    fips_facts = FipsFactCollector.collect()
    if not fips_facts:
        assert fips_facts == {'fips': False}

# Generated at 2022-06-23 01:11:39.009144
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollectorTest = FipsFactCollector()
    assert FipsFactCollectorTest

# Generated at 2022-06-23 01:11:40.696844
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-23 01:11:49.891573
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines

    fips_collector = FipsFactCollector()
    facts_collector = FactsCollector()
    facts_collector._collectors = [fips_collector]

    module = AnsibleModuleMock()

    get_file_content_mock = patch.object(get_file_content, '__call__', return_value=to_bytes('1'))
    get_file_lines_mock = patch.object(get_file_lines, '__call__')

# Generated at 2022-06-23 01:11:52.313310
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assertTrue(isinstance(FipsFactCollector(), FipsFactCollector))

# Generated at 2022-06-23 01:11:56.748415
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert fc._fact_ids == set()
    assert fc.collect_fn.__name__ == 'collect'


# Generated at 2022-06-23 01:11:59.092410
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:12:01.195447
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {}

# Generated at 2022-06-23 01:12:03.448224
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = dict(fips=True)
    instance = FipsFactCollector()
    assert fips_facts == instance.collect()

# Generated at 2022-06-23 01:12:10.975630
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector

    fcol = FipsFactCollector()
    assert isinstance(fcol, FipsFactCollector), \
        "FipsFactCollector() fails to create FipsFactCollector instance"
    assert isinstance(fcol, Collector), \
        "FipsFactCollector() fails to create Collector instance"
    assert isinstance(fcol, FactsCollector), \
        "FipsFactCollector() fails to create FactsCollector instance"



# Generated at 2022-06-23 01:12:13.225583
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:12:14.784728
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FF = FipsFactCollector()
    assert FF.name == "fips"
    assert FF._fact_ids == set()

# Generated at 2022-06-23 01:12:18.411903
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == "fips"


# Generated at 2022-06-23 01:12:23.665377
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = { "fips" : False }
    fips_facts = fact_collector.collect(None, collected_facts)
    assert (fips_facts["fips"] == False)


# Generated at 2022-06-23 01:12:25.891781
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:12:34.581096
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_facts = dict(fips='unset')

    ffc = FipsFactCollector()

    # fips_facts should be unchanged when fips is not enabled
    ffc.collect(module=None, collected_facts=fips_facts)
    assert fips_facts['fips'] == 'unset', 'fips_facts changed but not enabled'

    # FIPS is enabled, so fips_facts should be updated and accurate
    fips_facts['fips'] = False  # Set the value to something, just so it's *not* the default
    ffc.get_file_lines = lambda path: ['1']
    ffc.collect(module=None, collected_facts=fips_facts)
    assert fips_facts['fips'] == True, 'fips_facts not updated when FIPS is enabled'

# Generated at 2022-06-23 01:12:37.522768
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()



# Generated at 2022-06-23 01:12:40.228317
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_test = FipsFactCollector()
    result = fips_test.collect()
    assert result['fips'] is False

# Generated at 2022-06-23 01:12:42.544693
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:12:48.737312
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    ffc1 = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc.__name__ == 'fips'
    assert ffc.__doc__ == 'Get fips status'
    assert isinstance(ffc.collect(), dict)
    assert ffc.collection_type == 'fips'
    assert FipsFactCollector.__doc__ == 'Get fips status'

# Generated at 2022-06-23 01:12:51.082141
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == "fips"
    assert fips_fact._fact_ids == set()

# Generated at 2022-06-23 01:12:53.761244
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == "fips"
    assert FipsFactCollector._fact_ids == set()
    assert hasattr(FipsFactCollector, "collect")

# Generated at 2022-06-23 01:13:03.631801
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # first set the /proc/sys/crypto/fips_enabled to 0
    # creating a file at the location and writing 0 to it
    import os
    open('/proc/sys/crypto/fips_enabled', 'a').close()
    f_handle = open('/proc/sys/crypto/fips_enabled', 'w')
    f_handle.write('0')
    f_handle.close()
    
    # deleting the file if it already exists
    if os.path.exists('/etc/system-fips'):
      os.remove('/etc/system-fips')
    else:
      pass
    
    if os.path.exists('/proc/sys/crypto/fips_enabled'):
      os.remove('/proc/sys/crypto/fips_enabled')


# Generated at 2022-06-23 01:13:05.384844
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:13:14.771585
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()

    # Failing Case
    with open('./fips_facts_file.txt', 'w') as fips_file:
        fips_file.write('0\n')
    
    # Success Case
    fips_facts = fips_fc.collect()
    assert fips_facts == {'ansible_fips': False}
    
    # Failing Case
    with open('./fips_facts_file.txt', 'w') as fips_file:
        fips_file.write('1\n')
        
    # Success Case
    fips_facts = fips_fc.collect()
    assert fips_facts == {'ansible_fips': True}

# Generated at 2022-06-23 01:13:16.864173
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc
    assert ffc.name == 'fips'

# Generated at 2022-06-23 01:13:22.816732
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    # Create mock for module
    module = MockModule()
    # Create object for class
    fips_fact_collector = FipsFactCollector()
    # Collect facts
    collected_facts = fips_fact_collector.collect(module)
    # Assert that class name is in collected_facts
    assert 'fips' in collected_facts


# Generated at 2022-06-23 01:13:26.923754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test the collect method of FipsFactCollector."""
    test_obj = FipsFactCollector()
    output = test_obj.collect()
    assert output['fips'] == False

# Generated at 2022-06-23 01:13:29.547423
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    no_fips_facts = {'fips': False}
    assert fips_facts == no_fips_facts

# Generated at 2022-06-23 01:13:30.208999
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:13:35.795110
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test FipsFactCollector"""
    # Test the constructor
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:13:38.026037
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# test with data

# Generated at 2022-06-23 01:13:40.032310
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'

# Generated at 2022-06-23 01:13:46.650347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled', 'w+') as f:
        f.write('1')
    f.close()
    assert fips_facts.collect().get('fips') == True

    with open('/proc/sys/crypto/fips_enabled', 'w+') as f:
        f.write('0')
    f.close()
    assert fips_facts.collect().get('fips') == False

# Generated at 2022-06-23 01:13:48.970362
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['ansible_local']['fips'] == False

# Generated at 2022-06-23 01:13:51.715812
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-23 01:13:56.118253
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:13:59.144730
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_col = FipsFactCollector()
    # Function collect must return a dict
    assert type(fips_col.collect()) is dict

# Generated at 2022-06-23 01:14:03.447587
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('1')
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips']


# Generated at 2022-06-23 01:14:15.527962
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {'fips': False}
    fips_collector = FipsFactCollector()
    # mock get_file_content
    def mock_get_file_content_fips_enable(*args, **kwargs):
        return "1"
    # mock get_file_content
    def mock_get_file_content_fips_disable(*args, **kwargs):
        return "0"
    # fips is enabled
    fips_collector.get_file_content = mock_get_file_content_fips_enable
    assert fips_facts['fips'] is False
    assert fips_collector.collect()['fips'] is True
    # fips is disabled
    fips_collector.get_file_content = mock_get_file_content_fips_disable
   

# Generated at 2022-06-23 01:14:17.935718
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips'] == False


# Generated at 2022-06-23 01:14:23.657607
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a instance of FipsFactCollector
    FipsFactCollector_obj = FipsFactCollector()
    # Create a fact for testing
    collected_facts = {}

    # Run the method collect of FipsFactCollector
    FipsFactCollector_obj.collect(collected_facts=collected_facts)

    # Test if fips fact is created or not
    assert 'fips' in collected_facts

# Generated at 2022-06-23 01:14:25.938481
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:14:36.442102
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == { 'fips': False }

    # Test when fips is enabled
    get_file_content_saved = get_file_content
    def get_file_content_mock_fips_enabled(path):
        return "1"
    get_file_content.side_effect = get_file_content_mock_fips_enabled
    assert fips_fact_collector.collect() == { 'fips': True }
    get_file_content = get_file_content_saved

# Generated at 2022-06-23 01:14:38.727182
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:14:40.659405
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print('Test started')
    FipsFactCollector().collect()
    print('Test finished')


# Generated at 2022-06-23 01:14:44.887623
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj1 = FipsFactCollector()
    assert obj1
    assert obj1.name == 'fips'
    assert obj1._fact_ids == set()
    assert obj1.collect() == {'fips': False}

# Generated at 2022-06-23 01:14:49.845929
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect()
    assert isinstance(fips_facts, dict)
    assert set(fips_facts.keys()) == set(['fips'])
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:14:53.789064
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}

    collector = FipsFactCollector()
    result = collector.collect(module, collected_facts)
    assert result['fips'] == True or result['fips'] == False

# Generated at 2022-06-23 01:14:58.210301
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips', \
        "The name of class FipsFactCollector should be 'fips'"

    assert FipsFactCollector._fact_ids == set(), \
        "The _fact_ids of class FipsFactCollector should be empty"

# Generated at 2022-06-23 01:15:04.132048
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Instantiate the FipsFactCollector
    fips_fc = FipsFactCollector()
    assert fips_fc

    # Assert name of FactCollector
    assert fips_fc.name == 'fips'

    # Assert that empty _fact_ids is set
    assert fips_fc._fact_ids == set()

    # Assert that empty _fact_ids is set
    assert fips_fc._fact_ids == set()



# Generated at 2022-06-23 01:15:08.450420
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test FipsFactCollector class constructor without parameters
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

    # Test FipsFactCollector class constructor with parameters
    fact_collector = FipsFactCollector(route='ansible.module_utils.facts.fips')
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:15:11.790757
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:15:22.749522
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print("test_FipsFactCollector_collect")
    # test data
    data = '1'
    fips_facts = {
        'fips': True
    }
    
    # mock get_file_content
    get_file_content_values = {
        '/proc/sys/crypto/fips_enabled': data
    }
    def mocked_get_file_content(file, default=None):
        return get_file_content_values[file]
    mocker.patch('ansible.module_utils.facts.utils.get_file_content', side_effect=mocked_get_file_content)

    # test
    ffc = FipsFactCollector()
    collected_facts = {}
    fips_facts_returned = ffc.collect(collected_facts=collected_facts)


# Generated at 2022-06-23 01:15:25.954324
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    assert type(result) == dict
    assert 'fips' in result
    if result['fips'] != False:
        assert result['fips'] == True
    else:
        assert result['fips'] == False

# Generated at 2022-06-23 01:15:29.269776
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = '1'
    fips_facts = {}
    fips_facts['fips'] = True
    FipsFactCollector._get_file_content = lambda self, path: fips_data
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-23 01:15:35.144309
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect"""
    filename = "fips"
    fips = FipsFactCollector()
    output = fips.collect()
    assert (type(output) == dict)
    assert (output['fips'] == False)
    assert (filename in output)
    assert (output[filename] == "0")
    output = fips.collect()
    assert (output['fips'] == False)
    assert (filename in output)
    assert (output[filename] == "0")

# Generated at 2022-06-23 01:15:36.808299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips':False}

# Generated at 2022-06-23 01:15:39.349898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert isinstance(fips_facts, dict)
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:15:42.489679
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:15:44.120600
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:15:46.857935
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:15:49.960493
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    myFipsFactCollector = FipsFactCollector()
    assert myFipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:15:54.205382
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    facts = fc.collect(collected_facts=None)
    expected_facts = {'fips': False}
    if facts == expected_facts:
        assert True
    else:
        assert False

# Generated at 2022-06-23 01:15:58.319212
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    collected_facts = fips_fact.collect()

    assert 'fips' in collected_facts

# Generated at 2022-06-23 01:16:01.371310
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:16:05.976362
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = True
    fc = FipsFactCollector()
    results = fc.collect()
    if results == fips_facts:
        print('test_FipsFactCollector_collect test passed')
    else:
        print('test_FipsFactCollector_collect test failed')

# Generated at 2022-06-23 01:16:08.492135
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:12.390951
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = """
    1
    """
    fips_fac = FipsFactCollector()
    fips_result = fips_fac.collect(None, None)
    assert fips_result == {'fips': True}

# Generated at 2022-06-23 01:16:15.334601
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    assert result['fips'] == False, "Expected false but got {0}".format(result['fips'])

# Generated at 2022-06-23 01:16:17.113147
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    fipsFactCollector.collect()

# Generated at 2022-06-23 01:16:22.292059
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect(None, None)
    assert "fips" in facts, "FipsFactCollector did not add fips to the facts"
    assert facts["fips"] is False, "FipsFactCollector did not set fips to False"

# Generated at 2022-06-23 01:16:23.480696
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:16:24.613835
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:16:27.612011
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    # Assert that name and _fact_ids attributes are set
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:16:30.036755
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == "fips"
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:16:30.938004
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:16:32.733581
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    z = FipsFactCollector()
    assert z.name == 'fips'
    assert z._fact_ids == set()

# Generated at 2022-06-23 01:16:34.541068
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:36.628533
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert('fips' in result)
    assert(isinstance(result['fips'], bool))

# Generated at 2022-06-23 01:16:41.270959
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts == {'fips': True}, \
        "Failed to collect the expected facts"

# Generated at 2022-06-23 01:16:43.097038
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts['fips']

# Generated at 2022-06-23 01:16:49.509131
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Constructor of class FipsFactCollector should assign proper values for the
    class attributes
    """
    fips_fact_collector = FipsFactCollector()

    assert hasattr(fips_fact_collector, 'name')
    assert fips_fact_collector.name == 'fips'

    assert hasattr(fips_fact_collector, '_fact_ids')
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:51.770274
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:16:54.114013
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:16:58.443273
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:01.533685
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open("/proc/sys/crypto/fips_enabled", 'w') as file_write:
        file_write.write("1")
    fipsFactCollector = FipsFactCollector()
    fipsFact = fipsFactCollector.collect()
    assert(fipsFact['fips'] == True)

# Generated at 2022-06-23 01:17:05.203202
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_fact = fips_collector.collect()
    assert type(fips_fact) == dict
    assert fips_fact['fips'] == False

# Generated at 2022-06-23 01:17:08.482369
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_identifier = set()
    expected_identifier.add('fips')
    collector = FipsFactCollector()
    identifier_result = collector.identifier
    assert identifier_result == expected_identifier

# Generated at 2022-06-23 01:17:16.395292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()

    # Test return when no system is in FIPS mode
    module = Mock(params={})
    ret = fips_fc.collect(module=Mock(), collected_facts={})
    assert ret == {'fips': False}

    # Test return when a system is in FIPS mode
    module = Mock(params={})
    get_file_content = Mock(return_value='1')
    ret = fips_fc.collect(module=Mock(), collected_facts={})
    assert ret == {'fips': True}

# Generated at 2022-06-23 01:17:25.392358
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Initialize fixtures
    module = None
    collected_facts = None

    # Get instance of FipsFactCollector class
    fips_fact_collector = FipsFactCollector()

    # Test collect method
    data = fips_fact_collector.collect(module, collected_facts)

    assert data["fips"] == False

    # Define file content for fips_enabled file
    data = '1'

    # Mock content
    fips_fact_collector.get_file_content = lambda x: data

    # Test collect method
    data = fips_fact_collector.collect(module, collected_facts)

    assert data["fips"] == True

# Generated at 2022-06-23 01:17:27.214727
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Validate expected metadata for FipsFactCollector class."""
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:17:30.110578
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:17:33.437109
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == "fips"

# Generated at 2022-06-23 01:17:43.128557
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect
    """
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector
    import os

    if os.path.isfile('/proc/sys/crypto/fips_enabled'):
        fips_value = get_file_content('/proc/sys/crypto/fips_enabled')
        fc = FipsFactCollector()
        facts = fc.collect()
        if fips_value == '1':
            assert facts['fips']
        else:
            assert not facts['fips']
    else:
        assert True

# Generated at 2022-06-23 01:17:46.392368
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    kwargs = {
        'collected_facts': {},
        'module': {},
    }
    instance = FipsFactCollector()
    facts = instance.collect(**kwargs)
    assert 'fips' in facts


# Generated at 2022-06-23 01:17:47.754385
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-23 01:17:50.319520
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected = FipsFactCollector()
    assert(expected.name == "fips")
    assert(expected._fact_ids == set())


# Generated at 2022-06-23 01:17:52.676818
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'

# Generated at 2022-06-23 01:17:54.642923
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:17:56.119795
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    assert not fact_collector.collect().get('fips')

# Generated at 2022-06-23 01:18:08.272065
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_module
    from ansible.module_utils.facts.utils import get_file_content

    fips_facts = {
        'fips': False,
    }

    def mock_get_file_content(file_name):
        if file_name == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return None

    # fail no file_content
    def mock_get_file_content_fail(file_name):
        return None

    mock_module = collector_module('fips')
    mock_module.get_file_content = mock_get_file_content
    mock_module.params = {}

    collector = FipsFactCollector(mock_module)
    facts_from_collector = collector

# Generated at 2022-06-23 01:18:09.626108
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    

# Generated at 2022-06-23 01:18:11.551010
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == { 'fips': False }

# Generated at 2022-06-23 01:18:14.974461
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()



# Generated at 2022-06-23 01:18:16.697319
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-23 01:18:24.612192
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """unit test to verify the output of method collect of class FipsFactCollector """

    # setup context
    class Mocked:
        def __init__(self):
            self.ansible_facts = {}
        def exit_json(self, **kwargs):
            self.ansible_facts = kwargs['ansible_facts']
            return True

    # instantiate the test module
    x = Mocked()
    FipsFactCollector().collect(module=x)

    # validate the expected output
    assert 'fips' in x.ansible_facts, "Expected 'fips' to be returned as a fact"
    assert x.ansible_facts['fips'] is False, "Expected value 'False' for 'fips' in the returned facts"

# Generated at 2022-06-23 01:18:31.521278
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    try:
        f = FactCollector("","")
        f.collect = FipsFactCollector("","").collect
        f.populate()
        pass
    except:
        pass

# Generated at 2022-06-23 01:18:33.812615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
	fipsFactCollector = FipsFactCollector()
	assert fipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:36.099479
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:18:39.922803
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    factCollector = FipsFactCollector()
    factCollector._module_name = 'collect_fips'

    facts = factCollector.collect()

    assert type(facts) == dict, facts
    assert type(facts['fips']) == bool, facts


# vim: set ai et ts=4 sw=4:

# Generated at 2022-06-23 01:18:41.607486
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector is not None
    assert collector.name == "fips"


# Generated at 2022-06-23 01:18:43.173675
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = {}
    collector = FipsFactCollector()
    assert collector is not None