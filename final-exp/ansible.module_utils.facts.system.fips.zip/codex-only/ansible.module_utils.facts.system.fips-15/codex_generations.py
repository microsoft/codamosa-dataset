

# Generated at 2022-06-23 01:08:46.581379
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.collect() is not None

# Generated at 2022-06-23 01:08:48.257167
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj is not None


# Generated at 2022-06-23 01:08:52.079463
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_dict = {'fips':True}
    assert fips_facts_dict == FipsFactCollector().collect()

# Generated at 2022-06-23 01:08:58.578236
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import tempfile

    with tempfile.NamedTemporaryFile('w+', delete=False) as f:
        f.write('1')

    try:
        # Setup
        fips = FipsFactCollector()
        fips.collect()

        # Test that collect() returns a dict
        assert isinstance(fips.collect(), dict)

        # Test that correct value is returned for fips
        assert fips.collect()['fips']
    finally:
        os.unlink(f.name)

# Generated at 2022-06-23 01:09:01.738237
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = None
    mock_collected_facts = None
    fips = FipsFactCollector()
    result = fips.collect(mock_module, mock_collected_facts)
    assert 'fips' in result

# Generated at 2022-06-23 01:09:03.763183
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert obj.name == 'fips'
    assert obj.collect()


# Generated at 2022-06-23 01:09:07.625063
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Units tests for method FipsFactCollector.collect of
    class FipsFactCollector
    '''
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:09:10.911808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector.platform == "All"
    assert fips_fact_collector.legacy_fact_names == set()


# Generated at 2022-06-23 01:09:12.700779
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:15.720336
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # TODO: Add tests for method FipsFactCollector.collect
    pass

# Generated at 2022-06-23 01:09:26.000228
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method `FipsFactCollector.collect`"""
    # Set up
    fact_collector = FipsFactCollector()

    # Test a system in 'fips' mode
    FipsFactCollector.get_file_content = lambda x: '1'
    result = fact_collector.collect()
    assert result['fips'] == True
    # Test a system not in 'fips' mode
    FipsFactCollector.get_file_content = lambda x: '0'
    result = fact_collector.collect()
    assert result['fips'] == False
    # Test a missing file
    FipsFactCollector.get_file_content = lambda x: ''
    result = fact_collector.collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:09:28.637793
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:09:31.373648
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids
    assert fips.collect_fn
    assert not fips.required_module_names

# Generated at 2022-06-23 01:09:33.669749
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:09:40.566753
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    fips_facts = {}
    fips_facts['fips'] = False
    fc = FipsFactCollector()
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    assert data == '1' or data == '0'
    if data == '1':
        fips_facts['fips'] = True
    assert fc.collect(module, collected_facts) == fips_facts

# Generated at 2022-06-23 01:09:43.501555
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {}
    collector = FipsFactCollector()
    facts = collector.collect(collected_facts)
    assert(facts['fips'] == False)

# Generated at 2022-06-23 01:09:45.849270
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert 'fips' == fips.name
    assert set() == fips._fact_ids

# Generated at 2022-06-23 01:09:51.043073
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    of class FipsFactCollector
    """
    fips = FipsFactCollector()
    collected_facts = fips.collect()
    assert isinstance(collected_facts, dict)
    assert isinstance(collected_facts[fips.name], dict)
    assert isinstance(collected_facts[fips.name]['fips'], bool)

# Generated at 2022-06-23 01:10:00.569313
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    def mock_get_file_content(file):
        if file == '/proc/sys/crypto/fips_enabled':
            return '0'
        raise OSError()

    fips_fact_collector = FipsFactCollector()
    get_file_content_mock = 'ansible.module_utils.facts.collector.get_file_content'
    with mock.patch(get_file_content_mock, side_effect=mock_get_file_content):
        fips_facts = fips_fact_collector.collect()
        assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:10:05.327986
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""
    fips_fact_collector = FipsFactCollector()
    # call method collect()
    fact_collector_result = fips_fact_collector.collect()
    assert fact_collector_result == {}
    # add an assertion if needed

# Generated at 2022-06-23 01:10:09.229468
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # there is no constructor for this class
    # constructor called implicitly
    fact_collector = FipsFactCollector()

    # tests for FipsFactCollector class
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:10:17.318950
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test the collect method of class FipsFactCollector
    """
    # Create and initialize instance of class FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # Set the path of the file to be read from
    file_path='/proc/sys/crypto/fips_enabled'
    fips_fact_collector.set_file_content(file_path)

    # Collect fips facts
    collected_facts=fips_fact_collector.collect()

    # Assert the collected facts
    assert collected_facts['fips'] is True

# Generated at 2022-06-23 01:10:20.025400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: Place for future unit tests for FipsFactCollector class
    pass


# Generated at 2022-06-23 01:10:22.804428
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()


# Generated at 2022-06-23 01:10:25.141869
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:10:31.719674
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Return value for method get_file_content
    test_get_file_content = ["1"]

    # Assign fips facts collector object to variable
    fips_facts_collector = FipsFactCollector()
    fips_facts_collector.__class__.get_file_content = lambda self1, arg1: test_get_file_content

    expected_result = {'fips': True}
    result = fips_facts_collector.collect()
    assert result == expected_result

# Generated at 2022-06-23 01:10:35.821288
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    assert FipsFactCollector.name == "fips"
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:10:37.127346
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x is not None


# Generated at 2022-06-23 01:10:40.479396
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method FipsFactCollector.collect
    """
    args = []
    assert FipsFactCollector.collect(*args) == {'fips': False}


# Generated at 2022-06-23 01:10:50.847772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    fc = FipsFactCollector()
    assert isinstance(fc,BaseFactCollector)

    def fake_get_file_content(*args, **kwargs):
        return None

    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    fipsfc = FipsFactCollector()
    assert (fipsfc.collect() == {'fips': False})

    def fake_get_file_content(*args, **kwargs):
        return '1'

    with pytest.raises(Exception):
        assert (fipsfc.collect() == {'fips': True})

# Generated at 2022-06-23 01:10:52.221856
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:10:54.864417
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test the method FipsFactCollector.collect.
    """
    # Test for existence of dictionary fips
    fact_collector = FipsFactCollector()
    assert 'fips' in fact_collector.collect()

# Generated at 2022-06-23 01:11:03.849296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case 1: fips is set.
    # Expected - fips fact = True
    fd = open('/proc/sys/crypto/fips_enabled', 'w')
    fd.write('1')
    fd.close()

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

    fd = open('/proc/sys/crypto/fips_enabled', 'w')
    fd.write('0')
    fd.close()

# Generated at 2022-06-23 01:11:06.951084
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()

# Unit of collection method

# Generated at 2022-06-23 01:11:10.138941
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-23 01:11:15.166939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    assert fips_fc.collect()['fips'] is False
    fips_fc.set_content('/proc/sys/crypto/fips_enabled', '1')
    assert fips_fc.collect()['fips'] is True

# Generated at 2022-06-23 01:11:17.566595
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == { 'fips': False }

# Generated at 2022-06-23 01:11:20.299148
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:11:22.989696
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test = FipsFactCollector()
    result = test.collect()
    assert result['fips'] is False

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 01:11:25.425409
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    try:
        FipsFactCollector()
    except Exception as e:
        pytest.fail('Failed to instantiate FipsFactCollector: %s' % e)


# Generated at 2022-06-23 01:11:29.227094
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    tmp1 = FipsFactCollector()
    file_content = "1\n"
    assert tmp1.collect(file_content)['fips']  # Assert True

    tmp2 = FipsFactCollector()
    file_content = "0\n"
    assert not tmp2.collect(file_content)['fips']  # Assert False

# Generated at 2022-06-23 01:11:31.037407
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:34.913986
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector(None)
    data = fact_collector.collect(collected_facts=None)
    assert 'fips' in data
    assert data['fips'] is False

# Generated at 2022-06-23 01:11:37.290399
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector.collect()



# Generated at 2022-06-23 01:11:39.704655
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-23 01:11:41.033646
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    # just a placeholder
    collector.collect()

# Generated at 2022-06-23 01:11:41.970848
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:11:50.925491
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from tempfile import NamedTemporaryFile
    from os import path

    # Create a fake file and configure fact collector
    fact_collector = FipsFactCollector()
    collector = Collector()
    collector.add_collector(fact_collector)
    collected_facts = collector.collect(module=None, collected_facts=None)

    # check if original method get_file_content was called
    try:
        with NamedTemporaryFile(mode='w+b') as file:
            fake_proc_file = file.name
            content = "0"
            file.write(content)
    finally:
        assert get_file_content.called
        assert get_file_content.call

# Generated at 2022-06-23 01:11:59.377615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for the method FipsFactCollector.collect."""
    # Assign a temporary file for /proc/sys/crypto/fips_enabled
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write(b"1")
        tmp.flush()
        os.environ["PROC_SYS_CRYPTO_FIPS_ENABLED_PATH"] = tmp.name
        fips_collector = FipsFactCollector()
        fips_fact = fips_collector.collect()
   

# Generated at 2022-06-23 01:12:00.838879
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-23 01:12:04.944744
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert len(ffc._fact_ids) == 1
    assert 'fips' in ffc._fact_ids

# Generated at 2022-06-23 01:12:06.391083
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:12:08.306887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsrange = FipsFactCollector()
    assert fipsrange.name == 'fips'

# Generated at 2022-06-23 01:12:10.444639
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:12:12.877632
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    result = ffc.collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:12:17.005938
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Unit test for collect method
    # AnsibleModule.params is not defined but is needed to run facts collection
    # This is a hack to get around it and make it work
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule.params = {}
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    # Unit test will return whatever is returned
    assert True

# Generated at 2022-06-23 01:12:22.938815
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_module
    ansible_module = collector_module()
    fips_collector = FipsFactCollector()
    ansible_module.exit_json(ansible_facts=fips_collector.collect())
    # FIXME: need to check if the test fails as fips_enabled or not

# Generated at 2022-06-23 01:12:25.145471
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """ This unit test is to test the constructor of class FipsFactCollector """
    obj = FipsFactCollector()
    assert obj is not None

# Generated at 2022-06-23 01:12:28.774693
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    FipsFactCollector._fact_ids.add('fips')
    assert len(FipsFactCollector._fact_ids) == 1
    assert FipsFactCollector._fact_ids.pop() == 'fips'

# Generated at 2022-06-23 01:12:31.124012
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips', fips_fact_collector.name



# Generated at 2022-06-23 01:12:33.785690
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    results = collector.collect()
    assert type(results) is dict
    assert len(results.keys()) == 1
    assert 'fips' in results.keys()
    assert type(results['fips']) is bool

# Generated at 2022-06-23 01:12:36.869286
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:12:39.016343
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_const=FipsFactCollector()
    assert fips_const.name == 'fips'

# Generated at 2022-06-23 01:12:41.979557
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:12:43.864962
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:12:47.233206
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-23 01:12:48.673789
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipscollector = FipsFactCollector()
    assert fipscollector.name == 'fips'

# Generated at 2022-06-23 01:12:49.700494
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:55.541114
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create instance of class
    fips_collector = FipsFactCollector()

    # create mock for method 'get_file_content'
    t = True
    f = False
    fips_collector.get_file_content = Mock()
    fips_collector.get_file_content.side_effect = [f, f, t]

    # run method 'collect'
    result = fips_collector.collect()

    assert result['fips'] == [f, f, t]

# Generated at 2022-06-23 01:12:59.083676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Ensure fips fact is populated
    result = fips_fact_collector.collect()
    assert 'fips' in result
    # Ensure and it is always a boolean
    assert isinstance(result['fips'], bool)

# Generated at 2022-06-23 01:13:00.539725
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-23 01:13:04.497648
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_content = '1'
    ffc = FipsFactCollector()
    fips_facts = ffc.collect(collected_facts = {'kernel': 'Linux'})
    assert fips_facts['fips']

# Generated at 2022-06-23 01:13:07.886515
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:13:12.932002
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fact = fips.collect()
    assert fact == { "fips": False }
    fact = fips.collect(module="dummy")
    assert fact == { "fips": False }
    fact = fips.collect(collected_facts="dummy")
    assert fact == { "fips": False }

# Generated at 2022-06-23 01:13:13.949173
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
     collector = FipsFactCollector()
     assert collector

# Generated at 2022-06-23 01:13:16.323144
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f=FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()

# Generated at 2022-06-23 01:13:19.491557
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert type(obj.name).__name__ == 'str'
    assert type(obj._fact_ids).__name__ == 'set'


# Generated at 2022-06-23 01:13:22.523866
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert 'fips' in fips_collector.collect()


# Generated at 2022-06-23 01:13:24.293719
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts.get('fips') is False

# Generated at 2022-06-23 01:13:28.196318
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:13:30.117141
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'


# Generated at 2022-06-23 01:13:31.096362
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:33.951301
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:13:36.533021
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert type(ffc) == FipsFactCollector

# Generated at 2022-06-23 01:13:37.361002
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:13:42.665604
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    # test default value is False
    result = f.collect()
    assert result == {'fips': False}

if __name__ == '__main__':
    test_FipsFactCollector_collect()

# Generated at 2022-06-23 01:13:49.019969
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {'fips': False}
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == fips_facts, \
        "Class method returns incorrect result"

# Generated at 2022-06-23 01:13:51.716178
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert set(fips._fact_ids) == {'fips'}

# Generated at 2022-06-23 01:13:54.046051
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsf = FipsFactCollector()
    # Assert that the name variable is set to the correct value
    assert fipsf.name == 'fips'

# Generated at 2022-06-23 01:14:05.460627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_module

    # The collector class that is to be tested
    cls = collector_module.get_collector('fips')

    # Define the expected results of the collect method given different input data
    module = None
    collected_facts = {}
    expected_result = {'fips': True}
    test_result = cls.collect(module=module, collected_facts=collected_facts)
    assert test_result == expected_result

    # test default result...
    expected_result = {'fips': False}
    test_result = cls.collect(module=module, collected_facts=collected_facts)
    assert test_result == expected_result

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-23 01:14:15.355045
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        from ansible.module_utils.facts import collector
        collector.collectors['fips'] = FipsFactCollector
    except:
        pass
    fips_facts = FipsFactCollector.collect()
    assert not fips_facts['fips']

    signal(SIGALRM, exit)
    alarm(1)
    os.environ['TEST_COLLECTOR_FIPS'] = '1'
    fips_facts = FipsFactCollector.collect()
    alarm(0)
    assert fips_facts['fips']
    del os.environ['TEST_COLLECTOR_FIPS']

# Generated at 2022-06-23 01:14:18.127901
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:21.024016
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
   fips_fact_collector = FipsFactCollector()
   result = fips_fact_collector.collect()
   assert result.get('fips')

# Generated at 2022-06-23 01:14:23.169860
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-23 01:14:25.499850
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'

# Generated at 2022-06-23 01:14:28.075807
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   # Test constructor of class FipsFactCollector
   fips_fact_collector = FipsFactCollector()
   assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:14:31.994072
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert len(fips_facts._fact_ids) == 0


# Generated at 2022-06-23 01:14:40.147638
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids = set()
    fips_facts_collector = FipsFactCollector()

    # Testing normal case
    def get_file_content(path):
        return "foo"
    fips_facts = fips_facts_collector.collect(collected_facts=dict())
    assert fips_facts == dict(fips=False)

    # Testing when fips is enabled
    def get_file_content(path):
        return "1"
    fips_facts = fips_facts_collector.collect(collected_facts=dict())
    assert fips_facts == dict(fips=True)

# Generated at 2022-06-23 01:14:42.528833
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == { 'fips': True }

# Generated at 2022-06-23 01:14:46.030806
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == "fips"
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:14:50.444650
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    unit tests for method collect of class FipsFactCollector
    """
    module = 'module'
    i_am_facts = {}
    ffc = FipsFactCollector()
    result = ffc.collect(module)
    assert result['fips'] == False

# Generated at 2022-06-23 01:14:54.978336
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = "dummy_module"
    collected_facts = {}
    fact_collector = FipsFactCollector(module, collected_facts)
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set([])


# Generated at 2022-06-23 01:14:58.155894
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = object()
    collected_facts = dict()

    fips_fact = FipsFactCollector()
    result = fips_fact.collect(module, collected_facts)
    assert result['fips'] == False

# Generated at 2022-06-23 01:15:00.727295
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert 'fips' in collector._fact_ids
    assert collector.collect()['fips'] == False

# Generated at 2022-06-23 01:15:04.450919
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_collector = FipsFactCollector()
    result = test_collector.collect()
    assert result.get('fips') == False, "fips value is not True or False"
    assert result.get('fips') != None, "fips value is set to None"

# Generated at 2022-06-23 01:15:11.033634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    open_mock = mock.mock_open()
    with mock.patch('ansible.module_utils.facts.collector.FipsFactCollector.open', open_mock, create=True):
        open_mock.return_value.__iter__.return_value = ['1']
        fips_collector = FipsFactCollector()
        collected_facts = fips_collector.collect()
        assert collected_facts == {'fips': True}

# Generated at 2022-06-23 01:15:13.239306
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj.collect() != None

# Generated at 2022-06-23 01:15:16.107074
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    result = obj.collect(None, None)
    assert result['fips'] is False


# Generated at 2022-06-23 01:15:18.887181
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    text = ''
    with open('/proc/sys/crypto/fips_enabled') as f:
        text = f.read()
    assert text == '0'

# Generated at 2022-06-23 01:15:25.704311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class _module_mock:
        class _params_mock:
            gather_subset = ['!all', '!min']

    _module_mock = _module_mock()
    fips_facts_collector = FipsFactCollector(_module_mock)

    fips_facts = {
        'fips': True
    }
    facts_mock = {"fips": ["This is not a fips"]}
    fips_facts = fips_facts_collector.collect(module=_module_mock, collected_facts=facts_mock)
    assert fips_facts == {'fips': True}

# Generated at 2022-06-23 01:15:27.652941
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ify = FipsFactCollector()
    assert ify.collect() == {'fips': False}

# Generated at 2022-06-23 01:15:31.677374
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect()
    assert fips_facts is not None
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-23 01:15:37.410776
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    target_collection_obj = {}
    fips_facts = fips_collector.collect(collected_facts=target_collection_obj)
    assert fips_facts == {'fips': False}, "Failed to collect fips facts"

# Generated at 2022-06-23 01:15:42.861556
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsCollector = FipsFactCollector()
    fips_facts = fipsCollector.collect()
    try:
        assert(fips_facts['fips'] == False)
    except (AssertionError, KeyError):
        pass
    else:
        pass
        #assert(fips_facts['fips'] == True)



# Generated at 2022-06-23 01:15:44.481676
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'

# Generated at 2022-06-23 01:15:46.858103
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_instance = FipsFactCollector()
    assert fips_instance.name == 'fips'
    assert fips_instance._fact_ids == set()


# Generated at 2022-06-23 01:15:48.175251
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert 'fips' == fips.name

# Generated at 2022-06-23 01:15:50.190147
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:15:53.134009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    ans = fips_fact_collector.collect()
    assert ans['fips'] == False

# Generated at 2022-06-23 01:15:55.355478
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:15:59.776969
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj is not None
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()

# Generated at 2022-06-23 01:16:06.629774
# Unit test for method collect of class FipsFactCollector

# Generated at 2022-06-23 01:16:07.139676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:16:09.597069
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()

# Generated at 2022-06-23 01:16:13.523068
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:16:15.077816
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:16.892201
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # check instance
    fips_fact = FipsFactCollector()
    assert isinstance(fips_fact, FipsFactCollector)


# Generated at 2022-06-23 01:16:18.503241
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:21.521039
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:16:23.516380
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:16:25.765523
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:16:28.377404
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()



# Generated at 2022-06-23 01:16:30.746503
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert isinstance(instance.name, str)
    assert isinstance(instance._fact_ids, set)


# Generated at 2022-06-23 01:16:31.868481
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:16:33.949061
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect()
    assert 'fips' in facts
    assert facts['fips'] == False

# Generated at 2022-06-23 01:16:36.896645
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert hasattr(fips_fact_collector, 'collect')
    assert isinstance(fips_fact_collector._fact_ids, set)


# Generated at 2022-06-23 01:16:41.270427
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips = fips_fact.collect()

    assert isinstance(fips, dict), "Fips is not a dict"

# Generated at 2022-06-23 01:16:45.127892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_data = FipsFactCollector().collect()

    if fips_data != {'fips': False}:
        raise Exception("Fips test failed!")


# Generated at 2022-06-23 01:16:46.628797
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    n = FipsFactCollector()
    n.collect()
    print("Test finished")

# Generated at 2022-06-23 01:16:50.800651
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    return fips_facts

# Generated at 2022-06-23 01:16:54.075373
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert isinstance(instance, FipsFactCollector)
    assert isinstance(instance._fact_ids, set)
    assert instance._fact_ids is not None

# Generated at 2022-06-23 01:16:58.231418
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fs = FipsFactCollector(None)
    collected_facts = {}
    fs.collect(None, collected_facts)
    assert 'fips' in collected_facts
    if collected_facts['fips']:
        assert type(collected_facts['fips']) is bool

# Generated at 2022-06-23 01:16:59.922364
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert hasattr(FipsFactCollector(), "name")
    assert hasattr(FipsFactCollector(), "_fact_ids")

# Generated at 2022-06-23 01:17:01.706185
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:17:03.482912
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:17:05.827962
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:08.696260
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()



# Generated at 2022-06-23 01:17:12.163478
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set(['fips'])

# Generated at 2022-06-23 01:17:13.965279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:17:16.151195
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:17:17.662426
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:17:21.489498
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert "fips" == fips.name
    assert not fips._fact_ids
    assert hasattr(fips, 'collect')
    assert callable(fips.collect)

# Generated at 2022-06-23 01:17:23.666378
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"


# Generated at 2022-06-23 01:17:24.998665
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': True}

# Generated at 2022-06-23 01:17:26.632433
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    o = FipsFactCollector()
    assert o.name == 'fips'
    assert o._fact_ids == set()


# Generated at 2022-06-23 01:17:29.541661
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_instance = FipsFactCollector()
    res1 = FipsFactCollector_instance.collect()
    assert res1 == {'fips': False}

# Generated at 2022-06-23 01:17:34.845572
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips_facts_dict = fips_fact.collect()
    assert fips_facts_dict['fips'] == False
    assert fips_facts_dict['ansible_fips'] == False
    assert fips_facts_dict['fips_enabled'] == False
    assert 'ansible_fips_enabled' not in fips_facts_dict

# Generated at 2022-06-23 01:17:42.050780
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Setup arguments
    args = {}

    # Create instance of FipsFactCollector
    fips_collector = FipsFactCollector(args)

    # Assert that instance is not null
    assert fips_collector is not None

    # Assert that instance is of correct type
    assert isinstance(fips_collector, FipsFactCollector)

    # Assert that instance name property is correct
    assert fips_collector.name == 'fips'


# Generated at 2022-06-23 01:17:50.943587
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collection_data = {'fips':False}
    new_fips_collector_data = fips_collector.collect()
    assert fips_collector.collection_data == new_fips_collector_data
    fips_collector.collection_data = {'fips': True}
    new_fips_collector_data = fips_collector.collect()
    assert {'fips':False} == new_fips_collector_data
    fips_collector.collection_data = {}
    new_fips_collector_data = fips_collector.collect()
    assert {'fips':False} == new_fips_collector_data

# Generated at 2022-06-23 01:17:56.603994
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    facts_manager = FactsCollector()
    facts_manager.add_collector(FipsFactCollector())
    collected_facts = facts_manager.collect(module=None, collected_facts=None)
    assert collected_facts['fips'] is False

# Generated at 2022-06-23 01:18:00.577631
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.required_facts['fips'] == False

# Generated at 2022-06-23 01:18:03.487428
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == "fips"
    assert collector._fact_ids == set()
    assert collector.collect() == {
        'fips': True
    }

# Generated at 2022-06-23 01:18:05.669839
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'


# Generated at 2022-06-23 01:18:09.121741
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfact_collector = FipsFactCollector()
    assert(fipsfact_collector.name == "fips")
    assert(type(fipsfact_collector._fact_ids) == set)
    assert(fipsfact_collector._fact_ids == set())

# Generated at 2022-06-23 01:18:11.821389
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:18:15.202425
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == "fips"
    assert 'fips' in x.collect()

# Generated at 2022-06-23 01:18:18.441705
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Run collect to populate the fact
    ffc = FipsFactCollector()
    my_facts = ffc.collect()
    assert 'fips' in my_facts
    assert isinstance(my_facts['fips'], bool)

# Generated at 2022-06-23 01:18:22.534809
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == 'fips'
    assert bool(fips_fact_collector._fact_ids)


# Generated at 2022-06-23 01:18:24.287605
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'

# Generated at 2022-06-23 01:18:26.956043
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:18:29.613581
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    result = {}
    result['fips'] = True
    module = None
    collected_facts = None
    assert(f.collect(module, collected_facts) == result)

# Generated at 2022-06-23 01:18:31.189645
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    '''
    Test whether or not the constructor creates an instance of class FipsFactCollector
    '''
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-23 01:18:32.154209
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:18:42.137001
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from mock import patch
    from os.path import exists
    module = object()
    collected_facts = object()
    fips_facts = {}
    fips_facts['fips'] = False
    mocked_data = '0'
    mocked_exists = True
    mocked_open = mock_open(read_data=mocked_data)

# Generated at 2022-06-23 01:18:45.998165
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Let's create a test collector and get its data
    test_collector = FipsFactCollector()
    test_data = test_collector.collect()

    # Assertions
    assert test_data['fips'] == get_file_content('/proc/sys/crypto/fips_enabled')

