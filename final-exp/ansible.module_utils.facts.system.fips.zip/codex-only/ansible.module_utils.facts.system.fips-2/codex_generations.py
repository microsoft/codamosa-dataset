

# Generated at 2022-06-23 01:08:49.575948
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    fips_facts._module = MagicMock()
    fips_facts._module.get_bin_path = MagicMock(return_value='/bin/true')
    fips_facts._module.run_command = MagicMock(return_value=(0, '1'))
    fips_facts.collect()
    assert fips_facts.fips == True

# Generated at 2022-06-23 01:08:56.655704
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = MagicMock()
    mock_collected_facts = MagicMock()

    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert 'fips' in facts
    assert facts['fips'] == False

# Generated at 2022-06-23 01:08:58.847080
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector_obj = FipsFactCollector()
    data = fact_collector_obj.collect()
    assert isinstance(data, dict)

# Generated at 2022-06-23 01:09:05.742203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    # TODO: Need to mock file
    fips_dict = fips.collect()
    assert "fips" in fips_dict

# Generated at 2022-06-23 01:09:10.212488
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj1 = FipsFactCollector()
    assert obj1.name == 'fips'
    assert obj1._fact_ids == set()

# Generated at 2022-06-23 01:09:12.525819
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module_info_ob = FipsFactCollector()
    assert module_info_ob.name == 'fips'

# Generated at 2022-06-23 01:09:14.487595
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect = FipsFactCollector().collect
    assert FipsFactCollector().collect() == {"fips": False}

# Generated at 2022-06-23 01:09:16.997392
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    inst = FipsFactCollector()
    assert isinstance(inst, FipsFactCollector)
    assert inst.name == 'fips'

# Generated at 2022-06-23 01:09:19.369763
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:09:22.238292
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:25.506787
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module_instance = ansible_module(PyModule=FipsFactCollector)
    assert ansible_module_instance.fips() == {'fips': False}

# Generated at 2022-06-23 01:09:28.912375
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:31.612737
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector
    module = None
    collected_facts = None
    fips_facts = collector.collect(module, collected_facts)
    assert fips_facts is not None

# Generated at 2022-06-23 01:09:33.669843
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:09:44.582829
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content_mock(fname):
        return "1"

    import sys
    if sys.version_info[:2] == (2, 6):
        import __builtin__ as builtins
    else:
        import builtins
    backed_up = builtins.__dict__.get('open')
    builtins.__dict__['open'] = get_file_content_mock

    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': True}

    builtins.__dict__['open'] = get_file_content_mock

    def get_file_content_mock(fname):
        return "0"

    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': False}

    builtins.__

# Generated at 2022-06-23 01:09:45.596544
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:47.814246
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector(None)
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:09:52.755082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    fipsfc = FipsFactCollector()
    collected_facts = {}
    fips_facts = fipsfc.collect(collected_facts=collected_facts)
    # Verify the facts returned
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:09:55.880786
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert isinstance(fips_facts, dict)
    assert fips_facts.get('fips') is not None

# Generated at 2022-06-23 01:09:57.523697
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts['fips'] is True

# Generated at 2022-06-23 01:10:02.386753
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    # Get return of the method
    data = obj.collect()
    # Get keys of the return
    keys = data.keys()
    # Check if the keys are real
    assert 'fips' in keys

# Generated at 2022-06-23 01:10:03.939369
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:10:05.333532
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:07.328545
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert 'fips' in fips._fact_ids

# Generated at 2022-06-23 01:10:10.136664
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    print('Testing constructor of FipsFactCollector')
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:10:13.669889
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {}
    fips_collector._get_file_content = lambda x: '1'
    assert fips_collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:10:16.418974
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips.priority == 80
    assert not fips._fact_ids
    assert 'fips' in fips.collect()

# Generated at 2022-06-23 01:10:20.403846
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:10:22.750452
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:10:25.514330
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ssh_fs = FipsFactCollector()
    fips_facts = ssh_fs.collect()
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-23 01:10:27.686512
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:10:30.623179
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector(None)
    data = fips_collector.collect(collected_facts={})
    assert not data.get('fips')

# Generated at 2022-06-23 01:10:34.051001
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_f = FipsFactCollector()
    assert fips_f.name == 'fips'
    assert fips_f._fact_ids == set()


# Generated at 2022-06-23 01:10:37.863893
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Constructor of FipsFactCollector should return an object with the attributes:
    # name
    # _fact_ids
    # collect()
    #
    # The collect() function should return a boolean

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert hasattr(fips_fact_collector, 'name')
    assert fips_fact_collector.name == 'fips'
    assert hasattr(fips_fact_collector, '_fact_ids')
    assert hasattr(fips_fact_collector, 'collect')
    fips_facts = fips_fact_collector.collect()
    assert fips_facts
    assert fips_facts['fips']

# Generated at 2022-06-23 01:10:46.591960
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case data
    fips_enabled_content = '1'
    fips_disabled_content = '0'

    # Create a class instance
    fips_fact_collector = FipsFactCollector()

    # Construct a mock_module with a mocked get_file_content method
    mock_module = type('module', (object,), {'get_file_content': lambda x: fips_enabled_content})()

    # Test case when fips is enabled
    fips_facts = fips_fact_collector.collect(mock_module)
    assert fips_facts['fips'] is True

    # Test case when fips is disabled
    mock_module = type('module', (object,), {'get_file_content': lambda x: fips_disabled_content})()
    fips_facts = fips

# Generated at 2022-06-23 01:10:48.849617
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-23 01:10:55.637439
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Valid
    fips_result = fips_fact_collector.collect({}, {})
    assert fips_result['fips'] is False
    fips_result = fips_fact_collector.collect({}, {'fips': True})
    assert fips_result['fips'] is True
    fips_result = fips_fact_collector.collect({}, {'fips': False})
    assert fips_result['fips'] is False

# Generated at 2022-06-23 01:11:01.839603
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test case for method collect of class FipsFactCollector"""
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    fips = False
    if data and data == '1':
        fips = True
    result = FipsFactCollector()
    result.collect()
    assert fips == result.collect()['fips']

# Generated at 2022-06-23 01:11:03.608279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:11:05.949393
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    r1 = FipsFactCollector()
    assert r1.collect({}) == {'fips': False}

# Generated at 2022-06-23 01:11:08.293759
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    myClass = FipsFactCollector()
    assert myClass.name == 'fips'
    assert myClass._fact_ids == set()

# Generated at 2022-06-23 01:11:09.280743
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:11.051984
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc_obj = FipsFactCollector()
    assert fips_fc_obj != None

# Generated at 2022-06-23 01:11:11.688318
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:11:15.050603
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = type('', (), {})
    collected_facts = {}
    collector = FipsFactCollector(module, collected_facts)
    results = collector.collect()
    assert results['fips'] == False

# Generated at 2022-06-23 01:11:17.014444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect() == {'fips': True}

# Generated at 2022-06-23 01:11:25.118415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test fips_facts collection with mocked data"""
    mock_module = Mock()
    mock_module.params = {'gather_subset': [],
                          'gather_timeout': 10,
                          'filter': '*'}
    fips_collector = FipsFactCollector(mock_module)
    collected_facts = {}
    fips_collector.collect(module=mock_module, collected_facts=collected_facts)
    assert collected_facts['fips'] == False


# Generated at 2022-06-23 01:11:27.536556
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m = FipsFactCollector()
    res = m.collect()
    assert type(res) is dict
    assert res['fips'] is True or res['fips'] is False

# Generated at 2022-06-23 01:11:30.441861
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_return = fips_fact_collector.collect()
    assert 'fips' in fips_return

# Generated at 2022-06-23 01:11:31.954471
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:11:34.448620
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:11:38.970327
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Unit test for FipsFactCollector"""
    # get an instance
    test_fact = FipsFactCollector()
    # assert the name
    assert test_fact.name == 'fips'
    # assert the fact_ids
    assert test_fact._fact_ids == set()
    # assert the collect function
    assert test_fact.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:41.463787
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert isinstance(obj._fact_ids, set)
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:11:43.143806
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-23 01:11:44.697020
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'


# Generated at 2022-06-23 01:11:45.566030
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:11:46.736120
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:48.202899
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:50.240437
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts_collector = FipsFactCollector()
    result = facts_collector.collect()
    assert result['fips'] == False


# Generated at 2022-06-23 01:11:55.581048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test the method FipsFactCollector.collect."""
    collector = FipsFactCollector()
    collected_facts = collector.collect(collected_facts=None)
    assert collected_facts == {
        'fips': False
    }

# Generated at 2022-06-23 01:12:06.828024
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mocked_fips = '1'
    mocked_data = {'fips': True}

    class MockedF(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

        def close(self):
            pass

    MockedFile = MockedF(mocked_fips)

    call_count = 0

    def mocked_open(path, mode, *args, **kwargs):
        nonlocal call_count
        # This is used instead of get_file_content()
        if path == '/proc/sys/crypto/fips_enabled':
            call_count += 1
            return MockedFile
        # This is used to find the FIPS modules
        elif path == '/proc/modules':
            return MockedFile

# Generated at 2022-06-23 01:12:09.110095
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc
    assert ffc.name == 'fips'


# Generated at 2022-06-23 01:12:10.062315
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:12:12.131325
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    c = FipsFactCollector()
    assert c.name == 'fips'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:12:14.653447
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {}
    FipsFactCollector = FipsFactCollector()
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:12:21.138577
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    collected_facts = {}
    f.collect(collected_facts=collected_facts)
    print("collected_facts obtained:")
    print(collected_facts)
    assert 'fips' in collected_facts

if __name__ == "__main__":
    test_FipsFactCollector_collect()

# Generated at 2022-06-23 01:12:31.042133
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import os
    import tempfile
    fact_collector = FactCollector()

    test_fips_file = tempfile.NamedTemporaryFile(mode='w+')
    test_fips_file.write('0\n')
    test_fips_file.seek(0)
    os.environ['PATH'] = "%s:%s" % (os.path.dirname(test_fips_file.name), os.environ.get('PATH', ''))
    os.environ['LANG'] = 'C'

    facts = fact_collector.collect(module=None, collected_facts=None)

    assert 'fips' in facts
    assert not facts['fips']

    test_fips_file.close()

    test_f

# Generated at 2022-06-23 01:12:33.436224
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    facts = fc.collect()
    assert 'fips' in facts.keys()
    assert facts['fips'] is False
    assert facts['fips'] is not None

# Generated at 2022-06-23 01:12:36.475383
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: This is a stub function.  Replace this with a fully functional
    # test
    assert True

# Generated at 2022-06-23 01:12:41.834073
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_facts = FipsFactCollector_obj.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)


# Generated at 2022-06-23 01:12:44.109494
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    try:
        fips_fct = FipsFactCollector()
    except:
        assert False
    assert True

# Generated at 2022-06-23 01:12:46.594698
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:12:48.725539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fc.collect()
    assert False


# Generated at 2022-06-23 01:12:49.798799
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.collect()['fips'] is False

# Generated at 2022-06-23 01:12:52.402276
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert len(fips_collector._fact_ids) == 0

# Generated at 2022-06-23 01:12:54.210842
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """ Test case for constructor of FipsFactCollector
    """

    fips = FipsFactCollector()
    assert fips 


# Generated at 2022-06-23 01:12:59.548062
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Initialize FipsFactCollector object
    fips_fact = FipsFactCollector()

    # Initialize object to store {'fips': False}
    dict_value = {'fips': False}

    # Test name
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()
    assert fips_fact.collect() == dict_value

# Generated at 2022-06-23 01:13:00.868907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect(None, {}) == {'fips': False}

# Generated at 2022-06-23 01:13:05.112233
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()

    # Assert that the name of the instance is set as expected
    assert ffc.name == 'fips'
    # Assert that the constructor does not set any of the facts collected by the fact collector
    assert not ffc._fact_ids

# Generated at 2022-06-23 01:13:10.205282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) == bool
    assert type(fips_facts.keys()) == list
    assert type(fips_facts.values()) == list
    assert type(fips_facts.items()) == list

# Generated at 2022-06-23 01:13:12.978106
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector(None, None)
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:13:15.082263
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-23 01:13:25.582021
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_file = dict()
    fips_file['exists'] = True
    fips_file['content'] = '1'

    mock_module = Mock(params={})
    mock_module.get_bin_path.return_value = None
    mock_module.get_file_content.return_value = fips_file

    mock_module.run_command.return_value = (0, '', '')

    fact_collector = FipsFactCollector()
    facts = fact_collector.collect(module=mock_module, collected_facts=None)
    assert facts['fips'] is True

    fips_file['content'] = '0'
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect(module=mock_module, collected_facts=None)

# Generated at 2022-06-23 01:13:28.384816
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:13:30.257576
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-23 01:13:32.182884
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:13:35.906978
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   fips_fact_collector = FipsFactCollector()
   assert fips_fact_collector.name == 'fips'
   assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:13:37.312876
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:13:39.505630
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:13:50.500289
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec = dict(gather_subset=dict(default=['!all', 'fips'], type='list'),
                             gather_timeout=dict(default=10, type='int'))
    )

    fips_enabled = False
    if os.path.exists('/proc/sys/crypto/fips_enabled'):
        fips_enabled = os.path.isfile('/proc/sys/crypto/fips_enabled')
    if fips_enabled:
        fd, path_fips = tempfile.mkstemp()

# Generated at 2022-06-23 01:13:51.979984
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector == type(FipsFactCollector())

# Generated at 2022-06-23 01:13:53.012378
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:58.289272
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create object of class FipsFactCollector
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    # Verify empty set
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:14:08.384749
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collection import FactCollectionManager
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from mock import MagicMock, patch

    collector = FipsFactCollector()

    # inject the method dependencies
    get_file_content = MagicMock()

    # set up
    files_content = {
        '/proc/sys/crypto/fips_enabled': '1'
    }

    def get_file_content_side_effect(file_path):
        return files_content[file_path]

    get_file_content.side_effect = get_file_content_side_effect

    # test

# Generated at 2022-06-23 01:14:12.226723
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    tested_module = FipsFactCollector()
    # Tested with a system not in FIPS-CC mode
    result = tested_module.collect(collected_facts={})
    assert result == {'fips': False}

# Generated at 2022-06-23 01:14:15.864118
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect()
    if collected_facts is None:
        assert False
    else:
        assert collected_facts['fips'] is False

# Generated at 2022-06-23 01:14:19.119972
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # create the class object
    instance = FipsFactCollector()

    # get the facts of the system
    facts = instance.collect()

    # check if the fips fact is present in the facts
    assert facts['fips']

# Generated at 2022-06-23 01:14:22.254151
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:30.520771
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_content = b'1'
    module = AnsibleModuleMock()
    fc = FipsFactCollector()
    fc.collect(module=module)
    module.get_file_content.assert_called_once_with('/proc/sys/crypto/fips_enabled')
    module.get_file_content.return_value = fips_content
    assert fc.collect(module=module)['fips'] is True
    fips_content = b'0'
    module.get_file_content.return_value = fips_content
    assert fc.collect(module=module)['fips'] is False
    fips_content = None
    module.get_file_content.return_value = fips_content

# Generated at 2022-06-23 01:14:32.412591
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'


# Generated at 2022-06-23 01:14:33.779546
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Unit tests are not supported under the network/common framework

    assert ()

# Generated at 2022-06-23 01:14:36.274387
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:14:38.352908
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()



# Generated at 2022-06-23 01:14:40.138465
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc.priority == 99
    assert ffc.fact_ids == set()

# Generated at 2022-06-23 01:14:42.973168
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == "fips"
    assert facts_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:47.010128
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == "fips"
    assert len(FipsFactCollector._fact_ids) == 0
    assert isinstance(FipsFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:14:50.893419
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:14:53.182314
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

# Generated at 2022-06-23 01:14:56.390015
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()
    assert isinstance(ffc.collect(), dict)

# Generated at 2022-06-23 01:14:59.008567
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:15:01.576975
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfc = FipsFactCollector()
    assert fipsfc.name == 'fips'
    assert fipsfc._fact_ids == set()



# Generated at 2022-06-23 01:15:03.629522
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Requires root privileges to test /proc/sys/crypto/fips_enabled
    # Does not work with a mocking framework because it reads a file
    pass

# Generated at 2022-06-23 01:15:04.000512
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:15:06.366043
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert hasattr(fips_collector, 'collect')

# Generated at 2022-06-23 01:15:07.693099
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass


# Generated at 2022-06-23 01:15:11.468616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = {
        'fips': False
    }
    assert fips_collector.collect(collected_facts=fips_facts) == {'fips': False}

# Generated at 2022-06-23 01:15:22.482540
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test the method FipsFactCollector.collect of the class FipsFactCollector
    """
    # Test content of /proc/sys/crypto/fips_enabled
    content_proc1 = {'path': '/proc/sys/crypto/fips_enabled', 'content': '1'}

    FipsFactCollector_instance = FipsFactCollector()
    FipsFactCollector_instance.files_dict = {'proc': [content_proc1]}

    assert FipsFactCollector_instance.collect() == {'fips': True}

    # Test content of /proc/sys/crypto/fips_enabled
    content_proc2 = {'path': '/proc/sys/crypto/fips_enabled', 'content': '0'}

    FipsFactCollector_instance = FipsFactCollector()


# Generated at 2022-06-23 01:15:28.950009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    def mock_get_file_content(file):
        content = None
        if file == '/proc/sys/crypto/fips_enabled':
            content = '1'
        return content

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    builtins.open = open
    builtins.get_file_content = mock_get_file_content
    collected_facts = {'kernel': 'Linux'}
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect(collected_facts=collected_facts)
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:15:31.404555
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:15:36.119299
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:15:37.892780
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test = FipsFactCollector()
    result = test.collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:15:41.154756
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
	fips = FipsFactCollector()
	assert fips.name == 'fips'
	assert fips._fact_ids == set()


# Generated at 2022-06-23 01:15:42.817588
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:15:44.126113
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test method collect of class FipsFactCollector"""
    pass

# Generated at 2022-06-23 01:15:45.795154
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'

# Generated at 2022-06-23 01:15:50.080867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {
                'gather_subset': ['!all', 'hardware'],
                'gather_timeout': 10,
                'filter': '*'
            }
            self.fail_json = Mock(side_effect=Exception)

    test_fipsFactCollector = FipsFactCollector()
    test_fipsFactCollector.collect(module=MockModule())

# Generated at 2022-06-23 01:15:59.553015
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class FipsFactCollector_collect_TestModule(object):
        def __init__(self, return_fips_enabled):
            self.return_fips_enabled = return_fips_enabled

        def get_file_content(self, path):
            self.path = path
            return self.return_fips_enabled

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.collector

    temp_BaseFactCollector_get_collector_classes = BaseFactCollector.get_collector_classes
    BaseFactCollector.get_collector_classes = lambda self: [FipsFactCollector]

    test_collector = FipsFactCollector()
    test_module

# Generated at 2022-06-23 01:16:03.188386
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  f = FipsFactCollector()
  assert f.name == 'fips'
  assert f._fact_ids == set()


# Generated at 2022-06-23 01:16:04.077676
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == "fips"

# Generated at 2022-06-23 01:16:09.006022
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #from ansible.module_utils.facts.collector import FipsFactCollector
    fips_facts_collector_obj = FipsFactCollector()
    fips_facts = fips_facts_collector_obj.collect()
    assert fips_facts['fips'].__class__ == bool

# Generated at 2022-06-23 01:16:12.094431
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = dict()
    result = fips.collect(collected_facts=facts)
    assert result == {'fips': False}

# Generated at 2022-06-23 01:16:14.475569
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:16:17.456163
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:21.317187
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    print('FipsFactCollector object created successfully')


# Generated at 2022-06-23 01:16:22.742634
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    s = FipsFactCollector()
    assert s != None

# Generated at 2022-06-23 01:16:25.182972
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:16:25.765255
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:16:27.969763
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:16:30.357626
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    test_facts = fips_collector.collect()

    assert test_facts['fips'] is not None

# Generated at 2022-06-23 01:16:32.217933
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:16:37.126987
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    testvectors = [
        ('fips', """1""", True),
        ('fips', """0""", False)
    ]

    for (key, data, expected) in testvectors:
        fc = FipsFactCollector(None)
        fc._get_file_content_mock = lambda path: data
        result = fc.collect()
        assert result[key] == expected

# Generated at 2022-06-23 01:16:40.474335
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    if module._socket_path:
        # Ansible 2.3+
        testobj = FipsFactCollector()
    else:
        # Ansible 2.2 and older
        testobj = FipsFactCollector(module=module, collected_facts={})
    facts = testobj.collect(module=module, collected_facts={})
    assert 'fips' in facts

# Generated at 2022-06-23 01:16:42.702408
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:16:44.510870
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()



# Generated at 2022-06-23 01:16:46.585347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert result == {'fips': False}

# Generated at 2022-06-23 01:16:49.720940
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_name = 'fips'
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == expected_name
    assert isinstance(fips_fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:16:52.397888
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mod = None
    collected_facts = None
    FipsFactCollector().collect(mod, collected_facts)

# Generated at 2022-06-23 01:16:56.637714
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    collector = Collector()
    assert collector
    fips = collector.collect_fips()
    assert isinstance(fips, dict)

    #assert fips
    #assert fips['fips'] is False

# Generated at 2022-06-23 01:16:59.223215
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_facts = FipsFactCollector().collect(module, collected_facts)
    assert isinstance(fips_facts, dict)
    assert fips_facts == { u'fips': False }

# NOTE: this is just a generic test to see how the collector works
# An actual unit test should check the file content, but this requires
# mocking the function get_file_content (possible to do with setUp)

# Generated at 2022-06-23 01:17:03.070114
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class_name = 'ansible.module_utils.facts.system.fips.FipsFactCollector'
    module_base_path = 'ansible.module_utils.facts'
    class_object = FipsFactCollector()
    expected_result = "{'fips': False}"
    result = class_object.collect()
    assert str(result) == expected_result

# Generated at 2022-06-23 01:17:05.457017
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert set(fips._fact_ids) == set(['fips'])

# Generated at 2022-06-23 01:17:16.388470
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test1_data = ""
    test1_data_expected = {u'fips': False}
    test2_data = "1"
    test2_data_expected = {u'fips': True}

    fips_collector = FipsFactCollector()
    fips_collector._module = AnsibleMockModule()
    fips_collector._module.get_file_content = get_file_content_mock
    fips_collector._module.get_file_content.side_effect = test1_data
    assert fips_collector.collect() == test1_data_expected
    fips_collector._module.get_file_content.side_effect = test2_data
    assert fips_collector.collect() == test2_data_expected


# Generated at 2022-06-23 01:17:26.926968
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        def __init__(self, *args, **kwargs):
            self.was_called = False
            super(MockCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            self.was_called = True

    collector = Collector()

# Generated at 2022-06-23 01:17:34.731552
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    m = pytest.importorskip("ansible.module_utils.facts.collector")
    mock_module = m.AnsibleModule(argument_spec={})
    mock_base_fact_collector = m.BaseFactCollector(module=mock_module)
    mock_fips_fact_collector = m.FipsFactCollector(module=mock_module)
    mock_facts = {}
    result = mock_fips_fact_collector.collect(module=mock_module, collected_facts=mock_facts)
    assert result == {'fips': False}

# Generated at 2022-06-23 01:17:41.959424
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, FipsFactCollector)
    assert fips_fact_collector.name == 'fips'

    # Check the list of facts is created correctly for this collector
    assert 'fips' in fips_fact_collector._fact_ids
    assert fips_fact_collector._fact_ids == {'fips'}


# Generated at 2022-06-23 01:17:45.807284
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:17:46.455562
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:17:49.892245
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:17:54.692847
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict), 'collect should return a dict'
    assert 'fips' in fips_facts, 'collect should return a dict with key fips'

# Generated at 2022-06-23 01:17:56.740228
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == "fips"
    assert fips_obj._fact_ids == set()

# Generated at 2022-06-23 01:18:01.126347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {'fips': False}
    module = ""
    collected_facts = {}
    collector = FipsFactCollector()
    test_facts = {}
    test_facts = collector.collect(module,collected_facts)
    assert test_facts == fips_facts

# Generated at 2022-06-23 01:18:05.317432
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert not fc._fact_ids
    assert fc.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:08.100203
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:18:10.545780
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert isinstance(FipsFactCollector._fact_ids, set)


# Generated at 2022-06-23 01:18:12.133167
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_class = FipsFactCollector()
    assert test_class.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:15.506237
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:18:16.162425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:18:24.800257
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_data = {'fips': False}
    fips_data['module'] = None
    fips_data['collector'] = FipsFactCollector()

    with mock.patch('ansible.module_utils.facts.utils.get_file_content') as mock_get_file_content:
        mock_get_file_content.return_value = '1'
        result = FipsFactCollector().collect(fips_data['module'], fips_data)
        assert result['fips'] == True
        mock_get_file_content.assert_called_once_with('/proc/sys/crypto/fips_enabled')

    with mock.patch('ansible.module_utils.facts.utils.get_file_content') as mock_get_file_content:
        mock_get_file_content

# Generated at 2022-06-23 01:18:31.162030
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect(None, None)
    assert ffc.name is not None
    assert ffc._fact_ids == set(['fips'])

# Generated at 2022-06-23 01:18:35.544158
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == False
    # NOTE: this is populated even if it is not set
    assert fips.collect()['fips'] == False

# Generated at 2022-06-23 01:18:37.657689
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:18:39.382149
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:18:41.091267
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

# Generated at 2022-06-23 01:18:45.260813
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = {'fips':True}
    assert fips_facts == fips_fact_collector.collect()
    fips_facts = {'fips':False}
    assert fips_facts == fips_fact_collector.collect()