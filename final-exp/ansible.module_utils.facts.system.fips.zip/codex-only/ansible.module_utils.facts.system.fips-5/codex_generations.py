

# Generated at 2022-06-23 01:08:43.364335
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_data = FipsFactCollector().collect()
    assert 'fips' in fact_data and isinstance(fact_data['fips'], bool)

# Generated at 2022-06-23 01:08:47.012114
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    facts = f.collect()
    assert facts['fips'] == False

# Generated at 2022-06-23 01:08:48.466916
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert type(fips_facts['fips']) == bool

# Generated at 2022-06-23 01:08:51.904225
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:08:53.940307
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == "fips"
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:08:56.548300
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:08:59.539875
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts._fact_ids == set(), "default fact_ids should be empty"
    assert fips_facts.name == 'fips'


# Generated at 2022-06-23 01:09:06.151490
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = False
    collected_facts = {}
    fipscollector = FipsFactCollector()
    assert fipscollector.collect(module, collected_facts) == {'fips': False}

# Generated at 2022-06-23 01:09:13.922415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # NOTE: this module is not running in a real Ansible execution and therefore the
    # module argument is not filled and can not be used
    # In this case module argument is set to None
    assert(fips_fact_collector.collect(module=None, collected_facts=None))


# Generated at 2022-06-23 01:09:16.643278
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    facts = f.collect()
    assert 'fips' in facts

# Generated at 2022-06-23 01:09:18.618240
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector

# Generated at 2022-06-23 01:09:20.922304
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    result = fips_facts.collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:09:30.845288
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import FactNotFoundError
    from ansible.module_utils.facts.collector import default_collectors
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content
    #
    #  Expected fact
    expected_collector_instance = get_collector_instance(FipsFactCollector)
    #  Test the good case
    result_collector_instance = get_collector_instance(FipsFactCollector)

# Generated at 2022-06-23 01:09:33.548920
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector =FipsFactCollector()
    assert collector.name == 'fips'

# Generated at 2022-06-23 01:09:40.156319
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    file_data = '''
0
1
    '''
    lines = file_data.split('\n')
    collected_facts = {}
    FipsFactCollector().collect(module=None, collected_facts=collected_facts)
    for i in lines:
        if i == '0':
            assert collected_facts['fips'] == False
        if i == '1':
            assert collected_facts['fips'] == True

# Generated at 2022-06-23 01:09:42.278239
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == dict(fips=True)

# Generated at 2022-06-23 01:09:44.655960
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None


# Generated at 2022-06-23 01:09:46.136429
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:09:49.478652
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # create an empty fips_facts dictionary
    fips_facts = {}
    # check for fips mode in the system
    fips_facts = fips_fact_collector.collect(None, fips_facts)
    assert fips_facts['fips'] == True or fips_facts['fips'] == False

# Generated at 2022-06-23 01:09:57.730749
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create instance of class FipsFactCollector
    test_instance = FipsFactCollector()
    assert test_instance
    assert isinstance(test_instance, FipsFactCollector)
    assert hasattr(test_instance, 'name')
    assert hasattr(test_instance, '_fact_ids')
    assert isinstance(test_instance.name, str)
    assert test_instance.name == 'fips'
    assert not test_instance._fact_ids
    assert isinstance(test_instance._fact_ids, set)


# Generated at 2022-06-23 01:10:05.673138
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys

    if sys.version_info.major < 3:
        fips_collector = FipsFactCollector()
    else:
        fips_collector = FipsFactCollector()
    assert isinstance(fips_collector, FipsFactCollector)
    assert isinstance(fips_collector, BaseFactCollector)
    assert isinstance(fips_collector, Collector)

# Generated at 2022-06-23 01:10:07.407147
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:10:12.078458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_file_content = '1'
    collect = FipsFactCollector()
    test_result = collect.collect(None, None)
    assert test_result['fips'] == True

    test_file_content = '0'
    collect = FipsFactCollector()
    test_result = collect.collect(None, None)
    assert test_result['fips'] == False

# Generated at 2022-06-23 01:10:13.370625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:15.166048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert  FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:10:20.832706
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    firstFipsFactCollector = FipsFactCollector
    firstFacts = firstFipsFactCollector.collect()
    assert firstFacts["fips"] == False

    secondFipsFactCollector = FipsFactCollector
    secondFacts = secondFipsFactCollector.collect()
    assert secondFacts["fips"] == True


# Generated at 2022-06-23 01:10:23.605728
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids is not None


# Generated at 2022-06-23 01:10:27.499805
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Instantiate class
    fips_fact_collector = FipsFactCollector()
    # Run method collect
    fact_list = fips_fact_collector.collect()
    assert(fact_list["fips"] is False)

# Main function

# Generated at 2022-06-23 01:10:29.035742
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-23 01:10:30.384946
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert(FipsFactCollector.collect()['fips'] == False)

# Generated at 2022-06-23 01:10:36.177724
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Returned object
    fips_obj = FipsFactCollector()
    #
    # First time when collect() is executed, fips_facts is empty, but
    # after next execution of collect(), fips_facts contains
    # information about fips mode.
    #
    assert not fips_obj.collect()
    assert fips_obj.collect()

# Generated at 2022-06-23 01:10:37.126063
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:10:37.629709
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:40.264688
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-23 01:10:40.775429
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:44.307021
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-23 01:10:45.215392
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:10:46.875044
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False


# Generated at 2022-06-23 01:10:49.101545
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert 'fips' in f._fact_ids


# Generated at 2022-06-23 01:10:53.303315
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    if x.name != 'fips':
        raise Exception('Unexpected FipsFactCollector.name value')
    if x._fact_ids != set():
        raise Exception('Unexpected FipsFactCollector._fact_ids value')


# Generated at 2022-06-23 01:10:55.448271
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    # Ensure that method collect returns only fips fact
    assert len(FipsFactCollector.collect()) == 1

# Generated at 2022-06-23 01:11:03.428818
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()

    # Test collect with a Fips system
    fips_system = {'fips_enabled': '1'}
    fips_facts = fact_collector.collect(None, fips_system)
    assert fips_facts['fips']

    # Test collect without a Fips system
    fips_system = {'fips_enabled': '0'}
    fips_facts = fact_collector.collect(None, fips_system)
    assert not fips_facts['fips']

# Generated at 2022-06-23 01:11:06.606772
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()


# Generated at 2022-06-23 01:11:08.135674
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:11:09.136410
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:11:12.776102
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    obj = FipsFactCollector()
    name = obj.name
    assert name == 'fips', name

    fact_ids = obj._fact_ids
    assert fact_ids is not None, fact_ids



# Generated at 2022-06-23 01:11:15.542760
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test FipsFactCollector class"""
    f_FipsFactCollector = FipsFactCollector()
    assert f_FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:11:18.006541
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:11:20.347469
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert hasattr(FipsFactCollector, '_fact_ids')
    assert callable(FipsFactCollector)

# Generated at 2022-06-23 01:11:22.640529
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = set()
    FipsFactCollector(fips_facts)
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:11:25.324194
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector_obj1 = FipsFactCollector()
    assert fips_fact_collector_obj1.name == 'fips'

# Generated at 2022-06-23 01:11:27.412299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-23 01:11:29.124787
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert 'fips' in facts

# Generated at 2022-06-23 01:11:37.651666
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class MockFacts(object):
        def populate(self, module):
            self.facts = module.params['ansible_facts']

    import ansible.module_utils.facts.collector.fips
    mod = MockModule(ansible_facts={})
    facts_obj = MockFacts()
    ansible.module_utils.facts.collector.fips.FipsFactCollector()(mod)
    facts_obj.populate(mod)
    return facts_obj.facts['fips']

# Generated at 2022-06-23 01:11:45.156222
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file_content = '1'

    def mock_get_file_content(file_path):
        if file_path == '/proc/sys/crypto/fips_enabled':
            return fips_file_content

    mock_module = type('AnsibleModule', (), {})
    mock_module.get_file_content = mock_get_file_content

    fips_fact_collector = FipsFactCollector()
    ansible_facts = {}
    fips_fact_collector.collect(module=mock_module, collected_facts=ansible_facts)

    assert ansible_facts
    assert ansible_facts['fips'] == True

# Generated at 2022-06-23 01:11:46.807527
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'

# Generated at 2022-06-23 01:11:48.475745
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()

    assert collector.collect() == {'fips': True}

# Generated at 2022-06-23 01:11:50.287463
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfc = FipsFactCollector()
    assert fipsfc.name == 'fips'
    assert fipsfc._fact_ids == set()

# Generated at 2022-06-23 01:11:52.524246
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:12:03.520181
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ''' unit testing for method collect of class FipsFactCollector '''

    from ansible.module_utils.facts.system.fips import FipsFactCollector

    ansible_info = dict()
    ansible_info_mock = dict(ansible_info)
    ansible_info_mock['module'] = Mock()
    ansible_info_mock['module'].get_bin_path = Mock()

    fips = FipsFactCollector(ansible_info_mock, None)
    assert fips.collect() == dict(fips=False)
    ansible_info_mock['module'].get_file_content = Mock(return_value='1')
    assert fips.collect() == dict(fips=True)

# Generated at 2022-06-23 01:12:07.890888
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_collector = FipsFactCollector()
    res = fips_collector.collect(module, collected_facts)
    assert type(res) is dict
    assert 'fips' in res
    assert type(res['fips']) is bool

# Generated at 2022-06-23 01:12:11.517354
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    FipsFactCollector = FipsFactCollector()

    assert FipsFactCollector.collect() in (True, False)

# Generated at 2022-06-23 01:12:16.558348
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    "Unit test for FipsFactCollector.collect()"
    with open('/proc/sys/crypto/fips_enabled', 'w') as fp:
        fp.write('0')

    assert FipsFactCollector().collect() == {'fips': False}

    with open('/proc/sys/crypto/fips_enabled', 'w') as fp:
        fp.write('1')
    assert FipsFactCollector().collect() == {'fips': True}

# Generated at 2022-06-23 01:12:19.554796
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    k = FipsFactCollector()
    assert k.name == 'fips'
    assert k._fact_ids == set()



# Generated at 2022-06-23 01:12:21.634630
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fc.collect()

# Generated at 2022-06-23 01:12:23.800823
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fake_module = None
    fake_collector = FipsFactCollector(fake_module)
    fake_collector.collect()

# Generated at 2022-06-23 01:12:26.391922
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result == {'fips': False}

# Generated at 2022-06-23 01:12:28.440921
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    data = fips.collect()
    assert 'fips' in data


# Generated at 2022-06-23 01:12:30.497533
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    first_fact = FipsFactCollector().collect()
    assert first_fact['fips'] is True or first_fact['fips'] is False

# Generated at 2022-06-23 01:12:32.548710
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids

# Generated at 2022-06-23 01:12:36.530943
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:12:40.946031
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-23 01:12:49.702006
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test collect method of FipsFactCollector.

    :return: None
    """
    from ansible.module_utils.facts.collector import get_collector_instance
    class MockModule:
        def run(self):
            content = '1'
            self.run_command = lambda x: (0, content, '', None)
    module = MockModule()
    test_fips = get_collector_instance(FipsFactCollector, module=module)
    test_fips.collect()
    assert module.run_command.called
    assert module.run_command.call_count == 1


# Generated at 2022-06-23 01:12:51.504321
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == False

# Generated at 2022-06-23 01:12:53.353867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-23 01:12:58.303422
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts import timeout

    ac = AnsibleCollector(module=None, collected_facts=None, timeout=timeout)

    ffc = FipsFactCollector()
    ac.add_collector(ffc)
    res = ac.collect(module=None, collected_facts=None)
    assert isinstance(res, dict)
    assert res['fips'] is False or res['fips'] is True

# Generated at 2022-06-23 01:12:59.082366
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:02.722049
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.__name__ == 'FipsFactCollector'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:13:04.800796
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    ret = fips_collector.collect()
    assert ret == {'fips': False}

# Generated at 2022-06-23 01:13:15.014627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file_path = "/tmp/module_util_facts_fips"
    test_cases = [
        # test_case, expected_output
        (None, {'fips': False}),
        ('1', {'fips': True}),
        ('0', {'fips': False}),
        ('2', {'fips': False}),
        ('1\n', {'fips': True}),
        ('randomtext', {'fips': False})
    ]
    mock_module_util_facts_fips = MagicMock(side_effect=[fips_file_path])
    mocked_open = mock_open(read_data=None)

# Generated at 2022-06-23 01:13:16.703106
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)


# Generated at 2022-06-23 01:13:19.440843
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollectorTest = FipsFactCollector()
    FipsFactCollectorTest.collect = FipsFactCollector.collect
    FipsFactCollectorTest.collect() # noqa

# Generated at 2022-06-23 01:13:22.057729
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()



# Generated at 2022-06-23 01:13:23.855737
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:13:27.960952
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:13:30.206630
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() is not None

# Generated at 2022-06-23 01:13:31.144299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:13:33.135822
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    assert fips_fact.collect()

# Generated at 2022-06-23 01:13:45.467314
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    if not hasattr(FipsFactCollector, "collect"):
        pytest.skip("Could not run test_FipsFactCollector_collect, because there is no collect method.")

    module = None
    collected_facts = None
    fact_collector = FipsFactCollector()

    # These are not really used so just mock them out
    def mock_get_file_content(path):
        return "1"
    def mock_get_file_content_off(path):
        return "0"
    def mock_get_file_content_notexist(path):
        raise Exception("notexist")
    fact_collector.get_file_content = mock_get_file_content
    facts = fact_collector.collect(module, collected_facts)
    assert facts is not None
    assert "fips" in facts


# Generated at 2022-06-23 01:13:55.467141
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    my_FipsFactCollector = FipsFactCollector()
    my_FipsFactCollector._module = None
    my_FipsFactCollector._client = None
    my_FipsFactCollector._cache = {}
    my_FipsFactCollector._module_name = 'FipsFactCollector'

    # Test for empty file
    my_FipsFactCollector.get_file_content = get_file_content
    collected_facts = my_FipsFactCollector.collect()
    assert collected_facts == {'fips': False}

    # Test for file with data
    del my_FipsFactCollector._cache['FipsFactCollector']
    my_FipsFactCollector._cache['FipsFactCollector'] = '1'
    collected_facts = my_FipsFactCollector.collect()


# Generated at 2022-06-23 01:13:57.176893
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == "fips"


# Generated at 2022-06-23 01:14:00.290096
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-23 01:14:02.334342
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:14:06.769746
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_obj = FipsFactCollector()
    new_dict = fips_obj.collect(module, collected_facts)
    fips_dict = {
        "fips": True
    }
    assert (new_dict == fips_dict)

# Generated at 2022-06-23 01:14:10.153761
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    # Fips is disabled
    result = fc.collect()
    assert result == {'fips': False}


# Generated at 2022-06-23 01:14:11.955624
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:14:15.702787
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:14:17.066724
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), BaseFactCollector)

# Generated at 2022-06-23 01:14:20.560247
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'

# Generated at 2022-06-23 01:14:24.137449
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    global fips_fact_collector
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:27.223884
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:14:29.393569
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:14:32.139678
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert(fips_fact_collector.name == 'fips')


# Generated at 2022-06-23 01:14:33.151399
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:14:38.265618
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: same as collect for now
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert FipsFactCollector().collect() == fips_facts

# Generated at 2022-06-23 01:14:39.266295
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:14:40.503119
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:14:44.282984
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {}
    fact_collector.collect(collected_facts=collected_facts)
    assert 'fips' in collected_facts

# Generated at 2022-06-23 01:14:46.893217
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    result = FipsFactCollector().collect()
    if (result['fips'] != False) and (result['fips'] != True):
        assert False

# Generated at 2022-06-23 01:14:48.998834
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == dict(fips=False)

# Generated at 2022-06-23 01:14:51.403139
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:14:54.527842
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-23 01:14:56.885346
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:15:01.484469
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_collector = FipsFactCollector()
    mock_module = Mock()
    mock_collected_facts = Mock()
    test_collector.collect(mock_module, mock_collected_facts)
    assert mock_collected_facts.update.called

# ======
#  Mock
# ======


# Generated at 2022-06-23 01:15:05.925090
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    def mock_get_file_content(path):
        return '1'
    FipsFactCollector._get_file_content = mock_get_file_content
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips']

# Generated at 2022-06-23 01:15:07.514653
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect({}) == {'fips': False}

# Generated at 2022-06-23 01:15:08.593369
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:15:09.236400
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:15:11.737658
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fips = fc.collect(None, None)
    assert fips.get('fips') == False

# Generated at 2022-06-23 01:15:15.876418
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    if fips_facts['fips'] == False:
        print ("This system is not fips compliant")
    else:
        print ("This system is fips compliant")

# Generated at 2022-06-23 01:15:18.690717
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """ Test fact module as standalone """
    facts = FipsFactCollector()
    assert facts.name == 'fips'
    assert facts._fact_ids == set()

# Generated at 2022-06-23 01:15:20.507169
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import collector

    FipsFactCollector.collect(None, None)

# Generated at 2022-06-23 01:15:23.930755
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    fips_obj.collect()

# Generated at 2022-06-23 01:15:26.352748
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_test = FipsFactCollector()
    assert fips_test.name == 'fips'
    assert fips_test._fact_ids == set()


# Generated at 2022-06-23 01:15:32.869719
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Sample data
    fips_data = '1'
    nonfips_data = '0'

    # test with fips True
    fips_fc = FipsFactCollector()
    fips_fc._get_file_content = lambda x: fips_data
    fips_assert = fips_fc.collect()
    assert(fips_assert.get('fips'))
    # test with fips False
    nonfips_fc = FipsFactCollector()
    nonfips_fc._get_file_content = lambda x: nonfips_data
    nonfips_assert = nonfips_fc.collect()
    assert(not nonfips_assert.get('fips'))

# Generated at 2022-06-23 01:15:36.345703
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert 'fips' in fact_collector.name
    assert 'fips' in fact_collector._fact_ids


# Generated at 2022-06-23 01:15:38.538251
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:15:47.435240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Return fips_facts if FIPS is enabled
    """

    # GIVEN a file where FIPS is enabled
    fips_file = "/proc/sys/crypto/fips_enabled"
    fips_file_data = '1'
    fips_facts = {'fips': True}
    fips_expected_result = dict(ansible_facts=dict(fips=True))

    # WHEN FIPS is enabled
    fips_collector = FipsFactCollector({ fips_file: fips_file_data })
    fips_result = fips_collector.collect()

    # THEN the fips facts are returned
    assert fips_result == fips_expected_result


# Generated at 2022-06-23 01:15:50.657742
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  assert FipsFactCollector.name == 'fips'
  assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:15:52.894243
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipscollector = FipsFactCollector()
    assert fipscollector.name == 'fips'

# Generated at 2022-06-23 01:15:55.830455
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert 'fips' in facts.keys()
    assert type(facts['fips']) is bool

# Generated at 2022-06-23 01:15:58.856624
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_info = FipsFactCollector()
    assert fips_info.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:10.789111
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # verify that 'fips' is returned when fips is enabled
    import mock
    import os
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    get_file_content_orig = get_file_content
    get_file_content_mock = mock.MagicMock(name='get_file_content')
    get_file_content_mock.return_value = '1'
    get_file_content.side_effect = get_file_content_mock
    fips_facts = FipsFactCollector()
    fips_facts.collect()
    assert fips_facts.get_facts()['fips'] is True

# Generated at 2022-06-23 01:16:20.347825
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fc = FipsFactCollector()

    return_data={}
    return_data['ansible_fips'] = True
    fc._read_file_content = MagicMock(return_value=b'1')
    assert fc.collect() == return_data

    return_data['ansible_fips'] = False
    fc._read_file_content = MagicMock(return_value=b'0')
    assert fc.collect() == return_data

    # Should fail due to the exception
    fc._read_file_content = MagicMock(side_effect=IOError('File not found'))
    with pytest.raises(IOError):
        fc.collect()

# Generated at 2022-06-23 01:16:23.945360
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:16:25.806792
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'


# Generated at 2022-06-23 01:16:28.748715
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:32.377643
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    # Initialize required objects
    fips_collector = FipsFactCollector()

    # Unit testing with available fips file
    fips_fct = fips_collector.collect(module=None, collected_facts=None)
    assert fips_fct.get('fips')

# Generated at 2022-06-23 01:16:34.797551
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-23 01:16:36.860947
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    instance = FipsFactCollector()
    assert isinstance(instance.collect(), dict)
    assert isinstance(instance.collect()['fips'], bool)


# Generated at 2022-06-23 01:16:42.876283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    # test with data in /proc/sys/crypto/fips_enabled
    fips_facts = fips.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] == True


# Generated at 2022-06-23 01:16:53.262105
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import tempfile
    import sys
    import stat

    def _create_file(content):
        f = tempfile.NamedTemporaryFile(delete=False)
        f.write(content)
        f.close()
        os.chmod(f.name, stat.S_IRUSR)
        return f.name

    file_path = _create_file('1')
    os.rename(file_path, '/proc/sys/crypto/fips_enabled')
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] is True
    os.remove('/proc/sys/crypto/fips_enabled')

# Generated at 2022-06-23 01:16:55.224892
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-23 01:16:59.031361
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    Collector = FipsFactCollector()
    fips_facts = Collector.collect()
    assert 'fips' in fips_facts


# Generated at 2022-06-23 01:17:02.129633
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Run unit tests when '--unit' is given as a parameter
if __name__ == '__main__':
    import pytest
    pytest.main([__file__, "--unit"])

# Generated at 2022-06-23 01:17:08.667754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Return fips data if system is in fips mode or not."""
    from ansible.module_utils.facts import FactCollector

    facts_dirs = [os.path.dirname(__file__)]
    ffc = FactCollector(facts_dirs=facts_dirs)
    facts = ffc.collect()
    assert isinstance(facts, dict)
    assert 'fips' in facts
    assert facts['fips'] in [True, False]

# Generated at 2022-06-23 01:17:12.112650
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """unit test for constructor of class FipsFactCollector"""
    fact_collector_obj = FipsFactCollector()
    assert fact_collector_obj.name == 'fips'


# Generated at 2022-06-23 01:17:15.513909
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:17:16.936835
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'

# Generated at 2022-06-23 01:17:19.823071
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test collecting facts for fips.
    """
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-23 01:17:21.665062
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_object = FipsFactCollector()
    assert my_object.name == 'fips'
    assert my_object._fact_ids == set()

# Generated at 2022-06-23 01:17:22.391289
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:17:24.013389
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips_facts = fips_fact.collect()
    assert fips_facts['fips']

# Generated at 2022-06-23 01:17:26.925093
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:17:28.126306
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:17:31.578785
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:17:34.164718
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == "fips"
    assert fips_collector._fact_ids == set(['fips'])


# Generated at 2022-06-23 01:17:36.699114
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:17:45.214127
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with mock.patch('ansible.module_utils.facts.collector.get_file_content') as mock:
        mock.return_value = '1'
        fips_collector = FipsFactCollector()
        assert fips_collector.collect() == dict(fips=True)

    with mock.patch('ansible.module_utils.facts.collector.get_file_content') as mock:
        mock.return_value = '0'
        fips_collector = FipsFactCollector()
        assert fips_collector.collect() == dict(fips=False)

# Generated at 2022-06-23 01:17:47.008269
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == "fips"

# Generated at 2022-06-23 01:17:54.753077
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.utils import get_file_content

    FactCollector._collectors = {}
    fips_fact_collector = FipsFactCollector()
    content = '1'
    get_file_content = MagicMock(return_value=content)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

    content = '0'
    get_file_content = MagicMock(return_value=content)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

    content = None
    get_file_content = MagicMock(return_value=content)
    fips

# Generated at 2022-06-23 01:18:02.231892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module=object()
    expected_fips_facts = {'fips': True}
    test_FipsFactCollector = FipsFactCollector(mock_module)
    test_FipsFactCollector._read_file = lambda x: '1'
    fips_facts = test_FipsFactCollector.collect(mock_module)
    assert fips_facts == expected_fips_facts

# Generated at 2022-06-23 01:18:03.727582
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-23 01:18:07.653726
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    test_object = FipsFactCollector()
    test_data = '0' # Dummy value
    test_result = test_object.collect(module = None, collected_facts = None)
    assert test_result['fips'] == False # Verify that FipsFactCollector.collect outputs fips = False


# Generated at 2022-06-23 01:18:11.243469
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips']

# Generated at 2022-06-23 01:18:13.925139
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_factCollector = FipsFactCollector()
    assert fips_factCollector.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:16.958960
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_factCollector = FipsFactCollector()
    assert fips_factCollector.name == 'fips'
    assert not fips_factCollector._fact_ids

# Generated at 2022-06-23 01:18:18.962304
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fcollector = FipsFactCollector()
    assert fcollector.name == 'fips'
    assert fcollector._fact_ids == set()

# Generated at 2022-06-23 01:18:20.842914
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    m = FipsFactCollector()
    assert m.collect() == {'fips': False}
    return

# Generated at 2022-06-23 01:18:24.188993
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ check value of fips when fips is disabled """
    fips_fact = FipsFactCollector()
    result = fips_fact.collect(None, None)
    assert result['fips'] == False


# Generated at 2022-06-23 01:18:38.142265
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils.facts.collector.fips import get_file_content
    from ansible.module_utils._text import to_bytes
    import os

    def get_file_content_mock(filename):
        if os.path.basename(filename) == "fips_enabled" and os.path.isdir(os.path.dirname(filename)):
            return "1"

    os.path.isfile = lambda x: True

    with pytest.raises(TypeError):
        FipsFactCollector.collect()

    with pytest.raises(TypeError):
        FipsFactCollector.collect(collected_facts=None)


# Generated at 2022-06-23 01:18:43.141380
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Input data to be returned by the mocked method get_file_content
    test_data = [
        ('/proc/sys/crypto/fips_enabled', '1'),
    ]
    test_FipsFactCollector = FipsFactCollector()
    assert test_FipsFactCollector.collect(get_file_content=lambda x: test_data.pop(0)) == {'fips': True}