

# Generated at 2022-06-23 01:08:47.960420
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.collect()

# Generated at 2022-06-23 01:08:52.701748
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:09:03.015155
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    # noinspection PyProtectedMember
    test_fips_facts_collector = FipsFactCollector()
    # noinspection PyProtectedMember
    test_fips_facts_collector._read_file = lambda path: '1'
    assert test_fips_facts_collector.collect(collected_facts=None) == {'fips': True}
    # noinspection PyProtectedMember
    test_fips_facts_collector._read_file = lambda path: ''
    assert test_fips_facts_collector.collect(collected_facts=None) == {'fips': False}
    assert fips_facts_collector.collect(collected_facts=None) == {'fips': False}

# Generated at 2022-06-23 01:09:04.155961
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector._fact_ids is not None

# Generated at 2022-06-23 01:09:05.843574
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    f.collect()

# Generated at 2022-06-23 01:09:10.932416
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector_instance = FipsFactCollector()
    assert fact_collector_instance.name == 'fips'
    assert fact_collector_instance._fact_ids == set()

# Generated at 2022-06-23 01:09:11.923950
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:09:13.825630
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    try:
        fips_fc_obj = FipsFactCollector()
        assert True
    except:
        assert False

# Generated at 2022-06-23 01:09:15.924949
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:24.686813
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = Mock()
    mock_collected_facts = {'ansible_lsb': {'description': 'Ubuntu 16.04.4 LTS', 'distributor_id': 'Ubuntu', 'major_release': '16', 'release': '16.04'}}
    fc = FipsFactCollector(mock_module)

    with patch.object(fc, 'get_file_content') as mock_get_file_content:
        mock_get_file_content.return_value = None

        assert fc.collect(mock_module, mock_collected_facts) == {'fips': False}

# Generated at 2022-06-23 01:09:30.188458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    ansible_facts = {}
    ansible_facts['fips'] = False
    if_testdata_available = fips_fact_collector.collect(collected_facts=ansible_facts)
    assert ansible_facts['fips'] == False
    #TODO how to test fips data

# Generated at 2022-06-23 01:09:32.075525
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_obj = FipsFactCollector()
    fips_obj.module = object()
    fips_obj.collect(collected_facts=dict())['fips']

# Generated at 2022-06-23 01:09:36.270211
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    Tests = FipsFactCollector()
    if Tests.name == 'fips':
        output = Tests.collect()
        if output['fips'] == False:
            print("Incomplete output. FIPS should be true")
    else:
        print("FIPS fact collector failed")

# Generated at 2022-06-23 01:09:37.948444
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:40.407992
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-23 01:09:43.347958
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-23 01:09:44.914566
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Class constructor test"""
    FipsFactCollector.collect()

# Generated at 2022-06-23 01:09:45.494767
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:09:46.285080
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:09:46.906375
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:09:49.096037
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector({})
    test_val = f.collect()
    assert test_val == {'fips': False}

# Generated at 2022-06-23 01:09:51.876804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    fips_facts = obj.collect(module=None, collected_facts=None)
    assert fips_facts == {'fips': False}

# Generated at 2022-06-23 01:09:59.338575
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    test_data = '1'
    result = fips_fact_collector.collect(None, None, test_data)
    assert result['fips']
    test_data = '0'
    result = fips_fact_collector.collect(None, None, test_data)
    assert not result['fips']
    test_data = 'foo'
    result = fips_fact_collector.collect(None, None, test_data)
    assert not result['fips']

# Generated at 2022-06-23 01:10:00.367465
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()

# Generated at 2022-06-23 01:10:05.785350
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize the collector object
    fips_fact_collector = FipsFactCollector()

    # Build expected values
    expected_fips_facts = {'fips': False}

    # Build actual values
    fips_facts = fips_fact_collector.collect()

    # Test if actual values match expected values
    assert fips_facts == expected_fips_facts

# Generated at 2022-06-23 01:10:10.690691
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {}
    FipsFactCollector({}, collected_facts).collect()
    assert collected_facts['fips'] == False

    with open('/tmp/fips_enabled', 'w') as f:
        f.write('1')
    FipsFactCollector({}, collected_facts).collect()
    assert collected_facts['fips'] == True

# Generated at 2022-06-23 01:10:12.348413
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:10:15.132960
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:10:17.058597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts == {'fips': False}

# Generated at 2022-06-23 01:10:21.055035
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert set(fips._fact_ids) == set(['fips'])


# Generated at 2022-06-23 01:10:23.817989
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()


# Generated at 2022-06-23 01:10:26.541887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Test FipsFactCollector
    """
    fips = FipsFactCollector()
    assert fips is not None
    assert fips.name == 'fips'

# Generated at 2022-06-23 01:10:28.074727
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-23 01:10:39.555631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Arrange
    import os
    import tempfile
    path = os.path.join(tempfile.gettempdir(), 'fips_enabled')
    
    fips_true = '1'
    fips_false = '0'
    args = {'fips': False}
    f = FipsFactCollector()

    # Act
    # check with fips enabled
    with open(path, 'w') as file:
        file.write(fips_true)
    collected_facts = f.collect()

    # Assert
    assert collected_facts['fips'] == True

    # Act
    # check with fips disabled
    with open(path, 'w') as file:
        file.write(fips_false)
    collected_facts = f.collect()

    # Assert
    assert collected_facts

# Generated at 2022-06-23 01:10:41.609813
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:10:44.589025
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collected_facts = {}
    FipsFactCollector().populate(collected_facts)
    assert "fips" in collected_facts

# Generated at 2022-06-23 01:10:50.517105
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test constructor of FipsFactCollector class"""
    fips_variables = ['fips']
    fips_fact_collecter = FipsFactCollector()
    # test if the class name and fact_ids are as expected
    assert fips_fact_collecter.name == 'fips'
    assert fips_fact_collecter._fact_ids == set(fips_variables)

# Generated at 2022-06-23 01:10:53.169106
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:10:56.999407
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Unit test to check the functionality of collect()

# Generated at 2022-06-23 01:10:58.819547
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    result = FipsFactCollector()
    assert result.name == 'fips'

# Generated at 2022-06-23 01:11:03.926810
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test the collect method of class FipsFactCollector"""
    fips_collector = FipsFactCollector()

    # This is a dummy test for fips was not implemented for
    # Windows yet. We will test it when we have a Windows machine.
    # https://github.com/ansible/ansible/issues/42545
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:07.971458
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set(['fips'])


# Generated at 2022-06-23 01:11:12.121222
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # If a system has FIPS enabled, return True
    collector = FipsFactCollector(None)

    module = MockModule()
    module.run_command = Mock(return_value=(0, '1', ''))

    facts = collector.collect(module=module)

    assert facts['fips']


# Generated at 2022-06-23 01:11:15.019779
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts_collector = FipsFactCollector()
    fips_facts = facts_collector.collect()
    assert fips_facts == {
        "fips": False,
        }

# Generated at 2022-06-23 01:11:16.971452
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:19.520714
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:11:22.740331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect()"""
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert 'fips' in result

# Generated at 2022-06-23 01:11:23.330585
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-23 01:11:33.174509
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #
    # setup
    #
    fips_obj = FipsFactCollector()
    
    #
    # test for fips==True
    #
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('1\n')
    # run
    fips_obj.collect()
    # check results
    assert fips_obj.collect()['fips']

    #
    # test for fips==False
    #
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('0\n')
    # run
    fips_obj.collect()
    # check results
    assert not fips_obj.collect()['fips']

# Generated at 2022-06-23 01:11:34.204332
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:11:37.562687
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids is not None

# Generated at 2022-06-23 01:11:39.986937
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_module = FipsFactCollector()
    assert fact_module.name == 'fips'
    assert fact_module._fact_ids == set()


# Generated at 2022-06-23 01:11:42.110583
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert type(obj) is FipsFactCollector
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:11:43.957570
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert 'fips' in facts

# Generated at 2022-06-23 01:11:46.008225
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:11:52.259081
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    This method unit tests the functionality provided by method collect
    of class FipsFactCollector.
    """
    fips_fact_collector = FipsFactCollector()
    fips_facts = {'fips': True}
    # Fake the method get_file_content
    fips_fact_collector.get_file_content = lambda arg: '1'
    fips_fact_collector.__name__ = 'FipsFactCollector'
    # Call the method with all arguments as none
    # Assert that the method returns the proper fips fact
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-23 01:11:59.538616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Prepare test data
    #fips_facts = FipsFactCollector()
    #mock_module = 'ansible.module_utils.facts.collector.get_file_content'
    #mock_path = '/proc/sys/crypto/fips_enabled'

    # Test for exception
    #with pytest.raises(Exception) as e_info:
    #    fips_facts.collect(module=mock_module, collected_facts=mock_path)
    pass

# Generated at 2022-06-23 01:12:03.690526
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

    assert fips_collector.collect(), "Failed to collect the facts."


# Generated at 2022-06-23 01:12:06.036190
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids

# Generated at 2022-06-23 01:12:07.809235
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-23 01:12:08.863325
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:16.844664
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Define a mock object for ansible module argument_spec
    class MockModuleArgumentSpec:
        def __init__(self):
            self.argument_spec = dict()
            self.argument_spec['gather_subset'] = set(['!all', 'fips'])

    # Define a mock object for ansible module
    class MockModule:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = set(['fips'])
            self.params['filter'] = 'fips'
            self.argument_spec = MockModuleArgumentSpec()

    # Define a mock object for ansible module import module
    class MockAnsibleModule:
        def __init__(self):
            self.params = MockModule()

    mock_module = MockAn

# Generated at 2022-06-23 01:12:23.519082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    file_content = b"\x01"
    fake_file = {}
    fake_file['/proc/sys/crypto/fips_enabled'] = file_content
    test_module = True
    test_facts = True
    collector = FipsFactCollector()
    result = collector.collect(module=test_module, collected_facts=test_facts)
    assert result['fips'] == True


# Generated at 2022-06-23 01:12:26.469843
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()['fips'] == False
    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:12:27.397002
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:12:29.094067
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-23 01:12:30.408347
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()

    assert not fips._fact_ids

# Generated at 2022-06-23 01:12:33.375905
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result.get('fips')
    assert result.get('fips') is not None

# Generated at 2022-06-23 01:12:37.741255
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Unit test case for method collect

# Generated at 2022-06-23 01:12:41.237579
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # instantiate FipsFactCollector
    ff = FipsFactCollector()

    # run collect method
    ff.collect()

    # check if fips_facts is populated
    assert ff.fips_facts

# Generated at 2022-06-23 01:12:44.062183
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    test_fips_fact_collector = FipsFactCollector()
    assert test_fips_fact_collector.name == 'fips'


# Generated at 2022-06-23 01:12:48.053255
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = None
    collected_facts = None

    # If nothing is collected, then the result is false
    collector = FipsFactCollector()
    facts = collector.collect(module, collected_facts)
    assert facts['fips'] is False



# Generated at 2022-06-23 01:12:49.599474
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect()['fips'] == False

# Generated at 2022-06-23 01:12:51.403040
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfc = FipsFactCollector()
    assert fipsfc.name == 'fips'

# Generated at 2022-06-23 01:12:53.317262
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == "fips"


# Generated at 2022-06-23 01:12:55.175960
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    ans = fips.collect()
    assert isinstance(ans, dict)
    assert len(ans) == 1
    assert ans['fips'] == False

# Generated at 2022-06-23 01:12:57.621039
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # create object without parameter
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:12:59.385608
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': True}

# Generated at 2022-06-23 01:13:03.366037
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:13:06.238427
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_bt = FipsFactCollector()
    assert fips_bt.name == 'fips'
    assert 'fips' in fips_bt._fact_ids
    

# Generated at 2022-06-23 01:13:11.180817
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  # Test with a file that contains the expected string
  collector = FipsFactCollector()
  fips_facts = collector.collect()
  assert fips_facts == {'fips': True}
  # Test with a file that does not exist
  collector = FipsFactCollector()
  fips_facts = collector.collect()
  assert fips_facts == {'fips': False}

# Generated at 2022-06-23 01:13:12.837875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # TODO write unit test for method collect of class FipsFactCollector
    assert True

# Generated at 2022-06-23 01:13:14.885612
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    parent = FipsFactCollector()
    assert parent.collect() == { 'fips': False }

# Generated at 2022-06-23 01:13:18.245616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect(collected_facts=None)
    assert collected_facts.get('fips') == False

# Generated at 2022-06-23 01:13:20.505496
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:13:30.073544
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set up a mock module and a mock class for the call to
    # get_file_content to return a value.
    module = None
    collected_facts = None
    fips_facts = {
        'fips': True
    }
    # NOTE: mocking the get_file_content function causes
    # the parent class to not be evaluated, so we will
    # also test for that case
    fips_facts_no_fips = {
        'fips': False
    }
    def mock_get_file_contents():
        return '1'
    fipsfc = FipsFactCollector()
    assert fipsfc.collect(module, collected_facts) == fips_facts
    fipsfc._get_file_content = mock_get_file_contents

# Generated at 2022-06-23 01:13:31.048747
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-23 01:13:43.725535
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Testing with /proc/sys/crypto/fips_enabled not present
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False
    # Testing with /proc/sys/crypto/fips_enabled present and set to 1
    fips_facts = fips_fact_collector.collect(
        module=dict(params=dict(get_file_content_raises_exception=False))
    )
    assert fips_facts['fips'] == True
    # Testing with /proc/sys/crypto/fips_enabled present and set to 0

# Generated at 2022-06-23 01:13:54.239547
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Verify that fips fact collector returns the correct data"""

    # Import
    from ansible.module_utils.facts import FactCollector

    # Create mock context
    context = {'ANSIBLE_CACHE_PLUGIN': 'jsonfile', 'ANSIBLE_CACHE_PLUGIN_CONN': '', 'ANSIBLE_CACHE_PLUGIN_PREFIX': '.fact_cache', 'ANSIBLE_CACHE_PLUGIN_TIMEOUT': 86400}

    # Create fake content
    fake_content = """1"""

    # Create mock AnsibleModule
    from ansible.module_utils._text import to_bytes
    import types
    mock_AnsibleModule = types.ModuleType('ansible.module_utils.basic.AnsibleModule')
    mock_AnsibleModule.get_bin

# Generated at 2022-06-23 01:13:55.843248
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:13:58.889185
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:01.591398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()



# Generated at 2022-06-23 01:14:05.394264
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert not fips_facts._fact_ids
    assert fips_facts.collect()['fips'] is not None

# Generated at 2022-06-23 01:14:08.339233
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:14:12.225015
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert len(fipsFactCollector._fact_ids) == 0


# Generated at 2022-06-23 01:14:15.434408
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert facts['fips'] is False


# Generated at 2022-06-23 01:14:16.828435
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector

# Generated at 2022-06-23 01:14:21.567951
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize class object
    fc = FipsFactCollector()
    facts = {'fips': False}

    # Execute the testing method
    result = fc.collect()

    # Compare result to expected dict
    assert result == facts

# Generated at 2022-06-23 01:14:25.320243
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_fips_data = (
        (b'1', True),
        (b'0', False)
    )
    fips_collector = FipsFactCollector()
    for data, expected in test_fips_data:
        result = fips_collector.collect(data=data)
       

# Generated at 2022-06-23 01:14:27.879320
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert type(fips_facts) is dict
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-23 01:14:31.392635
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:34.105135
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = '1'
    if data == '1':
        fips_facts['fips'] = True
    assert fips_facts['fips']

# Generated at 2022-06-23 01:14:37.342415
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:14:38.712915
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    fips_fc.collect()

# Generated at 2022-06-23 01:14:42.469498
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    Collector._collectors = []
    collected_facts = {}
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts['fips'] == False

# Generated at 2022-06-23 01:14:46.439842
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Unit test for method collect of class FipsFactCollector
    '''
    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-23 01:14:53.189483
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    module = None
    collected_facts = None
    fips_facts = collector.collect(module, collected_facts)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)
    if fips_facts['fips']:
        print("System is in FIPS mode")
    else:
        print("System is not in FIPS mode")

# Generated at 2022-06-23 01:14:56.441025
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:14:57.845482
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# Generated at 2022-06-23 01:15:00.442915
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    is_fips = collector.collect()
    assert(is_fips['fips'] in (False, True))


# Generated at 2022-06-23 01:15:03.819538
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup
    collected_facts = {}
    fips = FipsFactCollector()

    # Test
    fips.collect(collected_facts)

    # Assertions
    for fact in collected_facts:
        assert fact in ['fips']

# Generated at 2022-06-23 01:15:08.413088
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Check the case where FIPS is configured on the system
    obj = FipsFactCollector()
    result = obj.collect(None, None)
    assert 'fips' in result
    assert result['fips'] == True

    # Check the case where FIPS is not configured on the system
    obj = FipsFactCollector()
    result = obj.collect(None, None)
    assert 'fips' in result
    assert result['fips'] == False

# Generated at 2022-06-23 01:15:12.218771
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def mock_get_file_content(file):
        return '1'
    c = FipsFactCollector()
    d = c.collect()
    assert d['fips'] is True
    c._get_file_content(file) == '1'

# Generated at 2022-06-23 01:15:16.648108
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Constructor should succeed due to no parameters
    try:
        FipsFactCollector()
        pass
    except:
        print("Failed to instantiate FipsFactCollector")

    # Make sure name is set correctly
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-23 01:15:17.626436
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:15:20.015254
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector.collect()['fips'] == False

# Generated at 2022-06-23 01:15:24.155211
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': False}

# Generated at 2022-06-23 01:15:26.264398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    input_validate = FipsFactCollector()
    assert input_validate.name == 'fips'
    assert input_validate._fact_ids == set()


# Generated at 2022-06-23 01:15:28.495459
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    expected_facts = {'fips': False}
    assert fips_facts.collect() == expected_facts

# Generated at 2022-06-23 01:15:34.087689
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    ansible_facts = {}
    ans_mod = AnsibleModule(ansible_facts=ansible_facts)
    collector = FipsFactCollector()
    fips_facts = collector.collect(module=ans_mod, collected_facts=ansible_facts)
    assert fips_facts['fips'] == os.path.isfile(
        '/proc/sys/crypto/fips_enabled'
    )

# Generated at 2022-06-23 01:15:37.553821
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {
        'fips': True
    }
    FipsFactCollector._get_file_content = lambda self, path: '1'
    assert fips_facts == FipsFactCollector().collect()

# Generated at 2022-06-23 01:15:42.682809
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids is not None
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids is not None


# Generated at 2022-06-23 01:15:43.984557
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:15:46.052494
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'


# Generated at 2022-06-23 01:15:46.949361
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:15:53.650607
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''
    # mock the module
    module = type('module', (), {'params':{}})
    module.params = {'gather_subset':['fips']}
    module.run_command = MagicMock(return_value=['Foo'])
    # create a FipsFactCollector object
    fips_fact_collector = FipsFactCollector(module)
    # check if we can create object
    assert fips_fact_collector



# vim: expandtab tabstop=4 expandtab shiftwidth=4 shiftround autoindent

# Generated at 2022-06-23 01:15:59.821140
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_test_obj = FipsFactCollector()
    assert fips_test_obj.name == 'fips'
    assert fips_test_obj._fact_ids == set()

# Unit test to test if the function collect returns true
# when FIPS module is not enabled

# Generated at 2022-06-23 01:16:02.802329
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-23 01:16:04.133388
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    result = FipsFactCollector().collect()
    assert result['fips'] == False

# Generated at 2022-06-23 01:16:06.313937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect()
    assert result == {'fips':False}

# Generated at 2022-06-23 01:16:07.289814
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:16:10.549349
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    fips_facts = c.collect()
    assert len(fips_facts.keys()) == 1
    assert fips_facts['fips'] is True or fips_facts['fips'] is False

# Generated at 2022-06-23 01:16:12.457378
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:16:15.462971
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    FF = FipsFactCollector(None, None)
    assert FF.name == 'fips'
    assert FF._fact_ids == set()

# Generated at 2022-06-23 01:16:20.833084
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    # Create a dummy module instance
    class DummyModule(object):
        def __init__(self):
            self.params = {}

    module = DummyModule()

    # Create a dummy Collector instance
    class DummyCollector(object):
        def __init__(self):
            self._disabled = False
            self._fact_ids = set()

        def disabled(self, disabled=None):
            pass


# Generated at 2022-06-23 01:16:23.477416
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file = FipsFactCollector()
    facts = fips_file.collect()
    assert facts['fips'] == False


# Generated at 2022-06-23 01:16:26.110070
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    assert isinstance(fips_collector.collect(), dict)

# Generated at 2022-06-23 01:16:28.031488
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:16:30.072102
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:16:31.297162
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-23 01:16:39.121987
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test: If /proc/sys/crypto/fips_enabled is not found
    # If FIPS module is not loaded, it will return:
    #  { 'fips' : False }
    import tempfile
    import shutil
    import os
    # Create temporary dir to hold dummy file
    tmp_dir = tempfile.mkdtemp()
    # Create dummy file
    tmp_name = os.path.join(tmp_dir, 'fips_enabled')
    with open(tmp_name, 'w') as fd:
        fd.write('disabled')
    # Set up the module
    import sys
    mod_name = 'ansible.module_utils.facts.collectors.system.fips'
    mod_obj = sys.modules.get(mod_name, None)

# Generated at 2022-06-23 01:16:48.590802
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    # Assert ffc is not null
    assert ffc is not None
    # Assert ffc has attribute 'name'
    assert hasattr(ffc, 'name')
    # Assert ffc has attribute '_fact_ids'
    assert hasattr(ffc, '_fact_ids')
    # Assert ffc has attribute 'collect'
    assert hasattr(ffc, 'collect')
    # Assert ffc's attribute 'name' is 'fips'
    assert ffc.name == 'fips'
    # Assert ffc's attribute '_fact_ids' is set type
    assert isinstance(ffc._fact_ids, set)
    # Assert ffc's attribute '_fact_ids' is empty
    assert len(ffc._fact_ids) == 0

# Generated at 2022-06-23 01:16:50.625910
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:16:53.198242
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    result = obj.collect()
    assert result['fips'] == False or result['fips'] == True

# Generated at 2022-06-23 01:16:55.861946
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert isinstance(fips_collector.name, str)
    assert isinstance(fips_collector._fact_ids, set)


# Generated at 2022-06-23 01:16:58.887398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    returned_object = FipsFactCollector()
    assert returned_object.name == 'fips'
    assert returned_object._fact_ids == set()
    assert returned_object.collect()['fips'] == False

# Generated at 2022-06-23 01:17:01.474123
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 0
    assert isinstance(FipsFactCollector._fact_ids, set)


# Generated at 2022-06-23 01:17:06.283727
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Check the method collect returns the expected result"""
    class MockModule(object):
        pass

    class MockCollectedFacts(dict):
        pass

    obj = FipsFactCollector()
    assert obj.collect(MockModule(), MockCollectedFacts()) == {'fips': False}


# Generated at 2022-06-23 01:17:13.900466
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    # Test _fact_ids as a property
    assert fips.fact_ids == set()

    # Test `name` as a property
    assert fips.name == 'fips'

    # Test `collect` method
    fake_module_obj = None
    fake_collected_facts = {'fips': 'Not Collected'}
    fact_dict = fips.collect(fake_module_obj, fake_collected_facts)
    assert 'fips' in fact_dict
    assert fact_dict['fips'] == 'Not Collected'

# Generated at 2022-06-23 01:17:23.423845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import FactsCollector
    facts = Facts()
    facts_collector = FactsCollector(facts)
    fips_facts_collector = FipsFactCollector(facts)
    fips_facts = fips_facts_collector.collect()
    assert fips_facts == {}

    fips_facts_collector._module = 'unit_test_module'
    fips_facts_collector._module_lock = 'unit_test_module_lock'
    fips_facts = fips_facts_collector.collect()
    assert fips_facts == {'fips': False}

# Generated at 2022-06-23 01:17:24.051122
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-23 01:17:27.273683
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = {}
    fips_facts = FipsFactCollector().collect(module, collected_facts)
    assert fips_facts['fips'] == False



# Generated at 2022-06-23 01:17:29.735892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    assert 'fips' in result
    assert type(result['fips']) is bool

# Generated at 2022-06-23 01:17:32.781708
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()


# Generated at 2022-06-23 01:17:35.087196
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert 'fips' in facts

# Generated at 2022-06-23 01:17:39.461562
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()
    assert fips_fact_collector._fact_ids.add

# Generated at 2022-06-23 01:17:41.112744
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    f.collect()

# Generated at 2022-06-23 01:17:43.378676
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    t_facts = FipsFactCollector().collect()
    assert 'fips' in t_facts, "FipsFactCollector constructor test failed"
    return

# Generated at 2022-06-23 01:17:44.395618
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert not FipsFactCollector().collect()

# Generated at 2022-06-23 01:17:46.486270
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Initialize the FipsFactCollector
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-23 01:17:50.833129
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert 'fips' in fips_facts_collector._fact_ids


# Generated at 2022-06-23 01:17:54.643189
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()


# Generated at 2022-06-23 01:17:59.328060
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids.add('fips')
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:01.290657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-23 01:18:05.094371
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert(fips_obj.__class__.__name__ == 'FipsFactCollector')


# Generated at 2022-06-23 01:18:06.735677
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-23 01:18:08.269414
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    result = collector.collect()
    assert result == {'fips': False}

# Generated at 2022-06-23 01:18:09.162064
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()

# Generated at 2022-06-23 01:18:11.823179
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()



# Generated at 2022-06-23 01:18:15.202460
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
     fips_fact_collector = FipsFactCollector()
     assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-23 01:18:17.709495
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert(isinstance(f, BaseFactCollector))
    assert(f.name == 'fips')


# Generated at 2022-06-23 01:18:19.999804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-23 01:18:30.437553
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ################################################################################
    # Construct test data
    ################################################################################
    fips_content = '1\n'
    no_fips_content = '0\n'

    ################################################################################
    # Perform test
    ################################################################################
    fips = FipsFactCollector()
    fips_facts = fips.collect(None)

    ################################################################################
    # Check results
    ################################################################################
    assert fips_facts['fips'] is False



# Generated at 2022-06-23 01:18:35.295873
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = {}
    collected_facts = None
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect(module, collected_facts)
    assert type(fips_facts) is dict
    assert len(fips_facts) == 1
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-23 01:18:38.133195
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()

# Generated at 2022-06-23 01:18:38.996339
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-23 01:18:41.174423
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    o = FipsFactCollector()
    assert o._fact_ids == set()
    assert o.name == 'fips'

# Generated at 2022-06-23 01:18:42.807589
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    tester = FipsFactCollector()
    assert tester.name == 'fips'