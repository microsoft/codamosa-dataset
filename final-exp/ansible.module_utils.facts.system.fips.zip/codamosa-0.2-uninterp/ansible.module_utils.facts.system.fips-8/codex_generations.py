

# Generated at 2022-06-17 02:05:57.509636
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:05:58.985494
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:00.454668
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:04.175124
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:06.725549
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:11.751178
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:06:14.396071
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-17 02:06:16.089132
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:18.541652
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-17 02:06:20.179520
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-17 02:06:26.541826
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:31.526772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:34.279669
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:37.051907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:39.494333
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:41.961450
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:44.453550
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:46.043326
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-17 02:06:48.411867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:50.467103
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:06:58.544422
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:02.923849
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:06.505972
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:09.621575
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-17 02:07:11.235734
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:16.171624
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:18.662457
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:23.436363
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:24.927944
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-17 02:07:27.140067
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:43.123771
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:44.281335
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:46.246993
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:47.751054
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-17 02:07:49.281083
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:52.166625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:54.849208
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:07:57.014841
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-17 02:07:58.776871
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:02.173487
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:36.828066
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:41.289985
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:46.886791
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:52.529860
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:55.182517
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:08:57.865704
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-17 02:08:59.772444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:09:02.916062
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:09:06.796615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-17 02:09:09.685274
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:13.185396
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:17.497386
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:19.497497
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:25.026195
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:27.140887
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:28.731471
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:30.187354
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:35.122129
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:37.211100
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:10:39.090962
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:00.301189
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:04.435493
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:07.883919
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:12.146832
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:17.506194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:20.024490
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] is False

# Generated at 2022-06-17 02:13:21.958018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-17 02:13:24.008388
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-17 02:13:24.643867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-17 02:13:27.712193
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False