

# Generated at 2022-06-20 19:22:05.052376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    print(fips_facts)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)


# Generated at 2022-06-20 19:22:07.795457
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'



# Generated at 2022-06-20 19:22:13.578909
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # test data
    fips_test_data ={
        'fips': True,
    }

    # create object and invoke method
    fips_collector = FipsFactCollector()
    result = fips_collector.collect()

    assert result == fips_test_data

# Generated at 2022-06-20 19:22:18.462245
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of FipsFactCollector
    test_fips_fact_collector = FipsFactCollector()

    # Test method collect
    test_fips_fact_collector.collect()

# Generated at 2022-06-20 19:22:21.699570
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfact = FipsFactCollector()
    assert fipsfact.name == 'fips'
    assert not fipsfact._fact_ids

# Generated at 2022-06-20 19:22:25.449819
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    out = FipsFactCollector().collect(collected_facts=None)
    print(out)
    return out


if __name__ == '__main__':
    res = test_FipsFactCollector_collect()
    print(res)

# Generated at 2022-06-20 19:22:27.064328
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector


# Generated at 2022-06-20 19:22:32.752839
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = type('module', (object,), {'exit_json': lambda x:None,
                                             'fail_json': lambda x:None})()

    fc = FipsFactCollector(mock_module)
    facts = fc.collect()

    assert 'fips' in facts

# Generated at 2022-06-20 19:22:42.012469
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    fipsfc = FipsFactCollector()
    # Assert that method name of FipsFactCollector is 'fips'
    assert fipsfc.name == 'fips'
    # Assert that method _fact_ids of FipsFactCollector has no 'fips'
    assert not(fipsfc._fact_ids.intersection(['fips']))
    # Perform collection of 'fips'
    collected_facts = fipsfc.collect()
    # Assert that collected facts is not empty
    assert collected_facts
    # Assert that collected facts has 'fips'
    assert 'fips' in collected_facts
    # Assert that 'fips' is True or False
    assert isinstance(collected_facts['fips'], bool)

# Generated at 2022-06-20 19:22:42.627200
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:22:47.359590
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == "fips"


# Generated at 2022-06-20 19:22:53.497196
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts.collector == 'FipsFactCollector'
    assert fips_facts.collectors == set([])
    assert fips_facts.platform == 'all'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-20 19:22:54.306228
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-20 19:22:55.888382
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    # These tests don't make sense, but we have them to please pylint
    assert x.name == 'fips'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:23:02.014153
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Test function for class constructor
    :return:
    """
    fips_fact_obj = FipsFactCollector()
    assert fips_fact_obj.name == 'fips'
    assert fips_fact_obj._fact_ids == set()

# Generated at 2022-06-20 19:23:04.942833
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert isinstance(fips, FipsFactCollector)

# Generated at 2022-06-20 19:23:07.306700
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:23:12.382463
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    FipsFactCollector._module = True
    FipsFactCollector._module.exit_json = True
    FipsFactCollector._module.exit_json.return_value = True
    get_file_content = '1'
    FipsFactCollector._get_file_content = get_file_content
    assert FipsFactCollector.collect() == {'fips': True}

# Generated at 2022-06-20 19:23:19.304028
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec={},
    )
    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    test_obj = FipsFactCollector()
    result = test_obj.collect(
        module=test_module,
        collected_facts={'ansible_local': {}}
    )

    assert type(result) is dict
    assert 'ansible_local' in result
    assert type(result['ansible_local']) is dict
    assert 'fips' in result['ansible_local']

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 19:23:25.719710
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert isinstance(fips_collector, FipsFactCollector)
    assert fips_collector.name == 'fips'
    assert set(fips_collector._fact_ids) == set()
    assert callable(fips_collector.collect)

# Generated at 2022-06-20 19:23:33.575740
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # init a fake module
    module = {}
    # init a FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    # run the collect method
    collected_facts = fips_fact_collector.collect(module)
    # assert 'fips' in collected_facts
    assert 'fips' in collected_facts

# Generated at 2022-06-20 19:23:36.873475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test case for method collect of class FipsFactCollector
    """
    facts = FipsFactCollector().collect()
    assert facts['fips'] == False

# Generated at 2022-06-20 19:23:40.908321
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    dict_test = {'fips': False}
    obj = FipsFactCollector()
    assert obj.collect() == dict_test

# Generated at 2022-06-20 19:23:45.008358
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert isinstance(obj.name, str)
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-20 19:23:51.765288
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import facts

    # this is still a bit fragile, but it does test the logic.
    ffc = FipsFactCollector('fips', set(), facts)
    ffc._module = {'get_file_content': lambda x: '1'}
    assert ffc.collect() == {'fips': True}
    ffc._module = {'get_file_content': lambda x: '0'}
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-20 19:23:54.947335
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:23:57.135879
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_facts = FipsFactCollector().collect(module=module, collected_facts=collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:24:00.012523
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test normal instantiation with class FipsFactCollector
    fc = FipsFactCollector()
    assert fc.name == 'fips'
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-20 19:24:03.481831
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    t = FipsFactCollector()
    assert t
    assert t.name == 'fips'
    assert 'fips' in t.collect().keys()

# Generated at 2022-06-20 19:24:14.942445
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()

    # Test condition when fips is enabled
    with open('/proc/sys/crypto/fips_enabled', 'w') as fips_enabled:
        fips_enabled.write('1\n')
        fips_facts = collector.collect()
        assert fips_facts['fips']

    # Test condition when fips is disabled
    with open('/proc/sys/crypto/fips_enabled', 'w') as fips_enabled:
        fips_enabled.write('0\n')
        fips_facts = collector.collect()
        assert not fips_facts['fips']

    # Test condition when file does not exist
    with open('/proc/sys/crypto/fips_enabled', 'w') as fips_enabled:
        fips_enabled.write

# Generated at 2022-06-20 19:24:25.222516
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'
    assert sorted(fact._fact_ids) == sorted([])


# Generated at 2022-06-20 19:24:27.576752
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:24:28.921351
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-20 19:24:29.937050
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:24:32.362171
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:24:34.806802
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:24:37.776109
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import Collector
    x = FipsFactCollector()
    assert isinstance(x, Collector)

# Generated at 2022-06-20 19:24:41.106818
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert len(fips_facts_collector._fact_ids) == 0

# Generated at 2022-06-20 19:24:43.572541
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    data = c.collect()
    assert data['fips'] == False

# Generated at 2022-06-20 19:24:50.307754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Given
    fips_fact = FipsFactCollector()
    class MockModule:
        pass
    module = MockModule()
    collected_facts = {"ansible_facts": {}}

    # When
    result = fips_fact.collect(module, collected_facts)

    # Then
    assert result == { 'fips': False }


# Generated at 2022-06-20 19:25:03.937817
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:25:07.725022
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = {}
    FipsFactCollector().collect(None, facts=facts)
    assert 'fips' in facts
    assert facts['fips'] == False


# Generated at 2022-06-20 19:25:08.812244
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass


# Generated at 2022-06-20 19:25:10.623837
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts = FipsFactCollector.collect(None, None)
    assert type(fips_facts['fips']) == bool

# Generated at 2022-06-20 19:25:14.965108
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:25:17.573433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:18.982492
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:25:27.487259
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collection import collector

    def _get_file_content(path):
        output = to_bytes('0') # for FIPS not enabled
        return output

    get_file_content_orig = collector.get_file_content
    try:
        collector.get_file_content = _get_file_content

        result = FipsFactCollector().collect()
        assert 'fips' in result
        assert not result.get('fips')
    finally:
        collector.get_file_content = get_file_content_orig

# Generated at 2022-06-20 19:25:38.082024
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    # When we call the collect method, we return
    # the value for the key 'fips' of the returned dict.
    # NOTE: this is populated even if it is not set
    assert fips.collect() == {'fips': False}
    # If the file does not exist, we return
    # the value for the key 'fips' of the returned dict.
    with patch.dict('os.path.exists', new=Mock(return_value=False)):
        assert fips.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:41.183344
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert not FipsFactCollector().collect()['fips']

# Generated at 2022-06-20 19:26:06.961629
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-20 19:26:09.600822
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:26:12.454981
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:19.145110
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # mock module
    module = Mock()
    # mock collected_facts
    collected_facts = {}
    # create instance of FipsFactCollector
    instance = FipsFactCollector()
    # verify if mocked module is returned by method collect
    fips_facts = instance.collect(module, collected_facts)
    assert 'fips' in fips_facts
    assert fips_facts['fips'] is False


# Generated at 2022-06-20 19:26:19.930973
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect(None, None)

# Generated at 2022-06-20 19:26:22.971253
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_coll = FipsFactCollector()
    assert fips_fact_coll.name == 'fips'
    assert fips_fact_coll._fact_ids == set(['fips'])

# Generated at 2022-06-20 19:26:24.235594
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:26.183013
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect(None, None) == {'fips': False}

# Generated at 2022-06-20 19:26:31.567601
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    fips_facts = ffc.collect(module=None, collected_facts=None)
    assert 'fips' in fips_facts


# Generated at 2022-06-20 19:26:37.745726
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = {}
    data = "1"
    assert get_file_content('/proc/sys/crypto/fips_enabled') == data
    fips_facts['fips'] = True
    assert FipsFactCollector().collect(None, None) == fips_facts

# Generated at 2022-06-20 19:27:46.947897
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert type(fips_facts) is dict
    assert all (k in fips_facts for k in ('fips'))
    assert all (type(v) is bool for v in fips_facts.values())
    assert set(fips_facts.keys()) == set(['fips'])

# Generated at 2022-06-20 19:27:51.671136
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()


# Generated at 2022-06-20 19:27:55.714321
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsCollector = FipsFactCollector()
    assert fipsCollector.name == 'fips'
    assert fipsCollector.priority == 90
    assert fipsCollector._fact_ids == set()

# Generated at 2022-06-20 19:27:58.444802
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    if os.path.isfile('/proc/sys/crypto/fips_enabled'):
        _FipsFactCollector = FipsFactCollector()
        assert _FipsFactCollector.collect()['fips']
    else:
        assert "Host system is not RHEL"

# Generated at 2022-06-20 19:28:00.651871
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-20 19:28:05.108898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file_data= '1'
    FipsFactCollector._get_file_content = lambda x: fips_file_data
    result = FipsFactCollector.collect()
    assert result['fips']


# Generated at 2022-06-20 19:28:05.968689
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-20 19:28:07.943213
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:28:12.068345
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:28:19.509578
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = {'fips': True}
    fips_collector.get_file_content = lambda filename: '1'
    assert fips_facts == fips_collector.collect()
    fips_facts = {'fips': False}
    fips_collector.get_file_content = lambda filename: '0'
    assert fips_facts == fips_collector.collect()

# Generated at 2022-06-20 19:30:31.370936
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:30:35.314007
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test constructor of FipsFactCollector class"""
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:30:46.333263
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    # Testing `collect` method
    FipsFactCollector = FipsFactCollector

    get_file_content = get_file_content

    module = None
    collected_facts = None
    fips_facts = {}
    fips_facts['fips'] = True
    data = 1


    def side_effect(argument):
        return data

    setattr(get_file_content, 'side_effect', side_effect)
    result = FipsFactCollector.collect(FipsFactCollector, module=module, collected_facts=collected_facts)
    assert result == fips_facts

    data = None
    fips_facts['fips'] = False
    result = FipsFactCollector.collect(FipsFactCollector, module=module, collected_facts=collected_facts)

# Generated at 2022-06-20 19:30:47.003244
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:30:53.179128
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Constructor of the class FipsFactCollector should pass the following test.
    1. Check the instance is created properly
    2. Check the constructor of base class BaseFactCollector is called. For this, we need to ensure the
       attribute name (str) of the BaseFactCollector is defined properly.
    """
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-20 19:30:59.036374
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import os
    import mock

    # prep the test
    test_fips = FipsFactCollector()
    test_fips._module = mock.MagicMock()
    test_fips._module.params = {}
    test_fips._module.get_bin_path = mock.MagicMock()

    # Assert that result is False
    facts_reader_mock = mock.MagicMock()
    facts_reader_mock.read.return_value = ""
    with mock.patch("__builtin__.open", mock.mock_open(read_data=''), create=True):
        results = test_fips.collect()

    assert not results['fips']

    # Assert that result is True
    facts_reader_mock = mock.MagicMock()
    facts_reader_

# Generated at 2022-06-20 19:31:01.306526
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:31:03.789532
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Ensure that the empty text file doesn't throw an exception
    FipsFactCollector.collect({'system_version': 'Fedora 27'})

# Generated at 2022-06-20 19:31:12.983447
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    #mock get_file_content and verify call
    with patch('ansible.module_utils.facts.collector.get_file_content') as mock_get_file_content:
        mock_get_file_content.return_value = 1
        fact_collector = FipsFactCollector()
        assert fact_collector.collect() == {'fips': True}

    #mock get_file_content and verify call
    with patch('ansible.module_utils.facts.collector.get_file_content') as mock_get_file_content:
        mock_get_file_content.return_value = 0
        fact_collector = FipsFactCollector()
        assert fact_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:31:17.822158
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # set up object FipsFactCollector
    fipsFactCollector = FipsFactCollector()

    # test with fips enabled
    fipsFactCollector.collect(collected_facts=None)
    # assert fips_enabled present
    assert fipsFactCollector.collect()['fips'] is True
    # asert _fact_ids has entry
    assert 'fips' in fipsFactCollector._fact_ids