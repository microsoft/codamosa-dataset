

# Generated at 2022-06-20 19:22:08.742604
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector(None, None)

    assert fips_collector.name == 'fips'
    assert 'fips' in fips_collector._fact_ids


# Generated at 2022-06-20 19:22:13.496166
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-20 19:22:16.503848
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'

# Generated at 2022-06-20 19:22:21.013598
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Tests the constructor of FipsFactCollector
    """
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:22:24.735694
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    try:
        FipsFactCollector()
    except AttributeError as e:
        assert False, "FipsFactCollector init failed with AttributeError: "+str(e)
    else:
        assert True

# Generated at 2022-06-20 19:22:25.964478
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # just instantiating the class should be enough.
    FipsFactCollector()

# Generated at 2022-06-20 19:22:27.484470
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:38.027192
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import tempfile
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.write('1')
    temp.close()

    fips = FipsFactCollector()
    assert fips.name == 'fips'
    collected_facts = fips.collect()

    assert isinstance(fips, BaseFactCollector)
    assert isinstance(collected_facts, dict)
    assert collected_facts['fips'] == True
    assert fips.name not in collected_facts['ansible_local']

    os.remove(temp.name)

# Generated at 2022-06-20 19:22:39.708459
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:22:43.289893
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:22:48.705971
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    status = collector.collect()
    assert status.has_key('fips')

# Generated at 2022-06-20 19:22:51.734822
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    func_fips = FipsFactCollector()
    assert func_fips.name == 'fips'
    assert func_fips._fact_ids == set([])


# Generated at 2022-06-20 19:22:55.466844
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize class instance
    ffc = FipsFactCollector()
    # call collect method
    fips_facts = ffc.collect()
    # assert isinstance(fips_facts, dict)
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:22:58.985165
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    c = FipsFactCollector()
    assert c.name == 'fips', 'Failed to create Fips Fact Collector object'


# Generated at 2022-06-20 19:23:00.482710
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact = FipsFactCollector()
    result = fact.collect(module=None, collected_facts=None)
    assert result == {'fips': False}

# Generated at 2022-06-20 19:23:04.795197
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 1
    assert FipsFactCollector._fact_ids == set(['fips'])

# Generated at 2022-06-20 19:23:07.137602
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()

    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:23:12.219275
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    import tempfile
    import filecmp

    fips_path = tempfile.NamedTemporaryFile(delete=False)
    fips_path.write('1\n')
    fips_path.close()

    collector = FipsFactCollector()
    res = collector.collect(collected_facts = None)
    assert res['fips'] == True

# Generated at 2022-06-20 19:23:16.228846
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert isinstance(fips_fact_collector._fact_ids, set)
    assert fips_fact_collector.name in fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:23:28.460886
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_collector = FipsFactCollector()
    test_module = None
    test_collector.collect(module=test_module)
    if not test_collector.collected_facts:
        raise AssertionError('FipsFactCollector collect failed to collect fips facts.')
    elif len(test_collector.collected_facts) != 1:
        raise AssertionError('Expected 1 fips facts, found %d.' % len(test_collector.collected_facts))
    elif not isinstance(test_collector.collected_facts['fips'], bool):
        raise AssertionError('Expected fips fact to be bool, found %s.' % type(test_collector.collected_facts['fips']))

# Generated at 2022-06-20 19:23:35.619827
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector

# Generated at 2022-06-20 19:23:37.003998
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()


# Generated at 2022-06-20 19:23:42.301639
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:23:47.098915
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_obj = FipsFactCollector()
    assert(fact_obj.name == 'fips')
    assert(fact_obj._fact_ids == set())
    assert(isinstance(fact_obj.collect(), dict))

# Generated at 2022-06-20 19:23:49.534859
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-20 19:23:52.682422
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:23:55.133324
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-20 19:23:57.643442
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    collector = FipsFactCollector()
    collected_facts = collector.collect()
    print(collected_facts)

# Generated at 2022-06-20 19:24:01.018186
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize the class object
    fips_facts = FipsFactCollector()
    # Make sure that the module object is not none
    assert fips_facts is not None
    # Test method collect
    assert fips_facts.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:02.402462
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:24:15.860376
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:24:18.217442
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    assert ffc.collect() == {'fips': False}
    # TODO: add a test_fixture for the file /proc/sys/crypto/fips_enabled

# Generated at 2022-06-20 19:24:22.183210
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc
    assert isinstance(ffc, FipsFactCollector)
    assert repr(ffc) == "<fips_fact_collector.FipsFactCollector()>"
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()
    assert isinstance(ffc._fact_ids, set)
    assert ffc.fetch_facts() == {}

# Generated at 2022-06-20 19:24:25.903917
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ff = FipsFactCollector()
    assert ff.name == 'fips'
    print("Passed test_FipsFactCollector()")



# Generated at 2022-06-20 19:24:29.336992
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()


# Generated at 2022-06-20 19:24:32.564988
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    c = FipsFactCollector()
    assert c.collect()["fips"] == False

# Generated at 2022-06-20 19:24:35.478049
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert len(fips._fact_ids) == 0

# Generated at 2022-06-20 19:24:39.067695
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    module = None
    collected_facts = None
    result = FipsFactCollector.collect(module, collected_facts)
    assert isinstance(result, dict)
    assert 'fips' in result

# Generated at 2022-06-20 19:24:42.130887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    inst = FipsFactCollector()
    assert inst.name == 'fips'
    assert inst._fact_ids == set()


# Generated at 2022-06-20 19:24:51.290271
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Data is not in the file
    data = ''
    collected_facts = fips_fact_collector.collect(collected_facts={}, module=None)
    assert(len(collected_facts) == 1)
    assert(collected_facts['fips'] == False)

    # Data is not a valid value
    data = 'value'
    collected_facts = fips_fact_collector.collect(collected_facts={}, module=None)
    assert(len(collected_facts) == 1)
    assert(collected_facts['fips'] == False)

    # fips value = True
    data = '1'
    collected_facts = fips_fact_collector.collect(collected_facts={}, module=None)

# Generated at 2022-06-20 19:25:18.352517
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture = FipsFactCollector()
    assert fixture.collect() == {'fips': False}
    assert fixture.collect() != {'fips': True}

# Generated at 2022-06-20 19:25:20.950298
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_instance = FipsFactCollector()
    assert isinstance(fips_instance, FipsFactCollector)
    assert fips_instance.name == 'fips'

# Generated at 2022-06-20 19:25:21.962419
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert 'fips' == FipsFactCollector.name
    assert {'fips'} == FipsFactCollector._fact_ids

# Generated at 2022-06-20 19:25:26.241118
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    print('Test FipsFactCollector constructor')
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-20 19:25:27.860452
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-20 19:25:38.548402
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactManager
    # Create a test FactManager that contains a single FipsFactCollector
    fm = FactManager()
    fm.collectors = [FipsFactCollector()]
    # Run the fact collector
    collected_facts = fm.collect()
    # Assert that the fact collector is named 'fips'
    assert fm.collectors[0].name == 'fips'
    # Assert that the fact collector returned a fact of 'fips'
    assert 'fips' in collected_facts

# Generated at 2022-06-20 19:25:41.954875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:44.912695
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:25:47.611493
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_fact = FipsFactCollector()
    assert my_fact.name == "fips"
    assert my_fact.collect() == {'fips': False}


# Generated at 2022-06-20 19:25:49.430704
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-20 19:26:15.298142
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-20 19:26:17.188155
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-20 19:26:18.402908
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector()


# Generated at 2022-06-20 19:26:19.659556
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:26:22.908517
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] is False

# Generated at 2022-06-20 19:26:31.830819
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    test_collector = FipsFactCollector()
    get_file_content_orig = get_file_content
    get_file_content_mock = MagicMock()

    test_facts = {}
    expected_facts = {'fips': False}
    Collector.add_collector(test_collector)
    test_collector.collect(collected_facts=test_facts)
    assert test_facts == expected_facts

    get_file_content_mock.return_value = '1'
    get_file_content = get_file_content_mock
    expected_facts = {'fips': True}
    test_facts = {}
    test_collector

# Generated at 2022-06-20 19:26:40.395522
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    # this test will only be valid when the file actually exists
    # and has the correct content. You can set it up by doing
    #
    # sudo su
    # echo 1 > /proc/sys/crypto/fips_enabled
    # echo 0 > /proc/sys/crypto/fips_enabled
    #
    # and this should give the expected values
    assert fact_collector.collect(collected_facts={}) == {'fips': True}
    assert fact_collector.collect(collected_facts={}) == {'fips': False}

# Generated at 2022-06-20 19:26:42.850038
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts.keys()
    assert isinstance(fips_facts.get('fips'), bool)

# Generated at 2022-06-20 19:26:47.303048
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:26:56.682144
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.fips import FipsFactCollector
    from ansible.module_utils._text import to_native
    import pytest
    collector = Collector()
    fips_fact_collector = FipsFactCollector(collector)


# Generated at 2022-06-20 19:27:57.058911
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-20 19:28:07.520770
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize a FipsFactCollector and a base module
    fips = FipsFactCollector()
    fips.collect()
    assert fips.name == 'fips'

    class MockModule:
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            if cmd == 'getenforce':
                return (0,'Enforcing')
            else:
                return ()
    mock_module = MockModule()

    # Initialize a FipsFactCollector and call its method collect
    fips = FipsFactCollector()
    fips.collect(mock_module,{})

# Generated at 2022-06-20 19:28:12.763487
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect(collected_facts=None) is not None

# Generated at 2022-06-20 19:28:17.337612
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == "fips"
    assert isinstance(ffc._fact_ids, set)
    assert ffc._fact_ids == set()

# Generated at 2022-06-20 19:28:21.535537
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Constructor of FipsFactCollector should set name of class
    # and fact identifier set.
    fact_collector = FipsFactCollector()
    # Assert that name of fact collector is set to fips
    assert fact_collector.name == 'fips'
    # Assert that fact identifiers are set
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:28:29.068687
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #
    # Configure data that would normally be returned by a module
    #
    result = {
        "fips": False,
    }
    #
    # Create the object that we are testing
    #
    FipsFactCollector_obj = FipsFactCollector()
    #
    # Override methods in the specific type of manager
    #
    def get_file_content(filename):
        if filename == '/proc/sys/crypto/fips_enabled':
            return b'0'
        elif filename == '/proc/sys/crypto/fips_enabled':
            return b'1'
        else:
            return b''
    FipsFactCollector_obj.get_file_content = get_file_content

    fips_facts = FipsFactCollector_obj.collect()
    assert fips

# Generated at 2022-06-20 19:28:33.999328
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fake_module = None
    fake_collect_facts = None
    fips_fact = FipsFactCollector()
    result = fips_fact.collect(fake_module, fake_collect_facts)
    assert result['fips'] is False

# Generated at 2022-06-20 19:28:34.789214
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:28:38.430344
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = None

    # Constructor test: check FipsFactCollector instance
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None

    # Method collect test: Normal case
    fips_fact_collector.collect(mock_module)

# Generated at 2022-06-20 19:28:41.879917
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:30:55.334905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect()['fips'] == True

# Generated at 2022-06-20 19:30:57.438829
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()

# Generated at 2022-06-20 19:31:02.805273
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()
    assert repr(fips_fact_collector) == '<fips>'
    assert fips_fact_collector.__str__()  == '<fips>'

# Generated at 2022-06-20 19:31:04.987608
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert 'fips' == FipsFactCollector.name
    assert set() == FipsFactCollector._fact_ids


# Generated at 2022-06-20 19:31:07.052508
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'

# Generated at 2022-06-20 19:31:10.027266
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector("test_FipsFactCollector")
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:31:12.284932
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == {'fips': False}

# Generated at 2022-06-20 19:31:17.017272
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 0
    assert FipsFactCollector.collect.__name__ == 'collect'
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert isinstance(fips_fact_collector, FipsFactCollector)

# Generated at 2022-06-20 19:31:21.368484
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_collect_object = FipsFactCollector()
    FipsFactCollector_collect_result = FipsFactCollector_collect_object.collect(module=None, collected_facts=None)
    assert 'fips' in FipsFactCollector_collect_result

# Generated at 2022-06-20 19:31:25.556358
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()
