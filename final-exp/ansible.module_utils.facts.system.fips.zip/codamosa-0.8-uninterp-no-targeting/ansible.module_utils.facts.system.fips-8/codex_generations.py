

# Generated at 2022-06-20 19:22:15.209229
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Mock the method
    class MockFipsFactCollector(FipsFactCollector):
        def collect(self, module=None, collected_facts=None):
            # Collect mock data
            return {'fips': False}

    # Create an instance of module
    fips_fact_collector = MockFipsFactCollector()

    # Collect facts
    facts = fips_fact_collector.collect()

    # Assert that the function worked as expected
    assert type(facts) is dict
    assert facts['fips'] is False

# Generated at 2022-06-20 19:22:23.427241
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test method collect of class FipsFactCollector"""
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector.fips # noqa
    fact_collector = FipsFactCollector()
    facts_obj = collector.Facts(fact_collector)
    facts_obj.populate()
    assert 'fips' in facts_obj.facts

# Generated at 2022-06-20 19:22:25.409978
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()
    fips_collector.collect()

# Generated at 2022-06-20 19:22:30.119406
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector()
    assert facts.name == 'fips', 'test_FipsFactCollector - Incorrect name'
    assert 'fips' in facts._fact_ids, 'test_FipsFactCollector - Incorrect fact_ids'

# Generated at 2022-06-20 19:22:33.548305
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert {'fips': False} == fips_collector.collect()

# Generated at 2022-06-20 19:22:37.899860
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert isinstance(FipsFactCollector.collect(), dict)

# Generated at 2022-06-20 19:22:40.708567
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    factCollector = FipsFactCollector()
    facts = factCollector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 19:22:43.288068
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert result.get('fips') is False

# Generated at 2022-06-20 19:22:45.775524
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'

# Generated at 2022-06-20 19:22:54.134838
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()

    # noinspection PyProtectedMember
    assert collector._fact_ids == set()
    assert collector.name == 'fips'

    # system is not in 'fips' mode
    # noinspection PyProtectedMember
    assert collector._collect(collected_facts={}) == {'fips': False}

    # system is in 'fips' mode
    # noinspection PyProtectedMember
    assert collector._collect(collected_facts={}) == {'fips': True}

# Generated at 2022-06-20 19:22:58.985891
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:23:04.921871
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a FipsFactCollector instance
    fips_fact_collector = FipsFactCollector()
    # Call method collect of FipsFactCollector instance
    result = fips_fact_collector.collect()
    # Verify that the call returns what we expect
    assert result == {'fips': False}

# Generated at 2022-06-20 19:23:09.087782
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids is not None
    assert fips_facts.collect()['fips'] == get_file_content('/proc/sys/crypto/fips_enabled')

# Generated at 2022-06-20 19:23:10.742703
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:23:12.260728
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector
    assert collector.name == 'fips'


# Generated at 2022-06-20 19:23:14.868682
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:23:20.676854
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = type(__name__, (), {})()
    module.params = dict()
    coll = FipsFactCollector(module)
    assert coll.module == module
    assert coll._fact_ids == set()


# Generated at 2022-06-20 19:23:23.007324
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact is not None


# Generated at 2022-06-20 19:23:26.288362
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    res = fips_fact.collect(collected_facts={})
    assert res == { 'fips' : False }

# Generated at 2022-06-20 19:23:31.689298
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector.collect() == {'fips': True}

# Generated at 2022-06-20 19:23:35.806787
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:23:37.894638
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert not ffc._fact_ids

# Generated at 2022-06-20 19:23:41.081655
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    result = fips.collect()
    assert result['fips'] == False

# Generated at 2022-06-20 19:23:43.829955
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

FactCollector = FipsFactCollector

# Generated at 2022-06-20 19:23:47.882502
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:23:53.860269
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    with FipsFactCollector() as f_col:
        f_col.collect()
    assert f_col.name == 'fips'
    assert f_col._fact_ids == {'fips'}


# Generated at 2022-06-20 19:23:57.434873
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    result = fips_fact.collect()
    assert (result['fips'] == False or result['fips'] == True)

# Generated at 2022-06-20 19:24:00.864940
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfc = FipsFactCollector()
    result = fipsfc.collect()
    assert ('fips' in result) and ('fips' in fipsfc.__dict__)
    assert fipsfc.__dict__['fips'] == result['fips']

# Generated at 2022-06-20 19:24:05.009360
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = 'module'
    collected_facts = 'collected_facts'
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:24:09.703069
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert len(fips._fact_ids) == 0
    assert isinstance(fips.collect(), dict)

# Generated at 2022-06-20 19:24:24.064900
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # test normal execution
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips = True
    else:
        fips = False
    assert fips_fact_collector.collect() == {'fips': fips}

    # test execution for which /proc/sys/crypto/fips_enabled
    # file does not exist
    fips_fact_collector._module = MagicMock()
    fips_fact_collector._module.get_bin_path = MagicMock(return_value=None)
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:31.732593
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a dummy instance of the FipsFactCollector class
    dummmy_class = FipsFactCollector()

    # Create a dummy instance of the AnsibleModule class
    dummy_module = 'dummy_module'

    # Create a dummy instance of the AnsibleModule class
    facts_dummy_dict = dict()

    # unit test method collect of class FipsFactCollector
    result_collect = dummmy_class.collect(dummy_module, facts_dummy_dict)

    # assert the result
    assert result_collect['fips'] == False



# Generated at 2022-06-20 19:24:38.044849
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.get_file_content = lambda x: '1'
    result = ffc.collect()
    assert result['fips'] is True
    ffc.get_file_content = lambda x: ''
    result = ffc.collect()
    assert result['fips'] is False

# Generated at 2022-06-20 19:24:43.933781
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import utils
    class Mock(object): pass
    module = Mock()
    module.params = {}
    module.run_command = lambda *args, **kwargs: (0, "", "")
    utils.get_file_content = lambda x: '1'
    # execute the collect method
    FipsFactCollector().collect(module=module)
    #assert False

# Generated at 2022-06-20 19:24:45.838624
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-20 19:24:50.690361
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    f = FipsFactCollector()
    fips_collection = f.collect(module, collected_facts)
    assert fips_collection['fips'] == False or fips_collection['fips'] == True, 'Failed to return collection'


# Generated at 2022-06-20 19:24:56.817636
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test the FipsFactCollector.collect() method
    """
    fips_facts = FipsFactCollector.collect()
    assert isinstance(fips_facts, dict)
    assert fips_facts['fips'] == False


# Generated at 2022-06-20 19:24:59.369570
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == "fips"
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-20 19:25:02.088613
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ft = FipsFactCollector()
    assert ft.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:04.491626
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:25:20.160607
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:25:21.850064
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-20 19:25:27.075252
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = """
/proc/sys/crypto/fips_enabled:
status: 1"""
    
    fips = FipsFactCollector()
    fips.file_exists = lambda x: True
    fips.get_file_content = lambda x: data

    assert fips.collect() == {'fips': True}

# Generated at 2022-06-20 19:25:28.713559
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert 'fips' in fips._fact_ids

# Generated at 2022-06-20 19:25:34.606862
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result == {'fips': False}      # if this fails, it means fips changed


# Generated at 2022-06-20 19:25:36.944319
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ssh = FipsFactCollector()
    assert ssh.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:38.715061
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsc = FipsFactCollector()
    assert fipsc.collect() == {'fips': False}


# Generated at 2022-06-20 19:25:41.482911
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:25:46.178491
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    facts = c.collect()
    assert 'fips' in facts, "Failed to collect FIPS" 
    assert facts['fips'] == False, "Failed to fetch FIPS status"

# Generated at 2022-06-20 19:25:48.471741
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
      fipscollector = FipsFactCollector()
      result = fipscollector.collect()
      assert result['fips'] == True

# Generated at 2022-06-20 19:26:16.406254
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert('fips' in FipsFactCollector().collect())

# Generated at 2022-06-20 19:26:17.984422
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect()['fips'] is False


# Generated at 2022-06-20 19:26:20.265869
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == "fips"
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:26:29.809418
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a mock module and a mock opened file
    m = mock.MagicMock(name='module')
    f = mock.mock_open(read_data='1')
    # Use mocks to patch the open file and os.access
    with mock.patch('ansible.module_utils.facts.collector.open', f, create=True):
        with mock.patch('os.access', mock.Mock(return_value=True)):
            # Create and run instance of FipsFactCollector
            ffc = FipsFactCollector(m)
            collected_facts = ffc.collect()
            # Test if collected_facts is a dictionary
            assert isinstance(collected_facts, dict)
            # Test if the returned dictionary is correct (key and value)
            assert 'fips' and True == collected_facts.items()

# Generated at 2022-06-20 19:26:33.577918
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert isinstance(obj._fact_ids, set)
    assert len(obj._fact_ids) == 1


# Generated at 2022-06-20 19:26:36.102223
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    result = fips_fc.collect()
    assert result['fips'] == False

# Generated at 2022-06-20 19:26:39.985694
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()


# Generated at 2022-06-20 19:26:42.508753
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert isinstance(obj, FipsFactCollector)


# Generated at 2022-06-20 19:26:50.265418
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import Collector
    the_module = mock_module()
    facts = dict()

    c = Collector(the_module, facts)
    c.collect()
    assert not c.facts['fips']

    f = FipsFactCollector(the_module, {})
    f_data = f.collect()
    assert f_data['fips'] == False

# Generated at 2022-06-20 19:26:52.593567
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'

# Generated at 2022-06-20 19:28:04.151321
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()
    assert fips_facts_collector.__class__.__name__ == 'FipsFactCollector'


# Generated at 2022-06-20 19:28:06.439790
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'

# Generated at 2022-06-20 19:28:08.609803
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-20 19:28:12.171597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsObj = FipsFactCollector()
    testDict = { "fips" : True }
    assert fipsObj.collect() == testDict
    fipsObj = FipsFactCollector()
    testDict = { "fips" : False }
    assert fipsObj.collect() == testDict

# Generated at 2022-06-20 19:28:14.462357
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts

# Generated at 2022-06-20 19:28:17.497459
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFact = FipsFactCollector()
    assert fipsFact.name == 'fips'
    assert fipsFact._fact_ids

# Generated at 2022-06-20 19:28:19.973893
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"


# Generated at 2022-06-20 19:28:21.406083
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    blk = FipsFactCollector()
    fips = blk.collect()
    # Always expect fips true/false
    assert 'fips' in fips

# Generated at 2022-06-20 19:28:25.429197
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup an instance of the FipsFactCollector and collect facts
    c = FipsFactCollector()
    facts = c.collect()

    # Test that fips key is present and has a boolean value
    assert 'fips' in facts
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-20 19:28:29.445796
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()

    assert result is not None

# Generated at 2022-06-20 19:30:50.064938
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()



# Generated at 2022-06-20 19:30:55.706618
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test when data exists
    fips_facts = dict()
    fips_facts['fips'] = False
    data = "1"
    mock_get_file_content = lambda x:data
    FipsFactCollector.get_file_content = mock_get_file_content
    assert FipsFactCollector.collect() == fips_facts
    # Test when data does not exists
    data = ""
    mock_get_file_content = lambda x:data
    FipsFactCollector.get_file_content = mock_get_file_content
    assert FipsFactCollector.collect() == fips_facts

# Generated at 2022-06-20 19:30:57.499872
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-20 19:31:00.246499
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert isinstance(f, FipsFactCollector)
    assert f.name == 'fips'

# Generated at 2022-06-20 19:31:04.417705
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create an object of class FipsFactCollector
    fips_fact_collector_obj = FipsFactCollector()

    assert fips_fact_collector_obj.__class__.name  == "fips"
    assert fips_fact_collector_obj.__class__._fact_ids == set()

# Generated at 2022-06-20 19:31:06.793676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-20 19:31:07.407831
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:31:10.105449
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsCollector = FipsFactCollector()
    FipsCollector.collect()
    assert FipsCollector.name == 'fips'
    assert 'fips' in FipsCollector.fqdn_facts

# Generated at 2022-06-20 19:31:13.686712
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect(module=None, collected_facts=None)
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-20 19:31:14.736847
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
	test_obj = FipsFactCollector()
	test_obj.collect()