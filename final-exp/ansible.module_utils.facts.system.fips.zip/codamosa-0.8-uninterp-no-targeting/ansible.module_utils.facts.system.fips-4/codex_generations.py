

# Generated at 2022-06-20 19:22:12.777988
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Mock the get_file_content method to return '1'
    FipsFactCollector.get_file_content = lambda *_, **__: '1'

    # Test to ensure if collect method is working as expected or not
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == True


# Generated at 2022-06-20 19:22:14.412486
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector is not None

# Generated at 2022-06-20 19:22:19.587258
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fake_module = dict()
    fake_facts = dict()
    FipsFactCollector(fake_module).collect(module=fake_module, collected_facts=fake_facts)
    assert fake_facts['fips'] is False

# Generated at 2022-06-20 19:22:22.825634
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:22:30.048282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_file_true = {'/proc/sys/crypto/fips_enabled': '1'}
    fips_file_false = {'/proc/sys/crypto/fips_enabled': '0'}
    fips_file_none = {}

    fips_obj = FipsFactCollector(module=None, collected_facts=None)
    fips_facts = {}

    # Case 1: fips=True
    fips_facts = fips_obj.collect(module='/usr/bin/ansible', collected_facts=None, file_facts=fips_file_true)
    assert fips_facts['fips'] is True

    # Case 2: fips=False

# Generated at 2022-06-20 19:22:34.216820
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-20 19:22:40.994620
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test case with:
    * fips_enabled file present and it has value of 0
    Expected result:
    * fips should be set to False
    """
    from ansible.module_utils.basic import AnsibleModule

    mocked_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    fips_obj = FipsFactCollector(mocked_module)
    fips_obj._read_file = lambda x: '0'
    assert fips_obj.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:43.889697
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collect = FipsFactCollector()
    assert collect.name == 'fips'
    assert collect._fact_ids == set()


# Generated at 2022-06-20 19:22:45.458783
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 1

# Generated at 2022-06-20 19:22:55.865848
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    def get_file_content_mock(path):
        return path

    mocker_fips_enabled_file_content = mocker.patch('ansible.module_utils.facts.collector.fips.get_file_content')
    mocker_fips_enabled_file_content.side_effect = get_file_content_mock

    # Testing for facts is empty
    test_collector = FipsFactCollector()
    test_fct = test_collector.collect(collected_facts=None)
    assert test_fct == {'fips': '/proc/sys/crypto/fips_enabled'}

    # Testing for fips enabled
    test_collector = FipsFactCollector()
    test_fct = test_collector.collect(collected_facts={})
    assert test_f

# Generated at 2022-06-20 19:23:02.960519
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:12.381831
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Build a list of fact collector objects
    fact_collector_objects_list = []
    for fc in BaseFactCollector.get_fact_collector_classes_names():
        fact_collector_objects_list.append(globals()[fc]())
    ref_data = {'filesystems': 
        {'filesystems': ['aufs', 'bdev', 'devtmpfs', 'mqueue', 'overlay']}, 
                 'fips': {'fips': False}}
    # Run collect method 
    result = FipsFactCollector().collect(None,ref_data)
    assert result == {'fips': False}


# Generated at 2022-06-20 19:23:18.497599
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Get the class to test
    from ansible.module_utils.facts.collectors.platform.fips import FipsFactCollector

    # Create an instance of the class to test
    result = FipsFactCollector()

    # Run the method collect of the class to test
    result.collect()

    # The result should be a dict
    assert isinstance(result, FipsFactCollector)

    # The result should have the attribute 'fips'
    assert hasattr(result, 'fips')

    # The fips attribute should be a bool
    assert isinstance(result.fips, bool)

# Generated at 2022-06-20 19:23:28.325035
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set up mocks
    from ansible.module_utils.facts.utils import get_file_content as utils_get_file_content
    m_utils_get_file_content = mocker.patch('ansible.module_utils.facts.utils.get_file_content')
    m_utils_get_file_content.side_effect = utils_get_file_content
    # Test
    fips_fc = FipsFactCollector()
    fips_fc.collect()
    assert m_utils_get_file_content.call_args_list == [mocker.call('/proc/sys/crypto/fips_enabled')]

# Generated at 2022-06-20 19:23:39.896348
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    import os
    import sys

    # Create a temporary directory
    tmp_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../../unit/tmp'))
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    # Create temporary files
    filename = os.path.join(tmp_dir, 'ansible_fips_enabled')
    with open(filename, 'w') as f:
        f.write('1')

    # Create an instance of FipsFactCollector
    fact_collector = FipsFactCollector()
    # Create an

# Generated at 2022-06-20 19:23:49.765984
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test for FipsFactCollector
    """
    test_FipsFactCollector_collect_result = {'fips': True}
    test_FipsFactCollector_collect_result1 = {'fips': False}
    test_FipsFactCollector_collect_exp = FipsFactCollector()
    assert test_FipsFactCollector_collect_exp.collect() == \
        test_FipsFactCollector_collect_result
    assert test_FipsFactCollector_collect_exp.collect() == \
        test_FipsFactCollector_collect_result1

# Generated at 2022-06-20 19:23:53.513039
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f_FipsFactCollector = FipsFactCollector()
    assert f_FipsFactCollector
    assert f_FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:24:01.910759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import sys
    import pytest
    import tempfile
    import textwrap
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fips_file = os.path.join(tmpdir, 'fips_enabled')
    with open(fips_file, 'w') as f:
        f.write('1')

    # Get the current path and add the temporary directory to it
    paths = os.environ['PATH'].split(':')
    paths.insert(0, tmpdir)
    os.environ['PATH'] = ':'.join(paths)

    # Create a FipsFactCollector instance

# Generated at 2022-06-20 19:24:08.040054
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test if the Fips is correctly detected"""
    from ansible.module_utils.facts import timeout
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector = FipsFactCollector()
    content = to_bytes("1")
    def get_file_content_mock(path):
        return content

    def get_file_lines_mock(path):
        return []

    def get_file_content_empty(path):
        return ""

    def get_file_content_not_exist(path):
        raise IOError()

    # Check if the command is correctly detected as available

# Generated at 2022-06-20 19:24:11.971567
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect() == {'fips': False}

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-20 19:24:19.641319
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

# Generated at 2022-06-20 19:24:24.649403
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector(None, None)
    assert fips_facts_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:27.743263
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Unit test"""
    fa = FipsFactCollector()
    assert fa.name == 'fips'
    assert fa._fact_ids == set()

# Generated at 2022-06-20 19:24:35.221240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollectorException
    import os.path

    fips_file = '/proc/sys/crypto/fips_enabled'
    fips_data_in = '1'
    fips_data_out = '0'

    mock_data = None
    mock_exceptions = None
    def mock_get_file_content(file, default=None):
        mock_data['file'] = file
        return mock_data['content']
    def mock_isfile(path):
        mock_data['file_exists'] = True
        return True

    original_get_file_content = get_file_content
    original_isfile = os.path.isfile


# Generated at 2022-06-20 19:24:38.746582
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    new_facts = fips_fact_collector.collect(collected_facts=collected_facts)
    assert new_facts['fips'] == False

# Generated at 2022-06-20 19:24:44.811891
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    fips_facts = fips_fc.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts
    # sample return value (may vary on different systems)
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-20 19:24:53.279028
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Create an instance of the FipsFactCollector class.

    Verify the fact value returned by the collect method.
    """
    collector = FipsFactCollector()
    module = None
    collected_facts = {}
    expected_facts = { 'fips': True }
    def get_file_content(path):
        return "1"
    collector.get_file_content = get_file_content
    facts = collector.collect(module, collected_facts)
    assert facts == expected_facts


# Generated at 2022-06-20 19:24:59.302511
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect()['fips']
    collector.collect_file_content['/proc/sys/crypto/fips_enabled'] = '0'
    assert not collector.collect()['fips']
    del collector.collect_file_content['/proc/sys/crypto/fips_enabled']
    assert collector.collect()['fips']

# Generated at 2022-06-20 19:25:03.654198
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    result = FipsFactCollector_obj.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-20 19:25:10.914140
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert get_file_content.exists
    assert BaseFactCollector.collect.exists
    fc = FipsFactCollector()
    # notes: 'get_file_content' should exist in the namespace
    def get_file_content_side_effect(fn):
        if fn == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return ''
    get_file_content.side_effect = get_file_content_side_effect
    assert fc.collect() == {'fips': True}

# Generated at 2022-06-20 19:25:27.250489
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsc = FipsFactCollector()
    assert fipsc.name == "fips"
    assert hasattr(fipsc, 'collect')

# Generated at 2022-06-20 19:25:28.532781
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:25:33.177413
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_functor = FipsFactCollector()
    assert fips_functor.name == 'fips'
    assert fips_functor._fact_ids == set()

# Generated at 2022-06-20 19:25:37.235214
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    file_content = fips_fact.collect()
    # Test is fips is set to False
    assert file_content == {'fips': False}

# Generated at 2022-06-20 19:25:49.418028
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    def fake_get_file_content(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        elif path == '/proc/sys/kernel/random/boot_id':
            return 'fake_bootid'
        elif path == '/sys/devices/virtual/dmi/id/product_uuid':
            return 'fake_uuid'
        else:
            return None

    Collector.fetch_file_content = fake_get_file_content
    collector = FipsFactCollector()
    result = collector.collect()
    assert result['fips'] is True



# Generated at 2022-06-20 19:25:53.515065
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fips_facts = FipsFactCollector().collect(module, collected_facts)

    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:25:58.373857
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test what happens when we attempt to collect facts
       with a FipsFactCollector
    """
    # Create a FipsFactCollector object
    fipsfc_instance = FipsFactCollector()
    assert fipsfc_instance.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:02.706163
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    res = f.collect()
    assert type(res) == dict
    assert res['fips'] in [True, False]

# Generated at 2022-06-20 19:26:03.829277
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fact = collector.collect()
    assert fact['fips'] == False

# Generated at 2022-06-20 19:26:06.109639
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] is True


# Generated at 2022-06-20 19:26:21.205736
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-20 19:26:26.347337
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open("test/unit/files/fips_proc") as fipsfile:
        fipsfile_data = fipsfile.read()
    collector = FipsFactCollector()
    fips_facts = collector.collect(collected_facts={})
    assert fips_facts == {'fips': True}

# Generated at 2022-06-20 19:26:30.418315
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    module = None
    fips_fact_collector = FipsFactCollector(module)
    assert fips_fact_collector is not None

# Generated at 2022-06-20 19:26:34.783210
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    ret = fips_facts_collector.collect()
    assert isinstance(ret, dict)
    assert 'fips' in ret

# Generated at 2022-06-20 19:26:40.087134
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = MagicMock()

    mock_get_file_content = MagicMock()
    mock_get_file_content.return_value = '1'

    with patch.multiple(FipsFactCollector, get_file_content=mock_get_file_content):
        fips_facts_collector = FipsFactCollector()
        mock_module.params = {'gather_subset': 'all'}

        # Test collect method
        result = fips_facts_collector.collect(module=mock_module)
        assert result == {'fips': True}


# Generated at 2022-06-20 19:26:45.895185
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    from unittest_data_provider import data_provider
    from ansible.module_utils.facts.collector import FactsCollector

    ff = FipsFactCollector()
    ff.name = 'fips'
    f = dict()

    def test_data():
        return [
            ('1', True,),
            ('0', False,),
            ('2', False,),
            ('', False,),
            (None, False,),
        ]

    @data_provider(test_data)
    def test_collect(value, expected_fips):
        f.update(ff.collect())
        assert f['fips'] == expected_fips

    # Override the /proc/sys/crypto/fips_enabled file
    fips_enabled_file = os.path.realpath

# Generated at 2022-06-20 19:26:48.188795
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert 'fips' in fips._fact_ids

# Generated at 2022-06-20 19:26:49.662597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect()['fips'] == False

# Generated at 2022-06-20 19:26:51.945041
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:57.961318
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, Facts
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines, get_file_size, get_mount_size

    # Mock AnsibleModule
    try:
        from ansible.module_utils.facts import collector
    except ImportError:
        import ansible.module_utils.facts.collector as collector

    class MockAnsibleModule(object):

        def __init__(self):
            self.exit_json = None
            self.fail_json = None

        def exit_json(self, **kwargs):
            self.exit_json = kwargs

        def fail_json(self, **kwargs):
            self.fail_json = kwargs

    fipsfile = """
    1
    """

# Generated at 2022-06-20 19:27:34.364629
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:27:36.416424
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:27:41.375225
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert isinstance(FipsFactCollector.collect(), dict)

# Generated at 2022-06-20 19:27:44.284664
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-20 19:27:47.707037
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    result = ffc.collect()
    assert result is not None
    assert 'fips' in result
    assert type(result['fips']) == bool
    assert result['fips'] == False

# Generated at 2022-06-20 19:27:49.576079
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    try:
        FipsFactCollector()
    except:
        raise AssertionError()

# Generated at 2022-06-20 19:27:54.901756
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with patch('ansible.module_utils.facts.collector.FipsFactCollector.get_file_content', return_value=1):
        fips_collector = FipsFactCollector()
        assert fips_collector.collect()['fips'] is True

# Generated at 2022-06-20 19:27:57.461242
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    test_obj = FipsFactCollector()
    assert test_obj.name == 'fips'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-20 19:28:01.620879
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:28:03.943870
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    assert FipsFactCollector.collect()['fips'] == False

# Generated at 2022-06-20 19:29:07.526351
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc
    assert fc.name == 'fips'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 19:29:11.005705
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """
    Test FipsFactCollector constructor
    """
    f = FipsFactCollector()
    assert f is not None

# Generated at 2022-06-20 19:29:15.070840
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:29:18.299918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:29:24.618825
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj.collect() == dict(fips=False)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 19:29:26.233728
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsc = FipsFactCollector()
    assert fipsc.collect() == {'fips': False}

# Generated at 2022-06-20 19:29:31.448423
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create namedtuple mock object for 'distribution'
    Distribution = type('Distribution', (object,), {'name': 'CentOS Linux'})
    # create namedtuple mock object for 'distribution'
    Version = type('Version', (object,), {'major': '7','minor': '7'})
    # create mock version and distribution
    module = type('module', (object,), {'version_info': Version,'distribution_info': Distribution})
    # create mock object for 'collected_facts'
    collected_facts = type('collected_facts', (object,), {'fips': False})
    # create object for FipsFactCollector
    fips = FipsFactCollector()
    # call the method collect of class FipsFactCollector

# Generated at 2022-06-20 19:29:36.355411
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert not fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:29:39.511405
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert len(ffc._fact_ids) == 0
    assert isinstance(ffc, BaseFactCollector)


# Generated at 2022-06-20 19:29:43.565020
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()