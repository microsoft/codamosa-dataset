

# Generated at 2022-06-20 19:22:04.276884
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj_FipsFactCollector = FipsFactCollector()
    assert obj_FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:22:09.527162
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect().get('fips', None) == None

# vim: set et ts=4 sw=4

# Generated at 2022-06-20 19:22:12.558296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    assert collector.collect() == { "fips": False }

# Generated at 2022-06-20 19:22:15.403601
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips = fips_collector.collect(collected_facts={})
    assert isinstance(fips, dict)
    assert isinstance(fips['fips'], bool)
    assert fips['fips'] == True

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 19:22:20.636524
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_data = {}
    fips_data['fips'] = False
    fips_data['fips'] = True

    assert FipsFactCollector.collect() == fips_data

# Generated at 2022-06-20 19:22:29.454039
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Test case: file does not exist
    # Run command: collect
    # Expected results:
    # ansible_fips set to False
    m = FipsFactCollector()
    result = m.collect()
    assert('fips' in result and result['fips'] is False)

    # Test case: file exists, fips_enabled = 1
    # Run command: collect
    # Expected results:
    # ansible_fips set to True
    m = FipsFactCollector()
    m.file_exists = True
    m.file_read = True
    m.file_content = ['1']
    result = m.collect()
    assert('fips' in result and result['fips'] is True)

    # Test case: file exists, fips_enabled = 0
    # Run command: collect


# Generated at 2022-06-20 19:22:36.607300
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import os

    class MockModule:
        pass

    test_class = FipsFactCollector()
    test_module = MockModule()
    test_module.warn = lambda *args, **kwargs: sys.stderr.write(args[0] + '\n')

    test_module.params = {}
    test_module.params['gather_subset'] = ['all']
    test_class._module = test_module

    test_facts = {}
    test_file_content = b'0'
    test_class.get_file_content = lambda x: test_file_content

    test_result = test_class.collect(module=None, collected_facts=test_facts)
    assert test_result == {'fips': False}

    test_file_content = b'1'
   

# Generated at 2022-06-20 19:22:38.304204
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:22:42.022124
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'

# Unit test of collect method of class FipsFactCollector when file exists.

# Generated at 2022-06-20 19:22:43.002972
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:47.830524
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == "fips"


# Generated at 2022-06-20 19:22:50.992806
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:22:54.590973
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips is not None
    assert fips.name == 'fips'



# Generated at 2022-06-20 19:22:58.539004
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    test_fips_fact_collector = FipsFactCollector()
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:23:08.332964
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup a mock for the FipsFactCollector's _load_platform_subset method
    FipsFactCollector._load_platform_subset = lambda x, y: {}

    # Setup a mock for the FipsFactCollector's _get_platform_fact_defaults method
    FipsFactCollector._get_platform_fact_defaults = lambda x: {}

    # Setup a mock for the BaseFactCollector's get_all_facts method
    BaseFactCollector.get_all_facts = lambda x, y, z: {}

    # Create a FipsFactCollector object
    fact_collector = FipsFactCollector()

    # Create a mock module
    module = type('module', (object,), {})

    # Collect facts
    result = fact_collector.collect(module=module)

    # Test assertions
   

# Generated at 2022-06-20 19:23:12.310430
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsCollector()
    assert fips_collector is not None

# Generated at 2022-06-20 19:23:20.289289
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Test 1: the file does not exist
    # fips_fact_collector._module = AnsibleModuleMock(dict(path='/nonexistent', fail_on_missing=False))
    # with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command') as mocked_run_command:
    #     mocked_run_command.return_value = (1, '', '')
    #     output = fips_fact_collector.collect()
    #     mocked_run_command.assert_called_with(['find', '/nonexistent', '-name', '*.service'])
    #     assert output == {}
    # Test 2: the file is not set

# Generated at 2022-06-20 19:23:25.577280
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert isinstance(fips_obj._fact_ids,set)
    assert fips_obj.name in fips_obj._fact_ids

# Generated at 2022-06-20 19:23:27.586624
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-20 19:23:34.796557
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize class
    fipsFactCollector = FipsFactCollector()

    # Initialize parameters
    module = None
    collected_facts = None

    # Call method
    fips_facts = fipsFactCollector.collect(module, collected_facts)

    # Assertions
    assert isinstance(fips_facts, dict)

# Generated at 2022-06-20 19:23:40.464939
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# Generated at 2022-06-20 19:23:45.234719
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    ret = fips_fact_collector.collect()
    assert type(ret) is dict
    assert ret == {'fips': False}

# Generated at 2022-06-20 19:23:52.089942
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # init the FipsFactCollector
    fips_collector = FipsFactCollector()
    # check if it is not None
    assert fips_collector is not None
    # check type
    assert isinstance(fips_collector, FipsFactCollector)
    # collect facts
    facts = fips_collector.collect()
    # check if facts is not None
    assert facts is not None
    # check if fips key is in facts dict
    assert 'fips' in facts

# Generated at 2022-06-20 19:23:56.218233
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  # Create instance of FipsFactCollector
  # Collector info:
  # name = 'fips'
  # _fact_ids = set()
  #  = 'fips'
  x = FipsFactCollector()
  # Invoke collect method
  ret = x.collect()
  # Asserts
  assert(ret == {'fips': False})
  return

# Generated at 2022-06-20 19:23:59.417868
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFacts = FipsFactCollector()
    assert "fips" == fipsFacts.name
    assert 0 != len(fipsFacts._fact_ids)
    assert isinstance({}, fipsFacts.collect())

# Generated at 2022-06-20 19:24:04.365730
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    result = obj.collect()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()
    assert result['fips'] is False

# Generated at 2022-06-20 19:24:08.200684
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    response = FipsFactCollector()
    assert 'fips' in response.name
    assert not response._fact_ids
    assert response.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:10.824255
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert not fips._fact_ids

# Generated at 2022-06-20 19:24:15.043296
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:24:16.922853
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-20 19:24:26.614532
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    facts = fips_collector.collect()
    if facts.get('fips'):
        assert isinstance(facts.get('fips'), bool)
    assert 'fips' in facts


test_FipsFactCollector_collect()

# Generated at 2022-06-20 19:24:28.844504
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_obj = FipsFactCollector()
    assert facts_obj.name == 'fips'
    assert facts_obj._fact_ids == set()


# Generated at 2022-06-20 19:24:30.904586
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-20 19:24:35.344556
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:24:36.189553
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:24:39.169491
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids  == set()
    FipsFactCollector()

# Generated at 2022-06-20 19:24:42.132436
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:24:43.461469
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_object = FipsFactCollector()
    assert my_object is not None

# Generated at 2022-06-20 19:24:48.051608
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:24:50.019485
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector(None)
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:24:58.941475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    result = test_obj.collect()
    assert type(result) == dict
    assert result['fips'] == False

# Generated at 2022-06-20 19:25:02.295496
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector('dummy', 'dummy')
    assert fips_collector is not None


# Generated at 2022-06-20 19:25:11.847764
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_collector = FipsFactCollector()
    result = test_collector.collect()
    # NOTE: this is populated even if it is not set
    assert result['fips'] == False

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.params['path'] = '/proc/sys/crypto/fips_enabled'
    module.params['content'] = to_bytes('1')
    test_collector.populate_file_dict(module)
    result = test_collector.collect()
    assert result['fips'] == True

# Generated at 2022-06-20 19:25:13.861294
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector

# Generated at 2022-06-20 19:25:16.516147
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'


# Generated at 2022-06-20 19:25:26.558073
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collector

    # Save the FactCollectors from the module to restore after running the test
    fact_collectors = ansible.module_utils.facts.collector.FactCollectors

    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()
    assert fips_fc.collect() == {'fips': False}

    # Restore the FactCollectors in the module
    ansible.module_utils.facts.collector.FactCollectors = fact_collectors

# Generated at 2022-06-20 19:25:28.078279
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  fips_fact = FipsFactCollector()
  assert fips_fact.name == 'fips'

# Generated at 2022-06-20 19:25:29.415622
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:25:35.840374
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert 'fips' in x._fact_ids
    assert x._fact_ids.__len__() == 1
    assert x.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:40.179997
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # create an instance of FipsFactCollector
    my_obj = FipsFactCollector()
    # check the name of the instance
    assert my_obj.name == 'fips'
    # check the fact ids of the instance
    assert my_obj._fact_ids == set()
    # check the instance(my_obj) is instance of FipsFactCollector
    assert isinstance(my_obj, FipsFactCollector)


# Generated at 2022-06-20 19:25:56.454893
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result is not None
    assert result['fips'] is False

    fips_fact_collector._open_file = MockOpen({'/proc/sys/crypto/fips_enabled': '1'})
    result = fips_fact_collector.collect()
    assert result['fips'] is True


# Generated at 2022-06-20 19:26:09.268234
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    test the collect of FipsFactCollector
    '''
    from ansible.module_utils.facts.collectors.fips import FipsFactCollector
    from ansible.module_utils.facts.collectors.fips import get_file_content

    # create a FipsFactCollector object
    fips_obj = FipsFactCollector()

    # set of variables to pass to run
    set_variables = {}

    # the data in the fips file
    fips_file_content = '1'

    # mock the method get_file_content
    get_file_content_mock = dict(
        side_effect = lambda x: fips_file_content
    )

# Generated at 2022-06-20 19:26:11.547981
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc.collect() == {'fips': True}

# Generated at 2022-06-20 19:26:12.148681
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-20 19:26:13.504588
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    assert c.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:15.520030
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:26:18.341239
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector(None, None)
    assert collector.name == 'fips'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:26:21.123091
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    fips_facts = FipsFactCollector.collect()
    assert fips_facts

# Generated at 2022-06-20 19:26:25.630847
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collect_result = FipsFactCollector().collect()
    # Did we get a dict in return?
    assert type(collect_result) == dict
    # Did the dict have the key fips?
    assert 'fips' in collect_result

# Generated at 2022-06-20 19:26:26.709079
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-20 19:26:55.529141
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:26:59.840176
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:27:03.400902
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    fips_facts = fact_collector.collect()
    assert fips_facts == {'fips': False}

# Generated at 2022-06-20 19:27:06.095519
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_FipsFactCollector = FipsFactCollector()
    assert test_FipsFactCollector.collect().get('fips') == False

# Generated at 2022-06-20 19:27:17.872228
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    # Mock class for FipsFactCollector
    class MockClass():
        def __init__(self):
            pass
        
        # Mock method for get_file_content
        def get_file_content(file_path):
            return '1'
        
    # Mock class of BaseFactCollector
    class MockBaseFactCollector():
        def __init__(self):
            pass
        
        def filter_facts(self, facts):
            return facts
        
    # Set up required mocks
    m_FipsFactCollector = MockClass()
    m_FipsFactCollector.get_file_content = MockClass.get_file_content
    
    m_BaseFactCollector = MockBaseFactCollector()
    
    # Call method under test
    result = m_BaseFactCollector.filter_facts

# Generated at 2022-06-20 19:27:22.482221
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:27:26.697808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Unit tests for function collect() of class FipsFactCollector.

# Generated at 2022-06-20 19:27:31.603476
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert 'fips' in obj._fact_ids
    assert obj.collect()['fips'] == False

# Generated at 2022-06-20 19:27:35.131686
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-20 19:27:36.802636
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-20 19:28:40.996646
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # loading valid content
    content = '1'
    module = lambda: None
    setattr(module, 'run_command', lambda x, check_rc=True, executable=None: (0, content, ''))
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect(module=module)
    assert isinstance(collected_facts, dict)
    assert collected_facts['fips'] == True
    # loading invalid content
    content = ''
    module = lambda: None
    setattr(module, 'run_command', lambda x, check_rc=True, executable=None: (0, content, ''))
    fact_collector = FipsFactCollector()
    collected_facts = fact_collector.collect(module=module)
    assert isinstance(collected_facts, dict)

# Generated at 2022-06-20 19:28:50.314151
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module_mock = True
    fips_fact_collector._read_file_mock = True
    # Return None and test the code behavior
    fips_fact_collector._read_file_mock.return_value = None
    assert fips_fact_collector.collect() == {'fips': False}
    # Return empty and test the code behavior
    fips_fact_collector._read_file_mock.return_value = ''
    assert fips_fact_collector.collect() == {'fips': False}
    # Return Fips enabled and test the code behavior
    fips_fact_collector._read_file_mock.return_value = '1'
    assert fips_fact_

# Generated at 2022-06-20 19:28:53.049595
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsCollector.collect()"""

    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:28:54.466275
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:28:57.093842
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert (facts['fips'] == False) or (facts['fips'] == True)


# Generated at 2022-06-20 19:29:05.849822
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initializing FipsFactCollector
    test_obj = FipsFactCollector()
    # Working with response
    response = test_obj.collect()
    # Test if response is dict
    assert isinstance(response, dict)
    # Test if response has the key fips
    assert 'fips' in response
    # Test if response has boolean value for key fips

# Generated at 2022-06-20 19:29:13.910824
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # test 1
    fips_facts_collector = FipsFactCollector()
    fixtures = [
                '/proc/sys/crypto/fips_enabled',
        ]
    for fixture in fixtures:
        magic_mock = MagicMock(name="get_file_content")
        magic_mock.return_value = None

        with patch.object(fact_collector, "get_file_content", magic_mock, create=True):
            result = fips_facts_collector.collect()
            assert type(result) is dict
            assert 'fips' in result
            assert result['fips'] == False

    # test 2
    fips_facts_collector = FipsFactCollector()
    fixtures = [
                '/proc/sys/crypto/fips_enabled',
        ]

# Generated at 2022-06-20 19:29:19.455213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    ffc = FipsFactCollector()
    expected_result = {'fips': False}
    assert ffc.collect() ==  expected_result
    assert ffc.collect(collected_facts) ==  expected_result
    assert ffc.collect(collected_facts, module) == expected_result

# Generated at 2022-06-20 19:29:28.657892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    params = {
        'ansible_facts':{
            'processor': ['model name      : Intel(R) Xeon(R) CPU E5-2640 v4 @ 2.40GHz']
        },
        'ansible_distribution': 'SUSE',
        'ansible_distribution_release': '42.1',
        'ansible_distribution_version': '',
    }
    collector = FipsFactCollector()
    result = collector.collect(params, None)
    assert result['fips'] == False

# Generated at 2022-06-20 19:29:32.870258
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:31:59.985120
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'