

# Generated at 2022-06-20 19:22:06.697132
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    assert test_obj

# Generated at 2022-06-20 19:22:09.526959
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:22:13.577199
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] == False

# Generated at 2022-06-20 19:22:19.064867
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collected_facts = {}
    fact_collector = FipsFactCollector()
    fact_collector.collect(collected_facts=collected_facts)

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-20 19:22:22.301851
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:22:25.102441
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""

    # create a dummy module

# Generated at 2022-06-20 19:22:25.999193
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector().collect()

# Generated at 2022-06-20 19:22:32.425649
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()
    assert ffc.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:35.417801
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.priority == 1

# Generated at 2022-06-20 19:22:39.756028
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    fips_status = result['fips']
    assert isinstance(fips_status, bool)

# Generated at 2022-06-20 19:22:45.852080
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    # Verify the constructor
    assert fips_fact
    assert fips_fact.name == "fips"

# Generated at 2022-06-20 19:22:49.453283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()

    # fips_filepath = None
    # fips_content = '1'
    # fips_data = fips_content.splitlines()
    # fips_data[0] = '1'
    # fips_collector.get_file_content = MagicMock(return_value=fips_data)
    # fips = fips_collector.collect()

    # fips_filepath = None
    # fips_content = '0'
    # fips_data = fips_content.splitlines()
    # fips_data[0] = '0'
    # fips_collector.get_file_content = MagicMock(return_value=fips_data)
    # fips = fips_collector.collect()

# Generated at 2022-06-20 19:22:52.627372
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    data = fips.collect()

    assert(data['fips'] == True)

# Generated at 2022-06-20 19:22:55.690433
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()


# Generated at 2022-06-20 19:23:02.394656
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    fips_facts = {u'fips': True}

    obj = FipsFactCollector()
    obj.get_file_content = lambda x: "1"

    assert obj.collect() == fips_facts

# Generated at 2022-06-20 19:23:04.675880
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    data = fips.collect()
    assert data['fips'] == False

# Generated at 2022-06-20 19:23:09.882196
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a new instance of FipsFactCollector
    ffc_obj = FipsFactCollector()

    # Define dict fips_facts
    fips_facts = {'fips': False}

    # Call method collect
    ffc_obj.collect()

    # Compare values ffc_obj.collect() and fips_facts
    assert ffc_obj.collect() == fips_facts

# Generated at 2022-06-20 19:23:14.012002
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()

# Generated at 2022-06-20 19:23:16.329567
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:28.748850
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: '\x00' is the null byte
    # NOTE: there is a python bug that doesn't permit the null byte to be passed as a string
    #       so we pass a list of chars instead
    # TODO: python bug
    #fips_enabled = get_file_content('/proc/sys/crypto/fips_enabled')  # NOTE: always populated
    fips_enabled = ['\x00']
    fips_enabled_1 = ['1']
    fips_enabled_0 = ['0']

    # all fips_enabled string should pass the test
    fips = FipsFactCollector()

    # empty string
    result = fips.collect()
    assert result['fips'] == False

    # null byte
    result = fips.collect(fips_enabled)

# Generated at 2022-06-20 19:23:35.984253
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collectors = ['fips']
    fips = FipsFactCollector(collectors)
    assert fips.name == 'fips'



# Generated at 2022-06-20 19:23:37.492215
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:23:47.669183
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    temp_collector = FipsFactCollector()
    # arrange
    class ModuleMock():
        def __init__(self):
            self.params = {
                "gather_subset": ["all"]
            }
    temp_module = ModuleMock()
    # act
    result = temp_collector.collect(temp_module)
    # assert
    assert isinstance(result, dict)
    assert result["fips"] == False


# Generated at 2022-06-20 19:24:00.095767
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def test_get_file_content(file_name):
        return '0'

    setattr(FipsFactCollector, '_get_file_content', test_get_file_content)
    collected_facts = {}
    module = object()
    ffc = FipsFactCollector()
    result = ffc.collect(module=module, collected_facts=collected_facts)
    assert 'fips' in result
    assert result['fips'] == False
    assert ffc._fact_ids == {'fips'}

    def test_get_file_content(file_name):
        return '1'

    setattr(FipsFactCollector, '_get_file_content', test_get_file_content)
    collected_facts = {}
    module = object()
    ffc = FipsFactCollector

# Generated at 2022-06-20 19:24:03.539688
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {
        'fips':  False,
    }

# Generated at 2022-06-20 19:24:06.818522
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:24:08.296570
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect()

# Generated at 2022-06-20 19:24:13.002723
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class TestModule:
        def open_file(f):
            if f == '/proc/sys/crypto/fips_enabled':
                return ['1', '']
            else:
                return ['', '']
        def get_bin_path(s):
            return ''
    fips_collector = FipsFactCollector(module=TestModule())
    assert fips_collector.collect()['fips'] == True

# Generated at 2022-06-20 19:24:14.822068
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector

# Generated at 2022-06-20 19:24:17.805301
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'


# Generated at 2022-06-20 19:24:33.398098
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_object = FipsFactCollector()
    assert test_object.collect()['fips'] == False

# Generated at 2022-06-20 19:24:39.067293
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    collected_facts = {}
    fips_facts.collect(collected_facts)
    assert collected_facts['fips'] == False or type(collected_facts['fips']) == bool

# Generated at 2022-06-20 19:24:41.583779
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert not x._fact_ids

# Generated at 2022-06-20 19:24:50.086852
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_module = {
        'set_fact': {
            'fips': False
        }
    }
    fips_facts = {}
    fips_factCollector = FipsFactCollector()

    def mock_get_file_content(data, path=None):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return None

    fips_factCollector._get_file_content = mock_get_file_content
    fips_facts = fips_factCollector.collect(fips_module, fips_facts)
    assert fips_facts['fips']

# Generated at 2022-06-20 19:24:53.311909
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsCollector = FipsFactCollector()
    assert fipsCollector.name == 'fips'

# Generated at 2022-06-20 19:24:54.549137
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:24:55.639392
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()


# Generated at 2022-06-20 19:24:56.504368
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert((FipsFactCollector.__name__ == 'FipsFactCollector'))

# Generated at 2022-06-20 19:24:59.469042
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert len(fips_collector._fact_ids) == 0


# Generated at 2022-06-20 19:25:00.998023
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:25:15.110782
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:25:16.515296
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:25:19.746922
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    instance = FipsFactCollector()
    assert hasattr(instance, 'name')
    assert callable(instance.collect)
    assert isinstance(instance._fact_ids, set)

# Generated at 2022-06-20 19:25:21.117048
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector(None)
    ffc.collect()

# Generated at 2022-06-20 19:25:27.442189
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    cont = "1"
    collection = collector.load_collectors(['fips'], basic.AnsibleModule)
    fips_facts = collection['fips']

    if fips_facts.do_collect(None, None):
        assert fips_facts._fact_ids == {'fips'}



# Generated at 2022-06-20 19:25:31.501455
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == "fips"
    assert fips._fact_ids == set()

# Generated at 2022-06-20 19:25:33.383562
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert 'fips' in FipsFactCollector._fact_ids

# Generated at 2022-06-20 19:25:37.332152
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:25:40.772522
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_data = { 'fips': True}
    assert FipsFactCollector().collect() == fips_data

# Generated at 2022-06-20 19:25:42.165133
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:07.854507
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert(obj.name == 'fips')


# Generated at 2022-06-20 19:26:13.617238
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    MockModule = type('MockModule', (object,), {})
    mock_module = MockModule()
    facts_collector = FipsFactCollector()
    data = facts_collector.collect(module=mock_module)
    assert data['fips'] == False


# Generated at 2022-06-20 19:26:17.107564
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert isinstance(fips, FipsFactCollector)
    assert isinstance(fips._fact_ids, set)

# Generated at 2022-06-20 19:26:17.848291
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-20 19:26:19.596388
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:26:25.530666
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import mock
    import tempfile
    with mock.patch.object(os.path,'exists',return_value=True):
        with tempfile.NamedTemporaryFile() as tmpfile:
            tmpfile.write(b'1')
            tmpfile.flush()
            f = FipsFactCollector()
            result = f.collect()
            assert result == {'fips': True}

# Generated at 2022-06-20 19:26:34.296555
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = FipsFactCollector()
    result = fact_collector.collect(module, collected_facts)
    assert(result['fips'] is False)

    fact_collector = FipsFactCollector(file_content='1')
    result = fact_collector.collect(module, collected_facts)
    assert(result['fips'] is True)

# Generated at 2022-06-20 19:26:37.746199
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()
    assert obj.collect() == {'fips': True}

# Generated at 2022-06-20 19:26:41.066090
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:26:43.455549
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts = fips.collect()
    assert type(fips_facts) is dict
    assert fips_facts['fips'] is False

# Generated at 2022-06-20 19:27:45.761124
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    val = FipsFactCollector()
    assert val.name == 'fips'
    assert val._fact_ids == set()


# Generated at 2022-06-20 19:27:55.270094
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.system import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(path, quiet=False):
        return "test data"

    # set up the test
    setattr(FactsCollector, '_collectors', {})
    FactsCollector._collectors['fips'] = FipsFactCollector()
    get_file_content = mock_get_file_content
    facts_collector = FactsCollector()
    facts = facts_collector.collect(module=None, collected_facts=None)

    # check the results
    assert facts['fips'] == True

# Generated at 2022-06-20 19:27:57.613780
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = {}
    results = collector.collect(collected_facts=collected_facts)
    assert results['fips'] == 0

# Generated at 2022-06-20 19:28:00.084075
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:28:02.978238
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:28:08.720707
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture = FipsFactCollector()
    tests = [
        {'content': '0', 'expected': False},
        {'content': '1', 'expected': True}
    ]
    for test in tests:
        (is_fips, fips_content) = False, None

        def mock_get_file_content(*args, **kwargs):
            return test['content']

        fixture.get_file_content = mock_get_file_content
        fixture.collect()
        fips_facts = fixture.collect()
        assert fips_facts['fips'] == test['expected']

# Generated at 2022-06-20 19:28:14.663060
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture = {
        '1': True,
        '0': False,
        '': False,
        'True': True,
        'False': False,
        'dummy': False,
    }
    def data(value):
        return lambda module, collected_facts: value
    fips_collector = FipsFactCollector()
    for value, result in fixture.items():
        fips_collector.get_file_content = data(value)
        actual = fips_collector.collect()
        assert 'fips' in actual
        assert actual['fips'] == result

# Generated at 2022-06-20 19:28:18.217089
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:28:20.210722
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert isinstance(fips, FipsFactCollector)


# Generated at 2022-06-20 19:28:21.827918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    fips_facts_dict = {}
    assert FipsFactCollector.name == 'fips'
    assert fips.collect(collected_facts=fips_facts_dict) is None

# Generated at 2022-06-20 19:30:45.601448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content

    # Set up FactCollector and register FipsFactCollector
    fact_collector = get_collector_instance(FactCollector)
    fips_fact_collector = get_collector_instance(FipsFactCollector)
    fact_collector.add_collector(fips_fact_collector)

    # Inject some mock data
    #
    # We use the class name as the key, so want to make sure that
    # test data won't match anything that could be found by the
    # FipsFactCollector.
    old_get_file_content = get_file_content


# Generated at 2022-06-20 19:30:47.302067
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:30:50.506213
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:30:52.133947
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:30:54.979876
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:30:56.450312
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips.collect()

# Generated at 2022-06-20 19:30:57.138007
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert hasattr(FipsFactCollector, 'collect')

# Generated at 2022-06-20 19:30:59.526346
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:31:09.324859
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    import os
    import tempfile
    my_fips_facts = dict(fips=False)
    my_collector = FipsFactCollector()
    my_path = tempfile.mktemp()
    fp = os.fdopen(os.open(my_path, os.O_WRONLY | os.O_CREAT, 0o600), 'w')
    fp.write('1')
    fp.close()
    my_fips_facts['fips'] = True
    assert my_collector.collect(collected_facts=dict()) == my_fips_facts
    my_fips_facts['fips'] = False
    # If the file does not exist then no values are returned
    os.remove(my_path)

# Generated at 2022-06-20 19:31:11.643584
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFact = FipsFactCollector()
    assert fipsFact.name == 'fips'