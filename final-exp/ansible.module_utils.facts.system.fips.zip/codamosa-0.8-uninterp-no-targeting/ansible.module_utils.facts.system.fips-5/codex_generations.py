

# Generated at 2022-06-20 19:22:16.128411
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_data={
        '/proc/sys/crypto/fips_enabled': '1',
    }

    facts_collector = FipsFactCollector(None, fixture_data=fixture_data)
    results = facts_collector.collect()
    assert results['fips'] == True

    fixture_data={
        '/proc/sys/crypto/fips_enabled': '0',
    }

    facts_collector = FipsFactCollector(None, fixture_data=fixture_data)
    results = facts_collector.collect()
    assert results['fips'] == False

# Generated at 2022-06-20 19:22:23.655096
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_argv = {}
    collected_facts = {}
    fips_facts = FipsFactCollector().collect(module_argv, collected_facts)
    # there is no guarantee that FIPS is not enabled so we have to
    # make the assert check against a default value
    assert fips_facts == {'fips': False} or fips_facts == {'fips': True}

# Generated at 2022-06-20 19:22:24.572631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass


# Generated at 2022-06-20 19:22:25.449622
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect()

# Generated at 2022-06-20 19:22:29.112482
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-20 19:22:30.448632
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:41.062366
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import unittest

    class FipsFactCollectorTest(unittest.TestCase):
        def setUp(self):
            self.sys_path=sys.path
            sys.path.append('/usr/lib/python2.7/dist-packages/')
            self.fips_fact_collector = FipsFactCollector()
            self.test_fips_facts = self.fips_fact_collector.collect()

        def test_fips_value(self):
            self.assertIn('fips', self.test_fips_facts)

        def tearDown(self):
            sys.path=self.sys_path

    suite = unittest.TestLoader().loadTestsFromTestCase(FipsFactCollectorTest)

# Generated at 2022-06-20 19:22:48.058855
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():  # pylint: disable=invalid-name
    fake_collected_facts = {'system': {'fips': False}}
    FipsFactCollector().collect(None, fake_collected_facts)
    assert fake_collected_facts['system']['fips'] == False
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:22:50.009234
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fc.collect()

# Generated at 2022-06-20 19:22:54.592219
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    result = FipsFactCollector().collect(module=module, collected_facts=collected_facts)
    assert result is not None
    assert sorted(result.keys()) == ['fips']
    assert result['fips'] is False

# Generated at 2022-06-20 19:23:01.057358
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:04.921282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    data = fips_fc.collect()
    assert "fips" in data.keys()
    assert isinstance(data["fips"], bool)

# Generated at 2022-06-20 19:23:10.059193
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # test case expected results
    fixture_expected_results = {
        'fips': False
    }

    # initialize the fact collector
    fact_collector = FipsFactCollector()

    # run the fact collector and get the results
    fact_collector_results = fact_collector.collect()

    # check that the fact collector results are as expected
    assert fact_collector_results == fixture_expected_results

# Generated at 2022-06-20 19:23:12.655484
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert 'fips' in fips_collector._fact_ids

# Generated at 2022-06-20 19:23:15.925771
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    res = fact_collector.collect()
    assert 'fips' in res
    assert isinstance(res['fips'], bool) or (res['fips'] is None)

# Generated at 2022-06-20 19:23:20.675917
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert 'fips' in fips_facts and type(fips_facts['fips']) is bool

# Generated at 2022-06-20 19:23:24.246284
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert 'fips' in fips_facts


# Generated at 2022-06-20 19:23:26.561514
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Constructor test
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:23:28.619075
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:23:31.001666
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-20 19:23:35.865307
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-20 19:23:37.880568
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Creating a new instance of class FipsFactCollector
    fips_collector = FipsFactCollector()

    # Testing the method collect of class FipsFactCollector
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:23:47.496173
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {}

    # Testing the collect method without any values
    output = fact_collector.collect(collected_facts=collected_facts)
    assert output['fips'] is False

    # Testing the collect method with fips value as true
    output = fact_collector.collect(collected_facts=collected_facts)
    assert output['fips'] is True

# Generated at 2022-06-20 19:23:51.531596
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    with open('test_FipsFactCollector_collect_data') as f:
        data = f.read()
        fips = fips_fact_collector.collect({'file': {'content': data}})
        assert fips == {'fips': True}

# Generated at 2022-06-20 19:23:54.946406
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector(None, None)
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-20 19:23:56.301856
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:23:59.712877
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()

    mock_module = type('obj', (object,), {'params': {}})
    mock_collected_facts = {}

    fips_facts = fc.collect(mock_module, mock_collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:24:05.148645
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    real_facts = fact_collector.collect()
    assert (type(real_facts) == dict)
    assert (real_facts['fips'] == False or real_facts['fips'] == True)

# Generated at 2022-06-20 19:24:12.724227
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create mock class for module
    import ansible.module_utils.facts.system.fips as fips_module
    fips_module.get_file_content = lambda x: None
    fips_module.get_file_content.return_value = '1'
    # create instance of class FipsFactCollector
    collect = FipsFactCollector(module=None, collected_facts=None)
    # invoke method using mock data
    fips_facts = collect.collect()
    # assert results
    assert fips_facts['fips'] == True

# Generated at 2022-06-20 19:24:15.843154
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = type('', (), {'params': {} })
    fips_facts = FipsFactCollector().collect(module)
    assert fips_facts.get('fips') == False

# Generated at 2022-06-20 19:24:23.431538
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:24:27.177228
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    expected_ans = {'fips': False}
    assert fipsFactCollector.collect() == expected_ans

# Generated at 2022-06-20 19:24:29.407353
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:42.019002
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import mock
    import tempfile
    import sys

    filename = tempfile.mkstemp()
    f = os.fdopen(filename[0], 'w')
    f.write('1')
    f.close
    filename = filename[1]

    not_fips = {'fips': False}
    fips = {'fips': True}

    FipsFactCollector._fact_ids = set()

    with mock.patch.object(sys, 'version_info', (2, 6)):
        with mock.patch('ansible.module_utils.facts.utils.get_file_content', return_value=None):
            assert FipsFactCollector.collect(module=None, collected_facts=None) == not_fips

# Generated at 2022-06-20 19:24:52.848191
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # 1. When /proc/sys/crypto/fips_enabled exists and contains 1, 
    # fips_facts should have fips=True
    fips_fact_collector._module = "fips_proc_1"
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] is True

    # 2. When /proc/sys/crypto/fips_enabled exists and contains 0, 
    # fips_facts should have fips=False
    fips_fact_collector._module = "fips_proc_0"
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] is False

    # 3. When /proc/sys

# Generated at 2022-06-20 19:24:58.479325
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    global FipsFactCollector

    # Unit test the constructor.
    test_instance = FipsFactCollector()
    assert test_instance.name == 'fips'
    assert isinstance(test_instance._fact_ids, set)
    assert len(test_instance._fact_ids) == 0



# Generated at 2022-06-20 19:25:03.018538
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollectorObj = FipsFactCollector()
    fips_facts = FipsFactCollectorObj.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:25:04.560900
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:25:09.115474
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:25:12.673061
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts = collector.collect()
    assert facts['fips'] == False

# Generated at 2022-06-20 19:25:26.308222
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_col = FipsFactCollector()
    assert fips_fact_col.name == "fips"

# Generated at 2022-06-20 19:25:28.714331
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:25:33.942992
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector(None)
    # The name must be Fips
    assert obj.name == 'fips'
    # Fact ids is a empty set
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:25:35.613761
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test = FipsFactCollector()
    result = test.collect()
    assert result['fips'] is False
    assert result is not None

# Generated at 2022-06-20 19:25:38.068953
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x._fact_ids == set()
    assert x.name == 'fips'
    assert x.priority == 6
    assert x.stages == ['early']

# Generated at 2022-06-20 19:25:42.855371
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Verify that the class can be instantiated
    fips_collector_instance = FipsFactCollector()
    assert fips_collector_instance.name == 'fips'

# Generated at 2022-06-20 19:25:45.893196
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:25:51.910239
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Module import
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector

    # Definition of the content of a file
    def get_file_content(file):
        if file == '/proc/sys/crypto/fips_enabled':
            return "1"
        else:
            return None

    # Backup of the original method
    orig_get_file_content = ansible.module_utils.facts.collector.get_file_content

    # Definition of the new method to replace the original one
    ansible.module_utils.facts.collector.get_file_content = get_file_content

    # Creation of a fip fact collector
    fact_collector = collector.get_fact_collector('FipsFactCollector')

    # Invoke of the collection
   

# Generated at 2022-06-20 19:25:55.758549
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:26:01.282801
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect()"""
    FipsFactCollector._check_fips_status_exists = lambda: True
    FipsFactCollector._check_fips_status_file_content = lambda: '1'
    result = FipsFactCollector.collect()
    assert result['fips']
    FipsFactCollector._check_fips_status_file_content = lambda: '0'
    result = FipsFactCollector.collect()
    assert result['fips'] == False

# Generated at 2022-06-20 19:26:27.335377
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert 'fips' in fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:26:36.539901
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""
    fake_module = {
        'ansible_python_interpreter': '/usr/bin/python'
    }
    fact_collector = FipsFactCollector()
    result = fact_collector.collect(module=fake_module)
    assert 'fips' in result.keys()
    # fips is already set to False as default
    assert result['fips'] == False or result['fips'] == True

# Generated at 2022-06-20 19:26:41.055122
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.collect(collected_facts=dict()) == {
        'fips': False
    }

# Generated at 2022-06-20 19:26:42.068882
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert len(FipsFactCollector().collect()) > 0

# Generated at 2022-06-20 19:26:43.879508
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    c = FipsFactCollector()
    data = c.collect()
    assert data is not None
    assert 'fips' in  data
    assert data['fips'] is True


# Generated at 2022-06-20 19:26:45.470242
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:50.161726
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    def get_fips_file(self):
        return '1'

    from ansible.module_utils.facts import utils
    utils.get_file_content = get_fips_file

    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert(result["fips"] == True)

# Generated at 2022-06-20 19:26:51.427007
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:26:55.021545
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None

    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect(module, collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:27:01.552399
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Test the collect method of class FipsFactCollector

# Generated at 2022-06-20 19:28:01.265778
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact = FipsFactCollector()
    assert isinstance(fact.collect(), dict)

# Generated at 2022-06-20 19:28:02.133756
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:28:05.492712
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips = collector.collect()
    assert fips is not None
    print(fips)
    assert fips['fips'] is False

# Generated at 2022-06-20 19:28:07.464741
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc.name == 'fips'
    assert ffc._fact_ids == set()

# Generated at 2022-06-20 19:28:12.137992
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    myFipsFactCollector = FipsFactCollector()
    result = myFipsFactCollector.collect({})

    assert result == {'fips': True}

# Generated at 2022-06-20 19:28:22.025811
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    # mock_get_file_content returns the content of a file in /proc/sys/crypto
    FipsFactCollector.get_file_content = mock_get_file_content

    fips_collector = FipsFactCollector()

    # When calling collect with /proc/sys/crypto/fips_enabled = 1
    facts = fips_collector.collect(collected_facts=None)
    # Then the value of 'fips' should be True
    assert facts['fips'] == True

# Mock of get_file_content method to simulate the file /proc/sys/crypto/fips_enabled
# returns if the system is in fips mode

# Generated at 2022-06-20 19:28:24.596656
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_object = FipsFactCollector()
    if FipsFactCollector_object.collect():
        return True
    else:
        return False

# Generated at 2022-06-20 19:28:26.583127
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    test_obj = FipsFactCollector(None, None)
    assert test_obj.name == 'fips'
    assert not test_obj.collected_facts

# Generated at 2022-06-20 19:28:38.984905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.utils.strfuncs

    # Build test data
    # Build expected result
    # Build complete result
    # Build expected result
    # Build complete result
    # Build expected result
    file_content = ansible.utils.strfuncs.to_bytes('1')
    # Build complete result
    # Build expected result
    result = {'fips': True}
    # Build complete result
    # Build expected result
    # Build complete result

    # Test method collect of class FipsFactCollector
    mock_get_file_content = Mock(return_value=file_content)
    fips_collector = FipsFactCollector()

# Generated at 2022-06-20 19:28:43.172625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Returns fip mode of system """
    fact = FipsFactCollector()
    assert fact.collect() == {'fips': False}, 'False is not returned for default fips mode'

# Generated at 2022-06-20 19:30:59.036516
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Unit test for the method FipsFactCollector.collect.

    Returns:
        True if test succeeds, False otherwise.
    '''

    # create a MockModule object
    class MockModule:
        pass
    mockModule = MockModule()

    # create a MockObject object
    class MockObject:
        pass
    mockObject = MockObject()
    mockObject.path = '/proc/sys/crypto/fips_enabled'
    mockObject.content = '1'

    # get_file_content returns a MockObject object
    with mock.patch.object(FipsFactCollector, 'get_file_content', return_value=mockObject):
        # create a FipsFactCollector object
        fipsFacts = FipsFactCollector()

        # run the method collect

# Generated at 2022-06-20 19:31:06.186543
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()

    # Test if file /proc/sys/crypto/fips_enabled doesn't exist
    collected_facts = fact_collector.collect()
    assert 'fips' in collected_facts
    assert collected_facts['fips'] is False # Test if fips is False

    # Test if file /proc/sys/crypto/fips_enabled exists
    collected_facts = fact_collector.collect()
    assert 'fips' in collected_facts
    assert collected_facts['fips'] is False # Test if fips is False

# Generated at 2022-06-20 19:31:07.632827
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:31:10.027945
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    fips_fact.collect()
    assert fips_fact.name == 'fips'


# Generated at 2022-06-20 19:31:13.266775
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsfact = FipsFactCollector()
    assert fipsfact.name == 'fips'
    assert fipsfact._collect_subset == ('!all', '!min', '!custom')


# Generated at 2022-06-20 19:31:14.765799
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:31:17.701498
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test constructor of FipsFactCollector class"""

    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:31:20.694808
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()

# Generated at 2022-06-20 19:31:25.411576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-20 19:31:33.984305
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.collector.fips import FipsFactCollector

    # Mock the get_file_content method of utils module
    def mock_get_file_content(file_name):
        return to_bytes(to_native(file_name))

    # Mock the Collector class and its methods
    Collector.get_file_content = mock_get_file_content
    Collector.collect_fips_facts = FipsFactCollector(module=None)

    # invoke collect method of class FipsFactCollector
    fips_facts