

# Generated at 2022-06-20 19:22:10.360319
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = None
    ffc = FipsFactCollector()
    assert(ffc.collect(module, collected_facts) == {'fips': False})

# Generated at 2022-06-20 19:22:11.342003
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    pass

# Generated at 2022-06-20 19:22:14.659883
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts


# Generated at 2022-06-20 19:22:20.409424
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    # Create an instance of FipsFactCollector
    fips_collector = FipsFactCollector()

    # Verify the name
    assert fips_collector.name == 'fips'

    # Verify the fact ids
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-20 19:22:24.410307
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected_facts = { "fips": "False" }
    assert collector.collect(collected_facts=collected_facts) == { "fips": "False" }

# Generated at 2022-06-20 19:22:25.274882
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:27.832795
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj1 = FipsFactCollector()
    assert obj1.name == 'fips'
    assert obj1._fact_ids == set()
    assert isinstance(obj1._fact_ids, set)


# Generated at 2022-06-20 19:22:31.656365
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    output = {"fips": False}
    test_output = collector.collect()
    assert test_output == output

# Generated at 2022-06-20 19:22:34.786998
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert 'fips' in x.collect()


# Generated at 2022-06-20 19:22:35.791405
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    return FipsFactCollector(None, {})

# Generated at 2022-06-20 19:22:41.016103
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert not fips_fact_collector._fact_ids

# Generated at 2022-06-20 19:22:45.629799
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    collected_facts = dict()
    fips_facts = fips_fact.collect(collected_facts=collected_facts)
    assert sorted(fips_facts.keys()) == ['fips']

# Generated at 2022-06-20 19:22:48.856544
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact
    assert fact.name == 'fips'
    assert fact._fact_ids == set()

# Generated at 2022-06-20 19:22:54.590517
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()

    assert fc.name == 'fips'
    assert isinstance(fc.collect(), dict)
    assert isinstance(fc._fact_ids, set)
    assert not fc._fact_ids

# Generated at 2022-06-20 19:22:57.623852
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-20 19:23:00.529895
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:23:02.353067
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:23:05.557884
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:23:08.612179
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    module = None
    collector = FipsFactCollector()
    expected_result = {'fips': False}

    # Act
    result = collector.collect(module)

    # Assert
    assert result == expected_result

# Generated at 2022-06-20 19:23:14.829570
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # arrange
    test_obj = FipsFactCollector()
    test_obj.get_file_content = get_file_content
    # act
    fips_facts = test_obj.collect()
    # assert
    assert fips_facts == {'fips': False}

# Generated at 2022-06-20 19:23:19.118341
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts


# Generated at 2022-06-20 19:23:22.626407
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'


# Generated at 2022-06-20 19:23:25.761430
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-20 19:23:31.615964
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector('FipsFactCollector', None, None, None)
    collected_facts = {'fips': True}
    result = collector.collect(None, collected_facts)
    assert (result == {'fips': True})

# Generated at 2022-06-20 19:23:36.388528
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # create an instance of the FipsFactCollector class
    fips_fc = FipsFactCollector()

    # FipsFactCollector.collect() should return a dictionary
    assert isinstance(fips_fc.collect(), dict)

# Generated at 2022-06-20 19:23:38.393004
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:23:43.924690
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    collected_facts = {}
    collected_facts = fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts == {u'fips': False}


# Generated at 2022-06-20 19:23:48.653913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    assert isinstance(fipsFactCollector, FipsFactCollector)
    facts_result = fipsFactCollector.collect()
    assert facts_result == {'fips': False}

# Generated at 2022-06-20 19:23:52.341394
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set(['fips'])

# Generated at 2022-06-20 19:23:53.726541
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:23:57.752565
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect()['fips'] == False

# Generated at 2022-06-20 19:23:59.919629
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  fips_fact_collector = FipsFactCollector()
  assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-20 19:24:12.669381
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockDataCollector(collector.BaseFactCollector):
        name = 'mock'
        _fact_ids = set()

        # Override this method for testing
        def collect(self, module=None, collected_facts=None):
            return {'mock': 'data'}

    # Adding mock data collector to collectors list
    BaseFactCollector._fact_collectors.append(MockDataCollector())

    module = basic.AnsibleModule(argument_spec=dict())
    ignore_list = FipsFactCollector.get_ignore_list(collected_facts=dict())

# Generated at 2022-06-20 19:24:16.180513
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''Unit test for method collect of class FipsFactCollector'''
    collector = FipsFactCollector()
    output = collector.collect()
    assert isinstance(output['ansible_fips'], bool)

# Generated at 2022-06-20 19:24:17.461684
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    print('Test FipsFactCollector constructor')
    facts_collector = FipsFactCollector()
    assert facts_collector.name == 'fips'
    assert facts_collector._fact_ids == set()

# Unit test collect method of class FipsFactCollector

# Generated at 2022-06-20 19:24:20.189168
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:26.044589
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts,\
        "FipsFactCollector.collect returned unexpected facts: %s" % fips_facts

# Generated at 2022-06-20 19:24:32.067945
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Module input parameters
    collected_facts = dict()

    # Expected output
    expected_fips_facts = {
        'fips': False
    }

    # Initialize test object
    fips_fact_collector = FipsFactCollector()

    # Test method collect
    actual_fips_facts = fips_fact_collector.collect(collected_facts=collected_facts)

    # Compare expected ans actual output
    assert expected_fips_facts == actual_fips_facts

# Generated at 2022-06-20 19:24:34.469902
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts = FipsFactCollector()
    assert isinstance(facts, FipsFactCollector)

# Generated at 2022-06-20 19:24:40.667837
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    import mock
    import sys

    def mock_file_content(filename, *args, **kwargs):
        return '1'

    assert sys.modules['ansible.module_utils.facts.utils'].get_file_content == mock_file_content

    # noinspection PyTypeChecker
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:24:49.089817
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"

# Generated at 2022-06-20 19:24:56.683360
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collector = FipsFactCollector(module)

    data = get_file_content('/proc/sys/crypto/fips_enabled')

    if data and data == '1':
        test = True
    else:
        test = False
    result = collector.collect()

    assert result['fips'] is test

# Generated at 2022-06-20 19:25:02.015724
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == "fips"
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:25:11.169888
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test case for method collect of class FipsFactCollector"""
    fips_facts = {}
    fips_facts['fips'] = True
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.get_file_content = MagicMock(return_value = '1')
    assert fips_fact_collector.collect() == fips_facts
    fips_facts['fips'] = False
    fips_fact_collector.get_file_content = MagicMock(return_value = '0')
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-20 19:25:15.574687
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-20 19:25:19.557370
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()

    # An empty dictionary is returned when no file can be found.
    assert fact_collector.collect() == {
        'fips': False
    }


# Generated at 2022-06-20 19:25:22.988558
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class MockModule(object):
        pass

    obj = FipsFactCollector()
    assert obj.collect(collected_facts=None, module=MockModule())

# Generated at 2022-06-20 19:25:29.839657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import inspect

    args = (module, collected_facts)
    def mock_return(module, collected_facts):
        return {}
    mock_ansible_module = MockAnsibleModule()
    fact_collector_return_value = {}
    fact_collector_return_value['fips'] = True
    with patch.object(inspect, 'getargspec', side_effect=mock_getargspec):
        with patch.object(FipsFactCollector, 'collect', side_effect=mock_return):
            with patch.object(FipsFactCollector, '_get_platform_facts', return_value=fact_collector_return_value):
                fips_fact_collector = FipsFactCollector()

# Generated at 2022-06-20 19:25:40.969210
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock get_file_content to return '1' when '/proc/sys/crypto/fips_enabled' is requested
    import ansible.module_utils.facts.collectors.fips
    ansible.module_utils.facts.collectors.fips.get_file_content = lambda path: '1' if path == '/proc/sys/crypto/fips_enabled' else False

    result = FipsFactCollector.collect()
    assert result['fips'] == True

    # Mock get_file_content to return '0' when '/proc/sys/crypto/fips_enabled' is requested
    ansible.module_utils.facts.collectors.fips

# Generated at 2022-06-20 19:25:50.679013
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        elif path == '/proc/sys/crypto/fips_enabled_1':
            return '1'
        elif path == '/proc/sys/crypto/fips_enabled_0':
            return '0'
        else:
            return None
    module = None
    collected_facts = None
    fips_obj = FipsFactCollector()
    fips_obj.get_file_content = get_file_content
    fips_facts = fips_obj.collect(module, collected_facts)
    assert fips_facts['fips'] == True


# Generated at 2022-06-20 19:26:03.772259
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:26:04.662281
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:16.836233
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect"""
    import os
    import shutil
    import tempfile
    import mock
    import pytest
    import ansible.module_utils.facts.utils as utils
    with tempfile.TemporaryDirectory(prefix='ansible_test_tmp') as tmp_dir:
        mock_collected_facts = {}
        test_facts = {'fips': False}
        non_fips_file_path = os.path.join(tmp_dir, 'fips_test_file')
        with open(non_fips_file_path, 'w') as fp:
            fp.write('0')
        with mock.patch('ansible.module_utils.facts.collector.Collector', spec_set=True) as mock_collector:
            fips_collector = F

# Generated at 2022-06-20 19:26:18.555585
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'


# Generated at 2022-06-20 19:26:20.228719
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:26:21.560486
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips



# Generated at 2022-06-20 19:26:28.128509
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test FipsFactCollector collect
    """
    mock_module = Mock(params={})
    mock_FipsFactCollector = FipsFactCollector(mock_module)
    mock_FipsFactCollector.get_file_content = Mock()
    mock_FipsFactCollector.get_file_content.return_value = '1'
    res = mock_FipsFactCollector.collect()
    assert res['fips'] == True

# Generated at 2022-06-20 19:26:31.856454
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()

# Generated at 2022-06-20 19:26:33.538658
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()

    assert collected_facts['fips']

# Generated at 2022-06-20 19:26:34.913298
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:27:05.912988
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert 'fips' in x.collect()
    assert x._fact_ids == set(['fips'])

# Generated at 2022-06-20 19:27:09.762194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:27:11.836030
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert hasattr(obj, 'collect')

# Generated at 2022-06-20 19:27:15.442072
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-20 19:27:17.736317
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:27:20.116398
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:27:24.804667
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        fips_facts = {}
        fips_facts['fips'] = False
        data = get_file_content('/proc/sys/crypto/fips_enabled')
        if data and data == '1':
            fips_facts['fips'] = True
        assert fips_facts == FipsFactCollector.collect()
    except:
        raise AssertionError("Unit test for method  collect of class FipsFactCollector failed")

# Generated at 2022-06-20 19:27:27.238613
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'


# Generated at 2022-06-20 19:27:30.717682
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fsec = FipsFactCollector()
    fact = fsec.collect()
    assert fact['fips'] == True

# Generated at 2022-06-20 19:27:37.677858
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    
    # Test case 1 - on system with FIPS disabled
    open("/proc/sys/crypto/fips_enabled",'w').write("0")
    # TODO: add assert
    fips_fc.collect()
    
    # Test case 2 - on system with FIPS enabled
    open("/proc/sys/crypto/fips_enabled",'w').write("1")
    # TODO: add assert
    fips_fc.collect()

# Generated at 2022-06-20 19:28:37.104213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from . import MockModule, MockFile

    fips_module = MockModule(MockFile('/proc/sys/crypto/fips_enabled', '1'))

    fips_facts = FipsFactCollector().collect(fips_module)

    assert fips_facts['fips'] is True

# Generated at 2022-06-20 19:28:47.365281
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import callback_facts
    fips_fact = FipsFactCollector()
    fips_fact._module = Collector()
    fips_fact._module.callback_facts = callback_facts
    fips_fact._module.collector_facts[fips_fact.name] = {}
    fips_fact.collect()
    assert fips_fact._module.collector_facts[fips_fact.name]['fips'] == False

# Generated at 2022-06-20 19:28:51.831455
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()
    

# Generated at 2022-06-20 19:28:53.775629
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector is not None

# Generated at 2022-06-20 19:28:59.091236
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Prepare test data
    data = "1"
    # Run test
    fips_facts = FipsFactCollector()
    fips_facts.get_file_content = lambda x: data
    result_fips_facts = fips_facts.collect()
    # Verify results
    expected_fips_facts = {'fips': True}
    assert result_fips_facts == expected_fips_facts

# Generated at 2022-06-20 19:29:01.798444
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-20 19:29:06.960282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    module = None
    fips_facts = fc.collect(module)
    assert 'fips' in fips_facts, "FipsFactCollector_collect method returned unexpected results"

# Generated at 2022-06-20 19:29:12.550263
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert hasattr(FipsFactCollector, 'name')
    assert hasattr(FipsFactCollector, '_fact_ids')
    fips_obj = FipsFactCollector(module=None, collected_facts=None)
    assert hasattr(fips_obj, 'collect')

# Generated at 2022-06-20 19:29:17.455390
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()

# Generated at 2022-06-20 19:29:18.719225
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:31:32.250389
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fip = FipsFactCollector()
    assert fip

# Generated at 2022-06-20 19:31:34.139468
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:31:37.352022
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert "fips" == fips_fact_collector.name
    assert get_file_content('/proc/sys/crypto/fips_enabled') == "1"

# Generated at 2022-06-20 19:31:42.948843
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    ansible_name = 'fips'
    ansible_fact_id = {'fips'}

    obj = FipsFactCollector()

    assert obj.name == ansible_name
    assert obj._fact_ids == ansible_fact_id

# Generated at 2022-06-20 19:31:45.600474
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    obj.os = 'Linux'
    result = obj.collect()
    assert result == {'fips': False}

# Generated at 2022-06-20 19:31:46.555721
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:31:49.123750
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact1 = FipsFactCollector()
    assert fact1.name == 'fips'
    assert fact1._fact_ids == set()


# Generated at 2022-06-20 19:31:50.150999
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# Generated at 2022-06-20 19:31:53.654446
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Check if method collect works properly.
    It returns a dictionnary.
    """
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect(collected_facts=None)
    assert isinstance(facts, dict)
    assert 'fips' in facts

# Generated at 2022-06-20 19:31:56.603599
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set(['fips'])
