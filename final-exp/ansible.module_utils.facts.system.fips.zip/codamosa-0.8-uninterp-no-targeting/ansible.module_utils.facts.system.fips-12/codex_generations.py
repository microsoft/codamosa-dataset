

# Generated at 2022-06-20 19:22:09.035275
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_obj = FipsFactCollector()
    assert my_obj.name == 'fips'
    assert my_obj._fact_ids == set()


# Generated at 2022-06-20 19:22:12.634579
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    result = fact_collector.collect()
    assert result['fips'] is not None

# Generated at 2022-06-20 19:22:14.624557
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:18.026427
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    ret = fact_collector.collect()
    print(ret)



# Generated at 2022-06-20 19:22:23.053740
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector is not None
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-20 19:22:24.203014
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-20 19:22:32.361705
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write('1')
    my_obj = FipsFactCollector()
    try:
        assert my_obj
        fact_data = my_obj.collect()
        assert fact_data['fips']
    finally:
        with open('/proc/sys/crypto/fips_enabled', 'w'):
            pass

# Generated at 2022-06-20 19:22:35.045151
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids is None


# Generated at 2022-06-20 19:22:36.026724
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:37.898269
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'


# Generated at 2022-06-20 19:22:40.834265
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:22:48.634327
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    print('Unit test for constructor of class FipsFactCollector')
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect is not None
    assert callable(FipsFactCollector.collect)
    print('The constructor of class FipsFactCollector passed the unit tests.\n')


# Generated at 2022-06-20 19:22:54.065321
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    import pytest
    fips_collector = FipsFactCollector()
    assert type(fips_collector) == FipsFactCollector
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()

# Unit tests for functions of class FipsFactCollector

# Generated at 2022-06-20 19:22:55.542741
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector().collect() == {'fips': False}

# Generated at 2022-06-20 19:22:59.649949
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = type('module', (object,), {})
    mock_module.params = {}
    FipsFactCollector.collect(mock_module)

# Generated at 2022-06-20 19:23:01.958145
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert 'fips' == ffc.name

# Generated at 2022-06-20 19:23:04.830828
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    assert FipsFactCollector.collect() == {'fips': False}


# Generated at 2022-06-20 19:23:08.570134
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test FipsFactCollector.collect()
    """

    mock_module = object()
    mock_collected_facts = object()

    ffc = FipsFactCollector()
    ffc.collect(mock_module, mock_collected_facts)

# Generated at 2022-06-20 19:23:11.104502
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:23:14.680453
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect()
    assert facts['fips'] in [True, False]
    assert len(facts.keys()) == 1


# Generated at 2022-06-20 19:23:20.031158
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids is not None


# Generated at 2022-06-20 19:23:26.713504
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set up module parameters passed into the module
    params = {}

    # Set up module return values
    expected = {
        'fips': True
    }

    # Set up a FipsFactCollector instance
    ffc = FipsFactCollector(params, None)

    # This is the actual call to be tested
    result = ffc.collect()

    assert result == expected

# Generated at 2022-06-20 19:23:38.773606
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import tempfile
    from mock import patch

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock a tempfile to simulate /proc/sys/crypto/fips_enabled
    file_fd, file_path = tempfile.mkstemp()
    with open(file_path, 'w') as file:
        file.write('1')

    with patch.object(BaseFactCollector, 'collect', return_value=dict()):
        collector = FipsFactCollector()
        facts_collected = collector.collect()
        assert facts_collected == {'fips': True}

    os.close(file_fd)
    os.remove(file_path)

# Generated at 2022-06-20 19:23:48.982631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os

    def mock_method_get_file_content(param1):
        return '1'

    class MockModule:
        pass

    if not os.path.exists('/proc/sys/crypto/fips_enabled'):
        os.mknod('/proc/sys/crypto/fips_enabled')

    fc = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    assert fc.collect(MockModule, fips_facts) == fips_facts

# Generated at 2022-06-20 19:23:53.478637
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:23:58.374090
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts.options is None
    assert fips_facts._fact_ids == set()

# Unit test to check the data returned by FipsFactCollector class

# Generated at 2022-06-20 19:24:01.488305
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:24:06.206169
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = FipsFactCollector().collect()
    assert isinstance(collected_facts, dict)
    assert 'fips' in collected_facts
    assert isinstance(collected_facts['fips'], bool)

# Generated at 2022-06-20 19:24:10.742863
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False
    assert fips_facts['_fips'] == 'str'

# Generated at 2022-06-20 19:24:15.513472
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {'ansible_fips': False}
    fips_facts = FipsFactCollector().collect(collected_facts=collected_facts)
    assert fips_facts == {'ansible_fips': False}

# Generated at 2022-06-20 19:24:27.036774
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fixture = FipsFactCollector()
    assert fixture
    assert fixture.name == 'fips'
    assert 'fips' in fixture._fact_ids
    assert fixture.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:29.267887
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert fips_facts._fact_ids == set()



# Generated at 2022-06-20 19:24:32.989252
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()

# Generated at 2022-06-20 19:24:39.590875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module = None
    fips_fact_collector._collector_name = None
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-20 19:24:42.540677
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    constructor_argument_count = FipsFactCollector.__init__.__code__.co_argcount
    assert(constructor_argument_count == 3)

# Generated at 2022-06-20 19:24:43.545131
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'

# Generated at 2022-06-20 19:24:48.610844
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    from ansible.module_utils.facts.collector import FactCollector
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert len(fips_facts._fact_ids) == 0
    assert isinstance(fips_facts, FactCollector)

# Generated at 2022-06-20 19:24:54.549676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_module = FipsFactCollector()
    # set fips_enabled to 1
    fips_module.collect()
    facts = {'fips': True}
    assert (facts == fips_module.collect())

# Generated at 2022-06-20 19:25:01.856106
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    with patch("ansible.module_utils.facts.utils.get_file_content") as mock_get_file_content:
        mock_get_file_content.return_value = "0"
        fips_facts = fips_fact_collector.collect()
        assert fips_facts is not None
        assert fips_facts['fips'] is False
        mock_get_file_content.return_value = "1"
        fips_facts = fips_fact_collector.collect()
        assert fips_facts is not None
        assert fips_facts['fips'] is True

# Generated at 2022-06-20 19:25:03.300565
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:25:28.179499
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print("Running test_FipsFactCollector_collect")
    class FakeModule():
        pass
    class FakeCollector():
        name = 'fips'
    class MockGetFileContent():
        def __init__(self, fips):
            self.fips = fips
        def __call__(self, filename):
            return self.fips
    fips_enabled = str(1)
    mock_get_file_content = MockGetFileContent(fips_enabled)
    fake_module = FakeModule()
    fake_collector = FakeCollector()
    fips_collector = FipsFactCollector()
    fips_collector._get_file_content = mock_get_file_content
    collected_facts1 = fips_collector.collect(fake_module, fake_collector)
    assert collected

# Generated at 2022-06-20 19:25:32.290479
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_test = FipsFactCollector()
    assert fips_test.name == 'fips'



# Generated at 2022-06-20 19:25:35.376284
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == "fips"
    assert obj._fact_ids == set()



# Generated at 2022-06-20 19:25:37.849883
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'

# Generated at 2022-06-20 19:25:47.949231
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content(path, default=None):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return default

    setattr(FipsFactCollector, '_collect_platform_facts', lambda x: {})

    fact_collector = FipsFactCollector()
    fact_collector._get_file_content = get_file_content
    facts = fact_collector.collect()

    assert 'fips' in facts
    assert facts['fips'] is True

# Generated at 2022-06-20 19:25:53.148395
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fc = FipsFactCollector()
    fips_fc._module = {}
    fips_fc._collected_facts = {}
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-20 19:25:57.987966
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Unit test for FipsFactCollector with data
    fips_data = '1'
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write(fips_data)

    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips': True}

    # Unit test for FipsFactCollector without data
    fips_data = ''
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write(fips_data)

    fips_fc = FipsFactCollector()
    assert fips_fc.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:02.354833
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # create class object
    collector = FipsFactCollector()

    # check instance of class
    assert isinstance(collector, FipsFactCollector)


# Generated at 2022-06-20 19:26:09.126967
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test if fips is not set, then set fips_facts['fips'] to false
    fips_module = FipsFactCollector()
    assert fips_module.collect() == {'fips': False}

    # Test if fips is set, then set fips_facts['fips'] to true
    fips_module = FipsFactCollector()
    assert fips_module.collect(get_file_content=lambda x: '1') == {'fips': True}

# Generated at 2022-06-20 19:26:12.698356
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()


# Generated at 2022-06-20 19:26:40.990734
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-20 19:26:44.916097
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    F = FipsFactCollector()
    ret = F.collect()
    assert ret.get('fips') is None or type(ret.get('fips')) is bool

# Generated at 2022-06-20 19:26:55.343785
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method FipsFactCollector.collect
    """
    import io
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import utils
    from ansible.module_utils._text import to_bytes

    # Mock class FipsFactCollector
    class FipsFactCollectorMock(BaseFactCollector):
        name = 'fips'
        _fact_ids = set()
        def collect(self, module=None, collected_facts=None):
            FipsFactCollectorMock.result = super(FipsFactCollectorMock, self).collect(module=module, collected_facts=collected_facts)
            return FipsFactCollectorMock.result

    # Mock function get_file_content

# Generated at 2022-06-20 19:26:58.674303
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == 'fips'
    assert FipsFactCollector()._fact_ids == set()

# Generated at 2022-06-20 19:27:04.347880
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert set(fips_facts.keys()).issubset(['fips'])
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-20 19:27:06.474949
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:27:12.712854
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    file_data = {'/proc/sys/crypto/fips_enabled': ['1']}
    collector = FipsFactCollector(file_data)
    facts = collector.collect()
    assert facts['fips'] == True


# Generated at 2022-06-20 19:27:16.277947
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test 1:
    f = FipsFactCollector()
    assert f is not None
    assert f.name == 'fips'
    assert len(f._fact_ids) == 0


# Generated at 2022-06-20 19:27:21.654862
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_const = FipsFactCollector()

    assert fips_const.name == 'fips'
    assert fips_const._fact_ids == set()
    assert fips_const.files == []

# Generated at 2022-06-20 19:27:26.862441
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_collector = FipsFactCollector()
    test_collector._module = object()
    assert test_collector._module is not None
    assert test_collector.collect()['fips'] is False
    assert test_collector.collect()['fips'] is False

# Generated at 2022-06-20 19:28:34.070763
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = {"name": "fips"}
    fact_collector = FipsFactCollector(module)
    facts = {'module_setup': True}
    assert fact_collector.collect(module=module, collected_facts=facts) == {'fips': False}

# Generated at 2022-06-20 19:28:39.177733
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()

    # object is of type FipsFactCollector
    assert isinstance(fips_collector, FipsFactCollector)
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


if __name__ == '__main__':
    # Unit test for constructors of class FipsFactCollector
    test_FipsFactCollector()

# Generated at 2022-06-20 19:28:40.949081
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:28:50.315301
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import sys
    import os
    import tempfile

    module = mock.MagicMock()
    collected_facts = dict()
    f = tempfile.NamedTemporaryFile()


# Generated at 2022-06-20 19:28:54.739080
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert not fips_facts._fact_ids
    assert callable(fips_facts.collect)

# Generated at 2022-06-20 19:28:56.964493
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, FipsFactCollector)

# Generated at 2022-06-20 19:29:09.403604
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    class TestModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    class TestFacts:
        pass

    fc = FipsFactCollector()

    # Case #1: The file /proc/sys/crypto/fips_enabled does not exist
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        t = fc.collect(TestModule(path=f.name))
        assert t == {'fips': False}

    # Case #2: The file /proc/sys/crypto/fips_enabled exists and contains '1'
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write('1')

# Generated at 2022-06-20 19:29:17.445966
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert 'fips' in fips_obj._fact_ids
    assert 'fips' in fips_obj.fetch_all()
    assert isinstance(fips_obj.fetch_all(), dict)


# Generated at 2022-06-20 19:29:28.600178
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    m = FipsFactCollector()
    assert issubclass(m.__class__, BaseFactCollector)
    assert m.name == 'fips'
    assert m._fact_ids == set()
    # calling collect method with no arguments should raise exception
    with pytest.raises(TypeError):
        m.collect()
    # calling collect method with module and collected_facts as arguments
    # should return fips facts
    assert m.collect(collected_facts={}) == {
        'fips': False
    }

# Generated at 2022-06-20 19:29:30.932974
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test the constructor
    collector = FipsFactCollector()
    assert collector is not None