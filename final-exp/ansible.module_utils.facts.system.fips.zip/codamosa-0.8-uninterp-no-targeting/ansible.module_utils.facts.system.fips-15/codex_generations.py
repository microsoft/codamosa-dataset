

# Generated at 2022-06-20 19:22:13.135620
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    assert FipsFactCollector.collect()['fips'] == False
    # Note: Keys may be added to the fact, but no keys are ever removed
    assert len(FipsFactCollector.collect().keys()) >=1

# Generated at 2022-06-20 19:22:15.099819
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts.name == 'fips'
    assert 'fips' in fips_facts._fact_ids

# Generated at 2022-06-20 19:22:21.467904
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts_dict = fips_fact_collector.collect()
    assert 'fips' in facts_dict, 'fips key absent in facts dict returned'
    assert facts_dict['fips'] is False, 'fips value should be False'

# Generated at 2022-06-20 19:22:25.998772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_object = FipsFactCollector()

    # Returns False if FIPS is not enabled
    assert FipsFactCollector_object.collect()['fips'] == False
    # Returns True if FIPS mode is enabled
    assert FipsFactCollector_object.collect()['fips'] == True

# Generated at 2022-06-20 19:22:26.957552
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:22:28.849527
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:33.597928
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:22:42.366082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector.
    """
    fips_collector = FipsFactCollector({})
    collected_facts = {'fips': False, 'other_fact': 'other_value'}
    expected = {'fips': True}
    collection_results = fips_collector.collect(collected_facts=collected_facts)
    assert collection_results == expected

# Generated at 2022-06-20 19:22:47.986068
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Ensures that FipsFactCollector is a subclass of BaseFactCollector
    assert issubclass(FipsFactCollector, BaseFactCollector)
    # Ensures that FipsFactCollector is instance of BaseFactCollector
    assert isinstance(FipsFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:22:52.856613
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert isinstance(fips_facts, FipsFactCollector)
    assert fips_facts.name == 'fips'
    assert len(fips_facts._fact_ids) > 0



# Generated at 2022-06-20 19:22:55.424983
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:22:57.481316
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ffc = FipsFactCollector()
    assert ffc is not None

# Generated at 2022-06-20 19:23:03.495789
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    fips_fact_collector = FipsFactCollector(module=module, collected_facts=collected_facts)
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:23:09.087931
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids.clear()
    fips_facts = FipsFactCollector.collect()
    assert 'fips' in fips_facts
    if fips_facts['fips'] == 1:
        assert fips_facts['fips'] == False
    else:
        assert fips_facts['fips'] == True

# Generated at 2022-06-20 19:23:13.199045
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == "fips"
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:23:15.186292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    test_data = {}
    assert FipsFactCollector.collect(test_data) == {}

# Generated at 2022-06-20 19:23:18.471753
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().collect() is not None, \
           "FipsFactCollector can not collect any facts"

# Generated at 2022-06-20 19:23:20.034374
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:23:24.726295
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()
    assert len(obj.collect()) == 1

# Generated at 2022-06-20 19:23:27.404197
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:23:35.996299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create instance of FipsFactCollector
    fipsfactcollector_obj = FipsFactCollector({}, [], [u"default"], [])
    # check method collect of class FipsFactCollector
    fipsfactcollector_obj.collect({}, {})


# Generated at 2022-06-20 19:23:44.399327
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def fail_json(self, **kwargs):
            return {'failed': True}

    mockModule = MockModule()
    fipsFactCollector = FipsFactCollector()
    fipsFactCollector.collect(mockModule)

# Generated at 2022-06-20 19:23:48.819722
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-20 19:24:00.176698
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    import unittest
    from nose.plugins.skip import SkipTest

    class TestFipsFactCollector(unittest.TestCase):
        def setUp(self):
            self.a = FipsFactCollector()

        def test_name(self):
            self.assertEqual(self.a.name, 'fips')

        def test_get_facts(self):
            try:
                content = get_file_content('/proc/sys/crypto/fips_enabled')
            except:
                raise SkipTest
            fips_facts = self.a.collect()
            self.assertTrue('fips' in fips_facts)
            self.assertTrue(fips_facts['fips'] == True or fips_facts['fips'] == False)

    return unittest.TestLoader().loadTestsFrom

# Generated at 2022-06-20 19:24:01.577996
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert not FipsFactCollector._fact_ids

# Generated at 2022-06-20 19:24:05.752439
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    data = fips_fact_collector.collect()
    assert data == {'fips': False}

# Generated at 2022-06-20 19:24:07.167353
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:24:13.032611
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import ansible.module_utils.facts.default_collectors
    from ansible.module_utils.facts.collector import Collectors
    import ansible.module_utils.facts.utils
    facts = ansible.module_utils.facts.collector.get_all_facts(Collectors,
                                                               supported_os='any')
    for fact in facts['fips']:
        if fact == 'fips':
            assert facts['fips'][fact] == True

# Generated at 2022-06-20 19:24:15.445626
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector=FipsFactCollector()
    assert fips_fact_collector


# Generated at 2022-06-20 19:24:16.614618
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:24:29.755445
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_file_content = '1'
    obj = FipsFactCollector()
    obj.module = ''
    obj.collect()
    obj.get_file_content = lambda x: fips_file_content
    result = obj.collect()
    assert result['fips'] == True
    fips_file_content = '0'
    result = obj.collect()
    assert result['fips'] == False

# Generated at 2022-06-20 19:24:34.402659
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect(None, None) == {
        "fips": False
    }

# Generated at 2022-06-20 19:24:36.864631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    facts = fips.collect()
    assert facts['fips'] == False

# Generated at 2022-06-20 19:24:39.237723
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'

# Generated at 2022-06-20 19:24:39.975821
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:24:45.704093
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector(['fips'])
    assert obj.name == 'fips'
    assert obj._fact_ids == set(['fips'])
    assert obj.collector == 'FipsFactCollector'
    assert obj.get_fact_ids() == set(['fips'])

# Generated at 2022-06-20 19:24:48.295115
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    obj.collect()

# Generated at 2022-06-20 19:24:50.950623
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert obj.name == 'fips'

# Generated at 2022-06-20 19:24:55.971522
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect()
    assert 'fips' in result
    assert isinstance(result['fips'], bool)

# Generated at 2022-06-20 19:24:58.594879
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {
        'fips': False
    }
    assert FipsFactCollector.collect() == fips_facts


# Generated at 2022-06-20 19:25:12.395841
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:25:15.724041
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector().name == "fips"
    assert FipsFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:25:17.713309
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fip = FipsFactCollector()
    assert fip is not None

# Generated at 2022-06-20 19:25:21.929528
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:25:24.699263
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    collected = collector.collect()
    fips_facts = collected['fips']
    assert isinstance(fips_facts, bool)

# Generated at 2022-06-20 19:25:28.152898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    content = b'1'
    fips_facts = {}
    fips_facts['fips'] = True
    mock_obj = get_file_content
    mock_obj.return_value = content
    fips = FipsFactCollector()
    assert fips.collect() == fips_facts

# Generated at 2022-06-20 19:25:28.951144
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True is True

# Generated at 2022-06-20 19:25:33.110384
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    facts_dict = collector.collect()
    assert 'fips' in facts_dict


# Generated at 2022-06-20 19:25:38.159447
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create FipsFactCollector object
    fips_fact_collector_ins = FipsFactCollector()
    test_fips_facts = fips_fact_collector_ins.collect()
    assert type(test_fips_facts) is dict
    assert 'fips' in test_fips_facts

# Generated at 2022-06-20 19:25:43.543338
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    # Test the class name
    assert fips.name == 'fips'
    # Test the fact ids
    assert 'fips' in fips._fact_ids

# Generated at 2022-06-20 19:26:11.500516
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    _FipsFactCollector = FipsFactCollector()
    assert _FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:26:21.159439
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Create class instance
    c = FipsFactCollector()

    # Create dictionary with mocks
    collected_facts = {}

    # execute method collect
    data = c.collect(collected_facts=collected_facts)

    # check if fips is False
    assert data['fips'] == False

    # assign file content mock to file /proc/sys/crypto/fips_enabled
    get_file_content.cache_data = {'fips_enabled': '1'}

    # execute method collect
    data = c.collect(collected_facts=collected_facts)

    # check if fips is True (see mock above)
    assert data['fips'] == True


# Generated at 2022-06-20 19:26:28.366274
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    mock_data = b'\x00'
    assert FipsFactCollector.collect(None, None, mock_data) == fips_facts
    fips_facts['fips'] = True
    mock_data = b'\x01'
    assert FipsFactCollector.collect(None, None, mock_data) == fips_facts
    mock_data = True
    assert FipsFactCollector.collect(None, None, mock_data) == fips_facts

# Generated at 2022-06-20 19:26:32.073484
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()

    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:26:33.507463
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:36.466699
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert len(f._fact_ids) == 0


# Generated at 2022-06-20 19:26:41.540810
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_facts = fips_collector.collect()
    assert fips_facts['fips'] == False or fips_facts['fips'] == True



# Generated at 2022-06-20 19:26:42.911323
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:26:47.303261
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    fips_facts = ffc.collect()
    assert 'fips' in fips_facts
    assert fips_facts['fips'] in [True, False]

# Generated at 2022-06-20 19:26:56.683571
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # When the file /proc/sys/crypto/fips_enabled does not exist, the value 'fips' is False
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

    # When the file /proc/sys/crypto/fips_enabled exists and the value is 0, the value 'fips' is False
    fips_file_content = '0\n'
    with mock.patch.object(fips_fact_collector, 'get_file_content', side_effect=[fips_file_content]):
        fips_facts = fips_fact_collector.collect()
        assert fips_facts['fips'] == False

    # When the file /proc/sys/

# Generated at 2022-06-20 19:28:02.058935
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()

# Generated at 2022-06-20 19:28:02.833231
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:28:04.155278
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:28:08.463083
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f is not None
    assert f.fips == False
    assert f.name == 'fips'
    assert f._fact_ids == set()
    assert len(f.collect()) == 1
    assert f.collect().get('fips') == False
    assert len(f.collect(collected_facts=dict())) == 1
    assert f.collect(collected_facts=dict()).get('fips') == False

# Generated at 2022-06-20 19:28:15.670983
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # mock /proc/sys/crypto/fips_enabled content
    mock_content = '1'

    # mock the get_file_content function
    module = 'ansible.module_utils.facts.collectors.fips.get_file_content'
    fips_content = 'ansible.module_utils.facts.collectors.fips.FipsFactCollector.collect'
    with mock.patch(module, side_effect=[mock_content, fips_content, fips_content, fips_content, fips_content]):
        # we expect a dictionary with fips set to True
        assert FipsFactCollector().collect(module=mock.MagicMock()) == {'fips': True}


# Generated at 2022-06-20 19:28:17.537059
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'

# Generated at 2022-06-20 19:28:18.381668
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:28:19.987248
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:28:21.201873
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    result = fips.collect()
    assert result['fips'] == False

# Generated at 2022-06-20 19:28:22.061713
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:30:36.771024
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert fipsFactCollector._fact_ids == set([])

# Generated at 2022-06-20 19:30:37.872939
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Not relevant now, will be relevant after fixing BZ#1469280
    assert True

# Generated at 2022-06-20 19:30:39.946007
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:30:40.990835
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert isinstance(FipsFactCollector(), FipsFactCollector)

# Generated at 2022-06-20 19:30:45.005821
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_obj = FipsFactCollector()
    assert(test_obj.collect()['fips'] == False)
    test_obj._read_content = lambda x: '1'
    assert(test_obj.collect()['fips'] == True)

# Generated at 2022-06-20 19:30:47.606331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = True
    fact_collector = FipsFactCollector()

    collected_facts = fact_collector.collect()

    assert collected_facts == fips_facts

# Generated at 2022-06-20 19:30:50.789807
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector()
    assert collector.name == 'fips'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:30:52.134260
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    assert fips.collect() == {'fips': False}

# Generated at 2022-06-20 19:30:59.139415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    class TestModule():
        pass

    # Create a test module for the test case
    test_module = TestModule()
    setattr(test_module,"params",{})

    # Obtain a FIPS Fact Collector from the platform.
    fips_collector = FipsFactCollector()

    # Test if the collect() return fips = False
    setattr(fips_collector,"_data",'0')
    fips_facts = fips_collector.collect(test_module)
    assert fips_facts['fips'] == False

    # Test if the collect() return fips = True
    setattr(fips_collector,"_data",'1')
    fips_facts = fips_collector.collect(test_module)
    assert fips_facts['fips'] == True


# Generated at 2022-06-20 19:31:08.693315
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('1')
    fips_facts = f.collect()
    assert fips_facts == {'fips': True}
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('0')
    fips_facts = f.collect()
    assert fips_facts == {'fips': False}
    with open('/proc/sys/crypto/fips_enabled', 'w') as fh:
        fh.write('2')
    fips_facts = f.collect()
    assert fips_facts == {'fips': False}