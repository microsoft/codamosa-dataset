

# Generated at 2022-06-20 19:22:05.696050
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module = type("AnsibleModule", (), {"params": {}, "exit_json": lambda **kwargs: None})()
    mock_collected_facts = {}

    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect(mock_module, mock_collected_facts)

    assert result["fips"] == False

# Generated at 2022-06-20 19:22:09.468376
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:22:14.447784
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert isinstance(fips_collector._fact_ids, set)
    assert 'fips' in fips_collector._fact_ids

# Generated at 2022-06-20 19:22:18.389331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    data = {'fips': False}
    assert fips_fact_collector.collect() == data

# Generated at 2022-06-20 19:22:25.821738
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""
    fips_data = "1"
    MOCK_OPEN = mock_open(read_data=fips_data)
    MOCK_MODULE = MagicMock()
    with patch('ansible.module_utils.facts.collector.open', MOCK_OPEN, create=True):
        MOCK_FACT_COLLECTOR = FipsFactCollector(MOCK_MODULE)
        fips_facts = MOCK_FACT_COLLECTOR.collect()
        assert fips_facts['fips'] == True

# Generated at 2022-06-20 19:22:28.980634
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj.collect_fn == 'collect'


# Generated at 2022-06-20 19:22:30.313318
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:22:33.960523
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    facts = fips_facts.collect()
    assert facts == {'fips': False}


# Generated at 2022-06-20 19:22:36.980310
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:22:38.813537
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector()
    assert fips_facts.collect()

# Generated at 2022-06-20 19:22:41.549037
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:22:43.582516
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    collector = FipsFactCollector
    assert collector.name == "fips"
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:22:46.143570
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fake_collector = FipsFactCollector()

    assert fake_collector.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:49.357553
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj=FipsFactCollector()
    module=None
    collected_facts={}
    obj.collect(module=None, collected_facts=None)

# Generated at 2022-06-20 19:22:53.349651
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_content = '1'
    assert(FipsFactCollector.collect() == {'fips': True})


if __name__ == "__main__":
    test_FipsFactCollector_collect()

# Generated at 2022-06-20 19:22:56.103269
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()


# Generated at 2022-06-20 19:23:07.543557
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    collector_fips = FipsFactCollector()
    assert isinstance(collector_fips, BaseFactCollector), "Ansible module FipsFactCollector failed to instantiate"
    assert collector_fips.name == 'fips', "Ansible module FipsFactCollector method collect failed to set attribute name"
    assert collector_fips._fact_ids == set(), "Ansible module FipsFactCollector method collect failed to set attribute _fact_ids"
    collector_fips._fact_ids.add('fips')

# Generated at 2022-06-20 19:23:16.296214
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_module = FipsFactCollector()
    r_fips_facts = fips_module.collect()
    # r_fips_facts is a dict
    assert isinstance(r_fips_facts, dict)
    assert len(r_fips_facts) == 1
    # Check fips key is present
    assert 'fips' in r_fips_facts
    # Check value of the fips key
    assert isinstance(r_fips_facts['fips'], bool)

# Generated at 2022-06-20 19:23:20.964236
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    c = Collector(FipsFactCollector, 'fips')
    data = c.collect()
    assert data.get('fips') is False

# Generated at 2022-06-20 19:23:32.245472
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    export_fips_enabled = True
    open_mock = mock.mock_open(read_data='1')
    # Mock for /proc/sys/crypto/fips_enabled
    with mock.patch('ansible.module_utils.facts.collectors.fips.open', open_mock, create=True):
        FipsFactCollector.collect()
    # Check that if fips_enabled is True, then fips fact collector will collect fips as True
    assert FipsFactCollector.collect()['fips']
    open_mock = mock.mock_open(read_data='0')
    # Mock for /proc/sys/crypto/fips_enabled

# Generated at 2022-06-20 19:23:36.872573
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:23:40.305729
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()
    assert fips_fact.collect() == dict(fips=False)

# Generated at 2022-06-20 19:23:47.355152
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.fact_collector import FACT_COLLECTORS
    from ansible.module_utils.facts.utils import module_shared_memory
    from ansible.module_utils.facts.collector import BaseFactCollector
    assert 'fips' in FACT_COLLECTORS
    fips = FACT_COLLECTORS['fips']
    assert isinstance(fips, BaseFactCollector)
    assert isinstance(fips, FipsFactCollector)
    assert fips.name == 'fips'
    assert fips.priority == 0
    assert fips._fact_ids == set()
    if isinstance(fips, FipsFactCollector):
        fips.collect(module_shared_memory('fips'))


# Generated at 2022-06-20 19:23:49.987759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()
    assert 'fips' not in fips_fact_collector._collected_facts

# Generated at 2022-06-20 19:23:54.947595
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert len(fips_fc._fact_ids) == 1
    assert 'fips' in fips_fc._fact_ids

# Generated at 2022-06-20 19:23:57.135971
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    collected_facts = {}
    fc = FipsFactCollector()
    data = fc.collect(module, collected_facts)
    assert data['fips'] is False


# Generated at 2022-06-20 19:23:59.498296
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  ffpc = FipsFactCollector()
  assert ffpc.name == 'fips'
  assert 'fips' in ffpc.collect()

# Generated at 2022-06-20 19:24:02.825886
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector.collect() == {'fips': False, 'changed': False}

# Generated at 2022-06-20 19:24:05.285082
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:24:09.213191
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert 'fips' in fips_collector._fact_ids

# Generated at 2022-06-20 19:24:17.843937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['ansible_facts']['fips'] == False


# Generated at 2022-06-20 19:24:21.157611
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    fips_test = FipsFactCollector()
    assert fips_test.collect() == {'fips': False}
    fips_test._module = True
    with pytest.raises(RuntimeError) as test_exception:
        fips_test.collect()

# Generated at 2022-06-20 19:24:22.821011
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:24:24.156464
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:24:33.838199
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fake_module = 'ansible'
    fake_fact_list = []
    expected_result = {'fips': False}
    fake_content = '1\n'
    fake_file_path = '/proc/sys/crypto/fips_enabled'
    fake_getfile_result = (None, None, None)
    f = FipsFactCollector()
    mock_get_file_content = get_file_content
    f.get_file_content = lambda x, z=None: fake_getfile_result
    result = f.collect(fake_module, fake_fact_list)
    assert result == expected_result
    mock_get_file_content.assert_called_once_with(fake_file_path)
    fake_getfile_result = (0, fake_content, None)
    expected_

# Generated at 2022-06-20 19:24:37.913091
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')

# Generated at 2022-06-20 19:24:44.517489
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # first create FipsFactCollector instance and test
    # properties of instance
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.priority == -1
    assert fips_fact_collector._fact_ids == set()
    # fips_fact_collector._fact_ids == set()
    # now test method collect of class FipsFactCollector
    # create instance of class FipsFactCollector again
    fips_fact_collector = FipsFactCollector()
    # now create test instance of class BaseFactCollector
    base_fact_collector = BaseFactCollector()
    base_fact_collector.plugin = 'fips'

# Generated at 2022-06-20 19:24:48.683040
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    obj = FipsFactCollector()
    obj.collect()

if __name__ == "main":
    test_FipsFactCollector_collect()

# Generated at 2022-06-20 19:24:54.548805
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect(collected_facts={})
    assert result == {'fips': False }

# Generated at 2022-06-20 19:24:59.265081
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    if not os.path.exists('/proc/sys/crypto'):
        os.makedirs('/proc/sys/crypto')

    with tempfile.NamedTemporaryFile(prefix='ansible_fips', delete=False) as f:
        f.write(to_bytes('1'))
        f.flush()
        f.close()
        os.rename(f.name, '/proc/sys/crypto/fips_enabled')

    c = FipsFactCollector()
    r = c.collect()

    assert r['fips']

# Generated at 2022-06-20 19:25:22.496169
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method "collect" of class FipsFactCollector
    """

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Collectors
    from ansible.module_utils.facts import FactCache

    # Run this fact collection module
    Collectors.add_collector(FipsFactCollector())
    fips_fact_collector = FipsFactCollector()
    collected_facts = FactCache()
    fips_fact_collector.collect(module=None, collected_facts=collected_facts)
    assert(collected_facts.get("fips"))

# Generated at 2022-06-20 19:25:26.417088
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector=FipsFactCollector()
    assert fips_collector is not None
    assert fips_collector.name == "fips"
    assert fips_collector._fact_ids == set()

# Generated at 2022-06-20 19:25:28.797322
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector
    assert fips_fact_collector.name == "fips"


# Generated at 2022-06-20 19:25:37.234729
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    facts_collected = {}
    fips_collector = FipsFactCollector()
    fips_collector.collect(collected_facts=facts_collected)
    assert type(facts_collected) is type({})
    assert len(facts_collected) == 1
    assert 'fips' in facts_collected
    assert type(facts_collected['fips']) is type(False)

# Generated at 2022-06-20 19:25:45.763266
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create an object of FipsFactCollector
    fipsfactcollector_obj = FipsFactCollector()

    # create a mock object of ansible module
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    module_mock = Mock(return_value=data)
    fipsfactcollector_obj.collect(module=module_mock)

# Generated at 2022-06-20 19:25:47.868877
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_obj = FipsFactCollector()
    assert fips_obj.name == 'fips'
    assert len(fips_obj._fact_ids) == 0


# Generated at 2022-06-20 19:25:49.728212
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:25:53.156161
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()
    facts = fact_collector.collect()
    assert 'fips' in facts

# Generated at 2022-06-20 19:25:55.758834
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()

    fips_collector.collect()



# Generated at 2022-06-20 19:25:58.377604
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert(fips_fact_collector.name == 'fips')


# Generated at 2022-06-20 19:26:26.772547
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert not FipsFactCollector().fetch_cacheable_facts()
    assert FipsFactCollector().name == "fips"

# Generated at 2022-06-20 19:26:31.785225
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()

    assert isinstance(fips_fact_collector, FipsFactCollector)
    assert isinstance(fips_fact_collector.collect(), dict)

# Generated at 2022-06-20 19:26:34.435311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    fipsFactCollector.collect()

# Generated at 2022-06-20 19:26:39.050886
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector()
    fips_facts = collector.collect()
    assert fips_facts
    assert 'fips' in fips_facts
    if fips_facts['fips'] is True:
        assert get_file_content('/proc/sys/crypto/fips_enabled') == '1'
    else:
        assert get_file_content('/proc/sys/crypto/fips_enabled') == '0'

# Generated at 2022-06-20 19:26:40.394339
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:26:51.785851
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # We only test for collection behavior by the collector.
    # It is not the role of the fact collector to validate the data.
    # (For that, there are tests for the various utils modules.)
    # It is the role of the fact collector to ensure that the data it
    # fetches is of the proper format and structure, regardless of content.
    # We can then test the utils themselves for correctness.
    # We are just testing that the collector stores the data properly
    # and makes it available to the fact module in an easily accessible
    # way.

    import ansible.module_utils.facts.collector

    facts = ansible.module_utils.facts.collector.collect('fips')
    assert facts['fips'] is False

    from ansible.module_utils.facts.utils import set_module_args
    set_module_args

# Generated at 2022-06-20 19:26:54.944121
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'
    assert fips_collector._fact_ids == set()


# Generated at 2022-06-20 19:27:00.283055
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
  test_obj = FipsFactCollector()
  assert test_obj
  assert test_obj.name == 'fips'
  assert test_obj._fact_ids == set()


# Generated at 2022-06-20 19:27:04.426652
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:27:06.070162
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'

# Generated at 2022-06-20 19:28:14.320222
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert len(FipsFactCollector._fact_ids) == 1
    assert FipsFactCollector._fact_ids == { 'fips' }

# Generated at 2022-06-20 19:28:18.031507
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test without any argument
    fips_fact = FipsFactCollector()
    assert fips_fact.name == 'fips'
    assert fips_fact._fact_ids == set()

# Generated at 2022-06-20 19:28:19.693484
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ffc.collect()

# Generated at 2022-06-20 19:28:21.644552
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    facts = Collector().collect(['fips'])
    assert 'fips' in facts

# Generated at 2022-06-20 19:28:25.655938
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert isinstance(fips_fact_collector._fact_ids, set)
    assert fips_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:28:32.376030
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
        # Instantiate FipsFactCollector
        Fips = FipsFactCollector()
        # Call method collect of FipsFactCollector
        data = Fips.collect()
        # Confirm that the results are of type dict
        assert(type(data) == dict)

# Generated at 2022-06-20 19:28:39.958437
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    def _get_file_content(path, default=None):
        return '1'

    # unit test code
    fips_collected_facts = {}
    fips_facts = {
        'fips': True
    }

    fips_test_obj = FipsFactCollector(None, None)

    # test default collect
    fips_test_obj.get_file_content = _get_file_content
    fips_test_obj.collect()

    fips_collected_facts = fips_test_obj.collect(None, fips_collected_facts)
    assert fips_collected_facts == fips_facts

# Generated at 2022-06-20 19:28:42.519206
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_collector.collect()


# Generated at 2022-06-20 19:28:43.996897
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:28:46.568337
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    assert fips_collector.collect()['fips'] is False

# Generated at 2022-06-20 19:31:13.423673
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    assert(fips_fact_collector.collect()['fips'] is True)

# Generated at 2022-06-20 19:31:16.247331
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_collect = FipsFactCollector.collect
    test_fips_facts = FipsFactCollector_collect()
    assert test_fips_facts['fips'] == False

# Generated at 2022-06-20 19:31:17.581322
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:31:19.505078
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Check that this method doesn't fail if we run it
    """
    FipsFactCollector.collect()

# Generated at 2022-06-20 19:31:23.702628
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_collector = FipsFactCollector()
    assert fips_collector.name == 'fips'


# Generated at 2022-06-20 19:31:25.108552
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:31:29.560742
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    ansible_module = MagicMock()
    ansible_module.params={}
    ffc=FipsFactCollector(ansible_module)
    assert(ffc)
    assert(ffc.name == 'fips')
    assert(ffc._fact_ids == set(['fips']))
    

# Generated at 2022-06-20 19:31:36.385957
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.utils import get_file_content

    modules_mock = ['fips']
    FactManager.add_collection_module('fips', FipsFactCollector)
    fc = get_collector_instance('fips')

    fips_facts = fc.collect()
    assert fips_facts == {'fips': False}

    # mock the data fips_enabled file to have a value of 1

# Generated at 2022-06-20 19:31:37.296666
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsfc = FipsFactCollector()
    fipsfc.collect()

# Generated at 2022-06-20 19:31:44.152514
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips', 'Fips fact should be fips'
    assert isinstance(FipsFactCollector._fact_ids, set), 'FipsFactCollector._fact_ids should be a set'
    assert not FipsFactCollector._fact_ids