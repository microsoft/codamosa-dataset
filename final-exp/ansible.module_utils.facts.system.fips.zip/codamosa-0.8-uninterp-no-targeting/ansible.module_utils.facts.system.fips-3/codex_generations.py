

# Generated at 2022-06-20 19:22:13.416058
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert 'fips' in fips_fc._fact_ids
    assert 'fips_enabled' not in fips_fc._fact_ids


# Generated at 2022-06-20 19:22:15.040768
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj.name == 'fips'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:22:17.881898
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fc = FipsFactCollector()
    assert fc.name == 'fips'


# Generated at 2022-06-20 19:22:25.647222
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    Collector.populate_fact_list(FipsFactCollector, module)
    facts_to_gather = Collector.get_fact_list()
    fact_gather_list = [fact_name for fact_name in facts_to_gather]
    assert 'fips' in fact_gather_list

# Generated at 2022-06-20 19:22:28.780939
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
   fips_fact_collector = FipsFactCollector()
   assert fips_fact_collector.name == 'fips'


# Generated at 2022-06-20 19:22:33.662203
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    from ansible.module_utils.facts.collector import BASE_CACHE
    assert 'fips' not in BASE_CACHE
    objFipsFactCollector = FipsFactCollector()
    assert isinstance(objFipsFactCollector, FipsFactCollector)


# Generated at 2022-06-20 19:22:38.486178
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    a = FipsFactCollector()
    assert a.name == 'fips'
    assert a._fact_ids == set()


# Generated at 2022-06-20 19:22:41.725289
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    obj = FipsFactCollector()
    assert obj
    assert obj.name == 'fips'
    assert obj._fact_ids == set()



# Generated at 2022-06-20 19:22:43.741271
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_ins=FipsFactCollector()
    assert fact_ins.name == 'fips'


# Generated at 2022-06-20 19:22:45.704654
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-20 19:22:53.196905
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == 'fips'
    assert len(fipsFactCollector._fact_ids) == 0


# Generated at 2022-06-20 19:22:55.838415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    res = fips_fact_collector.collect()
    assert res == {}

# Generated at 2022-06-20 19:22:58.763094
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector.collect()

# Generated at 2022-06-20 19:23:01.611314
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    my_obj = FipsFactCollector()
    assert my_obj.collect() == {'fips': False}
#

# Generated at 2022-06-20 19:23:05.234767
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    result = fips_facts_collector.collect()
    assert result['fips'].__class__.__name__ == bool.__name__

# Generated at 2022-06-20 19:23:11.035291
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collector = FipsFactCollector(None, None)
    data = collector.collect()
    assert collector.name == 'fips'
    fips_facts = {}
    fips_facts['fips'] = False
    assert data == fips_facts


# Generated at 2022-06-20 19:23:14.209691
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == "fips"
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:23:15.891076
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == "fips"
    assert fips._fact_ids == set()

# Generated at 2022-06-20 19:23:21.742614
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    """Test FipsFactCollector class."""
    fips_obj = FipsFactCollector('/proc/sys/crypto/fips_enabled')
    assert fips_obj.name == 'fips'
    assert fips_obj._fact_ids == set()



# Generated at 2022-06-20 19:23:28.155874
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = {}
    fips_facts['fips'] = False
    file_content = """1"""

    fips_mock = FipsFactCollector()
    fips_mock.get_file_content = Fakeget_file_content(file_content)
    result_fips_facts = fips_mock.collect()
    assert result_fips_facts == fips_facts


# Generated at 2022-06-20 19:23:40.018182
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_content = """1"""
    non_fips_content = """0"""

    fipscollector = FipsFactCollector()
    assert fipscollector.collect()['fips'] == False

    fipscollector = FipsFactCollector(None, {'fips': {'content': non_fips_content, 'path': '/proc/sys/crypto/fips_enabled'}})
    assert fipscollector.collect()['fips'] == False

    fipscollector = FipsFactCollector(None, {'fips': {'content': fips_content, 'path': '/proc/sys/crypto/fips_enabled'}})
    assert fipscollector.collect()['fips'] == True

# Generated at 2022-06-20 19:23:42.146339
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'

# Generated at 2022-06-20 19:23:53.333093
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import FallbackDict

    MOCK_COLLECTED_FACTS = {'fips': True}

    def mock_get_file_content(path):
        if path == '/proc/sys/crypto/fips_enabled':
            return '1'
        return ''

    collector = FipsFactCollector()

    # with file returning '1'
    collected_facts = FallbackDict(MOCK_COLLECTED_FACTS.copy())
    collector._get_file_content = mock_get_file_content
    result = collector.collect(collected_facts=collected_facts)
    assert result == {'fips': True}

    # with file returning empty string
    collected_facts = FallbackDict(MOCK_COLLECTED_FACTS.copy())


# Generated at 2022-06-20 19:23:57.503465
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x = FipsFactCollector()
    assert x.name == 'fips'
    assert x._fact_ids == set()
    assert x._cache == {'fips': None}

# Generated at 2022-06-20 19:24:02.072199
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fipsFactCollector = FipsFactCollector()
    fipsFactCollector._module = {'run_command': lambda *args, **kwargs: ('', '')}
    assert fipsFactCollector.collect() == {'fips': False}

    fipsFactCollector._module = {'run_command': lambda *args, **kwargs: ('1', '')}
    assert fipsFactCollector.collect() == {'fips': True}

# Generated at 2022-06-20 19:24:07.489692
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts = FipsFactCollector()
    assert fips_facts is not None
    assert fips_facts.name == "fips"
    assert fips_facts._fact_ids == set()


# Generated at 2022-06-20 19:24:11.373245
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector(): 
    fips=FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

if __name__ == '__main__':
    test_FipsFactCollector()

# Generated at 2022-06-20 19:24:12.963711
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:24:16.516573
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fipsFactCollector = FipsFactCollector()
    assert fipsFactCollector.name == "fips"
    assert fipsFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:24:20.557364
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert isinstance(fips_fact_collector._fact_ids, set)
    assert len(fips_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:24:35.477574
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:24:38.369079
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    c = FipsFactCollector()
    assert c.collect() == {'fips': False}

# Generated at 2022-06-20 19:24:40.936270
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    return_content = '1'
    collector = FipsFactCollector()
    collector.get_file_content = lambda x: return_content

    assert collector.collect() == {'fips': True}


# Generated at 2022-06-20 19:24:44.470551
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Unit test to check constructor of class FipsFactCollector
    fips_collector = FipsFactCollector()
    assert fips_collector.name


# Generated at 2022-06-20 19:24:48.294920
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    my_obj = FipsFactCollector()
    assert my_obj.name == 'fips'

# Generated at 2022-06-20 19:24:52.230937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    test_fact = {'fips': False}
    assert fips.collect() == test_fact

# Generated at 2022-06-20 19:24:55.326164
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert len(fips._fact_ids) == 0

# Generated at 2022-06-20 19:24:57.211575
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_facts_collector = FipsFactCollector()
    assert fips_facts_collector.name == 'fips'
    assert fips_facts_collector._fact_ids == set()

# Generated at 2022-06-20 19:25:00.844179
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = FipsFactCollector().collect()
    print(facts)
    assert facts == { 'fips': True }

# Generated at 2022-06-20 19:25:05.276569
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.name == 'fips'
    assert len(fips_fact_collector._fact_ids) == 1
    assert fips_fact_collector._fact_ids.pop() == 'fips'



# Generated at 2022-06-20 19:25:33.739187
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips = FipsFactCollector()
    assert fips.name == 'fips'
    assert fips._fact_ids == set()

# Generated at 2022-06-20 19:25:38.197432
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # FipsFactCollector constructor
    fact_collector = FipsFactCollector()

    # verify that the name and _fact_ids are set correctly
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:25:50.122205
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Example output of /proc/sys/crypto/fips_enabled file
    proc_sys_crypto_fips_enabled = '1'  # for FIPS mode on; 0 for off
    # Expected result
    expected_fips_facts = {'fips': True}

    # Mocking the reading of /proc/sys/crypto/fips_enabled file
    dummy_collected_facts = {}
    dummy_get_file_content = lambda _: proc_sys_crypto_fips_enabled
    monkeypatch_dict = {
        'ansible.module_utils.facts.utils.get_file_content': dummy_get_file_content
    }
    # Include the above into ansible.module_utils.facts.utils
    monkeypatch.setattr(**monkeypatch_dict)

    # Actual result
   

# Generated at 2022-06-20 19:26:01.176707
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Test with file containing fips_enabled: '1'
    class Mock_get_file_content:
        def __init__(self, data):
            self.data = data

        def __call__(self, path):
            return self.data

    m = Mock_get_file_content('1')
    fips_facts = FipsFactCollector()
    fips_facts._module = None
    fips_facts._collect = m
    fips = fips_facts.collect()
    assert fips['fips'] == True

    # Test with file containing fips_enabled: '0'
    m = Mock_get_file_content('0')
    fips_facts = FipsFactCollector()
    fips_facts._module = None
    fips_facts._collect = m
    fips = fips

# Generated at 2022-06-20 19:26:04.895309
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips = FipsFactCollector()
    res = fips.collect(None, None)
    assert 'fips' in res
    assert res['fips'] == False

# Generated at 2022-06-20 19:26:08.193248
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    expected_result = {
        'fips': False
    }

    fips_collector = FipsFactCollector()
    result = fips_collector.collect()

    assert result == expected_result

# Generated at 2022-06-20 19:26:16.633007
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_collector = FipsFactCollector()
    fips_facts = fips_facts_collector.collect()
    assert type(fips_facts) is dict
    assert 'fips' in fips_facts
    assert type(fips_facts['fips']) is bool
    if fips_facts['fips']:
        assert fips_facts['fips'] == True
    else:
        assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:26:17.543519
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()


# Generated at 2022-06-20 19:26:25.672958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #Define unit test class
    class MockFipsFactCollector(FipsFactCollector):
        def __init__(self, module, collected_facts):
            self.paths = {}
            self.paths['/proc/sys/crypto/fips_enabled'] = {'content': '1'}

    #Create instance of MockFipsFactCollector
    mock_instance = MockFipsFactCollector(module=None, collected_facts=None)
    #Call collect
    result = mock_instance.collect()
    #Check
    assert result == {'fips': True}

# Generated at 2022-06-20 19:26:32.145705
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    F = FipsFactCollector()
    # Creating a fixture
    fips_facts = {}
    fips_facts['fips'] = False
    # Running the method collect of class FipsFactCollector
    facts = F.collect()
    assert facts == fips_facts

# Generated at 2022-06-20 19:27:01.415895
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact = FipsFactCollector()
    assert fact.name == 'fips'

# Generated at 2022-06-20 19:27:02.798692
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:27:06.290125
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fact_collector = FipsFactCollector()
    assert fact_collector.name == 'fips'
    assert set(fact_collector._fact_ids) == set(['fips'])

# Generated at 2022-06-20 19:27:08.674315
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:27:13.186748
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Test object creation
    fips_fact_obj = FipsFactCollector()

    assert fips_fact_obj.name == 'fips'
    assert fips_fact_obj._fact_ids == set()

# Generated at 2022-06-20 19:27:15.825194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    #create an instance of  FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    #collect the facts
    fips_facts = fips_fact_collector.collect()
    # The fact fips must be present and its value must be a boolean 
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-20 19:27:18.642330
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    result = fips_collector.collect(collected_facts={})
    assert result['fips'] == False

# Generated at 2022-06-20 19:27:20.458795
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    FipsFactCollector()

# Generated at 2022-06-20 19:27:25.994861
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector._fact_ids = set()
    fipscollector = FipsFactCollector()
    fips_facts = fipscollector.collect(module=None, collected_facts=None)
    assert fips_facts['fips'] == False

# Generated at 2022-06-20 19:27:31.750916
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    def get_file_content_side_effect(path):
        return '1'

    MockModule = type('MockModule', (object, ), {'params': {}})
    MockAnsibleModule = type('MockAnsibleModule', (object, ), {'params': {}})
    FipsFactCollector._module = MockModule
    FipsFactCollector._ansible_module = MockAnsibleModule

    mock_file = type('File', (object,), {'read': get_file_content_side_effect})
    MockOpens = type('MockOpens', (object,), {'open': mock_file})
    FipsFactCollector._tmpdir = ''

    FipsFactCollector._opens = MockOpens
    fips_facts = FipsFactCollector()
    fips_facts.collect

# Generated at 2022-06-20 19:28:03.739774
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert bool(fips_fact_collector.collect())

# Generated at 2022-06-20 19:28:12.873465
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact = FipsFactCollector()

    # If a file_exist is checked and it exists, then return the content of the file
    def mock_get_file_content(file_name):
        if file_name == "/proc/sys/crypto/fips_enabled":
            return "1"
        return None
    get_file_content.side_effect = mock_get_file_content

    result = fips_fact.collect()
    assert result['fips'] is True

    # If a file_exist is checked and it does not exist, then return None
    def mock_get_file_content_none(file_name):
        return None
    get_file_content.side_effect = mock_get_file_content_none

    fips_fact = FipsFactCollector()
    result = fips_

# Generated at 2022-06-20 19:28:14.635971
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:28:21.951282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a temporary file to test the method collect
    with open('/proc/sys/crypto/fips_enabled', 'w') as tempf:
        tempf.write('0')
    # fips_facts = {}
    # fips_facts['fips'] = False
    with open('/proc/sys/crypto/fips_enabled', 'w') as tempf:
        tempf.write('1')
    # fips_facts = {}
    # fips_facts['fips'] = True
    # No need to remove the file, it will be removed when the test finishes

# Generated at 2022-06-20 19:28:24.192757
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:28:26.050117
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    f = FipsFactCollector()
    assert f.name == 'fips'
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:28:34.360527
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Test collect method of FipsFactCollector"""
    
    # Unit test for fips enabled
    test_class = FipsFactCollector()
    assert test_class.collect().get('fips') == True

    # Unit test for fips disabled
    test_class = FipsFactCollector()
    assert test_class.collect().get('fips') == False

# Generated at 2022-06-20 19:28:41.244026
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FACT_INFO = {'fips': False}
    collector = FipsFactCollector(None, None)

    # Test without crypto/fips_enabled file
    fips_facts = collector.collect()
    assert(fips_facts == FACT_INFO)

    # TODO: pexpect mock doesn't work
    # Test with crypto/fips_enabled file
    # with patch('ansible.module_utils.facts.utils.get_file_content', return_value="1"):
    #     fips_facts = collector.collect()
    #     FACT_INFO['fips'] = True
    #     assert(fips_facts == FACT_INFO)

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 19:28:42.095985
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:28:49.298264
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    ansible_facts = {
        'open_fds': [ ], 
        'mounts': [], 
        'ansible_devices': {}, 
        'ansible_mounts': [], 
        'ansible_all_ipv4_addresses': [],
        'ansible_all_ipv6_addresses': [],
    }
    fips_facts = fips_collector.collect(collected_facts=ansible_facts)
    assert len(fips_facts) == 1

# Generated at 2022-06-20 19:29:57.379359
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

# Generated at 2022-06-20 19:29:59.980677
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    x=FipsFactCollector()
    assert x
    assert x.name == 'fips'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:30:04.792438
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'

    # Ensure not none
    assert FipsFactCollector._fact_ids is not None

    # Ensure empty
    assert len(FipsFactCollector._fact_ids) == 0

# Generated at 2022-06-20 19:30:07.960341
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    fips_fc = FipsFactCollector()
    assert fips_fc.name == 'fips'
    assert fips_fc._fact_ids == set()

# Generated at 2022-06-20 19:30:10.423021
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = None
    ffc = FipsFactCollector()
    assert ffc.collect(module) == {'fips': False}

# Generated at 2022-06-20 19:30:14.791787
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    # Create an instance of FipsFactCollector
    fipsfact_collector = FipsFactCollector()
    # Assert class name
    assert fipsfact_collector.name == 'fips'
    # Assert fact ids
    assert fipsfact_collector._fact_ids == set()

# Generated at 2022-06-20 19:30:22.162910
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FAKE_FILE_CONTENTS

    ffc = FAKE_FILE_CONTENTS
    c = Collector(None, None)

    facts = c.collect(None, None)

    if facts['fips']:
        ffc.pop('/proc/sys/crypto/fips_enabled')
        ffc['/proc/sys/crypto/fips_enabled'] = '1'
    else:
        ffc.pop('/proc/sys/crypto/fips_enabled')
        ffc['/proc/sys/crypto/fips_enabled'] = '0'

    result = FipsFactCollector(None, None).collect(None, facts)
    assert result['fips'] == facts['fips']

# Generated at 2022-06-20 19:30:24.423823
# Unit test for constructor of class FipsFactCollector
def test_FipsFactCollector():
    assert FipsFactCollector.name == 'fips'
    assert FipsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:30:30.495942
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector.fips import FipsFactCollector

    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect().get('fips') == False

# Generated at 2022-06-20 19:30:34.814708
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_collector = FipsFactCollector()
    fips_fact = fips_collector.collect()
    assert type(fips_fact) is dict
    assert 'fips' in fips_fact
    assert type(fips_fact['fips']) is bool