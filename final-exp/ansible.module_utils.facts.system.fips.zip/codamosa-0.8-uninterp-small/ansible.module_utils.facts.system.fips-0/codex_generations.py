

# Generated at 2022-06-25 00:03:03.561018
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Ensures that the method collect of the class FipsFactCollector works as expected
    '''

    # Arrange
    # Nothing to arrange

    # Act
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()

    # Assert
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:03:06.369256
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:03:14.577051
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected_result = {'ansible_facts': {'ansible_fips': False}}
    fips_fact_collector_0 = FipsFactCollector()


# Generated at 2022-06-25 00:03:20.354803
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of the FipsFactCollector class with empty args dict
    fips_fact_collector_0 = FipsFactCollector()

    # Create a mock of the method get_file_content to be used by the fips_fact_collector_0.collect() method
    @patch.object(FipsFactCollector, 'get_file_content', return_value='1')
    def test_case_1(self, mock_get_file_content):
        # Execute the code to be tested
        fips_facts = fips_fact_collector_0.collect()

        # Make assertions on the results
        assert fips_facts['fips'] == True

    # Execute test case 1
    test_case_1(self)

    # Create a mock of the method get_file_content to be used by the

# Generated at 2022-06-25 00:03:21.068138
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:28.022143
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    # test response for fips enabled
    fips_fact_collector_0.get_file_content = lambda x: '1'
    response = fips_fact_collector_0.collect()
    assert response == {'fips': True}
    # test response for fips not enabled
    fips_fact_collector_0.get_file_content = lambda x: '2'
    response = fips_fact_collector_0.collect()
    assert response == {'fips': False}
    # test response for fips file not present
    fips_fact_collector_0.get_file_content = lambda x: None
    response = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:32.117744
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_data ={}
    fixture_data['fips'] = False
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert fips_facts == fixture_data

# Generated at 2022-06-25 00:03:36.783499
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:42.449544
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect_0 = FipsFactCollector()
    fips_fact_collector_collect_1 = FipsFactCollector()
    assert fips_fact_collector_collect_0.collect() == fips_fact_collector_collect_1.collect()

# Generated at 2022-06-25 00:03:45.492898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector_collect = fips_fact_collector.collect()
    assert 'fips' in fips_fact_collector_collect

# Generated at 2022-06-25 00:03:58.459357
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts_0 = {}

    # Collect method on FipsFactCollector instance should return a dict.
    # The returned dict should have key 'fips' and the key should have value True or False.
    assert isinstance(fips_fact_collector_0.collect(collected_facts=collected_facts_0), dict)
    assert 'fips' in fips_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert isinstance(fips_fact_collector_0.collect(collected_facts=collected_facts_0)['fips'], bool)

# Generated at 2022-06-25 00:04:03.813664
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with a standard FIPS system - 1
    test_FipsFactCollector_collect_0 = FipsFactCollector()
    data = '1'
    def mock_get_file_content(filename):
        if filename == '/proc/sys/crypto/fips_enabled':
            return data
        else:
            assert False
    test_FipsFactCollector_collect_0.get_file_content = mock_get_file_content
    expected_result = {'fips': True}
    result = test_FipsFactCollector_collect_0.collect()
    assert result == expected_result
    # Test with a standard FIPS system - 0
    test_FipsFactCollector_collect_1 = FipsFactCollector()
    data = '0'

# Generated at 2022-06-25 00:04:08.270678
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    module = ansible_mock.AnsibleModule()
    collected_facts = ansible_mock.AnsibleModule().params
    assert fips_fact_collector_0.collect(module=module, collected_facts=collected_facts) == {'fips': False}

# Generated at 2022-06-25 00:04:11.942659
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}


# Generated at 2022-06-25 00:04:14.051635
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-25 00:04:17.801374
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fips_fact_collector_collect = FipsFactCollector()
    fips_fact_collector_collect.collect()



# Generated at 2022-06-25 00:04:22.099925
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:04:24.762962
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == { 'fips': False }



# Generated at 2022-06-25 00:04:27.560023
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:04:29.287293
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect = FipsFactCollector()
    fips_fact_collector_collect.collect()

# Generated at 2022-06-25 00:04:41.899768
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1._module = Mock()
    fips_fact_collector_1._module.run_command = Mock()
    fips_fact_collector_1._module.run_command.return_value = (0, "\x01")

# Check that facts['fips'] is set to True
    fips_fact_collector_1.collect()
    fact_fips = fips_fact_collector_1._module._collected_facts
    assert fact_fips['fips'] == True

# Check that facts['fips'] is set to False
    fips_fact_collector_1._module.run_command.return_value = (0, "\x00")
    fips_fact_collector_

# Generated at 2022-06-25 00:04:45.324167
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:50.659524
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:52.019034
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:04:53.968996
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:03.063610
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1._module = FakeModule()
    fips_fact_collector_1._module.run_command = FakeRunCommand()
    fips_fact_collector_1._module.run_command.commands = {
        'cat /proc/sys/crypto/fips_enabled': (0, "1", ""),
        'cat /proc/sys/crypto/fips_enabled': (1, "0", ""),
    }
    facts = fips_fact_collector_1.collect()
    assert facts['fips']
    facts = fips_fact_collector_1.collect()
    assert not facts['fips']


# Generated at 2022-06-25 00:05:05.229155
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}


# Generated at 2022-06-25 00:05:07.893355
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_obj_0 = FipsFactCollector()
    assert fips_fact_collector_obj_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:12.350524
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Run collect method and store it in 'result'
    result = fips_fact_collector.collect()
    assert result
    assert isinstance(result, dict)
    assert 'fips' in result
    assert result['fips'] == False

# Generated at 2022-06-25 00:05:15.573140
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {u'fips': False}


# Generated at 2022-06-25 00:05:30.003707
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:34.584154
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_collect_obj = FipsFactCollector()
    Fips_result = FipsFactCollector_collect_obj.collect()
    assert Fips_result == {'fips': False}

# Generated at 2022-06-25 00:05:35.679286
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()


# Generated at 2022-06-25 00:05:40.213910
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    facts = fips_fact_collector_1.collect()
    assert bool(facts.get('fips')) == False

# Generated at 2022-06-25 00:05:44.075292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    exp = {'fips': False}
    ret = fips_fact_collector_0.collect(collected_facts)
    assert ret == exp


# Generated at 2022-06-25 00:05:45.730657
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:49.174007
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert type(fips_facts_1) is dict
    assert fips_facts_1.get('fips') is not None

# Generated at 2022-06-25 00:05:52.694567
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:54.412373
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}


# Generated at 2022-06-25 00:05:58.896660
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    module = object()
    collected_facts = object()
    fips_facts = fips_fact_collector.collect(module, collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:06:29.239487
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    facts_dict = fips_fact_collector_0.collect()
    if facts_dict is None:
        print('False is not equal to True')


# Generated at 2022-06-25 00:06:31.877172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    assert fips_facts_0 == {}

# Generated at 2022-06-25 00:06:34.386668
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert fips_fact_collector_0.fips == True

# Generated at 2022-06-25 00:06:40.097621
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    print(fips_facts_0)

# Generated at 2022-06-25 00:06:50.620663
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case with argument collected_facts=None
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect(collected_facts=None)
    assert fips_facts_0['fips'] == False
    # Test case with argument collected_facts
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect(collected_facts)
    assert fips_facts_1['fips'] == False
    # Test case with argument module=None
    fips_fact_collector_2 = FipsFactCollector()

# Generated at 2022-06-25 00:06:53.043537
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:06:55.063815
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts

# Generated at 2022-06-25 00:06:59.973905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print ("Starting test_FipsFactCollector_collect method ...")
    assert(FipsFactCollector().collect() == {'fips': False})
    print ("Successfully finished test_FipsFactCollector_collect method ...")

# Generated at 2022-06-25 00:07:02.204448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:07:04.186097
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data1 = "1"
    data2 = "0"
    obj = FipsFactCollector()
    fips_facts = obj.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:07:33.334838
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': True}


# Generated at 2022-06-25 00:07:35.056869
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:07:36.388508
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    return None


# Generated at 2022-06-25 00:07:38.920542
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Parameter validity check
    # Return True
    var_0 = FipsFactCollector().collect()
    assert True

# Generated at 2022-06-25 00:07:40.620104
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:07:42.354494
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()



# Generated at 2022-06-25 00:07:44.252043
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] == False

# Generated at 2022-06-25 00:07:50.040914
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = fips_fact_collector_0.collect()
    var_0 = fips_fact_collector_0.collect()
    var_2 = fips_fact_collector_0.collect()
    var_3 = fips_fact_collector_0.collect()
    var_4 = fips_fact_collector_0.collect()
    var_5 = fips_fact_collector_0.collect()
    var_6 = fips_fact_collector_0.collect()
    assert var_0 == var_1
    assert var_0 != var_2
    assert var_2 == var_3
    assert var_5 != var

# Generated at 2022-06-25 00:07:51.746601
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    # Input Parameters Test:
    #   - module
    #   - collected_facts
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:07:59.273749
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # No arguments
    # Run the method
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] == False
    # Run the method
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert var_2['fips'] == False

# Generated at 2022-06-25 00:09:00.719621
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:09:04.050347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    var = fips_fact_collector.collect()

    assert var is not None

# Generated at 2022-06-25 00:09:05.424731
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:09:10.225114
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:09:12.209341
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {
        'fips': False,
    }

# Generated at 2022-06-25 00:09:13.508199
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:09:17.066258
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:09:20.800134
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_mock = MagicMock()
    collected_facts_mock = MagicMock()
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect(module_mock, collected_facts_mock)


# Generated at 2022-06-25 00:09:22.553874
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:09:24.643153
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:11:47.265670
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    fips_fact_collector._fact_ids = set()
    assert fips_fact_collector.collect(collected_facts=collected_facts) == {'fips': False}
    assert collected_facts == {}
    assert fips_fact_collector._fact_ids == {'fips'}


# Generated at 2022-06-25 00:11:48.314539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:11:52.863626
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with a file that does not exist for /proc/sys/crypto/fips_enabled
    fips_fact_collector_0 = FipsFactCollector()
    with patch('ansible.module_utils.facts.collector.get_file_content',
                return_value=''):
        var_0 = fips_fact_collector_0.collect()
        assert var_0 == {'fips': False}
    # Test with a file that does not exist for /proc/sys/crypto/fips_enabled
    fips_fact_collector_1 = FipsFactCollector()
    with patch('ansible.module_utils.facts.collector.get_file_content',
                return_value=None):
        var_1 = fips_fact_collector_1.collect()
        assert var

# Generated at 2022-06-25 00:11:56.646634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:58.372068
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert True

# Generated at 2022-06-25 00:12:05.316276
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    #
    # This will fail if /proc/sys/crypto/fips_enabled does not exist, if it exists
    # the file will be read and the contents validated
    #
    res = fips_fact_collector_0.collect()
    assert res['fips'] == False

# Generated at 2022-06-25 00:12:08.236781
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        fips_fact_collector_1 = FipsFactCollector()
        var_1 = fips_fact_collector_1.collect()
        assert var_1 == {'fips': False}
        # This can't be tested without altering the system
    except:
        pass

# Generated at 2022-06-25 00:12:09.134031
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var = FipsFactCollector()
    var.collect()

# Generated at 2022-06-25 00:12:10.927828
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert len(var_0) == 1


# Generated at 2022-06-25 00:12:12.669668
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': False}