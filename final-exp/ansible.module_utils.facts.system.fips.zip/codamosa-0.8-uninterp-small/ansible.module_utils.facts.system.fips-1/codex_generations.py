

# Generated at 2022-06-25 00:02:55.675248
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts == {}

# Generated at 2022-06-25 00:02:57.003484
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:02:58.659742
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:06.896910
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test function with 'fips' set to True
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert isinstance(fips_facts, dict)
    assert fips_facts['fips'] == True

    # Test function with 'fips' set to False
    fips_fact_collector_2 = FipsFactCollector()
    fips_facts = fips_fact_collector_2.collect()
    assert isinstance(fips_facts, dict)
    if fips_facts['fips'] == True:
        assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:03:18.083909
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    module_mock = {}
    collected_facts_mock = {}

    fips_fact_collector_1 = FipsFactCollector()

    fips_facts_mock = {}
    fips_facts_mock['fips'] = False

    fips_facts_mock_2 = {}
    fips_facts_mock_2['fips'] = True

    fips_fact_collector_1.get_file_content = lambda x: None
    assert fips_fact_collector_1.collect(module=module_mock, collected_facts=collected_facts_mock) == fips_facts_mock

    fips_fact_collector_1.get_file_content = lambda x: '0'

# Generated at 2022-06-25 00:03:21.163162
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts

# Generated at 2022-06-25 00:03:24.375276
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    # Test the default case
    fips_facts = fips_fact_collector_0.collect()
    print(fips_facts)
    assert fips_facts == {'fips': True}

# Generated at 2022-06-25 00:03:26.015958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.fips = False
    assert fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:28.756245
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert fips_facts["fips"] == False

# Generated at 2022-06-25 00:03:32.382929
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_module_0 = object()
    test_FipsFactCollector_collect_0 = FipsFactCollector()
    fips_facts = test_FipsFactCollector_collect_0.collect(test_module_0)

# Generated at 2022-06-25 00:03:36.311262
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:03:40.352020
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    res = fips_fact_collector_0.collect()
    assert res == False

# Generated at 2022-06-25 00:03:46.191684
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # fips_fact_collector_0 = FipsFactCollector()
    collected_facts = dict()
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.name = "fips"
    expected_facts = dict({u'fips': True})
    fips_facts = fips_fact_collector_0.collect(collected_facts=collected_facts)
    assert(fips_facts == expected_facts)

# Generated at 2022-06-25 00:03:48.287867
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    result = fips_fact_collector_1.collect()
    assert 'fips' in result

# Generated at 2022-06-25 00:03:54.074044
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data_0 = fips_fact_collector_0.collect(module='0', collected_facts={})
    assert data_0 == {'fips': False}


# Generated at 2022-06-25 00:03:57.702130
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print('Testing FipsFactCollector_collect')
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    # Assert if the fips key exists
    assert 'fips' in fips_facts.keys()

# Generated at 2022-06-25 00:04:00.194098
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    ret = fips_fact_collector_0.collect()
    assert isinstance(ret, dict)

# Generated at 2022-06-25 00:04:05.407553
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0._file_exists = mock.MagicMock(side_effect = [True, True, True, True, True, False, False, False, False, False])
    fips_fact_collector_0._get_file_content = mock.MagicMock(return_value = '1')
    # Test
    result = fips_fact_collector_0.collect()
    # Assertions
    assert result['fips'] is True

# Generated at 2022-06-25 00:04:08.957260
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data = fips_fact_collector_0.collect()
    print(data)

if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:04:12.294747
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}


# Generated at 2022-06-25 00:04:21.665927
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert type(fips_fact_collector.collect()) is dict

# Generated at 2022-06-25 00:04:23.909894
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    r = fips_fact_collector_1.collect()
    assert type(r) is dict

# Generated at 2022-06-25 00:04:30.300128
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    # calls the method
    fips_facts = fips_fact_collector_1.collect()
    # checks return type
    assert isinstance(fips_facts, dict)
    for fips_fact_id, fips_fact_value in fips_facts.items():
        # checks the result for being a boolean
        assert isinstance(fips_fact_value, bool)

# Generated at 2022-06-25 00:04:35.138669
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_0 = FipsFactCollector().collect()
    assert type(fips_facts_0) is dict
    fips_facts_keys = fips_facts_0.keys()
    fips_facts_keys.sort()
    assert fips_facts_keys == ['fips']
    assert fips_facts_0['fips'] is False

# Generated at 2022-06-25 00:04:37.947799
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts.keys()



# Generated at 2022-06-25 00:04:40.413172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts = {}
    fips_fact_collector_1.collect(None, collected_facts)
    assert collected_facts.get('fips') == False


# Generated at 2022-06-25 00:04:45.235194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}



# Generated at 2022-06-25 00:04:55.254639
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup
    test_fips_facts = {'fips': True, 'system': 'Linux'}
    fips_fact_collector = FipsFactCollector()

    # Execution
    fips_fact_collector.collect(None, test_fips_facts)

    # Verification
    assert('fips' in test_fips_facts)
    assert('system' in test_fips_facts)
    assert(test_fips_facts['fips'] == True)
    assert(test_fips_facts['system'] == 'Linux')


# Generated at 2022-06-25 00:05:00.978004
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    fips_facts = {'fips': False}
    assert fips_fact_collector.collect(collected_facts=collected_facts) == fips_facts


# Generated at 2022-06-25 00:05:06.367614
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # setup test data
    fips_fact_collector_1 = FipsFactCollector()
    data_1 = "1"
    data_2 = "0"
    data_3 = ""
    module_1 = fips_fact_collector_1.collect()
    assert module_1['fips'] == False
    fips_fact_collector_1._module_utils.get_file_content = lambda x: data_1
    module_1 = fips_fact_collector_1.collect()
    assert module_1['fips'] == True
    fips_fact_collector_1._module_utils.get_file_content = lambda x: data_2
    module_1 = fips_fact_collector_1.collect()
    assert module_1['fips'] == False
    fips_

# Generated at 2022-06-25 00:05:24.141564
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

# Generated at 2022-06-25 00:05:25.732175
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}, 'Incorrect collect()'

# Generated at 2022-06-25 00:05:29.221374
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector_collect_result = fips_fact_collector.collect()
    assert fips_fact_collector_collect_result == {'fips': False}


# Generated at 2022-06-25 00:05:39.255098
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # This file is only present on a system in 'fips' mode
    # if os.path.exists('/proc/sys/crypto/fips_enabled'):
    #     fips_fact_collector_1 = FipsFactCollector()
    #     fips_facts_1 = fips_fact_collector_1.collect()
    #     assert fips_facts_1 != None
    #     assert fips_facts_1['fips'] == True
    # else:
    #     fips_fact_collector_2 = FipsFactCollector()
    #     fips_facts_2 = fips_fact_collector_2.collect()
    #     assert fips_facts_2 == None
    pass

# Generated at 2022-06-25 00:05:44.684211
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with /proc/sys/crypto/fips_enabled file present
    fips_fact_collector = FipsFactCollector()
    option_set = {'get_file_content': '/proc/sys/crypto/fips_enabled'}
    result = fips_fact_collector.collect(None, None, option_set=option_set)
    assert result['fips'] == False
    option_set = {'get_file_content': '/proc/sys/crypto/fips_enabled', 'content': '1'}
    result = fips_fact_collector.collect(None, None, option_set=option_set)
    assert result['fips'] == True
    # Test with /proc/sys/crypto/fips_enabled file not present

# Generated at 2022-06-25 00:05:46.876106
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}


# Generated at 2022-06-25 00:05:49.547900
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-25 00:05:52.693980
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:57.820053
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = {'fips': False}
    assert fips_fact_collector_1.name == 'fips'
    assert fips_fact_collector_1.collect(collected_facts=None) == fips_facts_1

# Generated at 2022-06-25 00:06:00.253494
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:19.029352
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:06:20.467612
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var0 = {'fips': False}
    assert var0 == FipsFactCollector().collect()


# Generated at 2022-06-25 00:06:21.782173
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    myFipsFactCollector = FipsFactCollector()
    myFipsFactCollector.collect()

# Generated at 2022-06-25 00:06:23.194278
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect()



# Generated at 2022-06-25 00:06:25.444588
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()



# Generated at 2022-06-25 00:06:27.840299
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {
        'fips': False,
    }

# Generated at 2022-06-25 00:06:31.624817
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:06:38.628170
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # test with empty file
    fips_fact_collector_0 = FipsFactCollector()
    def open_mock_0(file, open_flag='r'):
        test_file = open(file, open_flag)
        empty_file = ''
        test_file.read_data = empty_file
        return test_file
    fips_fact_collector_0.open = open_mock_0
    fips_fact_collector_0.file_exists = lambda file_path: True
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

    # test with 0
    fips_fact_collector_0 = FipsFactCollector()

# Generated at 2022-06-25 00:06:40.518327
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Create a test object of FipsFactCollector
    test_obj = FipsFactCollector()

    # Invoke the method
    actual_return = test_obj.collect()

    #Finally check the returned value
    assert actual_return == False

# Generated at 2022-06-25 00:06:45.266368
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:20.550485
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = set()
    fips_fact_collector_0._fact_ids = var_0
    var_1 = get_file_content('/proc/sys/crypto/fips_enabled')
    var_2 = dict()
    var_3 = False
    var_2['fips'] = var_3
    if var_1 and var_1 == '1':
        var_4 = True
        var_2['fips'] = var_4
    var_5 = fips_fact_collector_0.collect(collected_facts=var_2)
    assert var_5 == var_2

# Generated at 2022-06-25 00:07:23.473747
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:07:27.741658
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:30.815618
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert str(type(var_0)) == "<type 'dict'>"
    assert var_0['fips'] == False


# Generated at 2022-06-25 00:07:33.663904
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        fips_fact_collector_0 = FipsFactCollector()
        fips_fact_collector_0.collect()
    except:
        assert False


# Generated at 2022-06-25 00:07:39.385414
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    method = FipsFactCollector.collect
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert type(var_0) == dict or var_0 is None, ("The variable var_0 is of type %s, expected type is %s" % (type(var_0), dict))
    if (var_0 is not None):
        assert 'fips' in var_0, ("The variable var_0['fips'] is not set. The value is: %s" % (var_0['fips']))
        assert type(var_0['fips']) == bool, ("The variable var_0['fips'] is of type %s, expected type is %s" % (type(var_0['fips']), bool))


# Generated at 2022-06-25 00:07:42.090914
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # unit tests for method collect of class FipsFactCollector
    var = FipsFactCollector()
    facts = var.collect()
    assert facts is not None
    assert isinstance(facts['fips'], bool)

# Generated at 2022-06-25 00:07:42.731717
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_case_0()
    assert True

# Generated at 2022-06-25 00:07:44.837484
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_ = FipsFactCollector()
    # Testing if value of fips is False
    if True:
        result = fips_fact_collector_.collect()
        assert False == result['fips']

# Generated at 2022-06-25 00:07:46.631875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        fips_fact_collector_0 = FipsFactCollector()
        var_0 = fips_fact_collector_0.collect()
    except Exception as e:
        print("Test {0} failed: {1}".format("FipsFactCollector_collect", str(e)))
        assert False

# Generated at 2022-06-25 00:08:48.458351
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:08:49.681548
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:51.795907
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:08:53.714927
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Arrange
    fips_fact_collector_0 = FipsFactCollector()

    # Act
    var_0 = fips_fact_collector_0.collect()

    # Assert
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:08:59.652586
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}, 'fips_fact_collector_0.collect does not return {\'fips\': False}'


# Generated at 2022-06-25 00:09:01.344111
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:09:02.865255
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_instance = FipsFactCollector()
    var_0 = FipsFactCollector_instance.collect()
    assert var_0['fips'] == False


# Generated at 2022-06-25 00:09:03.614455
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Nothing to test in get_file_content.
    pass


# Generated at 2022-06-25 00:09:08.276077
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    name_0 = 'fips'
    fact_ids_0 = set()
    var_0 = FipsFactCollector(name_0, fact_ids_0)
    data_1 = get_file_content('/proc/sys/crypto/fips_enabled')
    var_1 = var_0.collect()
    assert var_1 == {'fips': False}
    # NOTE: this is populated even if it is not set
    data_2 = get_file_content('/proc/sys/crypto/fips_enabled')
    fips_facts_0 = {}
    fips_facts_0['fips'] = False
    var_2 = fips_facts_0
    if data_2 and data_2 == '1':
        fips_facts_0['fips'] = True
    var_

# Generated at 2022-06-25 00:09:11.295444
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:11:32.628285
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()

    # Test cases
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False
    assert var_0.get('fips') == False
    assert var_0.get('ansible_facts', {}).get('fips') == False

# Generated at 2022-06-25 00:11:34.411458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:11:38.449757
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # noinspection PyTypeChecker
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == None



# Generated at 2022-06-25 00:11:41.177063
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert var_0 == fips_facts


# Generated at 2022-06-25 00:11:42.215583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:45.274174
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:11:46.677838
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()



# Generated at 2022-06-25 00:11:48.222790
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:11:49.691267
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:11:53.555170
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = FipsFactCollector()
    var_2 = False
    var_3 = var_1.collect(var_2)
    assert var_3 == {'fips': False}
    var_1 = FipsFactCollector()
    var_2 = {}
    var_3 = var_1.collect(var_2)
    assert var_3 == {'fips': False}
    var_1 = FipsFactCollector()
    var_2 = None
    var_3 = var_1.collect(var_2)
    assert var_3 == {'fips': False}
    var_1 = FipsFactCollector()
    var_2 = {'fips': False}
    var_3 = var_1.collect(var_2)