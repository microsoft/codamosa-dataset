

# Generated at 2022-06-25 00:02:58.088147
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()

    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:03:03.162101
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert isinstance(fips_facts, dict) and fips_facts

# Generated at 2022-06-25 00:03:07.414777
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled') as f_0:
        f_0.read = lambda: '1'
        fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:10.409295
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    host_facts_0 = [{u'fips': False}]
    FipsFactCollector.collect(host_facts=host_facts_0)

# Generated at 2022-06-25 00:03:13.563415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert len(fips_fact_collector.collect()) == 1


# Generated at 2022-06-25 00:03:16.043009
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:03:18.272626
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:20.539736
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {
        'fips': False
    }

# Generated at 2022-06-25 00:03:25.769333
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._module = MockModule()
    fips_fact_collector._module.fail_json = Mock(return_value=False)
    fips_fact_collector._read_from_file = Mock(return_value='1')
    fips_fact_collector.collect()
    assert_equals(fips_fact_collector.get_facts()['fips'], True)


# Generated at 2022-06-25 00:03:28.475714
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

    out = fips_fact_collector_1.collect()

    assert out == {'fips': None}


# Generated at 2022-06-25 00:03:35.814526
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {u'memory': None, u'display': None, u'virtual': None, u'machine': None}
    module = None
    expected = {'fips': False}
    gathered_facts = fips_fact_collector_0.collect()
    assert gathered_facts == expected

# Generated at 2022-06-25 00:03:38.263490
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Unit test for method FipsFactCollector.collect
    '''
    fips_fact_collector_0 = FipsFactCollector()

    collected_facts_0 = {
        'fips': False,
    }

    fips_facts_0 = fips_fact_collector_0.collect()
    assert fips_facts_0 == collected_facts_0

# Generated at 2022-06-25 00:03:40.635597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    return # this test is not used because FipsFactCollector does not have a collect method

# Generated at 2022-06-25 00:03:42.982604
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data_0 = {'fips': False}
    result = fips_fact_collector_0.collect(None, None)
    assert data_0 == result

# Generated at 2022-06-25 00:03:50.400400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # fips_fact_collec_1 is an instance of class FipsFactCollector
    fips_fact_collector_1 = FipsFactCollector()

    with open('/proc/sys/crypto/fips_enabled', 'w') as mock_fips_enabled:
        mock_fips_enabled.write('0')
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:03:55.705858
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)


# Generated at 2022-06-25 00:03:59.141783
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_var = FipsFactCollector()
    assert True == test_var.collect()

# Generated at 2022-06-25 00:04:01.189927
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = {'fips': True}
    assert fips_fact_collector_0.collect() == fips_facts

# Generated at 2022-06-25 00:04:11.095381
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = '1'
    get_file_content_original = FipsFactCollector.get_file_content
    FipsFactCollector.get_file_content = lambda self, filename: data
    try:
        fips_fact_collector_obj = FipsFactCollector()
        result = fips_fact_collector_obj.collect()
        assert result == {'fips': True}
    finally:
        FipsFactCollector.get_file_content = get_file_content_original

    data = '0'
    FipsFactCollector.get_file_content = lambda self, filename: data

# Generated at 2022-06-25 00:04:19.463580
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    failure=False
    fips_fact_collector_0 = FipsFactCollector()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    fips_fact_collector_0.collect({},{})
    fips_fact_collector_0.collect({},{})
    fips_fact_collector_0.collect({},{})
    fips_fact_collector_0.collect({},{})
    fips_fact_collector_0.collect({},{})
    if failure:
        raise RuntimeError("Failure detected in test_FipsFactCollector_collect")


# Generated at 2022-06-25 00:04:28.421684
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:04:33.616207
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:04:35.470338
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_collect_0 = FipsFactCollector()
    FipsFactCollector_collect_0.collect(collected_facts={})


# Generated at 2022-06-25 00:04:37.690000
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert isinstance(var_1, dict) == True

# Generated at 2022-06-25 00:04:41.171675
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Unit test for method collect of class FipsFactCollector
    # Tests that the proper facts are collected in the case that
    # the fips_enabled file is present but not set.
    test_case_0 = {
        "fips": False
    }
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == test_case_0



# Generated at 2022-06-25 00:04:46.465569
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module = object()
    collected_facts = object()
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect(module=module, collected_facts=collected_facts) == {
        u'fips': False,
    }

# Generated at 2022-06-25 00:04:50.426934
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()

# Generated at 2022-06-25 00:04:54.931875
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test when module is None
    # Test when collected_facts is None
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    # Test when module is not None
    # Test when collected_facts is not None


test_case_0()

# Generated at 2022-06-25 00:04:56.733001
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:05:00.619271
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:05:14.280697
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Case 0: no FIPS mode
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

    # Case 1: with FIPS mode
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.get_file_content = lambda x: '1'
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': True}

# Generated at 2022-06-25 00:05:18.472777
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_0 = AnsibleModule({})
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect(module=module_0)
    assert var_0['fips'] == False



# Generated at 2022-06-25 00:05:19.709597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:05:26.292663
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Function test_case_0 is used to test method collect of class FipsFactCollector
    # This function is automatically generated by test_FipsFactCollector_gen
    # Please modify test_case_0 if you want to test method collect of class FipsFactCollector
    test_case_0()

# Generated at 2022-06-25 00:05:33.543480
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, FipsFactCollector)
    assert hasattr(fips_fact_collector, "collect")
    assert callable(getattr(fips_fact_collector, "collect", None))

# Generated at 2022-06-25 00:05:36.030524
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': True}


# Generated at 2022-06-25 00:05:40.288203
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    # Testing if instances of class 'FipsFactCollector' are callable
    assert callable(fips_fact_collector_1.collect)

# Generated at 2022-06-25 00:05:44.719613
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector_0 = FipsFactCollector()
    var_0 = fact_collector_0.collect()
    assert var_0['fips'] == False
    fact_collector_0._module = True
    var_1 = fact_collector_0.collect()
    assert var_1['fips'] == False


# Generated at 2022-06-25 00:05:50.219383
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector with mock attributes
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect = MagicMock(side_effect = fips_fact_collector_0.collect())
    var_0 = fips_fact_collector_0.collect()
    fips_fact_collector_0.collect.assert_called_with()
    assert var_0 == {'fips': True}

# Generated at 2022-06-25 00:05:52.787616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    expected = FipsFactCollector.collect()
    actual = fips_fact_collector.collect()
    assert expected == actual

# Generated at 2022-06-25 00:06:07.940421
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  fips_fact_collector_0 = FipsFactCollector()
  var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:06:09.782148
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:06:11.712531
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # User provided params
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data == '1':
        assert True
    elif data == '0':
        assert False

# Generated at 2022-06-25 00:06:13.861830
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts_0 = dict()
    collected_facts_0['fips'] = False
    fips_fact_collector_0.collect(collected_facts = collected_facts_0)

# Generated at 2022-06-25 00:06:19.352117
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    fips_fact_collector_ret = FipsFactCollector_obj.collect()
    assert fips_fact_collector_ret['fips'] == False


# Generated at 2022-06-25 00:06:21.077724
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:22.967738
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    fips_facts = {}
    fips_facts['fips'] = False
    if data and data == '1':
        fips_facts['fips'] = True
    val = fips_facts['fips']


# Generated at 2022-06-25 00:06:28.558649
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_2 = FipsFactCollector()
    fips_fact_collector_0.collect()
    fips_fact_collector_1.collect()
    fips_fact_collector_2.collect()


# Generated at 2022-06-25 00:06:31.684315
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:06:35.766512
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect(  )
    var_0 = fips_fact_collector_0.collect(  )
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:07:04.485634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:08.603709
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test class not found
    if test_case_0 == False:
        assert test_case_0 == True, "Test case failed"
    else:
        try:
            import test.test_fips_facts
        except ImportError:
            assert test_case_0 == False, "Test case failed"

# Generated at 2022-06-25 00:07:09.569188
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var = FipsFactCollector()
    var.collect()

# Generated at 2022-06-25 00:07:13.043921
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts_1 = dict()
    collected_facts_1['ansible_collected_facts'] = dict()
    collected_facts_1['ansible_collected_facts']['fips'] = True
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == collected_facts_1['ansible_collected_facts']


# Generated at 2022-06-25 00:07:14.187905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:15.332777
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  fact = {}
  assert FipsFactCollector.collect(None, fact) == {
          'fips': True
      }

# Generated at 2022-06-25 00:07:19.437259
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_mock = AnsibleModuleMock('FipsFactCollector')
    params = {'module': module_mock}
    module_mock.set_module_args(params)
    fips_fact_collector = FipsFactCollector()
    # 2. Call method collect
    var_return = fips_fact_collector.collect()
    assert var_return == None


# Generated at 2022-06-25 00:07:20.945107
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:07:31.919845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_0 = {
    }
    fixture_1 = {
        'fips': False
    }
    fixture_2 = {
        'fips': True
    }
    fixture_3 = {
        'fips': False
    }
    fixture_4 = {
        'fips': True
    }

    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    fips_fact_collector_2 = FipsFactCollector()
    fixture_0['fips'] = False

# Generated at 2022-06-25 00:07:33.494448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:39.996751
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected_0 = {'fips': False}
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == expected_0


# Generated at 2022-06-25 00:08:41.555088
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:43.104718
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # NOTE: the example above calls the method directly,
    # so we can skip this method test in that case

    pass  # noqa

# Generated at 2022-06-25 00:08:46.080919
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:08:51.522649
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect(): 
    # Test case 1
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect() 			
    #Test case 2
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect(module=None, collected_facts=None)
    assert(var_2['fips'] == False) 	
    #Test case 3
    fips_fact_collector_3 = FipsFactCollector()
    var_3 = fips_fact_collector_3.collect(module=None, collected_facts=None) 		
    assert(var_3['fips'] == False)
    #Test case 4
    fips_fact_collector_

# Generated at 2022-06-25 00:08:53.814954
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False



# Generated at 2022-06-25 00:08:55.784204
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_obj_0 = FipsFactCollector()
    var_0 = fips_fact_collector_obj_0.collect()
    assert var_0['fips'] == False

# Generated at 2022-06-25 00:08:59.563610
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_obj = FipsFactCollector()
    var_1 = FipsFactCollector_obj.collect()

if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:09:02.811702
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == fips_facts


# Generated at 2022-06-25 00:09:05.123561
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    # Check if the fips value is correct.
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    assert (data == '1') == fips_fact_collector_0._fact_ids()['fips']

# Generated at 2022-06-25 00:11:29.306408
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {u'fips': False}

# Generated at 2022-06-25 00:11:31.826898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # assert statement
    var_1 = FipsFactCollector()
    var_2 = var_1.collect()
    assert var_2 == {'fips': False}

# Generated at 2022-06-25 00:11:33.906546
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:11:38.594330
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_1 = FipsFactCollector()
    var_1.collect()
    assert var_0.name == var_1.name
    assert var_0._fact_ids == var_1._fact_ids

# Generated at 2022-06-25 00:11:39.732568
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    assert var_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:11:45.140649
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:46.528620
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-25 00:11:47.639500
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:51.666082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = get_file_content('/proc/sys/crypto/fips_enabled')
    if var_1 == '1':
        fips_fact_collector_0.collect() == True
    else:
        fips_fact_collector_0.collect() == False



# Generated at 2022-06-25 00:11:54.321011
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True

# vim: set expandtab shiftwidth=4 tabstop=4 softtabstop=4