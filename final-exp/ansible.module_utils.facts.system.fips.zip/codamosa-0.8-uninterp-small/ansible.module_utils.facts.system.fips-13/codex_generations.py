

# Generated at 2022-06-25 00:02:58.292712
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()

# Generated at 2022-06-25 00:02:59.997676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:03:03.366346
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_instance_0 = FipsFactCollector()
    FipsFactCollector_instance_0.collect()


# Generated at 2022-06-25 00:03:09.016296
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert fips_facts_0 == fips_facts_1

# Generated at 2022-06-25 00:03:12.748433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = {
        'fips': True
        }
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-25 00:03:14.973088
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': True}


# Generated at 2022-06-25 00:03:17.355325
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    result = fips_fact_collector_1.collect()
    assert result['fips'] is False


# Generated at 2022-06-25 00:03:19.098286
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] is False

# Generated at 2022-06-25 00:03:22.262968
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test collecting facts without invoking the module
    collected_facts = {}
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect(None, collected_facts)
    assert collected_facts['fips'] == False

# Generated at 2022-06-25 00:03:25.198389
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:03:28.802519
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_2 = FipsFactCollector()
    var_0 = fips_fact_collector_2.collect()

# Generated at 2022-06-25 00:03:32.073661
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # assert not implemented, test disabled
    # fips_fact_collector_0 = FipsFactCollector()
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:03:36.246537
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print (FipsFactCollector().collect())


# Generated at 2022-06-25 00:03:41.448244
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    counter=0
    def func1(self, module=None, collected_facts=None):
        nonlocal counter
        counter += 1
        return {'fips': False}

    fips_fact_collector_0 = FipsFactCollector()
    FipsFactCollector.collect = func1
    var_0 = fips_fact_collector_0.collect()
    assert counter == 1
    assert var_0 == {'fips': False}
    assert fips_fact_collector_0.name == 'fips'
    assert fips_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:03:46.256412
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_in_fips_enabled = get_file_content('/proc/sys/crypto/fips_enabled')
    assert fips_in_fips_enabled == '1'
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': True}


# Generated at 2022-06-25 00:03:47.771310
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    r = FipsFactCollector()
    r.collect()

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-25 00:03:51.896935
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:56.578311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    assert (FipsFactCollector.collect() == fips_facts)


# Generated at 2022-06-25 00:04:00.593287
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] == False, "Failed to assert fips_1"

# Generated at 2022-06-25 00:04:02.620187
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()



# Generated at 2022-06-25 00:04:07.018172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    not_expected_0 = 'n'
    actual_0 = ''
    assert actual_0 != not_expected_0

# Generated at 2022-06-25 00:04:10.252306
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert True

# Generated at 2022-06-25 00:04:14.582414
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create new instance of FipsFactCollector
    fips_fact_collector_1 = FipsFactCollector()
    # Store values returned by method collect
    collected_facts = fips_fact_collector_1.collect()

    # Check the values
    assert collected_facts['fips'] is True


# Generated at 2022-06-25 00:04:21.165881
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_2 = FipsFactCollector()
    module_mock_0 = Mock()
    collected_facts_mock_0 = Mock()
    with patch.object(FipsFactCollector, '_fact_ids', new_callable=PropertyMock) as mock_fact_ids:
        fips_fact_collector_0._fact_ids = collected_facts_mock_0

# Generated at 2022-06-25 00:04:23.017951
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Input parameters
    FipsFactCollector. collect(self)

# Generated at 2022-06-25 00:04:28.498097
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 00:04:33.040195
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test using mock object
    var_0 = FipsFactCollector()
    mock_0 = BaseFactCollector()
    mock_0.get_file_content.return_value = '1'
    var_1 = var_0.collect(collected_facts=mock_0)

    assert var_1 == {'fips': True}



# Generated at 2022-06-25 00:04:34.796418
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert isinstance(fips_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:04:36.450673
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:04:39.000574
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    # Verify fips is set
    assert var_0['fips'] is not None

# Generated at 2022-06-25 00:04:51.030958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-25 00:04:53.512333
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:04:59.742350
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()
    assert fips_fact_collector_0.name == 'fips'
    assert fips_fact_collector_0.fact_subset is None
    assert isinstance(fips_fact_collector_0._fact_ids, set) == True
    assert fips_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:05:07.506400
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    # Need to make sure that directory /proc/sys/crypto/fips_enabled exists in the test environment
    # otherwise, the test will throw an exception and the test will fail.
    # To achieve that, the following line creates the directory if it doesn't exist.
    if not os.path.exists("/proc/sys/crypto/fips_enabled"):
        os.makedirs("/proc/sys/crypto/fips_enabled")
    # Need to create the file /proc/sys/crypto/fips_enabled and write 1 to it.
    # Otherwise, the test will fail.
    # To achieve that, the following line creates the file if it exists.

# Generated at 2022-06-25 00:05:10.503012
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_2 = FipsFactCollector()
    var_1 = fips_fact_collector_2.collect()

# Generated at 2022-06-25 00:05:12.275884
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:15.448575
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:05:18.960903
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print('Test method collect of class FipsFactCollector')
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var == {'fips': False}

# Generated at 2022-06-25 00:05:20.760201
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:24.892311
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:40.961123
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    if not PYTHON_VERSION_MAJOR == 3:
        assert isinstance(fips_fact_collector_0, FipsFactCollector)


# Generated at 2022-06-25 00:05:44.683577
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    # Running unit test collect of method collect for class FipsFactCollector
    assert fips_fact_collector_0.collect() == {u'fips': False}


# Generated at 2022-06-25 00:05:47.211725
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:05:50.086520
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_1 = False
    var_2 = {'fips': var_1}
    var_3 = var_0.collect()
    assert var_3 == var_2


# Generated at 2022-06-25 00:05:53.198025
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': False}

# Generated at 2022-06-25 00:05:57.459625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:00.665068
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert not fips_fact_collector_0.collect()

# vim: expandtab filetype=python

# Generated at 2022-06-25 00:06:05.904572
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect().get('fips') == False

# Generated at 2022-06-25 00:06:10.551273
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # This is a dataparam test.
    # Given:
    fips_fact_collector_1 = FipsFactCollector()
    # When:
    var_1 = fips_fact_collector_1.collect()
    # Then:
    assert isinstance(var_1, dict)
    assert 'fips' in var_1
    assert var_1['fips'] == False


# Generated at 2022-06-25 00:06:10.978829
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:06:45.960646
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    data = fips_fact_collector.collect()
    assert type(data) == dict
    assert 'fips' in data

# Generated at 2022-06-25 00:06:46.792307
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:06:48.058366
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    fc.collect()

# Generated at 2022-06-25 00:06:51.459507
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:06:54.205634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc_0 = FipsFactCollector()

    ans_0 = ffc_0.collect()

    assert ans_0 == dict(fips=None)

# Generated at 2022-06-25 00:07:04.512424
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with patch('ansible.module_utils.facts.collector.get_file_content') as get_file_content_function:
        get_file_content_function.return_value = b'1'
        var_0 = FipsFactCollector()
        assert var_0.fips_facts == {'fips': True}
        get_file_content_function.assert_called_once_with('/proc/sys/crypto/fips_enabled')
        get_file_content_function.return_value = b'0'
        var_1 = FipsFactCollector()
        assert var_1.fips_facts == {'fips': False}
        get_file_content_function.assert_called_once_with('/proc/sys/crypto/fips_enabled')

# Generated at 2022-06-25 00:07:12.238283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

    # Assert file _read_proc_sys_crypto_fips_enabled exists
    # Assert fips key exists in fips_facts
    # Assert file crypto/fips_enabled has content 1
    # Assert fips key in fips_facts has content true
    # Assert file crypto/fips_enabled has content 0
    # Assert fips key in fips_facts has content false
    # Assert fact 'fips' exists in collected_facts
    # Assert fips key in fips_facts has content true
    # Assert fips key in collected_facts has content true
    # Assert file crypto/fips_enabled has content 0
    # Assert f

# Generated at 2022-06-25 00:07:15.578941
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:07:16.061451
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:07:20.424167
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert type(fips_facts['fips']) == bool

    fips_0 = fips_fact_collector._content_from_file(file_name=fips_fact_collector._fips_file_name)
    assert type(fips_0) == bool


# Generated at 2022-06-25 00:08:28.913621
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()



# Generated at 2022-06-25 00:08:30.695194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': True}

# Generated at 2022-06-25 00:08:35.314511
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-25 00:08:38.393969
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = FipsFactCollector()
    var_1.collect()


# Generated at 2022-06-25 00:08:41.105905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

    assert var_0 == {}, "Incorrect var_0 returned from FipsFactCollector.collect()"


# Generated at 2022-06-25 00:08:45.064577
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 00:08:48.657933
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = get_file_content('/proc/sys/crypto/fips_enabled')
    fips_fact_collector_1 = FipsFactCollector()
    if var_1 and var_1 == '1':
        var_2 = True
    else:
        var_2 = False
    var_3 = fips_fact_collector_1.collect()
    assert var_3 == {'fips': var_2}


# Generated at 2022-06-25 00:08:50.775412
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fact_list = ['fips']
    var_0 = fips_fact_collector_0.collect(module=None, collected_facts=None)
    for fact in fact_list:
        assert fact in var_0

# Generated at 2022-06-25 00:08:52.382448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:54.703749
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False

# Generated at 2022-06-25 00:11:23.294974
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:11:26.673645
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = None
    fips_fact_collector_1 = FipsFactCollector(module=var_1)
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] == False

# Generated at 2022-06-25 00:11:29.062045
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # This test cannot be used since this collector is not loaded by default
    # and is not tied to any platform (can be used anywhere)
    pass

# Generated at 2022-06-25 00:11:33.043069
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    data_1 = ''
    collected_facts_1 = {}
    var_1 = fips_fact_collector_1.collect(data_1, collected_facts_1)
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:11:35.021697
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:11:41.860082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert not var_0
    assert var_0['fips'] == False

    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert not var_1
    assert var_1['fips'] == False

    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert not var_2
    assert var_2['fips'] == False

# Generated at 2022-06-25 00:11:47.193271
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    try:
        var_0 = fips_fact_collector_0._fact_ids.update("python is awesome")
    except NameError:
        assert False
    try:
        var_1 = fips_fact_collector_0._fact_ids.update("python is awesome")
    except NameError:
        assert False


# Generated at 2022-06-25 00:11:50.892006
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import mock

    # Set up mock
    returned_value = True
    mock_get_file_content = mock.MagicMock(return_value=returned_value)

    # Call method
    try:
        with mock.patch('ansible_collections.ansible.community.plugins.module_utils.facts.utils.get_file_content', new=mock_get_file_content):
            fips_fact_collector_0 = FipsFactCollector()
            var_0 = fips_fact_collector_0.collect()
    except Exception as e:
        raise Exception(str(e))

    assert var_0 == {
        'fips': True
    }

# Generated at 2022-06-25 00:11:55.504561
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 is not None
    assert var_1 == {'fips': True}

# Generated at 2022-06-25 00:11:57.598277
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert callable(FipsFactCollector.collect)
    assert isinstance(FipsFactCollector.collect(), dict)

