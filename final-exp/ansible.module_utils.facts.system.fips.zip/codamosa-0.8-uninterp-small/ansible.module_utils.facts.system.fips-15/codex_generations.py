

# Generated at 2022-06-25 00:02:52.893392
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data = fips_fact_collector_0.collect()
    assert (data.get('fips') == False)

# Generated at 2022-06-25 00:02:57.138036
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:03:02.407185
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert (fips_fact_collector_0.collect() == {'fips': False})

# Testing default value of 'fips'

# Generated at 2022-06-25 00:03:05.699454
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    print(fips_facts)

# Generated at 2022-06-25 00:03:09.569663
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

# Generated at 2022-06-25 00:03:14.031928
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    # Test 1: no file to read from
    fips_dict_1 = fips_fact_collector_1.collect()
    assert fips_dict_1 == {'fips': False}

# Generated at 2022-06-25 00:03:19.698571
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    fips_fact_collector = FipsFactCollector()
    fips_path = '/proc/sys/crypto/fips_enabled'
    contents_off = '0'
    contents_on = '1'

    # Test logic where fips is off
    fips_fact_collector.read_file = MagicMock() 
    fips_fact_collector.read_file.return_value = (True, contents_off)
    result1 = fips_fact_collector.collect()
    assert result1['fips'] == False

    # Test logic where fips is on
    fips_fact_collector.read_file = MagicMock() 
    fips_fact_collector.read_file.return_value = (True, contents_on)
    result2 = fips

# Generated at 2022-06-25 00:03:21.574041
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:23.634947
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert result == {u'fips': False}

# Generated at 2022-06-25 00:03:26.922986
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    result = fips_fact_collector_1.collect()
    assert type(result) == dict
    assert 'fips' in result

# Generated at 2022-06-25 00:03:35.397340
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts = { 'fips' : True}
    else:
        fips_facts = { 'fips' : False}
    assert fips_fact_collector_1.collect() == fips_facts

# Generated at 2022-06-25 00:03:41.730715
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    #unit test for method collect of class FipsFactCollector
    content_0 = '''FILE_CONTENT'''

    #replace content of file /proc/sys/crypto/fips_enabled to content_0
    get_file_content_0 = fips_fact_collector_0.get_file_content
    def get_file_content_0_fixed(file_path):
        if file_path=='/proc/sys/crypto/fips_enabled':
            return content_0
        else:
            return get_file_content_0(file_path)
    fips_fact_collector_0.get_file_content = get_file_content_0_fixed

    #unit test for method collect of class FipsFactCollector


# Generated at 2022-06-25 00:03:45.425207
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # excuting the collect method
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = fips_fact_collector_0.collect(None, None)

    # verifying the result
    assert collected_facts['fips'] == False

# Generated at 2022-06-25 00:03:47.068178
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert isinstance(fips_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:03:49.252992
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:03:54.416384
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Testing with valid value
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert fips_facts_1 is not None

# Generated at 2022-06-25 00:03:56.795802
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    results = fips_fact_collector.collect()
    field = results.get('fips')
    assert isinstance(field, bool)

# Generated at 2022-06-25 00:03:59.816177
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:01.775499
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {u'fips': True}


# Generated at 2022-06-25 00:04:06.281383
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
        fips_fact_collector_ = FipsFactCollector()
        assert fips_fact_collector_.collect() is not None

# Generated at 2022-06-25 00:04:18.281095
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    host_0 = MockAnsibleHost(ansible_facts=dict(fips=dict(fips=False)))
    fs_0 = MockFileSystem(files={'/proc/sys/crypto/fips_enabled': '0'})
    host_0.file_system = fs_0
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect(host_0)


# Generated at 2022-06-25 00:04:25.827831
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    # Stub class to store return value of calls to methods
    class StubCollectedFacts(object):
        pass
    collected_facts = StubCollectedFacts()
    # Stub output of method get_file_content of class Collector
    class StubFileContent(object):
        pass
    collected_facts = StubCollectedFacts()
    # Stub output of method get_file_content of class Collector
    class StubFileContent(object):
        pass
    collected_facts = StubCollectedFacts()
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:32.789744
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    mock_module = {'exit_json': 'test'}
    mock_collected_facts = {'fips': 'test'}
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert fips_facts == {'fips': False}

if __name__ == "__main__":
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:04:35.059953
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert isinstance(result, dict)
    assert 'fips' in result['fips'].keys()

# Generated at 2022-06-25 00:04:37.618847
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

    # Test with params
    result = fips_fact_collector_1.collect(collected_facts=False)
    assert result['fips'] == False


# Generated at 2022-06-25 00:04:40.381393
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_case = {}
    fips_fact_collector_0 = FipsFactCollector()
    assert type(fips_fact_collector_0.collect()) == dict, "Unable to collect facts"

# Unit test check for file content function

# Generated at 2022-06-25 00:04:45.235918
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert isinstance(fips_facts, dict)

# Generated at 2022-06-25 00:04:56.433791
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    # From /proc/sys/crypto/fips_enabled
    fips_fact_collector_0.get_file_content = lambda x: '1'
    assert fips_fact_collector_0.collect()['fips'] == True

    fips_fact_collector_0.get_file_content = lambda x: '0'
    assert fips_fact_collector_0.collect()['fips'] == False

    fips_fact_collector_0.get_file_content = lambda x: 'x'
    assert fips_fact_collector_0.collect()['fips'] == False

# Generated at 2022-06-25 00:05:00.712213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': True}

# Generated at 2022-06-25 00:05:06.783494
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    def get_file_content_side_effect(arg):
        if arg == '/proc/sys/crypto/fips_enabled':
            return '1'
        else:
            return '0'

    module = AnsibleModuleMock()

    fips_fact_collector.get_file_content = mock.Mock(side_effect=get_file_content_side_effect)
    fips_facts = fips_fact_collector.collect(module=module, collected_facts=None)
    assert fips_facts['fips']

# Generated at 2022-06-25 00:05:30.201269
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    ansible_module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )
    ansible_module.params['gather_subset'] = ['all']
    ansible_module.params['gather_timeout'] = 5
    ansible_module_result = Facts({})
    result = fips_fact_collector_0.collect(ansible_module=ansible_module, ansible_module_result=ansible_module_result)
    assert result == {'fips': False}

# Generated at 2022-06-25 00:05:32.020282
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect() == {}


# Generated at 2022-06-25 00:05:35.155458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()


# Generated at 2022-06-25 00:05:39.729254
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result['fips'] is False

# Generated at 2022-06-25 00:05:41.133755
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:46.621423
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    global fips_fact_collector_0
    test_collect_content_0 = '2'
    global get_file_content
    fips_0 = False
    get_file_content = lambda x: test_collect_content_0
    fips_1 = fips_fact_collector_0.collect()
    get_file_content = lambda x: test_collect_content_0
    assert fips_1['fips'] is fips_0



# Generated at 2022-06-25 00:05:52.395984
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    # TODO: assert something about the result

# Generated at 2022-06-25 00:05:54.394341
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an object of class FipsFactCollector
    fips_fact_collector_instance = FipsFactCollector()
    # Run the collect method to collect the fips facts
    fips_fact_collector_instance.collect()

# Generated at 2022-06-25 00:05:58.341298
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector = FipsFactCollector()
    fips_facts = FipsFactCollector.collect()
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:06:00.934115
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert(fips_fact_collector_1.collect()['fips'] is False)

# Generated at 2022-06-25 00:06:37.376386
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Test fips_facts is returned when /proc/sys/crypto/fips_enabled returns '1'
    mock_get_file_content = MagicMock(return_value='1')
    with patch.dict(FipsFactCollector.__dict__, {'get_file_content': mock_get_file_content}):
        fips_fact_collector = FipsFactCollector()
        res = fips_fact_collector.collect(module=None, collected_facts=None)
        assert res['fips'] is True

    # Test fips_facts is returned when /proc/sys/crypto/fips_enabled returns '0'
    mock_get_file_content = MagicMock(return_value='0')

# Generated at 2022-06-25 00:06:38.799702
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    returned_dict = fips_fact_collector_1.collect()
    assert isinstance(returned_dict, dict)

# Generated at 2022-06-25 00:06:40.784415
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    assert len(fips_facts_0['fips']) == 1
    assert not fips_facts_0['fips']


# Generated at 2022-06-25 00:06:44.251251
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:06:47.909106
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert (fips_facts_1['fips'] == False) or (fips_facts_1['fips'] == True)


# Generated at 2022-06-25 00:06:51.974724
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    fips_facts = fips_fact_collector.collect()

    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-25 00:06:54.762024
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    result_1 = fips_fact_collector_1.collect()
    assert result_1 == {'fips': False}

# Generated at 2022-06-25 00:06:58.472807
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:07:01.632146
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data = fips_fact_collector_0.collect()
    assert data['fips'] == False


# Generated at 2022-06-25 00:07:05.020516
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FFC0 = FipsFactCollector()
    facts = FFC0.collect()
    assert facts['fips'] == False or facts['fips'] == True

# Generated at 2022-06-25 00:08:06.866973
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts == {'fips': False}


# Generated at 2022-06-25 00:08:10.282565
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:08:17.195772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    collected_facts = fips_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts == {u'fips': False}

# Generated at 2022-06-25 00:08:18.567184
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:08:27.665946
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.fips import FipsFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    fips_fact_collector = FipsFactCollector()
    assert isinstance(fips_fact_collector, BaseFactCollector)
    assert fips_fact_collector._fact_ids == set()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:08:28.288181
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:08:31.994386
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {}
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect(None, collected_facts)
    assert fips_facts == {'fips': False}


# Generated at 2022-06-25 00:08:35.425674
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    ret = fips_fact_collector.collect()

    assert ret == {'fips': False}

# Generated at 2022-06-25 00:08:43.419801
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Test with a file that exists, with no data
    fips_facts = fips_fact_collector.collect(collected_facts={})
    assert fips_facts['fips'] is True or fips_facts['fips'] is False

    # Test with a non-existent file
    def get_file_content_mock_0(*args, **kwargs):
        return ''
    fips_fact_collector.get_file_content = get_file_content_mock_0
    fips_facts = fips_fact_collector.collect(collected_facts={})
    assert fips_facts['fips'] is False

# Generated at 2022-06-25 00:08:46.943246
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # FipsFactCollector is not initialized
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.name = 'fips'
    fips_fact_collector._fact_ids = set()

    # Return value of method call collect()
    return_value = fips_fact_collector.collect()

    # Test the value of the return value
    assert return_value == {}

test_case_0()
test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:09:58.732757
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert get_file_content('/proc/sys/crypto/fips_enabled') == '1'
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-25 00:10:03.788994
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:10:04.773321
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:09.616253
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    # assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:10:15.209634
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False

# Generated at 2022-06-25 00:10:17.613989
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = fips_fact_collector_0.collect()
    assert var_0 == var_1



# Generated at 2022-06-25 00:10:22.113005
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:24.144019
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:10:28.233120
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_0 = FipsFactCollector()
    # Execute the method being tested.
    var_0 = fixture_0.collect()



# Generated at 2022-06-25 00:10:31.157551
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] is False



# Generated at 2022-06-25 00:12:43.597189
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:12:48.573241
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case 0
    # Patching the return value of function 'get_file_content' with a custom one
    import ansible.module_utils.facts.utils
    fips_fact_collector_0 = FipsFactCollector()
    import types
    fips_fact_collector_0.get_file_content = types.MethodType(get_file_content, fips_fact_collector_0)
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == { 'fips': False }