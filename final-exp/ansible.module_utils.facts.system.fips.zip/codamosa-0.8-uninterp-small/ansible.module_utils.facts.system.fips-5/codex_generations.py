

# Generated at 2022-06-25 00:02:58.567470
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    facts = {'fips': False}
    ansible_module_instance = AnsibleModule(argument_spec={})
    collected_facts = {'fips': True}

    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect(ansible_module_instance, collected_facts)
    assert collected_facts == facts

# Generated at 2022-06-25 00:03:03.938913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # create a FipsFactCollector
    fips_fact_collector = FipsFactCollector()

    # test against empty parameter
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] is False
    assert not fips_facts['fips']

# Generated at 2022-06-25 00:03:07.379430
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    assert (fips_fact_collector.collect(None, collected_facts) == {'fips': False})

# Generated at 2022-06-25 00:03:09.686302
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert not fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:03:11.191894
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:03:16.679633
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_dict = fips_fact_collector.collect()
    assert type(fips_dict) is dict
    assert 'fips' in fips_dict
    assert type(fips_dict['fips']) is bool
    assert fips_dict['fips'] == False

# Generated at 2022-06-25 00:03:22.625609
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # The following lines create the fips file
    with open('/proc/sys/crypto/fips_enabled', 'w') as f:
        f.write('1')
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    fips_value = collected_facts['fips']
    assert fips_value == True
    try:
        os.remove('/proc/sys/crypto/fips_enabled')
    except OSError:
        pass

# Generated at 2022-06-25 00:03:25.973937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:28.296523
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fip_facts = fips_fact_collector.collect()
    assert 'fips' in fip_facts

# Generated at 2022-06-25 00:03:30.571674
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:03:36.924259
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:39.704977
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize fips_fact_collector_0
    fips_fact_collector_0 = FipsFactCollector()
    # Execute fips_fact_collector_0.collect
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:45.606101
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Unit test for method collect of class FipsFactCollector
    """
    try:
        fips_fact_collector_1 = FipsFactCollector()
        fips_fact_collector_1.collect()
    except Exception as exp:
        assert False, "Check with valid inputs"
    fips_fact_collector_2 = FipsFactCollector()
    fips_fact_collector_2.collect(module=1, collected_facts="fips")
    fips_fact_collector_3 = FipsFactCollector()
    fips_fact_collector_3.collect(module="fips")
    fips_fact_collector_4 = FipsFactCollector()
    fips_fact_collector_4.collect()

# Generated at 2022-06-25 00:03:46.782286
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    testcase = FipsFactCollector()
    result = testcase.collect()
    assert result['fips'] is False

# Generated at 2022-06-25 00:03:48.577425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:03:57.701255
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect_0 = FipsFactCollector()
    fips_fact_collector_collect_0._file_exists = {'/proc/sys/crypto/fips_enabled': True}
    fips_fact_collector_collect_0._read_file = {'/proc/sys/crypto/fips_enabled': '1'}
    fips_fact_collector_collect_0._file_contents = {'/proc/sys/crypto/fips_enabled': '1'}
    fips_fact_collector_collect_0.collect()

# Generated at 2022-06-25 00:04:01.505176
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    return fips_facts

# Generated at 2022-06-25 00:04:06.854631
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    assert fips_facts_0['fips'] is False

# Generated at 2022-06-25 00:04:12.301170
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts = dict()
    expected_facts = {'fips': False}
    fips_facts = fips_fact_collector_1.collect(collected_facts=collected_facts)
    assert fips_facts == expected_facts

# Generated at 2022-06-25 00:04:14.316900
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:24.008788
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    data_0 = fips_fact_collector_1.collect()
    assert data_0['fips'] == False

# Generated at 2022-06-25 00:04:28.250669
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    set_module_args({
                    })
    result = FipsFactCollector.collect(FipsFactCollector, collected_facts={})
    assert result.get('fips') is False

# Generated at 2022-06-25 00:04:30.462504
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact = fips_fact_collector_1.collect()
    assert fips_fact == {'fips': False}


# Generated at 2022-06-25 00:04:33.659361
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect = FipsFactCollector()
    assert fips_fact_collector_collect.collect() == {"fips": False}


# Generated at 2022-06-25 00:04:41.289852
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled', 'w') as file:
        file.write('0\n')
    result = fips_fact_collector_1.collect()
    assert result == {'fips': False}
    with open('/proc/sys/crypto/fips_enabled', 'w') as file:
        file.write('1\n')
    result = fips_fact_collector_1.collect()
    assert result == {'fips': True}

# Generated at 2022-06-25 00:04:45.601224
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_collect_0.collect()
    assert fips_facts['fips'] is False

# Generated at 2022-06-25 00:04:51.078468
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect(module=None, collected_facts=None) is not False

# Generated at 2022-06-25 00:04:53.219619
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:00.705770
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    fips_facts = fips_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'fips' in fips_facts
    print('fips', fips_facts['fips'])
    if fips_facts['fips'] is True:
        assert fips_facts['fips'] == True
    elif fips_facts['fips'] is False:
        assert fips_facts['fips'] == False
    else:
        print('Testcase skipped because system is not in fips mode')
        assert True is not True

# Generated at 2022-06-25 00:05:03.043536
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    expected = {'fips': False}
    result = fips_fact_collector.collect()
    assert result == expected

# Generated at 2022-06-25 00:05:20.678052
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:29.154748
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    setattr(fips_fact_collector, '_module_cache', {'_ansible_sys_module_cache': {'/proc/sys/crypto/fips_enabled': '0'}})
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:05:32.424645
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = fips_fact_collector.collect()
    assert collected_facts['fips'] is False

# Generated at 2022-06-25 00:05:35.789151
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_0 = FipsFactCollector()
    fixture_0_result = {'fips': False}
    assert fixture_0.collect({}, {}) == fixture_0_result


# Generated at 2022-06-25 00:05:46.564285
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test for system in 'fips' mode
    fips_fact_collector_0 = FipsFactCollector()
    (fips, ansible_collector_fips) = fips_fact_collector_0.collect()
    assert fips['fips'] == True
    # Test for system not in 'fips' mode
    fips_fact_collector_1 = FipsFactCollector()
    (fips, ansible_collector_fips) = fips_fact_collector_1.collect()
    assert fips['fips'] == False
    # Test for missing file
    fips_fact_collector_2 = FipsFactCollector()
    (fips, ansible_collector_fips) = fips_fact_collector_2.collect()

# Generated at 2022-06-25 00:05:48.589677
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:50.863466
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()

    # Initialising the following facts:
    # fips = ''
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:52.687547
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:54.020193
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect_0 = FipsFactCollector()
    fips_fact_collector_collect_0.collect()

# Generated at 2022-06-25 00:05:58.036788
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:06:31.428660
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts_dict = fips_fact_collector.collect()
    assert fips_facts_dict['fips'] == False

# Generated at 2022-06-25 00:06:34.418941
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:41.931210
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """Unit test for method collect of class FipsFactCollector"""

    # Test data
    test_data_0 = [
        {'fips': False}
    ]

    # Create FipsFactCollector object
    fips_fact_collector_0 = FipsFactCollector()

    # Set collect method return value
    fips_fact_collector_0.collect = lambda: test_data_0

    # Call method
    result = fips_fact_collector_0.collect()

    # Assertions
    assert result == test_data_0



# Generated at 2022-06-25 00:06:45.521013
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:06:47.317885
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-25 00:06:54.573985
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec={})
    fips_fact_collector_0.collect(ansible_module_0)

# Compatibility with Python 2.6 because I can't test it
if not hasattr(__builtins__, 'unicode'):
    unicode = str
# Compatibility with Python 2
if not hasattr(__builtins__, 'long'):
    long = int
# Compatibility with Python 3
if not hasattr(__builtins__, 'basestring'):
    basestring = unicode = str
# Compatibility with Python 3
if not hasattr(__builtins__, 'xrange'):
    xrange = range


# Generated at 2022-06-25 00:07:04.512279
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    collected_facts['ansible_all_ipv4_addresses'] = ['192.168.0.10', '192.168.0.1']
    collected_facts['ansible_default_ipv4'] = {'address': '192.168.0.10', 'alias': 'eth0', 'broadcast': '192.168.0.255', 'gateway': '192.168.0.1', 'interface': 'eth0', 'macaddress': '66:55:44:33:22:11', 'mtu': 1500, 'netmask': '255.255.255.0', 'network': '192.168.0.0', 'type': 'ether'}

# Generated at 2022-06-25 00:07:05.975701
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert isinstance(fips_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:07:09.353426
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert 'fips' in result
    assert result['fips'] == False

# Generated at 2022-06-25 00:07:11.436422
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0_result = fips_fact_collector_0.collect()
    # check result
    assert fips_fact_collector_0_result == {'fips': False}


# Generated at 2022-06-25 00:08:23.414484
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # test case for collect on a system that is not fips enabled
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.read_cache = lambda: '{"fips": false}'
    fips_facts = fips_fact_collector_0.collect()
    assert fips_facts['fips'] is False



# Generated at 2022-06-25 00:08:29.040002
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    fact_ids = set()
    fact_ids.add('fips')
    facts_result = {}
    facts_result['fips'] = False
    result = fips_fact_collector_0.collect(None, facts_result)
    assert result == facts_result

# Generated at 2022-06-25 00:08:29.952755
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Empty stub for collect method of FipsFactCollector class
    assert True

# Generated at 2022-06-25 00:08:32.428576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0 is not None

# Generated at 2022-06-25 00:08:35.461121
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert(fips_fact_collector_1.collect() == {'fips': False})


# Generated at 2022-06-25 00:08:39.416837
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_result_0 = fips_fact_collector_0.collect()
    assert isinstance(fips_result_0, dict)

# Generated at 2022-06-25 00:08:41.773414
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Run test case 1
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert 'fips' in fips_facts


# Generated at 2022-06-25 00:08:43.325564
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:47.331033
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case #1
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts_1 = {}
    collected_facts_1['ansible_module_mock'] = {}
    collected_facts_1['ansible_module_mock']['_text'] = '1'
    result_1 = fips_fact_collector_1.collect(collected_facts=collected_facts_1)
    assert (result_1 == {'fips': True})

# Generated at 2022-06-25 00:08:50.679138
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:10:15.454247
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect()


# Generated at 2022-06-25 00:10:16.903417
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector_instance_0 = FipsFactCollector()
    FipsFactCollector_instance_0.collect()

# Generated at 2022-06-25 00:10:18.671150
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': False, }

# Generated at 2022-06-25 00:10:21.735968
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:10:22.326588
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert fips_facts['fips'] is False

# Generated at 2022-06-25 00:10:28.396046
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Store value of attribute fips_fact_collector.name before test
    old_FipsFactCollector_name = FipsFactCollector.name
    if old_FipsFactCollector_name is not None:

        # Store value of attribute fips_fact_collector._fact_ids before test
        old_FipsFactCollector__fact_ids = FipsFactCollector._fact_ids
        if old_FipsFactCollector__fact_ids is not None:

            # Store value of attribute fips_fact_collector.fips_fact_ids before test
            old_fips_fact_collector_fips_fact_ids = FipsFactCollector._fact_ids

            # Construct dict to use as input parameters to method collect of fips_fact_collector
            collected_facts_value_0 = dict()

           

# Generated at 2022-06-25 00:10:30.075034
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:10:35.149563
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-25 00:10:37.148962
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0.get('fips') is False

# Generated at 2022-06-25 00:10:40.199105
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert 'fips' in var_0.keys(), 'var_0.keys() did not contain element "fips"'