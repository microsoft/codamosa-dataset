

# Generated at 2022-06-25 00:02:55.674845
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # fips: False
    fips_fact_collector_1 = FipsFactCollector()
    actual_result = fips_fact_collector_1.collect()

    expected_result = {'fips': False}
    assert actual_result == expected_result


# Generated at 2022-06-25 00:02:56.978876
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}


# Generated at 2022-06-25 00:02:59.479793
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts = {'uname.release': '3.10.0-693'}
    ansible_facts = fips_fact_collector_1.collect(collected_facts)
    assert ansible_facts['fips'] == False

# Generated at 2022-06-25 00:03:00.812211
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert result['fips'] == False


# Generated at 2022-06-25 00:03:04.722155
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    res_collect = fips_fact_collector_1.collect()
    assert res_collect['fips'] == False


# Generated at 2022-06-25 00:03:07.264592
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:12.969434
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0_instance = FipsFactCollector()
    fips_fact_collector_0_collect = fips_fact_collector_0_instance.collect()
    assert fips_fact_collector_0_collect == {'fips': True}

# Generated at 2022-06-25 00:03:16.110789
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Errors if data is not a list/dictionary
    data = {}
    fips_fact_collector = FipsFactCollector()
    if not isinstance(fips_fact_collector.collect(data), dict):
        raise AssertionError()


# Generated at 2022-06-25 00:03:18.842985
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect(module=None, collected_facts=None)
    assert fips_facts['fips'] == True

# Generated at 2022-06-25 00:03:23.845658
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = {'fips': False}

    def mock_get_file_content(file_path):
        return '1'

    FipsFactCollector.get_file_content = mock_get_file_content
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect(None, collected_facts)
    assert fips_facts == {'fips': True}

# Generated at 2022-06-25 00:03:32.035194
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Testing with fips enabled

    # collect method will read the status of fips from /proc/sys/crypto/fips_enabled
    # and will return the fips_facts dictionary.
    # The fips_facts dictionary will have key "fips" with value True if fips is enabled
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-25 00:03:37.067594
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert 'fips' in fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:40.970161
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: zFS is a special case and prevents running the test on zFS
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert fips_facts_1 != None
    assert str(fips_facts_1) != "", "FipsFactCollector collect() method returned an empty string"

# Generated at 2022-06-25 00:03:43.676656
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts = FipsFactCollector().collect()
    assert isinstance(fips_facts, dict)
    assert 'fips' in fips_facts
    assert isinstance(fips_facts['fips'], bool)

# Generated at 2022-06-25 00:03:51.207275
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    '''
    Unit test for method collect of class FipsFactCollector
    '''
    fips_facts = {}
    fips_facts['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts['fips'] = True
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result == fips_facts

# Generated at 2022-06-25 00:03:52.906646
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fact_collector = FipsFactCollector()

    facts = dict()
    ansible_module_0 = Mock(params=dict(), exit_json=facts)
    fact_collector.collect(ansible_module_0, facts)
    assert 'fips' in facts
    assert facts['fips'] == False

# Generated at 2022-06-25 00:03:56.849680
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_instance = FipsFactCollector()
    # Get the value of sysctl fips_enabled
    with open('../../../../system/proc_sys_crypto_fips_enabled', 'r') as f:
        flag = f.read()
    fips_facts = fips_fact_collector_instance.collect()

    # Test case for fips_facts is empty
    assert fips_facts == {}

    # Test case for flag is False
    if flag == '0':
        assert fips_facts['fips'] == False

    # Test case for flag is True
    if flag == '1':
        assert fips_facts['fips'] == True


# Generated at 2022-06-25 00:04:03.691699
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test 1 mock /proc/sys/crypto/fips_enabled
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1._read_file_from_disk = lambda path: '1'
    assert fips_fact_collector_1.collect()['fips'] == True

    # Test 2 mock /proc/sys/crypto/fips_enabled
    fips_fact_collector_2 = FipsFactCollector()
    fips_fact_collector_2._read_file_from_disk = lambda path: '0'
    assert fips_fact_collector_2.collect()['fips'] == False

    # Test 3 mock /proc/sys/crypto/fips_enabled
    fips_fact_collector_3 = FipsFactCollect

# Generated at 2022-06-25 00:04:08.753036
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_facts = {}
    fips_facts = {'fips': False}
    fips_fact_collector = FipsFactCollector()
    fips_facts_0 = fips_fact_collector.collect(collected_facts=test_facts)
    assert(fips_facts == fips_facts_0)


#Unit test for method collect of class FipsFactCollector

# Generated at 2022-06-25 00:04:11.969856
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert isinstance(fips_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:04:19.184140
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        f.write("1\n")
        f.flush()
        fips_fact_collector_1 = FipsFactCollector()
        fips_facts = fips_fact_collector_1.collect()
    assert fips_facts ==  {u'fips': True}


# Generated at 2022-06-25 00:04:21.993435
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:23.880552
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:33.479821
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    test_cases = [
        ('/tmp/test_fips_fact_collector_EgAKoZ', '1', True),
        ('/tmp/test_fips_fact_collector_EgAKoZ', '0', False)
    ]
    for test_case in test_cases:
        with open(test_case[0], 'w') as f:
            f.write(test_case[1])
        fips_facts = fips_fact_collector.collect()
        assert fips_facts['fips'] == test_case[2]
        f.close()

# Generated at 2022-06-25 00:04:35.027503
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()


# Generated at 2022-06-25 00:04:41.533316
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts = {}
    assert fips_fact_collector_1.collect(collected_facts=collected_facts) == {'fips': False}

    fips_fact_collector_2 = FipsFactCollector()
    collected_facts = {}
    assert fips_fact_collector_2.collect(collected_facts=collected_facts) == {'fips': False}

    fips_fact_collector_3 = FipsFactCollector()
    collected_facts = {}
    assert fips_fact_collector_3.collect(collected_facts=collected_facts) == {'fips': False}


# Generated at 2022-06-25 00:04:45.900496
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect(None, None)
    val = fips_facts['fips']
    assert isinstance(val, bool)

# Generated at 2022-06-25 00:04:53.053933
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fact_collector = FipsFactCollector()

    # happy path
    data = fact_collector.collect()
    assert data == {'fips': False}

    # ensure the collector always returns a dictionary
    data = fact_collector.collect(collected_facts=dict())
    assert data == {'fips': False}

# Generated at 2022-06-25 00:05:03.092421
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    print('Testing FipsFactCollector.collect')

    # Content of file /proc/sys/crypto/fips_enabled
    fips_code_0 = '0'
    fips_code_1 = '1'

    # Get content of file /proc/sys/crypto/fips_enabled
    fips_data_0 = get_file_content('/proc/sys/crypto/fips_enabled')
    if fips_data_0 == fips_code_0:
        fips_fact_collector_1 = FipsFactCollector()
        assert fips_fact_collector_1.collect() == {'fips': False}
    elif fips_data_0 == fips_code_1:
        fips_fact_collector_2 = FipsFactCollector()
        assert f

# Generated at 2022-06-25 00:05:06.531044
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts0 = fips_fact_collector_0.collect()
    assert 'fips' in fips_facts0

if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:05:16.799553
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector is not None
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:05:22.038835
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data = '1'
    get_file_content_0 = FipsFactCollector.get_file_content
    FipsFactCollector.get_file_content = staticmethod(lambda: data)
    collected_facts = fips_fact_collector_0.collect()
    assert collected_facts == {'fips': True}
    FipsFactCollector.get_file_content = get_file_content_0


# Generated at 2022-06-25 00:05:25.278379
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:05:26.484037
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:05:31.093554
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    res = fips_fact_collector.collect()
    assert res['fips'] == False



# Generated at 2022-06-25 00:05:35.753437
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_fips_collector = FipsFactCollector()
    test_fips_collector._read_file = lambda *args: '1'
    collected_facts = test_fips_collector.collect()
    assert collected_facts['fips']


# Generated at 2022-06-25 00:05:39.616008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': True}

# Generated at 2022-06-25 00:05:42.432499
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    collected_facts = dict()
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect(None, collected_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:05:50.677240
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    mock_module_0 = type('', (), {})()
    mock_module_0.params = type('', (), {})()
    mock_module_0.params.get = type('', (), {})()
    mock_module_0.params.get.return_value = None
    mock_module_0.fail_json = type('', (), {})()
    mock_module_0.fail_json.side_effect = get_exception(3)
    mock_get_file_content_0 = type('', (), {})()
    mock_get_file_content_0.return_value = '0'
    mock_file_0 = type('', (), {})()
    mock_file_0.read = type('', (), {})()
    mock_file_0.read.return_value = '0'

# Generated at 2022-06-25 00:05:53.789111
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected_result_collect_1 = {}
    expected_result_collect_1['fips'] = False
    fips_fact_collector_1 = FipsFactCollector()
    result_collect_1 = fips_fact_collector_1.collect()
    assert result_collect_1 == expected_result_collect_1


# Generated at 2022-06-25 00:06:16.817283
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """ Test collect method of class FipsFactCollector. """

    file_1_content = "1"
    file_2_content = "0"
    file_3_content = ""

    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.get_file_content = get_file_content

    # Test output without given argument.
    def test_run():
        fips_facts_0 = fips_fact_collector_0.collect()
        if not (fips_facts_0['fips']):
            raise AssertionError()
    if __name__ == '__main__':
        test_run()

    # Test output with given argument not given.
    def test_run():
        fips_facts_0 = fips_fact_collector

# Generated at 2022-06-25 00:06:18.293842
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:06:19.985256
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:24.169089
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass


# Generated at 2022-06-25 00:06:27.872185
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:06:30.788367
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_facts = {}
    fips = fips_fact_collector.collect(None, collected_facts)
    assert(fips['fips'] == False)

# Generated at 2022-06-25 00:06:35.670997
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Imports
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Initializing objects
    fips_fact_collector_1 = FipsFactCollector()

    # Check instance is subclass of BaseFactCollector
    assert isinstance(fips_fact_collector_1, BaseFactCollector)

# Generated at 2022-06-25 00:06:40.686433
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    with open("/proc/sys/crypto/fips_enabled") as f:
        f.write("1")
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': True}

# Generated at 2022-06-25 00:06:51.056157
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # fips: False
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.module = {'module_constants': {'no_log': "no_log"} }
    fips_fact_collector.module['module_constants']['cache'] = {'fips': "fips_0" }
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == 'False'

    # fips: False
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.module = {'module_constants': {'no_log': "no_log"} }

# Generated at 2022-06-25 00:06:53.830686
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': True}

# Generated at 2022-06-25 00:07:10.644398
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    assert var_1['fips'] == False


# Generated at 2022-06-25 00:07:15.850915
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:18.457757
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: the tests in this file are not comprehensive, they are only supposed to spot errors in the module
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-25 00:07:22.333008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
   pass

# Generated at 2022-06-25 00:07:26.629334
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:07:31.088526
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = fips_fact_collector_0.name
    var_2 = fips_fact_collector_0._fact_ids
    # NOTE: not sure how to verify the _fact_ids properly
    assert var_1 == 'fips'

# Generated at 2022-06-25 00:07:33.689029
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = {'fips': False}
    var_2 = None
    var_3 = FipsFactCollector()
    var_0 = var_3.collect(var_1, var_2)
    assert var_0 is None

# vim: set filetype=python :

# Generated at 2022-06-25 00:07:35.577245
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_0 = FipsFactCollector()
    var_1 = test_0.collect()
    assert var_1['fips'] == False
    test_1 = FipsFactCollector()
    # NOTE: add test assertions here


# Generated at 2022-06-25 00:07:39.108811
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:07:41.846030
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # noinspection PyProtectedMember
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:08:19.134274
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 is None


# Generated at 2022-06-25 00:08:23.169396
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:24.000824
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: no tests written, no methods defined in the class aside from __init__
    pass

# Generated at 2022-06-25 00:08:28.413937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    res = fips_fact_collector_0.collect()
    assert res['fips'] == False


# Generated at 2022-06-25 00:08:30.358902
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:32.647711
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert not FipsFactCollector().collect(module=object(), collected_facts=object())


# Generated at 2022-06-25 00:08:35.494803
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    assert fips_fact_collector_0.collect() == data

# Generated at 2022-06-25 00:08:39.836795
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    module_0 = None
    collected_facts_0 = None
    fips_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-25 00:08:45.930347
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Return data with fips in fips mode
    # Test expected return type
    fips_fact_collector = FipsFactCollector()
    mock_module = "module"
    mock_collected_facts = dict()
    mock_collected_facts['fips'] = False
    # Test with proper return value
    FipsFactCollector.collect(fips_fact_collector, mock_module,
        mock_collected_facts)
    fips_fact_collector.name
    fips_fact_collector._fact_ids
    # Test with return value of type bool
    # Test with return value of type int
    # Test with return value of type str
    # Test with return value of type list
    # Test with return value of type dict

# Generated at 2022-06-25 00:08:47.498597
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert not var_0['fips']

# Generated at 2022-06-25 00:10:09.611123
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FipsFactCollector
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert fips_fact_collector._fact_ids == {'fips'}
    assert isinstance(var, dict)
    assert var['fips'] == False

# Generated at 2022-06-25 00:10:15.687301
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:10:19.633906
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()

    # Unit test the fips is False when fips is not enabled
    var_1 = fips_fact_collector_0.collect()
    assert var_1 == {'fips': False}

    # Unit test the fips is True when fips is enabled
    fips_fact_collector_0.data = '1'
    var_2 = fips_fact_collector_0.collect()
    assert var_2 == {'fips': True}

# Generated at 2022-06-25 00:10:21.264082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True == 1

# Generated at 2022-06-25 00:10:22.656518
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:10:24.449165
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:34.025478
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    from collections import defaultdict
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector.fips import FipsFactCollector
    from ansible.module_utils._text import to_bytes

    import sys
    import os


# Generated at 2022-06-25 00:10:35.784525
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:36.246399
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:10:37.645475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_0.collect(module=None, collected_facts=None)

