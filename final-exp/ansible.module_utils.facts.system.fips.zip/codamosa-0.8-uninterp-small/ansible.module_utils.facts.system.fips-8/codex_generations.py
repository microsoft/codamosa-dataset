

# Generated at 2022-06-25 00:02:57.776160
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    assert fips_fact_collector.collect() == fips_facts

# Generated at 2022-06-25 00:03:02.743506
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:06.228047
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips']


# Generated at 2022-06-25 00:03:16.766365
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # See if we have a /proc/sys/crypto/fips_enabled file
    # Assume we are in fips mode
    # Update the FipsFactCollector object with the data from the file
    # Return the data from the FipsFactCollector object
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1_0 = {}
    fips_facts_1_0['fips'] = False
    fips_fact_collector_1.collect(collected_facts=fips_facts_1_0)
    # TODO: Determine the right value
    assert fips_facts_1_0 == {}


# Generated at 2022-06-25 00:03:18.749566
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:20.622998
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    assert fips_fact_collector.collect()['fips'] == False

# Generated at 2022-06-25 00:03:23.087197
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    expected_data = {
        "fips": False
    }
    fips_fact_collector = FipsFactCollector()
    data = fips_fact_collector.collect()
    assert data == expected_data

# Generated at 2022-06-25 00:03:26.876475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect = FipsFactCollector()
    assert fips_fact_collector_collect.collect() == {'fips': False}, 'Failed to collect fips facts'

# Generated at 2022-06-25 00:03:28.957109
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:31.651024
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    # Verify that returned facts are correct
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:35.159762
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:03:37.045236
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Case 1:
    fips_fact_collector = FipsFactCollector()
    print('Collecting Fact')
    fips_facts = fips_fact_collector.collect()
    print('Result: fips : %s' % fips_facts['fips'])


# Generated at 2022-06-25 00:03:42.649425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()

    # Assert that get_file_content('/proc/sys/crypto/fips_enabled') returns '1'
    saved_get_file_content = FipsFactCollector.get_file_content
    FipsFactCollector.get_file_content = lambda self: '1'
    assert fips_fact_collector.collect() == {
        'fips': True
    }
    # Assert that get_file_content('/proc/sys/crypto/fips_enabled') returns '0'
    FipsFactCollector.get_file_content = lambda self: '0'
    assert fips_fact_collector.collect() == {
        'fips': False
    }
    # Assert that get_file_content('/proc/

# Generated at 2022-06-25 00:03:48.837488
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()

    assert type(fips_facts) is dict
    assert type(fips_facts['fips']) is bool

# Generated at 2022-06-25 00:03:59.045980
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test that the return value is a dictionary when 'fips' is
    # enabled and a value
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect(collected_facts={})
    assert isinstance(fips_facts_1, dict)
    assert fips_facts_1 == {'fips': True}

    # Test that when 'fips' is not enabled, then the fips fact
    # is set to False
    fips_fact_collector_2 = FipsFactCollector()
    fips_facts_2 = fips_fact_collector_2.collect(collected_facts={})
    assert fips_facts_2 == {'fips': False}

# Generated at 2022-06-25 00:04:01.643681
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect = FipsFactCollector()
    # Test with data
    fips_fact_collector_collect.data = dict(fips=True)
    fips_fact_collector_collect.data = dict(fips=False)

# Generated at 2022-06-25 00:04:10.195754
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Initialize a module with argument_spec set to dict()
    module = AnsibleModule(argument_spec=dict())
    # Initialize a FipsFactCollector object
    fips_fact_collector_0 = FipsFactCollector()
    # Call method collect of FipsFactCollector object
    collected_facts = fips_fact_collector_0.collect(module=module, collected_facts=dict())
    # Assert that the return value of method collect is a dict
    assert isinstance(collected_facts, dict)

from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 00:04:14.795270
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert type(result) is dict
    result = fips_fact_collector_0.collect()
    assert type(result) is dict
    result = fips_fact_collector_0.collect()
    assert type(result) is dict

# Generated at 2022-06-25 00:04:16.550448
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:23.259141
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is populated even if it is not set
    fips_facts_0 = {}
    fips_facts_0['fips'] = False
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts_0['fips'] = True

    assert fips_facts_0 == fips_fact_collector_0.collect()


# unit test for method process of class FipsFactCollector

# Generated at 2022-06-25 00:04:29.900947
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert type(result) is dict
    assert result.get('fips', "fips key not found")
    assert result.get('fips', "fips key not found") == 0


# Generated at 2022-06-25 00:04:36.847014
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: this is not a unit test of anything
    #       this is a test of whether it runs without error
    #
    #       for us to get here, we know the code runs without error
    #       given an empty file /proc/sys/crypto/fips_enabled

    try:
        test_case_0()
        # If this prints, it will show test_case_0 ran without error
        print('test_case_0 ran without error')
    except Exception as e:
        print('test_case_0 failed with exception:')
        print(e)

# Generated at 2022-06-25 00:04:41.797610
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create an instance of class FipsFactCollector
    fips_fact_collector_0 = FipsFactCollector()

    # Try to invoke the method with and without specifying the module parameter
    try:
        fips_fact_collector_0.collect()
    except Exception as e:
        print(str(e))
    else:
        assert True
    try:
        fips_fact_collector_0.collect(module=None)
    except Exception as e:
        print(str(e))
    else:
        assert True


# Generated at 2022-06-25 00:04:49.814533
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    """
    Test collect of FipsFactCollector
    """
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

    fips_fact_collector_1 = FipsFactCollector()
    mock_module_1 = "mock_module_0"
    mock_collected_facts_1 = "mock_collected_facts_0"
    var_1 = fips_fact_collector_1.collect(mock_module_1, mock_collected_facts_1)
    assert var_1 == {'fips': False}

# Generated at 2022-06-25 00:04:51.230702
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:53.349583
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:55.793794
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0.get('fips') == False

# Generated at 2022-06-25 00:04:59.978841
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:05:07.207421
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data_0 = '1'
    mock_get_file_content_0 = MagicMock(return_value=data_0)
    patch_get_file_content_0 = patch('ansible.module_utils.facts.collector.FipsFactCollector.get_file_content', new=mock_get_file_content_0)

    with patch_get_file_content_0 as mock_get_file_content_1:
        fips_fact_collector_0 = FipsFactCollector()
        var_0 = fips_fact_collector_0.collect()
        mock_get_file_content_1.assert_called_once_with('/proc/sys/crypto/fips_enabled')


# Generated at 2022-06-25 00:05:17.555125
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_mock = [{'fips': False}]
    get_file_content_mock = lambda a: '0'
    from ansible.module_utils.facts.collector import get_file_content
    get_file_content_original = get_file_content
    setattr(ansible.module_utils.facts.collector, 'get_file_content', get_file_content_mock )
    fips_fact_result = fips_fact_collector.collect()
    setattr(ansible.module_utils.facts.collector, 'get_file_content', get_file_content_original )
    assert fips_fact_result == fips_fact_mock

# Generated at 2022-06-25 00:05:25.743458
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0["fips"]

# Generated at 2022-06-25 00:05:29.937463
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    a_0 = FipsFactCollector()
    var_0 = get_file_content('/proc/sys/crypto/fips_enabled')
    var_1 = False
    if var_0:
        var_1 = True
    var_2 = {'fips': var_1}
    var_3 = a_0.collect()
    assert var_2 == var_3

# Generated at 2022-06-25 00:05:35.124681
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Arrange
    fips_fact_collector_0 = FipsFactCollector()

    # Act
    var_0 = fips_fact_collector_0.collect()

    # Assert
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:05:40.288286
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert isinstance(fips_fact_collector_0.collect(), dict)
    assert len(fips_fact_collector_0.collect()) == 1

# Generated at 2022-06-25 00:05:49.176563
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Setup mocks
    class MockModule():
        def ipaddr(self, param_0, param_1):
            return [1, 2, 3]

    class MockCollectedFacts():
        def __init__(self):
            self.data = {'ansible_collector_0': 1}

    # Instantiate the class being tested
    fips_fact_collector = FipsFactCollector()

    # Assert instantiation
    assert isinstance(fips_fact_collector, FipsFactCollector)

    # Call collect to assert return value
    assert fips_fact_collector.collect(module=MockModule(), collected_facts=MockCollectedFacts()) == {'ansible_collector_0': 1, 'ansible_fips': False}

# Generated at 2022-06-25 00:05:50.711334
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var is not None

# Generated at 2022-06-25 00:05:56.461365
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    dict_0 = dict()
    str_0 = "proc/sys/crypto/fips_enabled"
    dict_0["fs_realpath/path"] = str_0
    list_0 = [str_0]
    dict_0["ansible_facts"] = list_0
    dict_0["failed"] = False
    var_0 = fips_fact_collector_0.collect(collected_facts=dict_0)
    assert var_0['ansible_facts'] is not None
    assert var_0['failed'] is False
    assert var_0['ansible_facts']['fips'] is True

# Generated at 2022-06-25 00:05:59.353602
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = FipsFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:06:02.583949
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    ansible_collector.collectors['ansible.module_utils.facts.system.fips'] = FipsFactCollector()

    fips_fact_collector_0 = ansible_collector.get_collector('ansible.module_utils.facts.system.fips')

    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:06.296999
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False

# Generated at 2022-06-25 00:06:24.938625
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:06:28.813780
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with default values for args
    fips_fact_collector = FipsFactCollector()
    ret = fips_fact_collector.collect()
    assert(type(ret) == dict)


# Generated at 2022-06-25 00:06:36.351937
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Test case 2
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert var_2['fips'] == True
    assert len(fips_fact_collector_2._fact_ids) == 1

    # Test case 3
    fips_fact_collector_3 = FipsFactCollector()
    var_3 = fips_fact_collector_3.collect()
    assert var_3['fips'] == False
    assert len(fips_fact_collector_3._fact_ids) == 1

    # Test case 4
    fips_fact_collector_4 = FipsFactCollector()
    var_4 = fips_fact_collector_4.collect()

# Generated at 2022-06-25 00:06:39.908213
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    x = FipsFactCollector()
    assert repr(x.collect()) == "{'fips': False}"

# Generated at 2022-06-25 00:06:41.255530
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] is not False

# Generated at 2022-06-25 00:06:50.079561
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    detected_fips = ('rh6' in PLATFORM_RELEASE or 'rh7' in PLATFORM_RELEASE)

    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 is not None, "FipsFactCollector.collect: testing for non empty"
    assert isinstance(var_1, dict), "FipsFactCollector.collect: testing for correct return type"
    assert var_1['fips'] == detected_fips, "FipsFactCollector.collect: testing for correct fips fact"


# Generated at 2022-06-25 00:06:51.585380
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = FipsFactCollector()
    var_2 = {}
    var_3 = var_1.collect()
    assert var_3['fips'] == False

# Generated at 2022-06-25 00:06:55.108840
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert isinstance(var, dict)
    assert 'fips' in var
    assert var['fips'] in [True, False]


# Generated at 2022-06-25 00:06:58.206122
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    try:
        test_case_0()
        test_case_0()
    except:
        #do nothing
        print('exception')

# Generated at 2022-06-25 00:07:01.958449
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect(module=None, collected_facts=None)
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:07:33.083321
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:37.971627
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert var_1['fips'] == False

    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert isinstance(var_2, dict)
    assert var_2['fips'] == False

    fips_fact_collector_3 = FipsFactCollector()
    var_3 = fips_fact_collector_3.collect()
    assert isinstance(var_3, dict)
    assert var_3['fips'] == False

    fips_fact_collector_4 = FipsFactCollector()
   

# Generated at 2022-06-25 00:07:38.920326
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:41.177270
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:42.814578
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var == dict()

# Generated at 2022-06-25 00:07:45.145959
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    var_2 = ('fips', 2, False)
    assert var_1 == {var_2}, var_1



# Generated at 2022-06-25 00:07:55.328919
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # From Ansible
    module0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    fips_fact_collector0 = FipsFactCollector()
    assert fips_fact_collector0.collect() == module0.exit_json(changed=False, ansible_facts={u'fips': False})
    # From Ansible
    module1 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    fips_fact_collector1 = FipsFactCollector()
    assert fips_fact_collector1.collect() == module1.exit_json(changed=False, ansible_facts={u'fips': False})
    # From Ansible

# Generated at 2022-06-25 00:07:58.430412
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:08:03.730242
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Set up test facts
    facts = dict()

    # Call method
    fact_collector = FipsFactCollector()
    fact_collector.collect(collected_facts=facts)

    # Assert expected results
    assert fact_collector.name == 'fips'
    assert fact_collector._fact_ids == set(['fips'])

# Generated at 2022-06-25 00:08:04.896195
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:09:10.990935
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    
    # Return value
    assert isinstance(fips_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:09:13.406995
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    fips_fact_collector = FipsFactCollector()
    vars = fips_fact_collector.collect()
    assert vars['ansible_local']['fips'] == bool(data)

# Generated at 2022-06-25 00:09:16.756499
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:09:24.565832
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # From /etc/system-release-cpe
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    assert var_1 == {'fips': True}
    print('var_1: ' + str(var_1))

    # From /etc/system-release-cpe
    fips_fact_collector_1 = FipsFactCollector()
    var_2 = fips_fact_collector_1.collect()
    assert var_2 == {'fips': True}
    print('var_2: ' + str(var_2))

    # From /etc/system-release-cpe
    fips_fact_collector_2 = FipsFactCollector()
    var_3 = fips_fact_

# Generated at 2022-06-25 00:09:33.909600
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_0 = FakeModule(
        dict(
            ansible_module_args=dict(
                gather_subset="network"
            )
        )
    )
    fips_fact_collector_0 = FipsFactCollector()

# Generated at 2022-06-25 00:09:37.550061
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Instantiating a FipsFactCollector object
    fips_fact_collector_0 = FipsFactCollector()

    # Calling the collect method of the object
    var_0 = fips_fact_collector_0.collect()

    # Testing the boolean value of isinstance of the variable returned
    # by the collect method
    if isinstance(var_0, dict) != True:
        raise Exception("Failed - Exception was not raised")


# Generated at 2022-06-25 00:09:39.920977
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fixture_0 = None
    fixture_1 = None
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect(fixture_0, fixture_1) == {'fips': False}


# Generated at 2022-06-25 00:09:41.447268
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()



# Generated at 2022-06-25 00:09:43.136777
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:09:47.885677
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup
    fips_fact_collector = FipsFactCollector()
    # Setup
    fips_fact_collector.name = 'fips'
    # Setup
    fips_fact_collector._fact_ids = set()
    # @call
    # @call
    # @call setup
    if get_file_content('/proc/sys/crypto/fips_enabled') != '1':
        print('data is empty')
    else:
        pass


# Generated at 2022-06-25 00:12:04.416268
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:12:06.762999
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:12:14.088730
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = {'fips' : False}
    var_0 = fips_fact_collector_0.collect(collected_facts=fips_facts_0)
    assert var_0 == fips_facts_0


# Generated at 2022-06-25 00:12:14.771220
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Unit test for case 0
    test_case_0()

# Generated at 2022-06-25 00:12:23.559706
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert type(var_0) == dict
    assert 'fips' in var_0["fips"]
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert type(var_1) == dict
    assert var_1["fips"]
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert type(var_2) == dict
    assert var_2["fips"]
    fips_fact_collector_3 = FipsFactCollecto

# Generated at 2022-06-25 00:12:26.542723
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:12:28.471715
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    if var_0:
        assert True
    else:
        assert False

# Generated at 2022-06-25 00:12:32.001082
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False


# Generated at 2022-06-25 00:12:35.330711
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    if fips_fact_collector_0.collect(collected_facts=collected_facts):
        var_0 = collected_facts['ansible_fips']
        assert var_0, "Failed to collect fips facts"

# Generated at 2022-06-25 00:12:39.504076
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
