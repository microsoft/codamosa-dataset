

# Generated at 2022-06-25 00:02:59.644161
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector_result = fips_fact_collector.collect()
    assert isinstance(fips_fact_collector_result, dict)
    if list(fips_fact_collector_result.keys()) != ['fips']:
        raise AssertionError('Invalid content found in result: {0}'.format(', '.join(fips_fact_collector_result.keys())))

# Generated at 2022-06-25 00:03:01.126779
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    facts1 = fips_fact_collector_1.collect()
#    assert facts1 == {'fips': True} or {'fips': False}

# Generated at 2022-06-25 00:03:02.091577
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:03:02.995543
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:03:06.884716
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert type(fips_facts) == dict
    assert 'fips' in fips_facts


# Generated at 2022-06-25 00:03:10.656269
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect().get('fips') is False


# Generated at 2022-06-25 00:03:13.818502
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:17.511476
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() == {'fips': False}
    assert fips_fact_collector_1.collect() == {'fips': False}
    assert fips_fact_collector_1.collect() == {'fips': False}

# Generated at 2022-06-25 00:03:22.855285
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = {}
    fips_facts['fips'] = False
    fips_facts = fips_fact_collector.collect(module=None, collected_facts=fips_facts)
    assert fips_facts['fips'] == False

# Generated at 2022-06-25 00:03:29.172647
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Passing in TestCase instance as second arg
    # to avoid throwing unittest.case.skipException
    # when running unittest on test_FipsFactCollector_collect.
    # with testtools.TestCase() as testcase_instance:

    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect(collected_facts=None) == {'fips': False}

# Generated at 2022-06-25 00:03:33.614420
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert type(var) is dict
    assert var['fips'] is False

# Generated at 2022-06-25 00:03:40.733539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_0 = AnsibleModule(argument_spec={})
    module_0.exit_json = MagicMock(return_value=None)
    fips_fact_collector_0 = FipsFactCollector()
    set_module_args(module_0, custom_args={'test': 'test'})

    with pytest.raises(AnsibleExitJson) as ex:
        fips_fact_collector_0.collect()

    print('Info: test_FipsFactCollector_collect(): %s' % repr(ex.value.args[0]))

# Generated at 2022-06-25 00:03:42.630508
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:50.574953
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    var_2 = fips_fact_collector_0.collect()
    expected_1 = {'fips': False}
    expected_2 = {'fips': False}
    assert var_1 == expected_1
    assert var_2 == expected_2


# Generated at 2022-06-25 00:03:53.251995
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert fips_fact_collector_0.fact_ids == {'fips'}
    assert fips_fact_collector_0.name == 'fips'
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:03:56.430707
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    module_arg_spec = {}
    # no result is returned, but an exception happens if the module code throws an error
    fips_fact_collector_0.collect(module_arg_spec)


# Generated at 2022-06-25 00:04:00.093989
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:04:02.355749
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert(var_0 == {'fips': False})

# Generated at 2022-06-25 00:04:05.011394
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()



# Generated at 2022-06-25 00:04:08.190933
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': True}

# Generated at 2022-06-25 00:04:11.469967
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:04:13.706045
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:15.411747
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:18.858001
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:04:20.699622
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:26.237940
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    
    # Test case where FIPS is not enabled

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == False

    # Test case where FIPS mode is enabled

    fips_fact_collector = FipsFactCollector()
    open("fips_fact_collector_test_case_1.txt", "w").write("1")
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-25 00:04:27.996147
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert isinstance(var, dict)

# Generated at 2022-06-25 00:04:33.011564
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:34.026956
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert callable(getattr(FipsFactCollector, "collect"))

# Generated at 2022-06-25 00:04:35.614804
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect() is not None

# Generated at 2022-06-25 00:04:47.150432
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1['fips'] == False
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    assert var_2['fips'] == False

# Generated at 2022-06-25 00:04:59.115859
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # noinspection PyPep8Naming
    def do_test(mocker):
        fips_fact_collector_0 = FipsFactCollector()
        var_1 = mocker.patch('ansible_collections.ansible.community.plugins.module_utils.facts.collector.get_file_content')
        var_2 = mocker.Mock()
        var_2.read.side_effect = (
            '1',
        )

        var_1.return_value = var_2
        var_3 = fips_fact_collector_0.collect()

        assert var_1.call_count == 2
        assert var_1.call_args_list == [call('/proc/sys/crypto/fips_enabled'), call('/proc/sys/crypto/fips_enabled')]

# Generated at 2022-06-25 00:05:01.811015
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    f = FipsFactCollector()
    assert f.collect() == {"fips": False}
    f.name = 'dummy'
    assert f.name == 'dummy'

# Generated at 2022-06-25 00:05:05.759271
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts = {}
    var_0 = fips_fact_collector_0.collect(module=None, collected_facts=collected_facts)
    expected = {'fips': False}
    var_0.pop('ansible_fips')
    assert var_0 == expected

# Generated at 2022-06-25 00:05:08.085104
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:18.072117
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect([], {})
    assert var_1['fips']==False
    assert var_1['ansible_facts']=={'fips': False}
    assert var_1['_ansible_no_log']==False
    assert var_1['changed']==False
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect([], {})
    assert var_2['fips']==False
    assert var_2['ansible_facts']=={'fips': False}
    assert var_2['_ansible_no_log']==False
    assert var_2['changed']==False



# Generated at 2022-06-25 00:05:20.971349
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    # assert var_0['fips'] is False

# Generated at 2022-06-25 00:05:25.555952
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == dict(fips=False)

# Generated at 2022-06-25 00:05:28.427142
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    # return_data = {'fips': False}

test_case_0()

# Generated at 2022-06-25 00:05:31.218215
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1



# Generated at 2022-06-25 00:05:47.866055
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {u'fips': False}
    assert fips_fact_collector_0._fact_ids == set([u'fips'])

# Generated at 2022-06-25 00:05:53.224316
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    if var_0 == True:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:05:57.931226
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 is not None and len(var_0) == 1
    assert var_0['fips'] is not None

# Generated at 2022-06-25 00:05:59.208290
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert not FipsFactCollector.collect()

# Generated at 2022-06-25 00:06:01.626452
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Arrange
    fips_fact_collector = FipsFactCollector()

    # Act
    var = fips_fact_collector.collect()

    # Assert
    assert var == {
        # NOTE: this is populated even if it is not set
        'fips': False
    }


# Generated at 2022-06-25 00:06:06.005517
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}


# Generated at 2022-06-25 00:06:09.563466
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup test environment
    fips_fact_collector_1 = FipsFactCollector()

    # Perform test
    var_1 = fips_fact_collector_1.collect()

    # Assert class attributes are set correctly
    assert 'fips' in var_1

# Generated at 2022-06-25 00:06:14.381829
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    module_0 = AnsibleModule
    collected_facts_0 = dict
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:06:19.128646
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:06:21.147750
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:06:52.012913
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    ffc = FipsFactCollector()
    ff = ffc.collect()
    assert ff['fips'] is False

# Generated at 2022-06-25 00:06:55.063105
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    if var_0:
        print(var_0)
    return var_0


# Generated at 2022-06-25 00:06:57.900846
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert isinstance(FipsFactCollector.collect(FipsFactCollector()), dict)


# Generated at 2022-06-25 00:07:00.469764
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:01.228292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # TODO
    assert True

# Generated at 2022-06-25 00:07:02.731620
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    global var_0
    var_0 = FipsFactCollector().collect()

test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:07:04.648654
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts == {'fips': False}



# Generated at 2022-06-25 00:07:06.142087
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:07:09.255169
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var == {'fips': True}

# Generated at 2022-06-25 00:07:11.623490
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result == False


if __name__ == "__main__":
    # Unit test
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:08:13.314798
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:08:18.548798
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': True}, "Incorrect value returned from FipsFactCollector.collect()"


# Generated at 2022-06-25 00:08:23.690952
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert var['fips'] == (get_file_content('/proc/sys/crypto/fips_enabled') == '1')


# Generated at 2022-06-25 00:08:25.321660
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Assume
    fips_fact_collector_0 = FipsFactCollector()
    # Assert
    assert fips_fact_collector_0


# Generated at 2022-06-25 00:08:32.417549
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Data return if the system is in FIPS
    fips_fact_collector_data_0 = {'fips': True}

    # Data return if the system is not in FIPS
    fips_fact_collector_data_1 = {'fips': False}

    assert fips_fact_collector_data_0.keys() == fips_fact_collector_data_1.keys()

# Generated at 2022-06-25 00:08:36.461991
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False



# Generated at 2022-06-25 00:08:39.415688
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()



# Generated at 2022-06-25 00:08:41.004078
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:08:45.063940
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert test_case_0() == {
        'fips': False,
    }

# Generated at 2022-06-25 00:08:46.758237
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0.get('fips') == 0

# Generated at 2022-06-25 00:11:01.877643
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:11:03.398575
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


import unittest

# Generated at 2022-06-25 00:11:05.524705
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:08.227363
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

    # AssertionError: assert <bool object at 0x7f264cd857b8> == False
    assert var_1 == False



# Generated at 2022-06-25 00:11:15.971772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
  import sys
  import pytest

  #from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
  #from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts import fips
  from unit.compat import unittest
  from plugins.module_utils.facts import fips

  class TestFipsFactCollector(unittest.TestCase):
      def setUp(self):
          self.fact_collector_instance = fips.FipsFactCollector()

      def test_collect(self):
          self.fact_collector_instance.collect()


# Generated at 2022-06-25 00:11:17.978172
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup test environment
    fips_fact_collector_1 = FipsFactCollector()

    # Invoke method
    var_1 = fips_fact_collector_1.collect()

    # Check results
    assert isinstance(var_1, dict) == 1

    # Teardown test environment
    # assert 1 == 1


# Generated at 2022-06-25 00:11:18.887949
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert callable(FipsFactCollector.collect)

# Unit test on the instance of class FipsFactCollector

# Generated at 2022-06-25 00:11:23.475949
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert type(var_0) == dict


# Generated at 2022-06-25 00:11:25.917539
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: manual testing is required
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:11:34.866114
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test with a FIPS enabled system
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = var_0['fips']
    assert var_1 is True
    # Test with a FIPS disabled system
    fips_fact_collector_1 = FipsFactCollector()
    var_2 = fips_fact_collector_1.collect()
    var_3 = var_2['fips']
    assert var_3 is False
    # Test with a FIPS /proc/sys/crypto/fips_enabled file removed
    # This is mostly to test the fact that we are not getting 
    # an error in this case.
    fips_fact_collector_2 = FipsFactCollector()
