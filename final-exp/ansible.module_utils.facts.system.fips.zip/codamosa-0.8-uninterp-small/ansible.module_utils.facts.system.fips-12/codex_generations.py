

# Generated at 2022-06-25 00:02:57.360724
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:03:03.247615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert 'fips' in result.keys()

# Generated at 2022-06-25 00:03:06.038527
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:13.710727
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips_facts = True
    else:
        fips_facts = False

    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()
    fips_facts_1 = fips_fact_collector_1._collected_facts['ansible_fips']

    assert fips_facts == fips_facts_1


# Test case for whether the fact exists or not

# Generated at 2022-06-25 00:03:16.374029
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    res = fips_fact_collector_0.collect(module=None, collected_facts={'fips': {'fips': True, 'fips_enabled': '1'}})
    assert res.keys() == ['fips']


# Generated at 2022-06-25 00:03:18.504173
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert fips_facts['fips'] == True

# Generated at 2022-06-25 00:03:21.039003
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    result_1 = fips_fact_collector_1.collect()
    assert 'fips' in result_1

# Generated at 2022-06-25 00:03:25.538108
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert result == {
        'fips': False
    }

# Generated at 2022-06-25 00:03:29.400676
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    assert isinstance(result, dict)
    assert len(result) == 1
    assert "fips" in result
    assert isinstance(result["fips"], bool)


# Generated at 2022-06-25 00:03:37.024608
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test collect where fips is not enabled
    fips_fact_collector = FipsFactCollector()
    result = fips_fact_collector.collect()
    assert result is not None
    assert result['fips'] == False

    # Test collect where fips is enabled
    class FipsEnabled(FipsFactCollector):
        def collect(self):
            self.fips_facts = {}
            self.fips_facts['fips'] = True
            return self.fips_facts
    fips_enabled = FipsEnabled()
    result = fips_enabled.collect()
    assert result is not None
    assert result['fips'] == True

# Generated at 2022-06-25 00:03:42.058378
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect_0 = FipsFactCollector()
    assert fips_fact_collector_collect_0.collect() == {'fips': False}


# Generated at 2022-06-25 00:03:43.461046
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.collect()

# Generated at 2022-06-25 00:03:52.650189
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test case where /proc/sys/crypto/fips_enabled does not exist
    # Assert returns False for fips
    fips_fact_collector_0 = FipsFactCollector()
    FipsFactCollector.collect = lambda self, module=None, collected_facts=None: {'fips': False}
    assert fips_fact_collector_0.collect() == {'fips': False}
    # Test case where /proc/sys/crypto/fips_enabled exists with '0'
    # Assert returns False for fips
    fips_fact_collector_1 = FipsFactCollector()
    FipsFactCollector.collect = lambda self, module=None, collected_facts=None: {'fips': False}

# Generated at 2022-06-25 00:03:56.064564
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0._module_cache[0] = None
    fips_fact_collector_0._file_cache[0] = None
    fips_fact_collector_0._file_cache['/proc/sys/crypto/fips_enabled'] = '1'
    result = fips_fact_collector_0.collect()
    assert result == {u'fips': True}


# Generated at 2022-06-25 00:03:59.778839
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:04:06.477312
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_facts_1 = {
        'fips': False
    }
    fips_facts_2 = {
        'fips': True
    }
    fips_fact_collector_0 = FipsFactCollector()
    return fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect(None, None), fips_fact_collector_0.collect

# Generated at 2022-06-25 00:04:13.812654
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    data = get_file_content('/proc/sys/crypto/fips_enabled')
    if data and data == '1':
        fips = True
    else:
        fips = False
    fips_facts = fips_fact_collector_0.collect()
    assert 'fips' in fips_facts and fips_facts['fips'] == fips

# Generated at 2022-06-25 00:04:17.208228
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()
    assert type(fips_facts) is dict
    assert fips_facts['fips'] is False


# Generated at 2022-06-25 00:04:22.073905
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert fips_facts['fips'] == False


# Generated at 2022-06-25 00:04:23.123523
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    FipsFactCollector.collect()

# Generated at 2022-06-25 00:04:29.027216
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    collected_fips_facts = fips_fact_collector.collect()
    assert isinstance(collected_fips_facts, dict)

# Generated at 2022-06-25 00:04:31.185892
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = fips_fact_collector_0.collect()
    fips_facts_0 = fips_facts['fips']
    # Assert set()
    if fips_facts_0 is False:
        assert True


# Generated at 2022-06-25 00:04:34.385537
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    collected_facts = {'ansible_fips': False}
    assert fips_fact_collector_1.collect(None, collected_facts) == {'fips': False}


# Generated at 2022-06-25 00:04:36.305565
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert fips_fact_collector_0.collect() == {'fips': False}

# Generated at 2022-06-25 00:04:39.731511
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    module_0 = None
    collected_facts_0 = None

    collected_facts_0 = fips_fact_collector_0.collect(module_0, collected_facts_0)

    assert collected_facts_0 == {'fips': False}

# Generated at 2022-06-25 00:04:46.599150
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_data = """
0
"""
    res = [None]
    def get_file_content_func(path):
        return test_data
    test_object = FipsFactCollector()
    result = test_object.collect(get_file_content=get_file_content_func)
    assert result == {'fips': False}

# Generated at 2022-06-25 00:04:47.967966
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test if the class can be instantiated
    fips_fact_collector = FipsFactCollector()
    assert fips_fact_collector


# Generated at 2022-06-25 00:04:56.671173
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # noinspection PyUnresolvedReferences
    fips_facts_0 = FipsFactCollector().collect(None, None)
    # noinspection PyUnresolvedReferences
    assert type(fips_facts_0) is dict
    # noinspection PyUnresolvedReferences
    assert 'fips' in fips_facts_0.get('fips')
    # noinspection PyUnresolvedReferences
    assert type(fips_facts_0.get('fips')) is bool
    # noinspection PyUnresolvedReferences
    assert fips_facts_0.get('fips').__eq__(False) or fips_facts_0.get('fips').__eq__(True)


# Generated at 2022-06-25 00:05:00.935305
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips = fips_fact_collector.collect()
    assert fips['fips']

# Generated at 2022-06-25 00:05:02.891472
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_collect = FipsFactCollector()
    assert isinstance(fips_fact_collector_collect.collect(), dict)

# Generated at 2022-06-25 00:05:13.473981
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1 is not None
    res = fips_fact_collector_1.collect()
    assert res is not None
    assert 'fips' in res


# Generated at 2022-06-25 00:05:17.453332
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_fact_collector._collect = MagicMock(return_value = {'fips':'value'})
    fips_fact_collector.collect()


# Generated at 2022-06-25 00:05:21.539461
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    collected_facts_0 = {}
    fips_facts_0 = fips_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert 'fips' in fips_facts_0.keys()


# Generated at 2022-06-25 00:05:24.970543
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    assert not fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:26.637425
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    facts = fips_fact_collector.collect()
    assert facts['fips'] == False

test_case_0()

# Generated at 2022-06-25 00:05:28.305215
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:33.288480
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    result = fips_fact_collector_0.collect()
    # 'fips' is required key in dictionary result
    assert 'fips' in result

# Generated at 2022-06-25 00:05:35.716475
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    fips_fact_collector = FipsFactCollector()
    fips_facts = fips_fact_collector.collect()

    assert 'fips' in fips_facts

# Generated at 2022-06-25 00:05:40.214008
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts = fips_fact_collector_1.collect()
    assert 'fips' in fips_facts


# Generated at 2022-06-25 00:05:43.775312
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    try:
        fips_fact_collector_0.collect()
    except Exception as a_exception:
        raise a_exception



# Generated at 2022-06-25 00:06:00.131274
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:05.623557
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    facts_dict, additional_warnings = fips_fact_collector_1.collect()
    print(facts_dict)
    print(additional_warnings)

if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:06:11.043836
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Non-fips system
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts_0 = fips_fact_collector_0.collect()
    assert fips_facts_0['fips'] == 0
    # fips system
    fips_fact_collector_1 = FipsFactCollector()
    fips_facts_1 = fips_fact_collector_1.collect()
    assert fips_facts_1['fips'] == 1

# Generated at 2022-06-25 00:06:14.775615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    fips_facts_0 = fips_fact_collector.collect()
    assert fips_facts_0['fips'] is False

    fips_facts_1 = fips_fact_collector.collect()
    assert fips_facts_1['fips'] is False

    fips_facts_2 = fips_fact_collector.collect()
    assert fips_facts_2['fips'] is False



# Generated at 2022-06-25 00:06:18.660950
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    assert fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:06:22.270868
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    fips_facts = get_file_content('/proc/sys/crypto/fips_enabled')
    fips = fips_facts == '1'
    fips_fact_collector_0.get_fips()
    if fips:
        assert True
    else:
        assert False

# Generated at 2022-06-25 00:06:23.834166
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

# Generated at 2022-06-25 00:06:29.548864
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    fips_fact_collector = FipsFactCollector()

    # Test response from get_file_content
    get_file_content_response_data = ['test']
    def get_file_content_side_effect(filename):
        return get_file_content_response_data.pop()
    previous_get_file_content = get_file_content
    get_file_content = lambda filename: get_file_content_side_effect(filename)

    # Test response from FipsFactCollector.collect
    # NOTE: this is populated even if it is not set
    fips_fact_collector.collect_response_data = fips_facts

# Generated at 2022-06-25 00:06:30.776309
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert FipsFactCollector.collect

# Generated at 2022-06-25 00:06:35.038049
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    parameters = set()
    parameters.add('module')
    parameters.add('collected_facts')
    fips_fact_collector_0 = FipsFactCollector()
    fips_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:06:58.683615
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips']
    assert "fips" in var_0

# check if the execution is
# running from the source code
# (for example if it has been included
# in another project as a library)
if __name__ == "__main__":
    """
    Run the unit tests for the fips module.
    To execute the test, run the command:
    python -m test.unit.ansible_collections.ansible.community.plugins.module_utils.facts.fips
    """
    # Run the unit tests
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:07:01.845041
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_1 = fips_fact_collector_0.collect()
    assert var_1['fips'] is False


# Generated at 2022-06-25 00:07:06.579127
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    output_0 = {'fips': True}
    # mock get_file_content to return '1'
    with patch.object(fips_fact_collector_0, 'get_file_content', return_value='1'):
        # mock get_file_content to return '1'
        assert fips_fact_collector_0.collect() == output_0

# Generated at 2022-06-25 00:07:10.499616
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Setup
    fips_fact_collector = FipsFactCollector()
    # Exercise
    var = fips_fact_collector.collect()
    # Verify


# Generated at 2022-06-25 00:07:20.899576
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Input parameters: create test case input parameters as dictionary
    # fips = parameter value for 'fips'

    # Output:
    # fips = expected value for 'fips'

    # Test case 0
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == False

    # Test case 1
    fips_fact_collector_1 = FipsFactCollector()
    with open('/proc/sys/crypto/fips_enabled', 'w') as f_0:
        f_0.write('1')
    var_0 = fips_fact_collector_1.collect()
    assert var_0['fips'] == True

# Generated at 2022-06-25 00:07:21.829150
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:07:23.328253
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:07:27.916898
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}

# Generated at 2022-06-25 00:07:30.108958
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:34.707538
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {
        'fips': False
    }
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {
        'fips': False
    }

# Generated at 2022-06-25 00:08:13.431705
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()

    assert var_1['fips'] == False


# Generated at 2022-06-25 00:08:18.549750
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Create a test object
    fips_fact_collector_1 = FipsFactCollector()

    # Test return value
    var_1 = fips_fact_collector_1.collect()
    assert var_1 == {'fips': False}


# Generated at 2022-06-25 00:08:19.279292
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # NOTE: test case is not implemented (yet)
    assert False



# Generated at 2022-06-25 00:08:23.941829
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    

    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()

# Generated at 2022-06-25 00:08:29.596622
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

    var_1 = fips_fact_collector_1.collect()

    print("collect returns: " + str(var_1))


if __name__ == '__main__':
    test_case_0()
    test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:08:34.327322
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.fact_ids
    var_1 = fips_fact_collector_0.collect()
    assert var_0 == {
        'fips': 'fips'}
    assert var_1 == {
        'fips': False
    }

# Generated at 2022-06-25 00:08:35.313536
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    assert callable(FipsFactCollector.collect)

# Generated at 2022-06-25 00:08:40.629470
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    var_1 = {}
    var_1['fips'] = False
    fips_fact_collector_1 = FipsFactCollector()
    var_2 = fips_fact_collector_1.collect()


# Generated at 2022-06-25 00:08:42.716485
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()
    var_1 = fips_fact_collector_1.collect()


test_case_0()
test_FipsFactCollector_collect()

# Generated at 2022-06-25 00:08:46.523016
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()
    assert fips_fact_collector.name == 'fips'
    assert fips_fact_collector._fact_ids == set()
    assert var == {'fips': False}

# Generated at 2022-06-25 00:10:09.204622
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_1 = FipsFactCollector()

    assert type(fips_fact_collector_1.collect()) is dict

# Generated at 2022-06-25 00:10:19.061772
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    # Test the following case where class FipsFactCollector::collect() returns
    # valid values with /proc/sys/crypto/fips_enabled
    fips_fact_collector_0 = FipsFactCollector()
    # Populate with /proc/sys/crypto/fips_enabled with '1' string so that
    # FipsFactCollector returns True in 'fips' key
    fips_fact_collector_0.get_file_content = MagicMock(return_value='1')
    var_0 = fips_fact_collector_0.collect()
    assert var_0['fips'] == 1, 'Return value is not zero'

    # Test the following case where class FipsFactCollector::collect() returns
    # invalid values with /proc/sys/crypto/fips_enabled
    #

# Generated at 2022-06-25 00:10:22.212300
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector = FipsFactCollector()
    var = fips_fact_collector.collect()


# Generated at 2022-06-25 00:10:24.769275
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    var_1 = None
    var_2 = None
    fips_fact_collector_1 = FipsFactCollector()
    var_3 = fips_fact_collector_1.collect(var_1, var_2)



# Generated at 2022-06-25 00:10:29.430859
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert var_0 == {'fips': False}


# Generated at 2022-06-25 00:10:31.708727
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_0 = FipsFactCollector()
    var_0 = fips_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    var_1 = fips_fact_collector_0.get_fact_names()
    assert var_1 == {'fips'}

# Generated at 2022-06-25 00:10:41.740773
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():

    # Setting up mock
    class MockFileContent:
        def __init__(self, *args, **kwargs):

            self.return_value = None
            self.value = None

            if 'return_value' in kwargs:
                self.return_value = kwargs['return_value']

        def __call__(self, *args, **kwargs):
            if 'fips_enabled' == args[0]:
                if '1' == self.return_value:
                    self.value = '1'
            return self.value

    fips_fact_collector = FipsFactCollector()
    fips_fact_collector.get_file_content = MockFileContent(return_value='1')

    assert fips_fact_collector.collect() is not None
    assert fips_fact_collector

# Generated at 2022-06-25 00:10:45.474231
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fc = FipsFactCollector()
    assert fc
    assert hasattr(fc, 'name')
    assert fc.name == 'fips'
    assert hasattr(fc, '_fact_ids')
    assert fc._fact_ids == set()
    assert hasattr(fc, 'collect')
    assert isinstance(fc.collect(), dict)

# Generated at 2022-06-25 00:10:49.681759
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    from ansible.module_utils.facts.collector import FipsFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    fips_fact_collector_1 = FipsFactCollector()
    fips_fact_collector_1._read_file = get_file_content
    var_1 = fips_fact_collector_1.collect()

# Generated at 2022-06-25 00:10:54.472636
# Unit test for method collect of class FipsFactCollector
def test_FipsFactCollector_collect():
    fips_fact_collector_2 = FipsFactCollector()
    var_2 = fips_fact_collector_2.collect()
    if var_2 != None:
        assert var_2['fips'] == 0