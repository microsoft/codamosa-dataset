

# Generated at 2022-06-22 19:20:12.961420
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    search_path = tempfile.mkdtemp(prefix="ansible-tmp-list_collection_dirs-")
    search_path = search_path.strip('/')
    os.makedirs(search_path + '/ansible_collections/acme/smile')
    os.makedirs(search_path + '/ansible_collections/acme/frown')
    os.makedirs(search_path + '/ansible_collections/acme/nod/mood')

    assert search_path + '/ansible_collections/acme/smile' in list_collection_dirs([search_path])
    assert search_path + '/ansible_collections/acme/frown' in list_collection_dirs([search_path])
    assert search_path

# Generated at 2022-06-22 19:20:22.757563
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list_collection_dirs(search_paths=['tests/support/collections', 'tests/support/collections2'], coll_filter='not.a.collection'))
    print(list_collection_dirs(search_paths=['tests/support/collections', 'tests/support/collections2'], coll_filter='not'))
    print(list_collection_dirs(search_paths=['tests/support/collections', 'tests/support/collections2'], coll_filter='other.collections'))
    print(list_collection_dirs(search_paths=['tests/support/collections', 'tests/support/collections2'], coll_filter=None))

# Generated at 2022-06-22 19:20:23.771205
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:20:34.900786
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import Dict
    from ansible.module_utils.common._collections_compat import String
    collection_dict = {"ansible_collections": {"test_collections": ["collection1", "collection2"]}}

    # Test with defaults
    assert list_collection_dirs() == [], "No collection paths should be returned"

    # Test without defaults
    with AnsibleCollectionConfig.mock(collection_dict):
        assert list_collection_dirs([]) == [], "No collection paths should be returned"

    # Test with a single collection, that doesn't exist
    collection_dict = {"ansible_collections": {"test_collections": ["collection1"]}}
    with AnsibleCollectionConfig.mock(collection_dict):
        assert list_collection_dirs([])

# Generated at 2022-06-22 19:20:43.357975
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    import tempfile
    import shutil

# Generated at 2022-06-22 19:20:53.890444
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    path_results = list(list_valid_collection_paths(search_paths=['/no/such/path']))
    assert len(path_results) == 0

    path_results = list(list_valid_collection_paths(search_paths=['/usr/share/ansible/collections']))
    assert len(path_results) == 1

    path_results = list(list_valid_collection_paths(search_paths=['/usr/share/ansible/collections', '/no/such/path']))
    assert len(path_results) == 1

    path_results = list(list_valid_collection_paths(search_paths=['/usr/share/ansible/collections', '/etc/ansible/src']))
    assert len(path_results) == 2

    path_results

# Generated at 2022-06-22 19:20:59.966701
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible.foo.bar.plugins.module_utils.test_utils import AnsibleExitJson
    from ansible_collections.ansible.foo.bar.plugins.modules.net_tools import net_tools

    assert net_tools._load_params() == AnsibleExitJson(changed=False, msg=dict(msg='success'))

# Generated at 2022-06-22 19:21:05.617820
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        os.path.join('test', 'data', 'test_collections'),
        '/doesnotexist',
        '/etc',
        '/etc/ansible',
        os.path.join('test', 'data', 'test_collections', 'ansible_collections')
    ]

    # bad_paths = ['foo']
    for path in list_valid_collection_paths(test_paths, warn=False):
        assert path in test_paths



# Generated at 2022-06-22 19:21:09.961695
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/foo/bar'], warn=False)) == []
    assert list(list_valid_collection_paths(['/bin', '/etc'], warn=False)) == []
    assert list(list_valid_collection_paths(['/etc', '/usr'], warn=False)) == ['/etc', '/usr']

# Generated at 2022-06-22 19:21:21.022019
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.common.text.converters import to_text

    # default collection dir
    paths = []
    expected_colls = ('core', 'crypto', 'cloud', 'community', 'database', 'network', 'webservers', 'windows', 'storage', 'notification', 'system')
    colls = list(list_collection_dirs(search_paths=paths))

    # we need to make sure we're getting the right collections
    # and that we're getting the right number of them
    coll_count = 0
    for coll in colls:
        coll_count += 1
        coll = to_text(coll)
        assert coll.split('/')[-1] in expected_colls, "Unexpected collection directory: %s" % coll


# Generated at 2022-06-22 19:21:27.426235
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_search_paths = ['', '.', './', '/tmp/doesnotexist', '/', 'c:\\tmp\\doesnotexist\\']
    test_search_paths_valid = ['./', '/']
    assert(list_valid_collection_paths(test_search_paths) == test_search_paths_valid)



# Generated at 2022-06-22 19:21:35.660902
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # find environment variable based paths
    print(list(list_valid_collection_paths(None, False)))

    # override environment variable to find the current folder
    print(list(list_valid_collection_paths([os.getcwd()], False)))

    # override environment variable to find the current folder, warn if not found
    print(list(list_valid_collection_paths([os.getcwd()], True)))

    # override environment variable to look for a non existent path, warn if not found
    print(list(list_valid_collection_paths(['/path/to/nowhere'], True)))


# Generated at 2022-06-22 19:21:42.589303
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import textwrap
    import random
    import string

    # create a collection path in a tempdir
    tempdir = tempfile.mkdtemp()

    b_tempdir = to_bytes(tempdir, errors='surrogate_or_strict')

    # make a collection dir
    b_coll_dir = os.path.join(b_tempdir, to_bytes('ns1.coll1'))
    os.makedirs(b_coll_dir)

    # make a dir with a . in the name
    os.makedirs(os.path.join(b_coll_dir, to_bytes('dir.with.periods')))

    # create dirs that are not collections
    for i in range(1, random.randint(1, 10)):
        os.mk

# Generated at 2022-06-22 19:21:44.026280
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = list_collection_dirs()

    assert isinstance(path, type(list()))
    assert path

# Generated at 2022-06-22 19:21:55.143899
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Testing with a path that doesn't exist
    paths = list(list_valid_collection_paths([os.getcwd() + '/foobar'], True))
    assert len(paths) == 0
    # Testing with a path that is a file
    paths = list(list_valid_collection_paths(['/proc/cpuinfo'], True))
    assert len(paths) == 0
    # Testing with a path that is a file
    paths = list(list_valid_collection_paths(['/dev'], True))
    assert len(paths) == 0
    # Testing with a good path
    paths = list(list_valid_collection_paths([os.getcwd()], True))
    assert len(paths) == 1

if __name__ == '__main__':
    test_list_valid

# Generated at 2022-06-22 19:22:05.319038
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = os.path.join(os.path.dirname(__file__), 'test_data', 'collections')
    collection_dirs = list(list_collection_dirs([coll_path], 'my_namespace.my_collection'))
    assert collection_dirs[0] == to_bytes(os.path.join(coll_path, 'ansible_collections', 'my_namespace', 'my_collection'))
    collection_dirs = list(list_collection_dirs([coll_path], 'my_namespace'))
    assert len(collection_dirs) == 2
    assert os.path.join(coll_path, 'ansible_collections', 'my_namespace', 'my_collection') in collection_dirs

# Generated at 2022-06-22 19:22:13.923840
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["/tmp", "/tmp/coll_dir"]
    list_dirs = list(list_collection_dirs(search_paths=search_paths))

    # Verify that the function returns only valid paths
    assert len(list_dirs) == 1
    assert list_dirs[0] == to_bytes("/tmp/coll_dir/ansible_collections")

    # Verify that the function returns the correct list of paths
    # for different input formats
    assert len(list(list_collection_dirs(coll_filter="test.ansible"))) == 1
    assert len(list(list_collection_dirs(coll_filter="test"))) == 1

# Generated at 2022-06-22 19:22:15.058020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter=None)



# Generated at 2022-06-22 19:22:25.145924
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader import _get_collections_base_path
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    b_base_path = to_bytes(_get_collections_base_path())
    b_valid_path = os.path.join(b_base_path, to_bytes(b'ansible_collections'))

    b_invalid_path = to_bytes(unfrackpath("$missing"))

    # no paths should be valid if none exist
    res = list_valid_collection_paths(search_paths=[])
    assert res == []

    # valid path should work
    res = list_valid_collection_paths(search_paths=[b_valid_path])

# Generated at 2022-06-22 19:22:25.791335
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:22:34.649988
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with only valid paths
    valid_paths = [
        "/path/to/collections1",
        "/path/to/collections2",
        "/path/to/collections3",
    ]
    expected = [
        "/path/to/collections1",
        "/path/to/collections2",
        "/path/to/collections3",
    ]
    assert list(list_valid_collection_paths(valid_paths)) == expected

    # Test with non-existing path
    invalid_paths = [
        "/path/to/collections1",
        "/path/to/collections2",
        "/path/to/collections3",
        "/path/to/does_not_exist",
    ]

# Generated at 2022-06-22 19:22:38.556479
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Test list_valid_collection_paths function in the collections manager
    '''

    list_valid_collection_paths(search_paths=["/does/not/exist", "/usr/share/ansible/collections"])

# Generated at 2022-06-22 19:22:47.956431
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-22 19:22:53.845644
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    my_path = [os.path.dirname(os.path.abspath(__file__))]
    my_collection = list(list_collection_dirs(search_paths=my_path,
                                              coll_filter='ansible_collections.t_collection.t_collection'))

    assert my_collection[0] is not None
    assert 't_collection' in my_collection[0]



# Generated at 2022-06-22 19:23:03.957338
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test non collection path
    search_paths = [
        "non_existant_path",
        "non_existant_path_2"
    ]

    filtered_paths = list(list_valid_collection_paths(search_paths))
    assert len(filtered_paths) == 0

    # Test collection path
    search_paths = [
        os.path.join(os.path.dirname(__file__), "../../ansible_collections"),
        os.path.join(os.path.dirname(__file__), "../../ansible_collections")
    ]

    filtered_paths = list(list_valid_collection_paths(search_paths))
    assert filtered_paths == search_paths

    # Test collection path and non collection path
    search_paths

# Generated at 2022-06-22 19:23:10.868630
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.display import Display
    display = Display()

    from ansible import context
    context._init_global_context(cli_args=[])
    context.CLIARGS._parse_cli()

    for path in list_collection_dirs(coll_filter='mycoll.myns'):
        display.display(path)

# Generated at 2022-06-22 19:23:21.885765
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_search_path = 'test/test_collections'
    test_coll = 'testns.empty'
    test_coll_dir = 'test/test_collections/ansible_collections/testns/empty'
    assert (list(list_collection_dirs([test_search_path], test_coll)).pop()) == b'test/test_collections/ansible_collections/testns/empty'
    assert (list(list_collection_dirs([test_search_path])).pop()) == b'test/test_collections/ansible_collections/testns/empty'
    assert list_collection_dirs().__iter__().__next__() == b'/etc/ansible/collections'

# Generated at 2022-06-22 19:23:28.748554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=["/a", "/b", "/c"])) == ["/a", "/b", "/c"]
    assert list(list_valid_collection_paths(search_paths=["/a", "relative", "/c"])) == ["/a", "/c"]



# Generated at 2022-06-22 19:23:32.532669
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(coll_filter=None))
    assert list(list_collection_dirs(coll_filter="ansible_collections.my.collection"))


# Generated at 2022-06-22 19:23:42.565026
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ''' 
    Unit test for function list_collection_dirs
    '''
    # Assert that the collection dirs are present in the default path
    assert len(list(list_collection_dirs(search_paths=[]))) > 0

    # Assert that listing invalid path results in no dirs
    assert len(list(list_collection_dirs(search_paths=['/invalid/path']))) == 0

    # Assert that listing invalid path and the valid path results in correct number of dirs
    assert len(list(list_collection_dirs(search_paths=['/invalid/path'] + list(list_valid_collection_paths())))) > 0

# Generated at 2022-06-22 19:23:54.010717
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.collection_loader import AnsibleCollectionConfig
    # Set collection paths for unit test
    AnsibleCollectionConfig.collection_paths = [
        "/not/exist",
        "/tmp/ansible_collections",
        "/etc/ansible/ansible_collections",
        "./my_collections",
    ]

    # Create some paths
    collection_dirs = [
        "/not/exist",
        "/tmp/ansible_collections",
        "/etc/ansible/ansible_collections",
        "./my_collections",
    ]
    for collection_dir in collection_dirs:
        os.makedirs(collection_dir)

    valid_paths = list(list_valid_collection_paths())
    assert(len(valid_paths) == 3)
   

# Generated at 2022-06-22 19:24:01.798565
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = AnsibleCollectionConfig.collection_paths
    assert len(list(list_valid_collection_paths())) >= len(search_paths)
    assert len(list(list_valid_collection_paths([]))) >= len(search_paths)
    assert len(list(list_valid_collection_paths(search_paths))) >= len(search_paths)

# Generated at 2022-06-22 19:24:14.496471
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-22 19:24:24.393163
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # creates a tempdir AND an ansible_collection subdir in that tempdir
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:24:32.953795
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    search_paths.append("/etc/ansible/collections")
    search_paths.append("/etc/ansible/foo")
    search_paths.append("/etc/ansible")
    search_paths.append("/etc/ansible/collections/ansible_collections/test/plugins")

    # search_paths valid
    result_paths = list_valid_collection_paths(search_paths=search_paths, warn=False)
    for result in result_paths:
        assert os.path.exists(result)

    result_paths = list_valid_collection_paths(search_paths=search_paths, warn=True)
    for result in result_paths:
        assert os.path.exists(result)

   

# Generated at 2022-06-22 19:24:43.314464
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import TemporaryDirectory
    from collections import defaultdict
    import shutil
    import os

    # return False if any collection has a module that exists in a different collections

# Generated at 2022-06-22 19:24:54.996720
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import os

    # create a dummy path
    temp_dir = tempfile.gettempdir()
    testpath = os.path.join(temp_dir, 'ansible_collections')


# Generated at 2022-06-22 19:25:02.858297
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.collection_loader import path_dwim
    from ansible.utils.path import unfrackpath

    coll_dirs = list_collection_dirs()

    for coll_path in coll_dirs:

        coll_path = unfrackpath(coll_path)

        if not os.path.exists(coll_path):
            raise AssertionError("Expected collection path at %s to exist" % coll_path)

        if not os.path.isdir(coll_path):
            raise AssertionError("Expected collection path at %s to be a directory" % coll_path)

        if not is_collection_path(coll_path):
            raise AssertionError("Collection path at %s failed to validate" % coll_path)


# Generated at 2022-06-22 19:25:12.844334
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # NOTE: this test will fail the first time it is run in the flake environment.
    # It needs to be rerun in order to pass.
    with tempfile.TemporaryDirectory() as tmp:
        search_paths = [os.path.join(tmp, "one"), os.path.join(tmp, "two")]

        # Create the test collections
        namespaces = ["ansible_namespace", "ansible_namespace_two"]
        for namespace in namespaces:
            for collection in ["collection", "collection_two"]:
                coll_path = os.path.join(search_paths[0], "ansible_collections", namespace, collection)
                os.makedirs(coll_path)

# Generated at 2022-06-22 19:25:19.307904
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for empty search path
    assert not list_valid_collection_paths(search_paths=[])

    # Test for non-existing path
    assert not list_valid_collection_paths(search_paths=['/path/to/non-existing'])

    # Test for non-directory path
    assert not list_valid_collection_paths(search_paths=['/etc/hosts'])

    # Test for existing paths
    assert list_valid_collection_paths(search_paths=['/tmp/path/to/existing'])


# Generated at 2022-06-22 19:25:26.130231
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    coll_name = "namespace.collection"
    coll_dir = os.path.join(tempfile.gettempdir(), "ansible_collections", coll_name)
    dummy_coll_dir = os.path.join(tempfile.gettempdir(), "ansible_collections", "namespace.collection2")
    os.makedirs(coll_dir)
    os.makedirs(dummy_coll_dir)
    dirs = list_collection_dirs([tempfile.gettempdir()], coll_name)
    shutil.rmtree(os.path.join(tempfile.gettempdir(), "ansible_collections"))
    assert(len(dirs) == 1)
    assert(dirs[0] == coll_dir)


# Generated at 2022-06-22 19:25:31.940650
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['__file__'] = '/ansible/ansible/lib/ansible/module_utils/basic.py'
    from ansible.module_utils.six.moves import reload_module
    reload_module(AnsibleCollectionConfig)
    assert len(list(list_collection_dirs())) > 0, "No valid collections found"
    assert len(list(list_collection_dirs(['/tmp']))) == 0, "Invalid collections found"

test_list_collection_dirs()

# Generated at 2022-06-22 19:25:33.876230
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths as utils_list_valid_collection_paths
    assert list(utils_list_valid_collection_paths()) == list(list_valid_collection_paths())

# Generated at 2022-06-22 19:25:38.720456
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    testcolpath = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'collection_loader', 'valid_collection_1')
    test_paths_list = ['/tmp/nonexistent', testcolpath]
    test_filtered_list = list(list_collection_dirs(test_paths_list))
    assert len(test_filtered_list) == 1
    assert testcolpath in test_filtered_list
    testcolpath = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'collection_loader', 'valid_collection_2')

# Generated at 2022-06-22 19:25:45.803608
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_collections = [
        "ansible_collections/temp",
        "collections_test_1/ansible_collections/test"
    ]

    temp_colls = list(list_collection_dirs(search_paths=test_collections))
    expected = os.path.join(os.path.dirname(__file__), 'collections_test_1/ansible_collections/test/test_collection/plugins/module_utils')

    assert expected in temp_colls


# Generated at 2022-06-22 19:25:52.305019
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/does/not/exist'])) == []
    assert (list(list_valid_collection_paths(['/does/not/exist', 'r%26r'])) == ['r&r'])
    assert (list(list_valid_collection_paths(['/does/not/exist', '/does/not/exist', 'r%26r'])) == ['r&r'])
    assert (list(list_valid_collection_paths(['/does/not/exist', 'r%26r', '/does/not/exist'])) == ['r&r'])

# Generated at 2022-06-22 19:26:01.140689
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils import basic
    import difflib
    import json

    global display

    class Display(object):
        verbosity = 0
        def vv(self, msg, host=None):
            print(msg)

        def v(self, msg, host=None):
            print(msg)

        def error(self, msg, wrap_text=True):
            print(msg)

        def warning(self, msg, wrap_text=True):
            print(msg)

    display = Display()

    # set the search path
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'collection_filter_test')
    search_paths = [test_path]


# Generated at 2022-06-22 19:26:10.638469
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [u'/nonexistpath', u'/usr/share/ansible', u'/home/ansible/mine']
    coll_dirs = list(list_collection_dirs(search_paths))
    assert len(coll_dirs) == 1
    assert coll_dirs[0] == '/usr/share/ansible/ansible_collections/ansible'
    assert set(list_collection_dirs(['/home/ansible/nonexist'])) == set()
    assert set(list_collection_dirs(search_paths, coll_filter='certbot')) == set()
    assert set(list_collection_dirs(search_paths, coll_filter='cloud.azure')) == set()

# Generated at 2022-06-22 19:26:19.820785
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import ansible.constants as C

    temp_roots = []
    def clean_up(temp_roots):
        for root in temp_roots:
            shutil.rmtree(root)


# Generated at 2022-06-22 19:26:24.180315
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths()
    assert type(paths) == list
    assert paths
    assert [x for x in paths if x.endswith("ansible_collections")]
    # TODO: test that each path exists and contains directories

# Generated at 2022-06-22 19:26:34.870478
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    test_path = tempfile.mkdtemp()

    # Create nested directory
    test_path_1 = os.path.join(test_path, 'ansible_collections')
    os.makedirs(test_path_1)

    test_path_2 = os.path.join(test_path, 'ansible_collections2')
    os.makedirs(test_path_2)

    test_path_3 = os.path.join(test_path, 'ansible_collections3')
    os.makedirs(test_path_3)

    # Create a file

# Generated at 2022-06-22 19:26:45.286822
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display

    display = Display()

# Generated at 2022-06-22 19:26:49.824813
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [os.getcwd()]
    coll_dirs = list_collection_dirs(search_paths)
    colls = list(coll_dirs)
    assert len(colls) == 1
    assert 'ansible_collections' in str(colls[0])

# Generated at 2022-06-22 19:26:55.723474
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import _load_collection_config

    _load_collection_config()
    search_paths = ["/this/does/not/exist", "/tmp"]

    for path in list_valid_collection_paths(search_paths):
        print(path)

# Generated at 2022-06-22 19:27:00.754003
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_list = ['does_not_exist', 'is_a_file']
    search_list.extend(AnsibleCollectionConfig.collection_paths)

    # filter out empty and invalid paths
    for i in list_valid_collection_paths(search_list, warn=True):
        assert i in AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:27:09.808420
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        import pytest
    except ImportError:
        print("*** pytest not found, unable to run unit test.")
        return

    valid_paths = ['/path/to/.ansible/collections/', '/path/to/ansible_collections/']
    invalid_paths = ['/path/to/ansible_collections', '/path/to/ansible_collections/something.txt']

    # Test filtering empty input list
    assert list(list_valid_collection_paths([])) == []

    # Test filtering out None input
    assert list(list_valid_collection_paths(None)) == []

    # Test filtering out None input with valid paths
    assert list(list_valid_collection_paths(valid_paths)) == valid_paths

    # Test filtering out None input with valid paths
   

# Generated at 2022-06-22 19:27:20.892380
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath
    from ansible.utils.hashing import secure_hash_s

    this_dir = os.path.dirname(__file__)
    collection_paths = [os.path.join(this_dir, u'test_collections')]
    search_paths = [os.path.join(this_dir, u'test_search_paths', u'a'), os.path.join(this_dir, u'test_search_paths', u'b')]
    for search_path in search_paths:
        collection_path = search_path
        collection_paths.append(collection_path)
    assert len(collection_paths) == 4


# Generated at 2022-06-22 19:27:26.058591
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with open('list_collection_dirs_ansible_collections_path.txt', 'w') as f:
        for coll_dir in list_collection_dirs(['/my/collection/path'], 'namespace.collection'):
            f.write(coll_dir + '\n')

# Generated at 2022-06-22 19:27:34.724901
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    other_path = b"/dev/null"
    this_path = b"/tmp"
    max_path = b"/tmp/file_deleted_during_test.test"
    dir_path = b"/tmp/dir_deleted_during_test"

    # create an empty file that will be used in below tests
    f = open(max_path, 'w')
    f.close()

    # create a directory that will be used in below tests

# Generated at 2022-06-22 19:27:44.135212
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == []
    assert list_valid_collection_paths([1, 'b']) == []
    assert list_valid_collection_paths(['/a/b/c']) == ['/a/b/c']
    assert list_valid_collection_paths([1, 'b'], warn=False) == []
    assert list_valid_collection_paths([1, 'b'], warn=True) == []
    assert list_valid_collection_paths(['/a/b/c'], warn=False) == ['/a/b/c']
    assert list_valid_collection_paths(['/a/b/c'], warn=True) == ['/a/b/c']

# Generated at 2022-06-22 19:27:50.789291
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # save the original paths
    paths = AnsibleCollectionConfig.collection_paths
    try:
        AnsibleCollectionConfig.collection_paths = [tmpdir, '/fake/path', '/fake/path2', '/fake/path3']
        retval = list(list_valid_collection_paths())
        assert len(retval) == 1
        assert tmpdir in retval
    finally:
        AnsibleCollectionConfig.collection_paths = paths
    # delete the tmpdir now that we are done
    os.rmdir(tmpdir)

# Generated at 2022-06-22 19:27:55.994717
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    result = list_valid_collection_paths(
        search_paths=['/tmp/roberts/does/not/exist/foo/bar', '/tmp/roberts/does/not/exist2'],
        warn=False
    )

    number_of_results = len(list(result))

    assert number_of_results == len(AnsibleCollectionConfig.collection_paths), 'Number of valid paths was not correct'


# Generated at 2022-06-22 19:28:03.280903
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    temp_d = tempfile.mkdtemp()

    # create a dummy collection
    os.mkdir(os.path.join(temp_d, 'ansible_collections'))
    os.mkdir(os.path.join(temp_d, 'ansible_collections', 'mynamespace'))
    os.mkdir(os.path.join(temp_d, 'ansible_collections', 'mynamespace', 'mycollection'))

    # create an empty dir, which should not be scanned
    os.mkdir(os.path.join(temp_d, 'ansible_collections', 'mynamespace', 'empty_dir'))

    # create a file w/ ansible_collections name, which should not be scanned

# Generated at 2022-06-22 19:28:11.411111
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """

    path_1 = '/a_path/that/does/not/exist'
    path_2 = '/a_path/that/is/not/a/directory'
    path_3 = '/boot'

    with open(path_2, 'w') as f:
        f.write('test')

    search_paths = [path_1, path_2, path_3]

    results = list_valid_collection_paths(search_paths)

    assert len(results) == 2
    assert path_3 in results
    assert path_1 not in results
    assert path_2 not in results

    os.remove(path_2)



# Generated at 2022-06-22 19:28:17.539976
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_collections_path = ['/path1/collections', '/path2/collections']
    test_coll_filter = 'namespace.collection'

    # Test that list_collection_dirs is returning all collections dirs
    assert set(list_collection_dirs(test_collections_path, test_coll_filter)) == set(list(list_collection_dirs(test_collections_path)))

    # Test that list_collection_dirs is returning one collection dir
    assert list_collection_dirs(test_collections_path, test_coll_filter) == [b'/path1/collections/namespace/collection']

# Generated at 2022-06-22 19:28:28.182679
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=[])) == []
    assert list(list_valid_collection_paths(search_paths=['/foo/bar'])) == []
    assert list(list_valid_collection_paths(search_paths=['/foo/bar'], warn=True)) == []
    assert list(list_valid_collection_paths(search_paths=['.', '/foo/bar'])) == ['.']
    assert list(list_valid_collection_paths(search_paths=['.', '/foo/bar'], warn=True)) == ['.']

# Generated at 2022-06-22 19:28:34.077582
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Return non-empty result if list_valid_collection_paths returns
    non-empty list
    """
    result = list_valid_collection_paths()
    assert result
    # If there are no default collection paths, Ansible should throw up
    assert AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:28:38.327226
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_of_collections = list(list_collection_dirs(
        [
            "./test/units/utils/collection_loader/fixtures/collection_paths/one",
            "./test/units/utils/collection_loader/fixtures/collection_paths/two"
        ]
    ))
    assert len(list_of_collections) == 2

# Generated at 2022-06-22 19:28:41.495308
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test empty path list
    assert len(list(list_collection_dirs(search_paths=[]))) == 0

# Generated at 2022-06-22 19:28:52.123086
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import textwrap
    from ansible.module_utils.six.moves import configparser
    from ansible.cli import CLI

    # Set up a basic collection directory for the test
    tmpdir = tempfile.mkdtemp()
    colldir = os.path.join(tmpdir, 'ansible_collections')
    os.mkdir(colldir)
    os.mkdir(os.path.join(colldir, 'my_namespace'))
    os.mkdir(os.path.join(colldir, 'your_namespace'))
    os.mkdir(os.path.join(colldir, 'my_namespace', 'my_collection'))
    os.mkdir(os.path.join(colldir, 'your_namespace', 'your_collection'))
   

# Generated at 2022-06-22 19:28:54.721262
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    has_path = False
    for path in list_valid_collection_paths():
        if "ansible_collections" in path:
            has_path = True
            break

    assert has_path



# Generated at 2022-06-22 19:28:56.864646
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) >= 2



# Generated at 2022-06-22 19:29:07.778151
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    invalid_paths = [
        "/tmp/does/not/exist",
        "/dev/null",
        "/etc/passwd",
    ]
    expected_paths = [
        "/usr/share/ansible/collections",
        "/etc/ansible/collections",
    ]
    for invalid_path in invalid_paths:
        try:
            list(list_valid_collection_paths([invalid_path]))
        except Exception as err:
            assert isinstance(err, AnsibleError)
    assert list(list_valid_collection_paths(expected_paths)) == expected_paths


# Generated at 2022-06-22 19:29:15.900154
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected_results = [os.path.expanduser("~/.ansible/collections"),
                        "/foo/bar/baz"]
    for test_path in [os.path.expanduser("~/.ansible/collections/"),
                      "/foo/bar/baz/",
                      "/usr/share/ansible/collections",
                      None]:
        assert test_path in expected_results

# Generated at 2022-06-22 19:29:25.836542
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    # test empty
    result = list(list_valid_collection_paths())
    assert result == []

    # test missing file
    missing_file = mkdtemp()
    result = list(list_valid_collection_paths([missing_file]))
    assert len(result) == 0

    # test single file, not dir
    with open(missing_file, 'w') as f:
        f.write('test')
    result = list(list_valid_collection_paths([missing_file]))
    assert len(result) == 0

    # test single dir
    os.remove(missing_file)
    os.mkdir(missing_file)
    result = list(list_valid_collection_paths([missing_file]))
    assert len(result) == 1

    #

# Generated at 2022-06-22 19:29:34.353708
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config.manager import ConfigManager, get_config_value_from_file
    from ansible.module_utils.six.moves.urllib.request import urlopen, Request

    # create temporary local collection directories
    (fd, local_collection) = tempfile.mkstemp(prefix="ansible_collections-")
    os.close(fd)
    os.mkdir(local_collection)
    os.mkdir(os.path.join(local_collection, 'namespace1'))
    with open(os.path.join(local_collection, 'namespace1', 'collection1', '__init__.py'), 'a') as f:
        f.write('#')
    os.mkdir(os.path.join(local_collection, 'namespace1', 'collection2'))

# Generated at 2022-06-22 19:29:43.332729
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmp_root = tempfile.mkdtemp(prefix='ansible_test_collection_find_')
    tmp_path = os.path.join(tmp_root, 'ansible_collections')

    # create some collections in subdirs
    os.mkdir(tmp_path)
    os.mkdir(os.path.join(tmp_path, 'test'))
    open(os.path.join(tmp_path, 'test', '__init__.py'), 'a').close()
    os.mkdir(os.path.join(tmp_path, 'test', 'one'))
    os.mkdir(os.path.join(tmp_path, 'test', 'two'))

# Generated at 2022-06-22 19:29:48.577047
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [b'test_path', b'invalid_path_1', b'invalid_path_2']
    expected = [b'test_path']
    for i, p in enumerate(list_valid_collection_paths(search_paths=paths)):
        assert p == expected[i]

# Generated at 2022-06-22 19:29:53.528876
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    search_paths = []
    # tests for broken directory (not existing or not dir)
    # tests for valid path
    coll_root = tempfile.mkdtemp()
    coll_path = os.path.join(coll_root, 'ansible_collections')
    search_paths.append(coll_root)
    search_paths.append(coll_path)

    # tests for broken directory (not existing or not dir)
    try:
        tmp_dir = tempfile.mkdtemp()
        fpath = os.path.join(tmp_dir, "tmpfile.txt")
        f = open(fpath,'wb')
        f.close()
        search_paths.append(fpath)
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-22 19:30:02.996033
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        import pytest
        pytest_found = True
    except ImportError:
        pytest_found = False

    if not pytest_found:
        print("The 'pytest' package is required for this test.")
        print("See http://pytest.org for more information about the test framework.")

    else:
        import shutil
        import tempfile

        from ansible_collections.test.test_utils.content.collection_test_dir.plugins.test_collection.test_test import get_test
        from ansible_collections.test.test_utils.content.collection_test_dir.plugins.test_collection2.test_test import get_test
        from ansible_collections.test.test_utils.content.collection_test_dir.plugins.test_collection3.test_test import get_test


# Generated at 2022-06-22 19:30:07.353776
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import TemporaryDirectory
    from ansible.module_utils.common.removed import removed
    with TemporaryDirectory() as tmpdir:
        result = list(list_valid_collection_paths([tmpdir]))
        assert result == []
        tmpdir_b = to_bytes(tmpdir, errors='surrogate_or_strict')
        assert os.path.exists(tmpdir_b)
        # For Python 3.5 we need to catch the ResourceWarning or it will abort the test
        try:
            os.mkdir(os.path.join(tmpdir_b, b'ansible_collections'))
        except UnicodeDecodeError:
            removed("Bytes to path conversion", "2.11")
        result = list(list_valid_collection_paths([tmpdir]))

# Generated at 2022-06-22 19:30:12.872781
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # parse valid path
    paths = ['./collections']
    for path in list_valid_collection_paths(paths):
        assert path == './collections'

    # parse empty path
    paths = []
    assert list(list_valid_collection_paths(paths)) == list(AnsibleCollectionConfig.collection_paths)

    # filter out invalid
    paths = ['./collections', './noexists', '/etc']
    for path in list_valid_collection_paths(paths):
        assert path in ['./collections', '/etc']

