

# Generated at 2022-06-22 19:20:16.403204
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Create a temp collection dir, validate it can be seen
    :return:
    """
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path, mkdir, listdir

    tmp_collections_dir = mkdtemp()
    test_content_dir = path.join(tmp_collections_dir, 'ansible_collections')
    mkdir(test_content_dir)

    # create a test collection directory
    test_collection_dir = path.join(test_content_dir, 'test_namespace', 'test_collection')
    mkdir(test_collection_dir)

    # validate find works
    result = list_collection_dirs([tmp_collections_dir, ], 'test_namespace.test_collection')
    rmtree(tmp_collections_dir)

# Generated at 2022-06-22 19:20:21.452060
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """
    test_dirs = [
        "/test/my/path",
    ]

    for d in test_dirs:
        for c in list_collection_dirs(search_paths=test_dirs):
            if not c.startswith(to_bytes(d)):
                assert False

# Generated at 2022-06-22 19:20:32.076533
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_path_missing = "/tmp/i/do/not/exist"
    test_path_not_dir = "/etc/passwd"

    file(test_path_not_dir, 'w').close()

    search_paths = []
    search_paths.append(test_path_missing)
    search_paths.append(test_path_not_dir)

    results = list(list_valid_collection_paths(search_paths, warn=False))

    os.remove(test_path_not_dir)

    assert len(results) == 0

    # Cleanup
    if os.path.exists(test_path_not_dir):
        os.remove(test_path_not_dir)

# Generated at 2022-06-22 19:20:41.585840
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        '../tests/unit/utils/collection-loader-internal/search_path_1',
        '../tests/unit/utils/collection-loader-internal/search_path_2',
        '../tests/unit/utils/collection-loader-internal/search_path_3',
        '../tests/unit/utils/collection-loader-internal/search_path_4',
    ]

    collection_dirs = list(list_collection_dirs(search_paths))

    collection_dirs_expected_count = 4
    assert len(collection_dirs) == collection_dirs_expected_count


# Generated at 2022-06-22 19:20:42.647247
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # TODO: Add Test
    pass


# Generated at 2022-06-22 19:20:45.297685
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/usr', '/etc', '~']

    from ansible.module_utils.collections import list_valid_collection_paths
    valid_paths = list(list_valid_collection_paths(test_paths))

    assert len(valid_paths) == 3



# Generated at 2022-06-22 19:20:54.549922
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that list_collection_dirs returns expected values for test collections
    """
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    test_coll_inv = tmpdir + '/test_coll_inv'
    test_coll1 = tmpdir + '/test_coll1/ansible_collection/test_coll1'
    test_coll2 = tmpdir + '/test_coll2/ansible_collection/test_coll2'

    os.mkdir(test_coll1)
    os.mkdir(test_coll2)

    os.mkdir(test_coll1 + '/plugins/module_utils')
    os.mkdir(test_coll2 + '/plugins/module_utils')


# Generated at 2022-06-22 19:21:04.698057
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths

    paths = ['/foo/bar/howdy', '/baz/zooloo', '/foo/bar/baz/zooloo', 'hello/world/foo/bar/howdy/', 'hello/world']
    valid_paths = ['/foo/bar/howdy', '/baz/zooloo', '/foo/bar/baz/zooloo', 'hello/world/foo/bar/howdy/']

    paths = [to_bytes(p) for p in paths]
    valid_paths = [to_bytes(p) for p in valid_paths]

    # setup

# Generated at 2022-06-22 19:21:12.594282
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    b_tmpdir = to_bytes(tmpdir, errors='surrogate_or_strict')
    assert list(list_valid_collection_paths([tmpdir])) == [tmpdir]

    os.rmdir(b_tmpdir)
    assert list(list_valid_collection_paths([tmpdir])) == []

    os.makedirs(b_tmpdir)
    assert list(list_valid_collection_paths([tmpdir])) == [tmpdir]

    os.makedirs(os.path.join(b_tmpdir, b'foobar'))
    assert list(list_valid_collection_paths([tmpdir])) == [tmpdir]

# Generated at 2022-06-22 19:21:14.786510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pathlist = []
    for path in list_valid_collection_paths(pathlist):
        print("Path: %s" % path)

# Generated at 2022-06-22 19:21:19.197878
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = list(list_valid_collection_paths(["/var/tmp", "/var/lib"]))
    assert "/var/tmp" in test_paths
    assert "/var/lib" in test_paths


# Generated at 2022-06-22 19:21:30.744893
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.utils.path import makedirs_safe

    collection_dirs = list()
    collection_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:21:39.991043
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    test_rval = []

    test_ns = "ansible_collections.namespace_1"
    test_coll = "namespace_1.collection_1"

    # create a temporary directory to use as the collection path
    temp_dir = tempfile.mkdtemp()

    # create a collection directory to represent what would be downloaded
    # from the galaxy server
    os.mkdir(os.path.join(temp_dir, test_ns))
    os.mkdir(os.path.join(temp_dir, test_coll))

    # create a role directory to represent a role in the collection
    os.mkdir(os.path.join(temp_dir, test_coll, "roles", "role_1"))

    # test a single collection filter

# Generated at 2022-06-22 19:21:47.175470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # initialized test environment
    d = '/tmp/.ansible/tmp/mazer_test/list_valid_collection_paths'

    # create test environment
    os.makedirs(d)
    os.makedirs('%s/existing/not_dir' % d)
    os.makedirs('%s/existing/ansible_collections' % d)
    os.makedirs('%s/existing/another_collections' % d)
    os.makedirs('%s/existing/ansible_collections/namespace/collection' % d)
    os.makedirs('%s/empty' % d)
    open('%s/existing/ansible_collections/namespace/collection/not_a_plugin' % d, 'w').close()

# Generated at 2022-06-22 19:21:57.207429
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test loading all collections from default path
    coll_list = list(list_collection_dirs())
    assert len(coll_list) > 0

    # Test loading all collections from specific path
    test_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    coll_list = list(list_collection_dirs(search_paths=[test_path]))
    assert len(coll_list) > 0

    # Test loading all collections from two specific paths
    test_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    coll_list = list(list_collection_dirs(search_paths=[test_path, test_path]))
    assert len(coll_list) > 0

    # Test loading

# Generated at 2022-06-22 19:22:08.339259
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    make sure list_collection_dirs works
    """
    from test.support.fixtures import AnsibleCollectionFixture
    from ansible.plugins.loader import ActionModuleLoader
    import os

    cwd = os.getcwd()

    # Create a collection using our temp collection fixture

    coll_root = "%s/ansible_collections" % cwd
    coll_fixture = AnsibleCollectionFixture('fake', 'test_collections', 'test_collections', collection_root=coll_root)

    # Create a sample collection copy and symlink
    action_plugin = os.path.join(coll_fixture.collection_path, 'plugins', 'actions')
    os.makedirs(action_plugin)

# Generated at 2022-06-22 19:22:17.162654
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile
    import unittest
    from shutil import rmtree

    class TestListCollectionDirs(unittest.TestCase):
        def setUp(self):
            self.temp_collection_root = tempfile.mkdtemp()
            self.collections_path = os.path.join(self.temp_collection_root, 'ansible_collections')
            self.namespace_path = os.path.join(self.collections_path, 'my_namespace')
            self.collection_path = os.path.join(self.namespace_path, 'my_collection')

        def tearDown(self):
            rmtree(self.temp_collection_root)


# Generated at 2022-06-22 19:22:26.132878
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_text
    import tempfile
    import shutil

    # Test with no search_paths (use Default config paths only)
    pathlist = list(list_valid_collection_paths())

    expected_defaults = [
        '/etc/ansible/collections',
        '/usr/share/ansible/collections',
        '~/.ansible/collections']

    # Validate search_paths against expected defaults
    assert(set(pathlist) == set([to_text(p) for p in expected_defaults]))

    # Create a temporary directory and copy a few empty files into it
    tmp_dir = tempfile.mkdtemp()
    file1 = tmp_dir + '/file1'
    os.mknod(file1)
    file2 = tmp_dir

# Generated at 2022-06-22 19:22:33.199368
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # cover corner case of no paths
    assert list(list_valid_collection_paths()) == []

    # cover corner case of not existing path
    assert list(list_valid_collection_paths(search_paths=['not_existing_path'])) == []

    # cover corner case of not existing path not warning
    assert list(list_valid_collection_paths(search_paths=['not_existing_path'], warn=False)) == []

    # cover corner case of valid path
    assert list(list_valid_collection_paths(search_paths=['/'])) == ['/']

# Generated at 2022-06-22 19:22:43.755765
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    binaries = [
        {
            "name": "python",
            "path": "/usr/bin/python",
            "version": "2.7",
            "usage": "test",
        },
        {
            "name": "python3",
            "path": "/usr/bin/python3",
            "version": "3.6",
            "usage": "test",
        },
    ]
    collection_paths = [
        '/usr/share/ansible/collections',
        '/usr/share/ansible_collections',
    ]
    collection_path = [
        '/usr/share/ansible/collections/ansible_collections/namespace/collection',
        '/usr/share/ansible_collections/ansible_collections/namespace/collection',
    ]

# Generated at 2022-06-22 19:22:53.947346
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import sys
    import tempfile
    import shutil

    # Create test collection path, fail the test if we fail to create a temp dir
    test_path = tempfile.mkdtemp(prefix='ansible_test_collection_path')

    if not os.path.isdir(test_path):
        sys.exit("Failed to create test collection path: %s" % test_path)

    # Create a test collection within an ansible_collections subdir of our test path
    fp = os.path.join(test_path, 'ansible_collections', 'test_ns', 'test_coll', 'plugin')
    os.makedirs(fp)
    with open(os.path.join(fp, '__init__.py'), 'w'):
        pass


# Generated at 2022-06-22 19:23:01.109724
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Unit test for function list_collection_dirs """
    from ansible.utils.collection_loader import AnsibleCollectionFinder
    from ansible.parsing.dataloader import DataLoader

    # Test for listing collection with absolute path
    finder = AnsibleCollectionFinder(loader=DataLoader(), collection_paths=[])
    # Test for listing collection with no namespace
    list_collection_dirs(coll_filter="foo.bar")
    # Test for listing collection with namespace
    list_collection_dirs(coll_filter="foo")

# Generated at 2022-06-22 19:23:08.991020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _collection_base

    assert 'ansible_collections' in next(list_collection_dirs(coll_filter='ansible.builtin'))
    assert 'ansible_collections' in next(list_collection_dirs(coll_filter='ansible.builtin'))

    for base in _collection_base:
        assert base not in next(list_collection_dirs(coll_filter='ansible.builtin'))

    assert 'ansible_collections' in next(list_collection_dirs(coll_filter='ansible.builtin'))

    list(list_collection_dirs(coll_filter='ansible.builtin'))

    # list_collection_dirs('/var/lib/ansible/ansible_collections/ansible/builtin')
    #

# Generated at 2022-06-22 19:23:17.965124
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # on python2 we can't use the module variable display, because it is unicode, and
    # that causes a unicode error when rendering the template in dedent
    disp = Display()


# Generated at 2022-06-22 19:23:27.052547
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    colls = list(list_collection_dirs(search_paths=['/tmp'], coll_filter='namespace.collection'))
    assert len(colls) == 1

    colls = list(list_collection_dirs(search_paths=['/tmp1', '/tmp2'], coll_filter='namespace.collection'))
    assert len(colls) == 2

    colls = list(list_collection_dirs(search_paths=['/tmp'], coll_filter='namespace'))
    assert len(colls) == 1

    colls = list(list_collection_dirs(search_paths=['/tmp1', '/tmp2'], coll_filter='namespace'))
    assert len(colls) == 2


# Generated at 2022-06-22 19:23:32.972662
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    CollectionFinder= collections.namedtuple('CollectionFinder', ['coll1', 'coll2', 'coll3', 'coll4'])
    valid_collections = CollectionFinder(coll1='/home/test/my_collections',
                                         coll2='/home/test/library/ansible_collections',
                                         coll3='/usr/share/ansible/collections',
                                         coll4=None)
    search_paths = [valid_collections.coll1, valid_collections.coll2, valid_collections.coll3, valid_collections.coll4]
    for path in list_valid_collection_paths(search_paths):
        assert path in search_paths


# Generated at 2022-06-22 19:23:41.302641
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test without specified search paths
    paths = list(list_valid_collection_paths())
    assert len(paths) >= 1

    # Test with specified search paths
    mypaths = ["/tmp/does_not_exist", "/tmp/not_a_dir", "/usr/share/ansible/"]
    paths = list(list_valid_collection_paths(search_paths=mypaths))
    assert len(paths) >= 1



# Generated at 2022-06-22 19:23:53.678217
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with default
    paths = list(list_valid_collection_paths())
    assert len(paths) > 0

    # Test with bogus path
    paths = list(list_valid_collection_paths(['/not/valid']))
    assert len(paths) == 0

    # Test with valid and invalid paths
    paths = list(list_valid_collection_paths(['/usr/share/ansible/collections', '/not/valid']))
    assert len(paths) == 1
    assert paths[0] == '/usr/share/ansible/collections'

    # Test with valid paths
    paths = list(list_valid_collection_paths(['/usr/share/ansible/collections', '/usr/share/ansible']))
    assert len(paths) == 2

# Generated at 2022-06-22 19:24:04.770285
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import COLLECTIONS_PATHS
    from ansible.config.manager import ConfigManager

    (result, error) = ConfigManager.load()
    if error is not None:
        raise Exception("Expected no errors, received %s" % error)

    default = [x.rstrip('/') for x in COLLECTIONS_PATHS]
    paths_tuple = (tuple(default), tuple(default) + ('/etc/ansible/collections',))

    def assert_collection_paths(paths, expected):
        for x in list_collection_dirs(paths):
            assert x in expected

    assert_collection_paths(None, paths_tuple[1])
    assert_collection_paths([], paths_tuple[1])
    assert_collection_paths

# Generated at 2022-06-22 19:24:15.488266
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.collection_loader import find_collection_in_search_paths

    # present in legacy-only dir, should not be found
    legacy_coll_dir = 'test/integration/ansible_collections/old_namespace/collection1/'

    # present in new-namespace dir
    new_coll_dir = 'test/integration/ansible_collections/new_namespace/collection1/'

    # present in both legacy and new namespace dirs
    duplicate_coll_dir = 'test/integration/ansible_collections/new_namespace/collection2/'

    found_legacy_dirs = []
    found_new_dirs = []
    found_dup_dirs = []

# Generated at 2022-06-22 19:24:20.230236
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    from tempfile import mkdtemp
    from shutil import copytree, rmtree

    coll_source_path = os.path.join(os.path.dirname(__file__), u'../data/collections')
    coll_root_path = mkdtemp()
    shutil.copytree(coll_source_path, coll_root_path)

    expected_namespace = os.path.basename(coll_source_path)
    expected_collection_list = os.listdir(os.path.join(coll_root_path, expected_namespace))

    # Test passing single custom path
    coll_paths = [coll_root_path]
    collection_list = [os.path.basename(c) for c in list_collection_dirs(coll_paths)]
    assert expected_collection

# Generated at 2022-06-22 19:24:30.070053
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    cwd = os.getcwd()
    try:
        os.chdir(os.path.join(os.path.dirname(__file__), '..', '..'))
        coll_dirs = list(list_collection_dirs(['test/units/utils/fixtures/ansible_collections/']))
        coll_dirs = dict([os.path.splitext(os.path.basename(dir)) for dir in coll_dirs])
        assert coll_dirs == {
            'ns1.coll1': '',
            'ns1.coll2': '.tar.gz',
            'ns2.coll2': '.tar.bz2',
            'ns2.coll1': '.tar.gz',
        }
    finally:
        os.chdir(cwd)

# Generated at 2022-06-22 19:24:33.713940
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # return paths for the specific collections found in passed or configured search paths
    # search_paths: list of text-string paths, if none load default config
    # coll_filter: limit collections to just the specific namespace or collection, if None all are returned
    # return: list of collection directory paths
    pass


# Generated at 2022-06-22 19:24:37.024466
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/tmp/ansible_collections']) == ['/tmp/ansible_collections']
    assert list_valid_collection_paths(['/tmp/ansible_collections', '/does/not/exist']) == ['/tmp/ansible_collections']

# Generated at 2022-06-22 19:24:45.695089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs() with different parameters
    """

    import tempfile
    import shutil

    tmp_path = tempfile.mkdtemp(prefix='ansible_test_')
    c1_path = os.path.join(tmp_path, 'ansible_collections/c1/test')
    os.makedirs(c1_path)
    shutil.copy2(__file__, os.path.join(c1_path, '__init__.py'))
    c2_path = os.path.join(tmp_path, 'ansible_collections/c2/test')
    os.makedirs(c2_path)
    shutil.copy2(__file__, os.path.join(c2_path, '__init__.py'))
    c3

# Generated at 2022-06-22 19:24:53.872640
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    This test validates that the expected collection paths are loaded.
    """
    expected_paths = ['/etc/ansible/collections', '/usr/share/ansible/collections', '/usr/local/share/ansible/collections',
                      '/var/lib/ansible/collections',
                      u'~/.ansible/collections', './collections', '~/.ansible/collections/ansible/']
    assert set(list_valid_collection_paths(warn=False)) == set(expected_paths)

# Generated at 2022-06-22 19:25:02.181866
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    local_paths = []
    invalid_paths = []
    valid_paths = []
    with tempfile.TemporaryDirectory() as tmpdir:
        valid_paths.append(tmpdir)
        # invalid paths
        invalid_paths.append('')
        invalid_paths.append('/not/likely/a/path')
        for path in list_valid_collection_paths(search_paths=invalid_paths, warn=True):
            assert(False)  # pragma: no cover
        # valid paths and defaults
        for path in list_valid_collection_paths(search_paths=valid_paths, warn=False):
            assert(path == tmpdir)

# Generated at 2022-06-22 19:25:12.810500
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    # create a temporary collection directory first
    tempdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tempdir, 'ansible_collections'))
    os.mkdir(os.path.join(tempdir, 'ansible_collections', 'my_namespace'))
    os.mkdir(os.path.join(tempdir, 'ansible_collections', 'my_namespace', 'my_collection'))
    os.mkdir(os.path.join(tempdir, 'ansible_collections', 'my_namespace', 'my_collection', 'plugins'))

# Generated at 2022-06-22 19:25:21.078281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    func = list_collection_dirs()
    func = sorted(func)

# Generated at 2022-06-22 19:25:32.469328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # These are the collections in the two subdirs
    expected = {
        'ansible_collections/co/test1': 'test1',
        'ansible_collections/co/test2': 'test2',
        'ansible_collections/co/test1/test3': 'test3',
        'ansible_collections/co/test1/test4': 'test4',
        'ansible_collections/co_new': None,
    }

    path = os.path.dirname(__file__)
    test_dirs = os.path.join(path, '..', '..', '..', 'test', 'sanity', 'collection_dirs')


# Generated at 2022-06-22 19:25:36.370925
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = [
        '/usr/share/ansible',
        os.environ.get('ANSIBLE_COLLECTIONS_PATHS', '~/.ansible/collections'),
        os.path.expanduser('~/.ansible/collections'),
        os.environ.get('ANSIBLE_ROLES_PATH'),
        '/usr/share/ansible/collections',
        os.path.expanduser('~/ansible/collections'),  # CI testing support
    ]
    coll_dirs = list(list_collection_dirs(dirs))
    assert os.path.exists(coll_dirs[0])

# Generated at 2022-06-22 19:25:47.235448
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    my_mock_path = '/tmp/collections'
    mock_path_coll = os.path.join(my_mock_path, 'ansible_collections')
    mock_namespaces = ['very', 'big', 'namespaces', 'are', 'the', 'best']
    mock_collections = ['my', 'first', 'collection', 'my', 'second', 'collection', 'my', 'third', 'collection']


# Generated at 2022-06-22 19:25:52.414100
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Unit test for function list_valid_collection_paths
    :return:
    '''

    # test good path
    search_paths = []
    for path in list_valid_collection_paths(search_paths):
        assert path == '~/.ansible/collections'

    # test bad path
    search_paths = ['/bad_path']
    assert len(list_valid_collection_paths(search_paths)) == 1

    # test non-existent path
    search_paths = ['/also_bad_path']
    assert len(list_valid_collection_paths(search_paths)) == 0



# Generated at 2022-06-22 19:26:01.181367
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_path = os.path.expanduser('~/.ansible/collections')
    b_test_path = to_bytes(test_path, errors='surrogate_or_strict')

    assert [x for x in list_collection_dirs([test_path])]

    assert list_collection_dirs([test_path, b_test_path])

    assert list_collection_dirs([test_path], coll_filter='ansible_collections'), 'collection not found'
    # assert list_collection_dirs([test_path], coll_filter='ansible_collections2'), 'filter error'

    assert list_collection_dirs([test_path], coll_filter='ansible_collections.community'), 'namespace not found'
    # assert list_collection_dirs([test_path], coll_filter='ans

# Generated at 2022-06-22 19:26:06.642426
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    We test that the function list_valid_collection_paths returns
    the same list when called with a list of paths.
    """

    with_config_paths = list_valid_collection_paths(warn=False)
    without_config_paths = list_valid_collection_paths(AnsibleCollectionConfig.collection_paths, warn=False)

    assert with_config_paths == without_config_paths

# Generated at 2022-06-22 19:26:09.498930
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    test defaults
    """

    collector = list_valid_collection_paths()
    assert isinstance(collector, type(list_valid_collection_paths()))
    assert next(collector) is not None



# Generated at 2022-06-22 19:26:13.336940
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=[os.path.expanduser("~/.ansible/collections"), '/foo/bar/baz'])) == \
        [os.path.expanduser("~/.ansible/collections")]



# Generated at 2022-06-22 19:26:21.634010
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import unittest
    import shutil
    import tempfile
    import ansible.collections.ansible_collections

    # imports required for test, part of release
    import ansible.collections.cloud.azure
    import ansible.collections.community.general


# Generated at 2022-06-22 19:26:32.601170
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test when no search_paths passed
    search_paths = []
    valid_paths = list_valid_collection_paths(search_paths)
    assert 'test/test_collections/ansible_collections' not in valid_paths
    assert 'test/test_collections/legacy' not in valid_paths
    assert 'test/test_collections/not_collections' not in valid_paths

    # Test when search_paths passed
    search_paths = ['test/test_collections/ansible_collections',
                    'test/test_collections/legacy',
                    'test/test_collections/not_collections']
    valid_paths = list_valid_collection_paths(search_paths)

# Generated at 2022-06-22 19:26:40.203180
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Ensure the list_valid_collection_paths function returns expected output """

    # "normal" use case
    result = ['/var/lib/ansible/collections']
    assert list(list_valid_collection_paths(search_paths=result)) == result
    # search path list includes missing entry
    result.append('/tmp/does-not-exist')
    assert list(list_valid_collection_paths(search_paths=result)) == ['/var/lib/ansible/collections']
    # search path list has a file instead of a directory
    result.remove('/tmp/does-not-exist')
    result.append('/bin/ls')
    assert list(list_valid_collection_paths(search_paths=result)) == ['/var/lib/ansible/collections']
    #

# Generated at 2022-06-22 19:26:52.353895
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # set up collections
    collections_paths = []
    file_one = tempfile.NamedTemporaryFile(delete=False)
    file_two = tempfile.NamedTemporaryFile(delete=False)
    file_three = tempfile.NamedTemporaryFile(delete=False)
    dir_one = tempfile.mkdtemp(dir=tmpdir)
    dir_two = tempfile.mkdtemp(dir=tmpdir)

    collections_paths.extend([file_one.name, file_two.name, file_three.name, dir_one])

# Generated at 2022-06-22 19:27:00.473041
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    path = tempfile.mkdtemp()
    b_path = to_bytes(path, errors='surrogate_or_strict')
    os.mkdir(b_path)
    file_path = os.path.join(b_path, 'test_file')
    with open(file_path, 'w') as f:
        f.write('test')
    assert list(list_valid_collection_paths([path])) == [path]
    shutil.rmtree(path)



# Generated at 2022-06-22 19:27:09.572180
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import copytree, copyfile, rmtree

    # Create a temporary collection directory with a single collection
    temp_coll_root = tempfile.mkdtemp(prefix='ansible-collections-tmp')
    temp_coll_src = os.path.join(temp_coll_root, 'ansible_collections/dummy/test')
    temp_coll_dest = os.path.join(temp_coll_root, 'ansible_collections/dummy/test')

# Generated at 2022-06-22 19:27:20.814511
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    b_tempdir = to_bytes(tempfile.mkdtemp(dir='.'))


# Generated at 2022-06-22 19:27:31.746712
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = ['/path/to/ansible/collections']

    # patch the filesystem to return one namespace and two collections
    import unittest.mock as mock
    mock_listdir = mock.Mock(side_effect=[[], ['namespace1'], ['collection1', 'collection2']])
    with mock.patch("os.path.exists", return_value=True):
        with mock.patch("os.path.isdir", return_value=True):
            with mock.patch("os.listdir", mock_listdir):
                for collection_dir in list_collection_dirs(collection_paths, None):
                    assert collection_dir == '/path/to/ansible/collections/namespace1/collection1'
                    break

    # patch the filesystem to return two namespaces and two collections
    mock

# Generated at 2022-06-22 19:27:43.524043
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.errors import AnsibleError
    from tempfile import mkdtemp
    import shutil
    test_dir = mkdtemp()
    test_dir_collections = []
    test_dir_collections.append(test_dir)
    test_dirs = ['test_ns1', 'test_ns2']
    test_collections = ['test_coll1', 'test_coll2']
    for dir in test_dirs:
        for collection in test_collections:
            test_dir_collections.append(os.path.join(dir, collection))
    test_bad_coll = 'test_bad_coll'
    test_bad_coll_dir = os.path.join(test_dir, test_bad_coll)
    test_bad_ns = 'test_bad_ns'
    test_bad

# Generated at 2022-06-22 19:27:54.051011
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_collection_paths
    from ansible.module_utils.common._collections_compat import CollectionLoader, list_collection_names

    # override local collection paths
    list_collection_paths(['/tmp', '/no_such_path'])
    assert list_valid_collection_paths(warn=True) == ['/tmp']
    assert not list_collection_names()

    # add to local paths
    add_coll = os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_config', 'collection_override')
    list_collection_paths(search_paths=[add_coll])
    assert list_valid_collection_paths(warn=True) == ['/tmp', add_coll]

# Generated at 2022-06-22 19:28:02.442666
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import makedirs
    from os.path import join

    tmp_dir = to_bytes(mkdtemp())
    bad_path = join(tmp_dir, b'test_path')
    good_path = join(tmp_dir, b'test_path2')
    makedirs(good_path)

# Generated at 2022-06-22 19:28:06.308670
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    colls = list(list_collection_dirs(["/tmp/fake_ansible_collections_dir"]))
    assert len(colls) == 0
    assert type(colls) is list
    assert type(colls[0]) is str

# Generated at 2022-06-22 19:28:12.798847
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test default paths
    paths = list(list_valid_collection_paths())
    assert len(paths) == 0

    # test absolute paths
    paths = list(list_valid_collection_paths(['/does/not/exist']))
    assert len(paths) == 0
    # test valid paths
    paths = list(list_valid_collection_paths(['/']))
    assert len(paths) == 1
    # test multiple paths
    paths = list(list_valid_collection_paths(['/', '/etc', '/usr']))
    assert len(paths) == 3


# Generated at 2022-06-22 19:28:23.918523
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from tests.support.unit import TestCase
    from tests.support.unit import load_fixture
    from ansible.utils import context_objects as co
    from ansible.playbook.play_context import PlayContext

    class TestListCollectionDirs(TestCase):

        def setUp(self):
            super(TestListCollectionDirs, self).setUp()
            self.test_dir = self.tmpdir()

            data = load_fixture('list_collections_data.json')
            co.GlobalCLIArgs._store = data['cli_args']
            co.GlobalCLIArgs._store['collections_paths'] = []
            co.GlobalCLIArgs._store['collections_paths'].append(self.test_dir)

            self.context_obj = PlayContext()
            self.context_obj.col

# Generated at 2022-06-22 19:28:32.472638
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections import get_collection_paths
    from ansible.utils.path import unfrackpath

    assert list_valid_collection_paths(['/dev/null']) == []

    (old_load_paths, new_load_paths) = get_collection_paths()

    for path in new_load_paths:
        path = unfrackpath(path)
        assert os.path.exists(path)
        assert os.path.isdir(path)

    assert list_valid_collection_paths(new_load_paths) == new_load_paths

    paths = new_load_paths + ['/dev/null']
    assert list_valid_collection_paths(paths) == new_load_paths



# Generated at 2022-06-22 19:28:34.409425
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['a', 'b', 'c'])) == ['a', 'b', 'c']
    assert list(list_valid_collection_paths('a')) == ['a']


# Generated at 2022-06-22 19:28:40.637899
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # no filter
    all_collections = list(list_collection_dirs())
    assert len(all_collections) > 0

    ansible_collections = list(list_collection_dirs(coll_filter='ansible'))
    assert len(ansible_collections) == 1
    assert os.path.basename(ansible_collections[0]) == 'ansible'

    ansible_collection_os_facts_collection = list(list_collection_dirs(coll_filter='ansible_facts.os'))
    assert len(ansible_collection_os_facts_collection) == 1
    assert os.path.basename(ansible_collection_os_facts_collection[0]) == 'os'

# Generated at 2022-06-22 19:28:46.645521
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:28:58.784537
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile, shutil
    from os.path import join
    from .test_utils import make_temp_path

    # TODO: pick a better path that doesn't have issues with different platforms
    tmp_path = make_temp_path(private=True)
    nspace = 'ansible_namespace'
    coll = 'my_first_collection'
    coll_path = join(tmp_path, 'ansible_collections', nspace, coll)
    os.makedirs(coll_path)
    os.makedirs(join(coll_path, 'plugins', 'action'))
    os.makedirs(join(coll_path, 'plugins', 'module'))
    os.makedirs(join(coll_path, 'plugins', 'lookup'))

# Generated at 2022-06-22 19:29:09.107694
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test to confirm that we can find default /home/ansible/.ansible/collections
    col_home = list(list_valid_collection_paths())
    assert col_home

    # Test to confirm that we do not find non-default non-existent path
    col_non_existent = list(list_valid_collection_paths(search_paths=[r'C:\does\not\exist']))
    assert col_non_existent == []

    # Test to confirm we find valid path even if default does not exist
    col_yes_default = list(list_valid_collection_paths(search_paths=['/usr/share/ansible/collections']))
    assert col_yes_default


# Generated at 2022-06-22 19:29:20.161099
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    from shutil import rmtree
    import sys
    import stat

    if sys.version_info[0] == 2:
        from unittest2 import TestCase
    else:
        from unittest import TestCase

    class ListCollectionDirsTest(TestCase):

        def setUp(self):
            # Create temp test dir
            self.test_root = mkdtemp()
            self.test_coll_dir = os.path.join(self.test_root, 'ansible_collections')
            self.test_namespace_dir1 = os.path.join(self.test_coll_dir, 'test_namespace1')
            self.test_namespace_dir2 = os.path.join(self.test_coll_dir, 'test_namespace2')
            self

# Generated at 2022-06-22 19:29:24.328960
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    good_paths = ['valid_dir', 'valid_dir_2']
    bad_paths = ['not_valid_dir']
    found = list(list_collection_dirs(search_paths=good_paths, coll_filter='namespace.collection'))
    if len(found):
        assert "namespace.collection" in found

# Generated at 2022-06-22 19:29:32.955693
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    coll_path = tempfile.mkdtemp(prefix='ansible_collections')
    coll_name = "test_namespace.test_collection"
    coll_root = os.path.join(coll_path, "ansible_collections")

    namespace = coll_name.split(".")[0]
    coll = coll_name.split(".")[1]

    os.makedirs(os.path.join(coll_root, namespace, coll, 'plugins'))
    os.makedirs(os.path.join(coll_root, namespace, coll, 'plugins', 'action'))
    os.makedirs(os.path.join(coll_root, namespace, coll, 'plugins', 'module'))


# Generated at 2022-06-22 19:29:40.531757
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths function
    """
    import tempfile
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import reload_module

    # clean up the module from our last run
    if hasattr(list_valid_collection_paths, 'tmpdir'):
        list_valid_collection_paths.tmpdir.cleanup()
    reload_module(list_valid_collection_paths)

    # create a temp directory which we can use to test
    list_valid_collection_paths.tmpdir = tempfile.TemporaryDirectory()

    # try with a valid directory
    paths = list_valid_collection_paths([list_valid_collection_paths.tmpdir.name])
    assert len(list(paths)) == 1

# Generated at 2022-06-22 19:29:45.931444
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == tuple(AnsibleCollectionConfig.collection_paths)
    assert list_valid_collection_paths([b'/etc/ansible/collections']) == \
        tuple(AnsibleCollectionConfig.collection_paths + [b'/etc/ansible/collections'])



# Generated at 2022-06-22 19:29:56.704774
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        '/tmp/a',
        '/tmp/b',
        '/tmp/c',
    ]

    for path in search_paths:
        # create some directories
        try:
            os.makedirs(path)
        except OSError:
            pass

    # there should be no collections
    test_collections = [i for i in list_collection_dirs(search_paths)]
    assert test_collections == []

    # create something that looks like a collection
    os.makedirs('%s/ansible_collections/acme/baz' % search_paths[0])

    # there should be one collection
    test_collections = [i for i in list_collection_dirs(search_paths)]
    assert len(test_collections) == 1


# Generated at 2022-06-22 19:30:01.023316
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([u'test', u'hello']) == []
    # NOTE: this test will fail if the directory /tmp/ansible/test exists on your system
    assert list_valid_collection_paths([u'test', u'/tmp/ansible/test']) == [u'/tmp/ansible/test']


# Generated at 2022-06-22 19:30:06.898976
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.test.unit.compat.mock import patch, MagicMock
    from ansible.collections.ansible.builtin import get_builtin_collection_path

    my_list_valid_collection_paths = list(list_valid_collection_paths(search_paths=['no_exist', 'no_exist2']))
    assert len(my_list_valid_collection_paths) == 1

    test_builtin_path = get_builtin_collection_path()
    assert test_builtin_path in my_list_valid_collection_paths

    # test that non-collection dirs are skipped