

# Generated at 2022-06-22 19:20:13.472470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    coll_paths = ['/does/not/exist/1', '/does/not/exist/2']

    # returns empty list if search_paths is None
    assert list(list_valid_collection_paths()) == []

    # returns empty list if no paths exist or are dir
    assert list(list_valid_collection_paths(search_paths=coll_paths)) == []

    # default search_paths is returned if no search_paths are supplied
    assert list(list_valid_collection_paths(search_paths=[])) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:20:23.172060
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that list_collection_dirs is behaving as expected
    """

    coll_dirs = list_collection_dirs(coll_filter='myns.mycoll')
    assert len(list(coll_dirs)) == 0

    # create test namespaces in a temp folder
    import os
    import tempfile
    import shutil

    temp_folder = tempfile.mkdtemp()
    print('### Testing in temp_folder: ', temp_folder)

    os.makedirs(os.path.join(temp_folder, 'myns', 'mycoll', 'plugins'))
    os.makedirs(os.path.join(temp_folder, 'myns', 'mycoll2', 'plugins'))

# Generated at 2022-06-22 19:20:31.620839
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_list = list(list_collection_dirs())
    print(coll_list)
    assert coll_list

    coll_list = list(list_collection_dirs(coll_filter='ansible'))
    print(coll_list)
    assert coll_list

    coll_list = list(list_collection_dirs(coll_filter='ansible.builtin'))
    print(coll_list)
    assert coll_list

    coll_list = list(list_collection_dirs(coll_filter='ansible_fake.fake'))
    print(coll_list)
    assert not coll_list

# Generated at 2022-06-22 19:20:40.034364
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert set(list_valid_collection_paths(search_paths=[])) == set(list_valid_collection_paths())

    search_paths = ['/tmp/fake-collections-dir',
                    '/non-existant-path',
                    '/usr/share/ansible/collections']

    assert set(list_valid_collection_paths(search_paths=search_paths)) == set(['/usr/share/ansible/collections'])
    assert set(list_valid_collection_paths(search_paths=search_paths, warn=True)) == set(['/usr/share/ansible/collections'])



# Generated at 2022-06-22 19:20:49.760495
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    INPUT_PATHS = [
        '/path/that/does/not/exist:/path/that/is/not/a/dir:/path/that/is/a/dir',
        '/etc/ansible',
    ]
    EXPECT_PATHS = ['/path/that/is/a/dir', '/etc/ansible']

    # use first element in list as the directory
    os.mkdir(to_bytes(EXPECT_PATHS[0]))

    assert(list(list_valid_collection_paths(search_paths=INPUT_PATHS)) == EXPECT_PATHS)

# Generated at 2022-06-22 19:21:01.651934
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_path = '/usr/share/ansible'
    bad_path = '/fake_path'
    coll_dirs = None

    # ensure no broken paths are returned
    coll_dirs = list(list_collection_dirs(search_paths=[bad_path], coll_filter='nonexistent.nonexistent'))
    assert len(coll_dirs) == 0

    # ensure the test_path is returned from default
    coll_dirs = list(list_collection_dirs())
    assert len(coll_dirs) > 0
    for dir in coll_dirs:
        assert test_path in dir

    # ensure the test_path is returned when passed a configured path
    coll_dirs = list(list_collection_dirs(search_paths=[test_path]))

# Generated at 2022-06-22 19:21:05.648758
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = [os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')]
    coll_dirs = list(list_collection_dirs(search_path))
    assert len(coll_dirs) == 1
    assert b"acme.test" in coll_dirs[0]

# Generated at 2022-06-22 19:21:13.570956
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.collections import default_collection_path, default_ansible_path


# Generated at 2022-06-22 19:21:19.559302
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Validate filtering of collection paths
    :return:
    """
    paths = ['/no_such/path', '/tmp', '/usr/share/ansible_collections']

    new_paths = list(list_valid_collection_paths(paths))

    assert 2 == len(new_paths)



# Generated at 2022-06-22 19:21:26.805267
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/etc/ansible/collections', '/home/user/.ansible/collections']
    search_paths.extend(AnsibleCollectionConfig.collection_paths)
    search_paths = list_valid_collection_paths(search_paths, True)
    assert '/home/user/.ansible/collections' not in search_paths
    assert '/etc/ansible/collections' in search_paths

# Generated at 2022-06-22 19:21:36.916053
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible_collections.testns.not_a_coll.tests.unit.compat import unittest
    from ansible_collections.testns.not_a_coll.tests.unit.compat.mock import patch

    def get_all_paths():
        return ['some/path', 'another/path', 'yet/another/path']

    def get_all_paths_shortened():
        return ['some/path', 'another/path']

    def get_all_paths_lengthed():
        return ['some/path', 'another/path', 'yet/another/path', 'new/path']


# Generated at 2022-06-22 19:21:41.059357
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/this/does/not/exist'])) == []
    assert list(list_valid_collection_paths(['/etc', '/this/does/not/exist'])) == ['/etc']



# Generated at 2022-06-22 19:21:47.644151
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import unittest
    import tempfile
    import shutil
    import os
    import sys

    _old_cwd = os.getcwd()

    class TestCollectionDirs(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.coll_dir = os.path.join(self.test_dir, 'ansible_collections')
            os.makedirs(self.coll_dir)
            os.chdir(self.test_dir)

        def tearDown(self):
            os.chdir(_old_cwd)
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-22 19:21:51.078931
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = [os.path.abspath(path) for path in list_collection_dirs()]
    assert os.path.join(os.path.dirname(__file__), '../../../') in coll_dirs

# Generated at 2022-06-22 19:21:52.510142
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert set(list_valid_collection_paths(["/some/path/that/does/not/exist", "/etc/ansible/collections", "/usr/share/ansible/collections"])) == set(["/etc/ansible/collections", "/usr/share/ansible/collections"])

# Generated at 2022-06-22 19:22:00.683033
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # empty path should return default paths
    assert list(list_valid_collection_paths([])) == AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths
    # warn for missing, but not if default
    assert list(list_valid_collection_paths(['/this/path/does/not/exist'])) == []
    # default collection path added to provided paths
    assert list_valid_collection_paths(['test_data/test_collections']) == ['test_data/test_collections'] + AnsibleCollectionConfig.collection_paths
    # replace default path collection path with provided path

# Generated at 2022-06-22 19:22:10.945235
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.six.moves import reload_module

    # Reload to reload the configuration file to default values
    reload_module(AnsibleCollectionConfig)

    collection_paths = AnsibleCollectionConfig.collection_paths

    # No directories, should be empty
    search_paths = ['a', 'b', 'c']
    valid_collection_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert not valid_collection_paths

    valid_collection_paths = list(list_valid_collection_paths(collection_paths, warn=False))
    assert len(valid_collection_paths) == len(collection_paths)

# Generated at 2022-06-22 19:22:15.103045
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the method based on the default search_paths
    :return: None
    """

    colls = list_collection_dirs()

    assert colls is not None
    assert len(list(colls)) > 0

# Generated at 2022-06-22 19:22:18.430609
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for coll_dir in list_collection_dirs(['test/unit/modules/test_collections/ansible_collections']):
        assert os.path.exists(coll_dir)

# Generated at 2022-06-22 19:22:27.704042
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    testpaths = ['/home/user1/collections',
                 '/home/user2/collections',
                 '/home/user3/collections'
                 ]

    existing_paths = set()
    for testpath in testpaths:

        # create test directory if not exists
        os.makedirs(testpath, mode=0o600, exist_ok=True)
        existing_paths.add(testpath)

    for testpath in testpaths:

        # try removing path
        os.rmdir(testpath)
        try:
            os.remove(testpath)
        except:
            # ignore non file errors
            pass
        try:
            os.remove(testpath + '.txt')
        except:
            # ignore non file errors
            pass


# Generated at 2022-06-22 19:22:35.828290
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert to_bytes(list(list_collection_dirs('terraform.is')), errors='surrogate_or_strict') == b'string'
    assert to_bytes(list(list_collection_dirs(['terraform.is'])), errors='surrogate_or_strict') == b'string'
    assert to_bytes(list(list_collection_dirs('terraform.is', 'terraform.is')), errors='surrogate_or_strict') == b'string'
    assert to_bytes(list(list_collection_dirs(['terraform.is'], 'terraform.is')), errors='surrogate_or_strict') == b'string'

# Generated at 2022-06-22 19:22:42.277608
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_collection_dirs = list(list_collection_dirs(['test_collections']))

    assert len(test_collection_dirs) == 2

    assert os.path.realpath('test_collections/ansible_collections/foo/bar') in test_collection_dirs
    assert os.path.realpath('test_collections/ansible_collections/foo/baz') in test_collection_dirs

# Generated at 2022-06-22 19:22:45.709496
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/foo', '/bar']) == ['/foo', '/bar']
    assert list_valid_collection_paths(['/foo', '/usr/share', '/bar']) == ['/foo', '/usr/share', '/bar']


# Generated at 2022-06-22 19:22:56.059921
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp()
    coll_dir = os.path.join(tempdir, 'ansible_collections')
    os.mkdir(coll_dir)
    os.mkdir(os.path.join(coll_dir, 'mynamespace'))
    os.mkdir(os.path.join(coll_dir, 'mynamespace', 'mycollection'))
    os.mkdir(os.path.join(coll_dir, 'mynamespace', 'myothercollection'))
    os.mkdir(os.path.join(coll_dir, 'myothernamespace'))
    os.mkdir(os.path.join(coll_dir, 'myothernamespace', 'mycollection'))

# Generated at 2022-06-22 19:23:02.127160
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert set(list_collection_dirs()) == set(list_valid_collection_paths())

    assert list_collection_dirs('/not/real/path') == []

    assert list_collection_dirs('/tmp/ansible_collections') == []

    assert list_collection_dirs(coll_filter='foobar') == []

    assert list_collection_dirs(coll_filter='foobar.baz') == []

# Generated at 2022-06-22 19:23:14.777633
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    all_collections = list(list_collection_dirs())
    assert len(all_collections) > 0
    assert 'ansible' in all_collections[0]
    assert 'basic' in all_collections[0]

    this_collection = list(list_collection_dirs(coll_filter='ansible.basic'))
    assert len(this_collection) == 1
    assert 'ansible' in this_collection[0]
    assert 'basic' in this_collection[0]

    this_namespace = list(list_collection_dirs(coll_filter='ansible'))
    assert len(this_namespace) > 1
    assert 'ansible' in this_namespace[0]
    assert 'basic' in this_namespace[0]


# Generated at 2022-06-22 19:23:24.414033
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)
    assert list(list_valid_collection_paths([])) == list(AnsibleCollectionConfig.collection_paths)
    search_paths = [
        '/var/local/ansible_collections',
        '~/my_collections',
        '/var/remote/collections',
    ]
    assert list(list_valid_collection_paths(search_paths)) == list(AnsibleCollectionConfig.collection_paths) + [
        '/var/local/ansible_collections',
        '/var/remote/collections',
    ]



# Generated at 2022-06-22 19:23:29.467014
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths

    search_paths = [
        "/tmp/does_not_exist",
        "/etc/ansible/collection/does_not_exist",
        "/etc/ansible/collection",
        "/etc/ansible/does_not_exist",
        "/etc/ansible",
        "/etc_ansible_collection_does_not_exist",
    ]
    result = list_valid_collection_paths(search_paths, warn=True)
    assert list(result) == [
        "/etc/ansible/collection",
        "/etc/ansible",
    ]

# Generated at 2022-06-22 19:23:32.610226
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list_collection_dirs()
    assert len(dirs) > 0
    assert isinstance(dirs, type(list))

# Generated at 2022-06-22 19:23:43.474095
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test listing of collection directories (including namespaces)
    """
    import ansible_collections.satellite.test.plugins.module_utils.test_collection_dirs as test_dirs

    collection_dir = test_dirs.get_test_dir()
    assert collection_dir is not None

    # Enumerate collections and namespaces
    for coll_dir in list_collection_dirs([collection_dir]):
        assert coll_dir == test_dirs.get_test_coll_dir()

    for coll_dir in list_collection_dirs([collection_dir], 'satellite'):
        assert coll_dir == test_dirs.get_test_coll_dir()

    for coll_dir in list_collection_dirs([collection_dir], 'satellite.test'):
        assert coll_dir == test

# Generated at 2022-06-22 19:23:54.108719
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:24:04.909684
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test search paths: None, empty, non-list, non-text
    paths = [None, [], [1], [{}]]
    for path in paths:
        search_paths = list_valid_collection_paths(search_paths=path)
        assert len(search_paths) == len(AnsibleCollectionConfig.collection_paths)

    # test search paths: bad text path

# Generated at 2022-06-22 19:24:14.349397
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    failed = False

    with tempfile.TemporaryDirectory() as test_coll_path1:

        with tempfile.TemporaryDirectory(dir=test_coll_path1) as test_coll_path2:
            # Test default (built in /usr/share/ansible/collections and ~/.ansible/collections)
            test_coll_dirs = list(list_collection_dirs())
            if len(test_coll_dirs) < 1:
                failed = True
                display.error('Failed on test_coll_dirs with default settings.')

            # Test only existent dir
            test_coll_dirs = list_collection_dirs([test_coll_path1])
            if len(test_coll_dirs) != 1:
                failed = True

# Generated at 2022-06-22 19:24:19.543757
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test missing collection path
    search_paths = ["/does/not/exist"]
    result = list(list_valid_collection_paths(search_paths))
    assert result == []

    # Test existing collection path
    search_paths = ["/usr/share/ansible/collections"]
    result = list(list_valid_collection_paths(search_paths))
    assert result == ['/usr/share/ansible/collections']

    # Test existing invalid collection path
    search_paths = ["/usr/share/ansible/collections/test.yml"]
    result = list(list_valid_collection_paths(search_paths))
    assert result == []

    # Test existing invalid collection path with warnings enabled

# Generated at 2022-06-22 19:24:29.425324
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import random

    tmp_collections_root = tempfile.mkdtemp()

    # add some nested fake namespaces/collections under the temp root path
    namespace_count = random.randint(1, 5)
    for x in range(namespace_count):
        tmp_namespace = 'test_namespace%s' % (x)
        tmp_namespace_path =  os.path.join(tmp_collections_root, 'ansible_collections', tmp_namespace)
        os.makedirs(tmp_namespace_path)

        # for each namespace add a collection and non collection dir
        collection_count = random.randint(1, 5)
        for y in range(collection_count):
            tmp_collection = 'test_collection%s' % (y)


# Generated at 2022-06-22 19:24:36.861904
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This unit test iterates over all files in the test_data collection and checks
    if the dir path is returned.
    """

    # To keep the test simple, we'll only check if 1 expected collection dir is
    # returned from the function.
    # This collection was not in the default paths, but we still have to load
    # the default paths in order to test the function

    search_paths = list_valid_collection_paths()
    assert len(search_paths) > 0

    # the collection dir is not in default search_path, so add it to a list
    search_paths.append('../../')
    collection_file_path = "../../ansible_collections/ansible/test_collection/plugins/modules/collection_test_module.py"
    # collection dir is returned from list_collection_dirs

# Generated at 2022-06-22 19:24:45.585600
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_paths = [
        '/usr/share',
        '/my/collection/path',
    ]

    collections = list(list_collection_dirs(collection_paths, coll_filter='myns.mycoll'))
    assert len(collections) == 1
    assert collections == [b'/my/collection/path/ansible_collections/myns/mycoll']

    collections = list(list_collection_dirs(collection_paths, coll_filter='myns'))
    assert len(collections) == 1
    assert collections == [b'/my/collection/path/ansible_collections/myns/mycoll']

    collections = list(list_collection_dirs(collection_paths, coll_filter=None))
    assert len(collections) == 1

# Generated at 2022-06-22 19:24:49.881405
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    if all search path is valid
    '''
    search_path = ['/path1', '/path2']
    assert list_valid_collection_paths(search_path) == search_path

# Generated at 2022-06-22 19:24:59.272804
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
        Unit test for list_collection_dirs function
    """

    # Create test files and directories
    collection_root_path = '/tmp/test_list_collection_dirs'
    namespaced_collection_path = os.path.join(collection_root_path, 'namespace_1.collection_1')
    os.makedirs(namespaced_collection_path)

    # Test for only namespace_1.collection_1 to be returned
    for collection_path in list_collection_dirs(search_paths=[collection_root_path], coll_filter='namespace_1.collection_1'):
        assert collection_path == namespaced_collection_path

    # Test for everything to be returned
    for collection_path in list_collection_dirs(search_paths=[collection_root_path]):
        assert collection_

# Generated at 2022-06-22 19:25:01.275757
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    valid_paths = []
    for path in list_collection_dirs():
        valid_paths.append(path)
    assert valid_paths

# Generated at 2022-06-22 19:25:08.948032
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # check with existing dirs
    search_paths = [
      'one/collection/root',
      'two/collection/roots',
      'three/collection/roots',
      'not/a/dir',
      'also/not/a/dir',
    ]

    for path in search_paths:
        assert os.path.exists(path)
        assert os.path.isdir(path)

    # check defaults
    assert len(list_valid_collection_paths()) > 0

    # get existing paths
    paths = list_valid_collection_paths(search_paths)
    assert len(paths) == 3


# Generated at 2022-06-22 19:25:13.480254
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common._collections_compat import Path

    search_path = ['./test/test_collections/','test/test_collections/','/not/existing/path/', '.']

    for p in ['.', 'test/test_collections/']:
        assert Path(p).absolute() in [Path(x).absolute() for x in list_valid_collection_paths(search_path)]

    # assert no invalid paths
    assert not [x for x in list_valid_collection_paths(search_path)]

# Generated at 2022-06-22 19:25:17.825072
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_collections = 'test/unit/sanity/code/rsrc/collections'
    test_collections_paths = [test_collections]

    exp_coll = []
    for collection in list_collection_dirs(test_collections_paths):
        exp_coll.append(collection)

    assert len(exp_coll) == 3

# Generated at 2022-06-22 19:25:20.067870
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Check if there are two paths in list_valid_collection_paths()
    """

    test_paths = list(list_valid_collection_paths())
    assert len(test_paths) == 2

# Generated at 2022-06-22 19:25:31.328513
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import to_text
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from ansible.module_utils.common.file import is_executable
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test with no search_paths
    search_paths = None
    coll_filter = None
    coll_dirs = {}
    for path in list_collection_dirs(search_paths, coll_filter):
        coll_dirs[to_text(os.path.dirname(path))] = path


# Generated at 2022-06-22 19:25:38.502853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils import basic
    import sys
    args = basic.AnsibleModule(argument_spec={})
    search_paths = sys.argv[1].split(",")
    coll_filter = sys.argv[2]
    collections = list(list_collection_dirs(search_paths, coll_filter))
    args.exit_json(changed=False, collections=collections)


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:25:48.362711
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    path_test_data = [
        ('test/test', True, True),
        ('test/test', False, False),
        ('test/test/test', True, False),
        ('test', True, True),
        ('test', False, True),
        ('test/../test', True, True),
        ('test/../test', False, False),
        ('test/../test/test', True, False),
        ('../test', True, True),
    ]

    for path, warn, expect_success in path_test_data:

        if os.path.exists(path):
            os.remove(path)

        f = open(path, 'a')
        f.close()

        gen = list_valid_collection_paths([path], warn)

        for p in gen:
            assert os.path.realpath

# Generated at 2022-06-22 19:26:00.262852
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config.manager import ConfigManager
    from ansible.cli import CLI

    cli = CLI(config=ConfigManager())
    cli.options.collections_paths = ['/tmp/collection_loader_test']
    dirs = list(list_collection_dirs(coll_filter='namespace.collection'))
    assert dirs[0].endswith(b'/tmp/collection_loader_test/ansible_collections/namespace/collection')

    dirs = list(list_collection_dirs(coll_filter='namespace'))
    assert len(dirs) == 2
    assert dirs[0].endswith(b'/tmp/collection_loader_test/ansible_collections/namespace/coll1')

# Generated at 2022-06-22 19:26:06.115037
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # This should find collection_dir
    collection_dirs = list(list_collection_dirs(['test/utils/fixtures/collection_path']))
    assert collection_dirs == ['test/utils/fixtures/collection_path/ansible_collections/collection_filter/collection']

    # No such path
    collection_dirs = list(list_collection_dirs(['test/utils/fixtures/collection_path_not_exists']))
    assert collection_dirs == []

# Generated at 2022-06-22 19:26:15.412363
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = []

    # first check if default paths exist
    for path in list_valid_collection_paths():
        # do not pollute os environ paths
        if path not in os.environ.get('ANSIBLE_COLLECTIONS_PATHS', []):
            test_paths.append(path)

    assert set(test_paths) == {'/usr/share/ansible/collections'}, 'Default collection paths not found'

    # insert a path that does not exist
    test_paths.append("/BAD_PATH")

    # filter out bad path
    filtered_paths = list_valid_collection_paths(search_paths=test_paths)


# Generated at 2022-06-22 19:26:22.917867
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # 1 - Ensure we do not get paths that do not exist, or are not dirs
    search_paths = [
        "/this/path/does/not/exist",
        "/this/is/a/file",
        "./these/paths/are/valid",
        "../these/paths/are/valid",
    ]
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2
    assert valid_paths[0] == "./these/paths/are/valid"
    assert valid_paths[1] == "../these/paths/are/valid"

    # 2 - Validate the default search paths
    valid_paths = list(list_valid_collection_paths())
    assert len(valid_paths)

# Generated at 2022-06-22 19:26:27.569852
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # invalid
    assert [] == list(list_valid_collection_paths([None, 0, '']))
    # valid
    assert ['foo'] == list(list_valid_collection_paths(['foo'], warn=False))
    # must exist
    assert [] == list(list_valid_collection_paths(['bar'], warn=False))
    # defaults
    assert ['foo'] == list(list_valid_collection_paths([], warn=False))

# Generated at 2022-06-22 19:26:31.703111
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # list_valid_collection_paths() should return valid search paths only
    assert list_valid_collection_paths()
    assert list_valid_collection_paths(search_paths=["/tmp/dir_not_exist", "/usr/local/lib/asnible_collections"])

# Generated at 2022-06-22 19:26:39.122184
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader.search_paths import list_collection_dirs

    # Test with single collection
    search_paths=['/tmp']
    coll_filter='acme.my_collection'
    result = list(list_collection_dirs(search_paths, coll_filter=coll_filter))
    assert (result == [b'/tmp/ansible_collections/acme/my_collection'])

    # Test with multiple collections
    search_paths=['/tmp']
    coll_filter=None
    result = list(list_collection_dirs(search_paths, coll_filter=coll_filter))
    assert (result == [b'/tmp/ansible_collections/acme/my_collection', b'/tmp/ansible_collections/acme/another_collection'])

   

# Generated at 2022-06-22 19:26:51.175552
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile, shutil

    test_ns1 = tempfile.mkdtemp()
    test_ns2 = tempfile.mkdtemp()
    test_ns3 = tempfile.mkdtemp(dir=test_ns1)
    test_coll1 = tempfile.mkdtemp(dir=test_ns1)
    test_coll2 = tempfile.mkdtemp(dir=test_ns2)
    test_coll3 = tempfile.mkdtemp(dir=test_ns3)


# Generated at 2022-06-22 19:27:02.273769
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths() == list(AnsibleCollectionConfig.collection_paths)

    assert list_valid_collection_paths(['/tmp']) == ['/tmp']

    test_dir = os.path.abspath(os.path.dirname(__file__))
    test_collection_dir = os.path.join(test_dir, 'collections')

    collection_dir = os.path.join(os.path.sep, 'tmp', 'collection')
    if os.path.exists(collection_dir):
        os.rmdir(collection_dir)

    assert list_valid_collection_paths([collection_dir]) == []

    os.makedirs(collection_dir)
    assert list_valid_collection_paths([collection_dir]) == [collection_dir]

   

# Generated at 2022-06-22 19:27:06.510110
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        'test/',
    ]

    namespace = "test"
    collection = "collection"
    coll_filter = namespace + "." + collection

    for path in list_collection_dirs(search_paths, coll_filter=coll_filter):
        assert path.endswith(namespace + "/" + collection)

# Generated at 2022-06-22 19:27:13.002011
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([u'/var/lib/ansible/collections', u'~/ansible_collections'])) == [
        '/var/lib/ansible/collections', u'~/ansible_collections']
    assert list(list_valid_collection_paths([u'/var/lib/ansible/collections', u'~/foo'])) == [
        '/var/lib/ansible/collections']
    assert list(list_valid_collection_paths([u'/var/lib/ansible/collections', u'~/foo'], warn=True)) == [
        '/var/lib/ansible/collections']
    assert list(list_valid_collection_paths(None)) == AnsibleCollectionConfig.default_collection_paths



# Generated at 2022-06-22 19:27:17.209837
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    namespace = 'otus'
    collection = 'ansible_collections.otus.demo'

    collection_directories = list(list_collection_dirs(coll_filter=collection))

    assert len(collection_directories) == 1
    assert to_bytes(collection) in collection_directories[0]

# Generated at 2022-06-22 19:27:24.364715
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/foo/bar/']
    actual_list = list(list_valid_collection_paths(search_paths, warn=True))
    assert actual_list == ['/foo/bar/']

    # no path given, default paths should be returned
    actual_list = list(list_valid_collection_paths())
    assert actual_list == AnsibleCollectionConfig.collection_paths



# Generated at 2022-06-22 19:27:34.476250
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/etc/ansible/test/test_collections']
    bad_paths = ['/etc/ansible/test/test_collections/my_namespace/my_collection',
                 '/etc/ansible/test/test_collections/my_namespace/my_collection/docs',
                 '/etc/ansible/test/test_collections/my_namespace/my_collection/plugins/collection_name',
                 '/etc/ansible/test/test_collections/my_namespace/my_collection/plugins/collection_name/my_plugin.py',
                 '/etc/ansible/test/test_collections/my_namespace/my_collection/plugins/lookup/collection_name/my_lookup.py']


# Generated at 2022-06-22 19:27:44.602475
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # test directory creation
    test_dir = None
    try:
        test_dir = tempfile.mkdtemp()

        # should always return system path
        assert list(list_valid_collection_paths([])) == ['/usr/share/ansible/collections', '/usr/share/ansible/roles']

        # warn for missing but not if default
        assert len(list(list_valid_collection_paths([test_dir], warn=True))) > 0
        assert len(list(list_valid_collection_paths([test_dir], warn=False))) > 0

        assert len(list(list_valid_collection_paths(['/this/does/not/exist']))) == 0

    finally:
        if test_dir is not None:
            import shutil
            shutil.rmt

# Generated at 2022-06-22 19:27:50.172837
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    with open('./test_list_valid_collection_paths.out', 'w') as f:

        search_paths = ['test_path1', 'test_path2']

        for r in list_valid_collection_paths(search_paths):
            assert(r in search_paths)

        for r in list_valid_collection_paths():
            f.write(r + '\n')
            assert(r.endswith('ansible_collections'))



# Generated at 2022-06-22 19:27:58.420868
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a temporary directory
    tmpdir = to_bytes(mkdtemp(), errors='surrogate_or_strict')

    # Create a test file in the temporary directory
    test_file = os.path.join(tmpdir, b'test_file')
    open(test_file, 'w').close()

    # Create a test directory in the temporary directory
    test_dir = os.path.join(tmpdir, b'test_dir')
    os.mkdir(test_dir)

    # Create a collection test directory in the temporary directory
    test_coll_dir = os.path.join(tmpdir, b'test.collection')
    os.mkdir(test_coll_dir)


# Generated at 2022-06-22 19:28:09.801166
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp

    # Test Collections
    tmp_path = mkdtemp()
    test_collections = {
        "ns1.coll1": os.path.join(tmp_path, "ns1", "coll1"),
        "ns1.coll2": os.path.join(tmp_path, "ns1", "coll2"),
        "ns2.coll1": os.path.join(tmp_path, "ns2", "coll1"),
    }

    for path in test_collections.values():
        os.makedirs(path)

    # Test that all collections are returned when none is passed
    colls = list(list_collection_dirs([tmp_path], None))
    assert len(colls) == len(test_collections), "All Collections are not returned"

    # Test that all

# Generated at 2022-06-22 19:28:19.625113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.collections import is_collection_path

    display = Display()
    paths = []

    test_path_1 = tempfile.mkdtemp()
    paths.append(test_path_1)
    test_path_2 = tempfile.mkdtemp()
    os.rmdir(test_path_2)
    paths.append(test_path_2)
    test_path_3 = tempfile.mkdtemp()
    paths.append(test_path_3)

    cfg = ConfigManager()

# Generated at 2022-06-22 19:28:30.781854
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # Create a tmp directory to use as the search path
    # and make sure it's removed when the test ends
    tmp_dir = tempfile.mkdtemp()
    os.environ['ANSIBLE_CONFIG_OVERRIDE'] = tmp_dir
    os.environ['ANSIBLE_COLLECTIONS_PATHS_OVERRIDE'] = tmp_dir
    collection_root = os.path.join(tmp_dir, 'ansible_collections')
    os.mkdir(collection_root)

    # Create collection directories in the search path
    coll_dirs = [os.path.join(collection_root, ns, coll) for ns, coll in [('foo', 'bar'), ('foo', 'baz'), ('joe', 'fred')]]


# Generated at 2022-06-22 19:28:39.805633
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # create dirs
    tmp_path = tempfile.mkdtemp()
    dirs = [
        os.path.join(tmp_path, 'coll_1'),
        os.path.join(tmp_path, 'coll_2'),
        os.path.join(tmp_path, 'coll_3'),
    ]
    for dir in dirs:
        os.mkdir(dir)

    # create file to check they get filtered out
    open(os.path.join(tmp_path, 'coll_1.txt'), 'a').close()
    open(os.path.join(tmp_path, 'coll_2.txt'), 'a').close()
    open(os.path.join(tmp_path, 'coll_3.txt'), 'a').close()

# Generated at 2022-06-22 19:28:51.647276
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from six.moves.configparser import ConfigParser
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.six.moves import configparser

    ansible_cfg = b"""[defaults]
collection_paths = %(one)s:%(two)s:%(three)s
"""

    coll_dir_1_1 = b'coll_dir_1_1'
    coll_dir_1_2 = b'coll_dir_1_2'
    coll_dir_2_1 = b'coll_dir_2_1'
    coll_dir_3_1 = b'coll_dir_3_1'
    coll_dir_1_x = b'coll_dir_1_x'

    # Create content for collection dir

# Generated at 2022-06-22 19:28:56.684699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = ["/tmp", "/mnt"]
    valid_list = list(list_valid_collection_paths(path_list, warn=True))
    if "/tmp" in valid_list:
        raise AssertionError("incorrect collection path returned")
    return True

# Generated at 2022-06-22 19:29:09.140887
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-22 19:29:20.161206
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible.collection_loader.targets import get_collection_loader
    loader = get_collection_loader()
    loader.set_collection_paths(["./test/unit/data/collections"])
    colls = list_collection_dirs(coll_filter='rhel7.mytest')
    assert next(colls) == './test/unit/data/collections/rhel7/mytest'

    colls = list_collection_dirs()
    assert next(colls) == './test/unit/data/collections/ansible.builtin/debug'

    colls = list_collection_dirs(coll_filter='ansible.builtin')
    assert next(colls) == './test/unit/data/collections/ansible.builtin/debug'

# Generated at 2022-06-22 19:29:24.201147
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(coll_filter="ansible.posix")) == ['/usr/share/ansible/collections/ansible_collections/ansible/posix']

# Generated at 2022-06-22 19:29:36.587120
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.common.collections import AnsibleRoleConfig

    # Get a tuple with (string, exists, valid_directory)
    def get_test_paths():

        # Paths to test
        path_list = [
            'test1',
            'test2',
            'test3',
            'test4',
            'test5',
            'test6',
            'test7',
            'test8',
            'test9',
        ]
        # Create the test paths
        for p in path_list:
            if not os.path.exists(p):
                os.makedirs(p)

        # Add non-existant paths
        path_list.append('test10')
        path_list.append('test11')



# Generated at 2022-06-22 19:29:43.639938
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    # get current collection config
    initial_config = AnsibleCollectionConfig.collection_paths.copy()
    # prep collections for unit test
    search_paths = [
        '../../lib/ansible/collections',  # collections from ansible/ansible top level
        '../../test/integration/targets/collections',  # test collections
    ]
    # test with all collections
    count = 0
    for coll_dir in list_collection_dirs(search_paths):
        count = count + 1
        assert os.path.exists(coll_dir)
    assert count == 19
    # test with single namespace were collection is not specified
    count = 0

# Generated at 2022-06-22 19:29:51.862387
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    results = list(list_valid_collection_paths())
    assert type(results) == list
    assert len(results) > 0
    assert '/usr/share/ansible/collections' in results

    results = list(list_valid_collection_paths(search_paths=['/tmp/does_not_exist']))
    assert len(results) == 0

    results = list(list_valid_collection_paths(search_paths=['/tmp/does_not_exist'], warn=True))
    assert len(results) == 0



# Generated at 2022-06-22 19:30:02.022105
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.path import unfrackpath

    assert unfrackpath(list_collection_dirs(coll_filter='my_namespace.my_collection')[0]) == b'/path/to/my_collection'
    assert unfrackpath(list_collection_dirs(coll_filter='my_namespace')[0]) == b'/path/to/my_collection'
    assert unfrackpath(list_collection_dirs()[0]) == b'/path/to/my_collection'
    assert unfrackpath(list_collection_dirs()[1]) == b'/path/to/another_collection'
    assert unfrackpath(list_collection_dirs(search_paths=['/path/to/'])[0]) == b'/path/to/my_collection'

# Generated at 2022-06-22 19:30:12.191364
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    collection_dir = os.path.join(tmpdir, 'ansible_collections')
    os.mkdir(collection_dir)

    collection_namespace1 = os.path.join(collection_dir, 'namespace1')
    os.mkdir(collection_namespace1)
    collection_namespace1_name1 = os.path.join(collection_namespace1, 'name1')
    os.mkdir(collection_namespace1_name1)

    collection_namespace2 = os.path.join(collection_dir, 'namespace2')
    os.mkdir(collection_namespace2)
    collection_namespace2_name1 = os.path.join(collection_namespace2, 'name1')
    os