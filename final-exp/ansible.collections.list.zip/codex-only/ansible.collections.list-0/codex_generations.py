

# Generated at 2022-06-22 19:20:10.362516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Should be empty if no search_paths is supplied
    assert list_valid_collection_paths(search_paths=None) == []

    # Should be empty if default search_paths is supplied and none exist
    assert list_valid_collection_paths(search_paths=[]) == []


# Generated at 2022-06-22 19:20:19.882690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Create fake filesystem and test list_collection_dirs."""

    search_paths = ["/root/fake1", "/root/fake2"]
    coll_filter = None
    paths = list(list_collection_dirs(search_paths, coll_filter))
    assert '/root/fake1/ansible_collections/namespace1/collection1' in paths
    assert '/root/fake1/ansible_collections/namespace1/collection2' in paths
    assert '/root/fake2/ansible_collections/namespace2/collection3' in paths
    assert '/root/fake2/ansible_collections/namespace2/collection4' in paths
    assert '/root/fake2/ansible_collections/namespace2/collection5' in paths

# Generated at 2022-06-22 19:20:26.609786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    fake_col_dir = "/foo"
    fake_file = "/bar"
    dne_dir = "/does_not_exist"
    dne_file = "/does_not_exist_not_file"


# Generated at 2022-06-22 19:20:37.866073
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import get_context_collection_loader
    loader = get_context_collection_loader(None)
    dirs = list(list_collection_dirs(None, 'testcoll'))
    assert len(dirs) == 1
    # first dir should be a test collection dir
    assert 'ansible_collections/testcoll' in dirs[0]
    dirs = list(list_collection_dirs(None, 'testcoll.testcoll'))
    assert len(dirs) == 1
    # first dir should be a test collection dir
    assert 'ansible_collections/testcoll/testcoll' in dirs[0]
    dirs = list(list_collection_dirs(None, 'testcoll.foo'))
    assert len(dirs) == 0

# Generated at 2022-06-22 19:20:45.168318
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs(coll_filter='ansible.test')
    assert len(coll_dirs) == 2
    assert next(coll_dirs) is not None
    assert next(coll_dirs) is not None
    with pytest.raises(StopIteration):
        next(coll_dirs)
    coll_dirs = list_collection_dirs(coll_filter='ansible.test.nested')
    assert len(coll_dirs) == 1
    assert next(coll_dirs) is not None
    with pytest.raises(StopIteration):
        next(coll_dirs)
    coll_dirs = list_collection_dirs(coll_filter='foo.bar')
    assert len(coll_dirs) == 0

# Generated at 2022-06-22 19:20:54.468124
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    This function tests the list_valid_collection_paths function by providing the following sets of inputs
    and ensuring that the expected output is returned for each set.
    :return:
    """
    from ansible.utils.file import mk_dict_of_dirs
    from tempfile import NamedTemporaryFile

    collection_paths = ['C:\\Program Files\\Ansible\\collections', '/etc/ansible/collections']

    # set up temp test paths and populate with minimal dirs
    test_paths = []
    test_file_handles = []
    for test_path in collection_paths:
        tmp_file = NamedTemporaryFile(prefix='ansible-collections_test-', suffix='_path',
                                      delete=False, dir=os.path.dirname(test_path))
        test_

# Generated at 2022-06-22 19:21:04.662842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    paths = ['../../library/', './', '../../tests/utils/collection_loader']
    coll_dirs = list(list_collection_dirs(paths))

    assert len(coll_dirs) == 5
    assert '../../tests/utils/collection_loader/ansible_collections/ns1.coll1' in coll_dirs
    assert '../../tests/utils/collection_loader/ansible_collections/ns1.coll2' in coll_dirs
    assert '../../tests/utils/collection_loader/ansible_collections/ns1.coll3' in coll_dirs
    assert '../../tests/utils/collection_loader/ansible_collections/ns1.coll4' in coll_dirs

# Generated at 2022-06-22 19:21:13.101263
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.path import unfrackpath


# Generated at 2022-06-22 19:21:20.978714
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list(list_collection_dirs(search_paths=[]))
    assert all(isinstance(x, str) for x in collections)

    collections = list(list_collection_dirs(search_paths=['/tmp']))
    assert all(isinstance(x, str) for x in collections)

    collections = list(list_collection_dirs(search_paths=['/tmp'], coll_filter='not_valid_collection'))
    assert len(collections) == 0

# Generated at 2022-06-22 19:21:26.560295
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/usr/share/ansible']
    test_paths.extend(AnsibleCollectionConfig.collection_paths)
    for path in list_valid_collection_paths(search_paths=test_paths):
        assert os.path.isdir(path)

# Generated at 2022-06-22 19:21:36.684031
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # provide config/defaults with no paths
    assert len(list(list_valid_collection_paths())) == 1

    # add a third path that is not a folder
    paths = ['../../../contrib/inventory/vagrant_inventory', '../../../lib/ansible/modules', '../../../lib/ansible']
    assert len(list(list_valid_collection_paths(paths))) == 2
    assert len(list(list_valid_collection_paths(paths, warn=False))) == 2
    assert len(list(list_valid_collection_paths(paths, warn=True))) == 2

    # add a third path that is a folder
    paths = ['../../../lib/ansible/plugins/modules', '../../../lib/ansible/modules', '../../../lib/ansible']


# Generated at 2022-06-22 19:21:41.726919
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_path = "/dev/null"
    display.verbosity = 4

    # Ensure that default search paths are returned
    list_valid_collection_paths()

    # Ensure that non-existent path is not returned
    result = list(list_valid_collection_paths([test_path]))

    assert len(result) == 0



# Generated at 2022-06-22 19:21:52.251908
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp, mkstemp

    # Create valid path
    valid_dir = mkdtemp()
    os.rmdir(valid_dir)  # have to remove before passing to list_valid_collection_paths

    # Create invalid path (file)
    broken_path = mkstemp()[1]

    paths = [valid_dir, broken_path]

    # List of valid paths
    valid_paths = list(list_valid_collection_paths(paths))
    assert len(valid_paths) == 1
    assert valid_paths[0] == valid_dir

    # List of invalid paths
    invalid_paths = list(list_valid_collection_paths(paths, warn=True))
    assert len(invalid_paths) == 1

# Generated at 2022-06-22 19:22:00.605164
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os.path
    import tempfile
    import shutil
    import stat

    coll_root = tempfile.mkdtemp()

# Generated at 2022-06-22 19:22:05.107477
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs
    """
    collection_dirs = list_collection_dirs()
    collection_names = []
    for collection in collection_dirs:
        collection_names.append(collection)
    assert len(collection_names) > 10



# Generated at 2022-06-22 19:22:06.773354
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    p = list_collection_dirs()

    assert isinstance(p, list)
    assert len(p) > 0

# Generated at 2022-06-22 19:22:16.283582
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test for proper operation of list_collection_dirs()
    """
    search_paths = ['/collection/root']
    list_coll = list_collection_dirs(search_paths=search_paths)
    assert list_coll is not None
    assert len(list(list_coll)) == 0

    some_ns = '/collection/root/ansible_collections/some_ns'
    some_coll = '/collection/root/ansible_collections/some_ns/some_coll'
    os.makedirs(some_coll)
    fd = open(os.path.join(some_coll, 'meta/main.yml'), 'w')
    fd.close()

    list_coll = list_collection_dirs(search_paths=search_paths)
    assert list_coll

# Generated at 2022-06-22 19:22:20.598641
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.cli.collection import list_collection_dirs

    dirs = list(list_collection_dirs(coll_filter='ansible_collections.core'))
    assert len(dirs) == 1
    assert dirs[0].endswith('ansible_collections/ansible/core')

# Generated at 2022-06-22 19:22:31.949963
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/tmp/junk1', '/home/foo/junk2']
    ret_list = list(list_valid_collection_paths(search_paths, warn=False))
    assert ret_list == []
    ret_list = list(list_valid_collection_paths(search_paths, warn=True))
    assert ret_list == []

    search_paths = ['/tmp/junk1', '/home/foo/junk2']
    ret_list = list(list_valid_collection_paths(None, warn=False))
    assert ret_list == AnsibleCollectionConfig.collection_paths
    ret_list = list(list_valid_collection_paths(None, warn=True))
    assert ret_list == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:22:38.832080
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections.ansible.tests import utils as collection_utils

    # Test with empty path list
    assert list(list_valid_collection_paths([])) == []

    # Test with empty path list
    assert list(list_valid_collection_paths([])) == []

    # Test with existing path
    existing_path = collection_utils.create_fake_collection_path('ansible.test')
    assert list(list_valid_collection_paths([existing_path])) == [existing_path]

    # Test with non existing path
    os.rmdir(existing_path)
    assert list(list_valid_collection_paths([existing_path])) == []

    # Test with file path
    file_path = os.path.join(existing_path, 'test.file')

# Generated at 2022-06-22 19:22:44.324986
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with a list of paths that contains only valid paths,
    # and with a list of paths that contains both valid and invalid paths.
    path_list1 = ["/valid_path"]
    path_list2 = ["/valid_path", "/invalid_path"]

    assert list(list_valid_collection_paths(path_list1)) == ["/valid_path"]
    assert list(list_valid_collection_paths(path_list2)) == ["/valid_path"]

# Generated at 2022-06-22 19:22:54.451774
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # these should give the same list
    paths1 = list(list_valid_collection_paths(search_paths=['~/.ansible/collections']))
    paths2 = list(list_valid_collection_paths(search_paths=['/home/testuser/.ansible/collections']))

    assert len(paths1) == len(paths2)
    assert paths1 == paths2

    # these should give different lists
    paths3 = list(list_valid_collection_paths(search_paths=['/home/otheruser/.ansible/collections']))

    assert len(paths1) != len(paths3)
    assert paths1 != paths3

    # this should give a shorter list

# Generated at 2022-06-22 19:23:01.801118
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = "namespace.collection"
    search_paths = ["test/test_utils"]
    assert list_collection_dirs(search_paths, coll_filter)
    with pytest.raises(AnsibleError) as error:
        coll_filter = "namespace.collection.extra"
        assert list_collection_dirs(search_paths, coll_filter)
    assert error.type == AnsibleError
    assert error.value.args[0] == "Invalid collection pattern supplied: namespace.collection.extra"

# Generated at 2022-06-22 19:23:04.740554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list(list_valid_collection_paths(search_paths=['./test/test_collections1', './test/test_collections2']))
    assert result == ['./test/test_collections2']

# Generated at 2022-06-22 19:23:08.990757
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_colls = list_collection_dirs()
    assert len(b_colls) > 0
    for col in b_colls:
        assert os.path.isdir(col) == True

# Generated at 2022-06-22 19:23:12.525051
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    vcps = list_valid_collection_paths()
    assert(len(vcps)) > 0
    assert isinstance(vcps, list)
    assert isinstance(vcps[0], str)


# Generated at 2022-06-22 19:23:23.968068
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    display.verbosity = 4
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Generated at 2022-06-22 19:23:35.523107
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test method list_collection_dirs
    """
    display = Display()
    display.columns = 160

    display.display("test_list_collection_dirs: Loading all collections")
    dirs = list_collection_dirs()
    for d in dirs:
        display.display("Collection found: %s" % d)

    display.display("test_list_collection_dirs: Loading specific collection")
    dirs = list_collection_dirs(coll_filter='ansible_collections.ansible_collections')
    for d in dirs:
        display.display("Collection found: %s" % d)

    display.display("test_list_collection_dirs: Loading specific namespace")
    dirs = list_collection_dirs(coll_filter='ansible_collections')

# Generated at 2022-06-22 19:23:46.508636
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # search_paths argument has a path that does not exist, the function must not include that path
    search_paths_1 = ["/abc/xyz", "/etc/ansible/collection_loader/"]
    assert ["/etc/ansible/collection_loader/"] == list(list_valid_collection_paths(search_paths_1))

    # search_paths argument has a path that is not a directory, the function must not include that path
    search_paths_2 = ["/etc/ansible/collection_loader/ns_name/coll_name", "/etc/ansible/collection_loader/"]
    assert ["/etc/ansible/collection_loader/"] == list(list_valid_collection_paths(search_paths_2))

    #

# Generated at 2022-06-22 19:23:51.780868
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_path = AnsibleCollectionConfig.playbook_paths
    coll_paths_list = list(list_collection_dirs())
    assert coll_paths_list
    assert coll_paths_list[0].startswith(b'/tmp/')


# Generated at 2022-06-22 19:24:04.389648
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile
    try:
        from subprocess import getstatusoutput
    except ImportError:
        from commands import getstatusoutput

    # Create a temporary directory and a bunch of nested sub directories.
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:24:13.819759
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # no paths specified, default paths should be loaded
    p = list(list_valid_collection_paths(warn=True))
    assert len(p) == 2

    # all invalid paths in list get filtered out
    p = list(list_valid_collection_paths(['/invalid/path', 'invalid/path', '/tmp/invalid/path'], warn=True))
    assert not p

    # all valid paths in list get returned
    p = list(list_valid_collection_paths(['/tmp', '.', os.path.dirname(__file__)], warn=True))
    assert len(p) == 3

    # a mix of valid and invalid paths get filtered out (os.path.dirname(__file__) is this file's dir)

# Generated at 2022-06-22 19:24:18.693889
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_path = ['test/unit/utils/fixtures/collections/ansible_collections']
    collection_dirs = list_collection_dirs(search_path)
    assert collection_dirs is not None
    assert len(collection_dirs) == 2
    collection_dirs = list(collection_dirs)
    assert collection_dirs[0] == b'test/unit/utils/fixtures/collections/ansible_collections/local/my_collection'
    assert collection_dirs[1] == b'test/unit/utils/fixtures/collections/ansible_collections/foo/bar'

# Generated at 2022-06-22 19:24:26.801125
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_bytes
    from ansible.collections import is_collection_path

    test = "/tmp"
    invalid_coll_paths = [
        '',
        None,
        '/fake/path',
        '..',
    ]
    invalid_coll_paths_count = 0
    for test in invalid_coll_paths:
        b_test = to_bytes(test)
        if os.path.exists(b_test) and is_collection_path(b_test):
            invalid_coll_paths_count += 1
    assert invalid_coll_paths_count == 0

# Generated at 2022-06-22 19:24:33.316103
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # os.listdir() is used to list the contents of a directory, therefore
    # it must be mocked to ensure predictable results.
    import mock
    mock_listdir = mock.Mock()
    mock_listdir.return_value = ['not_ansible_collections', 'ansible_collections']
    with mock.patch('os.listdir', mock_listdir):
        config_paths = ['/etc/ansible']
        result_paths = list(list_valid_collection_paths(search_paths=config_paths))
        assert result_paths == ['/etc/ansible/ansible_collections']



# Generated at 2022-06-22 19:24:42.378902
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:24:54.512211
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil

    root = to_bytes(tempfile.mkdtemp(prefix="ansible_collections"), errors='surrogate_or_strict')
    valid = to_bytes(os.path.join(root, 'valid'), errors='surrogate_or_strict')
    invalid = to_bytes(os.path.join(root, 'invalid'), errors='surrogate_or_strict')

    os.makedirs(valid)
    with open(invalid, 'wb') as f:
        f.write(b'foo')

    for x in list_valid_collection_paths(['/tmp', valid, invalid]):
        assert x == valid

    shutil.rmtree(root)



# Generated at 2022-06-22 19:24:58.913563
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    r = list(list_valid_collection_paths(['/foo']))
    assert r is not None and len(r) == 1, "should have one result"
    assert r[0] == "/foo", "should have /foo result"

    r = list(list_valid_collection_paths())
    assert r is not None and len(r) >= 1, "should have one default result"



# Generated at 2022-06-22 19:25:02.872110
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/some/non/existent',
        '/some/valid/path'
    ]

    # should not throw exceptions and return the valid path
    assert list(list_valid_collection_paths(search_paths)) == search_paths[1:]



# Generated at 2022-06-22 19:25:11.732003
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import list_valid_collection_paths
    from ansible.module_utils._text import to_bytes

    search_path_list = [
        '/not/a/path',
        ':',
        '/etc/ansible/collections',
        '!@#$%^&*()'
    ]

    expected_path_list = [
        to_bytes('/etc/ansible/collections'),
        to_bytes(os.path.join(os.path.sep, 'usr', 'share', 'ansible', 'collections'))
    ]

    valid_path_list = list(list_valid_collection_paths(search_path_list))

    assert valid_path_list == expected_path_list


# Generated at 2022-06-22 19:25:22.196388
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import ansible.module_utils.ansible_release as ar

    my_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    search_paths = [my_path + "/test/units/modules/test_collections1", my_path + "/test/units/modules/test_collections2"]
    dirs = list(list_collection_dirs(search_paths=search_paths))
    assert len(dirs) == 5

    # we want to return the same number of paths when we do this search so we can iterate through
    # all the collections again in test_list_collections

# Generated at 2022-06-22 19:25:33.238386
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    collections = list(list_collection_dirs(coll_filter='namespace_one.collection_one'))
    if len(collections) != 1:
        raise AssertionError("list_collection_dirs() returned wrong # of results for coll_filter=namespace_one.collection_one")

    # FIXME: The following only works in the current directory at the moment
    # We need to find a way to make it work when ansible-test is run from
    # anywhere.
    if PY3:
        collections = [collection.decode("utf-8") for collection in collections]


# Generated at 2022-06-22 19:25:38.358153
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible import context
    paths = context.CLIARGS.get('COLLECTIONS_PATHS', None)

    # test for empty list
    result = list(list_valid_collection_paths([]))
    assert not result, "Unexpected non-empty list result: {0}".format(result)

    # test for defaults when none set in config
    result = list(list_valid_collection_paths())
    assert len(result) == 1, "Unexpected size of list result: {0}".format(result)
    assert result[0] == '/usr/share/ansible/collections', "Unexpected list result: {0}".format(result)

    # test for single path which exists
    result = list(list_valid_collection_paths([os.path.dirname(__file__)]))
   

# Generated at 2022-06-22 19:25:48.281187
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    class FakeOsPath(object):
        def __init__(self):
            self.paths = {
                'is_dir': ['/good/path', '/good/path2'],
                'is_file': [],
                'exists': ['/good/path', '/good/path2']
            }

        def isfile(self, path):
            return path in self.paths['is_file']

        def isdir(self, path):
            return path in self.paths['is_dir']

        def exists(self, path):
            return path in self.paths['exists']

    def test_paths(paths, expected, warning=False, os_exists=True):

        # setup fake os_path calls
        fake_os_path = FakeOsPath()

# Generated at 2022-06-22 19:26:00.265678
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Ensure that list_collection_dirs returns the list of valid collection directories.
    :return: True on success.
    '''
    import tempfile
    import shutil
    import os

    from ansible.errors import AnsibleError

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import CollectionLoader
    from ansible.module_utils._collections_compat import list_collection_dirs as list_collection_dirs_real
    from ansible.module_utils._collections_compat import list_valid_collection_paths as list_valid_collection_paths_real

    path = tempfile.mkdtemp()
    collection_name = 'magic'
    module_name = 'magic'
    plugin_type = 'module'


# Generated at 2022-06-22 19:26:10.349688
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test of function list_collection_dirs() for multiple collections.
    """
    import sys
    import pytest

    # Add a mock collection path
    test_path = os.path.join(os.path.dirname(__file__), 'list_valid_collection_paths_test')
    sys.path.append(test_path)

    # Return a collection path (e.g. /tmp/mycollection)
    coll_paths = list(list_collection_dirs(search_paths=[test_path]))
    # The collection path should be a directory
    assert os.path.isdir(coll_paths[0])
    # The mock collection should be part of the 'test_namespace' namespace
    assert 'test_namespace' in coll_paths[0]

    # Return the collection path for

# Generated at 2022-06-22 19:26:17.629436
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    cur_path = os.path.dirname(os.path.abspath(__file__))
    test_paths = ['/abc', 'abc', cur_path]

    # Test when search_paths has no valid data
    res = list(list_valid_collection_paths(search_paths=[]))
    assert len(res) >= 1

    # Test when search_paths has valid data
    res = list(list_valid_collection_paths(search_paths=test_paths))
    assert len(res) == 1
    assert res[0] == cur_path



# Generated at 2022-06-22 19:26:24.131914
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that list_collection_dirs function works
    """
    # Test empty search path
    assert list_collection_dirs(search_paths=[]) == []

    # Test invalid collection path
    assert list_collection_dirs(search_paths=['/does_not_exist']) == []

    # Test valid collection path
    assert list_collection_dirs(search_paths=['fixtures/ansible_collections']) == [b'fixtures/ansible_collections/ansible/test1/plugins/']

    # Test valid collection path with collection filter
    assert list_collection_dirs(search_paths=['fixtures/ansible_collections'], coll_filter='ansible.test1') == [b'fixtures/ansible_collections/ansible/test1/plugins/']

# Generated at 2022-06-22 19:26:34.833196
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    function list_collection_dirs returns a list of collection paths when a list of search paths is provided
    """
    path = os.getcwd()
    valid_path = os.path.join(path, 'test-data/test_collections/')
    coll_dirs = list_collection_dirs(coll_filter=None, search_paths=[valid_path])
    assert list(coll_dirs)
    assert list(coll_dirs)[0] == to_bytes(valid_path, errors='surrogate_or_strict')

    # testing with collection
    coll_dirs = list_collection_dirs(coll_filter="newcoll.testcoll", search_paths=[valid_path])
    coll_list = list(coll_dirs)
    assert coll_list[0] == to_bytes

# Generated at 2022-06-22 19:26:45.249728
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections import is_collection_path

    import tempfile
    import shutil

    collections_root = tempfile.mkdtemp()

    test_collections = [
        os.path.join(collections_root, 'ansible_collections', 'test_namespace'),
        os.path.join(collections_root, 'ansible_collections', 'test_namespace', 'test_collection'),
        os.path.join(collections_root, 'test_namespace'),
        os.path.join(collections_root, 'test_namespace', 'test_collection'),
    ]

    for path in test_collections:
        os.makedirs(path)
        assert os.path.isdir(path)


# Generated at 2022-06-22 19:26:55.711585
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch, MagicMock

    # create mock search paths
    tmp_dir = tempfile.mkdtemp()
    tmp_dir2 = os.path.join(tmp_dir, "tmp2")
    not_a_directory = os.path.join(tmp_dir, "not_a_directory")
    mock_collection_config = os.path.join(tmp_dir2, "ansible_collections")

    os.makedirs(mock_collection_config)
    open(not_a_directory, 'a').close()
    search_paths = [tmp_dir, not_a_directory, tmp_dir2]

    # mock config
    m_collection_config

# Generated at 2022-06-22 19:27:00.643211
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert(list_collection_dirs([]) != [])
    assert(list_collection_dirs(['.']) != [])
    assert(next(list_collection_dirs(['.'])) != None)
    assert(list_collection_dirs(['ansible_collections']) != [])
    assert(list_collection_dirs(['ansible_collections']) != [])


# Generated at 2022-06-22 19:27:07.376041
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    # make sure we get the right number of collection paths
    search_paths = ['test/units/fixtures/collection_load/valid',
                    'test/units/fixtures/collection_load/invalid',
                    'dont_exist']
    num_paths = 0
    for path in list_valid_collection_paths(search_paths):
        num_paths += 1
    assert num_paths == 2


# Generated at 2022-06-22 19:27:09.749077
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.sensu.sensu_go.tests.unit import PATH
    import os

    dirs = list_collection_dirs([os.path.dirname(PATH)], coll_filter="other")
    assert sorted(dirs) == [b'ansible_collections/other/general']

# Generated at 2022-06-22 19:27:16.079629
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()
    assert list_valid_collection_paths([])
    assert not list_valid_collection_paths([1])
    assert not list_valid_collection_paths([1, 2])
    assert not list_valid_collection_paths([1, 2, 3])
    assert not list_valid_collection_paths([1, 2, 3, 4])

# Generated at 2022-06-22 19:27:27.359811
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    c = AnsibleCollectionConfig()

    # Test the empty list
    result = list(list_valid_collection_paths([]))
    assert result == c.collection_paths

    # Test the None list
    result = list(list_valid_collection_paths(None))
    assert result == c.collection_paths

    # Test a list of empty string
    result = list(list_valid_collection_paths([' ']))
    assert result == c.collection_paths

    # Test a list where each element is a space
    result = list(list_valid_collection_paths([' ', ' ']))
    assert result == c.collection_paths

    # Test a list of paths that don't exist

# Generated at 2022-06-22 19:27:34.350839
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    test_list_collection_dirs(paths, namespace, collection)
    """
    import os
    from ansible_collections.community.general.plugins.modules.system import apk

    test_coll_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(apk.__file__))))
    test_coll_dir = os.path.join(test_coll_dir, "ansible_collections", "community", "general", "plugins")

    for coll in list_collection_dirs([test_coll_dir]):
        assert os.path.isdir(coll)

# Generated at 2022-06-22 19:27:44.540254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from .mock_collections import MockCollectionsConfig
    from .mock_collections import MockDisplay

    # mock collection loader functions
    search_paths = [
        '~/my_collections',
        '/etc/ansible/collections'
    ]
    collection_paths = [
        'missing_path_1',
        '/etc/ansible/collections',
        'missing_path_2',
    ]

    # test mock collection loader with empty path
    with MockCollectionsConfig(search_paths=search_paths, collection_paths=collection_paths, warn=False) as cc_1:
        with MockDisplay():
            assert list_valid_collection_paths(search_paths, warn=False) == list(cc_1.valid_paths)

    # test mock collection loader with valid

# Generated at 2022-06-22 19:27:53.532712
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_collections')
    b_path = to_bytes(path, errors='surrogate_or_strict')
    list_collection_dirs(search_paths=path)
    list_collection_dirs(search_paths=b_path)
    list_collection_dirs(search_paths=[path, b_path])
    list_collection_dirs(search_paths='/this/path/doesnt/exist')
    list_collection_dirs(search_paths=['/this/path/doesnt/exist'])
    list_collection_dirs(search_paths=path, coll_filter="test_namespace.test_collection")

# Generated at 2022-06-22 19:28:02.077281
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile()

    coll_root = os.path.join(tmp_dir, 'ansible_collections')

    # test not set up correctly
    assert os.path.exists(tmp_dir) is False
    assert os.path.exists(coll_root) is False

    # test invalid path
    assert len(list(list_valid_collection_paths(['/tmp/does_not_exist']))) == 0

    # non collection dir
    assert len(list(list_valid_collection_paths([tmp_dir]))) == 0

    # normal collection dir
    os.makedirs(coll_root)

# Generated at 2022-06-22 19:28:06.091803
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.verbosity = 0
    invalid_paths = ['../fake_path1', '../fake_path2']
    valid_path = os.path.dirname(__file__)
    assert list(list_valid_collection_paths(search_paths=invalid_paths + [valid_path])) == [valid_path]
    assert list(list_valid_collection_paths(search_paths=invalid_paths)) == []


# Generated at 2022-06-22 19:28:13.741817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import StringTypes

    from ansible.utils.collection_loader import AnsibleCollectionConfig

    bad_paths = ["/does/not/exist", "/is/not/a/dir"]
    good_paths = ["/etc/ansible/collections", "/usr/local/share/ansible/collections"]
    good_paths.extend(AnsibleCollectionConfig.collection_paths)

    paths = good_paths + bad_paths
    log_capture_string = StringIO()


# Generated at 2022-06-22 19:28:21.895420
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    def _list_valid_collection_paths(search_paths=None, warn=False):
        for i in list_valid_collection_paths(search_paths=search_paths, warn=warn):
            yield i

    # default
    assert len(list(_list_valid_collection_paths())) > 0

    # empty list
    assert len(list(_list_valid_collection_paths([]))) > 0

    # default plus extra
    x = _list_valid_collection_paths(['./tests/data/collections_test/testcoll1/'])
    assert next(x) == './tests/data/collections_test/testcoll1/'

# Generated at 2022-06-22 19:28:31.822441
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = [u'/usr/share/ansible/test_collections/mytest']
    collection_dirs = list(list_collection_dirs(search_path))
    assert len(collection_dirs) == 2
    assert '/usr/share/ansible/test_collections/mytest/ansible_collections/mytest/test1' in collection_dirs
    assert '/usr/share/ansible/test_collections/mytest/ansible_collections/mytest/test2' in collection_dirs

    collection_dirs = list(list_collection_dirs(search_path, 'mytest.test1'))
    assert len(collection_dirs) == 1

# Generated at 2022-06-22 19:28:38.605833
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.path import makedirs_safe

    # create temp directories to test
    invalid_path = tempfile.mkdtemp()
    valid_path_1 = tempfile.mkdtemp()
    valid_path_2 = tempfile.mkdtemp()
    valid_path_3 = tempfile.mkdtemp()

    my_two_paths = [valid_path_1, valid_path_2]
    my_three_paths = [valid_path_3, valid_path_1, invalid_path]

    # create a file at the valid_path_2 location to make it invalid
    my_coll_file = os.path.join(valid_path_2, 'ansible_collections')

# Generated at 2022-06-22 19:28:51.103989
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # list of paths to test
    test_paths = ['/tmp/dummy_path_a', '/tmp/dummy_path_b']
    # list of collections
    test_collections = [
        {'namespace': 'some', 'collection': 'collection'},
        {'namespace': 'other', 'collection': 'collection'}
    ]
    # list of collections' paths
    collection_paths = []
    for coll in test_collections:
        namespace_path = os.path.join('/tmp/dummy_path_a', 'ansible_collections', coll['namespace'])
        collection_path = os.path.join(namespace_path, coll['collection'])
        os.makedirs(collection_path)
        collection_paths.append(collection_path)


# Generated at 2022-06-22 19:28:59.706691
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test data
    search_paths = [
        u'%(system_path)s',
        u'%(system_path)s/ansible/ansible_collections',
        u'%(system_path)s/ansible/'
    ]

    # test without system path
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2, "Configured paths should be 2 (using default system_path)"

    # test with system path
    search_paths[0] = search_paths[0] % dict(system_path=os.path.dirname(os.path.dirname(__file__)))
    valid_paths = list(list_valid_collection_paths(search_paths))

# Generated at 2022-06-22 19:29:06.658263
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert '.' in list_valid_collection_paths()

    # Check for a warning on invalid paths
    assert len(list_valid_collection_paths(['/dev/null/'], warn=True)) == 0

    # Check for a warning on valid paths that are not directories
    assert len(list_valid_collection_paths(['/etc/ansible'], warn=True)) == 0

# Generated at 2022-06-22 19:29:11.859874
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    c = list_valid_collection_paths()
    assert isinstance(c, type(list_valid_collection_paths()))
    assert isinstance(next(c), type(''))



# Generated at 2022-06-22 19:29:19.438229
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Dummy unit test for function list_collection_dirs.
    :return: None.
    """
    import collections
    import unittest

    class TestListCollectionDirs(unittest.TestCase):

        def test_list_collection_dirs(self):
            try:
                coll_dirs = list(list_collection_dirs())
                self.assertIsInstance(coll_dirs, collections.Iterable)
            except Exception as e:
                self.fail("unexpected exception listing collection dirs: {0}".format(e))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestListCollectionDirs)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 19:29:26.099204
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # empty search path
    search_paths = []
    assert list(list_valid_collection_paths(search_paths=search_paths)) == []

    # search path with invalid path
    search_paths = ['not_a_valid_path']
    assert list(list_valid_collection_paths(search_paths=search_paths, warn=True)) == []

    # search path with some invalid paths
    search_paths = ['not_a_valid_path', 'not_a_valid_path_two']
    assert list(list_valid_collection_paths(search_paths=search_paths, warn=True)) == []

    # search path with one valid path
    search_paths = ['/usr/share/ansible/collections']

# Generated at 2022-06-22 19:29:34.581542
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test function list_collection_dirs with mocked search_paths
    '''
    test_paths = [
        'tests/unit/mock_data/mock_collection_path/',
        'tests/unit/mock_data/mock_collection_path2/'
    ]
    dirs = list(list_collection_dirs(search_paths=test_paths))
    assert len(dirs) == 6
    assert dirs[0].endswith('mock_collection_path/ansible_collections/mock1/mock1_collection/')
    assert dirs[1].endswith('mock_collection_path/ansible_collections/mock1/mock2_collection/')

# Generated at 2022-06-22 19:29:41.912761
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test default
    valid_paths = list(list_valid_collection_paths())
    assert len(valid_paths) == 1
    assert valid_paths[0] == '~/.ansible/collections'

    # test single path with no existing path
    found = list(list_valid_collection_paths(['/fizz/buzz']))
    assert len(found) == 0

    # test single path with existing path
    assert list(list_valid_collection_paths([os.path.dirname(__file__)])) == [os.path.dirname(__file__)]

    # test another existing path
    tmpdir = os.path.dirname(__file__)
    assert list(list_valid_collection_paths([tmpdir])) == [tmpdir]

    # test two existing paths


# Generated at 2022-06-22 19:29:45.295223
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = ['first_path', 'second_path', 'third_path']
    assert expected == list_valid_collection_paths(['first_path', 'second_path', 'third_path'])


# Generated at 2022-06-22 19:29:56.260368
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test empty search paths
    assert(list(list_valid_collection_paths(search_paths=[])) == [])

    # Test missing dirname, warn for non-existent paths
    assert(list(list_valid_collection_paths(search_paths=['/tmp/no/such/place'], warn=True)) == [])

    # Test missing dirname, no warn
    assert(list(list_valid_collection_paths(search_paths=['/tmp/no/such/place'], warn=False)) == [])

    # Test non-directory path
    assert(list(list_valid_collection_paths(search_paths=['/tmp'], warn=True)) == [])

    # Test real path, no warn

# Generated at 2022-06-22 19:30:00.846421
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.collections import ansible_collections_path
    for collection_dir in list_collection_dirs(search_paths=ansible_collections_path):
        print("%s" % collection_dir)


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:30:07.798556
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    tempdir = tempfile.mkdtemp()
