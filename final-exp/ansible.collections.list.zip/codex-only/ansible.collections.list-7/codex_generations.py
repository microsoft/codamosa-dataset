

# Generated at 2022-06-22 19:20:16.175714
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_dir_1 = "./test_collections_dir"
    test_dir_2 = "./test_collections_dir_2"
    search_paths = []

    # test normal and relative path handling
    try:
        os.makedirs(test_dir_1)
        new_path = os.path.abspath(test_dir_1)
        assert to_bytes(new_path) in list_valid_collection_paths([test_dir_1])
        assert to_bytes(new_path) in list_valid_collection_paths([new_path])
        os.rmdir(test_dir_1)

    except OSError:
        assert False, "Creation or deletion of test directory failed"


# Generated at 2022-06-22 19:20:20.877204
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_path = ['/a/path/collections', '/another/path/collections']
    invalid_path = ['/a/path/collection']
    result = list_valid_collection_paths(valid_path)
    for path in result:
        assert path in valid_path
    for path in invalid_path:
        assert path not in result

# Generated at 2022-06-22 19:20:31.335474
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    from shutil import copytree, move, rmtree
    from os.path import join, exists, basename
    from ansible.plugins.loader import add_all_plugin_dirs


# Generated at 2022-06-22 19:20:41.083112
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:20:52.250561
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        list(list_collection_dirs(['/bad_path/foo']))
        assert False, 'expected Exception did not occur'
    except AnsibleError as e:
        assert 'does not exist' in str(e)

    try:
        list(list_collection_dirs(['/tmp']))
        assert False, 'expected Exception did not occur'
    except AnsibleError as e:
        assert 'missing' in str(e)

    def create_coll_dir(ns, coll):
        from ansible.module_utils.common._collections_compat import FileSystemLoader
        from ansible.module_utils.common._collections_compat import AtLeastOneFileFound
        for mypath in list_valid_collection_paths():
            if os.path.exists(mypath):
                full_

# Generated at 2022-06-22 19:20:59.041839
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == [os.environ['HOME'], '/usr/share/ansible/collections', '/etc/ansible/collections']
    assert list_valid_collection_paths(['/home/test/test']) == ['/home/test/test']
    assert list_valid_collection_paths(['/home/test/test_not'], warn=True) == []

# Generated at 2022-06-22 19:21:10.001176
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test defaults
    paths = list(list_valid_collection_paths(warn=False))
    assert len(paths) == 2
    assert paths[0] == '~/.ansible/collections'
    assert paths[1] == '/usr/share/ansible/collections'

    # test all invalid paths are dropped
    paths = list(list_valid_collection_paths(['/my/missing/path'], warn=True))
    assert len(paths) == 0

    # test non-path are dropped
    paths = list(list_valid_collection_paths(['/etc/hosts'], warn=True))
    assert len(paths) == 0

    # test relative path is accepted
    paths = list(list_valid_collection_paths(['../usr/lib'], warn=True))

# Generated at 2022-06-22 19:21:21.063805
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tdirs = []

    # Create some dummy collection directories
    tdirs.append(tempfile.mkdtemp(prefix='ansible_'))
    tdirs.append(tempfile.mkdtemp(prefix='foo_'))
    tdirs.append(tempfile.mkdtemp(prefix='bar_'))
    tdirs.append(tempfile.mkdtemp(prefix='ansible_'))
    tdirs.sort()

    # Create a list of directories with the collections in them
    collection_paths = []
    for dirname in tdirs:
        collection_paths.append(os.path.join(dirname, 'test.test'))

    # Create a list of directories with the namespaces in them
    collection_paths_namespace = []

# Generated at 2022-06-22 19:21:26.001563
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)
    assert list(list_valid_collection_paths(["/does/not/exist", "/also/not/exists"])) == list()


# Generated at 2022-06-22 19:21:36.449907
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import re
    # create a collection path
    (fd, collection_path) = tempfile.mkstemp()
    os.close(fd)
    # create a namespace
    namespace_path = os.path.join(collection_path, "ansible_collections", "test", "collection_stuff")
    os.makedirs(namespace_path, mode=0o755)
    # put a file in the namespace
    fd, txt_file = tempfile.mkstemp(dir=namespace_path)
    os.close(fd)
    fp = open(txt_file, 'w')
    fp.write("This file should exist, unless we think it's a collection.")
    fp.close()
    # Define a manifest

# Generated at 2022-06-22 19:21:39.157866
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test passing a single existing search_path
    """
    test_paths = ['.']

    for path in list_valid_collection_paths(search_paths=test_paths):
        assert path == '.'



# Generated at 2022-06-22 19:21:46.626929
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test existing directory is returned when only search_path is supplied
    search_path = ['/tmp']
    valid_paths = list(list_valid_collection_paths(search_path))
    assert len(valid_paths) == 1
    assert '/tmp' in valid_paths

    # Test non existing directory is not returned when only search_path is supplied
    search_path = ['/tmp_does_not_exist']
    valid_paths = list(list_valid_collection_paths(search_path))
    assert len(valid_paths) == 0

    # Test a non directory path is not returned when only search_path is supplied
    test_file = open('/tmp/ansible_testfile', 'w')
    test_file.close()

    search_path = ['/tmp/ansible_testfile']


# Generated at 2022-06-22 19:21:56.844327
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:22:02.641713
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp/collections', '/ansible_collections', '~/ansible_collections']
    res = list_valid_collection_paths(search_paths)
    assert list(res) == ['/ansible_collections']
    assert list(list_valid_collection_paths(search_paths, warn=True)) == ['/ansible_collections']



# Generated at 2022-06-22 19:22:04.380314
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), list)



# Generated at 2022-06-22 19:22:14.419980
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.ansible_release import __ansible_version__
    if __ansible_version__.startswith('2.11'):
        # skip test collections not supported before 2.12
        return

    import pytest
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # create directories
    os.makedirs(os.path.join(tmpdir, 'a'))
    os.makedirs(os.path.join(tmpdir, 'b'))
    os.makedirs(os.path.join(tmpdir, 'c'))
    os.makedirs(os.path.join(tmpdir, 'd'))
    os.makedirs(os.path.join(tmpdir, 'e', 'ansible_collections'))


# Generated at 2022-06-22 19:22:19.453561
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six.moves.builtins import filter

    assert list(filter(None, list_valid_collection_paths(['nonexistent_path']))) == \
        list(filter(None, list_valid_collection_paths()))

# Generated at 2022-06-22 19:22:28.755435
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    import tempfile

    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))

    def assert_contains_dir(dirs, expected_dir):
        assert expected_dir in dirs

    assert_contains_dir(list(list_valid_collection_paths([])), AnsibleCollectionConfig.default_collection_path)
    assert_contains_dir(list(list_valid_collection_paths([AnsibleCollectionConfig.default_collection_path])), AnsibleCollectionConfig.default_collection_path)
    assert_contains_dir(list(list_valid_collection_paths([tmpdir])), tmpdir)

# Generated at 2022-06-22 19:22:30.619686
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(["/tmp"], "my.test") == "/tmp/ansible_collections/my/test"

# Generated at 2022-06-22 19:22:37.693923
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # This is a copy from ansible.constants.
    # We would like to remove it one day.
    # collected from the environment variable
    COLLECTIONS_PATHS = os.getenv('ANSIBLE_COLLECTIONS_PATHS', '').split(os.pathsep)
    # collected from the ansible configuration option
    COLLECTIONS_PATHS.extend(AnsibleCollectionConfig.collection_paths)
    # defaults to install location
    COLLECTIONS_PATHS.append(os.path.join(os.path.dirname(__file__), '../../../..', 'collections'))
    # remove duplicates without altering order
    COLLECTIONS_PATHS = list(dict.fromkeys(COLLECTIONS_PATHS))


# Generated at 2022-06-22 19:22:42.781576
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Ensure collections-installed can be found by list_collection_dirs
    for path in list_collection_dirs(['/usr/share/ansible/collections']):
        if os.path.exists(path):
            assert is_collection_path(path) is True
            return

    raise AssertionError('FAIL: could not find collections-installed')

# Generated at 2022-06-22 19:22:52.094596
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import collections

    # setup current search paths
    search_paths = [
        "/etc/ansible/collections",
        "/usr/share/ansible/collections",
        "/etc/ansible/local_collections",
        "/home/ansible/collections",
    ]

    # setup the list of test collection DIRs
    test_dirs = collections.OrderedDict()
    # dir that does not exist
    test_dirs['does_not_exist'] = os.path.join('/etc', 'ansible', 'does_not_exist')
    # dir that does exist but does not have a collection
    test_dirs['no_collection'] = os.path.join('/etc', 'ansible', 'no_collection')
    # dir that contains a collection
    test_dirs['has_collection']

# Generated at 2022-06-22 19:22:57.865684
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.__dict__.pop('_deprecation_warnings', None)
    assert list_valid_collection_paths(['/my/path',
                                        '/no/such/path',
                                        '/no/such/file']) == ['/my/path']

    assert list_valid_collection_paths(['/my/path',
                                        '/no/such/path',
                                        '/no/such/file'],
                                       warn=True) == ['/my/path']

# Generated at 2022-06-22 19:23:04.817735
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_exists = '/Users/bobby//git/ansible/ansible/collection_tmp/ansible_collections/host_matcher_tests'
    path_noexist = '/Users/bobby//git/ansible/ansible/asdfa'

    search_paths = [path_exists, path_noexist]

    valid_paths = list_valid_collection_paths(search_paths, warn=False)
    assert valid_paths.__next__() == path_exists



# Generated at 2022-06-22 19:23:15.906961
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import collections
    import tempfile
    import unittest
    import shutil
    import ansible.constants as C

    class TestListCollectionDirs(unittest.TestCase):
        def setUp(self):
            # Create test collection directories
            self.ns = 'test_namespace'
            self.coll = 'test_collection'
            self.ns_dir = os.path.join(C.DEFAULT_COLLECTIONS_PATH, self.ns)
            self.coll_dir = os.path.join(self.ns_dir, self.coll)
            os.makedirs(self.coll_dir)
            os.mkdir(os.path.join(self.coll_dir, 'plugins'))

            # Quarantine global collection path
            self.orig_collections = C.COLLECTIONS_PATHS

# Generated at 2022-06-22 19:23:26.339909
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest

    from ansible.collections.default.plugins.module_utils import list_collection_dirs
    from ansible.utils import context_objects as co

    # test current working dir
    with pytest.raises(AnsibleError):
        list_collection_dirs(['.'], warn=False)

    # test non existing dir
    with pytest.raises(AnsibleError):
        list_collection_dirs(['/tmp/does_not_exist'], warn=False)

    # test non dir
    with pytest.raises(AnsibleError):
        list_collection_dirs(['/etc/passwd'], warn=False)

    # test root dir

# Generated at 2022-06-22 19:23:36.314632
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import tempfile
    import shutil
    import stat
    import sys


    # Function to return if the directory is empty
    def is_dir_empty(dirname):
        if os.path.exists(dirname):
            if os.path.isdir(dirname):
                return len(os.listdir(dirname)) == 0
        return True

    # Create a temp directory
    b_tmp_dir_root = to_bytes(tempfile.mkdtemp(prefix='ansible_test_list_collection_dirs_'))

    # Create 5 nested directories representing a namespace and collection

# Generated at 2022-06-22 19:23:47.069590
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # set up to test collection_paths
    cur_collection_paths = AnsibleCollectionConfig.collection_paths
    cur_collections_paths_setting = os.environ.get('ANSIBLE_COLLECTIONS_PATHS', None)
    # two paths, one nonexistent and one with a collection
    test_collection_paths = [u'/tmp/does_not_exist', u'/tmp/ansible_collections']
    AnsibleCollectionConfig.collection_paths = test_collection_paths
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = u':'.join(test_collection_paths)

    # Make sure no collection paths exist before the test
    assert len(list_collection_dirs()) == 0

    # Now create a collection and make sure it is found

# Generated at 2022-06-22 19:23:56.718178
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # pylint: disable=too-many-locals
    from tempfile import mkdtemp
    from tempfile import mkstemp

    # test with empty list
    result = list_valid_collection_paths([])
    assert len(list(result)) == 0

    # create new dirs for test
    good_path1 = mkdtemp()
    good_path2 = mkdtemp()
    good_path3 = mkdtemp()
    bad_file = mkstemp()[1]

    # test with some good paths and some bad paths
    result = list_valid_collection_paths([good_path1, bad_file, good_path2, good_path3])
    result_list = list(result)
    assert len(result_list) == 3
    assert good_path1 in result_list
    assert good

# Generated at 2022-06-22 19:23:59.364105
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) > 0
    for directory in collection_dirs:
        assert os.path.isdir(directory)

# Generated at 2022-06-22 19:24:04.728860
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # should return default paths: /usr/share/ansible/collections
    assert(list(list_valid_collection_paths()) == ['/usr/share/ansible/collections'])

    # should filter out non existing paths
    paths = ['/usr/share/ansible/collections', '/tmp/does_not_exist']
    assert(list(list_valid_collection_paths(search_paths=paths, warn=True)) == ['/usr/share/ansible/collections'])

# Generated at 2022-06-22 19:24:15.463082
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # [0] Test function with no arguments - returns default path list
    test_list = list(list_valid_collection_paths())
    assert test_list == AnsibleCollectionConfig.collection_paths

    # [1] Test function with user defined paths - overrides default path list
    test_list = list(list_valid_collection_paths(search_paths=['/tmp/a', '/tmp/b', '/tmp/c']))
    assert test_list == ['/tmp/a', '/tmp/b', '/tmp/c']
    test_list = list(list_valid_collection_paths(search_paths=['/tmp/user_defined_a', '/tmp/user_defined_b']))
    assert test_list == ['/tmp/user_defined_a', '/tmp/user_defined_b']

    #

# Generated at 2022-06-22 19:24:20.286963
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    p = list_valid_collection_paths(['/path/not/exist', '/etc/ansible/collection'])
    assert next(p) == '/etc/ansible/collection'
    assert os.path.exists(next(p))     # default system collection path location

# Generated at 2022-06-22 19:24:23.274030
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert set(list_valid_collection_paths(['/not/a/path', '/some/real/path'])) == set(['/some/real/path'])

# Generated at 2022-06-22 19:24:28.236054
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll_root = 'test/test_data/collection_paths/'
    coll_dirs = list(list_collection_dirs([test_coll_root]))

    expected = [os.path.join(test_coll_root, 'ansible_collections/test_ns/test_coll')]

    # This is a shallow compare between lists
    assert coll_dirs == expected


# Generated at 2022-06-22 19:24:31.760164
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Unit test for function list_collection_dirs
    :return: boolean
    '''

    # TODO
    assert True

# Generated at 2022-06-22 19:24:42.847485
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Ensure that the list_collection_dirs function behaves as expected
    """
    import unittest
    import tempfile
    import shutil
    from ansible.module_utils._text import to_native


# Generated at 2022-06-22 19:24:44.877636
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll = list_collection_dirs()
    assert test_coll is not None

# Generated at 2022-06-22 19:24:55.294968
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # all collections should be found in this fixed, minimal test dir structure
    test_dir = os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils/test_ansible_collection_loader/data')
    test_collection_dirs = [
        os.path.join(test_dir, 'ansible_collections/foo/bar/plugins/modules'),
        os.path.join(test_dir, 'ansible_collections/foo/baz/plugins/modules'),
        os.path.join(test_dir, 'ansible_collections/bar/baz/plugins/modules'),
    ]
    for coll_path in list_collection_dirs([test_dir]):
        assert coll_path in test_collection_dirs

# Generated at 2022-06-22 19:25:02.963879
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # make a list of local temp test paths
    tfiles = []
    for tf in range(1, 6):
        tfiles.append("tmp_%d" % tf)

    # touch temp files
    for tf in tfiles:
        open("%s" % tf, 'a').close()

    # build search paths from local temp file paths
    spaths = list_valid_collection_paths(tfiles)

    # build test dict for results of each list_valid_collection_paths since order is not guaranteed
    test_dict = {}
    for spath in spaths:
        test_dict[spath] = True

    # remove directories and files
    for tf in tfiles:
        if os.path.exists(tf):
            os.remove(tf)

    # verify that each of the collection paths are in the test dict

# Generated at 2022-06-22 19:25:08.666585
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '',
        ' ',
        'missing_dir',
        'missing_file'
    ]
    assert list_valid_collection_paths(search_paths) is not None
    assert list_valid_collection_paths(search_paths, warn=True) is not None
    assert list_valid_collection_paths() is not None

# Generated at 2022-06-22 19:25:14.883033
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    list_of_collections_paths = [
        '/non/existing/path',
        '../non/existing/path',
        '../../non/existing/path',
        '/tmp/tests/non/existing/path',
        '/tmp/tests/existing/path',
        '../tmp/tests/existing/path',
        '/tmp/tests/existing/file',
        ]

    filtered_paths = list(list_valid_collection_paths(search_paths=list_of_collections_paths))

    assert filtered_paths == ['/tmp/tests/existing/path']

# Generated at 2022-06-22 19:25:17.530638
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    mypath = ['/tmp/mycollections', '/mycollections']

    for x in list_collection_dirs(search_paths=mypath):
        print(x)

# Generated at 2022-06-22 19:25:18.103847
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:25:23.762746
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections import is_collection_path
    from ansible.module_utils._text import to_bytes

    # fake plugin paths
    plugin_path = [
        '/ns1/coll1',
        '/ns1/coll1/coll1_plugin_type1',
        '/ns2/coll2',
        '/ns2/coll2/coll2_plugin_type1',
        '/ns2/coll2/coll2_plugin_type2',
    ]

    # fake invalid plugin paths
    invalid_plugin_path = [
        '/.ansible',
        '/ns2/coll2/coll2_plugin_type1/coll2_plugin_type1_plugin',
        '/ns2/coll2/coll2_plugin_type1/coll2_plugin_type1_plugin.py',
    ]


# Generated at 2022-06-22 19:25:32.104126
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Should find stable.redhat.system_profiles
    coll_dirs = list_collection_dirs(['../collections'])
    assert len(coll_dirs) == 1
    assert '../collections/ansible_collections/stable/redhat/system_profiles' in coll_dirs

    # Should find stable.redhat.system_profiles
    coll_dirs = list_collection_dirs(['../../collections'])
    assert len(coll_dirs) == 1
    assert '../../collections/ansible_collections/stable/redhat/system_profiles' in coll_dirs

# Generated at 2022-06-22 19:25:43.425622
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list_collection_dirs(['test/data/collections'])

    # test list of collections
    assert 'geerlingguy.pip' in collections
    assert 'ansible.builtin' in collections

    # test filtering by namespace
    collections = list_collection_dirs(['test/data/collections'], 'ansible')
    assert 'ansible.builtin' in collections
    assert 'geerlingguy.pip' not in collections

    # test filtering by collection
    collections = list_collection_dirs(['test/data/collections'], 'geerlingguy.pip')
    assert 'geerlingguy.pip' in collections
    assert 'ansible.builtin' not in collections

    # test filtering by full collection

# Generated at 2022-06-22 19:25:44.407864
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Dummy test
    assert False

# Generated at 2022-06-22 19:25:50.774058
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    tpath = tempfile.mkdtemp()
    try:
        test_ns_path = os.path.join(tpath, 'myns')
        test_col_path = os.path.join(test_ns_path, 'mycol')
        test_plugin_path = os.path.join(test_col_path, 'plugins', 'myplugin')
        os.makedirs(test_plugin_path)
        for p in list_collection_dirs([tpath]):
            assert p == test_col_path
            break
    finally:
        shutil.rmtree(tpath)



# Generated at 2022-06-22 19:26:00.713843
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This is a unit test to ensure that list_collection_dirs work as expected
    """
    coll_dir = []

# Generated at 2022-06-22 19:26:10.840480
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    def _test_for_filter(input_paths, expected, warn=False):

        out = list(list_valid_collection_paths(input_paths, warn))
        assert out == expected


# Generated at 2022-06-22 19:26:19.974603
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:

        base_coll_dir = os.path.join(temp_dir, 'ansible_collections')

        os.makedirs(os.path.join(base_coll_dir, 'namespace1', 'collection1'))
        os.makedirs(os.path.join(base_coll_dir, 'namespace1', 'collection2'))
        os.makedirs(os.path.join(base_coll_dir, 'namespace2', 'collection1'))
        os.makedirs(os.path.join(base_coll_dir, 'namespace2', 'collection3'))


# Generated at 2022-06-22 19:26:27.852173
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    expected_paths = [
        '/tmp/1',
        '/tmp/2',
        '/tmp/3',
    ]

    paths = ['/tmp/1', '/tmp/2', '/tmp/3', '/tmp/4']

    os.makedirs('/tmp/1')
    open('/tmp/2', 'a').close()
    os.makedirs('/tmp/3')

    results = list_valid_collection_paths(paths, warn=True)

    for item in results:
        assert item in expected_paths
    assert len(expected_paths) == len(results)


if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-22 19:26:29.370667
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    actual_collections = list_collection_dirs()
    assert actual_collections != []

# Generated at 2022-06-22 19:26:37.772786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths
    import tempfile
    """
    1. filter out non existing or invalid search_paths for collections
    2. filter out non existing or invalid search_paths for collections
    3. filter out non existing or invalid search_paths for collections
    """

# Generated at 2022-06-22 19:26:46.989560
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import ansible.utils.collection_loader

# Generated at 2022-06-22 19:26:56.752320
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.dirname(__file__)
    listdir_dir = os.path.join(path, 'listdir')
    assert [
        b'/'.join([listdir_dir.encode(), b'ansible_collections', b'my_corp', b'networking']),
    ] == list(list_collection_dirs([listdir_dir]))
    assert [
        b'/'.join([listdir_dir.encode(), b'ansible_collections', b'my_corp', b'networking']),
        b'/'.join([listdir_dir.encode(), b'ansible_collections', b'my_corp', b'automation']),
    ] == list(list_collection_dirs([listdir_dir], 'my_corp'))

# Generated at 2022-06-22 19:27:07.938490
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # create & verify test paths
    import tempfile
    tempdir1 = tempfile.mkdtemp()
    tempdir2 = tempfile.mkdtemp()
    tempfile1 = tempfile.NamedTemporaryFile()

    testpaths = [tempdir1, tempdir2, tempfile1.name, 'donotexist']

    for testpath in testpaths:
        if testpath not in dict(list_valid_collection_paths(testpaths)).values():
            raise AnsibleError("test_list_valid_collection_paths: "
                               "testpath %s not returned by list_valid_collection_paths" % testpath)

    # cleanup
    import shutil
    shutil.rmtree(tempdir1)
    shutil.rmtree(tempdir2)
    tempfile1.close()

# Generated at 2022-06-22 19:27:16.567807
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test Path 1, path invalid
    assert list(list_valid_collection_paths(['/invalid/foo/bar/'])) == []
    # Test Path 2, path valid, directory does not exist
    assert list(list_valid_collection_paths(['/tmp/doesnotexist'])) == []
    # Test Path 3, path valid, existing directory
    assert list(list_valid_collection_paths(['/tmp'])) == ['/tmp']



# Generated at 2022-06-22 19:27:28.102382
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import shutil

    test_paths = []

    temp_path = AnsibleCollectionConfig().create_temp_path()
    test_paths.append(temp_path)

    os.makedirs(os.path.join(temp_path, 'ansible_collections', 'test_ns'))

    # test non-collections dirs don't get returned
    os.makedirs(os.path.join(temp_path, 'ansible_collections', 'test_ns', 'test_col'))
    os.makedirs(os.path.join(temp_path, 'ansible_collections', 'test_ns', 'test_col', 'plugins'))

# Generated at 2022-06-22 19:27:30.531556
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['foo', 'bar'])) == ['foo', 'bar']



# Generated at 2022-06-22 19:27:40.312000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_type_errors = False

    def is_path_valid(path):
        try:
            list(list_valid_collection_paths([path]))
        except TypeError:
            global path_type_errors
            path_type_errors = True

    path_list = [
        # search_path list of different types
        '/path/to/collections',
        u'/path/to/collections',
        b'/path/to/collections',
    ]

    for path in path_list:
        is_path_valid(path)

    assert not path_type_errors

# Generated at 2022-06-22 19:27:48.202594
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_dirs = []
    test_dirs.append("/foo/bar/baz")
    test_dirs.append("/foo/bar/baz")
    test_dirs.append("/foo/bar/baz")
    test_dirs.append("/foo/bar/baz")
    test_dirs.append("/foo/bar/baz")

    for k in list_valid_collection_paths(search_paths=test_dirs, warn=True):
        assert k == test_dirs[0]


# Generated at 2022-06-22 19:27:53.193317
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    verify list_valid_collection_paths only returns valid directories
    """
    collected_paths = list(list_collection_dirs(search_paths=['/tmp/badpath', '/tmp/goodpath']))
    assert len(collected_paths) == 1
    assert collected_paths[0].endswith('goodpath/ansible_collections')

# Generated at 2022-06-22 19:28:00.124785
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    collection_dirs = list(list_collection_dirs(['/dev/null']))
    assert len(collection_dirs) == 0
    assert isinstance(collection_dirs, list)

    collection_dirs = list(list_collection_dirs(['/dev/null', '/tmp']))
    assert len(collection_dirs) == 0
    assert isinstance(collection_dirs, list)

    collection_dirs = list(list_collection_dirs(['/dev/null', '/usr/share/ansible/collections/ansible_collections']))
    assert collection_dirs[0] == os.path.expanduser('/usr/share/ansible/collections/ansible_collections/ansible/community/cluster')
    assert len(collection_dirs) == 6


# Generated at 2022-06-22 19:28:09.762699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    This function lists all valid collection paths
    """

    import tempfile

    # Empty path
    assert list(list_valid_collection_paths([])) == []

    # path with invalid directories
    with tempfile.TemporaryDirectory() as temp1, tempfile.TemporaryDirectory() as temp2:
        assert temp1 not in list_valid_collection_paths([temp2, temp1, '/invalid/path'])

    # paths with valid directories
    with tempfile.TemporaryDirectory() as temp1, tempfile.TemporaryDirectory() as temp2:
        assert set(list(list_valid_collection_paths([temp2, temp1, '/invalid/path']))) == {temp1, temp2}



# Generated at 2022-06-22 19:28:12.937863
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_paths = list_collection_dirs()
    assert coll_paths

    coll_paths = list_collection_dirs(coll_filter='ns')
    assert coll_paths

    coll_paths = list_collection_dirs(coll_filter='ns.coll')
    assert coll_paths

# Generated at 2022-06-22 19:28:23.994450
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    search_path = tempfile.mkdtemp()
    collection_paths = os.path.join(search_path, "ansible_collections")

    os.makedirs(collection_paths)
    os.makedirs(os.path.join(collection_paths, "namespace1", "collection1"))
    os.makedirs(os.path.join(collection_paths, "namespace1", "collection2"))
    os.makedirs(os.path.join(collection_paths, "namespace2", "collection1"))
    os.makedirs(os.path.join(collection_paths, "namespace3", "collection3"))


# Generated at 2022-06-22 19:28:30.449726
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Use the test collections in tests/fixtures/ansible_collections_sorted
    # as a part of the test suite.
    test_paths = [os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_collections_sorted')]

    for path in list_valid_collection_paths(test_paths):
        assert path == os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_collections_sorted')


# Generated at 2022-06-22 19:28:39.199466
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    def assert_in_list(item, list_of_items):
        assert any(map(lambda x: x.endswith(item), list_of_items))

    collection_paths = list_valid_collection_paths(['invalid_path', 'another_invalid_path'])
    assert_in_list('/root/.ansible/collections', collection_paths)
    assert_in_list('/etc/ansible/collections', collection_paths)
    assert_in_list('/usr/share/ansible/collections', collection_paths)
    assert_in_list('/usr/local/share/ansible/collections', collection_paths)
    assert_in_list('/.ansible/collections', collection_paths)

# Generated at 2022-06-22 19:28:47.763970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    try:
        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, 'ansible_collections/ns/coll'))

            path = list(list_collection_dirs([tmp]))[0]

            assert path.endswith('ns/coll')
            assert is_collection_path(path)

    except AssertionError:
        raise


# Generated at 2022-06-22 19:28:59.264743
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # NOTE: Test needs to be run from the test directory.
    # Therefore, test looks for test files in that directory
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    # Test with empty collection paths
    assert list_valid_collection_paths([]) == list_valid_collection_paths(None)

    # Test with non-existent paths
    assert list(list_valid_collection_paths(['/tmp/non-existent'])) == []

    # Test with a non-directory path
    with open(tmpdir + "/test.file", 'w') as test_file:
        test_file.write("test")
    assert list(list_valid_collection_paths([tmpdir])) == []

    # Test with an existing directory
    shutil.rmtree(tmpdir)
   

# Generated at 2022-06-22 19:29:10.105763
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_root = "/tmp/test_list_collection_dirs"

    # Create a collection
    os.mkdir(coll_root)
    os.mkdir(os.path.join(coll_root, "ansible_collections"))
    os.mkdir(os.path.join(coll_root, "ansible_collections", "namespace1"))
    os.mkdir(os.path.join(coll_root, "ansible_collections", "namespace1", "collection1"))
    os.mkdir(os.path.join(coll_root, "ansible_collections", "namespace1", "collection2"))
    os.mkdir(os.path.join(coll_root, "ansible_collections", "namespace2"))

# Generated at 2022-06-22 19:29:18.669882
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with a simple dir structure
    search_paths = ['/tmp/collections', '/tmp/collections2']

    collection = None
    namespace = None
    collection_path = None
    if collection is not None or namespace is not None:
        collection_path = os.path.join(collection_path, namespace)

    # Add a ns.collection
    collection_path = os.path.join(collection_path, collection, 'ansible_collections')
    os.makedirs(collection_path)

    # Add files to the directory
    with open(os.path.join(collection_path, 'Galaxyfile'), 'w') as f:
        f.write('namespace: %s\n' % namespace)
        f.write('name: %s\n' % collection)


# Generated at 2022-06-22 19:29:21.795293
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=[], warn=True) == []
    assert list_valid_collection_paths(search_paths=['/does/not/exist'], warn=True) == []

# Generated at 2022-06-22 19:29:30.916462
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dir12 = '/tmp/12test/test'
    dir34 = '/tmp/34test/test'
    dir34_2 = '/tmp/34test2/test'
    dir67 = '/tmp/67test/test'
    dir84 = '/tmp/84test/test'
    dir84_2 = '/tmp/84test2/test'
    dir19 = '/tmp/19test/test'
    dir19_2 = '/tmp/19test2/test'
    dir19_3 = '/tmp/19test3/test'
    os.makedirs(dir12)
    os.makedirs(dir34)
    os.makedirs(dir34_2)
    os.makedirs(dir67)
    os.makedirs(dir84)
    os.makedirs(dir84_2)


# Generated at 2022-06-22 19:29:40.891348
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_path = __file__.rstrip('/c')
    test_path = os.path.dirname(test_path)

    # no_paths
    assert list(list_valid_collection_paths(search_paths=[])) == ['/etc/ansible/collections']

    # one_path_not_exists
    paths = [test_path]
    assert list(list_valid_collection_paths(search_paths=paths)) == []

    # one_path_not_a_dir, no_warn
    assert list(list_valid_collection_paths(search_paths=['/etc/ansible/ansible.cfg'])) == []

    # one_path_not_a_dir, warn

# Generated at 2022-06-22 19:29:51.323880
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # create a fake collection dir
    filename = tempfile.mkstemp()
    os.rmdir(filename[1])

    fake_dir = os.path.join(filename[1], 'ansible_collections')
    os.makedirs(fake_dir)

    coll_dir = os.path.join(fake_dir, 'awesome.cool')
    os.makedirs(coll_dir)

    # create a valid collection file
    f = open(os.path.join(coll_dir, 'plugins'), 'w')
    f.close()

    # test if collection is found
    coll_paths = list(list_collection_dirs([filename[1]]))

    assert coll_paths == [coll_dir]

# Generated at 2022-06-22 19:29:59.882365
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []

    # add an invalid path to an existing directory
    search_paths.append('/etc/passwd')
    assert list(list_valid_collection_paths(search_paths)) == []

    # add a directory that does not exist
    search_paths.append('/tmp/non-existant-dir')
    assert list(list_valid_collection_paths(search_paths)) == []

    # add a valid path
    search_paths.append('/tmp')
    assert list(list_valid_collection_paths(search_paths)) == ['/tmp']



# Generated at 2022-06-22 19:30:07.674851
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    path1 = "/path/to/c1"
    path2 = "/path/to/c2"

    config = AnsibleCollectionConfig([path1])

    found = list_valid_collection_paths(config.collection_paths)
    assert path1 in found
    assert path2 not in found

    # verify that we get a new list on subsequent calls
    assert len(found) == 1

    # now test with a non-existent path, but warn is false, so no error
    found = list_valid_collection_paths(["/path/to/c3"], warn=False)
    assert list(found) == []

    try:
        assert list(list_valid_collection_paths(["/path/to/c3"], warn=True))
    except AssertionError:
        pass
    else:
        raise Ass