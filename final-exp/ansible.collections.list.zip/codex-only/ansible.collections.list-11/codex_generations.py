

# Generated at 2022-06-22 19:20:18.174612
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    path_list = [ "." ]
    assert list(list_valid_collection_paths(path_list)) == [ "." ]

    path_list = [ "no_exist" ]
    assert list(list_valid_collection_paths(path_list)) == []

    path_list = [ "." ]
    assert list(list_valid_collection_paths(path_list, warn=True)) == [ "." ]

    path_list = [ "no_exist" ]
    assert list(list_valid_collection_paths(path_list, warn=True)) == []

    path_list = None
    assert list(list_valid_collection_paths(path_list)) == AnsibleCollectionConfig.collection_paths

    path_list = None

# Generated at 2022-06-22 19:20:24.462688
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll_dir = 'collectiontest'
    collection = 'mytest'
    namespace = 'mynamespace'

    test_coll_dirs = ['ansible_collections/' + namespace + '/' + collection + '/',
                      namespace + '/' + collection + '/']
    for test_coll_dir in test_coll_dirs:
        os.makedirs(test_coll_dir)

    found_coll = list(list_collection_dirs(search_paths=[test_coll_dir]))
    assert os.path.basename(found_coll[0]) == collection

# Generated at 2022-06-22 19:20:28.237069
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(None) is not None
    assert list_collection_dirs([]) is not None
    assert list_collection_dirs(['/dev/null'], 'ns.coll') is not None

# Generated at 2022-06-22 19:20:35.035861
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'modules', 'extras'))
    search_paths = [os.path.join(os.path.dirname(test_dir), 'data', 'collections')]
    collections = list(list_collection_dirs(search_paths, 'namespaced.collection'))
    assert collections[0].endswith(b'namespaced/collection')

# Generated at 2022-06-22 19:20:43.453601
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert set(list_collection_dirs(search_paths=['../test/integration/collection_loader_data/collections',
                                                  '../test/integration/collection_loader_data/ansible_collections'],
                                    coll_filter="foo")) == set([b'../test/integration/collection_loader_data/collections/ansible_collections/foo/bar',
                                                                b'../test/integration/collection_loader_data/ansible_collections/foo/bar'])


# Generated at 2022-06-22 19:20:49.807618
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/non/existing/collection/path', '/non/existing/collection/path2', '~/existing/collection/path']
    valid_search_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert sorted(valid_search_paths) == sorted(AnsibleCollectionConfig.collection_paths)

# Generated at 2022-06-22 19:20:56.847953
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # this is a valid path
    valid_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'fixtures')

    # This should be a valid path but in a playbooks repo so it won't be added
    valid_path_playbook = os.path.join(valid_path, 'ansible_collections')

    # path to a symlink to a collections dir
    coll_path = os.path.join(valid_path, 'valid_collections')

    # path to a symlink to a collections dir, with a trailing slash
    coll_path_trailing_slash = os.path.join(valid_path, 'valid_collections_2')

    # Path not found, should not be added

# Generated at 2022-06-22 19:20:57.774891
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True

# Generated at 2022-06-22 19:21:06.356982
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    b_temp_dir = to_bytes(temp_dir)
    parentdir = os.path.dirname(b_temp_dir)

    os.mkdir(b_temp_dir)
    os.mkdir(os.path.join(b_temp_dir, b"ansible_collections"))
    os.mkdir(os.path.join(b_temp_dir, b"ansible_collections", b"collection1"))
    os.mkdir(os.path.join(b_temp_dir, b"ansible_collections", b"collection2"))


# Generated at 2022-06-22 19:21:10.983226
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Inputs
    search_paths = [u'/path/does/not/exist', u'/home/ansible/projects/ansible/collections']

    # Result
    result = list(list_valid_collection_paths(search_paths))

    # Verify
    assert len(result) == 1
    assert result[0] == u'/home/ansible/projects/ansible/collections'


# Generated at 2022-06-22 19:21:14.834171
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    When called with an existing path then a list with that path should be returned
    :return: list with correct path
    """
    path = ["/existing/path"]
    res = list(list_valid_collection_paths(path, warn=True))
    assert path == res



# Generated at 2022-06-22 19:21:19.867363
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    if os.path.exists('tests/fixtures/test_collections'):
        test = list(list_valid_collection_paths(['tests/fixtures/test_collections']))
        assert test == ['tests/fixtures/test_collections']

# Generated at 2022-06-22 19:21:22.425479
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collections = list(list_collection_dirs(search_paths=['/tmp']))
    assert test_collections == ['/tmp/ansible_collections']

# Generated at 2022-06-22 19:21:27.192024
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == [
        os.path.join(os.path.expanduser('~'), '.ansible/collections')
    ], 'Expected Ansible collection paths.'



# Generated at 2022-06-22 19:21:37.218905
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Verify that list_collection_dirs works correctly
    :return: True for success, raises AssertionError on failure
    """
    import tempfile
    test_dir = tempfile.TemporaryDirectory()
    if not test_dir:
        raise AssertionError('Failed to create tempdir')

    mydirs = [
        os.path.join(test_dir.name, 'test.col1'),
        os.path.join(test_dir.name, 'test.col2'),
        os.path.join(test_dir.name, 'test.col3'),
        os.path.join(test_dir.name, 'test.fake1'),
        os.path.join(test_dir.name, 'test.fake2'),
    ]

    for mypath in mydirs:
        os.mk

# Generated at 2022-06-22 19:21:45.607639
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    test_search_paths = [mkdtemp(), mkdtemp(), mkdtemp(), mkdtemp(), mkdtemp()]

    valid_search_paths = list(list_valid_collection_paths(search_paths=test_search_paths))

    assert len(test_search_paths) == len(valid_search_paths)
    assert all(test_search_path in valid_search_paths for test_search_path in test_search_paths)
    assert all(os.path.exists(path) for path in valid_search_paths)
    assert all(os.path.isdir(path) for path in valid_search_paths)

    # Clear up our test

# Generated at 2022-06-22 19:21:49.813444
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['a_path_that_does_not_exist', './']
    result = list_valid_collection_paths(test_paths)
    # The first path should be skipped, the second is valid
    assert [path for path in result] == ['./']

# Generated at 2022-06-22 19:21:59.030827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # https://github.com/ansible/ansible/issues/55879
    # for this test to work correctly, the test must be run with a modified home dir
    # so that there is no ~/.ansible/collections link
    home = os.environ['HOME']
    os.environ['HOME'] = '/tmp/ansible-test-home-does-not-exist'

    cur_search_paths = AnsibleCollectionConfig.collection_paths[:]

# Generated at 2022-06-22 19:22:10.626600
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:22:18.282456
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = [
        'test/unit/plugins/modules/fixtures/collections1',
        'test/unit/plugins/modules/fixtures/collections2',
        'test/unit/plugins/modules/fixtures/collections3',
    ]

    # return all collections with no filter
    all_collections = list(list_collection_dirs(paths))
    assert len(all_collections) == 11

    # return all collections under specified namespace
    namespace_collections = list(list_collection_dirs(paths, 'ansible.builtin'))
    assert len(namespace_collections) == 3

    # return only named collection under specified namespace
    named_collection = list(list_collection_dirs(paths, 'ansible.builtin.foo'))
    assert len(named_collection) == 1

# Generated at 2022-06-22 19:22:24.673885
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def test_path(path):
        path = os.path.join(os.path.expanduser(path), 'ansible_collections')
        display.display("=== checking %s ===" % path)
        for path in list_collection_dirs([path], coll_filter='ansible.test_1'):
            display.display("   %s" % path)

    test_path('/usr/share')
    test_path('/usr/local/share')
    test_path('/opt/share')



# Generated at 2022-06-22 19:22:34.746526
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()

    # create some collections
    os.makedirs(os.path.join(tmp_dir, 'ansible_collections', 'ns1', 'collection1', 'pl.d'))
    os.makedirs(os.path.join(tmp_dir, 'ansible_collections', 'ns2', 'collection2', 'pl.d'))
    os.makedirs(os.path.join(tmp_dir, 'ansible_collections', 'ns2', 'collection3', 'pl.d'))

    # create a plugin
    os.makedirs(os.path.join(tmp_dir, 'ns1', 'collection1', 'pl.d', 'test.py'))

    # list all collections


# Generated at 2022-06-22 19:22:36.785969
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll_dirs = list_collection_dirs(coll_filter="my.collection")
    assert list(test_coll_dirs) == ['foo', 'bar']



# Generated at 2022-06-22 19:22:40.234024
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = [n for n in list_collection_dirs(search_paths=None, coll_filter='horrormovies.scream')]
    print(result)

# Generated at 2022-06-22 19:22:48.659663
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test data
    search_paths = ['../../../../colls/', './colls2']
    # test data
    #dir_name_1 = ['..', '..', '..', 'colls']
    #dir_name_2 = ['.', 'colls2']
    #dir_name = [dir_name_1, dir_name_2]
    #print(dir_name)
    #test_data = ['colls/ansible_collections/test_namespace_2/test_collection_2', 'colls2/ansible_collections/test_namespace/test_collection']
    #test_data = ['ansible_collections/test_namespace/test_collection', 'ansible_collections/test_namespace_2/test_collection_2']
    #expected_data =

# Generated at 2022-06-22 19:22:55.938206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/foo/bar', '/fuz/buz', '/does/not/exist']

    paths = list_valid_collection_paths(search_paths=search_paths, warn=True)
    assert len(paths) == 2

    paths = list_valid_collection_paths(search_paths=search_paths, warn=False)
    assert len(paths) == 2

    paths = list_valid_collection_paths(warn=True)
    assert len(paths) == len(AnsibleCollectionConfig.collection_paths) == 3

# Generated at 2022-06-22 19:23:01.167075
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test valid path
    assert ['/tmp/path'] == list(list_valid_collection_paths(['/tmp/path']))

    # Test invalid path
    assert [] == list(list_valid_collection_paths(['/tmp/invalidpath']))

    # Test no paths
    assert [] == list(list_valid_collection_paths([]))


# Generated at 2022-06-22 19:23:09.014232
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from six import StringIO

    def captureOutput(func):
        def wrapper(*args, **kwargs):
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            sys.stdout = buf = StringIO()
            sys.stderr = err = StringIO()
            res = func(*args, **kwargs)
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            return (res, buf.getvalue(), err.getvalue())
        return wrapper

    @captureOutput
    def validate_list_collection_dirs(coll_filter):
        res = []
        for col in list_collection_dirs(coll_filter=coll_filter):
            res.append(col)
        return res
    
    import sys
    import os

# Generated at 2022-06-22 19:23:11.960302
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    check_paths = ['/test/test1', '/test/test2', '/test2/test3']
    expected = ['/test/test1', '/test/test2']
    actual = list_valid_collection_paths(check_paths)

    assert len(list(actual)) == len(expected), "list_valid_collection_paths failed"
    assert all(path in actual for path in expected), "list_valid_collection_paths failed"



# Generated at 2022-06-22 19:23:19.432354
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # The test_collection_path has been verified to be a valid search_path
    test_collection_path = '/Users/sanabria/.ansible/collections'

    # The test_collection_path has been verified to NOT be a valid search_path
    test_non_collection_path = '/Users/sanabria/.ansible/non_collection_path'

    test_collection_paths = [test_collection_path, test_non_collection_path]

    # Verify that the correct collection path is returned, since test_non_collection_path is not a valid path
    results = list(list_valid_collection_paths(test_collection_paths))

    assert len(results) == 1
    assert results[0] == test_collection_path

# Generated at 2022-06-22 19:23:27.694718
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = "/tmp/test-ansible/collections"
    test_coll_dirs = {
        "namespace": {
            "collection1": "/tmp/test-ansible/collections/namespace/collection1",
            "collection2": "/tmp/test-ansible/collections/namespace/collection2"
        },
        "namespace2": {
            "collection1": "/tmp/test-ansible/collections/namespace2/collection1",
        }
    }
    collection_dirs = []
    for coll_root in list_collection_dirs([path]):
        collection_dirs.append(coll_root)

    assert len(collection_dirs) == 2
    assert collection_dirs[0] == b'/tmp/test-ansible/collections/namespace/collection1'
   

# Generated at 2022-06-22 19:23:33.771540
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import hashlib
    import tempfile

    # create a temporary directory and make it a collection root
    search_paths = [tempfile.mkdtemp(), '/does/not/exist']
    for path_to_test in search_paths:
        for path in list_valid_collection_paths(search_paths):
            assert path == path_to_test



# Generated at 2022-06-22 19:23:38.012510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: add asserts to this test
    list_valid_collection_paths(warn=True)
    print("*" * 80)
    list_valid_collection_paths(warn=False)

# Generated at 2022-06-22 19:23:47.693516
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # one collection
    list_of_dirs = list(list_collection_dirs(coll_filter='ansible_collections.nbarker.gcp_compute'))
    assert len(list_of_dirs) == 1, 'One collection was returned'
    assert list_of_dirs[0] == to_bytes('/Users/nbarker/.ansible/collections/ansible_collections/nbarker/gcp_compute'), 'Collection was found'

    # one namespace
    list_of_dirs = list(list_collection_dirs(coll_filter='ansible_collections.nbarker'))
    assert len(list_of_dirs) > 0, 'More than one collection was found in the namespace'

# Generated at 2022-06-22 19:23:57.159031
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    from ansible.module_utils._text import to_bytes

    from ansible.plugins.loader import collection_loader, get_all_plugin_loaders

    loaders = get_all_plugin_loaders()

    # The loader system can't really be unit tested without more changes, this will have
    # to do for now. We check that the loaders are loaded by the collection system and
    # that the call to list_collection_dirs() cause the loaders to be loaded because
    # collection_loader.collection_finder() will call loaders[0].find_plugin() on
    # non-collection paths.

    # Note: since the loader system is not being mocked, this test will assert that
    # collection_loader.collection_finder() is called as part of the function list_collection_dirs().
    #

# Generated at 2022-06-22 19:24:05.545605
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    """
    Test function list_collection_dirs
    :return: None
    """
    from ansible.utils.path import makedirs_safe
    from os import rmdir

    from ansible.module_utils.six import PY2

    from tempfile import mkdtemp

    import shutil

    # Setup test collection paths
    test_paths = []
    test_ns = 'ansible'
    test_coll = 'test'
    test_coll_dir = os.path.dirname(os.path.dirname(__file__))

    # Python 2 returns unicode
    if not PY2:
        test_coll_dir = to_bytes(test_coll_dir)

    test_paths.append(test_coll_dir)

    # Add bad path
    b_tmp_root = to_bytes

# Generated at 2022-06-22 19:24:11.806842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = "/Users/ansible-test/ansible_collections"
    coll_filter = "ns"
    search_path = ['ansible.posix', coll_filter]
    coll_filter = "ns.coll"

    search_path = ['ansible.posix', coll_filter]
    search_paths = list_collection_dirs(search_paths=path, coll_filter=coll_filter)
    assert search_paths is not None



# Generated at 2022-06-22 19:24:23.886912
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import glob

    collection_paths = [
        'tests/unit/utils/collection_loader/collections',
        'tests/unit/utils/collection_loader/collections_v2'
    ]
    tmp_paths = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp()
    ]
    for i, p in enumerate(tmp_paths):
        for f in glob.glob(collection_paths[i] + '/*'):
            shutil.copytree(f, os.path.join(p, os.path.basename(f)))
    collection_paths.append(tempfile.mkdtemp())
    tmp_paths.append(tempfile.mkdtemp())


# Generated at 2022-06-22 19:24:29.582604
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(['./lib/ansible/modules/cloud/azure', './lib/ansible/modules/cloud/rackspace']))) == 2
    assert len(list(list_valid_collection_paths(['./lib/ansible/modules/cloud/azure', '/tmp/ansible_test/test_not_exist_folder', './lib/ansible/modules/cloud/rackspace']))) == 2


# Generated at 2022-06-22 19:24:33.488342
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['/home/user/ansible_collections', '/usr/share/ansible/collections']

    assert list(list_collection_dirs(search_paths=search_paths, coll_filter='namespace.collection')) == []
    assert list(list_collection_dirs(search_paths=search_paths, coll_filter=None)) == []



# Generated at 2022-06-22 19:24:42.565623
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import unfrackpath

    local_dir = unfrackpath("$CWD/../lib/ansible/collections/ansible_collections/local")


# Generated at 2022-06-22 19:24:48.937689
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Given
    search_paths = []
    coll_filter = None

    # When
    result = list_collection_dirs(search_paths, coll_filter)

    # Then
    path = result.next()
    assert os.path.basename(path) == 'ansible_collections'

# Generated at 2022-06-22 19:24:54.058141
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    # Test with invalid search paths
    search_paths = ['/dev/null', '/tmp/non_existant_dir']
    assert list(list_valid_collection_paths(search_paths)) == []

    # Test with no search paths
    assert list(list_valid_collection_paths()) != []

# Generated at 2022-06-22 19:25:02.328132
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with valid search paths
    search_paths = ['.', './my_collections']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2

    # Also test with a non existing path
    search_paths.append('/non/existing/path')
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2

    # Also test with an existing file as path
    search_paths.append('./test_cl_utils.py')
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2

    # Also test with a combination of valid and non-existing

# Generated at 2022-06-22 19:25:12.812347
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    '''
    Validating the behaviour of list_collection_dirs function
    '''

    from tempfile import mkdtemp

    # Create collection directories
    tmp_col_root = mkdtemp()
    ns1_dir = os.path.join(tmp_col_root, 'ns1')
    ns2_dir = os.path.join(tmp_col_root, 'ns2')
    os.mkdir(ns1_dir)
    os.mkdir(os.path.join(ns1_dir, 'coll1'))
    os.mkdir(ns2_dir)
    os.mkdir(os.path.join(ns2_dir, 'coll1'))
    os.mkdir(os.path.join(ns2_dir, 'coll2'))

# Generated at 2022-06-22 19:25:13.954057
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths())



# Generated at 2022-06-22 19:25:22.853445
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test_list_collection_dirs tests the function list_collection_dirs
    import tempfile
    temp_root_dir = tempfile.mkdtemp()
    temp_ns_dir = tempfile.mkdtemp(dir=temp_root_dir)
    temp_coll_dir = tempfile.mkdtemp(dir=temp_ns_dir)
    temp_coll_dir2 = tempfile.mkdtemp(dir=temp_ns_dir)
    temp_coll_dir3 = tempfile.mkdtemp(dir=temp_ns_dir)
    coll_dirs = list(list_collection_dirs([temp_root_dir]))
    assert coll_dirs[0] == to_bytes(temp_coll_dir)
    assert coll_dirs[1] == to_bytes(temp_coll_dir2)

# Generated at 2022-06-22 19:25:33.720263
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():  # noqa
    assert '~/collections/ansible_collections' in list_valid_collection_paths(['~/collections/ansible_collections'])
    assert '~/collections' in list_valid_collection_paths(['~/collections'])
    assert '~/collections' in list_valid_collection_paths(['~/collections/ansible_collections'])
    assert '~/collections/ansible_collections' in list_valid_collection_paths(['~/collections'])
    assert '~/collections/ansible_collections' in list_valid_collection_paths(['~/collections', '~/collections/ansible_collections'])
    assert '~/collections/ansible_collections' in list_valid_collection_paths

# Generated at 2022-06-22 19:25:38.593819
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = [
        os.path.join(os.path.dirname(__file__), 'fixtures', 'collections')
    ]

    for coll_dir in list_collection_dirs(search_paths=collection_paths):
        print(coll_dir)



# Generated at 2022-06-22 19:25:48.426470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # This test uses the following filesystem tree:
    #
    #     /root/path/does/not/exist
    #     /tmp/ansible_collections/ns/coll
    #     /tmp/ns/coll/module
    #     /tmp/ns/coll/module2
    #     /tmp/ns/coll/tests/some_file
    #     /tmp/ns2/coll2/module
    #     /tmp/ns2/coll2/module2
    #     /tmp/ns2/coll2/tests/some_file

    # This is the collection file for "/tmp/ns/coll"
    collection1_file = {
        "namespace": "ns",
        "name": "coll",
        "version": "1.0.0"
    }

    # This is the collection file for "/tmp/

# Generated at 2022-06-22 19:26:00.264143
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    fixture_dir = 'test/utils/fixtures/collection_dirs'

    # Test 1: all collections
    paths = list_collection_dirs([fixture_dir])
    assert len(paths) == 3
    assert fixture_dir + '/ansible_collections/namespace1/collection' in paths
    assert fixture_dir + '/ansible_collections/namespace2/collection' in paths
    assert fixture_dir + '/ansible_collections/namespace3/collection' in paths

    # Test 2: one collection
    paths = list_collection_dirs([fixture_dir], coll_filter='namespace1.collection')
    assert len(paths) == 1
    assert fixture_dir + '/ansible_collections/namespace1/collection' in paths

    # Test 3: one namespace
    paths = list_collection

# Generated at 2022-06-22 19:26:10.349448
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Tests that we can find directory paths to ansible collections
    """
    import tempfile

    # create some temp dirs
    test_dir = tempfile.mkdtemp()
    coll_dir = tempfile.mkdtemp(dir=test_dir)
    coll1_dir = tempfile.mkdtemp(dir=coll_dir)
    coll2_dir = tempfile.mkdtemp(dir=coll_dir)
    bad_dir = tempfile.mkdtemp(dir=coll_dir)

    # create some temp files
    tempfile.NamedTemporaryFile(dir=coll1_dir)
    tempfile.NamedTemporaryFile(dir=coll2_dir)
    tempfile.NamedTemporaryFile(dir=bad_dir)

    # set up a list of test collection paths
    test_search_

# Generated at 2022-06-22 19:26:18.230418
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            search_paths=dict(type='list', elements='path'),
            warn=dict(type='bool', default=False),
        ),
    )

    search_paths = module.params.get('search_paths')
    warn = module.params.get('warn')

    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=warn))

    module.exit_json(changed=False, ansible_collections=valid_paths)



# Generated at 2022-06-22 19:26:26.394970
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = ['this_does_not_exist', 'path1', 'path2']
    paths = list(list_valid_collection_paths(paths, warn=True))
    assert len(paths) == 3

    # None should load defaults (not empty list), but no path objects should exist
    paths = list(list_valid_collection_paths(None, warn=True))
    assert len(paths) == 3, 'BAD: %r' % paths
    for path in paths:
        assert os.path.exists(path), 'BAD: %r' % path

# Generated at 2022-06-22 19:26:35.675809
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from os import mkdir, path
    from shutil import rmtree


# Generated at 2022-06-22 19:26:43.652857
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # check that an empty list returns the default paths
    assert list(list_valid_collection_paths([])) == [
        '/usr/share/ansible/collections',
        '/usr/share/ansible_collections',
        '/usr/local/share/ansible/collections'
    ]

    # verify the default list is returned when None is passed
    assert list(list_valid_collection_paths()) == [
        '/usr/share/ansible/collections',
        '/usr/share/ansible_collections',
        '/usr/local/share/ansible/collections'
    ]



# Generated at 2022-06-22 19:26:55.132333
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # test collection paths with no search_paths
    coll_paths = list(list_valid_collection_paths(search_paths=None))

    # test collection paths with non existing search_paths
    test_path1 = tempfile.mkdtemp()
    shutil.rmtree(test_path1)
    coll_paths = list(list_valid_collection_paths(search_paths=[test_path1]))
    assert len(coll_paths) == 0

    # test collection paths with valid search_paths
    test_path2 = tempfile.mkdtemp()
    coll_paths = list(list_valid_collection_paths(search_paths=[test_path2]))
    assert len(coll_paths) == 1
    assert test

# Generated at 2022-06-22 19:27:05.541362
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test a collection path
    coll_path = ["./test/units/collection_loader/fixtures"]
    coll_dirs = list(list_collection_dirs(search_paths=coll_path))
    assert 1 == len(coll_dirs)
    assert b'ns_coll1' in coll_dirs[0]

    # test muliple collection paths
    coll_path = ['./test/units/collection_loader/fixtures', "./test/units/collection_loader/fixtures2"]
    coll_dirs = list(list_collection_dirs(search_paths=coll_path))
    assert 2 == len(coll_dirs)

    # test a collection filter, which does not exist

# Generated at 2022-06-22 19:27:11.993286
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Simple: load all collections in search_paths
    collection_paths = []
    results = list(list_collection_dirs(collection_paths))
    assert len(results) > 0

    # Simple: load all collections in a specific search_path
    collection_paths = list_valid_collection_paths()
    results = list(list_collection_dirs(collection_paths))
    assert len(results) > 0

    # Load all collections in a specific namespace
    collection_paths = list_valid_collection_paths()
    results = list(list_collection_dirs(collection_paths, coll_filter='ansible'))
    assert len(results) > 0

    # Load specific collection in a specific namespace
    collection_paths = list_valid_collection_paths()

# Generated at 2022-06-22 19:27:21.962521
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test for missing path
    assert list(list_valid_collection_paths([os.getcwd() + '/tests/data/_doesnotexist'])) == []

    # test for empty dir
    assert list(list_valid_collection_paths([os.getcwd() + '/tests/data/_empty'])) == []

    # test for relative path
    assert list(list_valid_collection_paths(['tests/data/test_collections'])) == ['tests/data/test_collections']

    # test absolute path
    assert list(list_valid_collection_paths([os.path.abspath('./tests/data/test_collections')])) == [os.path.abspath('./tests/data/test_collections')]

    # test for file

# Generated at 2022-06-22 19:27:32.394778
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.test.test_utils.mock.mock import patch
    from ansible.collections.ansible.plugins.loader import _get_collection_config
    from ansible.collections.ansible.plugins.loader import _config_cache

    # prep
    _config_cache.clear()
    search_paths = [
        '/invalid/path',
        '/non/existent/path',
        '/invalid/path/file',
    ]

    # mock
    with patch.object(_get_collection_config, 'get_config_data') as m_gcd:
        fp = open('tests/unit/utils/ansible_collections/ansible/plugins/loader/ansible.cfg', 'r')

# Generated at 2022-06-22 19:27:37.981655
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os
    import shutil
    import tempfile

    # for cleanup
    search_paths = []


# Generated at 2022-06-22 19:27:43.378062
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import TemporaryDirectory
    from os import path

    with TemporaryDirectory() as tmpdirname:
        tmpdir = path.abspath(tmpdirname)
        test_paths = [path.join(tmpdir, 'ansible_collections'), path.join(tmpdir, 'not_a_directory'),
                      path.join(tmpdir, 'does_not_exist')]

        # Make sure a directory is created.
        os.mkdir(test_paths[0])

        # Make sure a file is created.
        with open(test_paths[1], 'w') as f:
            f.write('')

        actual_paths = list_valid_collection_paths(test_paths)
        assert [test_paths[0]] == list(actual_paths)

# Generated at 2022-06-22 19:27:49.671258
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        collection_dirs = list(list_collection_dirs(coll_filter='cloud.azure'))
    except AnsibleError as e:
        assert False, 'Error while attempting to list collection dirs: %s' % str(e)
    assert collection_dirs and len(collection_dirs) == 1, 'Azure collection not found'
    assert os.path.exists(os.path.join(collection_dirs[0], 'plugins', 'modules')), 'Azure modules not found in collection'



# Generated at 2022-06-22 19:27:59.288208
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    :return:
    """
    # set up temporary test path
    import tempfile
    test_search_path = tempfile.mkdtemp()

    # no paths supplied
    result = list(list_valid_collection_paths())
    assert test_search_path in result

    # no invalid paths
    result = list(list_valid_collection_paths([test_search_path]))
    assert test_search_path in result

    # invalid path, but not empty
    result = list(list_valid_collection_paths(['/tmp/does_not_exist']))
    assert test_search_path in result
    assert len(result) == 1

    # invalid path, but empty
    result = list(list_valid_collection_paths(['/tmp/does_not_exist'], False))
   

# Generated at 2022-06-22 19:28:09.951413
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Make some temp dirs
    base = tempfile.mkdtemp()
    valid1 = tempfile.mkdtemp(dir=base)
    valid2 = tempfile.mkdtemp(dir=base)
    valid3 = tempfile.mkdtemp(dir=base)
    valid4 = tempfile.mkdtemp(dir=base)
    valid5 = tempfile.mkdtemp(dir=base)

    # Non existing path
    not_a_dir = tempfile.mktemp(dir=base)
    open(not_a_dir, 'w').close()

    # Broken symlink
    link = tempfile.mktemp(dir=base)
    os.symlink(valid1, link)
    os.remove(link)

    # Symlink to file

# Generated at 2022-06-22 19:28:18.385398
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        for d in list_collection_dirs(search_paths=['../../../test/units/lib/ansible_test/_data'],
                                      coll_filter='google'):
            assert d.endswith('google')

        for d in list_collection_dirs(search_paths=['../../../test/units/lib/ansible_test/_data'],
                                      coll_filter='google.cloud'):
            assert d.endswith('google/cloud')
    except IndexError:
        pass  # FIXME: For some reason this is being called recursively by test runner



# Generated at 2022-06-22 19:28:30.254456
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # create a temp dir that is a collection
    fh, collection_dir = tempfile.mkstemp()
    os.close(fh)
    os.unlink(collection_dir)
    os.mkdir(collection_dir)

    # create a temp dir that is not a collection
    fh, no_collection_dir = tempfile.mkstemp()
    os.close(fh)
    os.unlink(no_collection_dir)
    os.mkdir(no_collection_dir)

    # create a temp dir that is a sub collection
    fh, sub_collection_dir = tempfile.mkstemp()
    os.close(fh)
    os.unlink(sub_collection_dir)
    os.mkdir(sub_collection_dir)
    collection_dir = os

# Generated at 2022-06-22 19:28:39.258675
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import tempfile
    import shutil
    import stat

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:28:45.054752
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = list(list_collection_dirs(['/mnt/ansible/ansible_collections']))
    assert len(coll_path) > 0
    coll_path = list(list_collection_dirs(['/mnt/ansible/ansible_collections', './foo']))
    assert len(coll_path) > 0
    coll_path = list(list_collection_dirs(['/mnt/ansible/ansible_collections', './foo/bar']))
    assert len(coll_path) > 0

    # with filter
    coll_path = list(list_collection_dirs(['/mnt/ansible/ansible_collections', './foo'], 'ansible_test.test_1'))
    assert len(coll_path) > 0

# Generated at 2022-06-22 19:28:45.961387
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:28:53.383866
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # get list of collection dirs
    success = []
    b_success = []
    for b_coll_dir in list_collection_dirs(search_paths=['test/unit/data/trellis', 'test/unit/data/mods'],
                                           coll_filter='ns.coll'):
        success.append(os.path.realpath(b_coll_dir))

        b_success.append(os.path.realpath(b_coll_dir))

    expected_success = [
        u"test/unit/data/trellis/ansible_collections/ns/coll",
        u"test/unit/data/mods/ansible_collections/ns/coll"
    ]

    assert success == expected_success
    assert b_success == expected_success

# Generated at 2022-06-22 19:28:54.726855
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list_collection_dirs())

# Generated at 2022-06-22 19:29:01.184314
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # search_paths=None, all paths are valid, one collection
    expected = ['/tmp/ansible_collections/mynamespace/mycollection']
    result = list(list_collection_dirs(coll_filter='mynamespace.mycollection'))
    assert expected == result

    # search_paths=None, all paths are valid, two collections
    expected = ['/tmp/ansible_collections/mynamespace/mycollection1', '/tmp/ansible_collections/mynamespace/mycollection2']
    result = list(list_collection_dirs(coll_filter='mynamespace'))
    assert expected == result

    # search_paths=None, all paths are valid, no collections
    result = list(list_collection_dirs(coll_filter='xyz'))
    assert [] == result

    #

# Generated at 2022-06-22 19:29:11.336773
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create fake directory to test function
    import tempfile
    import shutil
    fake_collection_root = tempfile.mkdtemp()
    fake_collection_path = os.path.join(fake_collection_root, 'ansible_collections')
    fake_namespace_path = os.path.join(fake_collection_path, 'fake_namespace')
    fake_collection_dir = os.path.join(fake_namespace_path, 'fake_collection')
    os.makedirs(fake_collection_dir)

    # Test function with valid search path
    dirs = list(list_collection_dirs([fake_collection_path]))
    assert len(dirs) == 1

    # Test function with invalid search path

# Generated at 2022-06-22 19:29:20.517408
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Verify list_valid_collection_paths() works
    """

    from tempfile import mkdtemp, mktemp
    from shutil import rmtree

    # create some empty temp paths
    tmp_paths = [mkdtemp() for _ in range(2)]
    tmp_paths.append(mktemp())

    # create some empty temp dirs
    tmp_dirs = [mkdtemp() for _ in range(3)]

    # check that all are found w/o warnings
    for path in list_valid_collection_paths(tmp_paths + tmp_dirs):
        assert path in tmp_dirs

    # check that all are found with warnings
    for path in list_valid_collection_paths(tmp_paths + tmp_dirs, warn=True):
        assert path in tmp_dirs



# Generated at 2022-06-22 19:29:24.674785
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # setup
    search_paths = ['/tmp/doesnotexist', '/tmp', '/does/not/exist']
    # run
    results = list_valid_collection_paths(search_paths, warn=True)
    # verify
    assert '/tmp' in results
    assert isinstance(results, list)


# Generated at 2022-06-22 19:29:31.890696
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = [u'.', u'./test-collections/ansible_collections', u'./test-collections/bad-collections']

    good_paths = list_valid_collection_paths(search_paths=paths, warn=False)

    assert(u'./test-collections/ansible_collections' in good_paths)

    bad_paths = list_valid_collection_paths(search_paths=paths, warn=True)

    assert(u'./test-collections/ansible_collections' in bad_paths)
    assert(u'./test-collections/bad-collections' not in bad_paths)

# Generated at 2022-06-22 19:29:39.467958
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    def create_tempfile(temp_dir, name):
        fd, path = tempfile.mkstemp(prefix=name, dir=temp_dir)
        os.close(fd)
        return path

    # create test directory in temp
    temp_top = tempfile.mkdtemp()

    # create valid collection paths
    path_exists = create_tempfile(temp_top, "exists")
    path_valid_dir = create_tempfile(temp_top, "valid_dir")
    os.remove(path_valid_dir)
    os.mkdir(path_valid_dir)
    path_invalid_file = create_tempfile(temp_top, "invalid_file")

# Generated at 2022-06-22 19:29:46.070211
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Check defaults
    valid = list(list_valid_collection_paths())
    assert valid

    # Check non-writable/existing paths are ignored
    valid = list(list_valid_collection_paths(['/foo', '/bar', '/baz']))
    assert not valid

    # Check valid paths are returned
    valid = list(list_valid_collection_paths(['/etc/ansible', '/usr/share/ansible']))
    assert valid

# Generated at 2022-06-22 19:29:54.114788
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    display.verbosity = 4
    collection_dirs = list(list_collection_dirs())

    assert isinstance(collection_dirs, list)

    for coll_dir in collection_dirs:
        assert os.path.exists(coll_dir)
        assert os.path.isdir(coll_dir)
        assert is_collection_path(coll_dir)

    module.exit_json(changed=False, collection_dirs=collection_dirs)



# Generated at 2022-06-22 19:30:03.407340
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def test_valid_coll_dir(coll_dir):
        assert is_collection_path(coll_dir)

    list(list_collection_dirs(warn=True, coll_filter='ansible_collections.ansible.builtin'))

    # TODO: Should we also test for collections which exist in multiple paths?
    #  Ansible core already is included in ansible_collections.$namespace.$collection and ansible_collections.$namespace
    for coll_dir in list_collection_dirs(coll_filter='ansible_collections.ansible.builtin'):
        test_valid_coll_dir(coll_dir)

    for coll_dir in list_collection_dirs(coll_filter='ansible_collections.ansible'):
        test_valid_coll_dir(coll_dir)


# Generated at 2022-06-22 19:30:12.738966
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    import ansible
    from ansible.module_utils import basic

    class TestListCollectionDirs(unittest.TestCase):

        def setUp(self):
            self.search_path = [os.path.join(ansible.__path__[0], 'collections')]
            self.coll_filter = None
            self.coll_root = os.path.join(self.search_path[0], 'ansible_collections')

        def tearDown(self):
            pass
