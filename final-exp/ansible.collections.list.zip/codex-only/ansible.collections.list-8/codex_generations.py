

# Generated at 2022-06-22 19:20:17.786685
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test that list_collection_dirs returns a list of collection directories."""

    # Create a directory to use as a collection
    test_coll_path = u'test_coll'
    os.mkdir(test_coll_path)
    os.mkdir(os.path.join(test_coll_path, u'ansible_collections'))
    os.mkdir(os.path.join(test_coll_path, u'ansible_collections', u'test_ns'))
    os.mkdir(os.path.join(test_coll_path, u'ansible_collections', u'test_ns', u'test_coll'))
    os.mkdir(os.path.join(test_coll_path, u'ansible_collections', u'test_ns2'))
    os.mkdir

# Generated at 2022-06-22 19:20:25.886699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected_paths = ["path1", "path2", "path3"]

    # This is the exact call that the collection loader makes to list valid search paths

# Generated at 2022-06-22 19:20:37.273675
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible
    test_paths = [os.path.join(os.path.dirname(ansible.__file__), 'test', 'data', 'test_collections_config')]
    coll_dirs = list(list_collection_dirs(test_paths))
    assert len(coll_dirs) == 2
    assert os.path.basename(coll_dirs[0]) == 'test_collection1'
    assert os.path.basename(coll_dirs[1]) == 'test_collection2'

# Generated at 2022-06-22 19:20:45.604320
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = ['/nonexistent_dir/',  # non-existent dir
             '/etc/nonexistent_dir/',  # non-existent dir
             '/etc/',  # existing dir
             './etc/',  # relative path
             '/etc/../etc',  # relative path
             '/etc/../etc/ansible',  # relative path
             '/etc/ansible/',  # existing dir
             ]

    paths = list_valid_collection_paths(search_paths=paths)

    assert len(list(paths)) == 3
    assert '/etc/ansible/' in paths

# Generated at 2022-06-22 19:20:53.687231
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Search list with no defaults specified, should only return existing paths
    test_list = ['/tmp', '/does/not/exist/path']
    test_ret_list = list(list_valid_collection_paths(test_list))
    assert test_ret_list == ['/tmp']

    # Search list with defaults specified, should return existing paths
    AnsibleCollectionConfig.collection_paths.append('/default/path')
    test_ret_list = list(list_valid_collection_paths(test_list))
    assert test_ret_list == ['/tmp', '/default/path']

    AnsibleCollectionConfig.collection_paths = []


# Generated at 2022-06-22 19:21:04.549825
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six.moves.builtins import range

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    coll_dirs = list_collection_dirs()

    for i in range(3):
        path = AnsibleCollectionConfig.collection_paths[i]
        assert path in coll_dirs, 'Path "{0}" not found in list of collection directories'.format(path)

    # check de-duped
    counts = OrderedDict()
    for coll_dir in coll_dirs:
        count = counts.get(coll_dir, 0)
        counts[coll_dir] = count + 1


# Generated at 2022-06-22 19:21:08.503789
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # empty list should return configured paths
    result = list(list_valid_collection_paths())
    assert isinstance(result, list)

    # by default configured paths should not be empty
    result = list(list_valid_collection_paths())
    assert len(result) > 0



# Generated at 2022-06-22 19:21:12.756273
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    correct_path = [
        '/tmp/collections',          # existing dir
        '/tmp/doesnotexists'         # non existent dir
    ]

    ok_paths = list(list_valid_collection_paths(search_paths=correct_path, warn=True))

    assert len(ok_paths) == 1
    assert ok_paths[0] == correct_path[0]


# Generated at 2022-06-22 19:21:23.672766
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Utility function to be used to test list_valid_collection_paths
    :return:
    """
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils._text import to_native

    # Create a new config parser and read a dummy collection.cfg,
    # since AnsibleCollectionConfig uses an existing one otherwise
    parser = configparser.ConfigParser()
    parser.read(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'test_collections.cfg'))
    default_config = AnsibleCollection

# Generated at 2022-06-22 19:21:27.807897
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Expected use case:
    >>> from ansible.utils.collection_loader import list_collection_dirs
    >>> coll_dirs = list(list_collection_dirs())
    """

    pass

# Generated at 2022-06-22 19:21:31.950860
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = ['/tmp', 'invalid/path', '/tmp/ansible_collections', '/tmp/ansible_collections/example/test']
    result = list_collection_dirs(search_paths=dirs)
    assert '/tmp/ansible_collections/example/test' in result



# Generated at 2022-06-22 19:21:36.168354
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths(search_paths=['/does/not/exist']) is not None
    assert list_valid_collection_paths(search_paths=[]) is not None
    assert list_valid_collection_paths(search_paths=['/tmp']) is not None

# Generated at 2022-06-22 19:21:42.788954
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    def create_test_collections(root_dir):
        os.mkdir('test1.namspace1')
        os.mkdir('test1.namspace2')
        open('test1.namspace1.metadata.json', 'w').close()
        open('test1.namspace2.metadata.json', 'w').close()

        os.mkdir('test2.namspace1')
        os.mkdir('test2.namspace2')
        open('test2.namspace1.metadata.json', 'w').close()
        open('test2.namspace2.metadata.json', 'w').close()

        os.mkdir(os.path.join(root_dir, 'test1.namspace1', 'plugins'))

# Generated at 2022-06-22 19:21:52.108911
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test without filter
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) == 14

    # Test with namespace filter
    collection_dirs = list(list_collection_dirs(coll_filter='community'))
    assert len(collection_dirs) == 10

    # Test with collection filter
    collection_dirs = list(list_collection_dirs(coll_filter='community.general'))
    assert len(collection_dirs) == 1

    # Test with invalid collection filter
    collection_dirs = list(list_collection_dirs(coll_filter='community.thisdoesntexist'))
    assert len(collection_dirs) == 0

# Generated at 2022-06-22 19:21:58.544812
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = [
        u'/opt/ansible/collections/ansible_collections/testns/testcoll',
        u'/opt/ansible/collections/ansible_collections/testns/mixed_case_coll',
    ]

    test_path = u'/opt/ansible/collections'
    test_coll_filter = u'testns.testcoll'

    res = list(list_collection_dirs(search_paths=[test_path], coll_filter=test_coll_filter))
    assert res == expected



# Generated at 2022-06-22 19:22:08.108080
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths())
    assert list(list_valid_collection_paths([]))
    assert list(list_valid_collection_paths(['/tmp/foo']))
    assert list(list_valid_collection_paths(['/tmp/bar', '/tmp/baz']))
    assert type(list(list_valid_collection_paths(['/tmp/blah']))) is list
    assert type(list(list_valid_collection_paths(['/tmp/foo', '/tmp/bar']))) is list
    assert type(list(list_valid_collection_paths(['/tmp/baz', '/tmp/qux']))) is list

# Generated at 2022-06-22 19:22:09.111164
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list_valid_collection_paths())

# Generated at 2022-06-22 19:22:17.622147
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # list of paths
    paths = ['/test/this', '/test/that/next']

    # list of paths with duplicate
    paths_dup = paths + ['/test/this']

    # empty list of paths
    paths_empty = []

    # empty list of paths
    paths_none = None

    # list of paths in string format
    paths_str = "/test/this,/test/that/next"

    # list of paths in string format with duplicate
    paths_str_dup = "/test/this,/test/that/next,/test/this"

    # empty list of paths in string format
    paths_str_none = None

    # negative test with collection path not found
    should_error = False

# Generated at 2022-06-22 19:22:26.767739
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    list_of_paths = ['/asdf', 'asdf/asdf.txt']
    valid_paths = list(list_valid_collection_paths(list_of_paths, warn=True))
    assert len(valid_paths) == 0, "Test failed: No paths should be valid"

    list_of_paths = ['/asdf/', '/asdf/asdf.txt']
    valid_paths = list(list_valid_collection_paths(list_of_paths, warn=True))
    assert len(valid_paths) == 1, "Test failed: One path should be valid"


# Generated at 2022-06-22 19:22:29.507504
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs
    :return:
    """


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:22:37.060987
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Test list_valid_collection_paths")

    # a list of paths to test, which may or may not exist at run time
    test_paths = [
        'foo',
        'bar',
        '/path/to/baz',
        os.path.expanduser('~'),
        'foo/bar',
        '/path/to/baz/../foo'
    ]

    # using default search paths
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)

    # testing paths with some existing, some not existing or non-dirs
    existing_paths = []
    for test_path in test_paths:
        b_test_path = to_bytes(test_path)

# Generated at 2022-06-22 19:22:44.126113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [os.getcwd()]

    # if we are using the test directory as the collection path, it will not exist
    list_valid_collection_paths(test_paths, warn=True)

    test_paths = AnsibleCollectionConfig.collection_paths
    test_paths.extend(['/tmp/bogusdir'])

    coll_paths = list_valid_collection_paths(test_paths, warn=True)
    for path in coll_paths:
        assert os.path.exists(path)

# Generated at 2022-06-22 19:22:48.240486
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll_filter = None
    test_search_paths = ['test/unit/modules']
    list_of_collections = list_collection_dirs(search_paths=test_search_paths, coll_filter=test_coll_filter)
    for coll_dir in list_of_collections:
        display.display("found collection: {0}".format(coll_dir))



# Generated at 2022-06-22 19:22:52.905290
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Method test_list_collection_dirs
    """

    current_dir = os.path.dirname(os.path.realpath(__file__))

    collections = list(list_collection_dirs([current_dir]))
    assert collections


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:23:03.092950
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    coll_dirs = {}

    # the first path should be in the list
    search_paths = [tmpdir]

    # create a normal collection directory
    coll_dirs['n1.c1'] = os.path.join(tmpdir, 'ansible_collections', 'n1', 'c1')
    os.makedirs(coll_dirs['n1.c1'])
    open(os.path.join(coll_dirs['n1.c1'], 'plugins', 'module_utils', '__init__.py'), 'a').close()

    # create a second namespace

# Generated at 2022-06-22 19:23:15.243712
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_path = [u'~/.ansible/collections', u'/usr/share/ansible/collections']

    # test collections to find
    mycolls = [u"ansible_collections.notmintest.not_a_real_collection",
               u"ansible_collections.anothernamespace.more_ficticious_collection",
               u"ansible_collections.notmintest.testing01"]

    my_coll_dir = list_collection_dirs(coll_path, coll_filter=u"ansible_collections.notmintest.testing01")

    for coll in my_coll_dir:
        print("Found Collection: %s" % coll)

    coll_dir = list_collection_dirs(coll_path, coll_filter=u"ansible_collections.notmintest")


# Generated at 2022-06-22 19:23:19.152380
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # with undefined config collection paths, should be empty list
    assert [] == list(list_valid_collection_paths([]))

    # with non existing collection path, should be empty list
    search_paths = [os.path.expanduser("~/.ansible/collections_test")]
    assert [] == list(list_valid_collection_paths(search_paths))

# Generated at 2022-06-22 19:23:32.452348
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    list_collection_dirs returns a dictionary of the collections found in the configured
    search paths.
    With no arguments it returns all collections
    With an argument it returns just that collection
    With an argument of the form NAMESPACE it returns all collections in that namespace
    """

    # a valid test collection (for now just a dir with the right name)
    valid_coll_dir = "collection_dir"
    # a valid namespace dir (for now just a dir with the right name)
    valid_ns_dir = "namespace_dir"

    # a test lookup of the config
    from ansible.config.manager import ConfigManager
    config = ConfigManager().get_config_obj(None)
    config.clear()
    search_paths = config.get_config_value('collections_paths')

# Generated at 2022-06-22 19:23:38.819327
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # No search_paths or collection provided so should load default
    dirs = list(list_collection_dirs())

    # List should contain at least one item
    assert len(dirs) > 0

    # All items in the list should be directories
    for item in dirs:
        assert os.path.isdir(item)

# Generated at 2022-06-22 19:23:42.637991
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for p in list_valid_collection_paths():
        print(p)


if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-22 19:23:54.010146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    path1 = tempfile.mkdtemp()
    path2 = tempfile.mkdtemp()
    collection1 = tempfile.mkdtemp(dir=path1)
    collection2 = tempfile.mkdtemp(dir=path2)

    open(os.path.join(collection1, '__init__.py'), 'wb').close()
    open(os.path.join(collection2, '__init__.py'), 'wb').close()

    search_paths = [path1, path2]
    full_collection = os.path.basename(collection1)
    assert full_collection in [os.path.basename(x) for x in list_collection_dirs(search_paths)]

    namespace = os.path.basename(os.path.dirname(collection1))
    assert full

# Generated at 2022-06-22 19:24:02.082319
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test default paths
    paths = list(list_valid_collection_paths())
    assert len(paths) > 0

    # make sure default paths are valid
    for path in paths:
        assert path

    # test that it works with a single path
    paths = list(list_valid_collection_paths(search_paths='~'))

    # make sure the path is valid
    for path in paths:
        assert path



# Generated at 2022-06-22 19:24:14.557431
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    from shutil import copyfile, copytree, rmtree


# Generated at 2022-06-22 19:24:24.413436
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.plugins.loader import find_plugin

    def _assert(coll_filter, expected):

        plugin_dirs = list(list_collection_dirs(search_paths=[], coll_filter=coll_filter))

        for p in plugin_dirs:
            if p not in expected:
                raise AssertionError("%s was not found in %s" % (p, expected))

        for p in expected:
            if p not in plugin_dirs:
                raise AssertionError("%s was not found in %s" % (p, plugin_dirs))

        # by using a set to compare, we can ensure they are the same
        assert set(plugin_dirs) == set(expected)


# Generated at 2022-06-22 19:24:32.986630
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    import shutil
    from ansible.utils.collection_loader import _get_collection_base_path

    tempdir = mkdtemp()
    coll_root = os.path.join(tempdir, 'ansible_collections')
    os.mkdir(coll_root)
    namespace_dir = os.path.join(coll_root, 'myns')
    os.mkdir(namespace_dir)
    collection_dir = os.path.join(namespace_dir, 'mycoll')
    os.mkdir(collection_dir)
    collection_dir_no_init = os.path.join(namespace_dir, 'mycoll_no_init')
    os.mkdir(collection_dir_no_init)

# Generated at 2022-06-22 19:24:43.314096
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test that list_collection_dirs returns the expected directory paths
    '''
    from ansible.ansible_collections.ansible.builtin.tests import (
        fixtures_path,
    )
    assert list_collection_dirs([fixtures_path]) == [
        os.path.join(fixtures_path, 'ansible_collection_one')
    ]
    assert list_collection_dirs() == [os.path.join(fixtures_path, 'ansible_collection_one')]
    assert list_collection_dirs([fixtures_path], 'ns') == [
        os.path.join(fixtures_path, 'ansible_collection_one')
    ]

# Generated at 2022-06-22 19:24:48.368031
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs([u'../test/collections']))
    assert dirs == [u'../test/collections/ansible_collections/test/plugins/module_utils/nested.py']


# Generated at 2022-06-22 19:24:56.461606
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This function is used to test list_collection_dirs function.
    """
    import tempfile

    tempdir1 = tempfile.TemporaryDirectory(prefix="ansible_collections_test_")
    tempdir2 = tempfile.TemporaryDirectory(prefix="ansible_collections_test_")
    tempdir3 = tempfile.TemporaryDirectory(prefix="ansible_collections_test_")
    tempdir4 = tempfile.TemporaryDirectory(prefix="ansible_collections_test_")

    # create first level directories in tempdir2
    for dirname in ["test1", "test2", "test3"]:
        os.mkdir(os.path.join(tempdir2.name, dirname))

    # create first level directories in tempdir1
    # and second level directories with valid collection
    test_

# Generated at 2022-06-22 19:25:05.656292
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        list(list_collection_dirs(search_paths=['bad_path'], coll_filter='ansible_collections.ns.coll'))
    except:
        pass
    try:
        list(list_collection_dirs(search_paths=['bad_path'], coll_filter='bad.collection'))
    except:
        pass
    try:
        list(list_collection_dirs(search_paths=['bad_path'], coll_filter='bad.ns.coll'))
    except:
        pass
    list(list_collection_dirs(search_paths=['bad_path'], coll_filter='ns.coll'))
    list(list_collection_dirs(search_paths=['bad_path'], coll_filter='ns'))

# Generated at 2022-06-22 19:25:13.665119
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    # Test with a collection
    temp_dir = tempfile.mkdtemp()
    assert os.path.exists(temp_dir)
    temp_coll_dir = tempfile.mkdtemp(dir=temp_dir)

    test_result = set(list_collection_dirs([temp_dir], 'my_namespace.my_collection'))
    assert len(test_result) == 1
    assert temp_coll_dir in test_result

    # Test without a collection
    test_result = set(list_collection_dirs([temp_dir], 'my_namespace'))
    assert len(test_result) == 1
    assert temp_coll_dir in test_result

    # Test without a namespace
    test_result = set(list_collection_dirs([temp_dir]))

# Generated at 2022-06-22 19:25:21.655875
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six import PY3

    results = list(list_valid_collection_paths(['/invalid/path', '/invalid/path2']))
    assert results == ['/invalid/path', '/invalid/path2'], 'Failed to return list of paths'

    # Make sure the user library paths are added
    #   - On PY2, added to the search_paths parameter when calling list_valid_collection_paths()
    #   - On PY3, added to the AnsibleCollectionConfig default_collection_paths
    py3_user_lib_path = b'/usr/share/ansible/ansible_collections/ansible_namespace/collection/plugins/module_utils/'

# Generated at 2022-06-22 19:25:33.002775
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Create some test paths to work with
    test_path = os.getcwd() + '/tests/list_collection_paths'
    test_path2 = test_path + '/fake_path'
    test_path3 = test_path + '/fake_file'
    # Test a valid path
    valid_path = list_valid_collection_paths(search_paths=[test_path])
    assert next(valid_path) == test_path
    # Test an invalid path
    try:
        next(list_valid_collection_paths(search_paths=[test_path2]))
    except StopIteration:
        pass
    # Test a path to a file

# Generated at 2022-06-22 19:25:36.464825
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = []
    for d in list_collection_dirs(coll_filter='one.collection'):
        assert d is not None
        dirs.append(d)
    assert len(dirs) == 1



# Generated at 2022-06-22 19:25:47.308753
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # confirm path filter doesn't include non-existing dirs
    test_path = ['/foo', '/bar']
    results = list_collection_dirs(search_paths=test_path, warn=True)
    assert(list(results) == [])

    # confirm list_collection_dirs returns known collection
    test_path = [os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../../')]
    results = list_collection_dirs(search_paths=test_path)
    assert(len(list(results)) == 1)

    # confirm list_collection_dirs filter on collection

# Generated at 2022-06-22 19:25:52.984185
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    paths = list_valid_collection_paths(search_paths=['/tmp', '/does-not-exist'], warn=False)
    assert '/tmp' in paths

# Generated at 2022-06-22 19:26:00.221818
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/test_folder1', '/test_folder2', '/test_folder3']
    test_paths = list_valid_collection_paths(search_paths)
    assert to_bytes(next(test_paths)) == to_bytes('/test_folder1')
    assert to_bytes(next(test_paths)) == to_bytes('/test_folder2')
    assert to_bytes(next(test_paths)) == to_bytes('/test_folder3')
    with pytest.raises(StopIteration):
        next(test_paths)



# Generated at 2022-06-22 19:26:10.301588
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test passing in a single collection
    test_collections = list(list_collection_dirs(search_paths=['/home/user/collections']))
    assert test_collections == [b'/home/user/collections/ansible_collections/test/test_collection_1']

    # test passing in multiple collections
    test_collections = list(list_collection_dirs(search_paths=['/home/user/collections', '/home/user/more_collections']))
    assert len(test_collections) == 2  # test that they are both there
    assert b'/home/user/collections/ansible_collections/test/test_collection_1' in test_collections
    assert b'/home/user/more_collections/ansible_collections/test/test_collection_2'

# Generated at 2022-06-22 19:26:19.285290
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible.my_test_collection.tests.unit.module_utils import test_data_utils
    from ansible_collections.ansible.my_test_collection.tests.unit.module_utils.test_list_collection_dirs import TestListCollectionDirs

# Generated at 2022-06-22 19:26:23.330810
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert [] == list(list_valid_collection_paths(search_paths=['bad_path']))
    assert [] == list(list_valid_collection_paths(search_paths=[]))



# Generated at 2022-06-22 19:26:34.239520
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # pylint: disable=protected-access
    # Create a dict of search paths to test
    paths_to_test = {
        '/a/b/c': False,  # does not exist
        '/usr/share': True,  # exists, but not a dir
        '/etc/ansible/': True,  # exists and is a dir
    }
    should_warn = {
        '/a/b/c': True,  # does not exist
        '/usr/share': True,  # exists, but not a dir
        '/etc/ansible/': False,  # exists and is a dir
    }
    # Create temporary test files and directories
    for path in paths_to_test:
        if paths_to_test[path] is True:
            os.makedirs(path)

# Generated at 2022-06-22 19:26:38.758651
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        '/tmp/invalid/path',
        '/tmp/ansible',
        '/tmp/ansible/ansible_collections',
        '/tmp/ansible/ansible_collections/some_namespace/some_collection',
    ]

    assert [
        '/tmp/ansible/ansible_collections',
        '/tmp/ansible/ansible_collections/some_namespace/some_collection',
    ] == list(list_valid_collection_paths(paths, warn=True))

# Generated at 2022-06-22 19:26:46.034674
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.six.moves import builtins

    assert list_valid_collection_paths() == list_valid_collection_paths(search_paths=None, warn=False)
    assert list_valid_collection_paths([]) == list_valid_collection_paths(search_paths=[], warn=False)

    assert list_valid_collection_paths(search_paths=[builtins.__file__]) == []
    assert list_valid_collection_paths(search_paths=[os.path.dirname(__file__)]) == [os.path.dirname(__file__)]

# Generated at 2022-06-22 19:26:50.777328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collections_path = [
        'test/unit/plugins/modules/sample_collections/collections',
        'test/unit/plugins/modules/sample_collections/collections_2'
    ]
    test_collections_dirs = list(list_collection_dirs(test_collections_path))
    assert len(test_collections_dirs) == 2

# Generated at 2022-06-22 19:27:02.003835
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test defaults
    default = list(list_valid_collection_paths())
    assert len(default) == 2

    # test empty list
    path = os.path.expanduser('~/ansible')
    empty_paths = list(list_valid_collection_paths([]))
    assert not len(empty_paths)

    # test new single path
    new_paths = list(list_valid_collection_paths([path]))
    assert len(new_paths) == 1
    assert new_paths[0] == path

    # test new multiple paths
    new_paths = list(list_valid_collection_paths([path, path]))
    assert len(new_paths) == 1
    assert new_paths[0] == path

    # test new multiple paths, one exists


# Generated at 2022-06-22 19:27:05.301592
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected_paths = list()
    result = list(list_valid_collection_paths(search_paths=['/path/to/nonexisting', '/dev/null']))
    assert result == expected_paths



# Generated at 2022-06-22 19:27:11.848845
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with a single collection and namespace
    dirs = list(list_collection_dirs(coll_filter='community.general'))
    assert len(dirs) == 1
    assert dirs[0].endswith("ansible_collections/community/general")

    # Test with no filter specified
    dirs = list(list_collection_dirs())
    assert len(dirs) >= 2
    assert dirs[0].endswith("ansible_collections/ansible/ansible")
    assert dirs[1].endswith("ansible_collections/community/general")

    # Test with multiple collections and namespaces
    dirs = list(list_collection_dirs(coll_filter='ansible.ansible,community.general'))
    assert len(dirs) == 2

# Generated at 2022-06-22 19:27:21.872154
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # build some tracker for the test methods
    valid_paths = []
    invalid_paths = []
    warnings = []

    def fake_warn(msg):
        warnings.append(msg)

    display.warning = fake_warn

    root = os.path.abspath(os.path.dirname(__file__))
    test_dir = root + '/unit_test_collections/'
    valid_paths.append(test_dir + 'ansible_collections')
    valid_paths.append(test_dir + 'ansible_collections/namespace1/collection1')
    valid_paths.append(test_dir + 'ansible_collections/namespace1/collection1/plugins/modules')
    valid_paths.append(test_dir + 'ansible_collections/empty_collection')


# Generated at 2022-06-22 19:27:31.422351
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    valid_collections_paths = list_valid_collection_paths()
    collection_path_next = next(valid_collections_paths, None)
    assert (collection_path_next is not None)

    valid_collections_paths = list_valid_collection_paths(search_paths=[])
    collection_path_next = next(valid_collections_paths, None)
    assert (collection_path_next is not None)

    valid_collections_paths = list_valid_collection_paths(search_paths=['/tmp/none'])
    collection_path_next = next(valid_collections_paths, None)
    assert (collection_path_next is None)

# Generated at 2022-06-22 19:27:38.457654
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Generate list of valid collection paths
    """
    defaults = AnsibleCollectionConfig.collection_paths
    paths = defaults + ["/notamodule"]

    one_result = list(list_valid_collection_paths(paths, warn=True))
    assert len(one_result) == len(defaults)
    assert all(p in one_result for p in defaults)


# Generated at 2022-06-22 19:27:48.457955
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    base_dir = '/tmp'
    search_paths = [
        os.path.join(base_dir, "ansible_collections/test.test/"),
        "/bogus/path/",
        os.path.join(base_dir, "noncollections/test.test/"),
        None,
    ]

    for path in search_paths:
        if path is not None and os.path.exists(path):
            os.rmdir(path)

    if os.path.exists(os.path.join(base_dir, "noncollections/test.test")):
        os.rmdir(os.path.join(base_dir, "noncollections/test.test"))

# Generated at 2022-06-22 19:27:58.540659
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test case 1: search_paths : None
    # Expected result: Default config

    search_path = None

    results = list(list_valid_collection_paths(search_path))

    if len(results) > 0:

        for result in results:

            if "/ansible_collections" in str(result):
                assert True
            else:
                assert False
    else:
        assert False

    # Test case 2: search_paths : Valid search paths
    # Expected result: Valid search paths


# Generated at 2022-06-22 19:28:09.877478
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = ['test/ansible_collections', 'test/fake_collections', 'test/non_existant_dir']
    test_collections = list(list_collection_dirs(search_paths=test_paths))
    assert len(test_collections)
    # this test collection is only guaranteed to have 2 collections
    assert len(test_collections) == 2

    # Ansible 2.9 and above have an extra collection and role
    if os.path.isdir(b"test/ansible_collections/c/dummy"):
        assert len(test_collections) == 3

    # Ansible 2.8 and lower have an extra collection

# Generated at 2022-06-22 19:28:13.510000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [os.path.join('mytest', 'ansible_collections'), 'test_path']
    out = list_valid_collection_paths(search_paths)
    assert out == ('test_path',)

# Generated at 2022-06-22 19:28:21.232775
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with input list of search_paths, expected result is the same list
    search_paths = [
        '/usr/share/ansible',
        '/usr/share/ansible/ansible_collections',
        '/usr/share/ansible/collections',
        '/usr/local/share/ansible_collections',
    ]
    assert list(list_valid_collection_paths(search_paths=search_paths)) == search_paths

    # Test with no input search_paths, expected result is the default list of paths
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:28:31.507510
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # create test collection directory structure in temp dir
    tmpdir = tempfile.mkdtemp()
    namespace = 'namespace'
    collection = 'collection'
    collection_path = os.path.join(tmpdir, 'ansible_collections', namespace, collection)
    os.makedirs(collection_path)

    # check it is returned in list
    l = list(list_collection_dirs(search_paths=[tmpdir]))
    assert l[0] == collection_path

    # check None is returned if path is invalid
    l = list(list_collection_dirs(search_paths=[tmpdir+'wrongpath']))
    assert l == []

    # check if coll_filter is present, only exact match is returned

# Generated at 2022-06-22 19:28:40.073984
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    working_dir = tempfile.mkdtemp()

    my_collections = os.path.join(working_dir, 'my_collections')
    os.mkdir(my_collections)
    os.mkdir(os.path.join(my_collections, 'my_ns'))
    os.mkdir(os.path.join(my_collections, 'podman'))

    os.mkdir(os.path.join(my_collections, 'my_ns', 'my_coll'))
    os.mkdir(os.path.join(my_collections, 'podman', 'collections'))
    os.mkdir(os.path.join(my_collections, 'podman', 'collections', 'collection1'))

# Generated at 2022-06-22 19:28:51.773107
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    dirs = [
        {'path': '/usr/share/ansible/collections', 'ns': 'namespace1', 'coll': 'collection1'},
        {'path': '/etc/ansible/collections', 'ns': 'namespace2', 'coll': 'collection2'},
        {'path': '/home/ansible/collections', 'ns': 'namespace3', 'coll': 'collection3'},
        {'path': '/tmp/a/b/c/d/e/f/g', 'ns': 'namespace4', 'coll': 'collection4'},
        {'path': '/tmp/a/b', 'ns': 'namespace5', 'coll': 'collection5'},
    ]

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-22 19:28:59.804443
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['test/test_test.test','test/test_test.test/test/test_test.test']

    def mock_list_valid_collection_paths(search_paths, warn=False):
        for path in search_paths:
            if os.path.exists(path):
                yield path

    mock_list_valid_collection_paths_old = list_valid_collection_paths
    list_valid_collection_paths = mock_list_valid_collection_paths

    try:
        dirs = list(list_collection_dirs(search_paths, None))
    finally:
        list_valid_collection_paths = mock_list_valid_collection_paths_old

    assert len(dirs) == 2



# Generated at 2022-06-22 19:29:10.271003
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # python 2.6 does not have assertIn/assertNotIn
    from unittest.case import SkipTest

    try:
        assertIn
    except NameError:
        def assertIn(a, b, *args, **kwargs):
            if a not in b:
                raise AssertionError(*args, **kwargs)
    try:
        assertNotIn
    except NameError:
        def assertNotIn(a, b, *args, **kwargs):
            if a in b:
                raise AssertionError(*args, **kwargs)

    # Test list_valid_collection_paths with no args and no config
    display.verbosity = 3
    valid_paths = list(list_valid_collection_paths())
    assert len(valid_paths) == 9

# Generated at 2022-06-22 19:29:20.610911
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import os
    import shutil
    import random

    tmpdir = tempfile.mkdtemp(dir=to_bytes(os.path.dirname(__file__)))


# Generated at 2022-06-22 19:29:28.567679
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/path/should/fail/if/not/exist',
        'exists_but_not_dir',
        '/tmp',
    ]
    result = list_valid_collection_paths(search_paths)

    # ensure the result didn't remove entries that do exist
    for path in ['/tmp']:
        assert path in result

    # ensure the result removed entries that didn't exist
    for path in ['/path/should/fail/if/not/exist']:
        assert path not in result

    # ensure the result removed entries that were not directories
    for path in ['exists_but_not_dir']:
        assert path not in result

# Generated at 2022-06-22 19:29:30.797814
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths())



# Generated at 2022-06-22 19:29:40.817828
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_path = "/usr/share/ansible_collections"
    coll_filter = "ansible.builtin"
    coll_filter_no_namespace = "builtin"
    coll_filter_no_match = "doesnotexist.doesnotexist"

    collection_dirs = list_collection_dirs([coll_path], coll_filter)
    assert next(collection_dirs) == b'/usr/share/ansible_collections/ansible/builtin'
    try:
        next(collection_dirs)
        assert False, "Expected StopIteration"
    except StopIteration:
        pass

    collection_dirs = list_collection_dirs([coll_path], coll_filter_no_namespace)

# Generated at 2022-06-22 19:29:51.904965
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """This function tests the list_collection_dirs function"""
    cwd = os.getcwd()
    default_collection_paths = AnsibleCollectionConfig.collection_paths
    test_dirs = []

    # Create test directories
    for path in list_valid_collection_paths(search_paths=default_collection_paths):
        path = os.path.join(path, 'ansible_collections', 'test_collection')
        if not os.path.exists(path):
            os.makedirs(path)
        test_dirs.append(path)

    # Check test dirs with out filter or namespace
    for test_dir in list_collection_dirs():
        assert test_dir in test_dirs

    # Check test dirs with filter

# Generated at 2022-06-22 19:29:55.910256
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/etc/ansible/collections', '/test/test2', '/test/test3']
    paths = list(list_valid_collection_paths(paths, warn=True))
    assert len(paths) == 1

# Generated at 2022-06-22 19:30:01.584033
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['test_data/valid_collection_paths']
    for path in list_valid_collection_paths(search_paths):
        assert path == 'test_data/valid_collection_paths'
    search_paths.append('test_data/invalid_collection_paths')
    for path in list_valid_collection_paths(search_paths):
        assert path == 'test_data/valid_collection_paths'



# Generated at 2022-06-22 19:30:08.272985
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    from tempfile import mkdtemp

    def create_empty_file(path):
        fd = os.open(path, os.O_WRONLY | os.O_CREAT, 0o600)
        os.close(fd)

    tmp_dir = to_bytes(mkdtemp())

    test_paths = [
        ['', False],
        [os.path.join(tmp_dir, 'a'), True],
        [os.path.join(tmp_dir, 'b'), True],
        [os.path.join(tmp_dir, 'c'), True],
        [os.path.join(tmp_dir, 'd'), True]
    ]
