

# Generated at 2022-06-22 19:20:14.349853
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    d1 = tempfile.mkdtemp()
    d2 = tempfile.mkdtemp()
    d3 = tempfile.mkdtemp()

    f = tempfile.NamedTemporaryFile(delete=False)

    b_d1 = to_bytes(d1)
    b_d2 = to_bytes(d2)
    b_d3 = to_bytes(d3)
    b_f = to_bytes(f.name)

    with open(b_f, 'w') as fd:
        fd.write('')


# Generated at 2022-06-22 19:20:23.926090
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    b = to_bytes(os.path.sep)

    coll_root = tempfile.mkdtemp()
    coll_path = os.path.join(coll_root, 'ansible_collections')

    path1 = os.path.join(coll_path, 'mynamespace')
    path1 = os.path.join(path1, 'mycollection_valid')
    path2 = os.path.join(coll_path, 'mynamespace')
    path2 = os.path.join(path2, 'othercollection_valid')

    os.makedirs(path1)
    open(os.path.join(path1, 'MANIFEST.json'), 'w').close()
    os.makedirs(path2)

# Generated at 2022-06-22 19:20:32.363712
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/home/test/collections',
        '/etc/ansible/collections',
    ]
    expected_paths = [
        '/etc/ansible/collections',
    ]
    expect_default = False
    len_default = 0
    for result in list_valid_collection_paths(search_paths):
        if result == '/etc/ansible/collections':
            expect_default = True
        else:
            len_default = len_default+1
    assert expect_default == True
    assert len_default == 0


# Generated at 2022-06-22 19:20:41.797872
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import defaultdict
    from ansible.utils.collection_loader import list_collection_dirs, get_plugin_paths, AnsibleCollectionConfig
    ansible_collections_paths = list(list_valid_collection_paths())
    all_collection_dirs = list(list_collection_dirs(search_paths=ansible_collections_paths))
    collection_dirs = dict()
    for coll_dir in all_collection_dirs:
        coll_dir_split = coll_dir.split('/')
        collection_name = coll_dir_split[-2] + "." + coll_dir_split[-1]
        collection_dirs[collection_name] = coll_dir

    # Check that each collection dir is in ansible collection paths

# Generated at 2022-06-22 19:20:47.622708
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Create fake collections
    base = '/tmp/ansible_collections/'
    os.makedirs(os.path.join(base, 'ns1/coll1'))
    os.makedirs(os.path.join(base, 'ns1/coll2'))
    os.makedirs(os.path.join(base, 'ns2/coll1'))

    # Test invalid path (missing trailing slash)
    search_path = ['/tmp/ansible_collections']
    coll_dirs = [coll for coll in list_collection_dirs(search_path)]
    assert len(coll_dirs) == 0

    # Test invalid path (non-existent)
    search_path = ['/tmp/ansible_collections/']

# Generated at 2022-06-22 19:20:53.722607
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    coll_path = ['/bogus/path/abc']
    out = list(list_valid_collection_paths(coll_path))

    assert len(out) == 1
    assert out[0] == '/bogus/path/abc'

    coll_path.append('/bogus/path/def')
    out = list(list_valid_collection_paths(coll_path, warn=True))

    assert len(out) == 1
    assert out[0] == '/bogus/path/abc'



# Generated at 2022-06-22 19:21:03.144507
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Slight abuse of the idea of a unit test here - this is not a proper unit test as it hits the file system.
    # It is designed to be run from the test/runner/ directory
    import os
    import sys

    test_coll_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_collections')
    if len(sys.argv) > 1:
        test_coll_path = sys.argv[1]

    print(test_coll_path)

    paths = list(list_collection_dirs(search_paths=[test_coll_path]))
    print(paths)

# Generated at 2022-06-22 19:21:10.182499
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.ansible import COLLECTIONS_PATHS
    from ansible.collections.ansible.tests.unit.common.test_collections import MockConfig
    import tempfile

    ansible_config = MockConfig()
    original_paths = ansible_config.collection_paths


# Generated at 2022-06-22 19:21:17.898068
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = ['.', 'foo.bar']
    assert expected == list(list_collection_dirs(coll_filter='foo.bar'))

    expected = ['.', 'foo.bar', 'fiz.buz', 'foo.biz']
    assert expected == list(list_collection_dirs(coll_filter='foo'))

    expected = ['.', 'foo.bar', 'foo.biz', 'foo.baz', 'foo.buz']
    assert expected == list(list_collection_dirs(coll_filter='foo.ba'))

# Generated at 2022-06-22 19:21:25.287561
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test empty
    pathlist = ['/foo', '/bar', '/baz']
    assert list(list_valid_collection_paths(pathlist, warn=False)) == []

    # Test mixture of valid and invalid paths
    pathlist = ['/tmp', '/root', '/home']
    assert set(list_valid_collection_paths(pathlist, warn=False)).issubset(pathlist) == True

    # Test mixture of valid and invalid paths and warnings
    pathlist = ['/tmp', '/root', '/home']
    assert set(list_valid_collection_paths(pathlist, warn=True)).issubset(pathlist) == True



# Generated at 2022-06-22 19:21:32.077893
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/invalid/path', '/dev/null'], warn=True)) == []
    assert list(list_valid_collection_paths(['/dev/null'], warn=True)) == []
    assert list(list_valid_collection_paths(['/invalid/path', '/dev/null'], warn=False)) == []
    assert list(list_valid_collection_paths(['/invalid/path', '/dev/null'])) == []

# Generated at 2022-06-22 19:21:35.978766
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test against real collection paths and collection filter values
    for search_path in ['', '/tmp/st3']:
        for coll_filter in ['', 'myansible_namespace.mycollection']:
            list_collection_dirs(search_path, coll_filter)

# Generated at 2022-06-22 19:21:42.771619
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # test empty input and returns on no path
    assert not list(list_valid_collection_paths([]))

    # test non-existent path and returns on only non-existent path
    t_path = tempfile.mkdtemp()
    assert not list(list_valid_collection_paths([t_path]))
    os.rmdir(t_path)

    # test existing path and returns on only existing path
    t_path = tempfile.mkdtemp()
    assert t_path in list(list_valid_collection_paths([t_path]))
    os.rmdir(t_path)

    # test existing and non-existent path and returns on both existing and non-existent path
    t_path = tempfile.mkdtemp()

# Generated at 2022-06-22 19:21:48.513137
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list_collection_dirs(search_paths=None, coll_filter='ns1.coll1')
    assert len(collections) == 1
    assert to_bytes(next(iter(collections))) == to_bytes(os.path.join(os.path.dirname(__file__), '..', 'test', 'unit', 'test_collections', 'test_data', 'ns1', 'coll1'))

# Generated at 2022-06-22 19:21:58.239628
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.utils import context_objects as co

    # 1. Test with path in search_paths
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = temp_dir + '/path'
        os.mkdir(temp_path)
        paths = list_valid_collection_paths([temp_path])
        assert temp_path in paths

    # 2. Test with path in search_paths that doesn't exist
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = temp_dir + '/path'
        paths = list_valid_collection_paths([temp_path], warn=True)
        assert temp_path not in paths

    # 3. Test with path in search_paths that is not a dir

# Generated at 2022-06-22 19:22:05.503328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path_list = ['data/testing/', 'data/testing/not_a_coll']
    path_dict = {'data/testing/': 'foo.bar', 'data/testing/not_a_coll': 'foo.moo'}

    for cpath in list_collection_dirs(search_paths=path_list):
        del path_list[path_list.index(path_dict[cpath])]

    assert not path_list



# Generated at 2022-06-22 19:22:09.805944
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = ['/not/real', '/home/user/collections']
    valid = list_valid_collection_paths(coll_paths)
    assert len(valid) == 1
    assert 'home/user/collections' in valid


# Generated at 2022-06-22 19:22:12.375193
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert(list_collection_dirs(search_paths=[os.path.join(os.path.dirname(__file__), 'test_data', 'collections')]))

# Generated at 2022-06-22 19:22:23.355388
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_colls = 'ainympdxv'
    test_cases = [
        'a.a',
        'b.b',
        'c.d.c',
        'e.d.e',
        'f.d.f',
        'g.g.g',
        'h.h.h'
    ]

    paths = [os.path.join(os.path.dirname(__file__), '..', '..', x) for x in test_cases]
    found = list(list_collection_dirs(paths, '.'.join(test_cases[0].split('.')[:-1])))
    assert len(found) == 2, 'Should find two collections, found: {0}'.format(found)


# Generated at 2022-06-22 19:22:31.758571
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert {
        'ansible_collections.test_namespace.test_collection': 'test_collection_dir',
        'ansible_collections.test_namespace.test_collection_2': 'test_collection_dir_2',
        } == dict(list_collection_dirs(search_paths=['test_collection_dir', 'test_collection_dir_2']))
    assert {
        'ansible_collections.test_namespace.test_collection': 'test_collection_dir',
        } == dict(list_collection_dirs(search_paths=['test_collection_dir', 'test_collection_dir_2'], coll_filter='test_namespace.test_collection'))

# Generated at 2022-06-22 19:22:38.722007
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["tests/fixtures/collection_paths/collections_a", "tests/fixtures/collection_paths/collections_b", "tests/fixtures/collection_paths/collections_c"]
    collection_dirs = list_collection_dirs(search_paths)
    collection_dirs_list = [coll_dir for coll_dir in collection_dirs]
    assert len(collection_dirs_list) == 8
    collection_dirs = list_collection_dirs(search_paths, "namespace_a.collection_b")
    collection_dirs_list = [coll_dir for coll_dir in collection_dirs]
    assert len(collection_dirs_list) == 1

# Generated at 2022-06-22 19:22:48.066079
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import namedtuple
    case = namedtuple('case', ['cwd', 'paths', 'coll_filter', 'expected'])

# Generated at 2022-06-22 19:22:57.944553
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test for two scnearios, one where list_collection_dirs() is called without any
    # arguments and one where search_paths is passed.
    for search_paths in (None, ['/foo']):
        # Test collection filter
        coll_filter = 'test_coll'
        coll_path = '/path/to/ansible_collections/test_coll'
        coll_dirs = list(list_collection_dirs(search_paths, coll_filter))
        assert len(coll_dirs) == 1
        assert coll_dirs[0] == coll_path.encode('utf-8')

        # Test namespace filter
        coll_filter = 'test_ns'
        coll_dirs = list(list_collection_dirs(search_paths, coll_filter))
        assert not coll_dirs

# Generated at 2022-06-22 19:23:07.118311
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Verify namespace/collection filter applied in function
    """
    import tempfile
    from ansible.utils.collection_loader import write_collection_artifact

    tmp_path = tempfile.mkdtemp()
    tmp_coll_path = os.path.join(tmp_path, 'ansible_collections')
    write_collection_artifact(tmp_coll_path, 'foo.bar')
    write_collection_artifact(tmp_coll_path, 'foo.baz')
    write_collection_artifact(tmp_coll_path, 'ansible.posix')

    # Test single collection
    assert len(list(list_collection_dirs(search_paths=[tmp_path], coll_filter='foo.bar'))) == 1

    # Test single namespace

# Generated at 2022-06-22 19:23:17.014695
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function list_collection_dirs

    :return: None
    """
    collection_filter_list = (None, 'namespace', 'namespace.collection',
                              'namespace.collection.subcollection')
    search_path_list = (None, [], ['nonexistent'],
                        ['test/integration/legacy/test_collections/single_namespace'],
                        ['test/integration/legacy/test_collections/single_namespace_with_subcollection'],
                        ['test/integration/legacy/test_collections/multiple_namespaces'],
                        ['test/integration/legacy/test_collections/multiple_namespaces',
                         'test/integration/legacy/test_collections/single_namespace'])

# Generated at 2022-06-22 19:23:21.315189
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert [] == list(list_valid_collection_paths(['']))
    assert [] == list(list_valid_collection_paths(['.']))
    assert [] == list(list_valid_collection_paths(['/this/does/not/exist']))
    assert [] == list(list_valid_collection_paths(['/etc/passwd']))

# Generated at 2022-06-22 19:23:34.357637
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_list = [
        '/home/test/ansible_collections',
        'ansible_collections',
        '/home/test/ansible_collections/',
        'ansible_collections/',
        'https://github.com/test/test.git',
        'git@github.com:test/test.git',
        '~/test/test',
        '~/test/test/',
        '~test/test',
        '~test/test/',
    ]

    expected_valid_paths = [
        'ansible_collections',
        'ansible_collections/',
        '/home/test/ansible_collections',
        '/home/test/ansible_collections/',
    ]

# Generated at 2022-06-22 19:23:44.089111
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.cli.collection.validate import CollectionRequirement
    from ansible.collection.collection_finder import list_collection_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    import os
    import shutil
    import tempfile

    display = Display()
    coll_config = AnsibleCollectionConfig(config_args=dict())

    # test function works w/o collections
    assert list_collection_dirs() == []

    # create a temp dir
    tmpdir = tempfile.mkdtemp()
    display.vvvvv('created temp dir %s' % tmpdir)

    # construct the collection structure
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))

# Generated at 2022-06-22 19:23:52.559730
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = [
        'does_not_exist',
        '/dev/null/not_here',
        '/etc/passwd',
    ]

    expected_paths = []

    result_paths = list(list_valid_collection_paths(paths))

    assert result_paths == expected_paths

    paths = [
        '/',
    ]

    expected_paths = ['/']

    result_paths = list(list_valid_collection_paths(paths))

    assert result_paths == expected_paths



# Generated at 2022-06-22 19:24:04.499909
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import pytest
    from ansible.utils.display import Display

    # Make sure we are working under tmp, so we don't cause disasters
    dir_path = tempfile.mkdtemp()

    # Get rid of the base collections config obj and init a new one
    AnsibleCollectionConfig._collections_config = None
    AnsibleCollectionConfig.ansible_config = None

    # Set the paths in the new config to the tmp dir
    AnsibleCollectionConfig.set_collection_paths([dir_path])
    assert AnsibleCollectionConfig.collection_paths == [dir_path]

    # Make a temp collection config
    with tempfile.NamedTemporaryFile(delete=False) as n:
        n.write(b'[collections]\n')

# Generated at 2022-06-22 19:24:14.113285
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    def list_valid_collection_paths(search_paths):
        for path in search_paths:
            exists = os.path.exists(path)
            isdir = os.path.isdir(path)
            if to_bytes(path) not in list_valid_collection_paths(search_paths):
                if exists and isdir:
                    yield path
    assert list_valid_collection_paths(["c:\\ansible\\collections", "/etc/ansible", "/home/ansible/collections"]) == \
        ["c:\\ansible\\collections", "/etc/ansible", "/home/ansible/collections"]

# Generated at 2022-06-22 19:24:18.159735
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([__file__, '/tmp'])) == [__file__]
    assert list(list_valid_collection_paths(['/tmp', __file__])) == [__file__]
    assert list(list_valid_collection_paths(['/tmp', __file__, '/invalid'])) == [__file__]
    assert list(list_valid_collection_paths(['/tmp', '/invalid', __file__])) == [__file__]
    assert list(list_valid_collection_paths(['/tmp', '/invalid', __file__, '/invalid_2', '/invalid_3'])) == [__file__]

# Generated at 2022-06-22 19:24:27.987087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible import context

    # test default config
    paths = [p for p in list_valid_collection_paths() if context.CLIARGS.python_interpreter.replace('python', '') in p]
    if len(paths) != 2:
        raise AssertionError("Default config test failed")

    context.CLIARGS = context.CLIARGS._replace(collections_paths=[])

    # test that missing path is filtered out
    paths = [p for p in list_valid_collection_paths(search_paths=['/junk'])]
    if len(paths) > 0:
        raise AssertionError("Filter out existing config failed")

    # test that missing path is filtered out

# Generated at 2022-06-22 19:24:35.818703
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert './ansible_collections' in list_valid_collection_paths(search_paths=['./'])
    assert './ansible_collections' in list_valid_collection_paths(search_paths=['./', './ansible_collections'])
    assert './ansible_collections' not in list_valid_collection_paths(search_paths=['../'])
    assert './ansible_collections' not in list_valid_collection_paths(search_paths=['../', './ansible_collections'])
    assert './ansible_collections' not in list_valid_collection_paths(search_paths=[])

# Generated at 2022-06-22 19:24:44.698131
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    search_paths = ["/tmp", "/tmp/foo", "/tmp/foo/bar"]

    # Create directories to test if they exist
    for path in search_paths:
        if not os.path.exists(to_bytes(path)):
            os.makedirs(to_bytes(path))

    # Create some files, these should not exist
    non_existant_paths = ["/tmp/foo/bar/test", "/tmp/foo/bar/test1", "/tmp/foo/bar/test2"]
    for path in non_existant_paths:
        f = open(to_bytes(path), 'w')
        f.close()

    # Run the function
    search_paths.extend(non_existant_paths)
    found_paths

# Generated at 2022-06-22 19:24:47.444833
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/foo', '/bar', 'nothing']) == ['/foo', '/bar']

# Generated at 2022-06-22 19:24:51.347779
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test list collection directories
    '''
    coll_dirs = list_collection_dirs(search_paths=["/home/ansible"])
    assert len(coll_dirs) == 2

# Generated at 2022-06-22 19:25:01.395919
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tmp_coll_root = None
    tmp_namespace_dir = None
    tmp_coll_dir = None

# Generated at 2022-06-22 19:25:12.705666
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = []
    path.append("../test/unit/utils/testdata/collections/testcoll")
    path.append("../test/unit/utils/testdata/collections/testcoll2")
    path.append("../test/unit/utils/testdata/collections/testcoll/collection")
    collection_dirs = list_collection_dirs(search_paths=path)
    assert("ansible_namespace.testcoll/collection" in collection_dirs)
    assert("ansible_namespace.testcoll2/collection" in collection_dirs)
    assert("ansible_namespace.testcoll/collection" in collection_dirs)
    assert("ansible_namespace.testcoll/subcollection1" in collection_dirs)

# Generated at 2022-06-22 19:25:21.049168
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test loading default paths
    default_paths = list(list_valid_collection_paths())
    assert len(default_paths) > 0

    # Test filtering of invalid paths
    empty_list = list(list_valid_collection_paths(search_paths=[]))
    assert len(empty_list) == 0

    missing_path = list(list_valid_collection_paths(search_paths=['/tmp/does/not/exist/'], warn=True))
    assert len(missing_path) == 0

    path_exists = list(list_valid_collection_paths(search_paths=['/tmp'], warn=True))
    assert len(path_exists) > 0

    # Test a list of paths

# Generated at 2022-06-22 19:25:32.469324
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )


# Generated at 2022-06-22 19:25:37.144428
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=['./tests/unit/utils/fixtures/ansible_collections']) != []
    assert list_collection_dirs(search_paths=['./tests/unit/utils/fixtures/ansible_collections'], coll_filter='nsd.bad_collection') == []
    assert list_collection_dirs(search_paths=['./tests/unit/utils/fixtures/ansible_collections'], coll_filter='nsd.good_collection') != []

# Generated at 2022-06-22 19:25:46.685332
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_collection_finder')
    dirs = list_collection_dirs([path], coll_filter='ns1.coll1')
    assert(len(dirs) == 1)
    for d in dirs:
        assert(os.path.basename(d) == to_bytes('coll1'))
        assert(os.path.basename(os.path.dirname(d)) == to_bytes('ns1'))
        assert(os.path.basename(os.path.dirname(os.path.dirname(d))) == to_bytes('ansible_collections'))



# Generated at 2022-06-22 19:25:58.874314
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.removed import removed
    from ansible_collections.ansible.builtin import load_collections
    from ansible.module_utils.common.collections import assert_is_valid_collection_path

    pwd = os.getcwd()

    # Test bad collection path

    bad_paths = ['', '#', '."#', './"#']

    for path in bad_paths:
        # Test paths that don't exist or are missing
        assert list(list_valid_collection_paths(search_paths=[path])) == []

    # Test good collection path

    test_paths = [pwd]

    for path in test_paths:
        for x in list_valid_collection_paths(search_paths=[path]):
            assert_is_

# Generated at 2022-06-22 19:26:09.461201
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collections_loader import list_collection_dirs, list_valid_collection_paths
    import tempfile

    paths = list(list_valid_collection_paths())
    assert len(paths) > 0

    path1 = os.path.join(tempfile.mkdtemp(), 'ansible_collections')
    os.makedirs(os.path.join(path1, 'lib_collection'))
    os.makedirs(os.path.join(path1, 'lib_collection2'))
    os.makedirs(os.path.join(path1, 'lib_collection.foo'))
    os.makedirs(os.path.join(path1, 'lib_collection.baz'))

# Generated at 2022-06-22 19:26:18.875394
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("==== display all collections in all search paths ====")
    for coll_dir in list_collection_dirs():
        print(coll_dir)
    print("==== display collections in ANSIBLE_COLLECTIONS_PATHS ====")
    for coll_dir in list_collection_dirs(['/usr/share/ansible/collections']):
        print(coll_dir)
    print("==== display collections with namespace ansible_namespace_1 ====")
    for coll_dir in list_collection_dirs(coll_filter='ansible_namespace_1'):
        print(coll_dir)
    print("==== display collections with namespace ansible_namespace_1 and collection ansible_collection_1 ====")

# Generated at 2022-06-22 19:26:19.629116
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for path in list_collection_dirs():
        print(path)


# Generated at 2022-06-22 19:26:28.454349
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from tempfile import mkdtemp
    from shutil import rmtree

    temp_dir = mkdtemp()

# Generated at 2022-06-22 19:26:31.096922
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['noexist', 'fake.yml', 'non-dir']
    assert [] == list(list_valid_collection_paths(search_paths, warn=False))

# Generated at 2022-06-22 19:26:36.302628
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert ['/abc/testing'] == list(list_valid_collection_paths(['/abc/testing'], warn=True))
    assert ['/abc/testing/ansible_collections'] == list(list_valid_collection_paths(['/abc/testing']))

    assert [] == list(list_valid_collection_paths(['/abc/testing/'], warn=True))
    assert [] == list(list_valid_collection_paths(['/abc/testing/']))

# Generated at 2022-06-22 19:26:47.153839
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    tp_path = tempfile.mkdtemp()
    coll_path = os.path.join(tp_path, 'ansible_collections')
    coll_path1 = os.path.join(tp_path, 'ansible_collections1')
    os.mkdir(coll_path)
    os.mkdir(coll_path1)
    search_paths = []
    search_paths.extend(AnsibleCollectionConfig.collection_paths)

    # temp dir created
    assert os.path.exists(tp_path)
    assert os.path.isdir(tp_path)

    # check that default paths are returned when no search_paths are passed
    paths = list(list_valid_collection_paths(search_paths))
    assert AnsibleCollectionConfig.collection_

# Generated at 2022-06-22 19:26:56.839348
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile, shutil
    from os.path import join

    # Create temp dir, add subdirs to make it look like a collection dir
    # Include a .ansible dir to verify it is ignored

    b_tmp_dir = to_bytes(tempfile.mkdtemp())
    b_coll_name = to_bytes('ns1.coll1')
    b_coll_dir = join(b_tmp_dir, b_coll_name)
    b_ans_dir = join(b_coll_dir, b_coll_name)

    os.mkdir(b_coll_dir)
    os.mkdir(b_ans_dir)

    test_path = [b_tmp_dir]

    # Only one dir should be returned

# Generated at 2022-06-22 19:27:00.078415
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = ['home/user/collections']
    display = Display()
    for path in list_valid_collection_paths(coll_paths):
        display.vvv('Path: ' + path)
        assert path == 'home/user/collections'


# Generated at 2022-06-22 19:27:09.182439
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import collections

    # create temp path and file
    temp_dir = tempfile.mkdtemp()
    temp_path_file = os.path.join(temp_dir, "foo.txt")
    open(temp_path_file, "w").close()

    # setup test list
    test_list = [
        temp_path_file,              # this is a file
        temp_dir,                    # this is a valid directory
        temp_dir + 'foo_bar_test'    # this is a missing directory
    ]

    # verify only the valid path is returned
    valid_paths = collections.deque(list_valid_collection_paths(test_list))
    assert valid_paths.pop() == temp_dir

    # clean up

# Generated at 2022-06-22 19:27:20.638458
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    tmp_root = tempfile.mkdtemp(suffix='-ansible-collections')


# Generated at 2022-06-22 19:27:31.625049
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    dirs = dict()
    b_tmpdir = to_bytes(tempfile.mkdtemp(), errors='surrogate_or_strict')

    # create ansible_collections/ns1 dir
    dirs['ns1'] = os.path.join(b_tmpdir, b'ansible_collections')
    os.mkdir(dirs['ns1'])

    # create ansible_collections/ns1/coll1.coll1 dir
    dirs['ns1/coll1.coll1'] = os.path.join(dirs['ns1'], b'coll1.coll1')
    os.mkdir(dirs['ns1/coll1.coll1'])

# Generated at 2022-06-22 19:27:43.412358
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.collection_loader import AnsibleCollectionConfig
    test_path = "/tmp/test_collection_loader"
    AnsibleCollectionConfig.clear_all()
    path_list = list_valid_collection_paths(["/home", "/var"])
    assert next(path_list) == "/home"
    assert next(path_list) == "/var"
    # TODO: Would be better to have a distinct test case for each of these.
    # The test should pass if either default is present
    if 'ANSIBLE_COLLECTIONS_PATHS' in os.environ:
        assert next(path_list) == os.environ['ANSIBLE_COLLECTIONS_PATHS']


# Generated at 2022-06-22 19:27:53.193548
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath
    from ansible.galaxy.collection import Collection
    from ansible.galaxy.collection_loader import CollectionsLoader

    ansible_collections_dir = os.path.dirname(to_bytes(__file__))
    ansible_collections_dir = os.path.dirname(ansible_collections_dir)
    ansible_collections_dir = os.path.dirname(ansible_collections_dir)
    ansible_collections_dir = os.path.dirname(ansible_collections_dir)
    ansible_collections_dir = os.path.join(ansible_collections_dir, to_bytes('test/unit/collection_fixtures/ansible_collections'))


# Generated at 2022-06-22 19:28:00.126483
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    from shutil import rmtree

    import sys

    test_config_path = mkdtemp()

# Generated at 2022-06-22 19:28:03.737772
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list_valid_collection_paths([])
    assert list_valid_collection_paths(['/tmp']) == ['/tmp']

# Generated at 2022-06-22 19:28:13.303759
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Standard list, no filter
    assert 'ansible.builtin' in [os.path.basename(x) for x in list(list_collection_dirs())]

    # Standard list, filter for namespace only
    assert 'ansible.builtin' in [os.path.basename(x) for x in list(list_collection_dirs(coll_filter='ansible'))]

    # Standard list, filter for collection only
    assert 'ansible.builtin' in [os.path.basename(x) for x in list(list_collection_dirs(coll_filter='builtin'))]

    # Standard list, filter for namespace and collection

# Generated at 2022-06-22 19:28:18.273751
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['foo/bar', 'foo/baz']
    coll_filter = 'namespace.collection'
    display.verbosity = 1
    collection_dirs = list(list_collection_dirs(search_paths, coll_filter))
    print(collection_dirs)


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:28:26.098114
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        'invalid_path',
        None,
        '/',
        'collections',
    ]

    test_paths = list_valid_collection_paths(search_paths, warn=True)

    assert('collections' in list(test_paths))
    assert(None not in search_paths)



# Generated at 2022-06-22 19:28:30.577554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import sys
    from ansible.collections import set_collection_playbook_paths, disable_collection_playbook_paths

    tempdir = tempfile.mkdtemp()
    testdir = os.path.join(tempdir, 'testdir')


# Generated at 2022-06-22 19:28:34.011253
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list_collection_dirs()

    # verify bad collection /path/
    assert list_collection_dirs(coll_filter='/path/') is None

# Generated at 2022-06-22 19:28:41.138020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections import ansible_collections_path
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.path import unfrackpath, makedirs_safe
    from os import makedirs

    # Create the path to the test fixture
    path = unfrackpath(
        "//mazer/ansible_collections/collection_fixtures/test_collections/"
    )
    makedirs_safe(path)

    # Ensure no collections exist in the fixture path
    assert list(list_collection_dirs([path])) == []

    # Create collections under the test fixture path
    makedirs(f"{path}/foo/bar/tasks")
    makedirs(f"{path}/foo/baz/tasks")

    # Verify that a collection dir

# Generated at 2022-06-22 19:28:52.025993
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test the list_collection_dirs function"""

    m_list_collection_dirs = list_collection_dirs
    m_list_val_paths = list_valid_collection_paths

    def mock_list_collection_dirs(*args, **kwargs):
        return list(m_list_collection_dirs(coll_filter=None, *args, **kwargs))

    # list_collection_dirs() requires list_valid_collection_paths() to return
    # some valid path or it will return an empty list.
    # Force list_valid_collection_paths() to return an empty list to test
    # the empty list return codepath.

# Generated at 2022-06-22 19:29:00.072120
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.config.manager import ConfigManager
    from ansible.plugins import collections_loader

    # The ConfigManager tracks which configuration variables we've seen,
    # in order to avoid overwriting them if they've been specified in more
    # than one place.  This is not a problem for normal use, but it causes
    # problems for unit tests, so we create a clean one here.
    config_manager = ConfigManager(config_data={})

    # mock collection loader
    def mock_get_collections_loader(config_manager):
        collection_loader = collections_loader.CollectionsLoader()
        collection_loader._config_manager = config_manager
        return collection_loader
    collections_loader.get_collections_loader = mock_get_collections_loader

    # config manager
    config_manager._options['collections_paths']

# Generated at 2022-06-22 19:29:10.854756
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """

    import tempfile

    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import list_collection_dirs

    # Note: Need to use explicit search path in tests to avoid loading default/configured paths
    coll_paths = [tempfile.mkdtemp()]
    AnsibleCollectionConfig.collection_paths = coll_paths

    # Test without configured search path
    assert len(list(list_collection_dirs())) == 0

    # Test search path where root is not a collection dir path
    coll_paths.append(tempfile.mkdtemp())
    assert len(list(list_collection_dirs())) == 0

    # Test search path where collection dir path exists, but empty

# Generated at 2022-06-22 19:29:19.378744
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    tmp_path = tempfile.mkdtemp()
    namespace = 'myns'
    coll = 'mycoll'

    # We need to create a valid collection
    ns_path = os.path.join(tmp_path, 'ansible_collections', namespace, coll)

    os.makedirs(ns_path)
    with open(os.path.join(ns_path, 'setup.yml'), 'wb') as new_file:
        new_file.write(to_bytes("---", errors='surrogate_or_strict'))

    collections = list(list_collection_dirs(search_paths=[tmp_path]))

    assert len(collections) == 1
    assert collections[0] == to_bytes(ns_path)


# Generated at 2022-06-22 19:29:22.408283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        len(list(list_collection_dirs(search_paths=['./test/units/module_utils/test_list_collection_dirs_collections'])))
    except Exception as e:
        assert False, "Unexpected exception found: {0}".format(e)

# Generated at 2022-06-22 19:29:31.439816
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import shutil
    import tempfile

    # setup has_collection(collection) fixture
    ns = 'testns'
    coll = 'testcoll'
    coll_filter = ns + '.' + coll
    coll_dir = tempfile.mkdtemp()

    # note: make collection dir with ansible_managed directory, so is_collection_dir is True
    os.makedirs(os.path.join(coll_dir, 'ansible_managed'))

    def coll_dir_exists():
        return os.path.exists(coll_dir)

    def coll_dir_not_exists():
        return not os.path.exists(coll_dir)


# Generated at 2022-06-22 19:29:41.155621
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: change to pytest
    # Setup
    search_paths = []
    Warn = True
    # Assert
    assert list_valid_collection_paths(search_paths, warn=Warn)

    # Setup
    search_paths = None
    Warn = True
    # Assert
    assert list_valid_collection_paths(search_paths, warn=Warn)

    # Setup
    search_paths = ["/non/existing/path"]
    Warn = True
    # Assert
    assert list_valid_collection_paths(search_paths, warn=Warn)

    # Setup
    search_paths = ["/usr/bin"]
    Warn = True
    # Assert
    assert list_valid_collection_paths(search_paths, warn=Warn)




# Generated at 2022-06-22 19:29:52.239965
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.plugin.finder import PluginFinder

    plugin_finder = PluginFinder()
    # Add the search paths to the PluginFinder singleton
    plugin_finder.add_directory(to_bytes('test/unit/utils/collection_loader/lib_collection/collections', errors='surrogate_or_strict'), with_subdir=True)
    plugin_finder.add_directory(to_bytes('test/unit/utils/collection_loader/lib_collection/not_collections', errors='surrogate_or_strict'), with_subdir=True)

    # Get the list of search paths
    search_paths = list(plugin_finder.paths)
    display.display("search_paths:%s" % search_paths)

    # Add a non existing path and another non directory path
    search_path

# Generated at 2022-06-22 19:29:54.417279
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:30:01.287242
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # a collection path does not exist
    assert list(list_valid_collection_paths(['/does_not_exist'], warn=False)) == []

    # a collection path is not a directory
    assert list(list_valid_collection_paths(['/etc/resolv.conf'], warn=False)) == []

    # a valid collection path
    assert list(list_valid_collection_paths(['/usr/share/ansible/collections'], warn=False)) == ['/usr/share/ansible/collections']



# Generated at 2022-06-22 19:30:07.059806
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile
    from ansible.module_utils._text import to_text

    coll_test1_ns = to_text('namespace')
    coll_test1_name = to_text('collection')
    coll_test1 = u"%s.%s" % (coll_test1_ns, coll_test1_name)

    coll_test2_ns = to_text('namespace2')
    coll_test2_name = to_text('collection2')
    coll_test2 = u"%s.%s" % (coll_test2_ns, coll_test2_name)

    test_paths = []

    tmpdir1 = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()

    # need to ensure that the dir exists and is writable
