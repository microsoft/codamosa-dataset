

# Generated at 2022-06-22 19:20:17.086228
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = []
    test_paths.append('')
    test_paths.append(None)
    test_paths.append('/foo/bar')
    test_paths.append('/foo/bar:baz')
    test_paths.append('/foo/bar:/baz')
    test_paths.append('/foo/bar:/baz:')
    test_paths.append(':')
    test_paths.append(':/foo/bar:')

    for test_path in test_paths:
        result = list(list_valid_collection_paths(test_path))
        assert len(result) == 0

    test_paths = []
    test_paths.append('/foo/bar')

# Generated at 2022-06-22 19:20:21.737665
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    root_relative_paths = [
        os.path.join('test', 'unit', 'utils', 'ansible_collections'),
    ]

    for path in list_collection_dirs(search_paths=root_relative_paths, coll_filter='testns'):
        assert os.path.basename(path) == 'testcoll'

# Generated at 2022-06-22 19:20:32.460911
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    base_paths = [
        '/tmp/ansible_collections',
        '/tmp/foo/bar/ansible_collections',
        '/where/is/no-way',
    ]

    # creating empty directories
    for path in base_paths:
        os.makedirs(to_bytes(path, errors='surrogate_or_strict'), exist_ok=True)

    # creating a file
    with open(to_bytes(os.path.join(base_paths[0], 'ansible.cfg'), errors='surrogate_or_strict'), 'w') as f:
        f.write('[defaults]\n')
        f.write('\n')
        f.write('collection_paths = %s\n' % ':'.join(base_paths))

    # trying to

# Generated at 2022-06-22 19:20:40.414372
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    :return:
    """

    expected_results = [
        ".",  # default search path
        "/my/path/collections",
        "/my/path/collections",
    ]

    search_paths = [
        "/my/path/collections",
        "/my/path/collections",
    ]

    results = []
    for x in list_valid_collection_paths(search_paths, warn=True):
        results.append(x)

    assert expected_results == results

    # this tests the caching of results
    assert expected_results == results

# Generated at 2022-06-22 19:20:51.775196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as fakepath:
        fake_coll_path = os.path.join(fakepath, 'ansible_collections')

        # Test that fake path will not exist
        result = list_valid_collection_paths([fake_coll_path])
        assert len(list(result)) == 0

        # Test single path, but don't create to ensure default is loaded
        result = list_valid_collection_paths([fake_coll_path])
        assert len(list(result)) == 1

        # Test multiple paths, one existing and other doesn't, warn default is loaded
        with pytest.warns(None):
            result = list_valid_collection_paths(['/does/not/exist', fake_coll_path])
            assert len(list(result)) == 2

# Generated at 2022-06-22 19:21:02.981711
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    from ansible.parsing.plugin_docs import read_docstring
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import Mapping

    MockPlugin = namedtuple('MockPlugin', ['name'])

    Plugin = namedtuple('Plugin', ['name', 'doc'])
    Plugin.__doc__ = read_docstring(Plugin, base_class=Mapping)

    # create collection
    base_temp_dir = tempfile.mkdtemp()
    collection_path = os.path.join(base_temp_dir, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(os.path.join(collection_path, 'plugins', 'action'))
    os

# Generated at 2022-06-22 19:21:05.419705
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list_collection_dirs()
    assert type(result) == list
    assert len(result) > 0
    assert to_bytes(result[0]).startswith(b'/usr/share/ansible/')

# Generated at 2022-06-22 19:21:12.907082
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dir_list = list(list_collection_dirs(search_paths=['test/unit/utils/fixtures/ansible_collections/'],
                                         coll_filter='ansible'))
    assert len(dir_list) == 1
    assert dir_list[0].endswith('test/unit/utils/fixtures/ansible_collections/ansible/test_collection/')

    dir_list = list(list_collection_dirs(search_paths=['test/unit/utils/fixtures/ansible_collections/'],
                                         coll_filter='ansible.test_collection'))
    assert len(dir_list) == 1
    assert dir_list[0].endswith('test/unit/utils/fixtures/ansible_collections/ansible/test_collection/')

    dir_

# Generated at 2022-06-22 19:21:16.713407
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import list_collection_dirs
    for coll_dir in list_collection_dirs(coll_filter='awx.awx'):
        print(coll_dir)
    assert True

# Generated at 2022-06-22 19:21:24.854109
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible.utilities import list_collection_dirs
    assert list_collection_dirs(['/does/not/exist']) == []
    assert len(list_collection_dirs(['/usr/share/ansible'])) > 0
    assert len(list_collection_dirs(['/usr/share/ansible'], 'ansible_collections.not_real')) == 0
    # TODO: add a unit test that supplies a real ansible collection to test against
    assert len(list_collection_dirs(['/usr/share/ansible'], 'ansible_collections.foo.not_real')) == 0

# Generated at 2022-06-22 19:21:28.911045
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.config import BasicCLI

    my_search_paths = ["/none", "/none2", "/none3", "/this/exists/collection/path"]

    for s in list_valid_collection_paths(my_search_paths):
        assert s == "/this/exists/collection/path"

# Generated at 2022-06-22 19:21:38.523970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.wpcutler.slack_custom_actions.plugins.modules import slack_alert
    from ansible_collections.wpcutler.slack_custom_actions.plugins.module_utils.slack_custom_actions import SlackCustomActionModuleTestCase

    import os
    import json

    module_name = 'slack_alert'
    module_dir = os.path.dirname(slack_alert.__file__)
    fixture_path = os.path.join(module_dir, 'tests/unit/fixtures')
    fixtures = dict()


# Generated at 2022-06-22 19:21:40.866385
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.module_utils.collection_loader
    ansible.module_utils.collection_loader.list_collection_dirs()
    pass

# Generated at 2022-06-22 19:21:45.538080
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        '/Users/someuser/ansible/ansible_collections',
        '/Users/someuser/ansible/ansible/collections',
    ]

    collections = list_collection_dirs(search_paths=search_paths)
    collections = list(collections)

    assert '/Users/someuser/ansible/ansible_collections/namespace/collection' in collections
    assert '/Users/someuser/ansible/ansible/collections/namespace/collection' in collections

# Generated at 2022-06-22 19:21:47.685128
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['./lib/ansible/collections', './lib/ansible/plugins/collections']
    print(search_paths)
    for coll_dir in list_collection_dirs(search_paths):
        print(coll_dir)



# Generated at 2022-06-22 19:21:52.253718
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Given
    search_paths = ['../ansible_collections', '../../ansible_collection']
    coll_filter = 'myns.mycoll'
    # When
    result = list_collection_dirs(search_paths, coll_filter)
    # Then
    assert 'myns.mycoll' in result

# Generated at 2022-06-22 19:21:58.348912
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_config = AnsibleCollectionConfig()
    collection_config.initialize()
    collection_config.populate_basedirs()
    search_paths = collection_config.collection_paths
    valid_search_paths = list(list_valid_collection_paths(search_paths))
    assert isinstance(valid_search_paths, list)
    assert len(valid_search_paths) > 0
    assert os.path.exists(valid_search_paths[0])

# Generated at 2022-06-22 19:22:09.943231
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # get some collection
    paths = [u'/Users/jenkins/workspace/projects-validate']
    dirs = list(list_collection_dirs(search_paths=paths, coll_filter=u'community.general'))
    assert dirs

    # another collection
    dirs = list(list_collection_dirs(search_paths=paths, coll_filter=u'cloud.azure'))
    assert dirs

    # different collection
    dirs = list(list_collection_dirs(search_paths=paths, coll_filter=u'ansible.builtin'))
    assert dirs

    # nonexistent collection
    dirs = list(list_collection_dirs(search_paths=paths, coll_filter=u'ansible.builtin_dd'))
    assert not d

# Generated at 2022-06-22 19:22:20.416586
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = [
        'tests/collection_loader/fixtures/collections_1',
        'tests/collection_loader/fixtures/collections_2'
    ]
    coll_dirs = list(list_collection_dirs(search_paths=collection_paths))
    assert sorted(coll_dirs) == sorted([
        b'tests/collection_loader/fixtures/collections_2/ansible_collections/test/test_collection_1',
        b'tests/collection_loader/fixtures/collections_1/ansible_collections/test/test_collection_2',
        b'tests/collection_loader/fixtures/collections_1/ansible_collections/test/test_collection_3',
    ])


# Generated at 2022-06-22 19:22:31.950193
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    expected = {
        'ansible_collections': {
            'test_namespace': '/b/n/ansible_collections/test_namespace/collection1',
            'another_ns': '/b/n/ansible_collections/another_ns/collection1'
        },
        'ansible': {
            'test_namespace': '/b/n/ansible_collections/test_namespace/collection2',
            'another_ns': '/b/n/ansible_collections/another_ns/collection2'
        }
    }

    # Must have a base dir to start with
    try:
        list(list_collection_dirs(search_paths=[]))
    except OSError:
        pass

# Generated at 2022-06-22 19:22:43.347967
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = './test/test_collections'
    expected_output = ['./test/test_collections/ansible_collections/internal/helloworld',
                       './test/test_collections/ansible_collections/internal/helloworld_2']
    assert list(list_collection_dirs([coll_path])) == expected_output

    expected_output = ['./test/test_collections/ansible_collections/internal/helloworld']
    assert list(list_collection_dirs([coll_path], 'internal.helloworld')) == expected_output

    expected_output = ['./test/test_collections/ansible_collections/internal/helloworld',
                       './test/test_collections/ansible_collections/internal/helloworld_2']
   

# Generated at 2022-06-22 19:22:45.637621
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['/tmp/dev', '/tmp/test']
    for path in list_collection_dirs(search_paths):
        print(path)

# Generated at 2022-06-22 19:22:55.994644
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Standard search paths
    assert set(list_valid_collection_paths(
        search_paths=['/dne/collections', './fixtures/test_collections/c2']
    )) == {'/dne/collections', './fixtures/test_collections/c2', './fixtures/test_collections/c1'}

    # Search paths that are non-standard
    assert set(list_valid_collection_paths(
        search_paths=['/dne/collections', '/fixtures/test_collections/c2/ansible_collections']
    )) == {'/dne/collections', '/fixtures/test_collections/c2/ansible_collections',
            '/fixtures/test_collections/c1/ansible_collections'}

    # Warning search

# Generated at 2022-06-22 19:23:04.481608
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list(list_collection_dirs(search_paths=["/path/to/nocheck", "/path/to/nocheck2"]))
    assert len(collections) == 0
    collections = list(list_collection_dirs(search_paths=["/path/to/nocheck", "/path/to/nocheck2"], coll_filter="namespace.collection"))
    assert len(collections) == 0
    collections = list(list_collection_dirs(search_paths=["/path/to/nocheck", "/path/to/nocheck2"], coll_filter="namespace"))
    assert len(collections) == 0

# Generated at 2022-06-22 19:23:15.729206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Build up a list of test dirs
    test_dirs = list()
    test_dirs.append("./test_dir1")
    test_dirs.append("./test_dir2")

    # Test an empty list
    search_paths = list()
    res = list(list_valid_collection_paths(search_paths))
    assert sum(1 for f in res) == 0

    # Test with a non-existing path
    search_paths = ["./test_dir99"]
    res = list(list_valid_collection_paths(search_paths))
    assert sum(1 for f in res) == 0

    # Test with a existing path, but not a directory
    with open('./test_file1', 'a'):
        # create the file
        os.utime

# Generated at 2022-06-22 19:23:26.028611
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    col_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_collections')
    items = list_collection_dirs([col_path])
    assert list(items) == [b'/Users/wozniak/code/github/ansible/lib/ansible/test/units/modules/extras/fixtures/ansible_collections/test_ns/test_coll/']

    items = list_collection_dirs([col_path], coll_filter='test_ns.test_coll')
    assert list(items) == [b'/Users/wozniak/code/github/ansible/lib/ansible/test/units/modules/extras/fixtures/ansible_collections/test_ns/test_coll/']

    items = list_collection_dirs

# Generated at 2022-06-22 19:23:33.817736
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Make sure function list_valid_collection_paths does not return paths that do not exist
    """

    for path in ["/foo/bar/baz", "./my_modules", "i_do_not_exist"]:
        search_paths = [path]
        valid_paths = [x for x in list_valid_collection_paths(search_paths, warn=False)]
        assert len(valid_paths) == 0


# Generated at 2022-06-22 19:23:41.736275
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths(["/tmp/bogus_path1", "/bogus/bogus_path2", "/bogus/bogus_path3"])
    assert not next(paths, None)
    paths = list_valid_collection_paths(["/tmp/bogus_path1", "/", "/bogus/bogus_path3"])
    assert next(paths, None) == "/"


# Generated at 2022-06-22 19:23:53.900732
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    cwd = os.path.dirname(os.path.abspath(__file__))
    collection_root = os.path.normpath(os.path.join(cwd, '../../../..', 'ansible_collections'))
    valid_paths = [collection_root]

    import pytest
    # lets test invalid path
    test_paths = list_valid_collection_paths(['/foo/bar'], warn=False)
    assert len(list(test_paths)) == 0

    # lets test invalid path (non dir)
    test_paths = list_valid_collection_paths([__file__], warn=False)
    assert len(list(test_paths)) == 0

    # lets test valid paths

# Generated at 2022-06-22 19:24:04.649032
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def _count_collections(collection_path, search_paths):
        return len(list(list_collection_dirs(search_paths, coll_filter=collection_path)))

    # find number of collections in installed path
    installed_collections_count = _count_collections("ansible.builtin", None)

    # find number of collections in default path
    default_paths = ['./test/units/utils/list_collections/collections',
                     './test/units/utils/list_collections/collections2']
    default_collections_count = _count_collections("ansible.builtin", default_paths)

    assert installed_collections_count == 1
    assert default_collections_count == 2



# Generated at 2022-06-22 19:24:08.529456
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = ['test/units/utils/test_collections/']
    for coll in list_collection_dirs(path):
        print(coll)



# Generated at 2022-06-22 19:24:16.929785
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile


# Generated at 2022-06-22 19:24:24.452889
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with empty list
    res = list(list_valid_collection_paths([]))
    assert len(res) == 0

    # test with default list
    res = [p for p in list_valid_collection_paths(None)]
    assert len(res) == 1
    assert to_bytes(res[0]) in to_bytes(AnsibleCollectionConfig.collection_paths)

    # test with full list
    res = [p for p in list_valid_collection_paths(None, warn=True)]
    assert len(res) == 1
    assert to_bytes(res[0]) in to_bytes(AnsibleCollectionConfig.collection_paths)

# Generated at 2022-06-22 19:24:32.627447
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for list_collection_dirs
    """
    # list all collections
    for _ in list_collection_dirs():
        pass
    # list single namespace
    for _ in list_collection_dirs(coll_filter='ansible_namespace'):
        pass
    # list single collection
    for _ in list_collection_dirs(coll_filter='ansible_namespace.ansible_collection'):
        pass

# Generated at 2022-06-22 19:24:43.200687
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    results = list(list_valid_collection_paths(['/foo']))
    assert results == ['/foo']
    results = list(list_valid_collection_paths(['/bar']))
    assert results == ['/bar']
    results = list(list_valid_collection_paths(['/bar', '/foo']))
    assert results == ['/bar', '/foo']

    with open('tmp_config', 'w') as config:
        config.write('[defaults]' + '\n')
        config.write('collections_paths=/foo' + '\n')

    # Test ansible.cfg setup
    os.environ['ANSIBLE_CONFIG'] = './tmp_config'
    results = list(list_valid_collection_paths())
    assert results == ['/foo']
    os.un

# Generated at 2022-06-22 19:24:50.520902
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # search_paths = []
    search_paths = [
        '/Users/jeremy/git/ansible_collections/ansible_collections/jeremy_testing',
    ]

    for path in list_collection_dirs(search_paths=search_paths, coll_filter=None):
        print(path)




# Generated at 2022-06-22 19:24:55.973329
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        '/tmp/does-not-exist',
        './lib/ansible_collections',
        './test/units/data/collection_loader/collections',
        './test/units/data/collection_loader/collections/ansible_collections'
    ]
    collection_dirs = [list_collection_dirs(search_paths=search_paths)]
    assert len(collection_dirs) == 1
    # TODO: test filter by namespace
    # TODO: test filter by collection
    # TODO: test filter by namespaced collection

# Generated at 2022-06-22 19:25:05.508816
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function
    """
    import tempfile
    import shutil
    import os

    #
    # Verify that if a invalid directory is in search_paths
    # then it is not returned.
    #
    with tempfile.TemporaryDirectory() as tmp_dir:
        coll_name = 'test.test_collection'
        tmp_coll_dir = os.path.join(tmp_dir, coll_name)

        # create temporary collection
        os.makedirs(tmp_coll_dir, exist_ok=True)
        with open(os.path.join(tmp_coll_dir, 'plugins', 'inventory', 'test_collection.py'), 'w') as fobj:
            fobj.write('from ansible.plugins.inventory import BaseInventoryPlugin\n')

        #
       

# Generated at 2022-06-22 19:25:14.387591
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs(coll_filter='ansible_collections.ns1.nginx'))
    assert len(collection_dirs) == 1, 'Expecting only one matching collection path'

    idx = collection_dirs[0].find('ns1/nginx')
    assert idx > -1, 'Collection path does not include the expected namespace and collection name'

    collection_paths = list(list_collection_dirs(coll_filter='ansible_collections.ns1'))
    assert len(collection_paths) == 2, 'Expecting two matching collections in the ns1 namespace'

    idx = collection_dirs[0].find('ns1/nginx')
    assert idx > -1, 'Collection path does not include the expected namespace'


# Generated at 2022-06-22 19:25:18.764383
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = ['/etc/ansible/collections',
             '/usr/share/ansible/collections',
             '/etc/ansible/ansible_collections']
    assert list_collection_dirs(search_paths=paths) == ['/etc/ansible/collections/ansible/somespace/somercoll/']



# Generated at 2022-06-22 19:25:25.705899
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test valid paths
    fake_paths = ['/tmp', '/tmp/my_collections']
    paths = list(list_valid_collection_paths(fake_paths))
    assert len(paths) == len(fake_paths)

    # test invalid paths
    fake_paths = ['/tmp', '/tmp/my_collections', '/bogus_dir']
    fake_paths.extend(AnsibleCollectionConfig.collection_paths)
    paths = list(list_valid_collection_paths(fake_paths))
    assert len(paths) == len(fake_paths) - 1

    # missing collection path, not displayed as warning
    fake_paths = ['/tmp/my_collections']

# Generated at 2022-06-22 19:25:30.831399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible import context
    context.CLIARGS._load_config_files = lambda *args: None
    context.CLIARGS._parse_cli_opts = lambda *args: None
    search_paths = ['/path/to/foo', '/path/to/bar']
    result = list_valid_collection_paths(search_paths)
    assert result == search_paths



# Generated at 2022-06-22 19:25:41.705449
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys

    # test that it works in no collections directory
    dirs = list(list_collection_dirs([os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 'fixtures', 'collection_not_found')]))
    assert len(dirs) == 0

    # test that it returns the right directories
    collection_root = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 'fixtures', 'collection_with_roles')
    dirs = list(list_collection_dirs([collection_root]))

    assert len(dirs) == 1
    assert dirs[0].endswith("collection_with_roles/ansible_collections/test_ns/test_coll")

# Generated at 2022-06-22 19:25:46.204110
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.constants as C
    C.ANSIBLE_COLLECTIONS_PATHS = [os.path.join(os.environ['HOME'], '.ansible', 'collections')]
    for path in list_valid_collection_paths():
        print(path)


# Generated at 2022-06-22 19:25:52.516019
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from sys import platform
    import subprocess
    import tempfile
    import shutil

    def get_platform():
        platforms = {
            'linux': 'Linux',
            'linux1': 'Linux',
            'linux2': 'Linux',
            'darwin': 'Mac',
            'win32': 'Windows'
        }

        if platform == 'darwin':
            return 'Mac'
        elif platform in ['linux', 'linux1', 'linux2']:
            return 'Linux'
        elif platform == 'win32':
            return 'Windows'

        return platform

    class MyFakeDisplay(object):
        def __init__(self):
            self.messages = []

        def warning(self, msg):
            self.messages.append(msg)

        def display(self, msg):
            self.messages

# Generated at 2022-06-22 19:26:01.220059
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    tmp_search_list = ["/tmp/path", "/fake/path", "/this/path/doesnt/exist"]
    real_search_list = ["/usr/share/ansible", "/etc/ansible/roles", "/usr/share/ansible/roles"]

    assert list(list_valid_collection_paths()) == list(list_valid_collection_paths([]))

    assert list(list_valid_collection_paths(tmp_search_list)) == ["/tmp/path"]
    assert list(list_valid_collection_paths(real_search_list)) == ["/usr/share/ansible", "/usr/share/ansible/roles"]

    # If a collection path is not a directory don't include it in the return list
    real_search_list.append("/usr/bin/python3")


# Generated at 2022-06-22 19:26:11.351908
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    os.system("mkdir -p /tmp/test_coll/test_ns/test_coll1")
    os.system("mkdir -p /tmp/test_coll/test_ns/test_coll2")

    col_dirs = list(list_collection_dirs(["/tmp/test_coll"]))
    # assert two collection dirs
    if len(col_dirs) != 2:
        raise AssertionError("Expected 2 collections, got '%s'" % len(col_dirs))

    # assert known collection paths
    expected_col_dirs = ['/tmp/test_coll/test_ns/test_coll1', '/tmp/test_coll/test_ns/test_coll2']
    for i in col_dirs:
        if i not in expected_col_dirs:
            raise Ass

# Generated at 2022-06-22 19:26:20.379619
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test filter out non existing or invalid search_paths for collections
    :return:
    """

    from ansible_collections.ansible.community.tests.unit.conftest import _create_directory_tree

    dirs = ['/etc', '/var', '/var/lib', '/var/lib/ansible', '/usr', '/usr/share', '/usr/share/ansible', '/srv', '/srv/lib']

    with _create_directory_tree(dirs):

        with open('/etc/ansible/ansible.cfg', 'w') as f:
            f.write("[defaults]\n")
            f.write("collections_path=/var/lib/ansible/collections:/srv/lib/ansible/collections\n")

        search_paths = []

        # new collection

# Generated at 2022-06-22 19:26:22.826511
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        "/nonexisting",
        "./test/unit/utils/collection_loader/test_collection_path",
        "./test/unit/utils/collection_loader/test_existing_collection/ns1.coll1",
    ]
    results = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(results) == 1
    assert results[0] == "./test/unit/utils/collection_loader/test_collection_path"

# Generated at 2022-06-22 19:26:29.581536
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    orig_path = to_bytes(os.path.realpath(os.curdir), errors='surrogate_or_strict')


# Generated at 2022-06-22 19:26:33.699485
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/foo/bar', '/baz/bar/buzz']
    valid_paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(valid_paths) == 2
    assert valid_paths == paths

    paths = ['/foo/bar', '/baz/bar/buzz', '/does/not/exist']
    valid_paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(valid_paths) == 2
    assert valid_paths == ['/foo/bar', '/baz/bar/buzz']

    valid_paths = list(list_valid_collection_paths(paths, warn=True))
    assert len(valid_paths) == 2

# Generated at 2022-06-22 19:26:42.311205
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Unit tests for list_collection_dirs, basically a wrapper for is_collection_path
    """
    from ansible.utils.collection_loader import is_collection_path
    from ansible.collections.ansible.builtin import profile_tasks as pt
    from ansible.collections.ansible.builtin.plugins.module_utils import network as nu1
    from ansible.collections.ansible.builtin.plugins.action.network import network as nu2

    # print(dir(nu1))
    # print(dir(nu2))

    # This is an actual collection dir
    assert is_collection_path(os.path.dirname(os.path.dirname(pt.__file__)))

    # These are not actual collection dirs

# Generated at 2022-06-22 19:26:54.098635
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Tests the list_collection_dirs function:
    - If no search_paths is passed, then `AnsibleCollectionConfig.collection_paths` is used
    - If a collection is provided, then only the paths for that collection are returned
    - If a namespace is provided, then only the paths for that namespace are returned
    """
    target_paths = [
        os.path.join('/tmp/collections_path', 'ansible_collections', 'foo', 'bar'),
        os.path.join('/tmp/collections_path', 'ansible_collections', 'foo', 'baz'),
        os.path.join('/tmp/collections_path', 'ansible_collections', 'hello', 'world')
    ]


# Generated at 2022-06-22 19:27:05.138322
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths

    # Make a test_tmp directory
    import tempfile
    test_tmp = tempfile.mkdtemp()

    # Create a collection directory
    collection_path = os.path.join(test_tmp, "test_collections")
    os.makedirs(collection_path)

    # Check that the valid collection path is returned
    assert list_valid_collection_paths([collection_path]) == [collection_path]

    # Check that a non-directory collection path is not returned
    f = open(collection_path, 'w')
    f.close()
    assert list_valid_collection_paths([collection_path]) == []

    # Check that a non-existent collection path is not returned
    assert list_valid_collection_paths

# Generated at 2022-06-22 19:27:12.094242
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # validate default paths
    assert next(list_valid_collection_paths()) == '/etc/ansible/collections'
    assert next(list_valid_collection_paths()) == '/usr/share/ansible/collections'

    # validate path that does not exist
    path_exists = False
    for x in list_valid_collection_paths(['/a/b/c/d/e/f']):
        path_exists = True

    assert not path_exists

    test_path = '/tmp/test_list_valid_collection_paths'
    os.makedirs(test_path)
    assert next(list_valid_collection_paths([test_path])) == test_path
    os.removedirs(test_path)

# Generated at 2022-06-22 19:27:13.335960
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-22 19:27:20.008182
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    search_paths = [
        "/this/path/does/not/exist",
        tempfile.mkdtemp(),
        "/this/path/is/a/file",
        "/no/trailing/slash"
    ]
    valid_paths = list(list_valid_collection_paths(search_paths))

    assert len(valid_paths) == 2
    assert search_paths[1] in valid_paths
    assert search_paths[3] in valid_paths

# Generated at 2022-06-22 19:27:22.507581
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    list_valid_collection_paths(search_paths=['/tmp', '/home'])

# Generated at 2022-06-22 19:27:26.724156
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_of_collections = list_collection_dirs(search_paths=[os.path.join(os.path.dirname(__file__), '..')])
    assert "ansible_collections.ansible.builtin" in list_of_collections

# Generated at 2022-06-22 19:27:29.896684
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        'this_is_not_a_real_path',
        '/tmp/no_chance_this_exists',
        '/etc'
    ]

    ret = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(ret) == 1
    assert ret.pop() == '/etc'

# Generated at 2022-06-22 19:27:42.824405
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import sys

    test_dir = tempfile.mkdtemp()
    collection_root = os.path.join(test_dir, 'ansible_collections')

    namespace_dir_1 = os.path.join(collection_root, 'namespace1')
    os.makedirs(namespace_dir_1)

    coll_dir_1 = os.path.join(namespace_dir_1, 'collection1')
    os.makedirs(coll_dir_1)

    collection_root_2 = os.path.join(test_dir, 'ansible_collections2')
    namespace_dir_2 = os.path.join(collection_root_2, 'namespace2')
    os.makedirs(namespace_dir_2)

    coll_dir_2

# Generated at 2022-06-22 19:27:52.220392
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # This tests whether the collections are found in the search_paths
    search_paths = ['/tmp/test_collection1', '/tmp/test_collection2']
    expected_result = ['/tmp/test_collection1/ansible_collections/test/test_plugin/plugins/modules',
                       '/tmp/test_collection1/ansible_collections/test/test_plugin/plugins/test',
                       '/tmp/test_collection2/ansible_collections/test/test_plugin/plugins/modules',
                       '/tmp/test_collection2/ansible_collections/test/test_plugin/plugins/test']
    for path in expected_result:
        if not os.path.exists(path):
            os.makedirs(path)


# Generated at 2022-06-22 19:27:59.632176
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import file_dummer

    # Absence of search_paths param should not cause any exception
    search_paths = list_valid_collection_paths()

    # Absence of search_paths param should not cause any exception
    search_paths = list_valid_collection_paths(warn=True)

    # Absolute path
    with file_dummer.create() as path:
        search_paths = list_valid_collection_paths([path])
        assert path in search_paths

    # Symbolic link
    with file_dummer.create() as path:
        os.symlink(path, 'link')

        search_paths = list_valid_collection_paths(['link'])
        assert path in search_paths

    # Broken symbolic link


# Generated at 2022-06-22 19:28:08.033497
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Tests for list_valid_collection_paths
    """

    # Test for missing path
    missing_path = ['/not/exist']
    r = list_valid_collection_paths(search_paths=missing_path, warn=True)
    assert list(r) == []

    # Test for valid path
    from ansible.utils.collection_loader import fetch_distribution_namespaces
    valid_path = fetch_distribution_namespaces()
    r = list_valid_collection_paths(search_paths=valid_path, warn=True)
    assert list(r) == valid_path

# Generated at 2022-06-22 19:28:15.536503
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    functional test for list_valid_collection_paths
    :return: 
    """
    # Test using default paths
    search_paths = []
    assert list(list_valid_collection_paths(search_paths)) == []
    assert len(list(list_valid_collection_paths(search_paths))) == 0

    # Test using non-existing paths
    search_paths = ['/foo/bar']
    assert list(list_valid_collection_paths(search_paths)) == []
    assert len(list(list_valid_collection_paths(search_paths))) == 0

    # Test using various combinations of valid and invalid paths
    search_paths = ['/foo/bar', '/', '/tmp/']
    assert list(list_valid_collection_paths(search_paths))

# Generated at 2022-06-22 19:28:25.570439
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [os.path.join(os.path.sep, "test1"), os.path.join(os.path.sep, "test2")]

    # test with invalid search_path
    b_path = to_bytes(os.path.join(os.path.sep, "test1"))
    assert list(list_valid_collection_paths(search_paths)) == [os.path.join(os.path.sep, "test2")]

    os.makedirs(b_path)
    # test with valid search_path
    assert list(list_valid_collection_paths(search_paths)) == [os.path.join(os.path.sep, "test1"), os.path.join(os.path.sep, "test2")]

    # test with

# Generated at 2022-06-22 19:28:26.890010
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from pprint import pprint
    pprint([x for x in list_collection_dirs()])

# Generated at 2022-06-22 19:28:37.000776
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _load_collections

    my_test_collections = ['/tmp/mytestcoll1', '/tmp/mytestcoll2']
    search_paths = ['/tmp/mytestcoll1', '/tmp/mytestcoll2']
    ansible_collections = ['ansible_collections']

    _load_collections(search_paths=search_paths, collection_list=ansible_collections + my_test_collections)

    assert set(list_collection_dirs(search_paths, None)) == set(my_test_collections)

# Generated at 2022-06-22 19:28:50.396373
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ''' This function tests the list_collection_dir function '''

    # Sandbox dir used to test the function
    sandbox_dir = os.path.join(os.path.dirname(__file__), 'test_data/list_collection_dirs/')

    # Dirs that should be returned for the search_path
    expected_dirs = [
        os.path.join(sandbox_dir, 'ansible_collections/ansible/test_collection1'),
        os.path.join(sandbox_dir, 'ansible_collections/ansible/test_collection2/plugins/actions')
    ]

    # List of collection directories returning from the function call
    coll_dirs = list(list_collection_dirs(search_paths=[sandbox_dir]))

    # Compare the expected and actual dirs, and print

# Generated at 2022-06-22 19:28:59.225266
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test empty list - should get default paths
    coll_paths = list(list_valid_collection_paths([]))
    assert len(coll_paths) == len(AnsibleCollectionConfig.collection_paths)

    # Test list with all default paths - should get all default paths
    coll_paths = list(list_valid_collection_paths(AnsibleCollectionConfig.collection_paths))
    assert len(coll_paths) == len(AnsibleCollectionConfig.collection_paths)

    # Test list with some default paths and some bogus paths - should get default paths
    coll_paths = list(list_valid_collection_paths(AnsibleCollectionConfig.collection_paths + ['/bogus/path']))

# Generated at 2022-06-22 19:29:10.078290
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # prep collections
    coll_path = './ansible_collections'
    if os.path.exists(coll_path):
        import shutil
        shutil.rmtree(coll_path)

    os.mkdir(coll_path)
    os.mkdir(os.path.join(coll_path, 'ns1'))
    os.mkdir(os.path.join(coll_path, 'ns2'))
    os.mkdir(os.path.join(coll_path, 'ns1', 'coll1'))
    os.mkdir(os.path.join(coll_path, 'ns1', 'coll2'))
    os.mkdir(os.path.join(coll_path, 'ns2', 'coll1'))

# Generated at 2022-06-22 19:29:18.608223
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # valid collection paths
    path1 = "/tmp/ansible_collections/test_namespace/test_collection"
    path2 = "/tmp/ansible_collections/ansible.test_collection"

    # invalid collection paths
    path3 = "/tmp/ansible_collections/"
    path4 = "/tmp/test_namespace/test_collection"

    # create test environment
    os.makedirs(path1)
    os.makedirs(path2)
    os.makedirs(path3)
    os.makedirs(path4)

    # test with no parameters
    paths = list_collection_dirs()  # should return all 3 valid directories
    assert path1 in paths
    assert path2 in paths
    assert path3 not in paths
    assert path4 not in paths

    # test with namespace filter

# Generated at 2022-06-22 19:29:27.946775
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # If no filter is provided, all collections in all directories should be returned
    assert len(list(list_collection_dirs())) == 2

    # If a collection is passed, the directory should be returned
    assert len(list(list_collection_dirs(coll_filter='ansible_namespace.awesome_collection'))) == 1

    # If a collection is passed and does not exist, an empty list should be returned
    assert not list(list_collection_dirs(coll_filter='ansible_namespace.non_existing_collection'))

    # If a namespace is passed, the directories for each collection in that namespace should be returned
    assert len(list(list_collection_dirs(coll_filter='ansible_namespace'))) == 1

    # If a namespace is passed and does not exist, an empty list should be returned
    assert not list

# Generated at 2022-06-22 19:29:33.943706
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_path = [os.path.dirname(__file__) + '/unit/collection_loader/data']
    correct_search_path = list(list_valid_collection_paths(search_path))
    assert correct_search_path == search_path


# Generated at 2022-06-22 19:29:43.132098
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    This function checks that the collection loader is able to find valid
    collection paths.
    """

    assert [] == list(list_valid_collection_paths([]))

    # mock a valid collection path
    my_path = os.path.join(os.path.dirname(__file__), "../../")
    my_path = os.path.join(my_path, 'ansible_collections/ansible/test_collection')

    # If the path is not a collection root, it should not be returned
    assert [] == list(list_valid_collection_paths([my_path]))

    # Now add a subdir inside a collection root, it should not be returned
    subdir = os.path.join(my_path, 'plugins/modules')

# Generated at 2022-06-22 19:29:54.208964
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    from ansible.module_utils.six.moves import StringIO

    def run_module():

        from ansible.module_utils.basic import AnsibleModule

        module = AnsibleModule(
            argument_spec=dict(),
        )
        module.exit_json(**result)

    def run_module_with_path(*paths):
        # create a fake path and ensure it's there
        newpath = tempfile.mkdtemp()

# Generated at 2022-06-22 19:30:03.407424
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        'non_existent',
        '/var/tmp/foo',
        'not_a_dir',
        'not_a_dir_either',
    ]

    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=True))
    assert len(valid_paths) == 0

    search_paths = [
        '/var/tmp/foo',
        '/var/tmp/bar'
    ]

    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=True))
    assert len(valid_paths) == 0

    search_paths = [
        '/var/tmp/foo',
        '/usr/local/bin'
    ]


# Generated at 2022-06-22 19:30:07.284390
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_search_paths = [
        '/etc/ansible',
        '/usr/share/ansible',
        '/usr/local/share/ansible',
        '/usr/share/ansible',
    ]
    found_paths = []
    for path in list_valid_collection_paths(test_search_paths):
        found_paths.append(path)
    assert len(found_paths) == 4