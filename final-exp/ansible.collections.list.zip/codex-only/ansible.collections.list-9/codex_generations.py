

# Generated at 2022-06-22 19:20:17.333697
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '/path/does/not/exist',
        '/dev/null',
        '/etc',
        '/etc/ansible',
        '/etc/ansible/collections',
    ]
    # verify that we do not get back any of the paths in test_paths
    # that do not exist
    assert ['/etc', '/etc/ansible', '/etc/ansible/collections'] == list(list_valid_collection_paths(test_paths, warn=False))
    # verify we get back all paths even if they do not exist
    assert ['/path/does/not/exist', '/dev/null', '/etc', '/etc/ansible', '/etc/ansible/collections'] == list(list_valid_collection_paths(test_paths, warn=True))



# Generated at 2022-06-22 19:20:25.658229
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Verify return list as expected
    :return:
    """
    collect_dirs = []
    for d in list_collection_dirs(search_paths=['/usr/share/ansible'], coll_filter=None):
        collect_dirs.append(os.path.basename(d))
    assert sorted(collect_dirs) == sorted(['community.general', 'community.general', 'community.windows'])

    collect_dirs = []
    for d in list_collection_dirs(search_paths=['/usr/share/ansible'], coll_filter='community'):
        collect_dirs.append(os.path.basename(d))
    assert sorted(collect_dirs) == sorted(['community.general', 'community.general', 'community.windows'])

    collect_dir

# Generated at 2022-06-22 19:20:29.519175
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/tmp/foo', '/tmp/bar', '/tmp/baz']

    for path in list_valid_collection_paths(paths, warn=False):
        assert path in paths



# Generated at 2022-06-22 19:20:34.373064
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["a", "b", "c", "d"])) == ['a', 'b', 'c', 'd']
    assert list(list_valid_collection_paths(["a", "b", "c", "d"], warn=True)) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-22 19:20:42.986599
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test default behavior
    paths = list(list_valid_collection_paths())
    assert isinstance(paths, list)
    assert len(paths) == 1

    # test with explicit path
    tmp_path = './mycoll'
    paths = list(list_valid_collection_paths([tmp_path]))
    assert paths[0] == tmp_path

    # test with non existing path
    paths = list(list_valid_collection_paths(['/tmp/doesnotexist', tmp_path]))
    assert paths[0] == tmp_path

    # test with non existing path, don't warn
    paths = list(list_valid_collection_paths(['/tmp/doesnotexist', tmp_path], warn=False))
    assert len(paths) == 0

    # test with not dir
   

# Generated at 2022-06-22 19:20:53.858285
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    tmp = tempfile.mkdtemp()

    # check with path that does not exist
    # warn
    result = list(list_valid_collection_paths([os.path.join(tmp, "dne")], warn=True))
    assert len(result) == 0

    # no warn
    result = list(list_valid_collection_paths([os.path.join(tmp, "dne")]))
    assert len(result) == 0

    # check with path that is not dir
    # warn
    path = os.path.join(tmp, "notdir")
    open(path, "ab").close()
    result = list(list_valid_collection_paths([path], warn=True))
    assert len(result) == 0

    # no warn

# Generated at 2022-06-22 19:20:58.515841
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/etc/ansible/collections', '/etc/ansible/mycollections']
    expected = search_paths
    actual = list_valid_collection_paths(search_paths)
    assert actual == expected

# Generated at 2022-06-22 19:21:06.938892
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the function list_collection_dirs
    """

    from ansible.utils import context_objects as co

    test_coll_paths = [
        '/tmp/not-exists',
        '/tmp/not/a/dir',
        '/tmp/ansible_collections',
        '/tmp/ansible_collections/not/a/dir',
        '/tmp/ansible_collections/ansible/foo',
        '/tmp/another/ansible_collections/ansible/foo',
    ]

    search_paths = []
    for test_path in test_coll_paths:
        if not os.path.exists(os.path.dirname(test_path)):
            os.makedirs(os.path.dirname(test_path))

# Generated at 2022-06-22 19:21:09.716318
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['foo', 'bar']
    result = list(list_valid_collection_paths(search_paths, warn=True))
    assert search_paths == result



# Generated at 2022-06-22 19:21:15.810640
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([])).__len__() == 1
    assert list(list_valid_collection_paths(None)).__len__() == 1
    assert list(list_valid_collection_paths(None, warn=False)).__len__() == 1
    assert list(list_valid_collection_paths(None, warn=True)).__len__() == 1


test_list_valid_collection_paths()



# Generated at 2022-06-22 19:21:25.378815
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test no search_paths supplied
    assert list(list_valid_collection_paths())

    expected_default_paths = [
        os.path.join(os.path.expanduser('~'), 'ansible', 'collections'),
        os.path.join('/', 'usr', 'share', 'ansible', 'collections')
    ]

    for path in list_valid_collection_paths():
        assert path in expected_default_paths

    # test existing path
    existing_path = "./"
    assert list(list_valid_collection_paths([existing_path]))

    # test no-existing path
    non_existing_path = "./unexisting"
    assert not list(list_valid_collection_paths([non_existing_path]))

    # test existing path, but not directory


# Generated at 2022-06-22 19:21:35.861853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from contextlib import contextmanager

    @contextmanager
    def ensure_collections(paths=None):
        """
        Creates a valid collection structure rooted at a temp file folder
        :param paths: the list of collection paths to create, default to the structure required by the unit test
        :return: the path to the temp folder contianing the valid collection structure
        """
        import shutil
        import tempfile


# Generated at 2022-06-22 19:21:42.693294
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    sample_dir = mkdtemp()

# Generated at 2022-06-22 19:21:53.274982
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    for path in list_valid_collection_paths(search_paths=['/tmp/doesnotexist']):
        assert False

        for path in list_valid_collection_paths(search_paths=['/dev/null']):
            assert False

        for path in list_valid_collection_paths(search_paths=['/etc']):
            assert False

        for path in list_valid_collection_paths(search_paths=[os.curdir]):
            assert False

        display.verbosity = 2
        for path in list_valid_collection_paths(search_paths=['/tmp/doesnotexist']):
            assert False

        display.verbosity = 2
        for path in list_valid_collection_paths(search_paths=['/dev/null']):
            assert False

   

# Generated at 2022-06-22 19:22:01.058459
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # No filter
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) >= 1
    for coll_dir in collection_dirs:
        assert os.path.isdir(coll_dir)
        assert is_collection_path(coll_dir)

    # Filter by namespace
    collection_dirs = list(list_collection_dirs(['../ansible_collections'], 'ansible'))
    assert len(collection_dirs) >= 1
    for coll_dir in collection_dirs:
        assert os.path.isfile(os.path.join(coll_dir, 'ansible.meta'))

    # Filter by collection
    collection_dirs = list(list_collection_dirs(['../ansible_collections'], 'ansible.builtin'))
   

# Generated at 2022-06-22 19:22:12.325052
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(search_paths=["/tmp/does_not_exist"]))) == 0
    assert len(list(list_valid_collection_paths(search_paths=["/"]))) == 0
    assert len(list(list_valid_collection_paths(search_paths=["/tmp"]))) == 1
    assert len(list(list_valid_collection_paths())) > 0
    # Noop
    assert len(list(list_valid_collection_paths())) == len(list(list_valid_collection_paths(warn=False)))

# Generated at 2022-06-22 19:22:18.852105
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = ['test/units/utils/test_collections/collections/one']
    dirs = list_collection_dirs(search_paths=paths, coll_filter='test.one')
    assert ['test.one'] == list(dirs)

    dirs = list_collection_dirs(search_paths=paths, coll_filter='test')
    assert ['test.one'] == list(dirs)

    dirs = list_collection_dirs(search_paths=paths)
    assert ['test.one'] == list(dirs)

    dirs = list_collection_dirs(search_paths=None, coll_filter='test.one')
    assert ['test.one'] == list(dirs)

# Generated at 2022-06-22 19:22:23.537847
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    mylist = [
        '/does/not/exist',
        '/dev/null',
        '/etc/passwd',
        '/etc',
        'ansible_collections',
        'namespace.collection',
        'namespace.collection.plugins.module_utils'
    ]

    assert not list(list_valid_collection_paths(mylist))



# Generated at 2022-06-22 19:22:30.511880
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ["/usr/share/ansible/collections"]

    paths = list(list_valid_collection_paths(search_paths))
    assert paths == search_paths

    search_paths = ["/tmp/does_not_exist", "/usr/share/ansible/collections", "/tmp/does_not_exist_either"]

    paths = list(list_valid_collection_paths(search_paths))
    assert paths == ["/usr/share/ansible/collections"]



# Generated at 2022-06-22 19:22:37.647361
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import sys

    search_path = [tempfile.mkdtemp()]
    path_set = set()

    mycoll = os.path.join(search_path[0], 'ansible_collections', 'foo', 'bar')
    mycoll_inexact = os.path.join(search_path[0], 'ansible_collections', 'foo', 'bar', 'baz')


# Generated at 2022-06-22 19:22:43.936047
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    dirname = tempfile.mkdtemp()
    temp_path = os.path.join(dirname, 'test_collections')
    os.mkdir(temp_path)

    # Test with mix of valid and invalid paths
    paths = [temp_path, "not_a_path", dirname]
    expected = [temp_path, dirname]

    filtered = list(list_valid_collection_paths(paths))
    assert filtered == expected



# Generated at 2022-06-22 19:22:45.004230
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # TODO: write test
    assert False

# Generated at 2022-06-22 19:22:54.823759
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Unit test for function list_collection_dirs
    '''
    import shutil
    import tempfile
    import os

    collections = {
        'ns1': {
            'coll1': '',
            'coll2': ''
        },
        'ns2': {
            'coll3': '',
            'coll4': ''
        }
    }

    with tempfile.TemporaryDirectory() as tmp_dir:
        for n, colls in collections.items():
            for c, _ in colls.items():
                collections[n][c] = os.path.join(tmp_dir, n, c)
                os.makedirs(collections[n][c], exist_ok=True)

# Generated at 2022-06-22 19:22:58.870566
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/foo/bar', '/badpath', 'badpath/foo']
    assert list(list_valid_collection_paths(search_paths)) == []
    assert list(list_valid_collection_paths(search_paths, warn=True)) == []



# Generated at 2022-06-22 19:23:03.135345
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['./collections/ansible_collections', '~/.ansible/collections/ansible_collections', 'nothing']
    assert(len(list(list_valid_collection_paths(test_paths))) == 1)



# Generated at 2022-06-22 19:23:11.560486
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_search_paths = ['.', '~/collections', '/usr/share/ansible/collections']
    search_paths = list(list_valid_collection_paths(test_search_paths))

    assert './ansible_collections' in search_paths
    assert '~/collections' in search_paths
    assert '/usr/share/ansible/collections' in search_paths



# Generated at 2022-06-22 19:23:19.677160
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def _test_list_collection_dirs(coll_filter, expected):

        collection_paths = ['/path/to/collections', '/path/to/other', '/path/to/third-party']

        # mock the collection_paths returned by list_valid_collection_paths()
        with mock.patch.object(AnsibleCollectionConfig, 'collection_paths', new_callable=mock.PropertyMock,
                               return_value=collection_paths):

            try:
                actual = [x for x in list_collection_dirs(coll_filter=coll_filter)]
            except AnsibleError as e:
                if "Invalid collection pattern supplied" in str(e):
                    # return if the coll_filter is invalid
                    return

            expected_length = len(expected)

# Generated at 2022-06-22 19:23:32.959330
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import list_valid_collection_paths

    print("\n*** No search_paths, only defaults")
    search_paths = None
    for path in list_valid_collection_paths(search_paths):
        print(path)

    # test a mix of good and bad search_paths

# Generated at 2022-06-22 19:23:43.622561
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create a fake collection test directory structure to find
    # It will be a subdirectory of the directory
    # in which the test is being executed
    base_dir = os.path.dirname(__file__)
    collection_dir = os.path.join(base_dir, "test_colls")
    # We want to be sure that the only collections found
    # are those in the test directory
    search_path = [collection_dir]

    # Create the test directory and a fake collection namespace directory
    os.mkdir(collection_dir)
    os.mkdir(os.path.join(collection_dir, "namespace"))

    # Create a fake collection for the namespace
    coll = os.path.join(base_dir, "test_colls", "namespace", "collection")
    os.mkdir(coll)
    f

# Generated at 2022-06-22 19:23:54.155770
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import makedirs_safe

    valid_paths = []
    invalid_paths = []

    with make_tempdir() as tempdir:
        path1 = os.path.join(tempdir, 'path1')
        makedirs_safe(path1)
        valid_paths.append(path1)

        file1 = os.path.join(tempdir, 'file1')
        with open(file1, 'w') as f:
            f.write('test')
        invalid_paths.append(file1)

        path2 = os.path.join(tempdir, 'path2')
        makedirs_safe(path2)
        valid_paths.append(path2)

        path3 = os.path.join(tempdir, 'path3')
        invalid_path

# Generated at 2022-06-22 19:24:03.809039
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert [path for path in list_valid_collection_paths()] is not None

default_coll_root = b'/tmp/ansible_collections'
default_coll1 = b'/tmp/ansible_collections/namespace/collection1'
default_coll2 = b'/tmp/ansible_collections/namespace/collection2'
default_coll3 = b'/tmp/ansible_collections/namespace/collection3'
default_coll4 = b'/tmp/ansible_collections/namespace/collection4'
default_coll5 = b'/tmp/ansible_collections/namespace/collection5'


# Generated at 2022-06-22 19:24:15.326483
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Pass one normal path and one fake path.
    search_paths = [
        "~/ansible/test-collections",
        "/fake/path/test-collections",
    ]

    new_paths = list(list_valid_collection_paths(search_paths))

    # Expect the new list to be just the first valid path.
    assert len(new_paths) == 1
    assert new_paths[0] == search_paths[0]

    # Test with no args.
    new_paths = list(list_valid_collection_paths())

    # Expect the default collection path to be returned
    # and it should meet some basic criteria.
    assert(len(new_paths) > 0)


# Generated at 2022-06-22 19:24:18.238386
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(coll_filter='community.general'))
    assert len(dirs) == 1



# Generated at 2022-06-22 19:24:27.986101
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import os
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.display import Display
    display = Display()

    collection_path = os.getcwd()

    display.display("Testing list_collection_dirs()")
    display.display("collection_path: %s" % collection_path)

    display.display("list_collection_dirs() without filters")
    for collection in list_collection_dirs([collection_path]):
        display.display("Collection dir: %s" % collection)

    display.display("list_collection_dirs() with filters")
    for collection in list_collection_dirs([collection_path], coll_filter='ns1.coll1'):
        display.display("Collection dir: %s" % collection)

# Generated at 2022-06-22 19:24:36.252275
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    tmppath = './ansible/test/utils/collection_loader/__pycache__'
    test_paths = [
        './ansible',
        tmppath,
        './ansible/collections',
        '/usr/share/ansible/collections',
        '/tmp/does/not/exist',
        '/tmp/does/not/exist_either',
    ]

    os.makedirs(tmppath, mode=0o777, exist_ok=True)

    new_paths = list_valid_collection_paths(test_paths, warn=False)
    assert len(new_paths) == 1
    assert new_paths[0] == tmppath


# Generated at 2022-06-22 19:24:42.897739
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    to_test = ['/some/path', '/some/other/path']
    should_be = ['/some/path/ansible_collections', '/some/other/path/ansible_collections']

    # No search paths
    val = list(list_collection_dirs())

    # Default collection search paths
    val = list(list_collection_dirs(search_paths=[]))


    # Specific search path
    val = list(list_collection_dirs(search_paths=to_test))

    assert to_test == should_be

# Generated at 2022-06-22 19:24:48.513012
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['test_path_1', 'test_path_2', 'test_path_3']
    expected_paths = []
    assert list(list_valid_collection_paths(test_paths)) == expected_paths


# Generated at 2022-06-22 19:24:58.149786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible import cli
    from ansible.errors import AnsibleOptionsError

    # test missing collection path
    options = cli.CLI._create_parser().parse_args(['--collections-path', 'doesnotexist'])
    try:
        list_valid_collection_paths(options.collections_path)
    except AnsibleOptionsError as e:
        assert 'doesnotexist' in str(e)

    # test collection path that is a file
    with tempfile.NamedTemporaryFile() as f:
        options = cli.CLI._create_parser().parse_args(['--collections-path', f.name])
        try:
            list_valid_collection_paths(options.collections_path)
        except AnsibleOptionsError as e:
            assert f.name in str(e)

# Generated at 2022-06-22 19:24:58.748242
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:25:01.505784
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list(list_collection_dirs())
    assert len(collections) > 0
    for coll in collections:
        assert os.path.isdir(coll)



# Generated at 2022-06-22 19:25:10.789553
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    try:
        dirs = list_valid_collection_paths()
    except:
        dirs = []
    assert "/usr/share/ansible/collections" in dirs

    tempdir = tempfile.gettempdir()
    not_dir = list_valid_collection_paths([os.path.join(tempdir, 'tempfile.txt')])
    assert len(not_dir) == 0
    not_exists = list_valid_collection_paths([os.path.join(tempdir, 'not_exists')])
    assert len(not_exists) == 0



# Generated at 2022-06-22 19:25:21.372033
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():


    def get_test_search_paths(paths):
        test_search_paths = []
        for path in paths:
            if path is not None:
                test_search_paths.append(path)
            else:
                test_search_paths.append("/tmp/dummy_path")
        return test_search_paths


    test_search_paths = get_test_search_paths(['/tmp/collection_path'])
    result = list(list_valid_collection_paths(test_search_paths))
    assert result == ['/tmp/collection_path']


    test_search_paths = get_test_search_paths(['/tmp/collection_path', None, '/tmp/collection_path1'])

# Generated at 2022-06-22 19:25:27.375440
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=["./test/units/data/ansible_collections_1/ansible_collections"], coll_filter=None) == [
        b'./test/units/data/ansible_collections_1/ansible_collections/test_ns/test_collection_2']



# Generated at 2022-06-22 19:25:34.030978
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test list_valid_collection_paths
    # first some good ones, should return the same list
    test = ['foo', 'bar']
    assert list(list_valid_collection_paths(test)) == test

    # and now some negative cases
    test = ['nosuchfile/nosuchdir']
    assert list(list_valid_collection_paths(test)) == []

    test = ['test/testdata/list_collection_dirs.py']
    assert list(list_valid_collection_paths(test)) == []



# Generated at 2022-06-22 19:25:45.477990
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the list_collection_dirs function
    """
    # pylint: disable=unused-variable, unused-argument

    import os
    # import pytest

    test_vars = {
        'ansible_collections_path': [os.path.abspath('tests/fixtures/collections')],
        'my_collection': 'my.collection',
        'no_collection': 'no.collection'
    }

    def test_list_collection_dirs_one_collection(mocker, monkeypatch, ansible_module):
        """
        This test-case tests the list_collection_dirs function with 1 collection
        """
        # pylint: disable=unused-argument

# Generated at 2022-06-22 19:25:55.226749
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    display = Display()
    try:
        collection = os.environ['ANSIBLE_COLLECTIONS_PATHS']
    except KeyError:
        raise SystemExit("Failed to get ANSIBLE_COLLECTIONS_PATHS")

    if not collection:
        raise SystemExit("Failed to get ANSIBLE_COLLECTIONS_PATHS")

    collection_path = collection.split(os.pathsep)

    coll_dir = list_collection_dirs(collection_path)
    for cl in coll_dir:
        display.display(cl)

# test_list_collection_dirs()

# Generated at 2022-06-22 19:26:04.077680
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    list_collection_dirs should return a list of valid collection directories
    """
    coll_dirs = list(list_collection_dirs(search_paths=['test/unit/plugins/modules/ansible_collections']))
    expected_coll_dirs = set(['test/unit/plugins/modules/ansible_collections/namespace2/collection2/',
                              'test/unit/plugins/modules/ansible_collections/namespace1/collection1/',
                              'test/unit/plugins/modules/ansible_collections/namespace1/collection2/',
                              'test/unit/plugins/modules/ansible_collections/namespace2/collection1/'])
    assert set(coll_dirs) == expected_coll_dirs

# Generated at 2022-06-22 19:26:13.292615
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([os.path.join(os.path.dirname(__file__),
                                                          'fixtures/collection_loader/search_paths_test/path1'),
                                            os.path.join(os.path.dirname(__file__),
                                                         'fixtures/collection_loader/search_paths_test/path2')
                                            ])) == [os.path.join(os.path.dirname(__file__),
                                                                 'fixtures/collection_loader/search_paths_test/path1'),
                                                    os.path.join(os.path.dirname(__file__),
                                                                 'fixtures/collection_loader/search_paths_test/path2')]

# Generated at 2022-06-22 19:26:21.606318
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import unittest

    class AnsibleCollectionUtilsModuleUtilsTest(unittest.TestCase):

        def test_list_collection_dirs(self):

            a_paths = []
            a_paths.append('/tmp/ansible_collections')
            a_paths.append('/tmp/ansible_collections2')

            d_dict = {}
            d_dict['ansible_simple_collection'] = '/tmp/ansible_collections/ansible/simple_collection'
            d_dict['ansible_simple_collection2'] = '/tmp/ansible_collections/ansible/simple_collection2'
            d_dict['ansible_simple_collection3'] = '/tmp/ansible_collections2/ansible/simple_collection3'

            b_dict = {}

# Generated at 2022-06-22 19:26:29.141539
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test passing no filters
    root_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-22 19:26:37.616498
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ansible = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    test_coll_paths = []
    for path in ["/tmp/ansible_collections", os.path.join(ansible, "test/support/test_collections")]:
        if os.path.exists(path):
            test_coll_paths.append(path)

    for path in list_collection_dirs(test_coll_paths, coll_filter="mynamespace.mycollection"):  # noqa: F841
        assert '/ansible_collections/mynamespace/mycollection' in path
        assert 'ansible_collections' in path
        assert 'mycollection' in path
        assert 'mynamespace' in path


# Generated at 2022-06-22 19:26:46.989685
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    test_coll_path = tempfile.mkdtemp()
    # test single valid path
    assert list(list_valid_collection_paths([test_coll_path])) == [test_coll_path]
    assert list(list_valid_collection_paths([test_coll_path], warn=False)) == [test_coll_path]
    assert list(list_valid_collection_paths([test_coll_path], warn=True)) == [test_coll_path]
    # test single invalid path
    assert list(list_valid_collection_paths(["/usr/bin"])) == []
    assert list(list_valid_collection_paths(["/usr/bin"], warn=False)) == []
    assert list(list_valid_collection_paths(["/usr/bin"], warn=True))

# Generated at 2022-06-22 19:26:49.027158
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections_list = list_collection_dirs()
    assert collections_list is not None

# Generated at 2022-06-22 19:26:56.091433
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_text
    from tempfile import mkdtemp
    from shutil import rmtree
    import os


# Generated at 2022-06-22 19:27:07.938316
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import ansible.module_utils.validate_collection

    old_display = ansible.module_utils.validate_collection.display
    test_dir = tempfile.mkdtemp()
    test_dir2 = tempfile.mkdtemp()
    test_dir3 = tempfile.mkdtemp()
    test_dir4 = tempfile.mkdtemp()
    test_dir5 = tempfile.mkdtemp()
    test_dir6 = tempfile.mkdtemp()
    test_dir7 = tempfile.mkdtemp()
    test_dir8 = tempfile.mkdtemp()
    test_dir9 = tempfile.mkdtemp()
    test_dir10 = tempfile.mkdtemp()


# Generated at 2022-06-22 19:27:12.736142
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert next(list_valid_collection_paths(['/tmp', '/usr/share/ansible/collections'])) == '/usr/share/ansible/collections'



# Generated at 2022-06-22 19:27:22.347096
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os.path

    # make a temp dir for a collection for testing
    tempdir = tempfile.mkdtemp(prefix='ansible_collections-')
    testdir = os.path.join(tempdir, 'ansible_collections/test/test')
    os.makedirs(testdir)

    # create a temp dir for a collection for testing
    tempdir2 = tempfile.mkdtemp(prefix='ansible_collections-')
    testdir2 = os.path.join(tempdir2, 'ansible_collections/test/test')
    os.makedirs(testdir2)

    # create a temp dir for a collection for testing
    tempdir3 = tempfile.mkdtemp(prefix='ansible_collections-')

# Generated at 2022-06-22 19:27:31.902741
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    inputs = ['', '/home/user/ansible_collections', '/home', '/var/ansible_collections', 'ansible_collections',
              '/etc/ansible/ansible_collections']
    expected_outputs = ['/home/user/ansible_collections', '/var/ansible_collections', 'ansible_collections',
                        '/etc/ansible/ansible_collections']

    test_outputs = list_valid_collection_paths(search_paths=inputs)

    assert len(test_outputs) == len(expected_outputs)
    for i in range(len(test_outputs)):
        assert test_outputs[i] == expected_outputs[i]



# Generated at 2022-06-22 19:27:43.587677
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with no args
    expected = [os.path.expanduser("~/.ansible/collections")]
    assert(list_valid_collection_paths() == expected)

    # test with args, including valid and invalid paths
    expected = [os.path.expanduser("~/.ansible/collections"),
                "/tmp/foo/bar",
                "/tmp/baz/bin",
                "/tmp/foo/bin",
                "/tmp/foo/bin/qux",
                "/tmp/foo/bar/bin",
                "/tmp/foo/bar/bin/qux",
                "/tmp/foo/bar/qux"]

    expected.sort()


# Generated at 2022-06-22 19:27:52.701499
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import sys

    current_dir = os.path.dirname(os.path.realpath(__file__))
    module_utils_file = os.path.join(os.path.dirname(current_dir), 'module_utils')
    ansible_collections_file = os.path.join(os.path.dirname(current_dir), 'ansible_collections')
    sys.path.insert(0, module_utils_file)
    sys.path.insert(0, ansible_collections_file)

    from ansible_test.test_utils.module_loader import AnsibleFileFinder

    ansible_file_finder = AnsibleFileFinder(None, None, None, None)

# Generated at 2022-06-22 19:27:59.939674
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Simple unit test to validate behavior of list_collection_dirs

    This is executed by running "python plugins/collections/__init__.py"
    and if the collection directory is not found the test will report FAIL.
    """

    # test for all collections for current ansible install
    for path in list_collection_dirs():
        print("Found collection path: %s" % path)

    # test for a single collection
    for path in list_collection_dirs(coll_filter='community.general'):
        print("Found collection path: %s" % path)

    # test for a single namespace
    for path in list_collection_dirs(coll_filter='community'):
        print("Found collection path: %s" % path)

    # bad namespace

# Generated at 2022-06-22 19:28:09.277440
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test with no collections in the search paths
    search_paths = ['/tmp/foo', '/tmp/bar']
    coll_filter = None
    colls = list(list_collection_dirs(search_paths, coll_filter))
    assert len(colls) == 0

    # test with collections in the search paths
    from ansible_collections.ansible.community.tests.unit.conftest import populate_collections_path
    collections_path = populate_collections_path()

    search_paths = [collections_path]
    coll_filter = None
    colls = list(list_collection_dirs(search_paths, coll_filter))
    assert len(colls) == 1

# Generated at 2022-06-22 19:28:14.790418
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        '/tmp',
        './path/does/not/exist',
        './not/a/dir.txt',
        './path/exists',
    ]

    # create simple dir
    path = os.path.join(os.getcwd(), 'path/exists')
    os.makedirs(path)

    # expect to find only 1 path
    valid_paths = list_valid_collection_paths(search_paths)
    assert len(list(valid_paths)) == 1
    assert list(valid_paths)[0] == './path/exists'

    # cleanup
    os.rmdir(path)



# Generated at 2022-06-22 19:28:18.120698
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths([])
    assert list_valid_collection_paths(None)
    assert list_valid_collection_paths(search_paths=['/path/not/exist'])

# Generated at 2022-06-22 19:28:28.998800
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fakesearch = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fake_collection_dir')
    assert len(list(list_collection_dirs([fakesearch]))) == 1
    assert len(list(list_collection_dirs([fakesearch], 'fake_ns'))) == 1
    assert len(list(list_collection_dirs([fakesearch], 'fake_ns.fake_coll'))) == 1
    assert len(list(list_collection_dirs([fakesearch], 'fake_ns.fake_coll2'))) == 0

# vim: set noexpandtab ts=4 sw=4 autoindent

# Generated at 2022-06-22 19:28:39.185294
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    list_collection_dirs._unfrackpath = mock_unfrackpath_noop

    results = list(list_collection_dirs(['/tmp']))
    assert len(results) == 1
    assert results[0] == '/tmp/ansible_collections/test/test_collection'

    results = list(list_collection_dirs(['/tmp'], 'test'))
    assert len(results) == 1
    assert results[0] == '/tmp/ansible_collections/test/test_collection'

    results = list(list_collection_dirs(['/tmp'], 'test.test_collection'))
    assert len(results) == 1

# Generated at 2022-06-22 19:28:49.650307
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        "/foo/bar/baz",
        "/home/username/mycollections/"
    ]

    # verify we return valid paths
    assert list(list_valid_collection_paths(test_paths)) == test_paths

    # verify we filter out invalid paths
    assert list(list_valid_collection_paths([''])) == []

    # verify we filter out invalid paths, and return the valid paths
    assert list(list_valid_collection_paths([''] + test_paths)) == test_paths

    # verify we add default paths
    assert list(list_valid_collection_paths()) != []

# Generated at 2022-06-22 19:28:59.944395
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # collection name only
    test_paths = list(list_collection_dirs(coll_filter="acme.test"))
    assert len(test_paths) == 2
    for test_path in test_paths:
        # check for "acme/test"
        assert b"acme" in os.path.basename(os.path.dirname(test_path))
        assert b"test" in os.path.basename(test_path)

    # namespace name only
    test_paths = list(list_collection_dirs(coll_filter="acme"))
    assert len(test_paths) == 4

# Generated at 2022-06-22 19:29:10.716513
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    tmp_path = "/tmp/collections"

    if os.path.exists(tmp_path):
        os.rmdir(tmp_path)

    # path is an invalid location
    path1 = "/invalid/path"

    # path is a valid, existing location, but not a directory
    with open(tmp_path, 'w') as f:
        f.write('test contents here')

    # path is a valid location
    path3 = tmp_path

    # create tmp dir
    os.mkdir(tmp_path)

    search_paths = [path1, path2, path3]
    valid_paths = list_valid_collection_paths(search_paths, warn=False)

    # verify path1 was not returned
    assert path1 not in valid_paths
    # verify path3 was returned

# Generated at 2022-06-22 19:29:20.764254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.common.collections import list_collection_dirs

    good_paths = ['./ansible_collections/col1/ns1',
                  './ansible_collections/col2/ns2',
                  './ansible_collections/col3/ns3',
                  './ansible_collections/col4/ns4',
                  './ansible_collections/col5/ns5',
                  './ansible_collections/col6/ns6',
                  './ansible_collections/col7/ns7',
                  ]

    bad_paths = ['./bad_path1',
                 './bad_path2',
                 './bad_path3',
                 ]

    # check handling of path filtering

# Generated at 2022-06-22 19:29:30.018424
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os

    collection_root = os.path.join(os.path.dirname(__file__), '../../../../../collections/ansible_collections')

    collection_dirs = list(list_collection_dirs(search_paths=[collection_root]))

    assert isinstance(collection_dirs, list)
    assert len(collection_dirs) == 3
    assert os.path.basename(collection_dirs[0]) == 'my_namespace'
    assert os.path.basename(collection_dirs[1]) == 'my_namespace2'
    assert os.path.basename(collection_dirs[2]) == 'my_namespace3'


# Generated at 2022-06-22 19:29:40.367014
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    import pytest
    from ansible.module_utils.common._collections_compat import CollectionLoader

    test_collections_root = tempfile.mkdtemp()

    test_namespace = "test_namespace"
    test_collection = "test_collection"
    test_collection_dir = "%s/%s" % (test_namespace, test_collection)

    test_invalid_namespace = "test_invalid_namespace"
    test_invalid_directory = "test_invalid_dir"

    test_namespace_dir = test_invalid_namespace
    test_collection_dir = "%s/%s" % (test_namespace_dir, test_invalid_directory)


# Generated at 2022-06-22 19:29:51.408883
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(["test/unit/utils/ansible_test_collections"]))

    assert len(coll_dirs) == 1

    first_coll = next(iter(coll_dirs))
    assert to_bytes(first_coll) in [b"test/unit/utils/ansible_test_collections/ansible_namespace/test_coll"]

    filtered_colls = list(list_collection_dirs(["test/unit/utils/ansible_test_collections"], "ansible_namespace.test_coll"))
    assert len(filtered_colls) == 1

    first_coll = next(iter(filtered_colls))

# Generated at 2022-06-22 19:29:58.003327
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp/does/not/exist'])) == []
    assert list(list_valid_collection_paths([os.path.abspath(__file__)])) == []
    assert '/tmp/tests' in list(list_valid_collection_paths(['/tmp/tests']))
    assert '/tmp/tests' in list(list_valid_collection_paths(['/tmp/tests', '/tmp/does/not/exist']))

# Generated at 2022-06-22 19:30:06.433972
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join
    import os

    # create temp dirs for test
    tmp_dir_a = mkdtemp()
    tmp_dir_b = mkdtemp()
    tmp_dir_c = mkdtemp()
    tmp_dir_d = mkdtemp()
    tmp_non_dir_a = mkdtemp()
    tmp_non_dir_b = mkdtemp()

    fp = os.open(tmp_non_dir_a, os.O_WRONLY | os.O_CREAT)
    os.close(fp)
    os.remove(tmp_non_dir_a)


# Generated at 2022-06-22 19:30:13.636770
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test with no specific filters
    col_paths = list(list_collection_dirs())
    assert len(col_paths) > 0

    # test with namespace filter
    namespace = 'ansible_namespace'
    col_paths = list(list_collection_dirs(coll_filter=namespace))
    assert len(col_paths) > 0
    for path in col_paths:
        assert namespace in path

    # test with namespace and collection filter
    collection = 'ansible_collection'
    col_paths = list(list_collection_dirs(coll_filter='.'.join([namespace, collection])))
    assert len(col_paths) > 0
    for path in col_paths:
        assert namespace in path
        assert collection in path