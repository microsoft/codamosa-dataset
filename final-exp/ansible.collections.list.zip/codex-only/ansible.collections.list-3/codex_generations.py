

# Generated at 2022-06-22 19:20:15.172744
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test case 1
    search_path = None
    valid_collection_paths = list_valid_collection_paths(search_paths=search_path, warn=False)
    assert isinstance(valid_collection_paths, object)
    assert len(valid_collection_paths) == 0
    # test case 2
    search_path = ['test/test']
    valid_collection_paths = list_valid_collection_paths(search_paths=search_path, warn=False)
    assert isinstance(valid_collection_paths, object)
    assert len(valid_collection_paths) == 1
    assert next(valid_collection_paths) == 'test/test'
    # test case 3
    search_path = ['does/not/exist', 'test/test']
    valid_collection_paths

# Generated at 2022-06-22 19:20:24.596317
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test list_valid_collection_paths() with empty search_paths list
    assert list(list_valid_collection_paths([])) == []

    # Test list_valid_collection_paths() with empty path in list
    assert list(list_valid_collection_paths([''])) == []

    # Test list_valid_collection_paths() with non-existing path in list
    assert list(list_valid_collection_paths(['/bogus/path'])) == []

    # Test list_valid_collection_paths() with valid path in list
    assert list(list_valid_collection_paths(['/etc/ansible'])) == ['/etc/ansible']

    # Test list_valid_collection_paths() with valid path in list and empty path

# Generated at 2022-06-22 19:20:33.147164
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    cfg_paths = ['/foo/bar', '/usr/lib/python2.7/site-packages']
    tmpdir = to_bytes(tempfile.mkdtemp())
    paths = cfg_paths[:]
    paths.append(tmpdir)

    results = list(list_valid_collection_paths(paths, warn=True))
    assert '/foo/bar' in results
    assert '/usr/lib/python2.7/site-packages' in results
    assert tmpdir in results
    shutil.rmtree(tmpdir)


# Generated at 2022-06-22 19:20:37.247306
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    try:
        AnsibleCollectionConfig._instance = None
    except AttributeError:
        pass

    # use the default configured collection paths, should find test_collection
    collection_dirs = list(list_collection_dirs())

    assert len(collection_dirs) == 1
    assert collection_dirs[0].endswith(u'test_collections/test_namespace/test_collection')

    # filter by namespace
    collection_dirs = list(list_collection_dirs(coll_filter='test_namespace'))

    assert len(collection_dirs) == 1
    assert collection_dirs[0].endswith(u'test_collections/test_namespace/test_collection')

    # filter by collection

# Generated at 2022-06-22 19:20:44.784056
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '/no/such/path',
        '/etc',
        'not/a/dir',
    ]

    results = list(list_valid_collection_paths(test_paths, warn=False))
    assert len(results) == 0 or results is None
    results = list(list_valid_collection_paths(test_paths, warn=True))
    assert len(results) == 0 or results is None

    test_paths = [
        './unit/modules/resources/collection_loader',
    ]

    results = list(list_valid_collection_paths(test_paths, warn=False))
    assert len(results) > 0 or results is None
    results = list(list_valid_collection_paths(test_paths, warn=True))

# Generated at 2022-06-22 19:20:54.344160
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import unittest
    import os

    class TestListCollectionsDirs(unittest.TestCase):

        def setUp(self):
            self.collection_root = os.path.expanduser('~/.ansible/collections/ansible_collections/')
            self.mock = os.makedirs(self.collection_root)
            self.mock_namespaces = {'testnamespace1', 'testnamespace2'}
            self.mock_collection_names = {'testcollection1', 'testcollection2'}
            for namespace in self.mock_namespaces:
                os.makedirs(os.path.join(self.collection_root, namespace))

# Generated at 2022-06-22 19:21:04.661810
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths function
    Make sure existing paths are returned, invalid paths are filtered out
    """
    valid_path = "/my/valid/path"
    invalid_path1 = "/my/invalid/path"
    invalid_path2 = "/my/other/invalid/path"
    search_paths = [valid_path, invalid_path1, invalid_path2]

    b_valid_path = to_bytes(valid_path)  # Need bytes type as we are testing os methods
    b_invalid_path1 = to_bytes(invalid_path1)
    b_invalid_path2 = to_bytes(invalid_path2)

    # Create mock os.path
    mock_os_path = MockOsPath()

# Generated at 2022-06-22 19:21:13.109587
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible import constants as C

    original_config = C.config.base_definitions

    # Test without any collection directory specified
    assert os.path.exists(C.config.base_definitions['collections_paths'][0]) is False

    # Test with collection directory specified
    C.config.base_definitions['collections_paths'] = ['tests/fixtures/collections']
    assert next(list_collection_dirs()) == b'tests/fixtures/collections/ansible_collections/testns/testcoll/'
    assert next(list_collection_dirs(['tests/fixtures/missing_dir'])) == b'tests/fixtures/collections/ansible_collections/testns/testcoll/'

# Generated at 2022-06-22 19:21:23.959826
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    b_coll_root = to_bytes(os.path.realpath(__file__).rsplit(os.path.sep, 3)[0])

    b_coll_dir = to_bytes(os.path.join(b_coll_root, to_bytes('test/integration/targets/collections')))
    search_paths = [b_coll_root, b_coll_dir, b_coll_dir + to_bytes('/foo')]

    b_coll_dirs = list(list_valid_collection_paths(search_paths, warn=False))

    assert len(b_coll_dirs) == 2
    assert b_coll_dirs[0] == b_coll_root
    assert b_coll_dirs[1] == b_coll_dir

# Generated at 2022-06-22 19:21:35.211268
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Check if the function for listing collections in a directory works
    '''

    # Check if the function raises a specific exception if an empty search path is passed as argument
    try:
        list_collection_dirs([])
    except AnsibleError:
        pass
    # Check if the function returns the expected list of collection paths
    search_path = [os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')),
                   os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'data'))]

# Generated at 2022-06-22 19:21:41.974387
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    valid_folder = os.path.join(temp_dir, 'collections')
    os.mkdir(valid_folder)
    invalid_folder = os.path.join(temp_dir, 'collections.txt')
    with open(invalid_folder, 'w') as fd:
        fd.write('blah')

    paths = list_valid_collection_paths([valid_folder, invalid_folder])
    valid_folders = [path for path in paths]
    assert len(valid_folders) == 1
    assert valid_folder in valid_folders

    shutil.rmtree(temp_dir)

# Generated at 2022-06-22 19:21:52.347755
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # use search paths containing only the test directory
    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_collections')
    b_test_path = to_bytes(test_path)
    coll_dirs = list(list_collection_dirs(search_paths=[test_path]))
    assert len(coll_dirs) == 2
    for coll_dir in coll_dirs:
        assert coll_dir.startswith(b_test_path)

    # use filter to return only the one collection
    coll_dirs = list(list_collection_dirs(search_paths=[test_path], coll_filter='one.first'))
    assert len(coll_dirs) == 1

# Generated at 2022-06-22 19:22:00.657784
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    test list_collection_dirs from this module using a filesystem fixture
    """

    def get_test_fixture_path(*args):
        """
        :return: path in filesystem fixture for this collection
        """
        return to_bytes(os.path.join('test', 'units', 'module_utils', 'ansible_test_collection', *args))

    from ansible_collections.ansible_test_collection.tests.unit.plugins.module_utils import ansible_test_collection

    # set up filesystem fixture in collection for unit testing
    fixture_path = get_test_fixture_path()
    path_list = ansible_test_collection.list_collection_dirs(search_paths=[fixture_path], coll_filter='ansible_test_collection.collection1')

    # test to make sure a single

# Generated at 2022-06-22 19:22:05.963712
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    collections = list(list_collection_dirs(search_paths, coll_filter=None))

    assert len(collections) != 0, 'There should be collections in the path'
    assert isinstance(collections, list) and isinstance(collections[0], bytes), 'Collections should be a list of str'

# Generated at 2022-06-22 19:22:06.906634
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass


# Generated at 2022-06-22 19:22:16.109112
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import os
    from ansible.module_utils._text import to_bytes

    # Setup
    tmpdir = tempfile.mkdtemp()
    dirs = [tmpdir + "/dir1", tmpdir + "/dir2"]
    for dir in dirs:
        os.mkdir(to_bytes(dir))

    # Test
    assert set(dirs) == set(list_valid_collection_paths(dirs))

    # Test warning
    assert set(dirs) == set(list_valid_collection_paths(dirs + ["test"], warn=True))

    # Teardown
    for dir in dirs:
        os.rmdir(to_bytes(dir))
    os.rmdir(to_bytes(tmpdir))

# Generated at 2022-06-22 19:22:20.812421
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    folders = list_collection_dirs()
    assert len(folders) > 0
    success = False
    for folder in folders:
        if folder.endswith('ansible_collections/ansible/ansible'):
            success = True
    assert success



# Generated at 2022-06-22 19:22:21.328400
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:22:26.363411
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import (
        _init_collections,
    )

    collections_paths = ('/tmp/does_not_exist', './test/collections/ansible_collections')

    # Make sure none of the paths exist
    for path in collections_paths:
        assert not os.path.exists(to_bytes(path, errors='surrogate_or_strict'))

    # Make paths with collections
    _init_collections(collections_paths)


# Generated at 2022-06-22 19:22:34.997401
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.removed import removed_module

    search_paths = [
        'unknown_path',
        "/usr/share/ansible/collections",
    ]

    if not removed_module('ansible.module_utils.six'):
        from ansible.module_utils import six
        from ansible.module_utils._text import to_native
        from ansible.module_utils.common.removed import removed_module
        to_bytes = six.binary_type

    # make a list of allowed strings, those that are valid and should not trigger a warning
    valid_search_paths = list(list_valid_collection_paths(search_paths, warn=False))
    # test to make sure the list is correct

# Generated at 2022-06-22 19:22:40.717368
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test for list_valid_collection_paths"""

    test_paths = ["/path/that/does/not/exist", "/path/to/a/file.txt", "invalidpath/"]

    search_paths = list(list_valid_collection_paths(search_paths=test_paths))

    assert len(search_paths) == 0

# Generated at 2022-06-22 19:22:43.725630
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert None == list_valid_collection_paths()

    assert ['test_path'] == list_valid_collection_paths(['test_path'])

# Generated at 2022-06-22 19:22:53.909439
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # make sure returned dirs are not just empty DirEntries
    collection_dirs = [coll_dir for coll_dir in list_collection_dirs(['/tmp/test'])]
    assert(all(isinstance(coll_dir, bytes) for coll_dir in collection_dirs))

    # make sure that an invalid search path is not used
    collection_dirs = [coll_dir for coll_dir in list_collection_dirs(['/tmp/invalid'])]
    assert(len(collection_dirs) == 0)

    # make sure a single filter is satisfied
    collection_dirs = [coll_dir for coll_dir in list_collection_dirs(['/tmp/test'], 'namespace.collection')]
    assert(len(collection_dirs) == 1)

    # make sure multiple filters are satisfied

# Generated at 2022-06-22 19:22:56.813777
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(['.']) == [b'./ansible_collections/ansible/ocl']

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-22 19:22:59.808350
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.collection_loader import list_collection_dirs

    for coll in list_collection_dirs():
        # print(coll)
        assert os.path.exists(coll)



# Generated at 2022-06-22 19:23:08.420973
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import ansible
    from ansible.config.manager import ConfigManager

    temp_directory = tempfile.mkdtemp()
    test_coll_path = os.path.join(temp_directory, "ansible_collections")

    cfg = ConfigManager()
    cfg.set_config({"collections_path": [test_coll_path]})

    # Test with a non existing path
    path = [os.path.join(temp_directory, "invalid_collections_path")]
    result = list(list_valid_collection_paths(path, warn=False))
    assert len(result) == 0, "Got invalid data: %s" % result

    # Create the path

# Generated at 2022-06-22 19:23:13.149597
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil

    from tempfile import mkdtemp
    from ansible.utils.collection_loader import list_collection_dirs, COLLECTIONS_PATHS_MAIN

    TEST_COLLECTIONS_PATH = mkdtemp()

    # create a dummy collection
    collection_dir = os.path.join(TEST_COLLECTIONS_PATH, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(collection_dir)
    assert os.path.isdir(collection_dir)

    COLLECTIONS_PATHS_MAIN.append(TEST_COLLECTIONS_PATH)

    # verify collection is found
    assert collection_dir in list_collection_dirs(search_paths=[TEST_COLLECTIONS_PATH])

    # cleanup
    shutil

# Generated at 2022-06-22 19:23:22.710510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ["/etc/foobar", "/foo/bar/", "/etc/ansible/collections", "/etc/ansible/foobar"]
    validate_paths = list_valid_collection_paths(search_paths)
    assert '/etc/ansible/collections' in validate_paths
    assert '/foo/bar/' in validate_paths
    assert '/etc/foobar' in validate_paths
    assert '/etc/ansible/foobar' in validate_paths
    assert '/etc/ansible/bar/' not in validate_paths
    assert '/foo/bar' not in validate_paths
    assert '/bar/foo' not in validate_paths

# Generated at 2022-06-22 19:23:23.611095
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-22 19:23:35.373701
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil
    import os

    # create a temp collections directory with a subdir "foo"
    temp_collection_dir = tempfile.mkdtemp(prefix='ansible_collections_')
    foo_collection_dir = os.path.join(temp_collection_dir, "foo")
    os.mkdir(foo_collection_dir)

    search_paths = [temp_collection_dir, foo_collection_dir, "/does/not/exist"]

    valid_paths = list_valid_collection_paths(search_paths)
    assert list(valid_paths) == search_paths
    assert isinstance(valid_paths, list)  # verify that a generator is returned

    # clean up
    shutil.rmtree(temp_collection_dir)

    # test missing paths


# Generated at 2022-06-22 19:23:42.095761
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

# Generated at 2022-06-22 19:23:51.583809
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Create temp collections path directory
    path = '/tmp/test_collections_dirs/ansible_collections/test/test_collections'
    os.makedirs(path)

    for coll in list_collection_dirs(search_paths=['/tmp/test_collections_dirs']):
        assert coll.endswith(path)

    # Cleanup
    shutil.rmtree('/tmp/test_collections_dirs')

    return

# Generated at 2022-06-22 19:24:04.295527
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    ''' tests for list_valid_collection_paths '''
    paths = list(list_valid_collection_paths(["/root", "/tmp", "/etc", "/doesntexist", "/usr/share/ansible/collections"]))
    assert len(paths) == 5
    assert paths[0] == "/root"
    assert paths[1] == "/tmp"
    assert paths[2] == "/etc"
    assert paths[4] == "/usr/share/ansible/collections"

    paths = list(list_valid_collection_paths(["/tmp", "/usr/share/ansible/collections", "/doesntexist", "/etc"]))
    assert len(paths) == 4
    assert paths[0] == "/tmp"
    assert paths[1] == "/usr/share/ansible/collections"


# Generated at 2022-06-22 19:24:15.355058
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths against a mock filesystem
    """

    class Fs:
        """
        Create a dict that behaves like a filesystem for testing
        """

        def __init__(self, module=None):
            self.module = module

# Generated at 2022-06-22 19:24:20.148301
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test for None
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)

    # test for []
    assert list(list_valid_collection_paths([])) == list(AnsibleCollectionConfig.collection_paths)

    # test for invalid collection path
    assert list(list_valid_collection_paths(['/invalid/collections/path', '/invalid/collections/path2'])) == []

    # test for valid collection path
    tmp_dir = "/tmp"
    assert list(list_valid_collection_paths([tmp_dir])) == [tmp_dir]

    # test for valid and invalid collection paths
    tmp_dir = "/tmp"

# Generated at 2022-06-22 19:24:27.160257
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    cur_paths = list_valid_collection_paths()

    # add some test paths
    test_paths = ['/tmp/collections', '/does/not/exist']
    all_paths = list_valid_collection_paths(search_paths=test_paths, warn=True)

    # check that we have not duplicated
    assert len(all_paths) == len(cur_paths) + len(test_paths) - 1
    assert len(set(all_paths)) == len(all_paths)

# Generated at 2022-06-22 19:24:36.353488
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with open('./test_data/test_collections.yaml', 'r') as f:
        test_colls = yaml.load(f, Loader=yaml.SafeLoader)
    assert len(list(list_collection_dirs(test_colls.get('search_paths', None)))) == 7
    assert len(list(list_collection_dirs(test_colls['search_paths'], 'fake_coll'))) == 1
    assert len(list(list_collection_dirs(test_colls['search_paths'], 'fake_coll.fake_subcoll'))) == 1


# Generated at 2022-06-22 19:24:45.141690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    fake_collections = os.path.join(os.path.dirname(__file__), 'fake_collections')
    expected_paths = set(os.path.join(fake_collections, x)
                         for x in ['ansible_collections/asdf/asdf',
                                   'ansible_collections/demo/demo',
                                   'ansible_collections/namespace/collection',
                                   'ansible_collections/plugin_type/plugin',
                                   'ansible_collections/other/collection/subdir',
                                   'ansible_collections/not_a_collection',  # should not match
                                   'ansible_collections/other/another_collection/subdir',  # should not match
                                   ])

# Generated at 2022-06-22 19:24:55.530467
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test collection search path logic
    :return:
    """
    search_paths = []

    # will be skipped as Ansible defaults
    path1 = '/usr/share/ansible/collections'
    search_paths.append(path1)
    path2 = '/etc/ansible/collections'
    search_paths.append(path2)

    # should be valid
    path3 = '/test/2'
    search_paths.append(path3)
    b_path3 = to_bytes(path3)
    os.makedirs(b_path3, 0o755)
    assert os.path.exists(b_path3)

    # should be skipped
    path4 = '/test2'
    search_paths.append(path4)
    b_path4 = to_

# Generated at 2022-06-22 19:25:03.085189
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    (tmpfd, tmpfile) = tempfile.mkstemp()
    os.close(tmpfd)


# Generated at 2022-06-22 19:25:12.326375
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.cli.collection_list import list_valid_collection_paths
    from ansible.config import ANSIBLE_COLLECTIONS_PATHS

    test_path = "/non/existing/path"
    test_path1 = ""
    test_path2 = "/"

    search_paths = [test_path, test_path1, test_path2]

    # check error path
    try:
        list_valid_collection_paths(search_paths)
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError should have been raised"

    # check default path
    assert list_valid_collection_paths() == ANSIBLE_COLLECTIONS_PATHS



# Generated at 2022-06-22 19:25:20.709592
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.cli.galaxy import _get_action_parser, GalaxyCLI
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    import tempfile

    tmp_path = tempfile.mkdtemp()
    tmp_coll_tmp_path = os.path.join(tmp_path, 'ansible_collections')

    galaxy = GalaxyCLI(args=[])
    galaxy._run_argv = []
    galaxy.parser = _get_action_parser()

    # we need to add a collection path so galaxy can find our test collections
    galaxy.options.collections_paths = tmp_path
    galaxy.all_collections = dict()


# Generated at 2022-06-22 19:25:21.291117
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass



# Generated at 2022-06-22 19:25:32.677943
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import __path__ as collection_path
    search_paths = [collection_path[0]]
    assert list_valid_collection_paths(search_paths) == search_paths

    # create a temp dir.
    import tempfile
    # https://docs.python.org/3/library/tempfile.html#tempfile.TemporaryDirectory
    with tempfile.TemporaryDirectory() as coll_dir:
        # below is a real collection path. This will be used to test the list_valid_collection_paths function.
        coll_dir_path = "/usr/share/ansible/collections/ansible_collections/test_ns/test_coll"
        coll_dir_namespace = "test_ns"
        coll_dir_collection = "test_coll"
        # print the temp dir

# Generated at 2022-06-22 19:25:44.036077
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # create a tempdir to store the collection dirs
    tempdir = tempfile.mkdtemp()
    # create a nested collection directory structure
    acdir = os.path.join(tempdir, 'ansible_collections')
    os.mkdir(acdir)
    # first collection
    os.mkdir(os.path.join(acdir, 'first_coll'))
    # second collection
    os.mkdir(os.path.join(acdir, 'second_coll'))
    # third collection
    os.mkdir(os.path.join(acdir, 'third_coll'))
    # create a duplicate of ansible_collections just for this test
    shutil.copytree(acdir, acdir + '_copy')

    # Test that all collections are returned if

# Generated at 2022-06-22 19:25:45.435280
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), list)

# Generated at 2022-06-22 19:25:52.936959
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(['/tmp/foo'], None))

    assert coll_dirs is None

    coll_dirs = list(list_collection_dirs(['/tmp/foo'], '/tmp/foo'))

    assert coll_dirs is None

    coll_dirs = list(list_collection_dirs(['/tmp/foo'], 'foo.bar'))

    assert coll_dirs is None

# Generated at 2022-06-22 19:25:59.032895
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['./test/units/utils/ansible_collections',
                    './ansible_collections']

    list_dirs = []
    for dir in list_collection_dirs(search_paths):
        list_dirs.append(dir)
    assert len(list_dirs) == 1
    assert list_dirs[0] == b'./test/units/utils/ansible_collections/f5networks/f5_modules'

# Generated at 2022-06-22 19:26:06.913054
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    my_path = os.path.dirname(os.path.abspath(__file__))
    good_dir = [my_path, os.path.dirname(my_path)]
    bad_dir = [os.path.join(my_path, 'not_existing_dir')]

    good_dir.extend(bad_dir)

    count = 0
    for p in list_valid_collection_paths(good_dir):
        count += 1
        assert p == my_path

    assert 2 == count

# Generated at 2022-06-22 19:26:17.697146
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # The path type is a string, but we need to convert to bytes for os.exists
    temp_path = os.path.realpath('./test/utils/ansible_runner/tests')
    b_temp = to_bytes(temp_path)

    # Test that a temp path is valid
    assert os.path.exists(b_temp) is True
    assert os.path.isdir(b_temp) is True

    try:
        # Test with a bad path
        results = list_valid_collection_paths(['/bad/path'])
        for result in results:
            print(result)
        assert False
    except ValueError:
        assert True

    # Test with a valid path
    result_list = []
    results = list_valid_collection_paths([temp_path])

# Generated at 2022-06-22 19:26:27.727941
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_root = '/tmp/ansible_collections'
    collection_paths = [coll_root]
    # test ns1.coll1
    test_coll_dirs = list_collection_dirs(collection_paths, 'ns1.coll1')
    assert test_coll_dirs
    for test_coll_dir in test_coll_dirs:
        assert test_coll_dir.endswith('/ns1/coll1')
        assert os.path.exists(test_coll_dir)
        assert os.path.exists(test_coll_dir+'/')
        # test ns2.coll2
        test_coll_dirs = list_collection_dirs(collection_paths, 'ns2.coll2')
        assert test_coll_dirs
        test_coll_dirs = list_

# Generated at 2022-06-22 19:26:36.700379
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list_collection_dirs(['/tmp/test_path', '/bad/path'], 'stdlib.test.coll1')

    assert b'/tmp/test_path/ansible_collections/stdlib/test_coll1' in coll_dirs

    # test all
    coll_dirs = list_collection_dirs(['/tmp/test_path', '/bad/path'])
    assert b'/tmp/test_path/ansible_collections/stdlib/test_coll1' in coll_dirs
    assert b'/tmp/test_path/ansible_collections/stdlib/test_coll2' in coll_dirs
    assert b'/tmp/test_path/ansible_collections/stdlib/test_coll3' in coll_dirs

# Generated at 2022-06-22 19:26:46.593713
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible import context
    from ansible.cli import CLI
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible_galaxy.playbook_api._playbook_api_base import PlaybookAPIBase

    colls = list(list_collection_dirs(search_paths=['fixtures/collections']))
    assert len(colls) == 2

    colls = list(list_collection_dirs(search_paths=['fixtures/collections'], coll_filter='geerlingguy.redhat'))
    assert len(colls) == 1

    colls = list(list_collection_dirs(search_paths=['fixtures/collections'], coll_filter='geerlingguy.redhat.other'))
    assert len(colls) == 1

    coll

# Generated at 2022-06-22 19:26:56.329166
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # make directory and file objects to test
    tempdir = tempfile.mkdtemp()
    templist = []
    templist.append(tempdir)

    # create file that exists and is not a directory
    tempfile_path = os.path.join(tempdir, 'test2')
    tempfile_obj = open(tempfile_path, 'w')
    tempfile_obj.close()
    templist.append(tempfile_path)

    # create directory that does not exist
    tempdir_path = os.path.join(tempdir, 'test')
    templist.append(tempdir_path)

    # return only valid directories
    valid = list(list_valid_collection_paths(templist))
    assert len(valid) == 1

    # remove test directory
   

# Generated at 2022-06-22 19:27:00.562133
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup
    collection_dir = 'ansible_namespace.collection'
    path = '/path/to/' + collection_dir

    # Test
    assert list(list_collection_dirs([path])) == [path]


# Generated at 2022-06-22 19:27:05.381285
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ["/tmp/foo/bar", "/tmp/12345", "/tmp/baz_bak"]
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 1
    assert valid_paths[0] == "/tmp/baz_bak"

# Generated at 2022-06-22 19:27:12.429114
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_path = os.path.join(os.path.dirname(__file__), '..', 'test', 'units', 'test_collections')

    def paths():
        return [
            os.path.join(test_path, 'collection_a', 'foo'),
            os.path.join(test_path, 'collection_b', 'bar'),
        ]

    assert set(list_collection_dirs(search_paths=paths())) == set(paths())

    assert set(list_collection_dirs(search_paths=paths(), coll_filter='collection_a.foo')) == set(paths()[0:1])

    assert set(list_collection_dirs(search_paths=paths(), coll_filter='collection_a')) == set(paths()[0:1])



# Generated at 2022-06-22 19:27:22.189078
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.module_utils._text import to_native

    # test default search_paths
    assert list(list_valid_collection_paths(warn=False)) == AnsibleCollectionConfig.collection_paths, \
        "List of collection paths does not match AnsibleCollectionConfig.collection_paths"

    # test invalid search_paths
    paths = [None, 1, b'foo', {'foo': 'bar'}]
    for path in paths:
        assert all(p is None for p in list_valid_collection_paths([path])), \
            "Invalid search_path returned"

    # test with bad search_paths
    with tempfile.TemporaryDirectory() as tmpdir:
        dir1 = os.path.join(tmpdir, 'dir1')
        dir2 = os.path

# Generated at 2022-06-22 19:27:32.428571
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import sys
    # Create a temporary directory and change into that directory.
    tmpdir = tempfile.mkdtemp()
    oldpath = os.getcwd()
    os.chdir(tmpdir)

    # Create and write a simple playbook.
    playbook_name = 'playbook.yml'
    with open(playbook_name, 'w+') as f:
        f.write("""---
- hosts: localhost
  connection: local
  tasks:
    - name: tasks
      assert:
        that:
          - 1 == 1
""")

    # Create a simple collection with one plugin.
    namespace = 'mynamespace'
    collection = 'mycollection'
    collection_path = os.path.join(namespace, collection)

# Generated at 2022-06-22 19:27:38.032270
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Namespace not present, no collections
    result = list(list_collection_dirs(coll_filter='ansible_namespace_not_present'))
    assert result == []

    # Namespace present but no collections found
    result = list(list_collection_dirs(coll_filter='ansible_namespace_present'))
    assert result == []

    # Collection "ansible_collection_not_present" not found
    result = list(list_collection_dirs(coll_filter='ansible.ansible_collection_not_present'))
    assert result == []

    # Collection "ansible_collection_present" found
    result = list(list_collection_dirs(coll_filter='ansible.ansible_collection_present'))

# Generated at 2022-06-22 19:27:48.771139
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
  import os
  import tempfile
  tmp = tempfile.mkdtemp()
  tmp2 = tempfile.mkdtemp()
  tmp3 = tempfile.mkdtemp()
  tmp4 = tempfile.mkdtemp(dir=tmp)
  tmp5 = tempfile.mkdtemp(dir=tmp)
  tmp6 = tempfile.mkdtemp(dir=tmp)
  tmp7 = tempfile.mkdtemp(dir=tmp)
  tmp8 = tempfile.mkdtemp(dir=tmp)
  tmp9 = tempfile.mkdtemp()


# Generated at 2022-06-22 19:27:55.533548
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            search_paths=dict(type='list'),
            coll_filter=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    result = list_collection_dirs(module.params['search_paths'], module.params['coll_filter'])

    module.exit_json(changed=False, collection_dirs=list(result))

# Generated at 2022-06-22 19:28:02.810572
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    try:
        test_colls = list_collection_dirs(search_paths=['./tests/units/framework/example_projects/sample_collections'])
        test_collections = {
            'namespace1': ['collection1'],
            'namespace2': ['collection1', 'collection2'],
            'namespace3': ['collection1']
        }

        assert len(list(test_colls)) == len(test_collections.keys()) * sum(len(v) for v in test_collections.values())

        for coll in test_colls:
            (root, namespace, collection) = os.path.split(coll)
            assert collection in test_collections[namespace]

    except Exception as e:
        print(e)

# Generated at 2022-06-22 19:28:08.952176
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test default search path
    coll_dirs = list(list_collection_dirs())

    assert len(coll_dirs) > 0

    # Test specific collection search
    coll_dirs = list(list_collection_dirs(coll_filter='ansible_collections.ns0.c0'))

    assert len(coll_dirs) == 1

    coll_dirs = list(list_collection_dirs(coll_filter='ansible_collections.ns0.c0.c1'))
    assert len(coll_dirs) == 1

# Generated at 2022-06-22 19:28:16.177850
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.test.utils import TestCollectionLoader
    tcl = TestCollectionLoader()
    path1 = tcl.get_data_loader_path('test_collections/ns/coll1')
    path2 = tcl.get_data_loader_path('test_collections/ns/coll2')
    path3 = tcl.get_data_loader_path('test_collections/ns/coll3')
    path4 = tcl.get_data_loader_path('test_collections/ns/coll3/plugins/')
    search_paths = [path1, path2, path3, path4, '/incorrect_path/', '/incorrect_path2']

    result = list(list_valid_collection_paths(search_paths=search_paths, warn=False))

# Generated at 2022-06-22 19:28:23.121151
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six import StringIO

    stdout = StringIO()
    path = list_collection_dirs()
    for collection in path:
        print("{}".format(collection.decode()), file=stdout)

    assert stdout.getvalue() != ''


# Generated at 2022-06-22 19:28:32.367331
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    import os

    coll_root_dir = os.getcwd()
    coll_paths = [coll_root_dir]
    coll_ns = 'test'
    coll_name = 'ansible_test_collection'
    coll_nsfull = coll_ns + '.' + coll_name
    coll_dir = os.path.join(coll_root_dir, 'ansible_collections', coll_ns, coll_name)
    coll_dirs = list(list_collection_dirs(search_paths=coll_paths, coll_filter=coll_nsfull))
    assert coll_dirs[0] == coll_dir

# Generated at 2022-06-22 19:28:40.568371
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert (list_collection_dirs(coll_filter="invalid")) == []

    assert (list_collection_dirs(coll_filter="invalid.invalid")) == []

    assert (list_collection_dirs(coll_filter="invalid.copy")) == []

    assert (list_collection_dirs(coll_filter="ansible.builtin")) == []

    # new collection with no modules
    assert list_collection_dirs(coll_filter="ansible_collections.ansible.new") == []

    assert list_collection_dirs(coll_filter="ansible_collections.ansible.builtin")
    assert list_collection_dirs(coll_filter="ansible_collections.ansible.builtin.argspec")

# Generated at 2022-06-22 19:28:51.923531
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import file_common_config
    from ansible.module_utils.common.collections import list_collection_dirs

    data = None
    result = False

    original = file_common_config.get_config_value('collection_paths')

    file_common_config.set_config_value('collection_paths', [os.path.join(os.path.dirname(__file__), 'files', 'collections')])

    try:
        mylist = []
        for x in list_collection_dirs():
            mylist.append(x)
        mylist.sort()

        half = len(mylist) // 2

        data = (mylist[0:half], mylist[half:])
    finally:
        file_common_config.set_config_

# Generated at 2022-06-22 19:29:00.033985
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import textwrap
    import tempfile
    import shutil
    import os


# Generated at 2022-06-22 19:29:06.097551
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    failed = False
    test_paths = ['no/such/path', 'no/such/path/still/']
    for path in list_valid_collection_paths(test_paths):
        if path in test_paths:
            failed = True
            break
    assert not failed


# Generated at 2022-06-22 19:29:20.195308
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test result against a collection directory
    """
    expected = ['/etc/ansible/ansible_collections/ns1/coll1', '/etc/ansible/ansible_collections/ns2/coll2']

    result = list_collection_dirs(search_paths=['/etc/ansible'])
    assert set(result) == set(expected)

    result = list_collection_dirs(coll_filter='ns1.coll1')
    assert set(result) == set(expected[0:1])

    result = list_collection_dirs(coll_filter='ns1')
    assert set(result) == set(expected[0:1])

    result = list_collection_dirs(coll_filter='ns2')
    assert set(result) == set(expected[1:])

    result = list

# Generated at 2022-06-22 19:29:26.289511
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.path import unfrackpath

    coll_root = unfrackpath('/Users/username/git/ansible')
    dirs = list(list_collection_dirs([coll_root]))

    assert dirs is not None

# Generated at 2022-06-22 19:29:33.129732
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    bad_paths = ['/foo/bar', '/tmp/doesnotexist']
    # first check paths with bad paths
    expected = ['test/integration/data/collection_path']
    expected.extend(AnsibleCollectionConfig.collection_paths)

    # create new temp dir as path
    test_path = tempfile.mkdtemp()
    expected.append(test_path)
    bad_paths.append(test_path)

    # test fuction
    actual = list(list_valid_collection_paths(bad_paths, warn=True))
    assert actual == expected


# Generated at 2022-06-22 19:29:40.705254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    path = tempfile.mkdtemp()

    ansible_collections = 'ansible_collections'
    namespace_dir = 'namespace1'
    collection_dir = 'collection1'
    test_dir = 'test'
    test_plugin_dir = 'plugins'
    test_action_dir = 'actions'
    test_module_dir = 'modules'
    test_filter_dir = 'filter_plugins'
    test_doc_dir = 'docs'
    contrib_dir = 'contrib'
    test_file = 'test.yml'

    # create ansible_collections top level directory
    coll_path = os.path.join(path, ansible_collections)
    os.mkdir(coll_path)

    # add namespace directory


# Generated at 2022-06-22 19:29:42.329064
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter='test')

# Generated at 2022-06-22 19:29:53.403139
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    good_paths = [
        os.path.join(os.path.expanduser("~"), "foo", "bar", "baz"),
        os.path.join(os.path.expanduser("~"), "foo", "bar", "baz", "ansible_collections"),
        "foo/bar/baz",
        "foo/bar/baz/ansible_collections",
    ]

    # try/except for python 2, to_bytes() on paths with unicode

# Generated at 2022-06-22 19:29:55.962187
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible_collections.testns.subns.testcoll.plugins.modules import test_coll_module

    assert test_coll_module

# Generated at 2022-06-22 19:30:04.204941
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # create temp test directory
    tmpdir = tempfile.mkdtemp()
    b_tmpdir = to_bytes(tmpdir)

    # create temp file
    temp = tempfile.NamedTemporaryFile(delete=False)
    tmpfile = to_bytes(temp.name)
    temp.close()

    # create temp subdirectory
    temp_subdir = os.path.join(tmpdir, 'subdir')
    os.makedirs(temp_subdir)

    from ansible.collections import list_valid_collection_paths

    # pass in test temp file
    search_paths = [tmpfile]
    for path in list_valid_collection_paths(search_paths=search_paths):
        assert path is None

    # pass in test temp subdir
    search_path