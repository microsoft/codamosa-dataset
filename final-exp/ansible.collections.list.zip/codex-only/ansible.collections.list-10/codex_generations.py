

# Generated at 2022-06-22 19:20:16.494534
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os
    import tempfile

    fake_coll_root = tempfile.mkdtemp()

    fk_path = os.path.join(fake_coll_root, 'ansible_collection')
    os.makedirs(fk_path)

    fk_namespace_dir = os.path.join(fk_path, 'some_namespace')
    os.makedirs(fk_namespace_dir)

    fk_coll_dir = os.path.join(fk_namespace_dir, 'some_collection')
    os.makedirs(fk_coll_dir)

    fk_other_coll_dir = os.path.join(fk_namespace_dir, 'another_collection')
    os.makedirs(fk_other_coll_dir)


# Generated at 2022-06-22 19:20:25.186952
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible_collections.ansible.community.plugins.module_utils.test.test_collection_loader import (
        DummyAnsibleCollectionConfig,
        DummyAnsiblePath,
        DummyFileSystemLoader
    )

    # make a Fake CollectionConfig
    ac = DummyAnsibleCollectionConfig(collection_paths=['/tmp/nonexistent', '/tmp/notadir'])
    ac.FILE_SYSTEM_LOADER = DummyFileSystemLoader()

    # make a few fake paths
    ap = DummyAnsiblePath()

# Generated at 2022-06-22 19:20:33.758711
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        './test/sanity/utils/fixtures/collections',
    ]
    dir_paths = list(list_collection_dirs(search_paths=search_paths))
    assert len(dir_paths) == 2
    assert dir_paths[1].endswith("test/sanity/utils/fixtures/collections/ansible_collections/neillturner/apache")
    assert dir_paths[0].endswith("test/sanity/utils/fixtures/collections/ansible_collections/neillturner/nginx")

# Generated at 2022-06-22 19:20:41.264036
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        list_valid_collection_paths(['/dev/null', '/'])
        assert False, "Expected an AnsibleError"
    except AnsibleError as e:
        assert e.message == "The configured collection path /dev/null does not exist."

    try:
        list_valid_collection_paths(['/dev'])
        assert False, "Expected an AnsibleError"
    except AnsibleError as e:
        assert e.message == "The configured collection path /dev, exists, but it is not a directory."

    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-22 19:20:47.306587
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    tf = tempfile.mkdtemp()

    os.mkdir(os.path.join(tf, 'ansible_collections'))
    os.mkdir(os.path.join(tf, 'ansible_collections', 'ns1'))
    os.mkdir(os.path.join(tf, 'ansible_collections', 'ns1', 'coll1'))
    os.mkdir(os.path.join(tf, 'ansible_collections', 'ns1', 'coll1', 'plugins'))
    os.mkdir(os.path.join(tf, 'ansible_collections', 'ns1', 'coll1', 'plugins', 'lookup'))

# Generated at 2022-06-22 19:20:55.359213
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    import os

    # Ensure the default paths are detected
    search_paths = list(list_valid_collection_paths([], warn=False))
    assert len(search_paths) > 0
    assert os.path.exists(search_paths[0])
    assert os.path.isdir(search_paths[0])

    # Invalid path
    paths = list(list_valid_collection_paths(["/this/path/does/not/exist"], warn=False))
    assert len(paths) == 0

    # Valid path
    home = os.path.expanduser("~")
    paths = list(list_valid_collection_paths([home], warn=False))
    assert len(paths) == 1
   

# Generated at 2022-06-22 19:21:04.947138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile


# Generated at 2022-06-22 19:21:05.443871
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-22 19:21:13.544230
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    search_paths = [tempfile.mkdtemp(prefix='ansible_collections_test_tmp_')]

    def create_subpath(subpath):
        if subpath:
            subpath = os.path.join(*subpath)
        return os.path.join(search_paths[0], subpath or '')

    os.mkdir(create_subpath('collections'))
    os.mkdir(create_subpath(('collections', 'myns')))
    os.mkdir(create_subpath('collection_name'))
    os.mkdir(create_subpath('collection_name2'))

# Generated at 2022-06-22 19:21:20.343208
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(["one", "two", "three", "four", "five"]))) == 5
    assert len(list(list_valid_collection_paths(["one", "two", "three", "four", "five"], warn=True))) == 5
    assert len(list(list_valid_collection_paths(None, warn=True))) > 5


# Generated at 2022-06-22 19:21:31.831756
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    base_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_list_collection_dirs")
    coll_path = os.path.join(base_path, "ansible_collections")
    paths = (coll_path, base_path)
    for cpath in list_collection_dirs(paths):
        assert cpath == os.path.join(coll_path, "test_ns", "test_coll")

    coll_path = os.path.join(base_path, "ansible_collections")
    paths = (coll_path,)
    for cpath in list_collection_dirs(paths):
        assert cpath == os.path.join(coll_path, "test_ns", "test_coll")

    coll_path = os

# Generated at 2022-06-22 19:21:40.678861
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for invalid paths
    invalid_paths = ['/no/such/path', '/no/such/path2', '/no/such/path3']

    valid_paths = list([p for p in list_valid_collection_paths(invalid_paths)])

    assert len(valid_paths) == 0, "list_valid_collection_paths = %r != %r" % (valid_paths, [])

    # Test for valid paths with invalid in the middle
    invalid_paths = ['', '/no/such/path2', '/no/such/path3', '__init__.py']

    valid_paths = list([p for p in list_valid_collection_paths(invalid_paths, warn=True)])


# Generated at 2022-06-22 19:21:43.837325
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs())

    # Verify that the collections returned were all valid
    for coll in coll_dirs:
        assert is_collection_path(coll)

# Generated at 2022-06-22 19:21:49.009773
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Load a valid path and a non existing path
    test_paths = ['/tmp/some_directory', 'non_existing']
    # Filter out the invalid path
    result = list(list_valid_collection_paths(test_paths))

    # Expect only the existing path
    assert result == ['/tmp/some_directory']

# Generated at 2022-06-22 19:21:55.142127
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # verify default list
    search_paths = list(list_valid_collection_paths())
    assert len(search_paths) == 1
    assert search_paths[0] == '~/ansible/collections'

    # verify that non existent path is not in list
    search_paths = list(list_valid_collection_paths(['/doesnotexist']))
    assert len(search_paths) == 0

# Generated at 2022-06-22 19:22:05.319528
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    #test when search_paths is None
    assert list(list_valid_collection_paths(None)) == list(list_valid_collection_paths(None, False))

    search_paths = None
    assert list(list_valid_collection_paths(search_paths)) == list(list_valid_collection_paths(search_paths, False))

    search_paths = []
    assert list(list_valid_collection_paths(search_paths)) == list(list_valid_collection_paths(search_paths, False))

    search_paths = ['/tmp/test_collections_path']
    assert ''.join(list_valid_collection_paths(search_paths)) == ''.join(list_valid_collection_paths(search_paths, False))


# Unit test

# Generated at 2022-06-22 19:22:11.222842
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    list_ = ['/a/b/c', '/d/e/f', 'none_exist']

    valid_paths = list(list_valid_collection_paths(search_paths=list_))

    assert len(valid_paths) == 2
    assert '/a/b/c' in valid_paths
    assert '/d/e/f' in valid_paths



# Generated at 2022-06-22 19:22:14.115126
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test empty list
    assert list(list_valid_collection_paths()) == []
    # Test invalid path, should be filtered
    assert list(list_valid_collection_paths(['invalid_path'])) == []



# Generated at 2022-06-22 19:22:20.100413
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    search_path = [tempfile.mkdtemp()]

    coll_root = os.path.join(search_path[0], 'ansible_collections')
    os.makedirs(coll_root)

    # set up test data
    colls = {'namespace1': ['collection1', 'collection2'],
             'namespace2': ['collection1', 'collection2']}

    for ns, mycolls in colls.items():
        ns_root = os.path.join(coll_root, ns)
        os.makedirs(ns_root)

        for coll in mycolls:
            coll_root = os.path.join(ns_root, coll)
            os.makedirs(coll_root)


# Generated at 2022-06-22 19:22:21.323403
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(warn=False)) == []

# Generated at 2022-06-22 19:22:26.037835
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_search_paths = [
        './test_ansible_collections/namespace1.collection1/',
        './test_ansible_collections/namespace2.collection2/',
        './test_ansible_collections/namespace3.collection3',
        './test_ansible_collections/namespace4.collection4/LOCK'
    ]

    found_paths = list(list_valid_collection_paths(test_search_paths, True))

    assert len(found_paths) == 1
    assert os.path.basename(found_paths[0]) == 'namespace1.collection1'
    assert os.path.isdir(found_paths[0])



# Generated at 2022-06-22 19:22:34.859141
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import json

    # a trivial collection we'll "install"
    fake_collection_metadata = json.dumps({
        "namespace": "not_really",
        "name": "trivial",
    })

    temp_collection = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_collection, 'not_really', 'trivial'))

    # write a fake collection
    with open(os.path.join(temp_collection, 'not_really', 'trivial', 'galaxy.yml'), 'w') as f:
        f.write(fake_collection_metadata)

    # This is a valid collection directory, but it has no collection in it

# Generated at 2022-06-22 19:22:39.372021
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    nstest = 'testns'
    coltest1 = 'testcoll1'
    coltest2 = 'testcol2'
    testpath = os.path.join(tempfile.mkdtemp(), 'ansible_collections', nstest, coltest1)
    os.makedirs(testpath)
    testpath = os.path.join(tempfile.mkdtemp(), 'ansible_collections', nstest, coltest2)
    os.makedirs(testpath)
    testpath = os.path.join(tempfile.mkdtemp(), 'nonsense')
    os.makedirs(testpath)
    paths = [tempfile.mkdtemp(), tempfile.mkdtemp()]

# Generated at 2022-06-22 19:22:48.224760
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # default config, no path
    search_paths = []
    assert len(list(list_valid_collection_paths(search_paths))) > 0

    # default config, missing path
    search_paths = ['/imaginary/path']
    assert len(list(list_valid_collection_paths(search_paths))) > 0

    # default config, real path
    search_paths = [os.path.dirname(__file__)]
    assert len(list(list_valid_collection_paths(search_paths))) > 0

    # default config, existing and not existing paths
    search_paths = [os.path.dirname(__file__), '/imaginary/path']
    assert len(list(list_valid_collection_paths(search_paths))) > 0

    # default config, file

# Generated at 2022-06-22 19:22:56.954101
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    fake_collections_paths = ["collections", "/etc/ansible/collections"]
    fake_collections_filter = None

    result = list(list_collection_dirs(fake_collections_paths, fake_collections_filter))
    assert len(result) > 0

    fake_collections_filter = "my.collection"
    result = list(list_collection_dirs(fake_collections_paths, fake_collections_filter))

    if result is None:
        assert False, "Collection my.collection should exist."

    result = list(list_collection_dirs(fake_collections_paths, "this.does.not.exist"))
    assert len(result) == 0

# Generated at 2022-06-22 19:23:06.418426
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_paths = [
        '/tmp/collections',
        '/tmp/ansible_collections',
        '/tmp/ansible_collections/namespace1',
    ]

    for path in collection_paths:
        if not os.path.isdir(path):
            os.makedirs(path)

    collection_paths.append('/tmp/ansible_collections/namespace1/collection1')
    collection_paths.append('/tmp/ansible_collections/namespace1/collection2')
    collection_paths.append('/tmp/ansible_collections/namespace1/collection3')

    output = list(list_collection_dirs(search_paths=['/tmp'], coll_filter='namespace1.collection1'))


# Generated at 2022-06-22 19:23:16.597647
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # this dir should not be in default path
    tempdir = tempfile.mkdtemp()

    # these dirs should be in default path
    confdir = os.path.join(tempdir, 'ansible.cfg')
    try:
        # create a fake config dir
        os.makedirs(confdir)
    except Exception:
        pass

    with open(os.path.join(confdir, 'ansible.cfg'), "w") as f:
        f.write("[defaults]\ncollections_paths = %s\n" % tempdir)

    pathlist = list_valid_collection_paths()
    assert tempdir in pathlist

    # because this dir is not a collection path, it should be filtered out by function

# Generated at 2022-06-22 19:23:20.357061
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/a/b/c', '/a/b/c/d', '/other/b/c/d']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=False))

    assert len(valid_paths) == 1



# Generated at 2022-06-22 19:23:33.419314
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['test/unit/module_utils/collection_loader/test_fixtures/custom_path']
    coll_filter = None
    returned_collections = list(list_collection_dirs(search_paths, coll_filter))

    assert len(returned_collections) == 2
    assert returned_collections[0].endswith('test/unit/module_utils/collection_loader/test_fixtures/custom_path/ansible_collections/test_namespace_1/test_collection_1')
    assert returned_collections[1].endswith('test/unit/module_utils/collection_loader/test_fixtures/custom_path/ansible_collections/test_namespace_2/test_collection_2')


# Generated at 2022-06-22 19:23:43.787213
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import platform
    import shutil
    import tempfile
    from ansible.utils.collection_loader import list_collection_dirs

    # helper function
    def mkdirp(path):
        os.makedirs(path, mode=0o755, exist_ok=True)
        return path

    # helper function
    def mkdir(path):
        os.mkdir(path, mode=0o755)
        return path

    tempdir = mkdirp(os.path.join(tempfile.gettempdir(), 'ansible_collections'))
    collection_dirs = []

    if platform.system() == 'Windows':
        # create a root collection dir
        collection_dir = mkdir(os.path.join(tempdir, 'testcoll'))
        collection_dirs.append(collection_dir)

        #

# Generated at 2022-06-22 19:23:54.199399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # Create a temp dir and file, use the file as a search_path
    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.mkstemp(dir=tmpdir)
    tmp_search_path = [tmpdir, tmpfile[1]]

    # Create a temp dir, use it as a valid search_path
    tmpdir2 = tempfile.mkdtemp()
    tmp_search_path.append(tmpdir2)

    # Create a temp dir and use it as a valid search_path
    tmpdir3 = tempfile.mkdtemp()
    tmp_search_path.append(tmpdir3)

    # Create a temp dir, one dir deep, and use it as a valid search_path
    tmpdir4 = tempfile.mkdtemp()
    tmp_search_

# Generated at 2022-06-22 19:24:04.927117
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    tmpdir = tempfile.mkdtemp()
    path1 = 'test_list_valid_collection_paths'
    path2 = '/does/not/exist'
    path3 = '/etc/passwd'

    list_paths = ['', None, 'foo', [1,2,3], [], [path1, path2, path3], [path1, path2, path3, tmpdir]]
    search_paths = []

    with AnsibleCollectionConfig.temporary_config(collection_paths=[tmpdir]):
        for paths in list_paths:
            if isinstance(paths, list):
                search_paths = paths
            else:
                search_paths = [paths]

            result = list(list_valid_collection_paths(search_paths))

# Generated at 2022-06-22 19:24:11.159796
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        '../tests/data/collections/namespace1/collection1/',
        '../tests/data/collections/namespace1/collection2/',
        '../tests/data/collections/namespace2/collection3/',
        '../tests/data/collections/',
    ]

    paths = list_valid_collection_paths(search_paths)
    assert len(list(paths)) == 5



# Generated at 2022-06-22 19:24:15.673648
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test to list out valid collection paths"""

    valid_paths = ['.',
                   '/var/tmp',
                   '/foo/bar',
                   '/tmp/doesnotexist',
                   '/foo/bar/doesnotexist',
                   '/tmp/doesnotexist/doesnotexist'
                   ]

    expected_paths = valid_paths[0:2]

    assert list(list_valid_collection_paths(valid_paths)) == expected_paths


# Generated at 2022-06-22 19:24:21.756609
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/non_existing_path', '/usr/share/ansible/collections'])) == ['/usr/share/ansible/collections']
    assert list(list_valid_collection_paths()) == [
        '/etc/ansible/collections',
        '/usr/share/ansible/collections',
        ]


# Generated at 2022-06-22 19:24:31.121806
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_bytes
    import os

    test_colls = [
        '.'.join([ns, coll]) for ns, coll in [
            ('myns1', 'mycoll1'),
            ('myns2', 'mycoll2'),
            ('myns3', 'mycoll3'),
        ]
    ]

    tmp_root = '/tmp/ansible_collections_test_root'


# Generated at 2022-06-22 19:24:42.542724
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # On some systems, user's home directory may not be defined (e.g. Container Linux)
    # This test is not reliable on those systems
    if os.path.exists(to_bytes("~")):
        # Make sure we expand $HOME
        search_paths = ["~/.ansible/collections"]
        expanded_search_paths = list_valid_collection_paths(search_paths=search_paths)
        assert expanded_search_paths == [os.path.join(os.environ.get("HOME"), ".ansible", "collections")]
        assert list_valid_collection_paths() == expanded_search_paths

    # Make sure we expand $FOOBAR into a warning about not existing
    search_paths = ["$FOOBAR/ansible_collections"]
    expanded_search_

# Generated at 2022-06-22 19:24:54.776524
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Make list_collection_dirs a non-generator function
    list_collection_dirs_no_generator = lambda *args, **kwargs: list(list_collection_dirs(*args, **kwargs))

    # The fixture collections filesystem dir structure is:
    # collections/
    #  |
    #  |---acmesoftware/
    #  |     |
    #  |     |---ansible_collections/
    #  |           |
    #  |           |---one/
    #  |           |     |
    #  |           |     |---plugins/
    #  |           |     | |
    #  |           |     | |---collection_artifact.py
    #  |           |     |
    #  |           |     |---tests/
    #  |           |          

# Generated at 2022-06-22 19:25:02.741905
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test that multiple search paths are handled
    val = sorted(list_valid_collection_paths(search_paths=[
        'not_exists',  # Does not exist
        'not_a_dir',  # Exists but not a directory
        'ansible_collections',  # Default path, exists, directory
        'ansible_collections/binary/binary_default',  # Is a collection lookup
    ]))

    assert val == sorted([
        'ansible_collections',
        'ansible_collections/binary/binary_default'
    ])

    # Test that default configuration search paths are picked up
    try:
        import ssl
    except ImportError:
        ssl = None

    if ssl:
        val = sorted(list_valid_collection_paths())


# Generated at 2022-06-22 19:25:10.275409
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = os.path.join(os.path.dirname(__file__), '..', '..')
    coll_paths = list(list_collection_dirs(search_paths=[coll_path]))
    assert len(coll_paths) > 0
    for coll in coll_paths:
        assert coll.endswith('ansible_collections')
        ns = os.path.basename(os.path.dirname(coll))
        assert ns in ['bit9', 'ansible', 'community']



# Generated at 2022-06-22 19:25:21.137085
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths function
    :return:
    """

    from ansible.plugins.loader import find_collection_paths
    from ansible.utils.collection_loader import _get_collection_root_paths

    search_paths = ["/does/not/exist",
                    "/usr/bin",
                    "/usr/share/ansible/collections",
                    "/usr/share/ansible/ansible_collections",
                    "/usr/share/ansible_collections",
                    "/etc/ansible/hosts",
                    "/etc/ansible/ansible.cfg"]

    valid_search_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(valid_search_paths) == 7

    # Since this is done before the

# Generated at 2022-06-22 19:25:32.511921
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    # Create a collection dir and make a collection
    dircollections = tempfile.mkdtemp()
    os.mkdir(os.path.join(to_bytes(dircollections), to_bytes('ansible_collections')))
    os.mkdir(os.path.join(to_bytes(dircollections), to_bytes('ansible_collections'), to_bytes('mynamespace')))
    os.mkdir(os.path.join(to_bytes(dircollections), to_bytes('ansible_collections'), to_bytes('mynamespace'), to_bytes('myname')))

# Generated at 2022-06-22 19:25:37.192543
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Basic
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/test/collections'
    display.verbosity = 5
    assert list(list_collection_dirs(warn=True)) == []

    # One match
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/test/collections'
    os.mkdir(os.environ['ANSIBLE_COLLECTIONS_PATHS'])
    assert list(list_collection_dirs(warn=True)) == []

    # Two matches
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/test/collections:/tmp/test/collections2'
    os.mkdir(os.environ['ANSIBLE_COLLECTIONS_PATHS'])
    os.mk

# Generated at 2022-06-22 19:25:43.070722
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Given a path to a valid ansible_collections folder check that list_valid_collection_paths returns it
    """
    coll_list = list_valid_collection_paths()

    for coll_path in coll_list:
        assert os.path.isdir(coll_path)
        assert os.path.basename(coll_path) == b'ansible_collections'

# Generated at 2022-06-22 19:25:47.995443
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['invalid']
    result = list_valid_collection_paths(test_paths)
    assert list(result) == []
    test_paths = ['invalid', '/usr/share/ansible/collections']
    result = list_valid_collection_paths(test_paths)
    assert list(result) == ['/usr/share/ansible/collections']



# Generated at 2022-06-22 19:25:56.656134
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/tmp/ansible_collections/my_namespace/my_collection', '/tmp/ansible_collections/my_namespace/my_collection2']
    paths = list(list_valid_collection_paths(search_paths=paths, warn=False))
    assert paths == ['/tmp/ansible_collections/my_namespace/my_collection', '/tmp/ansible_collections/my_namespace/my_collection2']

# Generated at 2022-06-22 19:26:04.888728
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:26:15.798565
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    import tempfile
    from shutil import rmtree

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:26:21.076991
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp/does_not_exist', '/tmp/does_not_exist2'])) == list()
    assert list(list_valid_collection_paths(['/tmp/does_not_exist', '/tmp/does_not_exist2'], warn=False)) == list()
    assert list(list_valid_collection_paths(['/tmp/does_not_exist', '/tmp/does_not_exist2'], warn=True)) == list()

# Generated at 2022-06-22 19:26:28.913961
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collect1 = "od1.mycoll"
    collect2 = "od2.mycoll"
    collect3 = "od1.mycoll2"

    # At least two collections with same name should be present to check priority order
    collect4 = "od1.mycoll3"
    collect5 = "od2.mycoll3"

    search_paths = []
    search_paths.append(os.path.sep + collect1 + os.path.sep + "plugins")
    search_paths.append(os.path.sep + collect2 + os.path.sep + "plugins")
    search_paths.append(os.path.sep + collect3 + os.path.sep + "plugins")

# Generated at 2022-06-22 19:26:33.802980
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/fake_i_do_not_exist', '/does_not/exist', '/usr/share/ansible/collections', '/usr/share/ansible/collections_does_not/exist']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert '/usr/share/ansible/collections' in valid_paths

# Generated at 2022-06-22 19:26:37.170510
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test various passing and failing paths for the list_collection_dirs function
    :return:
    """

    # should not fail for empty path
    list(list_collection_dirs())

# Generated at 2022-06-22 19:26:46.871884
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import list_collection_paths

    # path is not existing
    search_paths = ['/var/tmp']
    assert list(list_valid_collection_paths(search_paths, warn=True)) == []

    # path is existing, but is not a directory
    f = tempfile.NamedTemporaryFile(delete=False)
    search_paths = [f.name]
    f.close()
    assert list(list_valid_collection_paths(search_paths, warn=True)) == []

    # path is existing, is a directory
    d = tempfile.mkdtemp()
    search_paths = [d]
    assert list(list_valid_collection_paths(search_paths, warn=True)) == [d]

    # path is default,

# Generated at 2022-06-22 19:26:50.396683
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))
    result = list(list_collection_dirs())
    assert result != []
    assert isinstance(result[0], bytes)

# Generated at 2022-06-22 19:27:01.803242
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.plugin_docs import list_all
    from ansible.collections.ansible.network.plugins.modules import ios_template
    from ansible.collections.ansible.network.plugins.modules.network_cli import ios_template as ios_template_network_cli
    from ansible.collections.ansible.network.plugins.modules.network_device import ios_template as ios_template_network_device

    assert ios_template == ios_template_network_cli
    assert ios_template_network_cli == ios_template_network_device

    all_modules = sorted(list_all())

    base_module_names = [os.path.basename(module_path) for module_path in all_modules]

    assert 'ios_template.py' in base_module_names

# Generated at 2022-06-22 19:27:05.098076
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(warn=True))
    assert len(dirs) > 0

    dirs = list(list_collection_dirs(coll_filter='foo', warn=True))
    assert len(dirs) == 0

# Generated at 2022-06-22 19:27:12.242964
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Case 1.1 - list_valid_collection_paths() will return the default value
    default_collection_paths = list_valid_collection_paths()
    assert(len(default_collection_paths) == 1)

    # Case 1.2 - list_valid_collection_paths() will return the last item
    search_paths = ['one', 'two']
    collection_paths = list_valid_collection_paths(search_paths)
    assert(collection_paths[len(collection_paths)-1] == 'two')

    # Case 2.1 - If a search_path does not exist, there will be a warning
    search_paths = ['one', 'no_exist']
    collection_paths = list_valid_collection_paths(search_paths, True)

# Generated at 2022-06-22 19:27:22.103578
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import ansible
    import shutil
    mydir = tempfile.mkdtemp()

    # Set a fake collection path
    # This should be the 1st directory, due to the order in which things happen
    # in an ansible collection loader, when YAML is specified in a config file.
    # I'm not sure about the order, but it should appear after any default
    # search paths.
    #
    # The first directory in the returned list should be the one we specify here.
    # DO NOT CHANGE THIS TO A DIRECTORY THAT ALREADY EXISTS.
    # The actual test is that it returns directories that exist.
    fakeroot = os.path.join(mydir, "does_not_exist")

    # Add a fake ansible collection (one-level deep)

# Generated at 2022-06-22 19:27:32.392679
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = ['/tmp/this/path/does/not/exist', '/tmp/this/path/exists/but/is/a/file']
    paths = list(list_valid_collection_paths(collection_paths, warn=True))
    assert 2 == len(paths)
    assert '/tmp/this/path/does/not/exist' not in paths
    assert '/tmp/this/path/exists/but/is/a/file' not in paths

    collection_paths = []
    paths = list(list_valid_collection_paths(collection_paths, warn=True))
    assert len(paths) > 0

    # noinspection PyProtectedMember

# Generated at 2022-06-22 19:27:38.016044
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_path = [
        'list_collections/colls',
        'list_collections/colls/other_colls',
        'list_collections/colls/other_colls/yet_other_colls']
    collections_dirs = list_collection_dirs(search_path)

    # Verify that there are correct number of collections
    collections = []

# Generated at 2022-06-22 19:27:43.419183
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Return paths for the specific collections found in passed or configured search paths
    :param search_paths: list of text-string paths, if none load default config
    :param coll_filter: limit collections to just the specific namespace or collection, if None all are returned
    :return: list of collection directory paths
    """
    assert list(list_collection_dirs(['/home/labuser/realansible/ansible_collections'])) == [b'/home/labuser/realansible/ansible_collections/nti310/nti310_linux/']

# Generated at 2022-06-22 19:27:51.724201
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['./.ansible/collections', 'foo']

    # Existing directory
    for path in list_valid_collection_paths(search_paths):
        if path == search_paths[0]:
            break
    else:
        raise AssertionError("In list of valid collection paths, .ansible/collections not found")

    # Non-existing directory
    for path in list_valid_collection_paths(search_paths):
        if path == search_paths[1]:
            raise AssertionError("In list of valid collection paths, foo should not be found")



# Generated at 2022-06-22 19:27:59.281561
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from ansible.module_utils._text import to_bytes

    import os

    # check temp dir
    temp_path = os.path.join(os.getcwd(), 'ansible_collections')

    if not os.path.exists(temp_path):
        os.makedirs(temp_path)

        # Make a fake collection
        coll_path = os.path.join(temp_path, b'ansible_namespace', b'ansible_collection')
        if not os.path.exists(coll_path):
            os.makedirs(coll_path)

        # Test our collection filter
        coll_list = list_collection_dirs(coll_filter='ansible_namespace.ansible_collection')


# Generated at 2022-06-22 19:28:07.910708
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test list_collection_dirs() function"""

    # Path to fixture collection
    collection_path = '/tmp/ansibullbot/tests/fixtures/ansible_collections/ansible/test_collection'

    # Execution is done via normal path
    paths = list(list_collection_dirs(coll_filter='ansible.test_collection'))
    assert paths == [collection_path]

    # Execution is done via collection path
    paths = list(list_collection_dirs(coll_filter='ansible.test_collection:file/modules/test_module.py'))
    assert paths == [collection_path]

# Generated at 2022-06-22 19:28:15.536559
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

    # test a simple path
    paths = ['%s/test/data/collection_loader/col1' % base_path]
    expected = path_to_bytes(paths)
    results = list(list_valid_collection_paths(paths))

    assert results == expected

    # test a relative path
    paths = ['test/data/collection_loader/col1']
    expected = path_to_bytes(paths)
    results = list(list_valid_collection_paths(paths))

    assert results == expected

    # test an invalid path
    paths = ['%s/test/data/collection_loader/colXXX' % base_path]
    expected = []


# Generated at 2022-06-22 19:28:28.827690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collections = [
        '/home/user/.ansible/collections',
        '/home/user/custom_collections'
    ]

    dirs = list_collection_dirs(search_paths=test_collections, coll_filter='test')
    assert '/home/user/custom_collections/ansible_collections/test/default' in dirs
    assert '/home/user/.ansible/collections/ansible_collections/test/default' in dirs

    dirs = list_collection_dirs(search_paths=test_collections, coll_filter='test.default')
    assert '/home/user/custom_collections/ansible_collections/test/default' in dirs
    assert '/home/user/.ansible/collections/ansible_collections/test/default' in dirs

# Generated at 2022-06-22 19:28:39.129833
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # import modules from local ansible repository
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import configparser

    collection_paths = ['./test/utils/collections/search_path_1/',
                        './test/utils/collections/search_path_2/',
                        './test/utils/collections/search_path_3/',
                        './test/utils/collections/search_path_4/']


# Generated at 2022-06-22 19:28:44.226252
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths(['/etc/ansible/'])
    for path in paths:
        assert isinstance(path, str)
        assert os.path.exists(to_bytes(path))

# Generated at 2022-06-22 19:28:52.000612
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == AnsibleCollectionConfig.collection_paths
    assert list_valid_collection_paths(search_paths=None) == AnsibleCollectionConfig.collection_paths
    assert list_valid_collection_paths(search_paths=[]) == AnsibleCollectionConfig.collection_paths
    assert list_valid_collection_paths(search_paths=["/tmp/nonexistent"]) == AnsibleCollectionConfig.collection_paths
    assert list_valid_collection_paths(search_paths=["/tmp/nonexistent"], warn=True) != AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-22 19:29:00.052052
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert sorted(list(list_collection_dirs(search_paths=[os.getcwd()]))) == sorted([
        os.path.join(os.getcwd(), 'ansible_collections', 'example_namespace', 'example_collection'),
        os.path.join(os.getcwd(), 'ansible_collections', 'example_namespace', 'example_collection_two')
    ])


# Generated at 2022-06-22 19:29:10.854861
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the function list_valid_collection_paths.
    """
    from ansible.utils import collection_loader
    from ansible.utils.collection_loader import _get_collection_name_from_path
    from ansible.plugins import module_loader

    test_path = collection_loader._get_deprecated_collections_path()
    search_paths = [test_path]

    collection_dirs = list_collection_dirs(search_paths)

    collections = list(list_valid_collection_paths(search_paths))

    assert collections

    # should not have duplicate paths
    assert len(collections) == len(set(collections))

    # assert that collections contain all valid collection sub directories
    for path in collection_dirs:
        assert any(path in x for x in collections)

   

# Generated at 2022-06-22 19:29:15.386923
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six import (
        PY3,
    )
    import tempfile

    tmpdir = tempfile.mkdtemp()
    coll = os.path.join(tmpdir, 'col')
    os.mkdir(coll)

    if PY3:
        coll = coll.encode('utf-8').decode()

    assert coll in list(list_collection_dirs([tmpdir]))

# Generated at 2022-06-22 19:29:25.343047
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert '.' in list(list_valid_collection_paths())  # default path exists
    assert '.' in list(list_valid_collection_paths(search_paths=['.']))  # default used when requested

    # non-existing paths are skipped, default path is not added
    assert '.' not in list(list_valid_collection_paths(search_paths=['/no/path/here']))

    # non-existing dir is skipped, default path is used
    assert '.' in list(list_valid_collection_paths(search_paths=['/no/path/here', '.']))

    # None for searchpaths is ok, returns default path
    assert '.' in list(list_valid_collection_paths(search_paths=None))


# Generated at 2022-06-22 19:29:33.883523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # empty list
    assert len(list(list_valid_collection_paths([]))) == len(list(list_valid_collection_paths()))

    # missing dirs
    assert list(list_valid_collection_paths(['/tmp/doesnotexist'])) == []

    # single dir
    res = list(list_valid_collection_paths(['/tmp']))
    assert len(res) == 1
    assert res[0] == '/tmp'

    # multiple dirs
    res = list(list_valid_collection_paths(['/tmp', '/tmp/doesnotexist']))
    assert len(res) == 1
    assert res[0] == '/tmp'

    # multiple dirs, but one existing

# Generated at 2022-06-22 19:29:37.723872
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = "/Users/zez/work/ansible/external_plugins"
    coll_filter = "community.general"
    collection_dirs = list_collection_dirs(search_path, coll_filter)
    for collection_dir in collection_dirs:
        print(collection_dir)


# Generated at 2022-06-22 19:29:44.652530
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''Test list_collection_dirs returns expected results'''

    # setup test environment and collection directories

    test_collection_root = "/tmp/ansible_collections"

    # the following collections to be tested
    collections = [("ansible_namespace", "collection1"),
                   ("ansible_namespace", "collection2"),
                   ("ansible_namespace", "collection3"),
                   ("ansible_namespace2", "collection1")]

    for (namespace, collection) in collections:
        namespace_dir = os.path.join(test_collection_root, namespace)
        collection_dir = os.path.join(test_collection_root, namespace, collection)
        os.makedirs(collection_dir)

    # function to use with utils.list_collection_dirs,
    # returns only collections that have a

# Generated at 2022-06-22 19:29:47.893080
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with well formed collections
    assert len(list(list_collection_dirs())) > 0
    assert len(list(list_collection_dirs(["/tmp/test123"]))) == 0

# Generated at 2022-06-22 19:29:52.789021
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['tests/data']

    assert list(list_collection_dirs(search_paths, 'namespace.collection1')) == [b'namespace.collection1']
    assert list(list_collection_dirs(search_paths, 'namespace.collection2')) == [b'namespace.collection2']
    assert list(list_collection_dirs(search_paths, 'namespace')) == [b'namespace.collection1', b'namespace.collection2']
    assert list(list_collection_dirs(search_paths)) == [b'namespace.collection1', b'namespace.collection2']
    assert list(list_collection_dirs(search_paths, 'non_existing_namespace')) == []

# Generated at 2022-06-22 19:29:59.632448
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for path in list_collection_dirs(search_paths=['./test_data/collection_loader'],
                                     coll_filter='testcoll1'):
        assert path.endswith(b'ansible_collections/testcoll1/plugins')

    for path in list_collection_dirs(search_paths=['./test_data/collection_loader'],
                                     coll_filter='testcoll2'):
        assert path.endswith(b'ansible_collections/testcoll2/plugins')

# Generated at 2022-06-22 19:30:01.953873
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert ['/path1', '/path2'] == list(list_valid_collection_paths(['/path1', '/path2', '/path3']))



# Generated at 2022-06-22 19:30:08.460666
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    from io import StringIO
    from tempfile import TemporaryDirectory

    search_paths = ['/tmp/test_collections']
    coll_filter = 'ns.test'
    collection = None
    namespace = None

    if coll_filter is not None:
        if '.' in coll_filter:
            try:
                (namespace, collection) = coll_filter.split('.')
            except ValueError:
                raise AnsibleError("Invalid collection pattern supplied: %s" % coll_filter)
        else:
            namespace = coll_filter
