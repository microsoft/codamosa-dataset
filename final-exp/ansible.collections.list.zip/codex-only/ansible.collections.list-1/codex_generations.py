

# Generated at 2022-06-22 19:20:14.679584
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_paths = ['/path/does/not/exist', '/path/does/not/exist/either']
    ret_paths = list(list_valid_collection_paths(valid_paths))
    assert len(ret_paths) == 0

    invalid_path = '/this/path/does/not/exist'
    ret_paths = list(list_valid_collection_paths(valid_paths, warn=True))
    assert len(ret_paths) == 0

    valid_path = '/path/to/does/exist'
    ret_paths = list(list_valid_collection_paths([invalid_path, valid_path], warn=True))
    assert len(ret_paths) == 1
    assert valid_path in ret_paths



# Generated at 2022-06-22 19:20:22.136841
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    q = list_valid_collection_paths(["/tmp/doesnotexist"])
    assert False == isinstance(q, list)
    assert True == isinstance(q, type(iter([])))

    q = list(q)
    assert [] == q

    q = list_valid_collection_paths(["/tmp/doesnotexist"], warn=True)
    assert False == isinstance(q, list)
    assert True == isinstance(q, type(iter([])))

    q = list(q)
    assert [] == q



# Generated at 2022-06-22 19:20:33.146945
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader

    test_data = './test/unit/utils/test_collection_paths.yml'

    loader = DataLoader()
    test_data = loader.load_from_file(to_text(test_data))

    display = Display()

    valid = test_data['valid']
    bad = test_data['bad']

    # Check valid paths
    valid_paths = list_collection_dirs(search_paths=valid)
    assert valid_paths is not None

    # Check empty paths

# Generated at 2022-06-22 19:20:35.046172
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    data = []
    assert list(list_valid_collection_paths(data)) == []

    data = [
        '$INVALID_PATH_DEASHLASH',
        'invalid_path'
    ]

    assert list(list_valid_collection_paths(data, warn=True)) == []



# Generated at 2022-06-22 19:20:43.452542
# Unit test for function list_collection_dirs

# Generated at 2022-06-22 19:20:53.890307
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test 1, check if function list_valid_collection_paths returns only existing collection paths
    test1_search_paths = ['/path/to/nonexisting/dir', '/path/to/another/nonexisting/dir']

    test1_result1 = list(list_valid_collection_paths(test1_search_paths, warn=True))
    assert len(test1_result1) == 0

    # test 2, check if collection paths are returned
    test2_result = list(list_valid_collection_paths())
    assert len(test2_result) >= 2

    # test 3, check if function list_valid_collection_paths warns about collection paths that don't exist

# Generated at 2022-06-22 19:21:04.014670
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    (dummy_fd, fname) = tempfile.mkstemp()
    os.close(dummy_fd)
    paths = [fname]

    paths = list(list_valid_collection_paths(paths, warn=True))

    assert len(paths) == 0
    os.unlink(fname)

    (dummy_fd, fname) = tempfile.mkstemp()
    os.close(dummy_fd)
    os.mkdir(fname)
    paths = [fname]

    paths = list(list_valid_collection_paths(paths, warn=True))

    assert len(paths) == 1
    os.rmdir(fname)

# Generated at 2022-06-22 19:21:06.280962
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for d in list_collection_dirs(search_paths=['test/data/collections/ansible_collections']):
        print(d)

# Generated at 2022-06-22 19:21:08.373945
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['test/path', '~/.ansible/collections', '/tmp/test']
    ret = list(list_valid_collection_paths(paths, warn=True))
    assert ret == ['test/path', '/tmp/test']

# Generated at 2022-06-22 19:21:15.156057
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.module_utils._text import to_native
    from ansible.modules.collection_loader.list_collection_paths import get_collections_paths

    # mocking get_collections_paths to only return /tmp as search path
    original__get_collections_paths = get_collections_paths
    get_collections_paths = None
    original_module_utils_paths = AnsibleCollectionConfig.module_utils_paths

    def _mock_get_collections_paths(subdirs=None):
        return ['/tmp']
    get_collections_paths = _mock_get_collections_paths

    # create a collection dir inside /tmp
    tmpdir = tempfile.mkdtemp(dir='/tmp/')
    nsdir = temp

# Generated at 2022-06-22 19:21:25.136247
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import ansible.constants as C
    from ansible.utils import context_objects as co

    with co.GlobalLoader():
        b_paths = list(list_collection_dirs(search_paths=[C.DEFAULT_COLLECTIONS_PATHS]))

        assert len(b_paths) > 0

        paths = [p.decode('utf-8') for p in b_paths]

        for base_path in [C.DEFAULT_LOCAL_TMP, C.DEFAULT_REMOTE_TMP]:

            found = False
            for p in paths:
                if p.startswith(os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_collections')):
                    found = True
                    break
            assert found is True


# Generated at 2022-06-22 19:21:32.283827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    SEARCH_PATHS = ["/invalid/path/to/place/should/be/invalid",
                    "/etc/ansible/collections",
                    "/usr/share/ansible/collections"]
    valid_paths = list(list_valid_collection_paths(search_paths=SEARCH_PATHS, warn=True))
    assert len(valid_paths) > 0
    assert "/etc/ansible/collections" in valid_paths
    assert "/usr/share/ansible/collections" in valid_paths

# Generated at 2022-06-22 19:21:40.825361
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os

    search_paths = []
    coll_filter = 'test_namespace.test_collection'

    collections = []
    for coll_path in list_collection_dirs(search_paths, coll_filter):
        collections.append(coll_path.decode('utf-8'))

    display.info("Collections found: {0}".format(collections))

    assert len(collections) == 1
    assert os.path.basename(collections[0]) == 'test_collection'

# Generated at 2022-06-22 19:21:47.528453
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    collection dir list test
    looks in fixture dir and builds a list of collections there
    tests a few paths to ensure only collection dirs are returned
    """

    search_path = ['fixture/collection_loader_test/collections_a']

    for test_dir in list_collection_dirs(search_path):
        assert os.path.basename(test_dir) in ['my_namespace', 'my_namespace_b', 'my_namespace_c', 'not_a_collection']

    for test_dir in list_collection_dirs(search_path, coll_filter='not_a_collection'):
        assert os.path.basename(test_dir) == 'not_a_collection'

# Generated at 2022-06-22 19:21:57.445767
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(search_paths=[b'sample_data/collections']))
    assert dirs == [b'sample_data/collections/ansible_collections/test_ns/test_coll',
                    b'sample_data/collections/ansible_collections/test_ns2/test_coll2']
    dirs = list(list_collection_dirs(search_paths=[b'sample_data/collections'],
                                     coll_filter='test_ns.test_coll'))
    assert dirs == [b'sample_data/collections/ansible_collections/test_ns/test_coll']

# Generated at 2022-06-22 19:22:08.637968
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.parsing.dataloader import DataLoader

    # Test with default collections
    coll_dirs = list(list_collection_dirs(coll_filter='my_namespace.my_collection'))
    assert len(coll_dirs) == 2  # One for ansible and one for ansible_collections
    assert coll_dirs[0].endswith('/ansible_collections/my_namespace/my_collection')
    assert coll_dirs[1].endswith('/ansible/my_namespace/my_collection')

    # Test with one collections path that has no collections
    coll_dirs = list(list_collection_dirs(search_paths=['/tmp'], coll_filter='my_namespace.my_collection'))

# Generated at 2022-06-22 19:22:18.430254
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test a list of valid search paths
    b_path1 = to_bytes('/path1')
    b_path2 = to_bytes('/path2')
    b_path3 = to_bytes('/path3')
    b_path4 = to_bytes('/path4')
    b_path5 = to_bytes('/path5')
    b_path6 = to_bytes('/path6')
    b_path7 = to_bytes('/path7')
    b_path8 = to_bytes('/path8')
    b_path9 = to_bytes('/path9')
    b_path10 = to_bytes('/path10')
    b_path11 = to_bytes('/path11')
    b_path12 = to_bytes('/path12')
    b_path13 = to_bytes

# Generated at 2022-06-22 19:22:30.617751
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil

    import tempfile

    TMP_DIR = tempfile.mkdtemp()

    # Make two temp dirs, one missing the initial collection dir
    TMP_DIR_A = os.path.join(TMP_DIR, 'dir_a')
    TMP_DIR_B = os.path.join(TMP_DIR, 'dir_b')
    os.mkdir(TMP_DIR_A)
    os.mkdir(TMP_DIR_B)

    # Make them appear in the wrong order in os.listdir
    shutil.move(os.path.join(TMP_DIR, 'dir_b'), os.path.join(TMP_DIR, 'dir_b_moved'))

    # Make an initial collection directory

# Generated at 2022-06-22 19:22:41.716839
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # path is None
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

    search_paths = ['/tmp/invalid_path1', '/tmp/invalid_path2']
    # path is not existing
    assert list(list_valid_collection_paths(search_paths)) == []

    search_paths = [os.path.dirname(__file__), os.path.dirname(os.path.dirname(__file__))]
    # path is existing but not a dir
    assert list(list_valid_collection_paths(search_paths)) == [os.path.dirname(os.path.dirname(__file__))]

    # path is existing and a dir

# Generated at 2022-06-22 19:22:46.460441
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/foo/bar", "/baz/duh"])) == ["/foo/bar", "/baz/duh"]
    assert list(list_valid_collection_paths(["/foo/bar", "/baz/duh"])) == ["/foo/bar", "/baz/duh", '~/.ansible/collections']

# Generated at 2022-06-22 19:22:50.248650
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths([__file__]))) == 1
    assert len(list(list_valid_collection_paths([__file__, __file__]))) == 2

# Generated at 2022-06-22 19:23:00.034024
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import ansible_collections_paths

    search_paths = [
        '/nonexistent',
        '/etc/ansible',
        '/etc/ansible/ansible_collections',
        '~/.ansible/collections',
    ]

    valid = list(list_valid_collection_paths(search_paths, warn=False))

    for path in valid:
        if path not in ansible_collections_paths:
            assert False, "path %s not found" % path

    # add a missing search path to defaults, then test it warns
    ansible_collections_paths.append('/nonexistent')
    valid = list(list_valid_collection_paths(warn=True))

    # now remove it
    ansible_collections_paths.pop()


# Generated at 2022-06-22 19:23:08.506875
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """
    ####################################################################################################################
    # INTEGRATION TESTS
    ####################################################################################################################
    display.debug('Testing list_collection_dirs()')

    test_paths = [os.path.join(os.path.sep, 'usr', 'local', 'share', 'ansible', 'collections'),
                  os.path.join(os.path.sep, 'etc', 'ansible', 'collections')]

    for test_path in test_paths:
        display.debug('Listing collections in {path}'.format(path=test_path), verbosity=1)
        paths = list_collection_dirs(search_paths=[test_path])


# Generated at 2022-06-22 19:23:17.626490
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.plugins.loader
    import collections
    import tempfile

    # Create a collection directory
    with tempfile.TemporaryDirectory() as temp_dir:
        paths = ["{}/ansible_collections/{}/{}".format(temp_dir, namespace, collection) for namespace, collection in
                 list(collections.ChainMap(ansible.plugins.loader.PSC, ansible.plugins.loader.LC))]
        for path in paths:
            os.makedirs(path)

        # Test with no arguments
        dirs = list_collection_dirs()
        assert len(dirs)
        assert set(dirs) == set(paths)

        # Test with search_paths
        dirs = list_collection_dirs(search_paths=[temp_dir])

# Generated at 2022-06-22 19:23:26.904330
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import sys
    import os
    import tempfile
    import shutil

    mytempdir = tempfile.mkdtemp()

    my_search_paths = [
        'thisdoesnotexist',
        '../thisneither',
        os.path.join(os.path.split(__file__)[0], 'notarealdir'),
        sys.prefix]

    for path in list_valid_collection_paths(my_search_paths):
        assert False, "Should not be any valid paths"

    # add valid path
    my_search_paths.append(mytempdir)

    for path in list_valid_collection_paths(my_search_paths):
        assert path == mytempdir

    # make existing path a file
    os.remove(mytempdir)

# Generated at 2022-06-22 19:23:33.699812
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.ansible.community.tests.unit.conftest import collection_artifact_dir, ansible_base_dir
    assert list(list_valid_collection_paths([])) == list(AnsibleCollectionConfig.collection_paths)
    assert list(list_valid_collection_paths([collection_artifact_dir, ansible_base_dir])) == [collection_artifact_dir]

# Generated at 2022-06-22 19:23:40.066871
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_dirs = list_collection_dirs(search_paths=['test/unit/data/test_collections/collections_default_paths'])
    collection_dirs = list(collection_dirs)
    assert len(collection_dirs) == 3
    assert b'ansible.test' in collection_dirs[0]

# Generated at 2022-06-22 19:23:48.626358
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test for empty input
    assert len(list(list_valid_collection_paths())) == 0

    # Test for one directory path option
    assert len(list(list_valid_collection_paths(['~/ansible_collections']))) == 1

    # Test for multiple directory path options
    assert len(list(list_valid_collection_paths([
        '/usr/share/ansible_collections',
        '/usr/local/share/ansible_collections'
    ]))) == 2

    # Test for multiple directory path options
    # - one path that exist and is a directory, while the other doesn't exist
    assert len(list(list_valid_collection_paths([
        '/usr/share/ansible_collections',
        '/tmp/ansible_collections'
    ]))) == 1


# Unit

# Generated at 2022-06-22 19:23:55.128667
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    cp = ['/tmp', '/dev/null', '/tmp/does_not_exist', '/root', '/tmp/does_not_exist-test']

    # filter out non existing search_paths
    res = list(list_valid_collection_paths(cp))

    assert res == ['/tmp']

    # filter out non existing search_paths, with warnings
    res = list(list_valid_collection_paths(cp, warn=True))

    assert res == ['/tmp']



# Generated at 2022-06-22 19:24:02.323432
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test existing directory path
    coll_dir = '/etc/ansible/ansible_collections'
    with open('/etc/ansible/ansible.cfg', 'r') as f:
        f.write('[defaults]\ncollections_paths = /var/lib/awx/plugins/ansible_collections,%s' % coll_dir)

    # Test not existing directory path
    coll_dir = '/home/user/k8s'
    with open('/etc/ansible/ansible.cfg', 'r') as f:
        f.write('[defaults]\ncollections_paths = /home/user/test,%s' % coll_dir)

# Generated at 2022-06-22 19:24:12.889088
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Test to ensure that list_valid_collection_paths() returns a list of valid paths
    """

    collection_paths = ['/foo/bar/baz', '/bar/baz/foo', '/foo/bar/']
    valid_paths = list(list_valid_collection_paths(collection_paths))

    assert len(valid_paths) == 3
    assert valid_paths[0] == '/foo/bar/baz'
    assert valid_paths[1] == '/bar/baz/foo'
    assert valid_paths[2] == '/foo/bar/'

# Generated at 2022-06-22 19:24:24.034643
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    cwd = os.getcwd()

    search_paths = [
        "/tmp",
        cwd
    ]

    # Create collection directory with os.makedirs
    os.makedirs(cwd + "/ansible_collections/test_collection", mode=0o755, exist_ok=True)

    # Test if collection directory is found
    valid_collection_paths = list(list_valid_collection_paths(search_paths=search_paths))
    assert cwd in valid_collection_paths

    # Test if non-existing search_path is not found
    os.rmdir(cwd + "/ansible_collections/test_collection")
    os.rmdir(cwd + "/ansible_collections")

# Generated at 2022-06-22 19:24:32.684899
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # pylint: disable=unused-variable

    # Test for a collection name with dots
    collection = "my.collection"
    # expected result from function
    expected = ["/tmp/ansible_collections/collections_root/my/collection", "/tmp/ansible_collections/another_root/my/collection"]
    # create a temp directory to validate collection path
    import shutil
    from tempfile import mkdtemp
    coll_root = mkdtemp()

    another_root = mkdtemp()
    coll_dir = os.path.join(coll_root, "ansible_collections", "my", "collection")
    coll_dir2 = os.path.join(another_root, "ansible_collections", "my", "collection")
    os.makedirs(coll_dir)
    os.m

# Generated at 2022-06-22 19:24:43.224382
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.module_utils.six import PY2

    #Create a tempfile with multibyte chars and write to it
    if PY2:
        from unicode_literals import UnicodeString
        content = UnicodeString(u"This is an example")
    else:
        content = "This is an example"

    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write(content)
    tmp.close()

    tmp_path = os.path.dirname(tmp.name)

    #List of invalid paths
    search_paths = ['invalidpath', '', 'x', tmp.name]

    assert list(list_valid_collection_paths(search_paths)) == []

    #List of valid paths

# Generated at 2022-06-22 19:24:49.446081
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    for path in list_collection_dirs():
        if sys.version_info[0] < 3:
            print(path.decode())
        else:
            print(path)


if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-22 19:24:56.686839
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os

    import pytest
    from ansible.utils.hashing import md5s

    # Setup some fake collections
    test_coll_path = os.path.join(os.getcwd(), 'test_collections')
    coll_namespace = 'fake_ns'
    coll_name = 'fake_coll'
    coll_path = os.path.join(test_coll_path, coll_namespace, coll_name)

    os.makedirs(coll_path)

    # Save a test file that we can check for
    test_file_name = 'test_file.py'
    file_path = os.path.join(coll_path, test_file_name)
    test_file = open(file_path, 'w')
    test_file.write("# test file")

# Generated at 2022-06-22 19:25:05.709271
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Warnings for missing paths should be generated
    search_paths = ['/none/existing1', '/none/existing2']
    search_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(search_paths) == 0

    # Warnings not generated if path not in default
    search_paths = ['/none/existing1']
    search_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(search_paths) == 0

    # Default paths should be included
    search_paths = []
    search_paths = list(list_valid_collection_paths(search_paths, warn=False))

# Generated at 2022-06-22 19:25:11.308542
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dir_list = []
    for collection_dir in list_collection_dirs(['test/units/utils/fixtures/collections']):
        collection_dir_list.append(collection_dir)
    assert 'ansible.builtin' in collection_dir_list
    assert 'my_namespace.my_collection' in collection_dir_list



# Generated at 2022-06-22 19:25:21.823370
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from os import makedirs
    from shutil import rmtree
    from tempfile import NamedTemporaryFile

    tmp_dir = mkdtemp()

    b_tmp_dir = to_bytes(tmp_dir)

    # verify that non-existing paths are ignored
    paths = list(list_valid_collection_paths([b_tmp_dir], warn=True))
    assert not paths

    # verify that empty path is handled
    paths = list(list_valid_collection_paths([''], warn=True))
    assert not paths

    # verify that non-directory paths are ignored
    # create an empty directory
    non_dir_path = NamedTemporaryFile(dir=tmp_dir, delete=False)
    non_dir_path.close()


# Generated at 2022-06-22 19:25:30.788558
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'ansible_collections/z/z_namespace' in list_collection_dirs()
    assert 'ansible_collections/z/z_namespace' in list_collection_dirs(coll_filter='z')
    assert 'ansible_collections/z/z_namespace' in list_collection_dirs(coll_filter='z.z_namespace')
    assert 'ansible_collections/z/z_namespace' in list_collection_dirs(coll_filter='z_namespace')

    list_collection_dirs(search_paths=['invalid_path'], warn=True)

# Generated at 2022-06-22 19:25:35.421478
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test default config
    valid_paths = list(list_valid_collection_paths(search_paths=None))

    assert len(valid_paths) > 0

    # Test with empty path
    valid_paths = list(list_valid_collection_paths(search_paths=[]))
    
    assert len(valid_paths) > 0


# Generated at 2022-06-22 19:25:46.846190
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    test_dir = tempfile.mkdtemp()
    test_dir_2 = tempfile.mkdtemp()

    # create a file, not a directory
    file_dir = os.path.join(test_dir, 'foo')
    open(file_dir, 'a').close()

    try:

        # path list with non existing paths
        paths = [test_dir, test_dir_2, '/tmp/does_not_exist']

        # filter out non existing paths
        filtered_paths = list(list_valid_collection_paths(paths))

        # one path was filtered out
        assert len(filtered_paths) == 2

        # file_dir is not a directory
        assert file_dir not in filtered_paths

    finally:
        shut

# Generated at 2022-06-22 19:25:59.032328
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test empty search_path
    assert not list(list_valid_collection_paths([]))

    # test single good existing path
    existing_path = [os.path.abspath('test/units/data/test_collections/good_collection_default')]
    assert list(list_valid_collection_paths(existing_path)) == [os.path.abspath('test/units/data/test_collections/good_collection_default')]

    # test single missing path
    missing_path = ['/bad/path/missing']
    assert not list(list_valid_collection_paths(missing_path))

    # test multiple good paths

# Generated at 2022-06-22 19:26:09.652049
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    from ansible.collections.ansible.plugins.module_utils.URLs import fetch_url

    collections = [
        {'namespace': 'test_namespace_1', 'collection': 'test_collection_1'},
        {'namespace': 'test_namespace_2', 'collection': 'test_collection_2'},
        {'namespace': 'test_namespace_3', 'collection': 'test_collection_3'},
        {'namespace': 'test_namespace_3', 'collection': 'test_collection_3_dupe'},
        {'namespace': 'test_namespace_4', 'collection': 'test_collection_4'}
    ]

    coll_dir = tempfile.mkdtemp()
    coll_paths = []


# Generated at 2022-06-22 19:26:14.506427
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = ['/etc/ansible/collections', '/usr/share/ansible/collections']
    actual = list(list_valid_collection_paths(search_paths=['/etc/ansible/collections',
                                                            '/usr/share/ansible/collections',
                                                            '/usr/share/ansible/noexist']))

    assert sorted(expected) == sorted(actual)

# Generated at 2022-06-22 19:26:22.319170
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_paths = ['/etc/ansible/ansible.cfg', '/etc/ansible/ansible.cfg', '/etc/ansible']
    invalid_paths = ['/etc/ansible/ansiblerc', '/etc/ansible/ansible.cf', '/etc/ansible/ansible.cfg/']

    default_paths = list_valid_collection_paths()

    assert len(default_paths) > 0, "List of default paths should not be empty"

    with_valid_paths = list_valid_collection_paths(valid_paths, warn=True)

    # even the invalid paths are expected to be found since they are default paths

# Generated at 2022-06-22 19:26:33.437919
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        os.path.join(os.getcwd(), 'test', 'unit', 'utils', 'test_collections'),
        os.path.join(os.getcwd(), 'test', 'integration', 'utils', 'test_collections'),
        os.path.join(os.getcwd(), 'test', 'units', 'utils', 'test_collections'),
        os.path.join(os.getcwd(), 'test', 'integrations', 'utils', 'test_collections'),
        os.path.join(os.getcwd(), 'test', 'unit', 'integration', 'utils', 'test_collections'),
        os.path.join(os.getcwd(), 'test', 'integration', 'unit', 'utils', 'test_collections'),
    ]


# Generated at 2022-06-22 19:26:41.896666
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.cli.playbook import CLI
    from test.units.test_playbook.test_playbook import MockPlaybookCLIRunner
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook

    pb = Playbook()
    pb.load()
    pb.basedir = '/a/b/c'
    pc = PlayContext()
    runner = MockPlaybookCLIRunner(pb, pc)
    cli = CLI(runner, '/a/b/c')

    # Remove the directories we create

# Generated at 2022-06-22 19:26:53.291955
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_paths = ['../targets/test_collections']
    collection_dirs = list_collection_dirs(search_paths=coll_paths)
    assert '../targets/test_collections/ansible_collections/test_ns/sub_ns/test_coll1_a/' in collection_dirs
    assert '../targets/test_collections/ansible_collections/test_ns/sub_ns/test_coll2/' in collection_dirs
    assert '../targets/test_collections/ansible_collections/test_ns/sub_ns/test_coll3/' in collection_dirs
    assert '../targets/test_collections/ansible_collections/test_ns/sub_ns/test_coll3_a/' not in collection

# Generated at 2022-06-22 19:27:04.527411
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    empty_paths = list_valid_collection_paths(search_paths=[])
    assert len(empty_paths) == 0

    path_list = []

    if os.path.isdir("/etc/ansible"):
        path_list.append("/etc/ansible")

    if os.path.isdir("/usr/share/ansible"):
        path_list.append("/usr/share/ansible")

    if os.path.isdir(os.path.expanduser("~/.ansible")):
        path_list.append(os.path.expanduser("~/.ansible"))

    if os.path.isdir("/etc/ansible/ansible_collections"):
        path_list.append("/etc/ansible/ansible_collections")


# Generated at 2022-06-22 19:27:11.889420
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test ansible.collection.config first
    bad_paths = ['/does/not/exist', '/this/one/does/also/not/exist']
    good_paths = ['/usr/share/ansible/collections', '/etc/ansible/collections']

    dirs = list_valid_collection_paths()

    # First check that our paths exist
    assert list(dirs) == AnsibleCollectionConfig.collection_paths

    # Now add some bad paths to check we filter those out
    test_paths = good_paths.copy()
    test_paths.extend(bad_paths)

    dirs = list_valid_collection_paths(search_paths=test_paths)
    assert list(dirs) == good_paths

    # If we add a good path that doesn't

# Generated at 2022-06-22 19:27:21.904208
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    from shutil import rmtree

    # temp for the default collection path
    b_tmp_path = to_bytes(tempfile.mkdtemp())
    os.mkdir(os.path.join(b_tmp_path, to_bytes('ansible_collections')))
    os.mkdir(os.path.join(b_tmp_path, to_bytes('ansible_collections'), to_bytes('dummy')))
    os.mkdir(os.path.join(b_tmp_path, to_bytes('ansible_collections'), to_bytes('dummy'), to_bytes('dummy1')))
    os.mkdir(os.path.join(b_tmp_path, to_bytes('ansible_collections'), to_bytes('dummy'), to_bytes('dummy2')))


# Generated at 2022-06-22 19:27:25.615441
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/tmp', '/does_not_exist', '/etc']
    valid_paths = list(list_valid_collection_paths(test_paths))
    assert '/tmp' in valid_paths

# Generated at 2022-06-22 19:27:34.419905
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import defaultdict
    from ansible.module_utils._text import to_bytes

    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'collections')
    test_paths = [to_bytes(os.path.join(test_path, 'root'))]
    dirs_to_check = defaultdict(dict)
    dirs_checked = defaultdict(dict)
    for entry in os.listdir(test_path):
        if os.path.isdir(os.path.join(test_path, entry)):
            dirs_to_check[entry] = os.path.join(test_path, entry)
    # All collections

# Generated at 2022-06-22 19:27:42.591431
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # get a list of all paths for all Ansible collections
    x1 = list(list_collection_dirs())

    # get the path for the current namespace
    x2 = list(list_collection_dirs(coll_filter='ansible_collections.foo'))

    # get the path for the current namespace and collection
    x3 = list(list_collection_dirs(coll_filter='ansible_collections.foo.bar'))

    assert x1[0] == x2[0] == x3[0]
    assert len(x1) > 1

# Generated at 2022-06-22 19:27:52.063746
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    print()
    print("List all collections in default search path")
    print([c for c in list_collection_dirs()])
    print()

    print("List specific collections in default search path")
    print([c for c in list_collection_dirs(coll_filter="test.collection1")])
    print([c for c in list_collection_dirs(coll_filter="test.collection2")])
    print([c for c in list_collection_dirs(coll_filter="test")])
    print([c for c in list_collection_dirs(coll_filter="test.dummy")])
    print()

    print("List all collections in default search path + extra path")
    print([c for c in list_collection_dirs(search_paths=["/tmp"])])
    print()


# Generated at 2022-06-22 19:27:59.516954
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    bad_tmpdir1 = os.path.join(tmpdir, 'bad_tmpdir1')
    bad_tmpdir2 = os.path.join(tmpdir, 'bad_tmpdir2')
    good_tmpdir1 = os.path.join(tmpdir, 'good_tmpdir1')
    good_tmpdir2 = os.path.join(tmpdir, 'good_tmpdir2')
    coll_path = os.path.join(good_tmpdir2, 'ansible_collections')

    # Create a bad path, which does not exist
    valid_coll_paths = list(list_valid_collection_paths([bad_tmpdir1]))
    assert len(valid_coll_paths) == 0

    # Create

# Generated at 2022-06-22 19:28:09.982024
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY3

    if PY3:
        ansible_min_version = b'2.9'
    else:
        ansible_min_version = '2.9'

    # We simply test here whether ansible_collections.txt exists or not.
    # On run time the file may exist or not, depending on the current running version.
    # The file will be created when ansible is shipped inside a generated wheel.
    ansible_collections_txt = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ansible_collections.txt')

# Generated at 2022-06-22 19:28:19.853091
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _collection_finder
    from ansible.utils.collection_loader._data import DataLoader

    # use a simple test fixture with collections
    # this does not need to actually load the collections, just verify the list of dirs
    # since we are testing the actual loading of collections in another module, invalid
    # collection dirs will trigger errors in the other test and can be skipped

    # create a new collection_finder based on test fixture directories
    test_paths = ['/path/to/collections', '/path/to/collections/ansible_collections']
    collection_finder = _collection_finder(DataLoader(), test_paths)

    # test with a namespace.collection filter that matches dirs
    namespace = 'foo'
    collection = 'bar'

# Generated at 2022-06-22 19:28:23.572567
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid1 = '/foo'
    valid2 = '/bar'

    # Test where both paths do not exist
    valid_paths = list(list_valid_collection_paths([to_bytes(valid1), to_bytes(valid2)]))
    assert (len(valid_paths) == 0)

    # Test where one path exists
    os.makedirs(to_bytes(valid1))
    valid_paths = list(list_valid_collection_paths([to_bytes(valid1), to_bytes(valid2)]))
    assert (len(valid_paths) == 1)
    os.rmdir(to_bytes(valid1))

    # Test where both paths exist
    os.makedirs(to_bytes(valid1))
    os.makedirs(to_bytes(valid2))
    valid_

# Generated at 2022-06-22 19:28:29.432290
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_path = '/path/to/invalid/collections'
    coll_path_with_warning = '/tmp'
    search_pathes = [coll_path, coll_path_with_warning]
    filtered_pathes = list(list_valid_collection_paths(search_pathes))
    assert len(filtered_pathes) == 1
    assert filtered_pathes[0] == coll_path_with_warning

# Generated at 2022-06-22 19:28:39.314817
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    temp_ns = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_ns, 'ansible_collections'))
    os.mkdir(os.path.join(temp_ns, 'ansible_collections', 'my_namespace'))
    os.mkdir(os.path.join(temp_ns, 'ansible_collections', 'my_namespace', 'my_collection'))

    temp_ns_coll = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_ns_coll, 'ansible_collections'))
    os.mkdir(os.path.join(temp_ns_coll, 'ansible_collections', 'my_namespace'))

# Generated at 2022-06-22 19:28:51.468640
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    #
    #  test1: list all collections, no filter
    #
    search_paths = [
        os.path.expanduser('~/.ansible/collections/ansible_collections'),
        os.path.expanduser('~/.ansible/ansible_collections'),
        '/usr/share/ansible',
    ]
    expected_ns = {
        'testns',
    }
    expected_colls = {
        'collection',
    }

    for coll_dir in list_collection_dirs(search_paths):
        ns = os.path.basename(os.path.dirname(coll_dir))
        coll = os.path.basename(coll_dir)
        assert ns in expected_ns, "Unexpected collection %s" % ns
        assert coll in expected_colls

# Generated at 2022-06-22 19:29:00.664986
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils._text import to_text

    coll_dir = mkdtemp()
    coll_dir = os.path.join(coll_dir, 'ansible_collections')
    os.mkdir(coll_dir)


# Generated at 2022-06-22 19:29:11.101276
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test normal case
    from collections import Counter

    paths = Counter(list(list_collection_dirs(['/etc/ansible/collections', '/usr/share/ansible/collections',
                                               '/etc/ansible/ansible_collections', '/usr/share/ansible/ansible_collections'])))

    print(paths)

    # Test returning specific collection
    paths = list(list_collection_dirs(['/etc/ansible/collections', '/usr/share/ansible/collections',
                                       '/etc/ansible/ansible_collections', '/usr/share/ansible/ansible_collections'], "TEST.collection"))

    print(paths)

    # Test returning specific namespace that contains no collections

# Generated at 2022-06-22 19:29:20.899460
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Create test assets
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        test_collection_dir1 = os.path.join(tmp_dir_name, 'test_collections')
        test_collection_dir2 = os.path.join(tmp_dir_name, 'test_collections_2')

        os.mkdir(test_collection_dir1)
        os.mkdir(test_collection_dir2)

        # Test collection check
        test_collections = [test_collection_dir1, test_collection_dir2]
        assert len(list(list_valid_collection_paths(search_paths=test_collections))) == 2

        test_collections = [os.path.join(tmp_dir_name, 'test'), test_collection_dir1]
       

# Generated at 2022-06-22 19:29:30.134787
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_path = '/tmp/test_collections'

    coll_path = os.path.join(collection_path, 'ansible_collections')
    ns_path = os.path.join(coll_path, 'namespace1')
    coll_path = os.path.join(ns_path, 'collection1')

    os.mkdir(collection_path)
    os.mkdir(coll_path)
    os.mkdir(ns_path)

    paths = [coll_path]

    assert os.path.exists(coll_path) is True
    for path in list_valid_collection_paths(paths):
        assert path == coll_path

    # Test that the function returns a list containing the directory passed in.
    paths = [coll_path]

# Generated at 2022-06-22 19:29:40.403048
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    b_cwd = to_bytes(os.getcwd())

    # test invalid search path on disk
    search_paths = [b_cwd, os.path.join(b_cwd, b'nonexistent')]
    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(paths) == 1
    assert paths[0] == b_cwd

    # test non directory search path on disk
    non_dir = __file__

    # on windows, __file__ is a unicode string to convert to bytes we need encoding
    if os.name == 'nt':
        non_dir = non_dir.encode(sys.getfilesystemencoding())

    search_paths = [b_cwd, non_dir]

# Generated at 2022-06-22 19:29:49.579036
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        'files://../lib/ansible/ansible_collections/zax/test',
        'files://../lib/ansible/ansible_collections/zax/test_null',
    ]

    colls = list_collection_dirs(search_paths=search_paths, coll_filter='zax.test')

    assert is_collection_path(list(colls)[0])

    colls = list_collection_dirs(search_paths=search_paths, coll_filter='zax.test_null')

    assert not is_collection_path(list(colls)[0])

# Generated at 2022-06-22 19:29:56.558696
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() is not None
    assert list_collection_dirs() == list_collection_dirs(search_paths=None, coll_filter=None)
    assert list_collection_dirs(search_paths=["test"], coll_filter="test.test") is not None
    assert list_collection_dirs(search_paths=["test"], coll_filter="test.test") == list_collection_dirs(search_paths=["test"], coll_filter="test.test")

# Generated at 2022-06-22 19:30:01.339117
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_paths = [
        '/usr/share/ansible_collections/',
        '/usr/custom/ansible_collections/'
    ]
    collections = list_collection_dirs(search_paths=coll_paths, coll_filter='test_co.test_coll')
    assert len(collections) == 1

# Generated at 2022-06-22 19:30:08.138891
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    collection_paths = ['tests/data/roles/role_with_plugins/collection/contrib',
                        'tests/data/roles/role_with_plugins/collection/library',
                        'tests/data/roles/role_with_plugins/collection/module_utils']
    coll_dirs = list_collection_dirs(search_paths=collection_paths)
    assert isinstance(coll_dirs, MutableMapping)
    assert len(coll_dirs.keys()) == 1
    assert 'role_with_plugins' in coll_dirs
    assert len(coll_dirs['role_with_plugins'].keys()) == 1