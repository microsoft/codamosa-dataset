

# Generated at 2022-06-10 22:40:44.760195
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import tempfile
    import shutil
    import random
    import string

    class FakeOs(object):
        '''Fake class for os.'''
        def __init__(self):
            self.namespaces = set()

        def listdir(self, path):
            '''List dir in the fake os.'''
            if os.path.basename(path) == 'ansible_collections':
                return list(self.namespaces)
            return ['a.b']

        def mkdir(self, path):
            '''Make a dir in the fake os.'''
            (_, namespace, collection) = path.split(os.path.sep)
            if namespace in self.namespaces:
                return
            self.namespaces.add(namespace)


# Generated at 2022-06-10 22:40:51.736799
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test for default search paths
    coll_dirs = list(list_collection_dirs())
    assert len(coll_dirs) > 0
    for collection_dir in coll_dirs:
        assert isinstance(collection_dir, bytes)

    # Test with specific search path
    coll_dirs = list(list_collection_dirs(search_paths=['../']))
    assert len(coll_dirs) > 0
    for collection_dir in coll_dirs:
        assert isinstance(collection_dir, bytes)

    # Test with specific collection name
    coll_dirs = list(list_collection_dirs(coll_filter='ansible_collections.collections_path.tests'))
    assert len(coll_dirs) > 0
    for collection_dir in coll_dirs:
        assert isinstance

# Generated at 2022-06-10 22:41:02.825476
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = [os.path.join(os.getcwd(), 'plugins/test/data/collection_data')]
    coll_list = list(list_collection_dirs(test_paths))
    assert len(coll_list) == 2
    assert b"test_namespace.first" in coll_list
    assert b"test_namespace.second" in coll_list

    test_paths = [os.path.join(os.getcwd(), 'plugins/test/data/collection_data')]
    coll_list = list(list_collection_dirs(test_paths, "test_namespace.first"))
    assert len(coll_list) == 1
    assert b"test_namespace.first" in coll_list


# Generated at 2022-06-10 22:41:14.044477
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = []

    test_paths.append("/root/ansible_collections/")
    test_paths.append("/root/ansible_collections")
    test_paths.append("/root/ansible.collections")
    test_paths.append("/root/ansible.collections/")

    # Should only return valid paths
    search_paths = list(list_valid_collection_paths(search_paths=test_paths))
    assert len(search_paths) == 0

    # should return only 1 valid path, since /root/ansible_collections
    # exists and is a directory
    test_paths.append("/root/ansible_collections")

# Generated at 2022-06-10 22:41:21.287514
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import os

    dir1 = tempfile.mkdtemp()
    dir2 = tempfile.mkdtemp()
    dir3 = tempfile.mkdtemp()
    file1 = tempfile.NamedTemporaryFile()

    search_paths = [dir1, dir2, dir3, file1.name]
    search_paths_test = list(list_valid_collection_paths())
    for search_path in search_paths:
        assert search_path in search_paths_test

# Generated at 2022-06-10 22:41:24.985790
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths
    paths = list_valid_collection_paths(['/invalid/path', '/etc/ansible/ansible.cfg', '/usr/lib/ansible/collections'])
    assert len(paths) == 2
    assert '/etc/ansible/ansible.cfg' in paths
    assert '/usr/lib/ansible/collections' in paths

# Generated at 2022-06-10 22:41:33.644478
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    fake_dirs = (
        '/fake/dir01',
        '/fake/dir02',
        '/fake/dir03',
        '/fake/dir04/doesnotexist',
        '/fake/dir05',
    )

    # Testing with no input, expect an empty list
    assert list(list_valid_collection_paths()) == []

    # Testing with all dirs non existent, expect an empty list
    assert list(list_valid_collection_paths(fake_dirs)) == []

    # Testing with one dir non existent in the middle of the list
    fake_dirs = (
        '/fake/dir01',
        '/fake/dir02',
        '/fake/dir03',
        '/fake/dir04/doesnotexist',
        '/fake/dir05',
    )

    # Testing with no input, expect

# Generated at 2022-06-10 22:41:41.132316
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs

    import tempfile
    import shutil

    collection_root = tempfile.mkdtemp()
    search_paths = [collection_root]

# Generated at 2022-06-10 22:41:53.856112
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    import shutil
    from os.path import isdir, isfile
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    old_collection_paths = AnsibleCollectionConfig.collection_paths.copy()


# Generated at 2022-06-10 22:42:03.955480
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        # valid paths
        "/tmp",
        os.path.join(os.path.expanduser('~'), "test_collection_paths"),
        # invalid paths
        "testing/../../testing",  # relative paths
        "~/testing/../../testing",  # relative path with tilde
        "/doesnt/exist",
        "doesnt_exist"
    ]
    expected = [
        "/tmp",
        os.path.join(os.path.expanduser('~'), "test_collection_paths"),
    ]

    paths = list(list_valid_collection_paths(search_paths))

    assert len(paths) == len(expected)

    for path in paths:
        assert path in expected



# Generated at 2022-06-10 22:42:18.763041
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    :return:
    """

    # Test function - bad search paths
    search_paths = [
        'non-existing-path',
        'test/roles',
        'test/ansible_collections/bad/test.test'
    ]

    my_res = list_valid_collection_paths(search_paths=search_paths)
    assert len(list(my_res)) == 0

    # Test function - good search path
    search_paths = [
        'test/ansible_collections/good/test.test'
    ]

    my_res = list_valid_collection_paths(search_paths=search_paths)
    assert len(list(my_res)) == 1

    # Test function - good and

# Generated at 2022-06-10 22:42:29.085964
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_search_path = ['/tmp/collections/']
    test_coll_filter = 'namespace1.collection1'
    test_coll_dir = '/tmp/collections/ansible_collections/namespace1/collection1'

    file_mock = os.listdir
    os.listdir = lambda path: test_coll_filter.split('.') if path == '/tmp/collections/ansible_collections' else [test_coll_filter.split('.')[1]]
    is_collection_path_mock = is_collection_path
    is_collection_path = lambda p: p == test_coll_dir
    os.path.exists = lambda path: path == '/tmp/collections/ansible_collections'

# Generated at 2022-06-10 22:42:29.996228
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert '.' in list_valid_collection_paths()

# Generated at 2022-06-10 22:42:42.982577
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list()
    for _ in list_collection_dirs(search_paths=[os.path.abspath(os.path.join(os.path.dirname(__file__), 'list_collections'))]):
        result.append(_)
    assert len(result) == 0

    result = list()
    for _ in list_collection_dirs(search_paths=[os.path.abspath(os.path.join(os.path.dirname(__file__), 'list_collections')),
                                                os.path.abspath(os.path.join(os.path.dirname(__file__), 'list_collections_2'))]):
        result.append(_)
    assert len(result) == 12

# Generated at 2022-06-10 22:42:45.216954
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['no_such_path'])) == []
    assert list(list_valid_collection_paths(['../module_utils'])) == []

# Generated at 2022-06-10 22:42:51.437920
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['./test/unit/utils/list_collection_dirs/test_collection_path']
    expected = [
        b'./test/unit/utils/list_collection_dirs/test_collection_path/ansible_collections/my_namespace/my_collection/'
    ]
    result = list(list_collection_dirs(search_paths))

    assert expected == result

# Generated at 2022-06-10 22:42:52.708220
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()

# Generated at 2022-06-10 22:43:02.719959
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # empty list, return defaults
    paths = list(list_valid_collection_paths(search_paths=[]))

    assert len(paths) == 2

    # empty list, return defaults, with warning
    paths = list(list_valid_collection_paths(search_paths=[], warn=True))

    assert len(paths) == 2

    # existing path, with warning
    paths = list(list_valid_collection_paths(search_paths=[os.path.join(os.path.dirname(__file__), '..')], warn=True))

    assert len(paths) == 1


# Generated at 2022-06-10 22:43:08.568774
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = list_valid_collection_paths(['/does not exist', '/foo/bar'])
    assert collection_paths == []

    # maybe this test should be moved to test_config?
    collection_paths = list_valid_collection_paths(warn=False)
    assert collection_paths == [os.path.join(os.path.dirname(__file__), '..', '..', '..', 'plugins')]

# Generated at 2022-06-10 22:43:13.293225
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['doesnt_exist',
                    'doesnt_exist_either', ]

    for path in list_valid_collection_paths(search_paths, warn=False):
        assert False

    for path in list_valid_collection_paths(search_paths, warn=True):
        assert False



# Generated at 2022-06-10 22:43:40.224146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def test_collection_path_valid(coll_dir):
        assert isinstance(coll_dir, Path)
        ns = coll_dir.name
        coll = coll_dir.parent.name

        assert coll_dir.exists()
        assert coll_dir.is_dir()
        assert is_collection_path(coll_dir) is True

        # coll_dir should be a path to the collection under the namespace
        assert coll_dir.parent == ansible_coll_path / ns
        assert coll_dir.parent.parent == ansible_coll_path
        assert coll_dir.parent.parent.parent == ansible_coll_path.parent

        return ns, coll

    # create a collection and test it exists

# Generated at 2022-06-10 22:43:50.685817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.warning = lambda x: None  # suppress warning messages
    assert list(list_valid_collection_paths(['test/test_collections/good'])) == ['test/test_collections/good']
    assert list(list_valid_collection_paths(['test/test_collections/missing', 'test/test_collections/bad'])) == []
    assert list(list_valid_collection_paths(['test/test_collections/bad', 'test/test_collections/good'])) == ['test/test_collections/good']
    assert list(list_valid_collection_paths(['test/test_collections/missing', 'test/test_collections/good'])) == ['test/test_collections/good']

# Generated at 2022-06-10 22:43:57.020491
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test data
    collection_dir = '/tmp/test'
    namespace = 'awx'
    collection = 'awx_test'
    namespaced_collection = namespace + '.' + collection
    namespace_collection_path = os.path.join(collection_dir, namespace, collection)
    os.makedirs(namespace_collection_path)
    # Main logic
    collections = list(list_collection_dirs([collection_dir], namespaced_collection))
    assert collections == [namespace_collection_path]
    assert len(collections) == 1

    # tear down
    os.rmdir(namespace_collection_path)

# Generated at 2022-06-10 22:44:02.692151
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['/root/nonexistent'], warn=False)) == []
    assert list(list_valid_collection_paths(search_paths=['/etc/ansible'], warn=False)) == []
    assert list(list_valid_collection_paths(search_paths=[], warn=False)) == ['/usr/share/ansible/collections']



# Generated at 2022-06-10 22:44:14.709400
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os
    import sys

    # setup a temp dir for testing
    tmp_dir = tempfile.mkdtemp()
    tmp_coll_dir = os.path.join(tmp_dir, 'ansible_collections')
    tmp_namespace_dir = os.path.join(tmp_coll_dir, 'namespace')
    tmp_collection_dir = os.path.join(tmp_namespace_dir, 'collection')

    # populate temp dir with necessary directories
    os.makedirs(tmp_collection_dir)
    os.makedirs(os.path.join(tmp_dir, 'not_a_coll_dir'))

    # make sure temp dir is in the search path list, windows requires the + to join paths
    search_paths = [tmp_dir]

   

# Generated at 2022-06-10 22:44:24.624249
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test for None
    assert list(list_valid_collection_paths()) == []

    # test for single valid path
    paths = ['here/ansible']
    actual_paths = list(list_valid_collection_paths(search_paths=paths))
    assert actual_paths == paths

    # test for valid and invalid path
    paths = ['here/ansible', 'there/playbooks']
    actual_paths = list(list_valid_collection_paths(search_paths=paths))
    assert actual_paths == paths



# Generated at 2022-06-10 22:44:31.473729
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp'])) == ['/tmp']
    assert list(list_valid_collection_paths(['/tmp', '/nonexistent'])) == ['/tmp']
    assert list(list_valid_collection_paths(['/tmp', '/nonexistent', '/nonexistent2'])) == ['/tmp']

# Generated at 2022-06-10 22:44:39.755099
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Ensure collection_paths default to defaults
    paths = list_valid_collection_paths()
    assert paths == AnsibleCollectionConfig.collection_paths
    # when search_path specified, only display warning for invalid paths, not the defaults
    paths = list_valid_collection_paths(search_paths=['/foo/bar', '/baz/buz'], warn=True)
    assert paths == []
    # Ensure that the default path does not raise a warning
    paths = list_valid_collection_paths(warn=True)
    assert paths == AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-10 22:44:49.770136
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test various inputs to validate the function returns expected directories
    """

    # Test with empty non-existent paths, should return nothing
    result = list(list_collection_dirs(['/path/does/not/exist/']))
    assert len(result) == 0, 'No items should be returned for an empty path'

    # Test with a valid search_path and collection, should return one item
    result = list(list_collection_dirs([os.path.join(os.path.dirname(__file__), 'data', 'collections')], 'awx.awx'))
    assert len(result) == 1, 'One item should be returned'

    # Test with a valid search_path and namespace, should return multiple items

# Generated at 2022-06-10 22:44:54.773721
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # mocked data
    test_paths = [os.path.dirname(__file__)]

    # tests with data
    assert len(list(list_collection_dirs(test_paths))) == 1
    assert len(list(list_collection_dirs(test_paths, coll_filter='unit_test'))) == 1

# Generated at 2022-06-10 22:45:30.421634
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/tmp"])) == ["/tmp"]
    assert list(list_valid_collection_paths(["/tmp", "/tmp2"])) == ["/tmp", "/tmp2"]
    assert list(list_valid_collection_paths(["/tmp", "/tmp2", ""])) == ["/tmp", "/tmp2"]


# Generated at 2022-06-10 22:45:41.447380
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture = 'ansible_collections/ansible_namespace/collection_name'
    fixture_path = os.path.join(os.path.expanduser('~'),
                                '.ansible/collections',
                                fixture)
    os.makedirs(fixture_path)
    try:
        next(list_collection_dirs(search_paths=[fixture_path]))
    finally:
        os.rmdir(fixture_path)
        fixture_namespace_path = os.path.dirname(fixture_path)
        os.rmdir(fixture_namespace_path)
        fixture_collections_path = os.path.dirname(fixture_namespace_path)
        os.rmdir(fixture_collections_path)

# Generated at 2022-06-10 22:45:48.064496
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['test/unit/utils']
    results = list_collection_dirs(search_paths)
    assert len(list(results)) == 5

    results = list_collection_dirs(search_paths, 'dummy')
    assert len(list(results)) == 2

    results = list_collection_dirs(search_paths, 'dummy.no_manifest')
    assert len(list(results)) == 1

# Generated at 2022-06-10 22:45:49.114824
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths()

# Generated at 2022-06-10 22:45:58.856122
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the collections loader in various configurations, including
    hidden directories (prefixed with '.')
    """

    test_dir = os.path.dirname(os.path.abspath(__file__))
    coll_dir = os.path.join(test_dir, 'test_collections')
    assert os.path.exists(coll_dir)

    # test ignoring hidden directories
    collections = [x for x in list_collection_dirs([coll_dir])]
    assert len(collections) == 2

    # test each collection
    collections = [x for x in list_collection_dirs([coll_dir], 'ns_coll')]
    assert len(collections) == 1
    assert os.path.basename(collections[0]) == 'ns_coll'


# Generated at 2022-06-10 22:46:08.758984
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    file_dir = os.path.dirname(os.path.abspath(__file__))
    coll_dir = os.path.join(file_dir, os.pardir, 'ansible_collections')
    tmp_coll = tempfile.mkdtemp()

    search_paths = [coll_dir, tmp_coll]

    # Create things, they should not be returned as part of the iter
    os.mkdir(os.path.join(tmp_coll, 'foo.bar'))
    os.mkdir(os.path.join(tmp_coll, 'some_namespace'))
    os.mkdir(os.path.join(tmp_coll, 'some_namespace', 'some_collection'))

# Generated at 2022-06-10 22:46:18.383224
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.parsing.dataloader import DataLoader

    # Travis CI, latest master from stable-2.9
    search_paths = ['/etc/ansible/collections', '/home/travis/build/ansible/ansible/lib/ansible/collections']

    collection_paths = [p for p in list_collection_dirs(search_paths) if p.endswith(b'ansible_collections/foo_namespace/bar_collection')]

    assert len(collection_paths) == 3
    assert collection_paths[0] == b'/etc/ansible/collections/ansible_collections/foo_namespace/bar_collection'

# Generated at 2022-06-10 22:46:28.708069
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import collection_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    display.verbosity = 4

    mock_collections = [
        ("awx", "awx", "ansible_collections.awx.awx"),
        ("awx", "awx_core", "ansible_collections.awx.core"),
    ]

    c = CLI(args=[])

    tmp_dir = tempfile.mkdtemp()
    b_tmp_dir = to_bytes(tmp_dir, errors='surrogate_or_strict')


# Generated at 2022-06-10 22:46:38.430199
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from os.path import isdir
    from tempfile import mkdtemp, mkstemp

    # test empty input
    test_paths = ()
    expected_paths = ()
    assert (list_valid_collection_paths(test_paths) == expected_paths)

    # test valid paths
    test_paths = (
        "/fake/path/one",
        "/fake/path/two",
        "/fake/path/three",
    )
    expected_paths = (
        "/fake/path/one",
        "/fake/path/two",
        "/fake/path/three",
    )
    for i in list_valid_collection_paths(test_paths):
        assert(i in test_paths)

    # test non-existing paths

# Generated at 2022-06-10 22:46:43.076743
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    curr_path = os.path.dirname(__file__)
    test_path = os.path.join(curr_path, 'test_collection_path')

    p = list_valid_collection_paths([test_path])
    assert next(p) == test_path



# Generated at 2022-06-10 22:47:56.706301
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for no search paths supplied
    assert list(list_valid_collection_paths()) == [b'/etc/ansible/collections']
    assert list(list_valid_collection_paths([b'/etc/ansible/collections'])) == [b'/etc/ansible/collections']
    assert list(list_valid_collection_paths([b'/etc/ansible/collections', b'/etc/ansible/collections'])) == [b'/etc/ansible/collections']
    assert list(list_valid_collection_paths([b'/etc/ansible/collections', b'/nonexistent'])) == [b'/etc/ansible/collections']

# Generated at 2022-06-10 22:48:03.349840
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_text

    paths = ['/tmp/doesnotexist', '/tmp/doesnotexist2', '/tmp/foo', '/tmp/foo2']

    with open('/tmp/foo/ansible_collections', 'w'):
        pass

    with open('/tmp/foo2/ansible_collections', 'w'):
        pass

    l = list(list_valid_collection_paths(search_paths=paths))
    assert l == [to_text(x) for x in ['/tmp/foo', '/tmp/foo2']]

    import os
    os.unlink('/tmp/foo/ansible_collections')
    os.unlink('/tmp/foo2/ansible_collections')
    os.rmdir('/tmp/foo')
   

# Generated at 2022-06-10 22:48:10.965817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    p1 = "/bar/foo"
    p2 = "/baz/foo"
    p3 = "/baz/bar"
    search_paths = [p1, p2, p3]
    ansible_cfg = os.path.join(p1, "ansible.cfg")
    results = list_valid_collection_paths(search_paths, warn=False)
    assert results == [p2, p3]

# Generated at 2022-06-10 22:48:13.031078
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['test'], warn=False) == ()


# Generated at 2022-06-10 22:48:17.544963
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert next(list_valid_collection_paths(), None)
    assert next(list_valid_collection_paths([]), None)
    assert next(list_valid_collection_paths(search_paths=[os.path.dirname(__file__)]), None)
    assert next(list_valid_collection_paths(search_paths=[os.path.dirname(__file__)], warn=True), None)

# Generated at 2022-06-10 22:48:27.960294
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.constants as C
    cur_search_path = C.DEFAULT_COLLECTIONS_PATHS[:]

    # run with defaults
    assert list(list_collection_dirs())

    # run with empty path list
    assert list(list_collection_dirs([]))

    # run with non-existent paths
    assert list(list_collection_dirs(['/tmp/non-existent'])) == []

    # run with non-existent and existing paths
    assert list(list_collection_dirs(['/tmp/non-existent', '/usr'])) == []

    # run with existing paths
    assert list(list_collection_dirs(['/usr'])) == []

    # run with existing paths
    assert list(list_collection_dirs(['/etc'])) == []

    # run with existing paths

# Generated at 2022-06-10 22:48:38.401763
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp/foo']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 1
    assert valid_paths[0] == '/tmp/foo'

    search_paths = ['/tmp/foo', '/tmp/bar']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 2
    assert valid_paths == ['/tmp/foo', '/tmp/bar']

    search_paths = ['/tmp/foo', '/tmp/bar', '/tmp/baz']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 3
    assert valid_

# Generated at 2022-06-10 22:48:46.885042
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test default configuration
    path_list = list(list_valid_collection_paths())
    assert len(path_list) > 0

    # test an additional path
    import tempfile
    path = tempfile.mkdtemp(prefix="test_ansible_collections.")
    path_list = list(list_valid_collection_paths([path]))
    assert len(path_list) > 0
    assert path in path_list

    # test a path that does not exist
    path = tempfile.mkdtemp(prefix="test_ansible_collections.")
    os.rmdir(path)
    path_list = list(list_valid_collection_paths([path]))
    assert len(path_list) == 0

    # test an invalid path

# Generated at 2022-06-10 22:48:58.796930
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.testing.silence import silence_warnings, SilenceCapturedWarnings

    def fake_listdir(path):
        return [
            'ansible.builtin',
            'ansible.netcommon',
            'ansible.posix',
            'ansible.module_utils.network.common.utils',
            'ansible.module_utils.network.common.parsegen',
            'ansible.module_utils.network.common.cfg',
            'ansible.module_utils.network.common.parsing',
        ]
    def fake_isdir(path):
        return True


# Generated at 2022-06-10 22:49:04.806097
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [os.path.join(os.path.dirname(__file__), '..', 'data', 'collections')]
    dir_list = list(list_collection_dirs(search_paths))
    assert len(dir_list) == 2
    assert os.path.basename(dir_list[0]) == 'a'
    assert os.path.basename(dir_list[1]) == 'b'