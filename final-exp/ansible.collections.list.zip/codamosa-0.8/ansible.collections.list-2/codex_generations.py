

# Generated at 2022-06-10 22:40:45.449302
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # Create temporary collection directory
    tmpdir = tempfile.mkdtemp()
    tmpdir2 = os.path.join(tmpdir, "ansible_collections")
    os.mkdir(tmpdir2)
    tmpdir3 = os.path.join(tmpdir2, "foobar")
    os.mkdir(tmpdir3)
    tmpdir4 = os.path.join(tmpdir3, "barbaz")
    os.mkdir(tmpdir4)

    # Create a dummy collection in temporary directory
    with open(os.path.join(tmpdir4, "galaxy.yml"), 'a') as galaxy_file:
        galaxy_file.write("namespace: foobar\nname: barbaz")

    paths = [tmpdir]

# Generated at 2022-06-10 22:40:54.264817
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import os

    base_dir = tempfile.mkdtemp()

    coll_dir = os.path.join(base_dir, 'ansible_collections', 'test_coll', 'mycollection')
    os.makedirs(coll_dir)
    f_fp = os.path.join(coll_dir, '__init__.py')
    with open(f_fp, 'w') as f:
        f.write('#')
    f_fp = os.path.join(coll_dir, 'plugins', '__init__.py')
    with open(f_fp, 'w') as f:
        f.write('#')
    f_fp = os.path.join(coll_dir, 'plugins', 'module_utils', '__init__.py')

# Generated at 2022-06-10 22:41:00.325943
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=[]))
    assert list(list_valid_collection_paths())
    assert list(list_valid_collection_paths(search_paths=['/does/not/exist'])) == []
    assert list(list_valid_collection_paths(search_paths=['/etc/ansible/collections']))



# Generated at 2022-06-10 22:41:06.266159
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # list_collection_dirs()
    # list_collection_dirs(['/a/b/c', '/d/e/f'])
    # list_collection_dirs(coll_filter='my_collection')
    # list_collection_dirs(coll_filter='my_namespace.my_collection')
    return

# Generated at 2022-06-10 22:41:13.778573
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from os.path import dirname, abspath, exists, isdir
    from ansible.module_utils.common.collections import list_valid_collection_paths

    parent_dir = dirname(dirname(abspath(__file__)))
    for path in list_valid_collection_paths([parent_dir]):
        assert exists(path)
        assert isdir(path)

    for path in list_valid_collection_paths(['/does/not/exist']):
        assert False


# Generated at 2022-06-10 22:41:24.485049
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common._collections_compat import MutableMapping
    import tempfile, shutil


# Generated at 2022-06-10 22:41:32.125217
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.config.manager import ConfigManager
    from ansible.constants import CONFIG_FILE_PATH
    config_manager = ConfigManager(CONFIG_FILE_PATH, config_file=dict(), dependencies=None)
    config_manager._get_settings()
    config_manager.settings.config_data['collections_paths'] = ["/tmp/collections", "/bad/path/does/not/exist"]
    config_manager._init_config_data()
    paths = list_valid_collection_paths(warn=True)
    assert len(paths) == 1
    paths = list_valid_collection_paths(warn=False)
    assert len(paths) == 2

# Generated at 2022-06-10 22:41:38.180959
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp/foo', 'invalid_path'])) == ['/tmp/foo']
    assert list(list_valid_collection_paths(['/tmp/foo', 'invalid_path'], warn=False)) == ['/tmp/foo']
    assert list(list_valid_collection_paths(['/tmp/foo', 'invalid_path'], warn=True)) == ['/tmp/foo']
    assert list(list_valid_collection_paths([])) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-10 22:41:48.855617
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # create a temporary directory
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # create a namespace and collection in the tmpdir
    import shutil
    ns = os.path.join(tmpdir, 'ansible_collections', 'foo')
    os.makedirs(ns)
    shutil.copytree(os.path.join(os.path.dirname(__file__), '../../../../plugins'),
                                 os.path.join(ns, 'mycoll'))

    # get a list of the dirs
    dirs = list_collection_dirs([tmpdir])
    assert tmpdir in [os.path.dirname(d) for d in dirs]

    # clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-10 22:41:56.478065
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # for tests we use the collection path name of `my_coll_root`
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'unit', 'test', 'files', 'test_collections')

    collections = list(list_collection_dirs([test_path]))
    assert len(collections) == 3, "Collections found %s" % collections

    collections = list(list_collection_dirs([test_path], 'myfirst.myfirst_coll'))
    assert len(collections) == 1, "Collections found %s" % collections

    collections = list(list_collection_dirs([test_path], 'myfirst'))
    assert len(collections) == 2, "Collections found %s" % collections



# Generated at 2022-06-10 22:42:14.267797
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test default root
    list_valid_collection_paths()

    # Test empty list
    list_valid_collection_paths([])

    # Test wrong path
    list_valid_collection_paths(['/usr/share/my_collections'])

    # Test good path
    list_valid_collection_paths(['/usr/share/ansible/collections'])

    # Test bad path + good path
    list_valid_collection_paths(['/usr/share/my_collections', '/usr/share/ansible/collections'], warn=False)

    # Test bad path + good path + default path
    list_valid_collection_paths(['/usr/share/my_collections', '/usr/share/ansible/collections'], warn=True)



# Generated at 2022-06-10 22:42:25.471189
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with a few valid paths
    valid_paths = [
        '/etc/ansible/collections',
        '/my/collections/path1',
        '/another/collections/folder',
    ]

    # Iterate over result, just to be sure it is a generator
    for valid_path in list_valid_collection_paths(valid_paths):
        """ :type valid_path: str """
        assert valid_path in valid_paths

    # Test with a few invalid paths
    invalid_paths = [
        '/etc/ansible/collections',
        '/my/collections/path1',
        '/another/collections/folder',
        '/does/not/exists',
        '/path/does/not/exists'
    ]

    # Iterate over result, just to be sure it is a

# Generated at 2022-06-10 22:42:28.674772
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ["/fake/path", "~/fake_home", "/fake/path2"]
    ret = ['/fake/path', '/fake/path2']
    assert list_valid_collection_paths(paths) == ret



# Generated at 2022-06-10 22:42:41.010858
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'sanity', 'code', 'plugins', 'modules')
    search_paths = [path]

    for collection in list_collection_dirs(search_paths):
        assert os.path.exists(collection)
        assert os.path.isdir(collection)


if __name__ == "__main__":
    collections = {
        'foo.bar': '/path/to/collections'
    }

    if len(sys.argv) > 1:
        search_paths = sys.argv[1:]
    else:
        search_paths = collections

    for collection in list_collection_dirs(search_paths):
        print(collection)

# Generated at 2022-06-10 22:42:53.026025
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        'test/units/collections/ansible_collections/ansible',
        'test/units/collections/ansible_collections/ansible/test_ns'
    ]

    cld_result = set(list_collection_dirs(search_paths=search_paths))
    expected = set((
        'test/units/collections/ansible_collections/ansible/test_coll',
        'test/units/collections/ansible_collections/ansible/test_coll2',
        'test/units/collections/ansible_collections/ansible/test_coll3',
        'test/units/collections/ansible_collections/ansible/test_ns/test_coll'
    ))

    # all correct results

# Generated at 2022-06-10 22:43:00.260487
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == []
    assert len(list(list_valid_collection_paths(['/dev/null']))) == 0
    assert len(list(list_valid_collection_paths(['/dev/null', '/dev/null']))) == 0
    assert len(list(list_valid_collection_paths(['/dev/null', '/dev']))) == 1
    assert len(list(list_valid_collection_paths([]))) > 0

# Generated at 2022-06-10 22:43:10.048319
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import MockCollectionFinder
    from ansible.utils.plugin_docs import get_docstring

    mcf = MockCollectionFinder()
    mcf.reset_mocks()

    coll_paths = mcf.collection_paths
    coll_filter = None
    coll_dirs = list(list_collection_dirs(coll_paths, coll_filter))

    assert len(coll_dirs) == 3
    assert coll_dirs[0].endswith('my_namespace.my_collection')
    assert coll_dirs[1].endswith('your_namespace.your_collection1')
    assert coll_dirs[2].endswith('your_namespace.your_collection2')

    # test filter on namespace
    coll_filter = 'your_namespace'

# Generated at 2022-06-10 22:43:12.704584
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_coll = list_collection_dirs(coll_filter='ansible.posix')
    assert len(list(list_coll)) == 1

# Generated at 2022-06-10 22:43:22.337651
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with a valid path
    search_paths = ['/does_not_exist', '/usr/share']
    assert 'usr/share' in list_valid_collection_paths(search_paths, True)
    # Test with an invalid path (which does not exist)
    assert '/does_not_exist' not in list_valid_collection_paths(search_paths, True)
    # Test with a valid path, which isn't a directory
    search_paths = ['/etc/passwd']
    assert '/etc/passwd' not in list_valid_collection_paths(search_paths, True)

# Generated at 2022-06-10 22:43:29.030410
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """

    # Setup environment
    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = "/tmp/invalid"

    assert [y for y in list_valid_collection_paths(warn=True)] == []
    assert [y for y in list_valid_collection_paths()] == ['/usr/share/ansible/collections']


# Generated at 2022-06-10 22:43:52.647560
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['/foo/bar'])) == ['/foo/bar']
    # append another path
    assert list(list_valid_collection_paths(search_paths=['/foo/bar'])) == ['/foo/bar']
    # filter out non-existing paths
    assert list(list_valid_collection_paths(search_paths=['/foo/bar', '/does/not/exist'])) == ['/foo/bar']
    # filter out non-directories
    assert list(list_valid_collection_paths(search_paths=['/foo/bar', '/etc/passwd'])) == ['/foo/bar']

# Generated at 2022-06-10 22:43:58.920985
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    filename = "/tmp/ansible.cfg"
    search_paths = [filename]
    # file does not exist
    for s in list_valid_collection_paths(search_paths, True):
        raise AnsibleError("File does not exist, but should be filtered out")

    # file exists but it is not a directory
    with open(filename, 'w') as f:
        f.write("test")

    for s in list_valid_collection_paths(search_paths, True):
        raise AnsibleError("File is not a directory, but should be filtered out")

    # create directory that exists
    os.rmdir(filename)
    os.mkdir(filename)

# Generated at 2022-06-10 22:44:03.279460
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(['./test-resources.nosuchpath'])) == []
    assert list(list_valid_collection_paths(['./test-resources.bad_dir'])) == []
    assert list(list_valid_collection_paths(['./test-resources'])) == ['./test-resources']

# Generated at 2022-06-10 22:44:15.334604
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile
    from ansible.config.data import ConfigData
    from ansible.config.manager import ConfigManager

    coll_dirs = {}
    for d in ['namespace1', 'namespace2', 'namespace3']:
        coll_dirs[d] = {}
        for c in ['collection1', 'collection2', 'collection3']:
            coll_dirs[d][c] = tempfile.mkdtemp(prefix='%s.%s' % (d, c))

    b_config_data = to_bytes(ConfigData())
    b_config_manager = to_bytes(ConfigManager(b_config_data))

# Generated at 2022-06-10 22:44:28.675985
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    try:
        list_valid_collection_paths([1])
        assert False, "list_valid_collection_paths did not fail with bad type"
    except TypeError:
        pass

    # returns empty list
    assert list(list_valid_collection_paths([])) == []

    # returns defaults
    assert list(list_valid_collection_paths()) == [
        "/usr/share/ansible/collections",
        "/etc/ansible/collections"
    ]

    # returns defaults and first path
    assert list(list_valid_collection_paths(['/home/user'])) == [
        "/usr/share/ansible/collections",
        "/etc/ansible/collections",
        "/home/user"
    ]

# Generated at 2022-06-10 22:44:30.385897
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = []
    for dir in list_collection_dirs():
        collections.append(dir)
    assert collections

# Generated at 2022-06-10 22:44:37.995786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = ['/tmp', '/tmp/path/to/file', "/tmp/path/to/directory", "/tmp/path/to/non/existent"]
    expected = ["/tmp/path/to/directory"]
    found = list(list_valid_collection_paths(path_list))
    assert found == expected


    # test the default paths from collection_config
    found = list(list_valid_collection_paths([]))
    assert len(found) > 0


# Generated at 2022-06-10 22:44:44.848844
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(search_paths=[])) == []
    assert list(list_valid_collection_paths(search_paths=['./lib/ansible/my_collections'])) == ['./lib/ansible/my_collections']
    assert list(list_valid_collection_paths(search_paths=['./lib/ansible/my_collections/'])) == ['./lib/ansible/my_collections/']
    assert list(list_valid_collection_paths(search_paths=['./lib/ansible/my_collections/..'])) == []

# Generated at 2022-06-10 22:44:55.613970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import unittest

    class TestListCollectionDirs(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_list_collection_dirs(self):
            import os
            import tempfile

            # set up temp collection paths for test
            (fd, coll_path_one) = tempfile.mkstemp(prefix='ansible_collection_')
            (fd, coll_path_two) = tempfile.mkstemp(prefix='ansible_collection_')
            (fd, coll_path_three) = tempfile.mkstemp(prefix='ansible_collection_')
            (fd, coll_path_four) = tempfile.mkstemp(prefix='ansible_collection_')

            # temporary paths to use for both testing and cleanup later
           

# Generated at 2022-06-10 22:44:59.964205
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import get_collection_roots

    list_valid_collection_paths()
    list_valid_collection_paths(warn=True)

    roots = list(get_collection_roots())
    assert roots == list(list_valid_collection_paths(search_paths=['/foo/bar', '/tmp', '/etc/ansible/roles'], warn=True))

# Generated at 2022-06-10 22:45:40.082664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    # create a test collection
    coll_base = tempfile.mkdtemp()
    coll_path = os.path.join(coll_base, 'ansible_collections')
    os.mkdir(coll_path)
    os.mkdir(os.path.join(coll_path, 'namespace'))
    os.mkdir(os.path.join(coll_path, 'namespace', 'collection1'))
    coll_paths = [coll_base]

    # no filter, return all
    dirs = list(list_collection_dirs(coll_paths))
    assert len(dirs) == 1
    assert dirs[0].endswith(os.path.join('namespace', 'collection1'))

    # filter namespace, return all of it
    d

# Generated at 2022-06-10 22:45:50.982687
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # TODO: Add test case when directory 'my_collection_A' exists without '__init__.py' file
    import os
    import tempfile

    test_coll_root_dir = tempfile.mkdtemp()
    # create collection 'my_collection_A'
    os.makedirs(os.path.join(test_coll_root_dir, 'ansible_collections', 'test_namespace', 'my_collection_A'))
    with open(os.path.join(test_coll_root_dir, 'ansible_collections', 'test_namespace', 'my_collection_A', '__init__.py'), 'w') as f:
        f.write('from ansible_collections.test_namespace.my_collection_A.plugins.module_utils import *')
    # create collection 'my

# Generated at 2022-06-10 22:45:53.284996
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    res = list_valid_collection_paths(search_paths=["/fake/path1", "fake_path2"])
    assert res == []

# Generated at 2022-06-10 22:46:00.377987
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    search_paths.append(os.path.join(os.getcwd(), "test_collections"))
    search_paths.append(os.path.join(os.getcwd(), "test_collections_not_exists"))
    search_paths.append(os.path.join(os.getcwd(), "test_collections_not_dir"))
    valid_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert valid_paths == [os.path.join(os.getcwd(), "test_collections")]


# Generated at 2022-06-10 22:46:04.102881
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Set up test fixture
    display.verbosity = 4

    # Exercises
    paths = list(list_valid_collection_paths(search_paths=None, warn=False))

    # Verify
    assert len(paths) > 1

    # Clean off
    display.verbosity = 0



# Generated at 2022-06-10 22:46:14.977148
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.constants import COLLECTIONS_PATHS as DEFAULT_PATHS
    from ansible.collections import COLLECTIONS_PATHS as FULL_PATHS
    for path in DEFAULT_PATHS:
        assert path in FULL_PATHS

    assert len(list(list_collection_dirs())) == len(DEFAULT_PATHS)
    assert len(list(list_collection_dirs(search_paths=FULL_PATHS))) == len(DEFAULT_PATHS)
    assert len(list(list_collection_dirs(search_paths=FULL_PATHS + ["/tmp"]))) == len(DEFAULT_PATHS) + 1
    assert len(list(list_collection_dirs(coll_filter="ansible_collections"))) == 1
   

# Generated at 2022-06-10 22:46:23.008471
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    display.verbosity = 4
    assert list(list_collection_dirs(warn=True)) == []

    # should return a single collection under the default paths
    assert list(list_collection_dirs(coll_filter='ansible.builtin')) == []

    #  should return a single collection under the default paths
    assert list(list_collection_dirs(coll_filter='ansible_collections.somespace.somecollection')) == []

# Generated at 2022-06-10 22:46:33.255314
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    expected = [u'ansible_collections/test_ns/test_coll', u'ansible_collections/test_ns/test_coll2', u'ansible_collections/test_ns', u'ansible_collections/another_ns/another_coll', u'ansible_collections/other_ns']

    assert expected == list(list_collection_dirs(search_paths=[u'../../lib/ansible/test/units/modules/utils', u'../../lib/ansible/test/units/modules/utils/ansible_collections'],
                                                 coll_filter=None))

    expected = [u'ansible_collections/test_ns/test_coll']


# Generated at 2022-06-10 22:46:36.711693
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) is not None
    assert list_valid_collection_paths(['fake'], warn=True) is not None
    assert list_valid_collection_paths(['fake'], warn=False) is not None

# Generated at 2022-06-10 22:46:39.161977
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dir = list_collection_dirs(search_paths=['/usr/share/ansible/'])

    assert(coll_dir is not None)

# Generated at 2022-06-10 22:47:51.893977
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    b_coll_root = to_bytes(tempfile.mkdtemp())


# Generated at 2022-06-10 22:47:54.536455
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list(list_collection_dirs(search_paths=['/tmp']))

    assert len(coll_dirs) == 0

# Generated at 2022-06-10 22:48:00.473814
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path1 = '/path/to/not/existing/'
    path2 = './not_existing_path'

    test_paths = [path1, path2]

    # Test with a path that does not exist
    result = list(list_valid_collection_paths(test_paths))
    assert result == []

    test_paths = []

    # Test with default configuration that does not exist
    result = list(list_valid_collection_paths(test_paths))
    assert result == []


# Generated at 2022-06-10 22:48:13.087592
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from distutils.version import LooseVersion
    from importlib import util as import_util
    from shutil import rmtree

    import pytest

    from ansible import context

    import ansible.module_utils.six as six

    try:
        import ansible_collections
    except ImportError:
        pass

    search_paths = []

    # the following loop is based on the logic in ansible.__init__.__init__()
    old_search_paths = context.CLIARGS.get('collections_paths')
    if old_search_paths is None:
        # ensure that we don't error if the config has not been moved
        old_search_paths = list(context.CLIARGS.get('search_paths'))


# Generated at 2022-06-10 22:48:21.525991
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert [val for val in list_valid_collection_paths(['../tests'])] == ['../tests']
    assert [val for val in list_valid_collection_paths(['../tests', '../tests/data'])] == ['../tests', '../tests/data']
    assert [val for val in list_valid_collection_paths(['../tests', '../tests/data'], True)] == ['../tests', '../tests/data']
    assert [val for val in list_valid_collection_paths(['../tests_does_not_exist', '../tests/data'])] == ['../tests/data']
    assert [val for val in list_valid_collection_paths(['../README.md'])] == []


# Generated at 2022-06-10 22:48:22.672576
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # WIP TODO
    pass

# Generated at 2022-06-10 22:48:25.458043
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'galaxy' in list(list_collection_dirs(search_paths=['test/utils/fixtures'], coll_filter='galaxy.foo'))

# Generated at 2022-06-10 22:48:35.029518
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=None)) == ['../collections', './collections', '/etc/ansible/collections']
    assert list(list_valid_collection_paths(search_paths=['~/foo', '~/bar'])) == ['~/foo', '~/bar', '../collections', './collections', '/etc/ansible/collections']
    assert list(list_valid_collection_paths(search_paths=['~/foo', '~/bar'], warn=True)) == ['~/foo', '~/bar', '../collections', './collections', '/etc/ansible/collections']

# Generated at 2022-06-10 22:48:40.789590
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    export_paths = [
        'test_path_1',
        'test_path_2',
        'test_path_3',
        'test_path_4'
    ]

    path_list = list_valid_collection_paths(search_paths=export_paths, warn=True)

    assert list(path_list) == export_paths

# Generated at 2022-06-10 22:48:48.220882
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    test_collections_root = tempfile.mkdtemp(prefix='ansible_collections_')
    test_collections_root_b = to_bytes(test_collections_root, errors='surrogate_or_strict')

    test_collection_dirs = {
        'ns1': {
            'coll1': tempfile.mkdtemp(prefix='ns1.coll1.', dir=test_collections_root_b),
            'coll2': tempfile.mkdtemp(prefix='ns1.coll2.', dir=test_collections_root_b),
        },
        'ns2': {
            'coll3': tempfile.mkdtemp(prefix='ns2.coll3.', dir=test_collections_root_b),
        },
    }

    test_col