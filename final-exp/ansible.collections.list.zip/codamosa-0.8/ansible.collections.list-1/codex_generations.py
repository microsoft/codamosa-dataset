

# Generated at 2022-06-10 22:40:37.621126
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dir = list_collection_dirs()
    assert len(coll_dir) > 0

# Generated at 2022-06-10 22:40:47.653913
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test for function list_valid_collection_paths"""
    # check empty path
    paths = list(list_valid_collection_paths())
    assert len(paths) > 0, 'Should be at least one default collection path'

    # check wrong path
    paths = list(list_valid_collection_paths(['/some/wrong/path']))
    assert len(paths) == 0, 'Should be 0 paths if all are invalid'

    # check valid path
    valid_path = list(list_valid_collection_paths(['/tmp']))
    assert len(valid_path) == 1, 'Should be just one valid path'
    assert valid_path[0] == '/tmp', 'Should be just one valid path'

    # check both valid and invalid path

# Generated at 2022-06-10 22:40:57.516549
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil
    import sys

    test_path = tempfile.mkdtemp(prefix="ansible-test_collections_path-")
    collections_path = ansible_collections_path = os.path.join(test_path, 'ansible_collections')
    os.mkdir(ansible_collections_path)


# Generated at 2022-06-10 22:41:01.606970
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():  # noqa
    valid_paths = list(list_valid_collection_paths(['data/collection_search_paths/valid1', 'data/collection_search_paths/valid2']))

    assert len(valid_paths) == 2

# Generated at 2022-06-10 22:41:08.427759
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    import shutil
    import tempfile
    import os

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-10 22:41:20.056014
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_data = [
        ('/foo/bar', True, True, True),
        ('/foo/bar', False, False, False),
        ('/foo/bar', False, True, False),
        ('/foo/bar', True, False, True),
    ]

    class FakeFile:

        def __init__(self, exists, directory):
            self.exists = exists
            self.directory = directory

    for path, exists, directory, result in test_data:

        fobj = FakeFile(exists, directory)

# Generated at 2022-06-10 22:41:26.250127
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    tmp_dir = tempfile.mkdtemp()
    assert list_collection_dirs(search_paths=[tmp_dir]) == []

    tmp_dir2 = tempfile.mkdtemp()
    assert list_collection_dirs(search_paths=[tmp_dir, tmp_dir2]) == []

    os.makedirs(os.path.join(tmp_dir, 'ansible_collections', 'namespace', 'collection', 'action_plugins'))
    assert list_collection_dirs(search_paths=[tmp_dir]) == [os.path.join(tmp_dir, 'ansible_collections', 'namespace', 'collection')]


# Generated at 2022-06-10 22:41:34.366452
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import Mock

    test_path = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, os.path.pardir, 'test/resources/collections')

    mock_env = {
        'ANSIBLE_COLLECTIONS_PATHS': test_path,
    }

# Generated at 2022-06-10 22:41:46.389631
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list(list_valid_collection_paths(['/tmp/doesnotexist']))
    # search paths should always be prefixed with ansible_collections
    coll_root = os.path.join('/tmp', 'ansible_collections')

# Generated at 2022-06-10 22:41:51.475612
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=["/ansible/collections"])) == ["/ansible/collections"]
    assert list(list_valid_collection_paths(search_paths=["/ansible/nocollections"])) == []



# Generated at 2022-06-10 22:42:10.087940
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # The first run should warn us that the configured path does not exist
    search_paths = [
        '/etc/ansible/ansible_collections/test1',
        '/etc/ansible/ansible_collections/test2'
    ]
    search_paths_list = list_valid_collection_paths(search_paths, True)
    for path in search_paths_list:
        assert path in search_paths

    # The second run should use the default path.
    search_paths_list = list_valid_collection_paths(None, False)
    assert search_paths_list is not None

# Generated at 2022-06-10 22:42:18.145881
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # patch the environment so that the package is installed in a fixed location
    # instead of the users home directory
    with patch.dict("os.environ", ANSIBLE_COLLECTIONS_PATHS="{0}/ansible_collections_dir".format(os.getcwd())):
        # remove any existing/leftover test directories
        shutil.rmtree("ansible_collections_dir", True)

        # test with no collection_paths directory, should return empty list
        assert list_collection_dirs() == list()

        # create a directory for collection_paths
        os.makedirs("ansible_collections_dir")

        # test with empty collection_paths directory, should return empty list
        assert list_collection_dirs() == list()

        # create a test collection in the collection_paths directory


# Generated at 2022-06-10 22:42:25.298660
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible.plugins.filter.collection_array import get_collection_array

    for collection_dir in list_collection_dirs():
        assert os.path.exists(os.path.join(collection_dir,"plugins","filter","collection_array.py"))
        assert 'ansible.plugins.filter.collection_array.get_collection_array' in get_collection_array.__module__
        assert 'ansible.plugins.filter.collection_array' in collection_dir


# Generated at 2022-06-10 22:42:32.557183
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Validate list_collection_dirs()
    """
    import tempfile
    import shutil
    import sys

    # Create empty ansible collection directories
    tmp_dir = tempfile.mkdtemp(prefix="ansible_collections_test_")
    tmp_collection = os.path.join(tmp_dir, "ansible_collections")

    # Create ansible collection test directory structure
    os.makedirs(os.path.join(tmp_collection, "mytestnamespace1", "mycollection1"))
    os.makedirs(os.path.join(tmp_collection, "mytestnamespace1", "mycollection2"))
    os.makedirs(os.path.join(tmp_collection, "mytestnamespace2", "mycollection3"))

# Generated at 2022-06-10 22:42:43.673582
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with config
    ansible_cfg = """
[defaults]
collections_path = /foo
collections_path = /bar
collections_path = %(ansible_local_tmp)s/test
collections_path = /nonexist
collections_path = /notadir/
"""
    # test with no config
    assert list_valid_collection_paths() == []

    # test with config, some paths do not exist
    with open('test.cfg', 'w') as f:
        f.write(ansible_cfg)
    cfg = AnsibleCollectionConfig.load("test.cfg")
    assert set(list_valid_collection_paths(cfg.collections_paths)) == set(['/bar', '/foo', None])
    os.remove("test.cfg")

    # test with

# Generated at 2022-06-10 22:42:49.994386
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        "/does/not/exist",
        "/etc/passwd",
        "/etc",
        "/tmp",
    ]
    expected_paths = [
        "/etc",
        "/tmp",
    ]
    actual_paths = list(list_valid_collection_paths(search_paths))
    assert expected_paths == actual_paths


# Generated at 2022-06-10 22:42:59.517274
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Function accept list of string as input and filtered out non existing or invalid paths
    :return: subset of list of valid path
    """
    # if search paths is None return default search paths
    path = list(list_valid_collection_paths())
    assert len(path) == 0

    # if empty list is passed return default search paths
    path = list(list_valid_collection_paths([]))
    assert len(path) == 0

    # if list of non-existing path is passed ignore it and return default search paths
    path = list(list_valid_collection_paths(['/some/invalid/path', '/some/other/invalid/path']))
    assert len(path) == 0

    # if valid path added, it should be in the result list

# Generated at 2022-06-10 22:43:03.847047
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    coll_dirs = list(list_collection_dirs(coll_filter='n1.c1'))
    assert len(coll_dirs) == 1
    assert 'n1/c1' in os.path.basename(coll_dirs[0])

# Generated at 2022-06-10 22:43:11.985429
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.current_display = None

    # Test with empty list and no config
    assert len(list(list_valid_collection_paths([]))) == 0
    assert len(list(list_valid_collection_paths())) == 0

    # Test with empty list and config with invalid paths
    assert len(list(list_valid_collection_paths([], warn=True))) == 0
    assert len(list(list_valid_collection_paths(warn=True))) == 0

    # Test with valid listing and no config
    test_data = ['/tmp/foo', '/tmp/bar']
    assert len(list(list_valid_collection_paths(test_data))) == 2

    # Test with valid listing and config with invalid paths
    assert len(list(list_valid_collection_paths(test_data))) == 2
   

# Generated at 2022-06-10 22:43:23.794622
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    def create_subdir(dirname, name):
        b_subdir = os.path.join(dirname, to_bytes(name))
        os.mkdir(b_subdir)
        return b_subdir

    # create a hierarchy of test directories
    tmp_dir = tempfile.mkdtemp()  # tmp_dir is /tmp/tmp0xxxxx

    for ns, coll in [(u'ns1', u'coll1'), (u'ns2', u'coll2')]:
        b_ns_dir = create_subdir(tmp_dir, ns)
        b_coll_dir = create_subdir(b_ns_dir, coll)
        create_subdir(b_coll_dir, u'modules')

    # first use a set of valid paths
    dirs = list_collection

# Generated at 2022-06-10 22:43:45.088831
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os

    from ansible.module_utils._text import to_bytes

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.common.text.formatters import test_formatter

    collections_root = os.path.join(os.path.dirname(to_bytes(__file__)), 'fixtures', 'collection_roots')

    paths = [os.path.join(collections_root, x) for x in os.listdir(collections_root) if os.path.isdir(os.path.join(collections_root, x))]

    found_dirs = list(list_collection_dirs(paths))
    assert len(found_dirs) == 6

    # test the validation of the list_collection_dirs function againt the expected dirs
   

# Generated at 2022-06-10 22:43:54.541030
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def assert_dirs(dirs, expected):
        assert set(dirs) == expected

    display.verbosity = 4

    base_path = os.path.dirname(__file__)

    # no dirs
    assert_dirs(list_collection_dirs(search_paths=[]), set())
    assert_dirs(list_collection_dirs(search_paths=['/fake/path']), set())

    # one dir
    dirs = list_collection_dirs(search_paths=[os.path.join(base_path, 'data/colls_not_installed')])
    assert_dirs(dirs, {os.path.join(base_path, 'data/colls_not_installed/ansible_collections/awesome/basic')})

    # two dirs
    d

# Generated at 2022-06-10 22:43:56.823384
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test function to list collection dirs
    :return:
    '''
    result = list_collection_dirs()

# Generated at 2022-06-10 22:44:04.719713
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "test_data"),
        "/invalid/path",
        "/",
        "~home/blah/path"
    ]

    assert list(list_valid_collection_paths(test_paths, warn=False)) == ['/', '~home/blah/path']
    assert list(list_valid_collection_paths(test_paths, warn=True)) == ['/', '~home/blah/path']



# Generated at 2022-06-10 22:44:10.359548
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Simple test to ensure missing paths are filtered out
    """
    collection_paths = ['/path/does/not/exist', '/does/not/exist/either']
    filtered_collection_paths = list_valid_collection_paths(collection_paths)
    assert list(filtered_collection_paths) == []



# Generated at 2022-06-10 22:44:18.837202
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    conn_paths = ['/tmp/ansible_collections', '/tmp/ansible_anotherpath']

    # collection not installed
    coll_paths = list(list_collection_dirs(search_paths=conn_paths, coll_filter='amazon.aws'))
    assert len(coll_paths) == 0

    # create collections dir and fake amazon.aws collection dir
    os.makedirs(conn_paths[0])
    os.makedirs(os.path.join(conn_paths[0], 'amazon', 'aws'))
    coll_paths = list(list_collection_dirs(search_paths=conn_paths, coll_filter='amazon.aws'))
    assert len(coll_paths) == 1

# Generated at 2022-06-10 22:44:21.504133
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_path = [os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test', 'collection_root')]
    list_collection_dirs(collection_path, 'test.test_component')

# Generated at 2022-06-10 22:44:32.744076
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs
    """

    # simple match all works
    assert(list_collection_dirs(search_paths=['tests/artifactory/sample_collections/collections'], coll_filter=None))

    # Some things don't exist
    assert(not list_collection_dirs(search_paths=['doesnotexist', 'tests/artifactory/sample_collections/collections'], coll_filter=None))

    # Some things exist but aren't collections
    assert(not list_collection_dirs(search_paths=['ansible/docs', 'tests/artifactory/sample_collections/collections'], coll_filter=None))

    # matching for a specific collection filters as expected

# Generated at 2022-06-10 22:44:34.995894
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for p in list_collection_dirs(search_paths=['tests/collections/']):
        print(p)

# Generated at 2022-06-10 22:44:38.478482
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list(list_valid_collection_paths(['/doesnt_exist/test', '/doesnt_exist_either/test', '/etc']))
    assert result == ['/etc']

# Generated at 2022-06-10 22:45:10.462996
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the module list_collection_dirs with a different search path.
    """

    coll_paths = ['test/my_collection']
    for mycoll in list_collection_dirs(coll_paths):
        print(mycoll)

# Generated at 2022-06-10 22:45:13.149133
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/fake/path', '/test/path']
    valid_paths = list(list_valid_collection_paths(search_paths=paths, warn=False))
    assert valid_paths == ['/test/path', '/fake/path']


# Generated at 2022-06-10 22:45:17.566605
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import unfrackpath

    test_paths = ["/foo/bar", "/baz/qux"]

    for path in list_valid_collection_paths(search_paths=test_paths, warn=False):
        assert path == unfrackpath("/foo/bar") or path == unfrackpath("/baz/qux")



# Generated at 2022-06-10 22:45:21.957707
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Test for list_valid_collection_paths"""

    # Test for empty search path
    assert list(list_valid_collection_paths()) == []

    # Test for unsupported type
    invalid_path = [None, object]
    assert list(list_valid_collection_paths(invalid_path)) == []

# Generated at 2022-06-10 22:45:34.582168
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # non existing or invalid search_paths for collections
    test_paths = ["/tmp/collections/test_collection",
                  "/tmp/collections/test_collection/file",
                  "/tmp/collections/test_collection/file.txt"]
    # valid set of paths
    valid_paths = ["/tmp/collections/test_collection/ansible_collections",
                   "/tmp/collections/test_collection/ansible_collections/namespace",
                   "/tmp/collections/test_collection/ansible_collections/namespace/collection"]
    valid_paths_list = []
    for path in valid_paths:
        os.makedirs(to_bytes(path, errors='surrogate_or_strict'), exist_ok=True)
        valid_paths_list.append(path)

# Generated at 2022-06-10 22:45:45.157997
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    assert list(list_valid_collection_paths(search_paths=[])), AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(search_paths=None)), AnsibleCollectionConfig.collection_paths

    assert list(list_valid_collection_paths(search_paths=["/bogus_path"])) == []
    assert list(list_valid_collection_paths(search_paths=["/bogus_path"], warn=True)) == []

    assert list(list_valid_collection_paths(search_paths=["/tmp"])) == ['/tmp']

# Generated at 2022-06-10 22:45:55.975477
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        'test/org_local/ansible_collections',
        'test/org/ns1/coll2/ansible_collections',
    ]

    res = list(list_collection_dirs(search_paths=search_paths))
    assert len(res) == 6

    res = list(list_collection_dirs(search_paths=search_paths, coll_filter='org_local.ns1.coll1'))
    assert len(res) == 1

    res = list(list_collection_dirs(search_paths=search_paths, coll_filter='org_local'))
    assert len(res) == 2

    res = list(list_collection_dirs(search_paths=search_paths, coll_filter='org_local.coll1'))

# Generated at 2022-06-10 22:45:58.782384
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list_collection_dirs(['plugins/module_utils/'])
    assert list(collection_dirs) == [b'plugins/module_utils/ansible_collections/agilista/utils']


# Generated at 2022-06-10 22:46:08.667283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # If no collection filter is passed, all collection directories will be returned.
    paths = list(list_collection_dirs())
    assert len(paths) > 10

    # If a collection filter is passed, only the requested collection directories will be returned.
    paths = list(list_collection_dirs(coll_filter='acme'))
    assert len(paths) == 1
    assert paths[0].endswith(os.path.join("ansible_collections", "acme", "test_collections"))

    # If a namespace filter is passed, only the requested namespace directories will be returned.
    paths = list(list_collection_dirs(coll_filter='acme.test_collections'))
    assert len(paths) == 1

# Generated at 2022-06-10 22:46:13.221195
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # load up default locations
    search_paths = []
    for path in list_valid_collection_paths(search_paths):
        assert os.path.exists(path) and os.path.isdir(path)
    assert len(list(list_collection_dirs())) > 0

# Generated at 2022-06-10 22:47:17.780701
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.utils.collection_loader import _load_collections
    from ansible.utils.path import unfrackpath

    paths = ['./test/support/test_collections']

    # create temporary dir for testing
    coll_root = tempfile.mkdtemp(prefix='ansible_collections_')

    for path in paths:

        for ns in os.listdir(path):
            if ns == '.' or ns == '..':
                continue
            if os.path.isdir(os.path.join(path, ns)):
                coll_path = os.path.join(coll_root, 'ansible_collections', ns)
                if not os.path.exists(coll_path):
                    os.makedirs(coll_path)

# Generated at 2022-06-10 22:47:23.451443
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [u'/does/not/exist', u'/usr/share/{0}'.format(u'\u2603')]
    expected_paths = [u'/usr/share/{0}'.format(u'\u2603')]
    for result in list_valid_collection_paths(search_paths):
        assert result in expected_paths

# Generated at 2022-06-10 22:47:31.675290
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function list_collection_dirs
    """
    from ansible.module_utils.collection_loader import CollectionLoader
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.cli import CLI
    from ansible.config.loader import ConfigLoader
    from ansible.config.manager import ConfigManager
    from ansible import context
    import os

    cli = CLI(['ansible-playbook', '--version'])
    cli.parse()

    loader = ConfigLoader(cli.options, p.CONFIG_FILE, p.CONFIG_DEFAULTS)
    config_manager = ConfigManager(loader)

    context._init_global_context(config_manager)

    coll_paths = list_valid_collection_paths()

    # test that list_collection_dirs

# Generated at 2022-06-10 22:47:37.930655
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_path_list = ['fakedir1', 'fakedir2', 'fakedir3']
    search_paths = ['/tmp', '/var', 'fakedir1', 'fakedir2', 'fakedir3']
    results = list(list_valid_collection_paths(search_paths))
    assert len(results) == len(collection_path_list), "incorrect number of valid collections found in function"


# Generated at 2022-06-10 22:47:51.110530
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections import ansible_collections
    from ansible.collections import ansible_collections
    from ansible.collections.helpers import to_bytes
    from ansible_collections.testns.testcoll.plugins.module_utils.test_module_utils import test_data

    # Create a test collection
    test_ns_name = 'testns'
    test_coll_name = 'test_collection'
    test_coll_path = os.path.join(ansible_collections, test_ns_name, test_coll_name)
    os.mkdir(test_coll_path)
    os.mkdir(os.path.join(test_coll_path, 'plugins'))
    os.mkdir(os.path.join(test_coll_path, 'plugins', 'modules'))


# Generated at 2022-06-10 22:48:00.694355
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest

    @pytest.fixture
    def mock_os(mocker):
        # Mock os.path.abspath
        mocker.patch('ansible.utils.collections.os.path.abspath')

        def _mocked_abspath(pth):
            return pth

        os.path.abspath.side_effect = _mocked_abspath

    # Case: no collection, no search path
    dirs = list(list_collection_dirs())
    assert len(dirs) == 0

    # Case: no collection, single search path
    dirs = list(list_collection_dirs(search_paths=[]))
    assert len(dirs) == 0

    # Case: no collection, multiple search paths

# Generated at 2022-06-10 22:48:05.945311
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    list_collection_dirs test collection directories
    """
    test_dirs = ['/tmp', '/tmp/ansible_collections']
    for path in list_collection_dirs(test_dirs):
        assert '/ansible_collections/' in path
        print(path)



# Generated at 2022-06-10 22:48:10.914812
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with invalid search path
    search_paths = ["/wrong/path", "wrong/path/again"]
    try:
        for b_coll_dir in list_collection_dirs(search_paths):
            assert False
    except AnsibleError:
        pass

# Generated at 2022-06-10 22:48:14.150148
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from nose.plugins.skip import SkipTest

    raise SkipTest("not implemented. Write test to include python equivalent of test/sanity/utils/code-smell/no-dup-collections.sh")

# Generated at 2022-06-10 22:48:23.699287
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    # Create 2 temp directories one not accessible
    temp_dir_1 = tempfile.mkdtemp()
    temp_dir_2 = tempfile.mkdtemp()
    temp_dir_3 = tempfile.mkdtemp()

# Generated at 2022-06-10 22:49:27.937153
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # no actual test, just code coverage
    paths_to_test = ['a/b/c', 'b/c/d']
    dirs = list_collection_dirs(search_paths=paths_to_test, coll_filter='testcoll.test')
    for mydir in dirs:
        assert len(mydir) > 0
    dirs = list_collection_dirs(search_paths=paths_to_test, coll_filter='testcoll')
    for mydir in dirs:
        assert len(mydir) > 0
    dirs = list_collection_dirs(search_paths=paths_to_test)
    for mydir in dirs:
        assert len(mydir) > 0

# Generated at 2022-06-10 22:49:38.807048
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        'path/does/not/exist',
        'path/exists/but/is/not/a/directory',
        'path/is/valid/collection/path',
        '/etc/ansible/ansible.cfg'
    ]

    with open('path/exists/but/is/not/a/directory', 'w'):
        pass

    os.makedirs('path/is/valid/collection/path')
    os.makedirs('/etc/ansible/ansible.cfg')

    results = list(list_valid_collection_paths(paths, warn=True))

    assert '/etc/ansible/ansible.cfg' in results
    assert 'path/is/valid/collection/path' in results
    assert 'path/exists/but/is/not/a/directory'

# Generated at 2022-06-10 22:49:48.974727
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    verifies list_valid_collection_paths function produces the expected results
    """

    import tempfile
    import shutil

    # make sure the collection path is not in the configured paths
    coll_root = tempfile.mkdtemp()
    coll_paths = list_valid_collection_paths(search_paths=[coll_root])
    assert coll_paths is not None
    assert len(coll_paths) == 1
    assert coll_root in coll_paths

    # try a non-existent path, the path should not be in the returned list
    non_existent = os.path.join(coll_root, 'doesnotexist')
    coll_paths = list_valid_collection_paths(search_paths=[coll_root, non_existent])
    assert coll_paths is not None

# Generated at 2022-06-10 22:49:51.822238
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Call the function
    x = list_valid_collection_paths()

    assert isinstance(x, list)
    for path in x:
        assert isinstance(path, str)


# Generated at 2022-06-10 22:49:59.447194
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.ansible.my_namespace.my_collection.plugins.module_utils import my_foo
    root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(my_foo.__file__)))))
    collection_path = os.path.join(root_path, 'ansible_collections', 'ansible', 'my_namespace', 'my_collection')
    real_path = os.path.join(root_path, 'ansible_collections', 'ansible', 'my_namespace', 'my_collection')
    fake_path = os.path.join(root_path, 'ansible_collections', 'ansible', 'my_namespace', 'my_fake_collection')

# Generated at 2022-06-10 22:50:08.537392
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test on existent inventory
    search_paths = ['../../ansible_collections']
    assert len(list(list_valid_collection_paths(search_paths))) == 1
    # test on non-existent inventory
    search_paths = ['../../ansible_collections1']
    assert len(list(list_valid_collection_paths(search_paths))) == 0
    # test on non-directory inventory
    search_paths = ['../../ANSIBILITY-1473']
    assert len(list(list_valid_collection_paths(search_paths))) == 0



# Generated at 2022-06-10 22:50:17.185680
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup a local collection and add it to the path
    search_paths = [os.path.join(os.path.dirname(__file__), 'data', 'valid_collection_root')]

    # Test all collections returned
    test_colls = list_collection_dirs(search_paths)
    assert len(test_colls) == 2

    # Test specific collection returned
    test_colls = list_collection_dirs(search_paths, 'namespace.collection')
    assert len(test_colls) == 1
    assert os.path.basename(list(test_colls)[0]) == 'collection'

    # Test specific collection returned
    test_colls = list_collection_dirs(search_paths, 'namespace.fake_collection')
    assert len(test_colls) == 0

# Generated at 2022-06-10 22:50:18.218785
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs()

# Generated at 2022-06-10 22:50:21.327602
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_coll_root = list_valid_collection_paths()

    assert os.path.exists(b_coll_root)
    assert os.path.isdir(b_coll_root)

# Generated at 2022-06-10 22:50:31.495935
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    from ansible.utils.collection_loader import write_tree_file

    coll_name = 'rt_n_collection'
    coll_namespace = 'ansible_test_user'
    other_coll_name = 'rt_n_collection2'
    tmp_dir = tempfile.mkdtemp()
    collection_dir = os.path.join(tmp_dir, 'ansible_collections', coll_namespace, coll_name, 'plugins', 'modules')
    write_tree_file(collection_dir, {'ping.py': '#!/usr/bin/python'})

    other_collection_dir = os.path.join(tmp_dir, 'ansible_collections', 'ns_other', other_coll_name, 'plugins', 'modules')