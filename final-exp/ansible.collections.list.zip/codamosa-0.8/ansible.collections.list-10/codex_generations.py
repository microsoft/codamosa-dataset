

# Generated at 2022-06-10 22:40:44.231579
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collections = list_collection_dirs(search_paths=['test/unit/plugins/collections/fixtures/test_collections'],
                                       coll_filter=None)

    assert len(list(collections)) == 2
    assert collections[0].endswith("test/unit/plugins/collections/fixtures/test_collections/ansible_collections/x1/test1/")
    assert collections[1].endswith("test/unit/plugins/collections/fixtures/test_collections/ansible_collections/x2/test2/")

# Generated at 2022-06-10 22:40:46.832088
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Smoke test for list_collection_dirs
    """

    b_coll_dir = list(list_collection_dirs())[0]
    assert is_collection_path(b_coll_dir)

# Generated at 2022-06-10 22:40:54.211629
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/tmp/does_not_exist', '/etc']) == ['/etc']

    # Adding a test for a collection path which is a regular file
    # This is a rare case but it can happen if the user is installing a collection via ansible-galaxy
    with open("/tmp/test_col_path", "w") as f:
        f.write("test file")

    try:
        assert list_valid_collection_paths(['/tmp/test_col_path']) == []
    except Exception:
        raise
    finally:
        os.remove("/tmp/test_col_path")

# Generated at 2022-06-10 22:41:04.353060
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that we can iterate all collection paths given the provided search paths.
    """
    paths = [
        '../../ansible_collections',
        '../../ansible_collections/ansible_namespace',
        '../../ansible_collections/ansible_namespace/another_collection',
    ]

    iter_paths = list_collection_dirs(search_paths=paths)

    found_paths = []
    for path in iter_paths:
        found_paths.append(path)

    expected_paths = [
        b'../../ansible_collections',
        b'../../ansible_collections/ansible_namespace',
        b'../../ansible_collections/ansible_namespace/another_collection'
    ]


# Generated at 2022-06-10 22:41:15.814091
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    from ansible.module_utils.common.collections import list_collection_dirs

    search_paths = []
    test_path = tempfile.mkdtemp()

    valid_collection_path = os.path.join(test_path, 'ansible_collections', 'ns', 'mycoll')
    os.makedirs(valid_collection_path)

    # Test non-existent path in search path
    search_paths.append("/non-existent")

    # Test a path that exists, but is not a directory
    file_path = os.path.join(test_path, 'file.txt')
    with open(file_path, 'a'):
        os.utime(file_path, None)
    search_paths.append(file_path)

    # Test

# Generated at 2022-06-10 22:41:26.093818
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    tmpdir = TemporaryDirectory()
    tmpdir_path = Path(tmpdir.name)

    collection_dir = tmpdir_path / 'ansible_collections'
    collection_dir.mkdir()

    namespace_dir1 = collection_dir / 'testns1'
    namespace_dir1.mkdir()

    collection_dir1 = namespace_dir1 / 'testcoll1'
    collection_dir1.mkdir()

    collection_dir2 = namespace_dir1 / 'testcoll2'
    collection_dir2.mkdir()

    collection_dir3 = namespace_dir1 / 'testcoll3'
    collection_dir3.mkdir()

    namespace_dir2 = collection_dir / 'testns2'
    namespace_dir2.mkdir()

    collection

# Generated at 2022-06-10 22:41:34.284800
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Direct match
    colls = list(list_collection_dirs(search_paths=["/path/to/collections"], coll_filter='namespace.collection'))

    assert len(colls) == 1
    assert colls[0] == '/path/to/collections/ansible_collections/namespace/collection'

    # Namespace-only match
    colls = list(list_collection_dirs(search_paths=["/path/to/collections"], coll_filter='namespace'))

    assert len(colls) == 1
    assert colls[0] == '/path/to/collections/ansible_collections/namespace/collection'

    # Multiple matches for namespace.collection

# Generated at 2022-06-10 22:41:41.574689
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_root = 'test/utils/ansible_collections'
    expected_collections = [
        'path1/ansible_collections/collection_one/plugins/modules/module_one.py',
        'path1/ansible_collections/collection_two/plugins/modules/module_two.py',
        'path2/ansible_collections/collection_three/plugins/modules/module_three.py',
    ]
    expected_collections = [
        os.path.join(coll_root, coll) for coll in expected_collections
    ]

    for exp_path in expected_collections:
        assert exp_path in list(list_collection_dirs(coll_filter='*.*', search_paths=[coll_root]))

# Generated at 2022-06-10 22:41:51.851983
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import unfrackpath

    search_paths = [
        unfrackpath("/invalid_path"),
        unfrackpath("/etc/ansible/roles"),
        unfrackpath("/usr/share/ansible/collections"),
    ]

    result_paths = list_valid_collection_paths(search_paths, warn=False)
    assert result_paths[0] == "/etc/ansible/roles"
    assert result_paths[1] == "/usr/share/ansible/collections"

# Generated at 2022-06-10 22:41:54.747608
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        list_valid_collection_paths(["/dev/null", "/tmp", "/dev/foo"])
        # This should not be reached.
        assert False
    except OSError:
        # Expected since /dev/foo is not a dir
        pass

# Generated at 2022-06-10 22:42:17.724132
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # FIXME: Move to unit tests
    testpath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = os.path.join(testpath, "data/collections")

    # test default search paths
    check = list_valid_collection_paths()
    assert(len(list(check)) == 2)

    # test single search path
    check = list_valid_collection_paths(search_paths=[os.path.join(testpath, "data/collections")])
    assert(len(list(check)) == 1)

    # test invalid path
    check = list_valid_collection_paths(search_paths=["bad path"])

# Generated at 2022-06-10 22:42:21.145578
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_list = list(list_collection_dirs(search_paths=['/does/not/exist', '/etc/ansible/collections']))
    assert len(coll_list) == 6


# Generated at 2022-06-10 22:42:30.578374
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil


# Generated at 2022-06-10 22:42:42.525357
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmp_root = None


# Generated at 2022-06-10 22:42:49.549405
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree
    from ansible.module_utils.six import string_types

    fake_collections = {
        'namespace1': {
            'collection1': ['plugins/', 'roles/'],
            'collection2': ['plugins/', 'roles/']
        },
        'namespace2': {
            'collection1': ['plugins/', 'roles/'],
            'collection2': ['plugins/', 'roles/']
        },
    }

    coll_dirs = []

    with tempfile.TemporaryDirectory(prefix='ansible_collections_') as tmpdir:
        for ns, colls in fake_collections.items():
            for coll, dirs in colls.items():
                base = os.path.join(ns, coll)
                coll

# Generated at 2022-06-10 22:43:02.092078
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    fake_paths = ['/path/to/nonexistent/01', '/path/to/nonexistent/02',
                  '/path/to/nonexistent/03', '/path/to/nonexistent/04']

    # first validate all none existing paths are silently skipped
    len_pfx = len([p for p in list_valid_collection_paths(search_paths=fake_paths)])
    assert len_pfx == 0

    # second validate they are all skipped with warnings
    len_pfx = len(
        [p for p in list_valid_collection_paths(search_paths=fake_paths, warn=True)])
    assert len_pfx == 0

    # third validate a default config search_path is found

# Generated at 2022-06-10 22:43:06.182113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        '/not/a/path',
        '/not/a/directory',
        '/tmp'
    ]

    paths = list_valid_collection_paths(search_paths)

    assert list(paths) == [
        '/tmp'
    ]



# Generated at 2022-06-10 22:43:16.221599
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        import ansible_collections
        import ansible_collections.testns.testcoll
    except ImportError:
        raise Exception("Unable to import test collection from the importlib path")

    # For the test collection we are using, we know the relative path is
    # ansible_collections/testns/testcoll.
    # We also know that the collection_loader should add the path we set in
    # the environment variable ANSIBLE_COLLECTIONS_PATHS to the collection
    # search path.
    base_dir = os.path.dirname(os.path.dirname(ansible_collections.__file__))
    test_coll_dir = os.path.join(base_dir, 'testns/testcoll')
    if not is_collection_path(test_coll_dir):
        raise Exception

# Generated at 2022-06-10 22:43:25.992932
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    path = tempfile.mkdtemp()

    # Create the expected collection directory structure
    os.mkdir(os.path.join(path, 'ansible_collections'))
    os.mkdir(os.path.join(path, 'ansible_collections', 'namespace1'))
    shutil.copytree(os.path.join(path, 'ansible_collections', 'namespace1'), os.path.join(path, 'ansible_collections', 'namespace2'))
    shutil.copytree(os.path.join(path, 'ansible_collections', 'namespace1'), os.path.join(path, 'ansible_collections', 'namespace3'))

# Generated at 2022-06-10 22:43:29.090225
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Verify that the default search path is included in results
    list_dir = list(list_collection_dirs())
    assert len(list_dir) > 0
    assert os.path.exists(list_dir[0])

# Generated at 2022-06-10 22:43:53.704163
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test collection loader plugin
    :return: void
    """

    test_paths = ['/tmp/foo',
                  '~/ansible_collections',
                  '/tmp/bar',
                  '~/foo',
                  '~/bar',
                  '~/baz',
                  '~/qux',
                  '~/qux/baz']


# Generated at 2022-06-10 22:43:59.946922
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common import SensuCommon
    import sys
    import os

    handler_path = os.path.join(os.path.dirname(os.path.abspath(SensuCommon.__file__)), "handlers")

    sys.path.append(handler_path)
    from list_collection_dirs_test import check_list_collection_dirs
    check_list_collection_dirs()

# Generated at 2022-06-10 22:44:08.050053
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import list_valid_collection_paths, AnsibleCollectionConfig

    assert len(AnsibleCollectionConfig.collection_paths) > 0

    # expecting only default system locations
    all_sys_locations = len(AnsibleCollectionConfig.collection_paths)
    valid_paths_count = 0
    for _ in list_valid_collection_paths():
        valid_paths_count += 1

    assert all_sys_locations == valid_paths_count

# Generated at 2022-06-10 22:44:09.830365
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    result = list_collection_dirs()
    assert result is not None

# Generated at 2022-06-10 22:44:18.544959
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil

    import ansible.collection

    coll_dirs = list(list_collection_dirs())
    assert coll_dirs

    temp_dir = tempfile.gettempdir()
    ns1 = 'temp_ns1'
    ns2 = 'temp_ns2'
    coll1 = 'temp_coll1'
    coll2 = 'temp_coll2'
    coll3 = 'temp_coll3'

    # create collection directories
    ns1_path = os.path.join(temp_dir, 'ansible_collections', ns1)
    ns2_path = os.path.join(temp_dir, 'ansible_collections', ns2)
    os.makedirs(ns1_path)
    os.makedirs(ns2_path)

   

# Generated at 2022-06-10 22:44:21.180490
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader.collection_finder import list_collection_dirs

    coll_dirs = list(list_collection_dirs())
    print(coll_dirs)
    assert coll_dirs is not None

# Generated at 2022-06-10 22:44:31.720274
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Test that list_valid_collection_paths returns the correct values.
    '''
    assert list_valid_collection_paths(['/a/b', '/c/d']) == ['/a/b', '/c/d']
    assert list_valid_collection_paths(['/a/b', '/c/d'], warn=True) == ['/a/b', '/c/d']
    assert list_valid_collection_paths(['/a/b', '/c/d'], warn=False) == ['/a/b', '/c/d']



# Generated at 2022-06-10 22:44:40.844441
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test args with no specified paths
    assert list(list_valid_collection_paths())

    # Test args with one specified path that exists
    # and one that doesn't
    assert list(list_valid_collection_paths([
        os.path.dirname(os.path.dirname(__file__)),
        '/nonexistant/path/blah']))

    # Test args with one specified path that exists but is not a dir
    # and one that doesn't
    assert list(list_valid_collection_paths([
        os.path.dirname(os.path.dirname(__file__)),
        '/nonexistant/path/blah'
    ], warn=True))



# Generated at 2022-06-10 22:44:52.722484
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    b_tmpdir = None

    b_tmpdir = to_bytes(tempfile.mkdtemp(), errors='surrogate_or_strict')
    os.makedirs(os.path.join(b_tmpdir, b'ansible_collections', b'ansible', b'collections'))
    os.makedirs(os.path.join(b_tmpdir, b'ansible_collections', b'namespace1', b'collection1'))
    os.makedirs(os.path.join(b_tmpdir, b'ansible_collections', b'namespace2', b'collection2'))

# Generated at 2022-06-10 22:45:00.707107
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _get_collection_base_path
    from ansible.plugins.loader import collection_loader

    # Get the collection loader base from Ansible, which is the same as the Ansible community collection path
    ansible_base = _get_collection_base_path()

    # Setup a list of collections for testing
    collections_to_test = ['ansible_collections.namespace1.collection1',
                           'ansible_collections.namespace2.collection2',
                           'ansible_collections.namespace2.collection3']

    # Create the collection directories
    for collection in collections_to_test:
        base = os.path.join(ansible_base, os.path.dirname(collection))
        collection = os.path.basename(collection)


# Generated at 2022-06-10 22:45:41.216787
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    from shutil import rmtree

    search_paths = [mkdtemp()]
    os.mkdir(os.path.join(search_paths[0], 'ansible_collections'))
    os.mkdir(os.path.join(search_paths[0], 'ansible_collections', 'my_namespace'))
    os.mkdir(os.path.join(search_paths[0], 'ansible_collections', 'my_namespace', 'my_first_collection'))
    os.mkdir(os.path.join(search_paths[0], 'ansible_collections', 'my_namespace', 'my_second_collection'))

# Generated at 2022-06-10 22:45:52.247603
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test function to list collection directories.

    Given a directory containing a collection path for a single collection, and
    a list of search paths containing the directory and a second path,
    list_collection_dirs returns an array containing the path to the directory.
    """

    collection_name = "test_collection"
    namespace_name = "test_namespace"
    collection_path = os.path.join(collection_name, namespace_name, collection_name)

    collection_dir = os.path.join(os.path.realpath(os.path.dirname(__file__)), collection_path)

    assert is_collection_path(collection_dir, True)

    search_paths = [os.path.dirname(collection_dir), "/dev/null"]


# Generated at 2022-06-10 22:45:54.095896
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=[])) == []



# Generated at 2022-06-10 22:46:01.160307
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = ["tests/data/valid_collections"]
    for path in list_valid_collection_paths(search_paths=paths):
        assert path == "tests/data/valid_collections"

    paths = ["tests/data/valid_collections", "bad_path"]
    for path in list_valid_collection_paths(search_paths=paths, warn=False):
        assert path == "tests/data/valid_collections"

    paths = ["tests/data/valid_collections", "bad_path"]
    for path in list_valid_collection_paths(search_paths=paths, warn=True):
        pass



# Generated at 2022-06-10 22:46:11.752298
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_path = os.path.join(os.getcwd(), 'test_collections')
    collection_path2 = os.path.join(collection_path, 'ansible_collections')
    search_paths = [collection_path, collection_path2]

    # valid
    collections = list(list_collection_dirs(search_paths, coll_filter='community.general'))
    assert len(collections) == 1

    os.chdir(collections[0])


# Generated at 2022-06-10 22:46:17.820052
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/tmp/a', '/tmp/b']
    invalid_paths = ['/tmp/c/d']
    default_paths = [os.getcwd()]
    result = list_valid_collection_paths(test_paths)

    assert next(result) in test_paths
    assert next(result) in test_paths
    assert next(result) not in invalid_paths
    assert next(result) in default_paths


# Generated at 2022-06-10 22:46:19.969348
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-10 22:46:28.235329
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_bytes
    def test_it():
        import ansible.constants as C

        coll_paths = ['NOTVALID1',
                      C.DEFAULT_COLLECTIONS_PATHS[1],
                      'NOTVALID2']
        path_found = False
        for path in list_valid_collection_paths(search_paths=coll_paths,
                                                warn=True):
            if path == C.DEFAULT_COLLECTIONS_PATHS[1]:
                path_found = True
        assert path_found

    test_it()


# Generated at 2022-06-10 22:46:38.041701
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Test ansible.module_utils.basic.list_collection_dirs """

    tmp_path = tempfile.mkdtemp()
    tmp_coll_path = os.path.join(tmp_path, 'ansible_collections')
    coll_dirs = [
        os.path.join(tmp_coll_path, 'test.test_collection_1'),
        os.path.join(tmp_coll_path, 'test.test_collection_2'),
        os.path.join(tmp_coll_path, 'test.test_collection_3'),
        os.path.join(tmp_coll_path, 'test.test_collection_4'),
    ]
    for directory in coll_dirs:
        os.mkdir(directory)

    # test no filter

# Generated at 2022-06-10 22:46:49.170455
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import is_collection_dir

    test_collections = [
        'joe.foo1',
        'joe.foo2',
        'bob.foo3'
    ]

    path = './unit/utils/mock_collections'
    assert os.path.exists(path)
    assert os.path.isdir(path)

    # ensure path is not empty
    coll_dirs = list(list_collection_dirs([path]))
    assert len(coll_dirs) > 0

    # use list_collection_dirs to write out search list

# Generated at 2022-06-10 22:47:57.482878
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    #default ansible_collections paths should be returned
    search_paths = list_valid_collection_paths()
    assert search_paths is not None

    #search_paths is expected to an empty list if the path in the config file
    #does not exist.
    search_paths = list_valid_collection_paths(['/tmp/invalid/path'])
    assert search_paths is not None
    assert list(search_paths) == []

# Generated at 2022-06-10 22:48:10.411355
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from glob import glob
    from shutil import rmtree
    from os import link
    from ansible.utils.collection_loader import filter_collection_name

    # create temporary directory for test
    dn = tempfile.mkdtemp()

    # create some dummy files and directories
    for mydir in ('myns.mycoll', 'myns.mycoll.docs', 'myns.mycoll.plugins', 'myns.mycoll.plugins.another_plugin',
                  'myns.mycoll.plugins.module_utils', 'myns.mycoll.plugins.modules', 'myns.mycoll.plugins.modules.a_module'):
        dp = os.path.join(dn, mydir)
        os.makedirs(dp)

    # Test that the filter_collection_name method works as expected.

# Generated at 2022-06-10 22:48:17.054917
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # empty config so default is used
    dirs = list(list_collection_dirs())
    assert len(dirs) > 0

    # supply a blank config list to force defaulting
    dirs = list(list_collection_dirs([]))
    assert len(dirs) > 0

    # supply a blank, non-existing config list to force defaulting
    dirs = list(list_collection_dirs(['/no/such/path']))
    assert len(dirs) > 0


# Generated at 2022-06-10 22:48:23.961714
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from types import GeneratorType

    vcs = list_valid_collection_paths()
    assert isinstance(vcs, GeneratorType)

    vcs = list_valid_collection_paths([])
    assert isinstance(vcs, GeneratorType)

    vcs = list_valid_collection_paths(search_paths=['/tmp/no_such_directory', '/tmp'])
    assert isinstance(vcs, GeneratorType)

    vcs = list_valid_collection_paths(search_paths=['/tmp/no_such_directory', '/tmp', '/bin/ls'])
    assert isinstance(vcs, GeneratorType)



# Generated at 2022-06-10 22:48:33.792102
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert len(list(list_valid_collection_paths(search_paths=['this/path/does/not/exist']))) == 0
    assert len(list(list_valid_collection_paths(search_paths=['/dev/random']))) == 0
    assert len(list(list_valid_collection_paths(search_paths=[None, None, None]))) == len(AnsibleCollectionConfig.collection_paths)
    assert len(list(list_valid_collection_paths(search_paths=[None, '/dev/random', None]))) == len(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:48:44.346311
# Unit test for function list_collection_dirs
def test_list_collection_dirs():


    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.common.collections import AnsibleCollectionConfig
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.collections.openstack.cloud.plugins.module_utils.openstack import OpenStackModule

    def _create_test_dir(topdir, rootdir, nsdir, colldir, moddir):
        topdir = to_text(topdir)

        abs_nsdir = os.path.join(topdir, rootdir, nsdir)
        os.makedirs(to_bytes(abs_nsdir))

# Generated at 2022-06-10 22:48:56.406881
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This function serves as unit test for function list_collection_dirs.
    """
    from tempfile import TemporaryDirectory
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import list_valid_collection_paths, list_collection_dirs

    result = list(list_valid_collection_paths(search_paths=[]))
    assert result == [], "list_valid_collection_paths must return empty list if search_paths is empty."

    result = list(list_valid_collection_paths(search_paths=["non_existing_directory"]))
    assert result == [], "list_valid_collection_paths must return empty list if search_paths is non existing directory."


# Generated at 2022-06-10 22:49:06.433144
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import ansible_galaxy
    # Test with default search_paths
    search_paths = None
    valid_paths = list_valid_collection_paths(search_paths)
    assert len(valid_paths) > 0
    # Test with empty search_paths
    search_paths = []
    if not isinstance(ansible_galaxy.__file__, unicode):
        # python 2 will throw TypeError if path is unicode, so make sure we return a str
        ansible_galaxy_path = ansible_galaxy.__file__.decode("utf-8")
    else:
        ansible_galaxy_path = ansible_galaxy.__file__
    # path to galaxy/data/collections on disk
    galaxy_collections_path = os.path

# Generated at 2022-06-10 22:49:11.526233
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/tmp']) == ['/tmp']
    assert list_valid_collection_paths(['/this/path/does/not/exist']) == []
    assert list_valid_collection_paths(['/usr/bin/bash']) == []

# Generated at 2022-06-10 22:49:14.448874
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['foo', 'bar'])) == ['foo', 'bar']