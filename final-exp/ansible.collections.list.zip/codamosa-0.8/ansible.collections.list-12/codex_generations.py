

# Generated at 2022-06-10 22:40:46.205151
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # temp file no exist
    assert not os.path.exists(tempfile.mktemp())

    # temp file empty with no path
    assert list(list_valid_collection_paths([])) == []

    # temp dir is valid
    with tempfile.TemporaryDirectory() as td:
        assert list(list_valid_collection_paths([td])) == [td]

    # temp file is invalid
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        assert not os.path.exists(tf.name)
        assert list(list_valid_collection_paths([tf.name])) == []

    # temp file exists, but is not a dir
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tf.close()
        assert os

# Generated at 2022-06-10 22:40:55.156273
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    class MockOsPath(object):

        def isdir(self, path):
            return True

        def exists(self, path):
            return True

    class MockOsPath2(object):

        def isdir(self, path):
            return False

        def exists(self, path):
            return True

    orig_path = None

    try:
        import __builtin__  # Python 2
        orig_path = __builtin__.os.path
        __builtin__.os.path = MockOsPath()
    except ImportError:
        import builtins  # Python 3
        orig_path = builtins.os.path
        builtins.os.path = MockOsPath()

    assert len(list(list_valid_collection_paths(['path_one', 'path_two']))) == 2


# Generated at 2022-06-10 22:41:05.075717
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible.fortios.tests.unit.compat import unittest

    class TestListCollectionDirs(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_list_collection_dirs_base(self):
            collections = list(list_collection_dirs())
            self.assertGreater(len(collections), 0)

        def test_list_collection_dirs_namespace(self):
            collections = list(list_collection_dirs(coll_filter='fortinet'))
            self.assertGreater(len(collections), 0)

        def test_list_collection_dirs_coll(self):
            collections = list(list_collection_dirs(coll_filter='fortinet.fortios'))

# Generated at 2022-06-10 22:41:16.693818
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    temp_path = tempfile.gettempdir()
    test_path = os.path.join(temp_path, 'ansible_collections')
    test_path_other = os.path.join(test_path, 'test.other')
    test_path_other2 = os.path.join(test_path, 'test.other2')

    collection_paths = [test_path, test_path_other, test_path_other2]

    collection_paths_new = list(list_valid_collection_paths(collection_paths))
    assert(test_path in collection_paths_new)
    assert(len(collection_paths_new) == 3)

    collection_dirs = list(list_collection_dirs(collection_paths_new))

# Generated at 2022-06-10 22:41:21.252612
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/non/existent/path', '~/my/collections', '/etc/ansible/collections']

    # test with invalid search_paths
    assert len(list(list_valid_collection_paths(search_paths))) == 3

    # test with warning on invalid search_paths
    assert len(list(list_valid_collection_paths(search_paths, warn=True))) == 3

    # test without search_paths
    assert len(list(list_valid_collection_paths())) == 0

    # test with warning without search_paths
    assert len(list(list_valid_collection_paths(warn=True))) == 0



# Generated at 2022-06-10 22:41:22.908916
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:41:32.088151
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        os.path.join(os.path.abspath(os.path.dirname(__file__)), 'unit_collections', 'collections1'),
        os.path.join(os.path.abspath(os.path.dirname(__file__)), 'unit_collections', 'collections2'),
        os.path.join(os.path.abspath(os.path.dirname(__file__)), 'unit_collections', 'collections3'),
    ]

    # This should return all collections
    dirs = list(list_collection_dirs(search_paths))
    assert len(dirs) == 4
    assert 'collections1/namespace1/collection1' in dirs
    assert 'collections2/namespace2/collection2' in dirs
   

# Generated at 2022-06-10 22:41:39.945245
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import unittest
    import tempfile
    import shutil
    import os
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))
    test_paths = (
        tmpdir,
        os.path.join(tmpdir, 'ansible_collections', 'ansible', 'test'),
        'foobar',
        '/usr/share',
        '/usr/share/ansible_collections',
        '/usr/share/ansible_collections/ansible/test',
    )


# Generated at 2022-06-10 22:41:50.528081
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import sys
    import tempfile
    import shutil

    # create temp dir for testing
    test_parent = tempfile.mkdtemp()
    test_coll1 = os.path.join(test_parent, 'ansible_collections', 'test', 'foo')
    test_coll2 = os.path.join(test_parent, 'ansible_collections', 'test' , 'bar')
    test_coll3 = os.path.join(test_parent, 'ansible_collections', 'test2' , 'other')
    test_coll_dup = os.path.join(test_parent, 'test2', 'test', 'other')
    test_bad1 = os.path.join(test_parent, 'ansible_collections', 'test1')

    # prepare test directories

# Generated at 2022-06-10 22:41:57.196074
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_path = to_bytes(__file__, errors='surrogate_or_strict')
    os.makedirs(os.path.join(os.path.dirname(b_path), 'test_collection'))

# Generated at 2022-06-10 22:42:14.556631
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ["path1", "path2", "path3"]
    valid_paths = list(list_valid_collection_paths(search_paths=paths))
    assert paths == valid_paths

# Generated at 2022-06-10 22:42:23.314893
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # path_1 is not a dir, path_2 doesn't exist, path_3 is a dir
    path_1, path_2, path_3 = '/etc/passwd', '/not/exist', '/etc'
    search_paths = [path_1, path_2, path_3]
    new_paths = list_valid_collection_paths(search_paths)
    assert path_3 in new_paths
    assert path_1 not in new_paths
    assert path_2 not in new_paths
    assert len(list(new_paths)) == 1


# Generated at 2022-06-10 22:42:31.736716
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_data = [
        # Test case 1: valid search_paths
        {
            'search_paths': ['/tmp/collections']
        },
        # Test case 2: invalid search_paths
        {
            'search_paths': ['/tmp/collections-foo']
        },
        # Test case 3: un-exisiting search_paths
        {
            'search_paths': ['/tmp/collections-bar']
        },
    ]

    valid_path = '/tmp/collections'

    for test in test_data:
        # create test search_paths
        for path in test.get('search_paths', []):
            os.mkdir(path)
        # remove test search_paths
        for path in test.get('search_paths', []):
            os

# Generated at 2022-06-10 22:42:43.001068
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Makes sure that non-existing paths are not returned and paths which exist
    but are not directories are also not returned.
    """
    tmpdir = os.path.realpath(os.path.join(os.path.dirname(__file__), u'test_collections_utils_dirs'))
    assert os.path.exists(tmpdir)

    valid_path = os.path.join(tmpdir, u'valid')
    invalid_path = os.path.join(tmpdir, u'invalid')
    assert not os.path.exists(valid_path)
    assert not os.path.exists(invalid_path)


# Generated at 2022-06-10 22:42:49.718937
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['.']
    collection_paths = list(list_collection_dirs(search_paths))

    assert '.' in collection_paths
    assert os.path.exists(b'ansible_collections/ansible/modules')

    search_paths = ['.']
    collection_paths = list(list_collection_dirs(search_paths, 'ansible'))

    assert os.path.basename(collection_paths[0]) == b'ansible'
    assert os.path.exists(b'ansible_collections/ansible/modules')

    search_paths = ['.']
    collection_paths = list(list_collection_dirs(search_paths, 'ansible.modules'))


# Generated at 2022-06-10 22:42:55.731952
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter='namespace') == list_collection_dirs(coll_filter='namespace.collection')
    assert list_collection_dirs(search_paths=['/does/not/exist']) == []
    assert list_collection_dirs() == list_collection_dirs(search_paths=[])

# Generated at 2022-06-10 22:42:57.920500
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = '/home/ansible/collections'
    assert list_valid_collection_paths([path])

# Generated at 2022-06-10 22:43:08.360212
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/path/does/not/exist']
    paths = list(list_valid_collection_paths(search_paths))
    assert paths == []

    search_paths = ['/path/does/not/exist', os.getcwd()]
    paths = list(list_valid_collection_paths(search_paths, True))
    assert paths == [os.getcwd()]

    search_paths = ['/etc/ansible/collections', '/path/does/not/exist', os.getcwd()]
    paths = list(list_valid_collection_paths(search_paths, True))
    assert paths == ['/etc/ansible/collections', os.getcwd()]


# Generated at 2022-06-10 22:43:20.713954
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    namespaces = {
        'ansible': {
            'random': 'random',
            'crypto': 'crypto',
        },
        'newns': {
            'mycoll': 'mycoll',
            'random': 'random',
        },
    }
    import tempfile
    import shutil
    import types

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    test_path = os.path.join(tmpdir, 'ansible_collections')
    os.makedirs(test_path)

    for namespace in namespaces:
        ns_path = os.path.join(test_path, namespace)
        os.mkdir(ns_path)
        for collection in namespaces[namespace]:
            coll_path = os.path.join(ns_path, collection)
           

# Generated at 2022-06-10 22:43:22.746004
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ask_collection_dirs = list_collection_dirs()
    assert 'ansible_collections.ansible.builtin' in ask_collection_dirs

# Generated at 2022-06-10 22:43:53.463017
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: make a proper unit test for this once utils has been split
    # TODO: consider moving to module_utils/collection_loader
    pass

# Generated at 2022-06-10 22:43:58.900494
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with defaults
    paths = list(list_valid_collection_paths())

    # test with list of non-existing path
    paths = list(list_valid_collection_paths(search_paths=['/path/does/not/exist']))
    print("paths: ", paths)
    assert len(paths) == 0

    # test with list of one existing path
    collconf = AnsibleCollectionConfig()
    collconf.list_paths()


# Generated at 2022-06-10 22:44:09.111565
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Unit test for list_collection_dirs """
    from ansible.tests.unit.utils.collection_loader import ansible_local_test_dir

    collection_dirs = list(list_collection_dirs([ansible_local_test_dir('ansible_collections/test_collections/')],
                                                'namespace1.test_collection1'))

    assert len(collection_dirs) == 1, "Unexpected number of directories found: %d" % len(collection_dirs)
    assert collection_dirs[0].endswith("test_collections/ansible_collections/namespace1/test_collection1")



# Generated at 2022-06-10 22:44:15.652477
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-10 22:44:25.039829
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmp_root = tempfile.mkdtemp()
    tmp_coll_root = os.path.join(tmp_root, 'ansible_collections')

    mazer_coll_root = os.path.join(tmp_coll_root, 'mazer')
    os.makedirs(mazer_coll_root)
    os.makedirs(os.path.join(mazer_coll_root, 'other_collection'))
    os.makedirs(os.path.join(mazer_coll_root, 'test_collection'))

    # non-ansible_collection path is ignored
    my_path = os.path.join(tmp_root, 'my_collection')
    os.mkdir(my_path)

    # non-directory path is ignored
    my_file

# Generated at 2022-06-10 22:44:31.721927
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp/invalid/path1', '/tmp/invalid/path2', '/etc/ansible/collections']
    for path in list_valid_collection_paths(search_paths, warn=False):
        assert path == '/etc/ansible/collections' or path == '/etc/ansible/collections/'



# Generated at 2022-06-10 22:44:41.748805
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader import _get_collection_base_path

    base_path = _get_collection_base_path()

    coll_list = ["collection1.namespace1",
                 "collection2.namespace2",
                 "collection3.namespace3"]
    pattern = "*.namespace1"

    coll_path = os.path.join(base_path, "ansible_collections")
    os.mkdir(coll_path)

    for coll in coll_list:
        namespace, collection = coll.split('.')
        b_namespace = to_bytes(namespace)
        b_collection = to_bytes(collection)

        ns_path = os.path.join(coll_path, b_namespace)
        os.mkdir

# Generated at 2022-06-10 22:44:50.267627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(coll_filter="not.there")) == []
    import tempfile
    temp_dir = tempfile.mkdtemp()
    assert list(list_collection_dirs(search_paths=[temp_dir])) == []
    temp_coll_dir = os.path.join(temp_dir, "ansible_collections")
    os.mkdir(temp_coll_dir)
    assert list(list_collection_dirs(search_paths=[temp_dir])) == []
    temp_coll_dir = os.path.join(temp_dir, "ansible_collections", "there", "not")
    os.makedirs(temp_coll_dir)
    assert list(list_collection_dirs(search_paths=[temp_dir], coll_filter="there.not"))

# Generated at 2022-06-10 22:44:59.299131
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_path = {
        'missing_path': '/usr/foo/bar',
        'file_path': '/usr/foo/bar/file',
        'dir_path': '/tmp/empty_dir',
        'coll_path': '/usr/share/ansible_collections',
        'other_path': '/tmp'
    }

    # Add a file, an empty dir and a collection dir to the search paths
    search_paths = [test_path['missing_path'], test_path['dir_path'], test_path['file_path'],
                    test_path['coll_path'], test_path['other_path']]

    # Create the test file
    with open(test_path['file_path'], "w") as f:
        f.write("test file\n")

    # Create the test empty

# Generated at 2022-06-10 22:45:10.464301
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import logging
    import sys
    import tempfile
    import shutil
    import stat
    import re

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    log = logging.getLogger(__name__)

    for name in logging.root.manager.loggerDict:
        if name in ('paramiko',):
            continue

        logging.getLogger(name).setLevel(logging.INFO)

    tmpdir = tempfile.mkdtemp(prefix='ansible_test_collections_')
    this_file = sys.modules[__name__].__file__
    test_data_path = os.path.join(os.path.dirname(this_file), 'test_data')

# Generated at 2022-06-10 22:45:45.277523
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that only valid collection directories are returned.
    """
    search_paths = [
        "./test/collections/valid",
        "./test/collections/invalid"
    ]
    collection_dirs = list(list_collection_dirs(search_paths))
    assert len(collection_dirs) == 4

# Unit test function list_valid_collection_paths

# Generated at 2022-06-10 22:45:53.862850
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils._text import to_bytes
    from ansible.utils import context_objects as co

    search_paths = [
        '/tmp',
        'doesnotexist',
        '/tmp/ansible_collections',
        '/tmp/ansible_collections/ansible/hello',
    ]

    loader = co.GlobalCLILoader()
    valid_collection_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(valid_collection_paths) == 1

    # back out changes to the config made by loader in the test
    loader.unload()



# Generated at 2022-06-10 22:46:01.921495
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.plugins.loader import collection_loader
    import sys

    if sys.version_info >= (3, 4):
        from unittest.mock import patch
    else:
        from mock import patch

    collection_paths = ['/opt/ansible_collections', '/usr/share/ansible/collections', '/ansible/collections']
    search_paths = ['/opt/ansible_collections/testns/testcoll',
                    '/usr/share/ansible/collections/testns/testcoll',
                    '/ansible/collections/testns/testcoll/']


# Generated at 2022-06-10 22:46:03.803355
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) == len(AnsibleCollectionConfig.collection_paths)



# Generated at 2022-06-10 22:46:14.882095
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test that the list_valid_collection_paths returns non existing directories
    :return:
    """
    from ansible.utils.path import makedirs_safe

    test_paths = [
        '/some/non/existing/**/path',
        '/some/existing/path/for/collections',
        '/some/existing/path/with/a/file/in/it',
    ]

    expected_paths = [
        '/some/existing/path/for/collections',
    ]

    valid_paths = list(list_valid_collection_paths(test_paths, False))

    makedirs_safe(expected_paths[0])

# Generated at 2022-06-10 22:46:20.805849
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    v_paths = list_valid_collection_paths(['a', 'b'], False)
    assert 'a' in v_paths
    assert 'b' in v_paths
    assert 'c' not in v_paths



# Generated at 2022-06-10 22:46:30.833351
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:46:34.345523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = os.path.dirname(__file__)
    test_paths = [path]

    result = list(list_valid_collection_paths(test_paths, warn=True))
    assert path in result[0]



# Generated at 2022-06-10 22:46:36.517484
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collection_dirs()

# Generated at 2022-06-10 22:46:47.235343
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # set up class/stubs
    class os_package():
        class path():
            @staticmethod
            def exists(path):
                if path == b'/foo':
                    return True
                elif path == b'/bar':
                    return False
                elif path == b'/nonexist':
                    return False
                else:
                    raise Exception("Unexpected path provided: %s" % path)

            @staticmethod
            def isdir(path):
                if path == b'/foo':
                    return True
                elif path == b'/bar':
                    return True
                elif path == b'/nonexist':
                    return False
                else:
                    raise Exception("Unexpected path provided: %s" % path)

    # Backup original for reset
    original_os = os

    # Test function with empty list
    os = os_

# Generated at 2022-06-10 22:47:54.529096
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = [x for x in list_collection_dirs()]
    assert len(coll_dirs) >= 1
    display.display("Found %d collection directories." % len(coll_dirs))
    for i in coll_dirs:
        display.display("Found collection directory: %s" % i)
    assert coll_dirs == list_collection_dirs()



# Generated at 2022-06-10 22:47:57.427743
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_cases = [
        # test_case1:
        # test_case2:
    ]

    for search_paths, warn, expected in test_cases:
        assert list_valid_collection_paths(search_paths, warn) == expected



# Generated at 2022-06-10 22:48:10.355073
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # list_valid_collection_paths() should handle:
    #   - empty list

    paths = []
    assert list(list_valid_collection_paths(paths)) == []

    #   - missing paths

    paths = ['/missing-path/', '/missing-path/ansible_collections']
    assert list(list_valid_collection_paths(paths)) == []

    #   - existing but non-directory paths

    paths = ['tests/utils/data/existing-path']
    assert list(list_valid_collection_paths(paths)) == []

    #   - existing but non-collection-root paths

    paths = ['ansible/utils/_text.py']  # ansible/utils/_text.py is a file
    assert list(list_valid_collection_paths(paths)) == []

   

# Generated at 2022-06-10 22:48:14.433040
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list(list_valid_collection_paths(search_paths=['/a/b/c/d/e/f/g/h/i']))
    assert list(list_valid_collection_paths(search_paths=[os.getcwd()]))


# Generated at 2022-06-10 22:48:22.235975
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from unit_tests.test_loader.test_utils import TestModuleUtils

    assert 'test' in TestModuleUtils.test_data
    assert 'collections_dir' in TestModuleUtils.test_data['test']
    if TestModuleUtils.test_data['test']['collections_dir'] != '':
        assert os.path.exists(TestModuleUtils.test_data['test']['collections_dir'])

    collections = list(list_collection_dirs([TestModuleUtils.test_data['test']['collections_dir']]))
    assert len(collections) >= 1
    assert all(os.path.exists(c) for c in collections)

# Generated at 2022-06-10 22:48:35.425567
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible
    import mock

    assert len(list_collection_dirs())
    assert len(list_collection_dirs(['/tmp/no_collection_path'])) == 0

    with mock.patch('ansible.utils.collection_loader.list_valid_collection_paths', return_value=[]):
        assert len(list_collection_dirs()) == 0
        assert len(list_collection_dirs(coll_filter='foo.bar')) == 0

        # Add custom collection path for testing purposes
        test_collections_path = '/tmp/ansible_collections'
        assert not os.path.exists(test_collections_path)
        os.makedirs(test_collections_path, 0o700)
        assert os.path.exists(test_collections_path)

        # Over

# Generated at 2022-06-10 22:48:40.662659
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test with valid and invalid paths
    """
    mypaths = "tangguy,/boguspath,/Users/myname,/"
    mypaths = mypaths.split(',')

    # should be no warnings
    assert 2 == len(list(list_valid_collection_paths(search_paths=mypaths)))

    # Should be two warnings for bogus/non-existent paths
    assert 0 == len(list(list_valid_collection_paths(search_paths=mypaths, warn=True)))

# Generated at 2022-06-10 22:48:48.170115
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from ansible.collections.ansible.community.plugins.module_utils.collection_loader import resolve_collection_roles, RoleFinder

    # check name filtering
    collection_paths = [os.path.join(os.path.dirname(__file__), 'data', 'collections')]
    assert [coll for coll in list_collection_dirs(collection_paths, 'my.ns')] == [os.path.join(os.path.dirname(__file__), 'data', 'collections', 'ansible_collections', 'my', 'ns', 'coll')], "Filter 'myns' failed"

    # check collection filtering

# Generated at 2022-06-10 22:48:51.952506
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    example_path = ['test/unit/modules/test_collection_loader/test_data/collection_path']
    collection_path_list = list(list_collection_dirs(example_path))
    assert(len(collection_path_list) == 2)

# Generated at 2022-06-10 22:48:57.739046
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for coll_dir in list_collection_dirs(search_paths=[
        '/Users/robyoung/dev/ansible/test/unit/utils/loader_fixtures/collections/all/1'
    ], coll_filter='all.collection'):
        assert coll_dir.endswith('all/1/ansible_collections/all/collection')