

# Generated at 2022-06-10 22:40:39.198265
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths_in = ['test_list_valid_collection_paths_invalid_path_test', '.', 'test_list_valid_collection_paths_invalid_path_test/some_subdir']
    paths_out = list(list_valid_collection_paths(search_paths=paths_in, warn=True))
    assert paths_out == ['.']


# Generated at 2022-06-10 22:40:44.485235
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs(['/etc/ansible/collections'], 'namespace.collection')

    assert ['/etc/ansible/collections/namespace/collection'] == coll_dirs

    assert ['namespace.collection'] == list_collection_dirs(['/tmp/foo'],
                                                            'namespace.collection')

# Generated at 2022-06-10 22:40:49.308838
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == []
    assert list_valid_collection_paths(["/zomg/does/not/exist"]) == []
    assert list_valid_collection_paths(["/zomg/does/not/exist", "/usr/bin"]) == ["/usr/bin"]
    assert list_valid_collection_paths(["/zomg/does/not/exist", "/usr/bin"], warn=False) == []

# Generated at 2022-06-10 22:40:59.004362
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test a missing path
    assert list(list_valid_collection_paths(['/foo/bar/baz'])) == []
    # Test a non-directory path
    assert list(list_valid_collection_paths(['/etc/hosts'])) == []
    assert list(list_valid_collection_paths(['/etc', '/etc/hosts'])) == ['/etc']
    # Test a directory path
    assert list(list_valid_collection_paths(['/etc/hosts', '/etc'])) == ['/etc']
    assert list(list_valid_collection_paths(['/etc/hosts', '/etc/bash_completion.d'])) == ['/etc/bash_completion.d']

# Generated at 2022-06-10 22:41:03.428676
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_path = []
    search_path.append('/dev/null')
    search_path.append('/tmp')

    search_path_result = list(list_valid_collection_paths(search_path))
    assert len(search_path_result) == 1
    assert '/tmp' in search_path_result


# Generated at 2022-06-10 22:41:14.531952
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test return of collection directories with different search_paths and coll_filter matches
    '''

    coll_dirs = list(list_collection_dirs(search_paths=['test/unit/utils/fixtures/collections/bad_input'], warn=False))
    assert len(coll_dirs) == 0

    coll_dirs = list(list_collection_dirs(search_paths=['test/unit/utils/fixtures/collections/existing'], warn=False))
    assert len(coll_dirs) == 4
    assert os.path.basename(coll_dirs[0]) == 'ansible_collections'


# Generated at 2022-06-10 22:41:25.123558
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Unit test for collection roles
    search_paths = [
        'test/unit/utils/collection_loader/meta_data_files/roles',
        'test/units/utils/collection_loader/meta_data_files/roles2'
    ]

    collection_dirs = []
    for collection_dir in list_collection_dirs(search_paths, None):
        collection_dirs.append(collection_dir.decode('utf-8'))

    assert collection_dirs == [
        'test/unit/utils/collection_loader/meta_data_files/roles/test_ns.test_role',
        'test/units/utils/collection_loader/meta_data_files/roles2/test_ns.test_role',
    ]

    collection_dirs = []

# Generated at 2022-06-10 22:41:26.435941
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) > 0

# Generated at 2022-06-10 22:41:34.495108
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six.moves.builtins import input
    from hashlib import md5
    from tempfile import mkdtemp

    # Create a set of fake paths and make sure the fake paths are immediately returned
    exp_paths = ['/tmp/ansible/foo', '/tmp/ansible/bar', '/tmp/ansible/baz']
    obs_paths = [path for path in list_valid_collection_paths(exp_paths)]
    assert exp_paths == obs_paths

    # Create a set of fake paths and ensure that the fake paths get passed back if the fake paths do not exist
    exp_paths = ['/tmp/ansible/foo', '/tmp/ansible/bar', '/tmp/ansible/baz']

# Generated at 2022-06-10 22:41:46.453322
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Use temp dir to avoid failing tests
    import tempfile

    # Get temp directory
    tmp_dir = tempfile.gettempdir()

    # Create directories and files in temp dir
    invalid_coll_path1 = os.path.join(tmp_dir, 'test_invalid_path01')
    open(invalid_coll_path1, 'a').close()
    invalid_coll_path2 = os.path.join(tmp_dir, 'test_invalid_path02')
    os.mkdir(invalid_coll_path2)
    invalid_coll_path3 = os.path.join(tmp_dir, 'test_invalid_path03')
    open(invalid_coll_path3, 'a').close()


# Generated at 2022-06-10 22:42:10.501409
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from pkg_resources import parse_version
    import re
    import json

    collection_dirs = list_collection_dirs(search_paths=[])
    assert(collection_dirs is None)

    collection_dirs = list_collection_dirs(search_paths=[])
    assert(collection_dirs is not None)

    collection_dirs = list_collection_dirs(search_paths=[])
    assert(collection_dirs is not None)

    collection_dirs = list_collection_dirs(coll_filter="test.test")
    assert(collection_dirs is None)

    collection_dirs = list_collection_dirs(coll_filter="test.test")
    assert(collection_dirs is not None)

    collection

# Generated at 2022-06-10 22:42:18.323685
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    import sys

    if sys.version_info.major < 3 and sys.version_info.minor < 6:
        pytest.skip("Python versions earlier than 3.6 are not supported", allow_module_level=True)

    test_collection_paths = [
        '/my/path/'
    ]

    test_search_paths = [
        '/my/path/'
    ]

    test_collection_namespace = 'my_namespace'
    test_collection_name = 'my_collection'

    test_coll_filter = '%s.%s' % (test_collection_namespace, test_collection_name)

    for test_search_path in test_search_paths:
        test_search_paths.append(test_search_path)


# Generated at 2022-06-10 22:42:21.923589
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Do a simple test for list_collection_dirs
    results = list_collection_dirs()
    assert len(results) >= 2
    assert 'ansible.posix' in results
    assert 'ansible.netcommon' in results

# Generated at 2022-06-10 22:42:31.019716
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # No collection_filter, no search_paths returns same as list_collection_paths()
    assert list_collection_dirs() == [x for x in list_valid_collection_paths() if x.endswith('ansible_collections')]

    # Collection_filter with no search paths
    assert list_collection_dirs(coll_filter='testcoll') == [x for x in list_valid_collection_paths() if x.endswith(os.path.join('ansible_collections', 'testcoll'))]

    # Namespace and collection_filter with no search paths

# Generated at 2022-06-10 22:42:42.589737
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    from os.path import join, exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils._text import to_bytes

    # Create a temp collection dir structure
    coll_tmpdir = mkdtemp()
    coll_dir1 = join(coll_tmpdir, 'ansible_collections', 'testns1', 'testcoll1')
    coll_dir2 = join(coll_tmpdir, 'ansible_collections', 'testns1', 'testcoll2')
    coll_dir3 = join(coll_tmpdir, 'ansible_collections', 'testns2', 'testcoll3')

# Generated at 2022-06-10 22:42:44.159259
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # TODO: unit test for list_collection_dirs

    return

# Generated at 2022-06-10 22:42:54.842138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # an existing path
    search_path = ["/tmp"]
    assert list(list_valid_collection_paths(search_path)) == search_path

    # a non-existing path
    search_path = ["/a_non_existing_path"]

    # no warning for default paths
    assert list(list_valid_collection_paths(search_path, warn=False)) == []
    assert list(list_valid_collection_paths(search_path, warn=True)) == []

    # a file that exists is not a valid path
    search_path = ["/etc/hosts"]
    assert list(list_valid_collection_paths(search_path, warn=False)) == []


# Generated at 2022-06-10 22:43:06.042444
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import os

    tmp_dir = tempfile.mkdtemp(prefix='ansible_collections', dir='/tmp')
    print("%s" % tmp_dir)

    os.makedirs(os.path.join(tmp_dir, 'namespace1'))

    namespace1_coll1_path = os.path.join(tmp_dir, 'namespace1', 'coll1')
    os.makedirs(namespace1_coll1_path)
    os.makedirs(os.path.join(tmp_dir, 'namespace1', 'coll2'))
    os.makedirs(os.path.join(tmp_dir, 'namespace2'))

    namespace2_coll1_path = os.path.join(tmp_dir, 'namespace2', 'coll1')
   

# Generated at 2022-06-10 22:43:16.057570
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list_valid_collection_paths([])) > 0  # default
    assert len(list_valid_collection_paths()) > 0  # default
    assert len(list_valid_collection_paths(warn=True)) > 0  # default
    assert len(list_valid_collection_paths(search_paths=['/tmp/ansible_galaxy_collections_dir'])) == 1  # set valid
    assert len(list_valid_collection_paths(search_paths=[['/tmp/ansible_galaxy_collections_dir']])) == 1  # set valid
    assert len(list_valid_collection_paths(search_paths=['/tmp/ansible_galaxy_collections_dir', '/tmp/fake_dir'])) == 1  # set valid

# Generated at 2022-06-10 22:43:25.875964
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile

    # setup
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'namespace1', 'collection1'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'namespace1', 'collection2'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'namespace2', 'collection1'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'namespace2', 'collection2'))

    # test

# Generated at 2022-06-10 22:43:51.206279
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import tempfile


# Generated at 2022-06-10 22:43:57.292577
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collections_dirs
    """
    from test.units.modules.collection_loader.test_collection_loader import collection_finder_mock_src_count

    my_paths = [os.path.join(os.path.expanduser("~"), 'collections')]
    collection_finder_mock_src_count(0)
    i = 0
    for coll_dir in list_collection_dirs(search_paths=my_paths):
        display.vv("{0} collection dir: {1}".format(i, coll_dir))
        i += 1
    assert i == 3

# Generated at 2022-06-10 22:44:08.971459
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:44:16.149471
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        '/etc/foo',
        '/etc/bar',
        '/etc/ansible',
        '/etc/ansible/collections',
    ]

    # These should all be valid paths
    for path in list_collection_dirs(search_paths):
        assert path

    search_paths = [
        '/etc/foo',
        '/etc/bar',
        '/etc/ansible/blah',
    ]

    # These should NOT be valid paths
    for path in list_collection_dirs(search_paths):
        assert not path

# Generated at 2022-06-10 22:44:18.956076
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the list_collection_dirs function
    """
    # ansible.cfg has a list of paths specified
    dirs = list(list_collection_dirs())
    assert dirs, "Should have found at least one path"

# Generated at 2022-06-10 22:44:30.125573
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:44:33.320985
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert (list_valid_collection_paths(['/tmp/foo']) == ['/tmp/foo'])
    assert (list_valid_collection_paths(['/tmp/foo', '~/foo', 'bar']) == ['/tmp/foo', 'bar'])


# Generated at 2022-06-10 22:44:46.361246
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the function list_valid_collection_paths()
    """
    import tempfile

    # List of paths for testing
    paths = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp(),
    ]

    # Test case 1: two valid paths
    result = list(list_valid_collection_paths(search_paths=paths))
    assert len(result) == 2
    assert result == paths

    # Test case 2: one invalid path
    paths.append(tempfile.mkdtemp() + '/foo')
    result = list(list_valid_collection_paths(search_paths=paths))
    assert len(result) == 2
    assert paths[0] in result
    assert paths[1] in result

    # Test case 3: two invalid paths

# Generated at 2022-06-10 22:44:56.844801
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # FIXME: this is just a stub

    # TODO: test with a collection that satisfies the following test cases
    # a) collection that exists
    # b) collection that has statefully installed content
    # c) collection that has statefully installed content with config
    # d) collection that is installed in a venv
    # e) collection that is installed in a venv with config
    # f) collection that is partially installed in a collection

    import sys
    import shutil
    import tempfile
    import time

    test_collections = [
        'ansible_collections.testcoll.firstcoll',
        'ansible_collections.testcoll.secondcoll',
        'ansible_collections.testcoll.thirdcoll',
        'ansible_collections.myns.mycoll',
    ]

    # create a config file to ensure

# Generated at 2022-06-10 22:45:07.017543
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import mock

    # noinspection PyTypeChecker
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    with mock.patch.object(m.module, 'list_collection_dirs') as mock_list_coll:

        # test no namespace
        mock_list_coll.return_value = 'hello_world'
        m.list_collection_dirs(search_paths=[])
        mock_list_coll.assert_called_once_with(search_paths=[])

        # test no namespace
        mock_list_coll.reset_mock()
        mock_list_coll

# Generated at 2022-06-10 22:45:37.117222
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-10 22:45:48.968541
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:45:58.781854
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    mock_paths = ['/tmp/fake/path/1',
                  '/tmp/fake/path/2',
                  '/root/fake/path/3',
                  '/root/fake/path/4',
                  '/root/fake/path/5']

    mock_existing_paths = ['/tmp/fake/path/1',
                           '/root/fake/path/3',
                           ]

    mock_paths_not_dirs = ['/root/fake/path/4',
                           ]

    mock_valid_paths = ['/tmp/fake/path/1',
                        '/root/fake/path/3',
                        '/root/fake/path/5',
                        ]

    mock_return_paths = []

    for path in list_valid_collection_paths(mock_paths):
        mock_

# Generated at 2022-06-10 22:46:04.339509
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """
    try:
        list_collection_dirs(search_paths=None, coll_filter=None)
    except ValueError as e:
        print("Unit Test for function list_collection_dir is failed: %s" % e)
    else:
        print("Unit Test for function list_collection_dir is passed")


if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-10 22:46:15.158604
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import inspect
    import sys

    import ansible_collections.mycol.mycoll

    result_path = os.path.dirname(os.path.dirname(inspect.getfile(ansible_collections.mycol.mycoll)))
    unpacked_path = sys.modules[ansible_collections.mycol.mycoll.__name__].__file__
    if unpacked_path.endswith('.pyc') or unpacked_path.endswith('.pyo'):
        # pylint bug.  See https://github.com/PyCQA/pylint/issues/414
        unpacked_path = unpacked_path[:-1]
    unpacked_path = os.path.dirname(os.path.dirname(unpacked_path))

# Generated at 2022-06-10 22:46:25.393764
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Case 1: List search_paths with incorrect path
    search_paths = ['/collections/path/1', '/collections/path/2']
    collection_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(collection_paths) == 0

    # Case 2: List search_paths with correct path
    search_paths = [os.getcwd()]
    correct_paths = list_valid_collection_paths(search_paths, warn=True)
    assert next(correct_paths) == os.getcwd()



# Generated at 2022-06-10 22:46:35.510005
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.ansible_release import __version__
    from ansible.utils.path import makedirs_safe

    mydir = "/tmp/ansible-collections-test/"
    mydir_b = to_bytes(mydir, errors='surrogate_or_strict')

    # Create a temp path for the test
    if not os.path.isdir(mydir_b):
        makedirs_safe(mydir_b, mode=0o700)
    assert os.path.exists(mydir_b)

    # If a none-existing path is passed, we should get an empty list
    search_paths = ["/etc/foo/bar", mydir]
    result = list(list_valid_collection_paths(search_paths))
    assert result == [mydir]



# Generated at 2022-06-10 22:46:42.085343
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    # create a tmp dir
    tmpdir = tempfile.mkdtemp()
    coll_dir = os.path.join(tmpdir, 'ansible_collections', 'ns1', 'coll1')
    os.makedirs(coll_dir)
    open(os.path.join(coll_dir, 'MANIFEST.json'), 'a').close()

    coll_dir_2 = os.path.join(tmpdir, 'ansible_collections', 'ns1', 'coll2')
    os.makedirs(coll_dir_2)
    open(os.path.join(coll_dir_2, 'MANIFEST.json'), 'a').close()


# Generated at 2022-06-10 22:46:51.780527
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # check default return, empty path list
    result = list_valid_collection_paths()
    assert result is not None
    assert len(result) > 0

    # check list of paths is filtered when passed filter is not empty
    result = list_valid_collection_paths(['doesnt_exist'], warn=True)
    assert result is not None
    assert len(result) == 0

    # check list of paths is filtered when passed filter has missing and valid
    result = list_valid_collection_paths(['doesnt_exist', __file__], warn=True)
    assert result is not None
    assert len(result) == 1
    assert __file__ in result



# Generated at 2022-06-10 22:47:01.105094
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    tst_path = os.path.dirname(__file__)
    test_coll_paths = [
        os.path.join(tst_path, 'test_data', 'fake_collection_one'),
        os.path.join(tst_path, 'test_data', 'fake_collection_two'),
        os.path.join(tst_path, 'test_data', 'fake_collection_three'),
        os.path.join(tst_path, 'test_data', 'fake_collection_four'),
        os.path.join(tst_path, 'test_data', 'fake_collection_five'),
    ]

    # Verify good collection path matches
    paths = list_valid_collection_paths(search_paths=test_coll_paths, warn=True)

# Generated at 2022-06-10 22:48:13.573262
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    path = next(list_valid_collection_paths(search_paths=None))
    assert path.endswith('ansible_collections') is True

    path = next(list_valid_collection_paths(search_paths=['/tmp/xyz', '/tmp/../xyz']))
    assert path.endswith('ansible_collections') is True

    path = next(list_valid_collection_paths(search_paths=['/tmp/xyz', '/tmp/../xyz'], warn=True))
    assert path.endswith('ansible_collections') is True

    path = next(list_valid_collection_paths(search_paths=['/tmp/not_there', '/tmp/../nonexist'], warn=True))

# Generated at 2022-06-10 22:48:22.880046
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # need to set a local CWD for relative path testing, even though it is moot on a paths test
    b_cwd = to_bytes(os.getcwd(), errors='surrogate_or_strict')
    os.chdir(b_cwd)

    from tempfile import mkdtemp
    from shutil import rmtree
    from itertools import product

    import os
    import stat

    # create temp dir
    tmpdir = mkdtemp(prefix="anscom")
    tmpdir = to_bytes(tmpdir, errors='surrogate_or_strict')

    # create 4 subdirs, one of each
    dirlist = []

# Generated at 2022-06-10 22:48:32.861137
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    import sys

    collection_paths = []
    bad_paths = []
    temp_paths = []

    # store passed in collection_paths
    if sys.argv[1:]:
        collection_paths.extend(sys.argv[1:])

    # make sure none of the collection_paths passed in don't exist
    for path in collection_paths:
        if not os.path.exists(path):
            bad_paths.append(path)
            display.warning("Collection path {0} does not exist.".format(path))
        else:
            temp_paths.append(path)

    # remove bad_paths from collection_paths list
    for bad_path in bad_paths:
        collection

# Generated at 2022-06-10 22:48:41.162105
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    dirpath = tempfile.mkdtemp()

    # Create a nested structure, with a dir inside a dir,
    # and an Ansible collection under that
    os.makedirs(os.path.join(dirpath, 'foo', 'bar', 'ansible_collections', 'namespace1', 'collection1'))

    # Create a second collection in a different namespace
    os.makedirs(os.path.join(dirpath, 'foo', 'bar', 'ansible_collections', 'namespace2', 'collection2'))

    # Create an invalid Ansible collection

# Generated at 2022-06-10 22:48:48.410056
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils import basic

    from ansible.module_utils.common.collections import list_valid_collection_paths

    # Mock up some pytest fixtures for our module as we don't have an execution context
    basic._ANSIBLE_ARGS = None
    basic._ANSIBLE_ALLOW_UNKNOWN_MODULE_ARGUMENTS = None
    basic._ANSIBLE_CLEAN = None
    basic._ANSIBLE_COMMAND_WARNINGS = None
    basic._ANSIBLE_COMPATIBLE_NO_LOG_DEFAULT = None
    basic._ANSIBLE_DEBUG = None
    basic._ANSIBLE_FORCE_COLOR = None
    basic._ANSIBLE_GATHERING = None
    basic._ANSIBLE_HOST_KEY_CHECKING = None

# Generated at 2022-06-10 22:48:52.642264
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    colls = list_collection_dirs(search_paths=['test/unit/utils/collection_loader/data/collections'], coll_filter='ansible_namespace1.collection1')
    assert os.path.basename(next(colls)) == 'collection1'

# Generated at 2022-06-10 22:48:53.709427
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO
    pass


# Generated at 2022-06-10 22:48:57.731087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ["/test_path", "/not-a-dir", "/Test-collections"]

    assert list(list_valid_collection_paths(search_paths=test_paths)) == ['/test_path']



# Generated at 2022-06-10 22:49:00.629155
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test listing the collection directories

    :return: None
    """
    list_collection_dirs(['../test/integration/targets/'])

# Generated at 2022-06-10 22:49:08.274176
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # intentionally remove the default paths to verify they are added back
    AnsibleCollectionConfig.collection_paths = list()

    display.verbosity = 3
    assert list(list_valid_collection_paths()) == list()

    assert list(list_valid_collection_paths(
        ["/my/missing/dir", "/my/dir"])) == ["/my/dir"]

    AnsibleCollectionConfig.collection_paths = ["/my/dir"]
    assert list(list_valid_collection_paths()) == ["/my/dir"]

    AnsibleCollectionConfig.collection_paths = ["/dev/null"]
    assert list(list_valid_collection_paths()) == ["/dev/null"]

