

# Generated at 2022-06-10 22:40:46.208601
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # no search paths, expect empty list
    assert list(list_valid_collection_paths(search_paths=[])) == []

    # no search paths, expect default search path
    assert list(list_valid_collection_paths()) == [
        u'/home/username/.ansible/collections:/usr/share/ansible/collections',
    ]

    # search paths provided
    assert list(list_valid_collection_paths(search_paths=['/path/coll/a'])) == [
        u'/path/coll/a',
    ]

    # search paths provided, 2 of them, one missing

# Generated at 2022-06-10 22:40:55.200907
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree

    # tests for search_paths list
    test_path = []
    test_path.append(mkdtemp())
    test_path.append(mkdtemp())
    test_path.append(mkdtemp())

    # os.chmod(test_path, 0o555)
    for path in test_path:
        with pytest.raises(AnsibleError):
            list_valid_collection_paths([path])

    # os.chmod(test_path, 0o666)
    for path in test_path:
        with pytest.raises(AnsibleError):
            list_valid_collection_paths([path])

    with pytest.raises(AnsibleError):
        list_valid_

# Generated at 2022-06-10 22:41:05.075763
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    verify that invalid paths are not in list returned
    '''
    all_paths = [u'subdir1/subdir2/subdir3', u'subdir1/subdir2/subdir4',
                 u'subdir1/subdir3/subdir4', u'subdir1/subdir3/subdir5']

    valid_paths = [u'subdir1/subdir2/subdir3', u'subdir1/subdir3/subdir4']

    file_path = u'subdir1/subdir2/subdir3'
    if os.path.exists(file_path):
        os.rmdir(file_path)

    file_path = u'subdir1/subdir2/subdir4'

# Generated at 2022-06-10 22:41:16.647337
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import os
    import shutil

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-10 22:41:17.341480
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs()) == []

# Generated at 2022-06-10 22:41:27.591425
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Basic valid path list
    '''

    colls = list(list_valid_collection_paths(search_paths=['/none/existing/path',
                                                           '../../'
                                                           ], warn=False))
    assert len(colls) >= 1
    # Should be an absolute path
    assert os.path.isabs(colls[0])

    '''
    Empty config, return defaults
    '''
    colls = list(list_valid_collection_paths(search_paths=[], warn=False))
    assert len(colls) >= 1

    '''
    Invalid config, return defaults
    '''


# Generated at 2022-06-10 22:41:28.915374
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_coll_dirs = list(list_collection_dirs())
    assert isinstance(list_coll_dirs, list)



# Generated at 2022-06-10 22:41:38.075583
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tempdir = tempfile.gettempdir()

    # create ansible_collections dir
    collection_path = os.path.join(tempdir, 'ansible_collections')
    os.mkdir(collection_path)

    # create a namespace dir
    os.mkdir(os.path.join(collection_path, 'test'))

    # create a collection dir
    os.mkdir(os.path.join(collection_path, 'test', 'coll'))

    # add collection path to search_paths
    search_paths = [tempdir]

    # call list_collection_dirs
    collection_dirs = list(list_collection_dirs(search_paths, 'test.coll'))

    # check if collection path returned
    assert collection_dirs[0] == os.path

# Generated at 2022-06-10 22:41:47.191140
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test for empty paths
    assert list(list_valid_collection_paths(search_paths=None)) == []

    # Test for list of paths
    assert list(list_valid_collection_paths(search_paths=[])) == []

    # Ensure only valid paths are returned
    assert list(list_valid_collection_paths(search_paths=['/tmp/does/not/exist'])) == []

    # Ensure only valid paths are returned
    assert list(list_valid_collection_paths(search_paths=['/tmp/does/not/exist', '/etc'])) == ['/etc']


# Generated at 2022-06-10 22:41:59.549379
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with no paths
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths
    # Test with valid paths
    path1 = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_data')
    path2 = os.path.join(path1, 'ansible_collections', 'testns', 'testcoll')
    assert list(list_valid_collection_paths([path1, path2])) == [path1, path2]
    # Test with one invalid path (directory exists but is not a valid coll path)
    path3 = os.path.join(path1, 'no_collections_here')

# Generated at 2022-06-10 22:42:16.715637
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible import collections

    def _get_coll_dir(collections):
        for collection in collections:
            for coll_dir in collection.split(':'):
                return coll_dir

    # default collection paths
    coll_dir = _get_coll_dir(list_collection_dirs())
    assert coll_dir == os.path.abspath(os.path.join(os.path.dirname(collections.__file__), os.path.pardir, 'ansible_collections'))

    # empty search_paths list
    coll_dir = _get_coll_dir(list_collection_dirs(search_paths=[]))

# Generated at 2022-06-10 22:42:27.981376
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Test that invalid collection paths are not returned"""

    # if none are passed to the function use defaults
    search_paths = None
    paths = list(list_valid_collection_paths(search_paths))
    assert paths
    assert isinstance(paths, list)

    # if no valid paths are passed to the function, return empty list
    search_paths = ["/invalid/path"]
    paths = list(list_valid_collection_paths(search_paths))
    assert not paths

    # if non existing paths are passed to the function warn, but dont return them
    search_paths = ["/invalid/path"]
    paths = list(list_valid_collection_paths(search_paths, True))
    assert not paths

    # if non existing paths are passed to the function return empty list
    search_

# Generated at 2022-06-10 22:42:33.407017
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    res = list_valid_collection_paths(search_paths=["/foo/bar", "/baz/boof"], warn=False)
    assert res == []

    res = list_valid_collection_paths(search_paths=["/tmp/test_coll_loader"], warn=False)
    assert '/tmp/test_coll_loader' in res

# Generated at 2022-06-10 22:42:44.159762
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_search_paths = ['/tmp/foo', '/tmp/bar', '/usr/share/ansible/collections']
    valid_paths = list(list_valid_collection_paths(coll_search_paths, warn=False))
    assert len(valid_paths) == 1
    assert valid_paths[0] == '/usr/share/ansible/collections'

    coll_search_paths = ['/tmp/foo', '/tmp/bar', '/usr/share/ansible/collections']
    valid_paths = list(list_valid_collection_paths(coll_search_paths, warn=True))
    assert len(valid_paths) == 1
    assert valid_paths[0] == '/usr/share/ansible/collections'


# Generated at 2022-06-10 22:42:56.307401
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_text

    def _touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    def _is_collection_path(path):
        if os.path.isfile(os.path.join(path, 'plugins', 'action', '__init__.py')):
            return True
        return False

    def _makedirs(parent_dir, subdir_list):
        dirs = [os.path.join(parent_dir, subdir) for subdir in subdir_list]
        if not os.path.exists(dirs[0]):
            os.makedirs(dirs[0])

# Generated at 2022-06-10 22:43:07.068233
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # fail_on_missing = True
    def _test_list_collection_dirs(search_paths, coll_filter=None, fail_on_missing=True):
        # list all should have global defaults appended
        if search_paths is None:
            search_paths = []

        # check for global defaults
        if not search_paths:
            search_paths.extend(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:43:12.310681
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    check_paths = [
        '/foo/bar/baz',
        '~/foo/bar/baz',
        '/foo/bar/baz/',
        '~/foo/bar/baz/',
    ]
    # FIXME: this test needs to be re-validated once we have a real system to test in
    # expected_paths = ['~/foo/bar/baz']
    # out_paths = list_valid_collection_paths(list(check_paths), warn=False)
    # assert list(out_paths) == expected_paths

# Generated at 2022-06-10 22:43:19.187773
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(search_paths=['/foo/bar/baz'])) == ['/foo/bar/baz']
    assert list(list_valid_collection_paths(search_paths=['/'])) == ['/']
    assert list(list_valid_collection_paths(search_paths=['/does/not/exist'])) == []



# Generated at 2022-06-10 22:43:23.191529
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    my_path = '/dev/null'

    paths = list_valid_collection_paths([my_path])
    assert list(paths) == []

    paths = list_valid_collection_paths([my_path], warn=True)
    assert list(paths) == []

# Generated at 2022-06-10 22:43:35.527896
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test collection paths configured in ansible.cfg
    test_collection_dirs = list(list_collection_dirs(coll_filter='ansible_collections.foo.bar'))
    assert len(test_collection_dirs) == 1, "Expected to find single collection in test"
    assert os.path.basename(test_collection_dirs[0]) == b'bar', "Expected to list collection \"bar\""

    # Test collection with custom search path
    test_collection_dirs = list(list_collection_dirs(search_paths=['/tmp/ansible_collections'], coll_filter='ansible_collections.foo.bar'))
    assert len(test_collection_dirs) == 1, "Expected to find single collection in test"

# Generated at 2022-06-10 22:43:53.463554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # test for non-existing path
    test_paths = ['/nonexist']
    warn = True
    result = list_valid_collection_paths(test_paths, warn)
    assert isinstance(result, MutableMapping) is False
    assert len(list(result)) == 0

    # test for file-path instead of dir
    test_paths = [__file__]
    result = list_valid_collection_paths(test_paths, warn)
    assert isinstance(result, MutableMapping) is False
    assert len(list(result)) == 0

    # test default

# Generated at 2022-06-10 22:43:57.142533
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = ['not_exist0', 'not_exist1']
    collection_paths.extend(list(list_valid_collection_paths()))
    collection_paths.extend(list(list_valid_collection_paths(warn=True)))
    assert len(list_valid_collection_paths(collection_paths)) == len(AnsibleCollectionConfig.collection_paths)

# Generated at 2022-06-10 22:44:04.719505
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Load ansible_collections in the current directory
    # (for unit testing purposes only)
    search_paths = [os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))]
    coll_filter = "ansible"

    for coll_dir in list_collection_dirs(search_paths, coll_filter):
        print("%s" % coll_dir)

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-10 22:44:08.898581
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = [
        '/tmp/ansible_collections/ansible_collections',
        '/tmp/collection_invalid_root/ansible_collections',
        '/tmp/collection_invalid_ext/ansible_collections/',
        '/tmp/empty_directory',
    ]
    # create directories
    for dir in test_paths:
        try:
            os.makedirs(dir)
        except OSError:
            print("Creation of the directory %s failed" % dir)
        else:
            print("Successfully created the directory %s " % dir)

    for coll in list_collection_dirs(test_paths, 'test_namespace.test_mixed_case'):
        print(coll)


# Generated at 2022-06-10 22:44:18.028946
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.unit.utils.path import ROLE_PATH
    from tempfile import TemporaryDirectory

    def create_tmp_dir():
        tmp_path = TemporaryDirectory()
        tmp_path.cleanup()
        return tmp_path.name

    with TemporaryDirectory() as tmp_path:
        tmp_coll_path = os.path.join(tmp_path, 'ansible_collections')
        os.mkdir(tmp_coll_path)

    # No search paths supplied or configured, use defaults
    paths = list(list_valid_collection_paths())
    assert paths == AnsibleCollectionConfig.collection_paths

    # Valid search path supplied
    paths = list(list_valid_collection_paths([tmp_path]))
    assert paths == [tmp_path]

    # Non-existent search path supplied, should be skipped


# Generated at 2022-06-10 22:44:21.104460
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # FIXME: Remove this test when we remove deprecated collection_paths
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/collections1:/tmp/collections2'
    assert len(list(list_collection_dirs())) == 2



# Generated at 2022-06-10 22:44:28.675946
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["/usr/share/ansible"]
    coll_paths = list(list_collection_dirs(search_paths))
    assert len(coll_paths) > 0

    namespace = "ansible_namespace.ansible_collection"
    coll_paths = list(list_collection_dirs(search_paths, namespace))
    assert len(coll_paths) == 1



# Generated at 2022-06-10 22:44:39.598813
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_text
    from ansible.utils.collection_loader import all_collections
    from ansible.utils.collection_loader import load_collections

    TEST_COLLECTION = 'mynamespace.mycollection'
    TEST_PATH = './test/units/utils/collection_loader/test_collections/ansible_collections/%s' % TEST_COLLECTION

    assert os.path.exists(TEST_PATH)

    # test that normal case works
    coll_dir = test_list_collection_dirs_func()[0]
    assert coll_dir == to_bytes(TEST_PATH)

    # test that collection dir returns full path
    coll_dir = test_list_collection_dirs_func(TEST_COLLECTION)[0]
    assert coll

# Generated at 2022-06-10 22:44:49.725647
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-10 22:44:59.236494
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys

    temp_mod_path = os.path.join(tempfile.gettempdir(), 'ansible_collections/namespace/valid')
    temp_mod_path_with_invalid = os.path.join(tempfile.gettempdir(), 'ansible_collections/namespace/valid/invalid')
    temp_mod_path_invalid = os.path.join(tempfile.gettempdir(), 'ansible_collections/namespace/invalid')


# Generated at 2022-06-10 22:45:21.628061
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _get_collection_path
    from tempfile import mkdtemp
    from shutil import rmtree

    ns_a = 'test_ns1'
    ns_b = 'test_ns2'
    coll_a = 'test_coll'
    coll_b = 'test_coll2'
    test_coll_list = [ns_a, ns_b, coll_a, coll_b]


# Generated at 2022-06-10 22:45:34.386685
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.ansible.plugins.loader import _get_plugin_paths
    from ansible.utils import plugin_docs
    import tempfile, os

    # create a temp dir to use as a collections dir
    fd, coll_path = tempfile.mkstemp(prefix='collections_')
    os.mkdir(coll_path)
    coll_path = os.path.join(coll_path, 'ansible_collections')
    os.mkdir(coll_path)

    # create a plugin path that contains a tmp file
    fd, plugin_path = tempfile.mkstemp(prefix='plugin_')

    # create a temporary collections config
    temp_config = plugin_docs.get_config_from_site_yaml('')

# Generated at 2022-06-10 22:45:46.105961
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([])) == []
    assert list(list_valid_collection_paths(['/tmp'])) == []
    assert list(list_valid_collection_paths([os.path.dirname(__file__)])) == [os.path.dirname(__file__)]
    assert list(list_valid_collection_paths(['/does/not/exist'])) == []
    assert list(list_valid_collection_paths(['/does/not/exist/ asdf'])) == []
    assert list(list_valid_collection_paths(['/does/not/exist', os.path.dirname(__file__)])) == [os.path.dirname(__file__)]

# Generated at 2022-06-10 22:45:56.885280
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Search path is empty
    result = list_valid_collection_paths([])
    assert len(list(result)) == len(AnsibleCollectionConfig.collection_paths)

    # Search path contains an invalid path
    result = list_valid_collection_paths(['/invalid/path'])
    assert len(list(result)) == len(AnsibleCollectionConfig.collection_paths)

    # Search path contains a valid path but it is not a directory
    result = list_valid_collection_paths([__file__])
    assert len(list(result)) == len(AnsibleCollectionConfig.collection_paths)

    # Search path contains a valid path
    result = list_valid_collection_paths(['/etc/ansible'])

# Generated at 2022-06-10 22:45:59.689638
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    collpaths = list_valid_collection_paths()
    assert isinstance(collpaths, list)
    assert len(collpaths) >= 1
    for path in collpaths:
        assert os.path.isdir(path)



# Generated at 2022-06-10 22:46:03.645293
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths

    for path in list_valid_collection_paths(search_paths=('/usr/share', '/usr/share2', '/usr/share3')):
        assert(path in ('/usr/share', '/usr/share2', '/usr/share3'))



# Generated at 2022-06-10 22:46:14.849116
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.ansible.community.tests.unit.config.test_collection_config import FakeConfig

    test_collection_paths = ['/ansible/test/foo',
                             '/test/test/bar',
                             '/ansible/test/baz',
                             '/ansible/test/fan']
    assert list(list_valid_collection_paths(test_collection_paths, warn=False)) == [
        '/ansible/test/foo',
        '/ansible/test/baz',
        '/ansible/test/fan']

    # add test if no search_paths
    # copy original collection search paths
    orig_paths = list(test_collection_paths)
    test_collection_paths = []

# Generated at 2022-06-10 22:46:27.005140
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    from ansible.config.manager import ConfigManager
    from ansible.config.defaults import CONFIG_FILE_NAME, DEFAULTS

    display_type = 'stderr'
    display_args = []
    display_kwargs = {}

    # setup fake config and temp directories
    tmp_config_dir = to_bytes(tempfile.mkdtemp())
    tmp = tempfile.mkdtemp()
    tmp_paths = [to_bytes(tmp)]
    tmp_collections = [os.path.join(tmp, to_bytes('ansible_collections'))]
    for path in tmp_collections:
        os.makedirs(path)

    # create a 'test' collection

# Generated at 2022-06-10 22:46:33.161300
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['.',
                  os.path.join(".", 'nonexistent'),
                  os.path.join(".", 'not_a_dir')]

    result = list_valid_collection_paths(test_paths, warn=False)
    assert '.' in result
    assert os.path.join(".", 'nonexistent') not in result
    assert os.path.join(".", 'not_a_dir') not in result



# Generated at 2022-06-10 22:46:37.961472
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    :return: None
    """

    search_paths = [
        "/tmp/foo/bar",
        "/dev/null",
        "nope",
    ]

    count = 0
    for path in list_valid_collection_paths(search_paths, warn=True):
        count += 1

    assert count == 0



# Generated at 2022-06-10 22:47:11.621646
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = [
        'good_dir',
        'not_there',
        'not_a_dir',
    ]

    for p in list_valid_collection_paths(paths):
        assert p == 'good_dir'



# Generated at 2022-06-10 22:47:13.776311
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.constants import COLLECTIONS_PATHS
    assert list_valid_collection_paths(search_paths=COLLECTIONS_PATHS, warn=True)

# Generated at 2022-06-10 22:47:25.474690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function with data sets
    """

    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible import context
    from ansible.plugins.loader import collection_loader

    # get the dirs for the test collection
    b_test_coll_dir = os.path.join(os.path.dirname(__file__), b'fixtures', b'collection_root', b'ns1', b'mycoll')
    test_coll_dir = to_bytes(b_test_coll_dir, errors='surrogate_or_strict')
    b_test_coll_root = os.path.dirname(test_coll_dir)

    # Test list_collection_dirs with no directories

# Generated at 2022-06-10 22:47:37.188749
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import collections
    import os
    import ansible.utils.collection_loader
    import ansible.utils.display
    import tempfile
    import shutil

    #
    # Get path to the 'ansible_collections' directory
    #
    coll_dir = os.path.join(os.path.dirname(ansible.utils.collection_loader.__file__), u'ansible_collections')

    #
    # Create a temporary directory to store collections
    #
    tmp_dir = tempfile.mkdtemp()

    #
    # Create a temporary directory that is not a collection, but
    # contains collections underneath it.
    #
    tmp_dir_not_coll = os.path.join(tmp_dir, 'notcoll')
    os.mkdir(tmp_dir_not_coll)

    #
   

# Generated at 2022-06-10 22:47:50.263281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = '/var/tmp/ansible-collections'
    fake_collection_dirs = [
        'foo.default',
        'bar.default',
        'foo.baz',
        'bar.baz',
    ]
    fake_collection_files = [
        'foo/default/.galaxy_metadata.yml',
        'bar/default/.galaxy_metadata.yml',
        'foo/baz/.galaxy_metadata.yml',
        'bar/baz/.galaxy_metadata.yml',
    ]
    os.mkdir(path)
    for coll in fake_collection_dirs:
        os.mkdir(os.path.join(path, coll))

# Generated at 2022-06-10 22:47:57.793375
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from os import makedirs, rmdir

    tmpdir = mkdtmp()

    try:
        # create a directory and a file
        dirpath = os.path.join(tmpdir, 'collections')
        filepath = os.path.join(tmpdir, 'file')
        makedirs(dirpath)
        open(filepath, 'w').close()

        result = list(list_valid_collection_paths([dirpath, filepath]))

        # check that only the directory is part of the result
        assert len(result) == 1
        assert result[0] == dirpath

    finally:
        rmdir(dirpath)
        os.remove(filepath)


# Generated at 2022-06-10 22:48:01.704897
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_paths = [b"/some/path", b"/another/path"]
    assert list(list_valid_collection_paths(b_paths)) == [b"/some/path", b"/another/path"]

# Generated at 2022-06-10 22:48:13.086185
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Tests for list_collection_dirs
    """
    assert sorted(list_collection_dirs(coll_filter='ansible_collections.ns')) == [
        'ns',
    ]
    assert sorted(list_collection_dirs(coll_filter='ns')) == [
        'ns',
    ]
    assert sorted(list_collection_dirs(coll_filter='ns.coll1')) == [
        'ns.coll1',
    ]
    assert sorted(list_collection_dirs(coll_filter='')) == []
    assert sorted(list_collection_dirs()) == [
        'ns.coll1', 'ns.coll2', 'ns.subns.subcoll'
    ]

# Generated at 2022-06-10 22:48:21.960723
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil

    base = tempfile.mkdtemp()
    collection_paths = [os.path.join(base, 'coll1'), os.path.join(base, 'coll2'), os.path.join(base, 'coll3')]

    os.mkdir(collection_paths[0])
    os.mkdir(collection_paths[1])
    with open(collection_paths[2], 'w'):
        pass
    valid_collection_paths = list(list_valid_collection_paths(collection_paths))
    assert len(valid_collection_paths) == 2
    assert collection_paths[0] in valid_collection_paths
    assert collection_paths[1] in valid_collection_paths
    shutil.rmtree(base)

# Generated at 2022-06-10 22:48:30.054848
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([])) == []
    assert list(list_valid_collection_paths(['/foo/bar'])) == []
    assert list(list_valid_collection_paths(['/bin'])) == []
    assert list(list_valid_collection_paths(['/usr'])) == []
    assert list(list_valid_collection_paths(['/etc'])) == []

    assert list(list_valid_collection_paths(['/tmp'])) == ['/tmp']
    assert list(list_valid_collection_paths([])) != []

# Generated at 2022-06-10 22:49:36.781178
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test valid search paths returned
    """
    search_paths = ['/dev/null', '/ansible_collections']
    valid_search_paths = list(list_valid_collection_paths(search_paths=search_paths))
    assert len(valid_search_paths) == 2
    assert '/dev/null' in valid_search_paths
    assert '/ansible_collections' in valid_search_paths



# Generated at 2022-06-10 22:49:45.614939
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = []

    # List in bad
    paths.append('/very/non/existent')

    # List in a file
    with open('test.txt', 'w') as f:
        f.write('test')
    paths.append(os.path.abspath('test.txt'))
    os.unlink('test.txt')

    # List in good
    paths.append(os.path.abspath(os.curdir))

    # List in collection path
    paths.append(os.getenv('ANSIBLE_COLLECTIONS_PATHS', '/path/to/nowhere'))

    for path in list_valid_collection_paths(paths, warn=True):
        print(path)



# Generated at 2022-06-10 22:49:50.106063
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp/collections_0', '/tmp/collections_1', '/tmp/collections_2']
    search_paths_valid = list(list_valid_collection_paths(search_paths, False))
    assert search_paths_valid == search_paths


# Generated at 2022-06-10 22:49:58.410290
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test without passing any argument
    assert set(list_valid_collection_paths()) == set(AnsibleCollectionConfig.collection_paths)

    # test passing a non-existing path
    test_paths = ['/this/path/should/not/exist']
    assert set(list_valid_collection_paths(search_paths=test_paths)) == set([])

    # test passing a non-directory pathname
    test_paths = ['/etc/fstab']
    assert set(list_valid_collection_paths(search_paths=test_paths)) == set([])

    # test passing a file path with warning
    test_paths = ['/etc/fstab']
    assert set(list_valid_collection_paths(search_paths=test_paths, warn=True)) == set

# Generated at 2022-06-10 22:50:08.231826
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    colls = list(list_collection_dirs(search_paths=['.'], coll_filter='test_namespace.test_collection'))
    assert colls == [b'ansible_collections/test_namespace/test_collection']

    colls = list(list_collection_dirs(search_paths=['.'], coll_filter='test_namespace'))
    assert colls == [b'ansible_collections/test_namespace/test_collection']

    colls = list(list_collection_dirs(search_paths=['.']))
    assert colls == [b'ansible_collections/test_namespace/test_collection']

# Generated at 2022-06-10 22:50:13.604949
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/dev/null']
    paths.extend(AnsibleCollectionConfig.collection_paths)
    result = list(list_valid_collection_paths(paths, warn=True))
    # should not warn since it is default, but it should get filtered out
    assert len(result) == len(AnsibleCollectionConfig.collection_paths)
    assert result == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-10 22:50:19.518403
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    fake_path = os.path.join(os.path.sep, 'fake', 'path')
    fake_path_file = os.path.join(os.path.sep, 'fake', 'path', 'file')
    assert list(list_valid_collection_paths([fake_path])) == []

    fake_path_exists = os.path.join(os.path.sep, 'tmp', 'fake', 'path')
    os.makedirs(os.path.sep + os.path.join(*fake_path_exists.split(os.sep)[1::]), exist_ok=True)
    assert list(list_valid_collection_paths([fake_path_exists])) == [fake_path_exists]


# Generated at 2022-06-10 22:50:28.447694
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        '/foo/bar/baz/',
        '/tmp/does_not_exist/',
        '/tmp/does_not_exist_file',
    ]

    paths = list(list_valid_collection_paths(search_paths=test_paths))
    assert len(paths) == 1, "List did not contain correct number of paths"
    assert '/foo/bar/baz/' in paths, "List did not contain expected path"

    # make sure it works with bad paths
    paths = list(list_valid_collection_paths(search_paths=['/bad/path/']))
    assert len(paths) == 0, "Bad path was not filtered"

