

# Generated at 2022-06-10 22:40:44.049554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Ensure that list_valid_collection_paths returns a subset of the original list """
    from tempfile import mkdtemp
    from shutil import rmtree
    import random

    tmp_paths = []
    for i in range(10):
        path = mkdtemp()
        tmp_paths.append(path)

    try:
        random.shuffle(tmp_paths)  # use random list of path directories
        ret_paths = list(list_valid_collection_paths(tmp_paths))
        assert len(ret_paths) <= len(tmp_paths)
    finally:
        for path in tmp_paths:
            rmtree(path)

# Generated at 2022-06-10 22:40:51.347738
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp
    import shutil
    import os

    # Create temp directories
    temp_dirs = {}
    temp_dirs['temp_dir'] = mkdtemp()
    temp_dirs['collection_dir'] = mkdtemp(prefix='ansible_collections', dir=temp_dirs['temp_dir'])
    temp_dirs['namespace_dir'] = mkdtemp(prefix='namespace_one', dir=temp_dirs['collection_dir'])
    temp_dirs['collection_dir1'] = mkdtemp(prefix='collection_one', dir=temp_dirs['namespace_dir'])

# Generated at 2022-06-10 22:40:54.211664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_colls = list(list_collection_dirs())
    assert isinstance(list_colls, list)
    assert len(list_colls) > 0

# Generated at 2022-06-10 22:40:56.855359
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = list_valid_collection_paths()
    assert len(search_paths) == len(list(list_valid_collection_paths()))


# Generated at 2022-06-10 22:41:02.786283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import Path

    colls = list_collection_dirs()
    assert colls
    colls_list = [i for i in colls]
    assert len(colls_list) >= 1
    assert all(type(i) == Path for i in colls_list)
    assert all(i.is_dir() for i in colls_list)

# Generated at 2022-06-10 22:41:14.047291
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Test the list_collection_dirs function works as expected. """
    my_path = None
    if '/tmp/' in __file__:
        my_path = os.path.dirname(__file__)
    assert my_path is not None, "/tmp/ missing from test path"
    test_path = os.path.join(my_path, '../../', 'test/units/utils/collection_loader/')
    display.vvv("test_path: %s" % test_path)
    search_paths = [test_path]
    collection_paths = list(list_collection_dirs(search_paths))
    assert len(collection_paths) == 4, "Expected 4 collection_paths, got %s" % collection_paths

# Generated at 2022-06-10 22:41:24.767538
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil

    coll_path = tempfile.mkdtemp()

    test_coll_paths = [
        '/collection/root/should/not/exist',
        '/collection/root/is/a/file',
        '/collection/root/should/not/exist/either',
        coll_path
    ]

    ansible_collections_file = os.path.join(coll_path, 'ansible_collections')
    open(ansible_collections_file, 'a').close()

    valid_paths = list_valid_collection_paths(test_coll_paths)
    assert coll_path in valid_paths

    valid_paths = list_valid_collection_paths(test_coll_paths, warn=True)
    assert coll_path in valid_paths

   

# Generated at 2022-06-10 22:41:33.506718
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.collections.ansible.community.tests.unit.compat import unittest

    class TestListCollectionDirs(unittest.TestCase):

        def test_invalid_coll_filter(self):

            search_paths = []

            coll_filter = 'foobar'
            with self.assertRaises(AnsibleError) as exc:
                list_collection_dirs(search_paths, coll_filter)
                self.assertEqual(exc.exception.args[0], "Invalid collection pattern supplied: %s" % coll_filter)

        def test_coll_filter_namespace_only(self):

            search_paths = []

            coll_filter = 'the_namespace'

            my_list = list(list_collection_dirs(search_paths, coll_filter))

           

# Generated at 2022-06-10 22:41:40.994133
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.collection_loader import AnsibleCollectionConfig
    from ansible.plugins.loader import find_collections

    # Test for functionality if searching for all collections
    test_coll_dirs = list(list_collection_dirs(
        search_paths=["/opt/other_user/ansible_collections", "/opt/user/ansible_collections"],
        coll_filter=None))

    # Sub-test: Test if directory paths are found in the list
    assert "/opt/other_user/ansible_collections/ns1/coll1" in test_coll_dirs,\
        "Expected '/opt/other_user/ansible_collections/ns1/coll1' not found."
    assert "/opt/other_user/ansible_collections/ns4/coll4" in test_

# Generated at 2022-06-10 22:41:53.740800
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.verbosity = 4
    print('test_list_valid_collection_paths')

    import tempfile

    tempdir = tempfile.mkdtemp()

    dirs = ['{0}/dir1'.format(tempdir), '{0}/dir2'.format(tempdir), '{0}/dir3'.format(tempdir)]
    for d in dirs:
        os.mkdir(d)
        os.mkdir('{0}/ansible_collections'.format(d))

    # Test default
    # - this is the default path
    # - dir3 is a real directory
    good_paths = ['/usr/share/ansible/collections', dirs[2]]
    good_paths.extend(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:42:17.671605
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['/tmp/ansible_collections', '/tmp/ansible_collections_2']
    search_paths_not_exists = ['/tmp/ansible_collections_not_exists', '/tmp/ansible_collections_2_not_exists']
    coll_filter = 'my_namespace.my_plugin'
    coll_filter_1 = 'my_namespace'
    coll_filter_2 = 'my_namespace.my_plugin_2'
    coll_filter_3 = 'my_namespace_2.my_plugin_2'
    coll_filter_4 = 'my_namespace_2.my_plugin_3'
    coll_filter_not_exist = 'my_namespace_2.my_plugin_not_exist'


# Generated at 2022-06-10 22:42:28.448885
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Tests the function list_collection_dirs with the following:
      1. User supplied list of search paths
      2. Filter by namespace
      3. Filter by namespace and collection
      4. A combination of all of the above

    A total of four separate tests is conducted and the four different test
    cases are numbered.
    """

    try:
        temp_path1 = os.environ['ANSIBLE_COLLECTIONS_PATHS']
    except KeyError as e:
        temp_path1 = None

    # unit test #1
    # User supplied list of search paths
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/invalid1:/invalid2"
    result = list(list_collection_dirs(search_paths=["/usr/share/ansible/collections"]))

# Generated at 2022-06-10 22:42:34.817465
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_dirs = ['/user/ansible/collections',
                 '/user/ansible/collections_exist',
                 '/user/ansible/not_a_dir',
                 '/user/ansible/do_not_exist']
    for test_dir in test_dirs:
        assert list_valid_collection_paths([test_dir]) == [test_dir]

# Generated at 2022-06-10 22:42:44.919492
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    import tempfile
    tempdir = tempfile.mkdtemp()

    # ensure no paths exist by default
    assert list(list_valid_collection_paths()) == []

    # create a valid path and ensure it is returned
    coll_path = os.path.join(tempdir, 'foo')
    os.makedirs(coll_path)
    assert list(list_valid_collection_paths(search_paths=[tempdir])) == [tempdir]

    # create an invalid path and ensure it is not returned
    coll_path = os.path.join(tempdir, 'bar')
    open(coll_path, 'a').close()

# Generated at 2022-06-10 22:42:57.264241
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''Verify list_collection_dirs return collections paths'''
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils._text import to_text
    search_paths = []

    testdir = mkdtemp()

    coll_dir = os.path.join(testdir, 'ansible_collections')
    os.makedirs(coll_dir)
    search_paths.append(testdir)

    namespace_dir = os.path.join(coll_dir, 'testns')
    os.makedirs(namespace_dir)

    collection_dir = os.path.join(namespace_dir, 'testcoll')
    os.makedirs(collection_dir)

    coll_filter = 'testns.testcoll'


# Generated at 2022-06-10 22:43:07.739430
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_path = 'ansible_collections'
    search_path = os.path.join(os.path.expanduser('~'), collection_path)
    if not os.path.exists(search_path):
        os.makedirs(search_path)

    collection_name = 'test_collection'
    collection_namespace = 'test_namespace'
    collection_path = os.path.join(search_path, collection_namespace, collection_name)
    os.makedirs(collection_path)

    assert os.path.exists(collection_path)

    collection_dirs = list(list_collection_dirs(search_paths=[search_path]))
    assert len(collection_dirs) == 1
    assert collection_dirs[0] == collection_path

# Generated at 2022-06-10 22:43:13.664950
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import sys
    import tempfile

    # Setup "fake" collections
    tempdir = tempfile.mkdtemp()
    test_namespaces = ['test1', 'test2']
    test_collections = ['coll1', 'coll2']
    for test_namespace in test_namespaces:
        os.mkdir(os.path.join(tempdir, 'ansible_collections', test_namespace))
        for test_collection in test_collections:
            os.mkdir(os.path.join(tempdir, 'ansible_collections', test_namespace, test_collection))
    sys.path.append(tempdir)

    # List all

# Generated at 2022-06-10 22:43:19.254844
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.list_collection_dirs import list_collection_dirs
    import os

    dirs = list_collection_dirs(os.environ.get('COLLECTIONS_PATHS'))
    assert dirs
    for d in dirs:
        assert os.path.isdir(d)

# Generated at 2022-06-10 22:43:27.224022
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    # build up a fake collection dir
    coll_dir_root = tempfile.mkdtemp(prefix='collections', dir=os.getcwd())
    # add a namespace directory
    namespace_dir = tempfile.mkdtemp(prefix='foo', dir=coll_dir_root)
    # add a collection directory
    collection_dir = tempfile.mkdtemp(prefix='bar', dir=namespace_dir)

    os.mkdir(os.path.join(collection_dir, to_bytes('plugins')))
    os.mkdir(os.path.join(collection_dir, to_bytes('docs')))
    os.mkdir(os.path.join(collection_dir, to_bytes('tests')))

    # now the collection dir is in place, the function will return the path to it
    coll_

# Generated at 2022-06-10 22:43:32.552663
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert "." in list_valid_collection_paths()
    assert "." in list_valid_collection_paths([])

    path = os.path.join(os.path.dirname(__file__), "data")
    assert path in list_valid_collection_paths([path])



# Generated at 2022-06-10 22:43:56.160636
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list(list_collection_dirs(coll_filter='test.test1'))
    assert collections[0].endswith('/ansible_collections/test/test1')

    collections = list(list_collection_dirs(coll_filter='test'))
    assert len(collections) == 2
    assert collections[0].endswith('/ansible_collections/test/test1')
    assert collections[1].endswith('/ansible_collections/test/test2')

    collections = list(list_collection_dirs(coll_filter=None))
    assert len(collections) > 2
    assert collections[0].endswith('/ansible_collections/test/test1')
    assert collections[1].endswith('/ansible_collections/test/test2')

# Generated at 2022-06-10 22:44:07.485138
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.collection_loader import list_collection_dirs

    assert list_collection_dirs() != []

    assert list_collection_dirs(search_paths=[]) == []

    assert list_collection_dirs(coll_filter='test') != []
    assert list_collection_dirs(coll_filter='test') == list_collection_dirs(search_paths=['test'])
    assert list_collection_dirs(coll_filter='test') == list_collection_dirs(search_paths=['test'], coll_filter='test')

    assert list_collection_dirs(coll_filter='somedude.somecollection') != []

# Generated at 2022-06-10 22:44:11.622326
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
   list_collections = {}
   for p in list_collection_dirs():
      collection_name = os.path.basename(os.path.normpath(p))
      list_collections[collection_name] = p
   assert list_collections
   return list_collections

# Generated at 2022-06-10 22:44:19.530628
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil

    class TestCollectionConfig(AnsibleCollectionConfig):
        def __init__(self):
            self.COLLECTIONS_PATHS = [tempfile.mkdtemp()]

    # populate search path with some test collection content
    c = TestCollectionConfig()
    search = c.collection_paths[0]
    os.makedirs('%s/ansible_collections/mynamespace' % search)
    os.makedirs('%s/ansible_collections/mynamespace/mycollection' % search)
    os.makedirs('%s/ansible_collections/mynamespace/mycollection/plugins' % search)
    os.makedirs('%s/ansible_collections/ansible_namespace/anothercollection' % search)
   

# Generated at 2022-06-10 22:44:25.901675
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list = list_collection_dirs(search_paths=['../test/test_collections'],
                                coll_filter='test.bogus')
    assert list == []

    list = list_collection_dirs(search_paths=['../test/test_collections'],
                                coll_filter='test')
    assert list == [b'../test/test_collections/ansible_collections/test/bogus']

# Generated at 2022-06-10 22:44:34.530229
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-10 22:44:47.408680
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for default
    assert(list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths)

    # Test for non-existent paths
    assert(list(list_valid_collection_paths(search_paths=['/tmp/fake123'])) == AnsibleCollectionConfig.collection_paths)

    # Test for non dir paths
    assert(list(list_valid_collection_paths(search_paths=['/tmp/ansible.cfg'])) == AnsibleCollectionConfig.collection_paths)

    # Test for valid path
    fake_path = '/tmp/fake123/ansible_collections'
    os.makedirs(fake_path)

# Generated at 2022-06-10 22:44:57.620505
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.collections.collection_loader import enable_legacy_collection_loader
    enable_legacy_collection_loader()

    from ansible.utils.collection_loader import _parser_cache
    from ansible.utils.display import Display
    from ansible.utils.hashing import secure_hash_s

    display = Display()

    test_paths = []
    test_ns_colls = []

    # Create a test dir
    test_dir = os.path.join(os.environ['HOME'], 'test_coll_dirs')
    os.makedirs(test_dir)
    test_paths.append(test_dir)

    # Create a namepace dir
    namespace_dir = os.path.join(test_dir, 'ansible_namespace')

# Generated at 2022-06-10 22:45:02.289196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_path = "/tmp/ansible_collections"
    os.makedirs(test_path)

    expected_result = [ test_path ]
    found_paths = list_valid_collection_paths([ test_path ])

    assert list(found_paths) == expected_result

    os.rmdir(test_path)



# Generated at 2022-06-10 22:45:14.591094
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # save original env
    original_env_paths = list(os.environ['ANSIBLE_COLLECTIONS_PATHS'].split(os.pathsep))

    # set up paths in env
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.pathsep.join(['/tmp/does_not_exist', '/tmp/foo'])

    # test function
    results = list(list_valid_collection_paths(['/tmp/exists', '/tmp/foo'], warn=True))
    assert len(results) == 2
    assert results == ['/tmp/exists', '/tmp/foo']

    # restore env
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.pathsep.join(original_env_paths)

# Generated at 2022-06-10 22:45:41.160192
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import makedirs_safe
    from tempfile import mkdtemp

    def _create_file(path):
        makedirs_safe(os.path.dirname(path))
        with open(path, 'wb') as f:
            f.write(b'')

    temp_dir = mkdtemp()

    sub_dir = os.path.join(temp_dir, 'myGalaxy')
    _create_file(os.path.join(sub_dir, 'toto.txt'))

    sub_dir2 = os.path.join(temp_dir, 'myGalaxy', 'titi')
    _create_file(os.path.join(sub_dir2, 'toto.txt'))

    foo = os.path.join(temp_dir, 'foo.txt')
   

# Generated at 2022-06-10 22:45:52.199102
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import errno
    import tempfile

    tmpdir = tempfile.gettempdir()

    good_paths = [
        tmpdir,
    ]

    bad_paths = [
        '~{0}'.format(os.getlogin()),      # Non-existant path
        u'{0}/{1}'.format(tmpdir, os.urandom(24).encode('hex')),  # Non-existant path
        '/dev/null',                      # File
        '/proc',                          # Not a file or directory
    ]

    for path in bad_paths:

        results = list_valid_collection_paths([path])
        try:
            next(results)
        except StopIteration:
            assert True
            continue


# Generated at 2022-06-10 22:46:00.969134
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = ['test/ansible_collections/test_namespace', 'test/ansible_collections/test_namespace/test_collection_3']
    test_files = ['test_namespace', 'test_namespace/test_collection_1', 'test_namespace/test_collection_2', 'test_namespace/test_collection_3']
    coll_dirs = list(list_collection_dirs(collection_paths, coll_filter=None))
    assert len(coll_dirs) == 3
    for mydir in coll_dirs:
        assert os.path.basename(mydir) in test_files
    coll_namespace = list(list_collection_dirs(collection_paths, coll_filter='test_namespace'))

# Generated at 2022-06-10 22:46:11.449514
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    #test for function with coll filter
    search_paths = ['testSearchPath']
    coll_filter = 'name.collection'
    #setup test function to return an iterable of paths based on coll_filter
    test_return = ['testSearchPath/ansible_collections/name/collection']
    def return_function(arg1, arg2):
        return iter(test_return)
    with mock.patch('ansible.utils.collection_loader.list_collection_dirs', return_function):
        returned_colls = list_collection_dirs(search_paths, coll_filter)
        assert len(returned_colls) == 1
        assert returned_colls[0] == 'testSearchPath/ansible_collections/name/collection'
    #test for function without coll filter
    coll_filter = None
   

# Generated at 2022-06-10 22:46:20.531786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    search_paths = []
    os.environ.pop('ANSIBLE_COLLECTIONS_PATH', None)

    # Add a valid search path
    search_paths.append(mkdtemp())

    # Add a non-existent search path
    search_paths.append("/fake/path/foobar/")

    # Add a non-directory path
    tmp_file = mkdtemp()
    os.remove(tmp_file)
    search_paths.append(tmp_file)

    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=True))

    assert len(valid_paths) == 1
    assert valid_paths[0] == search_paths[0]


# Generated at 2022-06-10 22:46:30.584999
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path_list = ['/home/charlie/ansible/ansible_collections', '/home/charlie/ansible/ansible_collections/ansible_collections']
    coll_list = list(list_collection_dirs(path_list))
    assert len(coll_list) == 2, "Expected coll_list to be 2, got {}".format(len(coll_list))

    coll_list = list(list_collection_dirs(path_list, 'community.general'))
    assert len(coll_list) == 1, "Expected coll_list to be 1, got {}".format(len(coll_list))

    coll_list = list(list_collection_dirs(path_list, 'community.general.plugins'))

# Generated at 2022-06-10 22:46:39.792760
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = "/home/username/ansible_collections"
    list_of_paths = ["/home/username/ansible_collections", "/not/real"]
    search_paths = [path]
    list_of_search_paths = [path, "/not/real"]

    # check that an empty list is returned if paths are invalid
    assert [] == list(list_valid_collection_paths(search_paths))
    assert [] == list(list_valid_collection_paths(list_of_search_paths))
    assert [] == list(list_valid_collection_paths([]))
    assert [] == list(list_valid_collection_paths(["/not/real"]))

    # check that a single valid path is returned

# Generated at 2022-06-10 22:46:51.459949
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create temporary directory
    tempdir = to_bytes(mkdtemp())

    # Create test files
    existing_dir = os.path.join(tempdir, b'existing_dir')
    existing_file = os.path.join(tempdir, b'existing_file')
    missing = os.path.join(tempdir, b'missing')
    os.makedirs(existing_dir)
    open(existing_file, 'w').close()

    test_paths = [
        existing_dir,
        existing_file,
        missing,
    ]

    # Test without warning
    result = list(list_valid_collection_paths(test_paths, warn=False))
    assert result == [to_bytes(existing_dir)]



# Generated at 2022-06-10 22:47:00.436517
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tpath = tempfile.mkdtemp()

# Generated at 2022-06-10 22:47:03.854649
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = ['/path/to/collection', '/some/other/collection']
    actual = list(list_valid_collection_paths(['/path/to/collection', '/some/other/collection']))
    assert actual == expected



# Generated at 2022-06-10 22:47:49.607710
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile
    import unittest

    collection_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collections')

    class TestCollectionDirs(unittest.TestCase):
        def setUp(self):
            # create a temp dir, copy our test_collections directory into it, then set that as the new collection_path
            self.__test_dir = tempfile.mkdtemp()
            shutil.copytree(collection_path, os.path.join(self.__test_dir, 'test_collections'))
            self.__collection_path = [self.__test_dir]

        def tearDown(self):
            shutil.rmtree(self.__test_dir)

        # test filter on namespace


# Generated at 2022-06-10 22:47:59.801883
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCollectionConfig(unittest.TestCase):

        def setUp(self):
            # Create two temp directories
            self.test_dir = tempfile.mkdtemp()
            self.coll_dir1 = tempfile.mkdtemp(dir=self.test_dir)
            self.coll_dir2 = tempfile.mkdtemp()
            self.coll_dir3 = tempfile.mkdtemp()
            self.coll_dir4 = tempfile.mkdtemp()
            os.makedirs(os.path.join(self.coll_dir1, 'ansible_collections'))
            os.makedirs(os.path.join(self.coll_dir1, 'ansible_collections', 'namespace1'))


# Generated at 2022-06-10 22:48:12.374623
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Empty search_paths - return default (hard-coded) paths
    search_paths = []
    valid_paths = list_valid_collection_paths(search_paths, warn=False)
    assert list(valid_paths) == AnsibleCollectionConfig.collection_paths
    # None search_paths - return default (hard-coded) paths
    valid_paths = list_valid_collection_paths(None, warn=False)
    assert list(valid_paths) == AnsibleCollectionConfig.collection_paths
    # Invalid path - return no paths
    search_paths = ['/foo']
    valid_paths = list_valid_collection_paths(search_paths, warn=False)
    assert list(valid_paths) == []
    # Valid path - return paths
    search_paths

# Generated at 2022-06-10 22:48:19.857700
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        "/etc/ansible/collections",
        ".:../collections"
    ]

    colls = list_collection_dirs(search_paths)

    assert os.path.exists("../collections/ansible_collections/ns1/coll1")
    assert os.path.exists("../collections/ansible_collections/ns1/coll2")
    assert os.path.exists("../collections/ansible_collections/ns2/coll3")

    # all collections returned
    assert len(list(colls)) == 3

    colls = list_collection_dirs(search_paths, "ns1.coll1")
    assert len(list(colls)) == 1

    # test namespace pattern

# Generated at 2022-06-10 22:48:30.903247
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp, mkstemp
    from shutil import rmtree
    from ansible.module_utils._text import to_text

    # Create a temp directory
    temp_root_dir = mkdtemp()

    # Create a test collection dir
    test_coll_name = 'test_coll'
    test_coll_path = os.path.join(temp_root_dir, to_text(test_coll_name))
    os.mkdir(test_coll_path)

    # Create a test collection file
    test_coll_file = mkstemp(prefix=to_text(test_coll_name), dir=test_coll_path)[1]

    # Create a test ansible collection dir
    test_coll_dir = os.path.join(temp_root_dir, 'ansible_collections')


# Generated at 2022-06-10 22:48:31.760569
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO
    pass

# Generated at 2022-06-10 22:48:42.394865
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys

    # Helper
    def create_temp_coll_paths(temp_path_root, coll_name, version='1.0.0', namespace=None, extra_paths=[]):
        if not os.path.exists(temp_path_root):
            os.makedirs(temp_path_root)

        if namespace is not None:
            temp_path = os.path.join(temp_path_root, 'ansible_collections', namespace, coll_name)
        else:
            temp_path = os.path.join(temp_path_root, 'ansible_collections', coll_name)

        if not os.path.exists(temp_path):
            os.makedirs(temp_path)


# Generated at 2022-06-10 22:48:49.665581
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Single path that does not exist should be ignored
    assert list(list_valid_collection_paths(["/foo/bar/baz"])) == []

    # Multiple paths, only one that does not exist should be ignored
    default_paths = ['/var/lib/ansible/collections', '/usr/share/ansible/collections']
    assert list(list_valid_collection_paths(default_paths + ["/foo/bar/baz"])) == default_paths



# Generated at 2022-06-10 22:49:01.163695
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.test.utils import collections_loader_mock
    from ansible.test import mock
    from ansible_collections.mjhas.test_collection.plugins.module_utils.collection_loader_test_dir.collection_dirs import test_dir
    test_dirs = []
    # Verify non-existent dir
    with collections_loader_mock.patch_collections_loader_search_paths(['/tmp/does_not_exist']):
        for dir in list_collection_dirs():
            test_dirs.append(dir)
    assert len(test_dirs) == 0
    # Verify non-collection dir

# Generated at 2022-06-10 22:49:09.287739
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        '/path/to/collection',
        '/path/to/collection2',
        '/path/to/collection3'
    ]
    # test when all search paths are valid
    valid_paths = list_valid_collection_paths(search_paths=paths)
    assert len(valid_paths) == 3
    # test when search path does not exist
    paths.append('/path/to/collection4')
    valid_paths = list_valid_collection_paths(search_paths=paths, warn=True)
    assert len(valid_paths) == 3
    # test when search path is not a directory
    paths[3] = '/path/to/collection5'

# Generated at 2022-06-10 22:49:46.533497
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # non existent path
    paths = ['foobar']
    assert list(list_valid_collection_paths(paths)) == []

    # not a directory
    paths = ['/etc/hosts']
    assert list(list_valid_collection_paths(paths)) == []

    paths = ['/etc']
    assert list(list_valid_collection_paths(paths)) == ['/etc']


# Generated at 2022-06-10 22:49:55.996950
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # [[[Test the following cases:
    #     list_collection_dirs() -- show all collections in the default path
    #     list_collection_dirs(coll_filter='NS') -- show collections for NS in default path
    #     list_collection_dirs(coll_filter='NS.COLL') -- show collection NS.COLL in default path
    #     list_collection_dirs(search_paths=['path']) -- show collections for path
    #     list_collection_dirs(['path1','path2']) -- show collections for path1 and path2
    # ]]]

    # list_collection_dirs()
    run = list(list_collection_dirs())
    assert len(run) > 0

    # list_collection_dirs(coll_filter='NS')

# Generated at 2022-06-10 22:49:58.866759
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = ["/foo/bar", "/etc/ansible/collections"]

    paths = list(list_valid_collection_paths(collection_paths))

    assert len(paths) == 1
    assert paths[0] == "/etc/ansible/collections"


# Generated at 2022-06-10 22:50:10.403889
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six import PY3

    # Test setup
    # Names of nonexistent directories
    nonexistent_dir_1 = 'abc'
    nonexistent_dir_2 = 'def'
    # Names of directories that exist and are directories
    existing_dir_1 = 'ghi'
    existing_dir_2 = 'jkl'
    # Names of directories that exist but are not directories
    existing_not_dir_1 = 'mno'
    existing_not_dir_2 = 'xyz'
    # Names of directories that are actually empty strings (to test
    # path.exists() on empty string)
    empty_dir_1 = ''
    empty_dir_2 = ''
    # Names of directories that are None (to test path.exists() on null
    # object)

# Generated at 2022-06-10 22:50:18.105590
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test default list
    collection_dirs = list(list_collection_dirs())
    assert collection_dirs is not None
    assert len(collection_dirs) > 0

    # test list with empty filter
    collection_dirs = list(list_collection_dirs(coll_filter=''))
    assert collection_dirs is not None
    assert len(collection_dirs) > 0

    # test list with namespace filter
    collection_dirs = list(list_collection_dirs(coll_filter='not_ansible.not_collection'))
    assert collection_dirs is not None
    assert len(collection_dirs) == 0

    # test list with collection filter
    collection_dirs = list(list_collection_dirs(coll_filter='ansible.collection'))
    assert collection_dirs is not None

# Generated at 2022-06-10 22:50:27.864982
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths_default = list_valid_collection_paths()
    assert len(search_paths_default) > 0
    assert search_paths_default == list_valid_collection_paths(search_paths=None)

    search_paths_empty = list_valid_collection_paths(search_paths=[])
    assert len(search_paths_empty) > 0
    assert len(set(search_paths_default).difference(set(search_paths_empty))) == 0

    search_paths_non_existing = list_valid_collection_paths(search_paths=['/var/no_collection_directory'])
    assert len(search_paths_non_existing) == 0
