

# Generated at 2022-06-10 22:40:41.225114
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [os.path.sep.join(['/test/path','does','not','exist']), 'test/path/does/exist']

    for p in list_valid_collection_paths(search_paths):
        assert p == os.path.realpath(search_paths[1])

if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-10 22:40:48.268523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(None, warn=False)) == []
    assert list(list_valid_collection_paths(search_paths=[], warn=False)) == []
    assert list(list_valid_collection_paths(search_paths=['dummy'], warn=False)) == []

    assert list(list_valid_collection_paths(search_paths=['resources/collection_loader'], warn=False)) == ['resources/collection_loader']
    assert list(list_valid_collection_paths(search_paths=['resources/invalid'], warn=False)) == []

# Generated at 2022-06-10 22:40:58.767137
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=["../ansible_collections/ansible/test_collection/", "../ansible_collections/ansible/test_collection2/"]) == [b'../ansible_collections/ansible/test_collection/ansible_collections/ansible/test_collection/plugins', b'../ansible_collections/ansible/test_collection/ansible_collections/ansible/test_collection2/plugins']
    assert list_collection_dirs(search_paths=["../ansible_collections/ansible/test_collection/"]) == [b'../ansible_collections/ansible/test_collection/ansible_collections/ansible/test_collection/plugins']

# Generated at 2022-06-10 22:41:04.906706
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        './test/integration/utils/data/collection_paths',
        './test/integration/utils/data/non_existing',
        './test/integration/utils/data/not_a_dir'
    ]

    assert list(list_valid_collection_paths(paths)) == [
        './test/integration/utils/data/collection_paths',
    ]

    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths



# Generated at 2022-06-10 22:41:16.437219
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '/tmp/does-not-exist',
        '/tmp/does-not-exist2',
        't/does-not-exist',
        '../t/does-not-exist',
        './t/does-not-exist',
    ]

    # This path exists but is not a directory
    test_paths.append(__file__)

    # This path exists and is a directory
    test_paths.append(__file__[0:__file__.rindex('/')])

    display.verbosity = 3
    valid_paths = list(list_valid_collection_paths(test_paths, warn=True))
    assert len(valid_paths) == 1, "There should be only one path to return"
    assert valid_paths[0] == test_path

# Generated at 2022-06-10 22:41:19.139210
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        'doesnotexist.collection',
        '/collections',
        '/path/to/a/file.txt',
    ]
    expected = ['/collections']

    actual = list(list_valid_collection_paths(search_paths))

    assert expected == actual, 'Expected %s to equal %s' % (expected, actual)


# Generated at 2022-06-10 22:41:28.893223
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_dir = os.path.dirname(__file__)
    coll_dir = os.path.join(test_dir, '..', '..', 'roles', 'test_collection')

    # 1. test that invalid paths are removed from list
    assert list(list_valid_collection_paths([
        os.path.join(coll_dir, 'not_a_real_path'),
        os.path.join(coll_dir, 'invalid_collection_type')
    ])) == []

    # 2. test that valid (existing) collection path is ok and path is returned
    assert list(list_valid_collection_paths([
        os.path.join(coll_dir, 'roles')
    ])) == [os.path.join(coll_dir, 'roles')]

    # 3. test that default

# Generated at 2022-06-10 22:41:32.471553
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        './doesnotexist',
        './doesnotexist2',
        './library'
    ]

    for path in list_valid_collection_paths(search_paths, warn=True):
        print(path)

# Generated at 2022-06-10 22:41:40.208660
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Verify basic behavior of list_collection_dirs()"""

    try:
        for path in list_collection_dirs(coll_filter='hidden_namespace.deprecated'):
            assert path
    except AssertionError:
        raise AssertionError('Did not load hidden_namespace.deprecated from library')

    try:
        for path in list_collection_dirs(coll_filter='hidden_namespace.missing'):
            assert path
    except AssertionError:
        raise AssertionError('Did not load hidden_namespace.missing from library')

    try:
        for path in list_collection_dirs(coll_filter='hidden_namespace'):
            assert path
    except AssertionError:
        raise AssertionError('Did not load hidden_namespace from library')

# Generated at 2022-06-10 22:41:48.669898
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # not a real collection
    coll_path = '/tmp/ansible_collections/foo/nope'
    assert not next(list_collection_dirs(coll_filter=coll_path), False)

    # not a real collection
    coll_path = '/tmp/ansible_collections/foo/nope/not.a.collection'
    assert not next(list_collection_dirs(coll_filter=coll_path), False)

    # a valid collection
    coll_path = '/tmp/ansible_collections/foo/nope/not.a.collection'
    assert is_collection_path(os.fsencode(coll_path))

# Generated at 2022-06-10 22:41:58.075001
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([])) == []

    assert list(list_valid_collection_paths([None])) == []

    assert list(list_valid_collection_paths(['/tmp/not/a/valid/path'])) == []

    assert list(list_valid_collection_paths(['/tmp/not/a/valid/path', None, '/tmp'])) == ['/tmp']

# Generated at 2022-06-10 22:42:07.448692
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import unittest.mock
    test_paths = ['testpath1', 'testpath2']
    mock_listdir = ['ansible_collections', 'mynamespace']
    mock_os_path = unittest.mock.MagicMock()
    mock_os_path.isdir.return_value = True
    mock_os_path.normpath.return_value = '/tmp/mycollections/mynamespace'

    mock_b_coll_root = b'testpath1/ansible_collections'
    mock_b_namespace_dir = b'testpath1/ansible_collections/mynamespace'
    mock_b_coll_dir = b'testpath1/ansible_collections/mynamespace/mycollection'


# Generated at 2022-06-10 22:42:17.008967
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    is_dir = os.path.isdir
    is_file = os.path.isfile
    find_lib = 'find /usr/lib -name "ansible_collections" -type d'
    if os.path.exists('/usr/lib/ansible'):
        find_lib = 'find /usr/lib/ansible -name "ansible_collections" -type d'



# Generated at 2022-06-10 22:42:21.199545
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(["/doesnt/exist"]) == []
    assert list_valid_collection_paths(["/usr/bin"]) == []
    assert list_valid_collection_paths() == []

# Generated at 2022-06-10 22:42:30.611922
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        'bogus',
        os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'units', 'module_utils', 'compat', 'collections')
    ]

    # all collections
    for coll_path in list_collection_dirs(search_paths):
        assert os.path.exists(coll_path) and os.path.isdir(coll_path)

    # bad collection
    for coll_path in list_collection_dirs(['bogus']):
        assert not os.path.exists(coll_path)

    # is collection path
    assert is_collection_path(os.path.join(os.path.dirname(__file__), '..', '..'))

# Generated at 2022-06-10 22:42:31.987046
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-10 22:42:43.163749
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import get_configured_plugins
    from ansible.plugins.loader import find_plugin_files
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.synchronize import ActionModule as SyncActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule
    from ansible.module_utils.facts.system.distribution import Distribution
    import tempfile
    import shutil
    import os


# Generated at 2022-06-10 22:42:49.776852
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    print("Testing function: list_collection_dirs")

    # test existing valid collection
    test_path_1 = "/tmp/"
    test_coll_filter_1 = "acme.aws"

    coll_dir_1 = list(list_collection_dirs(search_paths=[test_path_1], coll_filter=test_coll_filter_1))

    assert len(coll_dir_1) == 1
    assert isinstance(coll_dir_1[0], bytes)
    assert coll_dir_1[0] == "/tmp/ansible_collections/acme/aws"

    # test existing valid collection
    test_path_2 = "/tmp/"
    test_coll_filter_2 = "awesome.aws"


# Generated at 2022-06-10 22:42:53.299338
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    path_list = ["../../../../test_collections"]
    collections = list(list_collection_dirs(path_list))
    assert len(collections) == 4

# Generated at 2022-06-10 22:43:04.780427
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.validation import check_type_str

    collection_paths = ['', '.', '/', '/none/none']
    for path in list_valid_collection_paths(collection_paths):
        check_type_str(path)
        assert isinstance(path, str)

    collection_paths = []
    coll_list = list(list_collection_dirs(collection_paths))
    assert isinstance(coll_list, list)
    for path in coll_list:
        check_type_str(path)
        assert isinstance(path, str)

    collection_paths = ['/none/none']
    coll_list = list(list_collection_dirs(collection_paths))
    assert isinstance(coll_list, list)
    assert not coll_list



# Generated at 2022-06-10 22:43:22.953744
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([])) == list()
    assert list(list_valid_collection_paths(["foo", "bar", "baz"])) == list()
    assert list(list_valid_collection_paths(["foo", "bar", "baz"], True)) == list()

    my_path = os.path.join(os.path.dirname(__file__), '..', '..')
    assert list(list_valid_collection_paths([my_path])) == [my_path]
    assert list(list_valid_collection_paths([my_path], True)) == [my_path]



# Generated at 2022-06-10 22:43:35.539491
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            kwargs['failed'] = True
            raise AnsibleFailJson(kwargs)


# Generated at 2022-06-10 22:43:44.077442
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    dir1 = tempfile.mkdtemp(dir=tmpdir)
    dir2 = tempfile.mkdtemp(dir=tmpdir)
    dir3 = tempfile.mkdtemp(dir=tmpdir)
    fh, file1 = tempfile.mkstemp(dir=tmpdir)
    os.close(fh)
    fh, file2 = tempfile.mkstemp(dir=tmpdir)
    os.close(fh)
    try:
        ret = list(list_valid_collection_paths(search_paths=['/foo/bar', dir1, file1, dir2, file2, dir3]))
        assert ret == [dir1, dir2, dir3]
    finally:
        os.remove(file2)

# Generated at 2022-06-10 22:43:48.259611
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = [
        '/some/invalid/path',
        '/etc/ansible',
        '~/.ansible/collections',
        './collections',
    ]

    result = list_valid_collection_paths(path_list)
    assert len(list(result)) == 2

# Generated at 2022-06-10 22:43:50.009264
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:43:52.143182
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)



# Generated at 2022-06-10 22:43:58.690776
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    if not os.path.exists('/tmp/ansible_collections'):
        os.mkdir('/tmp/ansible_collections')
    if not os.path.exists('/tmp/more_collections'):
        os.mkdir('/tmp/more_collections')

    if not os.path.exists('/tmp/ansible_collections/ns1'):
        os.mkdir('/tmp/ansible_collections/ns1')
    if not os.path.exists('/tmp/ansible_collections/ns1/coll1'):
        os.mkdir('/tmp/ansible_collections/ns1/coll1')
        open('/tmp/ansible_collections/ns1/coll1/__init__.py', 'w').close()

# Generated at 2022-06-10 22:44:10.739863
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # create a fake collection dir
    coll_dir = '/tmp/namespace/collection'
    os.makedirs(coll_dir)
    open(os.path.join(coll_dir, 'plugin_type'), 'w').close()

    assert coll_dir == next(list_collection_dirs(['/tmp']))
    assert coll_dir == next(list_collection_dirs(['/tmp'], 'namespace.collection'))

    try:
        next(list_collection_dirs(['/tmp'], 'namespace.bad_coll'))
        assert False, "Invalid collection was found"
    except StopIteration:
        pass

    # cleanup
    os.remove(os.path.join(coll_dir, 'plugin_type'))
    os.removedirs(coll_dir)

# Generated at 2022-06-10 22:44:19.008335
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    coll_root = tempfile.mkdtemp()
    coll_subdirs = os.path.join(coll_root, 'ansible_collections')
    os.mkdir(coll_subdirs)
    os.mkdir(os.path.join(coll_subdirs, 'namespace1'))
    os.mkdir(os.path.join(coll_subdirs, 'namespace2'))
    os.mkdir(os.path.join(coll_subdirs, 'namespace1', 'collection1'))
    os.mkdir(os.path.join(coll_subdirs, 'namespace2', 'collection2'))
    os.mkdir(os.path.join(coll_subdirs, 'namespace2', 'collection3'))

    # all collections in root

# Generated at 2022-06-10 22:44:25.219093
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.collection_loader import list_collection_dirs, ANSIBLE_COLLECTIONS_PATHS

    print(" %d collection paths in config" % len(ANSIBLE_COLLECTIONS_PATHS))
    print("")

    collections = list_collection_dirs(coll_filter='ansible_namespace.collection_name')

    for collection in collections:
        print("collection: %s" % collection)

# Generated at 2022-06-10 22:44:49.769715
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import list_collection_dirs
    from ansible.module_utils.common.collections import list_valid_collection_paths
    import os

    # Test a function that returns a generator
    coll_generator = list_collection_dirs()

    # Test that it returns a generator
    assert isinstance(coll_generator, types.GeneratorType)

    # Test the generator returns namespaced collection dirs
    assert next(coll_generator) == os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'ansible_collections', 'ns_coll')

    # Test that the generator returns a list of directories to its caller

# Generated at 2022-06-10 22:44:56.206413
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # common patten used in other modules
    coll_path = AnsibleCollectionConfig.DEFAULT_COLLECTIONS_PATHS[0]
    print(coll_path)
    print(list_collection_dirs([coll_path]))
    print(list_collection_dirs([coll_path], coll_filter="geerlingguy.awx"))
    print(list_collection_dirs([coll_path], coll_filter="geerlingguy.awx.1.0.0"))

# Generated at 2022-06-10 22:45:05.357682
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible.fortios.tests.unit.unit_test_loader import load_fixtures
    from ansible.collections.ansible.fortios.plugins.module_utils.network.fortios.fortios_config import CollectionConfigParser

    coll_dir = load_fixtures('ansible_collections')

    colls = list(list_collection_dirs(search_paths=[coll_dir]))

    assert len(colls) == 1
    colls = list(list_collection_dirs(search_paths=[coll_dir], coll_filter='fortios.fortios'))
    cp = CollectionConfigParser(colls[0])
    assert cp.namespace == 'fortios'
    assert cp.collection == 'fortios'

# Generated at 2022-06-10 22:45:16.804829
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

    # Create a collection path
    coll_path = os.path.join(temp_dir, "ansible_collections/namespace/mycollection")
    os.makedirs(coll_path)

    # Create a mock collection dir
    coll_init = os.path.join(coll_path, "__init__.py")
    with open(coll_init, "w") as ci:
        ci.write("# empty\n")

    # Run list_collection_dirs()
    coll_dirs = list(list_collection_dirs(search_paths=[temp_dir]))

    assert len(coll_dirs) == 1

    shutil.rmtree(temp_dir)

# Generated at 2022-06-10 22:45:27.651210
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import NamedTemporaryFile
    from shutil import copy
    import json
    import sys

    coll_root = NamedTemporaryFile(prefix='ansible_collections', dir='/tmp', delete=False)
    coll_root.close()

    coll_one = NamedTemporaryFile(prefix='ansible_collections', dir='/tmp', delete=False)
    coll_one.close()

    coll_two = NamedTemporaryFile(prefix='ansible_collections', dir='/tmp', delete=False)
    coll_two.close()


# Generated at 2022-06-10 22:45:38.541098
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import get_collection_dirs

    # test default path from running in a git checkout with proper env vars
    paths = list(list_collection_dirs())
    path_check = False
    k8s_check = False
    for path in paths:
        if '/ansible/test/units/' in path:
            path_check = True
        if 'ansible_collections/k8s/kubernetes' in path:
            k8s_check = True
    assert path_check is True
    assert k8s_check is True

    # test specific path
    paths = list(list_collection_dirs(['/foo/bar']))
    assert len(paths) == 0

    # test passed collection filter

# Generated at 2022-06-10 22:45:48.183953
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['plugins/collections', collections_path]
    collection_dirs = list_collection_dirs(search_paths)
    assert collections_path in collection_dirs

    search_paths = ['plugins/collections', collections_path]
    collection_dirs = list_collection_dirs(search_paths, 'myns.mycoll')
    assert collections_path in collection_dirs

    search_paths = ['plugins/collections', collections_path]
    collection_dirs = list_collection_dirs(search_paths, 'myns')
    assert collections_path in collection_dirs



# Generated at 2022-06-10 22:45:58.179590
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    coll_paths = [
        '/tmp/ansible_collections/',
        '/tmp/ansible_collections/fictici_collections_path/',
    ]
    try:
        assert list(list_collection_dirs(coll_paths)) == [
            b'/tmp/ansible_collections/fictici_collection_path/',
            b'/tmp/ansible_collections/fictici_collection_path_2/',
        ]
    finally:
        import shutil
        import tempfile
        shutil.rmtree(os.path.join(tempfile.gettempdir(), 'ansible_collections'))

# Generated at 2022-06-10 22:46:02.002546
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([])).sort() == ['.'].sort()
    assert list(list_valid_collection_paths(None)).sort() == ['.'].sort()
    assert list(list_valid_collection_paths(['/tmp'])).sort() == ['/tmp'].sort()


# Generated at 2022-06-10 22:46:03.158407
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter=None)



# Generated at 2022-06-10 22:46:40.156729
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test for list_valid_collection_paths(),
    by checking:
        1. all search path entries with valid paths are included in the list
        2. all search path entries with invalid paths are NOT included in the list
    """

    # Define the search paths to test for
    search_paths = [
        "/tmp/ansible_collections:",
        "/foo/this/path/does/not/exist",
        "/bar/this/path/exists/but/is/not/a/directory"
    ]

    # List valid paths
    valid_paths = [path for path in list_valid_collection_paths(search_paths)]

    # Declare the paths that are expected to be included in the valid path list
    expected_paths = [
        search_paths[0],
    ]

   

# Generated at 2022-06-10 22:46:51.726223
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.config.manager import ConfigManager
    from collections import namedtuple
    import tempfile
    import shutil

    config_manager = ConfigManager()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    search_paths = [os.path.join(tmpdir, 'testdir')]
    # Create a collection in the temporary directory
    coll_dir = os.path.join(search_paths[0], 'ansible_collections', 'windowsserver', 'dsc')
    os.makedirs(coll_dir)
    open(os.path.join(coll_dir, '__init__.py'), 'a').close()
    config_manager.set_config({
        'defaults': {
            'collection_paths': search_paths
        }
    })
   

# Generated at 2022-06-10 22:47:00.602771
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Neither path exists
    assert list(list_valid_collection_paths(search_paths=['/tmp/1/2/3/4', '/tmp/a/b/c/d'])) == []

    # just one path exists
    assert list(list_valid_collection_paths(search_paths=['/tmp/1/2/3/4', '/tmp'])) == ['/tmp']

    # both paths exist
    assert list(list_valid_collection_paths(search_paths=['/tmp/1/2/3/4', '/tmp'])) == ['/tmp']

    # Both paths assigned as default, only one exists
    assert list(list_valid_collection_paths()) == ['/usr/share/ansible/collections']

    # Both paths assigned as default, both exist

# Generated at 2022-06-10 22:47:04.496933
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp', '../..'])) == ['/tmp']
    assert list(list_valid_collection_paths(['/tmp', '/dev/null', '../..'])) == ['/tmp']


# Generated at 2022-06-10 22:47:10.777810
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # import pdb; pdb.set_trace()
    cwd = os.path.dirname(os.path.abspath(__file__))
    collection_dirs = list(list_collection_dirs([os.path.join(cwd, 'unit-tests/collections/')]))
    assert len(collection_dirs) == 1
    assert collection_dirs[0].endswith('unit-tests/collections/ansible_collections/somecoll')

# Generated at 2022-06-10 22:47:13.014858
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Return the results of function list_collection_dirs
    """
    for res_coll_dir in list_collection_dirs():
        print(res_coll_dir)

# Generated at 2022-06-10 22:47:16.281213
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    coll_dirs = list_collection_dirs(search_paths)
    assert len(list(coll_dirs)) > 0

# Generated at 2022-06-10 22:47:19.187583
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with default settings
    # get list of valid paths with defaults
    # check that it is not empty
    vpaths = list(list_valid_collection_paths())

    assert len(vpaths) > 0

# Generated at 2022-06-10 22:47:29.453437
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import unittest

    def get_ansible_collections_path():
        locations = [
            # the installed path
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'),
            # the source code path
            os.path.join(os.path.abspath(__file__), '..', '..')
        ]
        for loc in locations:
            loc = os.path.normpath(loc) # case windows, mingw
            if os.path.exists(loc):
                return loc
        return ''

    collections_path = get_ansible_collections_path()
    sys.path.insert(0, collections_path)


# Generated at 2022-06-10 22:47:40.019404
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_dir1 = mkdtemp(dir=temp_dir)
    temp_dir2 = mkdtemp(dir=temp_dir)
    temp_dir3 = mkdtemp(dir=temp_dir)
    temp_dir4 = mkdtemp(dir=temp_dir)
    with open(temp_dir2, 'w') as f:
        f.write('foo')
    temp_dir5 = mkdtemp(dir=temp_dir)

# Generated at 2022-06-10 22:48:45.347217
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths() - filter out non-existing path elements
    """

    bad_path = ['/dev/nul']
    assert [] == list(list_valid_collection_paths(search_paths=bad_path))

    good_path = ['/dev']
    assert good_path == list(list_valid_collection_paths(search_paths=good_path))

    good_path = ['/dev', '/dev/nul']
    assert ['/dev'] == list(list_valid_collection_paths(search_paths=good_path))
    assert ['test'] == list(list_valid_collection_paths(search_paths=['test']))
    assert [] == list(list_valid_collection_paths(search_paths=['test/test']))

# Generated at 2022-06-10 22:48:49.285672
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths(search_paths=[])
    assert len(list(paths)) == len(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-10 22:49:00.918736
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup
    coll_dir_root_1 = 'test/example_collection_dir'
    coll_dir_root_2 = 'test/example_collection_dir2'
    test_collection_name = 'example_collection'
    test_collection_namespace = 'namespace'
    test_collection_fullname = '{}.{}'.format(test_collection_namespace, test_collection_name)

    # Instantiate mock get_config
    AnsibleCollectionConfig.get_config = lambda: []

    # Add directories and collections
    AnsibleCollectionConfig.collection_paths.extend([coll_dir_root_1, coll_dir_root_2])

# Generated at 2022-06-10 22:49:09.134527
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # set up mock collection paths
    mock_collection_paths = [
        '/usr/share',
        '/usr/local/share/ansible/collections',
        os.path.expanduser('~/.ansible/collections'),
        '/usr/share/ansible/collections',
        '/usr/local/lib/ansible/collections',
    ]

    # set up mock paths
    mock_paths = [
        '/tmp',
        '/do/not/exist',
        None,
        '/usr/local/share/ansible/collections',
        '/',
    ]

    # define expected result
    expected_list = [
        '/usr/local/share/ansible/collections',
    ]

    # test first use case

# Generated at 2022-06-10 22:49:16.361765
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        os.path.join('test', 'support', 'collection-invalid'),
        os.path.join('test', 'support', 'collection-valid'),
    ]

    paths = list(list_valid_collection_paths(search_paths))
    assert len(paths) == 1
    assert paths[0] == os.path.join('test', 'support', 'collection-valid')


# Generated at 2022-06-10 22:49:24.277195
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths

    # Make a temp dir and add to the search paths
    from tempfile import mkdtemp
    tmpdir = mkdtemp()
    search_paths = [tmpdir]

    # Test that the temporary directory exists and is returned
    for path in list_valid_collection_paths(search_paths):
        assert(os.path.exists(path))
        assert(path == tmpdir)

# Generated at 2022-06-10 22:49:35.154842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    test listing of collection dirs.
    :return:
    """
    from ansible.utils.collection_loader import list_collection_dirs

    results = []
    for r in list_collection_dirs(['test/unit/test_utils/testdata/collections_path1',
                                   'test/unit/test_utils/testdata/collections_path2',
                                   'test/unit/test_utils/testdata/collections_path3'],
                                   'testns.collection1'):
        results.append(r)

    results = [os.path.basename(y) for y in results]
    assert(len(results) == 1)
    assert(results[0] == 'collection1')

    results = []

# Generated at 2022-06-10 22:49:42.207788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert(len(list(list_valid_collection_paths(['/foo/bar/baz']))) == 0)
    assert(len(list(list_valid_collection_paths(['/etc/ansible']))) == 0)
    assert(len(list(list_valid_collection_paths(['/usr/bin']))) == 0)
    assert(len(list(list_valid_collection_paths(['/usr']))) == 1)
    assert(len(list(list_valid_collection_paths(['/tmp']))) == 1)


# Generated at 2022-06-10 22:49:52.233505
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    # Support function to create fake collections
    def create_collection(collection_root, namespaces, collections):
        ns_cols = collections.keys()

        for ns in namespaces:
            for mycoll in collections[ns]:
                base = os.path.join(collection_root, ns, mycoll, 'tests')
                os.makedirs(base)

    # Setup fake collection directories
    root_temp = tempfile.mkdtemp()
    # create a temp file as well (invalid collection)
    temp_file = tempfile.NamedTemporaryFile(delete=False)

    # 10 namespaces
    nss = ['ns' + str(n) for n in range(10)]

    # 10 collections per namespace
    colls = {}

# Generated at 2022-06-10 22:49:59.670585
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the list_valid_collection_paths function
    """

    search_paths = ['/tmp/ansible_collections_1', '/tmp/ansible_collections_2', '/tmp/ansible_collections_3']

    # the following list should be identical to search_paths as all are valid
    results = list_valid_collection_paths(search_paths=search_paths)
    assert len(results) == 3
    assert '/tmp/ansible_collections_1' in results
    assert '/tmp/ansible_collections_2' in results
    assert '/tmp/ansible_collections_3' in results

    # now break a few