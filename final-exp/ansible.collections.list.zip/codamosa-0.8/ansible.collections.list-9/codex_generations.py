

# Generated at 2022-06-10 22:40:45.497024
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, 'foo')
    shutil.copytree('test/unit/utils/test_collections/ansible_collections', tmp_path)
    shutil.copytree('test/unit/utils/test_collections/test_collections2/test_namespace', 'test/unit/utils/test_collections/test_collections2/test_namespace') # noqa
    good_paths = list_valid_collection_paths([tmp_path, 'test/unit/utils/test_collections/test_collections2', 'test/unit/utils/test_collections/test_collections2/foo']) # noqa
    assert tmp_path in good_paths

# Generated at 2022-06-10 22:40:49.773546
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = ["bogus", "/non-existent/bogus", "/etc/ldap/slapd.d"]
    for path in list_valid_collection_paths(search_paths=test_paths, warn=True):
        assert os.path.isdir(path)
        assert path in ['/etc/ldap/slapd.d']


# Generated at 2022-06-10 22:40:52.225126
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = ['/tmp/test/collections', '/tmp/test2/collections']

    for path in list_collection_dirs(test_paths):
        assert isinstance(path, bytes)

# Generated at 2022-06-10 22:40:54.838245
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collections = list_collection_dirs(coll_filter='namespace.collection')
    assert test_collections is not None

# Generated at 2022-06-10 22:41:00.616435
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(search_paths=['/Users/developer/.ansible/collections:collections']))
    assert len(coll_dirs) == 1, coll_dirs
    assert '/Users/developer/.ansible/collections/ansible_collections/ansible/netcommon' in coll_dirs



# Generated at 2022-06-10 22:41:02.666393
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert (list(list_valid_collection_paths(["/path/to/nowhere", "/"])) == ['/'])

# Generated at 2022-06-10 22:41:11.513077
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    b_coll_path = to_bytes('../ansible_collections')

    assert list(list_collection_dirs(search_paths=[b_coll_path]))
    assert list(list_collection_dirs(search_paths=[b_coll_path], coll_filter='ansible_namespace'))
    assert list(list_collection_dirs(search_paths=[b_coll_path], coll_filter='ansible_namespace.module'))
    assert list(list_collection_dirs(search_paths=[b_coll_path], coll_filter='ansible_namespace.module.subcollection'))

# Generated at 2022-06-10 22:41:21.712374
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    :return: list of collection directory paths
    """
    coll_paths = list_valid_collection_paths(["/invalid/path1","/invalid/path2"])
    assert(len(list(coll_paths)) == len(AnsibleCollectionConfig.collection_paths))

    coll_paths = list_valid_collection_paths(["/invalid/path"])
    assert(len(list(coll_paths)) == len(AnsibleCollectionConfig.collection_paths))

    coll_paths = list_valid_collection_paths([])
    assert(len(list(coll_paths)) == len(AnsibleCollectionConfig.collection_paths))


# Generated at 2022-06-10 22:41:28.545244
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import unittest
    import tempfile
    import textwrap

    class TestListValidCollectionPaths(unittest.TestCase):
        def setUp(self):
            self.base_dir = tempfile.mkdtemp(suffix='ansible_collections_test')
            self.v_good_path = self.base_dir + "/ansible_collections"
            self.bad_path = self.base_dir + "/ansible_collection"
            self.bad_path2 = self.base_dir + "/ansible_collections/file"
            self.v_good_path2 = self.base_dir + "/ansible_collections2"

            self.orig_search_paths = AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-10 22:41:31.818244
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['not_here', '/tmp', '/root']
    my_list = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(my_list) == 1
    assert my_list[0] == '/tmp'

# Generated at 2022-06-10 22:41:49.568521
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        'test/units/module_utils/ansible_test/_data/collections_1',
        'test/units/module_utils/ansible_test/_data/collections_2',
        'test/units/module_utils/ansible_test/_data/collections_3',
        'test/units/module_utils/ansible_test/_data/collections_4',
        'test/units/module_utils/ansible_test/_data/collections_5',
        'test/units/module_utils/ansible_test/_data/collections_6',
        'test/units/module_utils/ansible_test/_data/collections_7',
        'test/units/module_utils/ansible_test/_data/collections_8',
    ]
    collection_dir

# Generated at 2022-06-10 22:41:56.864031
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    tmp_directory = '/tmp/valid-paths'

    # Create directory
    os.makedirs(tmp_directory)

    assert list(list_valid_collection_paths([tmp_directory])) == [tmp_directory]
    assert list(list_valid_collection_paths([join(tmp_directory, 'does-not-exist')])) == []
    assert list(list_valid_collection_paths([join(tmp_directory, 'does-not-exist')], warn=True)) == []

    # Create file
    open(join(tmp_directory, 'file'), 'a').close()

    assert list(list_valid_collection_paths([join(tmp_directory, 'file')])) == []

# Generated at 2022-06-10 22:42:00.642445
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        "/dev/null",
        "/does/not/exist",
    ]

    for path in list_valid_collection_paths(test_paths):
        assert path in test_paths


# Generated at 2022-06-10 22:42:10.501768
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [os.path.dirname(os.path.dirname(__file__))]

    collection_dirs = list_collection_dirs(search_paths=search_paths)
    assert len(collection_dirs) != 0

    # collection_dirs = list_collection_dirs(search_paths=search_paths, coll_filter='ansible_collections.namespace.collection')
    # assert len(collection_dirs) == 1

    collection_dirs = list_collection_dirs(coll_filter='nonexistent')
    assert len(collection_dirs) == 0

    collection_dirs = list_collection_dirs(coll_filter='nonexistent.collection')
    assert len(collection_dirs) == 0


# Generated at 2022-06-10 22:42:18.323910
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.ansible_release import __version__

    # Test with empty list
    path_list = []
    count = 1
    for path in list_collection_dirs(path_list):
        # We should find core under default paths
        assert count == 1, "Expected to find ansible_collections/ansible/core"
        assert path.endswith("ansible_collections/ansible/core"), 'Path should end with ansible_collections/ansible/core, not %s' % path

        count += 1

    # add a path to the list
    test_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/cloud')
    path_list.append(test_path)

    # Test with non-empty list
   

# Generated at 2022-06-10 22:42:21.534933
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Make sure that list_collection_dirs provides valid collection paths
    """
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) > 0


# Generated at 2022-06-10 22:42:24.787075
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # this function is tested by test_collections_loader and since the fixtures are the same
    # test_collections_loader.py test_collections_loader_list_collections() can be used to test
    pass

# Generated at 2022-06-10 22:42:27.481555
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.cli.arguments import optional_dir_argument
    from ansible.config.manager import ConfigManager
    from ansible.config.loader import load_config_file
    impor

# Generated at 2022-06-10 22:42:40.218711
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from tempfile import mkdtemp

    with pytest.raises(AnsibleError):
        list_valid_collection_paths([])

    # temp directory that doesn't exist
    tmp = "{0}/{1}".format(mkdtemp(), 'test')

    # test empty list, should return default
    data = list(list_valid_collection_paths([]))
    assert data == AnsibleCollectionConfig.collection_paths

    # test with one existing dir
    data = list(list_valid_collection_paths(["/"]))
    assert len(data) == 1

    # test with two existing dirs
    data = list(list_valid_collection_paths(["/", "/etc"]))
    assert len(data) == 2

    # test with one existing dir and one missing
   

# Generated at 2022-06-10 22:42:44.567039
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # relative path
    assert 'ansible_collections/acme/mycoll' in list_collection_dirs(['./'])
    assert 'ansible_collections/acme/mycoll' in list_collection_dirs(['./ansible_collections'])
    # absolute path
    cwd = os.getcwd()
    assert cwd + '/ansible_collections/acme/mycoll' in list_collection_dirs([cwd])
    assert cwd + '/ansible_collections/acme/mycoll' in list_collection_dirs([cwd + '/ansible_collections'])
    # filter by collection
    assert 'ansible_collections/acme/mycoll' in list_collection_dirs(coll_filter='acme.mycoll')

# Generated at 2022-06-10 22:43:08.691853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test
    search_paths = ['tests/fixtures/collections/ansible_collections/namespace1/collection1/']
    full_collection_names = ['namespace1.collection1']
    for collection_dir in list_collection_dirs(search_paths=search_paths, coll_filter=None):
        full_name = os.path.basename(os.path.dirname(collection_dir)) + '.' + os.path.basename(collection_dir)
        assert full_name in full_collection_names
    # Test missing paths
    search_paths = ['tests/fixtures/collections/non_existent/']
    for collection_dir in list_collection_dirs(search_paths=search_paths):
        assert False
    # Test file paths

# Generated at 2022-06-10 22:43:21.007798
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

    collection_path = os.path.join(tmpdir, 'collections')
    os.mkdir(collection_path)
    os.mkdir(os.path.join(collection_path,'collection'))

    os.mkdir(os.path.join(tmpdir, 'other'))

    os.mkdir(os.path.join(tmpdir, 'doesnotexist'))
    os.unlink(os.path.join(tmpdir, 'doesnotexist'))

    os.mkdir(os.path.join(tmpdir, 'brokenpath'))

# Generated at 2022-06-10 22:43:27.755299
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible_collections.myns.mycoll.tests.unit.compat import unittest
    from ansible_collections.myns.mycoll.tests.unit.compat.mock import patch

    class TestListValidCollectionPaths(unittest.TestCase):

        def setUp(self):
            self.mock_listdir_patch = patch('os.listdir', return_value=[])
            self.mock_listdir = self.mock_listdir_patch.start()

        def tearDown(self):
            self.mock_listdir_patch.stop()


# Generated at 2022-06-10 22:43:39.752946
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Unit Tests for list_valid_collection_paths """
    import tempfile
    import shutil
    from time import time

    # Create temp collection
    tmp_dir = tempfile.mkdtemp()
    b_tmp_dir = to_bytes(tmp_dir, errors='surrogate_or_strict')


# Generated at 2022-06-10 22:43:40.927498
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-10 22:43:46.607438
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # create temp folder with
    # ansible_collections/
    # ansible_collections/test_namespace/
    # ansible_collections/test_namespace/test_collection/
    # test_collection/

    import tempfile
    import shutil
    import os

    temp_root_path = tempfile.mkdtemp()
    test_coll_root_path = os.path.join(temp_root_path, 'ansible_collections')
    os.mkdir(test_coll_root_path)
    os.mkdir(os.path.join(test_coll_root_path, 'test_namespace'))
    os.mkdir(os.path.join(test_coll_root_path, 'test_namespace', 'test_collection'))

# Generated at 2022-06-10 22:43:55.663355
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test for missing path (both formats)
    search_paths = ["invalid_path", "/even/more/invalid/path"]
    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=True))
    assert(len(valid_paths) == 0)

    # test for invalid path
    search_paths = ["/etc/passwd", "/tmp/foo.bar"]
    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=True))
    assert(len(valid_paths) == 0)

    # test for a valid path
    search_paths = ["/tmp/foo.txt", "/tmp/bar.txt"]

# Generated at 2022-06-10 22:44:06.804817
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    current_dir = os.path.dirname(__file__)
    ansible_collections_dir = os.path.join(current_dir, 'roles', 'roles_galaxy_yaml')
    paths = [ansible_collections_dir]
    collection_dirs = list(list_collection_dirs(search_paths=paths))
    assert len(collection_dirs) == 3
    assert os.path.join(ansible_collections_dir, 'example.test', 'test') in collection_dirs
    assert os.path.join(ansible_collections_dir, 'example.test', 'test2') in collection_dirs
    assert os.path.join(ansible_collections_dir, 'example.test', 'test4') in collection_dirs

    collection_dirs = list

# Generated at 2022-06-10 22:44:16.737323
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import logging
    import tempfile
    import shutil


# Generated at 2022-06-10 22:44:27.263050
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = ['test/test_search_paths']
    test_paths_coll = ['test/test_search_paths']

    # Valid search paths
    assert len(list(list_collection_dirs(search_paths=test_paths))) == 1
    # Invalid search paths
    assert len(list(list_collection_dirs(search_paths=['test/invalid_dir']))) == 0

    # Test coll filter on search path with no colls
    assert len(list(list_collection_dirs(search_paths=['test/test_search_paths/invalid']))) == 0

    # Test coll filter on search path with single valid coll
    test_paths_coll.append('test/test_search_paths/valid/ansible_collections/test/test_collection')


# Generated at 2022-06-10 22:44:55.206461
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list(list_collection_dirs())
    assert result
    assert len(result) > 0



# Generated at 2022-06-10 22:44:59.569516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # create the test dir
    os.mkdir(r'/tmp/mytestpath')
    # run the list_valid_collection_paths function
    assert list_valid_collection_paths([r'/tmp/mytestpath']) == ['tmp/mytestpath']
    # clean up the test dir
    os.rmdir(r'/tmp/mytestpath')


# Generated at 2022-06-10 22:45:10.692240
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function list_collection_dirs
    """
    # Ensure we get no collections when we pass in invalid paths
    assert list(list_collection_dirs(search_paths=["/some/bad/path", "/and/another/bad/path"])) == []

    # Ensure we get system collections when we pass in no paths
    assert list(list_collection_dirs(search_paths=None)) == list(list_collection_dirs(search_paths=[]))
    assert all("/ansible_collections" in x for x in list(list_collection_dirs(search_paths=None)))

    # Ensure we get no collections when we pass in empty string
    assert list(list_collection_dirs(search_paths=[""])) == []

    # Ensure we get only collections for the specified namespace when we

# Generated at 2022-06-10 22:45:20.141410
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    # mock import of AnsibleCollectionConfig
    class AnsibleCollectionConfigMock:
        def __init__(self, collection_path=None):
            self.collection_paths = []
            if collection_path is not None:
                self.collection_paths = [collection_path]

    # mock import of AnsibleError
    class AnsibleErrorMock(Exception):
        pass

    # mock import of Display
    class DisplayMock:
        def __init__(self):
            pass

        def warning(self, text):
            print("MockWarning: %s" % text)


# Generated at 2022-06-10 22:45:32.981627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    moduleDir = os.path.dirname(__file__)
    moduleFancyPath = "%s/test/test_collections/my_namespace/my_collection/plugins" % moduleDir
    moduleFancyPath2 = "%s/test/test_collections/my_namespace/my_collection/roles/utility/cluster-check" % moduleDir
    moduleFancyPath3 = "%s/test/test_collections/my_namespace/my_collection/roles/utility/cluster-check/tasks/main.yml" % moduleDir

    coll = list_collection_dirs([moduleFancyPath, moduleFancyPath2, moduleFancyPath3])

    if not coll:
        raise AssertionError("list_collection_dirs returned empty list")

    # walk the path to ensure it is a

# Generated at 2022-06-10 22:45:42.516308
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test default
    search_paths = []
    coll_paths = list_valid_collection_paths(search_paths)
    assert isinstance(coll_paths, list)

    # test with path that does not exist
    search_paths.append('/tmp/does not exist')
    coll_paths = list_valid_collection_paths(search_paths)
    assert isinstance(coll_paths, list)

    # test with existing directory
    search_paths.append('/tmp')
    coll_paths = list_valid_collection_paths(search_paths)
    assert isinstance(coll_paths, list)


# Generated at 2022-06-10 22:45:53.612728
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        os.path.join(os.path.dirname(__file__), "__fixtures__/collections"),
        os.path.join(os.path.dirname(__file__), "__fixtures__/collections_foo")
    ]

    assert sorted([x for x in list_collection_dirs(search_paths, coll_filter="foo.bar")]) == sorted([
        os.path.join(os.path.dirname(__file__), "__fixtures__/collections/foo/bar"),
        os.path.join(os.path.dirname(__file__), "__fixtures__/collections_foo/foo/bar")
    ])


# Generated at 2022-06-10 22:46:01.788205
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = set(['fakecoll/ansible_collections/some_namespace/some_collection',
                        'some_other_fakecoll/ansible_collections/some_namespace/some_collection'])

    valid_collections = set(['some_collection'])

    # Invalid collection path should not be returned
    bad_valid_collections = set(['some_collection', 'some_other_fakecoll/ansible_collections/some_namespace/some_bad_collection'])


# Generated at 2022-06-10 22:46:12.555559
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    def mock_listdir(path):
        if path == '/foo/bar':
            return ['ns1', 'ns2']
        elif path == '/foo/bar/ns1':
            return ['coll1', 'coll2']
        elif path == '/foo/bar/ns2':
            return ['coll3', 'coll4']
        else:
            return []
    old_listdir = os.listdir
    os.listdir = mock_listdir
    my_dirs = list(list_collection_dirs(search_paths=['/foo/bar']))
    assert my_dirs == ['/foo/bar/ns1/coll1', '/foo/bar/ns1/coll2', '/foo/bar/ns2/coll3', '/foo/bar/ns2/coll4']
    os.listdir = old

# Generated at 2022-06-10 22:46:21.180018
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import ansible_collections_path

    paths = [
        os.path.expanduser('~/my-collections/'),
        ansible_collections_path(),
    ]

    # None should be ignored
    paths.append(None)

    # test that invalid paths are ignored
    paths.append('/jkbvb/jfs16gf')
    paths.append(os.path.expanduser('~/my-collections/foo'))

    paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(paths) == 2

    # tests that default path is not ignored
    paths = list(list_valid_collection_paths(None, warn=False))
    assert len(paths) == 1



# Generated at 2022-06-10 22:47:27.592862
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path1 = '/usr/share/ansible/collections'
    path2 = 'invalid_path'
    path3 = '~/invalid_path'
    path4 = '~/invalid_path/ansible_collections'
    search_paths = [path1, path2, path3, path4]
    valid_collection_paths = list_valid_collection_paths(search_paths, True)

    # test for lower and upper case, to make sure that path was normalized to lower
    assert(path1 in valid_collection_paths)

    # test for warning
    assert(path2 in valid_collection_paths)

    # test for warning
    assert(path3 in valid_collection_paths)

    # test for warning
    assert(path4 in valid_collection_paths)


#

# Generated at 2022-06-10 22:47:32.034994
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_path = [os.path.join(os.path.dirname(__file__), 'data/collections_path')]

    for mycoll in list_collection_dirs(search_paths=test_path):
        print ("Collection: %s" % mycoll)

# Generated at 2022-06-10 22:47:40.939616
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.community.tests.unit.compat.mock import patch
    from ansible.config.collection_loader import AnsibleCollectionConfig
    from ansible_collections.community.tests.unit.compat.mock import PropertyMock

    good_dir = '/go/collections/dir'
    bad_dir = '/no/collections/here'

    with patch.object(AnsibleCollectionConfig, 'collection_paths', new_callable=PropertyMock) as patch_collection_paths:
        patch_collection_paths.return_value = [bad_dir, good_dir]
        g = list_valid_collection_paths()
        assert list(g) == [good_dir]


# Generated at 2022-06-10 22:47:52.846352
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    result = dict()
    for path in list_collection_dirs(search_paths=['/test/ansible_collections'], coll_filter='name.space'):
        result[path] = 1
    assert result == {'/test/ansible_collections/name/space': 1, '/test/ansible_collections/namespace': 1}

    result = dict()
    for path in list_collection_dirs(search_paths=['/test/ansible_collections'], coll_filter='name.space'):
        result[path] = 1
    assert result == {'/test/ansible_collections/name/space': 1, '/test/ansible_collections/namespace': 1}

    result = dict()

# Generated at 2022-06-10 22:48:00.274069
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_exist = list_valid_collection_paths(['./test/data/collections', './test/data/badpath'])
    assert len(list(path_exist)) == 1

    path_not_exist = list_valid_collection_paths(['./test/data/badpath', './test/data/badpath2'])
    assert len(list(path_not_exist)) == 0

    path_not_exist = list_valid_collection_paths(['./test/data/badpath', './test/data/badpath2'], warn=True)
    assert len(list(path_not_exist)) == 0

# Generated at 2022-06-10 22:48:12.057528
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # by default, only the configured (default) collection paths are returned
    coll_paths = list(list_valid_collection_paths())
    assert len(coll_paths) == 2

    # if no collection paths exist or are invalid non should be returned
    coll_paths = list(list_valid_collection_paths(search_paths=['/no/such/path']))
    assert len(coll_paths) == 0

    # if valid search_paths are provided, they will be returned as long as they exist
    coll_paths = list(list_valid_collection_paths(search_paths=['/tmp']))
    assert len(coll_paths) == 1
    assert '/tmp' in coll_paths



# Generated at 2022-06-10 22:48:14.269106
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.mkstemp()

    assert len(list(list_valid_collection_paths(['/foo/bar', temp_dir, temp_file[1]]))) == 1

# Generated at 2022-06-10 22:48:21.464544
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Tests that this function returns a generator that yields all valid paths
    when passed a list of valid paths.
    :return:
    """
    path1 = "/test_path/test_file1"
    path2 = "/test_path/test_file2"
    path3 = "/test_path/test_file3"

    search_paths = [path1, path2, path3]

    output = list_valid_collection_paths(search_paths)
    assert type(output) is type(iter([]))
    assert list(output) == [path1, path2, path3]



# Generated at 2022-06-10 22:48:31.108470
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Unit test for function list_collection_dirs
    collection_path = [os.path.join(os.path.dirname(__file__), '..', '..', 'packaging', 'test_collections')]
    search_paths = [os.path.join(os.path.dirname(__file__), '..', '..', 'packaging', 'test_collections')]
    coll_namespace_collection = "c1.c1"
    collections = list_collection_dirs(search_paths, coll_namespace_collection)

    for collection in collections:
        collection = collection.decode('utf-8')
        assert os.path.join(collection_path[0], 'c1', 'c1') == collection

# Generated at 2022-06-10 22:48:39.654368
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.collections.ansible.community.plugins.module_utils.network.f5.bigip import list_valid_collection_paths
    p = list(list_valid_collection_paths(search_paths=["~/ansible_collections"]))
    print(p)
    p = list(list_collection_dirs(search_paths=["~/ansible_collections"], coll_filter="community.general"))
    print(p)

if __name__ == '__main__':
    test_list_collection_dirs()