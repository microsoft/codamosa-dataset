

# Generated at 2022-06-10 22:40:44.528385
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.compat.tests.mock import patch

    import tempfile
    import shutil
    import os

    tmp = tempfile.mkdtemp()
    display = Display()

    path = os.path.join(tmp, 'ns1', 'coll1')
    path = os.path.join(path, 'plugins', 'modules')
    makedirs_safe(path)

    path = os.path.join(tmp, 'ns2', 'coll2')
    path = os.path.join(path, 'plugins', 'modules')
    makedirs_safe(path)

    path = os.path.join(tmp, 'ns2', 'coll2', 'foo')
    path = os.path.join

# Generated at 2022-06-10 22:40:51.610589
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from unittest.mock import patch, call
    from ansible.module_utils.common.warnings import _load_warnings_filters
    import ansible

    with patch('ansible.collections.ansible_collections.config.display.warning') as warn_mock:
        display.verbosity = 0
        display.deprecate("test")
        assert warn_mock.call_count == 1
        assert warn_mock.call_args == call("test")

    with patch('ansible.collections.ansible_collections.config.display.warning') as warn_mock:
        display.verbosity = 3
        display.deprecate("test")
        assert warn_mock.call_count == 0

    # test with mock display, so that we can assert no output


# Generated at 2022-06-10 22:41:02.713442
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import os

    dirs = []
    baddirs = []

# Generated at 2022-06-10 22:41:14.000320
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    def test_list_collection_dirs_helper(coll_filter,
                                         search_paths=None,
                                         expected_results=None):

        actual_results = list(list_collection_dirs(search_paths=search_paths,
                                                   coll_filter=coll_filter))
        assert actual_results == expected_results

    # Should return all collection paths for filter=None
    test_list_collection_dirs_helper(
        coll_filter=None,
        search_paths=['Foo/Bar/ansible_collections',
                      'Baz/qux/quux'],
        expected_results=['Foo/Bar/ansible_collections/Foo/Bar',
                          'Baz/qux/quux/Baz/qux'])

    # Should filter paths

# Generated at 2022-06-10 22:41:17.353523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_path = ['/tmp/doesnotexist',
                   '/tmp/collection']

    for path in list_valid_collection_paths(search_paths=search_path):
        assert path == '/tmp/collection'

# Generated at 2022-06-10 22:41:27.591949
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # create fake home dir and collection path
    temp_home_dir = tempfile.mkdtemp()
    non_existent_path = os.path.join(temp_home_dir, "fake_collections")
    valid_collections_path = os.path.join(temp_home_dir, "valid_collections")
    os.mkdir(valid_collections_path)
    temp_collection_paths = [non_existent_path, valid_collections_path]

    # no search_paths
    gen = list_valid_collection_paths()
    for path in gen:
        assert path

    # breaks with warnings, warn is on by default
    gen = list_valid_collection_paths(temp_collection_paths)   # warning expected
    for path in gen:
        assert path



# Generated at 2022-06-10 22:41:30.321931
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs(coll_filter='ansible_collections')
    for coll_dir in coll_dirs:
        #print(coll_dir)
        pass

# Generated at 2022-06-10 22:41:36.177247
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the function list_valid_collection_paths
    """

    cur_dir = os.path.dirname(__file__)
    # test a few known valid paths that exist
    input_paths = ['/etc/ansible/collections',
                   os.path.abspath(os.path.join(cur_dir, '../../test/collections/ansible_collections')),
                   '_random_path_that_does_not_exist_',
                   '.']

    out_paths = list(list_valid_collection_paths(input_paths))
    assert len(out_paths) == 2
    assert os.path.abspath(os.path.join(cur_dir, '../../test/collections/ansible_collections')) in out_paths

# Generated at 2022-06-10 22:41:37.738840
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs())
    assert coll_dirs

# Generated at 2022-06-10 22:41:48.902088
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths

    assert list(list_valid_collection_paths((None, None))) == AnsibleCollectionConfig.collection_paths

    assert list(list_valid_collection_paths([None, None])) == AnsibleCollectionConfig.collection_paths

    assert list(list_valid_collection_paths([to_bytes(os.path.expanduser("~/.ansible/collections"), errors='surrogate_or_strict')])) == \
           [to_bytes(os.path.expanduser("~/.ansible/collections"), errors='surrogate_or_strict')]


# Generated at 2022-06-10 22:42:14.102832
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath

    # Check that collection directories that do not exist or are not a directory are not part of results
    invalid_colls = ['/does/not/exist', '/does/not/exist/ansible_collections', '/does/not/exist/ansible_collections/collection']
    assert len(list(list_collection_dirs(invalid_colls))) == 0

    # Check that all collection directories that exist and are a directory are returned
    coll_dirs = ['/path/a', '/path/b/ansible_collections', '/path/c/ansible_collections/collection']
    coll_dirs_normalized = [unfrackpath(cdir) for cdir in coll_dirs]

# Generated at 2022-06-10 22:42:20.038136
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    expected = 'test_collection'
    search_paths = ['test/units/utils/fixtures/fakedir_for_testing_list_collection_dirs']
    coll_dirs = list(list_collection_dirs(search_paths))
    coll = coll_dirs[0]
    coll_name = os.path.basename(coll)
    assert expected == coll_name



# Generated at 2022-06-10 22:42:28.294766
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    display.vvv = True
    display.verbosity = 4
    # pass in a coll_filter to just get back a single collection
    collections = list(list_collection_dirs([os.path.join(os.path.dirname(__file__), 'data')], coll_filter='ansible_collections.food'))
    assert len(collections) == 1

    # without a coll_filter, all collections are returned
    collections = list(list_collection_dirs([os.path.join(os.path.dirname(__file__), 'data')]))
    assert len(collections) == 2

# Generated at 2022-06-10 22:42:40.501023
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-10 22:42:52.579564
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    loader = AnsibleCollectionConfig()
    default_collection_paths = loader.get_collection_paths()

    # Test with default collection paths and all search paths valid
    paths = None
    assert set(list_valid_collection_paths(paths)) == set(default_collection_paths)

    # Test with default collection paths, some paths are invalid.
    paths = ['/foo/bar', '/usr/share/ansible/collections', '/foo/bar/baz']
    assert list_valid_collection_paths(paths) == ['/usr/share/ansible/collections']

    # Test with default collection paths and empty search path
    paths = []
    assert set(list_valid_collection_paths(paths)) == set(default_collection_paths)

    # Test with default collection paths and empty search path and

# Generated at 2022-06-10 22:43:04.551217
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    lib_coll_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'collections')
    search_paths = [lib_coll_path]
    coll_dirs = list(list_collection_dirs(search_paths))
    assert len(coll_dirs) == 4
    path_exists = False
    for dir in coll_dirs:
        if dir.endswith('stdlib'):
            path_exists = True
    assert path_exists
    coll_dirs = list(list_collection_dirs(search_paths, coll_filter='ansible.module_utils'))
    assert len(coll_dirs) == 1

# Generated at 2022-06-10 22:43:07.693295
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/not/a/path', '/a/valid/path']
    valid_paths = list(list_valid_collection_paths(paths, warn=True))
    assert valid_paths == ['/a/valid/path']

# Generated at 2022-06-10 22:43:11.657007
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [os.path.join(os.path.dirname(__file__), '..', '..')]
    list_dirs = list(list_collection_dirs(search_paths, 'collections.ansible_collections'))
    assert len(list_dirs) == 1
    assert os.path.basename(list_dirs[0]) == 'ansible_collections'

# Generated at 2022-06-10 22:43:19.634171
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths()
    :return:
    """

    expected = ('/tmp/test_collections', '/tmp/test_collections2')
    search_paths = ('/tmp/test_collections', '/tmp/test_collections2', '/tmp/none')
    paths = list_valid_collection_paths(search_paths)
    assert isinstance(paths, list)
    assert paths == expected



# Generated at 2022-06-10 22:43:27.401286
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list(list_collection_dirs(['/tmp']))
    assert len(coll_dirs) == 0

    # Test empty path
    coll_dirs = list(list_collection_dirs([]))
    assert len(coll_dirs) == 0

    expected_path = '/tmp/ansible_collections/acme'
    coll_dirs = list(list_collection_dirs(['/tmp'], 'acme'))
    assert len(coll_dirs) == 1
    assert coll_dirs[0] == expected_path

    expected_path = '/tmp/ansible_collections/acme.pie'
    coll_dirs = list(list_collection_dirs(['/tmp'], 'acme.pie'))
    assert len(coll_dirs) == 1


# Generated at 2022-06-10 22:44:07.104974
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    import shutil

    search_paths = [
        'bad',
        'good',
        mkdtemp(),
    ]
    good = search_paths[1]
    new_dir = search_paths[2]

    def cleanup():
        shutil.rmtree(new_dir)

    # ensure new dir exists
    assert os.path.exists(new_dir)

    # test no warning on defaults
    result = list_valid_collection_paths()
    assert next(result) == './collections'
    assert next(result) == '~/.ansible/collections'

    # test new dir
    result = list_valid_collection_paths(search_paths, warn=True)
    for path in result:
        if path == good:
            break

# Generated at 2022-06-10 22:44:09.120937
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list_collection_dirs(search_paths=[""])

# Generated at 2022-06-10 22:44:18.189113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # setup a fake directory in temp space
    tmp_dir = tempfile.mkdtemp()

    # put a file in it
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    open(tmp_file, 'w').close()

    # create a fake collection dir
    coll_dir = tempfile.mkdtemp()

    # create a file in the fake collection dir
    coll_file = os.path.join(coll_dir, 'test.txt')
    open(coll_file, 'w').close()

    # create a fake collection dir
    coll_dir_b = tempfile.mkdtemp()

    tmp_dirs = [tmp_file, tmp_dir, coll_dir, coll_dir_b]


# Generated at 2022-06-10 22:44:29.229978
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test non-existent or non directories
    search_paths = ['invalid_path1', 'invalid_path2']

    test_paths = list(list_valid_collection_paths(search_paths))

    assert len(test_paths) == 0

    # Test non existent or non directories with default search paths
    search_paths = ['invalid_path1', 'invalid_path2']
    test_paths = list(list_valid_collection_paths(search_paths))

    assert len(test_paths) == 0

    # Test valid directories
    search_paths = ['.', 'ansible_collections']

    test_paths = list(list_valid_collection_paths(search_paths))

    assert len(test_paths) == 2

# Generated at 2022-06-10 22:44:31.848806
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list(list_collection_dirs(search_paths=['mock_collections'], coll_filter='local.collection')))


# Generated at 2022-06-10 22:44:41.821680
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import os
    # create temporary directory
    tmpDir = tempfile.mkdtemp()

    # create dummy collection directory - this ensures that list_collection_dirs won't filter these directories out
    os.mkdir(os.path.join(tmpDir, 'ansible_collections'))

    # create dummy directory inside of temp dir
    os.mkdir(os.path.join(tmpDir, 'some_dir'))

    # create dummy file inside of temp dir
    with open(os.path.join(tmpDir, 'dummy_file'), 'wb'):
        pass

    # create a dummy collection
    os.makedirs(os.path.join(tmpDir, 'ansible_collections', 'tmp_namespace', 'dummy_collection'))
    valid_paths = list_valid_collection_

# Generated at 2022-06-10 22:44:53.407297
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import stat

    coll_root = tempfile.mkdtemp()
    coll_arg = "my_collection"
    coll_dir = os.path.join(coll_root,
                            coll_arg.replace(".", os.path.sep))
    os.mkdir(coll_dir)
    open(os.path.join(coll_dir, "pytest.py"), 'w').close()
    os.chmod(coll_dir, stat.S_IRWXU)
    try:
        my_gen = list_collection_dirs([coll_root], coll_arg)
        count = 0
        for coll in my_gen:
            count += 1
        assert count == 1
    finally:
        shutil.rmtree(coll_root)

# Generated at 2022-06-10 22:45:01.106960
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import ansible
    ansible_root = os.path.dirname(os.path.dirname(ansible.__file__))
    coll_root = tempfile.mkdtemp()

    coll_names = ['test1', 'test2', 'test3']
    coll_dirs = []
    os.mkdir(os.path.join(coll_root, 'ansible_collections'))
    os.mkdir(os.path.join(coll_root, 'ansible_collections', 'mynamespace'))
    for coll in coll_names:
        os.mkdir(os.path.join(coll_root, 'ansible_collections', 'mynamespace', coll))

# Generated at 2022-06-10 22:45:04.977666
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(coll_filter="ansible_namespace.collection"))
    assert len(dirs) == 1
    assert dirs[0].endswith('/ansible_namespace/collection')

# Generated at 2022-06-10 22:45:10.539233
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp/test/faketest', '/tmp/test/testytest']
    l = list(list_valid_collection_paths(search_paths))
    assert len(l) == 2
    assert l == ['/tmp/test/testytest', '/tmp/test/faketest']



# Generated at 2022-06-10 22:46:18.145890
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with no search paths
    results = list(list_valid_collection_paths(None))
    assert len(results) == len(AnsibleCollectionConfig.collection_paths)
    assert set(AnsibleCollectionConfig.collection_paths) == set(results)

    # Test with empty search paths
    results = list(list_valid_collection_paths([]))
    assert len(results) == len(AnsibleCollectionConfig.collection_paths)
    assert set(AnsibleCollectionConfig.collection_paths) == set(results)

    # Test with the default search paths plus non-existent path
    search_paths = list(AnsibleCollectionConfig.collection_paths)
    search_paths.append('/tmp/non-existent-path')

# Generated at 2022-06-10 22:46:19.148237
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()

# Generated at 2022-06-10 22:46:20.707857
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    for path in list_collection_dirs(search_paths):
        pass

# Generated at 2022-06-10 22:46:28.413525
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        "../../ansible_collections",
        "../../../ansible_collections",
        "../../../../ansible_collections",
        "../../../../../ansible_collections",
        "../../../../../../ansible_collections",
    ]

    collection_paths = list_collection_dirs(search_paths=search_paths, coll_filter="ansible_collections")
    assert list(collection_paths) == [b"../../ansible_collections/ansible_collections/ansible_collections"]

# Generated at 2022-06-10 22:46:36.852628
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the func list_collection_dirs
    """
    current_path = os.path.dirname(os.path.abspath(__file__))

    collection_pathes = list_collection_dirs([os.path.join(current_path, "collection_pathes"), 
                                              os.path.join(current_path, "collection_pathes_not_exist")])
    collections = []
    for collection_path in collection_pathes:
        collections.append(os.path.basename(collection_path))

    assert collections == ["ansible_test.test_collection", "ansible_test.test_collection_subdir"]



# Generated at 2022-06-10 22:46:39.705903
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    results = list(list_valid_collection_paths(search_paths=["test1/", "test2/"]))
    assert results == ["test1/", "test2/"]



# Generated at 2022-06-10 22:46:51.353862
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

# Generated at 2022-06-10 22:46:58.331603
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/doesnotexist"])) == []
    assert list(list_valid_collection_paths(["/etc"])) == []
    assert list(list_valid_collection_paths(["/etc/"])) == []
    assert list(list_valid_collection_paths(["/"])) == ['/']
    assert list(list_valid_collection_paths(["/usr"])) == ['/usr']
    assert list(list_valid_collection_paths(["/usr/bin"])) == ['/usr/bin']

# Generated at 2022-06-10 22:47:08.013526
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test for valid search path
    import tempfile
    search_path = tempfile.gettempdir()

    assert list(list_valid_collection_paths([search_path])) == [search_path]

    # test for missing search path
    search_path = os.path.join('/', 'tmp', 'non-existent-path')

    assert list(list_valid_collection_paths([search_path])) == []

    # test for non-directory search path
    search_path = os.path.join(tempfile.gettempdir(), 'non-existent-file')
    with open(search_path, 'w') as f:
        f.write("Hello")

    assert list(list_valid_collection_paths([search_path])) == []



# Generated at 2022-06-10 22:47:16.354439
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """
    coll_dir = None

    # Empty search_paths
    # Return empty coll_dir
    search_paths = []
    coll_dir = list(list_collection_dirs(search_paths))
    assert len(coll_dir) == 0

    # Search paths with invalid paths
    search_paths = ['/invalid/path1', '/invalid/path2']
    coll_dir = list(list_collection_dirs(search_paths))
    assert len(coll_dir) == 0

    # Search paths with directory path which is not a collection
    search_paths = ['/etc/passwd', '/etc']
    coll_dir = list(list_collection_dirs(search_paths))
    assert len(coll_dir)

# Generated at 2022-06-10 22:48:27.302196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert(list(list_valid_collection_paths(['test_data/test_collections/valid_root']))
           == ['test_data/test_collections/valid_root'])
    assert(list(list_valid_collection_paths(['test_data/test_collections/invalid_root']))
           == [])
    assert(list(list_valid_collection_paths(['test_data/test_collections/invalid_root', 'test_data/test_collections/valid_root']))
           == ['test_data/test_collections/valid_root'])


# Generated at 2022-06-10 22:48:39.165481
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.utils import plugin_docs

    found = []
    display.verbosity = 4
    tc_dir = mkdtemp()
    display.vvv("Created temporary test directory at: %s" % tc_dir)
    tc_path1 = os.path.join(tc_dir, "tc_path1")
    tc_path2 = os.path.join(tc_dir, "tc_path2")
    doc_dir = mkdtemp()
    display.vvvv("Created temporary doc directory at: %s" % doc_dir)
    doc_path = os.path.join(doc_dir, "doc_path")
    plugin_docs.gen_man_for_plugin_docs(doc_path)


# Generated at 2022-06-10 22:48:47.318887
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # NOTE: this is not a proper unit test and should not be considered one,
    #       it is just a convenience method for developers to test the function
    #       without installing the dependency

    import sys
    import mock

    collection_paths = []
    collection_paths.append(os.path.join(os.path.dirname(__file__), "../test/test_collections/collection1"))
    collection_paths.append(os.path.join(os.path.dirname(__file__), "../test/test_collections/collection2"))

    collection_dirs = list(list_collection_dirs(collection_paths, 'fake.test'))
    assert os.path.basename(collection_dirs[0]) == "test"

# Generated at 2022-06-10 22:48:59.083343
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible
    import collections
    import re
    import os

    collection_test = os.environ.get('UNITTEST_COLLECTION_TEST', None)
    if collection_test:
        display.display("Running Collection unit test")

        # Create a dummy collection for the test
        namespace = 'ansible_collections_test'
        collection = 'test_module'
        coll_dir = os.path.join(ansible.constants.DEFAULT_COLLECTIONS_PATHS[0], namespace, collection)

        os.mkdir(coll_dir)
        file = open(os.path.join(coll_dir, '__init__.py'),'w')
        file.close()
        file = open(os.path.join(coll_dir, 'plugins', '__init__.py'),'w')

# Generated at 2022-06-10 22:49:08.206335
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                            '..', '..', '..',
                                            'test', 'integration',
                                            'legacy', 'targets'))
    coll_dir_list = list(list_collection_dirs(search_paths=[coll_dir], coll_filter=None))

    assert len(coll_dir_list) == 2
    found1 = found2 = False

    for entry in coll_dir_list:
        if entry.endswith('test_collections_namespace_1.test_collections_name_1'):
            found1 = True

# Generated at 2022-06-10 22:49:20.217687
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    test with non-existing paths and invalid directory
    '''

    search_paths = [
        "/a/non_existing/path",
        "/etc/foo/bar",
        os.path.join(os.path.dirname(__file__), 'data', 'ansible_test_collections')
    ]

    # test with a single non-existing path
    expected = []
    rtn = list_valid_collection_paths(search_paths)
    tools.assert_equal(sorted(list(rtn)), sorted(expected))

    # test with a single non-existing path and a single valid directory
    expected = [os.path.join(os.path.dirname(__file__), 'data', 'ansible_test_collections')]
    rtn = list_valid_collection_paths

# Generated at 2022-06-10 22:49:28.484280
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test list_collection_dirs with namespace only
    paths = list_collection_dirs(coll_filter="ansible_namespace")
    paths = list(paths)
    assert len(paths) == 1
    assert paths[0] == b"/usr/share/ansible/ansible_collections/ansible_namespace/collection"

    # Test list_collection_dirs with namespace and collection
    paths = list_collection_dirs(coll_filter="ansible_namespace.collection")
    paths = list(paths)
    assert len(paths) == 1
    assert paths[0] == b"/usr/share/ansible/ansible_collections/ansible_namespace/collection"

    # Test list_collection_dirs with multiple search_paths

# Generated at 2022-06-10 22:49:32.967282
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/home/foo/.ansible/collections', '/home/bar/collection_github']

    out = list(list_valid_collection_paths(search_paths))

    # TODO: verify results
    assert out is not None


# Generated at 2022-06-10 22:49:35.948849
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [b'/tmp', b'~']
    ret = list_valid_collection_paths(paths, warn=True)
    assert b'/tmp' in ret
    assert b'~' not in ret

# Generated at 2022-06-10 22:49:45.926690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Testing list_collection_dirs()")
    print("--------------------------")
    import pprint
    test_dir = os.path.dirname(__file__)
    print("test_dir: %s" % test_dir)
    print("ansible_collections dir: %s" % os.path.join(test_dir, 'ansible_collections'))
    test_coll_dirs = list(list_collection_dirs([os.path.join(test_dir, 'ansible_collections')]))
    print("test_coll_dirs:")
    pprint.pprint(test_coll_dirs)
    assert '/'.join([test_dir, 'ansible_collections/ansible_namespace/collection']) in test_coll_dirs