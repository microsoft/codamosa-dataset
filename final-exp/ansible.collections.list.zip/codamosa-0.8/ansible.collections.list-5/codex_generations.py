

# Generated at 2022-06-10 22:40:46.796666
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test default empty list is transformed to default
    search_paths = list()
    valid_paths = list(list_valid_collection_paths(search_paths))
    if len(valid_paths) < 2:
        print("FAIL List of valid collection paths is less than 2. Default not applied?")
        print(valid_paths)
        exit(1)

    # test non existing paths are removed
    search_paths = ['/tmp/I/should/not/exist/1', '/tmp/I/should/not/exist/2']
    valid_paths = list(list_valid_collection_paths(search_paths))
    if len(valid_paths) != 0:
        print("FAIL List of valid collection paths is not empty")
        print(valid_paths)

# Generated at 2022-06-10 22:40:55.292601
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    from ansible.utils.collection_loader import list_collection_dirs
    import tempfile
    import os

    tempdir = tempfile.gettempdir()

    search_path = [tempdir]
    list(list_valid_collection_paths(search_paths=search_path, warn=True))

    collection_dir = tempfile.mkdtemp(dir=tempdir)
    os.makedirs(os.path.join(collection_dir, 'ansible_collections', 'foo', 'bar'))
    assert len(list(list_collection_dirs(search_path, coll_filter='foo.bar'))) == 1



# Generated at 2022-06-10 22:41:02.541369
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the list_valid_collection_paths function
    """

    # Test for files which do exist
    for path in ['/tmp', '/tmp/', '/', '']:
        assert path in list_valid_collection_paths([path]), "Failed path: %s" % path

    # Test for files which do not exist
    for path in ['/usr/foobar', '/tmp/foobar']:
        assert path not in list_valid_collection_paths([path]), "Failed path: %s" % path

# Generated at 2022-06-10 22:41:13.956281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os

    coll_dir = "test/roles/collections"
    if not os.path.exists(coll_dir):
        os.mkdir(coll_dir)

    my_collections = ["n_c1",
                      "ns.c1",
                      "ns.c2",
                      "ns2.c1",
                      "ns2.c2"]

    for c in my_collections:
        coll_path = os.path.join(coll_dir, c)
        os.mkdir(coll_path)
        os.mkdir(os.path.join(coll_path, "roles"))
        os.mkdir(os.path.join(coll_path, "plugins"))

    display.debug("COLLECTION PATH: %s" % coll_dir)


# Generated at 2022-06-10 22:41:24.683973
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # create test directory
    import tempfile
    import shutil
    root_dir = tempfile.mkdtemp(prefix="ansible_unit_tests_")
    test_coll_path = os.path.join(root_dir, 'ansible_collections')

    # create test collections
    ns_dirs = ['collection_name', 'collection_name2.collection_name2']
    for ns_dir in ns_dirs:
        os.mkdir(os.path.join(test_coll_path, ns_dir))

    # filter for test collections

# Generated at 2022-06-10 22:41:33.430713
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # list collections in a specific dir
    test_path = ['../test/data/collections/doesnotexist', '../test/data/collections/good']
    test_coll = ['nested_namespace.example', 'namespace.example', 'namespace.dupecollection']
    result = list(list_collection_dirs(test_path))

    assert len(result) == 3
    for path in result:
        assert path in test_coll

    # list collections in a specific dir with a filter
    test_path = ['../test/data/collections/good']
    test_coll = ['namespace.example']
    result = list(list_collection_dirs(test_path, 'namespace.example'))

    assert len(result) == 1
    for path in result:
        assert path in test_coll

# Generated at 2022-06-10 22:41:35.761430
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(['/does/not/exist', '/usr/local/share/ansible'])) == ['/usr/local/share/ansible']

# Generated at 2022-06-10 22:41:47.060867
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    tempdir = tempfile.mkdtemp()

    # Create a simple valid collection
    colldir = os.path.join(tempdir, 'ansible_collections', 'testns', 'testcoll')
    os.makedirs(colldir)
    with open(os.path.join(colldir, 'plugins', 'module_utils', '__init__.py'), 'w') as f:
        f.write('')
    with open(os.path.join(colldir, 'plugins', 'modules', '__init__.py'), 'w') as f:
        f.write('')
    with open(os.path.join(colldir, 'tests', '__init__.py'), 'w') as f:
        f.write('')

    # Create a valid collection with a broken __init__

# Generated at 2022-06-10 22:41:59.402494
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_native

    tmpdir = tempfile.mkdtemp()

    coll_roots = [tmpdir]

    # create basic directory structure
    os.mkdir(to_bytes(os.path.join(coll_roots[0], 'ansible_collections')))
    os.mkdir(to_bytes(os.path.join(coll_roots[0], 'ansible_collections', 'example')))
    os.mkdir(to_bytes(os.path.join(coll_roots[0], 'ansible_collections', 'example', 'foobar')))
    os.mkdir(to_bytes(os.path.join(coll_roots[0], 'ansible_collections', 'ns.example')))

# Generated at 2022-06-10 22:42:08.947377
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    class FileSystemStub(object):
        def __init__(self):
            self.files = []
            self.directories = []
            self.all = defaultdict(dict)

        def add_file(self, path):
            self.files.append(path)
            self.all[path] = 'file'

        def add_directory(self, path, contents=None):
            self.directories.append(path)
            self.all[path] = 'directory'
            if contents is not None:
                for item in contents:
                    self.all[os.path.join(path, item)] = 'file'

    def fake_exists(path):
        return (path in fake_fs.all)


# Generated at 2022-06-10 22:42:20.864676
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import doctest
    import ansible
    (failed, attempted) = doctest.testmod(ansible.module_utils.basic, optionflags=doctest.NORMALIZE_WHITESPACE)
    assert failed == 0

# Generated at 2022-06-10 22:42:30.415537
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_data = [
        'no-exist',
        'not-a-dir',
        'file-not-a-dir',
        'embedded/dir/no-exist',
    ]

    files = [
        'no-exist',
        'not-a-dir',
        'file-not-a-dir',
        os.path.join('embedded', 'dir', 'no-exist'),
    ]
    dirs = [
        'dir',
        os.path.join('embedded', 'dir'),
    ]

    for test in test_data:
        for f in files:
            fp = os.path.join(test, f)
            with open(fp, 'w') as fh:
                fh.write('blah')

        for d in dirs:
            dp = os

# Generated at 2022-06-10 22:42:42.445963
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(dir=os.path.dirname(__file__)) as temp_dir:
        my_collections_dir = os.path.join(temp_dir, 'my_collections')
        os.mkdir(my_collections_dir)

        my_namespace_dir = os.path.join(my_collections_dir, 'my_namespace')
        os.mkdir(my_namespace_dir)

        # Collection with no plugins
        collection_without_plugins = os.path.join(my_namespace_dir, 'my_collection')
        os.mkdir(collection_without_plugins)

        # Collection that contains empty plugins dir

# Generated at 2022-06-10 22:42:49.488843
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # all paths are valid, none are loaded
    paths, loaded = list_valid_collection_paths(search_paths=['/tmp/x', '/tmp/y', '/tmp/z'])
    assert loaded == []

    # all paths are invalid, none are loaded
    paths, loaded = list_valid_collection_paths(search_paths=['/tmp/x', '/tmp/y', '/tmp/z'], warn=False)
    assert loaded == []

    # all paths are invalid, none are loaded
    paths, loaded = list_valid_collection_paths(search_paths=['/tmp/x', '/tmp/y', '/tmp/z'], warn=True)
    assert loaded == []

    # path is invalid, none are loaded

# Generated at 2022-06-10 22:43:02.032061
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil

    temp_path = tempfile.mkdtemp()
    fake_path = os.path.join(temp_path, 'fake_path')
    fake_coll_path = os.path.join(fake_path, 'ansible_collections')
    fake_ns_path = os.path.join(fake_coll_path, 'fake_ns')
    fake_col_path = os.path.join(fake_ns_path, 'fake_col')

    os.makedirs(fake_col_path)

    test_dirs = [temp_path, fake_path, fake_coll_path, fake_ns_path, fake_col_path]

    for test_dir in test_dirs:
        if not os.path.isdir(test_dir):
            raise AnsibleError

# Generated at 2022-06-10 22:43:10.984627
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    path = os.path.expanduser('~')
    paths = [path]
    assert list(list_valid_collection_paths(search_paths=paths)) == [path]
    paths = ['~']
    assert list(list_valid_collection_paths(search_paths=paths)) == [path]
    paths = ['~/test']
    assert list(list_valid_collection_paths(search_paths=paths)) == []
    paths = ['~/test', '~']
    assert list(list_valid_collection_paths(search_paths=paths)) == paths[1:]
    paths = ['~/test']
    assert list(list_valid_collection_paths(search_paths=paths, warn=True)) == []

# Generated at 2022-06-10 22:43:21.907374
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    curdir = os.path.dirname(os.path.realpath(__file__))
    test_path = os.path.join(curdir, 'test_data', 'collections')

    search_paths = [test_path, os.path.join(test_path, 'sub', 'subsub')]
    paths = list_valid_collection_paths(search_paths)

    # test_data is added because we dynamically add to the search_paths
    result = set(['test_data', os.path.join('sub', 'subsub', 'subsubsub'), os.path.join('sub', 'subsub')])
    assert set(paths) == result

# Generated at 2022-06-10 22:43:34.226235
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # test the assumption that current working directory can be used
    search_paths = [os.getcwd()]
    paths = list(list_valid_collection_paths(search_paths))
    assert paths[0] == os.getcwd()

    temp_dir = tempfile.mkdtemp(prefix='ansible_test_')
    search_paths = [temp_dir]
    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert paths[0] == temp_dir

    # test filter for missing path
    search_paths = ['%s/invalid' % temp_dir]
    paths = list(list_valid_collection_paths(search_paths))
    assert not paths

    # test filter for file path
    temp_file

# Generated at 2022-06-10 22:43:45.363470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    tmpdir1 = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()

    # test if empty search path is handled
    search_paths = []
    assert [] == list(list_valid_collection_paths(search_paths))

    # test if empty search path, with default, is handled
    search_paths = []
    path = os.path.join(tmpdir1, 'ansible_collections')
    os.makedirs(path)
    search_paths.extend(AnsibleCollectionConfig.collection_paths)
    assert [path] == list(list_valid_collection_paths(search_paths))

    # test if non-existing, non-directory search path is handled

# Generated at 2022-06-10 22:43:54.723633
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.test.test_utils import TestPath

    with TestPath.patch('ansible.collections.ansible_collections.list_valid_collection_paths') as test_paths:

        # test default file paths supplied
        test_paths.return_value = [
            '/foo/bar'
        ]
        paths = list(list_valid_collection_paths())
        assert paths == ['/foo/bar']

        # test single non-existent path
        test_paths.return_value = [
            '/foo/bar',
            '/foo/bar_not_exist'
        ]
        paths = list(list_valid_collection_paths(warn=False))
        assert paths == ['/foo/bar']

        # test single non-exist path with warning

# Generated at 2022-06-10 22:44:14.489266
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['./data/collections'])) == ['./data/collections']
    assert list(list_valid_collection_paths(search_paths=['./data/collections', './data/collections2'])) == ['./data/collections', './data/collections2']


# Generated at 2022-06-10 22:44:20.970939
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    def fake_is_collection_path(path):
        if os.path.basename(os.path.dirname(path)) != 'ansible_collections':
            return False
        if path.endswith(".tar.gz"):
            return False
        else:
            return True

    # Monkey patching is_collection_path to return True only if path ends with ansible_collections
    ansible_collections_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../ansible_collections")
    ansible_collections_path = os.path.abspath(ansible_collections_path)

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-10 22:44:32.403963
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common import remove_values

    tmp_coll_paths = ['./lib/ansible/collections']
    actual = list_collection_dirs(tmp_coll_paths, 'test.test_collection')

    expected = {'test.test_collection': './lib/ansible/collections/test/test_collection'}
    expected_paths = list(remove_values(remove_values(remove_values(expected, 'test'), 'collection'), 'test_collection'))

    assert check_type_dict(expected_paths, dict)
    assert check_type_dict(actual, dict)

# Generated at 2022-06-10 22:44:45.421989
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import namedtuple
    from ansible.plugins.loader import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    _Collection = namedtuple('Collection', ['namespace', 'name'])

    def _get_collections(paths, coll_filter=None):
        collections = list()

        for coll_path in list_collection_dirs(paths, coll_filter=coll_filter):
            coll_loader = collection_loader.collection_loader._get_collection_loader(coll_path)
            if coll_loader:
                # get meta data from collection
                meta_data = coll_loader.get('galaxy.yml', {}, ignore_errors=True)
                if not meta_data or 'namespace' not in meta_data:
                    continue

# Generated at 2022-06-10 22:44:56.125087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # invalid collection path
    path = "/dev/null/not/exists"
    result = list(list_valid_collection_paths(search_paths=[path]))
    assert result == []
    # valid collection path
    path = os.getcwd()
    if os.path.exists(os.path.join(path, "ansible_collections")):
        result = list(list_valid_collection_paths(search_paths=[path]))
        assert result == [path]
    # invalid collection path, warning displayed
    path = "/dev/null/not/exists"
    result = list(list_valid_collection_paths(search_paths=[path], warn=True))
    assert result == []
    # valid collection path, warning displayed
    path = os.getcwd()

# Generated at 2022-06-10 22:45:05.669328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    basedir = os.path.join(os.path.abspath(__file__), '../../data')
    basedir = os.path.normpath(basedir)

    collection = "".join(list_collection_dirs([basedir], "mycoll"))
    assert '/mycoll' in collection

    collection = "".join(list_collection_dirs([basedir], "mycoll.mycoll"))
    assert '/mycoll/mycoll' in collection

    collection = "".join(list_collection_dirs([basedir], "mycoll2.subcoll"))
    assert '/mycoll2/subcoll' in collection

    collection = "".join(list_collection_dirs([basedir], "mycoll4.subcoll4"))
    assert '/mycoll4/subcoll4' in collection


# Generated at 2022-06-10 22:45:14.285980
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = ["/does/not/exist", "/home/john", "/home/jane", "/home/john/bad_file"]

    assert list(list_valid_collection_paths(path_list)) == ["/home/john", "/home/jane"]
    assert list(list_valid_collection_paths(["/home/john", "/home/jane"])) == ["/home/john", "/home/jane"]
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-10 22:45:18.713903
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # setting the default path
    test_paths = ['test/data/ansible_collections', 'test/data/ansible_collections/']

    # test for the search path
    f_test_path = list_valid_collection_paths(test_paths, warn=True)

    # check if the list has one content
    assert len(list(f_test_path)) == 1



# Generated at 2022-06-10 22:45:31.467015
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # Create a test collection
    temp_dir = tempfile.mkdtemp(suffix="test_list_collection_dirs")
    test_coll_dir = os.path.join(temp_dir, 'ansible_collections', 'test_list_collection_dirs_namespace', 'test_list_collection_dirs_collection')
    os.makedirs(test_coll_dir)
    with open(os.path.join(test_coll_dir, 'meta', 'main.yml'), 'w') as fh:
        fh.write("{'galaxy_info': {'namespace': 'test_list_collection_dirs_namespace', 'name': 'test_list_collection_dirs_collection'}}")
    # Test with a temp dir containing only a single collection
    # We

# Generated at 2022-06-10 22:45:36.442035
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/foo/bar', 'baz', '~/wee']

    for path in search_paths:
        assert list_valid_collection_paths([path]) == [path]

    # Add a non existant path
    search_paths.append('/nonexistant')

    # 'warn' is false in the default AnsibleCollectionConfig so only the first three paths should be returned
    assert list(list_valid_collection_paths(search_paths)) == search_paths[:-1]

# Generated at 2022-06-10 22:46:15.855808
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This unit test will test functionality of list_collection_dirs()
    """
    import tempfile
    import shutil

    src = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'ansible_test_collection')
    test_collection_path = tempfile.mkdtemp()

# Generated at 2022-06-10 22:46:24.992538
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test the following cases
    
    # empty collection filter
    colls = list_collection_dirs(list_valid_collection_paths(), None)
    assert isinstance(colls, list)

    # a successful filter
    colls = list_collection_dirs(list_valid_collection_paths(), 'community.general')
    assert isinstance(colls, list)

    # a failed filter
    colls = list_collection_dirs(list_valid_collection_paths(), 'community.absent')
    assert isinstance(colls, list)

# Generated at 2022-06-10 22:46:30.867305
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test paths that do not exist
    paths = ['DOES NOT EXIST/ansible_collections', os.path.expanduser('~/DOES-NOT-EXIST')]
    results = list(list_valid_collection_paths(paths))
    assert len(results) == 0

    # test paths that do exist
    for path in [os.path.dirname(__file__), os.path.dirname(__file__), os.path.expanduser('~')]:
        paths = [path]
        results = list(list_valid_collection_paths(paths))
        assert len(results) == 1
        assert results[0] == path

    # test list of paths that do/do not exist

# Generated at 2022-06-10 22:46:38.404887
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # sanity test for list_collection_dirs()
    import tempfile
    import shutil
    import os.path


# Generated at 2022-06-10 22:46:46.998002
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['bad_path1', '/dev/null', 'bad_path2']) == []
    assert list_valid_collection_paths() == []
    assert list_valid_collection_paths(['/usr/share/ansible/collections']) == ['/usr/share/ansible/collections']
    assert list_valid_collection_paths(['/usr/share/ansible/collections/ansible_collections/ansible']) == ['/usr/share/ansible/collections/ansible_collections/ansible']


# Generated at 2022-06-10 22:46:57.583330
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create test tempdir
    COLLECTIONS_ROOT = os.path.join(os.path.dirname(__file__), 'test_collection_dirs')

    # Set the search_paths
    search_paths = [COLLECTIONS_ROOT]

    # Set the filter
    coll_filter = None

    # List all collections in the paths.
    for c in list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter):
        print(c)

    # Set the filter
    coll_filter = 'ansible_namespace'

    # List all collections in the paths with a filter.
    for c in list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter):
        print(c)

# Generated at 2022-06-10 22:47:05.098590
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = set()
    expected.add(b'/home/ansible/collections')
    expected.add(b'/opt/collections')
    assert set(list_valid_collection_paths(search_paths=[b'/home/ansible/collections', b'/opt/collections'])) == expected

    expected = set()
    expected.add(b'/home/ansible/collections')
    assert set(list_valid_collection_paths(search_paths=[b'/home/ansible/collections', b'/opt/collections', b'/nonexistent'])) == expected



# Generated at 2022-06-10 22:47:14.534376
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.path import unfrackpath

    coll_load_path = unfrackpath(u'../files/collection_load')

    coll_paths = [coll_load_path]

    # filter all, expect both
    assert len(list(list_collection_dirs(coll_paths))) == 2

    # filter namespace, expect it
    assert coll_load_path in [x for x in list(list_collection_dirs(coll_paths, u'joe'))]

    # filter collection, expect it
    assert coll_load_path in [x for x in list(list_collection_dirs(coll_paths, u'joe.testing'))]

    # not a namespace or collection path, expect nothing

# Generated at 2022-06-10 22:47:26.137463
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import textwrap

    from ansible.module_utils._text import to_text
    from ansible.utils.path import unfrackpath

    temp_coll_root = tempfile.mkdtemp(prefix='ansible-collections')

    # os.makedirs() will handle nested directories
    subdir_path = os.path.join(temp_coll_root, 'ansible_collections', 'namespace', 'collection')
    os.makedirs(subdir_path)

    # Create empty __init__.py file
    open(os.path.join(subdir_path, '__init__.py'), 'a').close()

    cdirs = list_collection_dirs([temp_coll_root])

# Generated at 2022-06-10 22:47:37.669392
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import filecmp
    import tempfile
    import shutil

    b_test_dir = to_bytes(os.path.normpath(tempfile.mkdtemp()))
    os.mkdir(os.path.join(b_test_dir, b'a'))
    os.mkdir(os.path.join(b_test_dir, b'b'))
    os.mkdir(os.path.join(b_test_dir, b'c', b'd'))
    os.mkdir(os.path.join(b_test_dir, b'e', b'f', b'g'))
    os.mkdir(os.path.join(b_test_dir, b'h', b'i', b'j', b'k'))

    # Test valid collection paths

# Generated at 2022-06-10 22:48:39.766300
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = "ansible_namespace.collection"
    search_paths = ['test_collections']

    collection = []
    for collection in list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter):
        collection = collection
    assert collection == b'test_collections/ansible_collections/ansible_namespace/collection'

# Generated at 2022-06-10 22:48:45.147157
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test that we can find the collections in the directories
    :return: True
    """

    test_paths = ['/tmp/ansible_collections', '/root/ansible_collections']
    colls = list(list_collection_dirs(test_paths, 'test.testcoll'))

    assert colls == ['/tmp/ansible_collections/test/testcoll/ansible_collections/test/testcoll']
    return True

# Generated at 2022-06-10 22:48:57.371267
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    my_ansible_collections_paths = [
        "../../../../ansible_collections/collection_test",
        "/tmp/foo/bar",
        "/tmp/foo/baz",
        "/tmp/foo/baz/../bar",
        "/tmp/foo/baz/../../bar",
        "/tmp/../bar",
        "/var/lib/awx/venv/awx/lib/python3.5/site-packages/ansible/",
        "/",
        "//",
        "///"
    ]
    valid_collections_paths = list(list_valid_collection_paths(my_ansible_collections_paths))

# Generated at 2022-06-10 22:49:00.677486
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Usage:
    $ ansible-test sanity --test test_collection_loader --collect-only --python 3.6 -vvv --docker collections,js

    >>> list_collection_dirs()
    """

    pass

# Generated at 2022-06-10 22:49:07.220692
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Return paths for the specific collections found in passed or configured search paths
    :param search_paths: list of text-string paths, if none load default config
    :param coll_filter: limit collections to just the specific namespace or collection, if None all are returned
    :return: list of collection directory paths
    """

    result = list(list_collection_dirs(["src/ansible/collections"]))
    assert len(result) > 1
    col_path = result[0]
    assert "ansible_collections/ansible/builtin" in col_path

# Generated at 2022-06-10 22:49:19.208693
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Verify collection_paths are correctly filtered
    """
    # TODO: Paths may not always be absolute, use a tempdir
    test_path = 'tests/unit/utils/collection_loader/data/collection_paths/'
    search_paths = ['a', 'b', 'c']
    base_paths = ['d', 'e', 'f']

    # With no search paths specified, the default search paths should be used
    for p in list_valid_collection_paths():
        assert p in base_paths

    # Just a single path, not valid
    for p in list_valid_collection_paths(search_paths[:1]):
        assert p in search_paths[:1]
        assert p not in base_paths

    # A couple valid paths

# Generated at 2022-06-10 22:49:25.388122
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) == 1
    assert len(list(list_valid_collection_paths(search_paths=["/invalid/path", "/invalid/path2"]))) == 0
    assert len(list(list_valid_collection_paths(search_paths=["/invalid/path", "/invalid/path2"], warn=True))) == 0


# Generated at 2022-06-10 22:49:34.765519
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Ensure list_valid_collection_paths returns the expected path in the expected order
    """
    collection_paths = list_valid_collection_paths(search_paths=['/does/not/exist', '/usr/share/ansible'])
    c = next(collection_paths)
    assert c == '/usr/share/ansible'
    c = next(collection_paths)
    assert c == '/usr/share/ansible_collections'
    c = next(collection_paths)
    assert c == '/usr/share/ansible_collections'
    assert not os.path.exists(next(collection_paths))

# Generated at 2022-06-10 22:49:44.607727
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/invalid/path/to/collections',
        '/an/actual/path/to/collections',
        '/another/invalid/path/to/collections',
        '/another/actual/path/to/collections'
    ]

    try:
        from unittest import mock  # Python 3.3+
    except ImportError:
        import mock

    with mock.patch('os.path.exists') as mock_exists:
        with mock.patch('os.path.isdir') as mock_isdir:

            mock_exists.side_effect = [False, True, False, True]
            mock_isdir.side_effect = [False, True, False, True]

            result = list_valid_collection_paths(search_paths, warn=True)
           

# Generated at 2022-06-10 22:49:54.509640
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Sanity check for list_valid_collection_paths function.
    :return:
    """

    # invalid search path
    search_paths = ["/non-existent/path/foo/bar/v42/ansible_collections"]
    result = list_valid_collection_paths(search_paths=search_paths)
    assert not len(list(result)), 'No results should be returned'

    # valid search path
    search_paths = ["../../test/units/module_utils/compat/collections/ansible_collections"]
    result = list_valid_collection_paths(search_paths=search_paths)
    gen_paths = [path for path in result]
    assert len(gen_paths) == 1, 'Exactly one search path should be returned'
    assert gen