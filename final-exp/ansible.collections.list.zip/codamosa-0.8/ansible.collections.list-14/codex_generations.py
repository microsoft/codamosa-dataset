

# Generated at 2022-06-10 22:40:46.122544
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import sys
    import pytest
    from ansible.module_utils._text import to_text

    coll_dir = to_bytes(os.path.join(os.path.dirname(__file__), '../ansible_collections'))
    with pytest.raises(AnsibleError) as err:
        for c in list_collection_dirs(search_paths=[coll_dir], coll_filter='Ansible.foo'):
            pass
    assert 'Invalid collection pattern supplied' in to_text(err.value)

    good_coll_dir = None
    seen_ns = set()
    seen_coll = set()
    for c in list_collection_dirs(search_paths=[coll_dir], coll_filter='Ansible.test'):
        good_coll_dir = c
    assert os

# Generated at 2022-06-10 22:40:52.492852
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with no search paths passed, should return default search paths
    default_paths = list_valid_collection_paths()
    assert len(default_paths) > 1

    # Test with empty search paths passed, should return default search paths
    default_paths = list_valid_collection_paths([])
    assert len(default_paths) > 1

    # Test with search paths passed, should return those with default path appended
    search_paths = ['fake_path', 'fake_path2']
    paths = list_valid_collection_paths(search_paths)
    # Should have the default path
    assert next(iter(default_paths)) in paths
    # Should have the fake paths
    assert len(search_paths) == len([p for p in paths if p in search_paths])

# Generated at 2022-06-10 22:41:03.354644
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    display.verbosity = 0

    import os
    import shutil
    import tempfile
    import unittest

    class TestListCollectionDirs(unittest.TestCase):

        def setUp(self):

            self._collection_path = None
            self._collection_namespace = 'mynamespace'
            self._collection_name = 'mycollection'

            self._collection_dir = None
            self._collection_paths = None

        def tearDown(self):

            if self._collection_dir is not None and os.path.exists(self._collection_dir):
                shutil.rmtree(to_bytes(self._collection_dir, errors='surrogate_or_strict'), ignore_errors=True)


# Generated at 2022-06-10 22:41:14.044412
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    :return: None
    """
    print("The following list of paths should contain 3 collection directory paths:")
    paths = ['../../collections/mycollections',
             '../../collections/ansible_collections']
    for path in list_collection_dirs(search_paths=paths):
        print(path)

    print("The following list of paths should contain 1 collection directory path:")
    for path in list_collection_dirs(search_paths=paths, coll_filter='test'):
        print(path)

    print("The following list of paths should contain 2 collection directory paths:")
    for path in list_collection_dirs(search_paths=paths, coll_filter='test.test'):
        print(path)

# Generated at 2022-06-10 22:41:24.774167
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function
    """
    root_playbooks_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..', 'test', 'units'))
    test_collections_path = os.path.expanduser(os.path.join(root_playbooks_path, 'collections'))
    display.debug('TEST_COLLECTIONS_PATH: %s' % test_collections_path)

    # test default search paths
    collection_paths = list(list_collection_dirs())
    display.debug('DEFAULT collection_paths: %s' % collection_paths)
    assert test_collections_path in collection_paths

    # test explicit search paths

# Generated at 2022-06-10 22:41:31.778450
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test empty search paths
    search_paths = []
    assert list_valid_collection_paths(search_paths) == []

    # Test non-existing search paths
    search_paths = ['/nonexist', '/also/noneexist']
    assert list_valid_collection_paths(search_paths) == []

    # Test existing search paths
    search_paths = ['/etc', '/usr']
    valid_collection_paths = list_valid_collection_paths(search_paths)
    assert '/etc' in valid_collection_paths
    assert '/usr' in valid_collection_paths

# Generated at 2022-06-10 22:41:36.196945
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        'fake1',
        '/fake2',
        '/usr/bin',
        '/ansible/test/collections'
    ]
    paths = list(list_valid_collection_paths(test_paths))

    assert paths == [
        '/usr/bin',
        '/ansible/test/collections'
    ]

# Generated at 2022-06-10 22:41:37.738406
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert [path for path in list_valid_collection_paths()]

# Generated at 2022-06-10 22:41:48.941526
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    basic unit test to verify list_valid_collection_paths works as expected
    :return: exit_code from py.test
    """

    from ansible.collections import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # test non existent paths with warning
    paths = [
        "/this/path/does/not/exist",
        "/neither/does/this/path",
        "so/does/this/path",
    ]
    expected = 0
    assert expected == len(list(collection_loader.list_valid_collection_paths(paths, warn=True))), \
        "Should ignore non-existent paths with warn=True"
    # test non existent paths with no warning
    expected = 0

# Generated at 2022-06-10 22:41:56.529128
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import list_valid_collection_paths
    import os

    test_coll_path = "/tmp/ansible_collections"
    if os.path.exists(test_coll_path):
        raise Exception("Unit test failed to create test_collection_path, file exists")

    search_paths = ['/tmp', '/usr/local']
    ret_val = list(list_valid_collection_paths(search_paths, warn=True))

    if test_coll_path in ret_val:
        raise Exception("Unit test found non-existing test_collection_path in return value")

    if '/tmp' not in ret_val:
        raise Exception("Unit test did not find /tmp in return value")


# Generated at 2022-06-10 22:42:06.792089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs(search_paths=['test/testfixtures/test_collection_dirs']))
    assert len(collection_dirs) == 2


# Generated at 2022-06-10 22:42:16.550885
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert sorted(list_collection_dirs(coll_filter='ansible.builtin')) == sorted([
        '/usr/lib/python2.7/site-packages/ansible_collections/ansible/builtin',
        '/tmp/ansible_collections/ansible/builtin'
    ])

    assert sorted(list_collection_dirs(coll_filter='ansible.builtin.main')) == sorted([
        '/usr/lib/python2.7/site-packages/ansible_collections/ansible/builtin/main',
        '/tmp/ansible_collections/ansible/builtin/main'
    ])

    assert sorted(list_collection_dirs(coll_filter='ansible.builtin',
                                       search_paths=['/usr/lib/python2.7/site-packages']))

# Generated at 2022-06-10 22:42:27.874319
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil
    import os

    cwd = os.getcwd()
    tmpdir = tempfile.mkdtemp()

    search_path = os.path.join(tmpdir, 'foo/bar')


# Generated at 2022-06-10 22:42:40.586375
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # test a working directory
    test_dir = tempfile.mkdtemp()
    result = list(list_valid_collection_paths([test_dir]))
    print("Valid collection paths: %s" % result)
    assert test_dir in result
    os.rmdir(test_dir)

    # test a missing directory
    test_dir = tempfile.mkdtemp()  # make the dir, then delete it
    os.rmdir(test_dir)
    result = list(list_valid_collection_paths([test_dir], warn=True))
    print("Valid collection paths: %s" % result)
    assert test_dir not in result

    # test a bad path, but exists
    test_file = tempfile.mkstemp()[1]

# Generated at 2022-06-10 22:42:52.686046
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import ansible.constants as C

    temp_dir = tempfile.mkdtemp()

    # create global collection directory for test
    coll_dir = os.path.join(temp_dir, C.COLLECTIONS_PATHS[0])
    os.makedirs(coll_dir, mode=0o755)

    # create a fake collection
    collection = os.path.join(coll_dir, "myorg", "mycoll")
    os.makedirs(collection, mode=0o755, exist_ok=True)
    with open(os.path.join(collection, AnsibleCollectionConfig.META_FILE), 'w') as fd:
        fd.write("""
{
    "namespace": "myorg"
}
""")

    # create a fake

# Generated at 2022-06-10 22:43:04.642754
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    x = list_collection_dirs(['./test/units/test_collections_loader/collection_path_1',
                              './test/units/test_collections_loader/collection_path_2'])
    assert list(x) == [b'./test/units/test_collections_loader/collection_path_1/ansible_collections/my_namespace/my_collection',
                       b'./test/units/test_collections_loader/collection_path_1/ansible_collections/my_namespace/my_other_collection',
                       b'./test/units/test_collections_loader/collection_path_2/ansible_collections/my_namespace/my_collection']


# Generated at 2022-06-10 22:43:12.357985
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.collections.ansible.builtin.plugins.module_utils.test.test_utils import TestUtils
    from ansible.collections.ansible.builtin import plugins

    # Setup tmp collection
    test_path = TestUtils.create_temp_plugin_collections()
    assert os.path.isdir(test_path)

    # Setup tmp collection config
    display.verbosity = 3
    AnsibleCollectionConfig.load_configuration(paths=[test_path, ])

    collection_paths = list(list_valid_collection_paths(search_paths=[test_path]))

    # Verify that all collection paths are returned
    assert collection_paths == [test_path, plugins.__path__[0]]


# Generated at 2022-06-10 22:43:15.136698
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs()
    assert coll_dirs is not None
    assert len(coll_dirs) > 0



# Generated at 2022-06-10 22:43:25.480381
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ns = "mynamespace"
    coll = "mycollection"

    path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        "test_collections")

    assert list_collection_dirs([path]) == []

    ns_path = os.path.join(path, ns)
    if not os.path.exists(ns_path):
        os.mkdir(ns_path)

    assert list_collection_dirs([path]) == []

    coll_path = os.path.join(ns_path, coll)

    if not os.path.exists(coll_path):
        os.mkdir(coll_path)

    assert list_collection_dirs([path]) == [coll_path]

    os.rmdir(coll_path)


# Generated at 2022-06-10 22:43:37.345578
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os, tempfile
    from ansible.module_utils.common._collections_compat import AnsibleSequence

    b_coll1 = b'collection_1'
    b_coll2 = b'collection_2'
    b_ns1 = b'namespace_1'
    b_ns2 = b'namespace_2'

    coll_root = tempfile.mkdtemp()

    coll_path1 = tempfile.mkdtemp(prefix=b_coll1, dir=coll_root)
    coll_path2 = tempfile.mkdtemp(prefix=b_coll2, dir=coll_root)

    # create example collection dirs
    coll_dir1 = os.path.join(coll_path1, b_ns1)

# Generated at 2022-06-10 22:43:54.440505
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    d = {}
    for search_path in list_valid_collection_paths():
        d[search_path] = True
    if not d:
        assert False


# Generated at 2022-06-10 22:43:56.073296
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils import context
    from ansible.utils.collection_loader import AnsibleColl

# Generated at 2022-06-10 22:44:07.375110
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected_list = [
        u'/tmp/ansible_collections/namespace1/collection1',
        u'/tmp/ansible_collections/namespace1/collection2',
        u'/tmp/ansible_collections/namespace2/collection1',
        u'/tmp/ansible_collections/namespace2/collection2',
    ]

    os.makedirs(u'/tmp/ansible_collections/namespace1/collection1/docs')
    os.makedirs(u'/tmp/ansible_collections/namespace1/collection2/docs')
    os.makedirs(u'/tmp/ansible_collections/namespace2/collection1/docs')
    os.makedirs(u'/tmp/ansible_collections/namespace2/collection2/docs')


# Generated at 2022-06-10 22:44:15.958059
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths as list_vcp
    import tempfile
    import shutil
    import os
    import os.path
    tmpdir1 = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()
    mydir = os.path.join(tmpdir2, 'foo')
    os.mkdir(mydir)
    try:
        result = list(list_vcp([tmpdir1, tmpdir2]))
        assert result == [tmpdir2], result
    finally:
        shutil.rmtree(tmpdir1)
        shutil.rmtree(tmpdir2)

# Generated at 2022-06-10 22:44:20.875457
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Case when the path exists but is not a directory
    test_path = list_valid_collection_paths(["/dev/null"], warn=True)

    # Case when the path does not exist
    test_path2 = list_valid_collection_paths(["/thebiggestlieevertold/whowouldnameadirectorylikethis"], warn=True)

    # Case using default search paths
    test_path3 = list_valid_collection_paths()

    assert test_path == []
    assert test_path2 == []
    assert test_path3 != []
    assert test_path3 is not None

# Generated at 2022-06-10 22:44:28.739867
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(search_paths=None, warn=False))) == 2
    assert len(list(list_valid_collection_paths(search_paths=['/tmp/invalid', '/tmp/invalid2'], warn=False))) == 0
    assert len(list(list_valid_collection_paths(search_paths=['/tmp/invalid', '/tmp/invalid2'], warn=True))) == 0

# Generated at 2022-06-10 22:44:39.022570
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs(coll_filter='ansible_collections.test.test_plugin'))
    assert(len(collection_dirs) == 1)
    assert(collection_dirs[0].endswith('ansible_collections/test/test_plugin'))

    collection_dirs = list(list_collection_dirs(coll_filter='ansible_collections.test'))
    assert(len(collection_dirs) == 2)
    assert(collection_dirs[0].endswith('ansible_collections/test/test_plugin'))
    assert(collection_dirs[1].endswith('ansible_collections/test/another_test_plugin'))

# Generated at 2022-06-10 22:44:49.492730
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.plugins.collection_loader import COLLECTION_CACHE

    # Clear our cache and load none.
    COLLECTION_CACHE.clear()

    # Note: This is from one of Ansible Galaxy's CI tests
    #       The directory structure is as follows:
    #
    # path/to/collections/
    # ├── ansible_collections/
    # ├── test_collection_1/
    # │   ├── docs/
    # │   ├── filters/
    # │   ├── galaxy.yml
    # │   ├── plugins/
    # │   ├── README.md
    # │   └── roles/
    # ├── test_collection_2/
    # │   ├── docs/
    # │   ├── filters/
    # │   ├── galaxy.yml
    # │   ├── plugins/


# Generated at 2022-06-10 22:44:52.972991
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    pathlist = list(list_valid_collection_paths())
    assert len(pathlist) == 1
    assert '.' in pathlist
    assert "file:///" in pathlist[0]


# Generated at 2022-06-10 22:45:00.871067
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    testns = os.path.join(tmpdir, 'ansible_collections', 'testns')
    os.makedirs(testns)
    tst = os.path.join(testns, 'tst')
    open(os.path.join(tst, 'test.yml'), 'a')
    os.mkdir(os.path.join(tst, 'plugins'))
    os.mkdir(os.path.join(tst, 'data'))
    os.mkdir(os.path.join(tst, 'docs'))
    os.mkdir(os.path.join(tst, 'tests'))

    collection_dir_list = list(list_collection_dirs([tmpdir]))

# Generated at 2022-06-10 22:45:42.021487
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Confirm list_collection_dirs() does what it says, using test collection from unit-test/test_collections/ansible_collections
    :return:
    """
    from ansible.plugins.loader import collection_loader
    from ansible.collections import ansible_collections

    collection_name = "z_test_new_coll.z_test_collection"
    ns, name = collection_name.split('.')
    collection = ansible_collections[ns][name]
    #
    # Test collection loaded with paths()
    #
    assert collection.has_plugin('action')
    #
    # Test collection has plugins
    #
    search_paths = [collection.collection_path]

# Generated at 2022-06-10 22:45:53.084636
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import os
    import shutil
    import glob

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Change to it and create the ansible_collections dir
    os.chdir(tmpdir)
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'ns1', 'coll1'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'ns1', 'coll2'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'ns2', 'coll1'))

    # Create a dummy file to ensure it is not part of the list

# Generated at 2022-06-10 22:46:01.542597
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    # create temporary directory with 3 subdirs
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ansible'))
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))
    os.mkdir(os.path.join(tmpdir, 'ansible_collections/ansible'))

    # create file instead of dir
    with open(os.path.join(tmpdir, 'ansible_collections/ansible/file.txt'), 'w') as f:
        f.write('test')

    # create symlink to file

# Generated at 2022-06-10 22:46:12.191731
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from collections import namedtuple

    # no search_paths, should use AnsibleCollectionConfig.collection_paths
    data1 = namedtuple('args', ['search_paths'])
    data1.search_paths = None
    valid_paths1 = list_valid_collection_paths(**data1._asdict())
    assert len(valid_paths1) > 0
    for path1 in valid_paths1:
        assert os.path.exists(path1)

    # specify search_paths, should load AnsibleCollectionConfig.collection_paths
    data2 = namedtuple('args', ['search_paths'])
    data2.search_paths = ['/foo/bar']
    valid_paths2 = list_valid

# Generated at 2022-06-10 22:46:17.820552
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([])) == []
    p = os.getcwd()
    assert list(list_valid_collection_paths([p])) == [p]
    # not exists
    assert list(list_valid_collection_paths(['/somepath'], warn=True)) == []
    # exists but not a dir
    assert list(list_valid_collection_paths([__file__], warn=True)) == []


# Generated at 2022-06-10 22:46:28.371083
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import glob

    ns = 'ansible_namespace'
    coll = 'collection2'
    os_path = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-10 22:46:37.486362
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=["/path/to/collection"]) == []
    assert list_collection_dirs(search_paths=[]) == []
    assert list_collection_dirs(search_paths=["/path/to/collection"], coll_filter="") == []
    assert list_collection_dirs(search_paths=["/path/to/collection"], coll_filter="namespace") == []
    assert list_collection_dirs(search_paths=["/path/to/collection"], coll_filter="namespace.collection") == []
    assert list_collection_dirs(search_paths=["/path/to/collection"], coll_filter="namespace.collection.version") == []

# Generated at 2022-06-10 22:46:41.719674
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    collection_path = 'collections'
    default_path = os.path.join(tempfile.gettempdir(), collection_path)

    paths = [default_path, "not_a_dir"]
    with tempfile.TemporaryDirectory(prefix="ansible_collections_") as path:
        for p in list_valid_collection_paths([path]):
            assert p == path

    # should be ignored without warning
    for p in list_valid_collection_paths(paths):
        assert p == default_path

# Generated at 2022-06-10 22:46:53.251076
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # invalid configuration non existent
    search_paths = ['/tmp/nonexistent', '/tmp/alsononexistent']
    ret = set(list_valid_collection_paths(search_paths=search_paths, warn=False))
    assert len(ret) == 0

    # invalid configuration not a directory
    with open('/tmp/notadir','w') as f:
        f.write('text')

    assert os.path.exists('/tmp/notadir')
    search_paths = ['/tmp/notadir', '/tmp/alsononexistent']
    ret = set(list_valid_collection_paths(search_paths=search_paths, warn=False))
    assert len(ret) == 0

    # valid configuration
    assert os.path.exists('/tmp')

# Generated at 2022-06-10 22:47:01.411482
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import sys

    # Create temporary directories
    path_root = tempfile.mkdtemp(prefix='ansible_collections_test_')
    path_coll_dir_1 = tempfile.mkdtemp(dir=path_root)
    path_coll_dir_2 = tempfile.mkdtemp(dir=path_root, prefix='ansibull')
    path_coll_dir_3 = tempfile.mkdtemp(dir=path_root)
    path_coll_dir_4 = tempfile.mkdtemp(dir=path_root)
    path_coll_dir_5 = tempfile.mkdtemp(dir=path_root)

    # Copy collection directories
    path_ansible = os.path.join(path_coll_dir_1, 'ansible')
    path_

# Generated at 2022-06-10 22:48:06.646383
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['/'])) == ['/']



# Generated at 2022-06-10 22:48:17.801726
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = ['./fakes/list_valid_coll_paths']

    # Test with collection path in place
    assert list(list_valid_collection_paths(search_paths=path, warn=False)) == ['./fakes/list_valid_coll_paths']

    # Test without collection path in place
    assert list(list_valid_collection_paths(search_paths=path, warn=False)) == []

    # Test is_file and is_dir
    path = ['./fakes/collection_paths/not_coll']
    assert list(list_valid_collection_paths(search_paths=path, warn=True)) == []

    # Test if collection path exists, but is not a directory
    path = ['./fakes/collection_paths/other_coll']

# Generated at 2022-06-10 22:48:25.541252
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/nonexistent/path/'])) == []
    assert list(list_valid_collection_paths(['/nonexistent/path/', '/tmp/foo'])) == ['/tmp/foo']
    assert list(list_valid_collection_paths(['/tmp/foo', '/etc/bar'], warn=True)) == ['/tmp/foo', '/etc/bar']
    assert set(list(list_valid_collection_paths(['/tmp/foo', '/etc/bar'], warn=False))) == {'/tmp/foo', '/etc/bar'}

# Generated at 2022-06-10 22:48:28.185760
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass  # we can't test ansible.collections.collection_loader.list_valid_collection_paths
           # because of how it uses the AnsibleCollectionConfig module


# Generated at 2022-06-10 22:48:31.145808
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    mypaths = [
        '/mnt/nfs/collections'
        ]

    for path in list_valid_collection_paths(mypaths):
        assert path == '/mnt/nfs/collections'

# Generated at 2022-06-10 22:48:41.665901
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_text
    from tempfile import mkdtemp

    coll_path = mkdtemp()
    namespace = 'test_ns'
    coll = 'my_collection'
    coll_dir = os.path.join(coll_path, 'ansible_collections', namespace, coll)
    os.makedirs(coll_dir)
    collection_paths = [coll_path]

    with open(os.path.join(coll_dir, 'MANIFEST.json'), 'w') as manifest_file:
        manifest_file.write('{"galaxy_info": {"namespace": "%s", "name": "%s"}}' % (namespace, coll))


# Generated at 2022-06-10 22:48:48.069612
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    # Test to make sure it can find the collections in the integration test folder
    for path in list_collection_dirs(search_paths=["test/integration/targets/collections/ansible_collections"]):
        assert path.endswith("test/integration/targets/collections/ansible_collections/namespace/collection")

# Generated at 2022-06-10 22:48:59.478318
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = list(list_collection_dirs(['/usr/share/ansible/collections',
                                       '/usr/share/ansible/my_collections',
                                       '/usr/share/ansible/my_other_collections'],
                                      'my_namespace.my_collection'))
    assert paths == [b'/usr/share/ansible/my_collections/ansible_collections/my_namespace/my_collection']

    paths = list(list_collection_dirs(['/usr/share/ansible/collections',
                                       '/usr/share/ansible/my_collections',
                                       '/usr/share/ansible/my_other_collections'],
                                      'my_namespace.my_collection'))

# Generated at 2022-06-10 22:49:08.492749
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    thispath = os.path.dirname(os.path.abspath(__file__))
    test_paths = ["/tmp", thispath]

    # test empty list
    assert list(list_collection_dirs([])) == []

    # test with /tmp
    assert len(list(list_collection_dirs(test_paths))) > 0

    # test with a specific namespace
    assert len(list(list_collection_dirs(test_paths, coll_filter="ansible_namespace"))) > 0

    # test with a specific collection
    assert len(list(list_collection_dirs(test_paths, coll_filter="ansible_namespace.test_collection"))) > 0

    # test with a bad search path

# Generated at 2022-06-10 22:49:12.297765
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    for i in list_valid_collection_paths(search_paths, warn=True):
        assert os.path.isdir(i)

