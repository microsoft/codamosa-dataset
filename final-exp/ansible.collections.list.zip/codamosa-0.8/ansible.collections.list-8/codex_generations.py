

# Generated at 2022-06-10 22:40:44.942340
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    try:
        from ansible.config.manager import ConfigManager
    except ImportError:
        raise ImportError('To use this test, please install configmanager (using pip)')

    # Test empty
    assert list_valid_collection_paths() == []

    # Test default configuration
    with ConfigManager() as cm:
        search_paths = [x.strip() for x in cm.get_config_value('collections_paths').split(':')]
    assert list_valid_collection_paths() == search_paths

    # Test some valid paths, and some invalid
    search_paths += ['.', './ansible_collections']
    search_paths += ['nonexistentpath', 'notadirectory']
    search_paths = list(set(search_paths))

# Generated at 2022-06-10 22:40:49.239176
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths=['/etc/ansible/collects' ,'./collections']
    coll_filter='nagios.downtime'
    collections = list(list_collection_dirs(search_paths, coll_filter))
    assert len(collections) == 1
    assert collections[0] == '/etc/ansible/collects/ansible_collections/nagios/downtime'

# Generated at 2022-06-10 22:40:59.688295
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test a path that does not exist
    invalid_path1 = '/tmp/does_not_exist'
    actual_collections = list_collection_dirs([invalid_path1])
    expected_collections = []
    assert actual_collections == expected_collections
    # Test a path that exists, but is not a directory
    invalid_path2 = '/etc/ansible/ansible.cfg'
    actual_collections = list_collection_dirs([invalid_path2])
    expected_collections = []
    assert actual_collections == expected_collections

    # Test a valid path that should contain collections
    collections_root = os.path.abspath(os.path.join(os.path.dirname(__file__), u'../../../collections'))
    valid_path = os.path.join

# Generated at 2022-06-10 22:41:00.977855
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-10 22:41:04.945992
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) >= 1
    assert b'/'.join([to_bytes(os.getcwd()), b'extras/ansible_collections/ansible/test/test_plugins/test_data',
                      b'plugins/test_module_a.py']) in collection_dirs

# Generated at 2022-06-10 22:41:11.833788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Tests for list_valid_collection_paths
    """
    assert list(list_valid_collection_paths([])) == list()
    assert list(list_valid_collection_paths(['/bin'])) == list()
    assert list(list_valid_collection_paths(['/bin'], warn=True)) == list()
    assert list(list_valid_collection_paths(search_paths=None)) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-10 22:41:22.968752
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    assert set(list_collection_dirs(coll_filter="ansible_collections.notstdlib.moveit")) == set([b'/usr/share/ansible/collections/ansible_collections/notstdlib/moveit'])
    assert set(list_collection_dirs(coll_filter="ansible_collections.notstdlib.moveit",search_paths=["/usr/share/ansible/collections"])) == set([b'/usr/share/ansible/collections/ansible_collections/notstdlib/moveit'])
    assert set(list_collection_dirs(coll_filter="ansible_collections.notstdlib.moveit",search_paths=["/usr/share/ansible/collections","/usr/share/ansible/collections/ansible_collections"])) == set

# Generated at 2022-06-10 22:41:28.062711
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs(search_paths=['./data/collections'], coll_filter=None))

    # check so the number of collection directories match
    assert len(collection_dirs) == 12

    # check so the all directories exist
    for collection_dir in collection_dirs:
        assert os.path.exists(collection_dir)


# Generated at 2022-06-10 22:41:31.699351
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Do not display warnings as it would mess up unit tests results
    assert list(list_valid_collection_paths(['/invalid/path', '/invalid/path2'])) == []
    assert list(list_valid_collection_paths(['/invalid/path', '/invalid/path2'], True)) == []

# Generated at 2022-06-10 22:41:39.706758
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # remove env var AND disable config if set
    os.environ.pop('ANSIBLE_COLLECTIONS_PATHS', None)

    search_paths = [os.path.join(tempfile.gettempdir(), 'ansible_collections')]

    from ansible_collections.testns.testcoll.tests.unit.module_utils.test_list_collection_dirs import TEST_COLLECTION

    # create test collection
    os.makedirs(os.path.join(search_paths[0], 'testns', 'testcoll'))
    open(os.path.join(search_paths[0], 'testns', 'testcoll', 'manifest.json'), 'w').write(TEST_COLLECTION)

    # create test plugin in test collection

# Generated at 2022-06-10 22:41:59.789455
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """

    # List of known good paths
    known_libs = ['/home/ansible/collections', '/home/ansible/my_collection', '/home/ansible/my_collection/ansible_collections',
                  '~/collections/ansible_collections']

    # List of known bad paths
    known_bad_libs = ['/home/ansible/bad_collection', '/home/ansible/my_collection/ansible_collections/not_real',
                      '/home/ansible/my_broken_collection']

    # Test that good paths are found
    for lib in known_libs:
        good_paths = list_collection_dirs([lib])
        for good_path in good_paths:
            assert os.path.ex

# Generated at 2022-06-10 22:42:05.152575
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        '/does/not/exist',
        '/etc/ansible/ansible.cfg',
        '/etc/ansible/collections',
        '/etc/ansible/collections/ansible_collections',
        '/etc/ansible/collection',
        '/etc/ansible',
    ]

    result = list_valid_collection_paths(test_paths)

    assert len(result) == 3

# Generated at 2022-06-10 22:42:10.702491
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil


# Generated at 2022-06-10 22:42:15.339828
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs

    collection_dirs = list_collection_dirs()

    assert len(collection_dirs) > 0

    collection_dirs = list_collection_dirs(coll_filter='ansible_collections.nszm_dev.collection1')

    assert len(collection_dirs) == 1

# Generated at 2022-06-10 22:42:26.520435
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    # test passing in list of paths
    search_paths = ['/tmp/foo', '/tmp/bar']

    # test not found
    assert list(list_valid_collection_paths(search_paths, warn=True)) == []

    # test empty
    assert list(list_valid_collection_paths(search_paths)) == []

    # test passing in non absolute path
    search_paths = ['foo', 'bar']
    assert list(list_valid_collection_paths(search_paths)) == []

    # test passing in a non-existant absolute path
    # will only work if not run in a virtual env
    search_paths = ['/tmp/foo', '/tmp/bar']

    # create dirs
    tmpdir = tempfile.mk

# Generated at 2022-06-10 22:42:29.891525
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list(list_collection_dirs(search_paths=['tests/fixtures/test_collections']))

    assert len(coll_dirs) == 3

    for coll_dir in coll_dirs:
        assert 'test' in os.path.basename(coll_dir)

# Generated at 2022-06-10 22:42:42.003294
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # noinspection PyUnresolvedReferences
    from ansible.collections import ansible_collections_path
    import tempfile
    # set up a temporary namespace
    ns = 'testns'
    test_collection_ns_path = os.path.join(tempfile.gettempdir(), 'ansible_collections', ns)
    os.makedirs(test_collection_ns_path)
    # set up a temporary collection with a role and a plugin
    test_collection = 'testcol'
    test_collection_path = os.path.join(test_collection_ns_path, test_collection)
    os.makedirs(os.path.join(test_collection_path, 'plugins', 'lookup'))

# Generated at 2022-06-10 22:42:53.819802
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    coll_root = os.path.join(temp_dir, 'ansible_collections')
    args = ['foo.bar', 'ansible.test', 'ansible.builtin']

    for arg in args:
        try:
            namespace, collection = arg.split('.')
        except ValueError:
            raise AnsibleError("Invalid collection pattern supplied: %s" % coll_filter)

        coll_path = os.path.join(coll_root, namespace, collection)
        os.makedirs(coll_path)
        open(os.path.join(coll_path, '__init__.py'), 'w').close()

    paths = list_collection_dirs(search_paths=[temp_dir])


# Generated at 2022-06-10 22:43:05.159926
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.cli.galaxy import GalaxyCLI
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url
    from ansible.galaxy.api import GalaxyAPI

    galaxy_cli = GalaxyCLI(args=dict())
    collections_dir = os.path.join(galaxy_cli.base_branch_path, 'ansible_collections')
    url = urlparse(GalaxyAPI.base_server_list_url)
    server = url.netloc
    # two known collections to test
    collections = ['cisco.asa', 'walrus.walrus']

    for coll in collections:
        result = {}
        url_path = url.path + coll + '/'

# Generated at 2022-06-10 22:43:12.587349
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Empty search_paths
    assert len(list(list_valid_collection_paths(search_paths=[]))) == 0

    # Valid search_paths
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir, 'ansible_collections', 'mynamespace'))
    search_paths = [tmp_dir]
    assert '{0}/ansible_collections'.format(tmp_dir) in list(list_valid_collection_paths(search_paths=search_paths))

    # Invalid search_paths
    search_paths = ['/non/existing/path']
    assert len(list(list_valid_collection_paths(search_paths=search_paths))) == 0


# Unit test

# Generated at 2022-06-10 22:43:36.718406
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    #
    # Unit test function list_valid_collection_paths
    #
    # args:
    # search_paths=['/nonexisting/path','/proc','/tmp']
    #
    # expected results:
    # ['/tmp']
    #
    # actual results:
    #
    search_paths = ['/nonexisting/path', '/proc', '/tmp']
    actual = list(list_valid_collection_paths(search_paths))
    expected = ['/tmp']
    assert actual == expected



# Generated at 2022-06-10 22:43:47.313690
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.test.utils import get_test_path

    test_dir = get_test_path()
    collection_dir = os.path.join(test_dir, 'collections/ansible_collections/test')
    with open(os.path.join(collection_dir, 'plugins', 'module_utils', 'inspect_file.py'), 'rb') as f:
        if f.read(3) == b'\xef\xbb\xbf':
            raise AssertionError('ansible-test --requirements should have removed the UTF-8 BOM')
    assert collection_dir in list(list_collection_dirs(['.']))
    assert collection_dir not in list(list_collection_dirs(['/nonexistent']))

# Generated at 2022-06-10 22:43:56.128222
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    testmodule = os.path.join(tmpdir, 'ansible_collections/jpsantos/testmodule')
    os.makedirs(testmodule)
    open(os.path.join(testmodule, '__init__.py'), 'a').close()
    open(os.path.join(testmodule, 'collection_info/metadata.json'), 'a').close()
    open(os.path.join(testmodule, 'plugins/module_utils/test_module.py'), 'a').close()
    open(os.path.join(testmodule, 'plugins/modules/test_module.py'), 'a').close()


# Generated at 2022-06-10 22:44:06.013756
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Specifying paths that are directories
    dirs = ['/', '.']
    assert len(list(list_valid_collection_paths(dirs))) > 0

    # Specifying paths that are files
    files = ['/etc/passwd']
    assert len(list(list_valid_collection_paths(files))) == 0

    # Specifying nonexistent paths
    nonexistent = ['/nonexistent/foo']
    assert len(list(list_valid_collection_paths(nonexistent))) == 0

    # Specifying paths that are not directories
    not_dirs = ['/etc/passwd', '/etc/hosts']
    assert len(list(list_valid_collection_paths(not_dirs))) == 0

# Generated at 2022-06-10 22:44:16.296697
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import stat

    tmpdir = tempfile.mkdtemp()
    mycoll_dir = os.path.join(tmpdir, 'ansible_collections', 'mynamespace', 'mycollection')
    os.makedirs(mycoll_dir)

    for dir1, dir2 in list_collection_dirs(search_paths=[tmpdir]):
        assert dir1 == dir2

    os.rmdir(mycoll_dir)
    os.rmdir(os.path.join(tmpdir, 'ansible_collections', 'mynamespace'))
    os.rmdir(os.path.join(tmpdir, 'ansible_collections'))

    # create a soft link
    os.makedirs(mycoll_dir)

# Generated at 2022-06-10 22:44:17.192965
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass



# Generated at 2022-06-10 22:44:28.189738
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import sys

    temp_path = tempfile.mkdtemp()
    temp_path2 = tempfile.mkdtemp()

# Generated at 2022-06-10 22:44:39.368141
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.utils.list_collection_dirs import list_collection_dirs

    with tempfile.TemporaryDirectory() as td:
        # collections in a dir
        os.mkdir(os.path.join(td, 'a', 'b', 'c'))
        os.mkdir(os.path.join(td, 'a', 'b', 'd'))
        os.mkdir(os.path.join(td, 'e', 'f'))
        os.mkdir(os.path.join(td, 'e', 'g', 'h'))


# Generated at 2022-06-10 22:44:49.638148
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = [
        '/this/file/does/not/exist',
        '/this/file/does/exist/but/is/not/a/directory',
        '/etc/tacos',
        '/etc',
        '/usr/local/lib/python2.7/site-packages',
        '/usr/bin/python2.7'
    ]

    search_paths = list_valid_collection_paths(collection_paths, warn=True)
    assert '/usr/local/lib/python2.7/site-packages' in search_paths
    assert '/etc' in search_paths
    assert '/etc/tacos' not in search_paths
    assert '/usr/bin/python2.7' not in search_paths

# Generated at 2022-06-10 22:44:59.202072
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test with empty search_path, should find just the default
    colls = list(list_collection_dirs(search_paths=None, coll_filter=None))
    assert len(colls) == 2

    # test with a single search_path, with non-collection path, should find just the default
    colls = list(list_collection_dirs(search_paths=['/path/missing'], coll_filter=None))
    assert len(colls) == 2

    # test with a single search_path, with non-existing collection path, should find just the default
    colls = list(list_collection_dirs(search_paths=['/path/missing'], coll_filter='namespace.collection'))
    assert len(colls) == 2

    # test with a single search_path, with a collection path

# Generated at 2022-06-10 22:45:40.422255
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll = 'test.collection'
    test_ns = 'test'
    test_dir_coll = '/path/to/test/collection'
    test_dir_ns = '/path/to/test'
    test_dir_coll_dupe = '/path/to/dupe/test/collection'
    search_paths = [test_dir_coll, test_dir_coll_dupe, test_dir_ns]
    coll_dirs = [coll for coll in list_collection_dirs(search_paths, test_coll)]
    assert len(coll_dirs) == 1
    assert coll_dirs[0] == test_dir_coll
    coll_dirs = [coll for coll in list_collection_dirs(search_paths, test_ns)]
    assert len(coll_dirs) == 2

# Generated at 2022-06-10 22:45:48.694426
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = [u'../../test/units/lib/ansible/collections']
    namespace = 'test_namespace'
    collection = 'test_collection'
    coll_filter = namespace + '.' + collection
    collection_dirs = list_collection_dirs(search_path, coll_filter)
    assert isinstance(collection_dirs, list)
    for collection_dir in collection_dirs:
        assert os.path.basename(os.path.dirname(collection_dir)) == namespace
        assert os.path.basename(collection_dir) == collection



# Generated at 2022-06-10 22:45:56.237272
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # test current directory /tmp is valid
    search_paths = [
        '.',
        '/tmp',
    ]

    for p in list_valid_collection_paths(search_paths):
        assert p == '.'

    # test invalid /tmp is invalid
    search_paths = [
        '/tmp',
    ]

    with tempfile.NamedTemporaryFile(delete=True) as tmpf:
        for p in list_valid_collection_paths(search_paths, warn=False):
            assert p == tmpf.name

# Generated at 2022-06-10 22:46:02.932830
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:46:14.072063
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths
    """
    import tempfile
    tmp_path = tempfile.gettempdir()
    tmp_file = tempfile.NamedTemporaryFile(mode='w')

    # create real config location and populate with fake data
    ans_conf_dir = tempfile.mkdtemp(dir=tmp_path, prefix='as_conf')
    os.makedirs(os.path.join(ans_conf_dir,'ansible_collections','test','example','plugins','cliconf'))
    ans_conf_file = os.path.join(ans_conf_dir,'ansible.cfg')


# Generated at 2022-06-10 22:46:26.390007
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    os.environ['ANSIBLE_COLLECTIONS_PATH'] = "/etc/ansible/ansible_collections"
    assert list_valid_collection_paths(search_paths=[]) == ['/etc/ansible/ansible_collections']
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/etc/ansible/ansible_collections:/etc/ansible/ansible_collections2"
    assert list_valid_collection_paths(search_paths=[]) == ['/etc/ansible/ansible_collections', '/etc/ansible/ansible_collections2']
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/etc/ansible/ansible_collections:/etc/ansible/ansible_collections2"
    assert list_valid_collection

# Generated at 2022-06-10 22:46:28.325213
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pathes = list_valid_collection_paths([])
    assert list(pathes) == []



# Generated at 2022-06-10 22:46:38.121055
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import tempfile

    tmp = tempfile.mkdtemp()
    fake_paths = [os.path.join(tmp, 'fake'), tmp + '/fake']

    for path in fake_paths:
        assert not os.path.exists(path)

    # should return empty
    assert not list(list_valid_collection_paths(fake_paths))

    # create directories
    for path in fake_paths:
        os.makedirs(path)

    # should return both
    assert sorted(list(list_valid_collection_paths(fake_paths))) == sorted(fake_paths)

    # delete one
    os.rmdir(fake_paths[0])

    # should return one
    assert sorted(list(list_valid_collection_paths(fake_paths)))

# Generated at 2022-06-10 22:46:48.344352
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(["/foo", "/bar"])) == ['foo', 'bar']
    assert list(list_valid_collection_paths(["/foo", "/bar", "/baz"])) == ['foo', 'bar', 'baz']
    assert list(list_valid_collection_paths(["/foo"])) == ['foo']
    assert list(list_valid_collection_paths(["/foo", ""])) == ['foo']
    assert list(list_valid_collection_paths([])) == AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(["/foo", "", "/bar"])) == ['foo', 'bar']



# Generated at 2022-06-10 22:46:52.854305
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = ['ansible_collections/testuser/testcoll', 'ansible_collections/testuser/test/coll']
    for coll in list_collection_dirs('tests/unit/data/collection_loader/search_paths'):
        assert coll in expected

# Generated at 2022-06-10 22:48:03.443915
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_paths = [
        '/path/to/collections/ansible_collections',
        '/path/to/another/world/ansible_collections'
    ]

    path_count = 0
    for path in list_collection_dirs(test_paths):
        path_count += 1
        assert '/path/' in path

    assert path_count == 5

    # test single namespace.collection
    path_count = 0
    for path in list_collection_dirs(test_paths, 'test.first'):
        assert 'test.first' in path
        path_count += 1

    assert path_count == 1

    # test single namespace
    path_count = 0
    for path in list_collection_dirs(test_paths, 'test'):
        assert 'test' in path
        path

# Generated at 2022-06-10 22:48:09.216834
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(search_paths=[], coll_filter='operator.test'))
    assert ['operator.test'] == [os.path.basename(os.path.dirname(x)) + '.' + os.path.basename(x) for x in coll_dirs]

# Generated at 2022-06-10 22:48:19.361937
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_paths = ['../test/utils/fixtures/namespaces', '../test/utils/fixtures/collections']
    test_colls = list(list_collection_dirs(search_paths=test_paths, coll_filter=None))

    assert len(test_colls) == 6

    colls = list(list_collection_dirs(search_paths=test_paths, coll_filter='foo'))

    assert len(colls) == 3
    assert os.path.isdir(colls[0])
    assert os.path.isdir(colls[1])
    assert os.path.isdir(colls[2])
    assert colls[0].endswith('/ansible_collections/foo/one/')

# Generated at 2022-06-10 22:48:26.424417
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test default call
    paths = list(list_valid_collection_paths())
    assert len(paths) == 1
    assert paths[0] == '/usr/share/ansible/collections'
    # Test for some invalid paths
    paths = list(list_valid_collection_paths(['/', 'foo']))
    assert len(paths) == 1
    assert paths[0] == '/usr/share/ansible/collections'
    # Test path is accepted if it is a directory
    paths = list(list_valid_collection_paths([os.getcwd()]))
    assert len(paths) == 2
    assert paths[0] == os.getcwd()
    assert paths[1] == '/usr/share/ansible/collections'

# Generated at 2022-06-10 22:48:36.995563
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function to ensure correct results returned
    :return: None
    """
    import tempfile
    from ansible.utils.collection_loader import ansible_collections_paths
    from ansible.utils.collection_loader import list_collections
    from ansible.utils.collection_loader import list_dirs

    # create a temp collection dir
    tmpdir = tempfile.TemporaryDirectory()
    # remove the trailing '/' for convenience
    tmpdir = tmpdir.name.rstrip(os.sep)

    # create two collection dirs
    namespace1 = 'namespace1'
    collection1 = 'collection1'
    coll1_dir = os.path.join(tmpdir, 'ansible_collections', namespace1, collection1)

# Generated at 2022-06-10 22:48:43.021227
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = ["./test/units/lib/ansible/collections"]
    collection_dirs = list_collection_dirs(search_path, coll_filter="")
    for collection_dir in collection_dirs:
        print(collection_dir)
    collection_dirs = list_collection_dirs(search_path, coll_filter="test_collection")
    for collection_dir in collection_dirs:
        print(collection_dir)


# Generated at 2022-06-10 22:48:53.857109
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    not_real = '/path/that/does/not/exist'
    is_real = os.getcwd()

    search_paths = []

    for path in list_valid_collection_paths(search_paths):
        assert path == is_real

    search_paths.append(not_real)

    for path in list_valid_collection_paths(search_paths):
        assert path == is_real

    search_paths.append(not_real)

    for path in list_valid_collection_paths(search_paths):
        assert path == is_real

    search_paths.append(not_real)

    for path in list_valid_collection_paths(search_paths):
        assert path == is_real



# Generated at 2022-06-10 22:49:04.887451
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    res = list(list_collection_dirs(coll_filter='foo.bar'))
    assert len(res) == 1
    assert res[0] == '/usr/share/ansible_collections/foo/bar'

    res = list(list_collection_dirs(search_paths=['/dev/null'], coll_filter='foo.bar'))
    assert not res

    res = list(list_collection_dirs(search_paths=['/usr/share/ansible_collections/foo'], coll_filter='foo.bar'))
    assert len(res) == 1
    assert res[0] == '/usr/share/ansible_collections/foo/bar'


# Generated at 2022-06-10 22:49:07.528525
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert ['a', 'b'] == list(list_valid_collection_paths(['a', 'b']))
    assert [] == list(list_valid_collection_paths([]))



# Generated at 2022-06-10 22:49:19.558943
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test default case
    assert list(list_valid_collection_paths(None)) == list(AnsibleCollectionConfig.collection_paths)

    # Test non-existing directory raises error
    assert list(list_valid_collection_paths(["/not/a/valid/path/", "/nor/is/this/one"])) == list(AnsibleCollectionConfig.collection_paths)

    # Test non-directory raises error
    assert list(list_valid_collection_paths(["/dev/null", "/not/a/valid/path/"])) == list(AnsibleCollectionConfig.collection_paths)

    # Test valid configs are used
    assert list(list_valid_collection_paths(["/dev", "/tmp"])) == ['/dev', '/tmp']
