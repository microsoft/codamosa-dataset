

# Generated at 2022-06-10 22:40:46.523941
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test that we can pass a list of paths and some paths
    # will be filtered out if they are invalid
    assert list(list_valid_collection_paths(['/invalid/path', '/dev/null'])) == ['/dev/null']

    # Test that we see a warning if the configured search path
    # does not exist or is not a directory.
    try:
        list(list_valid_collection_paths(['/invalid/path', '/dev/null'], warn=True))
    except SystemExit as e:
        assert hasattr(e, 'code') and e.code == 0
    else:
        assert False, "The test should have raised SystemExit with a return code of zero"

    # Test that we get a warning when the configured search path
    # does not exist

# Generated at 2022-06-10 22:40:55.783268
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Setup
    # empty search_paths without defaults
    search_paths = []
    # Create a temp directory for collection tests
    tmp_coll_dir = tempfile.mkdtemp(prefix='ansible_collections_')
    # Add fake dir to empty search paths list
    search_paths.append(tmp_coll_dir)

    # Test that empty search_paths with defaults return 0 valid paths
    assert len(list(list_valid_collection_paths(search_paths))) == 0

    # Test that empty search_paths with defaults returns valid search path
    assert len(list(list_valid_collection_paths(search_paths, warn=False))) == 0

    # Test that empty search_paths with defaults returns no warnings

# Generated at 2022-06-10 22:41:05.369450
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test listing all collections
    results = list(list_collection_dirs(['./test/ansible_collections']))
    assert len(results) == 4

    # Test listing all collections in a namespace
    results = list(list_collection_dirs(['./test/ansible_collections'], 'namespace1'))
    assert len(results) == 2

    # Test listing one collection
    results = list(list_collection_dirs(['./test/ansible_collections'], 'namespace1.collection1'))
    assert len(results) == 1

    # Test listing a non existent namespace
    results = list(list_collection_dirs(['./test/ansible_collections'], 'noname'))
    assert len(results) == 0

    # Test listing a non existent collection

# Generated at 2022-06-10 22:41:13.449464
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = ['./lib/ansible/collections/ansible_collections']
    coll_dirs = list_collection_dirs(collection_paths)

    # test the content of the collection dirs
    assert len(coll_dirs) > 0
    for coll in coll_dirs:
        assert coll.endswith('ansible_collections') is False
        assert coll.endswith('/ansible_collections') is False
        assert coll.endswith('/ansible/collections/ansible_collections') is False

# Generated at 2022-06-10 22:41:24.114465
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Path
    from tempfile import mkdtemp
    import shutil

    tmp_path = to_native(mkdtemp())
    tmp_coll_path = to_native(Path(tmp_path, 'ansible_collections'))

    os.mkdir(to_bytes(tmp_coll_path))
    os.mkdir(to_bytes(Path(tmp_coll_path, 'mynamespace')))
    os.mkdir(to_bytes(Path(tmp_coll_path, 'mynamespace', 'mycollection')))

    os.mkdir(to_bytes(Path(tmp_coll_path, 'othernamespace')))

# Generated at 2022-06-10 22:41:33.071458
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Test initialization, ensure that we get the default ansible_collections dir
    paths = list_valid_collection_paths()
    for p in paths:
        assert 'ansible_collections' in p

    # Test bad search path, ensure that we do not get it when calling
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, "does_not_exist")
    paths = list_valid_collection_paths(search_paths=[temp_path])
    for p in paths:
        assert temp_path not in p

    # Test good search path, ensure that we get it when calling
    temp_path = os.path.join(temp_dir, "does_exist")
    os.mkdir(temp_path)
    paths = list_valid

# Generated at 2022-06-10 22:41:40.619000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '',
        '.',
        '/tmp/foo/bar',
        'file:///tmp/foo/bar',
        'ansible_collections',
        '/tmp/foo/bar/ansible_collections',
        'file:///tmp/foo/bar/ansible_collections',
    ]
    actual_list_valid_collection_paths = list_valid_collection_paths(search_paths, warn=False)
    expected_list_valid_collection_paths = [
        '/tmp/foo/bar',
        'ansible_collections',
        '/tmp/foo/bar/ansible_collections',
    ]
    assert str(actual_list_valid_collection_paths) == str(expected_list_valid_collection_paths)



# Generated at 2022-06-10 22:41:46.626013
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = [
        '/etc/ansible/collections/ansible_collections',
        '/usr/share/ansible/collections/ansible_collections',
        '/etc/ansible/ansible_collections',
    ]
    for path in list_collection_dirs(search_paths=paths):
        display.display(path)

# Generated at 2022-06-10 22:41:59.137702
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.collections import is_collection_path
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    collection_name = "test.collections.ansible_collections.test.namespace.test_collection"
    invalid_collection_name = "collections.ansible_collections.test.namespace.test_collection"

    def _clean_up(tmp_dir_c):
        """
        Checks if the directory path is created and delete it.
        """
        if os.path.exists(tmp_dir_c):
            os.rmdir(tmp_dir_c)

    # setup test
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-10 22:42:08.544706
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs(search_paths=['collection_loader/test_collections', 'collection_loader/test_collections2'])
    # we should have 2 namespaces, n1 and n2, and each should have 2 collections, c1 and c2
    namespaces = {}
    for d in coll_dirs:
        parts = os.path.split(d)
        namespace = parts[-2]
        collection = parts[-1]
        if namespace not in namespaces:
            namespaces[namespace] = {}
        if collection not in namespaces[namespace]:
            namespaces[namespace][collection] = d

    assert len(namespaces) == 2
    for ns in namespaces:
        assert len(namespaces[ns]) == 2

    coll_dirs = list_collection_dir

# Generated at 2022-06-10 22:42:23.368153
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display = Display()
    assert display

# Generated at 2022-06-10 22:42:31.763797
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    paths = ['/tmp/path1', '/tmp/path1/ansible_collections', '/tmp/path2/ansible_collections', '/tmp/path1/xyz']
    for path in paths:
        if os.path.isdir(path):
            os.rmdir(path)

    os.makedirs("/tmp/path1/ansible_collections/namespace/collection")
    os.makedirs("/tmp/path1/ansible_collections/namespace")
    os.makedirs("/tmp/path2/ansible_collections/namespace/collection")

    # All collection directories in all configured search_paths
    assert len(list_collection_dirs()) == 4

    # All collection directories in specific search_path

# Generated at 2022-06-10 22:42:43.048405
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    valid_paths = []
    invalid_paths = []

# Generated at 2022-06-10 22:42:49.738003
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test default search paths
    search_paths = list_valid_collection_paths()
    assert len(search_paths) > 0

    # Test search paths with missing dir
    search_paths = list_valid_collection_paths(['/tmp/__non_existant_dir__'])
    assert len(search_paths) == 0

    # Test search paths with existing dir
    search_paths = list_valid_collection_paths(['/tmp'])
    assert len(search_paths) > 0

    # Test search paths with invalid search path
    search_paths = list_valid_collection_paths(['/tmp/__non_existant_dir__', '/tmp'])
    assert len(search_paths) == 1

    # Test search paths with both valid and invalid
    search_paths

# Generated at 2022-06-10 22:43:02.339371
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Basic function tesing for list_valid_collection_paths
    """
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.common.parameters import _get_config_file

    # Append some default search paths
    search_paths = ['/non/existing/path/foo', '/non/existing/path/bar']

    # Load default ansible.cfg into memory and append search paths
    conf_file = _get_config_file(config_file='')
    config_content = open(conf_file, 'rb').read()
    buffer = BytesIO(config_content + b'\n[defaults]\ncollections_paths=/non/existing/path/foo:/non/existing/path/bar')

# Generated at 2022-06-10 22:43:11.150653
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test that it return only ansible collection directory
    dirs = list(list_collection_dirs(search_paths=["/home/ansible/collections"]))
    assert dirs == [b'/home/ansible/collections/ansible_collections']

    dirs = list(list_collection_dirs(search_paths=["/home/ansible/collections", "/home/ansible/collections2"]))
    assert dirs == [b'/home/ansible/collections/ansible_collections', b'/home/ansible/collections2/ansible_collections']

    # Test that it return only directories
    dirs = list(list_collection_dirs(search_paths=["/home/ansible/notadir"]))
    assert dirs == []

# Generated at 2022-06-10 22:43:23.368196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Additional search paths specified by user
    search_paths = [
        "/test-path1",
        "/test-path2",
        "/test-path3",
        "/test-path4",
        "/test-path5"
    ]
    # Expect same number of paths returned
    assert len(list_valid_collection_paths(search_paths)) == 5

    # Add path that does not exist and request warnings
    search_paths.append("/test-path6")
    search_paths.append("/test-path7")
    # Expect only paths to exist
    assert len(list_valid_collection_paths(search_paths, warn=True)) == 5

    # Add a non directory path and request warnings
    assert os.path.exists("/test-path8") == False

# Generated at 2022-06-10 22:43:35.527341
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            search_paths=dict(type='list', default=[]),
            warn=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    # pylint: disable=no-member
    # pylint: disable=unused-argument
    def exit_json(changed=False, **kwargs):
        """function to fake the exit_json method provided by AnsibleModule"""
        module.exit_json(changed=False, **kwargs)

    def fail_json(msg, **kwargs):
        """function to fake the fail_json method provided by AnsibleModule"""
        module.fail_json(msg=msg, **kwargs)

    m_

# Generated at 2022-06-10 22:43:42.803288
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    invalid_tmp_path = tempfile.mkdtemp(prefix="ansible-collections-")
    os.rmdir(invalid_tmp_path)
    result = list(list_valid_collection_paths([invalid_tmp_path]))
    assert len(result) == 0

    tmp_path = tempfile.mkdtemp(prefix="ansible-collections-")
    result = list(list_valid_collection_paths([tmp_path]))
    assert len(result) == 1
    assert tmp_path in result
    os.rmdir(tmp_path)

# Generated at 2022-06-10 22:43:47.161994
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Unit test for function list_collection_dirs."""

    # TODO: Fails on Travis
    # coll_path = 'test/unit/utils/module_docs_fragments'
    # assert [coll_path] == list(list_collection_dirs(search_paths=[coll_path]))

# Generated at 2022-06-10 22:44:12.598388
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the function list_collections_dirs
    """
    from ansible.utils.collection_loader import list_collection_dirs

    # Simple test for the function with a "good" collection in a collection path
    test_collection_path = "/tmp/test_collection"

    os.makedirs(test_collection_path)
    os.makedirs("%s/ansible_collections/awesome_namespace/awesome_collection" % test_collection_path)
    os.makedirs("%s/ansible_collections/awesome_namespace/awesome_plugin_collection" % test_collection_path)
    os.makedirs("%s/ansible_collections/awesome_namespace/awesome_module_utils" % test_collection_path)


# Generated at 2022-06-10 22:44:20.053267
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # create a custom ansible_collections directory
    coll_root = os.path.join("./test_data", "abc_collections")

    ns = os.path.join(coll_root, "namespace1")
    os.makedirs(ns)
    os.makedirs(os.path.join(ns, "collection1"))
    os.makedirs(os.path.join(ns, "collection2"))

    ns = os.path.join(coll_root, "namespace2")
    os.makedirs(ns)
    os.makedirs(os.path.join(ns, "collection1"))
    os.makedirs(os.path.join(ns, "collection2"))

    found_count = 0

# Generated at 2022-06-10 22:44:31.385919
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function list_collection_dirs
    """
    search_paths = [os.path.abspath('./test_data')]
    collection_dir_paths = list_collection_dirs(search_paths)
    assert 6 == len(collection_dir_paths)

    collection_dir_paths = list_collection_dirs(search_paths, coll_filter='ns1')
    assert 2 == len(collection_dir_paths)

    collection_dir_paths = list_collection_dirs(search_paths, coll_filter='ns1.coll1')
    assert 1 == len(collection_dir_paths)

    collection_dir_paths = list_collection_dirs(search_paths, coll_filter='ns1.coll1.subcoll1')
    assert 1

# Generated at 2022-06-10 22:44:37.145498
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for path in list_collection_dirs(search_paths=['/tmp']):
        print(path)
    for path in list_collection_dirs(search_paths=['/tmp'], coll_filter='F5.bigip'):
        print(path)
    for path in list_collection_dirs(search_paths=['/tmp'], coll_filter='F5'):
        print(path)

# Generated at 2022-06-10 22:44:46.936687
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_path = "/Users/scott/Development/ansible_collections/ansible_collections"
    coll_paths = list_collection_dirs([b_path, "./tests/test_collections"], 'testns.basic')
    assert set(coll_paths) == {b'/Users/scott/Development/ansible_collections/ansible_collections/testns/basic'}
    coll_paths = list_collection_dirs([b_path, "./tests/test_collections"], 'testns.bad')
    assert set(coll_paths) == set()

# Generated at 2022-06-10 22:44:51.437508
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([''])) == list(list_valid_collection_paths())
    assert list(list_valid_collection_paths([''], warn=True)) == list(list_valid_collection_paths())

# Generated at 2022-06-10 22:44:56.124734
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_dir = next(list_collection_dirs(search_paths=['test/utils/fixtures/collections'], coll_filter='ns1.coll1'))
    assert b_coll_dir
    assert b_coll_dir.endswith(b"test/utils/fixtures/collections/ansible_collections/ns1/coll1")

# Generated at 2022-06-10 22:44:59.799233
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list(list_collection_dirs()))
    print(list(list_collection_dirs(coll_filter='ansible.builtin')))
    print(list(list_collection_dirs(coll_filter='ansible.builtin.say')))

if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-10 22:45:10.907239
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Not a true unit test as it requires os.path and thus fixture working directory.
    The test exists to aid with coverage of the function.
    """
    assert next(list_valid_collection_paths(['.', '/usr/bin/']), None) == '.'
    assert next(list_valid_collection_paths(['.', '/usr/bin/']), None) == '/usr/bin/'
    assert next(list_valid_collection_paths(['/usr/bin/', '.']), None) == '/usr/bin/'
    assert next(list_valid_collection_paths(['/usr/bin/', '.']), None) == '.'

    assert next(list_valid_collection_paths(['/does/not/exist/']), None) is None

# Generated at 2022-06-10 22:45:20.293772
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test that function returns empty list if no valid paths exist
    def test_empty_list():
        assert list(list_valid_collection_paths([])) == []

    def test_valid_list():
        assert list(list_valid_collection_paths(["."])) == ["."]

    # Test that non existing paths are not included
    def test_invalid_paths():
        l = list(list_valid_collection_paths(["./foo"]))
        assert len(l) == 0

    def test_invalid_file():
        l = list(list_valid_collection_paths(["ansible/collection_loader.py"]))
        assert len(l) == 0

    # Test that function includes default paths if none are given

# Generated at 2022-06-10 22:45:57.591533
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile, os
    from shutil import rmtree
    from ansible.module_utils._text import to_native
    testpath = tempfile.mkdtemp()
    for x in range(0, 3):
        os.makedirs(os.path.join(testpath, "namespace%s/collection%s" % (x, x)))
        os.makedirs(os.path.join(testpath, "namespace%s/collectioninvalid%s" % (x, x)))
    os.makedirs(os.path.join(testpath, "ansible_collections/namespace4/collection4"))
    ansible_collections_path = os.path.join(testpath, "ansible_collections")

# Generated at 2022-06-10 22:46:07.054790
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(to_bytes(tmp_dir), to_bytes('ansible_collections')))
    os.mkdir(os.path.join(to_bytes(tmp_dir), to_bytes('ansible_collections'), to_bytes('namespace1')))
    os.mkdir(os.path.join(to_bytes(tmp_dir), to_bytes('ansible_collections'), to_bytes('namespace1'), to_bytes('collection1')))
    os.mkdir(os.path.join(to_bytes(tmp_dir), to_bytes('ansible_collections'), to_bytes('namespace1'), to_bytes('collection2')))

# Generated at 2022-06-10 22:46:17.202929
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    search_path_list = []
    # Add some valid search paths
    for i in range(1, 4):
        valid_path = mkdtemp()
        search_path_list.append(valid_path)

    # Add some invalid search paths
    for i in range(1, 4):
        invalid_path = mkdtemp()
        os.rmdir(invalid_path)
        search_path_list.append(invalid_path)

    # Get the valid paths
    valid_paths = list_valid_collection_paths(search_paths=search_path_list, warn=False)

    # Assert the number of valid paths is equal to
    # the number of valid paths we added
    assert len(valid_paths) == 3

    # Get the valid paths
   

# Generated at 2022-06-10 22:46:21.205347
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert(list(list_valid_collection_paths()) ==
           ['~/.ansible/collections', '/usr/share/ansible/collections', '/usr/share/ansible_collections'])

# Generated at 2022-06-10 22:46:25.447714
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        "/tmp/not_here",
        "/tmp/also_not_here",
        "/tmp/not_here_either",
    ]

    paths = list(list_valid_collection_paths(search_paths))
    assert paths == []



# Generated at 2022-06-10 22:46:25.871476
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-10 22:46:29.611063
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function
    """
    coll_path = '/tmp/test_ansible_collections'
    # NOTE: depending on the last collection listed on this dir, we could find a collection or we could not
    #       since we are testing the order in which collections are scanned (and the last one wins)

# Generated at 2022-06-10 22:46:39.140235
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Return paths for the specific collections found in passed or configured search paths
    :return: list of collection directory paths
    """

    #
    search_paths = [
        'test/data',
        'test/data/ansible_collections/another',
    ]

    coll_filter = 'ansible.collection'

    root_paths = [
        'test/data/ansible_collections/ansible/collection',
    ]
    collection_paths = list(list_collection_dirs(search_paths, coll_filter))
    for index in range(len(root_paths)):
        assert collection_paths[index].endswith(to_bytes(root_paths[index]))

    coll_filter = 'ansible.collection.foo'

# Generated at 2022-06-10 22:46:50.660776
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Check that if there are no search paths, we get the default collection path.
    assert list_valid_collection_paths()
    search_paths = ["test_fixtures/collections_test/v1", "test_fixtures/collections_test/v2"]
    assert search_paths == list(list_valid_collection_paths(search_paths=search_paths))
    assert ["test_fixtures/collections_test/v1", "test_fixtures/collections_test/v2"] == \
        list(list_valid_collection_paths(search_paths=search_paths))
    search_paths = ["test_fixtures/collections_test/v1", "not_existing", "test_fixtures/collections_test/v2"]

# Generated at 2022-06-10 22:46:59.636615
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([])).sort() == list(AnsibleCollectionConfig.collection_paths).sort()
    assert list(list_valid_collection_paths(["/tmp/badpath"])).sort() == list(AnsibleCollectionConfig.collection_paths).sort()
    assert list(list_valid_collection_paths(["/tmp/badpath"], warn=True)) == []

    assert list(list_valid_collection_paths(["/tmp/badpath", "/tmp/goodpath"])).sort() == [
        "/tmp/goodpath"].sort()
    assert list(list_valid_collection_paths(["/tmp/badpath", "/tmp/goodpath"], warn=True)).sort() == [
        "/tmp/goodpath"].sort()

# Generated at 2022-06-10 22:47:42.097714
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Run a series of tests of list_collection_dirs() with a known test collection tree
    """
    test_collection_tree = """/tmp/foo
        /ansible_collections
            /namespace1
                /collection1
                    /module1
                /collection2
                    /plugin1
            /namespace2
                /collection3
                    /module1
    """

    # create collection tree
    display.debug("creating unit test collection tree")
    os.makedirs('/tmp/foo/ansible_collections/namespace1/collection1/module1')
    os.makedirs('/tmp/foo/ansible_collections/namespace1/collection2/plugin1')
    os.makedirs('/tmp/foo/ansible_collections/namespace2/collection3/module1')



# Generated at 2022-06-10 22:47:47.010618
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    search_paths = ['test_path1', 'test_path2']
    result = list(list_valid_collection_paths(search_paths))
    assert result == search_paths

# Generated at 2022-06-10 22:47:58.065110
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.config
    search_paths = ['.', 'test/unit/utils/fixtures/collection_loader/collections', '/does/not/exist']
    should_return = ['test/unit/utils/fixtures/collection_loader/collections/ansible_collections/some_ns/some_coll',
                     'test/unit/utils/fixtures/collection_loader/collections/ansible_collections/some_ns/another_coll',
                     'test/unit/utils/fixtures/collection_loader/collections/ansible_collections/some_ns2/yet_another_coll']

    # get a deepcopy of the config as it can't be shared by multiple tests
    _config = ansible.config.loader.load_configuration()

# Generated at 2022-06-10 22:48:07.096349
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Some paths to be inserted
    coll_test_roots = ['/test/coll/root/b', '/test/coll/root/a']
    expected = ['/test/coll/root/b/ansible_collections/test/test_collection',
                '/test/coll/root/a/ansible_collections/test/test_collection']
    actual = list(list_collection_dirs(search_paths=coll_test_roots, coll_filter='test.test_collection'))

    assert set(actual) == set(expected)



# Generated at 2022-06-10 22:48:17.411262
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # create temporary directory
    temp_dir = tempfile.mkdtemp()

    # create collection and normal directories
    temp_coll_dir = tempfile.mkdtemp(prefix=temp_dir, suffix='ansible_collections')
    temp_sub_coll_dir = tempfile.mkdtemp(prefix=temp_coll_dir, suffix='ns1.coll1')
    temp_sub_coll_dir_2 = tempfile.mkdtemp(prefix=temp_coll_dir, suffix='ns1.coll2')

    my_coll_path = list_collection_dirs([temp_dir], 'ns1.coll1')

    assert list(my_coll_path) == [temp_sub_coll_dir]

# Generated at 2022-06-10 22:48:19.484074
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(coll_filter='ansible_collections.not.exist'))
    assert len(coll_dirs) == 0



# Generated at 2022-06-10 22:48:26.742002
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_text, to_bytes

    test_path = os.path.join(os.path.dirname(__file__), 'test_collection_path')
    cmd = ['/bin/sh', '-c', '. ./hacking/env-setup -q; ansible-test compile --color -v']

    # PY2 uses os.popen and that has an implicit encode of utf-8, so we ensure this test is also using utf-8 encoding
    if PY2:
        cmd = [shlex_quote(to_bytes(x, encoding='utf-8')) for x in cmd]

# Generated at 2022-06-10 22:48:37.318625
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.test.test_collection_loader import _collection_path_tests
    from ansible.test.test_collections.conftest import temp_collection_root
    from ansible.module_utils.six import PY3


# Generated at 2022-06-10 22:48:44.247347
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    paths = list_valid_collection_paths(search_paths=['~', '/var/lib/non-existent', '/usr/share/ansible/collections:/home/ansible/playbooks'], warn=False)
    # Ensure all paths expected are returned
    assert next(paths, None) == '~'
    assert next(paths, None) == '/usr/share/ansible/collections'
    assert next(paths, None) == '/home/ansible/playbooks'



# Generated at 2022-06-10 22:48:52.859916
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # given
    current_path = os.path.dirname(os.path.realpath(__file__))
    search_paths = [
        current_path,
        os.path.join(current_path, 'example_collections')
    ]

    # when
    result = list_valid_collection_paths(search_paths)

    # then
    assert next(result) == current_path
    assert next(result) == os.path.join(current_path, 'example_collections')
    assert next(result, None) is None



# Generated at 2022-06-10 22:49:59.838335
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # Empty dir path
    test_path = tempfile.mkdtemp(dir='/tmp')
    assert list(list_collection_dirs([test_path])) == []
    shutil.rmtree(test_path)

    # Non-existent dir path
    test_path = tempfile.mkdtemp(dir='/tmp')
    shutil.rmtree(test_path)
    assert list(list_collection_dirs([test_path])) == []

    # Non-directory path
    with tempfile.NamedTemporaryFile(dir='/tmp') as f:
        path = f.name
        assert list(list_collection_dirs([path])) == []

    # Single collection path
    test_path = tempfile.mkdtemp(dir='/tmp')


# Generated at 2022-06-10 22:50:11.312111
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    import os

# Generated at 2022-06-10 22:50:18.585256
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible import context
    context._init_global_context(None)

    # When no collection filter is provided, all the collections should be returned
    all_colls = list(list_collection_dirs())
    assert len(all_colls) > 0

    # Return something even if collections are not found
    colls = list(list_collection_dirs(search_paths=['/tmp/ansible/collections']))
    assert len(colls) == 0

    # When namespace is provided, all the collections in that namespace should be returned
    colls = list(list_collection_dirs(coll_filter='ansible_collections'))
    assert len(colls) > 0

    # When namespace and collection is provided, only that collection should be returned

# Generated at 2022-06-10 22:50:28.376054
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.plugins.loader
    import ansible.utils.collection_loader
    import ansible.utils.plugin_docs
    import os
    import imp
    import stat
    import shutil
    import tempfile
    from collections import defaultdict

    def get_valid_collection_paths():
        tmpdir = tempfile.mkdtemp()
        tmpdir = to_bytes(tmpdir)
        os.makedirs(os.path.join(tmpdir, b'ansible_collections', b'a', b'b'))
        os.makedirs(os.path.join(tmpdir, b'ansible_collections', b'c', b'b'))
        os.makedirs(os.path.join(tmpdir, b'foo'))