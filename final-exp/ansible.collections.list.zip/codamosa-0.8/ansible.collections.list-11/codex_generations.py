

# Generated at 2022-06-10 22:40:45.173523
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    class CollectionDir:
        """
        Stub CollectionDir class
        """
        def __init__(self, b_coll_dir):
            self.name = os.path.basename(b_coll_dir)
            self.dir = b_coll_dir
            self.path = os.path.dirname(b_coll_dir)

    tempdir = tempfile.mkdtemp()
    searchpaths = [os.path.join(tempdir, 'ansible_collections')]


# Generated at 2022-06-10 22:40:53.615779
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os.path
    import tempfile

    # Setup
    tmpdir = tempfile.mkdtemp()
    subdir1 = os.path.join(tmpdir, 'a')
    subdir2 = os.path.join(tmpdir, 'b')
    os.mkdir(subdir1)
    os.mkdir(subdir2)
    os.mkdir(os.path.join(subdir1, 'c'))
    os.mkdir(os.path.join(subdir2, 'd'))

    # Test
    results = list(list_collection_dirs(search_paths=[tmpdir]))
    assert len(results) == 2

    # Teardown
    import shutil
    shutil.rmtree(tmpdir)

# Generated at 2022-06-10 22:41:03.391028
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.cli.collection import CLI
    import os
    import shutil
    import tempfile

    t = tempfile.mkdtemp()
    cli = CLI(args=[])
    try:
        for cl in [cli.collection_loader.root, cli.collection_loader.src_root]:
            os.makedirs(os.path.join(t, cl))
            shutil.copytree(cli.collection_loader.paths[cl][0], os.path.join(t, cl, 'ansible_collections'))
        cli.collection_loader.init_collections(collections_paths=[t])
        assert len(list_collection_dirs()) > 0
    finally:
        shutil.rmtree(t)

# Generated at 2022-06-10 22:41:10.760002
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_namespace_dir = os.path.join(test_dir, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(test_namespace_dir)
    assert os.path.exists(test_namespace_dir)
    collections = list_collection_dirs([test_dir])
    assert len(list(collections)) == 1
    shutil.rmtree(test_dir)

# Generated at 2022-06-10 22:41:22.212403
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    # setup a temp directory to work with, and add it to the collection search path
    tmp_dir = tempfile.mkdtemp()
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = tmp_dir

    # create a fake collection in the temp directory
    namespace = "test"
    collection = "my_collection"
    os.mkdir(os.path.join(tmp_dir, "ansible_collections"))
    os.mkdir(os.path.join(tmp_dir, "ansible_collections", namespace))
    os.mkdir(os.path.join(tmp_dir, "ansible_collections", namespace, collection))
    os.mkdir(os.path.join(tmp_dir, "ansible_collections", namespace, collection, "plugins"))


# Generated at 2022-06-10 22:41:28.784538
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_dirs = list(list_collection_dirs(search_paths=['/Users/dag/.ansible/collections'], coll_filter='geerlingguy.homebrew'))
    assert len(collection_dirs) == 1
    assert to_bytes('/Users/dag/.ansible/collections/ansible_collections/geerlingguy/homebrew') in collection_dirs

    collection_dirs = list(list_collection_dirs(search_paths=['/Users/dag/.ansible/collections'], coll_filter=None))
    assert len(collection_dirs) > 1

    collection_dirs = list(list_collection_dirs(search_paths=None, coll_filter=None))
    assert len(collection_dirs) > 1

# Generated at 2022-06-10 22:41:37.895050
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:41:39.712488
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # this function currently called by the module_generate code
    assert True

# Generated at 2022-06-10 22:41:43.429478
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['__not_exist__'])) == []
    assert list(list_valid_collection_paths(['__not_exist__', '/'])) == ['/']

# Generated at 2022-06-10 22:41:56.049356
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    from os.path import join, abspath, dirname
    search_paths = [join(dirname(abspath(__file__)), 'fixtures', 'collection_paths')]
    collection_dirs = [c for c in list_collection_dirs(search_paths)]
    assert len(collection_dirs) == 3
    assert join(search_paths[0], 'ansible_collections', 'example', 'b') in collection_dirs
    assert join(search_paths[0], 'ansible_collections', 'example', 'd') in collection_dirs
    assert join(search_paths[0], 'ansible_collections', 'test', 'a') in collection_dirs

# Generated at 2022-06-10 22:42:13.691697
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible.community.plugins.module_utils.collection_util import collection_dirs
    from ansible.module_utils.common.collections import ANSIBLE_COLLECTIONS_PATH
    from ansible_collections.ansible.community.plugins.collection_loader import AnsibleCollectionConfig

    collections = list_collection_dirs()

    # check result
    assert len(collections) > 0
    assert collections == collection_dirs()

    # check collection_dirs equals results from AnsibleCollectionConfig.collection_paths
    assert collections == list_collection_dirs(search_paths=AnsibleCollectionConfig.collection_paths)

    # check collection_dirs equals results from ANSIBLE_COLLECTIONS_PATHS

# Generated at 2022-06-10 22:42:19.024878
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=["/not/exists", "/also/not/exists"])) == []
    assert list(list_valid_collection_paths(search_paths=["/not/exists", "./collection_loader"])) == ["./collection_loader"]


# Generated at 2022-06-10 22:42:29.305460
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.six.moves import builtins

    tmp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'test_list_valid_collection_paths'))
    makedirs_safe(tmp_dir)
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    with open(tmp_file, 'w') as f:
        f.write('test file')
    try:
        call = builtins.__dict__['__builtins__']['callable']
    except KeyError:
        # Python 3
        call = builtins.__dict__['callable']


# Generated at 2022-06-10 22:42:37.879196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    fixture_path = os.path.join(os.path.dirname(__file__), '..', 'test_data/test_collection_loader/test_collections')
    test_paths = [fixture_path]
    paths = list_valid_collection_paths(search_paths=test_paths)
    assert fixture_path in paths
    paths = list_valid_collection_paths(search_paths=['/not_exist'])
    assert not any(paths)

# Generated at 2022-06-10 22:42:46.681012
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected_result = ['/usr/share/ansible/collections/ansible_collections/first_ns/first_coll',
                       '/usr/share/ansible/collections/ansible_collections/second_ns/second_coll',
                       '/usr/share/ansible/collections/ansible_collections/third_ns/third_coll',
                       '~/ansible_collections/first_coll',
                       '~/ansible_collections/second_coll']
    result = list_collection_dirs(search_paths=['/usr/share/ansible/collections', '~/ansible_collections'],
                                  coll_filter=None)
    assert sorted(list(result)) == sorted(expected_result)


# Generated at 2022-06-10 22:42:51.456114
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = ["/foo", "/bar", "/baz"]
    assert list_valid_collection_paths(path_list) == path_list
    assert list_valid_collection_paths([]) == path_list
    assert list_valid_collection_paths(None) == path_list


# Generated at 2022-06-10 22:43:03.655185
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # path1 and path2 should be listed in the first return,
    # path3 and path4 should be skipped as they're missing or files not directories
    # path5 should not be returned as it's not a valid collection path
    test_paths = ['/path1', '/path2', '/path3', '/path4', '/path5/ansible_collections']
    # create directories /path1, /path2 and /path5/ansible_collections
    # create file /path3 and /path4
    for path in test_paths:
        if not os.path.exists(path):
            os.makedirs(path)

    test_paths = ['/path1', '/path2', '/path3', '/path4', '/path5/ansible_collections']
    # verify that the correct paths are returned

# Generated at 2022-06-10 22:43:09.335709
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # no args to force using default configuration
    paths = list(list_valid_collection_paths())

    # default
    assert '/usr/share/ansible/collections' in paths

    # add a missing path and test filtering
    paths.append('/unittest/does/not/exist')
    paths = list(list_valid_collection_paths(search_paths=paths, warn=True))

    assert '/unittest/does/not/exist' not in paths

# Generated at 2022-06-10 22:43:13.247458
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/scratch/foo', '/scratch/bar']
    display.verbosity = 4
    assert list(list_valid_collection_paths(search_paths=test_paths, warn=True)) == ['/scratch/foo', '/scratch/bar']

# Generated at 2022-06-10 22:43:19.426561
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # TODO: need a better way to verify results as tempdirs are not available to test fixtures
    # Do not allow any search paths to interfere with testing
    my_paths = ['~/tmp/test1', '~/tmp/test2']

    result = list(list_collection_dirs(my_paths))
    assert result



# Generated at 2022-06-10 22:43:43.217284
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    this_dir = os.path.dirname(__file__)
    search_paths = [os.path.join(this_dir, 'vars/foo/empty'),
                    os.path.join(this_dir, 'vars/foo/empty/bar'), os.path.join(this_dir, 'vars/foo'),
                    os.path.join(this_dir, 'vars/bar'),
                    os.path.join(this_dir, 'vars/baz')]
    assert sorted(list_valid_collection_paths(search_paths, warn=True)) == \
           sorted([os.path.join(this_dir, 'vars/foo'),
                   os.path.join(this_dir, 'vars/bar'), os.path.join(this_dir, 'vars/baz')])

# Generated at 2022-06-10 22:43:53.220562
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test good collection paths that exist
    paths = list_valid_collection_paths(['/usr/share/ansible/collections', '/usr/share/ansible/collections/ansible'])
    assert len(list(paths)) == 1

    # test missing but default collection paths
    paths = list_valid_collection_paths(['/usr/share/ansible/collections', '/usr/share/ansible/collections/ansible'], warn=True)
    assert len(list(paths)) == 1

    # test good non-default collection paths
    paths = list_valid_collection_paths(['/tmp'])
    assert len(list(paths)) == 0

    # test file instead of collection path
    paths = list_valid_collection_paths(['/etc/passwd'])
    assert len

# Generated at 2022-06-10 22:43:59.176482
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create temporary directory to store the test directory and files
    tmpdir = mkdtemp()

    # Create 4 directories in the temporary directory
    # Only one is a search path for collections
    for idx in range(4):
        dir_path = os.path.join(tmpdir, "dir{}".format(idx))
        os.mkdir(dir_path)

    # Create a text file in the temporary directory
    text_file = os.path.join(tmpdir, "file.txt")
    with open(text_file, 'w') as tfile:
        tfile.write("test file")

    # Get list of collection paths

# Generated at 2022-06-10 22:44:11.224895
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Input list with few valid and few invalid paths
    test_paths = ["/tmp", "/tmp/ansible_collections", "/tmp/ansible_collections/ansible_namespace/",
                  "/tmp/ansible_collections/ansible_namespace/ansible_collection/",
                  "/tmp/ansible_collections/ansible_namespace", "/tmp/ansible_collections/ansible_namespace/",
                  "/tmp1", "/tmp2/ansible_collections", "/tmp3/ansible_collections/ansible_namespace",
                  "/tmp4/ansible_collections/ansible_namespace/ansible_collection",
                  "/tmp5/ansible_collections/ansible_namespace/ansible_collection/",
    ]
    # Expected Output list with only valid paths
    expected

# Generated at 2022-06-10 22:44:15.829770
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    #assert list(list_collection_dirs(coll_filter='my.collection')) ==
    #assert list(list_collection_dirs(paths=['path_does_not_exist'])) == []

    #assert list(list_collection_dirs(paths=['path_does_not_exist'], warn=False)) == []
    #assert list(list_collection_dirs(paths=['path_does_not_exist'], warn=True)) == []

    #assert list(list_collection_dirs(paths=['path_does_not_exist'], warn=False)) == []
    #assert list(list_collection_dirs(paths=['path_does_not_exist'], warn=True)) == []

    assert list(list_collection_dirs(coll_filter='my.collection'))

# Generated at 2022-06-10 22:44:21.547329
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.path import get_distribution_version

    # get_distribution_version uses AnsibleConfig, which is not imported at load time
    if get_distribution_version:
        search_paths = []
        search_paths.append('/tmp/doesntexist')
        search_paths.append(os.path.expanduser('~/.ansible/collections'))

        valid_paths = len(list(list_valid_collection_paths(search_paths, warn=True)))
        assert valid_paths > 0


# Generated at 2022-06-10 22:44:30.941910
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = [
        u'/tmp/test_collections/ansible_collections/test_namespace/test_collection',
        u'/tmp/test_collections/ansible_collections/test_namespace/test_collection2',
        u'/tmp/test_collections/ansible_collections/test_namespace2/test_collection',
        u'/tmp/test_collections/ansible_collections/test_namespace2/test_collection2',
    ]
    assert list(list_collection_dirs(search_paths=['/tmp/test_collections'])) == expected

# Generated at 2022-06-10 22:44:41.265627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_coll_dir = os.path.join(os.getcwd(), 'tests/units/module_utils/metadata/ansible_collections')
    sys.path.append(test_coll_dir)
    from ansible_collections.test.plugins.module_utils.metadata.test_module_utils.module_utils1 import C
    for coll_dir in list_collection_dirs(['.']):
        assert os.path.isdir(coll_dir)
    for coll_dir in list_collection_dirs([test_coll_dir]):
        assert os.path.isdir(coll_dir)
    for coll_dir in list_collection_dirs(['.'], 'test.module_utils.module_utils1'):
        assert os.path.isdir(coll_dir)

# Generated at 2022-06-10 22:44:46.303085
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collections = defaultdict(dict)
    coll_path = [u'./collections']
    coll_filter = [u'ansible.builtin', u'ansible.builtin.like']

    for path in list_collection_dirs(coll_path, None):
        print(path)


# Generated at 2022-06-10 22:44:49.430474
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs('/etc/ansible/collections') is None
    assert list_collection_dirs(['/etc/ansible/collections', '/my/path']) is None

# Generated at 2022-06-10 22:45:33.125112
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Simple test to simply verify the function runs
    try:
        x = list(list_valid_collection_paths())
        x = list(list_valid_collection_paths(['/tmp/does_not/exist']))
    except Exception as e:
        assert False, "Exception " + str(e) + " observed running list_valid_collection_paths"

# Generated at 2022-06-10 22:45:44.778286
# Unit test for function list_collection_dirs

# Generated at 2022-06-10 22:45:55.608206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import list_valid_collection_paths
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.utils.collection_loader import collections_loader
    from ansible.utils.collection_loader import get_collection_role_definitions
    from ansible.plugins.loader import collection_loader


# Generated at 2022-06-10 22:46:02.642887
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    base_path = os.path.dirname(__file__)
    collection_path = os.path.join(base_path, "collection_root")
    search_paths = [collection_path]

    collection_dirs = list(list_collection_dirs(search_paths))
    assert collection_dirs == [os.path.join(collection_path, "ansible_collections", "test", "test_col")]

    collection_dirs = list(list_collection_dirs(search_paths, "test"))
    assert collection_dirs == [os.path.join(collection_path, "ansible_collections", "test", "test_col")]

    collection_dirs = list(list_collection_dirs(search_paths, "test.test_col"))
    assert collection_dirs

# Generated at 2022-06-10 22:46:09.318723
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_data_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_data_dir, 'test_data')
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = test_dir
    res = list(list_collection_dirs())
    assert len(res) == 1
    assert res[0].endswith('test_data/ansible_collections/acmecorp/example')

# Generated at 2022-06-10 22:46:12.899833
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    """
    # make sure collection_dirs uses the default collection_paths
    display.verbosity = 0
    dirs = list(list_collection_dirs())
    assert len(dirs) > 1

    # ensure that collections in a path with no ansible_collections subdir are not listed
    dirs = list(list_collection_dirs(["/"]))
    assert len(dirs) == 0

    # ensure that collections in a non-existent path are not listed
    dirs = list(list_collection_dirs(["/this_path_does_not_exist"]))
    assert len(dirs) == 0

# Generated at 2022-06-10 22:46:18.539970
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Testing with an non existing path
    search_paths = ['/foo/bar']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(valid_paths) == 0

    # Testing with an existing path
    search_paths = ['/']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(valid_paths) == 1


# Generated at 2022-06-10 22:46:26.136349
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list_collection_dirs(coll_filter='test.test')
    assert len(collection_dirs) > 0
    assert collection_dirs[0].endswith('roles/')

    collection_dirs = list_collection_dirs(coll_filter='test')
    assert len(collection_dirs) > 0
    assert collection_dirs[0].endswith('roles/')

    collection_dirs = list_collection_dirs(coll_filter=None)
    assert len(collection_dirs) > 0
    assert collection_dirs[0].endswith('roles/')

    collection_dirs = list_collection_dirs(coll_filter='fake')
    assert len(collection_dirs) == 0

# Generated at 2022-06-10 22:46:33.784866
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/this/doesnot/exist', '/usr/share/ansible', '/etc/ansible'])) == ['/usr/share/ansible', '/etc/ansible']
    assert list(list_valid_collection_paths(['/root/doesnot/exist', '/root/ansible_collections'])) == ['/root/ansible_collections']
    assert list(list_valid_collection_paths(['/etc/doesnot/exist', '/etc/ansible'])) == ['/etc/ansible']

# Generated at 2022-06-10 22:46:41.282380
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    expected = ['/home/ansible/collections']
    res = list(list_valid_collection_paths(expected))
    assert res == expected

    expected = []
    res = list(list_valid_collection_paths(expected, warn=False))
    assert res == expected

    expected = list(AnsibleCollectionConfig.collection_paths)
    res = list(list_valid_collection_paths(expected, warn=False))
    assert res == expected

    expected = ['/home/ansible/collections']
    res = list(list_valid_collection_paths(expected))
    assert res == expected

    paths = ['/home/ansible/collections', '/home/ansible/collections/namespace/collection']
    expected = ['/home/ansible/collections']

# Generated at 2022-06-10 22:47:31.027021
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.module_utils._text import to_text
    from tempfile import mkdtemp
    from shutil import rmtree

    b_coll_dir = to_text(mkdtemp(), errors='surrogate_or_strict')
    b_namespace_dir = os.path.join(b_coll_dir, 'ansible_namespace')
    b_collection_dir = os.path.join(b_namespace_dir, 'collection_name')

    os.makedirs(b_namespace_dir)
    os.makedirs(b_collection_dir)


# Generated at 2022-06-10 22:47:40.973897
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the function list_valid_collection_paths, using a fake search path list which includes some
    non existing or invalid collection paths.
    """
    fake_search_paths = ['/nonexisting/path',
                         'another/nonexsiting/yet/another/one',
                         '/existing/but/not/a/dir',
                         '/etc/ansible/collections',
                         '/etc/ansible/ansible_collections']
    search_paths = list(list_valid_collection_paths(fake_search_paths))
    len_sp = len(search_paths)
    assert len_sp == 2, 'Expect the number of filtered paths to be 2, but there were ' + str(len_sp)
    assert '/etc/ansible/collections' in search_paths

# Generated at 2022-06-10 22:47:52.880939
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = [
        u'./test/data/collections/namespace1',
        u'./test/data/collections/namespace2',
        u'./test/data/collections/namespace3',
        u'./test/data/collections/namespace4',
    ]


# Generated at 2022-06-10 22:47:59.897575
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.utils.collection_loader import ansible_collections_path

    def count_collection_dirs():
        ct = 0
        for path in list_collection_dirs():
            ct += 1
        return ct

    # function should return an empty list if no collection paths are configured
    assert list(list_collection_dirs()) == []

    # create a temp ansible_collections directory with a single collection
    tpath = tempfile.mkdtemp()
    os.makedirs(os.path.join(tpath, 'ansible_collections/testns/ansible_testcoll/modules'))

    # function should return a single dir if that is all that is found

# Generated at 2022-06-10 22:48:12.485951
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import stat

    path_to_tmp = tempfile.mkdtemp()
    collection_path = os.path.join(path_to_tmp, 'ansible_collections')
    os.mkdir(collection_path)

    # make namespace
    ns_path = os.path.join(collection_path, 'namespace')
    os.mkdir(ns_path)

    # make collection
    coll_path = os.path.join(ns_path, 'collection')
    os.mkdir(coll_path)

    # make roles
    internal_roles_path = os.path.join(coll_path, 'roles')
    os.mkdir(internal_roles_path)

    # make sample role

# Generated at 2022-06-10 22:48:20.035000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.foo.bar.plugins.module_utils import test_module_utils
    test_coll_path = os.path.dirname(os.path.dirname(test_module_utils.__file__))

    test_coll_path2 = os.path.join(test_coll_path, "extra")
    test_coll_path3 = os.path.join(test_coll_path, "extra2")
    test_coll_path4 = os.path.join(test_coll_path, "extra3")
    test_coll_path5 = os.path.join(test_coll_path, "extra4")

    # Check default path
    found = False
    for path in list_valid_collection_paths():
        if path == test_coll_path:
            found = True
    assert found

# Generated at 2022-06-10 22:48:31.108653
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    valid_search_path = tempfile.mkdtemp()
    coll_dir1 = os.path.join(valid_search_path, 'ansible_collections')
    coll_dir2 = os.path.join(valid_search_path, 'ansible_collections', 'namespace')
    coll_dir3 = os.path.join(valid_search_path, 'ansible_collections', 'namespace', 'collection1')
    coll_dir4 = os.path.join(valid_search_path, 'ansible_collections', 'namespace', 'collection2')
    os.makedirs(coll_dir2)
    os.makedirs(coll_dir3)
    os.makedirs(coll_dir4)

    invalid_search_path = tempfile.mk

# Generated at 2022-06-10 22:48:31.963069
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs('test') == None

# Generated at 2022-06-10 22:48:42.636841
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from unittest import mock

    f_path = "path1"
    f_path2 = "path2"
    f_path3 = "path3"
    f_path4 = "path4"
    f_path5 = "path5"
    f_path6 = "path6"

    # Test if None is supplied
    assert len(list(list_valid_collection_paths(None))) == len(AnsibleCollectionConfig.collection_paths)

    # Test if list is supplied
    assert len(list(list_valid_collection_paths([f_path]))) == len(AnsibleCollectionConfig.collection_paths) + 1

    # Test if list

# Generated at 2022-06-10 22:48:53.908200
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=['/tmp', '/bogus_path']) == ['/tmp']
    assert list_valid_collection_paths(search_paths=['/bogus_path']) == []
    assert list_valid_collection_paths(search_paths=['/tmp', '/tmp/bogus_subdir']) == ['/tmp', '/tmp/bogus_subdir']
    assert list_valid_collection_paths(search_paths=['/tmp', '/tmp/bogus_subdir/xyz']) == ['/tmp']
    assert list_valid_collection_paths(search_paths=['/tmp/bogus_subdir/xyz']) == []

# Generated at 2022-06-10 22:50:18.363154
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_list = ["testlist1", "testlist2"]
    test_list_paths = list_valid_collection_paths(search_paths=test_list)
    assert set(test_list) == set(test_list_paths)
    # list_valid_collection_paths should not return non existing paths
    test_list = ["testlist1", "/not/a/path" "testlist3"]
    test_list_paths = list_valid_collection_paths(search_paths=test_list)
    assert set(test_list) != set(test_list_paths)
    test_list_paths = list_valid_collection_paths()
    assert set(AnsibleCollectionConfig.get_collections_paths()) == set(test_list_paths)

# Unit test

# Generated at 2022-06-10 22:50:28.148896
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    # Create temp dir
    tmpdir = tempfile.mkdtemp()

    # Create a subdirectory off the temp dir
    os.makedirs(os.path.join(tmpdir, '.ansible', 'tmp', 'ansible_collections'))

    # Create a collection
    os.makedirs(os.path.join(tmpdir, '.ansible', 'tmp', 'ansible_collections', 'ansible', 'test'))

    # Empty collection
    paths = [os.path.join(tmpdir, '.ansible', 'tmp', 'ansible_collections', 'ansible', 'test', 'empty'), tmpdir]

    for out in list_valid_collection_paths(paths):
        assert out == tmpdir

    # Add a plugin