

# Generated at 2022-06-20 13:33:25.518062
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = [
        b'/home/john/.ansible/collections/ansible_collections/alumaweb/test_collection',
        b'/home/john/.ansible/collections/ansible_collections/alumaweb/ansible_test_collection',
        b'/home/john/Desktop/test_collections/ansible_collections/alumaweb/test_collection',
        b'/home/john/Desktop/test_collections/ansible_collections/alumaweb/ansible_test_collection'
    ]
    real_returned = list_collection_dirs(search_paths=['/home/john/.ansible/collections', '/home/john/Desktop/test_collections'])
    returned = list(real_returned)
    assert expected == returned


# Generated at 2022-06-20 13:33:29.253833
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = list_collection_dirs()


# Generated at 2022-06-20 13:33:34.848893
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_path = os.path.dirname(__file__)
    test_collection_dirs = list_collection_dirs([test_path])

    assert next(test_collection_dirs) == to_bytes('/tmp/ansible_collections', errors='surrogate_or_strict')

# Generated at 2022-06-20 13:33:45.341642
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.plugins.loader import collection_loader

    collection_path = 'foo'
    collection_loader.add_collection_path(path=collection_path)

    coll_paths = list(list_collection_dirs(search_paths=['.']))
    coll_paths.sort()

    assert len(collection_loader._collection_paths) == 2

    assert len(coll_paths) == 1

    ns, coll = os.path.basename(os.path.dirname(coll_paths[0])), os.path.basename(coll_paths[0])
    assert ns == 'testns'
    assert coll == 'testcoll'
    assert os.path.basename(os.path.dirname(os.path.dirname(coll_paths[0]))) == 'test_data'

# Generated at 2022-06-20 13:33:57.119227
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Assure function works with default collection paths
    dirs = list_collection_dirs()
    assert len(list(dirs)) > 0

    # Assure function works with empty list
    dirs = list_collection_dirs([])
    assert len(list(dirs)) > 0

    # Assure function works with nonexistent path
    dirs = list_collection_dirs(['/tmp/doesntexist'])
    assert len(list(dirs)) == 0

    # Assure function works with bogus path
    dirs = list_collection_dirs(['/tmp/doesntexist/ansible_collections/jctanner/testcol'])
    assert len(list(dirs)) == 0

    # Assure function works with valid path

# Generated at 2022-06-20 13:34:00.772096
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections = list_collection_dirs(['..', 'src'], 'foo.bar')

    assert len(collections) == 1
    assert len(next(collections)) == len('src/ansible_collections/foo/bar')


# Generated at 2022-06-20 13:34:12.200471
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = ['/some/path', '/other/path']
    test_coll_filter = 'foo.bar'
    expected = ['/some/path/ansible_collections/foo/bar']

    def dummy_list_valid_collection_paths(search_paths=None, warn=False):
        return test_paths

    def dummy_is_collection_path(coll_dir):
        if coll_dir == "/some/path/ansible_collections/foo/bar":
            return True
        else:
            return False

    list_collection_dirs.is_collection_path = dummy_is_collection_path
    list_collection_dirs.list_valid_collection_paths = dummy_list_valid_collection_paths


# Generated at 2022-06-20 13:34:21.102390
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test with coll_filter
    coll_filter = 'ansible.test1'
    collection_paths = ['~/.ansible/test']
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ':' + os.pathsep.join(collection_paths)
    list_paths = [path for path in list_collection_dirs(coll_filter=coll_filter)]
    assert list_paths[0] == os.path.expanduser(os.path.join('~', '.ansible/test/ansible_collections/ansible/test1'))

    # test with search_paths
    search_paths = ['~/.ansible/test', '~/.ansible/test1']
    del os.environ['ANSIBLE_COLLECTIONS_PATHS']
    list_

# Generated at 2022-06-20 13:34:31.576565
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    def verify_list_collection_dirs(coll_filter, expected_count, expected_files):
        """
        Verify the list_collection_dirs function behaves correctly
        :param coll_filter: either a collection or namespace to filter down on, or None for all
        :param expected_count: the number of collections returned
        :param expected_files: a list of tuples representing the collection subpaths we should expect in each collection returned
        :return:
        """
        # create a temp dir
        temp_dir = tempfile.mkdtemp()

        # make our paths
        base = os.path.join(temp_dir, 'collections')

        test_collection = os.path.join(base, 'test_namespace', 'test_collection')
        os.makedirs(test_collection)

        # create files

# Generated at 2022-06-20 13:34:42.077452
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test the default path
    default = list(list_valid_collection_paths())
    assert len(default) == 2
    assert default[0] == '/usr/share/ansible/collections'
    assert default[1] == '/usr/share/ansible_collections'

    # Add a non-existent path to the default
    result = list(list_valid_collection_paths(search_paths=['/nosuchdir']))
    assert len(result) == 2
    assert result[0] == '/usr/share/ansible/collections'
    assert result[1] == '/usr/share/ansible_collections'

    # Add a valid path to the default
    result = list(list_valid_collection_paths(search_paths=['/usr/share/my_ansible_collections']))

# Generated at 2022-06-20 13:34:59.921857
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["/tmp/c1", "/tmp/c2", "/tmp/c3"]
    collection_dirs = list_collection_dirs(search_paths)
    assert list(collection_dirs) == []
    search_paths = [
        "/tmp/ansible_collections/co1/ns1/coll1",
        "/tmp/ansible_collections/c/ns2/coll2",
        "/tmp/ansible_collections/co3/ns3/coll3",
    ]
    collection_dirs = list_collection_dirs(search_paths)

# Generated at 2022-06-20 13:35:12.250365
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Unit test for function list_valid_collection_paths """
    import shutil, tempfile, stat
    import os

    # create tmp directory
    test_dir = tempfile.mkdtemp()
    os.chmod(test_dir, stat.S_IRWXU)
    test_paths = [
        os.path.join(test_dir),
        os.path.join(test_dir, 'subdir'),
        os.path.join(test_dir, 'subdir2', 'subsubdir'),
        os.path.join(test_dir, 'subdir3', 'subsubdir', 'subsubsubdir'),
        os.path.join(test_dir, 'subdir3', 'subsubdir', 'subsubsubdir2', 'subsubsubsubdir'),
    ]


# Generated at 2022-06-20 13:35:19.491071
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    # create a temp dir to use as a search path for testing
    tempdir = tempfile.mkdtemp()

    # point search paths to temp dir
    search_paths = [tempdir]

    # create a fake collection
    fake_collection_dir = os.path.join(tempdir, 'ansible_collections', 'test_namespace', 'test_collection')
    os.makedirs(fake_collection_dir, mode=0o755)

    # create a test_collection.yml file for the fake collection
    fake_collection_yml = os.path.join(fake_collection_dir, 'ansible_collections', 'test_namespace', 'test_collection.yml')

# Generated at 2022-06-20 13:35:28.314077
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree

    # Empty paths
    assert list(list_valid_collection_paths([])) == []
    assert list(list_valid_collection_paths(None)) == []

    # Only valid paths
    temp_path = mkdtemp()
    try:
        assert list(list_valid_collection_paths([temp_path])) == [temp_path]
    finally:
        rmtree(temp_path)

    # Valid and invalid paths
    temp_path = mkdtemp()
    try:
        assert list(list_valid_collection_paths(['/not/a/path', temp_path])) == [temp_path]
    finally:
        rmtree(temp_path)

    # Paths which exist but are

# Generated at 2022-06-20 13:35:36.952994
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    tmp_dir = '/tmp/test_coll_path'
    tmp_dir_name = os.path.basename(tmp_dir)
    tmp_dir2 = '/tmp/test_coll_path_empty'
    tmp_dir2_name = os.path.basename(tmp_dir2)
    tmp_file = '/tmp/test_coll_path_file'
    tmp_file_name = os.path.basename(tmp_file)
    new_path = '/tmp/non_existing_coll_path'
    new_path_name = os.path.basename(new_path)
    os.makedirs(tmp_dir)
    os.makedirs(tmp_dir2)
    with open(tmp_file, "w") as f:
        f.write("")

# Generated at 2022-06-20 13:35:42.109797
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # TODO: this test needs to be converted to an integration test as it is not actually unit testing anything
    # function is returning correct paths based off of os.listdir calls
    # a more useful test would be one that compares entire contents of directories
    import pytest

    path = "/tmp/foo/ansible_collections/the_namespace/the_collection"
    assert list_collection_dirs() == [path]



# Generated at 2022-06-20 13:35:50.072222
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # function should return empty list when search_path does not exists
    search_path = ["/non/existing/path"]
    assert not list(list_valid_collection_paths(search_path))

    # function should return empty list when seach_path is not a directory
    node_exe = "/usr/bin/node"
    if os.path.exists(node_exe):
        search_path = [node_exe]
        assert not list(list_valid_collection_paths(search_path))

    # function should return search_path when it exists
    # and it is a directory
    search_path = ["/tmp"]
    assert list(list_valid_collection_paths(search_path))

# Generated at 2022-06-20 13:35:56.735400
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.ansible.plugins.loader import ansible_module_finder
    from ansible.module_utils._text import to_bytes
    from os.path import exists
    from shutil import rmtree

    # Create a temporary directory to act as the search_path
    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    rmtree(path, ignore_errors=True)

    # Create a temporary directory within the search_path to act as a collection
    collection_path = os.path.join(path, 'ansible_collections', 'namespace', 'collection')
    os.makedirs(collection_path)

    # A collection is a dir with a namespace file in it
    namespace_file = os.path.join(collection_path, 'namespace.yml')


# Generated at 2022-06-20 13:36:04.899409
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    from ansible.module_utils._text import to_text
    from ansible.collections.ansible.amazon.plugins.module_utils.ec2 import AWSLogs
    expected_path = to_text(os.path.join(AWSLogs.__path__[0], '..', '..'))
    assert list(list_collection_dirs(coll_filter='ansible_collections.amazon.aws.plugins.module_utils.ec2')) == [expected_path]

# Generated at 2022-06-20 13:36:12.063789
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_path_list = list_valid_collection_paths()
    #assert len(valid_path_list) == 4

    expected_paths = []

    # fixme, we don't have a test for this...
    #expected_paths.append(os.path.expanduser(b'~/.ansible/collections'))

    expected_paths.append(b'/usr/share/ansible/collections')

    # fixme, we don't have a test for this...
    #expected_paths.append(os.path.join(os.getcwd(), 'collections'))

    # For this we want to test pathlib API but it is not available in Python2.7
    import site

# Generated at 2022-06-20 13:36:26.423243
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Unit test for function list_collection_dirs."""
    search_paths = ['./test/integration/targets/collections',
                    './test/sanity/collection_data/default_config',
                    './test/sanity/collection_data/invalid_config']
    search_paths = list_valid_collection_paths(search_paths, warn=False)
    coll_dirs = list_collection_dirs(search_paths)

    assert len(coll_dirs) == 2
    assert b'./test/integration/targets/collections/ansible_collections/namespace1/collection1' in coll_dirs
    assert b'./test/sanity/collection_data/default_config/ansible_collections/namespace1/collection1' in coll_dir

# Generated at 2022-06-20 13:36:33.346138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test empty list of search paths
    test_paths = []
    assert not list_valid_collection_paths(test_paths)

    # test list with non-existent search path
    test_paths = ["/foo/bar/baz"]
    assert not list_valid_collection_paths(test_paths)

    # test list with non-directory search path
    test_paths = ["/usr/bin/python"]
    assert not list_valid_collection_paths(test_paths)

    # test list with existing directory search path
    test_paths = ["/etc"]
    assert "/etc" in list_valid_collection_paths(test_paths)

    # test list with all three type of search paths

# Generated at 2022-06-20 13:36:43.230308
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Unit test for function list_collection_dirs"""
    from ansible.utils.collection_loader import list_collection_dirs, \
        list_valid_collection_paths, AnsibleCollectionConfig
    from ansible.module_utils._text import to_bytes

    def test_coll_dirs(coll_filter):
        dirs = []
        for dirpath in list_collection_dirs(coll_filter=coll_filter):
            dirs.append(dirpath)
        return dirs

    # search_paths with default
    coll_root = os.path.join(os.path.dirname(__file__), "data/collections")
    AnsibleCollectionConfig.collection_paths = [coll_root]

    dirs = test_coll_dirs(coll_filter='test1.stuff')
    assert len

# Generated at 2022-06-20 13:36:53.136817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/does/not/exist'])) == []

    # main.yml is not one of the collection config files
    assert list(list_valid_collection_paths(['/etc/ansible'])) == []

    # minimal configuration, single path, path needs to exist
    assert list(list_valid_collection_paths(['/etc/ansible/ansible.cfg'])) == ['/etc/ansible/ansible.cfg']

# Generated at 2022-06-20 13:37:00.212280
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_valid_collection_paths
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    for path in AnsibleCollectionConfig.collection_paths:
        # all default paths exist
        assert list_valid_collection_paths([path])
    assert list_valid_collection_paths(['/not/a/real/path']) == ['/not/a/real/path']


# Generated at 2022-06-20 13:37:02.150309
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert 'test/test_collections' in list_valid_collection_paths(['test/test_collections'])

# Generated at 2022-06-20 13:37:12.406293
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test to verify behaviour of list_collection_dirs.
    """
    import tempfile
    import shutil
    import os

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create collection dirs
    os.mkdir(os.path.join(tmpdir, 'ansible_collections'))
    os.mkdir(os.path.join(tmpdir, 'ansible_collections', 'mynamespace1'))
    os.mkdir(os.path.join(tmpdir, 'ansible_collections', 'mynamespace1', 'mycollection1'))
    os.mkdir(os.path.join(tmpdir, 'ansible_collections', 'mynamespace1', 'mycollection2'))

# Generated at 2022-06-20 13:37:19.544389
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.test import AnsibleExitJson
    import sys

    try:
        # exit signal for test_utils.run_module_as_main()
        sys.exit = AnsibleExitJson
    except AttributeError:
        pass

    list_valid_collection_paths(search_paths=['/does_not_exist'], warn=True)
    list_valid_collection_paths(search_paths=['tests/support/root-collection/library'], warn=True)


if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-20 13:37:30.564970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    def _make_coll(path, namespace='test', collection='test'):
        os.mkdir(os.path.join(path, "ansible_collections"))
        os.mkdir(os.path.join(path, "ansible_collections", namespace))
        os.mkdir(os.path.join(path, "ansible_collections", namespace, collection))
        open(os.path.join(path, "ansible_collections", namespace, collection, "MANIFEST.json"), "w").close()


# Generated at 2022-06-20 13:37:37.563474
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    ret = list_valid_collection_paths(['/tmp/invalid_path'])
    assert not ret
    ret = list_valid_collection_paths(['/tmp/invalid_path'], True)
    assert not ret

    ret = list_valid_collection_paths(['/tmp'])
    assert ret
    ret = list_valid_collection_paths(['/tmp'], True)
    assert ret

    ret = list_valid_collection_paths(['./test/unit/utils/collection_loader/sample_collections'])
    assert ret
    ret = list_valid_collection_paths(['./test/unit/utils/collection_loader/sample_collections'], True)
    assert ret


# Generated at 2022-06-20 13:37:59.920901
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dir = '/tmp/ansible_collections'
    namespace = 'testns'
    collection = 'testcollection'
    coll_path = os.path.join(coll_dir, namespace, collection)
    os.makedirs(coll_path, exist_ok=True)

    coll_list = list(list_collection_dirs(search_paths=[coll_dir], coll_filter='%s.%s' % (namespace, collection)))
    assert(coll_list == [coll_path])

# Generated at 2022-06-20 13:38:02.778229
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_path = ['./non-existing-dir', '/usr/share']
    path1 = list_valid_collection_paths(test_path)

    for path in path1:
        assert os.path.exists(path)
        assert os.path.isdir(path)

# Generated at 2022-06-20 13:38:06.985389
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected_paths = {'/usr/share/ansible/collections', '/usr/share/ansible_collections', '/etc/ansible/collections'}
    result_paths = set(list_valid_collection_paths(search_paths=[]))

    assert expected_paths == result_paths



# Generated at 2022-06-20 13:38:16.664361
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    This method is used to test the list_valid_collection_paths method
    It returns True if the test passes else False
    """
    result = True
    search_path = ["/home/dev/collections", "/home/dev/collections", "/home/dev"]
    coll_path = list(list_valid_collection_paths(search_path))
    if len(coll_path) == 2:
        pass
    else:
        result = False
    return result


# Generated at 2022-06-20 13:38:25.505376
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    since we are patching list_valid_collection_paths, we don't have to supply the collection path,
    but the test requires that all the other arguments are supplied
    :return:
    """
    import os
    import tempfile
    import shutil
    import mock
    import unittest

    class TestListCollectionDirs(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(dir=os.getcwd())

            self.b_tmpdir = to_bytes(self.tmpdir, errors='surrogate_or_strict')
            self.b_good_ns = os.path.join(self.b_tmpdir, to_bytes('good_namespace'))

# Generated at 2022-06-20 13:38:38.018551
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    make sure we filter out non-existing paths
    :return:
    """

    import tempfile

    # create temp dir to test with
    tmpdir = tempfile.mkdtemp()

    # create some valid paths
    paths = [tmpdir, os.path.join(tmpdir,'ansible_collections')]

    # create a non-existing path
    paths.append(os.path.join(tmpdir,'doesnotexist'))

    # create file path, not dir
    open(os.path.join(tmpdir,'somefile'), 'a').close()
    paths.append(os.path.join(tmpdir,'somefile'))

    # call function
    for path in list_valid_collection_paths(paths):
        assert path in paths

if __name__ == '__main__':
    test

# Generated at 2022-06-20 13:38:43.225764
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ["/this/path/does/not/exist"]
    assert list(list_valid_collection_paths(search_paths=test_paths, warn=True)) == []

# Generated at 2022-06-20 13:38:54.978265
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.utils.path import unfrackpath
    import unittest.mock as mock

    @pytest.fixture
    def tmp_path(tmpdir):
        return unfrackpath(to_text(tmpdir.strpath))

    def test_search_paths(tmp_path):
        """
        Test that list_valid_collection_paths returns a valid set of search paths
        """
        # make a directory and file in a parent directory
        (tmp_path / 'src').mkdir()
        (tmp_path / 'src/ansible_collections').mkdir()
        (tmp_path / 'src/ansible_collections/collection').mkdir()

# Generated at 2022-06-20 13:39:05.549257
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.constants as C

    search_dirs = [C.DEFAULT_COLLECTIONS_PATHS[0]]
    coll_dirs = list_collection_dirs(search_dirs)

    assert len(coll_dirs) >= 1
    assert len([x for x in coll_dirs if b"ns1.coll1" in x]) == 1
    assert len([x for x in coll_dirs if b"ns1.coll1" not in x]) >= 1
    assert len([x for x in coll_dirs if b"ns2.coll2" not in x]) >= 1
    assert len([x for x in coll_dirs if b"ns2.coll2" in x]) == 1

# Generated at 2022-06-20 13:39:15.853145
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil
    from ansible.module_utils._text import to_native

    # initialize a fake config
    temp_config_dir = tempfile.mkdtemp(prefix='ansible-collections-test_config.')
    fake_config_path = os.path.join(temp_config_dir, 'ansible.cfg')
    with open(fake_config_path, 'w') as fp:
        fp.write('[defaults]\ncollections_path=%s' % os.path.join(temp_config_dir, 'foo'))

    # create a couple collection dirs and some junk
    temp_path = to_native(tempfile.mkdtemp(prefix='ansible-collections-test.'))

# Generated at 2022-06-20 13:39:46.229246
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    def list_valid_collection_paths_test(paths, valid_paths):
        assert set(list_valid_collection_paths(paths)) == set(valid_paths)

    # empty list
    list_valid_collection_paths_test([], [])

    # none in list
    list_valid_collection_paths_test([None], [])

    # single valid list
    valid_paths = [tempfile.mkdtemp()]
    list_valid_collection_paths_test(valid_paths[:], valid_paths)

    # multiple valid in list
    valid_paths = [tempfile.mkdtemp() for _ in range(10)]
    list_valid_collection_paths_test(valid_paths[:], valid_paths)

    #

# Generated at 2022-06-20 13:39:54.569176
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), list)
    assert isinstance(list_valid_collection_paths(['/tmp']), list)
    assert isinstance(list_valid_collection_paths(['/tmp', '/home']), list)
    assert isinstance(list_valid_collection_paths(['/tmp', '/home'], True), list)
    assert isinstance(list_valid_collection_paths(None), list)
    assert isinstance(list_valid_collection_paths(None, True), list)



# Generated at 2022-06-20 13:39:58.721191
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [u"/Users/sjenning/ansible", u"/Users/sjenning/ansible_collections"]
    assert list(list_valid_collection_paths(test_paths)) == [u"/Users/sjenning/ansible_collections"]

# Generated at 2022-06-20 13:40:05.715776
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _collection_finder
    from ansible.plugins.loader import plugin_loader

    # test that plugin_loader finds collection from paths
    assert plugin_loader.find_plugin(type_name='module', name='__fake_ns.__fake_coll.fakedocmodule') is not None

    # test that collection_finder finds collection from paths
    b_coll = to_bytes('__fake_ns.__fake_coll.fakedocmodule')
    assert b_coll in _collection_finder.collection_paths



# Generated at 2022-06-20 13:40:15.845310
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['test/unit/utils/collections/test_collections/main',
                    'test/unit/utils/collections/test_collections/dupe_colls',
                    'test/unit/utils/collections/test_collections/bad_colls']
    ns_filter = "ns_a"
    coll_filter = "coll_a.coll_b"
    coll_b_path = "test/unit/utils/collections/test_collections/main/ansible_collections/ns_a/coll_b"

    # all collections
    coll_paths = list(list_collection_dirs(search_paths, None))
    assert len(coll_paths) == 2
    assert coll_b_path in coll_paths

    # namespaced collections

# Generated at 2022-06-20 13:40:26.858099
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with None input
    result = list(list_collection_dirs())
    assert isinstance(result, list)
    assert len(result) > 0

    # Test with non-existing path
    assert len(list(list_collection_dirs(['/i_dont_exist']))) == 0

    # Test for a specific collection
    result = list(list_collection_dirs(coll_filter='ansible_collections.testns.testcoll'))
    assert len(result) == 1

    # Test for a specific namespace
    result = list(list_collection_dirs(coll_filter='ansible_collections.testns'))
    assert len(result) > 1

    # Test for a specific namespace with non-existing coll_filter

# Generated at 2022-06-20 13:40:41.211312
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    fd, path = tempfile.mkstemp()
    os.utime(path, None)
    assert list(list_collection_dirs(search_paths=[path])) == []

    test_dir = tempfile.mkdtemp()
    test_dir_1 = os.path.join(test_dir, 'ansible_collections')
    os.mkdir(test_dir_1)
    test_dir_2 = os.path.join(test_dir_1, 'ns1')
    os.mkdir(test_dir_2)

    open(os.path.join(test_dir_2, 'coll1.yml'), 'w+').close()
    open(os.path.join(test_dir_2, 'coll1.ps1'), 'w+').close()
   

# Generated at 2022-06-20 13:40:50.271615
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile
    coll_root = tempfile.mkdtemp()
    path = os.path.join(coll_root, 'ansible_collections')
    os.mkdir(path)
    os.mkdir(os.path.join(path, 'namespace'))
    os.mkdir(os.path.join(path, 'namespace', 'collection'))
    open(os.path.join(path, 'namespace', 'collection', 'plugins', '__init__.py'), 'w').close()

    results = list(list_collection_dirs([coll_root]))

    expected = [
        os.path.join(path, 'namespace', 'collection')
    ]

    assert results == expected

    shutil.rmtree(coll_root)



# Generated at 2022-06-20 13:41:00.549015
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    temp_collection_path = tempfile.mkdtemp()
    temp_collection_path_1 = tempfile.mkdtemp()
    temp_collection_path_2 = tempfile.mkdtemp()
    temp_collection_paths = [temp_collection_path, temp_collection_path_1, temp_collection_path_2]

    # so we can check that the search path was found when it contains a trailing slash
    trailing_slash_path = temp_collection_path + "/"
    trailing_slash_paths = [trailing_slash_path]

    temp_namespace_path = os.path.join(temp_collection_path, 'ansible_collections')

# Generated at 2022-06-20 13:41:08.849095
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test with empty search path list
    test_list = []
    assert list_collection_dirs(test_list) is not None
    # test with collection filter
    test_list = []
    coll_filter = "foo"
    assert list_collection_dirs(test_list, coll_filter) is not None

# Generated at 2022-06-20 13:41:53.044069
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This test should be run from tests/
    """
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils._text import to_bytes

    # empty list of paths, raise error
    try:
        list(list_collection_dirs())
    except AnsibleError:
        pass

    # add a path to an existing directory, find all collections
    test_dir = AnsibleCollectionConfig._default_collection_paths[0]
    test_dirs = list(list_collection_dirs(search_paths=[test_dir]))
    assert len(test_dirs) > 5

    # add a path to an existing directory, do not warn as not default
    test_dir = AnsibleCollectionConfig._default_collection_paths[0]

# Generated at 2022-06-20 13:42:04.765246
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # setup mock dirs and files
    # we only test the resulting list of collection paths
    os.makedirs('./test_coll_path/ansible_collections/namespace1/collection1')
    os.makedirs('./test_coll_path/ansible_collections/namespace1/collection2')
    os.makedirs('./test_coll_path/ansible_collections/namespace2/collection1')

    os.mknod('./test_coll_path/ansible_collections/namespace1/collection1/plugins/modules/test.py')
    os.mknod('./test_coll_path/ansible_collections/namespace1/collection2/plugins/modules/test.py')

# Generated at 2022-06-20 13:42:18.517786
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import Paths
    import tempfile

    # create temporary test dirs
    tmpdir = tempfile.gettempdir()
    tmp_coll_dir = os.path.join(tmpdir, "test_collections")
    os.makedirs(tmp_coll_dir)
    os.makedirs(tmp_coll_dir + "_2")

    # temporarily set the collection search paths
    p = Paths()
    saved_paths = p.get_search_paths()

# Generated at 2022-06-20 13:42:25.114438
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collection_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures', 'test_collections')
    test_collection_namespace = 'my.collection.namespace'
    test_collection_name = 'my_collection'
    test_collection_path_full = os.path.join(test_collection_path, 'ansible_collections', test_collection_namespace, test_collection_name)

    dirs = list(list_collection_dirs(coll_filter='%s.%s' % (test_collection_namespace, test_collection_name), search_paths=[test_collection_path]))

    assert test_collection_path_full in dirs

# Generated at 2022-06-20 13:42:29.887298
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Validate that we can return a list of directories for collections
    """

    search_paths = [
        'tests/fixtures/my_collections/foo',
        'tests/fixtures/my_collections/bar',
        'tests/fixtures/my_collections/baz',
        'tests/fixtures/my_collections/boo',
        'tests/fixtures/my_collections/bam',
        'tests/fixtures/my_collections/baz/bam',
    ]

    # test that with no namespace or collection specified return all collections
    colls = list(list_collection_dirs(search_paths))
    assert len(colls) == 3
    assert 'tests/fixtures/my_collections/foo/test/test_action' in colls

# Generated at 2022-06-20 13:42:33.652645
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    good_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    res = list_collection_dirs([good_path])
    assert res is not None



# Generated at 2022-06-20 13:42:43.898272
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils import collection_loader as cl
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    display.verbosity = 3
    old_config_data = AnsibleCollectionConfig.config_data

# Generated at 2022-06-20 13:42:53.041906
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert set(list_collection_dirs(['Test/integration/test_data/test_collections',
                                     'Test/integration/test_data/test_collections/ansible_collections'])) == \
           set([b'Test/integration/test_data/test_collections/ansible_collections/test_ns/test_coll/',
                b'Test/integration/test_data/test_collections/ansible_collections/test_ns/another_coll/',
                b'Test/integration/test_data/test_collections/another_namespace/another_collection/'])


# Generated at 2022-06-20 13:42:59.949686
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # pylint: disable=unused-argument
    def mock_display_warning(message):
        pass

    # pylint: disable=unused-variable
    def mock_os_path_exists(path):
        assert path in {
            to_bytes(os.path.join(os.getcwd(), "does_not_exist")),
            to_bytes(os.path.join(os.getcwd(), "does_exist", "does_not_exist")),
            to_bytes(os.getcwd())
        }
        return path != to_bytes(os.path.join(os.getcwd(), "does_not_exist"))

    # pylint: disable=unused-variable

# Generated at 2022-06-20 13:43:04.889931
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test if list_collection_paths returns all
    collection paths found in the configured path.
    """
    collection_dirs = list(list_collection_dirs())
    assert isinstance(collection_dirs, list)
    assert len(collection_dirs) >= 29

