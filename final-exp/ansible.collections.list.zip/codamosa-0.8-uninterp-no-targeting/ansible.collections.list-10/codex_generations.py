

# Generated at 2022-06-20 13:33:20.655357
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs())
    assert collection_dirs is not None

# Generated at 2022-06-20 13:33:25.571814
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Given
    search_paths = ['../lib/ansible/plugins/collection/', './data/foo/bar/collections/ansible_collections']

    # When
    result = list_valid_collection_paths(search_paths)

    # Then
    result = list(result)
    assert result == ['./data/foo/bar/collections/ansible_collections']



# Generated at 2022-06-20 13:33:31.280125
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test 1, path is a file, not a directory
    my_path = "/usr/lib/python2.7/dist-packages/ansible/playbooks/playbook.py"
    assert len(list(list_valid_collection_paths(search_paths=[my_path]))) == 0

    # Test 2, path does not exist
    my_path = "/tmp/no_exist"
    assert len(list(list_valid_collection_paths(search_paths=[my_path]))) == 0

    # Test 3, path is a directory
    my_path = "/tmp"
    assert len(list(list_valid_collection_paths(search_paths=[my_path]))) == 1

    # Test 4, path does not exist, but does not warn
    my_path = "/tmp/no_exist"


# Generated at 2022-06-20 13:33:42.313964
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    paths = []

    # dir does not exist
    paths.append('/dne')

    # dir exists and is a file
    with tempfile.NamedTemporaryFile('w') as f:
        paths.append(f.name)

    # non ansible_collections dir
    non_coll_dir = tempfile.mkdtemp(prefix='test_list_collection_dirs')
    paths.append(non_coll_dir)

    # ansible_collections dir with no subdirs
    coll_root = tempfile.mkdtemp(prefix='ansible_collections')
    paths.append(coll_root)

    # ansible_collections dir with a subdir without sync.yml
    coll_root = tempfile.mkdtemp(prefix='ansible_collections')
    coll_dir

# Generated at 2022-06-20 13:33:50.693945
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # list_valid_collection_paths with no input
    result = list_valid_collection_paths()

    assert result == AnsibleCollectionConfig.collection_paths

    # list_valid_collection_paths with no input and warnings
    result = list_valid_collection_paths()

    assert result == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-20 13:33:55.267142
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test that the function works as expected"""
    # No valid paths, no collections returned
    assert not list(list_collection_dirs(search_paths=['']))
    # No search paths, no collections returned
    assert not list(list_collection_dirs(search_paths=[]))


# Generated at 2022-06-20 13:34:02.183020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_collection = [
        'namespace1.coll1',
        'namespace2.coll2',
        'namespace3.coll3'
    ]

    display.verbosity = 99
    display.deprecation_warnings = True
    colls = list(list_collection_dirs(coll_filter="TESTNAMESPACE.TESTCOLL"))
    for coll in colls:
        assert "TESTNAMESPACE" in coll
        assert "TESTCOLL" in coll

# Generated at 2022-06-20 13:34:12.354977
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function
    """
    from ansible_collections.ansible.tests.unit.compat.mock import patch
    from ansible_collections.ansible.tests.unit.compat.mock import Mock
    import os

    tmpdir = "/tmp/sampleansiblecollectionsdir"
    os.makedirs(tmpdir)

    collec_dir_first = "/tmp/sampleansiblecollectionsdir/namespace/collection1"
    collec_dir_second = "/tmp/sampleansiblecollectionsdir/namespace/collection2"
    collec_dir_third = "/tmp/sampleansiblecollectionsdir/namespace/collection3"
    os.makedirs(collec_dir_first)
    os.makedirs(collec_dir_second)


# Generated at 2022-06-20 13:34:18.729415
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test that list_valid_collection_paths returns a subset of original list
    """
    orig_paths = ['~/ansible_collections', '~/ansible_collections/', '/tmp']

    expected_output = [os.path.expanduser('~/ansible_collections')]

    calculated_output = list(list_valid_collection_paths(orig_paths, warn=False))

    # Check that expected and calculated are the same
    assert expected_output == calculated_output


# Generated at 2022-06-20 13:34:27.106833
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import shutil
    import tempfile
    import unittest

    try:
        import ansible.module_utils.ansible_release
        has_ansible = True
    except:
        # most likely running from a source distribution that does not include the files
        has_ansible = False

    from ansible.utils.collection_loader import list_collection_dirs

    class TestCollectionLoader(unittest.TestCase):

        def setUp(self):
            self.collections_dir = tempfile.mkdtemp()
            self.namespaces = ['ns1', 'ns2', 'ns3']
            self.collections = ['col1', 'col2', 'col3', 'col4']
            self.collection_dirs = set()

            self.setup_collection_dir()


# Generated at 2022-06-20 13:34:40.290060
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Ignore this test if we do not have the needed test dirs
    try:
        os.stat("tests/resources/collection_loader")
        os.stat("tests/resources/collection_loader/invalid")
    except OSError:
        pass
    else:
        search_paths = ["tests/resources/collection_loader/foo",
                        "tests/resources/collection_loader/invalid",
                        "tests/resources/collection_loader/bar"]
        for path in list_valid_collection_paths(search_paths):
            assert os.path.isdir(path)

# Generated at 2022-06-20 13:34:46.078020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    result = list(list_collection_dirs(coll_filter='test.test_collection'))
    assert result == []

    tempdir = tempfile.mkdtemp()

    path = os.path.join(tempdir, 'ansible_collections', 'test', 'test_collection')
    os.makedirs(path)

    result = list(list_collection_dirs(search_paths=[tempdir], coll_filter='test.test_collection'))
    assert result == [to_bytes(path)]

    shutil.rmtree(tempdir)

# Generated at 2022-06-20 13:34:48.581830
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # TODO: Add tests here

    pass



# Generated at 2022-06-20 13:34:57.932731
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.utils.path import makedirs_safe

    search_paths = []
    for i in range(1, 5):
        path = os.path.join(tempfile.gettempdir(), "collection_test_" + str(i))
        search_paths.append(path)
        makedirs_safe(path)

    new_search_paths = list_valid_collection_paths(search_paths)
    assert len(new_search_paths) == 4
    assert new_search_paths[0].endswith("collection_test_1")

# Generated at 2022-06-20 13:35:05.789531
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.constants import COLLECTIONS_PATHS
    from tempfile import TemporaryDirectory
    import pytest

    # test no paths
    with pytest.raises(AnsibleError, match='No collection paths were configured or discovered for use'):
        list(list_collection_dirs())

    # test empty paths
    with pytest.raises(AnsibleError, match='No collection paths were configured or discovered for use'):
        list(list_collection_dirs([]))

    # test non existent path
    with TemporaryDirectory() as tmpdir:
        with pytest.raises(AnsibleError, match='No collection paths were configured or discovered for use'):
            list(list_collection_dirs([tmpdir]))

# Generated at 2022-06-20 13:35:14.357974
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    def helper(coll_filter, expected_results):
        assert list(list_collection_dirs(coll_filter=coll_filter)) == expected_results

    helper('bad', [])
    helper('acme.foo', [])
    helper('acme', ['acme.dummy'])
    helper('acme.dummy', ['acme.dummy'])
    helper('acme.dummy.bar', ['acme.dummy'])
    helper(None, ['acme.dummy', 'acme.another', 'acme.foo_bar'])

# Generated at 2022-06-20 13:35:26.960267
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    # create temp directories for collection
    ns_dirname = tempfile.mkdtemp()
    os.mkdir(os.path.join(ns_dirname, 'ansible_collections'))
    coll_dirname = os.path.join(ns_dirname, 'ansible_collections', 'test', 'test')
    os.makedirs(coll_dirname)
    with open(os.path.join(coll_dirname, 'MANIFEST.json'), 'w') as f:
        f.write("""{"namespace": "test", "name": "test", "version": "1.0.0"}""")

    # test that it returns the valid directory
    collection = list(list_collection_dirs([ns_dirname], 'test.test'))

# Generated at 2022-06-20 13:35:32.635933
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.facts.virtual.namespace import list_collection_dirs
    from ansible.module_utils.facts.virtual.namespace import list_valid_collection_paths
    for root in list_valid_collection_paths(warn=False):
        for collection in list_collection_dirs([root+"/ansible_collections"]):
            assert collection is not None

# Generated at 2022-06-20 13:35:38.204507
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import namedtuple

    # normalize_path() is in the idempotent library, so we have to mock it out
    from ansible.test.unit.utils import mock_plugins
    from ansible.utils.path import normalize_path

    collection_one = namedtuple('collection_one', ['collection', 'namespace', 'plugin_file'])
    coll_one = collection_one('one', 'ns', 'plugins/modules/foo.py')

    collection_two = namedtuple('collection_two', ['collection', 'namespace', 'plugin_file'])
    coll_two = collection_two('two', 'ns', 'plugins/modules/bar.py')

    collection_three = namedtuple('collection_three', ['collection', 'namespace', 'plugin_file'])

# Generated at 2022-06-20 13:35:49.979936
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    test that list_valid_collection_paths works correctly
    """
    import tempfile

    # Create a temorary directory to use for this test.
    temp_dir = tempfile.mkdtemp()

    # Create a subdirectory of the temorary directory.
    temp_sub_dir = tempfile.mkdtemp(dir=temp_dir)

    # Create a temporary file and open it for writing.
    (temp_file_fd, temp_file_path) = tempfile.mkstemp(dir=temp_dir)
    temp_file = os.fdopen(temp_file_fd, 'w')

    # Create a list of paths.

# Generated at 2022-06-20 13:36:07.823627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from ansible_collections.ansible.community.tests.unit.test_collection_config import get_test_config

    coll_root = get_test_config().config.get_collection_paths()[0]

    assert None is list(list_collection_dirs([coll_root], 'nonexistent_namespace.nonexistent_collection'))

    assert set(list_collection_dirs([coll_root, 'nonexistent_namespace.nonexistent_collection'])) == \
           set(list_collection_dirs([coll_root]))

    assert set(list_collection_dirs([coll_root, 'ansible.abc'])) == \
           set(list_collection_dirs([coll_root, 'ansible.abc_common_core']))


# Generated at 2022-06-20 13:36:15.745692
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        '/non/existent/path',
        '/dev',
        '/etc',
        '/usr/share/ansible',
        '/usr/share/ansible/collections/ansible_collections',
        '/usr/share/ansible/collections',
        '/usr/share/ansible/ansible_collections',
    ]

    # set up test case
    valid_paths = [p for p in list_valid_collection_paths(test_paths)]

    assert len(valid_paths) == 3

    assert '/etc' in valid_paths
    assert '/usr/share/ansible/collections' in valid_paths
    assert '/usr/share/ansible/ansible_collections' in valid_paths

    assert '/non/existent/path' not in valid_path

# Generated at 2022-06-20 13:36:25.919045
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test real and fake paths
    paths = [u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cg',
             u'/etc/ansible/ansible.cfg', u'/opt/test', u'~/test']
    expected = [u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cfg',
                u'/etc/ansible/ansible.cfg', u'/etc/ansible/ansible.cfg']
    assert list(list_valid_collection_paths(paths)) == expected
    assert list(list_valid_collection_paths(paths, warn=True)) == expected

    paths

# Generated at 2022-06-20 13:36:39.719357
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    b_temp_dir = to_bytes(temp_dir)

    b_coll_path_1 = os.path.join(b_temp_dir, to_bytes("path1"))
    coll_path_1 = to_text(b_coll_path_1)

    os.mkdir(b_coll_path_1)

    b_coll_root_1 = os.path.join(b_coll_path_1, b"ansible_collections")
    os.mkdir(b_coll_root_1)

    b_ns1 = os.path.join(b_coll_root_1, b"test_ns1")
    os.mkdir(b_ns1)
    b_col1

# Generated at 2022-06-20 13:36:46.307956
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = list_valid_collection_paths()
    # list_collection_dirs is an generator, let's call it once to get results.
    # Since some CI runs yields different list_collection_dirs results, we need to make sure to call it twice
    # to make sure we got the expected number of results
    first_call_number_of_results = len(list(list_collection_dirs(search_paths=search_paths)))
    second_call_number_of_results = len(list(list_collection_dirs(search_paths=search_paths)))

# Generated at 2022-06-20 13:36:51.744217
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list_collection_dirs(search_paths=['test/unit/plugins/collections/fixtures/ansible_collections_1'], coll_filter='acme.test_collection')
    assert list(dirs) == ['test/unit/plugins/collections/fixtures/ansible_collections_1/acme/test_collection']

# Generated at 2022-06-20 13:37:03.246099
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    test_dir = tempfile.mkdtemp()
    test_dirs = [os.path.join(test_dir, "foo"), os.path.join(test_dir, "bar"), os.path.join(test_dir, "baz")]
    test_collections = [os.path.join(test_dir, 'foo/ansible_collections/acme/foobar/'),
                        os.path.join(test_dir, 'bar/ansible_collections/acme/foobar/'),
                        os.path.join(test_dir, 'baz/ansible_collections/acme/foobar/')]

# Generated at 2022-06-20 13:37:13.230588
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # create a basic collection structure
    b_ansible_collections = to_bytes(os.path.join(temp_dir, 'ansible_collections'))
    os.mkdir(b_ansible_collections)
    b_collection_dir = os.path.join(b_ansible_collections, b'test_ns', b'test_coll')
    os.makedirs(b_collection_dir)

    # run the function using the temp dir
    collection_dirs = list_collection_dirs(search_paths=[temp_dir])

    # verify the result
    assert len(list(collection_dirs)) == 1

# Generated at 2022-06-20 13:37:20.746724
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Does not exist
    assert list(list_collection_dirs(['/does/not/exist/foo'])) == []

    # Is a file
    assert list(list_collection_dirs(['/etc/hosts'])) == []

    # Bad collection name
    assert list(list_collection_dirs(['t/ansible_collections/test/test'])) == []

    # No collections
    assert list(list_collection_dirs(['t/ansible_collections/test'])) == []
    assert list(list_collection_dirs(['t/ansible_collections/test/test_collection'])) == []

    # No namespace match
    assert list(list_collection_dirs(['t/ansible_collections'], 'test.test_collection')) == []

    # No collection match
   

# Generated at 2022-06-20 13:37:27.086283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test function list_collection_dirs given a collection path."""
    import tempfile
    dirs = {}

    dirs['coll_path'] = tempfile.mkdtemp()

    dirs['ns_path'] = tempfile.mktemp(dir=dirs['coll_path'])
    os.mkdir(dirs['ns_path'])

    dirs['coll_name'] = tempfile.mktemp(dir=dirs['ns_path'])
    os.mkdir(dirs['coll_name'])

    dirs['playbooks_path'] = tempfile.mktemp(dir=dirs['coll_name'])
    os.mkdir(dirs['playbooks_path'])
    dirs['plugins_path'] = tempfile.mktemp(dir=dirs['coll_name'])

# Generated at 2022-06-20 13:37:38.777028
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search = ['tmp', 'tmp/bar', 'tmp/bar/ansible_collections']
    for path in list_valid_collection_paths(search, warn=True):
        print(path)



# Generated at 2022-06-20 13:37:40.320442
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    mydata = list_collection_dirs()
    assert mydata is not None

# Generated at 2022-06-20 13:37:50.894918
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # catch missing path
    assert list(list_valid_collection_paths(["/tmp/ANSIBLE/foo", "/tmp/ANSIBLE/bar"])) == ['/tmp/ANSIBLE/bar']

    # catch missing path
    assert list(list_valid_collection_paths(["/tmp/ANSIBLE/foo", "/tmp/ANSIBLE/bar"], warn=True)) == ['/tmp/ANSIBLE/bar']

    # catch file instead of directory
    assert list(list_valid_collection_paths(["/tmp/ANSIBLE/foo", "/tmp/ANSIBLE/bar", "/tmp/ANSIBLE"], warn=True)) == ['/tmp/ANSIBLE/bar']



# Generated at 2022-06-20 13:37:57.345577
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    n = [
        path for path in list_collection_dirs(
            search_paths=['tests/data/collections/collections3'],
            coll_filter='some_namespace')
    ]
    assert os.path.basename(n[0]) == 'some_col'

# Generated at 2022-06-20 13:38:07.260107
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Helper for unit test for list_collection_dirs
    Usage:
        cd ansible/lib/ansible/plugins/test/utils_collection
        python -m unittest test_list_collection_dirs
    """

    import unittest
    import tempfile
    import shutil
    import os

    class TestListCollectionDirs(unittest.TestCase):
        '''
        Unit-test class for list_collection_dirs()
        '''
        def setUp(self):
            '''
            setUp for test_list_collection_dirs
            '''
            # make test dir
            self.tmp_dir = tempfile.mkdtemp()
            self.ns_dir1 = os.path.join(self.tmp_dir, 'ansible_collections', 'ns1')
           

# Generated at 2022-06-20 13:38:19.993906
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/tmp', '/no/path', '/tmp/no_collection_path']
    coll_paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(coll_paths) == 1 and '/tmp' in coll_paths

    paths = ['/tmp/collection_path', '/tmp/no_collection_path']
    coll_paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(coll_paths) == 2 and '/tmp/collection_path' in coll_paths and '/tmp/no_collection_path' in coll_paths

    paths = []
    coll_paths = list(list_valid_collection_paths(paths, warn=False))
    assert len(coll_paths) == 0



# Generated at 2022-06-20 13:38:27.591250
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with no search paths
    coll_paths = list(list_collection_dirs())
    assert len(coll_paths) > 0

    # Test with provided search path
    search_paths = ['./test/units/utils/ansible_collections']
    coll_paths = list(list_collection_dirs(search_paths=search_paths))
    assert len(coll_paths) > 0

    # Test with invalid search path
    search_paths = ['./test/units/utils/invalid_path']
    coll_paths = list(list_collection_dirs(search_paths=search_paths))
    assert len(coll_paths) == 0

    # Test for specific collection

# Generated at 2022-06-20 13:38:31.801610
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.notstdlib.moveitallout.tests.test_utils.test_list_collection_dirs import test_list_collection_dirs
    test_list_collection_dirs()



# Generated at 2022-06-20 13:38:41.669450
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Searching for a specific collection in a specific namespace
    expected_result = [
        "/test/ansible_collections/test_namespace/test_collection",
    ]
    assert [x for x in list_collection_dirs(
        ["/test"],
        coll_filter="test_namespace.test_collection"
    )] == expected_result

    # Searching for a specific collection in a default namespace
    expected_result = [
        "/test/ansible_collections/test_namespace/test_collection",
    ]
    assert [x for x in list_collection_dirs(
        ["/test"],
        coll_filter="test_collection"
    )] == expected_result

    # Searching for a specific collection in a specific namespace but namespace is not present
    expected_result = [
    ]

# Generated at 2022-06-20 13:38:54.884973
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import stat
    from ansible.utils.collection_loader import list_collection_dirs
    # Create a dummy collection
    b_colls_parent = os.path.join(to_bytes(tempfile.gettempdir()), b"ansible_collections")
    os.mkdir(b_colls_parent)
    b_coll_name = b"awesome_collection"
    b_coll_path = os.path.join(b_colls_parent, b_coll_name)
    os.mkdir(b_coll_path)
    # Create some content
    b_module_name = b"i_am_awesome.py"
    b_module_path = os.path.join(b_coll_path, b_module_name)
   

# Generated at 2022-06-20 13:39:12.158298
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = ['foo/bar', 'baz', '/not/a/real/path/']

    paths = list(list_valid_collection_paths(search_paths=test_paths))

    assert len(paths) == 2

    assert paths[0] == 'foo/bar'
    assert paths[1] == 'baz'

# Generated at 2022-06-20 13:39:21.583542
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    
    # mock display instance
    display.warning = lambda msg: msg

    # mock valid collection path
    os.path.exists = lambda path: True
    os.path.isdir = lambda path: True

    # create search_paths list
    search_paths = []

    # valid dir?
    search_paths.append('/path/to/somewhere')

    # call the function
    for path in list_valid_collection_paths(search_paths):
        pass

    assert path == '/path/to/somewhere'

    # non existent dir?
    search_paths.append('/does/not/exist')

    # call the function

# Generated at 2022-06-20 13:39:28.350275
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    file_path = os.path.join(os.path.dirname(__file__), 'test_list_collection_dirs.py')
    ansible_test_root = os.path.join(os.path.dirname(os.path.dirname(file_path)), 'test', 'lib')

    # These directories should have unique collection names, but the same collection versions
    path1 = os.path.join(ansible_test_root, 'collections_test_path', 'path1')
    path1_ns1_coll1 = os.path.join(path1, 'ns1', 'coll1', 'manifest.json')
    path1_ns1_coll1_version = '1.0.0'

# Generated at 2022-06-20 13:39:32.620179
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths())
    assert list(list_valid_collection_paths(search_paths=['/tmp/not_a_dir'])) == list()


# Generated at 2022-06-20 13:39:46.228899
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Incorrect case, None value for 'search_paths' parameter
    try:
        list_valid_collection_paths(search_paths=None)
    except:
        pass
    else:
        raise AssertionError()

    # Incorrect case, non list value for 'search_paths' parameter
    try:
        list_valid_collection_paths(search_paths='a')
    except:
        pass
    else:
        raise AssertionError()

    # Incorrect case, list with non str items value for 'search_paths' parameter
    try:
        list_valid_collection_paths(search_paths=['a', 2])
    except:
        pass
    else:
        raise AssertionError()

    # Incorrect case, non bool value for 'warn' parameter

# Generated at 2022-06-20 13:39:50.782516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    collection_paths_test = ['/tmp/', '/tmp', '/usr/share/ansible/not_collections', '/usr/share/ansible']
    assert list(list_valid_collection_paths(collection_paths_test)) == ['/tmp', '/usr/share/ansible/not_collections', '/usr/share/ansible']



# Generated at 2022-06-20 13:39:59.931746
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test that list_valid_collection_paths returns appropriate paths
    """

    # Test default
    default_paths = list_valid_collection_paths()
    assert len(default_paths) == 1

    # Test bad paths
    bad_paths = ['not/a/valid/path', 'another/invalid/path']
    filtered_paths = list_valid_collection_paths(bad_paths, warn=True)
    assert len(filtered_paths) == 0

    # Test a good path
    good_paths = next(list_valid_collection_paths([]))
    filtered_paths = list_valid_collection_paths([good_paths])
    assert len(filtered_paths) == 1

    # Test good and bad paths
    filtered_paths = list_

# Generated at 2022-06-20 13:40:04.755214
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'ansible_collections.mazer_test.collection_1' in list_collection_dirs(coll_filter='mazer_test.collection_1')
    assert 'ansible_collections.mazer_test.collection_1' not in list_collection_dirs(coll_filter='mazer_test.collection_2')

# Generated at 2022-06-20 13:40:10.129016
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    with pytest.raises(AnsibleError, match='The configured collection path foo/bar does not exist'):
        list(list_valid_collection_paths(search_paths=['fizz/buzz', 'foo/bar'], warn=True))

# Generated at 2022-06-20 13:40:24.023322
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    1. Filter out non existing or invalid search_paths for collections
    """
    search_paths = ['/tmp/non/existing/path']
    result = list(list_valid_collection_paths(search_paths, True))
    assert result == []

    search_paths = ['/etc/ansible/collections']
    result = list(list_valid_collection_paths(search_paths, True))
    assert result == []

    search_paths = ['/etc/ansible']
    result = list(list_valid_collection_paths(search_paths, True))
    assert result == ['/etc/ansible']

    search_paths = None
    result = list(list_valid_collection_paths(search_paths, True))

# Generated at 2022-06-20 13:40:48.195727
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) == 0
    assert len(list(list_valid_collection_paths(['/not/a/path']))) == 0
    assert len(list(list_valid_collection_paths(['/not/a/path'], warn=True))) == 1
    assert len(list(list_valid_collection_paths(['/etc/ansible']))) == 0
    assert len(list(list_valid_collection_paths(['/etc/ansible'], warn=True))) == 1

# Generated at 2022-06-20 13:40:59.538061
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    colls = list(list_collection_dirs(['/path/to/invalid/dir']))
    assert isinstance(colls, list)
    assert len(colls) == 0

    colls = list(list_collection_dirs(['library']))
    assert isinstance(colls, list)
    assert len(colls) == 8
    assert sorted(colls)[0] == b'/usr/share/ansible/collections/ansible_collections/community/crypto/library/aes_cbc'

    colls = list(list_collection_dirs(['/usr/share/ansible/collections']))
    assert isinstance(colls, list)
    assert len(colls) == 8

# Generated at 2022-06-20 13:41:02.172117
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # should warn if search path is invalid
    test_search_paths = ['bad_path_one', 'bad_path_two']
    paths = list(list_valid_collection_paths(search_paths=test_search_paths, warn=True))
    assert len(paths) == 0



# Generated at 2022-06-20 13:41:12.347745
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # No path configured
    expected = []
    actual = list(list_valid_collection_paths([]))
    assert actual == expected

    # Paths configured
    path = '/path/to/collection'
    expected = [path]
    actual = list(list_valid_collection_paths([path]))
    assert actual == expected

    # Bad path configured
    path = '/path/to/non/existant'
    expected = []
    actual = list(list_valid_collection_paths([path]))
    assert actual == expected



# Generated at 2022-06-20 13:41:15.812166
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = {'Foo-1.0.0': True, 'Foo-1.1.0': True}
    actual = {}

    for b_coll_dir in list_collection_dirs(coll_filter='Foo'):
        actual[os.path.basename(b_coll_dir)] = True

    assert actual == expected

# Generated at 2022-06-20 13:41:19.829330
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    search_paths = AnsibleCollectionConfig.collection_paths
    assert len(list_valid_collection_paths(search_paths=search_paths)) > 0

    paths = [
        '/nonexistent/path',
        '/etc',
        '/usr/lib/python2.7/site-packages',
    ]

    assert len(list_valid_collection_paths(search_paths=paths)) == 0



# Generated at 2022-06-20 13:41:21.799904
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()
    # Test return type is list
    assert isinstance(list(list_collection_dirs()), list)

# Generated at 2022-06-20 13:41:29.567335
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path1 = u'tests/blah/collections'
    path2 = u'tests/data/ansible_collections'
    list_val = list(list_valid_collection_paths([path1, path2]))
    assert len(list_val) == 1
    assert path2 in list_val

# Generated at 2022-06-20 13:41:31.622048
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/not/a/path", "/tmp"])) == ['/tmp']



# Generated at 2022-06-20 13:41:37.170103
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={},
                                supports_check_mode=True)

    search_paths = [u"/usr/share/ansible/collections", "/this/path/does/not/exist"]
    test_module.exit_json(valid_paths=list_valid_collection_paths(search_paths))



# Generated at 2022-06-20 13:42:19.770073
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list_collection_dirs(coll_filter='ansible_namespace.collection_name')
    assert(dirs is not None)
    assert(len(dirs) == 1)

    dirs = list_collection_dirs(coll_filter='ansible_namespace.collection_name', search_paths=['./'])
    assert(dirs is not None)
    assert(len(dirs) == 1)

# Generated at 2022-06-20 13:42:26.039885
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Return paths for the specific collections found in passed or configured search paths
    :param search_paths: list of text-string paths, if none load default config
    :param coll_filter: limit collections to just the specific namespace or collection, if None all are returned
    :return: list of collection directory paths
    """

    test_cases = [
        {
            "name": "test_base",
            "search_paths": [],
            "coll_filter": None,
            "expect_list_collection_dirs": [],
        },
        {
            "name": "test_no_collection",
            "search_paths": [],
            "coll_filter": "collection.name",
            "expect_list_collection_dirs": [],
        },
    ]


# Generated at 2022-06-20 13:42:36.581780
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    current_dir = os.getcwd()

    with os.tmpdir() as tmpdir:
        tmpdir = os.path.join(tmpdir, 'ansible_collections')
        os.mkdir(tmpdir)
        os.chdir(tmpdir)
        os.mkdir('namespace1')
        os.mkdir('namespace1.collection1')
        os.mkdir('namespace2')
        os.mkdir('namespace2.collection1')
        os.mkdir('namespace2.collection2')
        os.mkdir('namespace2.collection3')

        dirs = list_collection_dirs([tmpdir])

        assert len(dirs) == 3, "list_collection_dirs should return all of the collections, it returned %d" % len(dirs)
        assert os.path

# Generated at 2022-06-20 13:42:43.068343
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the list_valid_collection_paths function
    :return:
    """

    tst1 = ['/tmp', '/junk']
    assert list_valid_collection_paths(tst1, True) == []

    tst2 = ['~/.ansible/collections', '~/mycollections', os.getcwd()]
    assert list(list_valid_collection_paths(tst2, True)) == [os.getcwd()]



# Generated at 2022-06-20 13:42:52.602659
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ["/an/invalid/path", "/an/invalid/path2"]
    coll_dirs = list(list_collection_dirs(search_paths))
    assert len(coll_dirs) == 0

    search_paths = ["/an/invalid/path", AnsibleCollectionConfig.collection_paths[0]]
    coll_dirs = list(list_collection_dirs(search_paths))
    assert len(coll_dirs) == 12

    coll_dirs = list(list_collection_dirs(coll_filter="ansible.builtin"))
    assert len(coll_dirs) == 1
    assert os.path.isdir(coll_dirs[0])


# Generated at 2022-06-20 13:42:53.559765
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-20 13:43:08.560013
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile
    import ansible.module_utils.collection_loader as collection_loader

    b_coll_root = collection_loader.get_collections_loader_path()

    # create a new namespace at the top level of the collection root
    temp_namespace = os.path.join(b_coll_root, 'unit_test123')
    os.mkdir(temp_namespace)

    # create a collection within the new namespace
    temp_collection = os.path.join(temp_namespace, 'unit_test')
    os.mkdir(temp_collection)

    # create a plugin inside the new collection
    temp_plugin = os.path.join(temp_collection, 'plugins')
    os.mkdir(temp_plugin)
    temp_plugin_path = os.path.join