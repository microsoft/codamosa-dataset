

# Generated at 2022-06-20 13:33:22.881242
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    coll_path = list(list_valid_collection_paths(search_paths=['/tmp']))[0]

    assert coll_path == '/tmp'


# Generated at 2022-06-20 13:33:29.552945
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # pylint: disable=import-error
    import pytest

    # test valid and invalid paths
    search_paths = [
        './ansible/',
        '~/ansible/',
        '~/ansible',
        '/invalid/path',
        'invalid/path',
    ]

    # run the validation
    val_paths = list_valid_collection_paths(search_paths, warn=False)

    # ensure all valid paths are returned.
    for path in ['./ansible/', '~/ansible/', '~/ansible']:
        assert path in val_paths

    # ensure all invalid paths are not returned.
    for path in ['/invalid/path', 'invalid/path']:
        assert path not in val_paths

# Generated at 2022-06-20 13:33:34.039321
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list_valid_collection_paths(None) is None


# Generated at 2022-06-20 13:33:40.086931
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import _find_collection_paths

    # TODO: extend to cover full test suite behavior
    exp_coll_dirs = [
        'my_namespace.my_collection/',
        'test_collections/',
        ]

    for col_dir in list_collection_dirs(_find_collection_paths()):
        assert col_dir in exp_coll_dirs

# Generated at 2022-06-20 13:33:51.157434
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(["/my/collection/path"]) == ["/my/collection/path"]
    assert list_valid_collection_paths(["/my/collection/path", "/my/other/collection/path"]) == ["/my/collection/path", "/my/other/collection/path"]
    assert list_valid_collection_paths(["/my/collection/path", "/my/other/collection/path", "/my/non/existent/collection/path"]) == ["/my/collection/path", "/my/other/collection/path"]

# Generated at 2022-06-20 13:34:02.055805
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # list_valid_collection_paths performs path expansion, so use os.curdir
    # to avoid spurious test failures due to missing files in expanded paths.

    # empty search paths, should return empty
    paths = list(list_valid_collection_paths([]))
    assert paths == []

    # None path, should return empty
    paths = list(list_valid_collection_paths([None]))
    assert paths == []

    # empty string, should return empty
    paths = list(list_valid_collection_paths(['']))
    assert paths == []

    # path with empty directory, should return without warnings
    paths = list(list_valid_collection_paths([os.curdir]))
    assert paths == []

    # path with non-directory entry, should return without warnings

# Generated at 2022-06-20 13:34:12.295224
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = ['/tmp/ns1.coll1', '/tmp/ns1.coll2', '/tmp/ns1.coll3', '/tmp/ns2.coll1', '/tmp/ns2.coll2', '/tmp/ns2.coll3']
    for path in paths:
        os.makedirs(path)

    colls = list_collection_dirs(search_paths=['/tmp'], coll_filter=None)
    assert len(list(colls)) == 6

    colls = list_collection_dirs(search_paths=['/tmp'], coll_filter='ns1.coll1')
    assert len(list(colls)) == 1
    assert list(colls)[0] == '/tmp/ns1.coll1'


# Generated at 2022-06-20 13:34:21.176356
# Unit test for function list_collection_dirs

# Generated at 2022-06-20 13:34:26.951472
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    in_list = [
        '/home/testuser/collections',
        '/home/testuser/ansible/collections',
        '/home/testuser/devel/collections',
    ]

    out_list = [
        '/home/testuser/collections/ansible_collections',
        '/home/testuser/ansible/collections/ansible_collections',
        '/home/testuser/devel/collections/ansible_collections',
    ]

    assert out_list == list(list_collection_dirs(in_list))

# Generated at 2022-06-20 13:34:38.978506
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.plugins.loader import collection_loader, module_loader
    from ansible.plugins.module_utils import basic

    loader_prefix = basic.__name__ + '.'
    count = 0

    for dir in list_collection_dirs():

        display.display("DIR = %s" % dir)
        for collection in collection_loader.all(dir):
            display.display("    COLLECTION = %s" % collection)
            for plugin in module_loader.all(collection.collection_name):
                display.display("        PLUGIN = %s" % plugin.name)
                count += 1

    display.display("Count = %d" % count)

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-20 13:34:47.696498
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-20 13:34:56.705748
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = list(list_valid_collection_paths(search_paths=['/foo/bar/baz', '/etc']))
    assert test_paths == ['/etc']

    test_paths = list(list_valid_collection_paths(search_paths=['/foo/bar/baz', '/etc'], warn=True))
    assert test_paths == ['/etc']

    default_paths = list(list_valid_collection_paths(search_paths=None))
    assert '/etc' in default_paths

# Generated at 2022-06-20 13:35:00.325776
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import ansible.constants as C

    collection_dirs = list(list_collection_dirs(C.DEFAULT_COLLECTIONS_PATHS, 'acme.foobar'))

    assert len(collection_dirs) >= 1

# Generated at 2022-06-20 13:35:05.561738
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        'test/integration/targets/collections/ansible_collections',
        'test/integration/targets/collections/custom_collections'
    ]
    collection_paths = list(list_collection_dirs(search_paths=search_paths, coll_filter='acme.mycollection'))
    assert len(collection_paths) == 1
    assert collection_paths[0].endswith('/test/integration/targets/collections/ansible_collections/acme/mycollection')

# Generated at 2022-06-20 13:35:14.186937
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test that list_collection_dirs works with default search_paths
    list_collection_dirs()

    # Test that list_collection_dirs works with provided search_paths
    search_paths = [
        'tests/unit/data/valid_collections_1/ansible_collections',
        'tests/unit/data/valid_collections_2/ansible_collections'
    ]
    list_collection_dirs(search_paths)
    list_collection_dirs(search_paths, coll_filter='test.test')

    # Test that list_collection_dirs works with provided search_paths

# Generated at 2022-06-20 13:35:18.488198
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Ensures that list_collection_dirs pulls every collection
    and that it doesn't pull duplicates
    """

    files = list_collection_dirs()
    seen = []
    for collection_path in files:
        if collection_path.split(os.sep)[-1] in seen:
            assert False
        seen.append(collection_path.split(os.sep)[-1])

# Generated at 2022-06-20 13:35:27.550953
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections.collection_loader import _build_collection_name

    # Create a tempdir for this collection that we can delete
    # at the end of the test
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # Create a collection in this tempdir
    ns = "bobby"
    coll = "tables"

    coll_dir = os.path.join(tmpdir, "ansible_collections", ns, coll)
    os.makedirs(coll_dir)

    # Add this tmpdir to the search paths
    coll_paths = list_valid_collection_paths(search_paths=["does_not_exist", tmpdir])

    # assert that the correct collection path was returned
    expected_coll_path = os.path.join(tmpdir, "ansible_collections")

# Generated at 2022-06-20 13:35:36.589070
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # tests with no search paths, should give the default
    assert list(list_valid_collection_paths([])) == list(AnsibleCollectionConfig.collection_paths)

    # Test with list of paths
    assert list(list_valid_collection_paths(
        ['/a/b/c', '/dev/null', '/foo/bar', '/etc/ansible/collections', '/tmp/foo'])) == ['/dev/null', '/tmp/foo']

    # Test with list of paths, including default

# Generated at 2022-06-20 13:35:46.542962
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.jctanner.my_collection.plugins.module_utils import test_jctanner_my_collection_unit_test
    assert '/home/myuser/collections' in list(test_jctanner_my_collection_unit_test.list_valid_collection_paths())
    assert '/home/myuser/collections' not in list(test_jctanner_my_collection_unit_test.list_valid_collection_paths(warn=False))
    assert '/home/myuser/collections' in list(test_jctanner_my_collection_unit_test.list_valid_collection_paths(warn=True))

# Generated at 2022-06-20 13:35:55.112736
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree

    # Create temp folder
    temp_root = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_root, 'ansible_collections'))

    # Create collection dir
    b_test_coll_path = to_bytes(temp_root)

    os.mkdir(os.path.join(b_test_coll_path, b'ansible_collections', b'mycollection'))

    # Test that list_collection_dirs return temp dir
    collection_dirs = list_collection_dirs([temp_root])
    assert next(collection_dirs) == os.path.join(temp_root, 'ansible_collections/mycollection')

    # Test that list_collection_dirs return no collection when the collection dir is invalid

# Generated at 2022-06-20 13:36:09.879368
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.facts.collections import file_finders

    coll_path = list(list_collection_dirs(coll_filter='ansible_collections.ansible.os_ironic'))
    # One of the test fixtures is ansible_collections.ansible.os_ironic
    assert len(coll_path) == 1
    assert coll_path[0].endswith('ansible_collections/ansible/os_ironic')

    coll_path = list(list_collection_dirs())

    # Our test fixtures have 11 collections
    assert len(coll_path) == 11

    coll_path = list(list_collection_dirs(search_paths=['/tmp/nope']))
    # No collection found
    assert len(coll_path) == 0

# Generated at 2022-06-20 13:36:16.759965
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['../mygalaxy/', '/tmp/mygalaxy/', '/tmp/mygalaxy2', '/tmp/mygalaxy3/']
    for path in list_valid_collection_paths(search_paths, warn=False):
        print(path)


# Generated at 2022-06-20 13:36:19.925427
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/invalid/path', '/usr']
    assert list(list_valid_collection_paths(search_paths)) == ['/usr']



# Generated at 2022-06-20 13:36:29.389599
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    cur_dir = os.getcwd()
    temp_namespace = 'namespace1'
    temp_collection = 'collection1'
    temp_subdirectory = 'subdirectory1'
    temp_subsubdirectory = 'subsubdirectory1'
    temp_subsubsubdirectory = 'subsubsubdirectory1'
    temp_subsubsubsubdirectory = 'subsubsubsubdirectory1'
    temp_subsubsubsubsubdirectory = 'subsubsubsubsubdirectory1'
    temp_subsubsubsubsubsubdirectory = 'subsubsubsubsubsubdirectory1'
    temp_subsubsubsubsubsubsubdirectory = 'subsubsubsubsubsubsubdirectory1'

    temp_directory = tempfile.mkdtemp()
    os.chdir(temp_directory)

    test_path = os

# Generated at 2022-06-20 13:36:40.938742
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Should display the list of collections
    """
    import os
    import tempfile
    import shutil
    import pytest

    search_path = os.getcwd()
    p1n1c1p = os.path.join(os.path.dirname(__file__), "data", "ansible_collections", "p1", "n1", "c1")
    p1n1c2p = os.path.join(os.path.dirname(__file__), "data", "ansible_collections", "p1", "n1", "c2")
    p1n2c1p = os.path.join(os.path.dirname(__file__), "data", "ansible_collections", "p1", "n2", "c1")

# Generated at 2022-06-20 13:36:51.743869
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_paths = [
        os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader'),
        os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader', 'disabled')
    ]

    collection_dirs = list(list_collection_dirs(search_paths=collection_paths))
    assert len(collection_dirs) == 4

    collection_dirs = list(list_collection_dirs(search_paths=collection_paths, coll_filter='ansible.test3'))
    assert len(collection_dirs) == 1

    collection_dirs = list(list_collection_dirs(search_paths=collection_paths, coll_filter='ansible.test3.disabled'))
    assert len

# Generated at 2022-06-20 13:37:03.233438
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list_collection_dirs(None, None)
    assert len(coll_dirs) == 1
    assert os.path.basename(os.path.abspath(coll_dirs[0])) == 'ansible_collections'

    coll_dirs = list_collection_dirs([], None)
    assert len(coll_dirs) == 1
    assert os.path.basename(os.path.abspath(coll_dirs[0])) == 'ansible_collections'

    tmp_coll_dir = '/tmp/ansible_collections'
    if os.path.exists(tmp_coll_dir):
        assert False, 'Test setup error, temporary collection path already exists'


# Generated at 2022-06-20 13:37:13.229167
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import TemporaryDirectory
    from shutil import move
    from os import path
    import pytest

    test_namespace = 'test_namespace'
    test_collection = 'test_collection'
    test_sub_collection = 'test_sub_collection'
    test_role = 'test_role'
    test_plugin_type = 'test_plugin_type'
    test_plugin_name = 'test_plugin_name'


# Generated at 2022-06-20 13:37:18.805196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        './test/units/lib/ansible_collections/ansible_collections',
        './test/units/lib/ansible_collections/not_found',
        './test/units/lib/ansible_collections',
    ]

    ansible_collections = list(list_valid_collection_paths(search_paths=search_paths, warn=False))

    assert len(ansible_collections) == 2
    assert ansible_collections[0] == './test/units/lib/ansible_collections/ansible_collections'
    assert ansible_collections[1] == './test/units/lib/ansible_collections'

# Generated at 2022-06-20 13:37:26.794837
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    for path in ['/foo', 'bar', '/baz/']:
        assert list(list_valid_collection_paths([path])) == []
        assert list(list_valid_collection_paths([path], warn=True)) == []

    os.mkdir('/tmp/foo')

    assert list(list_valid_collection_paths(['/tmp/foo', 'bar'])) == ['/tmp/foo']

    os.rmdir('/tmp/foo')

# Generated at 2022-06-20 13:37:47.083094
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import copy

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 13:37:55.879372
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil

    import tempfile
    import unittest

    class TestCollection(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.coll_dir = os.path.join(self.tmpdir, 'ansible_collections')
            os.makedirs(self.coll_dir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_list_collection_dirs_basic_mixed(self):
            """ list_collection_dirs() when given empty list should return all paths """
            ns_dir = os.path.join(self.coll_dir, 'doesntmatter')
            os.makedirs(ns_dir)

# Generated at 2022-06-20 13:38:06.658128
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import is_collection_path
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    search_paths = [os.path.abspath(os.path.join('.', 'test', 'ansible_collections'))]

# Generated at 2022-06-20 13:38:19.994036
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_inputs = [
        ['a'],
        ['b'],
        ['a', 'b'],
        ['a', 'b', 'c', 'd'],
        ['a', 'b', 'c', 'd'],
        ['a', 'b', 'c', 'd', 'e'],
    ]
    expected = {
        'a': ['a'],
        'b': ['a', 'b', 'c', 'd'],
        'c': ['a', 'b', 'c', 'd', 'e'],
        'd': ['a', 'b', 'c', 'd', 'e']
    }
    for key in expected:
        assert expected[key] == list(list_valid_collection_paths(search_paths=test_inputs[key]))

# Generated at 2022-06-20 13:38:26.106575
# Unit test for function list_collection_dirs

# Generated at 2022-06-20 13:38:31.695206
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = list(list_collection_dirs())
    assert path[0] == './collection_root/ansible_collections/community/napalm/'
    assert path[1] == './collection_root/ansible_collections/community/general/'



# Generated at 2022-06-20 13:38:34.370477
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(['/not/real', './anything', '/bin']))) == 1


# Generated at 2022-06-20 13:38:40.331088
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    search_paths.append("/tmp")
    search_paths.append("/tmp/does_not_exist")
    search_paths.append("/etc")
    search_paths.append("/etc/fstab")
    for path in list_valid_collection_paths(search_paths, warn=True):
        pass

if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-20 13:38:54.884683
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # make sure that both collection_dirs and list_collection_dirs return same list of paths
    from ansible.utils.collection_loader import collection_dirs
    search_paths = ['test/units/utils/collection_loader/collection_dir_fixture']
    test_paths = list(list_collection_dirs(search_paths))
    assert test_paths == [os.path.join(path, 'ansible_collections/ns1/coll1') for path in search_paths]
    assert test_paths == list(collection_dirs(search_paths))
    # make sure that both collection_dirs and list_collection_dirs return correct path for a particular collection
    coll_filter = 'ns1.coll1'

# Generated at 2022-06-20 13:38:58.236412
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.dirname(__file__)
    assert list_collection_dirs([path]) == ['ansible_collections/test/test_collection.test_collection']

# Generated at 2022-06-20 13:39:21.039484
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible.collections.collection_loader import ansible_collections_path

    tmpdir = tempfile.mkdtemp()

    good_paths = [
        tmpdir,
    ]

    bad_paths = [
        '',
        None,
        '/this/path/should/not/exist',
    ]

    # Good Paths
    for path in good_paths:
        for d in list_collection_dirs([path]):
            assert os.path.exists(d)
            assert os.path.isdir(d)
            display.vvvv("Found collection dir: %s" % d)

    # Bad Paths
    for path in bad_paths:
        assert not list_collection_dirs([path])

# Generated at 2022-06-20 13:39:32.332510
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.module_utils._text import to_native

    # Test with no collection, just get the available namespace
    display = Display()


# Generated at 2022-06-20 13:39:46.229470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    coll_path = os.path.join(os.path.dirname(__file__), '../../', 'lib/ansible/collections')

    # Test string type input
    colls = list(list_valid_collection_paths(search_paths=coll_path))

    # Test list type input
    colls = list(list_valid_collection_paths(search_paths=[coll_path]))

    # Test no input
    colls = list(list_valid_collection_paths(search_paths=None))
    assert len(colls) > 0

    # Test input with path that doesn't exist
    search_paths = [coll_path, '/does/not/exist']
    colls = list(list_valid_collection_paths(search_paths=search_paths))
    assert len

# Generated at 2022-06-20 13:39:49.724861
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.path import unfrackpath
    from ansible.constants import COLLECTIONS_PATHS

    collection_paths = list(COLLECTIONS_PATHS)
    collection_paths.extend([
        unfrackpath('/tmp/foo'),
        unfrackpath('/tmp/bar')
    ])

    assert list(list_collection_dirs(collection_paths))

# Generated at 2022-06-20 13:40:03.212735
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['./', '/tmp/test_path', '/etc/ansible/test_path', '/etc/ansible/test_path/test_collection', '/tmp/test_path_does_not_exist', '/tmp/test_path_is_not_dir']

    new_paths = list_valid_collection_paths(search_paths)
    assert len(new_paths) == 5
    assert '/tmp/test_path' in new_paths
    assert '/etc/ansible/test_path' in new_paths
    assert '/etc/ansible/test_path/test_collection' in new_paths
    assert '/tmp/test_path_does_not_exist' not in new_paths
    assert '/tmp/test_path_is_not_dir' not in new_paths

# Generated at 2022-06-20 13:40:09.939578
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import list_collection_dirs, list_valid_collection_paths
    from pprint import pprint

    # filter path that are not directories
    filter_path = ['/test/test/test', '/etc', '/test/test/test2']
    pprint(list(list_valid_collection_paths(filter_path, warn=True)))

    assert list(list_valid_collection_paths(filter_path, warn=True)) == []

    # filter path that are directories
    filter_path = ['/etc', '/bin']
    pprint(list(list_valid_collection_paths(filter_path)))

    assert list(list_valid_collection_paths(filter_path)) == ['/etc', '/bin']

    filter_path = []

# Generated at 2022-06-20 13:40:24.022530
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import os
    import pytest

    search_paths = ['foo', 'bar']
    AnsibleCollectionConfig.set_collection_paths(search_paths)

    listing = list_valid_collection_paths()
    assert set(listing) == set(search_paths)
    assert set(list(AnsibleCollectionConfig.collection_paths)) == set(search_paths)

    # check that when first one doesn't exist, we get a warning
    with pytest.warns(UserWarning):
        listing = list_valid_collection_paths(warn=True)

    search_paths.append(os.getcwd())
    listing = list_valid_collection_paths()

# Generated at 2022-06-20 13:40:28.216478
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ansible_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'lib')
    assert list_collection_dirs([os.path.join(ansible_path, 'ansible_collections_invalid_path')]) == []



# Generated at 2022-06-20 13:40:36.082101
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil

    coll_path = None
    try:
        coll_path = tempfile.mkdtemp()
        ns_path = tempfile.mkdtemp(dir=coll_path)
        coll1_path = tempfile.mkdtemp(dir=ns_path)
    except Exception:
        pass
    finally:
        if coll_path:
            shutil.rmtree(coll_path)
        coll_path = None

    for path in list_valid_collection_paths(search_paths=[os.path.dirname(ns_path)]):
        collections = list(list_collection_dirs(search_paths=[os.path.dirname(ns_path)]))
        assert ns_path in collections

# Generated at 2022-06-20 13:40:44.397105
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    tmp_root = None
    tmp_collections_dir = None

# Generated at 2022-06-20 13:41:14.634109
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    display.verbosity = 1  # Remove verbosity when unit-testing module functions

    from collections import namedtuple
    from tempfile import mkdtemp

    DummyCollectionPath = namedtuple('DummyCollectionPath', ['search_path', 'valid', 'exists'])
    dummy_coll_paths = [
        DummyCollectionPath('/never/going/to/exist', False, False),
        DummyCollectionPath(mkdtemp(), True, True),
        DummyCollectionPath(__file__, False, True),
    ]

    for dummy_coll_path in dummy_coll_paths:
        dummy_coll_path_list = [dummy_coll_path.search_path]

        valid_paths = list(list_valid_collection_paths(dummy_coll_path_list, warn=True))

# Generated at 2022-06-20 13:41:18.622758
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    unit test for list_collection_dirs
    """

    coll_path = ['test/units/module_utils/testdata/collections_test/']
    coll_path_results = list(list_collection_dirs(coll_path))
    assert len(coll_path_results) > 0
    assert coll_path_results == ['test/units/module_utils/testdata/collections_test/ansible_collections/test_namespace/test_coll/']

# Generated at 2022-06-20 13:41:26.426591
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    test_search_paths = [
        "/this/does/not/exist",
        "/etc/file/does/not/exist",
        os.path.join(mkdtemp(), 'ansible_collections'),
        "ansible.builtin",
        os.path.join(mkdtemp(), 'ansible_modules'),
        "ansible.builtin",
        os.path.join(mkdtemp(), 'ansible_modules'),
        "ansible.builtin",
        "/usr/share/ansible/collections",
        "/usr/share/ansible/collections",
    ]

    test_search_paths_uniq = set(test_search_paths)
    result = list_valid_collection_paths

# Generated at 2022-06-20 13:41:31.795613
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = ['/tmp/doesnotexist', '../../../doesnotexist', '/etc', '/usr', '../../../etc']
    coll_paths.extend(AnsibleCollectionConfig.collection_paths)
    coll_dirs = list(list_valid_collection_paths(search_paths=coll_paths))
    assert coll_dirs == ['/etc', '/usr']

# Generated at 2022-06-20 13:41:40.026250
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from ansible.utils.collection_loader import list_collection_dirs

    dirs = list_collection_dirs()
    assert len(dirs) > 0

    dirs = list_collection_dirs(coll_filter='community')
    assert 'ansible_collections' in dirs[0]
    assert 'community' in dirs[0]
    assert len(dirs) == 1

    dirs = list_collection_dirs(coll_filter='community.foo')
    assert len(dirs) == 0

    # Test warning when non existing collection path is found
    with pytest.warns(UserWarning):
        list_collection_dirs(['/bad/collection/path'])
    # Test warning when collection path is a file not a directory

# Generated at 2022-06-20 13:41:48.155261
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test search_paths init
    p = list_valid_collection_paths()
    assert list(p)

    # test search_paths argument
    p = list_valid_collection_paths(['/tmp/junk_path', '/nonexistent/path'], warn=True)
    assert list(p) == []

# Generated at 2022-06-20 13:41:55.599671
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    # Mock the search paths
    tmp_dir = os.path.dirname(os.path.realpath(__file__))
    search_paths = [os.path.join(tmp_dir, 'test_data', 'ansible_collections_1')]
    # Mock the collection filter
    coll_filter = 'mynamespace.mycollection'

    # Create test directories
    for search_path in search_paths:
        os.makedirs(search_path)

    # Test function with a valid search path and valid collection filter
    for coll in list_collection_dirs(search_paths, coll_filter):
        assert coll.endswith(coll_filter)

    # Test function with a valid search path and invalid collection filter
    coll_filter = 'mynamespace.invalid'

# Generated at 2022-06-20 13:42:06.199261
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    src_path = os.path.dirname(os.path.realpath(__file__))
    tests_path = os.path.normpath(os.path.join(src_path, '../../../test/units/module_utils/collection_loader'))
    collection_config = {'collections_paths': [
        os.path.normpath(os.path.join(tests_path, 'collection_loader_data/non_existing')),
        os.path.normpath(os.path.join(tests_path, 'collection_loader_data/file'))
    ]}


# Generated at 2022-06-20 13:42:18.626463
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # No search paths
    results = [x for x in list_valid_collection_paths()]
    assert len(results) > 1

    # Known valid path
    pwd = os.getcwd()
    coll_path = os.path.join(pwd, 'lib/ansible/collections')
    results = [x for x in list_valid_collection_paths([coll_path])]

    assert len(results) == 1
    assert results[0] == coll_path

    # Known invalid path
    coll_path = os.path.join(pwd, 'invalid_directory')
    results = [x for x in list_valid_collection_paths([coll_path])]
    assert len(results) == 0

    # Known valid path and known invalid path

# Generated at 2022-06-20 13:42:25.485865
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ["/bad/path/does/not/exist", "/dev/null"]
    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(paths) == 0

    search_paths = ["../../docs/man/man1", "../../docs/man/man2"]
    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(paths) == 0

    search_paths = ["../../docs/man/man1", "../../docs/man/man2"]
    paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(paths) == 2

    search_paths = ["/dev/null"]

# Generated at 2022-06-20 13:43:09.780542
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from tempfile import mkdtemp, mktemp

    paths = []
    paths.append(mkdtemp(prefix='z-ansible-collections-1'))
    paths.append(mkdtemp(prefix='z-ansible-collections-2'))

    coll_root = os.path.join(paths[0], 'ansible_collections')
    os.makedirs(coll_root)

    coll_namespace = 'myns'
    colls = ['mydecl', 'mycoll1']
    collection_dirs = []
    for collection in colls:
        collection_path = os.path.join(coll_root, coll_namespace, collection)
        collection_dirs.append(collection_path)
        os.makedirs(collection_path)

# Generated at 2022-06-20 13:43:19.490375
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_dirs = list(list_collection_dirs(search_paths=['test/units/utils/ansible_collections']))

    assert len(test_dirs) == 2

    assert os.path.exists(os.path.join(test_dirs[0], 'ansible_collections'))
    assert os.path.exists(os.path.join(test_dirs[1], 'ansible_collections'))