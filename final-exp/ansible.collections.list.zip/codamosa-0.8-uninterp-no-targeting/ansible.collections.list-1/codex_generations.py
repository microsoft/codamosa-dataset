

# Generated at 2022-06-20 13:33:24.467905
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with no search_paths
    paths = list(list_valid_collection_paths())
    assert len(paths) == len(AnsibleCollectionConfig.collection_paths)

    # test with invalid search_paths
    path_list = ['/bad/path/', '/another/bad/path']
    paths = list(list_valid_collection_paths(search_paths=path_list))
    assert paths == []

    # test with valid search_paths but no 'ansible_collections' dir
    path_list = [os.path.join(os.path.dirname(__file__), 'support/valid_search_path')]
    paths = list(list_valid_collection_paths(search_paths=path_list))
    assert paths == []

    # test with valid search_path

# Generated at 2022-06-20 13:33:37.610583
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Make sure that the paths that are passed are valid
    """

    # Create and test a folder
    test_dir = "test/test_dir"
    os.makedirs(test_dir)

    # Use the created folder as the path
    search_path = [test_dir]
    search_paths = list(list_valid_collection_paths(search_paths=search_path, warn=True))
    assert test_dir in search_paths

    # Test a non-existent folder
    search_path = ["test/test_dir_1"]
    search_paths = list(list_valid_collection_paths(search_paths=search_path, warn=True))
    assert search_paths == []

    # Remove the created test folder for further testing

# Generated at 2022-06-20 13:33:40.722205
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Tests for function list_collection_dirs

    :return: returns True/False
    '''

    pass

# Generated at 2022-06-20 13:33:48.457443
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['/foo/bar', '/ansible/collections_path/']
    coll_filter = None

    assert os.path.join(to_bytes('/foo/bar'), to_bytes('ansible_collections')) in list_collection_dirs(search_paths, coll_filter)
    assert os.path.join(to_bytes('/ansible/collections_path/'), to_bytes('ansible_collections')) in list_collection_dirs(search_paths, coll_filter)

    coll_filter = 'not_exists_collection'
    assert os.path.join(to_bytes('/foo/bar'), to_bytes('ansible_collections')) not in list_collection_dirs(search_paths, coll_filter)

# Generated at 2022-06-20 13:33:59.976495
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.path import get_dist_subdir
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    # Test with empty search_paths list (should error)
    search_paths = []
    try:
        list(list_valid_collection_paths(search_paths, False))
        # if we made it here, we had an error
        assert False
    except AnsibleError:
        # if we made it here, we want to succeed
        assert True
    # Test with non-existing paths and empty search_paths list
    search_paths = [os.path.join(tmp_dir, 'does_not_exist')]

# Generated at 2022-06-20 13:34:09.274029
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.collection_loader import list_collection_dirs
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_text

    # get a collection and test the output
    response = fetch_url(module=None, url="https://galaxy.ansible.com/api/v1/collections/ansible/os_server")
    response_json = respo

# Generated at 2022-06-20 13:34:19.140764
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import pytest

    def _copy_tree(src,dest):
        try:
            shutil.copytree(src, dest, symlinks=True)
        except OSError as error:
            if error.errno == 20:
                # File exists, so just pass
                pass
            else:
                raise

    tmpdir = tempfile.mkdtemp()

    # Create an empty file where a collection should be
    with open(os.path.join(tmpdir,'test'), 'w'):
        pass

    # Create a valid collection
    src = os.path.join(os.path.dirname(__file__), 'data', 'test_collections', 'testcoll')
    dest = os.path.join(tmpdir,'testcoll')

# Generated at 2022-06-20 13:34:30.520258
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile

    test_colls = [
        'somespace.somecollection',
        'somespace.somecollection.1.0',
        'somespace.anothercollection',
        'somespace.anothercollection.1.0',
        'somespace.anothercollection.2.0',
        'somespace.anothercollection.3.0',
        'somespace.anothercollection.3.1',
    ]

    tmp = tempfile.mkdtemp(prefix='ansible_test.ansible_collections.')
    tmp_colls = os.path.join(tmp, 'ansible_collections')
    os.mkdir(tmp_colls)
    tmp_somespace = os.path.join(tmp_colls, 'somespace')
    os.mkdir

# Generated at 2022-06-20 13:34:35.748893
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = 'ansible_collections.nti_cloud'
    coll_root = '/tmp/ansible_collection_test'
    coll_path = os.path.join(coll_root,'ansible_collections','nti_cloud','cloud')
    try:
        os.makedirs(coll_path)
        coll_paths = list(list_collection_dirs([coll_root],coll_filter=coll_filter))
        assert(len(coll_paths) == 1)
    finally:
        os.rmdir(coll_path)



# Generated at 2022-06-20 13:34:44.914065
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths
    from ansible.module_utils.common.collections import list_collection_dirs
    from ansible.module_utils.six import PY2
    r = list(list_valid_collection_paths(["/tmp/a/ansible_collections/mynamespace/mycollection/plugins/modules",
                                          "/tmp/b/ansible_collections/mynamespace/mycollection/plugins/modules"]))
    assert len(r) == 2
    assert r[0] == "/tmp/a/ansible_collections/mynamespace/mycollection/plugins/modules"
    if PY2:
        assert r[1] == "/tmp/b/ansible_collections/mynamespace/mycollection/plugins/modules"

# Generated at 2022-06-20 13:34:56.032244
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the functions `list_collection_dirs` on a good and bad path
    """
    coll_dir = list_collection_dirs(['/tmp/doesntexist'])
    assert len(list(coll_dir)) is 0

# Generated at 2022-06-20 13:35:04.959500
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-20 13:35:13.958810
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    config = AnsibleCollectionConfig()
    config.set_search_paths(search_paths=['test/unit/utils/collections', ])
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = 'test/unit/utils/collections'

    # Multiple collections, no filter
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) == 2
    assert b'mynamespace' in collection_dirs[0]
    assert b'mynamespace' in collection_dirs[1]
    assert b'collection1' in collection_dirs[0]
    assert b'collection2' in collection_dirs[1]

    # Multiple collections, namespace filter
    collection_dirs = list(list_collection_dirs(coll_filter='mynamespace'))

# Generated at 2022-06-20 13:35:26.485802
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    display = Display()

    # make sure default is not empty
    assert list_collection_dirs()

    # check if invalid search path found
    search_paths = ['/tmp']
    assert not list_collection_dirs(search_paths=search_paths)

    # check if valid search path found
    search_paths = [os.path.join(os.path.dirname(os.path.dirname(__file__)), 'namespace1', 'collections')]
    assert list_collection_dirs(search_paths=search_paths)

    # check if valid search path found

# Generated at 2022-06-20 13:35:30.957699
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = ['./test', './test/ansible_collections/test/test']
    colls = list(list_collection_dirs(paths))

    assert len(colls) == 1
    assert colls[0] == b'./test/ansible_collections/test/test'


# Generated at 2022-06-20 13:35:35.909355
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_path = ["/tmp/plugins/role_collections",
                   "/etc/ansible/collections",
                   "/usr/share/ansible/collections"]

    valid_search_path = list(list_valid_collection_paths(search_path, warn=False))

    assert len(valid_search_path) == 1
    assert '/tmp/plugins/role_collections' in valid_search_path


# Generated at 2022-06-20 13:35:49.485941
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    coll_dir = tempfile.mkdtemp() + '/'
    ansible_coll_dir = os.path.join(coll_dir, 'ansible_collections')
    namespace_dir = os.path.join(ansible_coll_dir, 'namespace')
    collection_dir = os.path.join(namespace_dir, 'collection')

    # Make some directories
    os.makedirs(collection_dir)

    # Test with no search_paths
    results = [coll_dir for coll_dir in list_collection_dirs()]
    assert len(results) == 1

    # Test with no search_paths and a filter
    results = [coll_dir for coll_dir in list_collection_dirs('namespace.collection')]
    assert len(results) == 1

    # Test

# Generated at 2022-06-20 13:35:56.503680
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    expected_paths = ['/usr/share/ansible/collections/namespace1/collection1',
                      '/usr/share/ansible/collections/namespace1/collection2']

    # Mocked os.listdir function
    def mocked_listdir(path):
        if path == b'/usr/share/ansible/collections':
            return ['namespace1']
        else:
            assert path == b'/usr/share/ansible/collections/namespace1'
            return ['collection1', 'collection2']

    # Mocked os.path.isdir function that returns True for all input paths.
    def mocked_isdir(path):
        assert path in expected_paths
        return True

    mocked_collection_paths = ['/usr/share/ansible/collections']

    # Mocked list_valid_

# Generated at 2022-06-20 13:36:05.543881
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_collections = {'myns1': {'mycollection1': None, 'mycollection2': None}, 'myns2': {'mycollection1': None}}

    for x in list_collection_dirs(search_paths=['/tmp/so', '/tmp/so2'], coll_filter='myns1'):
        y = x.split('/')
        test_collections[y[-3]][y[-2]] = None

    assert test_collections == {'myns1': {'mycollection1': None, 'mycollection2': None}}

# Generated at 2022-06-20 13:36:11.446711
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.collection_loader import list_collection_dirs

    # test on existing collection paths
    for coll in list_collection_dirs(warn=False):
        assert os.path.isdir(coll)

    # test with a specific collection filtered
    for coll in list_collection_dirs(coll_filter='acme.demo_collection'):
        assert os.path.isdir(coll)

    # test on an invalid path
    for coll in list_collection_dirs(search_paths=['/dne'], warn=False):
        assert False, "Should not have iterated on a non-existing collection path"

# Generated at 2022-06-20 13:36:25.777747
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import errno
    import shutil
    import tempfile
    import unittest

    # create a dummy collection and make sure it can be discovered with function

    dummy_collection = """
    {
        "namespace": "mynamespace",
        "name": "mycollection"
    }
    """

    dummy_plugin = """
    #!/usr/bin/python3

    from ansible.module_utils.basic import AnsibleModule

    def main():
        module = AnsibleModule(argument_spec={})

        module.exit_json(msg="Hello from test collection plugin.")

    if __name__ == '__main__':
        main()
    """

    # create temporary working directory for collection
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 13:36:39.719760
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os.path

    import pytest

    test_dir = tempfile.mkdtemp()

    # Create a collection root directory
    root_dir = os.path.join(test_dir, 'foo')
    os.mkdir(root_dir)
    # Create namespace directory
    ns_dir = os.path.join(root_dir, 'testns')
    os.mkdir(ns_dir)

    # Create a collection directory inside the testns namespace
    coll_dir = os.path.join(ns_dir, 'testcoll')
    os.mkdir(coll_dir)

    # Create a plugins directory inside the testcoll collection
    # -- We don't currently support plugins in collections, but might in the future

# Generated at 2022-06-20 13:36:46.308272
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_dir = '/tmp/ansible_collections'
    coll_dir_1 = AnsibleCollectionConfig.format_collection_dir(search_dir, 'collection', 'namespace')
    coll_dir_2 = AnsibleCollectionConfig.format_collection_dir(search_dir, 'collection2', 'namespace2')
    coll_dir_3 = AnsibleCollectionConfig.format_collection_dir(search_dir, 'collection3', 'namespace2')

    # Create collection directories
    os.makedirs(coll_dir_1)
    os.makedirs(coll_dir_2)
    os.makedirs(coll_dir_3)

    result = list_collection_dirs([search_dir])
    expected = [coll_dir_1, coll_dir_2, coll_dir_3]

# Generated at 2022-06-20 13:36:52.792490
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections import is_collection_path
    from ansible.module_utils.parsing.convert_bool import boolean

    # calling without search_paths should yield empty
    assert list(list_valid_collection_paths()) == []

    # calling with non-existent path should not crash
    assert list(list_valid_collection_paths(search_paths=["./not_there"])) == []

    # calling with non-directory path should not crash
    assert list(list_valid_collection_paths(search_paths=["/dev/null"])) == []

    # calling with non-directory path should not crash
    assert list(list_valid_collection_paths(search_paths=[__file__])) == []

    # use a tempdir for a test collection
    from tempfile import mkdtemp

# Generated at 2022-06-20 13:36:57.400427
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    b_test_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    test_collection_dirs = list_collection_dirs([b_test_dir])
    assert len(list(test_collection_dirs)) == 1

# Generated at 2022-06-20 13:37:07.516089
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_search_path = ["/usr/share/ansible/collections",
                       "/usr/share/ansible/collections-test",
                       "/invalid/path",
                       "/usr/share/ansible/3",
                       "/usr/share/ansible/2/ansible_collections",
                       "/usr/share/ansible/2/ansible_collections/test_namespace/test_collection"]

    actual_result = list_valid_collection_paths(test_search_path)

    expected_result = ['/usr/share/ansible/collections',
                       '/usr/share/ansible/collections-test',
                       '/usr/share/ansible/3',
                       '/usr/share/ansible/2/ansible_collections']
    for path in actual_result:
        assert path in expected_

# Generated at 2022-06-20 13:37:13.223855
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    List valid collection paths
    """
    test_paths = ['~/collections', '/usr/share/ansible_collections/', '/etc/ansible/collections']
    result = list(list_valid_collection_paths(test_paths))

    assert len(result) == 1
    assert result[0] == '/etc/ansible/collections'



# Generated at 2022-06-20 13:37:13.963625
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-20 13:37:19.729532
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test for function list_valid_collection_paths"""

    # Test with a list of invalid item
    search_paths = ['/invalid_path_01',
                    '/invalid_path_02',
                    '/invalid_path_03',
                    '/invalid_path_04']

    # Should return an empty set
    assert set(list_valid_collection_paths(search_paths=search_paths, warn=False)) == set()

    # Test with a valid list and warn=False
    search_paths = ['/ansible/ansible_collections',
                    '/invalid_path_01',
                    '/invalid_path_02',
                    '/invalid_path_03',
                    '/invalid_path_04']

    # Should return  a set with 1 item

# Generated at 2022-06-20 13:37:30.649610
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath

    current_dir = unfrackpath(__file__)
    test_path = os.path.abspath(os.path.join(current_dir, '../../../../ansible_collections/test_namespace/test_collection'))
    test_path2 = os.path.abspath(os.path.join(current_dir, '../../../..'))
    test_path3 = os.path.abspath(os.path.join(current_dir, '../../../../ansible_collections'))

    # test that list_collection_dir returns an iterable
    assert isinstance(list_collection_dirs(), type(iter('test')))

    # test that list_collection_dir returns a list of paths to the
    # collection_dirs


# Generated at 2022-06-20 13:37:46.580177
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import random
    import string

    tmpdir = tempfile.mkdtemp()
    b_tmpdir = to_bytes(tmpdir, errors='surrogate_or_strict')

    d1_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    d2_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    d3_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    d4_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))

    d1_path = os.path.join(tmpdir, d1_name)

# Generated at 2022-06-20 13:37:48.576555
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = set(list_collection_dirs(['/test/path']))
    assert set == type(coll_dirs)

# Generated at 2022-06-20 13:38:03.548664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    if not os.path.exists('/tmp/ansible_collections/'):
        os.makedirs('/tmp/ansible_collections/')

    if not os.path.exists('/tmp/ansible_collections/mycollection/mynamespace'):
        os.makedirs('/tmp/ansible_collections/mycollection/mynamespace')

    if not os.path.exists('/tmp/ansible_collections/mynamespace/testcoll'):
        os.makedirs('/tmp/ansible_collections/mynamespace/testcoll')

    coll_paths = list_collection_dirs(search_paths=['/tmp'])
    assert coll_paths is not None

    coll_paths = list(coll_paths)

# Generated at 2022-06-20 13:38:08.680665
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths()
    """

    _search_paths = list()

    # invalid path
    _search_paths.append('/foo/bar')
    # non existing path
    _search_paths.append('/tmp/dir_not_exists')
    # valid path
    _search_paths.append('/tmp')

    # no warning, as neither invalid or non existing path exist
    assert len(list(_ for _ in list_valid_collection_paths(_search_paths, False))) == 1

    # with warning both invalid and non existing path should be skipped
    assert len(list(_ for _ in list_valid_collection_paths(_search_paths, True))) == 0

# Generated at 2022-06-20 13:38:17.002978
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Import to get the abspath of this collection
    import ansible_collections.nsbl.test_collection

    col_path = ansible_collections.nsbl.test_collection.collection_path

    # Test filtering on the collection
    my_coll_path = list(list_collection_dirs(coll_filter=col_path))
    assert len(my_coll_path) == 1
    assert os.path.exists(my_coll_path[0])

    # Test filtering on the namespace
    for ns_coll_path in list_collection_dirs(coll_filter="nsbl"):
        assert os.path.exists(ns_coll_path)

# Generated at 2022-06-20 13:38:21.526880
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys, os

    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) > 0, "No collection directories found in search path"

    for dir in collection_dirs:
        assert os.path.exists(dir), "Collection directory {0} does not exist".format(dir)

# Generated at 2022-06-20 13:38:28.243196
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from importlib import reload
    import os
    import tempfile
    from ansible.module_utils.common.collections import AnsibleCollectionRef

# Generated at 2022-06-20 13:38:39.658272
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_roots = [
        os.path.expanduser('~/ansible_collections'),
        os.path.expanduser('~/.ansible/collections'),
        '/usr/share/ansible/collections'
    ]

    # Test with specific namespace and collection
    # Make sure multiple roots are handled correctly.  Handle the
    # case where a collection exists in multiple roots.
    dirs = list(list_collection_dirs(coll_roots, 'testns.testcoll'))
    assert len(dirs) == 2, "Expected 2 returned dirs.  Got %s" % dirs
    assert dirs[0].endswith('testns/testcoll')
    assert dirs[1].endswith('testns/testcoll')

    # Test with just namespace

# Generated at 2022-06-20 13:38:43.204288
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirlist = list(list_collection_dirs(search_paths=["./tests/units/utils/collections"]))
    assert dirlist == [b'./tests/units/utils/collections/ansible_collections/mycol1/my_collection1']

# Generated at 2022-06-20 13:38:46.760823
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert(list(list_valid_collection_paths(['./test/testdata/collections'])) == ['./test/testdata/collections'])

# Generated at 2022-06-20 13:39:05.257726
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    coll = 'testcol'

    # create a collection in a tempdir
    collection_dir = os.path.join(temp_dir, 'ansible_collections', coll, coll)
    os.makedirs(collection_dir)

    # create a test collection def
    test_ns, test_coll = os.path.basename(collection_dir).split('-')
    collection_def = os.path.join(collection_dir, 'galaxy.yml')
    with open(collection_def, 'w') as gfd:
        gfd.write("---\nnamespace: %s\nname: %s" % (test_ns, test_coll))

    assert os.path.exists(collection_def)

   

# Generated at 2022-06-20 13:39:15.827395
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import inspect
    test_file = inspect.getfile(test_list_collection_dirs)
    test_dir = os.path.dirname(test_file)
    test_collection_dirs = (os.path.join(test_dir, 'ansible_collections', 'test_namespace1', 'test_collection1'),
                            os.path.join(test_dir, 'ansible_collections', 'test_namespace1', 'test_collection2'),
                            os.path.join(test_dir, 'ansible_collections', 'test_namespace2', 'test_collection3'))

    result = list(list_collection_dirs([test_dir]))
    assert set(result) == set(test_collection_dirs)


# Generated at 2022-06-20 13:39:20.051854
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # With default
    assert list(list_valid_collection_paths())

    # With one nonexisting path
    assert not list(list_valid_collection_paths(search_paths=['./nonexisting']))

    # With one existing and one nonexisting path
    assert list(list_valid_collection_paths(search_paths=['./nonexisting', './']))

# Generated at 2022-06-20 13:39:27.296252
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import is_collection_path
    assert '/opt/ansible/collections/ansible_collections' in list_valid_collection_paths()
    assert '/opt/ansible/collections/ansible_collections' in list_valid_collection_paths(['/opt/ansible/collections'])
    assert '/opt/ansible2/collections/ansible_collections' in list_valid_collection_paths(['/opt/ansible/collections', '/opt/ansible2/collections'])

# Generated at 2022-06-20 13:39:32.758339
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list_collection_dirs(coll_filter='azure.azcollection')
    assert next(result).endswith('ansible_collections/azure/azcollection')
    result = list_collection_dirs(coll_filter='azure')
    assert next(result).endswith('ansible_collections/azure/azcollection')

# Generated at 2022-06-20 13:39:46.242382
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test listing of collection directories"""
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    colls = [
        ("ansible.builtin", "subcollection"),
        ("ansible.modules", "subcollection"),
        ("ansible.builtin", "subcollection2"),
        ("ansible.modules", "subcollection2"),
    ]
    for ns, coll in colls:
        namespace_dir = os.path.join(tmpdir, "ansible_collections", ns)
        os.makedirs(namespace_dir)
        coll_dir = os.path.join(namespace_dir, coll)
        os.makedirs(coll_dir)

    # update collection path
    search_paths = [tmpdir]

# Generated at 2022-06-20 13:39:55.869014
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths

    search_paths = [
        '/some/fake/1.0.0',
        '/some/fake/2.0.0',
        '/some/fake/3.0.0/foo',
        '/some/fake/4.0.0/bar',
        '/some/fake/5.0.0/baz',
    ]

    expected_paths = [
        '/some/fake/3.0.0/foo',
        '/some/fake/5.0.0/baz',
    ]

    assert expected_paths == list(list_valid_collection_paths(search_paths, warn=False))

# Generated at 2022-06-20 13:40:06.212347
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import re
    from ansible.module_utils._text import to_text
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import PluginLoader

    basedir = os.path.dirname(__file__)
    collectionsdir = os.path.join(basedir, '..', '..', '..', 'test', 'sanity', 'collection_loader', 'test_collections')
    search_paths = [collectionsdir]
    pl = PluginLoader(
        "action",
        'ansible.plugins.action',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class="ActionBase",
    )
    loader = DataLoader()
    playbook = Playbook()
   

# Generated at 2022-06-20 13:40:16.139881
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Verify we get a list of collections found in search paths

    This is here because we moved this out of a module, and because we need to
    appropriately mock os and os.path for this test (which cannot be done in
    an integration test).
    """

    from ansible.module_utils.facts.collections import list_collection_dirs
    from ansible.module_utils.facts.collections.test.unit.test_utils import (
        modify_module_utils_path,
        restore_module_utils_path,
    )

    from ansible.module_utils.facts.collections.test.support_files import (
        CollectionFinderTestCase,
    )

    test_case = CollectionFinderTestCase('test_list_collection_dirs')
    test_case.create()


# Generated at 2022-06-20 13:40:22.137797
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Unit test for function list_collection_dirs
    assert list_collection_dirs()
    assert list_collection_dirs(search_paths=['/usr/share/ansible/collections', '/usr/share/ansible/collections2'])
    assert list_collection_dirs(coll_filter='my.collection')
    assert list_collection_dirs(coll_filter='my.collection', search_paths=['/usr/share/ansible/collections', '/usr/share/ansible/collections2'])
    assert list_collection_dirs(coll_filter='my')
    assert list_collection_dirs(coll_filter='my', search_paths=['/usr/share/ansible/collections', '/usr/share/ansible/collections2'])

# Generated at 2022-06-20 13:40:42.757583
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        '/usr/share/ansible/',
        '/usr/share/ansible/collections/ansible_collections',
    ]

    try:
        coll_dirs = list(list_collection_dirs(search_paths))
    except:
        assert True == False, 'Unexcepted error occured'

    assert len(coll_dirs) != 0

# Generated at 2022-06-20 13:40:50.489515
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Supply a filter that will not match any collections
    list_1 = list(list_collection_dirs(coll_filter='abc.def'))
    assert len(list_1) == 0

    # Test for a single collection
    list_2 = list(list_collection_dirs(coll_filter='community.vmware'))
    assert len(list_2) == 1
    assert 'community.vmware' in str(list_2[0])

    # Test for a single collection that has multi-level paths
    list_3 = list(list_collection_dirs(coll_filter='community.ansible.windows'))
    assert len(list_3) == 1
    assert 'community.ansible.windows' in str(list_3[0])

    # Test for a single collection that has multi-level paths
    list_4

# Generated at 2022-06-20 13:40:51.586456
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list(list_collection_dirs())

# Generated at 2022-06-20 13:40:58.882737
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.errors import AnsibleError

    assert('/tmp' in list_valid_collection_paths(search_paths=['/tmp']))
    with open('/tmp/foo', 'a') as f:
        f.write('foo')
    assert('/tmp' in list_valid_collection_paths(search_paths=['/tmp']))
    os.unlink('/tmp/foo')
    assert('/tmp' not in list_valid_collection_paths(search_paths=['/tmp']))

# Generated at 2022-06-20 13:41:07.784403
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    temp_dir = tempfile.mkdtemp()

    # non-existant path
    assert list(list_valid_collection_paths([temp_dir])) == []

    # existing dir
    assert list(list_valid_collection_paths([os.path.dirname(temp_dir)])) == [os.path.dirname(temp_dir)]

    # existing file
    assert list(list_valid_collection_paths([temp_dir])) == []

    # bad path
    assert list(list_valid_collection_paths([temp_dir + '\x00'])) == []

    # default
    assert list(list_valid_collection_paths(None)) == list(list_valid_collection_paths([]))

    # clean up
    os.rmdir(temp_dir)



# Generated at 2022-06-20 13:41:16.994172
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # passes
    assert list_valid_collection_paths(search_paths=['/tmp/ansible_collections']) == ['/tmp/ansible_collections']
    assert list_valid_collection_paths(search_paths=['/ansible_collections', '/ansible_collections_2']) == ['/ansible_collections']

    # fails
    assert list_valid_collection_paths(search_paths=['/tmp/ansible_collections/foo']) == []
    assert list_valid_collection_paths(search_paths=['/tmp/ansible_collections', '/tmp/ansible_collections/foo']) == []
    assert list_valid_collection_paths(search_paths=['/tmp/ansible_collections']) == []



# Generated at 2022-06-20 13:41:25.348706
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.verbosity = 6
    res = list(list_valid_collection_paths(warn=True))
    if './test_collections/collections_include' in res or './test_collections/collections_exclude' in res:
        assert False
    else:
        assert True


# Generated at 2022-06-20 13:41:35.887941
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = ["/tmp/ansible_collections", "/tmp/ansible_collections_2"]
    for path in coll_path:
        os.makedirs(path)
        os.makedirs(os.path.join(path, "mynamespace"))
        os.makedirs(os.path.join(path, "mynamespace", "mycollection"))
        os.makedirs(os.path.join(path, "mynamespace", "mycollection_dupe"))
        os.makedirs(os.path.join(path, "mynamespace_dupe"))
        os.makedirs(os.path.join(path, "mynamespace_dupe", "mycollection"))

# Generated at 2022-06-20 13:41:48.478072
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import tempfile
    test_dir = tempfile.mkdtemp(prefix='ansible-test-')

    # Test path
    search_paths = []
    gen = list_valid_collection_paths(search_paths=search_paths)
    assert len(search_paths) == 0
    assert len([x for x in gen]) == 0

    # Test path with invalid path
    search_paths = ['INVALID_PATH', 'INVALID_PATH_TOO']
    gen = list_valid_collection_paths(search_paths=search_paths)
    assert len([x for x in gen]) == 0

    # Test path with valid path
    search_paths = ['INVALID_PATH', test_dir, 'INVALID_PATH_TOO']
    gen = list

# Generated at 2022-06-20 13:41:58.002882
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_path = "/ansible/collections"
    invalid_path_file = "/ansible/collections_file"
    invalid_path_missing = "/ansible/missing"
    coll_paths = [valid_path, invalid_path_file, invalid_path_missing]

    valid_paths = list(list_valid_collection_paths(coll_paths))
    assert valid_path in valid_paths
    assert invalid_path_file not in valid_paths
    assert invalid_path_missing not in valid_paths



# Generated at 2022-06-20 13:42:19.186256
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for list_collection_dirs triggered by:
    ./test.sh -k test_file_utils
    """
    paths = []
    dirs = list(list_collection_dirs(paths, 'awx.awx'))
    assert dirs

# Generated at 2022-06-20 13:42:25.190307
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import tempfile
    import shutil
    test_list = []
    # test with a list one valid and one invalid path
    valid_path = os.path.join(tempfile.gettempdir(), 'ansible_valid')
    os.makedirs(valid_path)
    display.vvv(valid_path)
    invalid_path = os.path.join(tempfile.gettempdir(), 'ansible_invalid')
    display.vvv(invalid_path)
    test_list.append(valid_path)
    test_list.append(invalid_path)
    for path in list_valid_collection_paths(search_paths=test_list, warn=True):
        display.vvv(path)
    # test with a empty list
    test_list.clear()

# Generated at 2022-06-20 13:42:29.641972
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    display.verbosity = 4

    # check multiple non-existent paths
    assert list(list_valid_collection_paths(['/path/does/not/exist', '/path/definitely/does/not/exist'], warn=True)) == []

    # check single non-existent path
    assert list(list_valid_collection_paths(['/path/does/not/exist'], warn=True)) == []

    # check path exists but is not a directory
    assert list(list_valid_collection_paths(['/usr/bin/python'], warn=True)) == []

    # check path exists and is a directory
    assert list(list_valid_collection_paths(['/usr/bin'], warn=True)) == ['/usr/bin']

# Generated at 2022-06-20 13:42:36.482744
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # empty path
    list_collection_dirs(search_paths=[])
    # path that doesn't exist
    list_collection_dirs(search_paths=["/fake/path"])
    # path that exists, but not a directory
    list_collection_dirs(search_paths=["/etc/hosts"])
    # path with no collections
    list_collection_dirs(search_paths=["/usr"])
    # path with collections dir but no actual collections
    list_collection_dirs(search_paths=["/usr/lib"])



# Generated at 2022-06-20 13:42:39.604796
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    display.verbosity = 4

    # simple test

# Generated at 2022-06-20 13:42:41.863838
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_bad_path = to_bytes("/tmp/does_not_exist")
    b_good_path = to_bytes("/tmp")

# Generated at 2022-06-20 13:42:51.733792
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_search_paths = [
        'test/testdata/single_collection/namespace/collection',
        'test/testdata/dual_collection/namespace',
        'test/testdata/dual_collection/namespace2',    # exists but no collection
        'test/testdata/dual_collection/namespace/collection1',
        'test/testdata/dual_collection/namespace/collection2',
    ]

    # test empty
    assert list(list_collection_dirs()) == []

    # try a specific bad namespace
    assert list(list_collection_dirs(search_paths=test_search_paths, coll_filter='nosuchname')) == []

    # test specific namespace

# Generated at 2022-06-20 13:42:58.748844
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.file import unfrackpath
    from ansible.utils.collection_loader import _get_collection_metadata

    collection_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'utils', 'ansible_collections', 'ansible_collections')

    test_paths = [collection_path]

    colls = []
    [colls.append(unfrackpath(x)) for x in list_collection_dirs(search_paths=test_paths)]

# Generated at 2022-06-20 13:43:09.849537
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import random
    import string

    def random_string(length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    for _ in range(50):
        path = tempfile.mkdtemp()
        ns = random_string(6)
        coll = random_string(6)
        # create ansible_collections/mycoll/myns/mycoll/...
        coll_dir = os.path.join(path, 'ansible_collections', ns, coll)
        os.makedirs(coll_dir)
        # create ansible_collections/myns/mycoll/mycoll/...
        coll_dir2 = os.path.join(path, ns, coll)
        os.m