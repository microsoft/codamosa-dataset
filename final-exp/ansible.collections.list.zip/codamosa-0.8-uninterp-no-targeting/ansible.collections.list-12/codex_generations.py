

# Generated at 2022-06-20 13:33:27.750138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/foo/bar/baz', '../../bar/baz', 'foo/bar/baz']
    want = []
    got = list(list_valid_collection_paths(search_paths=search_paths))
    assert want == got

    search_paths = ['/foo/bar/baz', '../../bar/baz', 'foo/bar/baz', '/']
    want = ['/']
    got = list(list_valid_collection_paths(search_paths=search_paths))
    assert want == got
    os.path.exists

    search_paths = ['/foo/bar/baz', '../../bar/baz', 'foo/bar/baz', '/foo']
    want = ['/foo']

# Generated at 2022-06-20 13:33:34.501077
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        "/foo/bar",
        "/etc/ansible/collections",
    ]

    valid = list(list_valid_collection_paths(paths))
    assert len(valid)==1
    assert valid[0] == "/etc/ansible/collections"

# Generated at 2022-06-20 13:33:45.000847
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '~/ansible_collections',
        '/my/test/path/here/ansible_collections',
        'C:\\Users\\test\\ansible_collections',
        '/ansible/test/collections/dir',
    ]
    assert len(list(list_valid_collection_paths(test_paths))) == len(test_paths)
    assert len(list(list_valid_collection_paths(test_paths, warn=True))) == len(test_paths)

    # Test mixed case paths

# Generated at 2022-06-20 13:33:56.881756
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import stat
    import tempfile
    import shutil

# Generated at 2022-06-20 13:33:57.844164
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO?
    pass


# Generated at 2022-06-20 13:34:06.719139
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    tdir = tempfile.TemporaryDirectory()
    test_coll_dir = os.path.join(tdir.name, 'ansible_collections', 'moo', 'cow')
    os.makedirs(test_coll_dir)

    # no filter all should be returned
    coll_dirs = list(list_collection_dirs([tdir.name]))
    assert len(coll_dirs) == 1
    assert coll_dirs[0] == test_coll_dir

    # filter for specific namespace, no collection, should return all from that namespace
    coll_dirs = list(list_collection_dirs([tdir.name], 'moo'))
    assert len(coll_dirs) == 1
    assert coll_dirs[0] == test_coll_dir

    # filter for specific

# Generated at 2022-06-20 13:34:12.076994
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        "./does_not_exist",
        "./test/data/existing_dir",
        "./test/data/existing_file.txt",
        "./test/data/existing_dir/",
        "./test/data/existing_dir/ansible_collections"
    ]

    res = list_valid_collection_paths(test_paths)

    assert list(res) == [
        './test/data/existing_dir',
        './test/data/existing_dir/ansible_collections'
    ], "Incorrect paths returned for collection searches"

# Generated at 2022-06-20 13:34:20.805604
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Validates the list_collection_dirs function
    """
    # Tests for filter
    coll_paths = ['/tmp/ansible_collections/ansible/test']
    test_path = '/tmp/ansible_collections/ansible/test'
    collection_path = [path for path in list_collection_dirs(search_paths=coll_paths, coll_filter='ansible.test')]
    assert collection_path == [to_bytes(test_path)]

    # Tests for multiple filters
    coll_paths = ['/tmp/ansible_collections/ansible/test', '/tmp/ansible_collections/ansible/test1']
    test_path = '/tmp/ansible_collections/ansible/test'

# Generated at 2022-06-20 13:34:31.532367
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pwd = os.getcwd()
    ns1 = os.path.join(pwd, 'ansible_collections/ns1')
    c1_1 = os.path.join(ns1, 'c1')
    c1_2 = os.path.join(ns1, 'c2')
    c1_3 = os.path.join(ns1, 'c3')
    c2_1 = os.path.join(pwd, 'ansible_collections/ns2/c1')
    c2_2 = os.path.join(pwd, 'ansible_collections/ns2/c2')
    c2_3 = os.path.join(pwd, 'ansible_collections/ns2/c3')
    os.mkdir(ns1)

# Generated at 2022-06-20 13:34:42.024803
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # setup test environment
    TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
    TEST_DATA_DIR = os.path.join(TESTS_DIR, 'test_data', 'collection_loader')
    search_paths = [TEST_DATA_DIR]
    ns_path = os.path.join(search_paths[0], 'ansible_collections', 'namespace1')
    coll_path = os.path.join(ns_path, 'collection1')

    # test no namespace or collection filter
    found_collections = list_collection_dirs(search_paths)
    assert len(found_collections) == 1
    assert next(found_collections) == coll_path

    # test empty namespace filter
    found_collections = list_collection

# Generated at 2022-06-20 13:35:02.994880
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Invalid
    config = [
        {'invalid_path': '/this/path/does/not/exist'},
        {'invalid_path_2': '/this/path/exists/but/is/not/a/directory'},
        {'invalid_path_3': '../this/path/does/not/exist'},
        {'invalid_path_4': '..'},
        {'invalid_path_5': '/this/path/exists/but/is/not/a/directory/'},
    ]

    # Valid

# Generated at 2022-06-20 13:35:15.183860
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from tempfile import mkdtemp

    td = mkdtemp()
    b_td = to_bytes(td, errors='surrogate_or_strict')

    paths = []
    paths.append(tempfile.mktemp())
    paths.append(td)
    paths.append(b_td)
    paths.append('not a path')

    for p in list_valid_collection_paths(search_paths=paths, warn=True):
        assert p not in paths

    paths = []
    paths.append('not a path')

    for p in list_valid_collection_paths(search_paths=paths, warn=True):
        assert p not in paths

# Generated at 2022-06-20 13:35:20.600432
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    collection_path = os.path.join(this_dir, 'ansible_collections', 'ansible_collections')
    collection_path_dupe = os.path.join(this_dir, 'ansible_collections_dupe', 'ansible_collections')

    assert len(list(list_collection_dirs([collection_path, collection_path_dupe]))) == 2

# Generated at 2022-06-20 13:35:31.988354
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    @summary: test function list_valid_collection_paths
    """
    test_path_a = os.path.expanduser("~/my_collections")
    test_path_b = os.path.expanduser("~/collections")
    test_path_c = os.path.expanduser("~/does_not_exist")
    test_path_d = os.path.expanduser("~/file")


# Generated at 2022-06-20 13:35:43.485756
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Listing all collection dirs")
    for coll_dir in list_collection_dirs(search_paths=['../ansible_collections/ns1/coll1', '../ansible_collections/ns1/coll2', '../ansible_collections/ns2/coll3'],
                                         coll_filter='ns1'):
        print("  ", coll_dir)

    print("Listing all collection dirs in ns1")
    for coll_dir in list_collection_dirs(search_paths=['../ansible_collections/ns1/coll1', '../ansible_collections/ns1/coll2', '../ansible_collections/ns2/coll3'],
                                         coll_filter='ns1'):
        print("  ", coll_dir)

# Generated at 2022-06-20 13:35:50.120927
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Temporary directory
    valid_search_path = tempfile.mkdtemp()

    # Temporary file
    invalid_search_path = tempfile.mktemp()
    open(invalid_search_path, 'w').close()

    assert list_valid_collection_paths([valid_search_path]) == [valid_search_path]
    assert not list(list_valid_collection_paths([invalid_search_path]))


# Generated at 2022-06-20 13:35:56.667219
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Returns list of valid paths
    """

    # list_collection_dirs with dictionary
    assert isinstance(list_collection_dirs({'other': '/share/ansible/collections', 'collections_paths': ['/usr/share/ansible/collections']}), list)
    assert isinstance(list_collection_dirs({'other': '/share/ansible/collections', 'collections_paths': ['/usr/share/ansible/collections']}), list)

# Generated at 2022-06-20 13:36:08.250790
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        '.invalid',
        'not there',
        'tests/support/collection_fixed_paths/non_collection',
        'tests/support/collection_fixed_paths/ansible_collections/testns/testcoll1',
        'tests/support/collection_fixed_paths/ansible_collections/testns/testcoll2/modules',
        'tests/support/collection_fixed_paths/ansible_collections/testns/testcoll3/modules',
        'tests/support/collection_fixed_paths/ansible_collections/testns/testcoll4',
    ]
    ret = list_valid_collection_paths(test_paths)

# Generated at 2022-06-20 13:36:15.911696
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    fake_collections = ["ansible_collections", "some_other_coll", "my_collections"]
    fake_namespaces = ["some_namespc", "namespace", "ansible_collection"]
    fake_collections = ["coll1", "coll2", "collection"]

    search_paths = []
    for fake_coll in fake_collections:
        for fake_namespace in fake_namespaces:
            for fake_coll in fake_collections:
                path = os.path.join(fake_coll, to_bytes(fake_namespace), to_bytes(fake_coll))
                if not os.path.exists(path):
                    os.makedirs(path)
                search_paths.append(path)


# Generated at 2022-06-20 13:36:26.041743
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    (outfd, test_coll_path) = tempfile.mkstemp(prefix='ansible-test-')

    # write out the various test paths
    os.mkdir(to_bytes(os.path.join(test_coll_path, 'ansible_collections/ns1')))
    os.mkdir(to_bytes(os.path.join(test_coll_path, 'ansible_collections/ns1/coll1')))
    os.mkdir(to_bytes(os.path.join(test_coll_path, 'ansible_collections/ns1/coll2')))

# Generated at 2022-06-20 13:36:44.445536
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_list = list_collection_dirs(search_paths=['test/unit/modules/test_resources'])
    assert is_collection_path(next(coll_list))
    assert next(coll_list, None) is None

    coll_list = list_collection_dirs(search_paths=['test/unit/modules/test_resources/non_coll_dir'])
    assert next(coll_list, None) is None

    coll_list = list_collection_dirs(search_paths=['test/unit/modules/test_resources/coll_dir'])
    assert next(coll_list, None) is None

    coll_list = list_collection_dirs(search_paths=['test/unit/modules/test_resources/coll_dir/ansible_collections/ansible'])

# Generated at 2022-06-20 13:36:50.121870
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    import shutil


# Generated at 2022-06-20 13:36:58.376516
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert(len(list(list_collection_dirs(search_paths=['/no/such/path'], coll_filter='ansible.builtin'))) == 0)
    assert(len(list(list_collection_dirs(search_paths=['/no/such/path'], coll_filter='ansible.builtin'))) == 0)
    assert(len(list(list_collection_dirs(search_paths=['/etc/ansible', '/no/such/path'], coll_filter='ansible.builtin'))) == 1)

# Generated at 2022-06-20 13:37:07.803995
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections import ansible_collections_paths
    from ansible.utils.path import unfrackpath

    my_ansible_collections_paths = ansible_collections_paths
    my_ansible_collections_paths.append(unfrackpath('$HOME/my_playbooks/my_collections'))

    # Mock the config to provide our paths
    class myMockConfig(object):
        COLLECTIONS_PATHS = my_ansible_collections_paths

    # return results
    all_paths = list_valid_collection_paths(search_paths=[])
    assert len(all_paths) == len(my_ansible_collections_paths) - 1

    # return results

# Generated at 2022-06-20 13:37:16.670086
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ret = []
    for path in list_collection_dirs(['/x'], 'bar.baz'):
        assert path.endswith(b'/x/ansible_collections/bar/baz')
        ret.append(path)
    assert ret

    ret = []
    for path in list_collection_dirs(['/x', '/y'], None):
        assert path.endswith(b'/x/ansible_collections/bar/baz') or path.endswith(b'/y/ansible_collections/bar/baz')
        ret.append(path)
    assert ret

    ret = []

# Generated at 2022-06-20 13:37:30.108666
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs, list_valid_collection_paths

    # Create mock collection directories
    test_ns = 'test_ns'
    test_coll = 'test_coll'
    coll_path = '/tmp/ansible_collections'
    test_ns_path = os.path.join(coll_path, test_ns)
    test_coll_path = os.path.join(test_ns_path, test_coll)

    # Remove test collection space paths if they exist
    if os.path.exists(test_coll_path):
        import shutil
        shutil.rmtree(test_coll_path)
    if os.path.exists(test_ns_path):
        import shutil
        shutil.rmtree(test_ns_path)

# Generated at 2022-06-20 13:37:33.830902
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [b'/foo', b'/etc/ansible/collections']

    for path in list_valid_collection_paths(search_paths):
        assert(path in [b'/etc/ansible/collections'])



# Generated at 2022-06-20 13:37:46.347899
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """

    # setup test
    import tempfile
    t_dir = tempfile.mkdtemp()
    os.makedirs(t_dir)

    search_paths = [t_dir]
    warn = False

    # no paths
    data = list_valid_collection_paths(search_paths=None, warn=warn)
    assert not len(list(data))

    # one path, does not exist
    search_paths = [os.path.join(t_dir, 'foo')]
    data = list_valid_collection_paths(search_paths=search_paths, warn=warn)
    assert not len(list(data))

    # one path, exists but is not a directory

# Generated at 2022-06-20 13:37:47.193333
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()

# Generated at 2022-06-20 13:37:52.300588
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config.data import ConfigData
    from ansible.plugins.loader import collection_loader

    # Need to reset ConfigData so we can use the default collection_paths
    ConfigData().reset()

    collection_patches = collection_loader.collections

    # Load collection paths
    # Sanity check that we get back some collection paths
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) >= len(collection_patches)

    # Load one specific collection
    collection_dirs = list(list_collection_dirs(coll_filter='ansible_test.testcollection'))
    assert len(collection_dirs) == 1

    # Load one specific namespace
    collection_dirs = list(list_collection_dirs(coll_filter='ansible_test'))

# Generated at 2022-06-20 13:38:24.093237
# Unit test for function list_collection_dirs

# Generated at 2022-06-20 13:38:32.697042
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/tmp/path_1', '/tmp/path_2', '/tmp/path_3']
    result = list(list_valid_collection_paths(search_paths=paths, warn=True))
    assert result == []
    result = list(list_valid_collection_paths(search_paths=paths, warn=False))
    assert result == []



# Generated at 2022-06-20 13:38:38.449649
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['./test/test_module', '/tmp/does_not_exist', '/tmp']
    good_paths = list(list_valid_collection_paths(test_paths, warn=False))
    assert len(good_paths) == 2
    assert good_paths[0] == './test/test_module'
    assert good_paths[1] == '/tmp'

# Generated at 2022-06-20 13:38:42.673357
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list_valid_collection_paths(['/nonexisting/path'])
    assert list_valid_collection_paths()

# Generated at 2022-06-20 13:38:48.330985
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = '/tmp, /var/tmp, /bad/path'

    try:
        iter = list_valid_collection_paths(paths.split(', '))
        assert len(list(iter)) == 2
    except Exception:
        assert False



# Generated at 2022-06-20 13:38:53.955627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert '/path/to/collections/namespace/collection' in list_collection_dirs(search_paths=['/path/to/collections'], coll_filter='namespace.collection')
    assert '/path/to/collections/namespace' in list_collection_dirs(search_paths=['/path/to/collections'], coll_filter='namespace')

# Generated at 2022-06-20 13:39:02.673136
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    # Create a local collection dir and add it to config
    collection_paths = [tempfile.mkdtemp()]
    collection_paths.extend(AnsibleCollectionConfig.collection_paths)
    AnsibleCollectionConfig.set_collection_paths(collection_paths)
    collection_dir = os.path.join(collection_paths[0], 'ansible_collections', 'mock', 'fake')
    os.makedirs(collection_dir)
    # Test valid collection
    dirs = list_collection_dirs()
    assert(list(dirs) == [to_bytes(collection_dir)])
    # Test non-existing collection
    dirs = list_collection_dirs(coll_filter='mock.non-existing')
    assert(list(dirs) == [])

# Generated at 2022-06-20 13:39:12.553313
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = "test_collections/ansible_collections"
    coll_dir = os.path.join(os.getcwd(), path)
    assert list_collection_dirs([coll_dir]) != []

    path = "test_collections/ansible_collections/c/collection/"
    coll_dir = os.path.join(os.getcwd(), path)
    assert list_collection_dirs([coll_dir]) != []

    path = "test_collections/ansible_collections/c/collection/plugins"
    coll_dir = os.path.join(os.getcwd(), path)
    assert list_collection_dirs([coll_dir]) == []

    path = "test_collections/ansible_collections/c/collection/plugins/modules"

# Generated at 2022-06-20 13:39:21.700914
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import FileSystemCollectionLoader
    from ansible.module_utils.common.collections import AnsibleCollectionLoader
    import pytest

    # load the test collections paths
    loader = AnsibleCollectionLoader()
    loader.add_collection_paths(['test/unit/utils/ansible_collections', 'test/unit/utils/ansible_collections_nonansible'])

    # get the path to the collections
    collection_dirs = loader.get_collection_dirs()

    # test the collection is not loaded for the invalid collection namespace
    assert b"test_reject_namespace" not in collection_dirs
    assert b"test_reject_namespace.reject_collection" not in collection_dirs



# Generated at 2022-06-20 13:39:27.991826
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    display.verbosity = 6
    display.debug("Testing list_valid_collection_paths")

    paths = ['test/features/data/collections/missing',
             'test/features/data/collections/not_a_collection',
             'test/features/data/collections/all_collections',
             '/tmp'
             ]

    # display.verbosity = 2

    for path in paths:
        display.debug("Testing path: %s" % path)
        path_list = list_valid_collection_paths([path])
        for this_path in path_list:
            display.debug("    - %s" % this_path)
            assert this_path == 'test/features/data/collections/all_collections'

# Generated at 2022-06-20 13:39:55.758029
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp/foo', '/tmp/bar'])) == ['/tmp/foo', '/tmp/bar']
    assert list(list_valid_collection_paths(['/tmp/foo', '/tmp/bar', '/tmp/baz'])) == ['/tmp/foo', '/tmp/bar', '/tmp/baz']
    assert list(list_valid_collection_paths(['/tmp/foo', '/tmp/bar', '/foo/bar'])) == ['/tmp/foo', '/tmp/bar']


# Generated at 2022-06-20 13:40:06.089959
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # NOTE: if you have a symlink "ansible_collections" pointing to another directory
    # with a collection, you will get duplicate results in your unit tests.
    coll_dirs = list(list_collection_dirs())
    assert len(coll_dirs) > 0, "No collections found in " + ":".join(list_valid_collection_paths())
    in_ansible_path = False
    for cd in coll_dirs:
        assert os.path.isdir(cd), "Collection directory not found: "+cd
        assert cd.endswith("ansible_collections"), "Unexpected collection directory: "+cd
        if cd.startswith(AnsibleCollectionConfig.ansible_config.ansible_path):
            in_ansible_path = True

# Generated at 2022-06-20 13:40:16.094983
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    none_paths = list(list_valid_collection_paths(search_paths=None, warn=False))
    assert len(none_paths) >= 1, 'list_valid_collection_paths() should return at least /usr/share/ansible if no paths are passed'

    empty_paths = list(list_valid_collection_paths(search_paths=[], warn=False))
    assert len(empty_paths) >= 1, 'list_valid_collection_paths() should return at least /usr/share/ansible if no paths are passed'

    assert empty_paths == none_paths, 'list_valid_collection_paths() should return default paths if no paths are passed'


# Generated at 2022-06-20 13:40:25.022346
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # empty list
    search_paths = []
    result = list_valid_collection_paths(search_paths)
    assert len(list(result)) == len(AnsibleCollectionConfig.collection_paths)

    # non existent directory
    search_paths = ['/non/existent/folder']
    result = list_valid_collection_paths(search_paths)
    assert len(list(result)) == 0

    # existing directory
    search_paths = ['/']
    result = list_valid_collection_paths(search_paths)
    assert len(list(result)) == 1

# Generated at 2022-06-20 13:40:31.873942
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    all_collections = list(list_collection_dirs())
    assert 'ansible_collections.microsoft.azure' in all_collections
    assert 'ansible_collections.ansible.builtin' in all_collections
    assert 'ansible_collections.network.f5' in all_collections
    assert 'ansible_collections.ansible_tower.tower' in all_collections
    assert 'ansible_collections.community.general' in all_collections
    assert 'ansible_collections.not.a.real.collection' not in all_collections
    assert 'ansible_collections.missing.namespace' not in all_collections


# Generated at 2022-06-20 13:40:35.584111
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    assert list(list_valid_collection_paths(search_paths)) == [to_bytes(p, errors='surrogate_or_strict') for p in AnsibleCollectionConfig.collection_paths]

# Generated at 2022-06-20 13:40:44.357011
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create a test collection dir
    test_coll = './test_list_collection_dirs/ansible_collections/mytest'
    os.makedirs(test_coll)
    assert list(list_collection_dirs(['./test_list_collection_dirs'])) == [test_coll]

    # Create a test collection subdir
    test_ns = 'mytest.mytestns'
    test_coll = os.path.join('test_list_collection_dirs/ansible_collections', test_ns)
    os.makedirs(test_coll)

    # Test that list_collection_dirs returns the correct dir
    assert list(list_collection_dirs(['./test_list_collection_dirs'], test_ns)) == [test_coll]

    # Test that list_collection_

# Generated at 2022-06-20 13:40:58.138198
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_dir = '/tmp/ansible_collections_test'
    os.mkdir(os.path.join(test_dir, 'ansible_collections'))

    # set up some dirs with collection and not collection dir names
    os.mkdir(os.path.join(test_dir, 'ansible_collections/notnamespace'))
    os.mkdir(os.path.join(test_dir, 'ansible_collections/notnamespace/notcoll'))
    os.mkdir(os.path.join(test_dir, 'ansible_collections/namespace'))
    os.mkdir(os.path.join(test_dir, 'ansible_collections/namespace/notcoll'))

# Generated at 2022-06-20 13:41:02.229651
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    in_paths = ['test1', 'test2', 'test3']
    out_paths = list(list_valid_collection_paths(search_paths=in_paths))
    assert len(out_paths) == 3
    assert 'test1' in out_paths
    assert 'test2' in out_paths
    assert 'test3' in out_paths



# Generated at 2022-06-20 13:41:14.834255
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    
    # Need to mock Display class
    # load plugins is called by ansible-doc
    # mocking display will suppress some warnings
    class PluginLoader(object):
        def __init__(self): pass
        def run(self, name, module_name, path, invoke_module, module_args, desc, module, collection_name):
            return True

    class MockDisplay(object):
        def __init__(self):
            self.plugin_loader = PluginLoader()

    display = MockDisplay()

    search_paths = ['/tmp/ansible_collections']

    result = list_valid_collection_paths(search_paths)

    assert not result

    search_paths = ['/tmp/ansible_collections', 'doesnotexist']

    result = list_valid_collection_paths(search_paths)



# Generated at 2022-06-20 13:41:48.469392
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    base = os.path.dirname(os.path.dirname(__file__))
    testdir = os.path.join(base, b'test_valid_collection_paths')
    os.mkdir(testdir)

    bad_path = 'foo'

    # create a test config file
    config_path = os.path.join(testdir, b'ansible.cfg')
    f = open(config_path, b'w+')
    f.write(b'[collections] \n')
    f.write('other_paths = {0}'.format(bad_path))
    f.close()

    # create a test collection
    coll_path = os.path.join(testdir, b'ansible_collections/test/test_collection')
    os.makedirs(coll_path)

# Generated at 2022-06-20 13:41:52.149728
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=[])) == []
    assert list(list_valid_collection_paths(search_paths=['not.valid.dir'])) == []
    assert list(list_valid_collection_paths(search_paths=['not.valid.dir'.split('.')])) == []

# Generated at 2022-06-20 13:42:04.702334
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test empty list
    assert len(list(list_valid_collection_paths([], False))) == 0
    assert len(list(list_valid_collection_paths([], True))) == 0

    # Test list of bad search paths
    assert len(list(list_valid_collection_paths(['/foo/bar'], False))) == 0
    assert len(list(list_valid_collection_paths(['/foo/bar'], True))) == 0

    # Test list of good search paths
    paths = list_valid_collection_paths(['./test/integration/sanity/collections/good'], False)
    assert len(list(paths)) == 1
    paths = list_valid_collection_paths(['./test/integration/sanity/collections/good'], True)

# Generated at 2022-06-20 13:42:13.240524
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Verify that the default paths are returned
    result = list_valid_collection_paths(search_paths=None)
    assert isinstance(result, list)

    # Verify that a single valid path is returned
    result = list_valid_collection_paths(search_paths=['/var/tmp'])
    assert isinstance(result, list)
    assert len(result) == 1



# Generated at 2022-06-20 13:42:21.106113
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Given a valid collection path
    test_path = '/foo/bar/ansible_collections'

    # And a valid collection within that path
    test_coll = 'some.namespace.collection'

    # And a collection directory within that path
    test_coll_dir = os.path.join(test_path, test_coll)

    # When I supply the collection path to list_collection_dirs
    coll_dirs = list_collection_dirs([test_path])

    # Then I should get back the directory for that collection
    assert next(coll_dirs) == test_coll_dir

# Generated at 2022-06-20 13:42:33.953692
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test paths that do not exist and a path that does not exist
    # should be filtered out from the list and should not appear as
    # a valid path
    test_paths = [
        '/nonexistent/path',
        '/usr/share/ansible/collections',
        '/tmp',
    ]

    expect_paths = [
        '/usr/share/ansible/collections',
        '/tmp',
    ]

    result_paths = list(list_valid_collection_paths(test_paths, warn=True))

    assert set(result_paths) == set(expect_paths)

# Generated at 2022-06-20 13:42:44.281002
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # No collection paths configured
    empty_paths = []
    paths = list(list_valid_collection_paths(empty_paths, False))
    assert len(paths) == 0

    # Single path configured, existing and valid
    single_path = ['/tmp/collections']
    paths = list(list_valid_collection_paths(single_path, False))
    assert len(paths) == 1
    assert paths[0] == '/tmp/collections'

    # Single path configured, existing but not a dir
    single_path = ['/tmp/collections']
    with open(single_path[0], 'w') as temp_file:
        temp_file.write('# Test file')
    paths = list(list_valid_collection_paths(single_path, False))
    assert len(paths)

# Generated at 2022-06-20 13:42:53.213089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-20 13:43:03.967234
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for entry in list_valid_collection_paths(search_paths=['/nothing/is/here', '/tmp',
                                                           '/tmp/does/not/exist']):
        assert entry == '/tmp'

    for entry in list_valid_collection_paths(search_paths=['/etc/fake', '/dev/null']):
        # /dev/null is a character device, not a directory
        assert entry == '/etc/fake'



# Generated at 2022-06-20 13:43:09.112707
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(['/usr/local/test/testcoll'], 'ansible.test') == \
        ['/usr/local/test/testcoll/ansible_collections/ansible/test',
         '/usr/local/test/testcoll/ansible_collections/ansible.test']