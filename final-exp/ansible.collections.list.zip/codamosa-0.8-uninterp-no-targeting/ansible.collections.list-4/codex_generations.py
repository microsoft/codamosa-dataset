

# Generated at 2022-06-20 13:33:25.867152
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    orig_collection_paths = AnsibleCollectionConfig.collection_paths
    AnsibleCollectionConfig.collection_paths = []

    b_home_dir = to_bytes(os.getcwd(), errors='surrogate_or_strict')

    b_coll_dir = to_bytes(os.path.join(b_home_dir, 'ansible_collections'), errors='surrogate_or_strict')

    # Test with list of paths that include non existing and non dir
    search_paths = ['/does/not/exist', b_coll_dir, '/etc/passwd']
    valid_coll_paths = list(list_valid_collection_paths(search_paths=search_paths))
    assert len(valid_coll_paths) == 1
    assert valid_coll_paths[0]

# Generated at 2022-06-20 13:33:31.555189
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = [os.path.join('my_collections', 'my_namespace', 'my_collection'),
                       os.path.join('my_collections', 'my_namespace', 'my_collection2'),
                       os.path.join('my_collections', 'my_namespace2', 'my_collection3'),
                       os.path.join('my_collections', 'my_namespace2', 'my_collection4')]

    for c in collection_dirs:
        os.makedirs(c)

    assert sorted(collection_dirs) == sorted(list(list_collection_dirs(['my_collections'])))

    dirs = list(list_collection_dirs(['my_collections'], coll_filter='my_namespace.my_collection'))
    assert len(dirs)

# Generated at 2022-06-20 13:33:42.556488
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    List valid search_paths for collections
    """

    from ansible.plugins import find_collection_plugins
    from collections import defaultdict
    from ansible.collections import is_collection_dir

    import tempfile
    import shutil
    import os

    # create a collection that does not match
    tmpdir = tempfile.mkdtemp()
    shutil.rmtree(tmpdir)
    try:
        os.makedirs(tmpdir)
        os.makedirs(os.path.join(tmpdir, 'not_ans_collections'))
    except IOError:
        raise

    # create a collection dir
    tmpdir2 = tempfile.mkdtemp()
    outdir = os.path.join(tmpdir2, 'ansible_collections')

# Generated at 2022-06-20 13:33:54.678280
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        './test/unit/utils/test_collection_config/test_collection_paths',
        './test/unit/utils/test_collection_config/empty_collection_paths/',
        './test/unit/utils/test_collection_config/not_existing_collection_path'
    ]
    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert valid_paths == [
        './test/unit/utils/test_collection_config/test_collection_paths'
    ]

# Generated at 2022-06-20 13:34:01.874925
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = [
        '/tmp/collections',
        '/ansible/collections',
        '/ansible/path/does/not/exist',
    ]

    paths = list_valid_collection_paths(search_paths=test_paths, warn=True)

    assert paths is not None

    collected = []

    for path in paths:
        collected.append(path)

    assert len(collected) == 1
    assert collected[0] == '/tmp/collections'


# Generated at 2022-06-20 13:34:12.264212
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-20 13:34:19.206017
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list_collection_dirs()
    assert isinstance(collection_dirs, list)
    assert len(collection_dirs) >= 9
    assert "ansible_collections/ansible/netcommon/plugins/action" in collection_dirs
    assert "ansible_collections/test_namespace/nettest/plugins/action" in collection_dirs
    assert "ansible_collections/test_namespace/test_collection/plugins/action" in collection_dirs
    assert "ansible_collections/test_namespace/test_collection2/plugins/action" in collection_dirs

# Generated at 2022-06-20 13:34:26.533781
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures', 'collections'),
        'another_bogus_collections_path'
    ]

    paths = list(list_valid_collection_paths(search_paths, warn=True))

    assert paths
    assert len(paths) == 1
    assert paths[0] == search_paths[0]

# Generated at 2022-06-20 13:34:33.681530
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    result = list(list_valid_collection_paths(['/tmp']))
    assert result == ['/tmp']

    result = list(list_valid_collection_paths(['/tmp', '/tmp/empty', '/tmp/invalid']))
    assert result == ['/tmp']

    result = list(list_valid_collection_paths(['/tmp/invalid']))
    assert result == []

    # default should not warn
    result = list(list_valid_collection_paths())
    assert result == []

    # defaults should warn
    result = list(list_valid_collection_paths(warn=True))
    assert result == []

# Generated at 2022-06-20 13:34:38.219436
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
  assert list_collection_dirs(['/usr/share/ansible/collections/']) is not None

# Generated at 2022-06-20 13:34:53.211469
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list collection dir with different variants of given collection path
    """
    coll_path = ["../../../test/units/lib/ansible_collections"]
    collection = list_collection_dirs(coll_path, 'ns1.coll1')
    assert(next(collection) == b'../../../test/units/lib/ansible_collections/ns1/coll1')

    coll_path = ["../../../test/units/lib/ansible_collections/"]
    collection = list_collection_dirs(coll_path, 'ns1.coll1')
    assert(next(collection) == b'../../../test/units/lib/ansible_collections/ns1/coll1')


# Generated at 2022-06-20 13:34:57.515702
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common._collections_compat import Iterable

    result = list_valid_collection_paths(search_paths=None, warn=True)
    assert isinstance(result, Iterable)



# Generated at 2022-06-20 13:35:01.354082
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/etc/ansible/collections',
        '/tmp/doesnotexist',
        '/tmp/isnotadir',
    ]

    search_paths_directories = {}
    for path in list_valid_collection_paths(search_paths):
        assert os.path.exists(to_bytes(path, errors='surrogate_or_strict'))
        assert os.path.isdir(to_bytes(path, errors='surrogate_or_strict'))

        # For now we know that all collection paths should be directories
        search_paths_directories[path] = True

    assert len(search_paths_directories) == len(search_paths) - 2


# Generated at 2022-06-20 13:35:07.075381
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test with a list of paths
    paths = collections.deque()
    paths.append('tests/sanity/collection_loader/collections')
    # the following path is non-existent
    paths.append('tests/sanity/collection_loader/nonexistent')
    # these two next paths are not collection directories
    paths.append('tests/sanity/collection_loader/not_collections/ansible.builtin')
    paths.append('tests/sanity/collection_loader/not_collections/ansible.builtin/filter')
    # all other collection directories in tests/sanity/collection_loader/collections should be returned
    # note that there is the possibility of dupe collections at least in namespace
    # do namespaces get returned by this function?
    # per discussion: no, only collections

# Generated at 2022-06-20 13:35:17.368970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test with no collection filter
    coll_dirs = list_collection_dirs(search_paths=['test/units/utils/test_collections'], coll_filter=None)
    mycollpaths = []
    for coll_dir in coll_dirs:
        mycollpaths.append(coll_dir.decode('utf-8'))
    assert len(mycollpaths) == 2
    assert mycollpaths[0] == 'test/units/utils/test_collections/namespace1/collection1'
    assert mycollpaths[1] == 'test/units/utils/test_collections/namespace2/collection2'

    # test with namespace filter

# Generated at 2022-06-20 13:35:25.629408
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six import StringIO

    expected_warning = "The configured collection path {0}, exists, but it is not a directory.".format('/foo/bar')

    old_stdout = display.messaging.stdout
    display.messaging.stdout = StringIO()

    try:
        valid_collection_paths = list(list_valid_collection_paths(['/foo/bar', '/tmp']))
        assert expected_warning in display.messaging.stdout.getvalue()
        assert '/tmp' in valid_collection_paths
    finally:
        display.messaging.stdout = old_stdout



# Generated at 2022-06-20 13:35:27.768144
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert '/' in list(list_valid_collection_paths(warn=False))

# Generated at 2022-06-20 13:35:37.802249
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import random
    import string

    test_path = tempfile.mkdtemp()

    # verify empty list returns nothing
    assert len(list(list_valid_collection_paths([]))) == 0

    # verify non-existent path is not returned, but default path is
    assert test_path not in list(list_valid_collection_paths([test_path]))
    assert to_bytes(test_path) not in list(list_valid_collection_paths([test_path]))
    assert len(list(list_valid_collection_paths([test_path]))) == 1

    # verify non-directory path is not returned

# Generated at 2022-06-20 13:35:40.646789
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    colls = list(list_collection_dirs())
    assert len(colls) > 0

# Generated at 2022-06-20 13:35:47.144605
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['a/b', '/home/user/foo/bar', '~', '/path/does/not/exist']
    res = list_valid_collection_paths(search_paths)
    assert 'a/b' in res
    assert '/home/user/foo/bar' in res
    assert '~' not in res
    assert '/path/does/not/exist' not in res



# Generated at 2022-06-20 13:36:03.038598
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        './test/unit/list_collection_dirs',
        './nonexistent',
        './test/unit/data/plugins',
    ]

    collection_dirs = list(list_collection_dirs(search_paths=search_paths))

    assert len(collection_dirs) == 2
    assert 'test_namespace.test_coll1' in collection_dirs
    assert 'test_namespace.test_coll2' in collection_dirs

# Generated at 2022-06-20 13:36:14.152402
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.collections import is_collection_path

    # Assumes test collection exists, TODO: use temp_dir for unit tests
    test_coll = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'sanity', 'collection')

    paths = get_collection_paths()
    paths.append(test_coll)

    for path in list_valid_collection_paths(paths):
        assert is_collection_path(path)

    if test_coll not in paths:
        display.warning(
            "Test collection not found in configured paths, is your test env configured correctly??"
        )

# Generated at 2022-06-20 13:36:24.959309
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_path = os.path.dirname(__file__)
    test_path = os.path.join(test_path, '..')
    test_path = os.path.abspath(test_path)

    test_set = set(list_valid_collection_paths([test_path]))
    assert len(test_set) == 1
    assert test_path in test_set

    # path is file - should be excluded
    test_set = set(list_valid_collection_paths([__file__]))
    assert len(test_set) == 0

    # non-existent path - should be excluded
    test_set = set(list_valid_collection_paths(['non-existent-path']))
    assert len(test_set) == 0



# Generated at 2022-06-20 13:36:32.150049
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # A test for list_valid_collection_paths()
    # The test check only for whether the search_paths exist or not.
    # pylint: disable=redefined-outer-name
    search_paths = ['/--invalid/path/',
                    '/usr/share/ansible/collections/ansible_collections',
                    '/usr/share/ansible_collections/ansible_collections']

    valid_paths = list_valid_collection_paths(search_paths)
    assert valid_paths is not None
    assert len(valid_paths) == 2
    assert '/usr/share/ansible/collections/ansible_collections' in valid_paths
    assert '/usr/share/ansible_collections/ansible_collections' in valid_paths

    # Test when

# Generated at 2022-06-20 13:36:41.530604
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    tmpdir = os.environ.get('TMPDIR', '/tmp')
    search_path = os.path.join(tmpdir, 'test_collections')

    path_file = open(search_path, 'w')
    path_file.write('/this/path/does/not/exist\n')

    collection_paths = list_valid_collection_paths([search_path])
    assert list(collection_paths) == []

    path_file.write('/tmp\n')
    path_file.close()

    collection_paths = list_valid_collection_paths([search_path], warn=True)
    assert list(collection_paths) == ['/tmp']



# Generated at 2022-06-20 13:36:51.321242
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # load default config
    assert [] == list(list_valid_collection_paths(None, False))
    # add two paths (one existing, one non existing)
    assert ['foo'] == list(list_valid_collection_paths(['foo', 'bar'], False))
    # warn on empty list
    assert [] == list(list_valid_collection_paths(None, True))
    # warn on non existing path
    assert [] == list(list_valid_collection_paths(['bar'], True))
    # warn on existing not dir
    p = tmp_path+'/not-dir'
    os.mkdir(p)
    assert [] == list(list_valid_collection_paths([p], True))


# Generated at 2022-06-20 13:37:02.920981
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for the :func:`list_collection_dirs` function
    """
    import unittest
    import tempfile
    import shutil
    
    class ListCollectionDirsTestCase(unittest.TestCase):
        def setUp(self):
            self.root_temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.root_temp_dir, ignore_errors=True)

        def test_list_collection_dirs(self):
            """
            Unit test for the :func:`list_collection_dirs` function
            """

            # Make a mock collection
            coll_base = os.path.join(self.root_temp_dir, 'my_collection')
            os.mkdir(coll_base)

# Generated at 2022-06-20 13:37:13.011379
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    SEARCH_PATHS = [
        './not-exists',
        './not-a-dir',
        './path/to/a/fake/system/lib/python/site-packages/ansible_collections',  # valid
        './path/to/a/fake/system/extra/lib/python/ansible_collections',  # valid
        '/path/to/a/fake/system/extra/lib/python/ansible_collections'  # valid
    ]

    # create not-a-dir
    with open('./not-a-dir', 'w') as f:
        f.write('testing')


# Generated at 2022-06-20 13:37:20.759404
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    def assert_list_equal(list1, list2):
        assert sorted(list1) == sorted(list2)

    home_my_plugins = os.path.expanduser("~") + os.sep + "my_plugins"
    home_my_plugins_b = to_bytes(home_my_plugins)

    assert_list_equal(
        list(list_valid_collection_paths(search_paths=['/root/invalid_path',
                                                       '/root/invalid_path2',
                                                       home_my_plugins])),
        [home_my_plugins]
    )


# Generated at 2022-06-20 13:37:27.086376
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dirs = list(list_collection_dirs(coll_filter='mynamespace.mycollection'))
    assert len(coll_dirs) == 1
    assert 'ansible_collections/mynamespace/mycollection' in coll_dirs[0]
    assert 'ansible_collections/ansible/mycollection' not in coll_dirs[0]

    coll_dirs = list(list_collection_dirs(coll_filter='mycollection'))
    assert len(coll_dirs) == 2
    assert 'ansible_collections/mynamespace/mycollection' in coll_dirs[0]
    assert 'ansible_collections/ansible/mycollection' in coll_dirs[1]
    assert coll_dirs[0] != coll_dirs[1]

# Generated at 2022-06-20 13:37:44.011693
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = '/path/to/dir/fake'
    namespaces_dirs = ['namespace', 'namespace2']
    collections_dirs = ['collection', 'collection2']

    def os_listdir(path):
        if path == path:
            return namespaces_dirs
        if path.endswith('namespace'):
            return [collections_dirs[0]]
        if path.endswith('namespace2'):
            return [collections_dirs[1]]

    def is_collection_path(path):
        for c in collections_dirs:
            if path.endswith(c):
                return True
        return False

    ansible_collection = 'ansible_collections'

# Generated at 2022-06-20 13:37:53.137370
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import ansible.config

    temp_path = tempfile.mkdtemp()

    valid_namespace_dir = os.path.join(temp_path, 'ansible_collections', 'namespace1', 'collection1')
    valid_namespace_dir_2 = os.path.join(temp_path, 'ansible_collections', 'namespace1', 'collection2')
    valid_namespace_dir_3 = os.path.join(temp_path, 'ansible_collections', 'namespace2', 'collection3')
    valid_namespace_dir_4 = os.path.join(temp_path, 'ansible_collections', 'namespace2', 'collection4')

# Generated at 2022-06-20 13:38:04.529294
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.plugins.loader import get_collection_loaders

    dirs = list(list_collection_dirs())
    assert len(dirs) > 0

    # now verify each of the collections will be loaded via the collection loader
    for d in dirs:
        d = to_bytes(d)
        for loader in get_collection_loaders():
            if loader.is_collection_dir(d):
                assert loader.get_collection_name(d) == loader.get_collection_name(d)
                assert len(loader.list_collection_roles(d))
                assert len(loader.list_collection_plugins(d))
                assert len(loader.list_collection_modules(d))
                assert len(loader.list_collection_paths(d))

# Generated at 2022-06-20 13:38:07.659788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = ['.', '.doesnotexist', '/usr/share/ansible']
    for path in list_valid_collection_paths(coll_paths, warn=True):
        assert path in ['/usr/share/ansible']



# Generated at 2022-06-20 13:38:11.548145
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert(list([p for p in list_valid_collection_paths(search_paths=None)]))

# Generated at 2022-06-20 13:38:14.649400
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    f = list_valid_collection_paths([])
    for i in f:
        print(i)
    #print f.next() # Python 2
    #print(next(f)) # Python 3


# Generated at 2022-06-20 13:38:23.721974
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    real_path = list_valid_collection_paths(['./test/data/collection_dirs/ansible_collections'])
    assert len(list(real_path)) == 1
    real_path = list_valid_collection_paths(['./test/data/collection_dirs/ansible_collections'], warn=True)
    assert len(list(real_path)) == 1
    fake_path = list_valid_collection_paths(['I/should/not/exist/'])
    assert len(list(fake_path)) == 0
    fake_path = list_valid_collection_paths(['I/should/not/exist/'], warn=True)
    assert len(list(fake_path)) == 0



# Generated at 2022-06-20 13:38:35.825171
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # setup
    errorlog = ""

    # test
    for path in list_valid_collection_paths(search_paths=["/does/not/exist", "/root/bin/ansible", "/root"], warn=False):
        if path == "/does/not/exist":
            errorlog = "list_valid_collection_paths: returned a non-existent path"
            assert False, errorlog
        if path == "/root/bin/ansible" or path == "/root":
            assert True
    # teardown
    if errorlog != "":
        raise AnsibleError("Error in test: " + errorlog)



# Generated at 2022-06-20 13:38:39.190454
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=["/tmp/test_path_one", "/tmp/test_path_two"])
    assert list_valid_collection_paths(warn=True)

# Generated at 2022-06-20 13:38:52.894088
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert set(list_valid_collection_paths(['../test/unit/module_utils/collection_loader', '../test/unit/module_utils'])) == \
        set(['../test/unit/module_utils/collection_loader', '../test/unit/module_utils'])
    assert set(list_valid_collection_paths(['../test/unit/module_utils/collection_loader', '/not/valid/path', '../test/unit/module_utils'])) == \
        set(['../test/unit/module_utils/collection_loader', '../test/unit/module_utils'])

# Generated at 2022-06-20 13:39:12.125256
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs
    :return:
    """

    b_path = to_bytes(__file__)
    b_ansible_collections_path = os.path.join(os.path.dirname(b_path), b'files')
    assert list_collection_dirs([os.path.dirname(b_path)]) == []
    assert list_collection_dirs([b_ansible_collections_path])
    assert list_collection_dirs([b_ansible_collections_path], 'ns1.coll1')
    assert list_collection_dirs([b_ansible_collections_path], 'ns1')
    assert list_collection_dirs([b_ansible_collections_path], 'ns1.coll1')
    assert list_collection_dir

# Generated at 2022-06-20 13:39:18.794846
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Testing list_valid_collection_paths()")
    test_paths = [
        "/usr/share/ansible/collections",
        "/var/lib/ansible/collections",
        "/foo/bar",
        "/etc/ansible",
    ]
    print("Before: %s" % (test_paths))
    result = list_valid_collection_paths(test_paths, warn=True)
    print("After: %s" % (list(result)))

# Generated at 2022-06-20 13:39:30.373256
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    file1 = "/tmp/one/two"
    path1 = "/tmp/"
    path2 = "/tmp/one"
    path3 = "/tmp/three"

    # invalid paths
    assert (list_valid_collection_paths([file1]) == [])

    # default paths
    assert (list_valid_collection_paths([]) == list(AnsibleCollectionConfig.collection_paths))

    # default paths
    assert (list_valid_collection_paths(None) == list(AnsibleCollectionConfig.collection_paths))

    # valid paths
    assert (list_valid_collection_paths([path1]) == [path1])

    # both valid paths
    assert (list_valid_collection_paths([path1, path2]) == [path1, path2])

    # both valid paths, different order


# Generated at 2022-06-20 13:39:38.939248
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Uses default search_paths
    coll_dirs = [dir for dir in list_collection_dirs(coll_filter=None)]
    assert len(coll_dirs) > 0

    # Uses filter passed in
    coll_dirs = [dir for dir in list_collection_dirs(coll_filter='ansible_collections.nti_cloud_services.cloud')]
    assert '/home/ansible/ansible2.9/ansible_collections/ansible_collections/nti_cloud_services/cloud' in coll_dirs

    # Uses search_paths passed in
    coll_dirs = [dir for dir in list_collection_dirs(search_paths=['/home/ansible/ansible2.9/ansible_collections'], coll_filter=None)]

# Generated at 2022-06-20 13:39:42.705209
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import Path

    b_path = list_collection_dirs(search_paths=[Path.cwd()])
    assert b_path is not None

# Generated at 2022-06-20 13:39:53.824035
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    class MockDisplay:
        def __init__(self):
            self.log = []

        def warning(self, msg):
            self.log.append(msg)

    foo = os.path.join('foo', 'bar')
    bar = os.path.join('bar', 'baz')

    # make temp directory for testing
    tempdir = mkdtemp()

    # create collection path
    temp_coll = os.path.join(tempdir, 'ansible_collections')
    os.makedirs(temp_coll)

    test_collection_path = []
    test_collection_path.append(tempdir)


# Generated at 2022-06-20 13:40:04.564564
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    # create a temporary search path
    b_test_search_path = to_bytes(mkdtemp(), errors='surrogate_or_strict')
    coll_config = AnsibleCollectionConfig()
    coll_paths = list(coll_config.collection_paths)

    # add the temporary path to the collection path
    search_paths = [b_test_search_path]

    # filter out non existing or invalid search_paths
    filter_paths = list_valid_collection_paths(search_paths, warn=True)

    # create a temp dir with all required files and dirs
    b_temp_dir = to_bytes(mkdtemp(), errors='surrogate_or_strict')

# Generated at 2022-06-20 13:40:15.635987
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp

    from ansible.collections.ansible import AnsibleCollectionConfig
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # Create a simple namespace and collection hierarchy
    temp_dir = mkdtemp()
    coll_dir = os.path.join(temp_dir, 'bob_ns', 'my_coll')

    os.makedirs(coll_dir)

    # Insert a collection config to list_collection_dirs
    AnsibleCollectionConfig.config_data = {
        'collections_paths': [
            temp_dir
        ]
    }

    # Add all plugin dirs to the plugin loader
    add_all_plugin_dirs(AnsibleCollectionLoader, False)

    # Check

# Generated at 2022-06-20 13:40:26.695488
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Setup temp path strings
    tmp_dir = os.path.abspath(os.path.dirname(__file__) + '/../unit/test/ansible_collections')
    tmp_dir_jcopy = os.path.abspath(os.path.dirname(__file__) + '/../unit/test/ansible_collections_jcopy')
    b_tmp_dir = to_bytes(tmp_dir)
    b_tmp_dir_jcopy = to_bytes(tmp_dir_jcopy)

    # Setup collections for tests

# Generated at 2022-06-20 13:40:32.499917
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test function list_collection_dirs - this function is only tested indirectly via the collection linter
    '''

# Generated at 2022-06-20 13:40:46.086990
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/some/path']) == ['/some/path']
    assert list_valid_collection_paths(['/some/path', '/some/other/path']) == ['/some/path', '/some/other/path']



# Generated at 2022-06-20 13:40:52.344218
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp', '/tmp1', '/tmp/ansible_collections'])) == ['/tmp/ansible_collections']
    assert list(list_valid_collection_paths(['/tmp', '/tmp1', '/tmp/ansible_collections/badpath'])) == []

# Generated at 2022-06-20 13:40:55.658187
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['some/invalid/path', '/some/valid/path']
    result = list(list_valid_collection_paths(paths, warn=True))
    assert result == ['/some/valid/path']

# Generated at 2022-06-20 13:40:56.640928
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == []

# Generated at 2022-06-20 13:41:05.090113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test empty path
    assert list(list_valid_collection_paths([])) == []

    # test non existing dirs in list
    assert list(list_valid_collection_paths(['/foo/bar/baz', '/usr/local/share/foo/baz'])) == []

    # test existing paths in list
    test_paths = [
        '/usr/share/ansible',
        '/usr/local/share/ansible',
        '/tmp/foo/bar/ansible',
        '/tmp/ansible_bar'
    ]
    # create test paths
    for path in test_paths:
        if not os.path.exists(path):
            os.makedirs(path)


# Generated at 2022-06-20 13:41:15.906032
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_src = ['../test/testdata/collections/collections_one_ns/',
                '../test/testdata/collections/collections_two_ns/']
    assert list_collection_dirs(search_paths=coll_src) is not None
    assert list_collection_dirs(search_paths=coll_src, coll_filter='ns1') is not None
    assert list_collection_dirs(search_paths=coll_src, coll_filter='ns2') is not None
    assert list_collection_dirs(search_paths=coll_src, coll_filter='ns1.coll1') is not None
    assert list_collection_dirs(search_paths=coll_src, coll_filter='ns1.coll2') is not None

# Generated at 2022-06-20 13:41:19.945545
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    dir1 = tempfile.mkdtemp()
    dir2 = tempfile.mkdtemp()
    os.mkdir(os.path.join(dir2, "ansible_collections"))
    fd, temp_file = tempfile.mkstemp()
    test_search_paths = [dir1, dir2, temp_file]
    result = list(list_valid_collection_paths(test_search_paths, warn=True))
    assert result == [dir2]



# Generated at 2022-06-20 13:41:24.149397
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_root = to_bytes('./test/unit/ansible_collections/', errors='surrogate_or_strict')
    test_dirs = list(list_collection_dirs(search_paths=[b_coll_root]))
    assert test_dirs == [to_bytes('./test/unit/ansible_collections/test_namespace/test_collection')]

# Generated at 2022-06-20 13:41:35.269765
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Passed collections:
    # - namespace1.collection1
    # - namespace1.collection2
    # - namespace2.collection3
    # Configured collections:
    # - namespace2.collection4
    # - namespace2.collection5
    # - namespace3.collection6
    # => Expected result:
    # [ 'namespace1.collection1', 'namespace1.collection2', 'namespace2.collection3' ]
    search_paths = [ 'namespace1/collection1', 'namespace2/collection3', 'namespace2/collection4' ]
    coll_filter = 'namespace1'
    collections = list(list_collection_dirs(search_paths, coll_filter))
    assert len(collections) == 2
    assert collections[0] == 'namespace1/collection1'
    assert collections

# Generated at 2022-06-20 13:41:48.472210
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys

    mypath = os.path.abspath(os.path.dirname(__file__))
    myparent = os.path.dirname(mypath)
    mygrandparent = os.path.dirname(myparent)
    mygreatgrandparent = os.path.dirname(mygrandparent)

    sys.path.insert(0, mygreatgrandparent)

    print("Unit test for function list_collection_dirs")
    print("looking in %s" % mygreatgrandparent)

    # NOTE: this test relies on ansible.collections being in the repo root
    # not in lib/ansible/collections
    # break both of those cases for testing
    # TODO: add proper fixture for testing
    # TODO: generate a test collection

    from ansible.collections import list_collection_dirs



# Generated at 2022-06-20 13:42:18.668491
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.verbosity = 3

    # Test with non existent collection path
    search_paths = ['tests/unit/data/collection_loader/search_paths/does_not_exist']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert valid_paths == []

    # Test with existing collection path
    search_paths = ['tests/unit/data/collection_loader/search_paths/exist']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert valid_paths == ['tests/unit/data/collection_loader/search_paths/exist']

    # Test with existing file collection path

# Generated at 2022-06-20 13:42:23.323403
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['../../', './']
    coll_dirs = list(list_collection_dirs(search_paths))

    assert len(coll_dirs) == 2
    assert os.path.basename(coll_dirs[0]) == 'ansible_test_collection'
    assert os.path.basename(coll_dirs[1]) == 'ansible_test_collection2'

# Generated at 2022-06-20 13:42:28.919537
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Test with empty path
    assert list(list_valid_collection_paths([])) == []

    # Add file to path
    temp_path = tempfile.mktemp()
    open(temp_path, 'a').close()
    search_paths = [temp_path]

    # Test and assert
    assert list(list_valid_collection_paths(search_paths)) == []
    os.unlink(temp_path)

    # Add dir to path
    temp_dir = tempfile.mkdtemp()
    new_dir = os.path.join(temp_dir, 'ansible_collections')
    os.mkdir(new_dir)
    search_paths = [temp_dir]

    # Test and assert

# Generated at 2022-06-20 13:42:33.271247
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/test", "/test2"])) == []
    assert list(list_valid_collection_paths([])) != []
    assert list(list_valid_collection_paths(["/"])) == ["/"]


# Generated at 2022-06-20 13:42:44.497392
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit tests for the list_valid_collection_paths function
    """
    assert list_valid_collection_paths(['~/non/existent/path']) == []
    assert list_valid_collection_paths(['~/non/existent/path', '/tmp']) == ['/tmp']
    assert list_valid_collection_paths(['/tmp/non/existent/path', '/tmp']) == ['/tmp']
    assert list_valid_collection_paths(['/tmp/']) == ['/tmp/']
    assert list_valid_collection_paths(['/tmp', '/tmp']) == ['/tmp']
    assert list_valid_collection_paths(['/tmp/../tmp']) == []



# Generated at 2022-06-20 13:42:49.079223
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    fake_paths = [tempfile.mkdtemp(), tempfile.mkdtemp()]
    fake_paths.remove(fake_paths[1])
    assert list(list_valid_collection_paths(fake_paths, warn=False)) == [fake_paths[0]]



# Generated at 2022-06-20 13:42:54.050718
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    all_paths = ['/tmp/ansible_collections/', '/does/not/exist/']
    all_paths.extend(AnsibleCollectionConfig.collection_paths)

    assert list(list_valid_collection_paths(search_paths=all_paths)) == ['/tmp/ansible_collections/']



# Generated at 2022-06-20 13:42:58.394946
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: add unit test for this function
    pass


# Generated at 2022-06-20 13:43:09.638481
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils import plugin_docs

    def fake_loader(self, path, collection_list=None, ignore_deprecated=False):

        collection_list = collection_list if collection_list else []

        if path:
            path = os.path.basename(path)

        if '/' not in path:
            collection_list.append(tuple(path.split('.')))
        return collection_list

    # mock module_utils.plugin_docs.find_collections to detect use
    plugin_docs.find_collections = fake_loader

    config_paths = [
        '/path/to/collection',
        os.path.join(os.path.expanduser("~"), '.ansible', 'collections'),
        '/does/not/exist',
    ]

    # test with a list of paths that does not

# Generated at 2022-06-20 13:43:19.844391
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([os.path.expanduser('~/.ansible/collections'),
                                            "/foo/bar/baz"])) == \
           [os.path.expanduser('~/.ansible/collections'),
            "/foo/bar/baz"]

    assert list(list_valid_collection_paths(['/foo/bar/baz'])) == ["/foo/bar/baz"]
