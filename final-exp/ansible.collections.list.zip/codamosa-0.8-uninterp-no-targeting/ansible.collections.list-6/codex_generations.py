

# Generated at 2022-06-20 13:33:26.212599
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test that the correct collection paths are returned for a specific list
    """

    top_dir = os.path.dirname(os.path.dirname(__file__))
    valid_collections_paths = list_valid_collection_paths(search_paths=["/non/existant/dir",
                                                                        os.path.join(top_dir, "test/units/utils/")])
    correct_paths = [os.path.join(top_dir, "test/units/utils/")]

    assert sorted(correct_paths) == sorted(list(valid_collections_paths))

# Generated at 2022-06-20 13:33:29.676656
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter='test.test_collection') == ['test/test_collection']

# Generated at 2022-06-20 13:33:40.733681
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    a_dir_noncoll = '/tmp/ansible_collections/collections_dir'
    a_dir_coll = '/tmp/ansible_collections/ns.coll/tasks'
    b_dir_coll = '/tmp/ansible_collections/ns.coll/tasks'
    c_dir_coll = '/tmp/ansible_collections/ns.coll/tasks'

    os.makedirs(a_dir_noncoll)
    os.makedirs(a_dir_coll)
    os.makedirs(b_dir_coll)
    os.makedirs(c_dir_coll)

    coll = None
    # default no filter, all collections returned
    colls = list_collection_dirs(['/tmp'])
    assert len(colls) == 3

    # filter by coll

# Generated at 2022-06-20 13:33:55.628938
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible_galaxy import AnsibleGalaxyInterface

    tempdir = mkdtemp()

# Generated at 2022-06-20 13:33:56.256817
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-20 13:34:05.908558
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.ansible.myns.mycoll import plugins
    loader_path = os.path.dirname(plugins.__file__)

    coll_path_list = []

    # first use the loader_path
    coll_path_list.append(loader_path)
    assert list(list_collection_dirs(search_paths=coll_path_list, coll_filter='ansible.myns')) == [loader_path]

    # now add another path below and make sure we get both
    coll_path_list.append(loader_path)

    coll_path_list.append(os.path.join(loader_path, '..', '..', '..', 'myns2'))

# Generated at 2022-06-20 13:34:12.918270
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    search_paths.append('/usr/share/ansible/collection')
    search_paths.append('/etc/ansible/collections')
    search_paths.append('/usr/share/ansible')
    search_paths.append('/usr/share/foo/bar')
    search_paths.append('/usr/foo/bar')
    search_paths.append('/usr/foo/bar')

    test_paths = list_valid_collection_paths(search_paths=search_paths, warn=False)
    assert len(test_paths) == 2
    assert list(test_paths) == ['/usr/share/ansible/collection', '/etc/ansible/collections']



# Generated at 2022-06-20 13:34:21.187177
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    search_paths = []
    coll_filter = 'ns.coll'
    ns, coll = coll_filter.split('.')

    assert(list(list_collection_dirs(search_paths)) == [])

    # Create temporary collection
    tmp_nsdir = os.path.join(tmpdir, 'ansible_collections', ns)
    tmp_colldir = os.path.join(tmp_nsdir, coll)
    shutil.copytree(os.path.join(os.path.dirname(__file__),
                                 'testdata', 'namespace', 'collection'),
                    tmp_colldir)
    search_paths.append(tmpdir)


# Generated at 2022-06-20 13:34:31.794736
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config.manager import ConfigManager
    from ansible.utils import context_objects as co

    current_dir = os.path.dirname(os.path.realpath(__file__))

    base_dir = to_bytes(os.path.join(os.path.dirname(current_dir), 'test', 'unit', 'utils', 'ansible_config'))

    config = ConfigManager(base_dir, ini_path=to_bytes('ansible.cfg'), ini_file=to_bytes('ansible.cfg'))
    config._populate()
    co.GlobalCLIArgs._ansible_config = config.data
    co.GlobalCLIArgs._ansible_config._ConfigManager__cache.clear()

    # Test 1, Path not found

# Generated at 2022-06-20 13:34:41.945293
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function ansible.utils.collection_loader.list_valid_collection_paths
    :return:
    """

    # general tests
    test_search_paths = [
        "/foo/bar",
        "/ansible/collections",
    ]

    for path in list_valid_collection_paths(search_paths=test_search_paths):
        assert path == "/ansible/collections", "Path should be valid and equal to /ansible/collections"

    # run without any search path configured
    invalid_search_paths = [
        "/foo/bar",
    ]

    for path in list_valid_collection_paths(search_paths=invalid_search_paths):
        assert path == False, "Path should be invalid"

# Generated at 2022-06-20 13:34:56.859489
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list(list_valid_collection_paths(['/some/bogus/path', '/foo/bar', '/etc/ansible/collections']))
    assert paths == ['/etc/ansible/collections'], paths

    paths = list(list_valid_collection_paths(['/etc/ansible/collections/']))
    assert paths == ['/etc/ansible/collections'], paths

# Generated at 2022-06-20 13:34:58.670692
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # We don't need to do anything. Everything was tested
    # in test_collection_loader.
    pass

# Generated at 2022-06-20 13:35:06.398924
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [u'/bad/path', u'/good/path']
    good_search_paths = list(list_valid_collection_paths(search_paths))

    assert len(good_search_paths) == 1
    assert good_search_paths[0] == '/good/path'


# Generated at 2022-06-20 13:35:17.110475
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['/foo', '/bar']
    coll_filter = 'foobar.baz'

    def _build_coll_dir(path, coll_dir):
        b_coll_dir = os.path.join(path, coll_dir)
        os.makedirs(b_coll_dir)
        with open(os.path.join(b_coll_dir, 'MANIFEST.json'), 'w') as f:
            f.write('')

    def _cleanup_coll_dir(s_path, coll_path):
        b_path = to_bytes(s_path)
        b_coll = to_bytes(coll_path)
        os.remove(os.path.join(b_path, b_coll, 'MANIFEST.json'))

# Generated at 2022-06-20 13:35:26.502719
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test single collection, single path
    collection_dirs = list(list_collection_dirs(search_paths=["../test/units/modules/test_collections"],
                                                coll_filter="mycustomcollection"))
    assert len(collection_dirs) == 1
    assert collection_dirs[0] == b"../test/units/modules/test_collections/ansible_collections/mycustomcollection"

    # test single collection, two dirs, should only find one
    collection_dirs = list(list_collection_dirs(search_paths=["../test/units/modules/test_collections/ansible_collections",
                                                              "../test/units/modules/test_collections/ansible_collections"],
                                                coll_filter="mycustomcollection"))

# Generated at 2022-06-20 13:35:33.627743
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    from ansible.module_utils._text import to_bytes

    # Test with a list of invalid paths
    inv_paths = [os.path.sep.join(['path', 'does', 'not', 'exist']),
                 os.path.sep.join(['/dev', 'null']),
                 '/root']

    res = list_valid_collection_paths(inv_paths, warn=False)
    assert not len(list(res))

    # Test with a valid path
    (fd, tmp_path) = tempfile.mkstemp(dir='/tmp')
    os.close(fd)
    os.unlink(tmp_path)
    res = list_valid_collection_paths([tmp_path])
    assert len(list(res)) == 1

# Generated at 2022-06-20 13:35:37.738368
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(coll_filter="my_namespace.my_collection")
    assert list_collection_dirs(coll_filter="my_collection")



# Generated at 2022-06-20 13:35:47.402469
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    dirs = {}
    for i in range(3):
        dirs[i] = tempfile.mkdtemp(prefix="ansible_collections_test_list_collection_dirs")


# Generated at 2022-06-20 13:35:54.555844
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_dirs = list(list_collection_dirs(coll_filter='ansible_collections.ns.col'))

    assert len(collection_dirs) == 1
    assert os.path.basename(collection_dirs[0]).rstrip('.tar.gz') == 'col'

    collection_dirs = list(list_collection_dirs(coll_filter='ns.col'))

    assert len(collection_dirs) == 1
    assert os.path.basename(collection_dirs[0]).rstrip('.tar.gz') == 'col'

    collection_dirs = list(list_collection_dirs(coll_filter='ns'))

    assert len(collection_dirs) == 1

# Generated at 2022-06-20 13:36:06.535363
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'collections')
    assert os.path.isdir(path)
    my_list = [p for p in list_collection_dirs([path])]
    assert len(my_list) > 0
    my_list = [p for p in list_collection_dirs([path], 'ansible')]
    assert len(my_list) > 0
    my_list = [p for p in list_collection_dirs([path], 'ansible.test')]
    assert len(my_list) > 0
    my_list = [p for p in list_collection_dirs([path], 'ansible.test.helloworld')]
    assert len(my_list) > 0

# Generated at 2022-06-20 13:36:25.954106
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_valid_paths = [os.path.join(os.path.dirname(__file__), 'fixtures', 'collections')]
    valid_paths = [p.decode('utf-8') for p in b_valid_paths]
    assert list_collection_dirs(valid_paths) == list_collection_dirs(valid_paths, 'ns.coll')
    assert list_collection_dirs(valid_paths, 'ns') == list_collection_dirs(valid_paths, 'ns.coll')
    assert list_collection_dirs(valid_paths, 'ns.coll.1') == []



# Generated at 2022-06-20 13:36:34.141791
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """

    assert len(list(list_valid_collection_paths(['/does/not/exist']))) == 0
    assert len(list(list_valid_collection_paths(['/dev/null']))) == 0
    assert len(list(list_valid_collection_paths([]))) > 0

# Generated at 2022-06-20 13:36:43.692783
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = [
        'test/resources/collections_loader/collections_b',
        'test/resources/collections_loader/collections_root',
        'test/resources/collections_loader/ansible_namespace',
        'test/resources/collections_loader/collection_namespace',
        'test/resources/collections_loader/invalid_namespace'
    ]

    # test just namespace
    dirs = list(list_collection_dirs(search_paths, 'ansible'))
    assert len(dirs) == 5
    assert os.path.basename(dirs[0]) == 'test_collection'
    assert os.path.basename(dirs[1]) == 'test_collection2'

# Generated at 2022-06-20 13:36:49.889885
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Tests result of list_valid_collection_paths function
    """

    search_paths = ["/a", "/b", "/c", "/d"]
    found = list(list_valid_collection_paths(search_paths))
    assert len(found) == len(search_paths), \
        "Should return {0} for {1}".format(len(search_paths), found)
    for mydir in found:
        assert not os.path.exists(mydir), \
            "{0} should not exist".format(mydir)

    search_paths = ["/a", "/b", "/c", "/d"]
    current_dir = os.path.abspath(os.getcwd())
    for mydir in search_paths:
        os.makedirs(mydir)


# Generated at 2022-06-20 13:37:01.380370
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test if list_collection_dirs returns correct paths
    """

    import pytest
    import tempfile
    temp_path = tempfile.gettempdir()
    test_search_path = [os.path.join(temp_path, 'ansible_collections', 'test1'),
                        os.path.join(temp_path, 'ansible_collections', 'test2')]
    test_collections = [('test1', 'test1_coll1'), ('test1', 'test1_coll2'),
                        ('test2', 'test2_coll1'), ('test2', 'test2_coll2'),
                        ('test1', 'test1_alias1'), ('test2', 'test2_alias2')]

# Generated at 2022-06-20 13:37:13.784634
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    correct_paths = []
    tmpdir = tempfile.mkdtemp()
    assert tmpdir not in correct_paths
    correct_paths.append(tmpdir)

    tmpdir_inner = tempfile.mkdtemp(dir=tmpdir)
    assert tmpdir_inner not in correct_paths
    correct_paths.append(tmpdir_inner)

    tmpdir_fail = os.path.join(tmpdir, 'fail')
    assert tmpdir_fail not in correct_paths
    assert not os.path.exists(tmpdir_fail)

    tmpfile_fail = tempfile.mktemp()
    assert tmpfile_fail not in correct_paths
    assert not os.path.exists(tmpfile_fail)


# Generated at 2022-06-20 13:37:14.977539
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=['/not/a/valid/path']) == []

# Generated at 2022-06-20 13:37:20.807388
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    search_paths = []
    coll_filter = None

    namespaces = ["ansible_namespace", "ansible_namespace2", "ansible_namespace3"]
    collections = [["coll1", "coll2", "coll3"], ["coll1", "coll2", "coll3"], ["coll1", "coll2", "coll3"]]
    coll_file_name = "ansible_collections/%s/%s/%s"

# Generated at 2022-06-20 13:37:27.133929
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    p1 = "/foo"
    p2 = "/bar"
    p3 = "/foo/bar"
    p4 = "/bar/foo"
    p5 = "/foo/bar/baz"
    p6 = "/foo/bar/baz/qux"

    # Empty search path
    paths = []
    exp_paths = []
    result_paths = list(list_valid_collection_paths(paths))
    assert result_paths == exp_paths

    # Search path with non existing directory
    paths = [p1]
    exp_paths = []
    result_paths = list(list_valid_collection_paths(paths))
    assert result_paths == exp_paths

    # Search path with existing non directory
    os.makedirs(p1)

# Generated at 2022-06-20 13:37:37.621468
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_native
    from ansible.utils.path import unfrackpath

    good_path = unfrackpath("./test/units/data/collections/good_collections/ansible_collections", follow=False)
    expected = [good_path]


# Generated at 2022-06-20 13:38:11.902848
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import Path
    from ansible.module_utils.common._collections_compat import TemporaryDirectory

    testdirs = []
    colls = []
    for coll in ('linux', 'ansible_namespace.test', 'ansible_namespace.other_test'):
        with TemporaryDirectory(dir=testdirs) as tmpdir:
            collpath = os.path.join(tmpdir, coll.replace('.', '/'))
            os.makedirs(os.path.join(collpath, 'plugins/modules'))
            colls.append(Path(collpath))

    with TemporaryDirectory(dir=testdirs) as tmpdir:
        no_collpath = os.path.join(tmpdir, 'no_collection')

# Generated at 2022-06-20 13:38:16.807854
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_path=['/usr/share/ansible/collections','/usr/share/ansible/collections_bad']
    valid_paths=list(list_valid_collection_paths(search_path,True))
    assert valid_paths==['/usr/share/ansible/collections']


# Generated at 2022-06-20 13:38:19.945908
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/non/existing/path', '/etc/ansible/mycollections']
    assert list_valid_collection_paths(search_paths=search_paths) == ['/etc/ansible/mycollections']

# Generated at 2022-06-20 13:38:27.555680
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        '/tmp',
        '/tmp/ansible_collections',
        '/tmp/ansible_collections/badns/basic/plugins/modules',
        '/tmp/ansible_collections/badns/basic',
        '/tmp/ansible_collections/badns/basic/',
        '/tmp/ansible_collections/badns',
        '/tmp/ansible_collections/badns/',
        '/tmp/ansible_collections/badns/basic/subdir',
    ]
    base_collection_paths = [
        '/tmp/ansible_collections/badns/basic',
        '/tmp/ansible_collections/badns/basic/subdir',
    ]

# Generated at 2022-06-20 13:38:39.378919
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys

    # sanity check that test collections don't already exist
    test_collections = ['test.test1', 'test.test2', 'test.test3.test4']
    for t in test_collections:
        assert not is_collection_path(t)

    old_path = os.environ.get('ANSIBLE_COLLECTIONS_PATHS', None)

    base_dir = tempfile.mkdtemp(dir=os.getcwd(), suffix='-test_list_collection_dirs')

    # setup test collections directories
    test1_dir = os.path.join(base_dir, 'test', 'test1')
    test2_dir = os.path.join(base_dir, 'test', 'test2')
    test3_dir

# Generated at 2022-06-20 13:38:47.944500
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # deliberately empty search paths
    assert not list(list_collection_dirs(search_paths=[]))

    # assert search paths are filtered
    search_paths = [
        '/absolute/path/does/not/exist',
        'relative/path/does/not/exist',
        '/tmp',
        'roles',
        'plugins',
        'modules',
        '/etc/ansible/roles',
    ]
    only_tmp = list(list_collection_dirs(search_paths=search_paths))
    assert len(only_tmp) == 1

    # assert filter of collections and namespaces
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.common.collections import from_tarball

# Generated at 2022-06-20 13:38:58.192432
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = []
    collection_paths.append('test/test_collections_path')
    collection_paths.append('./test/test_collections_path')
    collection_paths.append('test/test_collections_path/')
    collection_paths.append('/test/test_collections_path/')
    collection_paths.append('/test/test_collections_path')
    collection_paths.append('does_not_exist')
    collection_paths.append('././')
    collection_paths.append('./')

    valid_collection_paths = []
    for path in collection_paths:
        if list(list_valid_collection_paths(search_paths=path)):
            valid_collection_paths.append(path)



# Generated at 2022-06-20 13:39:11.500893
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # normal case: all paths are directories
    search_paths = [
        "tests/units/plugins/collections/test_data/test_collections",
        "tests/units/plugins/collections/test_data/test_collections/sub1",
        "tests/units/plugins/collections/test_data/test_collections/sub2",
    ]

    listed_paths = list(list_valid_collection_paths(search_paths))
    assert search_paths == listed_paths

    # search path does not exist should be filtered out

# Generated at 2022-06-20 13:39:14.697327
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['non_existent', '/etc']
    assert list_valid_collection_paths(search_paths) == ['/etc']


# Generated at 2022-06-20 13:39:22.268197
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for collection_dir in list_collection_dirs(coll_filter='community.general'):
        assert os.path.exists(collection_dir)
        assert os.path.basename(collection_dir) == b'community'
        assert os.path.basename(os.path.dirname(collection_dir)) == b'general'

# Generated at 2022-06-20 13:40:24.354650
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    # Make some temporary directories
    testdirs = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp()
    ]

    # make some fake collection directories under testdirs
    testcollections = [
        ('org', 'one', 'ansible_collections/org/one'),
        ('org', 'two', 'ansible_collections/org/one'),
        ('org', 'three', 'ansible_collections/org/three'),
        ('org', 'four', 'ansible_collections/org/four'),
    ]

    for testcollection in testcollections:
        for dir in testdirs:
            newcoll = os.path.join(dir, testcollection[2])
            os.makedirs(newcoll)

# Generated at 2022-06-20 13:40:29.588699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    d_path = 'invalid_path'
    assert list(list_valid_collection_paths([d_path])) == []

    t_path = 'test_path'
    assert list(list_valid_collection_paths([t_path])) == [t_path]

    os.mkdir(t_path)
    assert list(list_valid_collection_paths([t_path])) == [t_path]

    os.rmdir(t_path)

# Generated at 2022-06-20 13:40:41.723452
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    from ansible_collections.ansible.builtin.plugins.module_utils.ansible_release import __version__ as ansible_version
    from tempfile import mkdtemp

    cur_dir = os.path.join('tests', 'units', 'module_utils', 'collection_loader', 'ansible_collection_path')
    assert os.path.exists(cur_dir), 'cant find %s' % cur_dir

    temp_dir = mkdtemp(prefix='ansible-testing-')

    temp_collections_dark_path = os.path.join(temp_dir, 'ansible_collections', 'dark')
    shutil.copytree(cur_dir, temp_collections_dark_path)

    # test for 1.4 versions
    ansible_version = ansible_version.rs

# Generated at 2022-06-20 13:40:50.273240
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with default search paths
    collection_paths = list(list_valid_collection_paths())

    display.display(collection_paths)
    assert collection_paths == ['/etc/ansible/collections']

    # test with 1 path
    paths = ['/usr/share/ansible/collections']
    collection_paths = list(list_valid_collection_paths(paths))
    assert collection_paths == ['/usr/share/ansible/collections']

    # test with 2 paths, 1 valid and 1 not
    paths = ['/usr/share/ansible/collections', '/inexistent/path']
    collection_paths = list(list_valid_collection_paths(paths))
    assert collection_paths == ['/usr/share/ansible/collections']

    # test

# Generated at 2022-06-20 13:41:00.586095
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    # create a temp directory for the test
    temp_dir = tempfile.mkdtemp()
    # this should be valid
    coll_dir1 = os.path.dirname(temp_dir + 'ansible_collections/')
    # this should be invalid
    coll_dir2 = temp_dir + 'ansible_collections/'
    # Save original config
    orig_coll_path = AnsibleCollectionConfig.collection_paths

    # Set config with invalid path and run test.
    # should return empty list
    AnsibleCollectionConfig.collection_paths = [coll_dir2]
    post_valid_paths = list(list_valid_collection_paths())
    assert len(post_valid_paths) == 0

    # Add valid path to end of list and run test.
    # should return

# Generated at 2022-06-20 13:41:14.633979
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_path = '/bar/collection-root/ansible_collections'
    colls = {
        'bar': {
            'baz': '/bar/collection-root/ansible_collections/bar/baz',
            'qux': '/bar/collection-root/ansible_collections/bar/qux',
        },
        'foo': {
            'bar': '/bar/collection-root/ansible_collections/foo/bar',
            'baz': '/bar/collection-root/ansible_collections/foo/baz',
        },
    }


# Generated at 2022-06-20 13:41:18.995866
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    try:
        test_path = mkdtemp()
        search_paths = [test_path]
        valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
        assert len(valid_paths) == 1
        assert os.path.samefile(to_bytes(test_path), to_bytes(valid_paths[0]))

    finally:
        rmtree(test_path)



# Generated at 2022-06-20 13:41:20.238844
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(['.'])  # Test with current directory
    assert list_collection_dirs(['.'], 'foo.bar')  # Test with non-exists collection

# Generated at 2022-06-20 13:41:21.440399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-20 13:41:26.173935
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Test that list_valid_collection_paths returns the expected number of paths
    '''
    path = list(list_valid_collection_paths(['/usr/share/ansible/collections', '/usr/share/ansible/extra_collections']))
    assert len(path) == 2

# Generated at 2022-06-20 13:43:07.202720
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ["/nonexistent_path", "/etc/ansible/mycollections"]
    assert list(list_valid_collection_paths(paths, True)) == ['/etc/ansible/mycollections']

# Generated at 2022-06-20 13:43:15.809446
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_text

    namespace = "test"
    collection = "awesome"
    coll_path = "/some/path/to/ansible_collections/{0}/{1}".format(namespace, collection)

    assert list_valid_collection_paths(["/some/path/to", "/some/invalid/path"], warn=True) == ["/some/path/to"]

    assert coll_path in [to_text(p) for p in list_valid_collection_paths([coll_path])]

