

# Generated at 2022-06-20 13:33:27.232064
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    if os.name == 'nt':
        # Windows path
        collection_paths = [r'c:\ansible_collections\ansible_collections']
    else:
        # Posix paths
        collection_paths = ['/etc/ansible/collections/ansible_collections']

    assert list(list_collection_dirs(coll_filter='foo.bar')) == []

    for collection_path in collection_paths:
        assert collection_path in list(list_collection_dirs(collection_path))
        assert collection_path in list(list_collection_dirs(coll_filter='foo'))
        assert collection_path in list(list_collection_dirs(coll_filter='foo.bar'))

# Generated at 2022-06-20 13:33:37.651059
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    import tempfile
    import shutil


# Generated at 2022-06-20 13:33:47.512821
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.collections import collection_loader

    def _get_config(paths):
        if paths is None:
            return AnsibleCollectionConfig()

        return AnsibleCollectionConfig(search_paths=paths)

    def _list_valid_collection_paths(paths, warn=False):
        """
        Method to invoke collection_loader.list_valid_collection_paths
        """
        # load existing config and use it as the base
        cfg = _get_config(paths)
        return collection_loader.list_valid_collection_paths(cfg.search_paths, warn=warn)


# Generated at 2022-06-20 13:33:58.805830
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils._text import to_text

    # no paths, use defaults
    coll_paths = list(list_valid_collection_paths())
    assert len(coll_paths) == 3

    # add some paths
    basepath = os.path.join(os.path.dirname(__file__), 'data', 'collections')
    # paths with 1 good, 1 not readable, 1 missing
    paths = [
        os.path.join(basepath, 'good'),
        os.path.join(basepath, 'bad', 'not_readable'),
        os.path.join(basepath, 'bad', 'no_exist'),
    ]
    coll_paths = list(list_valid_collection_paths(search_paths=paths))

# Generated at 2022-06-20 13:34:07.016508
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import AnsibleCollectionConfig

    AnsibleCollectionConfig.clear_config_cache()

    # Test list_valid_collection_paths with empty search_path and collection_paths
    assert list(list_valid_collection_paths([])) == []

    # Test with non existing path
    assert list(list_valid_collection_paths(['/non/existing/path'])) == []

    # Test with existing directory and non existing path
    public.ansible_module.makedirs(u'%s/testdir' % ANSIBLE_TEST_DATA_ROOT)

# Generated at 2022-06-20 13:34:19.049231
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['test/fixtures/collections']
    coll_directories = list(list_collection_dirs(search_paths))

    namespaces = ['testnamespace']
    collections = ['testcoll1', 'testcoll2', 'testcoll3']

    for ns in namespaces:
        for coll in collections:
            coll_fullname = ns + "." + coll
            coll_path = 'test/fixtures/collections/ansible_collections/' + coll_fullname
            assert(coll_path in coll_directories)

    # Test with coll_filter
    coll_fullname = 'testnamespace.testcoll1'
    coll_directories = list(list_collection_dirs(search_paths, coll_fullname))

# Generated at 2022-06-20 13:34:29.266281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    found_colls = list(list_collection_dirs())
    assert found_colls == [], found_colls
    found_colls = list(list_collection_dirs(coll_filter='invalid'))
    assert found_colls == [], found_colls
    found_colls = list(list_collection_dirs(coll_filter='test'))
    assert 'ansible_collections/test/my_collection' in found_colls, found_colls
    found_colls = list(list_collection_dirs(coll_filter='test.my_collection'))
    assert 'ansible_collections/test/my_collection' in found_colls, found_colls



# Generated at 2022-06-20 13:34:41.864664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import textwrap

    temp_root = tempfile.mkdtemp()

    # create test collection: foo.mycollection

    temp_coll = tempfile.mkdtemp(dir=temp_root)
    os.mkdir(os.path.join(temp_coll, b'foo'))
    os.mkdir(os.path.join(temp_coll, b'foo', b'mycollection'))
    os.mkdir(os.path.join(temp_coll, b'foo', b'mycollection', b'roles'))
    os.mkdir(os.path.join(temp_coll, b'foo', b'mycollection', b'plugins'))

# Generated at 2022-06-20 13:34:47.302281
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    for invalid_path in ('/usr/local/share/ansible/collections', '/usr/share/ansible_collections', '/tmp/does/not/exist'):

        iter = list_valid_collection_paths(search_paths=[invalid_path])
        assert not list(iter)

    for valid_path in ('/usr/share/ansible/collections', '/usr/share/ansible/collection', '/etc/ansible/collections'):

        iter = list_valid_collection_paths(search_paths=[valid_path])
        assert list(iter)

    # Test defaults
    iter = list_valid_collection_paths()
    assert list(iter)

# Generated at 2022-06-20 13:34:54.539932
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path1 = '/'
    path2 = '/tmp/does_not_exist'
    path3 = '/etc/crontab'
    paths = [path1,path2,path3]
    coll_paths = list(list_valid_collection_paths(search_paths=paths, warn=True))
    assert(len(coll_paths) == 1)
    assert(coll_paths[0] == path1)


# Generated at 2022-06-20 13:35:12.251440
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # List of valid and invalid paths
    search_paths = [
        "/usr/share/ansible/collections",
        "/usr/share/ansible/collections/ansible_collections/test_ns/test_coll1",
        "/usr/share/ansible/collections_folder",
        "/usr/share/ansible/collections/ansible_collections/test_ns/test_coll2",
    ]

    # List of valid paths
    valid_paths = [
        "/usr/share/ansible/collections",
        "/usr/share/ansible/collections/ansible_collections/test_ns/test_coll1",
        "/usr/share/ansible/collections/ansible_collections/test_ns/test_coll2"
    ]


# Generated at 2022-06-20 13:35:15.927346
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)

    test_paths = ['/foo', '/bar']
    assert list(list_valid_collection_paths(search_paths=test_paths)) == test_paths

    test_paths = ['/foo', '/bar']
    assert list(list_valid_collection_paths(search_paths=test_paths, warn=True)) == test_paths

# Generated at 2022-06-20 13:35:25.737622
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    test_data = [
        ('', '', None),
        ('a.b', '', 'a'),
        ('a.b', 'b', 'a'),
    ]

    import tempfile
    import shutil
    import os
    import sys

    def create_collection(collection_root, namespace, collection):
        os.makedirs(os.path.join(collection_root, 'ansible_collections', namespace, collection))
        with open(os.path.join(collection_root, 'ansible_collections', namespace, collection, '__init__.py'), 'w'):
            pass

    for ns, coll, search_path in test_data:
        with tempfile.TemporaryDirectory() as temp_dir:
            create_collection(temp_dir, 'a', 'b')
            create_

# Generated at 2022-06-20 13:35:29.630146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_roots = [os.path.join(os.path.dirname(__file__), '../../../../../collections')]
    colls = list(list_collection_dirs(collection_roots))
    assert colls == []

# Generated at 2022-06-20 13:35:37.802500
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    lst = list_valid_collection_paths(search_paths=["/tmp/collections"])
    assert lst == ["/tmp/collections"]

    lst = list_valid_collection_paths(search_paths=["/tmp/collections", "/tmp/collections2"])
    assert lst == ["/tmp/collections", "/tmp/collections2"]

    lst = list_valid_collection_paths(search_paths=["/tmp/collections", "/tmp/collections2", "/tmp/does_not_exist"])
    assert lst == ["/tmp/collections", "/tmp/collections2"]


# Generated at 2022-06-20 13:35:47.400207
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This function tests the list_collection_dirs function
    """
    from ansible.test.utils import ansible_posix_default_href
    from ansible.test.utils import get_data_loader

    # Test loading only specific collection
    jctanner_remote_plugins = [
        'ansible_collections.jctanner.remote_plugins.collection_tree'
    ]

    list_coll_dirs = list_collection_dirs(jctanner_remote_plugins)
    assert next(list_coll_dirs) == next(list_collection_dirs(jctanner_remote_plugins))

    # Test no collection paths
    empty_search_path = []

    list_coll_dirs = list_collection_dirs(empty_search_path)

# Generated at 2022-06-20 13:35:50.545163
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    collection_paths = [
        '/some/path/that/does/not/exist',
        '/etc/ansible/default_collections',
        '/some/path/that/does/not/really/exist',
        '/etc/ansible/collections',
    ]

    paths = list(list_valid_collection_paths(search_paths=collection_paths))

    assert len(paths) == 2
    assert '/etc/ansible/default_collections' in paths
    assert '/etc/ansible/collections' in paths



# Generated at 2022-06-20 13:35:58.574285
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six.moves.mock import patch
    import tempfile
    import random
    import string

    random_path = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    random_path2 = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    random_path3 = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))

    fake_collection_path_1 = os.path.join(tempfile.mkdtemp(), 'ansible_collections')

# Generated at 2022-06-20 13:36:09.337964
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils._text import to_bytes
    from ansible.utils.path import unfrackpath, makedirs_safe
    import tempfile
    basetempdir = tempfile.mkdtemp()

    coll1dir = unfrackpath(u"%s/ansible_collections/myns/c1" % basetempdir, follow=False)
    coll2dir = unfrackpath(u"%s/ansible_collections/myns/c2" % basetempdir, follow=False)
    makedirs_safe(to_bytes(coll1dir))
    makedirs_safe(to_bytes(coll2dir))

    # should find both myns.c1 and myns.c2
    colldirs = list_collection_dirs([basetempdir])

    assert coll1dir in coll

# Generated at 2022-06-20 13:36:23.287222
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    # prep temp collection structure
    test_search_paths = [tempfile.mkdtemp()]
    temp_collections = os.path.join(test_search_paths[0], 'ansible_collections')

    # prep normal collection structure
    os.makedirs(os.path.join(temp_collections, 'namespace', 'collection'))

    collection_dirs = list(list_collection_dirs(search_paths=test_search_paths, coll_filter='namespace.collection'))

    assert len(collection_dirs) == 1
    assert collection_dirs[0] == os.path.join(temp_collections, 'namespace', 'collection')

    # prep collection with extra collections (e.g. older versions)

# Generated at 2022-06-20 13:36:41.882994
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(["/dev/null", "/tmp"]) == ['/tmp']
    assert list_valid_collection_paths([]) == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-20 13:36:48.044917
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dir = list(list_collection_dirs(search_paths=['../../test/units/resources/collection_roots/multiple_roots'], coll_filter='foo.baz'))
    assert len(coll_dir) == 1
    assert 'baz' in coll_dir[0]



# Generated at 2022-06-20 13:37:00.117769
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    search_paths = []
    coll_filter = None

    # Normal case
    list_collection_dirs(search_paths, coll_filter)

    # Invalid filter
    coll_filter = 'foo.bar'
    try:
        list_collection_dirs(search_paths, coll_filter)
        assert False, "Invalid collection pattern supplied: {}".format(coll_filter)
    except AnsibleError as e:
        assert "Invalid collection pattern supplied: {}".format(coll_filter) in str(e)

    # Invalid filter
    expected = ['foo', 'bar', 'baz']
    coll_filter = ','.join(expected)

# Generated at 2022-06-20 13:37:08.610300
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Check the function list_collection_dirs return value and the
    order of the returned collections
    """

    to_sort = list(list_collection_dirs(search_paths=['test/units/module_utils/collection_loader/test_data']))

    # Need to convert the items to string in order to sort them
    to_sort = [to_bytes(item, errors='surrogate_or_strict') for item in to_sort]
    to_sort.sort()

    # Check the sorted list

# Generated at 2022-06-20 13:37:16.699528
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_text

    mypaths = ['/home/doug/.ansible/collections/ansible_collections',
               '/usr/share/ansible/collections/ansible_collections']
    pass_filt = 'namespace.collection'
    pass_filter = 'namespace'
    pass_filter2 = 'collection'
    test_filt = 'namespace.collection'
    test_filter = 'namespace'
    test_filter2 = 'collection'
    test_filt_fail = 'namespace.non_existent_collection'
    test_filt_fail2 = 'non_existent_namespace.collection'
    test_filter_fail = 'non_existent_namespace'
    test_filter_fail2 = 'namespace.non_existent_collection'


# Generated at 2022-06-20 13:37:26.647868
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_path = [os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collections')]
    test_colls = [i for i in list_collection_dirs(test_path)]
    assert len(test_colls) == 1
    test_colls = [i for i in list_collection_dirs(test_path, 'my_namespace.my_collection')]
    assert len(test_colls) == 1

# Generated at 2022-06-20 13:37:37.620658
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_dirs = list(list_collection_dirs(None, 'ns.coll'))

    assert len(collection_dirs) == 1, "Expected 1 collection dir returned"
    assert os.path.basename(collection_dirs[0]) == 'coll', "Expected collection 'coll' but found: %s" % collection_dirs[0]

    collection_dirs = list(list_collection_dirs(None, 'ns'))

    assert len(collection_dirs) == 1, "Expected 1 collection dir returned"
    assert os.path.basename(collection_dirs[0]) == 'coll', "Expected collection 'coll' but found: %s" % collection_dirs[0]

    collection_dirs = list(list_collection_dirs(None, 'ns_no_exists'))



# Generated at 2022-06-20 13:37:47.876763
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This function is not a test but a container for tests to be run by the unit tests
    """

    # test of list_collection_dirs with a list of paths
    def test_list_collection_dirs_with_paths():
        path_list = ["test1", "test2"]
        list_collection_dirs(path_list)

    # test of list_collection_dirs with no paths
    def test_list_collection_dirs_without_paths():
        path_list = []
        list_collection_dirs(path_list)

    # test of list_collection_dirs with an invalid directory
    def test_list_collection_dirs_with_invalid_dir():
        path_list = ["test1"]
        list_collection_dirs(path_list)

    # test of list

# Generated at 2022-06-20 13:37:50.455259
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    paths = [test_dir]

    for coll_dir in list_collection_dirs(paths):
        assert coll_dir is not None
        assert os.path.isdir(coll_dir)


__all__ = ['list_collection_dirs']

# Generated at 2022-06-20 13:37:58.595271
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test to ensure list_collection_dirs() returns consistent results.

    Given a specific search path, the function should return the same results
    when called with or without the "fos" namespace or collection.

    It should also return the same results when the "fos" namespace is only
    part of the search path, or when the search path includes nested paths.
    """
    os_collections_dir = '/etc/ansible/collections/ansible_collections'
    fos_dir = os_collections_dir + '/fos'
    fos_collections_dir = (fos_dir + '/collection_name')
    test_dirs = [
        'ansible_collections',
        'test_collections',
        fos_dir,
        fos_collections_dir
    ]

    # All

# Generated at 2022-06-20 13:38:23.975080
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # local setup
    test_path = u"/tmp/test_ansible_collections"
    my_collection_paths = [test_path, "/root/should_not_exist", "/tmp/my_test_file", "/usr/share/ansible/test/test_collections"]
    actual_paths = list()
    actual_paths_len = 0

    # happy path
    os.makedirs(test_path)
    actual_paths = list_valid_collection_paths(my_collection_paths)
    actual_paths_len = sum(1 for _ in list_valid_collection_paths(my_collection_paths))
    assert(actual_paths_len == 1)

    # expect default paths plus our test path
    actual_paths = list_valid_collection_paths()

# Generated at 2022-06-20 13:38:27.028617
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) is not None


# Generated at 2022-06-20 13:38:37.180833
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.plugins.loader import collection_loader
    from ansible.module_utils._text import to_text

    collection_loader.search_paths = []

    paths = ["/tmp/not_exist_dir", "/etc/passwd"]
    assert list(list_valid_collection_paths(paths, warn=True)) == []

    paths = ["/tmp/not_exist_dir", "/etc/passwd", "/bin"]
    for path in list_valid_collection_paths(paths, warn=True):
        assert os.path.realpath(to_text(path)) == '/bin'


# Generated at 2022-06-20 13:38:46.512371
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import os
    import shutil
    import io
    import pytest
    import sys

    (tmp_path, tmp_coll_paths) = tempfile.mkdtemp(), []

# Generated at 2022-06-20 13:38:58.129507
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collections_dirs with various inputs
    """

    expected = [b'/usr/share/ansible/collections/ansible_collections/acme/test']
    test = list(list_collection_dirs([], 'acme.test'))
    assert test == expected

    expected = [b'/usr/share/ansible/collections/ansible_collections/acme/test',
                b'/usr/share/ansible/collections/ansible_collections/acme/test2']
    test = list(list_collection_dirs([], 'acme'))
    assert set(test) == set(expected)


# Generated at 2022-06-20 13:39:11.462656
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.common._collections_compat import Path

    # create a temp dir for collections
    fd, coll_root = tempfile.mkstemp()
    os.close(fd)
    os.rmdir(coll_root)

    coll_root_path = Path(coll_root)

    # create a non existent dir
    bad_coll_root = coll_root_path / 'bad'

    # create a non-collection dir
    not_coll = coll_root_path / 'not_coll'
    not_coll.mkdir()

    # create a collection dir
    coll_dir = coll_root_path / 'myns' / 'mycoll'
    coll_dir.mkdir(parents=True)

    # create a collection symlink in a collection dir
    coll_symlink

# Generated at 2022-06-20 13:39:19.553552
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tmp_collection_dir = tempfile.TemporaryDirectory()
    tmp_collection_dir.path = to_bytes(tmp_collection_dir.name)
    path = os.path.join(tmp_collection_dir.path, b"ansible_collection", b"namespace", b"collection")
    os.makedirs(path)
    coll_dir = list(list_collection_dirs([tmp_collection_dir.name]))
    assert coll_dir is not None
    assert len(coll_dir) == 1
    assert coll_dir[0] == path
    tmp_collection_dir.cleanup()

# Generated at 2022-06-20 13:39:30.966367
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    "Tests the function collection_loader()"

    # NOTE: The assert statements in this function do
    # not use assertEqual because the order of the lists
    # is not important, and the string order returned by
    # list_collection_dirs() is unpredictable.

    # Empty list, to use default
    actual = list_collection_dirs([])
    expected = {'ansible': {'ansible_test_collection': '/usr/local/etc/ansible/collections/ansible_collections/ansible/ansible_test_collection'}}

    assert actual == expected

    # Default path
    actual = list_collection_dirs([], 'ansible.ansible_test_collection')

# Generated at 2022-06-20 13:39:41.204651
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = "test/test_collections/collections"
    test_filter = 'test.test_plugin'
    sub_dir = 'plugins'

    dirs = list_collection_dirs([path], coll_filter=test_filter)
    assert len(list(dirs)) == 1
    assert list(dirs)[0].endswith(sub_dir)

# Generated at 2022-06-20 13:39:45.433842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collections', 'ansible_collections')
    path = os.path.abspath(path)
    coll = list(list_collection_dirs([path]))
    assert coll

# Generated at 2022-06-20 13:40:25.996471
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collection_paths = ['fake_collection_path', '/dev/null']
    filtered_collection_paths = list(list_valid_collection_paths(search_paths=collection_paths))
    assert filtered_collection_paths == [], \
        "Fake collection_paths should not be included in the valid collection_paths list."
    filtered_collection_paths = list(list_valid_collection_paths())
    assert filtered_collection_paths == [], \
        "Default collection_paths should not be included in the valid collection_paths list."

# Generated at 2022-06-20 13:40:34.189067
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    from ansible.module_utils._text import to_bytes

    # create tempdir for test
    import tempfile
    testdir = tempfile.mkdtemp()
    os.environ['HOME'] = testdir
    testdir = to_bytes(testdir)

    # create a collection directory in that tempdir
    nsdir = os.path.join(testdir, to_bytes('ansible_collections/testns'))
    colldir = os.path.join(testdir, to_bytes('ansible_collections/testns/testcollection'))
    os.makedirs(colldir)
    open(os.path.join(colldir, to_bytes('plugin_type/plugin_name.py')), 'a').close()

    # call the function and check that it returns testdir

# Generated at 2022-06-20 13:40:43.800450
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import stat

    def create_dir(dirname):
        try:
            os.makedirs(dirname)
        except:
            pass
        assert os.path.isdir(dirname)

    def create_file(filename, contents):
        create_dir(os.path.dirname(filename))
        with open(filename, "w") as f:
            f.write(contents)

    def create_symlink(filename, linkname):
        try:
            os.symlink(filename, linkname)
        except:
            pass

    def create_collection(collection_path, name, version=None):
        create_dir(os.path.join(collection_path, name, 'plugins', 'modules'))
        if version:
            create_

# Generated at 2022-06-20 13:40:45.153096
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Give an empty iterator with the non-existing search paths

# Generated at 2022-06-20 13:40:58.138905
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()
    b_d = to_bytes(d, errors='surrogate_or_strict')
    expected_paths = [d]

    # Check that if we have the default collection path from the config file, it will still be returned
    default_coll_path = os.path.join(d, 'ansible_collections')
    b_default_coll_path = to_bytes(default_coll_path)
    os.makedirs(b_default_coll_path)
    assert list_valid_collection_paths() == expected_paths

    # Check that we return the collection path even if it doesn't have the 'ansible_collections' subdirectory

# Generated at 2022-06-20 13:41:11.376191
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # fixtures dir
    coll_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'lib', 'ansible_test', 'units')
    b_coll_root = to_bytes(coll_root)

    # test fixture dir
    test_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test')
    b_test_dir = to_bytes(test_dir)

    # tests
    collections = list_collection_dirs(search_paths=[coll_root])
    collections = list(collections)
    assert len(collections) == 3

# Generated at 2022-06-20 13:41:13.339034
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Tests for errors in function list_collection_dirs"""

    # TODO: test with a full collection path

# Generated at 2022-06-20 13:41:24.305780
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert ['a', 'b', 'c'] == list(list_valid_collection_paths(['a', 'b', 'c']))
    assert ['a', 'b', 'c'] == list(list_valid_collection_paths(['a', 'b', 'c', 'd', 'e']))
    assert ['a', 'c'] == list(list_valid_collection_paths(['a', 'b', 'c', 'd', 'e'], warn=False))



# Generated at 2022-06-20 13:41:32.060135
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    dir_paths = ['/tmp']
    temp_dir = tempfile.mkdtemp()

    display.verbosity = 4
    result = list_valid_collection_paths(dir_paths)
    assert (len(result) == 1)
    assert ('/tmp' in result)

    result = list_valid_collection_paths([temp_dir])
    assert (len(result) == 1)
    assert (temp_dir in result)

    shutil.rmtree(temp_dir)



# Generated at 2022-06-20 13:41:40.146936
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # invalid path
    invalid_path = "/tmp/this/directory/is/invalid"
    assert list_valid_collection_paths([invalid_path]) == []

    # valid path that ends in 'ansible_collections'
    coll_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'ansible_collections')
    assert list_valid_collection_paths([coll_root]) == [coll_root]

    # valid path that does not end in 'ansible_collections'
    coll_root = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..')

# Generated at 2022-06-20 13:42:48.629052
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test for function list_valid_collection_paths"""

    # test default
    paths = list(list_valid_collection_paths())
    assert paths, "paths is empty"

    # test with a single path
    paths = list(list_valid_collection_paths(["/tmp"]))
    assert len(paths) == 1, "paths wrong length"
    assert paths[0] == "/tmp", "path has wrong value"

    # test with multiple paths
    paths = list(list_valid_collection_paths(["/tmp", "/etc"]))
    assert len(paths) == 2, "paths wrong length"
    assert paths[0] == "/tmp", "path has wrong value"
    assert paths[1] == "/etc", "path has wrong value"



# Generated at 2022-06-20 13:42:58.018726
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os.path

    search_paths = [
        os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'collections', 'good_collections')),
    ]

    # test list all collections
    good_collections = [
        [os.path.join(path, 'ansible_collections', coll, collection) for collection in (
            'nested_namespace_collection',
            'namespace_collection')] for path in search_paths for coll in (
            'namespace1.collection1',
            'namespace2.collection2')]
    good_collections = [item for sublist in good_collections for item in sublist]

    results = list(list_collection_dirs(search_paths))

   

# Generated at 2022-06-20 13:43:06.330998
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    collection_path = '/collections/ansible_collections'
    collection_path_b = to_bytes(collection_path)
    assert list_valid_collection_paths([collection_path]) is not None
    assert list_valid_collection_paths(None) is not None
    assert list_valid_collection_paths([collection_path_b]) is not None
    assert list_valid_collection_paths(['fake/collections/ansible_collections']) is None

