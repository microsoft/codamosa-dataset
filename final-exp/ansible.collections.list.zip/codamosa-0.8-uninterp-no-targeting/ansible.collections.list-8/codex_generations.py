

# Generated at 2022-06-20 13:33:25.285530
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test the list_collection_dirs function
    """
    import tempfile
    import shutil
    import os
    import stat

    # create a placeholder collection

# Generated at 2022-06-20 13:33:37.572740
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # No search_paths, returns default_paths
    x = list(list_valid_collection_paths())
    assert len(x) == 2
    assert '.' in x
    assert '.ansible/collections' in x

    # Defined search paths that don't exist
    path1 = '/this/path/doesnt/exist'
    path2 = '/this/path/also/doesnt/exist'
    x = list(list_valid_collection_paths(search_paths=[path1, path2]))
    assert len(x) == 0

    # Defined search paths that exist but are not directories
    # (note: using /etc/hosts is considered safe because it is a file
    # that is known to exist on all platforms with valid permissions
    # for the test runner)

# Generated at 2022-06-20 13:33:47.455090
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function list_collection_dirs
    :return: success or failure
    """

    import os
    import shutil

    # return value
    retval = 0

    # create tempdir to write test collection
    tempdir_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tempdir')

    if not os.path.isdir(tempdir_path):
        os.mkdir(tempdir_path)

    # Create a test collection
    test_coll = os.path.join(tempdir_path, 'ansible_collections', 'test_ns', 'test_coll')

    if os.path.isdir(test_coll):
        shutil.rmtree(test_coll)
    os.makedirs(test_coll)

   

# Generated at 2022-06-20 13:33:53.537362
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    cpath = '/path/to/does_not/exist'
    paths = list_valid_collection_paths(search_paths=[], warn=False)
    assert cpath not in paths

    cpath = '/path/to/exists/but_is_file'
    paths = list_valid_collection_paths(search_paths=[], warn=False)
    assert cpath not in paths



# Generated at 2022-06-20 13:33:55.291796
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    if os.environ.get('TRAVIS_CI') is not None:
        return
    try:
        list(list_collection_dirs([]))
    except Exception as e:
        display.error('FAIL: %s' % e)

# Generated at 2022-06-20 13:34:05.386498
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    (handle, filename) = tempfile.mkstemp(prefix='ansible_collections')
    collection_dir = os.path.dirname(filename)


# Generated at 2022-06-20 13:34:13.080701
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp', '/tmp/ansible_collections']
    paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(paths) == 1

    search_paths = ['/tmp/ansible_collections', '/tmp']
    paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(paths) == 1

    search_paths = ['/tmp/ansible_collections', '/tmp']
    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(paths) == 1

    search_paths = []
    paths = list(list_valid_collection_paths(search_paths, warn=True))

# Generated at 2022-06-20 13:34:19.657652
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.path import unfrackpath
    from ansible.module_utils.six import PY2

    coll_path = unfrackpath('/foo/bar/baz')
    if PY2:
        coll_path = to_bytes(coll_path)

    list_of_paths = [coll_path]

    result = list_valid_collection_paths(search_paths=list_of_paths)

    assert next(result) == coll_path



# Generated at 2022-06-20 13:34:30.796412
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile

    # Generate the temp environment
    temp_env = tempfile.TemporaryDirectory()
    test_paths = [temp_env.name]

    # Create some directories
    os.makedirs(os.path.join(temp_env.name, 'ansible_collections', 'ansible', 'test'))
    os.makedirs(os.path.join(temp_env.name, 'ansible_collections', 'ansible', 'test2'))
    os.makedirs(os.path.join(temp_env.name, 'ansible_collections', 'test'))
    os.makedirs(os.path.join(temp_env.name, 'ansible_collections', 'test.test'))

    # Test search of all

# Generated at 2022-06-20 13:34:37.445024
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Searches for all collections in the supplied search_paths and asserts the directories found
    match the expected results.
    """
    tempdir = None

# Generated at 2022-06-20 13:34:48.569060
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs

    collection_path = '/var/lib/code'
    collections = list_collection_dirs([collection_path])

    assert list(collections) == []

    collection_path = '/var/lib/code/ansible_collections'
    collections = list_collection_dirs([collection_path])

    assert list(collections) == []



# Generated at 2022-06-20 13:35:00.447029
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import sys
    import shutil
    import tempfile

    b_test_dir = tempfile.mkdtemp(prefix='ansible_test_collections')
    collection_dirs = [
        tempfile.mkdtemp(prefix='mycoll1_', dir=b_test_dir),
        tempfile.mkdtemp(prefix='mycoll2_', dir=b_test_dir),
    ]
    for d in collection_dirs:
        # add temp plugin dirs
        tempfile.mkdtemp(prefix='test_', dir=d)
        # add temp meta dir
        tempfile.mkdtemp(prefix='ansible_galaxy_info_', dir=d)
        # add temp module_utils dir
        tempfile.mkdtemp(prefix='module_utils_', dir=d)

    test_paths

# Generated at 2022-06-20 13:35:11.421477
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = '/foo,/bar'
    assert list(list_valid_collection_paths(paths.split(','))) == ['/foo', '/bar']
    paths = '/foo,/bar,/baz'
    assert list(list_valid_collection_paths(paths.split(','))) == ['/foo', '/bar', '/baz']
    paths = '/persistent,/leaves,/dev,/etc,/tmp,/usr/share,/home,/opt,/var'
    assert list(list_valid_collection_paths(paths.split(','))) == [
        '/persistent', '/leaves', '/dev', '/usr/share', '/home', '/opt', '/var'
    ]

# Generated at 2022-06-20 13:35:24.222810
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile
    import shutil
    import sys

    coll_paths = []


# Generated at 2022-06-20 13:35:34.827407
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    bad_path = 'bad_path/does/not/exist'
    bad_path_dup = 'bad_path/does/not/exist'

    # invalid path, but not a duplicate
    paths = [bad_path]
    mylist = list(list_valid_collection_paths(paths, warn=True))
    assert not mylist

    # invalid path, but not a duplicate
    paths = [bad_path, bad_path_dup]
    mylist = list(list_valid_collection_paths(paths, warn=True))
    assert not mylist

    # invalid path, but not a duplicate
    generic_path = '/'
    paths = [bad_path, generic_path]
    mylist = list(list_valid_collection_paths(paths, warn=True))
    assert not mylist

# Generated at 2022-06-20 13:35:49.485824
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.ansible.plugins.loader import _load_collection_config
    from ansible.collections.ansible.plugins.loader import list_valid_collection_paths

    old_config = _load_collection_config()
    AnsibleCollectionConfig.collection_paths = []
    search_paths = [
        "/tmp/does_not_exist",
        "/etc/ansible/collections",
        "/tmp/A/B/C",
        "~/my_collections",
    ]
    result = list(list_valid_collection_paths(search_paths=search_paths))
    assert result == ["/etc/ansible/collections", "~/my_collections"]

    # restore config
    AnsibleCollectionConfig.load_configuration_definitions(old_config)




# Generated at 2022-06-20 13:35:51.810251
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == list(AnsibleCollectionConfig.collection_paths)



# Generated at 2022-06-20 13:35:58.618020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    from ansible.collections.ansible.tests.unit.utils.test_data import ANSIBLE_COLLECTIONS_PATH
    from ansible.collections.ansible.tests.unit.utils.test_data import ANSIBLE_COLLECTIONS_DIR
    from ansible.collections.ansible.tests.unit.utils.test_data import ANSIBLE_COLLECTION

    # Test with single collection, one namespace, multiple collections
    temp_dir_1 = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir_1, ANSIBLE_COLLECTIONS_DIR, 'ansible', ANSIBLE_COLLECTION))

# Generated at 2022-06-20 13:36:04.431267
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list_collection_dirs(['test/utils/unittests_collections_dir'],
                                           'myns.mycoll')
    count = 0
    for collection_dir in collection_dirs:
        count += 1
        assert os.path.isdir(collection_dir)
    assert count == 1

# Generated at 2022-06-20 13:36:14.658028
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Unit test for function list_valid_collection_paths"""

    paths = ('/tmp', '/tmp/ansible_collections')
    results = list(list_valid_collection_paths(paths))
    assert len(results) == 1
    # returns the path that exists
    assert len(results[0]) == len(paths[1])

    import tempfile
    prefix = os.path.dirname(os.path.dirname(__file__))
    prefix = os.path.dirname(prefix)
    d = tempfile.TemporaryDirectory(prefix=prefix, suffix='.collections')
    results = list(list_valid_collection_paths([d.name]))
    assert len(results) == 1
    # returns the path that exists
    assert len(results[0]) == len(d.name)


# Generated at 2022-06-20 13:36:28.947289
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ["bad/path", "/root", "root", '/tmp', '/not_a_dir']

    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(valid_paths) == 2
    assert set(valid_paths) == {'/root', '/tmp'}

    valid_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(valid_paths) == 2
    assert set(valid_paths) == {'/root', '/tmp'}

    valid_paths = list(list_valid_collection_paths(None, warn=True))
    assert valid_paths
    asse

# Generated at 2022-06-20 13:36:40.415526
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = ['test/unit/utils/collection_loader/test_collections']
    coll_filter = 'test_ns.test_coll'
    # full list of expected results

# Generated at 2022-06-20 13:36:43.496655
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp/fake_dir', '/tmp'])) == ['/tmp']
    assert list(list_valid_collection_paths(['/tmp/fake_dir', '/tmp'], warn=True)) == ['/tmp']

# Generated at 2022-06-20 13:36:49.342312
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # we should have at least one valid path
    assert next(list_valid_collection_paths(search_paths=None), False)

    # check for being robust to empty search paths
    assert next(list_valid_collection_paths(search_paths=[]), False)

    # check that we can even find a default path when given invalid paths
    assert next(list_valid_collection_paths(search_paths=['/no/such/directory']), False)

# Generated at 2022-06-20 13:36:56.244479
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp', '/usr/local/lib/ansible/collections', '~/ansible/']
    search_paths = list_valid_collection_paths(search_paths)
    assert os.path.expanduser('~/ansible/') in search_paths
    assert '/usr/local/lib/ansible/collections' in search_paths
    assert '/tmp' not in search_paths

# Generated at 2022-06-20 13:37:06.665132
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    # test single/multiple search paths
    with tempfile.TemporaryDirectory(prefix='ansible_test_collections') as temp_dir:

        data_path = os.path.join(temp_dir, "data")
        os.makedirs(data_path)
        with open(os.path.join(data_path, 'collection_config.json'), 'w') as f:
            f.write('{}')

        col_path = os.path.join(temp_dir, "collections")
        os.makedirs(col_path)
        ns_path = os.path.join(col_path, "namespace")
        os.makedirs(ns_path)

# Generated at 2022-06-20 13:37:14.610978
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Validate that the function is returning the expected list when passed
    a list of paths.
    :return: None
    """
    # Test with an empty list
    assert list(list_valid_collection_paths([])) == []

    # Test with a list containing invalid paths, None and empty strings
    assert list(list_valid_collection_paths(['/invalid/path', None, ''])) == []

    # Test with a list containing a single valid path
    assert list(list_valid_collection_paths(['.'])) == ['.']

    # Test with a list containing multiple valid paths
    result = list(list_valid_collection_paths(['.', './library', './plugins/modules']))
    assert len(result) == 3
    assert '.' in result

# Generated at 2022-06-20 13:37:20.507924
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['_'] = lambda x: x

    # only one path so easier to test
    search_path = tempfile.mkdtemp()
    os.mkdir(os.path.join(search_path, 'ansible_collections'))

    def create_structure(base, structure):
        """
        Allows us to create a structure of dirs/files for testing
        :param base: base directory to work from
        :param structure: list of dirs/files to create, dir will be created with a dummy file
        """

        # ensure structure is respected otherwise tests could fail
        total = len(structure)

# Generated at 2022-06-20 13:37:30.935204
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils._text import to_text
    from ansible.module_utils._text import to_bytes
    import tempfile
    from shutil import rmtree
    from ansible.module_utils.common.collections import ansible_collections_path

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Add a non-existent path
    paths = [tmpdir + '/foo']

    # Add a non-directory path
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    try:
        os.close(fd)
        paths.extend([fname])
    finally:
        os.unlink(fname)

    # Add an existing collection path

# Generated at 2022-06-20 13:37:36.378025
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # TODO: create test_data for unicode paths
    #test_paths = [u'test_1', u'test_2']

    test_paths = ['test_1', 'test_2']

    # TODO: create fake os.path.exists() and check results with groups
    # create_fake_returnvalues(os.path.exists, [True, True])
    #assert list_valid_collection_paths(test_paths) == [True, True]

    # TODO: create fake os.path.exists() and check results with groups
    # create_fake_returnvalues(os.path.isdir, [True, False])
    #assert list_valid_collection_paths(test_paths, warn=True) == [True, False]

    # TODO: create fake os.path.

# Generated at 2022-06-20 13:37:47.474600
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(search_paths=['/tmp/doesnotexist', '/tmp/doesnotexist2'])) == []
    assert list(list_valid_collection_paths(search_paths=[os.getcwd()])) == [os.getcwd()]

# Generated at 2022-06-20 13:37:56.115564
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Unit test for function list_collection_dirs
    '''
    # pylint: disable=unused-argument
    def mock_listdir(dirname):
        '''
        Mock os.listdir() function
        '''
        return ['test_col1', 'test_col2']

    import ansible.module_utils.collections_loader
    from unittest.mock import patch
    with patch('ansible.module_utils.collections_loader.os.listdir', side_effect=mock_listdir):
        results = list(ansible.module_utils.collections_loader.list_collection_dirs(['test_coll_path']))

# Generated at 2022-06-20 13:38:06.744403
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # path "abc" is not existing
    search_paths = ['abc', '/etc/ansible']
    result = ["/etc/ansible"] # on MacOS, result is "/usr/local/etc/ansible"
    assert list(list_valid_collection_paths(search_paths)) == result

    # no path is pass
    result = AnsibleCollectionConfig.collection_paths # on MacOS, result is ["/usr/local/etc/ansible"]
    assert list(list_valid_collection_paths()) == result

    # "abc" is a file, not a directory
    search_paths = ['abc', '/etc/ansible']
    result = AnsibleCollectionConfig.collection_paths # on MacOS, result is ["/usr/local/etc/ansible"]

# Generated at 2022-06-20 13:38:19.993682
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test list_valid_collection_paths with several parameters
    """
    test_path = os.path.join(os.path.expandvars('$HOME'), 'ansible_collections_test')
    os.mkdir(test_path)
    os.mkdir(os.path.join(os.path.expandvars('$HOME'), 'ansible_collections_test2'))

    result = list(list_valid_collection_paths(search_paths=[None, test_path, '~/ansible_collections_test2/']))
    assert len(result) == 3, "Unexpected number of paths on result"

    result = list(list_valid_collection_paths(search_paths=[None, test_path, '/invalid_path']))

# Generated at 2022-06-20 13:38:24.241504
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with single string
    search_path = "/some/path"
    coll_filter = "namespace.coll"
    actual_return = list_collection_dirs(search_path, coll_filter)
    result_list = [coll_filter]
    assert len(list(actual_return)) == 1

# Generated at 2022-06-20 13:38:27.041481
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list(list_collection_dirs()))



# Generated at 2022-06-20 13:38:39.152313
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_root = '/tmp/ansible_collections'
    os.makedirs(collection_root)
    os.makedirs(os.path.join(collection_root, 'ansible_namespace'))
    os.makedirs(os.path.join(collection_root, 'ansible_namespace', 'collection1'))
    os.makedirs(os.path.join(collection_root, 'ansible_namespace', 'collection2'))
    os.makedirs(os.path.join(collection_root, 'another_ansible_namespace'))
    os.makedirs(os.path.join(collection_root, 'another_ansible_namespace', 'collection3'))

# Generated at 2022-06-20 13:38:48.678547
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # purposely pass a non-existent path, should return an empty list
    assert [] == list(list_valid_collection_paths(['/var/lib/new_path1', '/var/lib/new_path2'], warn=True))

    # purposely pass a file as a path, should return an empty list
    assert [] == list(list_valid_collection_paths(['/var/lib/my_path/my_file.yml'], warn=True))

# Generated at 2022-06-20 13:38:58.215720
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from os import path, mkdir, utime
    from tempfile import mkdtemp
    from shutil import rmtree

    assert path is not None
    assert mkdir is not None
    assert utime is not None
    assert mkdtemp is not None
    assert rmtree is not None


# Generated at 2022-06-20 13:39:10.887403
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(path, '..', '..', '..', '..', 'collections', 'ansible_collections')
    display.debug(path)
    coll_dirs = list_collection_dirs([path])
    assert 'ansible.netcommon' in [os.path.basename(x) for x in coll_dirs]
    assert 'ansible.netcommon.nxos' in [os.path.basename(x) for x in coll_dirs]
    assert 'ansible.netcommon.nxos.plugins.modules.network' in [os.path.basename(x) for x in coll_dirs]

# Generated at 2022-06-20 13:39:20.553824
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_path = os.path.dirname(os.path.abspath(__file__))
    valid_paths = [os.path.join(test_path, 'data/collections')]
    expected = {'namespace': {'name': os.path.join(valid_paths[0], 'namespace/name/')}}
    result = dict(list_collection_dirs(valid_paths, 'namespace.name'))
    assert result == expected



# Generated at 2022-06-20 13:39:32.061626
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/tmp', '/tmp/foo']
    valid_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert '/tmp' in valid_paths and '/tmp/foo' in valid_paths

    # ensure that defaults are always used
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert '/tmp' in valid_paths and '/tmp/foo' in valid_paths and '/usr/share/ansible/collections' in valid_paths

    # ensure that no duplicate paths are returned
    search_paths = ['/tmp', '/tmp/foo', '/tmp']
    valid_paths = list(list_valid_collection_paths(search_paths))
    assert len(valid_paths) == 3

# Generated at 2022-06-20 13:39:46.235089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = '/home/user/collections'
    namespace = 'ansible_namespace'
    collection = 'test_collection'
    full_path = '%s/ansible_collections/%s/%s' % (path, namespace, collection)

    assert list(list_collection_dirs(search_paths=[path], coll_filter=namespace)) == []
    assert list(list_collection_dirs(search_paths=[path], coll_filter=namespace + '.' + collection)) == []

    assert list(list_collection_dirs(search_paths=[full_path], coll_filter=None)) == [full_path]
    assert list(list_collection_dirs(search_paths=[full_path], coll_filter=namespace)) == [full_path]

# Generated at 2022-06-20 13:39:52.651378
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.galaxy.collection import list_collection_dirs

    search_path = ['test/data/collections']
    coll = list_collection_dirs(search_path)
    result = ['/test/data/collections/ansible_collections/namespace1/collection1', '/test/data/collections/ansible_collections/namespace2/collection2']

    assert ''.join(coll) == ''.join(result)

# Generated at 2022-06-20 13:39:57.199863
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    test function list_valid_collection_paths
    """
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    path = os.path.join(tempdir, 'foo.txt')
    with tempfile.NamedTemporaryFile(dir=tempdir, delete=False, mode='w'):
        pass

    tmpfile = os.path.join(tempdir, 'foo.txt')
    tmpdir = os.path.join(tempdir, 'bar')
    os.mkdir(tmpdir)

    search_paths = [
        path,
        tmpdir,
        'bar',
        'baz',
    ]

    assert list(list_valid_collection_paths(search_paths)) == [tmpdir]
    shutil.rmtree

# Generated at 2022-06-20 13:40:07.000472
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    test_path = tempfile.mkdtemp()


# Generated at 2022-06-20 13:40:14.336434
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for function list_collection_dirs. This function only return
    valid collection paths.
    """

    assert list_collection_dirs() == list(list_collection_dirs(None, None))
    assert list_collection_dirs(search_paths=["/usr/share/ansible/collections"]) == list(list_collection_dirs(None, None))
    assert list(list_collection_dirs(search_paths=['/usr/share/ansible/collections',
                                                   '/usr/local/share/ansible/collections'],
                                     coll_filter='aws')) == list(list_collection_dirs(coll_filter='aws'))

# Generated at 2022-06-20 13:40:25.541720
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    import subprocess

    collection_path1 = None

# Generated at 2022-06-20 13:40:33.347075
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import mock
    import re

    import sys

    # We need to mock open in order to pretend we have a config file
    # and a collections dir. Otherwise, this is the same as the real
    # list_collection_dirs, except it only returns the absolute path
    # to the collection.
    if sys.version_info[0] == 2:
        mock_open = '__builtin__.open'
    else:
        mock_open = 'builtins.open'


# Generated at 2022-06-20 13:40:40.030455
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        "not-a-valid-path",
        "./non-existing-dir",
        "./lib/ansible/config/data/",
    ]
    # Expected result should be last element which is a valid collection dir
    expected = [
        "./lib/ansible/config/data/",
    ]
    result = list(list_valid_collection_paths(search_paths, True))
    assert result == expected

# Generated at 2022-06-20 13:40:54.565457
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_paths = list(list_valid_collection_paths(["/tmp", "/does/not/exist"]))
    assert len(b_paths) == 1
    assert b_paths[0] == "/tmp"

# Generated at 2022-06-20 13:41:03.588008
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import list_collection_dirs

    coll_paths = list()
    coll_paths.append(AnsibleCollectionConfig.DEFAULT_COLLECTIONS_PATHS[0])
    coll_paths.append(AnsibleCollectionConfig.DEFAULT_COLLECTIONS_PATHS[1])
    coll_paths.append('/invalid/path')
    coll_paths.append(os.path.dirname(__file__))

    # Return all collections from test directory
    coll_dirs = list(list_collection_dirs(coll_paths, None))
    assert len(coll_dirs) == 1

# Generated at 2022-06-20 13:41:15.032626
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_root = to_bytes(os.path.join(os.path.dirname(__file__), 'data', 'collections_one'))
    coll_root = os.path.join(os.path.dirname(__file__), 'data', 'collections_one')
    for cd in list_collection_dirs(['does-not-exist', coll_root]):
        assert cd == to_bytes(os.path.join(coll_root, 'ansible_collections', 'test', 'mytest'))
    for cd in list_collection_dirs(['does-not-exist', coll_root], 'test'):
        assert cd == to_bytes(os.path.join(coll_root, 'ansible_collections', 'test', 'mytest'))

# Generated at 2022-06-20 13:41:20.524007
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)

    nope_paths = ['/testing/nope', '<script>alert("xss")</script>']
    assert list(list_valid_collection_paths(nope_paths)) == list(AnsibleCollectionConfig.collection_paths)

    # default collection paths still there
    nope_paths = ['/testing/nope', '<script>alert("xss")</script>', './testing/nope']
    assert list(list_valid_collection_paths(nope_paths)) == list(AnsibleCollectionConfig.collection_paths)

    # we got a path
    real_paths = ['./testing/nope', '/testing', '/testing/nope']
   

# Generated at 2022-06-20 13:41:27.212760
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # create temporary paths to mimic typical collection layout
    coll_dirs = [
        '/not/a/collection/dir',
        '/also/not/a/coll/',
        '/my/tmp/ansible_collections/ns1',
        '/my/tmp/ansible_collections/ns1/coll1',
        '/my/tmp/ansible_collections/ns1/coll2',
        '/my/tmp/ansible_collections/ns2',
        '/my/tmp/ansible_collections/ns2/coll1',
        '/my/tmp/ansible_collections/ns2/coll2',
    ]
    for mydir in coll_dirs:
        os.makedirs(mydir)

    search_paths = ['/my/tmp']

    # test with no namespace or collection filter
   

# Generated at 2022-06-20 13:41:36.614176
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Make sure the collection paths are filtered correctly. """
    # Tests based on current working directory. If in near future
    # we don't want to depend on working directory, we can change
    # the cwd to something else in tests.
    cwd = os.getcwd()
    tmp_collection_path = os.path.join(cwd, 'tmp_collection')
    non_existing_path = os.path.join(cwd, 'non_existing_path')
    non_directory_path = '/etc/passwd'

    input_paths = [cwd, tmp_collection_path, non_existing_path, non_directory_path]
    expected_output_paths = [cwd]

    output = list(list_valid_collection_paths(input_paths, warn=False))

    assert output == expected_output

# Generated at 2022-06-20 13:41:48.475216
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    valid_paths = ['foo', 'bar']
    b_valid_paths = [to_bytes(p, errors='surrogate_or_strict') for p in valid_paths]
    with tempfile.TemporaryDirectory() as tmp:
        invalid_path = os.path.join(tmp, 'does_not_exist')
        search_paths = [invalid_path] + valid_paths

        no_dirs = list(list_collection_dirs(search_paths=search_paths))
        assert no_dirs == []
        for coll_dir in b_valid_paths:
            os.makedirs(os.path.join(coll_dir, 'ansible_collections', 'test_namespace', 'test_collection'))


# Generated at 2022-06-20 13:42:01.407454
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    This function is used to test the list_collection_dirs function.
    :return:
    '''
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a nested collection
    collection_root = os.path.join(tmpdir, 'ansible_collections')
    os.makedirs(collection_root)

    os.makedirs(os.path.join(collection_root, 'namespace'))
    os.makedirs(os.path.join(collection_root, 'namespace', 'collection'))
    os.makedirs(os.path.join(collection_root, 'namespace', 'collection', 'plugins'))

    # Test list_collection_dirs
    collection_dirs = list

# Generated at 2022-06-20 13:42:11.401179
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils import basic

    # Configure new search paths
    test_path = os.path.join(basic.AnsibleModule.fetch_asset('test'), 'valid_collection_paths_test')

    # path1: non-existing
    path1 = os.path.join(test_path, 'not_there')

    # path2: file, not a directory
    path2 = basic.AnsibleModule.fetch_asset('test', os.path.join('valid_collection_paths_test', 'not_a_dir'))

    # path3: existing, empty directory
    path3 = os.path.join(test_path, 'empty_dir')

    # path4: existing, non-empty directory

# Generated at 2022-06-20 13:42:16.768418
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = 'test.test-pool'
    assert list_collection_dirs(None, coll_filter)
    coll_filter = ['test.test-pool']
    assert list_collection_dirs(None, coll_filter)
    coll_filter = ''
    assert list_collection_dirs(None, coll_filter)
    coll_filter = None
    assert list_collection_dirs(None, coll_filter)

# Generated at 2022-06-20 13:42:43.861429
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    # check both Linux and Windows paths
    actual_paths = list(list_valid_collection_paths(search_paths=[os.path.join('/my/path/to', 'collections'),
                                                                  os.path.join('C:', 'my', 'path', 'to', 'collections')]))
    expected_paths = [os.path.join('/my/path/to', 'collections'),
                      os.path.join('C:', 'my', 'path', 'to', 'collections')]
    error_msg = "Output of list_valid_collection_paths is %s, should be %s"

# Generated at 2022-06-20 13:42:53.146873
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys


# Generated at 2022-06-20 13:42:58.830291
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import sys
    import tempfile

    paths = (
        os.path.join(sys.prefix, 'share', 'ansible'),
        '/bogus/path',
        tempfile.gettempdir()
    )

    # create temp dir so it exists for testing negative
    tmp_path = tempfile.mkdtemp()

    # create temp file as another negative test
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_path)

    # add to test paths
    paths += (tmp_file.name, tmp_path)

    for path in list_valid_collection_paths(search_paths=paths, warn=True):
        assert os.path.exists(path)

    # test without warnings

# Generated at 2022-06-20 13:43:06.527103
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/invalid', '/invalid2']) is not None
    assert list_valid_collection_paths(['/invalid', '/invalid2']) == []
    assert list_valid_collection_paths(['/etc', '/var/lib']) is not None
    assert list_valid_collection_paths(['/etc', '/var/lib']) == ['/etc', '/var/lib']


# Generated at 2022-06-20 13:43:12.819808
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test no search_paths
    paths = list_valid_collection_paths()
    assert '/home/user/.ansible/collections' in paths

    # Test search path
    paths = list_valid_collection_paths(search_paths=['/tmp'])
    assert '/tmp' in paths

    # Test skipping missing path in search paths
    paths = list_valid_collection_paths(search_paths=['/tmp','/missing'])
    assert '/tmp' in paths
    assert '/missing' not in paths

    # Test search path overrides default
    paths = list_valid_collection_paths(search_paths=['/tmp','/tmp2'])
    assert '/home/user/.ansible/collections' not in paths

    # Test skipping invalid existing path in search paths