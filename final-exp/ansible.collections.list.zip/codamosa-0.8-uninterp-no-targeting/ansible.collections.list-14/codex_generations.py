

# Generated at 2022-06-20 13:33:23.535365
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_dirs = list(list_collection_dirs(search_paths=[os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'test', 'data', 'collections')],
                                                coll_filter='test_namespace.test_collection'))
    assert len(collection_dirs) == 1
    assert os.path.basename(collection_dirs[0]) == 'test_collection'

# Generated at 2022-06-20 13:33:37.491808
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile, shutil, os
    from ansible.config.collection_loader import list_collection_dirs

    tmpdir = tempfile.mkdtemp()

    coll_dir_a = os.path.join(tmpdir, 'ansible_collections', 'a', 'b')
    coll_dir_b = os.path.join(tmpdir, 'ansible_collections', 'c', 'd')
    coll_dir_c = os.path.join(tmpdir, 'ansible_collections', 'e', 'f')
    os.makedirs(coll_dir_a)
    os.makedirs(coll_dir_b)
    os.makedirs(coll_dir_c)

    a = list_collection_dirs([tmpdir])
    assert len(a) == 3

    b = list

# Generated at 2022-06-20 13:33:46.652517
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_collection_paths
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    test_paths = [
        os.path.join(os.getcwd(), 'library'),
        AnsibleCollectionConfig.default_collection_paths[0]
    ]

    valid_paths = list(list_valid_collection_paths(search_paths=test_paths))

    # list_valid_collection_paths should return only one path
    assert len(valid_paths) == 1

    # That one path is the one that is valid
    assert valid_paths[0] == AnsibleCollectionConfig.default_collection_paths[0]

# Generated at 2022-06-20 13:33:57.876663
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-20 13:33:58.647064
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-20 13:34:05.168337
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ["/usr/lib/place/to/look", "/usr/lib/place/to/look2"]

    found_paths = list_valid_collection_paths(search_paths, warn=True)

    assert len(found_paths) == 0

    search_paths = ["/usr", "/usr"]

    found_paths = list_valid_collection_paths(search_paths, warn=True)

    assert len(found_paths) == 2



# Generated at 2022-06-20 13:34:10.928820
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([os.path.join("path", "does", "not", "exist")]) == []
    assert list_valid_collection_paths([os.path.join("path", "does", "not", "exist"),
                                        os.path.join("path", "does", "exist")]) == [os.path.join("path", "does", "exist")]


# Generated at 2022-06-20 13:34:19.637375
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Ansible is not guaranteed to be installed, we can fake it
    import sys

    test_lib_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'unit', 'lib')
    sys.path.append(test_lib_path)
    from test_utils.shim_ansible import Main

    from ansible.utils.path import unfrackpath

    fake_main = Main()
    fake_main.args = fake_main.parse()
    fake_main.args.list_collections = True

    plugin_vars = {'ANSIBLE_COLLECTIONS_PATHS': [unfrackpath(test_lib_path)]}
    fake_main.set_collection_paths(plugin_vars)


# Generated at 2022-06-20 13:34:26.072386
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    d = tempfile.mkdtemp()
    assert list(list_collection_dirs([d])) == []
    os.makedirs(os.path.join(d, 'ansible_collections', 'ns', 'coll'))
    assert list(list_collection_dirs([d])) == [os.path.join(d, 'ansible_collections', 'ns', 'coll')]

# Generated at 2022-06-20 13:34:34.553419
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    def make_temp_tree(tree):
        """
        Build a temp tree and return path to the root
        :param tree: nested dictionary of keys being directories and values being files or further nested dictionaries
        :return: string
        """

        tmpdir = tempfile.mkdtemp()

        for d in tree:

            if isinstance(tree[d], dict):
                path = os.path.join(tmpdir, d)
                os.mkdir(path)
                make_temp_tree(tree[d], path)
            else:
                fh = open(os.path.join(tmpdir, tree[d]), 'w')
                fh.write('test')
                fh.close()

        return to_bytes(tmpdir)

    # Make a temp dir and add a tree matching

# Generated at 2022-06-20 13:34:53.209852
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        '/this',
        '/that/does/not/exist',
        '/nor/this',
        '/this/exists/but/has/no/collections',
    ]

    # expect warning on missing
    paths = [p for p in list_valid_collection_paths(paths, warn=True)]
    assert len(paths) == 0

    paths = [
        '/usr/share/ansible/yer',
        '/usr/share/ansible/yo',
        '/usr/share/ansible/collections',
        '/usr/share/ansible/collections/bad/collection',
    ]

    # expect no warning on defaults and bad collections
    paths = [p for p in list_valid_collection_paths(warn=True)]
    assert len(paths) == 2

    # expect no

# Generated at 2022-06-20 13:35:03.843286
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections_paths = [
        '/path/to/collections1/ansible_collections',
        '/path/to/collections2/ansible_collections',
    ]


# Generated at 2022-06-20 13:35:04.402173
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-20 13:35:13.722693
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native

    # create temporary collection dir and nested dirs
    colldir = tempfile.mkdtemp()
    os.makedirs(os.path.join(colldir, 'ansible_collections', 'namespace1', 'my_collection'))
    os.makedirs(os.path.join(colldir, 'ansible_collections', 'namespace2', 'my_collection2'))
    os.makedirs(os.path.join(colldir, 'ansible_collections', 'namespace3', 'my_collection3'))

    # list_collections should return all collection paths

# Generated at 2022-06-20 13:35:17.556491
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = list()
    test_paths.append(os.path.join(os.getcwd(), ''))
    result = list_collection_dirs(test_paths)
    assert result, 'no collections found'
    result = list(result)
    assert len(result) > 0, 'no collections found'

# Generated at 2022-06-20 13:35:26.846922
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import sys

    # create a test collection

    namespace = 'mynamespace'
    collection = 'mycollection'

    dir_path = tempfile.mkdtemp(prefix='ansible_tests_')

    collection_path = os.path.join(dir_path, 'ansible_collections', namespace, collection)

    os.makedirs(collection_path)

    print("Created test collection in %s" % collection_path)

    # find it with the list_collection_dirs function
    found = False
    for coll_path in list_collection_dirs(search_paths=[dir_path], coll_filter=None):

        if coll_path == collection_path:
            found = True
            break


# Generated at 2022-06-20 13:35:36.256130
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test1 = '/tmp/someplace/ansible_collections/myns/mycoll'
    test2 = '/tmp/someplace/ansible_collections/myns/mycoll_again'
    test3 = '/tmp/someplace/ansible_collections/anotherns/anothercoll'


# Generated at 2022-06-20 13:35:44.465444
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test
    """

    dirs = list_collection_dirs()
    assert len(list(dirs)) > 0

    #
    # This can be used to manually test finding collections in odd paths
    #
    # import sys
    # dirs = list_collection_dirs(search_paths=[sys.executable])
    # print('\n'.join(dirs))

# Generated at 2022-06-20 13:35:54.140967
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # generate paths for some fake collections
    tmpdir = "/tmp/ansible_test_collections"
    collection_paths = [
        os.path.join(tmpdir, "namespace_coll"),
        os.path.join(tmpdir, "namespace2.collection2"),
        os.path.join(tmpdir, "namespace2.collection_does_not_exist"),
        os.path.join(tmpdir, "namespace_does_not_exist"),
        os.path.join(tmpdir, "namespace2.collection3"),
    ]

    # Create a collections directory structure
    for collection_path in collection_paths:
        os.makedirs(collection_path)

    # Test function list_collection_dirs

# Generated at 2022-06-20 13:36:06.529876
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Verify that list_collection_dirs returns list of existing collection directories
    """
    from ansible.utils.path import unfrackpath
    # test against path that exists
    collection_path = [unfrackpath(__file__)]
    existing_coll = [x for x in list_collection_dirs(collection_path)]
    assert existing_coll == [b'/usr/share/ansible/collections/ansible_collections/ansible/builtin']

    # test against path that does not exist
    collection_path = ['/remote_dir/does_not_exist']
    missing_coll = [x for x in list_collection_dirs(collection_path)]
    assert not missing_coll

    # test collection filter
    collection_path = [unfrackpath(__file__)]

# Generated at 2022-06-20 13:36:19.096219
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test case with valid and invalid search_paths
    search_paths = ['/valid/path', '/invalid/path', './invalid/path/2']
    valid = list(list_valid_collection_paths(search_paths))

    assert(valid == ['/valid/path'])

    # Test case with no search_paths
    valid = list(list_valid_collection_paths())
    assert(valid == [])

# Generated at 2022-06-20 13:36:28.133611
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        "/tmp/does-not-exist",
        "",
        "./",
        "/tmp",
        "/etc/yum.repos.d",
        "./tests/data/modules",
    ]
    expected = [
        "./",
        "/etc/yum.repos.d",
        "./tests/data/modules",
    ]
    for p in list_valid_collection_paths(paths):
        assert p in expected
    assert list_valid_collection_paths(paths) == expected
    assert len(list_valid_collection_paths(paths)) == 3

# Generated at 2022-06-20 13:36:39.877621
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os.path
    import tempfile
    import shutil

    # Create a test collection directory
    tmpdir = tempfile.mkdtemp()
    coll_root = os.path.join(tmpdir, 'ansible_collections')
    with open(os.path.join(coll_root, 'ns1.coll1', '__init__.py'), 'w'):
        pass
    with open(os.path.join(coll_root, 'ns1.coll2', '__init__.py'), 'w'):
        pass
    with open(os.path.join(coll_root, 'ns2.coll1', '__init__.py'), 'w'):
        pass

# Generated at 2022-06-20 13:36:49.571208
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    ''' Test valid collection paths returned '''

    import tempfile

    # create a tempfile to test
    test_file = tempfile.mktemp()
    # create a tempfile to test
    test_file_not_exists = tempfile.mktemp()
    # create a tempfile and directory to test
    test_file_is_dir = tempfile.mktemp()
    os.mkdir(test_file_is_dir)

    paths = ['/foo', '/bar', test_file, test_file_not_exists, test_file_is_dir]

    expected_paths = ['/foo', '/bar', test_file, test_file_is_dir]
    actual_paths = list_valid_collection_paths(paths)


# Generated at 2022-06-20 13:36:56.567447
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert 'my/collection/path' not in list(list_valid_collection_paths(['my/collection/path']))
    assert 'my/collection/path' not in list(list_valid_collection_paths(['my/collection/path', '/tmp/collections']))
    assert 'my/collection/path' in list(list_valid_collection_paths(['/tmp/collections', 'my/collection/path']))

# Generated at 2022-06-20 13:37:06.797474
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(search_paths=[u'.'])) == []
    assert list(list_collection_dirs(search_paths=[u'./test/data'], coll_filter='test')) == [b'test/data/ansible_collections/test/test']
    assert list(list_collection_dirs(search_paths=[u'./test/data'], coll_filter='test.test')) == [b'test/data/ansible_collections/test/test']
    assert list(list_collection_dirs(search_paths=[u'./test/data'], coll_filter='test.not')) == []
    assert list(list_collection_dirs(search_paths=[u'./test/data'], coll_filter='not')) == []

# Generated at 2022-06-20 13:37:11.269169
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = ['/usr/share/ansible/collections']

    assert list_valid_collection_paths(['/usr/share/ansible/collections', '/does/not/exist']) == expected
    assert list_valid_collection_paths(['/does/not/exist', '/usr/share/ansible/collections']) == expected



# Generated at 2022-06-20 13:37:15.901303
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for d in list_collection_dirs(search_paths=["../"]):
        print(d)

# Generated at 2022-06-20 13:37:26.637951
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test case when search_paths is None
    search_paths = None
    list_collection_dirs_return = list_collection_dirs(search_paths)
    assert list_collection_dirs_return

    # test case when search_paths is not None
    search_paths = ["/etc/my_path"]
    list_collection_dirs_return = list_collection_dirs(search_paths)
    assert list_collection_dirs_return



# Generated at 2022-06-20 13:37:37.621044
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import shutil
    import tempfile
    import tempfile

    tmp_dir = tempfile.mkdtemp()

    sub_dirs = []
    for sub_dir in ('ansible_collections/mazer_test/one/',
                    'collection/ansible_collections/mazer_test/two/',
                    'ansible_collections/ansible_namespace/three'):
        sub_dirs.append(tempfile.mkdtemp(prefix=os.path.join(tmp_dir, sub_dir)))

    # test non-existent path
    assert list(list_collection_dirs(search_paths=['/i_dont/exist/path'])) == []

    # test invalid path
    assert list(list_collection_dirs(search_paths=['/etc'])) == []

    # test

# Generated at 2022-06-20 13:37:55.839957
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Ensures list_collection_dirs is returning
    the correct output
    """

    from ansible_collections.ansible.community.tests import test_data
    from galaxy_test.utils import create_collection

    test_paths = test_data.DATA_DIR
    test_coll_name = 'test_namespace.test_collection'
    test_coll_path = os.path.join(test_paths, 'ansible_collections', 'test_namespace', 'test_collection')
    test_coll_path2 = os.path.join(test_paths, 'ansible_collections', 'test_namespace', 'test_collection2')

    create_collection(test_coll_name, collection_path=test_paths)

# Generated at 2022-06-20 13:38:05.338959
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert set([]) == set(list_valid_collection_paths(["test_empty"]))
    assert set([]) == set(list_valid_collection_paths(["test_empty", "test_dir"]))
    assert set([]) == set(list_valid_collection_paths(["test_empty", "test_file"]))
    assert set(["test_dir"]) == set(list_valid_collection_paths(["test_empty", "test_dir", "test_file"]))
    assert set(["test_dir"]) == set(list_valid_collection_paths(["test_empty", "test_dir", "test_dir"]))

# Generated at 2022-06-20 13:38:09.425130
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/does/not/exist/at/all', '/this/exists/but/is/not/a/dir']

    config = AnsibleCollectionConfig.load_config()
    config['collection_paths']['foo'] = search_paths[0]
    config['collection_paths']['bar'] = search_paths[1]
    with AnsibleCollectionConfig._use_temp_config(config):

        # Removing the first path (the one that doesn't exist) and changing the
        # second one to a valid path.
        search_paths[1] = os.path.dirname(os.path.realpath(__file__))

        # Calling list_valid_collection_paths() without passing search_paths
        # will load the default paths from AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-20 13:38:20.193320
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys

    # create a temp collection directory
    search_path = tempfile.mkdtemp()
    coll_dir = os.path.join(search_path, "ansible_collections", "namespace1", "collection1")
    pkg_dir = os.path.join(coll_dir, "plugins", "my_plugin")
    os.makedirs(pkg_dir)
    open(os.path.join(pkg_dir, "__init__.py"), 'a').close()
    AnsibleCollectionConfig.local_collection_paths = [search_path]

    # assert the dir is returned in the list of paths
    #
    collection_dirs = list_collection_dirs(search_paths=[search_path])

# Generated at 2022-06-20 13:38:24.897440
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test that we can pass a list of paths to search_paths
    search_paths = ['/tmp/first', '/tmp/second']
    valid_paths = list(list_valid_collection_paths(search_paths=search_paths, warn=False))
    assert len(search_paths) == len(valid_paths)
    assert search_paths == valid_paths

# Generated at 2022-06-20 13:38:31.573999
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert len(list(list_valid_collection_paths(search_paths=['/foo/bar']))) == 0

    test_collection_path = os.path.join(os.path.dirname(__file__), 'test_collections')
    valid_paths = list_valid_collection_paths(search_paths=[test_collection_path])
    assert len(list(valid_paths)) == 1
    assert valid_paths[0] == test_collection_path



# Generated at 2022-06-20 13:38:40.357764
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test: default search path, no warning
    test_valid_path_list = list(list_valid_collection_paths())
    assert test_valid_path_list

    # Test: invalid search path, warn
    test_valid_path_list = list(list_valid_collection_paths([os.path.join('foo', 'bar')], warn=True))
    assert not test_valid_path_list

    # Test: absolute path, warn
    test_valid_path_list = list(list_valid_collection_paths([os.path.abspath('foo')], warn=True))
    assert not test_valid_path_list


# Generated at 2022-06-20 13:38:54.885326
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp
    from shutil import rmtree

    collection_dirs = []
    for i in range(0, 3):
        collection_dirs.append(mkdtemp())

    # Provide an invalid path
    my_search_paths = collection_dirs
    my_search_paths.append('/my/foo/bar')

    results = list(list_valid_collection_paths(my_search_paths))
    assert len(results) == len(collection_dirs)
    assert set(results) == set(collection_dirs)

    # Provide an invalid path that can be written
    my_search_paths = collection_dirs
    my_search_paths.append('/tmp/my/foo/bar')


# Generated at 2022-06-20 13:38:57.871212
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'ansible.builtin' in [os.path.basename(c) for c in list_collection_dirs()]

# Generated at 2022-06-20 13:38:59.038984
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()


# Generated at 2022-06-20 13:39:30.251733
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # temp directories to test against
    b_tmp_path = to_bytes(os.path.realpath('tests/support/collection_loader'))
    coll_tmp_path = os.path.join(b_tmp_path, 'ansible_collections')

    # create topmost namespace
    b_namespace_dir = os.path.join(coll_tmp_path, to_bytes('some.namespace'))
    b_namespace_dir_1 = os.path.join(coll_tmp_path, to_bytes('another.namespace'))
    os.makedirs(b_namespace_dir)
    os.makedirs(b_namespace_dir_1)

    # create collection in namespace

# Generated at 2022-06-20 13:39:35.547430
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.compat.tests import unittest

    class TestCollectionFunctions(unittest.TestCase):

        def test_list_valid_collection_paths(self):

            search_paths = ['/nonexistentdir', '/etc/ansible', '/usr/share/ansible/collections']

            expected_results = ['/etc/ansible', '/usr/share/ansible/collections']
            results = list(list_valid_collection_paths(search_paths))

            self.assertEqual(results, expected_results)

    unittest.main()


# Generated at 2022-06-20 13:39:36.508015
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp', '/dev/null'])) == ['/tmp']

# Generated at 2022-06-20 13:39:37.899592
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # default is wrong
    assert list_valid_collection_paths() == list_valid_collection_paths(search_paths=['/tmp'])



# Generated at 2022-06-20 13:39:48.951003
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Sanity check to make sure list_collection_dirs() works as expected.
    This is only intended to be run as a unit test.
    """
    try:
        import jinja2
    except ImportError:
        raise AnsibleError("jinja2 is not installed")

    import doctest

    test_path = os.path.dirname(os.path.abspath(__file__))
    test_data = os.path.join(test_path, 'unit/list_collection_dirs.doctest')

    with open(test_data, 'rb') as test_data_file:
        template = jinja2.Template(test_data_file.read())

    print("==== BEGIN unit test for list_collection_dirs() ====")


# Generated at 2022-06-20 13:40:03.212725
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    paths = []

    def create_collection_dir(path, namespace, collection):
        b_dir = os.path.join(tempfile.gettempdir(), path, 'ansible_collections', namespace, collection)
        os.makedirs(b_dir)
        with open(os.path.join(b_dir, 'MANIFEST.json'), 'w') as f:
            f.write("{}")

    def create_collection(path, namespace, collection):
        # create collection with name "foo" in namespace "bar"
        # returns the dir for the collection
        create_collection_dir(path, namespace, collection)
        return os.path.join(tempfile.gettempdir(), path, 'ansible_collections', namespace, collection)

    # create 4 collections with two different namespaces and search paths

# Generated at 2022-06-20 13:40:13.821037
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test basics
    my_coll_list = list(list_collection_dirs(search_paths=[u'/tmp/test_test_test'], coll_filter=None))
    assert len(my_coll_list) == 0

    # Test a collection that exists
    # We can't use the install_collections task to install a collection because that would run
    # inside the Ansible process, not in the test process.
    # So, stub out a collection by creating the necessary directories.
    os.system(u"mkdir -p /tmp/test_test_test/ansible_collections/test_col/file_server")
    os.system(u"touch /tmp/test_test_test/ansible_collections/test_col/file_server/files.yml")

# Generated at 2022-06-20 13:40:14.968949
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # TODO: write unit test
    pass

# Generated at 2022-06-20 13:40:17.474075
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths(search_paths=[])

    assert len(list(result)) > 0



# Generated at 2022-06-20 13:40:27.957410
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections import file_collection_loader
    pathlist = ['bogus1', '/bogus2/', '/bogus3/', 'bogus4/']
    valid_collection_paths = list(list_valid_collection_paths(pathlist, warn=True))
    assert valid_collection_paths == []
    # Also test the directory and subdirectory case
    file_collection_loader.C.get_config = lambda *args, **kwargs: {
        'collections_paths': ['/bogus1/', '/bogus2/'],
        'collections_paths': ['/bogus1/', '/bogus2/'],
    }

# Generated at 2022-06-20 13:40:54.721983
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    tmp_paths = ['/tmp/foo', '/tmp/bar']
    assert list(list_valid_collection_paths(tmp_paths)) == []



# Generated at 2022-06-20 13:41:03.499448
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    :return:
    """

    import doctest

    # make a  temp dir for testing
    from ansible.module_utils.common._collections_compat import TemporaryDirectory
    with TemporaryDirectory() as tempdir:

        # create a coll path subdir
        os.makedirs(os.path.join(tempdir, 'ansible_collections'))

        # create a file in the root directory
        open(os.path.join(tempdir, 'my_file'), 'w').close()

        # create an empty subdir
        os.makedirs(os.path.join(tempdir, 'my_empty_dir'))

        # create a symlink to an existing subdir

# Generated at 2022-06-20 13:41:14.946249
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test to ensure list_valid_collection_paths works as expected
    """

    # Missing paths return empty list
    assert not list(list_valid_collection_paths(search_paths=['/invalid/path']))

    # Non-paths skipped
    assert not list(list_valid_collection_paths(search_paths=['/usr/bin/python']))

    # Not a path
    assert not list(list_valid_collection_paths(search_paths=[1]))

    # No path
    assert not list(list_valid_collection_paths(search_paths=[]))

    # Single path
    assert list(list_valid_collection_paths(search_paths=['/etc'])) == ['/etc']

    # Multiple paths

# Generated at 2022-06-20 13:41:16.032661
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), list)

# Generated at 2022-06-20 13:41:21.091110
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.config.manager import ConfigManager
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.parsing.plugin_docs import read_docstring

    # Create a fake config to return as the global config
    test_config = ConfigManager()
    test_config.set('DEFAULT', 'default_path', '/test/default/path')
    opt_help._config = test_config

    # Create a fake module that returns a static config for the sample collection
    # We cannot initialize the real config interface code as that requires the
    # rest of the collection module to be loaded, which would be a side-effect
    # of calling the test function.
    display.verbosity = 0

    class FakeModule(object):
        def get_config_data(self):
            mydict = dict()
           

# Generated at 2022-06-20 13:41:27.924647
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    ''' test list_valid_collection_paths. '''

    search_paths = ['/does/not/exist/', '/test/test']
    ret_val = list_valid_collection_paths(search_paths)
    assert list(ret_val) == ['/test/test']

    search_paths = []
    ret_val = list_valid_collection_paths(search_paths)
    assert list(ret_val) == []



# Generated at 2022-06-20 13:41:32.567193
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    coll_paths = [
        '/usr/share',
        '/usr/share/ansible_collections',
    ]

    coll_paths_filt = list(list_valid_collection_paths(coll_paths, warn=False))
    assert len(coll_paths_filt) == 1

    coll_paths = [
        '/usr/share',
        '/usr/share/ansible_collections',
        '/doesnotexist/ansible_collections',
    ]

    coll_paths_filt = list(list_valid_collection_paths(coll_paths, warn=False))
    assert len(coll_paths_filt) == 1


# Generated at 2022-06-20 13:41:38.006891
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = list_valid_collection_paths(['/abc','abc','abc/def','abc/def/nop','abc/def/nop/ansible_collections'])
    assert len(paths) == 3
    assert paths[0] == '/abc'
    assert paths[1] == 'abc'
    assert paths[2] == 'abc/def/nop/ansible_collections'


# Generated at 2022-06-20 13:41:48.431399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test list of search_paths including non-existent and non-directory
    search_paths = ['test_search_path', 'test_search_path/test_collection']

    # Test with existing path in search_paths
    for path in list_valid_collection_paths(search_paths, warn=True):
        assert True

    # Test with no existing paths in search_paths, should not warn
    search_paths = ['test_search_path', 'test_search_path/test_collection']
    for path in list_valid_collection_paths(search_paths, warn=False):
        assert True

    # Test with search_paths=None
    for path in list_valid_collection_paths(warn=True):
        assert True

# Generated at 2022-06-20 13:41:55.637317
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree

    def make_test_collection(test_namespace_path, test_collection_name):
        # create the collection directory
        coll_path = os.path.join(test_namespace_path, test_collection_name)
        os.mkdir(coll_path)

    # create a directory in /tmp
    tmp_dir = tempfile.mkdtemp()

    # make a collection
    tmp_collections_path = os.path.join(tmp_dir, 'ansible_collections')
    os.mkdir(tmp_collections_path)
    tmp_namespace_path = os.path.join(tmp_collections_path, 'mynamespace')
    os.mkdir(tmp_namespace_path)

# Generated at 2022-06-20 13:42:45.827415
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Tests for the list_valid_collection_paths function.
    '''

    import tempfile
    import shutil
    from textwrap import dedent

    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    valid_paths = [temp_dir, temp_file.name]
    invalid_paths = ['not-exist', 'foo', 'bar']
    search_paths = valid_paths + invalid_paths

    # each test case is a tuple of a configuration file and the expected result

# Generated at 2022-06-20 13:42:57.749472
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    expected = ['a', 'b']
    result = [val for val in list_valid_collection_paths(['a', 'b'])]
    assert result == expected

    expected = ['a', 'b']
    result = [val for val in list_valid_collection_paths(['a', 'b'], warn=True)]
    assert result == expected

    expected = []
    result = [val for val in list_valid_collection_paths(['x'], warn=True)]
    assert result == expected

    expected = []
    result = [val for val in list_valid_collection_paths(['x'], warn=False)]
    assert result == expected

    expected = ['a']
    result = [val for val in list_valid_collection_paths(['a', 'x'], warn=False)]

# Generated at 2022-06-20 13:43:08.729391
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # Create fake directories
    fake_dirs = [tempfile.TemporaryDirectory().name, tempfile.TemporaryDirectory().name, tempfile.TemporaryDirectory().name]
    display.verbosity = 4

    # Make one of them a file
    with open(fake_dirs[2], 'w') as f:
        f.write('test')

    try:
        # Check it only returns directories
        assert list(list_valid_collection_paths(fake_dirs, warn=True)) == [fake_dirs[0], fake_dirs[1]]
    finally:
        # Cleanup
        for path in fake_dirs:
            shutil.rmtree(path, ignore_errors=True)