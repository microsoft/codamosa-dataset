

# Generated at 2022-06-20 13:33:27.718418
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # non existent path, warned but not included
    search_paths = ['/foo/bar/baz/snap']
    assert list(list_valid_collection_paths(search_paths=search_paths)) == []

    # existent path, warning, but empty list
    search_paths = ['/tmp/']
    assert list(list_valid_collection_paths(search_paths=search_paths)) == []

    # existent path, warning, but empty list
    search_paths = ['/tmp/']
    assert list(list_valid_collection_paths(search_paths=search_paths)) == []

    # existent path, warning, but empty list
    search_paths = ['/tmp/']

# Generated at 2022-06-20 13:33:36.162480
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.ansible.builtin import get_collection_path

    search_paths = list_valid_collection_paths([], warn=True)
    assert len(search_paths) > 0

    for path in search_paths:
        result = get_collection_path(path, warn=True)
        assert os.path.exists(result)

    result = get_collection_path(None, warn=True)
    assert os.path.exists(result)



# Generated at 2022-06-20 13:33:46.380585
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # no paths search for
    actual = list(list_valid_collection_paths([]))
    assert actual == []

    # test a path that does not exist
    actual = list(list_valid_collection_paths(["/nonexistingpath/foo/bar"]))
    assert actual == []

    # test a path that exists, but is not a directory
    tmp_path = "/tmp/%s" % os.getpid()
    try:
        os.mknod(tmp_path)
        assert os.path.exists(tmp_path) is True
        assert os.path.isdir(tmp_path) is False

        actual = list(list_valid_collection_paths([tmp_path]))
        assert actual == []
    finally:
        os.unlink(tmp_path)

    # test a path

# Generated at 2022-06-20 13:33:51.002409
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = 'ansible_collections.namespace.collection'
    result = list_collection_dirs(search_paths='/tmp', coll_filter=coll_filter)
    assert result == '/tmp/ansible_collections/namespace/collection'

# Generated at 2022-06-20 13:33:57.120507
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for ansible.module_utils.common.collections.list_valid_collection_paths
    """
    test_paths = ['/tmp/foo', '/tmp/bar/baz', '/etc/redhat-release']
    valid_paths = list(list_valid_collection_paths(test_paths, warn=False))
    assert valid_paths == ['/etc/redhat-release']

# Generated at 2022-06-20 13:34:05.744962
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    try:
        path = os.path.join(temp_dir, 'ansible_collections/ns1.coll1/a')
        os.makedirs(path)
        dirs = list(list_collection_dirs([temp_dir]))
        assert len(dirs) == 1
        assert dirs[0] == to_bytes(os.path.join(temp_dir, 'ansible_collections/ns1.coll1'))
    finally:
        # Remove the directory after the test
        shutil.rmtree(temp_dir)

# Generated at 2022-06-20 13:34:13.078516
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Mocks
    import tempfile
    import shutil
    import os

    test_root = tempfile.mkdtemp()

    # Set up a mock directory structure:
    os.makedirs(os.path.join(test_root, 'ansible_collections', 'test.test'))
    os.makedirs(os.path.join(test_root, 'ansible_collections', 'test.testdupe'))
    os.makedirs(os.path.join(test_root, 'ansible_collections', 'test.testdupe'))

    # Make a duplicate collection in the same namespace
    with open(os.path.join(test_root, 'ansible_collections', 'test.testdupe', 'collection.yml'), "w") as f:
        f.close()

    #

# Generated at 2022-06-20 13:34:16.410677
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(['/does/not/exist']))) == 0
    assert len(list(list_valid_collection_paths(['/etc']))) == 0

# Generated at 2022-06-20 13:34:22.056292
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [u'foo/bar', u'home/me/ansible_collections', u'/root/mycollections']
    assert set(paths) == set(list_valid_collection_paths(search_paths=paths, warn=True))



# Generated at 2022-06-20 13:34:32.400265
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest
    from ansible.module_utils.common._collections_compat import Path
    from tempfile import TemporaryDirectory

    def create_dir(pth):
        os.makedirs(pth)

    def create_file(pth):
        open(pth, 'a').close()

    with TemporaryDirectory() as tmp:
        # create test dir and populate with test dir/file structure
        tmp_path = Path(tmp)
        dirs = [str(tmp_path.joinpath(x)) for x in ["a", "b", "c", "d", "e"]]
        create_dir(dirs[0])
        create_file(dirs[1])
        create_file(os.path.join(dirs[2], "f"))

# Generated at 2022-06-20 13:34:41.661638
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    list_valid_collection_paths test function
    """
    collection_paths = ["asdf", "/tmp", "/tmp/ansible_collections", "/tmp/ansible_collections/test/test_collection"]

    assert(list(list_valid_collection_paths(collection_paths)) == collection_paths[2:])



# Generated at 2022-06-20 13:34:44.943945
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs(coll_filter='col1.collection'))
    assert len(coll_dirs) == 1
    assert 'some_dir' in coll_dirs[0]
    assert 'some_dir2' not in coll_dirs[0]



# Generated at 2022-06-20 13:34:58.860334
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This is a unit test for the list_collection_dirs function
    """
    result = list(list_collection_dirs(['/tmp/fake_home', '/tmp/fake_usr']))

    assert len(result) == 0

    result = list(list_collection_dirs(['/tmp/fake_home/ansible_collections', '/tmp/fake_usr/ansible_collections']))

    assert len(result) == 2
    assert '/tmp/fake_home/ansible_collections/ansible/test' in result
    assert '/tmp/fake_home/ansible_collections/ansible/test2' in result

    result = list(list_collection_dirs(['/tmp/fake_home/ansible_collections', '/tmp/fake_home/ansible_collections']))

   

# Generated at 2022-06-20 13:35:04.288756
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    test_path = mkdtemp()
    assert test_path in list_valid_collection_paths([test_path])

    assert None is None

# Generated at 2022-06-20 13:35:10.903373
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = ['/tmp', '/noexists', '/notadir']
    test_passed_paths = list(list_valid_collection_paths(test_paths))

    assert('/tmp' in test_passed_paths)
    assert('/noexists' not in test_passed_paths)
    assert('/notadir' not in test_passed_paths)

# Generated at 2022-06-20 13:35:22.977712
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree

    # Test that it does not return a non existing path
    bad_temp_dir = mkdtemp()
    rmtree(bad_temp_dir)

    results = list(list_valid_collection_paths([bad_temp_dir]))
    assert len(results) == 0

    # Test that it does not return a file
    good_file = os.path.join(os.path.dirname(__file__), 'test_collections')

    results = list(list_valid_collection_paths([good_file]))
    assert len(results) == 0

    # Test that it does not return a bad collection path
    good_temp_dir = mkdtemp()

# Generated at 2022-06-20 13:35:28.167242
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.default_collection_paths)
    assert list(list_valid_collection_paths(['/does/not/exist'])) == []
    assert list(list_valid_collection_paths(['/does/not/exist'], warn=True)) == []

# Generated at 2022-06-20 13:35:33.309001
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # list_valid_collection_paths() test
    # 1. search_paths is None
    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)

    # 2. search_paths is not None
    list(list_valid_collection_paths(search_paths=[os.getcwd()]))



# Generated at 2022-06-20 13:35:42.276735
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test for default list
    assert [AnsibleCollectionConfig.configured_collection_path, os.path.expanduser('~/.ansible/collections')] == list(list_valid_collection_paths())

    # test for empty list
    assert [] == list(list_valid_collection_paths([]))

    # test for one missing search path
    assert [os.path.expanduser('~/.ansible/collections')] == list(list_valid_collection_paths(['/tmp/does/not/exist']))



# Generated at 2022-06-20 13:35:52.645045
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_text
    search_paths = []

    # fake ansible.cfg with a collection path
    with open("test_ansible.cfg", "w") as f:
        f.write("[defaults]\ncollections_paths=/etc/ansible/collections:/etc/ansible/user_collections:/usr/share/ansible/collections")

    v_paths = list(list_valid_collection_paths(search_paths, warn=False))
    # Ensure paths to collections are in v_paths
    assert '/usr/share/ansible/collections' in v_paths
    # Ensure path to non-collections does not exist

# Generated at 2022-06-20 13:36:04.430649
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with open('/tmp/test_list_collection_dirs.output', 'w') as f:
        for coll in list_collection_dirs(search_paths=['/usr/share/ansible', '/usr/share/ansible_collections', '/usr/share/ansible/my_modules'], coll_filter='ansible_collections.brian'):
            f.write(coll + '\n')

# Generated at 2022-06-20 13:36:07.790718
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['1', os.path.dirname(os.path.realpath(__file__))])) == [os.path.dirname(os.path.realpath(__file__))]


# Generated at 2022-06-20 13:36:14.576553
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/does/not/exist', '/tmp', '/tmp/does/not/exist', '/tmp/does']

    filtered_paths = list(list_valid_collection_paths(test_paths))
    assert len(filtered_paths) == 2, '%s contains %s' % (filtered_paths, test_paths)
    assert '/tmp' in filtered_paths, 'test path /tmp not in %s' % filtered_paths

    # ensure original list is not altered by list_valid_collection_paths
    assert len(test_paths) == 4, 'test_paths has been modified by list_valid_collection_paths'

# Generated at 2022-06-20 13:36:16.346603
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(list(list_valid_collection_paths()))


# Generated at 2022-06-20 13:36:26.214393
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os
    import tempfile
    import shutil

    base_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 13:36:39.719510
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        from ansible.utils.collection_loader import get_collection_mount_points
    except ImportError:
        print("Ansible is too old for this test")
        import sys
        sys.exit(99)

    # First, check that passing a namespace only returns results for that namespace
    for path in list_collection_dirs(coll_filter='ns1'):
        assert os.path.basename(path) == 'coll1'

    for path in list_collection_dirs(coll_filter='ns2'):
        assert os.path.basename(path) == 'coll2'

    # Next, check that passing a specific collection returns only results for that collection

# Generated at 2022-06-20 13:36:46.329753
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import tempfile

    temp_dir = tempfile.mkdtemp()
    print(temp_dir)
    ns_1_path = temp_dir + '/ansible_collections/ns_1/coll_1/ns_1.coll_1'
    ns_2_path = temp_dir + '/ansible_collections/ns_2/coll_2/ns_2.coll_2'
    ns_1_file = temp_dir + '/ansible_collections/ns_1/coll_1/file.txt'
    # make the directories
    os.makedirs(ns_1_path)
    os.makedirs(ns_2_path)
    # make a file to make sure its skipped
    open(ns_1_file, 'a').close()


# Generated at 2022-06-20 13:36:52.917048
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # pylint: disable=redefined-outer-name
    import tempfile
    import shutil
    import pytest

    ansible_test_directory = "./test/sanity/collection_loader/valid_collections"
    ansible_wrong_directory = "./test/sanity/collection_loader/invalid_collections"

    @pytest.fixture(scope='function')
    def collection_dir_fixture(request):
        """
        returns a temporary directory containing all the test collections
        """

        tempdir = tempfile.mkdtemp()

        # copy all test collections to the temporary dir
        for collection in os.listdir(ansible_test_directory):
            collection_path = os.path.join(ansible_test_directory, collection)

# Generated at 2022-06-20 13:37:04.797961
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.collections.default import CollectionPaths

    expected = [os.path.join(os.path.expanduser('~'), 'mycollections'),
                os.path.join(os.path.expanduser('~'), '.ansible', 'collections')]

    assert list(list_valid_collection_paths(['/invalid', os.path.join(os.path.expanduser('~'), 'mycollections')])) == [os.path.join(os.path.expanduser('~'), 'mycollections')]
    assert list(list_valid_collection_paths(expected)) == expected

# Generated at 2022-06-20 13:37:13.354442
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(coll_filter='ansible.builtin')) == [b'/usr/share/ansible/collections/ansible_collections/ansible/builtin']
    assert list(list_collection_dirs(['/etc/ansible/ansible.builtin'])) == [b'/usr/share/ansible/collections/ansible_collections/ansible/builtin']
    assert list(list_collection_dirs(coll_filter='ansible_collections.ansible.builtin')) == [b'/usr/share/ansible/collections/ansible_collections/ansible/builtin']

# Generated at 2022-06-20 13:37:30.180151
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    collection_dir = tempfile.mkdtemp()
    coll_1_dir = os.path.join(collection_dir, "ansible_collections", "test", "collection_1")
    coll_2_dir = os.path.join(collection_dir, "ansible_collections", "test", "collection_2")
    coll_3_dir = os.path.join(collection_dir, "ansible_collections", "test", "collection_3")
    coll_4_dir = os.path.join(collection_dir, "ansible_collections", "test", "collection_4")
    coll_1_nested_dir = os.path.join(collection_dir, "ansible_collections", "test", "collection_1", "collection_1.1")
   

# Generated at 2022-06-20 13:37:37.787874
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.hashing import checksum
    from ansible.collections.ansible import AnsibleCollectionConfig
    from ansible.collections.ansible.plugins.loader import collection_finder

    # create test dir for local collection
    tmp_coll_root = "/tmp/ansible_collections"
    tmp_coll_path = os.path.join(tmp_coll_root, 'test.testcoll')
    tmp_coll_tgz = os.path.join(tmp_coll_root, 'test.testcoll-0.1.0.tar.gz')
    os.makedirs(tmp_coll_path, exist_ok=True)
    os.makedirs(os.path.join(tmp_coll_path, 'plugins'), exist_ok=True)

# Generated at 2022-06-20 13:37:47.940699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths()

    assert list_valid_collection_paths(warn=True)

    # passing a list of paths
    assert list_valid_collection_paths(search_paths=["/tmp/path1", "/tmp/path2"])

    # with a list including a missing path
    assert list_valid_collection_paths(search_paths=["/tmp/path1", "/tmp/missing-path"])

    # with a list including a missing path, setting warn to True
    assert list_valid_collection_paths(search_paths=["/tmp/path1", "/tmp/missing-path"], warn=True)

    # with a list including a non directory path, setting warn to True

# Generated at 2022-06-20 13:37:52.668291
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_path = os.path.join(os.path.dirname(__file__), 'testdata', 'test_collections')
    assert set(list_collection_dirs([test_path])) == {
        os.path.join(test_path, "ansible_collections", "testns1", "testcoll1"),
        os.path.join(test_path, "ansible_collections", "testns1", "testcoll2"),
        os.path.join(test_path, "ansible_collections", "testns2", "testcoll1"),
        os.path.join(test_path, "ansible_collections", "testns2", "testcoll2"),
    }


# Generated at 2022-06-20 13:38:01.378084
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    from ansible.utils.path import assert_isfile, assert_isdir

    d1 = tempfile.mkdtemp()
    assert_isdir(d1)

    f1 = tempfile.mkstemp()[1]
    assert_isfile(f1)

    paths = [f1, d1]
    results = list(list_valid_collection_paths(paths))

    assert d1 in results
    assert f1 not in results

    shutil.rmtree(d1)
    os.remove(f1)

# Generated at 2022-06-20 13:38:07.527201
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ list_collection_dirs: test the caller to collection_loader.list_collection_dirs
        Note: This test is more of a 'smoke test' in that it only makes sure
        the caller handles missing arguments and returns a list vs. an iterator
    """
    import unittest


# Generated at 2022-06-20 13:38:15.371287
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """test_list_valid_collection_paths() - verify collection search path functionality"""

    valid_paths = list(list_valid_collection_paths())
    assert(len(valid_paths) > 0)
    for path in valid_paths:
        assert(os.path.exists(to_bytes(path)))
        assert(os.path.isdir(to_bytes(path)))



# Generated at 2022-06-20 13:38:16.473539
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs())



# Generated at 2022-06-20 13:38:25.417713
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Unit test for list_collection_dirs"""
    b_coll_path = to_bytes(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'data', 'collection_loader'))
    colls = list(list_collection_dirs([b_coll_path], 'namespace.collection'))
    assert len(colls) == 1
    assert os.path.basename(colls[0]) == 'collection'
    assert os.path.basename(os.path.dirname(colls[0])) == 'namespace'

    colls = list(list_collection_dirs([b_coll_path], 'namespace'))
    assert len(colls) == 2

# Generated at 2022-06-20 13:38:29.185090
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    found_collections = list(list_collection_dirs(coll_filter='default.example'))
    assert len(found_collections) == 1



# Generated at 2022-06-20 13:38:43.573947
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    ##########################################################################
    # Empty - Empty
    (list_valid_collection_paths() == list_valid_collection_paths(None, False))

    ##########################################################################
    # Empty - None
    (list_valid_collection_paths() == list_valid_collection_paths(None, False))

    ##########################################################################
    # Empty - One
    (list_valid_collection_paths() == list_valid_collection_paths(["/tmp/foo"], False))

    ##########################################################################
    # Empty - Some
    (list_valid_collection_paths() == list_valid_collection_paths(["/tmp/foo", "/tmp/bar"], False))

    ##########################################################################
    # None - Empty

# Generated at 2022-06-20 13:38:55.233531
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.plugins import collection_loader

    import sys
    import tempfile
    from collections import OrderedDict


# Generated at 2022-06-20 13:39:05.635427
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["/tmp/simple_collections", "/tmp/nested_collections"]

    # test for all collections
    for path in list_collection_dirs(search_paths=search_paths):
        print("path: %s" % path)

    # test for a specific collection
    for path in list_collection_dirs(search_paths=search_paths, coll_filter="mynamespace.mycollection"):
        print("path: %s" % path)

    # test for a specific namespace
    for path in list_collection_dirs(search_paths=search_paths, coll_filter="mynamespace"):
        print("path: %s" % path)

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-20 13:39:15.852984
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import datetime
    import tempfile
    import shutil

    test_start = datetime.datetime.now()

    # make a test dir
    tmpdir = tempfile.mkdtemp()

    # make an ansible_collections dir
    acdir = os.path.join(tmpdir, 'ansible_collections')
    os.makedirs(acdir)

    # make an ansible dir
    amd = os.path.join(acdir, 'ansible')

    # make a collections dir
    cmdd = os.path.join(amd, 'collections')
    os.makedirs(cmdd)

    # make an ansible.collections.test dir
    atcd = os.path.join(cmdd, 'test')
    os.makedirs(atcd)

    # make a test file


# Generated at 2022-06-20 13:39:23.865405
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    search_paths = ['/non_existing_path', mkdtemp(), '/existing_none_directory_path']
    non_existing_path = search_paths[0]
    existing_directory_path = search_paths[1]
    existing_none_directory_path = search_paths[-1]

    assert non_existing_path not in list_valid_collection_paths(search_paths, warn=False)
    assert existing_directory_path in list_valid_collection_paths(search_paths, warn=False)

    with open(existing_none_directory_path, 'w+') as f:
        f.write('')

    assert existing_directory_path in list_valid_collection_paths(search_paths, warn=False)
    assert existing_

# Generated at 2022-06-20 13:39:32.809815
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import sys

    test_dir = tempfile.mkdtemp()
    c = os.path.join(test_dir, 'collections')
    os.mkdir(c)

    default_paths = { 'COLLECTIONS_PATHS': c, 'ANSIBLE_COLLECTIONS_PATHS': c, 'ANSIBLE_ROLES_PATH': c,
                      'ANSIBLE_ROLES_PATH': c, 'ANSIBLE_LIBRARY': c }

    for k in default_paths.keys():
        assert os.environ.get(k, None) is not None, "Environment variable {0} cannot be found".format(k)


# Generated at 2022-06-20 13:39:46.243588
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '/usr/share/ansible/collections/ansible_collections',
        '/usr/share/ansible/collections',
        '/usr/share/ansible/collections/ansible/test',
        '/etc/ansible/collections/ansible_collections',
        '/etc/ansible/collections',
        '/etc/ansible/test_collections',
        '~/test_collections',
        'test_collections'
    ]

    valid_paths = list(list_valid_collection_paths(test_paths))

    assert len(valid_paths) == 3
    assert '/usr/share/ansible/collections/ansible_collections' in valid_paths
    assert '/etc/ansible/collections/ansible_collections' in valid

# Generated at 2022-06-20 13:39:56.573659
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Basic test, verifying a namespace and collection is found
    found_ns = False
    found_coll = False
    for path in list_collection_dirs():
        if path.endswith('ansible_collections/testns/testcoll'):
            found_ns = True
            found_coll = True
    assert found_ns
    assert found_coll

    # Test of name filtering
    found_ns = False
    found_coll = False
    for path in list_collection_dirs(coll_filter="testns.testcoll"):
        if path.endswith('ansible_collections/testns/testcoll'):
            found_ns = True
            found_coll = True
    assert found_ns
    assert found_coll

    # Test of namespace filtering
    found_ns = False

# Generated at 2022-06-20 13:40:06.657151
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    This is a test case for the list_collection_dirs function.
    Make sure it generates an iterator on the list of valid collections
    """
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:

        tmpdir_b = to_bytes(tmpdir, errors='surrogate_or_strict')
        shutil.copytree(
            os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'data', 'test_collections'),
            os.path.join(tmpdir_b, b'ansible_collections')
        )

        res = list_collection_dirs(search_paths=[tmpdir])


# Generated at 2022-06-20 13:40:14.219587
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    assert os.path.exists(tmpdir)

    # Prepare some dummy collection directories
    ns1 = os.path.join(tmpdir, "somenamespace")
    os.makedirs(ns1)
    coll1 = os.path.join(ns1, "somecollection")
    os.makedirs(coll1)
    coll2 = os.path.join(ns1, "othercollection")
    os.makedirs(coll2)
    coll3 = os.path.join(ns1, "anothercollection")
    os.makedirs(coll3)
    ns2 = os.path.join(tmpdir, "anothernamespace")

# Generated at 2022-06-20 13:40:30.260121
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_search_paths = ['~test_coll_path/', '~test_coll_path/badpath']

    test_calls = [
        {'coll_filter': None, 'expected': 'ansible_collections'},
        {'coll_filter': 'foo', 'expected': 'ansible_collections/foo'},
        {'coll_filter': 'foo.bar', 'expected': 'ansible_collections/foo/bar'},
    ]

    for call in test_calls:
        expected = call['expected']
        actual = list_collection_dirs(search_paths=test_search_paths, coll_filter=call['coll_filter'])
        assert not expected.startswith('~'), 'Collection path must be absolute'

        if actual:
            actual = actual[0]


# Generated at 2022-06-20 13:40:42.031204
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    class MyDisplay():
        def warning(self, string):
            pass

        def display(self, string):
            pass

    display = MyDisplay()

    coll_dirs = []
    warning_dirs = []
    tmpdir = tempfile.mkdtemp()
    tmpdir1 = os.path.join(tmpdir, 'ansible_collections')
    os.makedirs(tmpdir1)
    tmpdir2 = os.path.join(tmpdir, 'another')
    os.makedirs(tmpdir2)
    coll_dirs.append(tmpdir1)
    coll_dirs.append(tmpdir2)
    # collection paths specified in the Ansible config file,
    coll_dirs.append('/tmp/doesnotexist')
    # collection paths specified

# Generated at 2022-06-20 13:40:50.298812
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import list_collection_dirs
    from ansible.module_utils._text import to_bytes
    from ansible_collections.mynamespace.mycollection.plugins.module_utils.mymodule import myfunction
    from ansible_collections.mynamespace.mycollection.plugins.module_utils.mymodule import myotherfunction
    import os, shutil

    rootdir = os.path.dirname(os.path.dirname(myfunction.__file__))
    colrootdir = os.path.dirname(rootdir)
    tmpcolpath = os.path.join(colrootdir, 'myothertmpnamespace')
    os.makedirs(tmpcolpath)
    shutil.copytree(rootdir, os.path.join(tmpcolpath, 'mycollection'))
   

# Generated at 2022-06-20 13:40:54.049972
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/foo/bar']
    result = list(list_valid_collection_paths(search_paths=search_paths, warn=False))
    assert not result

    search_paths = ['/foo/bar']
    result = list(list_valid_collection_paths(search_paths=search_paths, warn=True))
    assert not result

# Generated at 2022-06-20 13:41:02.534236
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile

    # set up a temp dir with a couple namespaces/collections
    coll_dir = tempfile.mkdtemp()

    try:
        for ns in ['testns', 'testns2']:
            for coll in ['testcoll', 'testcoll2']:
                os.mkdir(coll_dir + '/' + ns + '/' + coll)

        wd = os.getcwd()
        os.chdir(coll_dir)
        assert len([test_dir for test_dir in list_collection_dirs()]) == 4

    finally:
        os.chdir(wd)

    assert len([test_dir for test_dir in list_collection_dirs(search_paths=[coll_dir])]) == 4

# Generated at 2022-06-20 13:41:09.972253
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_paths = [
        '../../../test/integration/targets',
    ]

    # Should only find mycollection
    colls = list(list_collection_dirs(search_paths=coll_paths, coll_filter='mycollection'))

    assert len(colls) == 1
    assert os.path.basename(colls[0]) == 'mycollection'

    # Should find all collections
    colls = list(list_collection_dirs(search_paths=coll_paths))

    assert len(colls) == 3
    for coll in colls:
        assert os.path.basename(coll) in ['mycollection', 'other_ns', 'test_namespace']

    # Should find all collections in other_ns namespace

# Generated at 2022-06-20 13:41:18.044959
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(['../test/units/fixtures/collection_loader/sample_collections']) == [b'../test/units/fixtures/collection_loader/sample_collections/ansible_collections/test_ns/test_coll']
    assert list_collection_dirs(['../test/units/fixtures/collection_loader/sample_collections'], 'test_ns') == [b'../test/units/fixtures/collection_loader/sample_collections/ansible_collections/test_ns/test_coll']

# Generated at 2022-06-20 13:41:28.650285
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        collection_directories = list_collection_dirs(search_paths=['/tmp/ansible_collections'])
    except AnsibleError as e:
        print(e.message)
        print("The configured collection path /tmp/ansible_collections does not exist.")
    else:
        print("The configured collection path /tmp/ansible_collections does exist.")
        for path in collection_directories:
            print(path)

"""
if __name__ == '__main__':
    test_list_collection_dirs()
."""

# Generated at 2022-06-20 13:41:38.910052
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible import context
    search_paths = ['test-unit/unit/plugins/collections', 'test-unit/unit/plugins/test_collections/partial']
    coll_filter = None
    context.CLIARGS = {'collections': [coll_filter], 'collection_paths': search_paths}
    dirs = list(list_collection_dirs())
    assert len(dirs) == 3
    context.CLIARGS = {'collections': ['testcoll.newcoll1'], 'collection_paths': search_paths}
    dirs = list(list_collection_dirs())
    assert len(dirs) == 1
    context.CLIARGS = {'collections': ['testcoll'], 'collection_paths': search_paths}

# Generated at 2022-06-20 13:41:49.191376
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    coll_root = tempfile.mkdtemp(prefix='ansible_collections_')
    coll_root_fmt = tempfile.mkdtemp(prefix='ansible_collections_')
    n1_dir = os.path.join(coll_root_fmt, 'ns1')
    c1_dir = os.path.join(n1_dir, 'coll1')
    n2_dir = os.path.join(coll_root_fmt, 'ns2')
    c2_dir = os.path.join(n2_dir, 'coll2')
    c3_dir = os.path.join(n2_dir, 'coll3')

    os.makedirs(c1_dir)
    os.makedirs(c2_dir)

# Generated at 2022-06-20 13:42:18.518700
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Build dummy collection path
    tmp_coll_dir = os.path.join(os.path.dirname(__file__), 'test_data', 'my_test_collections')
    coll_dir = to_bytes(tmp_coll_dir)

    # Create a temporary collection file structure
    test_collection1 = os.path.join(coll_dir, 'ansible_collections', 'testcoll1', 'mytest1')
    test_collection2 = os.path.join(coll_dir, 'ansible_collections', 'testcoll2', 'mytest2')
    if not os.path.exists(test_collection1):
        os.makedirs(test_collection1)
    if not os.path.exists(test_collection2):
        os.makedirs(test_collection2)

# Generated at 2022-06-20 13:42:24.899713
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(search_paths=[])) == AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(search_paths=['/tmp'])) == ['/tmp'] + AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(search_paths=['/tmp', 'doesnt_exist_path'])) == ['/tmp'] + AnsibleCollectionConfig.collection_paths
    assert list(list_valid_collection_paths(search_paths=['/tmp', 'doesnt_exist_path'], warn=True)) == ['/tmp'] + AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-20 13:42:36.383699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # mock an ansible.cfg
    def mock_open_config(path):
        with open(path, 'w') as fh:
            fh.write('''[defaults]
collections_paths = %s/foo:%s/bar''' % (os.path.dirname(__file__), os.path.dirname(__file__)))

    def mock_open_config_with_empty(path):
        with open(path, 'w') as fh:
            fh.write('')

    # mock the collection loader ansible.cfg (collection_paths)
    AnsibleCollectionConfig.collection_paths = ['%s/this' % os.path.dirname(__file__), '%s/that' % os.path.dirname(__file__)]

    # mock the os module


# Generated at 2022-06-20 13:42:45.829522
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(None))
    assert list(list_valid_collection_paths(["/usr/share/ansible/collections", "/usr/share/ansible/collections_tmp", "/usr/share/ansible/collections/test"])) == ["/usr/share/ansible/collections", "/usr/share/ansible/collections_tmp", "/usr/share/ansible/collections/test"]

# Generated at 2022-06-20 13:42:53.849215
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # basic coll find
    paths = list(list_collection_dirs(search_paths=['test/unit/utils/collections/list_coll/coll_root']))
    assert len(paths) == 4
    assert paths[0].endswith('ns1.coll1')
    assert paths[1].endswith('ns1.coll2')
    assert paths[2].endswith('ns2.coll1')
    assert paths[3].endswith('ns2.coll2')

    # find one coll
    paths = list(list_collection_dirs(search_paths=['test/unit/utils/collections/list_coll/coll_root'],
                                      coll_filter='ns1.coll1'))
    assert len(paths) == 1

# Generated at 2022-06-20 13:43:08.553715
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        os.path.join(os.path.dirname(os.path.dirname(__file__)), 'lib'),
        '/doesnotexist',
        'not a directory',
        '/etc/ansible/ansible.cfg'
    ]

    filtered_paths = list_valid_collection_paths(test_paths, warn=True)

    # make sure we did not get the bad ones
    assert '/doesnotexist' not in list(filtered_paths)
    assert 'not a directory' not in list(filtered_paths)
    assert '/etc/ansible/ansible.cfg' not in list(filtered_paths)

    # make sure the good ones are still there