

# Generated at 2022-06-20 13:33:24.333424
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import AnsibleCollectionRef

    for paths in [
        '/foo/ansible_collections/my_namespace1/my_collection1',
        '/foo/ansible_collections/my_namespace1/my_collection1/',
        '/foo/ansible_collections/my_namespace2/my_collection2',
        '/foo/ansible_collections/my_namespace2/my_collection2/',
    ]:
        os.makedirs(paths)

    assert os.path.isdir('/foo/ansible_collections/my_namespace1/my_collection1')
    assert os.path.isdir('/foo/ansible_collections/my_namespace1/my_collection1/')
    assert os.path.isdir

# Generated at 2022-06-20 13:33:34.783007
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        "do_not_exist",
        "_does_not_exist_in_this_universe",
    ]
    # test warning and display
    out = list(list_valid_collection_paths(test_paths, True))
    assert len(out) == 0
    # should list all collection paths returned by AnsibleCollectionConfig
    out = list(list_valid_collection_paths())
    assert len(out) == len(AnsibleCollectionConfig.collection_paths)


# Generated at 2022-06-20 13:33:45.264180
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # prepare dirs and files
    tmp_path = tempfile.mkdtemp()
    os.mkdir(tmp_path + '/ansible_collection')
    os.mkdir(tmp_path + '/ansible_collection/my_namespace')
    os.mkdir(tmp_path + '/ansible_collection/my_namespace/my_collection')
    open(tmp_path + '/ansible_collection/my_namespace/my_collection/plugins/action/my_action.py', 'w').close()
    open(tmp_path + '/my_file', 'w').close()

    # test with no args, should return only default paths
    err = False

# Generated at 2022-06-20 13:33:49.396092
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for path in list_collection_dirs(search_paths=[os.path.join(os.path.dirname(__file__), '../test/test_collections')]):
        print(path)


# Generated at 2022-06-20 13:33:50.953973
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs())
    assert collection_dirs

# Generated at 2022-06-20 13:33:59.175928
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_locations = list_collection_dirs()

    # Load expected values from file
    local_data_path = os.path.normpath(os.path.join(os.path.dirname(__file__), u'..', u'data'))
    with open(os.path.join(local_data_path, "test_list_collection_dirs_output.txt"), "r") as f:
        expected_output = [x.strip() for x in f.readlines()]

    # Compare expected output to the results of the function
    assert set(coll_locations) == set(expected_output)

# Generated at 2022-06-20 13:34:12.166182
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile

    coll_name = 'my_namespace.my_collection'

    tmp_dir = os.path.join(tempfile.gettempdir(), "list_collection_dirs_test")
    b_tmp_coll_root = to_bytes(tmp_dir)

    # create invalid collection
    os.makedirs(b_tmp_coll_root)
    coll_dir = os.path.join(tmp_dir, coll_name)
    coll_dir_b = to_bytes(coll_dir)
    os.makedirs(coll_dir_b)
    open(os.path.join(coll_dir_b, '__init__.py'), 'w').close()


# Generated at 2022-06-20 13:34:21.108194
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = ['/ansible/collections', '/ansible/collections/ns1', '/ansible/collections/ns2',
             '/ansible/collections/ns2/ns2coll']

    # return all collection paths
    results = list(list_collection_dirs(search_paths=paths))
    assert len(results) == 3

    # return all ansible.builtin collection paths
    results = list(list_collection_dirs(search_paths=paths, coll_filter='ansible.builtin'))
    assert len(results) == 1

    # return all ansible.builtin and ansible.networking collection paths
    results = list(list_collection_dirs(search_paths=paths, coll_filter=['ansible.builtin', 'ansible.networking']))
    assert len

# Generated at 2022-06-20 13:34:31.763097
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    class TestCase:
        def __init__(self, test_name, search_paths):
            self.test_name = test_name
            self.search_paths = search_paths

        def run(self):
            search_paths = self.search_paths
            # pylint: disable=unpacking-non-sequence
            test_name, search_paths = self.test_name.split('|')
            search_paths = search_paths.split(',')
            result = list(list_valid_collection_paths(search_paths=search_paths))
            assert result == search_paths, "Test '{0}' failed. Expected '{1}' and got '{2}'".format(test_name, search_paths, result)


# Generated at 2022-06-20 13:34:42.261043
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    run this test with pytest
    """
    # To get the test directory for all OS
    import __main__
    my_path = os.path.dirname(__main__.__file__)

    # test with list_collection_dirs function
    test_ns_coll_path = os.path.join(my_path, 'test_collections', 'ansible_collections', 'testns')
    test_collection_path = os.path.join(test_ns_coll_path, 'test_collection')
    test_module_path = os.path.join(test_collection_path, 'plugins', 'modules')
    test_filter_ns_path = os.path.join(my_path, 'test_collections', 'ansible_collections', 'testns')
    test_filter_coll_path

# Generated at 2022-06-20 13:34:55.671533
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collection_dirs('/Users/abjorkl/Development/ansible/devel/lib/ansible/modules/collection_examples')


# Generated at 2022-06-20 13:35:04.778502
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    test_coll_base = "test_collections"
    test_coll = 'collection1'
    test_coll2 = 'collection2'
    test_coll_ns = 'namespace1'
    test_coll_ns2 = 'namespace1.collection1'
    test_coll_full = '%s.%s' % (test_coll_ns, test_coll)
    test_coll2_ns = 'namespace2'
    test_coll2_full = '%s.%s' % (test_coll2_ns, test_coll2)

    # create a temporary directory
    tmpdir = tempfile.mkdtemp(test_coll_base)
    tmpdir2 = os.path.join(tmpdir, test_coll_ns, test_coll)

# Generated at 2022-06-20 13:35:13.138792
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/nonexistent', '/'])) == ['/']
    assert list(list_valid_collection_paths(['/', '/nonexistent'])) == ['/']
    assert list(list_valid_collection_paths(['/nonexistent', '/', '/etc/'])) == ['/', '/etc/']
    assert list(list_valid_collection_paths(['/nonexistent', '/', '/etc/bin'])) == ['/', '/etc/bin']
    assert list(list_valid_collection_paths(['/nonexistent'])) == list(AnsibleCollectionConfig.collection_paths)

# Generated at 2022-06-20 13:35:19.097624
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ["test/data/collections", "test/data/collections2"]
    coll_filter = 'community.general'
    for collection in list_collection_dirs(search_paths, coll_filter):
        print(collection)

    search_paths = ["test/data/collections", "test/data/collections2"]
    coll_filter = 'community'
    for collection in list_collection_dirs(search_paths, coll_filter):
        print(collection)

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-20 13:35:28.019846
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    cwd = os.getcwd()
    os.chdir('test/utils/')

    paths = ['fixtures/ansible_collections/']
    colls = list(list_collection_dirs(search_paths=paths))
    assert len(colls) == 2
    assert 'test.test_test' in os.path.basename(colls[0])
    assert 'test.test_test_plugin' in os.path.basename(colls[1])

    colls = list(list_collection_dirs(search_paths=paths, coll_filter='test_test'))
    assert len(colls) == 1
    assert os.path.basename(colls[0]) == 'test_test'


# Generated at 2022-06-20 13:35:36.825488
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test valid paths, should pass
    search_paths = ['.', './ansible_collections', '/opt/ansible/ansible_collections']
    out = list(list_valid_collection_paths(search_paths))
    assert out == ['.', './ansible_collections', '/opt/ansible/ansible_collections']

    # some paths don't exist, should drop them but add default
    search_paths = ['.', '/opt/ansible/ansible_collections', '/opt/ansible1/ansible_collections']
    out = list(list_valid_collection_paths(search_paths))
    assert out == ['.', '/opt/ansible/ansible_collections']

    # all paths don't exist, should add default

# Generated at 2022-06-20 13:35:43.696733
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collections_skipped_test = ['ansible_collections']
    coll_filter = None
    for path in list_collection_dirs([], coll_filter):
        for coll in collections_skipped_test:
            if path.endswith(coll):
                yield path

# Generated at 2022-06-20 13:35:53.630369
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ["/no_exist", "/no_exist2", "/usr/share/ansible/empty"]
    result = list_valid_collection_paths(search_paths=search_paths, warn=False)
    result = [p for p in result]
    assert result == [], "%s should equal empty list" % result
    result = list_valid_collection_paths(search_paths=search_paths, warn=True)
    result = [p for p in result]
    assert result == [], "%s should equal empty list" % result

    search_paths = ["/usr/share/ansible/empty", "/usr/share/ansible/collections"]
    result = list_valid_collection_paths(search_paths=search_paths, warn=False)

# Generated at 2022-06-20 13:36:03.089412
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert ['/var/valid', '/tmp/foo', '/tmp/bar'] == list(list_valid_collection_paths(
        ['/var/valid', '/tmp/foo', '/tmp/bar', '/tmp/nonexistent'], warn=False
    ))
    assert ['/var/valid', '/tmp/foo', '/tmp/bar'] == list(list_valid_collection_paths(
        ['/var/valid', '/tmp/foo', '/tmp/bar', '/tmp/nonexistent'], warn=True
    ))

# Generated at 2022-06-20 13:36:11.147798
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Create an arbitrary collection path to test against
    new_path = '/tmp/this-is-a-collection'
    os.makedirs(to_bytes(new_path, errors='surrogate_or_strict'))

    # Create an arbitrary collection path that does not exist to test against
    bad_path = '/tmp/this-is-bad-collection'

    # Create a file that should not be considered a collection path
    bad_file = '/tmp/not-a-collection'
    with open(to_bytes(bad_file, errors='surrogate_or_strict'), 'w+'):
        pass

    # Expected result of function for a list of 2 paths, one that does not exist, and one that does
    expected = [new_path]

    # Call function and assert results
    result = list_valid_collection

# Generated at 2022-06-20 13:36:29.411409
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test if the function list_collection_dirs works as expected.
    """
    from ansible.utils.collection_loader import COLLECTIONS_PATHS
    from ansible.plugins.loader import find_plugin_dirs, find_vars_plugins, find_action_plugin

    # Execute list_collection_dirs in silence
    current_display = display.verbosity
    display.verbosity = 0

    # find_plugin_dirs returns a list of tuples with a directory and a source.
    # We only want to iterate the directory in this test
    iter_directories = list(d[0] for d in find_plugin_dirs)

    # We assume that the action plugins provided by collections in COLLECTIONS_PATHS
    # have priority over the ones provided by the base system.
    # So we remove

# Generated at 2022-06-20 13:36:40.938578
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    coll_dir = '/tmp/ansible_collections/anycollection/test'
    if os.path.exists(coll_dir):
        from shutil import rmtree
        rmtree(coll_dir)

    os.makedirs(coll_dir)

    for path in list_collection_dirs():
        assert 'ansible_collections' not in path, path

    for path in list_collection_dirs(coll_filter='anycollection.test'):
        assert 'ansible_collections' not in path, path
        assert 'anycollection/test' in path, path

    # path /tmp isn't in config, so it should not be valid
    assert len(list(list_valid_collection_paths(['/tmp']))) == 0


# Generated at 2022-06-20 13:36:50.622781
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config import (DEFAULT_COLLECTIONS_PATHS, get_config)
    from ansible.plugins.loader import get_all_plugin_loaders

    config = get_config()
    plugin_loaders = get_all_plugin_loaders(config.plugin_paths)[1]

    plugin_loaders.set_collection_paths(DEFAULT_COLLECTIONS_PATHS)

    assert plugin_loaders.collection_paths == DEFAULT_COLLECTIONS_PATHS
    assert [] == list(list_valid_collection_paths())

    list_collection_dirs()


# Generated at 2022-06-20 13:37:02.356576
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # create a temp dir that does not exist
    tmp_path = tempfile.mkdtemp()
    os.rmdir(tmp_path)

    # check warning for missing dir
    list(list_valid_collection_paths([tmp_path], warn=True))

    # now create the dir
    os.makedirs(tmp_path)

    # check for default collection paths
    paths = list(list_valid_collection_paths())

    tmp_path = to_bytes(tmp_path)
    # check that the created temp path is not in the default paths
    assert tmp_path not in paths

    # check that the newly created dir was returned
    paths = list(list_valid_collection_paths([tmp_path]))
    assert tmp_path in paths


# Generated at 2022-06-20 13:37:10.423979
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    conf = AnsibleCollectionConfig(data={'collections_paths': ['./tests/data/', '/tmp/doesnotexist']}, validate=True)
    dirs = list(list_collection_dirs(search_paths=conf.collection_paths, coll_filter=None))
    assert len(dirs) > 0
    assert b"ansible.builtin" in dirs[0]
    assert b"./tests/data/ansible_collections/ansible/builtin" in dirs[0]



# Generated at 2022-06-20 13:37:13.593431
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collections = list(list_collection_dirs(['../../library', '../../module_utils'], 'test_collection.collection3'))
    assert len(list_collections) == 1
    assert list_collections[0] == '../../module_utils/ansible_collections/test_collection/collection3'

# Generated at 2022-06-20 13:37:19.808665
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import subprocess
    import tempfile

    def mock_subprocess_check_output(*args, **kwargs):
        if args[0][0] == 'git':
            raise subprocess.CalledProcessError(0, 'test git', 'test git content')
        return 'test version'

    subprocess_check_output_orig = subprocess.check_output

    path_list = []

    d = tempfile.mkdtemp()
    path_list.append(d)

    collection_paths = ["/tmp", d, "/home/foo/my_collections"]

    for cp in collection_paths:
        os.mkdir(os.path.join(cp, 'ansible_collections'))

    collection = "namespace.collection"
    namespace = "namespace"

# Generated at 2022-06-20 13:37:30.720246
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    List the collection directories from a temporary directory that has a
    collection called 'my_collection' inside the 'my_namespace' namespace.
    """
    # Setup a temporary directory with one namespace, one collection
    import pytest
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'my_namespace', 'my_collection'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'another_namespace', 'another_collection'))

    # Test for a collection in a namespace in the directory

# Generated at 2022-06-20 13:37:39.241287
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # In a single directory, it should find collections with 'x' and 'y' in each namespace directory
    assert set(list_collection_dirs(['/tmp/foo'])) == set(['/tmp/foo/ansible_collections/x/y',
                                                           '/tmp/foo/ansible_collections/x/z',
                                                           '/tmp/foo/ansible_collections/y/y',
                                                           '/tmp/foo/ansible_collections/y/z'])

    # Same as last test but with config
    with AnsibleCollectionConfig('/tmp/config'):
        AnsibleCollectionConfig.set_collection_paths(['/tmp/foo'])

# Generated at 2022-06-20 13:37:45.109210
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # empty search paths
    assert list(list_collection_dirs(search_paths=[])) == []

    # search path should match default
    assert list(list_collection_dirs(search_paths=['/nonexistent/path'])) == list_collection_dirs()

    # search path should match default
    assert list(list_collection_dirs(search_paths=['/nonexistent/path'])) == list_collection_dirs()

    # list_collection_dirs() should match default
    assert list(list_collection_dirs(search_paths=None)) == list_collection_dirs()

# Generated at 2022-06-20 13:38:14.609878
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    temp_root = tempfile.mkdtemp()
    temp_ansible_collections = os.path.join(temp_root, 'ansible_collections')
    os.mkdir(temp_ansible_collections)
    assert not os.path.exists(os.path.join(temp_ansible_collections, 'ns1'))
    os.mkdir(os.path.join(temp_ansible_collections, 'ns2'))
    os.mkdir(os.path.join(temp_ansible_collections, 'ns2', 'coll1'))
    assert not os.path.exists(os.path.join(temp_ansible_collections, 'ns2', 'coll1', 'plugins'))

# Generated at 2022-06-20 13:38:21.112705
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    paths = ['foo', 'bar']

    class mock_os(object):
        def exists(self, path):
            if path == 'foo':
                return True
            return False

        def isdir(self, path):
            if path == 'foo':
                return True
            return False

    os_copy = os
    os = mock_os()

    result = list(list_valid_collection_paths(paths))
    assert result == ['foo']

    os = os_copy

# Generated at 2022-06-20 13:38:28.038930
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    dirs = list(list_collection_dirs(search_paths='../../../lib/ansible/plugins/collections'))
    assert len(dirs) == 1
    assert dirs[0].endswith(b'ansible/plugins/collections/ansible_collections/acme/test')

    dirs = list(list_collection_dirs(coll_filter='acme.test'))
    assert len(dirs) == 1
    assert dirs[0].endswith(b'ansible/plugins/collections/ansible_collections/acme/test')

    dirs = list(list_collection_dirs(coll_filter='acme'))
    assert len(dirs) == 1

# Generated at 2022-06-20 13:38:38.928283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = "/home/ansible/test"
    coll_filter = 'ns1.coll1'
    coll_dirs = list(list_collection_dirs(search_path, coll_filter))
    assert coll_dirs == [b'/home/ansible/test/ansible_collections/ns1/coll1']

    search_path = "/home/ansible/test"
    coll_filter = 'ns1'
    coll_dirs = list(list_collection_dirs(search_path, coll_filter))
    assert coll_dirs == [b'/home/ansible/test/ansible_collections/ns1/coll1', b'/home/ansible/test/ansible_collections/ns1/coll2']

# Generated at 2022-06-20 13:38:44.915742
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = ['/etc', '/does/not/exist', '/etc/ansible']

    ret_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert '/etc' in ret_paths
    assert '/etc/ansible' in ret_paths
    assert '/does/not/exist' not in ret_paths



# Generated at 2022-06-20 13:38:51.212590
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ansible_galaxy_cli', 'tests', 'data', 'galaxy-roles')
    actual = list(list_collection_dirs([path]))

# Generated at 2022-06-20 13:39:01.290810
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil

    def _mk_ns_and_coll_dir(path, namespace, collection):
        b_coll = to_bytes(collection)
        b_ns = to_bytes(namespace)
        os.mkdir(to_bytes(os.path.join(temp_dir, path, b_ns)))
        os.mkdir(to_bytes(os.path.join(temp_dir, path, b_ns, b_coll)))

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 13:39:11.774184
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import time
    import glob

    tmpdir = tempfile.mkdtemp()

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)

    paths = []
    for dummy in range(0, 2):
        paths.append(tempfile.mkdtemp(dir=tmpdir))
        for ns in range(1, 3):
            ns_path = os.path.join(paths[-1], 'ns%d' % ns)
            os.mkdir(ns_path)
            for coll in range(1, 3):
                coll_path = os.path.join(ns_path, 'coll%d' % coll)
                os.mkdir(coll_path)

# Generated at 2022-06-20 13:39:17.917672
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/does/not/exist"])) == []
    assert list(list_valid_collection_paths(["/ansible/collection.conf"])) == []
    assert list(list_valid_collection_paths(["/ansible/ansible_collections"])) != []
    assert list(list_valid_collection_paths(["/ansible/ansible_collections/"])) != []

# Generated at 2022-06-20 13:39:28.451532
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_path = os.path.join(os.path.dirname(__file__), 'unit/list_collection_dirs/test_data')
    os.makedirs(test_path)

    errmsg = "Incorrect number of paths returned for list_valid_collection_paths"

    # default (empty) paths should find a single test path
    search_paths = []
    assert len(list(list_valid_collection_paths(search_paths))) == 1, errmsg

    # non existent path should warn but not return the bad path
    search_paths = ['nonesuch']
    assert len(list(list_valid_collection_paths(search_paths, True))) == 0, errmsg

    # file should warn and not return itself
    search_paths = [test_path]
    assert len

# Generated at 2022-06-20 13:40:15.798470
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # None should load defaults
    assert list(list_valid_collection_paths(None))

    # Should load defaults if empty list passed
    assert list(list_valid_collection_paths([]))

    # if we invent a fake path, warn if not found
    assert not list(list_valid_collection_paths(["this/is/not/a/path"], warn=True))

    # if path exists but not dir, warn
    assert not list(list_valid_collection_paths([os.getcwd()], warn=True))

    # if path doesn't exist, warn
    assert not list(list_valid_collection_paths(["/this/is/not/a/path"], warn=True))

    # It should find collections at the root of search path
    # It should find collections under ansible_collections
    #

# Generated at 2022-06-20 13:40:26.817523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    tmpdir = tempfile.mkdtemp()

    coll_paths = [
        tmpdir,
        '/usr/share/ansible',
        '/usr/share/ansible2',
        '/opt/ansible',
        '/opt/ansible2',
    ]

    # test valid collection paths
    for path in coll_paths:
        assert path in list_valid_collection_paths(search_paths=coll_paths)

    # test missing collection paths
    with pytest.raises(AnsibleError):
        list(list_valid_collection_paths(search_paths=['/nowhere']))

    # test non-dir collection paths
    with pytest.raises(AnsibleError):
        list(list_valid_collection_paths(search_paths=['/etc']))

   

# Generated at 2022-06-20 13:40:41.211747
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # remember original loaded paths
    search_paths = AnsibleCollectionConfig.collection_paths

    # cleanup paths loaded from config or default
    AnsibleCollectionConfig.collection_paths = []

    # - test empty search list
    assert (list_valid_collection_paths([]) is not None)

    # - test empty search list and warn
    assert (list_valid_collection_paths([], warn=True) is not None)

    # - test search list with bad paths
    assert (list_valid_collection_paths(['/tmp/doesnotexist', './tmp/doesnotexist2', 'test']) is not None)

    # - test search list with good paths
    assert (list_valid_collection_paths(['/tmp', './tmp']) is not None)

    # reload original paths loaded from config
    Ans

# Generated at 2022-06-20 13:40:47.141110
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from collections import defaultdict
    from ansible.utils.collection_loader import list_collection_dirs

    # collection directory structure
    #     base/
    #         ansible_collections/
    #             testns1/
    #                 testcoll1/
    #                 testcoll2/
    #             testns2/
    #                 testcoll3/
    #                 testcoll4/
    #         ansible_collections2/
    #             testns3/
    #                 testcoll5/
    #                 testcoll6/
    #             testns4/
    #                 testcoll7/
    #                 testcoll8/

    import shutil
    import tempfile

# Generated at 2022-06-20 13:40:56.903281
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.list_valid_collection_paths import list_valid_collection_paths
    from ansible.module_utils.common.collections import AnsibleCollectionConfig

    # test default paths
    paths = list(list_valid_collection_paths())
    assert paths == AnsibleCollectionConfig.collection_paths

    # test empty
    paths = list(list_valid_collection_paths([]))
    assert paths == []

    # test default + local
    paths = list(list_valid_collection_paths(['/tmp']))
    assert paths == AnsibleCollectionConfig.collection_paths + ['/tmp']


# Generated at 2022-06-20 13:41:04.745506
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = ['/tmp']
    for coll_path in list_valid_collection_paths(coll_paths):
        assert coll_path == '/tmp'

    # Test this function with a list containing a non existing path
    # and a non-directory path
    coll_paths = ['/tmp', 'this_does_not_exist', '/usr']
    with display.captured() as captured:
        coll_paths = [path for path in list_valid_collection_paths(coll_paths, warn=True)]
        assert not coll_paths

    # Test this function with a non existing path
    # and a non-directory path
    coll_paths = ['/tmp']

# Generated at 2022-06-20 13:41:15.687399
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    search_paths = []

    # test valid search paths
    tmp_dir = tempfile.mkdtemp()
    search_paths.append(tmp_dir)
    # 2 levels deep
    tmp_dir2 = tempfile.mkdtemp(dir=tmp_dir)
    tmp_dir3 = tempfile.mkdtemp(dir=tmp_dir2)
    os.mkdir(os.path.join(tmp_dir3, 'mycoll'))
    # 2 levels deep
    tmp_dir4 = tempfile.mkdtemp(dir=tmp_dir)
    tmp_dir5 = tempfile.mkdtemp(dir=tmp_dir4)
    os.mkdir(os.path.join(tmp_dir5, 'mycoll2'))

    # test

# Generated at 2022-06-20 13:41:20.825375
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Unit test to run against function list_valid_collection_paths """
    from ansible.module_utils._text import to_native
    import tempfile
    import shutil

    tdir = tempfile.mkdtemp()
    collpath = os.path.join(tdir, 'ansible_collections')
    os.makedirs(collpath)

    # create a valid collection to test for
    collection_dir = os.path.join(collpath, 'someorg', 'somecollection' )
    os.makedirs(collection_dir)
    open(os.path.join(collection_dir, 'README.md'), 'a').close()


# Generated at 2022-06-20 13:41:25.476065
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    If a collection filter is passed, we expect to only see results that match that filter.
    :return:
    """
    coll_filter = 'ansible_collections.namespaceA.colA.plugins.module_utils'
    # Test the case of a valid collection directory passed in
    search_paths = ['/tmp/collections/1']
    colls = list_collection_dirs(search_paths, coll_filter)
    assert len(colls) == 1

# Generated at 2022-06-20 13:41:29.842105
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['foo', 'bar']
    filtered_paths = [os.path.abspath(os.path.curdir), os.path.abspath(os.path.expanduser('~'))]
    assert list(list_valid_collection_paths(paths)) == filtered_paths

# Generated at 2022-06-20 13:42:45.790707
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Fake mocks for stubbing out os.path.* checks
    """

    # mock existing_path
    from functools import partial
    os.path.exists = partial(exists_mock, True)

    # mock path that is a dir
    os.path.isdir = partial(isdir_mock, True)

    # mock path that is a file
    os.path.isfile = partial(isfile_mock, False)

    # mock path that does not exist
    os.path.exists = partial(exists_mock, False)

    # mock path that is not a dir
    os.path.isdir = partial(isdir_mock, False)

    # mock path that is not a file
    os.path.isfile = partial(isfile_mock, True)

    # Function

# Generated at 2022-06-20 13:42:50.360748
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert ':/usr/share/ansible/collections' in list_valid_collection_paths()

# Generated at 2022-06-20 13:42:58.724858
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-20 13:43:09.851387
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import mock

    # test with no search_paths and no config file
    p = list_valid_collection_paths()
    assert len(p) == 1
    assert p[0] == "/usr/share/ansible/collections"

    # test that search_paths overrides config file
    b_coll_dir = b"my_own_dir"
    with mock.patch.object(AnsibleCollectionConfig, 'get_config_data', return_value=["/usr/share/ansible/collections", "/dev/null/collections"]):
        p = list_valid_collection_paths()
        assert len(p) == 1
        assert p[0] == "/usr/share/ansible/collections"

    # test that we get both search_paths and config file paths in list