

# Generated at 2022-06-20 13:33:24.334406
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # NOTE: all of the test collections are in the test/roles_collections directory
    collections_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'roles_collections')

    # NOTE: this adds test/roles_collections to the search paths
    list_collection_dirs([collections_dir])


# Generated at 2022-06-20 13:33:31.212412
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test if list_valid_collection_paths returns the same list of paths on each call
    """
    paths = list(list_valid_collection_paths())
    assert paths == list(list_valid_collection_paths())

# Generated at 2022-06-20 13:33:35.847248
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Make sure it is a generator
    assert list_valid_collection_paths() is not None

    # Make sure a passed list is returned
    assert list(list_valid_collection_paths(['/usr/share/ansible/'])) == ['/usr/share/ansible/']

    # Make sure default config is returned
    assert list(list_valid_collection_paths()) == ['~/.ansible/collections']



# Generated at 2022-06-20 13:33:46.276229
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from .collections_loader import path_dwim
    searchpaths = [path_dwim('../../../test/units/module_utils/test_collections'),
                   path_dwim('../../../test/units/module_utils/test_collections/ansible_collections/')]

    assert len(list(list_collection_dirs(searchpaths, 'mynamespace.mycollection'))) == 1
    assert len(list(list_collection_dirs(searchpaths))) == 2
    assert len(list(list_collection_dirs(searchpaths, 'mynamespace'))) == 2
    assert len(list(list_collection_dirs(searchpaths, 'zzz'))) == 0

# Generated at 2022-06-20 13:33:56.831254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    names = set()
    for d in list_collection_dirs():
        assert os.path.isdir(d), "Failed for " + d
        assert is_collection_path(d)
        coll_path = os.path.splitext(d)[0].split(os.path.sep)[-2:]
        names.add(coll_path[0])
        assert os.path.isfile(os.path.join(d, 'meta', 'collection.yml'))
    assert len(names) > 10  # we have at least 10 collections
    # we shouldn't find any if the filter doesn't match
    assert len(list(list_collection_dirs(coll_filter='nonexistent.collection'))) == 0

# Generated at 2022-06-20 13:34:06.223788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Return empty list if paths are None
    assert list(list_valid_collection_paths(None)) == []
    # Return empty list if paths are empty
    assert list(list_valid_collection_paths([])) == []
    # Return empty list if defaults is empty
    assert list(list_valid_collection_paths()) == []
    # Return non-empty list with path
    paths = ['/path/to/collections']
    assert list(list_valid_collection_paths(paths)) == paths
    # Return non-empty list with path and defaults
    default = ['/path/to/default_collections']
    assert list(list_valid_collection_paths(paths, default)) == paths + default
    # Return non-empty list with default
    default = ['/path/to/default_collections']


# Generated at 2022-06-20 13:34:08.838778
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths is not None

# Generated at 2022-06-20 13:34:19.140200
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # Create temp directories
    temp_dir = tempfile.TemporaryDirectory()
    temp_coll_dir = os.path.join(temp_dir.name, 'ansible_collections')
    temp_ns_dir = os.path.join(temp_coll_dir, 'test')
    temp_coll_test_dir = os.path.join(temp_ns_dir, 'test')

    # Create collection directory structure
    os.makedirs(temp_coll_test_dir)
    os.makedirs(os.path.join(temp_coll_test_dir, 'plugins'))

    # Create empty collection
    temp_ns_dir_empty = os.path.join(temp_coll_dir, 'empty')
    os.makedirs(temp_ns_dir_empty)

    # Create invalid

# Generated at 2022-06-20 13:34:30.532656
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    env_vars = ['ANSIBLE_COLLECTIONS_PATHS']
    current_env = {}
    for v in env_vars:
        if v in os.environ:
            current_env[v] = os.environ[v]

    def restore():

        for v in env_vars:
            if v in current_env:
                os.environ[v] = current_env[v]
            else:
                del os.environ[v]


# Generated at 2022-06-20 13:34:34.383049
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil

    # setup invalid paths and valid paths
    invalid_paths = ['', 'fake_path', 'fake_path/fake_path/', 'fake_path/fake_path/fake_path']
    valid_paths = []

    # create fake valid collection paths and add to valid_paths list
    for x in range(5):
        tmpdir = tempfile.mkdtemp()
        tmpdir = os.path.join(tmpdir, 'ansible_collections')
        os.mkdir(tmpdir)
        valid_paths.append(tmpdir)

    # create fake valid collection paths and add to valid_paths list
    # where the ansible_collections is not the last directory in
    # the path
    for x in range(5):
        tmpdir = tempfile.mkd

# Generated at 2022-06-20 13:34:46.576111
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from pprint import pprint
    import tempfile

    tmpdir = tempfile.mkdtemp(prefix='ansible_collections_test_')
    tmpdirb = to_bytes(tmpdir, errors='surrogate_or_strict')

    for (top, dirs, files) in os.walk(to_bytes("./collections", errors='surrogate_or_strict')):
        for dir in dirs:
            name = dir.split('.')
            if len(name) == 1:
                # dir is a 'namespace'
                os.mkdir(os.path.join(tmpdirb, dir))
            elif len(name) == 2:
                # dir is a collection
                os.mkdir(os.path.join(tmpdirb, name[0]))
                os.mkdir

# Generated at 2022-06-20 13:34:58.954497
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils import plugin_docs
    fixture = plugin_docs.load_fixture('collection_loader/list_collection_dirs.yml')
    for item in fixture:
        # filter for default search paths
        results = [to_bytes(x) for x in list_collection_dirs()]
        assert set(results) == set(item['expected_default'])

        # filter for a specific namespace
        results = [to_bytes(x) for x in list_collection_dirs(coll_filter=item['namespace'])]
        assert set(results) == set(item['expected_namespace'])

        # filter for a specific collection
        results = [to_bytes(x) for x in list_collection_dirs(coll_filter=item['collection'])]

# Generated at 2022-06-20 13:35:03.408302
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.config.manager import ConfigManager
    cm = ConfigManager(None, [], None)
    collection_dirs = list(list_collection_dirs(cm.data['collections_paths']))
    assert len(collection_dirs) > 0
    assert type(collection_dirs) == list


# Generated at 2022-06-20 13:35:12.139572
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths([]) == []

    assert list_valid_collection_paths([None]) == []

    assert list_valid_collection_paths([None, 'but_not_empty', None]) == []

    assert list_valid_collection_paths(['not_a_directory']) == []

    assert list_valid_collection_paths(['not_a_directory', 'not_a_directory']) == []

# Generated at 2022-06-20 13:35:24.275195
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == list_valid_collection_paths(warn=True) == []

    assert list(list_valid_collection_paths(['/tmp/does_not_exist'])) == []
    assert list(list_valid_collection_paths(['/tmp/does_not_exist'], warn=True)) == \
        ['/tmp/does_not_exist']

    # FIXME: this is a fragile test dependent on someone having /etc/ansible/ansible.cfg
    assert len(os.listdir(list_valid_collection_paths([b'/etc/ansible/ansible.cfg'])[0])) > 0


# Generated at 2022-06-20 13:35:32.432829
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert '/etc/ansible/ansible_collections/notns/collection/' in list_collection_dirs(coll_filter='notns.collection')
    assert '/etc/ansible/ansible_collections/ns/collection' in list_collection_dirs(coll_filter='ns.collection')
    assert '/etc/ansible/ansible_collections/notns/collection' in list_collection_dirs(coll_filter='notns')
    assert '/etc/ansible/ansible_collections/ns/collection' in list_collection_dirs(coll_filter='ns')

# Generated at 2022-06-20 13:35:43.501568
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Run tests for list_collection_dirs.
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.collection_loader import list_collection_dirs

    def _check_coll_dirs(search_path, namespace, collection, expected, warn=False):
        """
        :param search_path: a path to search in.
        :param namespace: expected collection namespace.
        :param collection: expected collection name.
        :param expected:  True or False to indicate if the collection is expected to be found.
        :param warn: True or False to indicate if a warning should be displayed.
        :return: None.
        """
        display = Display()
        display.verbosity = 0

        # we do not want to pollute the default search paths
        search_paths = []

# Generated at 2022-06-20 13:35:48.051790
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/does/not/exist/path', '/etc/ansible', '/root']
    filtered_paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert filtered_paths == ['/etc/ansible'], 'Did not filter bad search_paths: %s' % filtered_paths



# Generated at 2022-06-20 13:35:53.317971
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    coll_filter = 'ansible_collections.mycoll.myplugin'
    expected_path = os.path.join('/tmp/ansible_collections', os.path.sep.join(coll_filter.split('.')))
    expected_path = os.path.realpath(expected_path)

    for path in list_collection_dirs(search_paths, coll_filter):

        assert path == expected_path

# Generated at 2022-06-20 13:36:04.673932
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test a non-existing path
    bad_path = "/var/no/such/path"

    assert list(list_valid_collection_paths([bad_path])) == []

    # Test a path that exists but is not a directory
    import tempfile
    fd, path = tempfile.mkstemp()

    assert list(list_valid_collection_paths([bad_path, path])) == [path]

    # Test a path that exists and is a directory
    new_path = tempfile.mkdtemp()
    assert list(list_valid_collection_paths([bad_path, new_path])) == [new_path]

# Generated at 2022-06-20 13:36:19.247769
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    list_valid_collection_paths(None, False)

# Generated at 2022-06-20 13:36:29.366041
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    executable_path = os.path.dirname(os.path.abspath(__file__))

    # Test with a empty search_paths list
    search_paths = []
    result = list(list_valid_collection_paths(search_paths))
    assert result == []

    # non existing file
    search_paths = ["/fake_file"]
    result = list(list_valid_collection_paths(search_paths))
    assert result == []

    # existing file
    search_paths = [os.path.join(executable_path, "file.py")]
    result = list(list_valid_collection_paths(search_paths))
    assert result == [os.path.join(executable_path, "file.py")]

    # non existing dir
    search_path

# Generated at 2022-06-20 13:36:34.263523
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['test_path1', 'test_path2']
    expected = ['test_path1', 'test_path2']

    generator = list_valid_collection_paths(search_paths)
    assert list(generator) == expected



# Generated at 2022-06-20 13:36:43.071770
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        'tmp',
        'test/test_collections/missing_ns',
        'test/test_collections/invalid_ns',
        'test/test_collections/valid_ns',
        'test/test_collections/valid_ns2',
    ]
    results = list(list_valid_collection_paths(search_paths, warn=False))
    assert len(results) == 3
    assert 'test/test_collections/invalid_ns' not in results, "Invalid search_path should not be included"
    assert 'test/test_collections/missing_ns' not in results, "Missing search_path should not be included"


# Generated at 2022-06-20 13:36:50.059280
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid = list_valid_collection_paths(["/etc/ansible/collection", "/home/me/my_collection"])
    assert "/etc/ansible/collection" in valid
    assert "/home/me/my_collection" in valid

# Generated at 2022-06-20 13:36:51.495445
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Unit test for function list_collection_dirs"""
    pass

# Generated at 2022-06-20 13:37:03.038543
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.collections.plugins.loader_utils import get_collection_root
    from ansible.collections.plugins.loader_utils import get_collection_base_path

    coll_root = get_collection_root()
    coll_paths = AnsibleCollectionConfig.collection_paths

    # Test of ansible collection directories
    # Test all ansible collections
    all_collections = list_collection_dirs(coll_paths, None)
    assert len(all_collections) > 0
    # Test a specific collection
    all_collections = list_collection_dirs(coll_paths, 'ansible_namespace.collection_name')
    assert len(all_collections) > 0

    # Test non ansible collections
    # Test all collections


# Generated at 2022-06-20 13:37:13.094128
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import uuid
    import os

    # create tmp path for search_path, but ensure it's not already set
    tmp_coll_path = tempfile.mkdtemp()
    base_search_path = to_bytes(tmp_coll_path)
    assert base_search_path not in AnsibleCollectionConfig.collection_paths

    # create nested directories with collections

# Generated at 2022-06-20 13:37:17.344301
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from tempfile import TemporaryDirectory

    dir_paths = []
    for x in range(10):
        dir_paths.append(TemporaryDirectory().name)

    td = TemporaryDirectory()
    file_path = td.name + "-file"
    with open(file_path, 'w') as fp:
        fp.write("file")

    dir_paths.append(file_path)

    assert len(list_valid_collection_paths(dir_paths, warn=True)) == 0

# Generated at 2022-06-20 13:37:19.613994
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ['test/units/module_utils/legacy_collections']

    result = list_collection_dirs(search_paths)

    assert len(result) == 2
    assert 'test.foo' in result

# Generated at 2022-06-20 13:37:44.743186
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(search_paths=['/usr/share/ansible/ansible_collections'], coll_filter=None)) == ['/usr/share/ansible/ansible_collections/ansible/__init__.py']
    assert list(list_collection_dirs(search_paths=['/usr/share/ansible/ansible_collections'], coll_filter='ansible')) == ['/usr/share/ansible/ansible_collections/ansible/__init__.py']

# Generated at 2022-06-20 13:37:47.719726
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/tmp', '/tmp/test']
    actual = list(list_valid_collection_paths(search_paths))
    assert actual == ['/tmp', '/tmp/test']



# Generated at 2022-06-20 13:37:51.880021
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from tempfile import mkdtemp

    dirs = set()

    for _ in range(0, 5):
        dirs.add(mkdtemp())

    dirs.add('/no_such_dir')
    dirs.add('/etc/hosts')

    l = list(list_valid_collection_paths(dirs))

    assert len(l) == len(dirs) - 2



# Generated at 2022-06-20 13:37:59.368631
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for list_valid_collection_paths
    """
    paths1 = ['~/mypath', '/nonexistent', '/tmp']
    paths2 = ['~/mypath', '/etc', '/tmp']

    assert list(list_valid_collection_paths(paths1)) == ['/tmp']
    assert list(list_valid_collection_paths(paths2)) == ['~/mypath', '/etc', '/tmp']

# Generated at 2022-06-20 13:38:04.987359
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, '..', '..', '..', '..', 'test', 'units', 'utils', 'ansible_collections')
    test_dir = os.path.abspath(test_dir)
    test_dir = os.path.join(test_dir, 'temp_collection_dir')
    for c in list_collection_dirs([test_dir]):
        assert os.path.isdir(c)

# Generated at 2022-06-20 13:38:08.845756
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with the path /tmp/bad_path
    assert '/tmp/bad_path' not in list(list_valid_collection_paths(search_paths=['/tmp/bad_path']))

    # Test with the existing path /tmp
    assert '/tmp' in list(list_valid_collection_paths(search_paths=['/tmp']))


# Generated at 2022-06-20 13:38:14.849286
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ret = list(list_collection_dirs(['tests/unit/data/collections'], 'ansible_collections.my.my_namespace2'))
    assert len(ret) == 1
    assert ret[0].endswith('/tests/unit/data/collections/ansible_collections/my/my_namespace2/my_collection2')

# Generated at 2022-06-20 13:38:19.748557
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collections = list(list_collection_dirs(search_paths=['/usr/share', '//garbage///'], coll_filter='ansible_collections.namespace.collection'))

    assert len(collections) == 1
    assert os.path.basename(collections[0]) == 'collection'

# Generated at 2022-06-20 13:38:27.437279
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile

    # Create a test directory with some stuff in it
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 13:38:32.109365
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    searchpath = ['tests/unit/cli/ansible_collections', 'tests/unit/collection_loader/ansible_collections']
    for dirname in list_collection_dirs(searchpath):
        assert os.path.isdir(dirname)

# Generated at 2022-06-20 13:38:58.714325
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    collection_config return search paths will be different based on
    whether the default paths exist or not so the test cases
    need to be handled separately
    """
    from ansible.module_utils.ansible_release import __version__

    search_paths = ['/does/not/exist',
                    '/dev/null',
                    '.',
                    '__pycache__']

    try:
        search_paths_returned = list(list_valid_collection_paths(search_paths, warn=False))

        assert len(search_paths_returned) == 0

    except AnsibleError:
        # the mock module will not exist and when we use the default path
        # that contains the __init__.py file
        pass


# Generated at 2022-06-20 13:39:06.519374
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    current_path = os.path.dirname(os.path.realpath(__file__))
    valid_coll_path = os.path.join(current_path, 'valid_collection_path')
    invalid_coll_path = os.path.join(current_path, 'invalid_collection_path')
    missing_coll_path = '/var/tmp/not_a_real_path'
    search_paths = [valid_coll_path, missing_coll_path, invalid_coll_path]

    # filter out invalid search_paths
    actual = list_valid_collection_paths(search_paths, warn=True)
    assert len(list(actual)) == 1
    assert list(actual)[0] == valid_coll_path

# Generated at 2022-06-20 13:39:15.166389
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['/path/to/my/collections',
                    '/path/to/my/other/collections',
                    '/path/to/my/non/existent/collections',
                    '/path/to/my/other/bad/collections']

    collection_list = list(list_collection_dirs(search_paths))
    collection_list.sort()
    expected_collections = [b'/path/to/my/collections/ansible_collections/acme/test_collection',
                            b'/path/to/my/other/collections/ansible_collections/acme/test_collection']
    expected_collections.sort()
    assert collection_list == expected_collections

# Generated at 2022-06-20 13:39:18.214504
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/foo', 'bar', '/baz', 'bat']
    result = list(list_valid_collection_paths(search_paths))
    assert result == search_paths[2:]



# Generated at 2022-06-20 13:39:27.725807
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = [
        './test/',
        './ansible_collections/',
        './ansible_collections/test/',
        './ansible_collections/test/plugins/',
        './ansible_collections/test/plugins/modules/',
        './ansible_collections/test/plugins/modules/net_tools/',
        './ansible_collections/test/plugins/module_utils/',
        './ansible_collections/test/plugins/module_utils/network/',
    ]
    found = [path for path in list_collection_dirs(search_paths=["./test"])]
    assert sorted(found) == sorted(expected)

# Generated at 2022-06-20 13:39:33.128918
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = {"c:/foo/bar", "~/baz", "~/dev"}
    valid_paths = list(list_valid_collection_paths(paths, warn=True))

    for path in valid_paths:
        assert os.path.exists(path) and os.path.isdir(path)


# Generated at 2022-06-20 13:39:37.554320
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = list_valid_collection_paths()
    assert len(search_paths) > 0

    paths = {'/foo/bar/baz', '/baz/bar/foo', 'baz/bar/foo'}
    search_paths = list_valid_collection_paths(paths)
    assert len(search_paths) == 3

# Generated at 2022-06-20 13:39:48.675358
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil

    old_env = None
    if 'ANSIBLE_COLLECTIONS_PATHS' in os.environ:
        old_env = os.environ['ANSIBLE_COLLECTIONS_PATHS']
        del os.environ['ANSIBLE_COLLECTIONS_PATHS']


# Generated at 2022-06-20 13:40:03.212610
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil
    import collections
    import os

    # required to ensure a clean run first time
    try:
        shutil.rmtree("utest_collection_path")
    except OSError:
        pass

    # create simple test collection
    os.mkdir("utest_collection_path")
    os.mkdir("utest_collection_path/ansible_collections")
    os.mkdir("utest_collection_path/ansible_collections/test_ns")
    os.mkdir("utest_collection_path/ansible_collections/test_ns/test_coll")
    os.mkdir("utest_collection_path/ansible_collections/test_ns/test_coll2")

# Generated at 2022-06-20 13:40:13.821387
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

# Generated at 2022-06-20 13:40:59.449590
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os

    test_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../fixtures/test_collections')
    assert list(list_collection_dirs([test_path])) == [
        os.path.join(test_path, b'ansible_collections/collection_a'),
        os.path.join(test_path, b'ansible_collections/collection_b')
    ]

    assert list(list_collection_dirs([test_path], 'collection_a')) == [
        os.path.join(test_path, b'ansible_collections/collection_a')
    ]


# Generated at 2022-06-20 13:41:05.198492
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    valid_paths = list_collection_dirs(search_paths=['tests/unit/utils/test_collections/ansible_collections/'])
    expected = [
        'tests/unit/utils/test_collections/ansible_collections/testns/testcoll0',
        'tests/unit/utils/test_collections/ansible_collections/testns/testcoll1',
        'tests/unit/utils/test_collections/ansible_collections/testns/testcoll2'
    ]

    assert expected == list(valid_paths)

    collection_filter = 'testns.testcoll1'

# Generated at 2022-06-20 13:41:17.410473
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths([])) == []

    assert list(list_valid_collection_paths(['/does/not/exist'])) == []

    assert list(list_valid_collection_paths(['/usr/bin'])) == []

    assert list(list_valid_collection_paths(['/usr/bin', '/does/not/exist'])) == []

    assert list(list_valid_collection_paths()) == [
        '/etc/ansible/collections',
        '/usr/share/ansible/collections'
    ]

    assert list(list_valid_collection_paths(['.'], warn=True)) == ['.']

    assert list(list_valid_collection_paths(['/'], warn=True)) == ['/']



# Generated at 2022-06-20 13:41:29.128089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collections_dirs = list_collection_dirs()

    assert '/Users/chaonan/Workspace/ansible/collections/ansible_collections/jctanner/test_collection1' in list_collections_dirs
    assert '/Users/chaonan/Workspace/ansible/collections/ansible_collections/jctanner/test_collection2' in list_collections_dirs
    assert '/Users/chaonan/Workspace/ansible/collections/ansible_collections/jctanner/test_collection3' in list_collections_dirs

# Generated at 2022-06-20 13:41:38.909364
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs(search_paths=['test/data/collections/good', 'test/data/collections/bad'],
                                                coll_filter=None))
    assert len(collection_dirs) == 2, 'list_collection_dirs returns all collections in test path'
    assert 'test/data/collections/good/testns/testcoll1' in collection_dirs, 'list_collection_dirs includes test/data/collections/good/testns/testcoll1'
    assert 'test/data/collections/good/testns/testcoll2' in collection_dirs, 'list_collection_dirs includes test/data/collections/good/testns/testcoll2'


# Generated at 2022-06-20 13:41:44.675689
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/foo/bar', '/this/path/does/not/exist', '/tmp']
    valid_paths = list(list_valid_collection_paths(test_paths))

    assert len(valid_paths) == 1
    assert '/tmp' in valid_paths

# Generated at 2022-06-20 13:41:50.511047
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test one invalid, one valid and one default path
    paths = ['/invalid/path/', '/valid/path', '/default/path']
    expected_paths = ['/valid/path', '/default/path']

    # call function and validate
    for (index, path) in enumerate(list_valid_collection_paths(paths)):
        assert path == expected_paths[index]


# Generated at 2022-06-20 13:42:04.689177
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # collection not found
    with pytest.raises(AnsibleError) as e:
        list_collection_dirs(coll_filter='fred.douglas')
    assert "Invalid collection pattern supplied: fred.douglas" in to_text(e.value)

    # run search, list all namespaces
    coll_dirs = list(list_collection_dirs())

    # no collections in namespace 'fred'
    coll_dirs = list(list_collection_dirs(coll_filter='fred'))
    assert len(coll_dirs) == 0

    # list of collection directories in namespace 'ansible'
    coll_dirs = list(list_collection_dirs(coll_filter='ansible'))
    assert len(coll_dirs) == 1

    # show one collection in namespace 'ansible'


# Generated at 2022-06-20 13:42:11.963954
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ["/tmp", "invalid_path"]
    actual_paths = list(list_valid_collection_paths(test_paths, warn=True))
    assert actual_paths == ['/tmp'], "Expect paths to be filtered for non existing or invalid dirs."

# Generated at 2022-06-20 13:42:14.406479
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_paths = list_valid_collection_paths([])
    assert len(valid_paths) >= 0