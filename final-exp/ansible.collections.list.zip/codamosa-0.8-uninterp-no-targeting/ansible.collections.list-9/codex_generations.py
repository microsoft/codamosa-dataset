

# Generated at 2022-06-20 13:33:27.841017
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        '/not/a/real/path',
        '/usr/share/ansible/nonexistent',
        './test_data/doesnotexist',
        './test_data/fakecollections',
    ]

    # Test all collections
    dirs = list(list_collection_dirs(search_paths=search_paths))
    assert len(dirs) == 4

    # Test filtered collections
    dirs = list(list_collection_dirs(coll_filter='namespace_a.collection_a', search_paths=search_paths))
    assert len(dirs) == 1

    dirs = list(list_collection_dirs(coll_filter='namespace_a.collection_b', search_paths=search_paths))
    assert len(dirs) == 1

# Generated at 2022-06-20 13:33:34.817645
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        '/tmp/bogus/path',
        '/tmp/another/bogus/path',
    ]
    for path in list_valid_collection_paths(paths):
        assert path == paths[0]
        paths.remove(path)
    assert len(paths) == 0

# Generated at 2022-06-20 13:33:45.304745
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile
    import ansible.constants as C


# Generated at 2022-06-20 13:33:57.120254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes
    search_paths = [
        '/path/to/foo',
        '/path/to/bar/ansible_collections',
    ]
    # If a filters is specified
    actual_collection_dirs = list_collection_dirs(search_paths=search_paths,
                                                  coll_filter='namespace.collection')
    expected_collection_dir = os.path.join(to_bytes(search_paths[1]),
                                           to_bytes('namespace'),
                                           to_bytes('collection'))
    assert [expected_collection_dir] == actual_collection_dirs
    # If a filters is not specified
    actual

# Generated at 2022-06-20 13:34:03.602581
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        '/non_existing',
        '/etc/ansible/collections',
        '/usr/share/ansible/collections',
    ]

    result = list(list_valid_collection_paths(paths, warn=False))
    assert len(result) == 2
    assert result[0] == '/etc/ansible/collections'
    assert result[1] == '/usr/share/ansible/collections'

# Generated at 2022-06-20 13:34:07.678734
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [b'foo', b'bar']
    test_result = list(list_valid_collection_paths(test_paths))
    assert b'foo' in test_result
    assert b'bar' in test_result

# Generated at 2022-06-20 13:34:12.301606
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(['/path/does/not/exist', 'somewhere/over/the/rainbow']))
    assert [] == dirs

# Generated at 2022-06-20 13:34:13.539754
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # TODO - this test should be run against a full ansible install dir, perhaps a docker-compose setup
    assert False

# Generated at 2022-06-20 13:34:14.820017
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths())


# Generated at 2022-06-20 13:34:20.660726
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # If a collection is defined twice in the search path, only return it once
    dirs = list(list_collection_dirs(search_paths=['test/testdata/collections']))
    assert len(dirs) == 1

    # If a collection is not defined, don't return it and don't error out
    dirs = list(list_collection_dirs(search_paths=['test/testdata/collections'], coll_filter='does_not_exist'))
    assert len(dirs) == 0

# Generated at 2022-06-20 13:34:34.414114
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    test_search_path = [os.path.join(os.path.dirname(__file__), '../../test/unit/utils/ansible_collections')]
    expected_ns = ['test']
    expected_coll = ['testcoll']

    assert list(list_collection_dirs(test_search_path)) is not None

    for c in list_collection_dirs(test_search_path):
        assert c.endswith('test/testcoll')
        assert os.path.basename(os.path.dirname(c)) in expected_ns
        assert os.path.basename(c) in expected_coll

    assert len(list(list_collection_dirs(test_search_path, 'test'))) == 1

# Generated at 2022-06-20 13:34:42.409805
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'testcoll', 'testns', 'plugins', 'module_utils', 'test_utils'))
    os.makedirs(os.path.join(tmpdir, 'ansible_collections', 'testcoll', 'testns', 'plugins', 'modules'))
    for coll in list_collection_dirs([tmpdir]):
        assert os.path.exists(coll)
        assert 'testcoll' in coll
        assert 'testns' in coll

# Generated at 2022-06-20 13:34:47.238354
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths(search_paths=['/tmp/NONEXISTENT'])) == []
    assert list(list_valid_collection_paths(search_paths=['/tmp'])) == ['/tmp']
    assert list(list_valid_collection_paths(search_paths=['/tmp/test_coll'])) == ['/tmp/test_coll']
    assert list(list_valid_collection_paths(search_paths=['/tmp/test_coll', '/tmp'], warn=False)) == ['/tmp/test_coll', '/tmp']


# Generated at 2022-06-20 13:34:59.148538
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree

    # create a tmp dir with a fake collection path containing fake collections
    temp_path = tempfile.mkdtemp()
    collections_path = os.path.join(temp_path, 'ansible_collections')
    namespace = os.path.join(collections_path, 'testns')
    collection = os.path.join(namespace, 'testcollection')
    collection2 = os.path.join(namespace, 'testcollection2')
    os.makedirs(collection)
    os.makedirs(collection2)

    # check that function returns dir path of the two test collections
    collection_dirs = list_collection_dirs(search_paths=[temp_path])
    assert len([d for d in collection_dirs]) == 2

    # check that function

# Generated at 2022-06-20 13:35:12.254193
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # global called from within test
    global display

    from ansible.module_utils.six import StringIO

    coll_root = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test', 'unit', 'utils', 'collection_roots')
    coll_dir = os.path.join(coll_root, 'ansible_collections')
    plugin_dir = os.path.join(coll_dir, 'test_namespace', 'test_collection')

    search_paths = [coll_root, os.path.dirname(coll_dir)]
    display = Display()

    # test with one collection root, no filter
    for p in list_collection_dirs():
        pass

    # test with one collection root and filter

# Generated at 2022-06-20 13:35:12.773935
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list(list_collection_dirs()))

# Generated at 2022-06-20 13:35:24.821184
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''Verify that list_valid_collection_paths returns the expected values
    '''
    # Use a temporary directory as our test path
    import tempfile
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 13:35:35.236954
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch
    from ansible_collections.ansible.misc.tests.unit.compat.unittest import TestCase

    class TestFunc(TestCase):
        def setUp(self):
            self.maxDiff = None
            self.tmp_dir = '/tmp/ansible'
            self.mock_collection_config = patch('ansible.utils.collection_loader.AnsibleCollectionConfig')
            self.mock_collection_config = self.mock_collection_config.start()

        def tearDown(self):
            self.mock_collection_config.stop()


# Generated at 2022-06-20 13:35:47.142079
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths()) == list(AnsibleCollectionConfig.collection_paths)
    assert list_valid_collection_paths(['~/foo']).next() == os.path.expanduser('~/foo')
    assert list_valid_collection_paths(['~/bar']).next() == os.path.expanduser('~/bar')

    assert list(list_valid_collection_paths(['~/foo', '~/bar'])) == [os.path.expanduser('~/foo'), os.path.expanduser('~/bar')]

# Generated at 2022-06-20 13:35:51.622201
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test with empty search path
    directories = list(list_collection_dirs(search_paths=[]))
    assert not directories

    test_collection_directory = os.path.join(os.path.dirname(__file__), 'files', 'ansible_collections', 'my_namespace')
    test_collection = 'my_collection'

    # test specific collection
    directories = list(list_collection_dirs(search_paths=[test_collection_directory], coll_filter=(test_collection)))
    assert len(directories) == 1
    assert os.path.basename(directories[0]) == test_collection
    assert os.path.dirname(directories[0]).endswith('my_namespace')

    # test specific collection not in search path

# Generated at 2022-06-20 13:36:08.289625
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths

    # Test for invalid paths
    collection_list_invalid_paths = list_valid_collection_paths(search_paths=["./nonexistent_collections", "./other_invalid_collection"])
    assert list(collection_list_invalid_paths) == []

    # Test for valid path(s)
    collection_list_valid_paths = list_valid_collection_paths(search_paths=["./test_collections"])
    assert list(collection_list_valid_paths) == ["./test_collections"]

    # Test for duplicate paths

# Generated at 2022-06-20 13:36:15.934641
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # set a non-default collections path
    test_path = os.path.join(os.path.dirname(__file__), 'test_collections')
    test_path = os.path.normpath(test_path)
    assert os.path.isdir(test_path)

    # test that a single collection is found
    coll_paths = list(list_collection_dirs([test_path], "ansible_namespace.collection"))
    assert len(coll_paths) == 1
    assert os.path.isdir(coll_paths[0])

    # test with a collection pattern
    coll_paths = list(list_collection_dirs([test_path], "ansible_ns.*"))
    assert len(coll_paths) == 2

# Generated at 2022-06-20 13:36:24.210521
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    b_tmpdir = to_bytes(tmpdir)

    config_paths = ['A', 'B', tmpdir, 'C', os.path.join(tmpdir, 'ansible_collections'), 'D']

    count = 0
    for path in list_valid_collection_paths(config_paths):
        assert path == config_paths[count + 3]
        count += 1

    os.removedirs(tmpdir)
    shutil.rmtree(tmpdir)


# Generated at 2022-06-20 13:36:27.798787
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from os.path import join, dirname, basename, abspath

    module_path = join(dirname(abspath(__file__)), "../../../")
    collection_paths = [module_path]
    for path in list_valid_collection_paths(search_paths=collection_paths):
        print(path)
    assert path == module_path

# Generated at 2022-06-20 13:36:33.792510
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test different combinations of search_paths and coll_filter
    """

    from ansible.config.data import ConfigData

    # default collection paths
    # /etc/ansible/roles
    # ~/.ansible/collections
    # /usr/share/ansible/collections

    # define roles and collections (by namespace) directories
    my_etc_roles = '/etc/ansible/roles/my_etc_roles/'
    my_roles = '/home/myusername/.ansible/my_roles/'
    my_collections = '/home/myusername/.ansible/my_collections/'
    my_usr_collections = '/usr/share/ansible/my_collections/'

    # define collection namespaces

# Generated at 2022-06-20 13:36:43.498406
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils._text import to_native
    from ansible.testing.util.module_common import fail_if_missing

    fail_if_missing(module_name="os", msg="test requires os module",
                    exception=AnsibleError)
    fail_if_missing(module_name="tempfile", msg="test requires tempfile module",
                    exception=AnsibleError)

    import os
    import tempfile

    # Create temporary collection directory
    d = tempfile.mkdtemp()

    # Create a 'ansible_collections' directory
    os.mkdir(os.path.join(d, 'ansible_collections'))

    # Create a dummy collection directory with modules and plugins

# Generated at 2022-06-20 13:36:50.222513
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit Test to test list_collection_dirs()
    """
    collection_dirs = list_collection_dirs("/path_not_exists", "test.test")
    assert isinstance(collection_dirs, type(iter([])))

# Generated at 2022-06-20 13:36:51.256745
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # FIXME
    pass

# Generated at 2022-06-20 13:37:02.842498
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.common.collections import AnsibleCollectionConfig
    from ansible.collections.collection_loader import list_valid_collection_paths

    # test with no search_paths
    search_paths = []
    assert list(list_valid_collection_paths(search_paths=search_paths)) == search_paths

    # test with default search_paths
    assert list(list_valid_collection_paths(search_paths=None)) == AnsibleCollectionConfig.collection_paths

    # test with existing and non-existing search paths
    search_paths = ['/c', '/b']
    assert list(list_valid_collection_paths(search_paths=search_paths, warn=False)) == search_paths

# Generated at 2022-06-20 13:37:12.927335
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    test 1 : assert valid path is in list returned
    '''
    test_1 = list_valid_collection_paths()
    print("Test 1")
    print(test_1)
    assert(True)
    '''
    test 2: assert path returned is a valid directory path
    '''
    test_2 = list_valid_collection_paths()
    print("Test 2")
    print(test_2)
    assert(True)
    '''
    test 3: assert warning is displayed for non-existant paths 
    '''
    test_3 = list_valid_collection_paths()
    print("Test 3")
    print(test_3)
    assert(True)
    '''
    test 4: assert warning is displayed for invalid paths
    '''
    test_4 = list

# Generated at 2022-06-20 13:37:28.775107
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test non existing search path
    paths = list(list_valid_collection_paths(['/random/search/path']))
    assert 0 == len(paths)

    paths = list(list_valid_collection_paths())
    assert len(paths) > 0

    # Test valid search path
    paths = list(list_valid_collection_paths(['/usr']))
    assert len(paths) > 0



# Generated at 2022-06-20 13:37:37.671466
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    #
    # test if defaults are valid paths
    #
    collection_paths = list(list_valid_collection_paths())
    assert len(collection_paths) > 0
    for path in collection_paths:
        assert os.path.isdir(to_bytes(path))
    #
    # test for non existing paths
    #
    non_existing_path = '/non-existing-path'
    collection_paths = list(list_valid_collection_paths(search_paths=[non_existing_path], warn=True))
    assert len(collection_paths) == 0

    #
    # test if default paths are returned
    #
    collection_paths = list(list_valid_collection_paths(search_paths=[]))
    assert len(collection_paths) > 0

# Generated at 2022-06-20 13:37:44.421347
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.cli import CLI
    import shlex
    from tempfile import mkdtemp
    from shutil import rmtree

    working_dir = mkdtemp()


# Generated at 2022-06-20 13:37:53.278554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test that we get back the path provided
    def mock_os_path_exists(path):
        return True

    def mock_os_path_isdir(path):
        return True

    path = 'test_path'
    search_paths = [path]

    with patch('os.path.exists', mock_os_path_exists):
        with patch('os.path.isdir', mock_os_path_isdir):
            result = list(list_valid_collection_paths(search_paths))
            assert path in result

    # test that we get back the path provided
    def mock_os_path_exists(path):
        return False

    path = 'test_path'
    search_paths = [path]


# Generated at 2022-06-20 13:38:04.610853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create some directories in the temp directory
    import tempfile
    tmpdir = tempfile.mkdtemp(prefix='ansible_module_utils_entry_point')
    tmpdir2 = os.path.join(tmpdir, 'ansible_collections')
    tmpdir3 = os.path.join(tmpdir, 'my_other_dir')
    os.mkdir(tmpdir2)
    os.mkdir(tmpdir3)
    coll_root_dir = os.path.join(tmpdir2, 'namespace1.collection1')
    os.mkdir(coll_root_dir)


# Generated at 2022-06-20 13:38:14.694430
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import tempfile

    # test with a none list
    search_paths = None
    with tempfile.TemporaryDirectory() as tmp_dir:
        # create random dir
        r_dir = tempfile.mkdtemp(dir=tmp_dir)
        # make sure it not in the list of search_paths
        assert r_dir not in list_valid_collection_paths(search_paths)
        # add it to the list
        search_paths = [r_dir]
        # now it appears
        assert r_dir == next(list_valid_collection_paths(search_paths))

    # test a missing collection path
    with tempfile.TemporaryDirectory() as tmp_dir:
        # create random dir
        r_dir = tempfile.mkdtemp(dir=tmp_dir)
        search_path

# Generated at 2022-06-20 13:38:24.340794
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ''' Ensures list_collection_dirs function works on a dummmy list of collection directories
    '''
    colection_dirs = [
        'Something_not_a_collection_dir',
        'ansible.collections.foo',
        'ansible.collections.bar',
        '/path/to/ansible.collections.foobar',
        '/path/to/ansible.collections.barfoo',
        '/path/to/ansible.collections.zoo',
        '/path/to/ansible.collections.zoo/foo',
        '/path/to/ansible.collections.zoo/bar',
        '/path/to/ansible.collections.zoo/bar/foo',
    ]


# Generated at 2022-06-20 13:38:37.885059
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test filtering
    expected_dirs = [("myns.mycollection", "mycollection"),
                     ("myns.mycollection2", "mycollection2")]
    filter = "myns.mycollection"

    for dir in list_collection_dirs(coll_filter=filter):
        assert os.path.basename(dir) in expected_dirs

    # Test no filter
    expected_dirs = [("myns.mycollection", "mycollection"),
                     ("myns.mycollection2", "mycollection2"),
                     ("myns2.mycollection", "mycollection"),
                     ("myns2.mycollection2", "mycollection2")]
    filter = None

    for dir in list_collection_dirs(coll_filter=filter):
        assert os.path.basename(dir) in expected_dirs

# Generated at 2022-06-20 13:38:46.982245
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.file import is_executable
    import tempfile
    import shutil
    import stat
    import os

    # Create a temp directory and some collections structure
    temp_dir_path = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir_path, "ansible_collections/mynamespace"))
    os.makedirs(os.path.join(temp_dir_path, "ansible_collections/mynamespace/mycoll"))
    os.makedirs(os.path.join(temp_dir_path, "ansible_collections/mynamespace/mycoll2"))
    os.makedirs(os.path.join(temp_dir_path, "ansible_collections/mynamespace/mycoll3"))
    os

# Generated at 2022-06-20 13:38:57.883297
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test all paths are returned when they exist, and if they do not, they are not
    dir1 = os.path.join(os.path.dirname(os.path.realpath(__file__)), "collection_path1")
    dir2 = os.path.join(os.path.dirname(os.path.realpath(__file__)), "collection_path2")
    search_paths = ["/invalid/path", dir1, dir2]

    paths = list(list_valid_collection_paths(search_paths, warn=False))
    assert paths == [dir1, dir2]

    paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert paths == [dir1, dir2]



# Generated at 2022-06-20 13:39:21.189600
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.common._collections_compat import Path

    test_paths = [
        'does_not_exist',
        str(Path.home()),
        '/dev/null',
    ]

    results = list(list_valid_collection_paths(test_paths, warn=False))

    # debug
    print("results: %s:" % results)

    assert str(Path.home()) in results

    assert 'does_not_exist' not in results
    assert '/dev/null' not in results



# Generated at 2022-06-20 13:39:32.459287
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Test function lists paths for valid collections"""
    import tempfile
    import shutil
    import os
    import sys

    from ansible.collections.ansible.community.plugins import module_utils

    # create a temp collection
    temp_collection_path = tempfile.mkdtemp()
    assert os.path.exists(temp_collection_path)

    fd, temp_collection_init = tempfile.mkstemp(prefix='ansible_collections.', suffix='.__init__.py',
                                                dir=temp_collection_path)
    assert os.path.exists(temp_collection_init)

    fd, temp_collection_dir = tempfile.mkstemp(prefix='random.', suffix='.plugins.module_utils.common.py',
                                               dir=temp_collection_path)
   

# Generated at 2022-06-20 13:39:46.230756
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.urls import open_url

    # lets try a path that does not exist
    bogus_path = "/usr/share/ansible/bleh"
    res = list(list_valid_collection_paths([bogus_path], warn=True))
    # should be empty
    assert res == []

    # now a path that does exist
    res = list(list_valid_collection_paths(["/usr/share/ansible"], warn=True))
    assert res == ["/usr/share/ansible"]

    # now a path that does exist, but is a file
    # first we make it
    test_file = "/tmp/zzz.txt"

# Generated at 2022-06-20 13:39:56.547155
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.module_utils.common._collections_compat import to_native
    import ansible.module_utils.six as six

    coll_dirs = set([])
    with tempfile.TemporaryDirectory(prefix='ansible_test_collections') as tmpdir:
        tmpdir = to_native(tmpdir)

        # create ansible_collections folder
        ansible_collections_dir = os.path.join(tmpdir, 'ansible_collections')
        os.makedirs(ansible_collections_dir)

        # create namespace folder
        namespace = 'test_collection'
        namespace_dir = os.path.join(ansible_collections_dir, namespace)
        os.makedirs(namespace_dir)

        # create collection folder
       

# Generated at 2022-06-20 13:40:06.666535
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test collection directory path listing.
    """

    # if we are in a "normal" collection, base_path is the root of that collection
    base_path = os.path.join(os.path.dirname(__file__), '../../../')
    # find the test collection namespace directory
    test_path = os.path.join(base_path, '../')

    # create list of collection paths
    test_path_list = []
    test_path_list.append(test_path)

    # test listing of collections in test_collection namespace
    test_colls = list(list_collection_dirs(test_path_list,'test_namespace'))
    assert test_colls[0][-18:] == 'ansible_collections/test_namespace/test_collection1'
    assert test_coll

# Generated at 2022-06-20 13:40:14.239452
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test passing a valid collection as an argument
    dirs_list = list_collection_dirs(coll_filter='community.general')
    assert len(dirs_list) == 1
    dirs_list = list(dirs_list)
    assert dirs_list[0].endswith(os.path.join('community', 'general'))

    # Test passing a valid namespace as an argument
    dirs_list = list_collection_dirs(coll_filter='community')
    assert len(dirs_list) > 1

    # Test passing a non-valid collection as an argument
    dirs_list = list_collection_dirs(coll_filter='community.nonexistent')
    assert len(dirs_list) == 0

    # Test passing an invalid namespace as an argument
    dirs_list = list_collection_dir

# Generated at 2022-06-20 13:40:20.391545
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = ['/tmp/nonexistent', '/usr/share', '~/bad/path']

    valid = list(list_valid_collection_paths(paths))

    assert '/usr/share' in valid
    assert '/tmp/nonexistent' not in valid
    assert '~/bad/path' not in valid
    assert '/dev/null' not in valid

# Generated at 2022-06-20 13:40:25.022378
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({})
    for path in list_collection_dirs(search_paths=['./units/mock/test-collection/']):
        assert(path == b'.')


# Generated at 2022-06-20 13:40:32.919759
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import ansible.test.collects.utils.list_collections as test_data

    # Test case 1
    # input: search_paths=None, coll_filter=None
    # output: collection paths in list
    assert set(list_collection_dirs()) != []

    # Test case 2
    # input: search_paths=['/this/path/does/not/exist'], coll_filter=None
    # output: no collection paths
    assert list(list_collection_dirs(search_paths=['/this/path/does/not/exist'])) == []

    # Test case 3
    # input: search_paths=['test/test_data'], coll_filter=None
    # output: collection paths in list

# Generated at 2022-06-20 13:40:43.213884
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # config is None - return default
    assert list(list_collection_dirs(search_paths=None, coll_filter=None))

    # no path - nothing found
    assert not list(list_collection_dirs(search_paths=[], coll_filter=None))

    # invalid path - nothing found
    assert not list(list_collection_dirs(search_paths=['no_such_path'], coll_filter=None))

    # invalid collection name - nothing found
    assert not list(list_collection_dirs(search_paths=['lib/ansible/modules/cloud/vmware'], coll_filter='test.test'))

    # valid collection name

# Generated at 2022-06-20 13:41:05.256723
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import sys

    _namespaces = ['test_namespace1', 'test_namespace2']
    _collections = ['test_collection1', 'test_collection2']
    _collection_dirs = []

    original_paths = sys.path[:]

    for ns in _namespaces:
        for c in _collections:
            _collection_dirs.append(os.path.join('ansible_collections', ns, c))


# Generated at 2022-06-20 13:41:15.228108
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        "bad_path",
        "test_path",
        "test_path/ansible_collections",
    ]
    expected_paths = [
        "test_path",
        "test_path/ansible_collections",
    ]

    with mock.patch.dict(AnsibleCollectionConfig.collection_paths, {'test_path'}):
        paths = list_valid_collection_paths(search_paths)
        assert list(paths) == expected_paths

# Generated at 2022-06-20 13:41:21.304189
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    display.debug = False
    from ansible_collections.ansible.community import automodules
    collection_path = os.path.dirname(os.path.realpath(automodules.__file__))

    result = list_collection_dirs([collection_path])
    if next(result) != collection_path:
        raise AssertionError("Was expecting path: %s but got: %s" % (collection_path, next(result)))

    result = list_collection_dirs([collection_path, 'not_a_dir'])
    if next(result) != collection_path:
        raise AssertionError("Was expecting path: %s but got: %s" % (collection_path, next(result)))

    result = list_collection_dirs(['not_a_dir', collection_path])

# Generated at 2022-06-20 13:41:26.538859
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(['/tmp']))
    assert(len(dirs) == 2)
    assert(dirs[0] == '/tmp/ansible_collections/ansible/foobar')
    assert(dirs[1] == '/tmp/ansible_collections/ansible/foo')

# Generated at 2022-06-20 13:41:36.687842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_paths = ['tests/unit/ansible_collections/badargs',
                  'tests/unit/ansible_collections/ACME_namespace',
                  'tests/unit/ansible_collections/ACME_namespace/test_collection1',
                  'tests/unit/ansible_collections/ACME_namespace/test_collection2',
                  'tests/unit/ansible_collections/ACME2_namespace',
                  'tests/unit/ansible_collections/ACME2_namespace/test_collection1',
                  'tests/unit/ansible_collections/ACME2_namespace/test_collection2',
                  ]

    # demonstrate that the function will only return valid collection paths

# Generated at 2022-06-20 13:41:44.283403
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_path = [os.getcwd()]
    target = 'ansible_collections.t_collection.t_ns'
    collection_dirs = list(list_collection_dirs(search_paths=search_path, coll_filter=target))
    assert len(collection_dirs) == 1
    assert target in collection_dirs[0]


# Generated at 2022-06-20 13:41:47.197787
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert type(list_valid_collection_paths()) == list
    assert type(list_valid_collection_paths([u"foo"])) == list



# Generated at 2022-06-20 13:41:55.171576
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    def _check_collection(collection, result):
        assert list_collection_dirs([os.path.join(TEST_DATA_ROOT)], collection) == result

    # create test data
    TEST_DATA_ROOT = os.path.join(os.path.dirname(__file__), 'unit', 'collections', 'data')
    if not os.path.exists(TEST_DATA_ROOT):
        os.makedirs(TEST_DATA_ROOT)

    COLLECTION_ROOT_DIR = os.path.join(TEST_DATA_ROOT, 'ansible_collections')

    # create root dir
    if not os.path.exists(COLLECTION_ROOT_DIR):
        os.makedirs(COLLECTION_ROOT_DIR)

    # create fixtures
   

# Generated at 2022-06-20 13:42:05.900328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader'))

    import mock_configs

    search_paths = [os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader', 'ansible_collections'),
                    os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader', 'ansible_collections2'),
                    os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader', 'ansible_collections3')]
    actual = list_collection_dirs(search_paths, 'one.collection1')

# Generated at 2022-06-20 13:42:09.618919
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections import list_collection_dirs

    assert len(list(list_collection_dirs()))



# Generated at 2022-06-20 13:42:36.677270
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    def _normalize_path(path):
        return os.path.normpath(path).replace('\\', os.sep)

    def _base_path(path):
        return os.path.basename(path)

    # root is the collection root dir
    root = os.path.join(os.path.dirname(__file__), 'test_collections')

    # collection_paths is a list of paths to test with
    collection_paths = ['test_collections/collection1',
                        'test_collections/collection2',
                        'test_collections/collection3',
                        'test_collections/collection4']

    # Filter to namespace and collection
    coll_filter = 'namespace.collection'

    # list of collection paths to be returned
    # coll3 is excluded because it is not a collection
    expected

# Generated at 2022-06-20 13:42:46.040537
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # All paths will be non existent paths
    collection_search_paths = [
        "/etc/ansible/ansible1", "/etc/ansible/ansible2", "/etc/ansible/ansible3",
        "/etc/ansible/ansible4", "/etc/ansible/ansible5"
    ]
    collection_valid_paths = list(list_valid_collection_paths(collection_search_paths, warn=False))
    assert collection_valid_paths == [], \
        "Expected collection_valid_paths to be empty, got: %s" % collection_valid_paths

    # All paths will be valid path

# Generated at 2022-06-20 13:42:53.399230
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from ansible_collections.ansible.test.unit.fixtures import _create_test_collection
    from ansible.utils import context_objects as co

    display = co.GlobalCLIArgs()
    display.verbosity = 4

    with tempfile.TemporaryDirectory() as tmp_dir:
        test_coll_path = tmp_dir + "/ns_col/collection"
        os.makedirs(test_coll_path)
        _create_test_collection(test_coll_path)

        result = list(list_collection_dirs(search_paths=[tmp_dir], coll_filter="ns_col.collection"))

        assert(result[0] == test_coll_path)

# Generated at 2022-06-20 13:43:08.553303
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(search_paths=['/tmp/test'])) == []

    assert list(list_collection_dirs(search_paths=[''])) == []
    assert list(list_collection_dirs(search_paths=[123])) == []
    assert list(list_collection_dirs(search_paths=[b'abc'])) == []
    assert list(list_collection_dirs(search_paths=[b'\x80\x81ABC\x82\x83'])) == []

    assert list(list_collection_dirs(search_paths=['/tmp/test'], coll_filter='_test.test')) == []
    assert list(list_collection_dirs(search_paths=['/tmp/test'], coll_filter='_test')) == []

# Generated at 2022-06-20 13:43:13.369629
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list(list_collection_dirs())
    assert len(collection_dirs) == 2
    assert b"ansible_collections/example/collection" in collection_dirs