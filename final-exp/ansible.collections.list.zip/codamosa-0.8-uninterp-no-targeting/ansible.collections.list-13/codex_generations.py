

# Generated at 2022-06-20 13:33:25.756096
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import stat

    tmp_path = tempfile.mkdtemp()
    os.chmod(tmp_path, stat.S_IRWXU)

    ns = "flavio"
    coll = "test"
    content = ["TEST", "TEST", "TEST"]
    coll_path = os.path.join(tmp_path, "flavio", "test")
    os.makedirs(coll_path)
    with open(os.path.join(coll_path, "__init__.py"), 'w') as f:
        f.write('\n'.join(content))
        f.flush()
    idx = 0

# Generated at 2022-06-20 13:33:31.458500
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.common.collections import list_valid_collection_paths

    # Empty list
    assert list(list_valid_collection_paths([])) == []

    # With invalid paths
    assert list(list_valid_collection_paths(['non-existing-dir', '/dev/null'])) == []

    # With invalid path
    assert list(list_valid_collection_paths(['non-existing-dir'])) == []

    # With valid path
    assert list(list_valid_collection_paths(['/'])) == ['/']

    # With 2 invalid paths and 1 valid
    assert list(list_valid_collection_paths(['/', '/dev/null', 'non-existing-dir'])) == ['/']

    # With 2 valid paths

# Generated at 2022-06-20 13:33:42.550540
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # test for collections in /usr/share/ansible/collection
    assert list(list_collection_dirs())

    # test for collections in /usr/share/ansible/collection, filter for ansible_namespace.collection_name
    assert list(list_collection_dirs(coll_filter='ansible_namespace.collection_name'))

    # test for collections in /usr/share/ansible/collection, filter for ansible_namespace
    assert list(list_collection_dirs(coll_filter='ansible_namespace'))

    # test for collections in /usr/share/ansible/collection and /etc/ansible/collections
    assert list(list_collection_dirs(search_paths=['/etc/ansible/collections']))

    # test for collections in /usr/share/ansible/collection and

# Generated at 2022-06-20 13:33:56.687675
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os

    # Setup Collection test fixture
    collection_dir = tempfile.mkdtemp()

    collection_dir_ansible_collections = os.path.join(collection_dir, 'ansible_collections')
    os.makedirs(collection_dir_ansible_collections)

    collection_dir_ansible_collections_ns = os.path.join(collection_dir_ansible_collections, 'ns')
    os.makedirs(collection_dir_ansible_collections_ns)

    collection_dir_ansible_collections_col = os.path.join(collection_dir_ansible_collections_ns, 'col')
    os.makedirs(collection_dir_ansible_collections_col)


# Generated at 2022-06-20 13:34:00.016202
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list_collection_dirs(coll_filter='tests')
    assert next(result) == os.path.join(os.path.dirname(__file__), 'ansible_collections', 'tests', 'test')

# Generated at 2022-06-20 13:34:12.200651
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test list_collection_dirs function
    """
    import os
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a couple directories with collections in them
    tmp_dir = []
    tmp_colls = []
    for b in range(0, 2):
        tmp_dir.append(mkdtemp(prefix='colls'))
        tmp_colls.append([])
        for i in range(0, 3):
            tmp_coll = os.path.join(tmp_dir[b], "foo%d.bar%d" % (b, i))
            os.mkdir(tmp_coll)
            with open(os.path.join(tmp_coll, "__init__.py"), "w") as f:
                f.write("#")
            tmp_colls

# Generated at 2022-06-20 13:34:21.102709
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # create a list of test dirs
    test_dir = "/tmp/test_list_valid_collection_paths"
    test_paths= [test_dir]

    # create dirs
    assert not os.path.exists(test_dir)
    os.mkdir(test_dir)
    assert os.path.exists(test_dir)

    # test default config paths
    assert list_valid_collection_paths() != []

    # test that test dirs are in paths
    search_paths = list(list_valid_collection_paths(test_paths))
    assert test_dir in search_paths

    # remove first entry from search_paths
    search_paths.remove(test_dir)

    # test that test dirs are in paths

# Generated at 2022-06-20 13:34:25.133053
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = list(list_valid_collection_paths([u"/tmp", u"/doesnotexist", u"/etc/ansible/collections"]))
    assert len(test_paths) == 2
    assert u"/tmp" in test_paths
    assert u"/etc/ansible/collections" in test_paths


# Generated at 2022-06-20 13:34:33.919609
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import tempfile
    import shutil

    def create_coll_file():
        """
        Create tempfile with a valid collection file meta data
        :return: tempfile name
        """
        _, name = tempfile.mkstemp()
        with open(name, 'w') as f:
            f.write('{{"galaxy_info": {{"namespace": "testns", "collection_name": "test"}}}}')
        return name

    expected_coll_paths = []

    # create temp dir and valid collection structure
    test_coll = tempfile.mkdtemp('_test')
    test_coll_root = os.path.join(test_coll, 'ansible_collections')
    test_coll_ns = os.path.join(test_coll_root, 'testns')
    test_coll_ns

# Generated at 2022-06-20 13:34:44.735930
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    from ansible.utils.collection_loader import _get_collection_config

    search_path = tempfile.TemporaryDirectory()
    search_path_name = search_path.name
    search_path.cleanup()

    os.makedirs(os.path.join(search_path_name, "test_coll1", "test_namespace1", "test_collection_name1"))
    os.makedirs(os.path.join(search_path_name, "test_coll2", "test_namespace2", "test_collection_name2"))
    os.makedirs(os.path.join(search_path_name, "test_coll3", "test_namespace3", "test_collection_name3"))

# Generated at 2022-06-20 13:35:02.957037
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test function to test the functionality of list valid collection paths
    """
    import tempfile
    import shutil
    import os

    def create_collection_fixture(collection_path):
        """
        Helper function to create collection fixture
        :param collection_path: path to create fixture
        :return: None
        """
        for i in range(3):
            collection_path.mkdir(str(i))

    # Create temporary folder to run test
    tmp_dir = tempfile.mkdtemp()

    # Create collection fixture
    create_collection_fixture(tmp_dir)

    # Assert function returns valid path
    assert next(list_valid_collection_paths(search_paths=[tmp_dir])) == tmp_dir

    # Create invalid collection fixture

# Generated at 2022-06-20 13:35:16.148610
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Validate list_valid_collection_paths()
    """

    import tempfile
    test_path = tempfile.mkdtemp()

    # non existant, warning
    paths = list(list_valid_collection_paths(search_paths=["/no/such/path"], warn=True))
    assert len(paths) == 0

    # existant, file, warning
    os.mkdir(os.path.join(test_path, 'ansible_collections'))
    with open(test_path + "/notafile.txt", "wb") as f:
        f.write("notafile\n")
    paths = list(list_valid_collection_paths(search_paths=[test_path], warn=True))
    assert len(paths) == 0

    # existant, dir

# Generated at 2022-06-20 13:35:20.987617
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        "/tmp/does/not/exist",
        "/etc/exists/but/is/a/file",
        "/usr/share/ansible",
    ]

    assert len(list(list_valid_collection_paths(search_paths))) > 0

    assert len(list(list_valid_collection_paths(search_paths, warn=True))) > 0

# Generated at 2022-06-20 13:35:32.089896
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
                    os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../../.."),
                    os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../../../../ansible_collections/ns1")
                   ]

    # flag to skip 1st path as it is not a collections path
    skip_first = True
    for collection_path in list_collection_dirs(search_paths, "ns1.collection1"):
        assert os.path.exists(collection_path)
        assert not skip_first

        skip_first = False

    skip_first = True

# Generated at 2022-06-20 13:35:42.058861
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    cur_path = os.getcwd()
    test_paths = os.path.join(cur_path, 'test_data/test_collections')
    search_paths = ['collection_path_not_exist', test_paths, test_paths]
    res_list = list(list_valid_collection_paths(search_paths))

    assert len(res_list) == 1
    assert test_paths in res_list
    assert 'collection_path_not_exist' not in res_list


# Generated at 2022-06-20 13:35:52.625834
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # search_paths are valid, return them all
    search_paths = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp(),
    ]
    assert list_valid_collection_paths(search_paths)

    # search_path missing, do not return it, do not warn
    search_paths = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp() + 'missing',
    ]
    assert list_valid_collection_paths(search_paths)

    # search_path exists, but is a file
    search_paths = [
        tempfile.mkdtemp(),
        tempfile.mkdtemp() + '.file',
    ]
    assert list_valid_collection_paths(search_paths)

    # search_path missing,

# Generated at 2022-06-20 13:36:05.780155
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.mazer.plugins.module_utils import mazer_utils
    from ansible.galaxy.collection import CollectionRequirement

    # collection path is added here but does not exist
    # it should be ignored
    colldir = mazer_utils.list_collection_dirs(search_paths=['/tmp/'])
    assert colldir

    # create collection file
    collection = CollectionRequirement('test.test')
    collection.resolve()

    with_collpath = list(mazer_utils.list_collection_dirs(search_paths=collection.collection_paths))
    assert with_collpath

    without_collpath = list(mazer_utils.list_collection_dirs())
    assert without_collpath

# Generated at 2022-06-20 13:36:12.446977
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile


# Generated at 2022-06-20 13:36:23.853177
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Store the old current working directory and change the cwd to
    # the temporary directory
    old_cwd = os.getcwd()
    os.chdir(tmpdir)

    # Search paths
    search_paths = ['path1', 'path2']

    # Make sure the collection directories don't exist in the search paths
    assert not any(map(os.path.exists, search_paths))

    # Create directories for the search paths
    list(map(os.mkdir, search_paths))

    # Assert the number of directories that are in the empty search paths
    assert len(list(list_collection_dirs(search_paths=search_paths))) == 0

   

# Generated at 2022-06-20 13:36:30.440625
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        './test/utils/collections/collection_loader/valid',
        './test/utils/collections/collection_loader/invalid/not_a_dir',
        './test/utils/collections/collection_loader/invalid/not_a_coll',
        './test/utils/collections/collection_loader/invalid/bad_coll_name',
    ]

    ret = list(list_valid_collection_paths(search_paths, False))
    assert ret == search_paths[:1], 'should only return valid paths'

    ret = list(list_valid_collection_paths(search_paths, True))
    assert ret == search_paths[:1], 'should only return valid paths'


# Generated at 2022-06-20 13:36:45.402575
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Case1: Unsupported collection path
    path = ['/foo/bar']
    collections = list_collection_dirs(search_paths=path)
    assert (len(list(collections))) == 0

    # Case2: Supported collection path
    path = ["./../test/units/module_utils/test_collections/unsupported_path"]
    collections = list_collection_dirs(search_paths=path)
    assert (len(list(collections))) == 1

    # Case3: Unsupported collections
    path = ["./../test/units/module_utils/test_collections/unsupported_path"]
    collection = "test_date.foo"
    collections = list_collection_dirs(search_paths=path, coll_filter=collection)
    assert (len(list(collections))) == 0

# Generated at 2022-06-20 13:36:58.329114
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collection_name = 'some_namespace.some_collection'
    collection_dir = '/some_path/some_namespace/some_collection'

    def list_collection_dirs_stub(*args, **kwargs):
        return [collection_dir]

    list_collection_dirs = list_collection_dirs_stub
    paths = ['some_path']
    assert list(list_collection_dirs(search_paths=paths, coll_filter=collection_name)) == [collection_dir]

    paths = ['some_path', 'some_other_path']
    assert list(list_collection_dirs(search_paths=paths)) == [collection_dir]

    # Legacy collection
    collection_name = 'some_namespace.some_collection_old'

# Generated at 2022-06-20 13:37:06.231150
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # By default split will return the last part of the string as the collection
    collection_dirs = [
        '/usr/share/ansible/collections/foo/bar',
        '/usr/share/ansible/collections/foo/baz'
    ]
    path = '/usr/share/ansible/collections'
    each = list_collection_dirs(search_paths=[path])
    assert each == collection_dirs
    each = list_collection_dirs(search_paths=[path], coll_filter='foo.bar')
    assert each == collection_dirs[:1]



# Generated at 2022-06-20 13:37:14.248717
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible_collections.theonemul.collection_one.plugins.module_utils import mock_util
    import ansible_collections.theonemul.collection_one.plugins.modules

    def mock_collection_paths(root_dir):
        return [root_dir]

    mock_util.set_mock_root_dir(os.path.dirname(ansible_collections.theonemul.collection_one.plugins.modules.__file__))
    mock_util.set_mock_get_collection_dirs(list_collection_dirs)
    mock_util.set_mock_list_valid_collection_paths(list_valid_collection_paths)
    mock_util.set_mock_collection_paths(mock_collection_paths)


# Generated at 2022-06-20 13:37:20.167940
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    test_fixtures_path = os.path.join(dir_path, 'test_fixtures')

    assert len(list(list_collection_dirs([test_fixtures_path]))) == 3
    assert len(list(list_collection_dirs(
        [os.path.join(test_fixtures_path, 'ansible_collections')]))) == 3

    assert len(list(list_collection_dirs([test_fixtures_path], 'namespace1'))) == 3
    assert len(list(list_collection_dirs([test_fixtures_path], 'namespace1.collection1'))) == 1

# Generated at 2022-06-20 13:37:30.907114
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as directory:
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as temp_file:

            pytest.debug_func = locals()

            collection_paths = [directory]
            colls = list_collection_dirs(collection_paths)

            assert(not colls)

            temp_file.write(
                u'[collections]\n'
                u'collections_paths = {0}\n'.format(directory)
            )

            #test with file but no directory
            colls = list_collection_dirs(collection_paths)
            assert(not colls)

            os.mkdir(os.path.join(directory, u'ansible_collections'))

            #

# Generated at 2022-06-20 13:37:39.754097
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Valid search_paths and namespace, collection
    search_paths = [os.path.join(os.path.dirname(__file__), "collection_loader/valid_collection_root")]
    coll_filter = None
    collections = list(list_collection_dirs(search_paths, coll_filter))
    assert len(collections) == 2

    search_paths = [os.path.join(os.path.dirname(__file__), "collection_loader/valid_collection_root")]
    coll_filter = "test_namespace.test_collection"
    collections = list(list_collection_dirs(search_paths, coll_filter))
    assert len(collections) == 1
    assert collections[0].endswith(u"test_collection")


# Generated at 2022-06-20 13:37:45.607983
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible import context
    from ansible.module_utils.collection_loader import AnsibleCollectionLoader

    c_loader = AnsibleCollectionLoader()
    context.CLIARGS = defaultdict(lambda: None)
    context.CLIARGS['collections_paths'] = c_loader.collection_paths
    fixed_paths = list(list_valid_collection_paths(search_paths=c_loader.collection_paths))
    print(fixed_paths)
    # run actual test
    test_paths = list(list_collection_dirs(search_paths=c_loader.collection_paths))
    print(test_paths)
    assert test_paths == fixed_paths

# Generated at 2022-06-20 13:37:54.261916
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    from shutil import rmtree
    coll_path = tempfile.mkdtemp()

# Generated at 2022-06-20 13:37:58.681089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Unit test for function list_collection_dirs """

    # TODO implement
    # list_collection_dirs
    # list_collection_dirs
    # list_collection_dirs
    # list_collection_dirs

# Generated at 2022-06-20 13:38:15.861671
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    verify that we return valid collection paths
    """
    # FIXME: this needs to be improved to more exhaustively test other distros
    import sys
    import os

    if os.name != 'posix' or sys.platform == 'darwin' or not os.path.exists('/usr/share/ansible/ansible_collections'):
        return

    colls = list_collection_dirs(['/usr/share/ansible/ansible_collections'])
    assert 'ansible.builtin' in colls

# Generated at 2022-06-20 13:38:22.946697
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    colls = list(list_collection_dirs(search_paths=["/dev/null"]))
    assert len(colls) == 0
    colls = list(list_collection_dirs(search_paths=["/tmp/doesnotexist"]))
    assert len(colls) == 0
    colls = list(list_collection_dirs(search_paths=["/tmp/"]))
    assert len(colls) == 0
    colls = list(list_collection_dirs(search_paths=["/"]))
    assert len(colls) > 0

# Generated at 2022-06-20 13:38:27.815605
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    a = list_valid_collection_paths()
    assert isinstance(a, object)



# Generated at 2022-06-20 13:38:39.534740
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    dirs = list(list_collection_dirs(search_paths))
    assert len(dirs) > 0
    search_paths = ["/tmp"]
    dirs = list(list_collection_dirs(search_paths))
    assert len(dirs) == 0
    search_paths = ["/usr/share/ansible_collections"]
    dirs = list(list_collection_dirs(search_paths))
    assert len(dirs) > 0
    search_paths = ["/usr/share/ansible_collections", "/tmp", "/tmp/does_not_exist"]
    dirs = list(list_collection_dirs(search_paths))
    assert len(dirs) > 0

# Generated at 2022-06-20 13:38:42.747590
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = []
    paths.append(None)
    paths.append('/path/does/not/exist')
    for x in list_valid_collection_paths(paths, warn=False):
        assert x is not None


# Generated at 2022-06-20 13:38:49.616832
# Unit test for function list_collection_dirs
def test_list_collection_dirs():  # pylint: disable=unused-function
    """
    This is intended to be a unit test for the list_collection_dirs function.
    It tests that it contains the same directories and no others from the same
    path that it is run from that start with "ansible_collections".
    """
    from ansible.utils.collection_loader import list_collection_dirs

    test_path = os.path.abspath(os.path.dirname(__file__))
    ansible_paths = [path for path in os.listdir(test_path) if path.startswith('ansible_collections')]

    for path in list_collection_dirs([test_path]):
        assert path.decode('utf-8') in ansible_paths

# Generated at 2022-06-20 13:38:53.128241
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/collection/path/does/not/exist', 'test/unit/output/path/does/not/exist']
    assert len(list(list_valid_collection_paths(search_paths))) == 0



# Generated at 2022-06-20 13:39:02.266785
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tempfile import mkdtemp
    from shutil import rmtree

    temp_dir = to_bytes(mkdtemp())
    temp_path1 = to_bytes(os.path.join(temp_dir, 'ansible_collections/example.foo2/plugins'))
    temp_path2 = to_bytes(os.path.join(temp_dir, 'ansible_collections/example.foo/plugins'))
    temp_path3 = to_bytes(os.path.join(temp_dir, 'plugins'))
    temp_path4 = to_bytes(os.path.join(temp_dir, 'ansible_collections/nonamespace'))

    os.makedirs(temp_path1)
    os.makedirs(temp_path2)
    os.makedirs(temp_path3)

# Generated at 2022-06-20 13:39:12.314306
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    from shutil import rmtree
    from ansible.collection import list_collection_dirs
    cur_dir = os.path.dirname(__file__)
    tmp_dir = tempfile.mkdtemp()

    # Make dummy collection paths
    paths = [
        os.path.join(tmp_dir, 'ansible_collections'),
        os.path.join(tmp_dir, 'my_ansible_collections'),
    ]

# Generated at 2022-06-20 13:39:21.637907
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import os

    # Mocking sys argv and using argparse to parse the args for test_list_collection_dirs
    sys.argv = ["ansible-test", "collections", "--list-collection-dirs"]
    from ansible.cli.arguments import ArgumentParser
    from ansible.utils.collection_loader import get_collections_playbook_dirs
    parser = ArgumentParser(
        usage="%(prog)s collections [--list-collection-dirs]\n\n"
              "Find and/or list Ansible collections in the configured collection paths.",
        epilog='See %(prog)s collections --help for more information.',
        fromfile_prefix_chars='@',
    )

# Generated at 2022-06-20 13:39:42.194587
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/tmp', '~'])) == ['/tmp']

# Generated at 2022-06-20 13:39:44.422419
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: implement unit test
    # assert list_valid_collection_paths([]) == []
    pass


# Generated at 2022-06-20 13:39:50.469784
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test with no args, expect defaults
    result = list(list_valid_collection_paths())
    assert len(result) == len(AnsibleCollectionConfig.collection_paths)

    # test with empty list and expect defaults
    result = list(list_valid_collection_paths([]))
    assert len(result) == len(AnsibleCollectionConfig.collection_paths)

    # test with single item and expect it back
    result = list(list_valid_collection_paths(search_paths=['/tmp']))
    assert len(result) == 1
    assert result[0] == '/tmp'

    # test with 2 items and expect 2 back
    result = list(list_valid_collection_paths(search_paths=['/tmp', '/tmp2']))
    assert len(result) == 2


# Generated at 2022-06-20 13:39:55.586762
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        "wookie",
        "droids",
        "/path/to/c3po",
    ]

    valid_paths = list(list_valid_collection_paths(search_paths, warn=True))
    assert len(valid_paths) == 0

# Generated at 2022-06-20 13:40:05.992881
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Test the list_valid_collection_paths function
    '''
    # test_paths_none
    test_paths = None
    assert list_valid_collection_paths(search_paths=test_paths) == list_valid_collection_paths()

    # test_paths_none
    test_paths = []
    assert list_valid_collection_paths(search_paths=test_paths) == list_valid_collection_paths()

    # test_paths_exists_is_dir
    test_paths = [os.getcwd()]
    assert os.getcwd() in list(list_valid_collection_paths(search_paths=test_paths))

    # test_paths_exists_not_dir

# Generated at 2022-06-20 13:40:13.860047
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test empty search paths
    assert list(list_collection_dirs([])) == []

    # Test wrong search paths
    assert list(list_collection_dirs(['/a/b/c'])) == []
    assert list(list_collection_dirs(['/a/b/c'], 'myns.mycoll')) == []

    # Test wrong collection filter
    assert list(list_collection_dirs(['/a/b/c'], 'myns.mycoll')) == []

# Generated at 2022-06-20 13:40:25.204511
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os

    def collection_finder_test(coll_dir, expected_colls):
        """
        Basic test for collection finder
        :param coll_dir: test the finder with the directories in this path
        :param expected_colls: number of collections expected in the test dir
        """

        # setup
        b_coll_root = to_bytes(coll_dir)
        created_collections = defaultdict(dict)
        # create the collection dir if it doesn't exists
        if not os.path.exists(b_coll_root):
            os.makedirs(b_coll_root)

        for ns in os.listdir(b_coll_root):
            b_ns_dir = os.path.join(b_coll_root, to_bytes(ns))

# Generated at 2022-06-20 13:40:32.529627
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    search_paths = [
        '/foo',
        '/tmp',
    ]

    result_list = [x for x in list_valid_collection_paths(search_paths=search_paths)]
    assert result_list == [x for x in list_valid_collection_paths(search_paths=search_paths)]

    search_paths = [
        '/foo',
        '/tmp',
    ]

    result_list = [x for x in list_valid_collection_paths(search_paths=search_paths, warn=True)]
    assert result_list == [x for x in list_valid_collection_paths(search_paths=search_paths, warn=True)]



# Generated at 2022-06-20 13:40:38.237660
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/foo', '/bar', '/baz']) == ['/foo', '/bar', '/baz']
    assert list_valid_collection_paths(['/']) == ['/']
    assert list_valid_collection_paths(None) == list(AnsibleCollectionConfig.collection_paths)



# Generated at 2022-06-20 13:40:46.190782
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import list_valid_collection_paths

    existing_paths = list_valid_collection_paths()
    assert(existing_paths is not None)

    # if we don't pass in the search_paths value, we should get back the configured search paths
    assert(list(existing_paths) == AnsibleCollectionConfig.get_configured_collections_paths())

    for p in existing_paths:
        assert(isinstance(p, str))

    # pass in a value, but it doesn't exist
    fake_paths = ["/does/not/exist"]

    fake_path = list_valid_collection_paths(search_paths=fake_paths, warn=True)

# Generated at 2022-06-20 13:41:29.204208
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os.path
    from ansible.utils.collection_loader import list_collection_dirs
    coll_paths = list_collection_dirs()
    for path in coll_paths:
        assert os.path.isdir(path)

# Generated at 2022-06-20 13:41:37.642690
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # test list_valid_collection_paths with empty parameter
    path_list = list(list_valid_collection_paths())
    assert(len(path_list) == 1)
    assert(path_list[0].count(os.path.join('ansible', 'collections')))

    # test list_valid_collection_paths with non-empty parameter
    test_path = os.path.join(os.path.dirname(__file__), 'units', 'test_list')
    path_list = list(list_valid_collection_paths([test_path]))
    assert(len(path_list) == 1)
    assert(path_list[0] == test_path)

    # test list_valid_collection_paths with warning for non-existing

# Generated at 2022-06-20 13:41:48.535971
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    import os
    import tempfile

    from ansible.module_utils._text import to_bytes

    def make_path(path):
        return to_bytes(os.path.expanduser(path), errors='surrogate_or_strict')

    cwd = make_path(os.getcwd())
    tmpdir = make_path(tempfile.mkdtemp())

    # Test with default search_paths
    assert(list(list_valid_collection_paths()) == [cwd])

    # Test with non-existing paths
    assert(list(list_valid_collection_paths(search_paths=['/bad/path'])) == [cwd])

    # Test with a file instead of dir
    badfile = os.path.join(tmpdir, 'bad_file')

# Generated at 2022-06-20 13:41:55.673737
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.facts import get_config
    import tempfile

    # Ensure paths are re-loaded
    config = get_config()
    config.reload_config_definition()
    config.update_config({"COLLECTIONS_PATHS": [], "DEFAULT_CACHE_PLUGIN": "memory"})

    # Create a temp dir
    tmp_path = tempfile.mkdtemp()
    full_path = os.path.join(tmp_path, "ansible_collections", "namespace", "collection")

    # Add temp dir to search_paths
    config.set_global_config_value("collections_paths", [tmp_path])
    valid_paths = list(list_valid_collection_paths())

    # Ensure our temp dir is in the search_path
   

# Generated at 2022-06-20 13:42:06.219256
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    temp_collection = []

    result = list(list_collection_dirs(['.'], 'test'))
    assert b'./test/ansible_collections/test/plugins' in result

    result = list(list_collection_dirs(['.'], 'test.ansible_collections'))
    assert b'./test/ansible_collections/ansible_collections/plugins' in result

    result = list(list_collection_dirs(['.'], 'test.ansible_collections.test'))
    assert b'./test/ansible_collections/ansible_collections/test/plugins' in result

    result = list(list_collection_dirs(['.'], 'nonexistent'))
    assert not result


# Generated at 2022-06-20 13:42:13.347670
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    tmp_collection_dirs = ['/tmp/personal', '/tmp/shared']
    list(list_collection_dirs(tmp_collection_dirs))
    assert to_bytes(tmp_collection_dirs[0]) in list(list_collection_dirs(tmp_collection_dirs))
    assert '/tmp/shared/ansible_collections' in list(list_collection_dirs(tmp_collection_dirs))

# Generated at 2022-06-20 13:42:22.584752
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import shutil
    import tempfile

    # create test dir and build a temp collection
    coll_test_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(coll_test_dir, 'test_collection', 'namespace'))

    # create a fake collection and execute list_collection_dirs function
    fake_coll_dir = os.path.join(coll_test_dir, 'test_collection')
    coll_dirs = list_collection_dirs([coll_test_dir])
    # confirm returned value is correct
    assert list(coll_dirs) == [fake_coll_dir]

    # create collection with namespace
    os.makedirs(os.path.join(coll_test_dir, 'ansible_collections', 'namespace', 'collection'))


# Generated at 2022-06-20 13:42:30.451010
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths=["/tmp/foo", "/tmp/bar", "/tmp/foobar/baz", "/tmp/foobar/baz/ansible_collections"]
    path = list_collection_dirs(search_paths=search_paths)
    assert path == ['/tmp/foobar/baz/ansible_collections']



# Generated at 2022-06-20 13:42:42.777729
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_paths = []
    test_paths.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    test_paths.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    test_paths.append('/tmp')
    test_paths.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test'))
    test_paths.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'integration'))

    print("Search Paths: %s" % test_paths)

    paths

# Generated at 2022-06-20 13:42:48.697687
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result1 = list(list_collection_dirs(search_paths=['tests/unit/utils/ansible_collections_for_testing']))
    assert len(result1) >= 2
    result2 = list(list_collection_dirs(coll_filter='invalid.ns'))
    assert len(result2) == 0
    result3 = list(list_collection_dirs(coll_filter='ns0.coll7'))
    assert len(result3) == 1
    result4 = list(list_collection_dirs(coll_filter='ns0'))
    assert len(result4) >= 2