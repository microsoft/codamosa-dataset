

# Generated at 2022-06-24 18:15:09.889000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert isinstance(var_0, object)


# Generated at 2022-06-24 18:15:12.239861
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Assert the number of items in var_0
    assert len(var_0) == 10

    # Assert that var_0 is in list_collection_dirs
    assert var_0 in list_collection_dirs()

# Generated at 2022-06-24 18:15:22.404182
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    config = AnsibleCollectionConfig()
    # No search_paths
    search_paths = []

    assert list(list_valid_collection_paths(search_paths)) == []

    # search_paths with invalid directory
    search_paths = ['/root/foo']
    assert list(list_valid_collection_paths(search_paths)) == []

    # search_paths with valid directory
    search_paths = ['/usr/lib/python2.7']
    assert list(list_valid_collection_paths(search_paths)) == ['/usr/lib/python2.7']

    # config with invalid directory
    config.update({'collections_paths': ['/root/foo']})
    assert list(list_valid_collection_paths(config)) == []

    # config with valid

# Generated at 2022-06-24 18:15:24.934205
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    res = list_valid_collection_paths()
    assert type(res) is list
    assert len(res) > 0
    assert res[0] == '/var/lib/awx/.ansible/collections'


# Generated at 2022-06-24 18:15:26.825720
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # These test cases should be executed when running this file as __main__
    # test_case_0()
    pass



# Generated at 2022-06-24 18:15:29.619156
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert 1 == 1, 'list_valid_collection_paths() should return the correct value'


# Generated at 2022-06-24 18:15:31.523473
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True == True


# Generated at 2022-06-24 18:15:35.333360
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():  # noqa: E501
    """Test list_valid_collection_paths"""

    display = Display()
    search_paths = list()
    display.warning('not implemented')
    return '{0}'.format(search_paths)



# Generated at 2022-06-24 18:15:43.135293
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """This is unit test for the function `list_collection_dirs`. """
    expected_out = [b'/Users/jdoe/.ansible/collections/ansible_collections/acme/testcoll']
    actual_out = list(list_collection_dirs([b'/Users/jdoe/.ansible/collections'], b'acme.testcoll'))

    assert expected_out == actual_out, "Expected {}, but got: {}".format(expected_out, actual_out)

# Generated at 2022-06-24 18:15:49.369676
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from ansible.collections.ansible.builtin.tests.unit.compat.mock import patch
    from ansible.collections.ansible.builtin.tests.unit.compat.mock import PropertyMock

    class Mocked_list_valid_collection_paths:
        def __init__(self):
            self._CALLED_COUNTER = 0

        def __call__(self, search_paths=None, warn=False):
            self._CALLED_COUNTER += 1
            assert search_paths is None
            assert warn is False
            yield "a"
            yield "b"

    class Mocked_is_collection_path:
        def __init__(self):
            self._CALLED_COUNTER = 0


# Generated at 2022-06-24 18:15:59.138516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        assert list_valid_collection_paths(None) == list_valid_collection_paths()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 18:16:02.247712
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), type([""])), "Didn't return a list."


# Generated at 2022-06-24 18:16:03.084688
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True


# Generated at 2022-06-24 18:16:04.636777
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    assert var_1


# Generated at 2022-06-24 18:16:09.970646
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with no argument
    try:
        list_valid_collection_paths()
    except Exception as e:
        assert(e is None)
    # Test with valid argument
    try:
        list_valid_collection_paths(search_paths=None, warn=False)
    except Exception as e:
        assert(e is None)


# Generated at 2022-06-24 18:16:12.952994
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths(search_paths=['/tmp'], warn=True)
    assert len(result) == 1
    assert not result == ['/tmp']


# Generated at 2022-06-24 18:16:22.546969
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # set up test environment
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/not/a/real/path'
    paths_before_env = list_valid_collection_paths()
    paths_after_env = list_valid_collection_paths(search_paths=['/tmp/not/a/real/path'])

    s = set(paths_before_env)
    t = set(paths_after_env)

    assert s == t
    assert isinstance(s, set)
    assert list_valid_collection_paths(['./plugins', './modules'])
    assert list_valid_collection_paths()
    assert not list_valid_collection_paths([])

# Generated at 2022-06-24 18:16:33.304254
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = 'tests/unit/modules/shell/ansible_test_collection'
    var_3 = list_collection_dirs(var_2)
    var_4 = list(var_3)
    assert var_4 == [b'tests/unit/modules/shell/ansible_test_collection/ansible_collections/my_namespace/my_collection']

    var_5 = '/tmp/does_not_exist'
    var_6 = list_collection_dirs(var_5)
    var_7 = list(var_6)
    assert var_7 == []

# Generated at 2022-06-24 18:16:40.228864
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    args = dict()
    args['search_paths'] = dict()
    args['search_paths']['data'] = []
    args['warn'] = dict()
    args['warn']['data'] = False
    res = list_valid_collection_paths(**args['search_paths'], **args['warn'])
    # verify if var_0 is equal to ['ansible.builtin', 'ansible.module_utils']
    if not "['ansible.builtin', 'ansible.module_utils']" in str(res):
        print("Error in function 'list_valid_collection_paths'")
    else:
        print("Test passed for function 'list_valid_collection_paths'")


# Generated at 2022-06-24 18:16:42.028711
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == []


# Generated at 2022-06-24 18:16:54.702231
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    try:
        # Testing with a mock file as argument
        test_case_0()
        assert True
    except AssertionError as e:
        raise AssertionError("list_collection_dirs test failed: %s" % e)

# Generated at 2022-06-24 18:16:55.957814
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/path']
    assert list_valid_collection_paths(search_paths) == ['/path']


# Generated at 2022-06-24 18:17:04.133910
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    with pytest.raises(TypeError):
        list_valid_collection_paths(search_paths=7, warn=9)

    with pytest.raises(TypeError):
        list_valid_collection_paths(search_paths=7, warn=9)



# Generated at 2022-06-24 18:17:08.054876
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        assert(list_valid_collection_paths()) == list(list_valid_collection_paths())
    except AssertionError as e:
        print(str(e))
        print('AssertionError raised.')
        assert(False)
    
    # If the assertion passes, we are good to go.
    assert(True)


# Generated at 2022-06-24 18:17:11.970214
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test case for AnsibleCollectionConfig.list_collections function
    """
    # Default case
    displayed = display.display
    try:
        display.display = False
        var_0 = list_collection_dirs()
        var_1 = list(var_0)
        assert var_1
    finally:
        display.display = displayed

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 18:17:13.671432
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Add a test case here
    test_case_0()

# Generated at 2022-06-24 18:17:21.151806
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_path = to_bytes('~/path')

    with pytest.raises(Exception) as ex:
        os.listdir(b_path)

    assert 'No such file or directory' in str(ex.value)

    os.mkdir(b_path)
    os.mkdir(os.path.join(b_path, to_bytes('ansible_collections')))
    os.mkdir(os.path.join(b_path, to_bytes('ansible_collections'), to_bytes('my_namespace')))
    os.mkdir(os.path.join(b_path, to_bytes('ansible_collections'), to_bytes('my_namespace'), to_bytes('my_collection')))

    search_paths = ['~/path']

    var_0 = list_valid_collection

# Generated at 2022-06-24 18:17:21.916938
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths()
    assert result == ['.'], result


# Generated at 2022-06-24 18:17:24.791826
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = []
    var_1 = list()
    assert list_collection_dirs() == var_1


# Generated at 2022-06-24 18:17:33.462845
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_args_0 = None
    test_args_1 = None
    test_args_2 = None
    test_args_3 = None
    test_args_4 = None
    test_args_5 = None
    test_args_6 = None
    test_args_7 = None
    test_args_8 = None
    test_args_9 = None
    test_args_10 = None
    test_args_11 = None
    test_args_12 = None
    test_args_13 = None
    test_args_14 = None
    test_args_15 = None
    test_args_16 = None
    test_args_17 = None
    test_args_18 = None
    test_args_19 = None
    test_args_20 = None
    test_args_21 = None
   

# Generated at 2022-06-24 18:17:51.992763
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Ensure that the function executes without error
    # TODO: add better tests
    test_case_0()

# Generated at 2022-06-24 18:17:56.421012
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    p1 = 'test_value'
    p2 = list(p1)
    p3 = list_valid_collection_paths(p2)
    p4 = list(p3)


# Generated at 2022-06-24 18:18:06.603717
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary collection directory
    tmp_coll_dir = os.path.join(tmp_dir, 'ansible_collections', 'namespace_0', 'collection_0')

    # Create a temporary collection module
    tmp_module_dir = os.path.join(tmp_coll_dir, 'module_0')

    os.makedirs(tmp_module_dir)

    # Add the temporary directory to the collection paths
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = tmp_dir

    assert list_collection_dirs() == [ to_bytes(tmp_coll_dir) ]

    # Clean up the temporary directory
    rmtree(tmp_dir)


# Generated at 2022-06-24 18:18:12.979199
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = ['test1', 'test1.test2']
    var_3 = list(list_collection_dirs(coll_filter=var_2))

    var_2 = ['test1.test2']
    var_4 = list(list_collection_dirs(coll_filter=var_2))

    var_5 = 'test1.test2'

# Generated at 2022-06-24 18:18:16.781637
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Delete all variables created above.
    for var in dir():
        if var.startswith("var_"):
            del globals()[var]
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False
    else:
        assert True



# Generated at 2022-06-24 18:18:20.867943
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    filter_coll = 'namespace.collection'

    # This function is a generator, so we need to use list() to get all the values returned
    coll_dirs = list(list_collection_dirs(search_paths=[], coll_filter=filter_coll))
    assert len(coll_dirs) > 0
    assert os.path.basename(coll_dirs[0]) == filter_coll



# Generated at 2022-06-24 18:18:29.070516
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(search_paths=['path1', 'path2', 'path3'], coll_filter='collection_name')
    var_1 = list(var_0)
    assert var_1 == ['path1/ansible_collections/namespace/collection_name', 'path2/ansible_collections/namespace/collection_name', 'path3/ansible_collections/namespace/collection_name']

# Generated at 2022-06-24 18:18:33.059206
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert isinstance(list_collection_dirs(), list)
    assert isinstance(list_collection_dirs(coll_filter='azure.azcollection'), list)
    assert isinstance(list_collection_dirs(search_paths=['/root/ansible']), list)


# Generated at 2022-06-24 18:18:35.188698
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=["path1"]) == ["path1"]


# Generated at 2022-06-24 18:18:40.617043
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    warn = True
    ret_1 = list_valid_collection_paths(search_paths, warn)
    ret_2 = list(ret_1)
    assert ret_1 == ret_2
    assert len(ret_1) >= 2
    assert ret_1[0].endswith('/ansible_collections')
    assert ret_1[1].endswith('/ansible_collections')


# Generated at 2022-06-24 18:19:01.231481
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths([os.path.dirname(__file__)])) == ['C:\\jenkins\\workspace\\ASF\\test_collections\\facts\\ansible_collections\\test_coll_1\\collection_1']


# Generated at 2022-06-24 18:19:06.139544
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Check that the function ran
    assert test_case_0() is None

    # Check that the function behaves correctly
    assert var_1 == [b'/Users/mac/Documents/ansible_test/test-collection/roles'], var_1

# Generated at 2022-06-24 18:19:08.868332
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert to_bytes(list_valid_collection_paths()) == b''
    assert to_bytes(list_valid_collection_paths('foo')) == b'foo'


# Generated at 2022-06-24 18:19:10.594146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list_collection_dirs()) > 0, "Ansible-base supplies multiple collections"

# Generated at 2022-06-24 18:19:12.438669
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """Standard test case for list_valid_collection_paths"""
    test_case_0()

# Generated at 2022-06-24 18:19:13.429524
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()


# Generated at 2022-06-24 18:19:24.613135
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = b'/foo'
    var_3 = [var_2]
    var_4 = list_valid_collection_paths(var_3)
    var_5 = list(var_4)
    assert var_5 == [var_2]

    var_6 = b'/foo/bar'
    var_7 = [var_2, var_6]
    var_8 = list_valid_collection_paths(var_7)
    var_9 = list(var_8)
    assert var_9 == [var_2]

    var_10 = [b'/bar']
    var_11 = list_valid_collection_paths(var_10)
    var_12 = list(var_11)
    assert var_12 == [b'/bar']

    var_13 = []
    var_14

# Generated at 2022-06-24 18:19:26.209427
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 18:19:34.610812
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs()) == ['/home/s/sjesse/projects/ansible_targets/targets/ansible_collections/ansible/builtin', '/home/s/sjesse/projects/ansible_targets/targets/ansible_collections/ansible/community', '/home/s/sjesse/projects/ansible_targets/targets/ansible_collections/ansible_collections/ansible', '/home/s/sjesse/projects/ansible_targets/targets/ansible_collections/ansible_collections/community']


# Generated at 2022-06-24 18:19:37.576145
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(list_collection_dirs())

# Generated at 2022-06-24 18:20:18.645541
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        '/path/to/collections',
        '/path/to/another/collection',
        '/does/not/exist',
        '/path/to/collection/but/not/a/directory'
    ]

    assert set(list_valid_collection_paths(test_paths)) == set(test_paths[:2])
    assert set(list_valid_collection_paths(test_paths, warn=True)) == set(test_paths[:2])

# Generated at 2022-06-24 18:20:20.188132
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for case in [test_case_0 ]:
        case()

# Generated at 2022-06-24 18:20:21.222309
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass




# Generated at 2022-06-24 18:20:22.473711
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'ansible.builtin' in list(list_collection_dirs())

# Generated at 2022-06-24 18:20:24.423827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == ["/home/bogus/.ansible/collections"]


# Generated at 2022-06-24 18:20:33.156813
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    #
    # Create a mock collection directory structure
    #

    collpath_0 = to_bytes("/mockcoll_0", errors='surrogate_or_strict')
    collpath_1 = to_bytes("/mockcoll_1", errors='surrogate_or_strict')

    collection_dir_0 = os.path.join(collpath_0, to_bytes("ansible_collections", errors='surrogate_or_strict'))
    collection_dir_1 = os.path.join(collpath_1, to_bytes("ansible_collections", errors='surrogate_or_strict'))
    collection_dir_2 = os.path.join(collpath_1, to_bytes("collection_dir_2", errors='surrogate_or_strict'))


# Generated at 2022-06-24 18:20:37.751992
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['ansible_collections']
    var_0 = list_valid_collection_paths(search_paths=var_0)
    var_1 = list(var_0)


# Generated at 2022-06-24 18:20:38.524316
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:20:40.208314
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for path in list_valid_collection_paths():
        print(path)

# Generated at 2022-06-24 18:20:41.622246
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    namespaces = list_valid_collection_paths()
    assert (namespaces is not None)

# Generated at 2022-06-24 18:21:55.458669
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    
    path_list = [
        'foo',
        '/bar',
        '/baz',
        '/path/to/qux',
    ]
    
    var_0 = list_valid_collection_paths(path_list)
    var_1 = list(var_0)
    assert var_1 == ['/path/to/qux']
    
    path_list = [
        '/tmp/test-plugin-test',
        '/foo',
        '/bar',
        '/baz',
        '/path/to/qux',
    ]
    
    var_0 = list_valid_collection_paths(path_list)
    var_1 = list(var_0)
    assert var_1 == ['/tmp/test-plugin-test', '/path/to/qux']
    
    
#

# Generated at 2022-06-24 18:21:57.093552
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)



# Generated at 2022-06-24 18:21:59.907444
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_dirs = list_collection_dirs()
    coll_dirs = list(b_coll_dirs)
    assert len(coll_dirs) > 0


# Generated at 2022-06-24 18:22:09.249388
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Mock behaviors
    config_file = """
    # /tmp/ansible.cfg
    [defaults]
    collection_paths = /tmp/coll, /tmp/coll2
    """

    class DummyDevice:
        def __init__(self, config_file):
            self.config_file = config_file
            self.invalid_config = False

        def get_config(self):
            if self.invalid_config:
                return "invalid file"
            else:
                return self.config_file

    # Mock
    class MockFile(object):

        def __init__(self):
            self.content = config_file

        def read(self):
            return self.content

    # Test 1. Invalid Search Paths
    device1 = DummyDevice(config_file)
    

# Generated at 2022-06-24 18:22:17.884546
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = to_bytes('/etc/ansible/ansible.cfg')
    var_1 = to_bytes('/etc/ansible/ansible.cfg')
    var_2 = to_bytes('/etc/ansible/ansible.cfg')
    var_3 = to_bytes('/etc/ansible/ansible.cfg')
    expected_0 = os.path.join(os.path.sep, 'foo', 'bar')
    expected_1 = os.path.join(os.path.sep, 'foo', 'bar')
    expected_2 = os.path.join(os.path.sep, 'foo', 'bar')
    expected_3 = os.path.join(os.path.sep, 'foo', 'bar')
    expected_4 = '/foo/bar'
    expected_5

# Generated at 2022-06-24 18:22:28.660407
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.getcwd(), 'fixtures', 'unit', 'collection_loader', 'ansible_collections')
    search_paths = [path]
    collections = [
        'ansible.builtin',
        'ansible.builtin.collections.generic',
        'ansible.builtin.collections.generic.plugins.modules',
        'ansible.builtin.collections.generic.plugins.modules.test_module',
        'ansible.builtin.collections.generic.plugins.modules.test_module.test_plugin',
        'ansible.builtin.collections.generic.plugins.modules.test_module.test_plugin.test_action'
    ]

    coll_dirs = list_collection_dirs(search_paths=search_paths)
    coll_

# Generated at 2022-06-24 18:22:34.958040
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(["/var/lib/awx/", "/var/lib/ansible/"])) == ["/var/lib/ansible/"]
    assert list(list_valid_collection_paths(["/var/lib/awx/"])) == []
    assert list(list_valid_collection_paths()) == ["/var/lib/ansible/", "/usr/share/ansible/collections"]

# Generated at 2022-06-24 18:22:36.459163
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        assert list_valid_collection_paths()
    except:
        pass


# Generated at 2022-06-24 18:22:37.482796
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert callable(list_collection_dirs)


# Generated at 2022-06-24 18:22:45.734780
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == [os.path.join(os.path.expanduser('~'), ".ansible", "ansible_collections")]
    assert list_valid_collection_paths([]) == [os.path.join(os.path.expanduser('~'), ".ansible", "ansible_collections")]
    assert os.path.join(os.path.expanduser('~'), ".ansible", "ansible_collections") in list_valid_collection_paths(["/foo/bar"])
    assert os.path.join(os.path.expanduser('~'), ".ansible", "ansible_collections") in list_valid_collection_paths(["/foo/bar", "/frank/zappa"])
