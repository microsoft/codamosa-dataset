

# Generated at 2022-06-24 18:15:10.236261
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    for b_coll_dir in var_0:
        assert os.path.isdir(b_coll_dir)
    var_0 = list_collection_dirs(coll_filter='foobarbaz.test')
    assert var_0 == []


# Generated at 2022-06-24 18:15:11.242445
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/test_dir']) == ['/test_dir']


# Generated at 2022-06-24 18:15:17.585516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['']
    results_0 = list_valid_collection_paths(var_0)
    var_1 = ['/home/abigail/dev/ansible/lib/ansible/collections']
    results_1 = list_valid_collection_paths(var_1)
    assert results_0 == results_1


# Generated at 2022-06-24 18:15:20.533245
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['test_path']
    warn = False
    x, y = list_valid_collection_paths(search_paths, warn)

    assert y == 'test_path'
    assert x == y


# Generated at 2022-06-24 18:15:21.697322
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == None



# Generated at 2022-06-24 18:15:24.970753
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils import basic
    from ansible.utils.display import Display

    results = list_collection_dirs()
    for result in results:
        display.display(result)



# Generated at 2022-06-24 18:15:27.805159
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    arg0 = ['/path/to/somewhere']
    kwarg0 = {'search_paths': None, 'warn': False}
    result0 = list_valid_collection_paths(**kwarg0)
    assert result0 == arg0


# Generated at 2022-06-24 18:15:37.756376
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Testlist_valid_collection_paths")
    import os
    import sys

    # Remove it from sys.path to test that it's added again in the list
    path = '/home/lalit/workspaces/playground/my-ansible-collection/my-collection'
    if path in sys.path:
        sys.path.remove(path)

    expected_results = [
                        path,
                        '/home/lalit/.ansible/collections',
                        '/etc/ansible/collections',
                        '/usr/share/ansible/collections'
        ]

    result = list(list_valid_collection_paths())
    assert result == expected_results




# Generated at 2022-06-24 18:15:42.823358
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    path = '/foo/bar/ns2.coll2/plugins/inventory'
    coll_filter = 'ns2.coll2.plugins.inventory'

    try:
        test_case_0()
    except AnsibleError as e:
        if path in str(e):
            assert True
        else:
            assert False


# Generated at 2022-06-24 18:15:46.202155
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['test-data/mazer']
    expected = ['test-data/mazer']
    actual = list(list_valid_collection_paths(search_paths=search_paths))
    assert actual == expected


# Generated at 2022-06-24 18:15:57.815722
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_path = to_bytes('/home/2/sheraz/Projects/ansible-collections-core/')
    if not os.path.exists(b_path):
        display.warning("The configured collection path {0} does not exist.".format(b_path))
    else:
        if not os.path.isdir(b_path):
            display.warning("The configured collection path {0}, exists, but it is not a directory.".format(b_path))
        else:
            name = b_path
            yield name


# Generated at 2022-06-24 18:16:00.060399
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()

    # test.assert_equals(list_collection_dirs(), var_1)


# Generated at 2022-06-24 18:16:03.214574
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    inventory = []
    results = list_collection_dirs(inventory)
    assert type(results) == type([])
    assert len(results) == 0

# Generated at 2022-06-24 18:16:05.934270
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = ['test_file_path.txt', 'test_file.txt']
    var_2 = list_valid_collection_paths(var_1)
    assert not var_2


# Generated at 2022-06-24 18:16:12.796175
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/opt/test1', '/opt/test2', '/opt/test3']

    result = list(list_valid_collection_paths(test_paths))

    expected = [
        '/opt/test1', '/opt/test2', '/opt/test3',
        '/usr/share/ansible/collections', '/usr/share/ansible/ansible_collections',
        '/etc/ansible/collections', '~/.ansible/collections'
    ]

    assert result == expected

# Generated at 2022-06-24 18:16:13.830989
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    var_0 = list_valid_collection_paths()

# Generated at 2022-06-24 18:16:23.909686
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import sys
    import os
    import tempfile
    import shutil

    ast_path = tempfile.mkdtemp()
    sys.path.append(ast_path)


# Generated at 2022-06-24 18:16:31.327277
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_test_path = to_bytes('./test/test_data/test_collections_0/')

    # Test not passing 'coll_filter'
    results = list(list_collection_dirs([b_coll_test_path]))

    assert is_collection_path(results[0])
    results_str = [r.decode("utf-8") for r in results]
    assert 'test_namespace.test_collection_0' in results_str

    # Test passing a NAMESPACE
    results = list(list_collection_dirs([b_coll_test_path], 'test_namespace'))
    assert is_collection_path(results[0])
    assert results[0].split('/').index(b'test_namespace') == -1

# Generated at 2022-06-24 18:16:39.614136
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    dummy_search_paths = ['./test/temp_collections/default_path']
    dummy_search_paths_fail = ['./test/temp_collections/nonexistent_path']
    dummy_search_paths_fail2 = ['./test/temp_collections/a_file']
    result = list_valid_collection_paths(dummy_search_paths, warn=False)
    assert list(result) == dummy_search_paths
    result = list_valid_collection_paths(dummy_search_paths_fail, warn=False)
    assert list(result) == []
    result = list_valid_collection_paths(dummy_search_paths_fail2, warn=False)
    assert list(result) == []
    result = list_valid_collection_paths

# Generated at 2022-06-24 18:16:49.279319
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    base_0 = {
        '__ansible_module__': """get_collection_info""",
        '__ansible_collection__': """ansible""",
        '__ansible_version__': """2.7.10""",
        '__ansible_sys_version__': """3.4.3 (default, Mar  6 2019, 22:43:06) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-36)]""",
        '__ansible_os_family__': """RedHat""",
        '__ansible_distribution_major_version__': """7""",
        '__ansible_distribution__': """CentOS""",
        '__ansible_distribution_version__': """7.6.1810""",
    }


# Generated at 2022-06-24 18:16:54.943198
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 == None



# Generated at 2022-06-24 18:16:57.993434
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    warn = False
    result = list_valid_collection_paths(search_paths, warn)
    assert result is not None


# Generated at 2022-06-24 18:17:03.181834
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from collections import defaultdict
    collections = defaultdict(dict)
    assert None == list_collection_dirs(collections)
    collections = defaultdict(dict)
    assert None == list_collection_dirs()
    collections = defaultdict(dict)
    assert None == list_collection_dirs()

# Generated at 2022-06-24 18:17:11.204940
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    mydir = os.path.dirname(__file__)
    mydir = os.path.normpath(mydir)
    parentdir = os.path.normpath(os.path.join(mydir, '../..'))
    search_paths = [os.path.join(parentdir, 'test/units/module_util/test_collections')]
    var_0 = list_collection_dirs(search_paths)
    assert var_0 is not None
    assert len(var_0) == 4
    var_1 = list_collection_dirs(search_paths, 'ansible.test_collection')
    assert var_1 is not None
    assert len(var_1) == 1
    var_2 = list_collection_dirs(search_paths, 'invalid.namespace')
   

# Generated at 2022-06-24 18:17:20.147729
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import random
    import tempfile
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.collections.ansible.misc.tests.unit.compat.mock import patch

    coll_namespace = 'ansible_collections.test'
    coll_name = 'test_collection'
    coll_path = os.path.join(coll_namespace, coll_name)

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = to_text(tmp_dir)
        coll_dir = os.path.join(tmp_dir, coll_namespace, coll_name)
        os.makedirs(coll_dir)

        # test valid collection

# Generated at 2022-06-24 18:17:25.184146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    correct_list = ['ansible.builtin', 'ansible.posix']
    my_list = list(list_collection_dirs())
    assert my_list == correct_list


# Generated at 2022-06-24 18:17:33.760271
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.ci.common import (
        AnsibleFailJson,
        AnsibleExitJson,
        AnsibleUndefined,
        AnsibleModule,
    )
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.request import Request, urlopen
    from ansible_collections.community.general.plugins.modules.net_tools import test_case_0

    var_0 = list_collection_dirs()
    assert var_0 == list_collection_dirs(var_2, var_3)
    assert var_0 == list_collection_dirs(var_3, var_3)
    assert var_0

# Generated at 2022-06-24 18:17:36.160185
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for case in switch(test_case_0):
        if case():
            pass



# Generated at 2022-06-24 18:17:36.812929
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert not list_collection_dirs()



# Generated at 2022-06-24 18:17:38.652839
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()



# Generated at 2022-06-24 18:17:45.662068
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        assert test_case_0() == None
    except AssertionError as err:
        print(err)

# Generated at 2022-06-24 18:17:51.519758
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert not list_collection_dirs()

    assert len(list_collection_dirs(['/dev/null'])) == 0

    assert not list_collection_dirs(['/dev/null'])

    assert list(list_collection_dirs(['/dev/null'])) == []


# Generated at 2022-06-24 18:17:54.513783
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Verify that call to list_collection_dirs with proper args
    # returns expected result
    
    assert True

# Generated at 2022-06-24 18:17:56.359243
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    results_collection_paths = list_valid_collection_paths()
    print(results_collection_paths)


# Generated at 2022-06-24 18:18:01.842241
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    display.display("Testing list_valid_collection_paths")

    search_paths = ['a/b/c', 'd/e/f']
    list_valid_collection_paths(search_paths, warn=True)

    search_paths = [__file__]
    list_valid_collection_paths(search_paths, warn=True)


# Generated at 2022-06-24 18:18:08.677514
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var1 = AnsibleCollectionConfig.collection_paths
    assert len(var1) == 1
    assert var1 == [u'/Users/pwieczorek/.ansible/collections']
    var2 = AnsibleCollectionConfig.collection_paths
    assert len(var2) == 1
    assert var2 == [u'/Users/pwieczorek/.ansible/collections']
    var3 = AnsibleCollectionConfig.collection_paths
    assert len(var3) == 1
    assert var3 == [u'/Users/pwieczorek/.ansible/collections']
    pass




# Generated at 2022-06-24 18:18:11.631156
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = list_collection_dirs()
    assert(isinstance(collection_dirs, list))

if __name__ == '__main__':
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:18:12.631006
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not len(list_valid_collection_paths())


# Generated at 2022-06-24 18:18:15.910656
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with pytest.raises(AnsibleError) as excinfo:
        list_collection_dirs(search_paths=None, coll_filter='foo')
    assert 'Invalid collection pattern supplied' in str(excinfo)

    with pytest.raises(AnsibleError) as excinfo:
        list_collection_dirs(search_paths=None, coll_filter=None)
    assert 'Invalid collection pattern supplied' in str(excinfo)

# Generated at 2022-06-24 18:18:16.874901
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_case_0() == True

# Generated at 2022-06-24 18:18:30.071585
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    var_1 = list_collection_dirs()
    var_2 = list(var_1)
    assert var_2 == []
    assert type(var_2) == list
    assert isinstance(var_2, list)

# Generated at 2022-06-24 18:18:38.082910
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture_path = 'unit/module_utils/test_list_collection_dirs.txt'
    with open(fixture_path) as f:
        complete_list = [x for x in f.read().splitlines() if x]

    with open(fixture_path) as f:
        invalid_list = [x for x in f.read().splitlines() if x and x[0] == '#']

    with open(fixture_path) as f:
        test_list = [x for x in f.read().splitlines() if x and x[0] != '#']

    test_list.sort()
    test_case_0_list = list_collection_dirs()
    test_case_0_list.sort()


# Generated at 2022-06-24 18:18:39.532227
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    ftd = list_valid_collection_paths()
    assert type(list_valid_collection_paths()) == type(ftd)


# Generated at 2022-06-24 18:18:41.317005
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # FIXME: Fix this
    pass

# Generated at 2022-06-24 18:18:44.315250
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths(['/tmp/path/'])

    assert result is not None

# Generated at 2022-06-24 18:18:51.965070
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['test_data/test_collection_loader/my_test_non_existent_path'])) == []
    assert list(list_valid_collection_paths(['test_data/test_collection_loader/my_test_non_directory_path'])) == []
    assert list(list_valid_collection_paths(
        ['test_data/test_collection_loader/my_test_collection_path'])) == ['test_data/test_collection_loader/my_test_collection_path']


# Generated at 2022-06-24 18:18:54.833213
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1 == [], 'return should contain [], but contain {}'.format(var_1)

# Generated at 2022-06-24 18:18:59.423333
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = '../library'
    var_0 = list_valid_collection_paths(search_paths=['../library'], warn=False)
    var_1 = list(var_0)
    assert var_1 == ['../library']


# Generated at 2022-06-24 18:19:00.899103
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=[]) is not None


# Generated at 2022-06-24 18:19:07.625414
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # given
    search_paths = [
        "c:\\users\\bob\\.ansible\\collections",
        "/home/bobby/.ansible/collections"
    ]

    # when:
    results = list_valid_collection_paths(search_paths)

    # then:
    assert search_paths[0] == results[0]
    assert search_paths[1] == results[1]


# Generated at 2022-06-24 18:19:29.053210
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    arg = None
    results = list_collection_dirs(arg)
    return results


# Generated at 2022-06-24 18:19:33.206315
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = {list_collection_dirs()[0]}
    var_1 = {'/Users/user/projects/ansible/test/sanity/collection_loader/data/ansible_collections/collection_0/collection_0'}
    assert var_0 == var_1

# Generated at 2022-06-24 18:19:36.551811
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    cwd = os.path.abspath(os.getcwd())
    test_case_0(cwd)


test_case_0()

# Generated at 2022-06-24 18:19:44.547447
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with no argument
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    # Test with argument
    var_2 = list_collection_dirs(search_paths=['/tmp'])
    var_3 = list(var_2)

    # Test with argument
    var_4 = list_collection_dirs(search_paths=['/tmp'])
    var_5 = list(var_4)

# Generated at 2022-06-24 18:19:52.521384
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Mock object for path
    class MockPathObject(object):

        def mock_list_valid_collection_paths(search_paths, warn):
            return list_valid_collection_paths(search_paths, warn)

    # Mock object for collection_paths
    class MockCollectionPathsObject(object):

        def mock_list_valid_collection_paths(search_paths, warn):
            return list_valid_collection_paths(search_paths, warn)

    # Mock object for os
    class MockOsObject(object):

        def path(file):
            return file

        def mock_list_valid_collection_paths(search_paths, warn):
            if not os.path.exists(search_paths):
                return False

        def mock_isdir():
            return True

    #

# Generated at 2022-06-24 18:20:02.343681
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = 'nosetests2.plugin'
    var_3 = list_collection_dirs(coll_filter=var_2)
    var_4 = list(var_3)
    var_5 = sorted(var_4)
    var_6 = ['/home/travis/build/ansible/ansible/test/units/collection_loader/collections/nosetests2/plugins']
    var_7 = sorted(var_6)
    if var_5 is not var_7:
        var_8 = 'Failed to create expected output.  Expecting: %s but got: %s' % (var_7, var_5)
        assert False, var_8

test_case_0()
test_list_collection_dirs()

# Generated at 2022-06-24 18:20:04.101628
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0().__name__ == 'list_collection_dirs'

# Generated at 2022-06-24 18:20:06.222960
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    if not isinstance(list_collection_dirs(), Iterator):
        raise AssertionError



# Generated at 2022-06-24 18:20:16.239304
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = 'tests/fixtures/test_collections/ansible_collections/foo_go'
    assert list_valid_collection_paths(search_paths=[path]) == [path]
    path = 'tests/fixtures/test_collections/doesnotexist'
    assert list_valid_collection_paths(search_paths=[path]) == []
    path = 'tests/fixtures/test_collections/foo_go.py'
    assert list_valid_collection_paths(search_paths=[path]) == []
    path = 'tests/fixtures/test_collections/ansible_collections/foo_go'
    path = 'tests/fixtures/test_collections/ansible_collections/bar_go'

# Generated at 2022-06-24 18:20:24.042798
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Set up test inputs
    test__0 = None
    test__1 = "test_namespace"
    test__2 = "test_namespace.test_collection"

    # Call function
    __result__00 = list_collection_dirs()
    __result__01 = list_collection_dirs(test__0)
    __result__02 = list_collection_dirs(test__0, test__1)
    __result__03 = list_collection_dirs(test__0, test__2)

    # Write test result to file
    file = open("test/integration/targets/test_ansible_collections/testcase_0", "w")

# Generated at 2022-06-24 18:21:09.178003
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: this test fails; need to fix it
    # assert not exists('/tmp/ansible_collections')
    # test_paths = ['/tmp/ansible_collections', 'bogus']
    # assert list(list_valid_collection_paths(test_paths)) == []
    pass


# Generated at 2022-06-24 18:21:18.511594
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # List of paths that are valid configured search_paths
    test_paths = ['/mocked/path/ansible_collections', '/mocked/path/ansible_collections/fake_ns/ansible_fake_coll']
    # List of paths that are not valid configured search_paths
    invalid_paths = ['/mocked/path/ansible_fake_collection', '/mocked/path/ansible_collections/fake_ns/ansible_fake_coll/file']
    # List of valid paths; Note that invalid paths are filtered out
    valid_paths = list(list_valid_collection_paths([*test_paths, *invalid_paths], warn=False))
    # Check if valid path is contained in the valid paths list
    assert test_paths[0] in valid_paths

#

# Generated at 2022-06-24 18:21:28.642002
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_dirs = [
        "/ansible/test_dirs/ansible_collections/ns_1/coll_1",
        "/ansible/test_dirs/ansible_collections/ns_2/coll_2",
        "/ansible/test_dirs/ansible_collections/ns_2/coll_3"
    ]
    test_dirs_no_collections_dir = [
        "/ansible/test_dirs/ns_1/coll_1",
        "/ansible/test_dirs/ns_2/coll_2",
        "/ansible/test_dirs/ns_2/coll_3"
    ]

# Generated at 2022-06-24 18:21:31.375462
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 18:21:32.638043
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()
    assert True

# Generated at 2022-06-24 18:21:40.719159
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with valid search path
    search_path = ['/usr/share/ansible/']
    actual_result = list_valid_collection_paths(search_path)
    expected_result = ['/usr/share/ansible/']
    assert list(actual_result) == expected_result

    # Test with invalid search path
    search_path = ['/usr/share/collections/']
    actual_result = list_valid_collection_paths(search_path, warn=True)
    expected_result = []
    assert list(actual_result) == expected_result


# Generated at 2022-06-24 18:21:48.424982
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Should be list of paths with os path separator
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    assert len(var_1) > 0
    for path in var_1:
        assert isinstance(path, bytes)
        assert path.endswith(b"t")
        assert path.endswith(b"t")
        assert path.endswith(b"t")


# List all available tests

# Generated at 2022-06-24 18:21:50.106351
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    collections = list_valid_collection_paths()
    assert isinstance(collections, type(list()))


# Generated at 2022-06-24 18:21:55.573963
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # ensure that the exact expected values are returned
    assert list_valid_collection_paths()[0] == '/home/bglover/.ansible/collections'


# Generated at 2022-06-24 18:21:56.910523
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == None



# Generated at 2022-06-24 18:23:29.423736
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_list = list_collection_dirs()
    test_collections_list = []
    for collection in coll_list:
        test_collections_list.append(os.path.basename(collection))
    expected = ['win', 'test1', 'test2', 'test3', 'test4', 'test5', 'test6', 'test7', 'test8', 'test9', 'test10', 'test11', 'test12', 'test_collections_not_installed', 'test']
    assert sorted(expected) == sorted(test_collections_list)


# Generated at 2022-06-24 18:23:31.709285
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:23:36.221244
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        assert list_collection_dirs() is not None
        assert len(list_collection_dirs()) != 0

    except AssertionError:
        display.error('test_list_collection_dirs assertion error')

# Generated at 2022-06-24 18:23:41.960831
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list_valid_collection_paths()) > 0

assert len(list_valid_collection_paths()) > 0

# Generated at 2022-06-24 18:23:45.515241
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list = list_valid_collection_paths(['/tmp/1', '/tmp/2'])
    assert type(path_list) is list



# Generated at 2022-06-24 18:23:50.703692
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # prepare the test inputs
    test_input1 = b'/home/ansible'
    test_input2 = b'/home/ansible/mycollections'
    myinputs = [test_input1, test_input2]
    # now call the tested function and capture the results
    myresult = list_valid_collection_paths(myinputs)
    # assert on the expected results
    assert myresult == myinputs


# Generated at 2022-06-24 18:23:51.965342
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True



# Generated at 2022-06-24 18:23:53.232842
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()



# Generated at 2022-06-24 18:23:57.091149
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert type(var_1) == list

# Generated at 2022-06-24 18:23:59.826880
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with default arg
    test_case_0()

    # Test with arg specified
    test_case_0()