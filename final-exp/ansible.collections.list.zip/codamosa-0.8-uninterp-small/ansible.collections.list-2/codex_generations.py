

# Generated at 2022-06-24 18:15:06.541783
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = ['/nonexistent/path']
    
    assert var_1 == list_valid_collection_paths(var_1)


# Generated at 2022-06-24 18:15:10.445109
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    assert len(var_1) == 0
    var_3 = list_collection_dirs(coll_filter='ns.coll')
    assert len(var_3) == 0



# Generated at 2022-06-24 18:15:18.744785
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    b_my_path = to_bytes(__file__, errors='surrogate_or_strict')
    b_my_dir = os.path.dirname(b_my_path)
    b_common_dir = os.path.join(b_my_dir, b'../common')
    b_common_dir = os.path.normpath(b_common_dir)

    valid_paths = [b_my_dir, b_common_dir]

    invalid_paths = [b_my_dir, b'invalid_dir']

    results = list_valid_collection_paths(search_paths=valid_paths)

    assert b_my_dir in results
    assert b_common_dir in results


# Generated at 2022-06-24 18:15:26.576422
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Test list_collection_dirs"""

    import os.path
    import tempfile

    # Create a temporary collection testing directory
    tmpdir = tempfile.mkdtemp(dir='/tmp')
    # Name of the collection
    test_name = 'test'
    # Fully qualified path to the collection directory
    test_dir = os.path.join(tmpdir, test_name)

    # make sure it doesn't exist first
    if os.path.exists(test_dir):
        os.rmdir(test_dir)

    # Create the directory, and create a '__init__.py' file to make it a collection
    os.mkdir(test_dir)
    with open(os.path.join(tmpdir, test_name, '__init__.py'), 'w'):
        pass

    # Create another

# Generated at 2022-06-24 18:15:28.482580
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(test_case_0(), list)


# Generated at 2022-06-24 18:15:28.999139
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()

# Generated at 2022-06-24 18:15:31.687656
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # List of string paths, default is None
    search_paths = None
    # Boolean value, default is False
    warn = False
    # Filter out any non existing or invalid search_paths for collections
    assert list_valid_collection_paths(search_paths, warn) is None, "Test Failure: list_valid_collection_paths"



# Generated at 2022-06-24 18:15:33.543422
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:15:35.186335
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collection_dirs()


# Generated at 2022-06-24 18:15:45.533500
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = [(u'ansible.builtin', os.path.join(u'/home/robert/ansible_collections/ansible/builtin', u'/home/robert/ansible_collections/ansible/builtin'))]
    var_1 = list_collection_dirs(search_paths=[u'/home/robert/ansible_collections/ansible/builtin'])

# Generated at 2022-06-24 18:16:08.377471
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Set up mock objects
    class mock_Display():
        def __init__(self):
            pass
        display = 'warning'
        def warning(self, msg):
            return msg

    class mock_AnsibleCollectionConfig():
        def __init__(self):
            pass
        collection_paths = ['test', 'test']

    class mock_AnsibleError():
        def __init__(self, msg):
            pass
        msg = 'Invalid collection pattern supplied'

    # Set up test values
    coll_filter = 'test.test'
    search_paths = 'test'
    expected_result = ['test']

    # Set up mocks
    display = mock_Display()

    # Set up mocks
    AnsibleCollectionConfig = mock_AnsibleCollectionConfig()
    AnsibleError = mock_Ans

# Generated at 2022-06-24 18:16:10.841840
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Returns a list of all collection paths for which the given collection_filter is true
    assert list_collection_dirs(coll_filter="test_collections")

# Generated at 2022-06-24 18:16:12.657910
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert len(var_0) == 0

# Generated at 2022-06-24 18:16:14.115846
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    res = list_valid_collection_paths()
    assert res is not None


# Generated at 2022-06-24 18:16:19.920084
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = [
        ('/fake_path/ansible_collections'),
        ('/fake_path2/ansible_collections')
    ]

    var_1 = 'namespace.collection'

    assert var_0
    assert var_1

    assert list_collection_dirs(var_0, var_1)

    assert list_collection_dirs() == 'ansible_collections'



# Generated at 2022-06-24 18:16:24.583922
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter=None
    search_paths=['/home/devel/.ansible/collections']
    expected = '/home/devel/.ansible/collections/ansible_collections/test/my_collection'
    real = list_collection_dirs(search_paths, coll_filter)
    assert next(real) == expected

test_list_collection_dirs()

# Generated at 2022-06-24 18:16:27.658488
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list(list_valid_collection_paths()) is not None
    assert list(list_valid_collection_paths()) != []



# Generated at 2022-06-24 18:16:29.395203
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()


# Generated at 2022-06-24 18:16:37.825174
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    var_0 = list_collection_dirs()

    var_1 = list_collection_dirs(coll_filter='foo.bar')

    var_2 = list_collection_dirs(coll_filter='foo')

    var_3 = list_collection_dirs(search_paths=['a', 'b', 'c'])

    var_4 = list_collection_dirs(search_paths=['a', 'b', 'c'], coll_filter='foo.bar')

    var_5 = list_collection_dirs(search_paths=['a', 'b', 'c'], coll_filter='foo')

    var_6 = list_collection_dirs(search_paths=['a', 'b', 'c'], coll_filter='foo.bar', warn=True)

    var_7 = list_collection

# Generated at 2022-06-24 18:16:42.582864
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths(search_paths=None, warn=False)

# Generated at 2022-06-24 18:16:54.214252
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Setup test environment

    # Invoke function
    result = list_valid_collection_paths()

    # Check result
    assert result == []



# Generated at 2022-06-24 18:16:59.101239
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Testing list_valid_collection_paths")
    try:
        test_case_0()
    except AnsibleError as e:
        print(e)
        # AssertionError: The configured collection path foo does not exist.
    else:
        print('SUCCESS')


# Generated at 2022-06-24 18:17:03.013935
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Invoke the method with invalid parameters values
    result = list_collection_dirs(['/var/fake'])
    # Expected dictionary
    exp_result = []
    assert result == exp_result

# Generated at 2022-06-24 18:17:03.839545
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_case_0() == None

# Generated at 2022-06-24 18:17:05.195558
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert len(var_0) == 0


# Generated at 2022-06-24 18:17:06.423367
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 is not None

# Generated at 2022-06-24 18:17:07.947163
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs is not None


# Generated at 2022-06-24 18:17:15.810824
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_0 = list_valid_collection_paths(None)
    var_0 = list_valid_collection_paths(None, False)
    var_0 = list_valid_collection_paths(None, True)
    var_0 = list_valid_collection_paths([])
    var_0 = list_valid_collection_paths([], False)
    var_0 = list_valid_collection_paths([], True)
    var_0 = list_valid_collection_paths(["string"])
    var_0 = list_valid_collection_paths(["string"], False)
    var_0 = list_valid_collection_paths(["string"], True)
    var_0 = list_valid_collection_paths([1])
   

# Generated at 2022-06-24 18:17:17.680213
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Assert no exceptions are thrown
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-24 18:17:21.525556
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_input = "test_input"
    expected_result = ""
    result = list_collection_dirs(test_input)
    assert result == expected_result

# Generated at 2022-06-24 18:17:35.713720
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    global collection, namespace, coll_filter, search_paths
    collection = None
    namespace = None
    coll_filter = None
    search_paths = ['.']
    # list_collection_dirs(search_paths, coll_filter)


# Generated at 2022-06-24 18:17:40.036387
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    coll_filter = None
    var_3 = list_collection_dirs()
    var_4 = list(var_3)
    var_5 = list_collection_dirs()



# Generated at 2022-06-24 18:17:41.334401
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list(list_valid_collection_paths())


# Generated at 2022-06-24 18:17:43.569402
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert list(var_0) == ['/home/james/.ansible/collections', '/home/james/workspace/collections', '/usr/share/ansible/collections']


# Generated at 2022-06-24 18:17:46.064035
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = list_valid_collection_paths()
    var_2 = list(var_1)


# Generated at 2022-06-24 18:17:51.932858
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(['/tmp/foo', '/tmp/bar'])
    var_1 = list_collection_dirs([])
    var_2 = list_collection_dirs()
    var_3 = list_collection_dirs(coll_filter='fake.thing')

# Generated at 2022-06-24 18:17:57.035467
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert type(list_collection_dirs()) == list


# Generated at 2022-06-24 18:17:58.485465
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass



# Generated at 2022-06-24 18:17:59.545385
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_case_0() is None

# Generated at 2022-06-24 18:18:03.291358
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list(list_valid_collection_paths())
    assert var_0 == ["/usr/share/ansible/collections", "/etc/ansible/collections", "~/.ansible/collections", "/etc/ansible/ansible_collections"], "Variable 'var_0' value is incorrect"


# Generated at 2022-06-24 18:18:21.257335
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_3 = list_valid_collection_paths()


# Generated at 2022-06-24 18:18:27.933532
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    f1 = 'test_list_collection_dirs.py'
    p1 = os.path.realpath(f1)
    d1 = os.path.dirname(p1)
    d1 = os.path.join(d1, 'test_valid_collections')
    assert list_collection_dirs([d1]) == [d1]

# Generated at 2022-06-24 18:18:30.153440
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    return_value = list_valid_collection_paths()
    assert isinstance(return_value, list)


# Generated at 2022-06-24 18:18:34.665962
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # When:
    var_0 = list_valid_collection_paths()
    # Then:
    var_1 = list(var_0)
    assert type(var_1) == list
    # When:
    var_2 = list_valid_collection_paths()
    # Then:
    var_3 = list(var_2)
    assert type(var_3) == list


# Generated at 2022-06-24 18:18:37.020649
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_list_valid_collection_paths = None
    assert test_list_valid_collection_paths == "something"



# Generated at 2022-06-24 18:18:49.532549
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # This function is empty, please write test code for it if necessary
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    # check return type
    assert isinstance(var_1, list)
    # check value
    assert var_1[0] is not None
    assert var_1[0] == "/home/myname/.ansible/collections"
    var_2 = list_valid_collection_paths()
    var_3 = list(var_2)
    # check return type
    assert isinstance(var_3, list)
    # check value
    assert var_3[0] is not None
    assert var_3[0] == "/home/myname/.ansible/collections"


# Generated at 2022-06-24 18:18:52.411554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:18:53.145995
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass



# Generated at 2022-06-24 18:18:56.162178
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = [None]
    var_1 = list(var_0)
    var_2 = list_valid_collection_paths()


# Generated at 2022-06-24 18:18:58.326005
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = list_valid_collection_paths()
    assert var is not None


# Generated at 2022-06-24 18:19:32.147513
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_paths = list(list_valid_collection_paths())
    print(coll_paths)
    assert len(coll_paths) >= 1


# Generated at 2022-06-24 18:19:33.749073
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(list_valid_collection_paths())


# Generated at 2022-06-24 18:19:42.394198
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = []
    coll_filter = None
    assert list_collection_dirs(search_paths, coll_filter) == (yield list(list_collection_dirs(search_paths, coll_filter)))

    search_paths = []
    coll_filter = "foo:bar"
    assert list_collection_dirs(search_paths, coll_filter) == (yield list(list_collection_dirs(search_paths, coll_filter)))

# Generated at 2022-06-24 18:19:46.990817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)

    assert var_1 == [
        '/usr/share/ansible/collections/ansible_collections',
        '/etc/ansible/collections/ansible_collections'
    ]


# Generated at 2022-06-24 18:19:48.596991
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths()
    # result is of type 'generator'



# Generated at 2022-06-24 18:19:51.736206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 == ['bar/*', 'foo']



# Generated at 2022-06-24 18:19:56.142083
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    var_2 = list_valid_collection_paths()
    assert (var_1 == var_2)


# Generated at 2022-06-24 18:20:02.070737
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = []
    var_1 = []
    for var_2 in list_valid_collection_paths(var_0):
        var_1.append(var_2)

# Generated at 2022-06-24 18:20:10.531808
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        var_0 = list_valid_collection_paths()
        var_1 = list(var_0)
        try:
            var_2 = list_valid_collection_paths()
            assert var_1 == var_2
        except AssertionError:
            raise Exception(
                'Expected assertion to be raised but no exception was raised!')
    except Exception as e:
        raise Exception(
            'Expected no exception to be raised but exception was raised!') from e



# Generated at 2022-06-24 18:20:18.513269
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Using list to make sure that the function can be called with a list
    var_0 = [1]
    assert list(list_collection_dirs(var_0)) == ['ansible_collections']

    var_0 = None
    assert list(list_collection_dirs(var_0)) == ['ansible_collections']

    var_0 = []
    assert list(list_collection_dirs(var_0)) == ['ansible_collections']

    # test loading from default search paths
    assert list(list_collection_dirs(search_paths=None)) == ['ansible_collections']

    # test load from specific a search path
    assert list(list_collection_dirs(search_paths=['/dev/null'])) == []


# Generated at 2022-06-24 18:21:23.272399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test case path:
    # test_cases/test_case_0
    test_case_0()



# Generated at 2022-06-24 18:21:24.646206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    a = list_valid_collection_paths()
    assert True



# Generated at 2022-06-24 18:21:32.149285
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = None
    coll_filter = '%s.%s' % (namespace, collection_name)
    var_3 = list_collection_dirs()
    var_4 = list(var_3)
    assert var_4[0] == collection_path
    coll_filter = '%s.%s' % (namespace, collection_name)
    coll_filter = None
    var_5 = list_collection_dirs()
    var_6 = list(var_5)
    assert var_6[0] == collection_path

# Generated at 2022-06-24 18:21:34.517693
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # List is returned
    r0 = list_collection_dirs()
    assert r0



# Generated at 2022-06-24 18:21:36.213206
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(['/collections'])



# Generated at 2022-06-24 18:21:39.678530
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = ['home/ubuntu/ansible-project/ansible_collections']

    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 18:21:51.247220
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    var_2 = list_collection_dirs()
    var_3 = list_collection_dirs()
    var_4 = list(var_3)
    var_5 = list_collection_dirs()
    var_6 = list_collection_dirs()
    var_7 = list(var_6)
    var_8 = list_collection_dirs()
    var_9 = list_collection_dirs()
    var_10 = list(var_9)
    var_11 = list_collection_dirs()
    var_12 = list_collection_dirs()
    var_13 = list(var_12)
    var_14 = list_collection_dirs()
    var_15 = list_collection_

# Generated at 2022-06-24 18:21:52.709572
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    var_2 = list(var_1)


# Generated at 2022-06-24 18:21:53.412889
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True

# Generated at 2022-06-24 18:21:56.374007
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_3 = list_collection_dirs()
    var_4 = list(var_3)



# Generated at 2022-06-24 18:23:29.195975
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Create a mock search path and file/directory structure to test
    import ansible.constants as C
    import tempfile
    import shutil
    basedir = tempfile.mkdtemp()
    os.mkdir(os.path.join(basedir, 'collections'))
    os.mkdir(os.path.join(basedir, 'collections', 'ansible_collections'))
    os.mkdir(os.path.join(basedir, 'collections', 'ansible_collections', 'not_a_collection'))
    os.mkdir(os.path.join(basedir, 'collections', 'ansible_collections', 'missing_collection'))
    os.mkdir(os.path.join(basedir, 'collections', 'ansible_collections', 'missing_collection', 'missing'))

# Generated at 2022-06-24 18:23:33.695910
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list_valid_collection_paths()
    assert list_valid_collection_paths(['a'])
    assert not list_valid_collection_paths(['a'], True)


# Generated at 2022-06-24 18:23:35.722553
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    print("\n")

    test_case_0()

    print("\n")

# Generated at 2022-06-24 18:23:40.734882
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Test list_valid_collection_paths() """
    assert True == True

# Generated at 2022-06-24 18:23:42.854479
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)


# Generated at 2022-06-24 18:23:45.251329
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # assert list_collection_dirs() == '''
    # '''
    pass


# Generated at 2022-06-24 18:23:52.832618
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Expected AnsibleError due to invalid collection name.
    with pytest.raises(AnsibleError):
        list_collection_dirs(coll_filter='/foo')

    # Expected AnsibleError due to non-existing collection.
    with pytest.raises(AnsibleError):
        list_collection_dirs(coll_filter='foo.bar')

    # Expected AnsibleError due to invalid namespace name.
    with pytest.raises(AnsibleError):
        list_collection_dirs(coll_filter='foo/bar')

    # Expected AnsibleError due to non-existing namespace.
    with pytest.raises(AnsibleError):
        list_collection_dirs(coll_filter='/foo')

    # Test if list_collection_dirs() will return a list of paths found in

# Generated at 2022-06-24 18:24:04.782166
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test 'search_paths=None' and 'coll_filter=None'
    ret = list_collection_dirs(None, None)
    # Test 'search_paths=None' and 'coll_filter=None'
    ret = list_collection_dirs()
    # Test 'search_paths=search_paths' and 'coll_filter=coll_filter'
    ret = list_collection_dirs([], [])
    # Test 'search_paths=search_paths' and 'coll_filter=coll_filter'
    ret = list_collection_dirs([])



# Generated at 2022-06-24 18:24:10.711512
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_root_0 = b'/ansible_collections'
    b_namespace_dir_0 = os.path.join(b_coll_root_0, b'my_namespace')
    b_coll_0 = b'my_collection'
    b_coll_dir_0 = os.path.join(b_namespace_dir_0, b_coll_0)
    b_coll_path_0 = b_coll_dir_0
    path_0 = '/ansible_collections/my_namespace/my_collection'

# Generated at 2022-06-24 18:24:20.200570
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    path_1 = 'ansible_collections/ns_0/coll_0'
    assert var_1[0] == path_1
    path_2 = 'ansible_collections/ns_0/coll_1'
    assert var_1[1] == path_2
    path_3 = 'ansible_collections/ns_1/coll_0'
    assert var_1[2] == path_3
    path_4 = 'ansible_collections/ns_1/coll_1'
    assert var_1[3] == path_4