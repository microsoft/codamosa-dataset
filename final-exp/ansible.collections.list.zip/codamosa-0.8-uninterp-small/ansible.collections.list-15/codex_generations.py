

# Generated at 2022-06-24 18:15:07.488846
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        var_0 = list_collection_dirs()
    except:
        var_0 = None
    assert var_0 is not None

# Generated at 2022-06-24 18:15:09.255681
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() is not None

# Generated at 2022-06-24 18:15:10.499271
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    subjects = list_collection_dirs()
    assert subjects is not None
    assert type(subjects) == dict




# Generated at 2022-06-24 18:15:11.610731
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()



# Generated at 2022-06-24 18:15:14.752749
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = list_valid_collection_paths()
    for result in var:
        assert os.path.exists(to_bytes(result)) is True


# Generated at 2022-06-24 18:15:16.017506
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list_valid_collection_paths()



# Generated at 2022-06-24 18:15:16.984597
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass


# Generated at 2022-06-24 18:15:21.885800
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Test function with keyword arguments
    test_case_0
    """

    # initialize test defaults
    kwargs = {}

    # Execute the function and get the return values
    ret_val_0 = list_collection_dirs(**kwargs)

    # Return any output from the function
    assert ret_val_0 < 0


if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-24 18:15:23.404565
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = list_valid_collection_paths()



# Generated at 2022-06-24 18:15:25.713704
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    collections = list_collection_dirs()

    for c in collections:
        assert os.path.exists(c)


# Generated at 2022-06-24 18:15:41.371633
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['./unit/fixtures/test_collection_loader/multiple-namespace',
                    './unit/fixtures/test_collection_loader/single-namespace']

    # No filter
    collection_dirs = list(list_collection_dirs(search_paths))

    assert len(collection_dirs) == 3

    # Filter by namespace
    collection_dirs = list(list_collection_dirs(search_paths, 'test_ns1'))

    assert len(collection_dirs) == 2

    # Filter by collection
    collection_dirs = list(list_collection_dirs(search_paths, 'test_coll1.test_ns1'))

    assert len(collection_dirs) == 1

# Generated at 2022-06-24 18:15:47.989419
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    temp_root = tempfile.mkdtemp()
    temp_coll_root = os.path.join(temp_root, "ansible_collections")
    os.mkdir(temp_coll_root)
    os.mkdir(os.path.join(temp_coll_root, "my.collection"))
    os.mkdir(os.path.join(temp_coll_root, "my2.collection"))
    assert len(list(list_collection_dirs([temp_root]))) == 2
    os.mkdir(os.path.join(temp_coll_root, "another"))
    assert len(list(list_collection_dirs([temp_root]))) == 2
    assert len(list(list_collection_dirs([temp_root], coll_filter="my.collection"))) == 1
   

# Generated at 2022-06-24 18:15:49.882685
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths())


# Generated at 2022-06-24 18:15:57.863723
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test case: default values
    result = list(list_collection_dirs())
    assert len(result) > 0

    # Test case: bad search path
    result = list(list_collection_dirs(search_paths='/this/path/does/not/exist'))
    assert len(result) == 0

    # Test case: bad search path from config
    result = list(list_collection_dirs(search_paths=['/this/path/does/not/exist']))
    assert len(result) == 0

    # Test case: search path based on a file
    result = list(list_collection_dirs(search_paths=[__file__]))
    assert len(result) == 0

    # Test case: search path containing a single collection

# Generated at 2022-06-24 18:16:04.206538
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    temp_dir = tempfile.gettempdir()
    try:
        os.remove(os.path.join(temp_dir, 'collection_paths.yml'))
    except OSError:
        pass

    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/etc/ansible/collections"
    os.environ['ANSIBLE_CONFIG'] = os.path.join(temp_dir, 'ansible.cfg')

    # check that removing the envvars will hit the defaults
    del os.environ['ANSIBLE_COLLECTIONS_PATHS']
    del os.environ['ANSIBLE_CONFIG']
    my_paths = list(list_valid_collection_paths())
    assert len(my_paths) == 2

    # check that defaults

# Generated at 2022-06-24 18:16:14.816970
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with valid collection
    paths = list_collection_dirs(coll_filter='testcoll.random')

    assert isinstance(paths, list)
    assert len(paths) == 1

    # Test with invalid collection
    paths = list_collection_dirs(coll_filter='nottestcoll.random')

    assert isinstance(paths, list)
    assert len(paths) == 0

    # Test with valid namespace
    paths = list_collection_dirs(coll_filter='testcoll')

    # Test directory exists
    assert os.path.exists(paths[0])

    # Test is directory
    assert os.path.isdir(paths[0])

    # Test with invalid namespace
    paths = list_collection_dirs(coll_filter='nottestcoll')


# Generated at 2022-06-24 18:16:22.191459
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """ Tests of the list_collection_dirs function """
    # build an empty search path
    search_paths=[]
    # build a collection name
    coll_filter="galaxy.test"
    # get the list of dirs
    dirs = list_collection_dirs(search_paths, coll_filter)
    # assert the list is not empty
    assert len(dirs) > 0
    # assert the list only contains one entry
    assert len(dirs) == 1
    # make sure the collection is in the path
    assert "galaxy/test" in dirs[0]

# Generated at 2022-06-24 18:16:31.178687
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test without search_paths or default
    sp = list(list_valid_collection_paths())

    assert len(sp) == len(AnsibleCollectionConfig.collection_paths), 'Incorrect number of paths returned'

    # Test with list of invalid paths
    invalid_paths = ['/nonexistent', 'nonexistent']
    sp = list(list_valid_collection_paths(search_paths=invalid_paths))

    assert len(sp) == 0, "Invalid paths returned %s" % sp

    # Test with list of one path that is invalid and default
    invalid_paths = ['/nonexistent']
    sp = list(list_valid_collection_paths(search_paths=invalid_paths))


# Generated at 2022-06-24 18:16:38.130724
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ansible_collections_paths = []
    collection_namespace = 'test_namespace'
    collection_name = 'test_col'
    collection_path = os.path.join(os.getcwd(), 'ansible_collections', collection_namespace, collection_name)
    ansible_collections_paths.append(collection_path)

    collection_dir_paths = list_collection_dirs(search_paths=ansible_collections_paths,
                                                coll_filter='{}.{}'.format(collection_namespace, collection_name))
    collection_paths = [collection_path for collection_path in collection_dir_paths]
    assert collection_path in collection_paths



# Generated at 2022-06-24 18:16:48.650139
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath
    import tempfile
    import shutil
    import pytest

    collection_name = 'test_collection'

    (fd, temp_filename) = tempfile.mkstemp()
    tmp_dir = os.path.dirname(temp_filename)
    temp_collection_dir = os.path.join(tmp_dir, 'ansible_collections', 'namespace', collection_name)

    # create a dir to use as a fake collection
    os.makedirs(temp_collection_dir, mode=0o755)
    os.close(fd)


# Generated at 2022-06-24 18:16:57.201244
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = [
        'a',
        'b',
    ]

    assert var_2 == list_valid_collection_paths()



# Generated at 2022-06-24 18:17:07.439023
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Test list_valid_collection_paths
    '''

    project_root = os.path.realpath(os.path.join(__file__, '..', '..', '..', '..'))
    test_search_paths = [
        'doesnotexist',
        os.path.join(project_root, 'test', 'data', 'collections', 'for_plugins', 'plugins'),
        os.path.join(project_root, 'test', 'data', 'collections', 'for_plugins', 'non_plugin_files')
    ]

    var_0 = list_valid_collection_paths(search_paths=test_search_paths, warn=True)
    var_1 = list(var_0)
    assert len(var_0) == 1

# Generated at 2022-06-24 18:17:08.616560
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance([], test_case_0())



# Generated at 2022-06-24 18:17:18.542927
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    f = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'ansible', 'collections', 'ansible_collections')


# Generated at 2022-06-24 18:17:21.136803
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:17:31.874747
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_mocks = [{'ansible_collections': {'mycollection': {'plugins': {'action': {}, 'module_utils': {}}}}},
                        {'ansible_collections': {'mycollection': {'plugins': {'action': {}}}}},
                        {'ansible_collections': {'mycollection': {'plugins': {'module_utils': {}}}}}]
    search_paths = ['/tmp/ansible_test_0/test_cases',
                    '/tmp/ansible_test_0/test_cases/mycollection',
                    '/tmp/ansible_test_0/test_cases/ansible_collections']
    for mock in collection_mocks:
        var_0 = create_mock_collection(mock, '/tmp/ansible_test_0/test_cases')


# Generated at 2022-06-24 18:17:35.212983
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise AssertionError()


# Generated at 2022-06-24 18:17:36.496554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_case_0()

# Generated at 2022-06-24 18:17:38.614972
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = [
        '/ignore/this/path',
        '/foo/bar'
    ]
    assert list(list_collection_dirs(search_paths)) == ['/foo/bar/ansible_collections']


# Generated at 2022-06-24 18:17:45.352518
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Following code can be used to generate expected test output:
    # var_0 = list_valid_collection_paths()
    # print(var_0)

    # TODO: write tests
    # assert var_0 == expected_result

    assert True


# Generated at 2022-06-24 18:17:59.601769
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    coll_root = to_text(
        os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'collection_examples')
    )

    if PY3:
        # On python3, the collection_examples directory is not in a subdir of the collection_loader directory
        # as it was on python2.  This is because python3 no longer has the concept of a
        # PACKAGE_DIR and therefore the contents of the collection_examples directory were moved
        # to the top level of the collections dir.
        coll_root = os.path.join(coll_root, '..')


# Generated at 2022-06-24 18:18:01.142199
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths is not None



# Generated at 2022-06-24 18:18:06.354103
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert_equals(list_collection_dirs(['/home/foo/bar/ansible/collections', '/home/foo/baz/ansible/collection'], 'my_namespace.my_collection'), ['my_namespace.my_collection'])

# Generated at 2022-06-24 18:18:13.133000
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = "/home/dastang/Downloads/ansible/ansible/test/unit/utils/collection_loader/test_collections"
    warn = False
    result = list_valid_collection_paths(search_paths=search_paths,warn=warn)
    assert result[0] == '/home/dastang/Downloads/ansible/ansible/test/unit/utils/collection_loader/test_collections'


# Generated at 2022-06-24 18:18:14.607970
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for var_0 in test_case_0():
        print(var_0)
        print()



# Generated at 2022-06-24 18:18:16.524629
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=['foo']) == [('foo', 'ansible_collections')]

# Generated at 2022-06-24 18:18:17.917296
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs())
    print(coll_dirs)

# Generated at 2022-06-24 18:18:20.526572
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    var_1 = list(var_1)


if __name__ == '__main__':
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:18:26.594669
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)

    assert (var_1 != ["/usr/local/lib/python2.7/dist-packages/ansible_collections"])


# Generated at 2022-06-24 18:18:31.394079
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/home/user/src/xyz/abc']
    warn = True
    result = list_valid_collection_paths(search_paths, warn)
    assert type(result) == type(list_valid_collection_paths())
    assert type(result) == type(var_1)


# Generated at 2022-06-24 18:18:45.033275
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    mock_params = ['ansible.builtin']
    mock_params[0] = 'ansible.builtin'
    mock_params.append('ansible.module_utils.network.iosxr.config.iosxr')
    mock_params[1] = 'ansible.module_utils.network.iosxr.config.iosxr'
    mock_params.append('ansible.module_utils.network.iosxr.facts.iosxr')
    mock_params[2] = 'ansible.module_utils.network.iosxr.facts.iosxr'
    mock_params.append('ansible.module_utils.network.iosxr.nxos.file_copy')

# Generated at 2022-06-24 18:18:46.766825
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), Iterable)



# Generated at 2022-06-24 18:18:48.705958
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # assert list_collection_dirs
    var_2 = list_collection_dirs()

# Generated at 2022-06-24 18:18:57.998647
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(
        argument_spec=dict()
    )

    if not module._name == 'ansible.builtin.debug':
        module.exit_json(skipped=True, msg="The test module only works with the 'debug' module")

    # Test defaults
    with StringIO() as stdout:
        with StringIO() as stderr:
            orig_stdout = sys.stdout
            orig_stderr = sys.stderr
            sys.stdout = stdout
            sys.stderr = stderr
            result = module.run_command(["list_collection_dirs()"], check_rc=True)
            sys.stdout = orig_std

# Generated at 2022-06-24 18:18:59.113827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(test_case_0())
    assert True



# Generated at 2022-06-24 18:19:05.697483
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    invalid_collection_path_list = ('/etc/ansible/collections', '/usr/share/ansible_collections', '/usr/share/ansible/collections')
    valid_collection_path_list = ('/etc', '/usr/share/ansible_collections')
    var_0 = list_valid_collection_paths(search_paths=invalid_collection_path_list)
    var_1 = list(var_0)



# Generated at 2022-06-24 18:19:06.616066
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_case_0()

# Generated at 2022-06-24 18:19:09.080921
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list(list_collection_dirs())
    var_1 = list_collection_dirs()
    var_2 = list(var_1)

# Generated at 2022-06-24 18:19:10.939371
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 == []



# Generated at 2022-06-24 18:19:13.153269
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)


# Generated at 2022-06-24 18:19:34.739578
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test function list_valid_collection_paths
    """
    assert test_case_0()

# Generated at 2022-06-24 18:19:39.491734
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()  == list_valid_collection_paths()
    assert list_valid_collection_paths()  != list_valid_collection_paths()


# Generated at 2022-06-24 18:19:45.724004
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert isinstance(var_0, list)
    assert len(var_0) == 2
    assert '~/ansible_collections' in var_0
    assert '/.ansible/collections' in var_0


# Generated at 2022-06-24 18:19:46.850438
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass



# Generated at 2022-06-24 18:19:47.851387
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True == False


# Generated at 2022-06-24 18:19:53.848704
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        with patch('os.path.exists') as mock_exists:
            with patch('os.path.isdir') as mock_isdir:

                mock_exists.return_value = False
                mock_isdir.return_value = False

                list_valid_collection_paths()

    except Exception as e:
        assert(False)


# Generated at 2022-06-24 18:19:59.522879
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = os.getcwd()
    var_1 = list_collection_dirs()
    var_1_0 = list(var_1)


# Generated at 2022-06-24 18:20:01.873554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """ Test the list_valid_collection_paths function"""

    # Test case #0
    test_case_0()


# Generated at 2022-06-24 18:20:13.971393
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Mock list_valid_collection_paths
    mock_list_valid_collection_paths = lambda *args, **kwargs: ['path 1', 'path 2', 'path 3', ]

    import copy
    import sys
    import warnings

    from ansible.collections import is_collection_installed

    store_old_value = is_collection_installed.list_valid_collection_paths

# Generated at 2022-06-24 18:20:20.255782
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == ((),)
    assert list_collection_dirs() == ((),)
    assert list_collection_dirs() == ((),)


if __name__ == '__main__':
    import math
    import subprocess
    import sys
    import time

    test_cases = [
        # 0 Basic test.
        {'value': '--ansible-collection', 'expected': (None,)},
    ]

    num_pass = 0
    num_fail = 0

    for index, test_case in enumerate(test_cases):
        result = list_collection_dirs(*test_case['value'])

        if result != test_case['expected']:
            num_fail += 1

# Generated at 2022-06-24 18:21:00.346030
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert isinstance(var_0, list)
    assert isinstance(var_0[0], str)


# Generated at 2022-06-24 18:21:03.789534
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for path in list_valid_collection_paths():
        assert os.path.exists(path)
        assert os.path.isdir(path)
        assert os.path.basename(path) == 'ansible_collections'



# Generated at 2022-06-24 18:21:11.036999
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with a bogus path
    paths = ['bogus_path']
    search_paths = list_valid_collection_paths(paths, warn=True)
    search_paths = list(search_paths)
    if len(search_paths) != 0:
        raise AnsibleError("list_valid_collection_paths did not filter out bogus path")

    # Test with a valid path
    paths = ['./test_data']
    search_paths = list_valid_collection_paths(paths, warn=True)
    search_paths = list(search_paths)
    if len(search_paths) != 1:
        raise AnsibleError("list_valid_collection_paths did not add test_data to search paths")



# Generated at 2022-06-24 18:21:13.452217
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collection_dirs(search_paths=None, coll_filter=None)


# Generated at 2022-06-24 18:21:17.101788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print('')
    print('Testing list_valid_collection_paths:')
    print('Test case 0')
    try:
        test_case_0()
        print('Passed.')
    except:
        print('Failed.')
    print('')


# Generated at 2022-06-24 18:21:19.469381
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 == []


# Generated at 2022-06-24 18:21:27.507288
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = os.path.join(os.getcwd(), 'tests/data/playbooks/test_collections_file_include/')
    search_paths = [path, '/tmp/not_exist']
    ret = list_valid_collection_paths(search_paths, warn=True)
    assert len(ret) == 1
    from ansible.constants import DEFAULT_COLLECTIONS_PATHS
    DEFAULT_COLLECTIONS_PATHS.pop()
    ret = list_valid_collection_paths(search_paths)
    assert len(ret) != 1


# Generated at 2022-06-24 18:21:28.866376
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not test_case_0()



# Generated at 2022-06-24 18:21:32.127550
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=['/tmp']) == list_collection_dirs(search_paths=['/tmp'])


# Generated at 2022-06-24 18:21:37.226789
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test case 1
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    # Test case 2
    var_2 = list_collection_dirs(search_paths=[])
    var_3 = list(var_2)


# Generated at 2022-06-24 18:23:00.818404
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 == [
        '/etc/ansible/collections/ansible_collections',
        '/usr/share/ansible/collections/ansible_collections',
        '/Users/michaelkuhn/dev/ansible/test_collections/ansible_collections',
        '/home/ansible/ansible/test_collections/ansible_collections',
        '/home/ansible/ansible/test_collections_2/ansible_collections']



# Generated at 2022-06-24 18:23:02.716250
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)


# Generated at 2022-06-24 18:23:06.135474
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:23:09.133074
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert False is test_list_valid_collection_paths.__annotations__["var_0"].__class__.__isabstractmethod__
    assert False is test_list_valid_collection_paths.__annotations__["var_1"].__class__.__isabstractmethod__

    assert True is False



# Generated at 2022-06-24 18:23:10.762466
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert True

# Generated at 2022-06-24 18:23:11.681438
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:23:12.561067
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list_collection_dirs())

# Generated at 2022-06-24 18:23:23.286213
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths=None
    var_1 = list_valid_collection_paths( search_paths=search_paths)
    var_1 = list(var_1)
    assert len(var_1) == 2, 'Incorrect var_1 value for list_valid_collection_paths(): got %s, expected %s' % (var_1, '2')
    assert var_1[0] == './ansible_collections', 'Incorrect var_1 value for list_valid_collection_paths(): got %s, expected %s' % (var_1, '[\'./ansible_collections\']')

# Generated at 2022-06-24 18:23:30.784788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = [1]
    var_0 = list_valid_collection_paths(var)
    var_1 = list(var_0)
    var_2 = list(var_1)
    var_3 = list(var_2)
    var_4 = list(var_3)
    var_5 = list(var_4)
    var_6 = list(var_5)
    var_7 = list(var_6)
    var_8 = list(var_7)
    var_9 = list(var_8)
    var_10 = list(var_9)
    var_11 = list(var_10)
    var_12 = list(var_11)
    var_13 = list(var_12)
    var_14 = list(var_13)

# Generated at 2022-06-24 18:23:32.618518
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for result in list_collection_dirs():
        assert isinstance(result, str)