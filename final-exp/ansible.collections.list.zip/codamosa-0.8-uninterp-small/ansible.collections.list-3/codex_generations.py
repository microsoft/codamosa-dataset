

# Generated at 2022-06-24 18:15:09.806412
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list(list_collection_dirs())
    assert var_0.count(".") == 0
    assert var_0.count("/") == 0
    assert var_0.count("/") == 0
    assert var_0.count("/") == 0
    assert var_0.count("/") == 0


# Generated at 2022-06-24 18:15:12.972996
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Ensure AnsibleError is raised when a invalid value is passed
    with pytest.raises(AnsibleError) as exc:
        list_collection_dirs(search_paths=None, coll_filter=None)
    assert exc.value.args[0] == 'Invalid collection pattern supplied: None'



# Generated at 2022-06-24 18:15:15.718148
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = list_valid_collection_paths(["/home/ansible/ansible_collections"])


# Generated at 2022-06-24 18:15:24.530562
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for search_paths being None
    try:
        list_valid_collection_paths(None)
    except TypeError:
        pass
    # Test for search_paths being a list
    try:
        list_valid_collection_paths([])
    except TypeError:
        pass
    # Test for search_paths being a string
    try:
        list_valid_collection_paths('')
    except TypeError:
        pass
    # Test for search_paths being a boolean
    try:
        list_valid_collection_paths(True)
    except TypeError:
        pass
    # Test for search_paths being a dictionary
    try:
        list_valid_collection_paths({})
    except TypeError:
        pass
    # Test for search_paths being an integer


# Generated at 2022-06-24 18:15:26.495427
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    if not isinstance(list_collection_dirs(), types.GeneratorType):
        raise AssertionError()


# Generated at 2022-06-24 18:15:36.925092
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    list_of_valid_collections = '/etc/ansible/ansible_collections:/usr/share/ansible/ansible_collections:/usr/share/collection/:/usr/share/ansible/ansible_collections'
    actual_list_collect = list_valid_collection_paths(search_paths=['/etc/ansible/ansible_collections', '/usr/share/ansible/ansible_collections', ':', '/usr/share/collection/'])
    actual_list_output = "".join(actual_list_collect)

    if list_of_valid_collections == actual_list_output:
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-24 18:15:41.746211
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = None
    exp_0 = None
    result_0 = test_case_0()
    assert exp_0 == result_0, "Expected: '%s', Got: '%s'" % (exp_0, result_0)



# Generated at 2022-06-24 18:15:46.475773
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list(list_collection_dirs())
    assert var_0 == ['C:\\Users\\daniel.hargreaves\\.ansible\\collections\\ansible_collections\\microsoft\\azcollection', 'C:\\Users\\daniel.hargreaves\\.ansible\\collections\\ansible_collections\\netapp\\netapp_collection', 'C:\\Users\\daniel.hargreaves\\.ansible\\collections\\ansible_collections\\sensu\\sensu_go']


# Generated at 2022-06-24 18:15:55.609105
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # ensure the list of paths is a subset of what is expected
    list_paths = list(list_valid_collection_paths([], warn=False))
    assert(list_paths == [])

    list_paths = list_valid_collection_paths(['/usr/share/ansible/collections', '/tmp/doesnotexist'], warn=False)
    assert(list_paths == ['/usr/share/ansible/collections'])

    list_paths = list_valid_collection_paths(['/usr/share/ansible/collections', '/tmp/doesnotexist'], warn=True)
    assert(list_paths == ['/usr/share/ansible/collections'])


# Generated at 2022-06-24 18:16:03.762087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import is_proxy

    # API test

    # Only a single path is included.
    # 1. One valid search path.
    # 2. One invalid search path.
    # The invalid path won't be returned.

    search_paths = [basic.HOST_VAR_PATH]

    for path in list_valid_collection_paths(search_paths):
        assert path in search_paths, "Unexpected return from function."

    # API test

    # Only a single path is included.
    # 1. One valid search path.
    # 2. One invalid search path.
    # 3. One path, which exists, but isn't a directory.
    # The invalid path won't be returned.


# Generated at 2022-06-24 18:16:11.406406
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert var_0 == None

# Generated at 2022-06-24 18:16:14.962997
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # The default collection search_paths should be set
    assert AnsibleCollectionConfig.collection_paths != []

    # There should be at least one collection path in the default search_paths
    assert list_collection_dirs() != []



# Generated at 2022-06-24 18:16:24.657896
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture_0 = [
        {
            "a": "b",
            "c": "d"
        }
    ]
    fixture_1 = [
        {
            "a": "b",
            "c": "d"
        }
    ]
    fixture_2 = [
        {
            "a": "b",
            "c": "d"
        }
    ]

    # Pass in (search_paths=[a, b, c, ...])
    var_0 = list_collection_dirs(search_paths=[fixture_0])

    # Pass in (search_paths=[a, b, c, ...], coll_filter=None)
    var_1 = list_collection_dirs(search_paths=[fixture_1], coll_filter=None)

    # Pass in (search_

# Generated at 2022-06-24 18:16:26.908929
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = "/ansible"
    var_0 = "/ansible"
    assert var_0 == expected


# Generated at 2022-06-24 18:16:30.410141
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    result_0 = list_collection_dirs()
    test_case_0()
    assert len(result_0) > 0, "Test case 0 returned no result."



# Generated at 2022-06-24 18:16:34.421629
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/tmp'], True) == ['/tmp']
    assert list_valid_collection_paths(['/tmp/0', '/tmp/1'], True) == ['/tmp/0', '/tmp/1']


# Generated at 2022-06-24 18:16:36.197686
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(search_paths='test')
    assert isinstance(var_0, list)



# Generated at 2022-06-24 18:16:43.422628
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Mock AnsibleModule with a single test case
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict({},
        ),
        supports_check_mode=True,
    )
    module.exit_json(**test_case_0())


if __name__ == '__main__':
    # Run the unit test
    test_list_collection_dirs()

# Generated at 2022-06-24 18:16:47.979253
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths_0 = None

    assert list_collection_dirs() == (search_paths_0 == None)

# Generated at 2022-06-24 18:16:55.943790
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = 'path_0'
    warn = False
    expected = 'namespace_0'
    actual = list_valid_collection_paths(search_paths, warn)
    assert actual == expected, 'Expected: {0}, Actual: {1}'.format(expected, actual)
    # Test with a search_paths that is not an iterable

    search_paths = 'path_1'
    warn = False
    actual = list_valid_collection_paths(search_paths, warn)
    assert actual == expected, 'Expected: {0}, Actual: {1}'.format(expected, actual)


# Generated at 2022-06-24 18:17:04.507423
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1, "Test for function 'list_collection_dirs' failed"

# Generated at 2022-06-24 18:17:06.662138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(["path1", "path2"], False) == ["path1","path2"]


# Generated at 2022-06-24 18:17:09.056288
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = list_valid_collection_paths()
    var1 = list(var)
    assert 'playbooks' in var1


# Generated at 2022-06-24 18:17:16.119141
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = list_collection_dirs(search_paths=['{0}'.format(os.path.join(os.getcwd(), 'tests', 'data', 'ansible_test_collection')), '{0}'.format(os.path.join(os.getcwd(), 'tests', 'data', 'ansible_test_collection2'))], coll_filter='avocado.test')
    var_3 = list(var_2)
    assert len(var_3) > 0



# Generated at 2022-06-24 18:17:20.316689
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths()
    assert isinstance(result, types.GeneratorType)
    assert isinstance(list(result), list)


# Generated at 2022-06-24 18:17:26.342610
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    fixture_0 = ['/tmp/ansible_collections', '/foo']
    expected_0 = list_valid_collection_paths(fixture_0)
    fixture_1 = ['/tmp/ansible_collections', '/foo']
    expected_1 = list_valid_collection_paths(fixture_1, True)
    assert expected_0 == expected_1

# Generated at 2022-06-24 18:17:31.005682
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = os.path.join('test', 'data', 'collection_test', 'collections')
    var_1 = list_valid_collection_paths([var_0])
    var_2 = list(var_1)
    var_3 = var_2[0]
    var_4 = var_3 == var_0
    assert var_4 is True


# Generated at 2022-06-24 18:17:41.210763
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        import os
    except ImportError:
        raise Exception("No os module")
    v0 = b'/private/tmp/ansible_collections'
    v1 = to_bytes(v0, errors='surrogate_or_strict')
    v2 = os.path.join(v1, b'ansible_collections')
    v3 = list_valid_collection_paths(['/private/tmp/ansible_collections'])
    v4 = list(v3)
    v5 = v4[0]
    assert v5 == v0

# Generated at 2022-06-24 18:17:48.921324
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_path = to_bytes(os.path.join(get_resources_path(), 'ansible_collections'))
    collections = defaultdict(dict)
    for ns in os.listdir(b_path):
        b_namespace_dir = os.path.join(b_path, to_bytes(ns))
        for coll in os.listdir(b_namespace_dir):
            # skip dupe collections as they will be masked in execution
            if coll not in collections[ns]:
                b_coll_dir = os.path.join(b_namespace_dir, coll)
                if is_collection_path(b_coll_dir):
                    collections[ns][coll] = b_coll_dir
                    yield b_coll_dir



# Generated at 2022-06-24 18:17:49.857224
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:18:07.447129
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    assert list_collection_dirs()
    # TODO: this is a lousy test, fix it
    # assert not list_collection_dirs()
    # assert list_collection_dirs()


# # TODO: Unit test for function list_valid_collection_paths
# def test_list_valid_collection_paths():
#     assert list_valid_collection_paths()


# # TODO: Unit test for function list_valid_collection_names
# def test_list_valid_collection_names():
#     assert list_valid_collection_names()


# # TODO: Unit test for function filter_collections
# def test_filter_collections():
#     assert filter_collections()


# # TODO: Unit test for function load_collections
# def test_load_collections():
#     assert load

# Generated at 2022-06-24 18:18:13.585780
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs(search_paths=['/not/exists'])) == []
    assert list(list_collection_dirs(search_paths=['/not/exists', '/ansible_collections'])) == []
    assert list(list_collection_dirs(search_paths=['/not/exists', '/ansible_collections'],
                                     coll_filter='mycoll.mycoll2')) == []


# Generated at 2022-06-24 18:18:15.099009
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/non_existent/path', '/tmp'])


# Generated at 2022-06-24 18:18:15.917134
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:18:25.977249
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # This list of paths will be assumed to exist
    search_paths = [
        '/home/coleman/.ansible/mycollections',
        '/home/coleman/mycollections',
    ]

    # This list of paths will be assumed to not exist
    bad_search_paths = [
        '/home/coleman/mycollections/nope',
        '/home/coleman/mycollections/nope.nope',
    ]

    # Returned values should be only the paths which exist
    good_paths = list_valid_collection_paths(search_paths)
    assert search_paths[0] in good_paths
    assert search_paths[1] in good_paths
    assert bad_search_paths[0] not in good_paths
    assert bad_

# Generated at 2022-06-24 18:18:27.299328
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == True

# Generated at 2022-06-24 18:18:28.669639
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list(list_collection_dirs())) > 0

# Generated at 2022-06-24 18:18:34.776847
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test using default paths
    var_2 = list_valid_collection_paths()
    var_3 = list(var_2)
    assert '~/.ansible/collections' in var_3

    # Test using default + configured paths
    var_4 = list_valid_collection_paths(search_paths=['/tmp/foo'])
    var_5 = list(var_4)
    assert '~/.ansible/collections' in var_5
    assert '/tmp/foo' in var_5



# Generated at 2022-06-24 18:18:40.905044
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Create the mock object for the test case
    # ToDo: Write this unit test to make sure it finds things from all potential places (env vars, ansible.cfg, etc.)
    # ToDo: Also, this test should not use to_bytes, because it does not necessarily lead to utf-8
    try:
        assert isinstance(list_collection_dirs(), list)
        assert os.path.isdir(to_bytes(list_collection_dirs()[0]))
    except Exception:
        raise AssertionError


# Generated at 2022-06-24 18:18:43.356146
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is not None

# Generated at 2022-06-24 18:18:58.737734
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test nonexistent search path.
    nonexistent_search_paths = ["/opt/ansible/collections", "/does/not/exist"]
    ret = list_valid_collection_paths(search_paths=nonexistent_search_paths, warn=False)
    assert list(ret) == []

    # Test search path that exists but is not a directory.
    file_as_search_paths = ["tests/test_collections.py"]
    ret = list_valid_collection_paths(search_paths=file_as_search_paths, warn=False)
    assert list(ret) == []

    # Test a valid search path.
    valid_search_paths = ["/usr/share"]

# Generated at 2022-06-24 18:19:01.510102
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture_data = list_collection_dirs.__annotations__

    assert len(fixture_data) == 2

    assert fixture_data['search_paths'] == None
    assert fixture_data['coll_filter'] == None

# Generated at 2022-06-24 18:19:08.010646
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test the filtering of non-existing paths
    """
    assert list(list_valid_collection_paths(["/no/such/path", "/no/such/other/path"])) == []
    assert list(list_valid_collection_paths(["/etc/ansible/collections", "/no/such/path", "/no/such/other/path"])) == ['/etc/ansible/collections']

# Generated at 2022-06-24 18:19:11.001485
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_3 = ['an', 'ansible']
    var_4 = list_collection_dirs()
    var_5 = list(var_4)
    assert var_5.__eq__(var_3)

# Generated at 2022-06-24 18:19:12.038276
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False, "Not implemented"


# Generated at 2022-06-24 18:19:13.748015
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list_collection_dirs)
    assert list_collection_dirs()


# Generated at 2022-06-24 18:19:18.958894
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    mock_paths = []
    mock_coll_filter = 'collection.filter'

    # Passing mock objects as parameters
    list_collection_dirs(search_paths=mock_paths, coll_filter=mock_coll_filter)


# Generated at 2022-06-24 18:19:21.897281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # list_collection_dirs() returns list of text-string paths
    assert isinstance(list_collection_dirs(), list)

# Generated at 2022-06-24 18:19:22.707578
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True == True


# Generated at 2022-06-24 18:19:25.247088
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Assure no crash when empty search_paths
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert len(var_1) == 0



# Generated at 2022-06-24 18:19:49.285865
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_1 = "/Users/kelly/A-Work/automation/ansible-modules-core/ansible/utils/tests/data/test_collections"
    var_3 = list_valid_collection_paths(search_paths=var_1)
    var_4 = list(var_3)
    assert var_4 == [var_1], var_4

# Generated at 2022-06-24 18:20:00.760708
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with pytest.raises(AnsibleError) as excinfo:
        # Test with a collection filter that is invalid
        list_collection_dirs(coll_filter='foo')
    assert "Invalid collection pattern supplied" in str(excinfo.value)

    # Test with a valid collection filter (should return nothing)
    colls = list(list_collection_dirs(coll_filter='hehe.lol'))
    assert len(colls) == 0

    # Test with a valid namespace filter (should return nothing)
    colls = list(list_collection_dirs(coll_filter='hehe'))
    assert len(colls) == 0

    # Test with a namespace filter that is None (should return some collections)
    colls = list(list_collection_dirs())
    assert len(colls) > 0

# Generated at 2022-06-24 18:20:04.795349
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    test_case = [
        os.path.join(curr_dir, '..', '..', '..', 'ansible_collections', 'ansible', 'other'),
        os.path.join(curr_dir, '..', '..', '..', 'ansible_collections', 'ansible', 'my_collection')]
    assert list_collection_dirs() == test_case

# Generated at 2022-06-24 18:20:05.988724
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert type(test_case_0()) == list

# Generated at 2022-06-24 18:20:12.392194
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = "/etc/ansible/collections/ansible_collections"
    var_3 = list_valid_collection_paths([var_2])
    var_4 = list(var_3)
    assert var_4 == ["/etc/ansible/collections/ansible_collections"]


# Generated at 2022-06-24 18:20:19.760495
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['.', './', './ansible_collections']
    good_paths = []
    for path in list_valid_collection_paths(test_paths):
        good_paths.append(path)

    assert good_paths == ['./ansible_collections']


# Generated at 2022-06-24 18:20:21.498087
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 == var_0


# Generated at 2022-06-24 18:20:23.795074
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert type(list_valid_collection_paths(search_paths=[], warn=True)) == type(list_valid_collection_paths())


# Generated at 2022-06-24 18:20:32.483451
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import shutil
    import tempfile
    import ansible.constants as C

    # create a temp dir to store collections
    coll_root = tempfile.mkdtemp(prefix='ansible_collections-')

    # create a file as test to see if isdir() works
    tmp_file = tempfile.mktemp(dir=coll_root)

    # create a collection dir inside the temp dir
    coll_dir = tempfile.mkdtemp(dir=coll_root)
    if not coll_dir.endswith('ansible_collections'):
        coll_dir = os.path.join(coll_dir, 'ansible_collections')
    os.makedirs(coll_dir)

    # create a file inside the collection dir

# Generated at 2022-06-24 18:20:37.910868
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Scenario 1: Invalid collection path
    with pytest.raises(AnsibleError):
        res = list_valid_collection_paths(["/path/to/nowhere"])

    # Sceanrio 2: Valid collection path
    ac_path = AnsibleCollectionConfig.collection_paths
    res = list(list_valid_collection_paths(ac_path))
    assert ac_path == res



# Generated at 2022-06-24 18:21:22.570740
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    In this unit test, we will test "list_collection_dirs" function.
    We will test with different parameters and values.
    It's purpose is to return paths for the specific collections found in passed or configured search paths
    """

    # Test with default values - This will return a list of collection directory paths
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    # Test with search_paths parameter - This will return a list of collection directory paths
    var_0 = list_collection_dirs(search_paths=[])
    var_1 = list(var_0)

    # Test with search_paths and coll_filter parameter - This will return a list of collection directory paths
    var_0 = list_collection_dirs(search_paths=[], coll_filter="")
   

# Generated at 2022-06-24 18:21:23.594971
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == None

# Generated at 2022-06-24 18:21:25.031041
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(list_collection_dirs())



# Generated at 2022-06-24 18:21:26.937006
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Testing function list_collection_dirs")
    test_case_0()
    print("Success")


# Generated at 2022-06-24 18:21:38.703661
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Handle: None, False
    # expected_result: None
    assert list_valid_collection_paths() is not None

    # Handle: None, False
    # expected_result: None
    assert list_valid_collection_paths() is not None

    # Handle: None, False
    # expected_result: None
    # noinspection SpellCheckingInspection
    assert list_valid_collection_paths() is not None

    # Handle: None, False
    # expected_result: None
    assert list_valid_collection_paths() is not None

    # Handle: None, False
    # expected_result: None
    # noinspection SpellCheckingInspection
    assert list_valid_collection_paths() is not None

    # Handle: None, False
    # expected_result: None
    # noinspection Spell

# Generated at 2022-06-24 18:21:39.995776
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 1 == 1


# Generated at 2022-06-24 18:21:42.272184
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: Write test
    pass # nothing to test


# Generated at 2022-06-24 18:21:43.119395
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False


# Generated at 2022-06-24 18:21:46.226376
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    actual = list_collection_dirs()
    expected = test_case_0()

    assert actual == expected

# Test list_collection_dirs verbose

# Generated at 2022-06-24 18:21:54.353628
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1 == []
    var_2 = list_collection_dirs(search_paths=['my_search_path'])
    var_3 = list(var_2)
    assert var_3 == []
    var_4 = list_collection_dirs(coll_filter='my_coll_filter')
    var_5 = list(var_4)
    assert var_5 == []
    var_6 = list_collection_dirs(search_paths=['my_search_path'], coll_filter='my_coll_filter')
    var_7 = list(var_6)
    assert var_7 == []

# Generated at 2022-06-24 18:23:20.486402
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # case #0
    test_case_0()

# Generated at 2022-06-24 18:23:22.146391
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == ['roles']

# Generated at 2022-06-24 18:23:23.380863
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:23:25.100713
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import pytest

    with pytest.raises(SystemExit):
        list_valid_collection_paths()

# Generated at 2022-06-24 18:23:27.706728
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) == 0



# Generated at 2022-06-24 18:23:30.266198
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:23:33.695536
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Check if len of the returned list
    result_len = len(list_valid_collection_paths())

    # Verify expected results
    assert result_len == 2


# Generated at 2022-06-24 18:23:37.444424
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list(list_valid_collection_paths(path))
    assert not list(list_valid_collection_paths(path))
    assert not list(list_valid_collection_paths(path))


# Generated at 2022-06-24 18:23:41.090246
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 is None

# Generated at 2022-06-24 18:23:47.921516
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.information("Starting test_list_valid_collection_paths")
    # Test fail
    display.information("Expecting fail")
    try:
        list_valid_collection_paths(search_paths, warn)
    except Exception as err:
        display.information(err.__class__.__name__)
    else:
        display.information("No exception")
        assert False

    # Test pass
    display.information("Expecting pass")
    try:
        list_valid_collection_paths(search_paths)
    except Exception as err:
        display.information(err.__class__.__name__)
        assert False
    else:
        display.information("No exception")
