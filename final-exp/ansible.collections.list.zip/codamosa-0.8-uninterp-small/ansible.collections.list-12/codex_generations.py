

# Generated at 2022-06-24 18:15:07.504410
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:15:08.048083
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()



# Generated at 2022-06-24 18:15:09.245999
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    
    # Test 1
    var_0 = list_collection_dirs()
    assert var_0 == ()


# Generated at 2022-06-24 18:15:09.808919
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:15:18.126530
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_paths = [
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
        '/root/ansible/ansible_collections',
    ]

    coll_filter = 'w.w'

    result = list_collection_dirs(search_paths=coll_paths, coll_filter=coll_filter)
    assert result is not None




# Generated at 2022-06-24 18:15:20.539427
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Expected: List of collection paths
    Actual:   List of collection paths
    """
    expected = ['test']
    actual = list_valid_collection_paths(expected)
    assert actual == expected

# Generated at 2022-06-24 18:15:27.614431
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """Variable name 'var_0' is used to hold return value from function list_valid_collection_paths
    print var_0 to see the return value from list_valid_collection_paths that is being passed as a parameter to
    list_collection_dirs"""
    var_0 = list_valid_collection_paths()
    b_path = os.path.expanduser("ansible_collections")
    test_paths = [os.path.join(to_bytes(b_path), 'ansible_collections')]

    """Variable name 'var_1' is used to hold return value from function list_collection_dirs
    print var_1 to see the return value from list_collection_dirs that is being passed as a parameter to
    is_collection_path"""

# Generated at 2022-06-24 18:15:29.800967
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == 'my-ansible-collection'

# Generated at 2022-06-24 18:15:35.587788
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 == ('/etc/ansible/collections/ansible_collections/mycollection/mymodule', '/etc/ansible/collections/ansible_collections/mycollection/mymodule', '/etc/ansible/collections/ansible_collections/mycollection/mymodule')



# Generated at 2022-06-24 18:15:40.465215
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        'foo/bar/baz',
        'foo/bar/biz',
    ]
    result = list_valid_collection_paths(search_paths)
    assert len(result) == 0


# Generated at 2022-06-24 18:15:55.666502
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    '''
    Test for list_collection_dirs()
    '''
    import tempfile
    import shutil
    import os
    import pathlib
    from ansible.module_utils._text import to_bytes

    path = tempfile.mkdtemp()
    path = pathlib.Path(path)
    coll_path = path / 'ansible_collections'
    os.mkdir(str(coll_path))
    os.mkdir(str(coll_path / 'namespace1' / 'collection1'))

    assert list_collection_dirs(search_paths=[str(path)]) == iter([str(coll_path / 'namespace1' / 'collection1')])

# Generated at 2022-06-24 18:16:00.009647
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common._collections_compat import Path

    test_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'collections', 'ansible_collections')
    paths = list(list_collection_dirs(search_paths=[test_path]))

    assert Path(test_path, 'test_namespace', 'test_collection').__str__() in paths
    assert Path(test_path, 'test_namespace2', 'test_collection2').__str__() in paths

# Generated at 2022-06-24 18:16:05.052437
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    dirs = list(list_collection_dirs(search_paths=['test/data/test_list_collection_dirs']))
    assert dirs == [
        'test/data/test_list_collection_dirs/ansible_collections/testcoll.testplugin/'
    ]

# Generated at 2022-06-24 18:16:09.367758
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_filter = 'ansible_collections.test_namespace.test_name'
    test_colls = list()
    for test_path in list_collection_dirs(coll_filter=test_filter):
        test_colls.append(test_path)

    assert len(test_colls) == 1

# Generated at 2022-06-24 18:16:19.746472
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.utils.collection_loader import list_collection_paths
    from ansible.config.manager import ConfigManager
    from ansible.config.collection import AnsibleCollectionConfig
    from os.path import basename, dirname

    test_paths = ["/tmp/path1", "/tmp/path2", "/tmp/path3", "/tmp/path4", "/tmp/path5"]

    # create config manager and set collection search paths
    cfg_manager = ConfigManager()
    cfg_manager.set_options(config_file_parser_options={
        'config_dir': '/tmp/path1',
        'command_line': ['--collections-path', '/tmp/path2']
    })

    # check all paths

# Generated at 2022-06-24 18:16:23.870009
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/path/to/avocado/master', '/path/to/avocado/plugin']

    for path in list_valid_collection_paths(search_paths):
        assert(path == '/path/to/avocado/master' or path == '/path/to/avocado/plugin')

# Generated at 2022-06-24 18:16:31.302529
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # You should not reuse search path parameter as changing it will mask duplicates
    search_path = [os.path.join(os.path.dirname(__file__), '..', 'fixtures', 'packaging', 'ansible_collections')]
    collection_dirs = list(list_collection_dirs(search_paths=search_path))
    assert len(collection_dirs) == 9
    assert collection_dirs[0].endswith('namespace.othernamespace.test_collection.test_plugin')
    assert collection_dirs[1].endswith('namespace.othernamespace.test_collection2.test_plugin')
    assert collection_dirs[2].endswith('namespace.othernamespace.test_collection3.test_plugin')

# Generated at 2022-06-24 18:16:33.504132
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/nonexistent']) == []


# Generated at 2022-06-24 18:16:40.433135
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # import pprint
    # pprint.pprint(list(list_collection_dirs(coll_filter='collection')), width=1)
    # pprint.pprint(list(list_collection_dirs(coll_filter='namespace.collection')), width=1)
    # pprint.pprint(list(list_collection_dirs(coll_filter='ansible_collections.collection')), width=1)

    # TODO: Assert something meaningful
    assert list(list_collection_dirs(coll_filter='collection'))
    assert list(list_collection_dirs(coll_filter='namespace.collection'))
    assert list(list_collection_dirs(coll_filter='ansible_collections.collection'))



# Generated at 2022-06-24 18:16:46.051484
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from functools import reduce
    from ansible.utils.collection_loader import list_collection_dirs

    # Some useful directories
    from ansible.utils.hashing import checksum_s
    from ansible.module_utils.six.moves import urllib

    # Test all the collection paths
    ansible_collections_dirs = list_collection_dirs()

    # Test a single namespace
    ansible_collections_dirs = list_collection_dirs(coll_filter='ansible_namespace')
    assert 'ansible.ansible_namespace' in list(map(lambda x: urllib.parse.unquote(os.path.basename(x)), ansible_collections_dirs))

    # Test a single collection

# Generated at 2022-06-24 18:17:03.853780
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Tests with empty search_paths, warn should be true.
    with pytest.raises(AnsibleError):
        result = list_valid_collection_paths(search_paths=[], warn=True)

        assert result == None
    # Tests with empty search_paths, warn should be false.
    with pytest.raises(AnsibleError):
        result = list_valid_collection_paths(search_paths=[], warn=False)

        assert result == None
    # Test with empty search_paths and nonempty config, warn should be true.
    with pytest.raises(AnsibleError):
        result = list_valid_collection_paths(search_paths=['a'], warn=True)

        assert result == None
    # Test with empty search_paths and nonempty config, warn

# Generated at 2022-06-24 18:17:06.804795
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/usr/share/ansible/collections']
    search_paths = list(search_paths)
    search_paths = list(search_paths)
    assert list(list_valid_collection_paths(search_paths)) == search_paths


# Generated at 2022-06-24 18:17:07.892818
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True # This is a stub



# Generated at 2022-06-24 18:17:09.355760
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(list_collection_dirs())

# Generated at 2022-06-24 18:17:10.569406
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert False, 'Unimplemented'

# Generated at 2022-06-24 18:17:19.801843
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:17:21.137094
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    assert test_case_0() == None


# Generated at 2022-06-24 18:17:29.296243
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs(search_paths=['/usr/share/ansible/collections'])
    coll_dirs = list(coll_dirs)

    assert len(coll_dirs) == 2
    assert 'ansible.builtin' in coll_dirs[0]
    assert 'ansible_collections' in coll_dirs[0]
    assert 'ansible_collections' in coll_dirs[1]

# Generated at 2022-06-24 18:17:36.690922
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()

    var_1 = list(var_0)
    expected = [
        "/home/ansible/.ansible/collections",
        "/usr/share/ansible/collections",
        "/usr/share/ansible/collections/ansible_collections/microsoft/azure"
    ]

    assert var_1 == expected

# Generated at 2022-06-24 18:17:38.528002
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()


# Generated at 2022-06-24 18:17:48.561684
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths is not None


# Generated at 2022-06-24 18:17:53.407682
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Asserts
    assert test_case_0() is None, "list_collection_dirs returned bad value"


if __name__ == '__main__':
    test_list_valid_collection_paths()

# Generated at 2022-06-24 18:17:57.097012
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(list_collection_dirs())



# Generated at 2022-06-24 18:17:59.742724
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == set(['/home/adam/.ansible/collections'])


# Generated at 2022-06-24 18:18:10.196798
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import pytest
    from ansible.collections.ansible import ansible_collections

    ansible_collections.load()

    assert ansible_collections.collection_versions['ansible.netcommon'] == '0.1.0'
    assert ansible_collections.collection_versions['ansible.posix'] == '0.1.0'

    test_dir = os.path.join(os.path.dirname(__file__), "test_collections")


# Generated at 2022-06-24 18:18:13.586188
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    args = [{'search_paths': None, 'warn': False}]
    result = list_valid_collection_paths(*args[0]['search_paths'], **args[0]['warn'])
    assert result == ''


# Generated at 2022-06-24 18:18:16.758615
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/Users/david/ansible/collections']
    ret = list_valid_collection_paths(test_paths)
    assert ret is not None
    assert '/Users/david/ansible/collections' in list(ret)


# Generated at 2022-06-24 18:18:18.508278
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == ["/usr/share/ansible/collections", "/etc/ansible/collections"]


# Generated at 2022-06-24 18:18:21.864094
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Make sure the function returns a list
    assert isinstance(list_collection_dirs(), list)


# Generated at 2022-06-24 18:18:24.396354
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(list_collection_dirs())

# Generated at 2022-06-24 18:18:43.920491
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([])



# Generated at 2022-06-24 18:18:48.040186
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("[Testing AnsibleCollectionFinder.list_collection_dirs]")

    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 18:18:50.360352
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    def list_valid_collection_paths(search_paths, warn):
        pass
    assert callable(list_valid_collection_paths)



# Generated at 2022-06-24 18:18:51.373570
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:18:53.522960
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Dummy test to get 100% test coverage
    assert to_bytes(list_valid_collection_paths())

# Generated at 2022-06-24 18:18:58.993666
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=['/some/path/'], warn=True) == list(['/some/path/'])
    assert list_valid_collection_paths(search_paths=['/some/path/'], warn=False) == list(['/some/path/'])



# Generated at 2022-06-24 18:19:02.081383
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(None, None)
    var_1 = list(var_0)
    assert len(var_1) > 0

    for item in var_1:
        print(item)


# Generated at 2022-06-24 18:19:03.398494
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0()



# Generated at 2022-06-24 18:19:09.510573
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.utils.path import unfrackpath

    the_paths = ['.', 'mycollections', 'mycollections/ansible_collections', 'mycollections/ansible_collections/myns']

    results = []
    for path in the_paths:
        path_bs = to_bytes(unfrackpath(path), errors='surrogate_or_strict')
        results.append(path_bs)

    assert sorted(list_collection_dirs(search_paths=the_paths)) == sorted(results)



# Generated at 2022-06-24 18:19:12.962014
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 is None or all(isinstance(element, str) for element in var_1)


# Generated at 2022-06-24 18:19:57.739145
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs()) is not None

# Generated at 2022-06-24 18:20:05.463235
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test the case where the path does not exist
    # but we are not showing warnings
    # check the return value
    assert not list(list_valid_collection_paths([os.path.join('/', 'invalid', 'path')], warn=False))

    # Test the case where the path does not exist
    # but we are showing warnings
    # check the return value
    assert not list(list_valid_collection_paths([os.path.join('/', 'invalid', 'path')], warn=True))

    # Test the case where the path exists
    # is a directory
    # and we are not showing warnings
    # check the return value
    assert list(list_valid_collection_paths(['/'])) == ['/']

    # Test the case where the path exists
    # is a directory
    # and we

# Generated at 2022-06-24 18:20:07.435188
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([])



# Generated at 2022-06-24 18:20:09.572753
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Test Loading List collection dirs")

    test_case_0()



# Generated at 2022-06-24 18:20:14.505300
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Set up mock
    # FIXME: This mock does not test anything
    fixture_0 = [
        'collection',
        'search_paths',
        'coll_filter'
    ]
    fixture_1 = list_collection_dirs()
    fixture_2 = list(fixture_1)
    fixture_3 = list_collection_dirs()
    fixture_4 = list(fixture_3)
    fixture_5 = AnsibleCollectionConfig.collection_paths
    fixture_6 = list_valid_collection_paths()
    fixture_7 = list(fixture_6)
    fixture_8 = AnsibleCollectionConfig.collection_paths
    fixture_9 = list_collection_dirs()
    fixture_10 = list(fixture_9)
    fixture_11 = AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-24 18:20:16.633227
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths()
    assert paths
    assert len(paths) > 0


# Generated at 2022-06-24 18:20:18.992411
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == [], 'This assertion failed because "list_collection_dirs" returned unexpected value'


# Generated at 2022-06-24 18:20:21.570976
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = None
    var_1 = None
    var_2 = None

    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 18:20:29.925490
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/path/to/ansible_collections',
        '/path/to/other_ansible_collections',
    ]

    coll_paths = list_valid_collection_paths(search_paths, True)
    assert list(coll_paths) == [
        './ansible_collections',
        '/path/to/ansible_collections',
        '/path/to/other_ansible_collections'
    ]

    coll_paths = list_valid_collection_paths([], True)
    assert list(coll_paths) == ['./ansible_collections']
    # No warning should be displayed.

    coll_paths = list_valid_collection_paths(['/path/to/fake_ansible_collections'], False)
    assert list

# Generated at 2022-06-24 18:20:31.810412
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs()


# Generated at 2022-06-24 18:21:52.821468
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    current_dir = os.getcwd()
    test_dir = os.path.join(current_dir, "test_dir")
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)
    test_ansible = os.path.join(test_dir, "ansible_collections")
    if not os.path.exists(test_ansible):
        os.mkdir(test_ansible)
    test_ansible_1 = os.path.join(test_ansible, "test_collection_1")
    if not os.path.exists(test_ansible_1):
        os.mkdir(test_ansible_1)
    test_ansible_2 = os.path.join(test_ansible, "ansible_collections")

# Generated at 2022-06-24 18:21:55.784438
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = str()
    list_valid_collection_paths(var_2)


# Generated at 2022-06-24 18:22:04.286313
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Testing function list_collection_dirs")

    # No parameters passing, all defaults
    expected = {'myns': {'mycl': 'some/path'}}
    actual = list_collection_dirs()
    assert expected == actual

    # Search paths with one relative and one absolute path
    search_path = ['../tests/data/collection_loader', './tests/data/collection_loader']
    expected = {'myns': {'mycl': './tests/data/collection_loader/ansible_collections/myns/mycl'}}
    actual = list_collection_dirs(search_path)
    assert expected == actual

    # Filter by namespace
    expected = {'myns': {'mycl': './tests/data/collection_loader/ansible_collections/myns/mycl'}}
   

# Generated at 2022-06-24 18:22:05.658237
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test case 0
    assert list_collection_dirs() == list(list_collection_dirs())

# Generated at 2022-06-24 18:22:06.202203
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass



# Generated at 2022-06-24 18:22:11.034976
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test paths
    paths = ['/some/path', '/another/path']

    # Test params
    search_paths = paths
    warn = False

    # Test results
    expected = paths

    # Test execution
    result = list(list_valid_collection_paths(search_paths, warn))

    # Test for invalid type
    assert isinstance(result, list), "Expected type is 'list' but received: %s" % type(result)

    # Test for empty list
    assert len(result) != 0, "Expected non-empty list but received empty."

    # Test for expected results
    assert result == expected, "Expected list: %s, but received: %s" % (expected, result)



# Generated at 2022-06-24 18:22:13.754308
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Mode 0
    assert list_collection_dirs() == \
        list_collection_dirs()



# Generated at 2022-06-24 18:22:17.550719
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Function used to run the unit test
    def test_func():

        # Initialize
        var = list_collection_dirs()

        # Check if the result is a list
        assert var is not None
        assert isinstance(var, list)
        assert len(var) >= 0

        # Check if all the items are string
        assert all(isinstance(x, str) for x in var)

    # Run the unit test
    test_func()



# Generated at 2022-06-24 18:22:19.971742
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=['foo']) == ['foo']


# Generated at 2022-06-24 18:22:22.266554
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert var_0 is not None

