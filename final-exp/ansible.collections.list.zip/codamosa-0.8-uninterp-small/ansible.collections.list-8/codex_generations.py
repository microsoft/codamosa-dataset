

# Generated at 2022-06-24 18:15:07.139984
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_valid_collection_paths()

    return var_0


# Generated at 2022-06-24 18:15:07.939313
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:15:12.972450
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with invalid collection name
    var_0 = list_collection_dirs(search_paths=None, coll_filter='a.b')
    print(var_0)
    # Test with valid collection name
    var_1 = list_collection_dirs(search_paths=None, coll_filter='awx.awx')
    print(var_1)
    # Test with namespace name
    var_2 = list_collection_dirs(search_paths=None, coll_filter='awx')
    print(var_2)
    # Test with no filter
    var_3 = list_collection_dirs()
    print(var_3)
    # Test with empty filter
    var_4 = list_collection_dirs(search_paths=None, coll_filter=None)

# Generated at 2022-06-24 18:15:17.231273
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/usr/share/ansible']
    warn = True
    expected = '/usr/share/ansible'
    actual = list_valid_collection_paths(search_paths, warn)

    assert actual == expected


# Generated at 2022-06-24 18:15:18.167247
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_case_0()



# Generated at 2022-06-24 18:15:22.000324
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs('/path/to/collections')
    assert var_1
    var_2 = list_collection_dirs('/path/to/collections', 'my_collection')
    assert var_2 == '/path/to/collections/ansible_collections/my_collection/my_collection'

# Generated at 2022-06-24 18:15:28.442972
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    my_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', '..', 'common'))
    def os_path_join(a, b):
        return os.path.join(a, b).replace(my_path, '/my_path', 1)
    display = Display()
    display.display = lambda x: x
    display.deprecated = lambda old, new, version: (old, new, version, False)
    display.verbosity = 4
    ansible_config_file = '/my_path/setup.cfg'
    ansible_directory = '/my_path/'
    ansible_config_file = '/my_path/setup.cfg'
    ansible_config_repo_paths

# Generated at 2022-06-24 18:15:39.572215
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # List of strings to check
    str_res = ['testcol.mytest', 'testcol.mytest:plugins/module_utils', 'testcol.mytest:plugins/modules']
    str_res_filtered = ['testcol.mytest:plugins/module_utils', 'testcol.mytest:plugins/modules']

    # Check a collection filter works
    res0 = list(list_collection_dirs(coll_filter='testcol.mytest'))
    assert len(res0) == 1

    # Check a namespace filter works
    res1 = list(list_collection_dirs(coll_filter='testcol'))
    assert len(res1) == 2

    # Check path list works
    res2 = list(list_collection_dirs(search_paths=['/var/tmp/testcollections']))
   

# Generated at 2022-06-24 18:15:46.133060
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = 'ansible'
    search_paths = ['/home/cbennett/github/ansible/ansible/test/unit/modules/cloud/test_validate_certs']
    result = list_collection_dirs(search_paths, coll_filter)
    assert result is not None

# Generated at 2022-06-24 18:15:47.958586
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass # Nothing to do here


# Generated at 2022-06-24 18:16:13.406072
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert hasattr(list_valid_collection_paths, '__call__')
    var_1 = ['foo.bar', 'foo']
    var_2 = ['foo/my/ansible/collections', 'foo', 'foo/my/ansible/paths']
    var_3 = ['foo/my/ansible/collections']
    var_4 = ['foo/my/ansible/collections']
    var_5 = ['foo/my/ansible/collections']
    var_6 = ['foo/my/ansible/collections', 'foo', 'foo/my/ansible/paths']
    var_7 = ['foo/my/ansible/collections']
    var_8 = ['foo/my/ansible/collections', 'foo', 'foo/my/ansible/paths']
    var_9

# Generated at 2022-06-24 18:16:14.717751
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()

# Generated at 2022-06-24 18:16:20.948120
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Check valid call
    try:
        var_0 = list_collection_dirs()
        var_1 = list(var_0)
    except Exception as exception:
        print(str(exception))
        assert False

    # Check invalid call
    try:
        var_0 = list_collection_dirs(coll_filter=None)
        var_1 = list(var_0)
    except Exception as exception:
        print(str(exception))
        assert False



# Generated at 2022-06-24 18:16:23.403279
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Uncaught exception testing list_collection_dirs: {}".format(e)

# Generated at 2022-06-24 18:16:34.973764
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    b_var_0 = to_bytes('ansible.misc')
    b_path = to_bytes('/Users/ansible/ansible_collections/ansible/misc/')
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert len(var_1) > 0
    var_2 = list_collection_dirs(search_paths=[b_path])
    var_3 = list(var_2)
    for var_4 in var_3:
        assert os.path.basename(var_4) == b_var_0

if __name__ == "__main__":
    test_case_0()
    test_list_valid_collection_paths()

# Generated at 2022-06-24 18:16:35.825774
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass



# Generated at 2022-06-24 18:16:40.599538
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        # Test with new search paths
        res = list_valid_collection_paths(search_paths=['/tmp/foo'])
        assert list(res) == ['/tmp/foo']
    except AssertionError:
        display.error("Test failed")
        raise


# Generated at 2022-06-24 18:16:44.229858
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    default_paths = AnsibleCollectionConfig.collection_paths
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/path/to/collections:/path/to/another/collections'
    modified_path = os.environ['ANSIBLE_COLLECTIONS_PATHS'].split(os.pathsep)
    paths = list(list_valid_collection_paths(modified_path, True))
    assert default_paths == paths


# Generated at 2022-06-24 18:16:50.973934
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list_valid_collection_paths()) is not 0
    assert len(list_valid_collection_paths(['/usr/lib'])) is not 0
    assert len(list_valid_collection_paths(['/usr/lib/ansible/ansible_collections'])) is not 0
    assert len(list_valid_collection_paths(['/usr/lib/ansible/ansible_collections', '/etc/'])) is not 0
    assert len(list_valid_collection_paths(['/usr/lib/ansible/ansible_collections', '/etc/'])) is not 0
    assert len(list_valid_collection_paths(['/usr/lib/ansible/ansible_collections', '/etc/', '/usr/local/ansible/'])) is not 0



# Generated at 2022-06-24 18:16:53.130709
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = None
    warn = False
    res = list_valid_collection_paths(path, warn)
    assert res is not None


# Generated at 2022-06-24 18:17:03.991344
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = []
    var_1 = None
    var_2 = test_case_0()



# Generated at 2022-06-24 18:17:05.070064
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:17:08.653848
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Tests for function list_valid_collection_paths

    """
    search_paths = []
    coll_filter = None
    var_0 = list_valid_collection_paths(search_paths, warn)
    var_1 = list(var_0)



# Generated at 2022-06-24 18:17:09.509611
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:17:14.278781
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    mock_paths = [
        os.path.realpath('/abc'),
        os.path.realpath('/def')
    ]

    assert list(list_valid_collection_paths(search_paths=mock_paths, warn=True)) == list_valid_collection_paths()


# Generated at 2022-06-24 18:17:20.687040
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    input_0 = None
    input_1 = True

    # Test_0 - No defaults
    vars = locals()
    output = list(list_valid_collection_paths())
    assert output == []

    # Test_1 - All defaults
    vars = locals()
    output = list(list_valid_collection_paths())
    assert len(output) == 3

    # Test_3 - search_paths as a list
    vars = locals()
    output = list(list_valid_collection_paths(search_paths=['/etc/ansible/collections', '/usr/share/mycollections']))
    assert len(output) == 5


# Generated at 2022-06-24 18:17:28.882854
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    desc1 = "Empty search path for list_collection_dirs"
    search_paths1 = []
    exp1 = []
    act1 = list(list_collection_dirs(search_paths1))
    assert act1 == exp1, desc1
    desc2 = "Default search path"
    search_paths2 = None
    exp2 = []
    act2 = list(list_collection_dirs(search_paths2))
    assert act2 == exp2, desc2



# Generated at 2022-06-24 18:17:30.487484
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for var_0 in list_valid_collection_paths():
        assert var_0



# Generated at 2022-06-24 18:17:43.831792
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Testing with tests/data/test.txt
    var_0 = list_collection_dirs([u"tests/data/test.txt"])
    var_1 = list(var_0)
    assert var_1 == [u"tests/data/test/ansible_collections/test/collection"]

    # Testing with tests/data/test1.txt
    var_0 = list_collection_dirs([u"tests/data/test1.txt"])
    var_1 = list(var_0)
    assert var_1 == [u"tests/data/test/ansible_collections/test/collection"]

    # Testing with tests/data/test2.txt
    var_0 = list_collection_dirs([u"tests/data/test2.txt"])
    var_1 = list(var_0)

# Generated at 2022-06-24 18:17:46.709186
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert ['/tmp/collections_test/test_collections'] == list(list_valid_collection_paths(['/tmp/collections_test/test_collections']))


# Generated at 2022-06-24 18:18:13.510031
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths([]) is not None


# Generated at 2022-06-24 18:18:14.665099
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) != None


# Generated at 2022-06-24 18:18:16.251154
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == list(list_valid_collection_paths())


# Generated at 2022-06-24 18:18:17.683618
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # this function cannot be unit tested because it accesses the file system

    pass


# Generated at 2022-06-24 18:18:19.452826
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(list_valid_collection_paths(['/tmp/test', ]))
    print(list_valid_collection_paths())



# Generated at 2022-06-24 18:18:21.961729
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()



# Generated at 2022-06-24 18:18:33.023281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    os.environ['TEST_VAR_0'] = 'foo'
    os.environ['TEST_VAR_1'] = 'foo'
    os.environ['TEST_VAR_2'] = 'foo'
    os.environ['TEST_VAR_3'] = 'foo'
    os.environ['TEST_VAR_4'] = 'foo'
    os.environ['TEST_VAR_5'] = 'foo'
    # Test of the command without arguments
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    os.environ['TEST_VAR_0'] = 'foo'
    os.environ['TEST_VAR_1'] = 'foo'

# Generated at 2022-06-24 18:18:39.032664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    from ansible.playbook.play_context import PlayContext
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch

    mock_play_context = PlayContext()

    with patch('ansible_collections.ansible.misc.plugins.module_utils.list_collection_dirs.get_config_value', return_value='/dev/null'):
        with patch('ansible_collections.ansible.misc.plugins.module_utils.list_collection_dirs.display.warning'):
            var_0 = list_collection_dirs()
            var_1 = list(var_0)



# Generated at 2022-06-24 18:18:41.318828
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True == list_valid_collection_paths()


# Generated at 2022-06-24 18:18:48.951189
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = list_valid_collection_paths()
    paths.sort()
    assert paths == [b'/usr/share/ansible/collections'] or paths == [b'C:\\Program Files\\Ansible\\collections'], "Expected list_valid_collection_paths to return '/usr/share/ansible/collections' or 'C:\\Program Files\\Ansible\\collections', got %s" % paths


# Generated at 2022-06-24 18:19:29.972384
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert len(var_1) > 0

    var_2 = list_collection_dirs(coll_filter='z')
    var_3 = list(var_2)
    assert len(var_3) == 0

    var_4 = list_collection_dirs(coll_filter='z.b')
    var_5 = list(var_4)
    assert len(var_5) == 0

    var_6 = list_collection_dirs(coll_filter='ansible')
    var_7 = list(var_6)
    assert len(var_7) == 0

    var_8 = list_collection_dirs(coll_filter='ansible.z')
    var_9 = list(var_8)


# Generated at 2022-06-24 18:19:34.018996
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Try collection filter
    # This will raise an error if fixtures are not installed
    try:
        case_0 = list_collection_dirs(coll_filter="ansible_collections.ns.coll")
        case_1 = iter(case_0)
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-24 18:19:38.547373
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list_valid_collection_paths(search_paths=[''])) == 1
    assert len(list_valid_collection_paths(search_paths=['./'])) == 1



# Generated at 2022-06-24 18:19:44.816789
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_path = '/tmp/test_list_valid_collection_paths'
    os.makedirs(test_path)
    assert test_path in list_valid_collection_paths([test_path])



# Generated at 2022-06-24 18:19:47.038633
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_2 = list_valid_collection_paths()
    var_3 = list(var_2)


# Generated at 2022-06-24 18:19:52.066953
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1 == []
    assert type(var_1) == type([])
    assert list(_) == []
    assert type(list(_)) == type([])
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1 == []
    assert type(var_1) == type([])
    assert list(_) == []
    assert type(list(_)) == type([])

# Generated at 2022-06-24 18:19:57.821448
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [os.getcwd(), '~/ansible_collections', '/path/to/something/that/does/not/exist']

    results = list_valid_collection_paths(search_paths=test_paths, warn=True)

    assert len(list(results)) == 3



# Generated at 2022-06-24 18:20:05.518898
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Make sure we're testing against the right thing.
    assert list_valid_collection_paths
    # It takes a list of paths, and returns a subset.
    assert list_valid_collection_paths(search_paths=['path_1', 'path_2'])
    # That subset is a generator.
    assert list_valid_collection_paths(search_paths=['path_1', 'path_2'])
    assert next(list_valid_collection_paths(search_paths=['path_1', 'path_2']))
    # We need at least one item in the list.
    assert not list_valid_collection_paths(search_paths=[])
    # If we don't pass a list, it loads the default config.
    assert list_valid_collection_paths()
    # The default

# Generated at 2022-06-24 18:20:07.487670
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Call function
    list_valid_collection_paths()

# Generated at 2022-06-24 18:20:10.329425
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception as e:
        print("Failed in unit test. Error: %s" % e)

# Generated at 2022-06-24 18:21:24.018981
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = 3
    
    actual = list(list_valid_collection_paths())
    assert 2 <= len(actual) <= 3
    assert actual == expected

# Generated at 2022-06-24 18:21:34.097882
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Testing function list_valid_collection_paths...")

    # Simulate a config with an existing collection path and one that does not
    search_paths = [u'/my/valid/collection/path', u'/my/fake/collection/path']

    expected_result = [u'/my/valid/collection/path']
    result = list(list_valid_collection_paths(search_paths=search_paths))

    assert result == expected_result

    # User root for collections, should not warn
    search_paths = [u'/']
    result = list(list_valid_collection_paths(search_paths=search_paths))
    assert result == search_paths

    # User root for collections, should not warn
    search_paths = [u'/']

# Generated at 2022-06-24 18:21:42.251081
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils import basic

    if not basic.HAS_ANSIBLE_COLLECTIONS:
        assert False, "No Ansible collections library found, this is required for the unit tests"

    m = basic.AnsibleModule(
        argument_spec=dict(
            search_paths=dict(type='list'),
            warn=dict(type='bool'),
        ),
        supports_check_mode=False
    )
    result = list_valid_collection_paths(m, m.params['search_paths'], m.params['warn'])

    # exit_json(changed=False
    m.exit_json(**result)


# Generated at 2022-06-24 18:21:44.026194
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()



# Generated at 2022-06-24 18:21:45.709916
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:21:51.242929
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 1 == len(list(list_collection_dirs()))
    assert 0 == len(list(list_collection_dirs(search_paths=[])))
    assert 1 == len(list(list_collection_dirs(search_paths=['/tmp'])))
    assert 1 == len(list(list_collection_dirs(search_paths=['./test/integration/sanity/test_collections_fixture/test_case_0'])))



# Generated at 2022-06-24 18:21:53.559435
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    assert var_1 is not False
    assert var_1 is not True
    assert var_1 is None


# Generated at 2022-06-24 18:21:57.963201
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = os.path.expanduser('~/.ansible/collections')
    var_1 = list_valid_collection_paths([path])
    var_2 = list(var_1)
    assert var_2 == [path]



# Generated at 2022-06-24 18:22:07.202032
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        subdirs = os.listdir(to_bytes(os.path.dirname(os.path.dirname(__file__)), errors='surrogate_or_strict'))
    except OSError:
        return

    if b'lib' in subdirs:
        libdir = os.path.join(to_bytes(os.path.dirname(os.path.dirname(__file__)), errors='surrogate_or_strict'), b'lib')
        libsubdirs = os.listdir(libdir)

        if libsubdirs:
            test_case_0()
    else:
        test_case_0()

# Generated at 2022-06-24 18:22:10.270258
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=['/tmp'], warn=False) == ['/tmp']
    assert list_valid_collection_paths(search_paths=['/tmp/not_exist'], warn=False) == []
    assert list_valid_collection_paths(search_paths=['/tmp/not_exist'], warn=True) == []
