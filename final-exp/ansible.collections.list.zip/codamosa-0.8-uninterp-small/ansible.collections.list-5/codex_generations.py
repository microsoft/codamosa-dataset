

# Generated at 2022-06-24 18:15:05.567677
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Example unit test
    assert 1 == 1



# Generated at 2022-06-24 18:15:06.451286
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()


# Generated at 2022-06-24 18:15:15.545025
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['tests/unit/test_scripts/test_collections']
    coll_filter = None
    assert list(list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter)) == [b'ansible_collections/test/test_collection']
    search_paths = ['tests/unit/test_scripts/test_collections', 'tests/unit/test_scripts/test_collections_1']
    coll_filter = 'test.test_collection'
    assert list(list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter)) == [b'ansible_collections/test/test_collection']

# Generated at 2022-06-24 18:15:21.348770
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    arg_0 = ['/home/ansible/ansible_collections']
    arg_1 = False
    expected_0 = "/home/ansible/ansible_collections"
    expected_1 = False
    actual_0, actual_1 = list_valid_collection_paths(arg_0, arg_1)
    assert expected_0 == actual_0, "expected is not equal to actual"
    assert expected_1 == actual_1, "expected is not equal to actual"


# Generated at 2022-06-24 18:15:26.703212
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with default search_paths
    assert list(list_valid_collection_paths())

    valid_paths = ['/usr/share']
    # Test with valid search_paths list
    assert list(list_valid_collection_paths(search_paths=valid_paths)) == valid_paths

    invalid_path = ['/tmp/does_not_exists/']
    # Test with invalid search_paths list
    assert list(list_valid_collection_paths(search_paths=invalid_path)) == []



# Generated at 2022-06-24 18:15:38.589326
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_0 = '.'
    val_0 = list_collection_dirs(coll_filter=coll_0)

# Generated at 2022-06-24 18:15:47.576591
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # initialize the display
    display.verbosity = 1
    display.columns = 80 

    # get the collection dirs
    var_0 = list_collection_dirs()

    # check the contents of the list
    assert var_0 == [], "expected ['ansible_collections/fortinet/fortios', 'ansible_collections/ansible/os_server', 'ansible_collections/fortinet/fortios', 'ansible_collections/ansible/os_server'], got [%s]" % var_0


# Generated at 2022-06-24 18:15:55.999127
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    collection_dirs = None
    search_paths = None
    coll_filter = None

    print('Testing CollectionPathFinder.list_collection_dirs(collection_dirs=%s, search_paths=%s, coll_filter=%s)' % (collection_dirs, search_paths, coll_filter))
    for collection_dir in list_collection_dirs(collection_dirs=collection_dirs, search_paths=search_paths, coll_filter=coll_filter):
        print('Collection Dir: %s' % collection_dir)

    print('Collection Dirs: %s' % list_collection_dirs(collection_dirs=collection_dirs, search_paths=search_paths, coll_filter=coll_filter))


# Generated at 2022-06-24 18:16:02.105055
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with mock.patch.object(Display, 'warning') as m_warn, mock.patch.object(os.path, 'exists') as m_ex, \
            mock.patch.object(os, 'listdir') as m_ld, mock.patch.object(os.path, 'isdir') as m_isd, \
            mock.patch.object(os.path, 'join') as m_join:

        m_ex.side_effect = [False, True, True, True]
        m_isd.return_value = True
        m_ld.return_value = ['test1.namespace', 'test2.namespace']


# Generated at 2022-06-24 18:16:12.012718
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for a given list of collection paths
    # get all the valid paths by list_valid_collection_paths
    # validate if it matches the expeted output
    list_of_valid_paths = [
        './lib/ansible/collections/ansible_collections/foo/bar',
        './lib/ansible/collections/foo/bar',
        './lib/ansible/collections/foo'
    ]


# Generated at 2022-06-24 18:16:20.995510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths(search_paths=['./tests/unit/collection/collection_plugins/ansible_collections'], warn=True) is not None


# Generated at 2022-06-24 18:16:21.952251
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:16:29.666713
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test if str input is valid
    str_0 = '/home/hieu/collection/'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    # Test if list input is valid
    list_0 = ['/home/hieu/collection', '/home/hieu/test/test']
    var_2 = list_valid_collection_paths(list_0)
    var_3 = list(var_2)
    # Test if input is None
    var_4 = list_valid_collection_paths()
    var_5 = list(var_4)



# Generated at 2022-06-24 18:16:32.395230
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs('test.tes_collecton', 'test.tes_collecton') == ['test.tes_collecton']



# Generated at 2022-06-24 18:16:35.475873
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.tes_collecton'
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    print(var_1)

# Generated at 2022-06-24 18:16:35.970560
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:16:40.229546
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'test.tes_collecton'
    str_1 = 'test.tes_collecton.tes_collecton'
    var_0 = list_valid_collection_paths(str_0, str_1)
    var_1 = list(var_0)
    for var_2 in var_1:
        print("1st arg:", str_0, "2nd arg:", str_1, "returned:", var_2)



# Generated at 2022-06-24 18:16:45.555983
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return
    assert list_valid_collection_paths() == list_valid_collection_paths.default_return


# Generated at 2022-06-24 18:16:48.035111
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    text = ''
    with open('/tmp/ansible_module_utils_collection_loader_test.txt', 'r') as file:
        for line in file.readlines():
            text = text + line
    try:
        assert text == ''
    except AssertionError:
        print("Expected: '{}' != Actual: '{}'".format("", text))
        raise


# Generated at 2022-06-24 18:16:59.396439
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # str_0 is a simple collection with only basic plugin

    str_0 = 'test.tes_collecton'

    # var_0 is a generator object, to be converted to list for 
    # testing the test.tes_collecton with test_case_0
    var_0 = list_collection_dirs(str_0, str_0)
    
    # var_1 is list object containing the generator object
    var_1 = list(var_0)

    # var_2 is expected output of list_collection_dirs function 
    # with test.tes_collecton name collection
    var_2 = [b'/home/ubuntu/ansible_collections/test/tes_collecton']

    # Testing if the expected value of list_collection_dirs function 
    # is equal to its output
    assert var_1 == var

# Generated at 2022-06-24 18:17:13.054294
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = 'ansible_collections/ansible/test'
    paths = [path]
    collection_paths = list(list_valid_collection_paths(paths))
    assert collection_paths == paths
    collection_paths = list(list_valid_collection_paths(paths, True))
    assert collection_paths == paths


# Generated at 2022-06-24 18:17:14.779658
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs('test.tes_collecton', 'test.tes_collecton') is not None


# Generated at 2022-06-24 18:17:18.358797
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.test'
    path = '/home/user/ansible/test/test'

    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    assert var_1[0] == path


# Generated at 2022-06-24 18:17:29.025236
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:17:35.983413
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test_0
    str_0 = '/home/marius/Projects/ansible/test/sanity/collection_tests/list_valid_collection_paths/test_0/test_0.ansible_collections/test_0.tes_collecton'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    test_0 = '/home/marius/Projects/ansible/test/sanity/collection_tests/list_valid_collection_paths/test_0/test_0.ansible_collections'
    assert test_0 in var_1

    # test_1

# Generated at 2022-06-24 18:17:46.182653
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Testing if the function returns the correct value of type list
    assert type(list_valid_collection_paths()) is list

    # Testing if the function returns the correct value
    assert list_valid_collection_paths() == ['', 'ansible_collections']

    # Testing if the function raises the appropriate error on invalid data type
    try:
        list_valid_collection_paths(None)
    except TypeError:
        assert True
    else:
        assert False

    # Testing if the function returns the correct value of type list
    assert type(list_valid_collection_paths(None, True)) is list

    # Testing if the function returns the correct value of type str
    assert type(list_valid_collection_paths(None, True)[0]) is str

    # Testing if the function returns the correct value
    assert list_valid

# Generated at 2022-06-24 18:17:51.102849
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception:
        import traceback
        exception = traceback.format_exc()


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:17:54.337937
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(list_valid_collection_paths(["/test/test"]))


# Generated at 2022-06-24 18:18:00.387357
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections import ansible_collections_defaults
    from ansible.collections import collection_loader
    import shutil
    import tempfile
    import os

    tmpdir = tempfile.mkdtemp()
    tmpcoll_dir = os.path.join(tmpdir, 'test.test_collection')
    os.makedirs(tmpcoll_dir)
    ansible_collections_defaults.__bases__ = (object,)


# Generated at 2022-06-24 18:18:09.542119
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:18:21.355145
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'test.tes_collecton'
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)
    var_2 = list_valid_collection_paths(str_0, )
    var_3 = list(var_2)



# Generated at 2022-06-24 18:18:30.927031
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_str = to_bytes
    assert list_collection_dirs(['/test/ansible_collections'], 'test.test_collection') == [b_str('/test/ansible_collections/test/test_collection')]
    assert list_collection_dirs(['/test/ansible_collections'], 'test_collection') == [b_str('/test/ansible_collections/test_collection')]
    assert list_collection_dirs() == [b_str('/test/ansible_collections')]


# Generated at 2022-06-24 18:18:38.653885
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:18:45.869920
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_path = list_collection_dirs()
    b_path_0 = next(b_path)

    b_path_1 = list_collection_dirs(search_paths=b_path_0)
    b_path_2 = list(b_path_1)
    b_path_3 = b_path_2[0]



# Generated at 2022-06-24 18:18:51.710528
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.tes_collecton'
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)

    # Check if var_0 is an iterator
    assert isinstance(var_0, type(iter([])))
    # Check for function list_collection_dirs return type
    assert type(list_collection_dirs()) is list

# Generated at 2022-06-24 18:18:54.406284
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # print(list_collection_dirs())
    # print(os.getcwd())
    for i in list_collection_dirs():
        print(i)


# Generated at 2022-06-24 18:19:00.920797
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Unit test for function list_valid_collection_paths
    """
    # Path does not exist
    str_0 = 'this/does/not/exist'
    var_0 = list_valid_collection_paths(str_0, True)
    # Path is a file
    str_2 = 'filename.txt'
    var_2 = list_valid_collection_paths(str_2, True)




# Generated at 2022-06-24 18:19:08.588564
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = list_collection_dirs(None, None)
    var_3 = list(var_2)
    var_4 = list_collection_dirs(None, 'test')
    var_5 = list(var_4)
    var_6 = list_collection_dirs(None, 'test.tes_collecton')
    var_7 = list(var_6)
    var_8 = list_collection_dirs('/path/to/collection', 'test.tes_collecton')
    var_9 = list(var_8)



# Generated at 2022-06-24 18:19:10.137228
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:19:13.469258
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.tes_collecton'
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    print(var_1)



# Generated at 2022-06-24 18:19:31.901460
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # FIXME
    pass


# Generated at 2022-06-24 18:19:32.728552
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()



# Generated at 2022-06-24 18:19:35.897919
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'test.test_collection'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    assert var_1 == str_0


# Generated at 2022-06-24 18:19:42.519714
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'test.tes_collecton'
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)


# this test case is based on a similar test case in ansible-test
if __name__ == "__main__":
    test_list_valid_collection_paths()

# Generated at 2022-06-24 18:19:43.236297
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:19:46.011496
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []

    expected = ['.']

    result = list_valid_collection_paths(search_paths)
    assert result == expected



# Generated at 2022-06-24 18:19:51.837305
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_dir = 'testdir'
    collection_dir = 'ansible_collections'
    valid_path = os.path.join(test_dir, collection_dir)
    invalid_path = os.path.join(test_dir, 'invalid_collections')
    test_paths = [valid_path, invalid_path]
    collection_paths = list_valid_collection_paths(test_paths, warn=False)
    assert list(collection_paths) == [valid_path]

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:19:54.796176
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Check if the function raises the expected exception
    # when the first parameter 'search_paths' is not valid.
    pass


# Generated at 2022-06-24 18:20:01.776830
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [1, 2, 3]
    warn = True
    var_0 = list_valid_collection_paths(search_paths, warn)
    var = list(var_0)
    assert var[0] == 1
    assert var[1] == 2
    assert var[2] == 3



# Generated at 2022-06-24 18:20:08.921927
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test with no collection
    path = '~/ansible/ansible'
    collection = None
    assert list_collection_dirs(path, collection) == list_collection_dirs(path, collection)

    # Test with collection
    path = '~/ansible/ansible/'
    collection = 'test.test_collection'
    assert list_collection_dirs(path, collection) == list_collection_dirs(path, collection)

# Generated at 2022-06-24 18:20:47.762407
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'ansible_collections'
    str_1 = 'test'
    str_2 = 'test.tes_collecton'
    str_3 = 'test.tes_collecton[ansible.builtin]'
    str_4 = 'test.tes_collecton[ansible.builtin].foo'
    str_5 = 'test.tes_collecton[ansible.builtin].foo[test_plugins.test_module]'
    str_6 = 'test.tes_collecton[ansible.builtin].foo[test_plugins.test_module][test_plugins.test_module]'
    str_7 = 'test.tes_collecton[ansible.builtin].foo[test_plugins.test_module][test_plugins.test_module][test_plugins]'

# Generated at 2022-06-24 18:20:50.298059
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test_collection'
    assert list_collection_dirs(str_0, str_0) == list(list_collection_dirs(str_0, str_0))

# Generated at 2022-06-24 18:20:54.993222
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '/usr/share/ansible/collec_tions'
    var_0 = list_valid_collection_paths('/etc/ansible/collections')
    var_1 = list(var_0)
    var_2 = list(var_1)

    assert var_1 == var_2


# Generated at 2022-06-24 18:21:05.952534
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test 1
    str_0 = '/var/lib/awx/venv/awx/share/ansible/collections/ansible_collections'
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)
    assert var_1 == ['/var/lib/awx/venv/awx/share/ansible/collections/ansible_collections']
    # Test 2
    str_1 = '/var/lib/awx/venv/awx/share/ansible/collections/ansible_collections'
    str_2 = '/var/lib/awx/venv/awx/share/ansible/plugins/modules'

# Generated at 2022-06-24 18:21:12.701303
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test #0 - success
    try:
        # Call the method
        ret = list_valid_collection_paths('test')

        # Assertion - lists are equal
        assert list(ret) == ['test']

    except Exception as e:
        print('Test #0 failed: ' + str(e))

    # Test #1 - success
    try:
        # Call the method
        ret = list_valid_collection_paths()

        # Assertion - lists are equal
        assert list(ret) == list(AnsibleCollectionConfig.collection_paths)

    except Exception as e:
        print('Test #1 failed: ' + str(e))


# Generated at 2022-06-24 18:21:19.922328
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:21:29.728487
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    str_1 = 'test_collection'
    expected_0 = ['/usr/local/lib/python3.5/dist-packages/ansible/collections/ansible_collections/test_namespace/test_collection']

    # test None collection
    # test None namespace
    # test str_0 collection
    # test str_1 collection
    # test list_collection_dirs(str_0, str_0)
    # test list_collection_dirs(str_1, str_1)
    # test list_collection_dirs(str_0, str_1)
    # test list_collection_dirs(str_1, str_0)
    # test list_collection_dirs(str_0, str_0)
    # test list_collection_dirs(str_1, str_1)
    #

# Generated at 2022-06-24 18:21:39.720435
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.tes_collecton'
    var_0 = list_collection_dirs(str_0, str_0)[0]
    with open(var_0 + '/.ansible_collection_config.json') as f_0:
        s_0 = f_0.readline()
        var_1 = s_0 == '{\n'
    with open(var_0 + '/plugins/modules/tes_collecton_facter.py') as f_1:
        s_1 = f_1.readline()
        var_1 = var_1 and (s_1 == '#!/usr/bin/python\n')
    assert var_1



# Generated at 2022-06-24 18:21:41.454764
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()



# Generated at 2022-06-24 18:21:46.738369
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(
        search_paths=['/test', '/test/ansible_collection'],
    )
    assert module_args['search_paths'] == ['/test', '/test/ansible_collection']



# Generated at 2022-06-24 18:23:04.360656
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(None, None)
    var_1 = list(var_0)


# Generated at 2022-06-24 18:23:10.201681
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test.tes_collecton'
    var_1 = list_collection_dirs(str_0, 'test.tes_collecton')
    var_2 = list(var_1)
    var_3 = list_collection_dirs(str_0, str_0)
    var_4 = list(var_3)
    var_5 = list_collection_dirs(str_0, str_0)
    var_6 = list(var_5)
    assert var_2 == var_4 == var_6

# Generated at 2022-06-24 18:23:16.607119
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'test_collection'
    var_0 = list_collection_dirs(None, str_0)
    var_1 = list(var_0)
    var_2 = None

    if None in var_1:
        # Remove from array
        var_1.remove(None)
    var_3 = str_0

    if var_3 in var_1:
        test_case_0()
        var_2 = 'Success'
    else:
        var_2 = 'Fail'
    print(var_2)

# Generated at 2022-06-24 18:23:22.472650
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_list_valid_collection_paths.__name__ == 'test_list_valid_collection_paths'
    test_case_0()


# Generated at 2022-06-24 18:23:27.799671
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'ansible.test_colletion'
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    # print(var_1)
    var_2 = len(var_1)
    try:
        assert var_2 == 1
    except AssertionError:
        print("len: ", var_2)
        raise

# Generated at 2022-06-24 18:23:29.455274
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 1 == 1, 'test list_collection_dirs'

# Unit  test for function list_valid_collection_paths

# Generated at 2022-06-24 18:23:33.459564
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.display('Running tests list_valid_collection_paths...')
    assert to_bytes(list_valid_collection_paths())
    assert to_bytes(list_valid_collection_paths('test'))
    assert to_bytes(list_valid_collection_paths('test', 'test'))
    assert to_bytes(list_valid_collection_paths(['test']))
    assert to_bytes(list_valid_collection_paths(['test'], 'test'))
    assert to_bytes(list_valid_collection_paths(['test'], 'test'))
    assert to_bytes(list_valid_collection_paths(warn=True))
    assert to_bytes(list_valid_collection_paths(warn=True))



# Generated at 2022-06-24 18:23:41.063902
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '/usr/share/ansible_collections'
    str_1 = '/etc/ansible/ansible.cfg'
    str_2 = '/usr/share/ansible_collections:/etc/ansible/ansible.cfg'
    str_3 = 'not-a-dir'
    str_4 = 'nonexistdir'
    str_5 = '/etc/ansible'
    str_6 = '/etc/ansible/ansible.cfg:/usr/share/ansible_collections'

    var_0 = list_valid_collection_paths(str_0, False)
    var_1 = list(var_0)
    assert var_1 == [str_0]

    var_0 = list_valid_collection_paths(str_1, False)

# Generated at 2022-06-24 18:23:51.228233
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:23:53.860089
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        assert list_collection_dirs('test_str') == None
    except AssertionError as e:
        print(e)
        raise AssertionError()
