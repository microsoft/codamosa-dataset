

# Generated at 2022-06-24 18:15:13.835455
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Unit test for list_collection_dirs
    """

    coll_path = '/tmp/ansible_collections'
    search_paths = [coll_path]

    # 1. test with a search_path that is not the default path
    assert list(list_collection_dirs(search_paths=search_paths)) == []

    nspace_dir = os.path.join(coll_path, 'test_namespace')
    os.makedirs(nspace_dir)

    coll_dir = os.path.join(nspace_dir, 'test_collection')
    with open(os.path.join(coll_dir, 'MANIFEST.json'), 'w') as f:
        f.write('{}')

# Generated at 2022-06-24 18:15:15.111258
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
        var_0 = list_valid_collection_paths()


# Generated at 2022-06-24 18:15:17.494338
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    assert len(var_1) != 0


test_case_0()
test_list_collection_dirs()

# Generated at 2022-06-24 18:15:24.966851
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    def test_func(search_paths=None, coll_filter=None):
        from ansible.module_utils.collection_loader.list_collection_dirs import \
            list_collection_dirs

        return list_collection_dirs(search_paths=search_paths, coll_filter=coll_filter)

    target_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

    # Test with required parameters
    assert test_func([target_path]) is not None

    # Test with all (optional) parameters
    assert test_func(search_paths=[target_path], coll_filter="testcoll.common") is not None

# Generated at 2022-06-24 18:15:28.779600
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = test_case_0()
    var_2 = list_collection_dirs(var_1)
    for var_3 in var_2:
        result_1 = var_3[0]
        result_2 = var_3[1]
        result_3 = var_3[2]
        assert type(result_1) == str
        assert type(result_2) == str
        assert type(result_3) == str

# Generated at 2022-06-24 18:15:32.540782
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for d in list_collection_dirs(['/etc', '~']):
        print(d)

test_case_0()
test_list_collection_dirs()

# Generated at 2022-06-24 18:15:34.750552
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Display Every Var (Do not remove!)
    var_0 = list_valid_collection_paths()
    assert var_0 == []



# Generated at 2022-06-24 18:15:38.414087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Adding tests for list_valid_collection_paths
    var_0 = list_valid_collection_paths()
    print(var_0)


# Generated at 2022-06-24 18:15:48.993788
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    var_0 = list_valid_collection_paths(search_paths=search_paths)
    search_paths = []
    var_1 = list_valid_collection_paths(search_paths=search_paths)
    search_paths = []
    var_2 = list_valid_collection_paths(search_paths=search_paths)
    search_paths = []
    var_3 = list_valid_collection_paths(search_paths=search_paths)
    search_paths = []
    var_4 = list_valid_collection_paths(search_paths=search_paths)
    search_paths = []
    var_5 = list_valid_collection_paths(search_paths=search_paths)
   

# Generated at 2022-06-24 18:15:57.508224
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    import os

    b_plugins = os.environ.get('ANSIBLE_LOAD_CALLBACK_PLUGINS', '')
    b_roles = os.environ.get('ANSIBLE_ROLES_PATH', '')

    b_paths = []
    if b_plugins:
        b_paths.extend(b_plugins.split(os.pathsep))
    if b_roles:
        b_paths.extend(b_roles.split(os.pathsep))

    f_paths = []
    for b_path in b_paths:
        f_path = b_path.decode()
        if os.path.exists(f_path) and os.path.isdir(f_path):
            f_paths.append(f_path)

# Generated at 2022-06-24 18:16:08.083874
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # FIXME: mock
    assert True


# Generated at 2022-06-24 18:16:10.497031
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert isinstance(var_0, type(lambda: 1))



# Generated at 2022-06-24 18:16:12.334131
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == test_case_0()

test_case_0()



# Generated at 2022-06-24 18:16:15.849657
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    valid_path = False
    for path in list_valid_collection_paths():
        if os.path.exists(path):
            valid_path = True
            break
    assert valid_path is True



# Generated at 2022-06-24 18:16:17.602052
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    var_0 = list_collection_dirs(None, 'test')
    assert var_0 != None


# Generated at 2022-06-24 18:16:19.437447
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 is not None


# Generated at 2022-06-24 18:16:23.606190
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Mock search_paths
    search_paths = None

    # Mock warn
    warn = None

    # Call function with defined arguments
    rv = list_valid_collection_paths(search_paths, warn)

    for item in rv:
        print(item)



# Generated at 2022-06-24 18:16:29.908374
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for x in list_collection_dirs(search_paths=[], coll_filter=None):
        #print(str(x))
        assert str(x) == '/home/ansible/ansible_collections/ansible/test_collection'

test_case_0()
test_list_collection_dirs()

# Generated at 2022-06-24 18:16:35.256270
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # args = [{'search_paths': 'None:list'}]
    # for x in args:
    #     list_collection_dirs(**x)
    var_0 = list_collection_dirs()
    var_1 = list_collection_dirs(coll_filter='namespace.name')
    var_2 = list_collection_dirs(coll_filter='namespace')

# Generated at 2022-06-24 18:16:42.157020
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:16:52.813569
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Call list_valid_collection_paths without any mandatory parameter
    assert list_valid_collection_paths() is not None

    # Call list_valid_collection_paths with a parameter
    assert list_valid_collection_paths(['path']) is not None


# Generated at 2022-06-24 18:16:54.178890
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass



# Generated at 2022-06-24 18:17:05.282590
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args

    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    search_paths = []
    collections = list_valid_collection_paths(search_paths)
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    # Test: Test: Empty args
    #

# Generated at 2022-06-24 18:17:12.245010
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-24 18:17:14.912481
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = 'collection_path'
    warn = False
    result = list_valid_collection_paths(path, warn)
    assert isinstance(result, object)

# Generated at 2022-06-24 18:17:19.002266
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    str_1 = 'qoGN73Q[$CBrT01&'
    test_case_0()



# Generated at 2022-06-24 18:17:21.150951
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # (var_0, var_1, str_0) = test_case_0()
    # print('list_collection_dirs', var_1)
    # assert var_1 == ['qoGN73Q[$CBrT01&']
    pass



# Generated at 2022-06-24 18:17:29.700340
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    f_0 = 'QJtKb#8xBZq3o0^V'
    f_1 = 'v78D0.K1JX~^?o<I'
    f_2 = 'jA5Pf@)+(5y{O$[6'
    f_3 = "j=2}>h?^Bc'b]#gj"
    list_collection_dirs(f_0, f_1)
    str_0 = 'No collections found in any configured path.'
    error_0 = AnsibleError(str_0)
    list_collection_dirs(f_0, f_2)
    str_1 = 'No collections found in any configured path.'
    error_1 = AnsibleError(str_1)

# Generated at 2022-06-24 18:17:34.749077
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print('Unit test for function list_collection_dirs')
    # print(list_collection_dirs('/home/craig/projects/ansible-base/test/units/lib/ansible/collections/ansible_collections/test/plugins/test_ns/test_col', 'test_ns.test_col'))
    print(list_collection_dirs('/home/craig/projects/ansible-base/test/units/lib/ansible/collections/ansible_collections/test/plugins', 'test_ns'))



# Generated at 2022-06-24 18:17:45.732649
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Display message
    display.display('\n    Unit test fo list_valid_collection_paths\n  ')

    # Check if it can display warning when path is invalid
    display.display('\n    Check if it can display warning when path is invalid\n  ')
    try:
        search_paths = ['abc']
        list_valid_collection_paths(search_paths)
        display.display('\n    FAILED \n')
    except ValueError:
        display.display('\n    PASSED \n')

    # Check if it can display warning when path is invalid
    display.display('\n    Check if it can display warning when path is invalid\n  ')

# Generated at 2022-06-24 18:17:58.543591
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test case 0
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    str_1 = 'qoGN73Q[$CBrT01&'
    assert var_1 == str_1

# Generated at 2022-06-24 18:17:59.933404
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass # print(list_collection_dirs(str,str))



# Generated at 2022-06-24 18:18:03.342136
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'J#@5+%7&z5BL]b:7Jk'
    var_0 = list_collection_dirs(str_0, str_0)
    assert var_0 == ['yXlR[&F/2Y+I:jtUl+']



# Generated at 2022-06-24 18:18:07.056960
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    data0 = '\n    Unit test fo list_collction_dirs\n  D '
    expected_returned_0 = [list(list_collection_dirs(data0, data0))]
    returned_0 = test_case_0()

    assert expected_returned_0 == returned_0

# Generated at 2022-06-24 18:18:16.759198
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # path exists but not a dir
    with open('./non_existing_file', 'w') as f:
        f.write("should not exist!")

    paths = [
        './',
        './non_existing_file',
        '/',
        '/non/existing/dir',
        '~/.ansible/collections'
    ]

    valid_paths = list(list_valid_collection_paths(paths))
    assert set(valid_paths) == {'./'}
    assert valid_paths[0] == './'

    # path doesnt exist and not created
    not_created = [
        '~/.ansible/collections'
    ]

    valid_paths = list(list_valid_collection_paths(not_created, warn=True))

# Generated at 2022-06-24 18:18:17.576257
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()


# Generated at 2022-06-24 18:18:26.456428
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Configure and call 'list_valid_collection_paths'
    search_paths = '1EG,\\Ib'
    warn = False
    var_0 = list_valid_collection_paths(search_paths, warn)

    str_0 = 'ZN0>m'
    var_1 = dir(var_0)
    assert str_0 not in var_1
    str_1 = '\\x'
    var_2 = list(var_0)
    assert str_1 not in var_2
    str_2 = 'n'
    try:
        next(var_0)
    except StopIteration:
        assert False


# Generated at 2022-06-24 18:18:28.118350
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test case
    test_case_0()



# Generated at 2022-06-24 18:18:36.662557
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:18:40.483741
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # verify with passed values
    assert list(list_valid_collection_paths(['test_path_0', 'test_path_1'])) == ['test_path_0', 'test_path_1']

    # verify with default values
    assert list(list_valid_collection_paths()) == AnsibleCollectionConfig.collection_paths



# Generated at 2022-06-24 18:18:48.106772
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
  assert test_case_0() == None

# Generated at 2022-06-24 18:18:54.648650
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not list_valid_collection_paths(paths=None)
    assert not list_valid_collection_paths(list('$'))
    assert not list_valid_collection_paths(list_collection_dirs())


# Generated at 2022-06-24 18:18:55.418444
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True

# Generated at 2022-06-24 18:19:00.921252
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)

    assert var_1 == []
    str_1 = 'qoGN73Q[$CBrT01&'


# Generated at 2022-06-24 18:19:09.026503
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)
    str_1 = 'qoGN73Q[$CBrT01&'
    str_2 = '_'
    str_3 = 'wDQrO5a1R5Y'
    str_4 = ";'k6Pm0M2bM#1E"
    str_5 = '\n    Unit test fo list_collction_dirs\n  D '


# Generated at 2022-06-24 18:19:09.977538
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == None



# Generated at 2022-06-24 18:19:14.347058
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '\n    Unit test fo list_valid_collection_paths\n  D '
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)
    str_1 = 'qoGN73Q[$CBrT01&'

# Generated at 2022-06-24 18:19:24.977290
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = "Unit test for function list_valid_collection_paths"
    str_1 = "/usr/local/lib/python2.7/dist-packages/ansible/collections"
    list_tuple_0 = []
    list_tuple_0.append(str_1)
    var_0 = list_valid_collection_paths(list_tuple_0, str_0)
    var_1 = list(var_0)
    str_2 = "~/.ansible/collections"
    str_3 = "~/.ansible/collections"
    list_tuple_1 = []
    list_tuple_1.append(str_3)
    var_2 = list_valid_collection_paths(list_tuple_1, str_2)

# Generated at 2022-06-24 18:19:28.137560
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with pytest.raises(AnsibleError) as exc:
        list_collection_dirs(search_paths=None, coll_filter='qoGN73Q[$CBrT01&')
    assert exc.value.args[0] == 'Invalid collection pattern supplied: qoGN73Q[$CBrT01&'

# Generated at 2022-06-24 18:19:33.236817
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    input = """
    Unit test fo list_collction_dirs
  D """
    output = list_collection_dirs(input, input)
    expected_output = list(output)
    expected_output_str = 'qoGN73Q[$CBrT01&'
    assert expected_output == expected_output_str

# Generated at 2022-06-24 18:19:45.372770
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print('\n  D ')
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)



# Generated at 2022-06-24 18:19:52.802023
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_3 = str()
    str_1 = 'ansible_collections.ns.collection_0'
    var_4 = list_collection_dirs(var_3, str_1)
    var_5 = list(var_4)
    str_2 = 'ansible_collections.ns.collection_1'
    var_6 = list_collection_dirs(var_3, str_2)
    var_7 = list(var_6)
    str_3 = 'ansible_collections.ns.collection_2'
    var_8 = list_collection_dirs(var_3, str_3)
    var_9 = list(var_8)
    str_4 = 'ansible_collections.ns.collection_3'

# Generated at 2022-06-24 18:20:03.028261
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Define a dict for storing the input, expected, and output
    test_dict = {}
    test_dict['search_paths'] = '\n    Unit test fo list_collction_dirs\n  D '
    test_dict['coll_filter'] = '\n    Unit test fo list_collction_dirs\n  D '

    # Get the return value from calling the function
    returned_var = list_collection_dirs(test_dict['search_paths'], test_dict['coll_filter'])

    # Set the expected value by calling the function directly
    expected_var = returned_var

    # Compare the return value with the expected value
    assert returned_var == expected_var
    # If they are equal the test passed successfully
    print('Test passed successfully')


# Generated at 2022-06-24 18:20:14.409471
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with a variety of inputs.
    path_list = ['~/.ansible/collection', '~/galaxy', '/usr/share/ansible/collection']

    # Test without the warn option.
    assert list(list_valid_collection_paths(path_list)) == ['/usr/share/ansible/collection']

    # Test with the warn option.
    assert list(list_valid_collection_paths(path_list, warn=True)) == ['/usr/share/ansible/collection']

    # Test with the default search paths.
    assert list(list_valid_collection_paths()) == ['/usr/share/ansible/collection', '/usr/local/share/ansible/collection', '/usr/share/ansible/collections']



# Generated at 2022-06-24 18:20:17.560848
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '\n    Unit test for list_valid_collection_paths\n  D '
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)


# Generated at 2022-06-24 18:20:19.961359
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Test list_valid_collection_paths")
    str = '\n    Unit test fo list_valid_collection_paths\n  D '
    var = list_valid_collection_paths(str, str)
    var1 = list(var)

# Generated at 2022-06-24 18:20:22.669345
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        assert test_case_0() == None
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise e

test_list_collection_dirs()

# Generated at 2022-06-24 18:20:28.340671
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)

    # list_collection_dirs() missing 1 required positional argument: 'coll_filter'
    # list_collection_dirs() missing 1 required positional argument: 'coll_filter'
    with pytest.raises(TypeError):
        list_collection_dirs()



# Generated at 2022-06-24 18:20:39.217539
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_fd = ('/home/jcalhoun/ansible/ansible-base/test/sanity/collecti'
               'on_loader/data/collections')
    fd_mngr = list_collection_dirs(coll_fd, str())
    var_1 = list(fd_mngr)
    var_2 = [('/home/jcalhoun/ansible/ansible-base/test/sanity/collecti'
              'on_loader/data/collections/ansible_collections/testns/tes'
              'tcoll1'),
             ('/home/jcalhoun/ansible/ansible-base/test/sanity/collecti'
              'on_loader/data/collections/ansible_collections/testns/tes'
              'tcoll2')]
    assert var

# Generated at 2022-06-24 18:20:45.149166
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'm)`Ey\n'
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)
    var_2 = var_1[0]
    var_3 = var_1[1]
    var_4 = var_1[2]
    # assert '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\

# Generated at 2022-06-24 18:21:03.844685
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_path = os.path.abspath('../tests/units/modules/collection_data')
    assert list_collection_dirs([coll_path]) == [coll_path + '/ansible_collections/ansible/test']

    assert list_collection_dirs(['/non/existent/path']) == []



# Generated at 2022-06-24 18:21:05.603012
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    display.display(test_case_0)



# Generated at 2022-06-24 18:21:13.568899
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    s = '\n    unit test for list_valid_collection_paths:\n  '
    search_paths = ['\n    /full/path/to/collections\n  ', '\n    /path/to/collections/filename\n  ',
                    '\n    /path/to/collections/filename\n  ', 'C:\\path\\to\\collections\\filename']
    var_0 = '\n    /full/path/to/collections\n  '
    var_1 = '\n    /path/to/collections/filename\n  '
    var_2 = list_valid_collection_paths(search_paths, True)
    var_3 = next(var_2)

    # Test with collections in ~/ansible

# Generated at 2022-06-24 18:21:20.307418
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Test case 0
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_collection_dirs(str_0, str_0)
    var_1 = list(var_0)

    # Test case 1
    str_1 = '  \n \t'
    long_0 = [feefa7b8cdaabefb743f77e4d0414b8f]
    var_2 = list_collection_dirs(long_0, str_1)
    var_3 = list(var_2)

    # Test case 2
    str_2 = 'Test'
    str_3 = 'Test'

# Generated at 2022-06-24 18:21:30.034032
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    list_collection_dirs('/tmp/ansible/devel/test/unit/module_utils/test_collections.py', '/tmp/ansible/devel/test/unit/module_utils/test_collections.py')

    # Test a collection path with valid namespaces
    for dirpath in list_collection_dirs(['test/collections/valid_namespaces'], None):
        assert os.path.isdir(dirpath)

    # Test a collection path with invalid namespaces
    for dirpath in list_collection_dirs(['test/collections/invalid_namespaces'], None):
        assert not os.path.isdir(dirpath)

    # Test a collection path with namespaces and .tar.gz packaged collection

# Generated at 2022-06-24 18:21:40.966402
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Unit: default args
    arg = list_valid_collection_paths(
        [
            '/home/myname/mycollections1',
            '/home/myname/mycollections2',
            '/home/myname/mycollections3',
        ],
        True
    )
    assert all(arg)
    # Unit: empty path
    arg = list_valid_collection_paths([], True)
    assert all(arg)
    assert '/home/myname/mycollections1' in arg
    assert '/home/myname/mycollections2' in arg
    assert '/home/myname/mycollections3' in arg
    # Unit: invalid path

# Generated at 2022-06-24 18:21:45.821778
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is None
    # for k, v in var_1:
    # var_2 = k
    # var_3 = v
    # if not var_3:
    # break
    # assert var_3 == str_0


# Generated at 2022-06-24 18:21:49.160123
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '\n    Unit test fo list_collction_dirs\n  D '
    var_0 = list_valid_collection_paths(str_0, str_0)
    var_1 = list(var_0)

# Generated at 2022-06-24 18:21:56.375021
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_1 = 'tasks'
    str_2 = 'ansible_collections'
    str_4 = list_valid_collection_paths(str_2, str_1)
    var_3 = list(str_4)


# Generated at 2022-06-24 18:22:07.405612
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Run unit tests with some test collections
    # setup a test script location in the current working directory
    if not os.path.exists('./foo'):
        os.mkdir('./foo')
    if not os.path.exists('./foo/ansible_collections'):
        os.mkdir('./foo/ansible_collections')
    if not os.path.exists('./foo/ansible_collections/myns'):
        os.mkdir('./foo/ansible_collections/myns')
    if not os.path.exists('./foo/ansible_collections/myns/mycoll'):
        os.mkdir('./foo/ansible_collections/myns/mycoll')

# Generated at 2022-06-24 18:22:44.374849
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
  assert list_valid_collection_paths(None) == (lambda x: iter(x))((AnsibleCollectionConfig.collection_paths)[:])
  assert list_valid_collection_paths(None, False) == (lambda x: iter(x))((AnsibleCollectionConfig.collection_paths)[:])
  assert type(list_valid_collection_paths('s_14', True)) == type(list_valid_collection_paths('s_14', True))
  

# Generated at 2022-06-24 18:22:47.576642
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = "this is a demo string"
    var1 = list_valid_collection_paths(var)
    for v in var1:
        print(v)


# Generated at 2022-06-24 18:22:52.139405
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    list_0 = ['/home/joe/ansible_collections', '~/.ansible/collections']
    str_0 = '\n    Unit test for list_valid_collection_paths\n  D '
    list_1 = list_valid_collection_paths(list_0, str_0)
    var_0 = list(list_1)


# Generated at 2022-06-24 18:23:02.809163
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = [
        "/usr/share/ansible/collections",
        "/etc/ansible/collections",
        os.path.expanduser("~/.ansible/collections"),
        "/usr/share/ansible/ansible_collections",
        "/etc/ansible/ansible_collections",
        os.path.expanduser("~/.ansible/ansible_collections"),
    ]

    # list_valid_collection_paths()
    valid_paths = list_valid_collection_paths()
    assert valid_paths is not None

    # list_valid_collection_paths() with search_paths
    valid_paths = list_valid_collection_paths(search_paths=test_paths)
    assert valid_paths is not None

# Unit test

# Generated at 2022-06-24 18:23:04.489813
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result = list_collection_dirs('/tmp', 'ansible')
    assert f"/tmp/ansible_collections/ansible/test" in result

# Generated at 2022-06-24 18:23:05.598390
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list(AnsibleCollectionConfig.collection_paths)

# Generated at 2022-06-24 18:23:08.663945
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = '\n    Unit test fo list_valid_collection_paths\n'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)

# End of test case 0



# Generated at 2022-06-24 18:23:09.648377
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:23:11.037505
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:23:13.708837
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
  str_1 = '\n  D '
  var_2 = list_valid_collection_paths(str_1)
  var_3 = list(var_2)


# Generated at 2022-06-24 18:24:08.849966
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Dump output from function list_collection_dirs
    try:
        test_case_0()
    except AnsibleError as e:
        print("Exception from list_collection_dirs: {}".format(e))


if __name__ == '__main__':

    test_list_collection_dirs()

# Generated at 2022-06-24 18:24:10.178004
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dir = list_collec

# Generated at 2022-06-24 18:24:12.518753
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:24:17.740686
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    var_0 = 'var_0'
    var_1 = False
    var_0 = list_valid_collection_paths(var_1)
    # AssertionError
    if not isinstance(var_0, var_0):
        raise AssertionError(
            'Expected isinstance(list_valid_collection_paths(var_1), var_0), got {0}'.format(
                type(var_0))
        )


# Generated at 2022-06-24 18:24:21.079813
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['foo']
    var_1 = list_valid_collection_paths(var_0, str_0)


# Generated at 2022-06-24 18:24:26.007246
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path1 = '/etc/ansible/ansible.cfg'
    v_paths = list_valid_collection_paths([path1], True)
    e_paths = [path1]
    for index in range(len(v_paths)):
        assert v_paths[index] == e_paths[index]



# Generated at 2022-06-24 18:24:38.460803
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Assert False for non-existant non-default search-path
    assert list_valid_collection_paths(search_paths=['bad-path'], warn=True) == []
    # Assert that default paths are included
    test_paths = ['bad-path']
    assert '~/.ansible/collections' in list_valid_collection_paths(search_paths=test_paths, warn=True)
    # Assert that valid paths are present
    test_paths = ['/tmp', '~/foo/bar']
    assert '/tmp' in list_valid_collection_paths(search_paths=test_paths, warn=True)
    assert '~/foo/bar' in list_valid_collection_paths(search_paths=test_paths, warn=True)
    # Ass

# Generated at 2022-06-24 18:24:41.195092
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(str, bool) is not False
    assert callable(list_valid_collection_paths)


# Generated at 2022-06-24 18:24:47.501076
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    directories = ['.']
    coll_filter = 'foo.bar'

    # Testing
    path = 'tests/test_data/test_galaxy/valid'
    namespace = 'test_ns'
    collection = 'test_coll'

    result = list_collection_dirs(directories, coll_filter)
    assert list(result) == [b'tests/test_data/test_galaxy/valid/ansible_collections/test_ns/test_coll']

# Generated at 2022-06-24 18:24:50.456391
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True == isinstance(test_case_0(), list)

