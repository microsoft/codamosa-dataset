

# Generated at 2022-06-24 18:15:09.430068
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Arguments taken by the function
    test_0 = [1,2,3]
    test_1 = None
    result = list_collection_dirs(test_0, test_1)
    assert type(result) == list

# Generated at 2022-06-24 18:15:17.701127
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # This test is only valid if you're running it from the root of the
    # project directory. Run with 'make code-smell'
    test_paths = [
        './test/units/utils/testdata/collections',
        './test/units/utils/testdata/invalid_collection',
        './test/units/utils/testdata/collections_broken_namespace.conf',
        './test/units/utils/testdata/invalid_file',
        './test/units/utils/testdata/collections/not_a_collection_root',
        './test/units/utils/testdata/not_a_collection_root.conf',
    ]

    good_paths = list(list_valid_collection_paths(test_paths))

# Generated at 2022-06-24 18:15:19.264341
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # FIXME: This is just a placeholder; it doesn't actually test anything.
    assert True == True

# Generated at 2022-06-24 18:15:20.195064
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()

# Generated at 2022-06-24 18:15:21.997608
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths()
    assert result == ['/home/travis/.ansible/collections']



# Generated at 2022-06-24 18:15:23.341129
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None



# Generated at 2022-06-24 18:15:25.228463
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    results = list_valid_collection_paths()
    assert isinstance(results, collections.Iterable)



# Generated at 2022-06-24 18:15:28.151724
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = ['ansible_collections']
    var_1 = 'ansible'
    result_0 = list_collection_dirs(var_0, var_1)

if __name__ == '__main__':
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:15:35.827769
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import sys
    import os

    test_path = os.path.dirname(__file__)
    sys.path.append(test_path)

    import ansible.config

    # initialize the config
    ansible_config = ansible.config.loader.ConfigLoader(None)

    # initialize the search paths
    paths = ansible_config.collection_paths

    # test that it works as we expect
    assert paths == list_valid_collection_paths()

# Generated at 2022-06-24 18:15:43.316160
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Try to get data for testcase 1
    var_1 = list_collection_dirs()

    # Try to get data for testcase 2
    var_2 = list_collection_dirs()

    # Try to get data for testcase 3
    var_3 = list_collection_dirs()

    # Try to get data for testcase 4
    var_4 = list_collection_dirs()

    # Try to get data for testcase 5
    var_5 = list_collection_dirs()

# Generated at 2022-06-24 18:15:58.702190
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for i in range(0,1000):
        try:
            # Test for a single argument
            var_0 = list_valid_collection_paths([random_str(random.randint(1, 10))])
            assert isinstance(var_0, (list,)), "Returned value is not an instance of list"
            # Test for a single argument
            var_1 = list_valid_collection_paths(random_bool())
            assert isinstance(var_1, (list,)), "Returned value is not an instance of list"
        except Exception:
           pass


# Generated at 2022-06-24 18:16:01.435378
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_valid_collection_paths()
    int_0 = None
    var_1 = list_collection_dirs(int_0)
    var_2 = list(var_1)



# Generated at 2022-06-24 18:16:04.416940
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TEST 1:
    var_0 = list_valid_collection_paths()
    int_0 = None
    var_1 = list_collection_dirs(int_0)
    var_2 = list(var_1)
    return var_2


# Generated at 2022-06-24 18:16:05.389004
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert 1 == 0


# Generated at 2022-06-24 18:16:15.992574
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_valid_collection_paths()
    int_0 = None
    var_1 = list_collection_dirs(int_0)
    var_2 = list(var_1)

# Generated at 2022-06-24 18:16:18.583508
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ["~/.ansible/collections"]
    result = list_valid_collection_paths(search_paths)
    #assert result == expected



# Generated at 2022-06-24 18:16:23.486908
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list_collection_dirs()) > 0
    assert list_collection_dirs(['not-a-path']) == []
    assert list_collection_dirs(['not-a-path'], 'not-a-coll') == []
    assert len(list_collection_dirs(coll_filter='not-a-coll')) == 0


# Generated at 2022-06-24 18:16:29.210997
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    var_0 = list_valid_collection_paths()
    var_0 = list(var_0)
    var_1 = list_collection_dirs(var_0)
    var_1 = list(var_1)

    return var_0, var_1


# Generated at 2022-06-24 18:16:33.464816
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # FIX-ME: How to test with an empty arg list?
    var_0 = list_valid_collection_paths()
    int_0 = None
    
    assert type(var_0) == type(int_0)



# Generated at 2022-06-24 18:16:35.112283
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    with pytest.raises(Exception):
        list_valid_collection_paths()



# Generated at 2022-06-24 18:16:40.671479
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True == True

# Generated at 2022-06-24 18:16:49.686031
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_root = ''
    if os.path.exists('test/test_resources/test_collections'):
        coll_root = 'test/test_resources/test_collections'
    elif os.path.exists('../test/test_resources/test_collections'):
        coll_root = '../test/test_resources/test_collections'
    else:
        raise AnsibleError('Unable to find test collection directory')
    search_paths = [coll_root]

    # test basic
    collection_dirs = list_collection_dirs(search_paths)
    collection_count = 0
    for collection_dir in collection_dirs:
        collection_count += 1
    assert collection_count == 2

    # test limit by namespace

# Generated at 2022-06-24 18:16:55.592873
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for test in [('ansible_collections.ansible.builtin', ), (None, )]:
        display.info("Testing list_collection_dirs with %s" % test)
        var_0 = list_valid_collection_paths()
        var_1 = list_collection_dirs(var_0, *test)
        var_2 = list(var_1)



# Generated at 2022-06-24 18:17:00.612027
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import os
    import sys


# Generated at 2022-06-24 18:17:04.548323
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print(list_collection_dirs('test_paths'))
    print(list_collection_dirs(search_paths='test_paths', coll_filter='test_coll_filter'))
    print(list_collection_dirs(search_paths=['test_paths', 'test_paths'], coll_filter='test_coll_filter'))


# Generated at 2022-06-24 18:17:14.600998
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print('')
    print('# Unit test for function list_collection_dirs')
    var_0 = os.path.expanduser('~/.ansible/collections')
    var_1 = [var_0]
    var_2 = list_collection_dirs(var_1)
    var_3 = list(var_2)
    var_4 = len(var_3)
    var_5 = 'ansible_collections'
    var_6 = os.path.split(var_3[0])[-1]
    var_7 = var_5 == var_6
    var_8 = 'not '
    var_9 = var_8 if var_7 else ''
    var_10 = 'are' if var_4 > 1 else 'is'

# Generated at 2022-06-24 18:17:18.687044
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_3 = os.environ.get('ANSIBLE_COLLECTIONS_PATHS') + os.pathsep + 'test'
    var_0 = list_valid_collection_paths([var_3])
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)
    assert var_2[0] == '/tmp/ansible_collections/ansible_collections/syntax_test_col/syntax_test_col.0.01.syntax_test'
    # Load default paths
    var_0 = list_valid_collection_paths()
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)

# Generated at 2022-06-24 18:17:28.522140
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['/home/runner/work/ansible-core/ansible-core/', '/home/runner/work/ansible-core/ansible-core/lib/ansible/modules/network/fortios/fortios_firewall_internet_service_extension.py']
    var_1 = list_valid_collection_paths(var_0)
    var_2 = list(var_1)

    assert var_2 == ['/home/runner/work/ansible-core/ansible-core/', '/home/runner/work/ansible-core/ansible-core/lib/ansible/modules/network/fortios/fortios_firewall_internet_service_extension.py']


# Generated at 2022-06-24 18:17:31.212392
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = ['/path/to/my/collection/library']
    var_2 = 'my_namespace'
    var_3 = list(list_collection_dirs(var_1, var_2))
    assert var_3 == ['/path/to/my/collection/library/ansible_collections/my_namespace/my_collection']

# Generated at 2022-06-24 18:17:44.128125
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    import os
    import json

    dir1 = tempfile.mkdtemp()
    dir2 = os.path.join(dir1, 'ansible_collections', 'test', 'collection')
    os.makedirs(dir2)
    os.makedirs(os.path.join(dir2, 'plugins'))
    with open(os.path.join(dir2, 'plugins', 'modules', 'test.py'), 'w'):
        pass
    with open(os.path.join(dir2, 'plugins', 'modules', 'test2.py'), 'w'):
        pass
    with open(os.path.join(dir2, 'plugins', 'module_utils', 'test_utils.py'), 'w'):
        pass

# Generated at 2022-06-24 18:17:53.460514
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True



# Generated at 2022-06-24 18:17:56.604213
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is None

# Generated at 2022-06-24 18:17:58.545891
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None

# Generated at 2022-06-24 18:18:02.649420
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with AnsibleCollectionConfig():
        AnsibleCollectionConfig.set_collection_paths(['/home/natalie'])
        var_73 = list_collection_dirs(coll_filter='foo')
        var_74 = list(var_73)
    # Verify that the following calls return the correct type
    assert isinstance(var_74, list)

# Generated at 2022-06-24 18:18:04.581225
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/test_ansible_collections/test'])==['/test_ansible_collections/test']


# Generated at 2022-06-24 18:18:06.711230
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Ensure non existing paths are not returned
    """
    assert list(list_valid_collection_paths(['/fakepath'])) == []



# Generated at 2022-06-24 18:18:09.003511
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths([]) == ()


# Generated at 2022-06-24 18:18:10.311083
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert os.path.isdir(list_valid_collection_paths().__next__())

# Generated at 2022-06-24 18:18:14.664845
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    args = [None]
    # Testing for type: bool
    is_error, err_msg, result, var_deps = ansible_module_run(
        list_valid_collection_paths,
        args,
        stage='setup'
    )

    assert not is_error, err_msg
    assert isinstance(result, list)



# Generated at 2022-06-24 18:18:17.016843
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert 'collection-1.0.0' in list(list_collection_dirs(['tests/unit/modules/test_collections/collection-path'], 'some.collection'))



# Generated at 2022-06-24 18:18:24.956064
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Insert your test code here to run test case 0
    raise Exception("Test code for list_collection_dirs not implemented")



# Generated at 2022-06-24 18:18:28.749795
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.common.collections.ansible_collections.ansible.other.plugins.module_utils.libcloud import module_utils
    assert list_collection_dirs() == module_utils.list_collection_dirs()

# Generated at 2022-06-24 18:18:37.206004
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    configurations = [
        ("test_case_0", { "search_paths": ["test_value_1"]}),
        ("test_case_1", { "coll_filter": ["test_value_2"]}),
        ("test_case_2", { "search_paths": ["test_value_1"], "coll_filter": ["test_value_2"]}),
    ]
    for test_case, params in configurations:
        # I don't think the param names need to exactly match the names in the test case
        # But I wanted to demonstrate the proper way to name them
        test_case_params = params.copy()
        if 'search_paths' in test_case_params:
            test_case_params['search_paths'] = test_case_params[search_paths]

# Generated at 2022-06-24 18:18:43.706777
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ansible_collection_paths = list_valid_collection_paths()
    collection_dirs = list_collection_dirs(ansible_collection_paths)

    assert isinstance(collection_dirs, list)
    assert len(collection_dirs) > 0

    for path in collection_dirs:
        assert os.path.isdir(path)


# Generated at 2022-06-24 18:18:47.362531
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    args = {"search_paths": None, "warn": True}
    result = list_valid_collection_paths(**args)
    assert result is not None


# Generated at 2022-06-24 18:18:54.876295
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = list(list_collection_dirs(['/usr/share/ansible_collections', '/usr/share/ansible_collections/system',
                                       '/usr/share/ansible_collections/system/nsrx',
                                       '/usr/share/ansible_collections/system/nsrx/junos'],
                                      'system.nsrx'))
    paths.sort()
    assert "/usr/share/ansible_collections/system/nsrx/junos" in paths
    assert "/usr/share/ansible_collections/system/nsrx" in paths
    assert "/usr/share/ansible_collections/system" not in paths
    assert "/usr/share/ansible_collections/system/foo/junos" not in paths

# Generated at 2022-06-24 18:18:56.579992
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs is not None


# Generated at 2022-06-24 18:18:57.774918
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass


# Generated at 2022-06-24 18:19:01.763680
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Check if the function returns a list
    assert isinstance(list_valid_collection_paths(), list)

    # Check if the function returns the correct list
    var_1 = list_valid_collection_paths()
    var_2 = list(var_1)
    assert var_2 == []



# Generated at 2022-06-24 18:19:10.183827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = None
    var_1 = None
    var_2 = None
    if var_0 == None:
        var_0 = ['hello', 'world', 'some/dir']
    if var_1 == None:
        var_1 = True
    var_3 = list_valid_collection_paths(var_0, var_1)
    var_4 = list(var_3)
    var_5 = 'hello'
    var_6 = var_5 in var_4
    var_7 = 'world'
    var_8 = var_7 in var_4
    var_9 = 'some/dir'
    var_10 = var_9 in var_4
    assert var_6 and var_8 and var_10


# Generated at 2022-06-24 18:19:29.427060
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # empty list
    search_paths = []
    # empty list should return the default collection paths
    assert list_valid_collection_paths(search_paths) == list_valid_collection_paths()
    # collections dir in cwd
    search_paths = list_valid_collection_paths()
    assert list(list_valid_collection_paths(search_paths)) == ['/usr/share/ansible/ansible_collections']
    assert list(list_valid_collection_paths(search_paths, warn=True)) == ['/usr/share/ansible/ansible_collections']
    # No collections  dir
    bad_search_paths = ['/does/not/exist']
    assert list(list_valid_collection_paths(bad_search_paths)) == []
    assert list

# Generated at 2022-06-24 18:19:36.115041
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths=['data/test/unit/ansible_collections/test/files/collection_path_one', 'data/test/unit/ansible_collections/test/files/collection_path_two']
    valid_paths = list_valid_collection_paths(search_paths)
    if (next(valid_paths) != 'data/test/unit/ansible_collections/test/files/collection_path_one') or (next(valid_paths) != 'data/test/unit/ansible_collections/test/files/collection_path_two'):
        raise AssertionError('list_valid_collection_paths function failed')


# Generated at 2022-06-24 18:19:48.062210
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Argument(s)
    my_path_1 = "/my/path/1"
    my_path_2 = "/my/path/2"
    my_path_3 = "/my/path/3"

    existing_paths = [my_path_1, my_path_2, "/my/foo/bar"]
    non_existing_paths = [my_path_3]

    # Function call (with os.path mocks)
    with CollectionListUtilsMock(existing_paths, non_existing_paths):
        result = list_collection_dirs([my_path_1, my_path_2, my_path_3])

        # Verification

# Generated at 2022-06-24 18:19:56.654810
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Set up test case inputs
    search_paths = ['/Users/daniel/.ansible/collections/ansible_collections', '/Users/daniel/Desktop/Projects/ansible_collections']

    # Perform the action
    var_1 = list_valid_collection_paths(search_paths)

    # Verify the results
    assert list(var_1) == ['/Users/daniel/.ansible/collections/ansible_collections', '/Users/daniel/Desktop/Projects/ansible_collections']


# Generated at 2022-06-24 18:20:05.048533
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)
    test_0 = "/home/vagrant/.ansible/collections"
    test_1 = "/usr/share/ansible/collections"
    test_2 = "/etc/ansible/collections"
    test_3 = "/etc/ansible/ansible_collections"
    test_4 = "/usr/share/ansible/ansible_collections"
    test_5 = "/home/vagrant/.ansible/ansible_collections"
    test_6 = "/home/vagrant/.ansible/collections/ansible_collections"
    test_7 = "/usr/share/ansible/collections/ansible_collections"

# Generated at 2022-06-24 18:20:15.607352
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Setup test sample data
    # You can setup the test at this point, or pre-process the data, such as removing path information
    # that can vary between systems, like /tmp/ansible_collections/ansible/test
    sample_data = ['/ansible_collections/ansible/test']

    # If a test case needs to start up services, or get data, or create stubbed data, do it here.
    # You can also setup test objects here, and pass them to the function to test
    # There is an example of doing this below.

    # Run the function you are testing
    actual_results = list_collection_dirs(sample_data)
    actual_results = list(actual_results)

    # Setup Expected data
    # You can setup the expected data, or compare the actual data against another source, such as a stubbed

# Generated at 2022-06-24 18:20:16.734993
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:20:17.799162
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert 1 == 1


# Generated at 2022-06-24 18:20:20.469332
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for path in list_valid_collection_paths():
        assert os.path.exists(path)
        assert os.path.isdir(path)


# Generated at 2022-06-24 18:20:29.159396
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    func_name = 'list_collection_dirs'
    func_args = []
    func_kwargs = {}

# Generated at 2022-06-24 18:20:44.685413
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = isinstance(var_0, list)
    var_2 = len(var_0)
    var_3 = [var_0[var_2 - 1]]
    var_4 = var_3[0]
    var_5 = os.path.join(var_4, 'ansible_collections')
    var_6 = is_collection_path(var_5)
    if (not var_1):
        raise AssertionError('Returned value was not a list.')
    if (var_2 != 1):
        raise AssertionError('Returned list was not of expected length.')
    if (not var_6):
        raise AssertionError('Returned path is not a valid collection path.')


# Generated at 2022-06-24 18:20:50.537527
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    paths = [os.path.join(os.getcwd(), 'testing', 'data', 'collections')]
    dirs = list(list_collection_dirs(paths, 'acme.mymodule'))
    assert dirs == [os.path.join(os.getcwd(), 'testing', 'data', 'collections', 'acme', 'mymodule')]



# Generated at 2022-06-24 18:21:02.682229
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Testing with search_paths = None, coll_filter = None
    var_0 = None
    var_1 = None
    expected_result_0 = [
        b'/Users/mhayden/.ansible/collections/ansible_collections/ansible/testcoll',
        b'/Users/mhayden/.ansible/collections/ansible_collections/testns/testcoll',
        b'/Users/mhayden/ansible/test/data/test_collections/ansible_collections/ansible/testcoll',
        b'/Users/mhayden/ansible/test/data/test_collections/ansible_collections/testns/testcoll',
        b'/usr/share/ansible/collections/ansible_collections/testns/testcoll',
    ]
    var

# Generated at 2022-06-24 18:21:06.356753
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_output = list_collection_dirs()
    assert type(test_output) == list



# Generated at 2022-06-24 18:21:08.076540
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup

    # Result
    result = list_collection_dirs()
    assert isinstance(result, list)
    assert not result


# Generated at 2022-06-24 18:21:08.868627
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:21:15.415687
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list(list_collection_dirs(["0"]))) == 0
    assert len(list(list_collection_dirs(["0"], "0"))) == 0
    assert len(list(list_collection_dirs(["0"], "0.0"))) == 0
    assert len(list(list_collection_dirs())) > 0
    assert len(list(list_collection_dirs(["0"], "0"))) == 0
    assert len(list(list_collection_dirs(["0"], "0.0"))) == 0
    assert len(list(list_collection_dirs())) > 0

# Generated at 2022-06-24 18:21:19.725729
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_valid_collection_paths()
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)
    var_3 = list_valid_collection_paths()
    var_4 = list_collection_dirs(var_3)
    var_5 = list(var_4)



# Generated at 2022-06-24 18:21:29.686749
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:21:40.784294
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # mock functions to ensure tests fail if we try to load collections from filesystem
    mock_list_valid_collection_paths = lambda: [os.path.abspath("tests/mock_collections/empty_collection")]
    mock_validate_collection_path = lambda *x: False
    mock_is_collection_path = lambda *x: True

    # set up mocks
    global list_valid_collection_paths
    list_valid_collection_paths = mock_list_valid_collection_paths
    global validate_collection_path
    validate_collection_path = mock_validate_collection_path
    global is_collection_path
    is_collection_path = mock_is_collection_path

    # no search paths
    var_1 = list_collection_dirs()

# Generated at 2022-06-24 18:21:58.478422
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths())) > 0


# Generated at 2022-06-24 18:22:08.365879
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Example1
    var_0 = list_valid_collection_paths()
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)

    if var_2 == []:
        # Unit test for AssertionError.
        raise AssertionError("No configuration file could not be found for the collection module.")
    else:
        pass

    # Example2
    var_3 = list_valid_collection_paths(["/path/to/foo"])
    var_4 = list_collection_dirs(var_3)
    var_5 = list(var_4)

    if var_5 == []:
        # Unit test for AssertionError.
        raise AssertionError("The configured collection path /path/to/foo does not exist.")

# Generated at 2022-06-24 18:22:16.522499
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    v0 = ['/Users/benklein/.ansible/collections']
    v1 = list_collection_dirs(search_paths=v0)
    #print('got collection list: {}'.format(list(v1)))
    v2 = list(v1)
    assert len(v2) == 1
    v3 = list_collection_dirs(search_paths=v0, coll_filter='benklein.go')
    #print('got specific collection list: {}'.format(list(v3)))
    v4 = list(v3)
    assert len(v4) == 1

# Generated at 2022-06-24 18:22:21.438574
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()[0] == '/home/runner/work/.ansible/collections:/home/runner/work/.ansible/roles:/etc/ansible/collections:/usr/share/ansible/collections'


# Generated at 2022-06-24 18:22:23.860757
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    '''
    Unit test for list_valid_collection_paths
    '''
    assert list_valid_collection_paths()



# Generated at 2022-06-24 18:22:25.389944
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)



# Generated at 2022-06-24 18:22:31.764465
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test with default params
    var_0 = list_valid_collection_paths()
    assert type(var_0) is list
    assert len(var_0) > 0
    var_1 = var_0[0]
    assert var_1 == '/home/foo/ansible/collections'



# Generated at 2022-06-24 18:22:35.555993
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    with pytest.raises(AnsibleError) as excinfo:
        search_paths = list_valid_collection_paths('/usr/share/ansible/PACKMSG.TXT')
    assert 'PACKMSG' in str(excinfo.value)



# Generated at 2022-06-24 18:22:39.266090
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture = ['/path/to/a', '/path/to/b']
    assert list(list_collection_dirs(fixture)) == []
    fixture = ['/path/to/a', '/path/to/b']
    assert list(list_collection_dirs(fixture, 'acme.foo')) == []

# Generated at 2022-06-24 18:22:40.337506
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()



# Generated at 2022-06-24 18:23:29.197314
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from tests.unit.collection_loader.mock_data import mock_collection_config_data
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.collection_loader

    def mock_list_valid_collection_paths(search_paths=None, warn=False):
        return mock_collection_config_data['override_paths']

    ansible.module_utils.collection_loader.list_valid_collection_paths = mock_list_valid_collection_paths
    output = list_collection_dirs()
    if PY2:
        output = StringIO(unicode(output))
    else:
        output = StringIO(str(output))

# Generated at 2022-06-24 18:23:39.816715
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:23:48.064735
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import inspect

    collection_loader_path = inspect.getfile(inspect.currentframe()).replace('test/unit/utils/module_finder_spec.py', 'lib/ansible/utils/module_finder.py')

    name_space = 'ansible_collections'
    name_collections = 'my_namespace'
    name_module = 'my_collection'
    name_module_file = 'my_module.py'
    name_module_folder = inspect.getfile(inspect.currentframe()).replace('test/unit/utils/module_finder_spec.py', 'ansible/modules/')

    # Create the collection folder and default and init files
    ansible_collections_path = os.path.join(name_module_folder, name_space)

# Generated at 2022-06-24 18:23:53.046701
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_valid_collection_paths()
    var_1 = list_collection_dirs(var_0)
    var_2 = list(var_1)

    assert(len(var_2) == 2)
    assert('collections' in var_2[0])
    assert('ansible.builtin.system' in var_2[0])
    assert('collections' in var_2[1])
    assert('ansible.builtin' in var_2[1])


# Generated at 2022-06-24 18:23:56.106914
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is None

# Unit test case for func list_collection_dirs

# Generated at 2022-06-24 18:24:07.697001
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_3 = dict()
    var_3['namespace'] = 'test_collections'
    var_3['name'] = 'my_cool_collection'
    var_3['version'] = '1.0.0'
    var_3['main'] = dict()
    var_3['main']['requirements'] = dict()
    var_3['main']['plugins'] = dict()
    var_3['main']['plugins']['connection'] = 'collection_connection_plugins'
    var_3['main']['plugins']['terminal'] = 'collection_terminal_plugins'
    var_3['main']['plugins']['cache'] = 'collection_cache_plugins'
    var_3['main']['plugins']['action'] = 'collection_action_plugins'
    var_

# Generated at 2022-06-24 18:24:19.641255
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:24:25.222124
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        var_1 = list_collection_dirs()
        assert len(var_1) == 0
    except:
        assert False

    try:
        var_3 = list_collection_dirs(coll_filter = "azure")
        assert len(var_3) == 0
    except:
        assert False



# Generated at 2022-06-24 18:24:28.055125
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False, "Failed to find unit test for list_valid_collection_paths"


# Generated at 2022-06-24 18:24:33.515231
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Set target_dir as the current working directory, then run tests
    target_dir = os.path.abspath(os.curdir)
    test_case_0()

    # Test to make sure the plugin_dir has the expected amount of files.
    assert os.listdir(target_dir) is not None