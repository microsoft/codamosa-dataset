

# Generated at 2022-06-24 18:15:10.279192
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs(['test'])
    assert isinstance(var_1, collections.Iterable)

# Generated at 2022-06-24 18:15:11.717882
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert isinstance(var_0, types.GeneratorType)

# Generated at 2022-06-24 18:15:16.297895
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Condition 0
    coll_filter = None
    with pytest.raises(AnsibleError) as excinfo:
        list_collection_dirs(search_paths=None, coll_filter=None)
    assert "Invalid collection pattern supplied: None" in str(excinfo.value)

# Generated at 2022-06-24 18:15:24.902019
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = ['/usr/share/ansible_collections', '/usr/share/ansible_collections2']

    # Valid paths array
    ret_1 = list_collection_dirs(var_1, 'my_namespace.my_collection')

    # Valid paths array, collection filter
    ret_2 = list_collection_dirs(var_1, 'test_namespace.test_collection')

    # Valid namespace filter
    ret_3 = list_collection_dirs(var_1, 'test_namespace')

    # Valid all collections
    ret_4 = list_collection_dirs(var_1)

    # Invalid collection, invalid namespace
    ret_5 = list_collection_dirs(var_1, 'some_invalid_namespace.some_invalid_collection')

    # Invalid namespace only
   

# Generated at 2022-06-24 18:15:30.335551
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    fixture_0 = ['ansible_collections']
    fixture_1 = ['ansible_collections']
    fixture_1_warn = True
    expected_result_0 = ['ansible_collections']
    expected_result_1 = ['ansible_collections']
    try:
        result_0 = list_valid_collection_paths(fixture_0)
    except:
        raise ValueError("XFAIL: ansible-test does not support modules with xfail tests")
    try:
        result_1 = list_valid_collection_paths(fixture_1)
    except:
        raise ValueError("XFAIL: ansible-test does not support modules with xfail tests")
    result_2 = list_valid_collection_paths(fixture_0)
    result_3 = list_valid_collection_path

# Generated at 2022-06-24 18:15:34.896154
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=[]) == ['/Users/binty/ansible/ansible_collections', '/Users/binty/.ansible/collections', '/etc/ansible/ansible_collections']


# Generated at 2022-06-24 18:15:45.384998
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print('Test list_collection_dirs')
    coll_dirs = list(list_collection_dirs())
    collection_paths = AnsibleCollectionConfig.collection_paths

    assert len(collection_paths) > 0

    coll_dirs = list(list_collection_dirs(search_paths=collection_paths))

    assert len(coll_dirs) > 0

    for coll_dir in coll_dirs:
        assert is_collection_path(coll_dir)
        assert coll_dir.endswith(os.path.join('ansible_collections', 'ansible', 'test'))

    # NOTE: There is no collection for this namespace, but the dir should still be listed
    ns_dirs = list(list_collection_dirs(coll_filter='foo'))

# Generated at 2022-06-24 18:15:50.341703
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for path in list_valid_collection_paths():
        assert os.path.exists(to_bytes(path))
        assert os.path.isdir(to_bytes(path))


# Generated at 2022-06-24 18:15:58.066699
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # ok, none or empty path list or None
    try:
        r1 = list_valid_collection_paths()
    except Exception:
        raise AssertionError("Wrong exception raised")

    try:
        r2 = list_valid_collection_paths(search_paths=[])
    except Exception:
        raise AssertionError("Wrong exception raised")

    try:
        r3 = list_valid_collection_paths(search_paths=None)
    except Exception:
        raise AssertionError("Wrong exception raised")

    assert r1 == r2 == r3, "All paths return the same result."

    # ok, valid path

# Generated at 2022-06-24 18:15:59.349497
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert var_0 is not None


# Generated at 2022-06-24 18:16:06.508518
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True


# Generated at 2022-06-24 18:16:17.125646
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    var_0 = list_collection_dirs()
    var_1 = list_collection_dirs(search_paths=['/tmp/foo'])


# Generated at 2022-06-24 18:16:18.988222
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs('', '')
    assert var_0 == 'Not Implemented'

# Generated at 2022-06-24 18:16:21.372468
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var = '/'
    var = list_collection_dirs(var)
    assert isinstance(var, list)



# Generated at 2022-06-24 18:16:28.019429
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Setup test variables
    var_0 = test_case_0

    # Run code to test
    data = list_valid_collection_paths(var_0)

    # FIXME: assert the data matches expected
    object_type = type(data)
    obj_name = object_type.__name__
    assert object_type is object_type, "Didn't find expected type for object, got %s" % obj_name
    obj_name = object_type.__name__
    assert object_type is object_type, "Didn't find expected type for object, got %s" % obj_name
    assert data == data, "Expected output doesn't match result"



# Generated at 2022-06-24 18:16:29.845349
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = None
    coll_filter = None
    pass

# Generated at 2022-06-24 18:16:35.730316
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs().__next__().endswith('ansible_collections/ansible/builtin')
    assert list_collection_dirs(coll_filter='ansible.builtin').__next__().endswith('ansible_collections/ansible/builtin')
    assert list_collection_dirs(coll_filter='ansible.builtin.debug').__next__().endswith('ansible_collections/ansible/builtin/debug')


# Generated at 2022-06-24 18:16:37.976236
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_filter = ''
    search_paths = []
    assert list_collection_dirs(coll_filter, search_paths) == list_collection_dirs.return_value


# Generated at 2022-06-24 18:16:41.165359
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    for collection_dir in list_collection_dirs(coll_filter="test.test_collection_0"):
        path = os.path.dirname(collection_dir)



# Generated at 2022-06-24 18:16:42.464560
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()

# Generated at 2022-06-24 18:16:52.684533
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test'
    var_0 = list_collection_dirs(str_0)
    var_1 = list(var_0)
    assert var_1 is None

# Generated at 2022-06-24 18:16:55.649140
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # assert False # FIXME
    str_0 = 'test'
    var_1 = list_collection_dirs(str_0)
    assert var_1 == list(var_1)



# Generated at 2022-06-24 18:17:00.431767
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = ["/root/.ansible/collections", "/usr/share/ansible/collections", "fake/path/does/not/exist"]
    result = list(list_valid_collection_paths(path))
    assert result == ['/root/.ansible/collections', '/usr/share/ansible/collections'], "Failed to filter collection search paths."


# Generated at 2022-06-24 18:17:03.611327
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    arg_0 = 'test'
    arg_1 = False
    out = list_valid_collection_paths(arg_0, arg_1)
    assert isinstance(out, types.GeneratorType)


# Generated at 2022-06-24 18:17:04.796416
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths('test') is not None


# Generated at 2022-06-24 18:17:09.036021
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'C:\\Users\\dell\\.ansible\\collections\\ansible_collections\\ansible'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    assert var_1 == ['C:\\Users\\dell\\.ansible\\collections\\ansible_collections\\ansible']

# Generated at 2022-06-24 18:17:13.471606
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    f = list_collection_dirs
    var = 'test'
    var_1 = [var]
    print(var_1)
    print(f(var_1))



if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:17:15.166669
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    expected = ['test']
    result = list_valid_collection_paths(expected)



# Generated at 2022-06-24 18:17:16.805768
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    assert list_valid_collection_paths(search_paths=None, warn=False)



# Generated at 2022-06-24 18:17:28.522661
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test'
    var_0 = list_collection_dirs(str_0)
    var_1 = list(var_0)
    var_1 = list_collection_dirs()
    var_2 = list(var_1)
    var_3 = list_collection_dirs(coll_filter='test_')
    var_4 = list(var_3)
    var_5 = list_collection_dirs(coll_filter='test_')
    var_6 = list(var_5)
    var_7 = list_collection_dirs(coll_filter='test_')
    var_8 = list(var_7)
    var_9 = list_collection_dirs(coll_filter='test_')
    var_10 = list(var_9)
    var_11 = list_collection

# Generated at 2022-06-24 18:17:36.691384
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test'
    var_1 = list_collection_dirs(str_0)
    var_2 = list(var_1)



# Generated at 2022-06-24 18:17:46.457761
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_data = {
        'str_0': 'test',
        'str_1': 'test',
        'non_existing_path': '/i/dont/exist/and/neither/does/this/playbook.yml',
        'non_dir_path': '/etc/hosts',
    }
    os.chdir('/')
    var_0 = list_valid_collection_paths(test_data['str_0'])
    var_1 = list(var_0)
    assert False == any(x in test_data['non_existing_path'] for x in var_1)
    assert False == any(x in test_data['non_dir_path'] for x in var_1)
    assert False == any(x in test_data['str_1'] for x in var_1)




# Generated at 2022-06-24 18:17:47.773034
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_case_0()


# Generated at 2022-06-24 18:17:49.416088
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:17:51.754926
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:17:54.270592
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert callable(list_collection_dirs)



# Generated at 2022-06-24 18:17:56.971949
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test all possible paths
    # Test paths that are not a valid collection
    # Test paths that are a valid collection
    # Test path that is a valid collection but with no contents
    # Test path that is a valid collection with contents
    assert 1 == 1

# Generated at 2022-06-24 18:18:01.025228
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = '/tmp/does_not_exist'
    paths = [path]
    new_paths = list(list_valid_collection_paths(paths))
    assert new_paths == [path]


# Generated at 2022-06-24 18:18:08.954434
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test case for the list_valid_collection_paths function.
    """
    str_0 = 'test'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    assert len(var_1) == 0

    # test with a 'non existing' path
    # the path is created and the function is expected to return the empty list.
    os.mkdir('test')
    var_0 = list_valid_collection_paths(str_0)
    var_1 = list(var_0)
    assert len(var_1) == 0

    os.rmdir('test')


# Generated at 2022-06-24 18:18:09.586281
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()

# Generated at 2022-06-24 18:18:32.211455
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # import packages
    import argparse
    import os
    import tempfile

    module_path = os.path.join(os.path.dirname(__file__), '../ansible_collections/ansible/test/')

    # declare function to be tested, along with expected return
    def test_func(module_path, coll_filter):
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument('coll_filter', default=coll_filter, nargs='?')
        args = parser.parse_args([coll_filter])
        coll_filter = args.coll_filter
        return list_collection_dirs(module_path, coll_filter)

    # test for expected exception

# Generated at 2022-06-24 18:18:39.589914
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = os.path.join(os.path.sep, 'ansible', 'test', 'data', 'test_collections')
    str_1 = 'test_str'
    str_2 = os.path.join(os.path.sep, 'ansible', 'test', 'data', 'test_collections', str_1)
    var_0 = os.path.join(os.path.sep, 'ansible', 'test', 'data', 'test_collections', 'test_str')
    # Ensures that warn is set to False
    var_1 = list_valid_collection_paths(str_0, var_0, var_0)
    var_2 = list(var_1)
    # Ensures that warn is set to True
    var_3 = list_valid_collection_paths

# Generated at 2022-06-24 18:18:44.411357
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = 'tests/units/module_utils/collection_loader/collection_data'
    valid_collections = list_valid_collection_paths([path])
    assert(str(next(valid_collections)).endswith(path))


# Generated at 2022-06-24 18:18:45.292851
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_case_0()



# Generated at 2022-06-24 18:18:48.364969
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        collections = list_valid_collection_paths('test')
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-24 18:18:54.324551
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == ['/usr/share/ansible/collections', ansible.utils.collection_loader.ALWAYS_DEFAULT_ROOT]


# Generated at 2022-06-24 18:18:56.033807
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-24 18:18:59.175497
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    arg0 = None
    arg1 = False
    ret = list_valid_collection_paths(arg0,arg1)
    print(ret)


# Generated at 2022-06-24 18:19:02.743356
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Uncomment following line to print more information about test
    # print(test_case_0.__doc__)

    test_case_0()

if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-24 18:19:07.035012
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Tests for function list_collection_dirs
    str_0 = 'test'
    var_0 = list_collection_dirs(str_0)
    assert type(var_0) is not type(list_collection_dirs('test'))



# Generated at 2022-06-24 18:19:52.213022
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()



# Generated at 2022-06-24 18:20:02.087011
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print("Test list_collection_dirs(): (1) list_collection_dirs()")
    # var_0 = list_collection_dirs()
    # print(var_0)
    print("Test list_collection_dirs(): (2) list_collection_dirs()")
    # var_0 = list_collection_dirs()
    # print(var_0)
    print("Test list_collection_dirs(): (3) list_collection_dirs()")
    # var_0 = list_collection_dirs()
    # print(var_0)
    print("Test list_collection_dirs(): (4) list_collection_dirs()")
    # var_0 = list_collection_dirs()
    # print(var_0)

# Generated at 2022-06-24 18:20:14.177350
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    """
    Ensure we can list collection dirs from configured search paths
    """

    from ansible.utils.collection_loader import _list_collection_dirs

    # if run from the test dir, we need a clean env so we have no default collection paths
    default_collection_paths = AnsibleCollectionConfig.collection_paths
    AnsibleCollectionConfig.collection_paths = []

    # clear the collection dir cache so we can force a find
    _list_collection_dirs.clear()

    # no search paths
    colls = list_collection_dirs()
    assert colls == []

    # all collections found
    colls = list_collection_dirs(search_paths=['test/units/utils/collections'])
    assert len(colls) == 2

    # invalid path
    colls = list_collection_

# Generated at 2022-06-24 18:20:20.332273
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Path to the ansible_collections directory
    real_collection_path = os.path.join(os.getcwd(), 'tests', 'unit', 'legacy', 'data', 'module_utils', 'ansible_collections')
    # Path to the fake_collections directory
    fake_collection_path = os.path.join(os.getcwd(), 'tests', 'unit', 'legacy', 'data', 'module_utils', 'fake_collections')
    # Path to the ansible_collections directory
    real_collection_file = os.path.join(os.getcwd(), 'tests', 'unit', 'legacy', 'data', 'module_utils', 'ansible_collections.zip')


# Generated at 2022-06-24 18:20:24.182833
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['/var/lib/ansible/foo/bar', '/dev/null']
    paths = list(list_valid_collection_paths(test_paths, warn=False))
    assert paths == ['/var/lib/ansible/foo/bar/ansible_collections']


# Generated at 2022-06-24 18:20:25.539411
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Runs every test case
    test_case_0()



# Generated at 2022-06-24 18:20:26.423732
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True != False


# Generated at 2022-06-24 18:20:28.865403
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test the result of call to list_collection_dirs
    # Test 1: Collection dirs with no args
    try:
        assert test_case_0()
    except Exception as e:
        print(e)
        print(test_case_0())
        raise Exception(e)

# Generated at 2022-06-24 18:20:33.225777
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    result = list_valid_collection_paths(['test_collection_loader/test_base_test_case_0/testcase0'], True)
    assert result == ['test_collection_loader/test_base_test_case_0/testcase0']
    result = list_valid_collection_paths(['test_collection_loader/test_base_test_case_0/testcase1'], True)
    assert result == []
    result = list_valid_collection_paths(['test_collection_loader/test_base_test_case_0/testcase2'], True)
    assert result == []


# Generated at 2022-06-24 18:20:35.083755
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    fixture_0 = list_collection_dirs()
    fixture_1 = list(fixture_0)

    assert fixture_1

# Generated at 2022-06-24 18:21:14.053632
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert(var_1[0] == '/home/vagrant/.ansible/collections')

# Generated at 2022-06-24 18:21:15.466127
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        test_case_0()
    except Exception as e:
        raise e

# Generated at 2022-06-24 18:21:21.728082
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # check that if no default search paths exist, that we get empty list back
    with open(os.path.expanduser('~/.ansible.cfg'), 'w') as ansible_cfg:
        ansible_cfg.write('')
    with open(os.path.expanduser('~/.ansible/ansible.cfg'), 'w') as ansible_cfg:
        ansible_cfg.write('')

    assert list(list_valid_collection_paths()) == []



# Generated at 2022-06-24 18:21:32.292685
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        'foo',
        'bar',
        'baz',
        'foo/bar/baz'
    ]
    paths.append(to_bytes(paths[-1], errors='surrogate_or_strict'))
    paths.append(None)

    real_paths = [
        'foo',
        'bar',
        'baz',
        '/foo/bar/baz'
    ]
    real_paths.append(to_bytes(real_paths[-1], errors='surrogate_or_strict'))
    real_paths.append(None)  # This is always a valid path

    # Test paths always exist
    for path in real_paths:
        assert is_valid_path(path)

    # Test paths never exist

# Generated at 2022-06-24 18:21:35.679434
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths == [
'/home/user/.ansible/collections',
'/usr/share/ansible/collections'
]



# Generated at 2022-06-24 18:21:40.768912
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # If statement must be a string
    assert "" in str(test_case_0.__code__.co_code)
    # Code block must start with a string
    assert "" in str(test_case_0.__code__.co_consts[1])
    # Code block must end with a string
    assert "" in str(test_case_0.__code__.co_consts[3])

# Generated at 2022-06-24 18:21:51.352407
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_dir = "/etc/ansible/collections"
    path_file = "/etc/ansible/collections/ansible_collections/file.txt"
    path_dir2 = "~/.ansible/collections"
    target = ['/etc/ansible/collections/ansible_collections', '/usr/share/ansible/collections/ansible_collections',
              '~/.ansible/collections/ansible_collections']
    assert list_valid_collection_paths([path_dir2]) == ['~/.ansible/collections/ansible_collections']
    assert list_valid_collection_paths([path_dir]) == target
    assert list_valid_collection_paths([path_file]) == []


# Generated at 2022-06-24 18:21:53.346483
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Run the unit test only if running from source.
    if 'ANSIBLE_COLLECTIONS_PATHS' in os.environ:
        test_case_0()



# Generated at 2022-06-24 18:21:54.668187
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:21:58.209117
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    os.fakefs_start()
    var_1 = list_valid_collection_paths(search_paths=["/etc/ansible/roles"])
    var_2 = list(var_1)
    os.fakefs_stop()


# Generated at 2022-06-24 18:23:19.988685
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True

# Generated at 2022-06-24 18:23:24.492837
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_list=['/home/vagrant/ansible/fakes_collections1', '/home/vagrant/ansible/fakes_collections2']
    valid_path_list=list_valid_collection_paths(path_list)

    assert next(valid_path_list)=='/home/vagrant/ansible/fakes_collections1'

# Generated at 2022-06-24 18:23:30.401548
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # check default empty-list is ok
    var_0 = list_valid_collection_paths()

    # check with invalid path, no warning
    var_1 = list_valid_collection_paths(['foobar'])
    var_2 = list(var_1)
    var_3 = len(var_2)
    assert var_3 == 0

    # check with invalid path, no warning
    var_4 = list_valid_collection_paths(['foobar'], True)
    var_5 = list(var_4)
    var_6 = len(var_5)
    assert var_6 == 0



# Generated at 2022-06-24 18:23:40.074399
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test fixture format is (fps, input_args, expected_result)
    test_fixtures = [
        (
            (
                "{'search_paths': ['/Users/peter/Documents/GitHub/ansible-extras/collections'], 'coll_filter': None}",
            ),
            [],
            [],
        ),
        (
            (
                "{'search_paths': ['test/my_collection'], 'coll_filter': 'my_namespace'}",
            ),
            [],
            [],
        ),
    ]

    for arg_combination_index, (fixed_args, input_args, expected_result) in enumerate(test_fixtures):

        arg_combination = fixed_args.copy()
        arg_combination.update(input_args)

# Generated at 2022-06-24 18:23:41.628020
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test for path validity
    assert list_valid_collection_paths() != None


# Generated at 2022-06-24 18:23:44.058358
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == AnsibleCollectionConfig.collection_paths


# Generated at 2022-06-24 18:23:48.332610
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected = ['/tmp/ansible_collections/test/test_collection']
    observed = list_collection_dirs(search_paths=['/tmp'], coll_filter='test.test_collection')
    assert list(observed) == expected



# Generated at 2022-06-24 18:23:50.976685
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        print("Testing list_collection_dirs")
        test_case_0()
    except Exception as e:
        raise


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:23:52.520805
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert '/root/.ansible/collections' in list_valid_collection_paths()

# Generated at 2022-06-24 18:23:56.038594
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    with pytest.raises(TypeError):
        list_valid_collection_paths(search_paths=None, warn=None)
