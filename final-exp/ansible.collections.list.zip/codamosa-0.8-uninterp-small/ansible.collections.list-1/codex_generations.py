

# Generated at 2022-06-24 18:15:13.871807
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Using the following mock:
    class MockAnsibleCollectionConfig:

        @staticmethod
        def collection_paths():
            return []

    class MockAnsibleError:

        @staticmethod
        def AnsibleError(err):
            return True

    # Saving the original modules for later restoration
    real_ansible_collection_config = AnsibleCollectionConfig
    real_ansible_error = AnsibleError

    # Mock modules for this unit test
    AnsibleCollectionConfig = MockAnsibleCollectionConfig
    AnsibleError = MockAnsibleError

    # Test passing an incorrect path
    assert list_valid_collection_paths(search_paths=['/some/path'], warn=True)

    # Restore the original modules
    AnsibleCollectionConfig = real_ansible_collection_config
    AnsibleError = real_ansible

# Generated at 2022-06-24 18:15:22.861839
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = "/Users/rap/repos/openshift/openshift-ansible/test/integration/targets/docker-host/files/host-files/var/lib/openshift-ansible-collector"
    var_1 = "/Users/rap/repos/openshift/openshift-ansible/test/integration/targets/docker-host/files/host-files/var/lib/openshift-ansible-collector"
    var_2 = "/etc/ansible/roles"
    var_3 = "/Users/rap/repos/openshift/openshift-ansible/test/integration/targets/docker-host/files/host-files/var/lib/openshift-ansible-collector"

# Generated at 2022-06-24 18:15:26.268305
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_collection_0 = to_bytes(os.path.join('/tmp', 'mycollection'))

    os.makedirs(path_collection_0)
    assert is_collection_path(path_collection_0) is True



# Generated at 2022-06-24 18:15:35.587827
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Find the current dir of this file
    current_dir = os.path.abspath(os.path.dirname(__file__))

    # Set needed variables
    search_path = os.path.abspath(os.path.join(current_dir, "../../../../../lib/ansible/collections/ansible_collections"))
    search_paths = [search_path]
    search_paths_list = list(list_valid_collection_paths(search_paths))
    assert search_path in search_paths_list


# Generated at 2022-06-24 18:15:37.585399
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:15:41.260327
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(search_paths=None) == tuple()


# Generated at 2022-06-24 18:15:44.478559
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/etc/ansible/ansible.cfg', '/etc/ansible/ansible.cfg']
    warn = True
    res_0 = list_valid_collection_paths(search_paths=search_paths, warn=warn)
    assert res_0 != None


# Generated at 2022-06-24 18:15:46.560195
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = ['/Users/bingli/git/ansible/test/integration/targets']
    valid_path = list_valid_collection_paths(path)
    assert type(valid_path) == type(path)


# Generated at 2022-06-24 18:15:48.852041
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list(list_collection_dirs())) == 0


# Generated at 2022-06-24 18:15:53.639108
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = ["/home/chad/.ansible/roles"]
    var_1 = "my-custom-collection"
    res = list_collection_dirs(search_paths=var_0,coll_filter=var_1)
    assert res is not None


# Generated at 2022-06-24 18:16:06.679873
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [u'/usr/sbin', u'/usr/local/bin', u'/usr/bin', u'/usr/x86_64-pc-linux-gnu/gcc-bin/4.5.4', u'/usr/bin/site_perl', u'/usr/bin/vendor_perl', u'/usr/bin/core_perl', u'.']
    assert list_valid_collection_paths(search_paths=search_paths) == ['.']


# Generated at 2022-06-24 18:16:08.848394
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_list, correct_list = [], []

    for i in test_list:
        assert i in correct_list



# Generated at 2022-06-24 18:16:10.887216
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    assert var_0 is not None


# Generated at 2022-06-24 18:16:15.290346
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['tests/resources/0']
    var_1 = True
    var_2 = list_valid_collection_paths(var_0, var_1)
    assert var_2 == 'tests/resources/0', "Incorrect return value for list_valid_collection_paths()"


# Generated at 2022-06-24 18:16:20.332954
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # See if we would like to check for any exceptions
    # TODO: Replace assert with try/catch
    # Note: Exception can be of type IOError, KeyError, StopIteration, TypeError, ValueError
    try:
        test_case_0()

    except AssertionError as e:
        display.error("Test case 0 failed: %s" %e)

# Generated at 2022-06-24 18:16:24.179853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs(search_paths=['my_dir'])
    var_2 = list_collection_dirs(coll_filter='Random.Collection')
    var_3 = list_collection_dirs(search_paths=['my_dir'], coll_filter='Random.Collection')

# Generated at 2022-06-24 18:16:33.465186
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:16:39.390697
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    my_path = os.path.dirname(__name__)
    my_path = os.path.abspath(my_path)
    my_path = os.path.join(my_path, "ansible_collections")
    print("Path to my collection:")
    print(my_path)
    my_collections = list_collection_dirs([my_path])
    print("Found the following collections:")
    print(my_collections)

# result = list_collection_dirs()
# print(result)
# test_list_collection_dirs()


# Generated at 2022-06-24 18:16:42.218410
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list_collection_dirs()) > 0

# Unit test function to test 'list_collection_dirs'
# with all possible values.

# Generated at 2022-06-24 18:16:47.994506
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_a = "not_ansible_collections"
    var_b = "ansible_collections"

    # Test if the search path is a directory
    assert list_valid_collection_paths(var_a) == set(AnsibleCollectionConfig.collection_paths)
    assert list_valid_collection_paths(var_b) == set(AnsibleCollectionConfig.collection_paths)



# Generated at 2022-06-24 18:17:05.937897
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'utils_collection_loader.py')):
        raise Exception('Unit test must be run from the test directory inside the plugin directory')
    mod_path = 'ansible_collections.ansible.builtin'
    coll_list_dirs_filter = 'collect_facts.win_ping'
    coll_list_dirs_search_paths = ['../']
    assert set([os.path.realpath('./ansible_collections/ansible/builtin/collect_facts')]) == set(list_collection_dirs(search_paths=coll_list_dirs_search_paths, coll_filter=mod_path))

# Generated at 2022-06-24 18:17:12.967830
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # List which will hold the return values
    ret = []

    # Valid flag
    valid = True

    # Setup the mock

# Generated at 2022-06-24 18:17:18.967718
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # mockable path: /Users/dave/.ansible/roles/pf.testcollection.ping/tasks/main.yml
    mockable_path_01 = "/Users/dave/.ansible/roles/pf.testcollection.ping/tasks/main.yml"

    # TODO: Use items from mockable_path_01
    '''
    search_paths=None, coll_filter=None

    '''

    assert list_collection_dirs(search_paths=None, coll_filter=None)

# Generated at 2022-06-24 18:17:23.375855
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        search_paths = ['/root']
        warn = False
        assert list_valid_collection_paths(search_paths, warn)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-24 18:17:24.791969
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(), set)


# Generated at 2022-06-24 18:17:31.504893
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("Testing test_list_valid_collection_paths")
    paths = [
        "/tmp/does/not/exist",
        "/",
        "/tmp",
        "/tmp/does/not/exist/collections"
    ]
    valid_paths = list_valid_collection_paths(paths)
    assert '/tmp' in valid_paths
    assert '/tmp/does/not/exist' not in valid_paths
    assert '/' in valid_paths
    assert '/tmp/does/not/exist/collections' not in valid_paths

# Generated at 2022-06-24 18:17:34.695817
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert isinstance(var_0, list)



# Generated at 2022-06-24 18:17:38.144133
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Assert if the number of elements in the return is not equal to 0
    assert(len(list(list_collection_dirs())) > 0)


# Generated at 2022-06-24 18:17:39.871734
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list_collection_dirs()

    # The default collection path should contain a simple example collection
    assert len(list(coll_dirs)) > 0


# Generated at 2022-06-24 18:17:45.063500
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = '/usr/share/ansible/ansible_collections'
    assert path in list_valid_collection_paths()

    assert '/etc/ansible/ansible_collections' in list_valid_collection_paths()


# Generated at 2022-06-24 18:17:57.150088
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test with no argument
    assert list_collection_dirs() is not None

# Generated at 2022-06-24 18:18:02.286543
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = AnsibleCollectionConfig()
    var_1 = None
    path = to_bytes(os.path.join(var_0.config_data['collections_paths'], u'ansible_collections', u'_namespace_', u'_collection_'))
    collections = list_collection_dirs(var_1)
    assert path in collections

# Generated at 2022-06-24 18:18:03.677442
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
  assert False

# Generated at 2022-06-24 18:18:07.766078
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test for invalid return type
    var_0 = list_collection_dirs()
    assert isinstance(var_0, type(list_collection_dirs()))
    try:
        # Test for exception on failure
        var_0 = list_collection_dirs()
        assert False
    except (AnsibleError, SystemExit):
        # Test for exception on failure
        assert True



# Generated at 2022-06-24 18:18:13.487280
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_valid_collection_paths(['bogus', 'bogus2'], True)
    assert list_collection_dirs(['bogus', 'bogus2'])
    var_1 = AnsibleCollectionConfig.collection_paths
    assert len(var_1) != 0
    assert list_collection_dirs()
    assert list_collection_dirs(['bogus', 'bogus2'], 'bogus.bogus2')
    assert list_collection_dirs([], 'bogus.bogus2')
    assert list_collection_dirs()

# Generated at 2022-06-24 18:18:14.324171
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    pass



# Generated at 2022-06-24 18:18:19.922992
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test with no path set and environment not set
    assert list_valid_collection_paths()

    # Test with path and environment not set
    assert list_valid_collection_paths(['/fake/path'])

    # Test with path and environment set
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/fake/path'
    assert list_valid_collection_paths([])

    # Test with path set and environment set
    assert list_valid_collection_paths(['/fake/path'])



# Generated at 2022-06-24 18:18:23.822612
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    Print = 'print'
    var_0 = list(Print.__dict__.keys())



# Generated at 2022-06-24 18:18:26.988843
# Unit test for function list_collection_dirs

# Generated at 2022-06-24 18:18:28.117992
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass


# Generated at 2022-06-24 18:18:37.669414
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True == True

# Generated at 2022-06-24 18:18:44.029620
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = os.environ.get('HOME')
    var_1 ='.'
    # test with a file path
    var_2 = os.path.join(var_0, '.ansible', 'tmp', 'ansible-test-s1mlovkK')
    var_3 = var_2
    var_4 = os.path.join(var_0, var_1, '.ansible', 'collections')
    # test with a dir path
    var_5 = os.path.join(var_0, '.ansible', 'tmp', 'ansible-test-X9et64fE')
    var_6 = os.path.join(var_0, var_1, '.ansible', 'tmp', 'ansible-test-X9et64fE')
    # test with a broken path
    var_

# Generated at 2022-06-24 18:18:45.868356
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is None


# Generated at 2022-06-24 18:18:49.700927
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup
    search_paths = None
    coll_filter = None

    # Test
    result = list_collection_dirs(search_paths, coll_filter)

    # Verify
    assert isinstance(result, list)



# Generated at 2022-06-24 18:18:58.020038
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    testpath = "/home/testuser/testdir"
    fh = open("{}/test.txt".format(testpath), "w")
    fh.close()
    fh = open("{}/test.py".format(testpath), "w")
    fh.close()


# Generated at 2022-06-24 18:19:00.717023
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_3 = list_collection_dirs()
    var_4 = list(var_3)
    assert not isinstance(var_4, dict), "Must be list"

# Generated at 2022-06-24 18:19:04.811138
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    paths = [
        'test/test'
    ]
    assert set(list_valid_collection_paths(search_paths=paths)) == {'test/test'}


# Generated at 2022-06-24 18:19:11.259193
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    curdir = os.getcwd()
    assert list_valid_collection_paths(search_paths=[curdir]) == [curdir]
    assert list(list_valid_collection_paths(search_paths=[curdir])) == [curdir]
    assert list_valid_collection_paths(search_paths=[curdir, '/x']) == [curdir]
    assert list(list_valid_collection_paths(search_paths=[curdir, '/x'])) == [curdir]
    assert list_valid_collection_paths(search_paths=['/x']) == []
    assert list(list_valid_collection_paths(search_paths=['/x'])) == []

# Generated at 2022-06-24 18:19:17.064515
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Loop and print each collection directory
    for coll_path in list_collection_dirs():
        print(coll_path)
    # Loop and print each collection directory for a specific namespace
    for coll_path in list_collection_dirs(coll_filter='my_namespace'):
        print(coll_path)
    # Loop and print each collection directory for a specific collection
    for coll_path in list_collection_dirs(coll_filter='my_namespace.my_collection'):
        print(coll_path)

# Generated at 2022-06-24 18:19:22.614341
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths(search_paths=['a', 'b'])
    var_1 = list(var_0)

    assert var_1 == ['a', 'b', os.path.join(os.path.expanduser('~'), '.ansible', 'collections')]


# Generated at 2022-06-24 18:19:48.807540
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # mock path to return value
    os.path.exists.side_effect = lambda x: True
    os.path.isdir.side_effect = lambda x: True
    os.path.join.side_effect = os.path.join
    os.listdir.side_effect = lambda x: [path.split('/')[-1] for path in ['/'.join(x)]]
    is_collection_path.side_effect = lambda x: True

    # unit test
    try:
        test_case_0()
    except AssertionError as err:
        print("Test Failure: %s" % err)
        raise
    else:
        print("Test Success")



# Generated at 2022-06-24 18:19:49.424510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:19:53.719920
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = [
        '/foo/bar',
        '/baz/qux',
        ]
    warn = False
    paths = list(list_valid_collection_paths(search_paths, warn))
    assert paths == search_paths

# Generated at 2022-06-24 18:20:01.473974
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = ['bogus', '/tmp', '/ansible/collection/root']
    for path in list_valid_collection_paths(test_paths):
        print(path)
    for path in list_valid_collection_paths():
        print(path)


# Generated at 2022-06-24 18:20:04.101853
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    result_0 = list_collection_dirs()
    result_1 = list(result_0)

# Generated at 2022-06-24 18:20:10.679207
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths('~/.ansible/roles') == ['~/.ansible/roles']
    assert list_valid_collection_paths('./collections') == ['./collections']
    assert list_valid_collection_paths('/usr/share/ansible/collections') == ['/usr/share/ansible/collections']


# Generated at 2022-06-24 18:20:15.256045
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test list_valid_collection_paths
    # NOTE: This is a default use case in Ansible
    actual_results = list_valid_collection_paths()

    # Check if the actual results meet the expected
    if actual_results == []:
        raise AssertionError("Actual result '{}' does not match expected result '{}'".format(actual_results, []))


# Generated at 2022-06-24 18:20:18.509679
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    # var_1 => set of found collections


# Generated at 2022-06-24 18:20:27.341872
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    collection_paths = []

    # Create a collection directory
    collection_path = os.path.join(tmpdir, 'namespace', 'collection', 'ansible_collections')
    os.makedirs(collection_path)

    collection_paths.append(collection_path)

    # Create a sub collection directory
    sub_collection_path = os.path.join(collection_path, 'namespace', 'collection', 'some_collection')
    os.makedirs(sub_collection_path)

    # Set up arguments used in the following function call
    search_paths = [tmpdir]

    # Call function

# Generated at 2022-06-24 18:20:29.726798
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    mock_1 = ["/does/not/exist", "/root/ansible"]
    mock_2 = list(list_valid_collection_paths(search_paths=mock_1))
    assert mock_2 == ["/root/ansible"]


# Generated at 2022-06-24 18:21:06.438323
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == list(var_1)


# Generated at 2022-06-24 18:21:09.707073
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = None
    var_1 = None
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    var_2 = list_collection_dirs()
    var_3 = list(var_2)
    return {'var_0': var_0, 'var_1': var_1, 'var_2': var_2, 'var_3': var_3}



# Generated at 2022-06-24 18:21:12.686883
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(None, None) == list_collection_dirs()


# Functions for unit tests only

# Generated at 2022-06-24 18:21:13.855738
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == AnsibleCollectionConfig.collection_paths

# Generated at 2022-06-24 18:21:15.928081
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    assert var_1 is not None



# Generated at 2022-06-24 18:21:17.368576
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:21:23.925319
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    var_2 = list_collection_dirs(coll_filter="")
    var_3 = list(var_2)

    var_4 = list_collection_dirs(coll_filter="foo")
    var_5 = list(var_4)

    var_6 = list_collection_dirs(coll_filter="foo.bar")
    var_7 = list(var_6)

    pass

# Generated at 2022-06-24 18:21:34.032691
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test generating search_paths from default configuration
    var_2 = list_valid_collection_paths()
    var_3 = list(var_2)
    assert var_3 is not None
    assert len(var_3) >= 1

    # Test generating search_paths from list-of-paths configuration
    var_4 = ['.']
    var_5 = list_valid_collection_paths(var_4)
    var_6 = list(var_5)
    assert var_6 is not None
    assert len(var_6) >= 1

    # Test generating search_paths when list-of-paths has non-existent entry
    var_7 = ['.', 'does-not-exist']
    var_8 = list_valid_collection_paths(var_7)

# Generated at 2022-06-24 18:21:35.298494
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() == None

# Generated at 2022-06-24 18:21:44.182675
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print(set(list_valid_collection_paths(['/home/user', '/home/user/galaxy_path', '/home/user/galaxy_path'])))
    assert set(list_valid_collection_paths(['/home/user', '/home/user/galaxy_path'])) == set(['/home/user/galaxy_path'])
    assert set(list_valid_collection_paths(['/galaxy_path/ansible_collections'])) == set(['/galaxy_path/ansible_collections'])
    assert set(list_valid_collection_paths(['/galaxy_path/ansible_collections', '/home/user/.ansible/collections'])) == set(['/galaxy_path/ansible_collections', '/home/user/.ansible/collections'])

# Generated at 2022-06-24 18:23:09.641829
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # test default behaviour with empty entry
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)

    var_2 = list_valid_collection_paths(search_paths=['/tmp/foobar'])
    var_3 = list(var_2)

    var_4 = list_valid_collection_paths(search_paths=['/tmp/foobar'], warn=True)
    var_5 = list(var_4)


# Generated at 2022-06-24 18:23:19.840253
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    import tempfile
    import shutil
    now = os.getcwd()

    coll_root = tempfile.mkdtemp()
    coll_1 = 'ansible_collections/namespace_1/collection_1/collection_1/ansible_collections/namespace_1/collection_1/plugins'
    coll_2 = 'ansible_collections/namespace_1/collection_2/plugins'
    coll_3 = 'ansible_collections/namespace_2/collection_1'
    coll_4 = 'ansible_collections/namespace_2/collection_2'
    coll_5 = 'ansible_collections/namespace_1/collection_5/plugins'
    coll_6 = 'ansible_collections/namespace_2/collection_6/plugins/modules'

# Generated at 2022-06-24 18:23:23.677500
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        assert to_bytes(os.path.join(os.path.sep, 'ansible_collections')) in var_1[0]
        assert True
    except AssertionError as ae:
        raise AssertionError(ae)



# Generated at 2022-06-24 18:23:28.588021
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Sample inputs
    # Note that search_paths is set to None, because it is not modified in the test.
    inputs = {"search_paths": None, "warn": False}
    for search_paths in [None, []]:
        for warn in [False]:
            inputs["search_paths"] = search_paths
            inputs["warn"] = warn
            out = list_valid_collection_paths(**inputs)
            assert out is not None


# Generated at 2022-06-24 18:23:39.650650
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # this test assume current working directory is tests/
    assert list_collection_dirs(coll_filter='test') == ['/data/tests/test/ansible_collections/test/test']
    assert list_collection_dirs(coll_filter='test.test') == ['/data/tests/test/ansible_collections/test/test']
    assert list_collection_dirs(search_paths=['/data/tests/test/ansible_collections'], coll_filter='test.test') == ['/data/tests/test/ansible_collections/test/test']
    assert list_collection_dirs(search_paths=['/data/tests/test/ansible_collections'], coll_filter='notest') == []

# Generated at 2022-06-24 18:23:44.062737
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # initialize empty dict
    result = dict()

    # return the function and check the type
    var = test_case_0()
    assert isinstance(test_case_0(), type(test_case_0()))
    # store return value
    result['ret'] = var

    # check the function output against expected result
    assert result['ret'] == var_1

# Generated at 2022-06-24 18:23:50.504948
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path = '/home/ansible/mycollections'
    var_1 = list_valid_collection_paths()
    var_2 = list(var_1)
    var_3 = list_valid_collection_paths([path])
    var_4 = list(var_3)
    var_5 = list_valid_collection_paths([path], True)
    var_6 = list(var_5)
    assert var_2 == var_4
    assert var_6 == var_4


# Generated at 2022-06-24 18:23:55.926354
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)
    my_list = ['ansible_collections/test_fixtures/plugins/ansible_collections/test_fixtures/collection_fixtures.tar.gz', 'ansible_collections/test_fixtures/plugins/ansible_collections/test_fixtures/collection_plugins.tar.gz', 'ansible_collections/test_fixtures/plugins/ansible_collections/test_fixtures/collection_roles.tar.gz']
    var_1.sort()
    assert var_1 == my_list



# Generated at 2022-06-24 18:23:58.101615
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print("in function test_list_valid_collection_paths")


# Generated at 2022-06-24 18:24:08.417533
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths([
        'dummy_path_0',
        'dummy_path_1',
        'dummy_path_2',
        'dummy_path_3',
        'dummy_path_4',
        'dummy_path_5',
    ], True)
    var_1 = list(var_0)
    assert 'dummy_path_0' in var_1
    assert 'dummy_path_1' in var_1
    assert 'dummy_path_2' in var_1
    assert 'dummy_path_3' in var_1
    assert 'dummy_path_4' in var_1
    assert 'dummy_path_5' in var_1
    assert len(var_1) == 6
