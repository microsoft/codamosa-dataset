

# Generated at 2022-06-24 18:15:08.691035
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    expected = None
    assert var_0 == expected, "Test case failed. Expected: {} got: {}".format(expected, var_0)


# Generated at 2022-06-24 18:15:10.444287
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = ['']
    list_valid_collection_paths(var_0, True)


# Generated at 2022-06-24 18:15:15.162675
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Given
    ansible_config = """
    [defaults]
    collections_paths = /root/ansible/collections/:/root/ansible/module_utils/
    """

    # When
    from ansible.cli import CLI
    cli = CLI(None, '-c', ansible_config, None, None, None, None, None, None)
    cli._configure_settings()

    # Then
    var_0 = cli._settings['collections_paths']
    assert var_0 == ['/root/ansible/collections/', '/root/ansible/module_utils/']


# Generated at 2022-06-24 18:15:21.581606
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Tests that the list of valid collection paths is returned
    # when we have a valid collection paths
    search_paths = [os.getcwd(), os.getcwd()]
    assert list(list_valid_collection_paths(search_paths))
    # Tests that the list of valid collection paths is returned
    # when we have a valid collection paths
    search_paths = [os.getcwd(), os.getcwd(), os.getcwd()]
    assert list(list_valid_collection_paths(search_paths))


# Generated at 2022-06-24 18:15:24.547020
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs(['/etc/ansible/ansible_collections'], 'test_namespace.test_collection')



# Generated at 2022-06-24 18:15:29.102207
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    test_cases = [
        (0, )
    ]
    for test_input, expected_output in test_cases:
        print(test_input)
        print(' expected: {}'.format(expected_output))
        actual_output = list_collection_dirs(test_input)
        print(' actual: {}'.format(actual_output))
        assert actual_output == expected_output
    print('test_list_collection_dirs: ok')

if __name__ == "__main__":
    test_list_collection_dirs()

# Generated at 2022-06-24 18:15:30.387234
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    expected = {'foo', 'bar'}
    assert expected == set(list_valid_collection_paths(['foo', 'bar']))

# Generated at 2022-06-24 18:15:34.504276
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ansible_collections_dir = os.path.dirname(os.path.dirname(__file__))
    assert next(list_collection_dirs([ansible_collections_dir]), None) is not None


# Generated at 2022-06-24 18:15:45.198784
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_paths = list(list_valid_collection_paths(['/tmp/ansible_collections']))
    assert(len(test_paths)==1)
    test_paths = list(list_valid_collection_paths(['/tmp/ansible_collections', '/tmp/ansible_collections2/']))
    assert(len(test_paths)==2)
    test_paths = list(list_valid_collection_paths(['/tmp/ansible_collections3/']))
    assert(len(test_paths)==0)
    test_paths = list(list_valid_collection_paths(['/tmp/ansible_collections4']))
    assert(len(test_paths)==0)

# Generated at 2022-06-24 18:15:54.374502
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    display.display("Testing list_valid_collection_paths")
    search_paths = ['/Users/michael/Projects/ansible/tmp/does_not_exist',
                    '/Users/michael/Projects/ansible/tmp/empty',
                    '/Users/michael/Projects/ansible/ansible/test/units/modules/test_collections/collections'
                    ]

    var_1 = list_valid_collection_paths(search_paths, True)
    list_valid_collection_paths()



# Generated at 2022-06-24 18:16:04.674723
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected_result = None

    result = list_collection_dirs()
    assert result == expected_result, 'Expected and actual results do not match!'



# Generated at 2022-06-24 18:16:11.637013
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    coll_path = "/home/roota/.ansible/collections:/usr/share/ansible/collections"
    coll_path = '/home/roota/.ansible/collections:/usr/share/ansible/collections:/tmp/testing'
    valid_coll_path = list_valid_collection_paths(coll_path)
    assert valid_coll_path == ['/home/roota/.ansible/collections', '/usr/share/ansible/collections', '/tmp/testing']



# Generated at 2022-06-24 18:16:15.151147
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/var/lib/awx/projects']
    warn = True
    result = list_valid_collection_paths(search_paths, warn)
    assert result == '/var/lib/awx/projects'


# Generated at 2022-06-24 18:16:24.797321
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    a = '/home/deploy/.ansible/collections'
    b = './files/ansible_collections_test_file'
    c = 'abc'
    d = '/home/deploy/.ansible/test_file'
    e = '/home/deploy/.ansible/config'
    f = '/home/deploy/ansible_collections'

    test_0 = list_valid_collection_paths([a, b, c, d, e, f])
    test_1 = list_valid_collection_paths([a, e, f])
    test_2 = list_valid_collection_paths([a, b, c, d])
    test_3 = list_valid_collection_paths([])
    test_4 = list_valid_collection_paths([a, b, e, f])


# Generated at 2022-06-24 18:16:30.467692
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(['/etc/ansible/shared/ansible_collections', '/etc/ansible/ansible_collections']) == ['/etc/ansible/shared/ansible_collections', '/etc/ansible/ansible_collections']


# Generated at 2022-06-24 18:16:32.650422
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Tests for function list_collection_dirs
    var_0 = list_collection_dirs()


if __name__ == '__main__':
    import pytest

    pytest.main(['-v', '-s', '-x', __file__])

# Generated at 2022-06-24 18:16:36.570369
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert isinstance(list_valid_collection_paths(search_paths=["/etc/ansible/collections/ansible_collections"], warn=True), (list, tuple)) is True
    assert isinstance(list_valid_collection_paths(warn=True), (list, tuple)) is True


# Generated at 2022-06-24 18:16:41.861969
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    assert isinstance(var_0, object)
    assert to_bytes(var_0) == b'<generator object list_valid_collection_paths at 0x7fcb0c8a58e0>'



# Generated at 2022-06-24 18:16:42.540985
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert True


# Generated at 2022-06-24 18:16:47.055473
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert test_case_0() is not None

# Generated at 2022-06-24 18:17:03.724299
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = set(list_valid_collection_paths(None))
    var_1 = set(['/usr/share/ansible/collections', '/etc/ansible/collections', '/usr/share/ansible'])
    assert var_0 == var_1

    var_2 = set(list_valid_collection_paths(['/usr/share/ansible/collections', '/etc/ansible/collections', '/usr/share/ansible']))
    assert var_0 == var_2

    var_3 = set(list_valid_collection_paths(['/usr/share/ansible/collections', '/etc/ansible/collections', '/usr/share/ansible', '/not/a/path']))
    assert var_0 == var_3


# Generated at 2022-06-24 18:17:05.999102
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'foo'
    str_1 = {str_0, str_0}
    var_0 = list_collection_dirs(str_0)
    for var_1 in var_0:
        var_2 = str(var_1)
        print(var_2)

if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:17:10.446377
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'foo'
    str_1 = {str_0, str_0}
    var_0 = list_valid_collection_paths(str_0)
    var_1 = set(var_0)
    int_0 = len(var_1)



# Generated at 2022-06-24 18:17:11.661673
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert 0 == 0



# Generated at 2022-06-24 18:17:13.324712
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths('foo') is not None


# Generated at 2022-06-24 18:17:18.968038
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    func = list_collection_dirs
    str_0 = {'ansible_collections/azure/azcollection'}
    str_1 = 'ansible_collections/azure/azcollection'
    str_2 = str_0
    var_0 = func(str_1, str_0)
    print(var_0)
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 18:17:26.936420
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.path.curdir, 'mypath')
    if not os.path.exists(path):
        os.mkdir(path)
    with open(os.path.join(path, 'test.txt'), 'a') as f:
        f.write('test')
    var_0 = 'foo'
    var_1 = list_collection_dirs(path)
    os.remove(os.path.join(path, 'test.txt'))

# Generated at 2022-06-24 18:17:31.084004
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    print('Test list_collection_dirs')
    test_cases = []
    test_cases.append('{}')
    test_cases.append('{}')
    test_cases.append('{}')
    test_cases.append('{}')
    test_cases.append('{}')
    test_cases.append('{}')

# Generated at 2022-06-24 18:17:35.964345
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'test_cases/test_data/test_ansible_collections'
    var_0 = list_collection_dirs(str_0)
    assert len(var_0) == 5


# Generated at 2022-06-24 18:17:36.760043
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:17:59.970488
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    from ansible.module_utils.common._collections_compat import Mapping, Iterable, Sequence, Set
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import is_collection_path

    # exercise the function
    list_valid_collection_paths()

    # ensure the right exception was raised
    # assertRaisesRegex should be used instead of assertRaisesRegexp in python3
    # assertRaisesRegexp(expected_exception, expected_regexp, callable_obj, *args, **kwargs)
    assertRaisesRegexp(AnsibleError, 'Invalid collection path', list_valid_collection_paths, str_0)

# Generated at 2022-06-24 18:18:10.432772
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_0 = to_bytes('ansible_collections')
    b_1 = os.path.join(b_0, to_bytes('ansible', errors='surrogate_or_strict'), to_bytes('collection', errors='surrogate_or_strict'))
    b_2 = os.path.join(b_0, to_bytes('ansible', errors='surrogate_or_strict'), to_bytes('collection', errors='surrogate_or_strict'))
    b_3 = os.path.join(b_0, to_bytes('ansible', errors='surrogate_or_strict'), to_bytes('collection', errors='surrogate_or_strict'))
    str_0 = 'ansible_collections'
    list_0 = get_paths('plugin')
   

# Generated at 2022-06-24 18:18:14.130729
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        str_0 = 'foo'
        dict_0 = {str_0 : str_0}
        var_0 = list_collection_dirs(str_0, dict_0)
    except Exception as e:
        print(e)
        raise
    finally:
        print('finally')

# Generated at 2022-06-24 18:18:17.575465
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Initialize function arguments
    ###########################################################################
    search_paths = ['/Users/dave/Projects/ansible_collections']

    # Execute function
    ###########################################################################
    result = list_valid_collection_paths(search_paths=search_paths)
    print(result)

# Generated at 2022-06-24 18:18:26.456087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Creating an instance of class
    obj = list_valid_collection_paths()

    # Example using AnsibleModule
    mod = AnsibleModule(
        argument_spec={}
    )

    # Example using Python
    # Example using Python with multiple values
    search_paths=['str', 1]

    # Example using Python with multiple values
    warn=True

    # Example using Python with multiple values
    actual = list_valid_collection_paths(search_paths, warn)

    # Example comparing object
    actual = list_valid_collection_paths(search_paths)

    # Example comparing object
    actual = list_valid_collection_paths()


# Generated at 2022-06-24 18:18:27.306754
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:18:28.328113
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_case_0() is None

# Generated at 2022-06-24 18:18:30.149445
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert len(list_collection_dirs(["tests/unit/utils/list_collections"])) == 2

# Generated at 2022-06-24 18:18:32.816172
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'foo'
    str_1 = [str_0, str_0]
    var_0 = list_collection_dirs(str_1)
    var_1 = next(var_0)

# Generated at 2022-06-24 18:18:39.988433
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'foo'
    str_1 = {str_0, str_0}
    str_2 = 'bar'
    str_3 = 'baz'
    list_0 = [str_0, str_0]
    list_1 = [str_0, str_0]
    list_2 = [str_0, str_0]
    list_1.extend(list_2)
    list_3 = [str_0, str_0]
    list_1.extend(list_3)
    str_4 = 'quux'
    list_4 = [str_0, str_0]
    list_1.extend(list_4)
    str_5 = '/etc/ansible/ansible.cfg'
    str_6 = '/etc/ansible/playbooks'


# Generated at 2022-06-24 18:18:52.752283
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=[]) != None, 'path not found'
    assert list_collection_dirs(search_paths=[],coll_filter=None) != None, 'path not found'


# Generated at 2022-06-24 18:18:56.702378
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Test for function list_valid_collection_paths
    """

    search_path = '/path/to/directory/ansible_collections'
    assert list_valid_collection_paths(search_path) == search_path
    pass

# Generated at 2022-06-24 18:19:02.913024
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    os.chdir('/root')
    str_in_0 = ['/home/muaz/ansible_test/', '/home/muaz/ansible_test2/', '/home/muaz/ansible_test3/']
    bool_in_1 = False
    function_result = next(list_valid_collection_paths(str_in_0, bool_in_1))
    assert function_result == '/home/muaz/ansible_test2/'


# Generated at 2022-06-24 18:19:10.682206
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['/etc/ansible', '/usr/share/ansible']
    warn = False
    ret = list(list_valid_collection_paths(search_paths, warn))
    assert ret == search_paths

    search_paths = ['/etc/ansible/does_not_exist', '/usr/share/ansible/foo']
    ret = list(list_valid_collection_paths(search_paths, warn))
    assert ret == ['/usr/share/ansible/foo']

    search_paths = ['/etc/ansible/does_not_exist', '/usr/share/ansible/foo']
    warn = True
    ret = list(list_valid_collection_paths(search_paths, warn))
    assert ret == ['/usr/share/ansible/foo']



# Generated at 2022-06-24 18:19:14.989071
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    try:
        # test case #0
        str_0 = 'fl'
        var_0 = list_collection_dirs(str_0)
        var_1 = next(var_0)
    except Exception as exception:
        # if test case failed
        raise Exception("Failed in test_list_collection_dirs")



# Generated at 2022-06-24 18:19:20.077497
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # TODO: We should use unittest.mock to create
    # a temporary path, that does not exist, and
    # remove it.
    str_0 = None
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)
    assert type(var_1) == str
    assert to_bytes(var_1) == to_bytes('/root/.ansible/collections')



# Generated at 2022-06-24 18:19:20.846486
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False


# Generated at 2022-06-24 18:19:21.835048
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 18:19:27.950512
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # These tests should pass
    # Passed search_paths should return passed list
    assert list_valid_collection_paths(search_paths=['foo', 'bar']) == ['foo', 'bar']

    # search_paths that do not exist should not be returned
    assert list_valid_collection_paths(search_paths=['/foo', 'bar', '/baz/does_not_exist']) == ['foo', 'bar']

    # If search_paths is None, default search paths should be returned
    assert list_valid_collection_paths(search_paths=None) == ['foo', 'bar']



# Generated at 2022-06-24 18:19:31.939177
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['fl']
    var_0 = list_valid_collection_paths(search_paths)
    var_1 = next(var_0)
    assert var_1 == 'fl'

# Generated at 2022-06-24 18:19:49.715720
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Uncomment these lines to run a test
    # arr_0 = {'mycoll': {'ansible.builtin': '/opt/ansible/ansible_collections/ansible/builtin'}}
    # arg_0 = ['fl', 'ansible.builtin']
    # val_0 = list_collection_dirs(arg_0)
    # assert val_0 == arr_0
    # str_0 = ['fl']
    # var_0 = list_collection_dirs(str_0)
    # var_1 = next(var_0)
    # assert var_1.endswith('ansible_collections/ns1/mycoll')
    pass


# Generated at 2022-06-24 18:19:53.035178
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'fl'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)


# Generated at 2022-06-24 18:20:03.186178
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Test case 9
    str_0 = '/etc/ansible/collections:/usr/share/ansible/collections'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)
    assert var_1 == '/etc/ansible/collections'

    # Test case 10
    str_0 = 'garbage'
    var_0 = list_valid_collection_paths(str_0)
    assert var_0 == []

    # Test case 11
    str_0 = '/etc/ansible/collections:/usr/share/ansible/collections'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)
    assert var_1 == '/etc/ansible/collections'



# Generated at 2022-06-24 18:20:06.913142
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths(['/'])) == ['/']
    assert list(list_valid_collection_paths(['/non_exist'])) == []


# Generated at 2022-06-24 18:20:12.955882
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Setup args
    str_0 = 'fl'
    # Execute function
    test_case_0()
    # Verify conditions
    assert(var_1 == '/Users/corey/.ansible/collections/ansible_collections/fl/sqa_ansible_collections/sqa_ansible_collections/')

# Generated at 2022-06-24 18:20:21.988570
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    path_1 = ['C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections',
              'C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections\\F5',
              'C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections\\ansible',
              'C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections\\netapp',
              'C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections\\gvr',
              'C:\\Users\\Administrator\\Documents\\GitHub\\ansible-collections\\ansible_collections\\rh']


# Generated at 2022-06-24 18:20:24.265377
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'fl'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)


# Generated at 2022-06-24 18:20:27.524409
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths('foo') == list(list_valid_collection_paths(['foo']))
    assert list_valid_collection_paths('foo') == list(list_valid_collection_paths('foo'))


# Generated at 2022-06-24 18:20:33.178818
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert len(list(list_valid_collection_paths(["/root/.ansible/collections/ansible_collections"]))) != 0
    assert len(list(list_valid_collection_paths(["/root/.ansible/collections/ansible_collections/fl.test-collection/tests/units"]))) == 0
    assert len(list(list_valid_collection_paths(["/root/.ansible/collections/ansible_collections/invalid.test-collection/tests/units/test_invalid_module/__pycache__"]))) == 0
    assert len(list(list_valid_collection_paths(["/root/.ansible/collections/ansible_collections/invalid.test-collection/tests/units/test_invalid_module/__pycache__/es"]))) == 0
#

# Generated at 2022-06-24 18:20:41.653848
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    config = dict()
    config['collection_paths'] = []
    config['collection_paths'].append('/Users/tomashe/ansib')
    config['collection_paths'].append('/home/tomashe/collections')
    config['collection_paths'].append('/etc/ansible/collections')
    config['collection_paths'].append('/usr/local/share/ansible/collections')
    config['collection_paths'].append('/usr/share/ansible/collections')

    res = list(list_valid_collection_paths(search_paths=config['collection_paths']))
    assert res == ['/home/tomashe/collections', '/usr/share/ansible/collections']


# Generated at 2022-06-24 18:21:06.987566
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = []
    warn = False
    result = list_valid_collection_paths(search_paths, warn)
    assert result is not None


# Generated at 2022-06-24 18:21:17.718932
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    try:
        import lib.lib_mapping
    except ImportError:
        import lib_mapping as lib_mapping
    try:
        import lib.lib_collection_loader
    except ImportError:
        import lib_collection_loader as lib_collection_loader
    try:
        import lib.lib_ansible_collections_paths
    except ImportError:
        import lib_ansible_collections_paths as lib_ansible_collections_paths
    try:
        import lib.lib_display
    except ImportError:
        import lib_display as lib_display
    try:
        import lib.lib_common_filters
    except ImportError:
        import lib_common_filters as lib_common_filters
    str_0 = 'fl'
    var_0 = lib_display.Display()

# Generated at 2022-06-24 18:21:20.446375
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    str_0 = 'fl'
    var_0 = list_valid_collection_paths(str_0)
    var_1 = next(var_0)


# Generated at 2022-06-24 18:21:23.784352
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(to_bytes('/test/test/test')) == []
    assert list_valid_collection_paths(to_bytes('/test/test/test')) == []


# Generated at 2022-06-24 18:21:33.383966
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Setup
    paths = ['path1', 'path2', 'path3']

    # Expected results
    # Expected results
    results = []
    results.append('/home/shank/ansible/ansible/ansible_collections')
    results.append('path1')
    results.append('path2')
    results.append('path3')

    # Actual results
    actual = list_valid_collection_paths(paths, warn=False)

    # Result compare
    assert set(results) == set(next(actual) for _ in range(len(results)))

    # Verify warning if search_path does not exist
    # Actual results
    actual = list_valid_collection_paths(paths, warn=True)

    pass

# Generated at 2022-06-24 18:21:34.778307
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert(test_case_0())


# Generated at 2022-06-24 18:21:36.344258
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(None, False)


# Generated at 2022-06-24 18:21:37.714057
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert callable(list_valid_collection_paths)


# Generated at 2022-06-24 18:21:46.227039
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.collections.ansible_collections.fl.plugins.module_utils.foobar import list_collection_dirs

    str_0 = 'fl'
    var_0 = list_collection_dirs(str_0)
    var_1 = next(var_0)
    assert var_1 == '/home/fitz/.ansible/collections/ansible_collections/fl/plugins/module_utils/foobar'

    list_collection_dirs('fl')

# Generated at 2022-06-24 18:21:48.359392
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # make test reproducible
    os.chdir(os.path.expanduser('~/'))
    assert True == test_case_0()

# Generated at 2022-06-24 18:23:15.874339
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths(None) == \
     ["/home/james/.ansible/collections", "/usr/share/ansible/collections"]



# Generated at 2022-06-24 18:23:18.992399
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['fl']
    collections = list_collection_dirs(search_paths)
    assert 'ansible_collections/fl' in collections


# Generated at 2022-06-24 18:23:27.760972
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert next(list_collection_dirs('false')) == '/etc/ansible/ansible_collections/ansible/false'
    assert next(list_collection_dirs('false', 'ansible')) == '/etc/ansible/ansible_collections/ansible/false'
    assert next(list_collection_dirs('false', 'ansible.false')) == '/etc/ansible/ansible_collections/ansible/false'
    assert next(list_collection_dirs('false', 'false.false')) == '/etc/ansible/ansible_collections/ansible/false'



# Generated at 2022-06-24 18:23:38.813240
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert True
    # collection_path = None
    # test_cases = (
    #     (
    #         "False positive on invalid collection path",
    #         {"collection_path": "/etc/ansible/collections"},
    #         False,
    #         False,
    #     )
    #     (
    #         "Warn on missing collection path",
    #         {"collection_path": "/etc/ansible/collections"},
    #         True,
    #         True,
    #     )
    # )
    #
    # for desc, kwargs, warn, success in test_cases:
    #     assert success == list_valid_collection_paths(warn=warn, **kwargs)



# Generated at 2022-06-24 18:23:44.509196
# Unit test for function list_valid_collection_paths

# Generated at 2022-06-24 18:23:52.425550
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = None
    coll_filter = 'fl'
    str_1 = 'fl'
    str_2 = 'fl'
    str_3 = 'fl'
    var_0 = list_collection_dirs(search_paths=str_0, coll_filter=coll_filter)
    var_1 = next(var_0)
    print(var_1)
    print('\n')
    var_2 = list_collection_dirs(search_paths=[str_1], coll_filter=coll_filter)
    var_3 = next(var_2)
    print(var_3)
    print('\n')
    var_4 = list_collection_dirs(search_paths=[str_2], coll_filter=coll_filter)
    var_5 = next(var_4)


# Generated at 2022-06-24 18:24:06.269680
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'fl'
    var_0 = list_collection_dirs(str_0)
    var_1 = next(var_0)
    assert var_1 == '/home/travis/.ansible/collections/ansible_collections/fl/chocolatey'
    str_1 = 'fl'
    var_2 = list_collection_dirs(str_1)
    var_3 = next(var_2)
    assert var_3 == '/home/travis/.ansible/collections/ansible_collections/fl/chocolatey_server'
    str_2 = 'fl'
    var_4 = list_collection_dirs(str_2)
    var_5 = next(var_4)

# Generated at 2022-06-24 18:24:17.190622
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    str_0 = 'fl'
    var_0 = list_collection_dirs(str_0)
    b_var_0 = to_bytes(var_0)

    # Ensure that type of "var_0" is "list"
    assert isinstance(var_0, list)
    # Ensure that type of "b_var_0" is "bytes"
    assert isinstance(b_var_0, bytes)

    # Ensure that next item exists in "var_0"
    var_1 = next(var_0)
    b_var_1 = to_bytes(var_1)

    # Ensure that type of "var_1" is "str"
    assert isinstance(var_1, str)
    # Ensure that type of "b_var_1" is "bytes"

# Generated at 2022-06-24 18:24:18.918224
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False


# Generated at 2022-06-24 18:24:28.128808
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    test_data = {
        'a': ['a'],
        'b': ['b', 'a'],
        'c': ['c', 'a', 'b'],
        'd': ['d', 'c', 'a', 'b']
    }

    valid_test_data = {
        'a': ['a'],
        'b': ['b', 'a'],
        'c': ['c', 'a', 'b'],
        'd': ['d', 'c', 'a', 'b']
    }

    for test_label, test_value in test_data.items():
        result = list_valid_collection_paths(test_value)
        assert set(result) == set(valid_test_data[test_label])

