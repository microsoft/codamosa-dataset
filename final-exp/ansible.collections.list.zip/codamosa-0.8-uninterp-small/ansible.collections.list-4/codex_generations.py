

# Generated at 2022-06-24 18:15:07.008778
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == '/etc/ansible/collections:/usr/share/ansible/collections'

# Generated at 2022-06-24 18:15:08.380316
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()

# Generated at 2022-06-24 18:15:10.572330
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list(list_valid_collection_paths())

    assert var_0 == []
    assert var_0 is not None

# Generated at 2022-06-24 18:15:16.357760
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    sub = [(3,4), (4,4)]
    for index in range(len(sub)):
        print("var_0 = list_valid_collection_paths({0}, {1})".format(sub[index][0], sub[index][1]))

test_list_valid_collection_paths()

# Generated at 2022-06-24 18:15:25.956883
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # Create the 'ansible_collections' directory structure
    os.mkdir('test_dir_1')
    os.mkdir('test_dir_2')

    for dir_path in [os.path.join('test_dir_1', 'ansible_collections'),
                     os.path.join('test_dir_2', 'ansible_collections')]:

        os.mkdir(dir_path)

        for ns in ['namespace1', 'namespace2']:
            ns_path = os.path.join(dir_path, ns)
            os.mkdir(ns_path)

            for coll in ['collection1', 'collection2']:
                coll_path = os.path.join(ns_path, coll)
                os.mkdir(coll_path)

# Generated at 2022-06-24 18:15:27.387520
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_case_0()


# Generated at 2022-06-24 18:15:31.779252
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    for item in list_collection_dirs(['/tmp/test_collection_loader/test_collection', '/tmp/test_collection_loader/test_collections']):
        print(item)

# Generated at 2022-06-24 18:15:35.162112
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # /var/tmp/ansible_n2QA5S/test_data/unit/module_utils/ansible/collections/ansible/collections/__init__.py:152:5
    test_case_0()

# Generated at 2022-06-24 18:15:39.277205
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        list_valid_collection_paths()
    except Exception:
        display.warning("function 'list_valid_collection_paths' was not tested. ")


# Generated at 2022-06-24 18:15:44.101260
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() == list_valid_collection_paths()


# Generated at 2022-06-24 18:15:53.717491
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_dirs = list(list_collection_dirs())
    for coll in coll_dirs:
        print(coll)



# Generated at 2022-06-24 18:15:56.548782
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert test_case_0() == None


# Generated at 2022-06-24 18:15:58.720544
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_list = list(list_collection_dirs())
    assert (len(coll_list) > 0)



# Generated at 2022-06-24 18:15:59.757510
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    test_case_0()



# Generated at 2022-06-24 18:16:01.509707
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths is not None


# Generated at 2022-06-24 18:16:06.928914
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    cwd = os.getcwd()
    dirs = [
        os.path.join(cwd, "ansible_collections"),
        os.path.join(cwd, "ansible_collections/invalid"),
        os.path.join(cwd, "ansible_collections/not_exists"),
    ]
    paths = list_valid_collection_paths(dirs, warn=True)

    assert paths
    assert len(paths) == 1

# Generated at 2022-06-24 18:16:07.945737
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()

# Generated at 2022-06-24 18:16:17.602501
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    from ansible.module_utils.basic import AnsibleModule

    module_args = {
        'search_path': [
            '/ansible/collections_root/namespace1',
            '/ansible/collections_root/namespace2',
        ],
        'coll_filter': 'namespace1.collection',

    }
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    my_search_path = module_args['search_path']
    my_coll = module_args['coll_filter']
    path = None

    for path in list_collection_dirs(search_paths=my_search_path, coll_filter=my_coll):
        pass

# Generated at 2022-06-24 18:16:20.380941
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var = list_collection_dirs()
    assert all(isinstance(x, str) for x in var)
    assert any('ansible_collections' in x for x in var)

# Generated at 2022-06-24 18:16:28.740420
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    b_coll_root = to_bytes('/Users/johnny/code/ansible', errors='surrogate_or_strict')
    b_namespace_dir = os.path.join(b_coll_root, to_bytes('foo', errors='surrogate_or_strict'))
    b_coll = to_bytes('bar', errors='surrogate_or_strict')
    assert '/Users/johnny/code/ansible/foo/bar' == os.path.join(b_namespace_dir, b_coll)
    b_coll_dir = os.path.join(b_namespace_dir, b_coll)
    assert b_coll_dir == os.path.join(b_namespace_dir, b_coll)
    with pytest.raises(AnsibleError):
        ns

# Generated at 2022-06-24 18:16:35.813474
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var = list_valid_collection_paths
    assert var == list_valid_collection_paths
    assert var == list_valid_collection_paths


# Generated at 2022-06-24 18:16:37.190041
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:16:41.039897
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # check if not isinstance of list
    if isinstance(list_valid_collection_paths(), list):
        raise AssertionError("list returned by function is not an instance of list")


# Generated at 2022-06-24 18:16:44.208291
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = next(var_0)
    var_2 = list(var_0)


# Generated at 2022-06-24 18:16:48.027865
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    var_2 = list(var_1)

# Generated at 2022-06-24 18:16:50.212379
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)


# Generated at 2022-06-24 18:16:53.595235
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    new_paths = ['.', '/test']
    var_0 = list_valid_collection_paths(new_paths)
    var_1 = list(var_0)



# Generated at 2022-06-24 18:16:59.345196
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    print('in test_list_valid_collection_paths')

    expected_result_0 = ['test_search_path1', 'test_search_path2']
    actual_result_0 = list_valid_collection_paths(['test_search_path1', 'test_search_path2'])
    assert actual_result_0 == expected_result_0

    # Not a directory
    expected_result_1 = ['test_search_path1', 'test_search_path2']
    actual_result_1 = list_valid_collection_paths(['test_search_path1', 'test_search_path2'])
    assert actual_result_1 == expected_result_1

    expected_result_2 = ['test_search_path1', 'test_search_path2']
    actual_result_2 = list_

# Generated at 2022-06-24 18:17:07.439167
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    expected_1 = [
        b'/etc/ansible/collection_paths_2',
        b'/etc/ansible/collection_paths',
    ]
    for var_1 in list_valid_collection_paths():
        assert var_1 in expected_1, 'Variable var_1 has value {}, but expected {}'.format(var_1, expected_1)
    expected_2 = b'/etc/ansible/collection_paths_2/namespace/collection_name'
    for var_2 in list_collection_dirs():
        assert var_2 in expected_2, 'Variable var_2 has value {}, but expected {}'.format(var_2, expected_2)

# Generated at 2022-06-24 18:17:08.111674
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass

# Generated at 2022-06-24 18:17:20.575857
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:17:25.225007
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    list_obj = list_valid_collection_paths()
    assert isinstance(list_obj, type(list()))
    assert len(list(list_obj)) > 0


# Generated at 2022-06-24 18:17:33.789043
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    fixture_0 = [
        '/Users/mwumel/.ansible/collections',
        '/Users/mwumel/Software/ansible_collections',
        '/Users/mwumel/Software/mwumel/ansible_collections',
        '/Users/mwumel/.ansible/plugins/modules',
        '/usr/share/ansible/plugins/modules'
    ]


# Generated at 2022-06-24 18:17:36.395015
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

if __name__ == "__main__":
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:17:42.731664
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    # Scenario 1: The namespace and collection are passed, and they exist.
    var_2 = list_collection_dirs(search_paths=['/home/user/.ansible/collections', None, '/home/user/.ansible/collections'], coll_filter='test')
    var_3 = list(var_2)
    expected_result_0 = ['/home/user/.ansible/collections/test']
    assert var_2 == expected_result_0

    # Scenario 2: The namespace and collection are passed in the wrong order.

# Generated at 2022-06-24 18:17:45.129962
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    # test here for return count
    var_2 = list_collection_dirs()
    var_3 = list(var_2)
    print(var_3)


if __name__ == '__main__':
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:17:49.734359
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    args1 = "a"
    var_1 = list(list_valid_collection_paths(args1))
    var_2 = list_valid_collection_paths(args1)

    assert var_1 == var_2


# Generated at 2022-06-24 18:17:51.580930
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths() is not None


# Generated at 2022-06-24 18:17:53.594864
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert False


# Generated at 2022-06-24 18:17:56.239342
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert var_1 == []


# Generated at 2022-06-24 18:18:10.961418
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Capture the contents of the function so that we can check
    #   the actual return type.
    func_returns = locals()
    return_type = type(func_returns['var_0'])

    assert isinstance(func_returns['var_0'], return_type)


# Generated at 2022-06-24 18:18:12.265466
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list_collection_dirs()
    var_2 = list(var_1)


# Generated at 2022-06-24 18:18:18.590555
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # mock path module for test
    class MockPath:
        class MockDirEntry:
            def __init__(self, path):
                self.path = path
        def listdir(self):
            return ['mock_namespace', 'mock_namespace_1']
        def join(self, first, second):
            return os.path.join(first, second)
        def isdir(self, path):
            return path.endswith('_dir') and os.path.isdir(path)
        def exists(self, path):
            return os.path.exists(path)
        def normpath(self, path):
            return os.path.normpath(path)
        def basename(self, path):
            return os.path.basename(path)

# Generated at 2022-06-24 18:18:20.878519
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list(list_valid_collection_paths()) == []



# Generated at 2022-06-24 18:18:30.768350
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Now let's call the function
    func_ret = list_valid_collection_paths()
    assert isinstance(func_ret, collections.Iterator)

    # Now let's call the function
    func_ret = list_valid_collection_paths(['./test_paths/test_path_a'])
    assert isinstance(func_ret, collections.Iterator)

    # Now let's call the function
    func_ret = list_valid_collection_paths(['./test_paths'])
    assert isinstance(func_ret, collections.Iterator)



# Generated at 2022-06-24 18:18:33.883363
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # From local variable
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)

    assert var_1 is not None
    assert var_0 is not None
    assert var_1 == var_0

# Generated at 2022-06-24 18:18:38.710999
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    """
    Passing search_paths=None
    Filtering for non-existing or invalid paths
    Checking for type of return value
    """
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    assert len(var_0) == var_1
    assert len(var_0) > 0


# Generated at 2022-06-24 18:18:51.067976
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    #
    # 1.
    #
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

    #
    # 2.
    #
    var_0 = list_collection_dirs(coll_filter='ansible_collections.namespace.ansible_collections.sub_namespace.sub_sub_namespace.collection')

    #
    # 3.
    #
    var_0 = list_collection_dirs(coll_filter='ansible_collections.namespace.ansible_collections.sub_namespace.sub_sub_namespace')

    #
    # 4.
    #
    var_0 = list_collection_dirs(coll_filter='ansible_collections.namespace.ansible_collections.sub_namespace')

    #


# Generated at 2022-06-24 18:18:56.454202
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Test case:
    # test that a collection path returns valid full path
    # use default search path
    can_list_collection_dirs = False
    try:
        list_dirs = list_collection_dirs()
        if list_dirs:
            can_list_collection_dirs = True

    except Exception as err:
        # Do nothing
        pass

    assert can_list_collection_dirs


if __name__ == '__main__':
    test_list_collection_dirs()

# Generated at 2022-06-24 18:19:00.970651
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    search_paths = ['./test-data/collections/lib']
    var_0 = list_valid_collection_paths(search_paths, False)
    var_1 = list(var_0)
    assert var_1 == ['./test-data/collections/lib']



# Generated at 2022-06-24 18:19:35.457701
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    try:
        list_collection_dirs(coll_filter='fake.not_there')
        assert False, "Did not fail on non-existent collection"
    except:
        pass

    import os
    try:
        path = os.path.join('library/fake', 'ansible_collection')
        list_collection_dirs(coll_filter=path)
        assert False, "Did not fail on non-existent ansible-collection path"
    except:
        pass

    try:
        path = os.path.join('library/', 'ansible_collection')
        list_collection_dirs(coll_filter=path)
        assert False, "Did not fail on non-existent ansible-collection path"
    except:
        pass


# Generated at 2022-06-24 18:19:36.970120
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert not test_case_0()

# Generated at 2022-06-24 18:19:48.434647
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import ansible.module_utils.collection_loader
    PATH = ansible.module_utils.collection_loader.get_collections_path()
    SEARCH_PATHS = ['', '', '', '']
    SEARCH_PATHS[0] = 'tests/fixtures/test_collection_loader/test_0'
    SEARCH_PATHS[1] = 'tests/fixtures/test_collection_loader/test_1'
    SEARCH_PATHS[2] = 'tests/fixtures/test_collection_loader/test_2_nonexistent'
    SEARCH_PATHS[3] = 'tests/fixtures/test_collection_loader/test_3'

# Generated at 2022-06-24 18:19:49.831126
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs() == None


# Generated at 2022-06-24 18:19:53.219225
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    ret = list_collection_dirs()


if __name__ == '__main__':
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:20:03.344890
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    import tempfile

    # Path and folder set up
    temp_dir = tempfile.mkdtemp()
    temp_path_1 = tempfile.mktemp(dir=temp_dir)
    temp_path_2 = tempfile.mkdtemp(dir=temp_dir)

    test_paths = [temp_path_1, temp_path_2]

    # Test case with one valid path and one invalid path
    assert list_valid_collection_paths(search_paths=test_paths, warn=False) == test_paths, \
        "function list_valid_collection_paths() did not return all paths"

    # Test default search path

# Generated at 2022-06-24 18:20:14.810649
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_0 = 'cloud.azure'
    coll_1 = 'cloud.azure.azcollection'
    list_0 = ['cloud.azure']
    list_1 = ['cloud.azure', 'cloud.azure.azcollection']
    list_2 = ['cloud.azure.azcollection']
    list_3 = ['unknown.collection']
    list_4 = []
    list_5 = ['cloud.azure', 'cloud.azure.azcollection', 'unknown.collection']
    list_6 = ['cloud.azure', 'cloud.azure.azcollection', 'unknown.collection', 'cloud.azure.azcollection']
    list_7 = ['cloud.azure.azcollection', 'cloud.azure', 'unknown.collection']

# Generated at 2022-06-24 18:20:19.381272
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    # Check that function list_collection_dirs returns `str` or `bytes`
    def check_collection_dir(coll_dir):
        assert type(coll_dir) in [str, bytes]
    # Test with search_path None
    for collection_dir in list_collection_dirs():
        check_collection_dir(collection_dir)
    # Test with search_path not None
    for collection_dir in list_collection_dirs(search_paths=['./test/unit/collections/config']):
        check_collection_dir(collection_dir)

# Generated at 2022-06-24 18:20:28.160087
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():

    # Test paths are generated correctly
    assert list_valid_collection_paths() == list(list_valid_collection_paths())

    # Test if search_paths is used correctly
    assert list_valid_collection_paths(search_paths=['test_path']) == list(list_valid_collection_paths(
        search_paths=['test_path']))

    # Test if warn is used correctly
    assert list_valid_collection_paths(warn=True) == list(list_valid_collection_paths(warn=True))

    # Test if search_paths and warn are used correctly

# Generated at 2022-06-24 18:20:29.102772
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    assert list_valid_collection_paths()


# Generated at 2022-06-24 18:21:07.818313
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:21:12.286386
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    arg_0 = None
    arg_1 = None
    var2 = list_collection_dirs(arg_0, arg_1)
    assert isinstance(var2, list)


# Generated at 2022-06-24 18:21:15.646525
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    var_0 = list_valid_collection_paths()
    var_1 = list(var_0)
    expected = ['/etc/ansible/collections', '/usr/share/ansible/collections']
    assert var_1 == expected


# Generated at 2022-06-24 18:21:16.483007
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list(list_collection_dirs())

# Generated at 2022-06-24 18:21:18.011662
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_2 = list_collection_dirs()
    var_3 = list(var_2)

# Generated at 2022-06-24 18:21:21.461841
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_1 = list(list_collection_dirs())
    assert len(var_1) != 0

if __name__ == "__main__":
    print("Test: list_collection_dirs")
    test_list_collection_dirs()

# Generated at 2022-06-24 18:21:22.474995
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    pass


# Generated at 2022-06-24 18:21:27.506875
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # This test test the basic functionality of the list_valid_collection_paths function.
    # n.b. this test will fail if run outside of the test-framework.
    #      This is an implementation detail of this test and is not representative of how the list_valid_collection_paths function should be called in real code.
    assert test_case_0() is None


# Generated at 2022-06-24 18:21:29.801965
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    coll_paths = list(list_collection_dirs())
    assert len(coll_paths) >= 2

# Generated at 2022-06-24 18:21:40.848317
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    path = os.path.join(os.getcwd(), 'test')

    if os.path.exists(path):

        os.rmdir(os.path.join(path, 'collections_ansible'))
        os.rmdir(os.path.join(path, 'ansible_collections'))
        os.rmdir(path)

    os.makedirs(os.path.join(path, 'ansible_collections'))
    os.makedirs(os.path.join(path, 'ansible_collections/test/test'))
    os.makedirs(os.path.join(path, 'collections_ansible'))
    os.makedirs(os.path.join(path, 'collections_ansible/test'))

# Generated at 2022-06-24 18:23:07.540547
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    arg_0 = 'my_collection'
    var_0 = list_collection_dirs(coll_filter=arg_0)
    var_1 = list(var_0)

if __name__ == "__main__":
    print(vars())
    test_case_0()
    test_list_collection_dirs()

# Generated at 2022-06-24 18:23:09.255617
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    assert list_collection_dirs(search_paths=None, coll_filter=None)


# Generated at 2022-06-24 18:23:09.756166
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    pass

# Generated at 2022-06-24 18:23:14.257135
# Unit test for function list_collection_dirs
def test_list_collection_dirs():

    search_paths = ["/tmp", "/tmp/foo/bar"]
    coll_filter = "my_ns"

    # Testing with the default value for coll_filter
    test_case_1(search_paths)

    # Testing with coll_filter set to 'my_ns'
    test_case_2(search_paths, coll_filter)



# Generated at 2022-06-24 18:23:15.651629
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:23:25.202998
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    # Make sure we are running as root, otherwise the following tests will fail.
    if os.geteuid() != 0:
        assert "Not running as root, skipping tests"
        return
    assert not os.path.exists('/v1/collection')

# Generated at 2022-06-24 18:23:31.188855
# Unit test for function list_valid_collection_paths
def test_list_valid_collection_paths():
    try:
        test_case_0()
    except Exception as e:
        display.error("Error executing unittest for list_valid_collection_paths: %s" % to_text(e))
        raise e



# Generated at 2022-06-24 18:23:33.568119
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    var_0 = list_collection_dirs()
    var_1 = list(var_0)

# Generated at 2022-06-24 18:23:37.956748
# Unit test for function list_collection_dirs
def test_list_collection_dirs():
    search_paths = ['test/data/collections/a', 'test/data/collections/b', 'test/data/collections/c']
    coll_filter = 'test_collection'

# Generated at 2022-06-24 18:23:46.604028
# Unit test for function list_valid_collection_paths