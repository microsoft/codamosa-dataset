

# Generated at 2022-06-25 04:54:13.795298
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_1 = FieldAttributeBase()

    data = {
        "foo": [1, 2, 3],
        "bar": [],
        "baz": ["qux", "quux", "quuz"],
        "corge": None,
        "grault": "garply",
        "waldo": "fred",
        "fred": ["plugh", "xyzzy", 3],
        "plugh": True,
        "xyzzy": False,
        "thud": "",
        "abc": r"hello world!",
        "def": u"unicode",
        "obj": {
            "name": "one_obj"
        }
    }

    field_attribute_base_1.deserialize(data)
    assert field_attribute_base_1._attributes == data

# Unit test

# Generated at 2022-06-25 04:54:17.239273
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    expected = None
    actual = field_attribute_base_0.get_validated_value(None, None, None, None)
    assert expected == actual


# Generated at 2022-06-25 04:54:26.876859
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    class Foo(FieldAttributeBase):
        # FIXME: can't get the types import to work, so using strings for now
        #_valid_attrs = { 'one': FieldAttribute(isa=string_types, default='one'), 'two': FieldAttribute(isa=string_types, default='two') }
        _valid_attrs = { 'one': FieldAttribute(), 'two': FieldAttribute(default='two', private=True) }

    obj = Foo()
    obj.two = 'two override'

    combined = obj.squash()

    assert combined.one == 'one'
    assert combined.two == 'two override'
    assert combined.two is not obj.two


# Generated at 2022-06-25 04:54:28.457117
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    templar = Templar()
    field_attribute_base.post_validate(templar)


# Generated at 2022-06-25 04:54:34.525644
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # test case 1
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0
    field_attribute_base_0.validate("name1", "isa1", "default1", "required1", "static")

    # test case 2
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1
    with pytest.raises(AnsibleAssertionError):
        field_attribute_base_1.validate("name2", "isa2", "default2", "required2")

    # test case 3
    field_attribute_base_2 = FieldAttributeBase()
    assert field_attribute_base_2

# Generated at 2022-06-25 04:54:39.408392
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase.copy(field_attribute_base_0)
    assert field_attribute_base_1._loader is None


# Generated at 2022-06-25 04:54:43.436049
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # initialize object to test
    field_attribute_base_0 = FieldAttributeBase()
    result = field_attribute_base_0.dump_me()

    assert isinstance(result, string_types)

# Generated at 2022-06-25 04:54:46.722522
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    field_attribute_base_0 = FieldAttributeBase()
    task_0 = Base()
    assert task_0.get_search_path() == []
    assert field_attribute_base_0.get_search_path() == []


# Generated at 2022-06-25 04:54:49.860009
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # If no exception raised, that means the method works.
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.get_validated_value('attr_name', 'attrs_value', 'text_value', 'templar')



# Generated at 2022-06-25 04:54:53.247731
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_attrs()
    assert field_attribute_base_0._valid_attrs == dict()
    assert field_attribute_base_0._attributes == dict()


# Generated at 2022-06-25 04:55:20.658081
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'fake_name'
    field_attribute_base_0.description = 'fake_description'
    field_attribute_base_0.required = True
    field_attribute_base_0.default = 'fake_default'
    field_attribute_base_0.static = True
    field_attribute_base_0.always_post_validate = True
    field_attribute_base_0.validator = 'fake_validator'
    field_attribute_base_0.immutable = True
    field_attribute_base_0.fallback = 'fake_fallback'
    field_attribute_base_0.isidentifier = True
    field_attribute_base_0.isparam = True

# Generated at 2022-06-25 04:55:24.268471
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    if base_0.get_dep_chain() is None:
        print ("Test 1 : pass")
    else:
        print ("Test 1 : fail")
    # base_1 = Base()
    # if base_1.get_dep_chain() not None:
    #     print "Test 2 : pass"
    # else:
    #     print "Test 2 : fail"


# Generated at 2022-06-25 04:55:27.306234
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._post_validate_base_class()


# Generated at 2022-06-25 04:55:35.983668
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    # Check that the return type is correct.
    assert isinstance(field_attribute_base_1, FieldAttributeBase)
    # When there are no arguments, __new__ should return an instance of cls.
    field_attribute_base_2 = FieldAttributeBase()
    # Check that the return type is correct.
    assert isinstance(field_attribute_base_2, FieldAttributeBase)
    # When BaseMeta.__new__ is called with arguments, the arguments are passed
    # to type.__new__.
    field_attribute_base_3 = FieldAttributeBase()
    # Check that the return type is correct.
    assert isinstance(field_attribute_base_3, FieldAttributeBase)


# Generated at 2022-06-25 04:55:44.698893
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    o = FieldAttributeBase()
    ansible_mod_path = '/usr/lib/python2.7/site-packages/ansible/module_utils/facts'
    if os.path.exists(ansible_mod_path):
        module_utils_path = ansible_mod_path
    else:
        module_utils_path = os.path.join(ansible_mod_path, '..')

    sys.path.append(module_utils_path)
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.system.distribution as distribution
    o._post_validate_name('name','','','')
    o._post_validate_always_run('always_run','','','')
    o._post_validate_local_action

# Generated at 2022-06-25 04:55:46.181571
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_me() == ""

# Generated at 2022-06-25 04:55:48.984281
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Setup
    field_attribute_base_0 = FieldAttributeBase()
    # teardown

    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 04:55:52.733155
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create a FieldAttributeBase object
    field_attribute_base_0 = FieldAttributeBase()
    # Use the copy method
    # field_attribute_base_0.copy()
    # Output the result
    # print(field_attribute_base_0)


# Generated at 2022-06-25 04:55:54.573620
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.ds = None
    field_attribute_base_0.get_ds()


# Generated at 2022-06-25 04:56:03.491682
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._loader = DataLoader()
    field_attribute_base_0._variable_manager = VariableManager()

    ansible_0 = Ansible()
    ansible_0._ds = None
    ansible_0._ds_tried = False
    ansible_0._loader = DataLoader()
    ansible_0._variable_manager = VariableManager()

    os_0 = OS()
    os_0._ds = None

    task_0 = Task()
    task_0._ds = None
    task_0._ds_tried = False

    field_attribute_base_0._ds = ansible_0
    assert field_attribute_base_0.get_ds() == field_attribute_base_0._ds

    field_attribute_base_

# Generated at 2022-06-25 04:56:32.907036
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Data setup
    data = {}
    # Test 0
    field_attribute_base_0 = FieldAttributeBase()
    deserialize_ret = field_attribute_base_0.deserialize(data)
    assert deserialize_ret is None, "Error with deserialize"



# Generated at 2022-06-25 04:56:44.361587
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # test for attr isa = string
    attr = {'isa': 'string'}
    value = FieldAttributeBase().get_validated_value('name', attr, 'test_text', None)
    assert type(value) == str
    assert value == 'test_text'

    # test for attr isa = int
    attr = {'isa': 'int'}
    value = FieldAttributeBase().get_validated_value('name', attr, '1', None)
    assert type(value) == int
    assert value == 1

    # test for attr isa = float
    attr = {'isa': 'float'}
    value = FieldAttributeBase().get_validated_value('name', attr, '1', None)
    assert type(value) == float
    assert value == 1.0

# Generated at 2022-06-25 04:56:49.777973
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # test invalid type for isa
    ba = FieldAttributeBase(name='bar', isa='foobar', default='value')
    try:
        ba.validate()
        assert False, 'Expected a ValueError'
    except ValueError:
        pass
    # test invalid type for listof
    ba = FieldAttributeBase(name='bar', isa='list', listof='foobar')
    try:
        ba.validate()
        assert False, 'Expected a ValueError'
    except ValueError:
        pass


# Generated at 2022-06-25 04:56:55.671917
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_data = [
    ]
    for d in test_data:
        # check if the target function works
        with pytest.raises(AssertionError) as exc_info:
            field_attribute_base_0 = FieldAttributeBase()
            field_attribute_base_0.dump_me()
        # check if the test case suits the exception raised
        assert str(d['raise_exc']) in str(exc_info.value)


# Generated at 2022-06-25 04:56:57.313881
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    for obj in objects:
        obj.from_attrs(attrs)


# Generated at 2022-06-25 04:57:07.323226
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_0 = FieldAttribute(isa='string')
    field_attribute_1 = FieldAttribute(isa='int')
    field_attribute_2 = FieldAttribute(isa='float')
    field_attribute_3 = FieldAttribute(isa='bool')
    field_attribute_4 = FieldAttribute(isa='list')
    field_attribute_5 = FieldAttribute(isa='set')
    field_attribute_6 = FieldAttribute(isa='dict')
    field_attribute_7 = FieldAttribute(isa='class')
    field_attribute_8 = FieldAttribute(isa='string', listof=tuple)
    field_attribute_9 = FieldAttribute(isa='string', listof=list)
    field_attribute_10 = FieldAttribute(isa='string', listof=string_types)
    field

# Generated at 2022-06-25 04:57:16.138293
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test default case
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.get_dep_chain()
    # Test with a parent that has no _parent
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1._parent = 0
    field_attribute_base_1.get_dep_chain()
    # Test with a parent that has a parent with a _parent
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_2._parent = field_attribute_base_1
    field_attribute_base_2.get_dep_chain()
    # Test when _parent has a dep_chain
    field_attribute_base_1._parent = field_attribute_base_0
    field_attribute_base_2.get_dep_

# Generated at 2022-06-25 04:57:22.021429
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # check first to see if field exists

    field_attribute_base_0 = FieldAttributeBase()

    unittest.TestCase.assertTrue(hasattr(field_attribute_base_0, '__FieldAttributeBase_validate'))



# Generated at 2022-06-25 04:57:23.745688
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.post_validate('templar')


# Generated at 2022-06-25 04:57:28.219955
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_1 = FieldAttributeBase()
    obj_2 = { 'a': '1', 'b': 2 }
    field_attribute_base_1.load_data(obj_2)

# Test case for method load_data of class FieldAttributeBase

# Generated at 2022-06-25 04:57:58.237754
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize('data')


# Generated at 2022-06-25 04:58:08.339045
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Create an instance of FieldAttributeBase for attribute with type
    # 'str'
    field_attribute_base_str = \
        FieldAttributeBase(isa='str')
    # Try to validate an invalid value
    with pytest.raises(TypeError):
        field_attribute_base_str.validate(field_attribute_base_str, None, 1)
    # Try to validate an invalid value
    with pytest.raises(TypeError):
        field_attribute_base_str.validate(field_attribute_base_str, None, 1.0)

    # Create an instance of FieldAttributeBase for attribute with type
    # 'int'
    field_attribute_base_int = \
        FieldAttributeBase(isa='int')
    # Try to validate an invalid value
    with pytest.raises(TypeError):
        field

# Generated at 2022-06-25 04:58:09.260922
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:58:16.617369
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()

    decoded_object_0 = field_attribute_base_0.load_data({})
    assert isinstance(decoded_object_0, dict)
    assert decoded_object_0 == {}

    decoded_object_1 = field_attribute_base_1.load_data([])
    assert isinstance(decoded_object_1, list)
    assert decoded_object_1 == []


# Generated at 2022-06-25 04:58:22.367744
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    FAKE_VALUE = 'foo'
    assert field_attribute_base_0.get_validated_value(FAKE_VALUE, FAKE_VALUE, FAKE_VALUE, FAKE_VALUE) == FAKE_VALUE


# Generated at 2022-06-25 04:58:24.958506
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = field_attribute_base_0.dump_attrs()
    assert isinstance(attrs, dict)


# Generated at 2022-06-25 04:58:30.242049
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    test_case_0()
    field_attribute_base_0 = FieldAttributeBase()
    print("test_BaseMeta___new__")
    print(field_attribute_base_0)
    print("test_BaseMeta___new__ end")


__all__ = ['Base']



# Generated at 2022-06-25 04:58:35.333679
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # called without parameters -> AnsibleParserError thrown
    assertRaises(AnsibleParserError, FieldAttributeBase.post_validate, None, None)


# Generated at 2022-06-25 04:58:36.381706
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_var = FieldAttributeBase()
    my_var.post_validate()


# Generated at 2022-06-25 04:58:41.304503
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_1 = FieldAttributeBase()
    name_value = 'some_name'
    attribute_value = FieldAttribute(name='attribute_name')
    value_value = 'some_value'
    templar_value = 'some_templar'
    value = field_attribute_base_1.get_validated_value(name=name_value, attribute=attribute_value, value=value_value, templar=templar_value)
    assert value is None, "Value is %s" % value


# Generated at 2022-06-25 04:59:15.245474
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = {'name': 'test', 'foo': 'bar'}
    field_attribute_base_0.from_attrs(attrs)


# Generated at 2022-06-25 04:59:17.980671
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create a FieldAttributeBase object
    field_attribute_base = FieldAttributeBase()

    # Test for correct type
    assert isinstance(field_attribute_base, FieldAttributeBase)


# Generated at 2022-06-25 04:59:21.356307
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    data = field_attribute_base_0.dump_me()
    if data is not None:
        print("FieldAttributeBase_dump_me method PASSED")
    else:
        print("FieldAttributeBase_dump_me method FAILED")


# Generated at 2022-06-25 04:59:27.107579
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    field_attribute_base_0 = FieldAttributeBase()
    templar_0 = Templar()
    field_attribute_base_0.post_validate(templar=templar_0)
    assert True



# Generated at 2022-06-25 04:59:34.071810
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_get_validated_value_0 = FieldAttributeBase()
    name = 'name'
    attribute = 'attribute'
    value = 'value'
    templar = 'templar'
    result = field_attribute_base_get_validated_value_0.get_validated_value(name, attribute, value, templar)

    assert(result == value)


# Generated at 2022-06-25 04:59:44.877251
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Create a 'parent' object to squash against
    test_0 = FieldAttributeBase()
    test_0.name = "object1"
    test_0.role = "first_role"
    test_0._attributes = dict()
    test_0._attribute_defaults = dict()
    test_0._attr_defaults = dict()
    test_0.any_errors_fatal = False
    test_0.always_post_validate = False
    test_0.become = False
    test_0._loader = None
    test_0.notify = False
    test_0.register = False
    test_0.static = True
    test_0._variable_manager = None
    test_0._validated = False
    test_0._finalized = False
    test_0._squashed = False

# Generated at 2022-06-25 04:59:48.786589
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    FA = FieldAttributeBase()
    FA.release = "0.0.1"
    FA.post_validate()
    FA.release = None
    FA.post_validate()


# Generated at 2022-06-25 04:59:52.241870
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()


# Generated at 2022-06-25 05:00:01.952038
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    attr_name = field_attribute_base_0._load_data('Attribute name', 'test_var', '')
    assert attr_name == 'test_var', "test_FieldAttributeBase_load_data_0: expecting attr_name == 'test_var'"

    attr_alias = field_attribute_base_0._load_data('Attribute alias', 'test', '')
    assert attr_alias == 'test', "test_FieldAttributeBase_load_data_1: expecting attr_alias == 'test'"

    attr_required = field_attribute_base_0._load_data('Attribute required', 'True', '')
    assert attr_required == True, "test_FieldAttributeBase_load_data_2: expecting attr_required == True"

   

# Generated at 2022-06-25 05:00:12.361093
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Just in case someone forgets to add the tests for a new datatype
    exit_code = False

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0_show = field_attribute_base_0.get_validated_value(
        'name',
        AttributeField(isa='bool'),
        'True',
        'templar'
    )

    # Unit tests for type checking
    assert isinstance(field_attribute_base_0_show, boolean)

    # Unit tests for input checking
    with pytest.raises(AnsibleParserError) as error_info_0:
        field_attribute_base_0.get_validated_value(
            'name',
            AttributeField(isa='bool'),
            'no',
            'templar'
        )

# Generated at 2022-06-25 05:00:43.380981
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    assert isinstance(field_attribute_base_0, FieldAttributeBase)
    assert False # find a way to test this method


# Generated at 2022-06-25 05:00:45.556646
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()



# Generated at 2022-06-25 05:00:51.817130
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_1 = FieldAttributeBase()
    try:
        field_attribute_base_1.post_validate(templar='templar')
    except ValueError as e:
        assert type(e) == ValueError


# Generated at 2022-06-25 05:00:56.575915
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.load_data(attr_arg=None, attr_name='', field_name='',
                                     value=None, ds=None, isa=None)
    #print field_attribute_base_1


# Generated at 2022-06-25 05:01:03.782444
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    # Attribute '_loader' of class FieldAttributeBase is of type object and its value is None, which is not of type object
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._valid_attrs = {'_loader': Object(), '_variable_manager': Object(), '_validated': False}
    field_attribute_base_0._variable_manager = Object()
    field_attribute_base_1.load_data(dict(loader=Object(), variable_manager=Object(), validated=False, name='test'))
    assert field_attribute_base_0.dump_attrs() == {'_loader': Object(), '_variable_manager': Object(), '_validated': False}


# Generated at 2022-06-25 05:01:12.135020
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-25 05:01:14.085542
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()


# Generated at 2022-06-25 05:01:22.544383
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # ansible 2.5 dropped support for python2.6,
    # we don't need to test it here
    if PY2 and sys.version_info[1] <7:
        return

    field_attribute_base = FieldAttributeBase()

    args = [None, None, None, None]
    assert field_attribute_base.get_validated_value(*args) is None

    args = ['name', FieldAttribute(isa='string', default='default_name'),
            'validate me', 'templar']
    assert field_attribute_base.get_validated_value(*args) == 'validate me'

    args = ['name', FieldAttribute(isa='int', default=1), '2', 'templar']
    assert field_attribute_base.get_validated_value(*args) == 2


# Generated at 2022-06-25 05:01:26.938590
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    """
    FieldAttributeBase.deserialize test cases
    """
    data = {"__type__": "FieldAttributeBase"}
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize(data)
    assert field_attribute_base_0


# Generated at 2022-06-25 05:01:33.456924
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base()
    base_0._parent = field_attribute_base_0
    assert base_0.get_dep_chain() == field_attribute_base_0, "inst.get_dep_chain() != field_attribute_base_0"


# Generated at 2022-06-25 05:02:06.535742
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.squash()
    except AssertionError:
        pass
    else:
        raise AssertionError('AnsibleAssertionError exception expected, but none thrown')


# Generated at 2022-06-25 05:02:09.874985
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    print("Testing FieldAttributeBase.post_validate")

    field_attribute_base_0 = FieldAttributeBase()

    field_attribute_base_0.post_validate(templar=AnsibleTemplar())

    print("FieldAttributeBase.post_validate: PASS")


# Generated at 2022-06-25 05:02:11.504381
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Setup
    base_0 = Base()
    # Result
    result_0 = base_0.get_path()


# Generated at 2022-06-25 05:02:13.001457
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 05:02:15.173190
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 05:02:26.830525
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    name_0 = 'abc'
    field_attribute_base_0.name = name_0
    dflt_0 = None
    field_attribute_base_0.default = dflt_0
    doc_0 = 'abc'
    field_attribute_base_0.doc = doc_0
    req_0 = False
    field_attribute_base_0.required = req_0
    s_0 = True
    field_attribute_base_0.static = s_0
    isa_0 = 'abc'
    field_attribute_base_0.isa = isa_0
    env_0 = 'abc'
    field_attribute_base_0.env = env_0
    f_0 = None
    field_attribute_base_0.private = f

# Generated at 2022-06-25 05:02:28.177938
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    name = 'field_attribute_base'
    parents_0 = (Attribute,)
    dct_0 = {'default': object()}
    BaseMeta.__new__(BaseMeta, name, parents_0, dct_0)



# Generated at 2022-06-25 05:02:33.821891
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()
    assert field_attribute_base_1 is not None
    assert field_attribute_base_1._name == 'FieldAttributeBase'
    assert field_attribute_base_1._parent == None
    assert field_attribute_base_1._data == {}


# Generated at 2022-06-25 05:02:45.747214
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    f = FieldAttributeBase()
    t = Templar(loader=DictDataLoader({'foo': 'value'}))

    field_attribute_base_0_value = f.get_validated_value('name', FieldAttribute('name', 'int'), '1234', t)
    assert field_attribute_base_0_value == 1234

    field_attribute_base_1_value = f.get_validated_value('name', FieldAttribute('name', 'float'), '1234', t)
    assert field_attribute_base_1_value == 1234.0

    field_attribute_base_2_value = f.get_validated_value('name', FieldAttribute('name', 'bool'), 'true', t)
    assert field_attribute_base_2_value is True

    field_attribute_base_3_value = f.get

# Generated at 2022-06-25 05:02:50.966854
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    print('Test get_dep_chain of class Base')
    # Create an instance of Base
    base_0 = Base()
    # Create an instance of Base
    base_1 = Base()
    # Create an instance of Base
    base_2 = Base()
    # Create a variable to store the attribute _parent of base_2
    base_2_parent = base_1
    setattr(base_2, '_parent', base_2_parent)
    # Create a variable to store the attribute _parent of base_1
    base_1_parent = base_0
    setattr(base_1, '_parent', base_1_parent)
    # Call method get_dep_chain of base_2
    dep_chain = base_2.get_dep_chain()
    # Check that the returned list is [base_0, base_