

# Generated at 2022-06-25 04:54:18.437727
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Create class instances for test
    field_attribute_base_0 = FieldAttributeBase()
    # Check failure for missing 'attribute'
    # Load dictionary with data to use for call
    data = dict()
    data['attribute_type'] = 'String'
    data['always_post_validate'] = True
    data['required'] = True
    data['isa'] = 'dict'
    data['default'] = {}
    data['static'] = True
    data['error'] = 'This field is required'
    try:
        field_attribute_base_0.load_data(data)
    except:
        pass
    # Check failure for missing 'attribute_type'
    # Load dictionary with data to use for call
    data = dict()
    data['attribute'] = 'name'
    data['always_post_validate'] = True

# Generated at 2022-06-25 04:54:26.934592
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Python types to be tested
    valid_types = [int, float, bool, string_types, list, set, dict]

    # Test each valid case
    for valid_type in valid_types:
        ansible_obj = FieldAttributeBase(isa=valid_type)
        ansible_obj.validate()

    # Invalid types
    invalid_types = [None, 'something_else']

    # Test each invalid case
    for invalid_type in invalid_types:
        ansible_obj = FieldAttributeBase(isa=invalid_type)
        exc = None
        try:
            ansible_obj.validate()
        except Exception as e:
            exc = e

        assert isinstance(exc, Exception)


# Generated at 2022-06-25 04:54:30.158055
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_1 = FieldAttributeBase()
    post_validate_exceptions = []
    try:
        field_attribute_base_1.post_validate()
    except Exception as e:
        post_validate_exceptions.append(e)
    assert len(post_validate_exceptions) > 0, "Unit test for method post_validate of class FieldAttributeBase failed"


# Generated at 2022-06-25 04:54:35.506660
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    filepath_0 = field_attribute_base_0.get_path()
    # Test passes if filepath_0 and filepath_1 are equal
    assert filepath_0 == os.path.realpath(__file__) + ":186"


# Generated at 2022-06-25 04:54:37.116081
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    ansible_assertion_0 = type(field_attribute_base_0.deserialize({}))
    assert(ansible_assertion_0 == dict)


# Generated at 2022-06-25 04:54:41.059260
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_validated_value('name', attribute) == value


# Generated at 2022-06-25 04:54:48.353599
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    """
    Unit test for method dump_me of class FieldAttributeBase
    """
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1.dump_me() == {'is_list': False, 'is_template': True, 'is_static': False, 'required': False, 'default': None, 'version_added': None, 'version_removed': None, 'aliases': [], 'removed_in_version': None, 'alt_name': None, 'add_finalizer': False, 'always_post_validate': True}


# Generated at 2022-06-25 04:54:55.602135
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    #
    # Set up
    #

    # Define the attribute type
    attribute_type = FieldAttribute()

    # Make a field
    field_attribute_base_0 = FieldAttributeBase(attribute_type)

    #
    # Set up test cases
    #

    # Each test case should be a dictionary with:
    # - test_name: the name of the test
    # - pre_attrib_value: the value that should be set before validation
    # - pre_validation: a list of functions that should be evaluated
    #                   before validation
    # - post_validation: a list of functions that should be evaluated
    #                    after validation
    # - expect_errors: a list of errors we expect to see raised
    # - expect_valid: a list of functions that should be evaluated to
    #                 determine if the validate was successful


# Generated at 2022-06-25 04:55:00.853941
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    
    with mock.patch('ansible.parsing.utils.object_finder.AnsibleFileFinder.find_file') as mock_AnsibleFileFinder_find_file:
        mock_AnsibleFileFinder_find_file.side_effect = IOError()
        # The call to the method being tested is inside a try block
        try:
            mock_AnsibleFileFinder_find_file.return_value = 'ansible/lib/ansible/parsing/yaml/objects/task.py'
            field_attribute_base_0.get_dep_chain()
        # The assertion being tested
        except IOError as err:
            assert err.strerror == 'No such file or directory'



# Generated at 2022-06-25 04:55:09.380384
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    assert (field_attribute_base_0.get_validated_value(None, None, None, None) is None)
    assert (field_attribute_base_0.get_validated_value('name', 'name', 'name', 'name') == 'name')
    assert (field_attribute_base_0.get_validated_value(1, 1, 1, 1) == 1)
    assert (field_attribute_base_0.get_validated_value(0.5, 0.5, 0.5, 0.5) == 0.5)
    assert (field_attribute_base_0.get_validated_value(True, True, True, True) is True)

# Generated at 2022-06-25 04:55:37.867636
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base_0 = Base()
    assert isinstance(base_0.get_search_path(), list)


# Generated at 2022-06-25 04:55:49.944437
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.isa = 'string'
    field_attribute_base_0.name = 'name'
    field_attribute_base_0.parent = 'parent'
    field_attribute_base_0.default = None
    field_attribute_base_0.static = False
    field_attribute_base_0.required = False
    field_attribute_base_0.always_post_validate = False
    field_attribute_base_0.allow_duplicates = False
    field_attribute_base_0.apply_default_to_meta = False
    field_attribute_base_0.default_if_none_set = False
    field_attribute_base_0.class_type = None
    field_attribute_base_0.listof = string

# Generated at 2022-06-25 04:55:50.963058
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # Create instance of class BaseMeta
    base_meta_instance = BaseMeta()



# Generated at 2022-06-25 04:55:54.636295
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    assert(field_attribute_base_0.dump_attrs() == {})


# Generated at 2022-06-25 04:55:58.413892
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    field_attribute_base_0 = FieldAttributeBase()
    result = field_attribute_base_0.get_search_path()
    assert result == None


# Generated at 2022-06-25 04:56:00.412277
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    post_validate_0 = FieldAttributeBase()
    post_validate_0.post_validate()


# Generated at 2022-06-25 04:56:04.812787
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    data = "Test"
    field_attribute_base_0 = FieldAttributeBase()
    res = field_attribute_base_0.get_validated_value("name", field_attribute_base_0, data, templar=None)
    assert res == data


# Generated at 2022-06-25 04:56:07.776912
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.validate(None, None)



# Generated at 2022-06-25 04:56:13.385015
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.load_data(**{'a': 'b'})
    #assert field_attribute_base_1._attributes == {'a': 'b'}


# Generated at 2022-06-25 04:56:15.578809
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # test with incorrect attribute name
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(AssertionError):
        field_attribute_base_0.validate()


# Generated at 2022-06-25 04:56:47.912138
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attribute = FieldAttributeBase()
    # Test a valid Boolean value
    assert attribute.get_validated_value("name", "attribute", "True", "templar") == True
    # Test a string value for Boolean
    assert attribute.get_validated_value("name", "attribute", "false", "templar") == False
    # Test a string value for Boolean
    assert attribute.get_validated_value("name", "attribute", "True ", "templar") == True
    # Test a string value for Boolean
    assert attribute.get_validated_value("name", "attribute", "TRUE ", "templar") == True
    # Test an invalid value for Boolean
    with pytest.raises(Exception) as err:
        assert attribute.get_validated_value("name", "attribute", "yes", "templar")

# Generated at 2022-06-25 04:56:54.202174
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.dump_attrs()
    field_attribute_base_1.from_attrs({})


if __name__ == "__main__":
    test_case_0()
    test_FieldAttributeBase_from_attrs()

# Generated at 2022-06-25 04:56:59.511860
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # class defined in test_class_0
    base_obj = test_class_0()
    if base_obj is None:
        return False
    base_obj.test = 'host'
    base_obj.post_validate()
    return True


# Generated at 2022-06-25 04:57:06.253649
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    FAIL = False
    test_cases = []
    good_value_0 = FieldAttributeBase(name='good_value_0', isa=dict)
    bad_value_0 = FieldAttributeBase(name='bad_value_0', isa=dict)
    try:
        good_value_0.validate(dict())
    except:
        FAIL = True
    test_cases.append({"bad": FAIL, "good": not FAIL})

    FAIL = False
    try:
        bad_value_0.validate([])
    except:
        FAIL = True
    test_cases.append({"bad": FAIL, "good": not FAIL})

    FAIL = False
    try:
        bad_value_0.validate(set())
    except:
        FAIL = True
    test

# Generated at 2022-06-25 04:57:10.463871
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.get_ds()
    except Exception as e:
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:57:13.891887
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize({'_valid_attrs': {'foo1': 'bar1'}, '_loader': 'foo2'})
    field_attribute_base_0.from_attrs({'foo3': 'bar3'})


# Generated at 2022-06-25 04:57:18.601102
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = dict()
    field_attribute_base_0.from_attrs(attrs)


# Generated at 2022-06-25 04:57:23.534027
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    print(field_attribute_base_0.dump_me())


# Generated at 2022-06-25 04:57:24.808452
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.validate()
    assert True


# Generated at 2022-06-25 04:57:27.437329
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    class_type_0 = field_attribute_base_0.get_validated_value('attribute', 'isa', 'class_type', 'templar')
    assert(class_type_0 == 'class_type')


# Generated at 2022-06-25 04:57:57.418010
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass


# Generated at 2022-06-25 04:57:58.932719
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test_obj = FieldAttributeBase()
    test_obj.load_data('test_value', {})


# Generated at 2022-06-25 04:58:05.612997
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    import collections

    # Test when inputs is None
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.from_attrs(None)


# Generated at 2022-06-25 04:58:06.780530
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    pass # TODO: implement your test here


# Generated at 2022-06-25 04:58:15.218908
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # create an instance of FieldAttributeBase
    test_instance_0 = FieldAttributeBase()

    # Get an instance of the FieldAttributeBase class
    field_attribute_base_0 = FieldAttributeBase()
    # Call method validate of FieldAttributeBase class with args
    # (test_instance_0)
    try:
        field_attribute_base_0.validate(test_instance_0)
    except (TypeError, ValueError) as e:
        assert 'is not a valid FieldAttributeBase' in to_text(e)


# Generated at 2022-06-25 04:58:22.222484
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    roles = Role()
    blocks = Block()
    includes = TaskInclude()
    roles_includes = RoleInclude()
    play = PlayContext()
    play_context = PlayContext()

    print("Testing get_search_path without dependency chain")
    assert Base().get_search_path() == None

    print("Testing get_search_path when _parent is a PlayContext")
    assert play.get_search_path() == None


# Generated at 2022-06-25 04:58:26.421272
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    value = dict()
    field_attribute_base_0 = FieldAttributeBase(value)
    assert isinstance(field_attribute_base_0, FieldAttributeBase) == True


# Generated at 2022-06-25 04:58:28.355215
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert False, "Test if the method 'get_ds' is working."


# Generated at 2022-06-25 04:58:29.836931
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 04:58:33.666307
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = 'value1'
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        field_attribute_base_0.deserialize(data)
    assert 'data' in str(excinfo.value) and 'a dict' in str(excinfo.value) and 'a str' in str(excinfo.value), 'Unexpected error message %s' % excinfo.value


# Generated at 2022-06-25 04:59:07.373114
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    # Create an instance of FieldAttributeBase
    test_class_attr_base = FieldAttributeBase()

    # Create an instance of FieldAttributeBase
    test_class_attr_base.default_factory = "default_factory"
    test_class_attr_base.name = "name"

    # Verify the copy of the instance
    assert test_class_attr_base.copy() == test_class_attr_base


# Generated at 2022-06-25 04:59:09.440271
# Unit test for method get_dep_chain of class Base

# Generated at 2022-06-25 04:59:13.563425
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    ba = FieldAttributeBase()
    if hasattr(ba, "_post_validate"):
        raise AssertionError("The FieldAttributeBase has method post_validate which is not expected.")


# Generated at 2022-06-25 04:59:21.409558
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    my_FieldAttributeBase = FieldAttributeBase()
    #value is None
    assert my_FieldAttributeBase.validate(None) == None
    #value is bool
    assert my_FieldAttributeBase.validate(True) == True
    #value is int
    assert my_FieldAttributeBase.validate(2) == 2
    #value is float
    assert my_FieldAttributeBase.validate(2.0) == 2.0
    #value is string
    assert my_FieldAttributeBase.validate("test") == "test"
    #value is not string nor bool nor int nor float
    try:
        value = []
        raise my_FieldAttributeBase.validate(value)
    except ValueError as e:
        assert "Invalid value for FieldAttributeBase" in to_native(e)
        assert "list" in to_native

# Generated at 2022-06-25 04:59:23.926644
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    f = FieldAttributeBase()
    f._attributes = dict(foo='foo', bar='bar')
    f._attr_defaults = dict(foo='foo', bar='bar')

    attrs = f.dump_attrs()
    assert attrs == dict(foo='foo', bar='bar')


# Generated at 2022-06-25 04:59:28.265403
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    base_0._parent = '1'
    base_1 = Base()
    base_1._parent = '2'
    base_2 = Base()
    base_2._parent = '3'
    setattr(base_0, '_parent', base_1)
    setattr(base_1, '_parent', base_2)
    assert base_0.get_dep_chain() == '1'


# Generated at 2022-06-25 04:59:29.663052
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()


# Generated at 2022-06-25 04:59:32.301442
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    try:
        attr_base_0 = FieldAttributeBase()
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-25 04:59:40.426721
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base = Base()
    attrs = dict(a=1, b=2)
    base.from_attrs(attrs)
    assert base.a == 1
    assert base.b == 2

    attrs = dict(a=1)
    base.from_attrs(attrs)
    assert base.a == 1

    attrs = dict(b=2)
    base.from_attrs(attrs)
    assert base.b == 2

    attrs = dict(a=1, b=2)
    base.from_attrs(attrs)


# Generated at 2022-06-25 04:59:51.428496
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = FieldAttributeBase()
    base_0.name = 'name'
    base_0.isa = 'isa'
    base_0.default = 'default'
    base_0.listof = object()
    base_0.static = True
    base_0.required = True
    base_0.always_post_validate = False
    base_0.class_type = object()
    base_0.priority = 1
    try:
        base_0.copy()
    except Exception as e:
        raise Exception("FieldAttributeBase copy method failed to copy instance: " + str(e))
    if not isinstance(base_0, FieldAttributeBase):
        raise Exception("FieldAttributeBase copy method returned unexpected instance type")


# Generated at 2022-06-25 05:00:24.340215
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    attrs = dict(name="value")
    base_0.from_attrs(attrs)

    # test if the name attribute is set to "value"
    if base_0.name != "value":
        raise AssertionError("Expected: %s, Actual: %s" % ("value", base_0.name))



# Generated at 2022-06-25 05:00:29.557056
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # call, with args
    from ansible.playbook.attribute import FieldAttributeBase
    base_0 = FieldAttributeBase(aliases=['foo'], choices=['bar'], default=['baz'], isa='dict', required=True)
    base_0.copy()

    # call, with varargs
    base_0 = FieldAttributeBase(aliases=['foo'], choices=['bar'], default=['baz'], isa='dict', required=True)
    base_0.copy()


# Generated at 2022-06-25 05:00:41.517406
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Set up logging
    logging.basicConfig(level=logging.DEBUG)

    # Create an instance of class FieldAttributeBase
    f = FieldAttributeBase()
    f.name = 'Test field attribute name'
    f.isa = 'Test field attribute isa'
    # Invoke the dump_me method of instance f
    print(f.dump_me())

    # Create an instance of class FieldAttributeBase with positional arguments
    f = FieldAttributeBase('Test attr name', 'Test attr isa')
    # Invoke the dump_me method of instance f
    print(f.dump_me())

    # Create an instance of class FieldAttributeBase with valid arguments
    f = FieldAttributeBase('Test attr name', 'Test attr isa', 'Test attr default', True)
    # Invoke the dump_me method of instance f


# Generated at 2022-06-25 05:00:42.946001
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = FieldAttributeBase()
    base_1 = base_0.copy()


# Generated at 2022-06-25 05:00:45.794904
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class Base0(Base):
        _valid_attrs = dict(
            name = FieldAttribute(isa='str'),
        )
    base_0 = Base0()
    base_0.from_attrs({'name': 'test_name'})


# Generated at 2022-06-25 05:00:54.881009
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    fa = FieldAttributeBase()
    # First, test the case where a required attribute is not set
    with pytest.raises(AssertionError):
        fa.validate(None, None, None)
    # Now test the case where a required attribute is set
    fa.required = True
    fa.validate(1, None, None)
    # Test the case where an attribute has a default
    fa.required = False
    fa.validate(None, None, None)
    # Test the case where a static attribute is not static
    fa.static = True
    with pytest.raises(AssertionError):
        fa.validate(None, 1, None)
    # Test the case where a static field is static
    fa.static = False
    fa.validate(None, None, None)
    # Test the case

# Generated at 2022-06-25 05:01:03.375776
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    ba = FieldAttributeBase()

    # Test int type, value must be int
    valid_value = ba.get_validated_value('int_field', FieldAttribute(isa='int', default=0), 0, None)
    assert isinstance(valid_value, int)

    # Test bool type, value must be bool
    valid_value = ba.get_validated_value('bool_field', FieldAttribute(isa='bool', default=False), False, None)
    assert isinstance(valid_value, bool)

    # Test float type, value must be float
    valid_value = ba.get_validated_value('float_field', FieldAttribute(isa='float', default=0.0), 0.0, None)
    assert isinstance(valid_value, float)

    # Test percent type, value must be float

# Generated at 2022-06-25 05:01:12.642150
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class MyBase(Base):
        pass
    class MyClass1(MyBase):
        pass
    class MyClass2(MyClass1):
        pass
    l = [MyClass1(), MyClass1(), MyClass2(), MyClass2(), MyClass1(), MyClass2(), MyClass2()]
    c = 0
    for o in l:
        o._ds = {"_data_source":"/home/test/test/test","_line_number":c}
        if c == 0:
            o._parent = "parent_0"
        else:
            o._parent = l[c-1]
        c += 1
    assert l[0].get_search_path() == []
    assert l[1].get_search_path() == ['/home/test/test/test']
    assert l[2].get_search_

# Generated at 2022-06-25 05:01:21.451470
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-25 05:01:24.214884
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    a = FieldAttributeBase(isa='dict')
    b = a.copy()
    assert a.isa == b.isa


# Generated at 2022-06-25 05:02:47.379604
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task_include import TaskInclude

    class TestClass(AnsibleBaseYAMLObject):
        def __init__(self):
            super(TestClass, self).__init__()

    # Basic passing test
    FA = FieldAttributeBase(isa='class', class_type=TestClass)
    assert FA.name == 'FieldAttributeBase'
    FA.validate(TestClass())

    # Set up a test to see if the isa works
    FA = FieldAttributeBase(isa='class', class_type=TestClass)
    try:
        FA.validate(TaskInclude())
        assert False
    except TypeError:
        assert True

    # Set up a test to see if the required works
    FA

# Generated at 2022-06-25 05:02:50.916706
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from UnitTest import UnitTest

    base_0 = Base()
    attrs = {'hello':'world'}
    base_0.from_attrs(attrs)
    if base_0.hello != 'world':
        UnitTest().failure("base_0.hello != 'world'")
