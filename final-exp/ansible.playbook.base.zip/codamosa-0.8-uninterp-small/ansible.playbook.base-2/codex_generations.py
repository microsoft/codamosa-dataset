

# Generated at 2022-06-25 04:53:54.877810
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    cc_0 = field_attribute_base_0.dump_attrs()
    assert cc_0 == {}, "dump_attrs() is not working properly"


# Generated at 2022-06-25 04:53:57.534985
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        field_attribute_base.get_ds()


# Generated at 2022-06-25 04:54:05.665162
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-25 04:54:18.153820
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=loader, sources=['localhost']),
        variable_manager=VariableManager(),
        loader=loader,
        options=Options(),
        passwords={},
    )
    host = tqm.inventory.get_host(Host('localhost'))

# Generated at 2022-06-25 04:54:24.203919
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Make sure squash() throws an exception, as it should not be called directly
    '''
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.squash()
        raise Exception("Test Failed: squash did not raise expected exception")
    except NotImplementedError:
        pass


# Generated at 2022-06-25 04:54:26.958987
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()

# Generated at 2022-06-25 04:54:30.634192
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    class TestClass(Base):
        pass

    test_class_0 = TestClass()
    test_class_0._squashed = False
    test_class_0.no_log = None
    test_class_0._attributes = dict()
    test_class_0._attr_defaults = dict()

    test_class_0.squash()

    assert test_class_0._squashed



# Generated at 2022-06-25 04:54:33.216757
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()
    try:
        assert(field_attribute_base_0 == field_attribute_base_1)
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 04:54:38.143347
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_dep_chain() is None


# Generated at 2022-06-25 04:54:40.586809
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    a = FieldAttributeBase()
    a.foo = 'abc'
    a.bar = 'def'
    b = a.copy()
    b.foo = '123'
    b.bar = '456'
    assert a.foo == 'abc'
    assert a.bar == 'def'
    assert b.foo == '123'
    assert b.bar == '456'


# Generated at 2022-06-25 04:55:07.815045
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_attrs()


# Generated at 2022-06-25 04:55:15.177127
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()
    assert field_attribute_base_1.required == True
    assert field_attribute_base_1.default == None
    assert field_attribute_base_1.always_post_validate == False


# Generated at 2022-06-25 04:55:17.210180
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    # Test case setup
    field_attribute_base_0 = FieldAttributeBase()

    # Test assertions
    assert isinstance(field_attribute_base_0.dump_attrs(), dict)


# Generated at 2022-06-25 04:55:26.118097
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    
    assert field_attribute_base_0.name == field_attribute_base_1.name
    assert field_attribute_base_0.isa == field_attribute_base_1.isa
    assert field_attribute_base_0.default == field_attribute_base_1.default
    assert field_attribute_base_0.required == field_attribute_base_1.required
    assert field_attribute_base_0.static == field_attribute_base_1.static
    assert field_attribute_base_0.validate == field_attribute_base_1.validate

# Generated at 2022-06-25 04:55:29.359968
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_me()

# Generated at 2022-06-25 04:55:39.743521
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Let's check whether a new empty Base object is created or not
    base_0 = Base()
    # Let's check whether the get_search_path method return a list or not
    test_0 = isinstance(base_0.get_search_path(), list)
    # Let's check whether the get_search_path method return a list that is empty or not
    test_1 = len(base_0.get_search_path()) == 0
    # Let's check whether the get_search_path method return a list that contain only string objects or not
    test_2 = test_3 = True
    for elem in base_0.get_search_path():
        if not isinstance(elem, str): test_2 = False
    # Let's check whether the get_search_path method return a list that contain only absolute path or not
   

# Generated at 2022-06-25 04:55:44.826850
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''unit tests for the validate method of class FieldAttributeBase'''

    # Since FieldAttributeBase is an abstract base class,
    # we can not actually call its validate method
    # It will raise TypeError when we try to call it
    # Thus, there is no test written for the validate method
    pass


# Generated at 2022-06-25 04:55:50.419500
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = {
        'description': 'the description',
        'private': False,
        'attribute_value': 'a value'
    }

    fb = FieldAttributeBase()
    fb.from_attrs(attrs)

    assert_equals(fb.description, attrs['description'])
    assert_equals(fb.private, attrs['private'])
    assert_equals(fb.attribute_value, attrs['attribute_value'])


# Generated at 2022-06-25 04:55:58.146509
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.name = "test_field_attribute_base_1"
    field_attribute_base_1._valid_attrs = {"test_key": "test_value"}
    field_attribute_base_1._attributes = {"test_key": "test_value"}
    field_attribute_base_1._alias_attrs = {"test_key": "test_value"}
    field_attribute_base_1._loader = DictDataLoader()
    field_attribute_base_1._variable_manager = VariableManager()
    field_attribute_base_1._validated = True
    field_attribute_base_1._finalized = True
    field_attribute_base_1._uuid = "Test UUID"
    assert field_attribute_base_1

# Generated at 2022-06-25 04:56:02.509652
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    (target_0, ds_0, var_0, ds_0) = (ImplLoader(), "testdata", "testdata", "testdata")
    test_value = field_attribute_base_0.load_data(target_0, ds_0, var_0, ds_0)
    assert test_value == None
    return


# Generated at 2022-06-25 04:56:27.868955
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    data = {}
    with pytest.raises(AnsibleAssertionError) as excinfo:
        field_attribute_base_0.deserialize(data)
    excinfo.match('data \*\*\* should be a dict but is a')


# Generated at 2022-06-25 04:56:31.454441
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    str_0 = field_attribute_base_0.dump_me()
    assert str_0 is not None


# Generated at 2022-06-25 04:56:41.865470
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass #TODO: Implement your test here

# Generated at 2022-06-25 04:56:49.927108
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    FieldAttributeBase_load_data
        basic test for the load_data method

    Args:
        None
    Returns:
        None.
    '''
    # Check basic case
    yaml_data = """
    args:
        a: 1
        b: 2
        c: 3
    """
    data = yaml.safe_load(yaml_data)
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.load_data(data)

    assert field_attribute_base_0._valid_attrs['args'].required is False
    assert field_attribute_base_0._valid_attrs['args'].isa is dict
    assert field_attribute_base_0._valid_attrs['args'].default == {}
    assert field_attribute_base_

# Generated at 2022-06-25 04:56:52.717179
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Create an instance of FieldAttributeBase
    field_attribute_base_0 = FieldAttributeBase()

    with pytest.raises(AnsibleAssertionError):
        # load_data with a bogus first argument
        field_attribute_base_0.load_data('bogus', {'name': 'bogus'})


# Generated at 2022-06-25 04:56:59.101119
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Setup test data
    field_attribute_base_0 = FieldAttributeBase()
    # Exercise code path
    field_attribute_base_0.squash()
    # Verify expected results
    assert field_attribute_base_0._squashed == True


# Generated at 2022-06-25 04:57:05.476636
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    actual_0 = field_attribute_base_0.dump_attrs()

    # check default attribute values
    assert actual_0['_finalized'] == False
    assert actual_0['_squashed'] == False


# Generated at 2022-06-25 04:57:09.473673
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.squash() == ((), {})


# Generated at 2022-06-25 04:57:11.881073
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(AttributeError):
        field_attribute_base_0.get_ds()


# Generated at 2022-06-25 04:57:17.549410
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_me() == {}, "it should be {}"


# Generated at 2022-06-25 04:57:47.209221
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test standard attributes
    base_0 = Base()
    field = base_0.FieldAttributeBase('foo', 'str', '', True, None)
    field.validate(base_0, 'foo')
    field = base_0.FieldAttributeBase('foo', 'bool', '', True, None)
    field.validate(base_0, 'foo')
    field = base_0.FieldAttributeBase('foo', 'float', '', True, None)
    field.validate(base_0, 'foo')
    field = base_0.FieldAttributeBase('foo', 'int', '', True, None)
    field.validate(base_0, 'foo')
    field = base_0.FieldAttributeBase('foo', 'list', '', True, None)
    field.validate(base_0, 'foo')


# Generated at 2022-06-25 04:57:49.389674
# Unit test for method get_path of class Base
def test_Base_get_path():
    base_0 = Base()
    base_0._ds = dict()
    base_0._ds['_data_source'] = 'data_s0'
    base_0._ds['_line_number'] = 1
    path_0 = base_0.get_path()
    assert path_0 == 'data_s0:1'


# Generated at 2022-06-25 04:57:53.391359
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase()
    assert f.dump_me() == {}, 'dump_me returns wrong value'


# Generated at 2022-06-25 04:58:00.721710
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    def test_valid(field, expected=None):
        field.validate()
        if expected:
            assert field == expected
        assert field.isa == expected.isa if expected else None
        assert field.required == expected.required if expected else None
        assert field.default == expected.default if expected else None
        assert field.static == expected.static if expected else None

    def test_invalid(field, error):
        try:
            field.validate()
        except AttributeError as e:
            assert error in to_text(e)

    class TestField(FieldAttributeBase):
        def __init__(self, *args, **kwargs):
            super(TestField, self).__init__(*args, **kwargs)


    test_valid(TestField())
    test_valid(TestField(required=False))
   

# Generated at 2022-06-25 04:58:12.780425
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = Base()
    new_me = base_0.copy()
    assert new_me._validated is False
    assert new_me._finalized is False
    for name in base_0._valid_attrs.keys():
        assert new_me._attributes[name] == base_0._attributes[name]
        #assert new_me._attr_defaults[name] == base_0._attr_defaults[name]

    base_0._validated = True
    base_0._finalized = True
    assert base_0._validated is True
    assert base_0._finalized is True
    new_me = base_0.copy()
    assert new_me._validated is True
    assert new_me._finalized is True

# Generated at 2022-06-25 04:58:15.678576
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """
    Test method validate of FieldAttributeBase class
    """
    # Initialize test object
    attr = FieldAttributeBase()
    # Verify method throws exception when not overridden
    with pytest.raises(NotImplementedError) as excinfo:
        attr.validate(None)
    assert "validate method was not overridden" in str(excinfo.value)

# Generated at 2022-06-25 04:58:23.264566
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # create a class derived from the base class
    class MyBase(Base):
        _valid_attrs = dict(
            my_string = FieldAttributeBase(isa='string'),
            my_list   = FieldAttributeBase(isa='list'),
            my_set    = FieldAttributeBase(isa='set'),
            my_dict   = FieldAttributeBase(isa='dict'),
            my_bool   = FieldAttributeBase(isa='bool'),
            my_float  = FieldAttributeBase(isa='float'),
            my_int    = FieldAttributeBase(isa='int'),
            my_var    = FieldAttributeBase(isa='variables', required=True),
        )

    # create and test the instance
    my_base = MyBase()

    # test string
    my_base.my_string = "foobar"
    my_base.get_

# Generated at 2022-06-25 04:58:28.566393
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    foo = Base()
    # Validate a field name that does not exist on the class
    try:
        foo._valid_attrs['foo'].validate('bar')
        assert False, 'Ensure that the FieldAttributeBase.validate method throws an exception'
    except Exception:
        pass


# Generated at 2022-06-25 04:58:39.720368
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    attributes = base_0.dump_attrs()
    assert isinstance(attributes, dict)

    assert attributes['name'].name == 'name'
    assert attributes['name'].isa == 'string'
    assert attributes['name'].default == None
    assert attributes['name'].required == False

    assert attributes['vars'].name == 'vars'
    assert attributes['vars'].isa == 'class'
    assert attributes['vars'].default == {}
    assert attributes['vars'].required == False

    assert attributes['no_log'].name == 'no_log'
    assert attributes['no_log'].isa == 'bool'
    assert attributes['no_log'].default == False
    assert attributes['no_log'].required == False


# Generated at 2022-06-25 04:58:45.130425
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    f = FieldAttributeBase()
    assert f.validate("a") == "a"
    assert f.validate("aaa".encode("utf-8")) == "aaa"
    assert f.validate("aaa".encode("utf-16")) == "aaa"

# Generated at 2022-06-25 04:59:16.174033
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.name = "name"
    field_attribute_base.type = "type"
    field_attribute_base.required = True
    field_attribute_base.static = True
    field_attribute_base.class_type = Base
    field_attribute_base.default = Base()
    field_attribute_base.aliases = ["name1", "name2"]
    field_attribute_base.always_post_validate = True
    field_attribute_base.omit = True
    field_attribute_base.final = True
    field_attribute_base.fallback = (["name1", "name2"], )
    field_attribute_base.include_in_vars = False
    field_attribute_base.deprecate = True
    field_attribute_base

# Generated at 2022-06-25 04:59:23.775432
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    temp_dir = tempfile.mkdtemp()
    open(os.path.join(temp_dir, 'test1.yml'), 'a').close()
    open(os.path.join(temp_dir, 'test2.yml'), 'a').close()
    os.makedirs(os.path.join(temp_dir, 'test1'))
    open(os.path.join(temp_dir, 'test1', 'test3.yml'), 'a').close()

    with open(os.path.join(temp_dir, 'test1.yml'), 'w') as f:
        f.write('- include: test1/test3.yml\n')
        f.write('- include: test2.yml\n')
        f.write('- local_action:\n')

# Generated at 2022-06-25 04:59:30.248914
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    class Test():
        def __init__(self):
            self.x = 'a'
        def post_validate(self, templar):
            pass
    class Test2():
        def post_validate(self, templar):
            pass
    class_type = Test
    # Raise exception from value == None case in if-elif-if-if-if-if-if
    # statement of method
    with pytest.raises(TypeError):
        base_0.get_validated_value("key", FieldAttribute("key", "class", class_type=Test2), None, None)
    # Raise exception from isinstance(value, class_type) case in elif-if-if
    # statement of method
    with pytest.raises(TypeError):
        base_

# Generated at 2022-06-25 04:59:33.576933
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create an instance of FieldAttributeBase
    field_attribute_base_0 = Base()

    # Check return value of method dump_attrs
    assert(isinstance(field_attribute_base_0.dump_attrs, types.MethodType))


# Generated at 2022-06-25 04:59:38.432887
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_1 = Base()
    attrs = base_1.serialize()
    base_2 = Base()
    base_2.from_attrs(attrs)
    assert base_1.serialize() == base_2.serialize()

# Generated at 2022-06-25 04:59:42.445400
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase()

    if attr.name != None:
        raise Exception("Unit test failure in FieldAttributeBase validate")

    if attr.isa != None:
        raise Exception("Unit test failure in FieldAttributeBase validate")

    if attr.default != None:
        raise Exception("Unit test failure in FieldAttributeBase validate")

    if attr.always_post_validate != None:
        raise Exception("Unit test failure in FieldAttributeBase validate")

# Generated at 2022-06-25 04:59:50.149235
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # Create a FieldAttributeBase instance to test with
    base_instance = Base()

    # Create test case variables
    name0 = 'something'
    value0 = 'something'

    # Check that we have the expected results from the get_validated_value method
    assert base_instance.get_validated_value(name0, FieldAttributeBase(), value0, None) == value0




# Generated at 2022-06-25 04:59:59.037475
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta = BaseMeta
    #print(base_meta.__new__.func_code.co_consts)
    #print(base_meta.__new__)
    base_meta.__new__(BaseMeta, 'Base', (), {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}, '__dict__': {'_attributes': {},'_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}})


# Generated at 2022-06-25 05:00:06.002606
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    string_field = FieldAttribute(isa='string', default='foo')
    list_field = FieldAttribute(isa='list', default=['foo', 'bar'])
    int_field = FieldAttribute(isa='int', default=1234)
    dict_field = FieldAttribute(isa='dict', default={'foo': 'bar', 'biz': 'baz'})
    class_field = FieldAttribute(isa='class', default=Task(), class_type=Task)
    set_field = FieldAttribute(isa='set', default={'foo', 'bar'})

    assert string_field.dump_me() == 'string'
    assert list_field.dump_me() == 'list'
    assert int_field.dump_me() == 'int'
    assert dict_field.dump_me() == 'dict'
    assert class_field.dump_

# Generated at 2022-06-25 05:00:08.521973
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test a type conversion of an attribute value
    field_attribute_base_0 = FieldAttributeBase(isa='bool', default=True)
    field_attribute_base_0.deserialize('false')
    return True


# Generated at 2022-06-25 05:00:35.766701
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    attr = FieldAttributeBase(isa='bool')
    dump_me = attr.dump_me()
    assert dump_me == 'bool'



# Generated at 2022-06-25 05:00:45.565860
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Host, Inventory

    # Test case 1: Set of valid values, with data_type = 'str'
    # field_name = 'test_field_1'
    # data_type = 'str'
    # valid_values = ['a', 'b']
    # field_value = 'b'

    # Test case 2: Set of valid values, with data_type = 'int'
    # field_name = 'test_field_2'
    # data_type = 'int'
    # valid_values = [1, 2]
    # field_value = 2

    # Test case 3: Set of invalid values, with data_type = 'str'
    # field_name = 'test_field_3'
    # data_type = '

# Generated at 2022-06-25 05:00:51.586971
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert base.get_dep_chain() is None



# Generated at 2022-06-25 05:00:55.065678
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base_0 = Base()
    data = dict()
    base_0.from_attrs(data)


# Generated at 2022-06-25 05:00:57.049622
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = FieldAttributeBase()
    result = base_0.load_data(attr='attr_0', ds='ds_0')
    assert result is Sentinel


# Generated at 2022-06-25 05:01:04.133641
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # test with an 'int'
    base_1 = Base()
    base_1._valid_attrs = dict(foo=FieldAttribute('foo', 'int'))
    base_1.foo = '6'
    assert base_1.get_validated_value('foo', base_1._valid_attrs['foo'], base_1.foo, None) == 6
    # test with a 'float'
    base_2 = Base()
    base_2._valid_attrs = dict(foo=FieldAttribute('foo', 'float'))
    base_2.foo = '6.0'
    assert base_2.get_validated_value('foo', base_2._valid_attrs['foo'], base_2.foo, None) == 6.0
    # test with a 'bool'
    base_3 = Base

# Generated at 2022-06-25 05:01:05.109706
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    f = FieldAttributeBase()
    f.deserialize({})


# Generated at 2022-06-25 05:01:12.216500
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class Base_0(Base):
        pass
    base_0 = Base_0()
    templar = MagicMock()
    try:
        # Test case where field is None or Null
        base_0.get_validated_value('name', FieldAttribute(isa='string', validate=validate_module_spec), None, templar)
    except AssertionError as e:
        assert True, "Got exception: %s" % str(e)
    except Exception as e:
        assert False, "Got invalid exception: %s" % str(e)
    else:
        assert False, "Did not get expected exception"


# Generated at 2022-06-25 05:01:21.078937
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a null base
    test_base = Base()
    test_base.deserialize(None)

# Generated at 2022-06-25 05:01:25.277470
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    attr_0 = FieldAttributeBase()
    # get a copy of attr_0
    attr_0_copy = attr_0.copy()
    # check equality of attr_0 and attr_0_copy
    assert attr_0 is not attr_0_copy
    assert attr_0 == attr_0_copy


# Generated at 2022-06-25 05:01:53.554426
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with an empty dictionary
    x = [dict()]
    assert FieldAttributeBase.dump_me(x) == x[0]


# Generated at 2022-06-25 05:01:58.120566
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert base.get_dep_chain() == None


# Generated at 2022-06-25 05:02:03.151624
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Play()
    assert isinstance(base_0.get_dep_chain(), type(None))
    role_0 = Role()
    base_0.set_loader(MagicMock())
    base_0.set_parent(role_0)
    assert isinstance(base_0.get_dep_chain(), list)
    base_0.set_loader(None)
    base_0.set_parent(None)
    assert isinstance(base_0.get_dep_chain(), type(None))


# Generated at 2022-06-25 05:02:10.622365
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base1 = Base()
    assert not base1.get_dep_chain()
    base2 = Base(parent=base1)
    assert base2.get_dep_chain() == base1
    base3 = Base(parent=base2)
    assert base3.get_dep_chain() == base2
    base4 = Base(parent=base3)
    assert base4.get_dep_chain() == base3


# Generated at 2022-06-25 05:02:13.194882
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    temp_attribute = FieldAttributeBase(isa='string')
    assert temp_attribute.dump_me() == 'FieldAttributeBase(isa="string", default=None, required=True, final=False, static=False, always_post_validate=False)'

# Generated at 2022-06-25 05:02:22.302726
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base = Base()
    base.deserialize(dict(name='test', ignore_errors=True))
    assert base.name == 'test'
    assert base.ignore_errors == True

    # deserialize with a null value for ignore_errors
    base.deserialize(dict(name='test', ignore_errors=None))
    assert base.name == 'test'
    assert base.ignore_errors == True

    # deserialize with a weird value
    base.deserialize(dict(name='test', ignore_errors='true'))
    assert base.name == 'test'
    assert base.ignore_errors == True

    # deserialize with a list
    base.deserialize(dict(name='test', ignore_errors=[True]))
    assert base.name == 'test'

# Generated at 2022-06-25 05:02:27.938688
# Unit test for method squash of class FieldAttributeBase

# Generated at 2022-06-25 05:02:31.578836
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # This is a simple test to check if the get_dep_chain method 
    # returns None or not.
    test_obj = Base()
    assert (test_obj._parent == None)


# Generated at 2022-06-25 05:02:38.322068
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class Foo(Base):
        name = FieldAttribute(isa='string')
        vars = FieldAttribute(isa='dict', default={})
        var_test = FieldAttribute(isa='list', listof=string_types)
        percent = FieldAttribute(isa='percent')

    base_0 = Foo()
    base_0.name = "test_name"
    base_0.percent = -1.0
    base_0.var_test = ["a", "b", "c"]
    base_0.var_test_0 = ["a", "b", "c"]
    base_0.var_test_1 = "a,b,c"
    base_0.var_test_2 = "a"
    base_0.var_test_3 = ["a", None, "c"]


# Generated at 2022-06-25 05:02:46.524825
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()

    # Check if function throws an exception if value is None
    try:
        base_0.get_validated_value('None', 'None', None)
    except AnsibleParserError as e:
        print(e)
    except TypeError as e:
        print(e)
    # Check if function throws an exception if value is a string
    try:
        base_0.get_validated_value('String', 'String', 'String')
    except AnsibleParserError as e:
        print(e)
    except TypeError as e:
        print(e)
    # Check if function throws an exception if value is an integer
    try:
        base_0.get_validated_value('Integer', 'Int', 1)
    except AnsibleParserError as e:
        print(e)
   