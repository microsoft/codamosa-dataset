

# Generated at 2022-06-25 04:54:00.251683
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = Base()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy()
    field_attribute_base_0.isvalid()


# Generated at 2022-06-25 04:54:04.050854
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fields = FieldAttributeBase(name="my_method", stub=True, isa="test_class")
    fields_dumped = fields.dump_me()
    assert fields_dumped == "my_method = stub_type(name='my_method', stub=True, isa='test_class')", "FieldAttributeBase.dump_me() failed"


# Generated at 2022-06-25 04:54:09.272285
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # create a test case instance
    base_0 = Base()
    # create a test class instance
    obj = dict()
    # create a test attribute
    attribute = FieldAttributeBase()
    # create a test value
    value = 'test'
    # create a test templar
    templar = dict()
    # expected result
    expected = 'test'
    # call the get_validated_value method
    result = base_0.get_validated_value(obj, attribute, value, templar)
    # check if the result is correct
    assert result == expected


# Generated at 2022-06-25 04:54:14.099272
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    base._parent = MagicMock()
    base._parent.get_dep_chain.return_value = ['ret1']
    assert base.get_dep_chain() == ['ret1']

    base = Base()
    base._parent = None
    assert base.get_dep_chain() == None

# Generated at 2022-06-25 04:54:24.015843
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from datetime import datetime

    base_0 = Base()

    attrs = {'ignore_errors': True, 'foo': 'bar'}
    base_0.from_attrs(attrs)

    # Check if the ignore_errors attr was set correctly
    result = base_0._attributes["ignore_errors"]
    assert result == attrs["ignore_errors"]

    # Check if the attr that is not in the valid attrs is not set
    assert attrs["foo"] not in base_0._attributes.values()

    # Test with datetime attribute
    class TestClassTime(Base):
        _valid_attrs = dict(
            tz=FieldAttribute(isa='string'),
            dt=FieldAttribute(isa=datetime, default=datetime.now()),
        )

# Generated at 2022-06-25 04:54:26.262297
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = FieldAttributeBase()
    base_0_copy = base_0.copy()
    assert base_0_copy.required is base_0.required
    return


# Generated at 2022-06-25 04:54:32.125496
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
        python -m unitest ansible.parsing.yaml.objects.test_FieldAttributeBase
    '''

# Generated at 2022-06-25 04:54:39.791829
# Unit test for method get_path of class Base
def test_Base_get_path():
    test_case_0.base_0.__dict__.update({'_ds': {'_line_number': __LINE__, '_data_source': 'test_file'}})

    assert test_case_0.base_0.get_path() == "test_file:%s" % __LINE__


# Generated at 2022-06-25 04:54:42.324165
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    assert base_0._loader is not None


# Generated at 2022-06-25 04:54:43.775818
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # There are no field attributes which have a post_validate method
    pass


# Generated at 2022-06-25 04:55:17.771684
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    f = FieldAttributeBase()
    f.isa = "int"
    f.static = True
    f.required = True
    f.default = 0

    # test int
    try:
        f._post_validate("10")
    except:
        assert False, "case 1 'int' test failed"

    # test float
    try:
        f._post_validate("10.5")
    except:
        assert False, "case 2 'int' test failed"

    # test bool
    try:
        f._post_validate("False")  # test boolean
    except:
        assert False, "case 3 'int' test failed"

    # test list

# Generated at 2022-06-25 04:55:25.216276
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from lib.ansible.module_utils.hashdict import HashDict

    attr_0 = FieldAttributeBase.deserialize(None)
    assert attr_0 is None
    assert_raises(AnsibleAssertionError, FieldAttributeBase.deserialize, {})
    assert_raises(AnsibleAssertionError, FieldAttributeBase.deserialize, 10)
    assert_raises(AnsibleAssertionError, FieldAttributeBase.deserialize, [])
    assert_raises(AnsibleAssertionError, FieldAttributeBase.deserialize, set())
    assert_raises(AnsibleAssertionError, FieldAttributeBase.deserialize, ())

    # HashDict

# Generated at 2022-06-25 04:55:34.524972
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    s = [Sentinel(), Sentinel(), None, 0]
    assert FieldAttributeBase.squash(s) == Sentinel()
    s = [Sentinel(), Sentinel(), None, 1]
    assert FieldAttributeBase.squash(s) == [Sentinel(), Sentinel(), None, 1]
    s = [Sentinel(), Sentinel(), None, 0, 1]
    assert FieldAttributeBase.squash(s) == [1]
    s = [0, 0]
    assert FieldAttributeBase.squash(s) == 0
    s = [1, 1]
    assert FieldAttributeBase.squash(s) == [1, 1]
    s = [0, 1]
    assert FieldAttributeBase.squash(s) == [0, 1]

if __name__ == '__main__':
    test_case_0()
    test_Field

# Generated at 2022-06-25 04:55:44.513535
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_field_attribute_base = FieldAttributeBase()

    # Test for case where ds_type is string
    test_field_attribute_base.ds_type = 'string'
    assert test_field_attribute_base.get_validated_value('name', test_field_attribute_base, b'hello', None) == 'hello'
    assert test_field_attribute_base.get_validated_value('name', test_field_attribute_base, 123, None) == '123'
    assert test_field_attribute_base.get_validated_value('name', test_field_attribute_base, 12.3, None) == '12.3'
    assert test_field_attribute_base.get_validated_value('name', test_field_attribute_base, True, None) == 'True'
    assert test_field

# Generated at 2022-06-25 04:55:49.127028
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Tests post_validate function of class FieldAttributeBase
    @param: An instance of FieldAttributeBase class
    '''
    base_1 = Base()
    assert type(base_1) == Base
    base_2 = Base()
    assert type(base_2) == Base
    assert base_1._validated == base_2._validated


# Generated at 2022-06-25 04:55:59.212852
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.base import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    base_0 = Base()
    play_0 = Play()
    block_0 = Block()
    block_1 = Block()
    task_0 = Task()
    role_0 = Role()
    handler_0 = Handler()
    # Setup test data
    base_0._name = 'base_0'
    base_0._parent = None

    play_0._name = 'play_0'
    play_0._parent = None

    block_0._name = 'block_0'
    block_0._parent = block_1


# Generated at 2022-06-25 04:56:08.165123
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # create new object from field attribute base
    field_attribute_base = FieldAttributeBase()
    field_attribute_base_json = field_attribute_base.dump_attrs()
    # check for the type of the json object returned
    assert type(field_attribute_base_json) == dict
    # check if the deserialization returns the same json object
    # that we got when we called dump_attrs
    field_attribute_base.from_attrs(field_attribute_base_json)
    new_field_attribute_base_json = field_attribute_base.dump_attrs()
    assert field_attribute_base_json == new_field_attribute_base_json


# Generated at 2022-06-25 04:56:12.393331
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    fld_attr_0 = FieldAttributeBase()
    fld_attr_0.name = 'name_0'
    fld_attr_0.isa = 'string'

    name_0 = 'name_0'
    attribute = fld_attr_0
    value = 'string'
    templar_mock = MagicMock()
    templar_mock.configure_mock(**{'template.return_value': 'string'})
    base_0.get_validated_value(name_0, attribute, value, templar_mock)


# Generated at 2022-06-25 04:56:17.664263
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.module_utils import basic
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    base_0 = Base()
    loader_0 = DataLoader()
    vault_password = basic.get_file_vault_secret(VaultLib(), loader_0)
    inventory_0 = InventoryManager(loader_0, sources=None, vault_password=vault_password)

# Generated at 2022-06-25 04:56:24.964556
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    def test_squash_of_none(s):
        return s.squash(None) == Sentinel

    def test_squash_of_sentinel(s):
        return s.squash(Sentinel) == Sentinel

    def test_squash_of_list(s):
        return s.squash(['a', 'b']) == ['a', 'b']

    def test_squash_of_non_list(s):
        return s.squash(1) == 1

    s = FieldAttributeBase(default=True)
    assert test_squash_of_none(s)
    assert test_squash_of_sentinel(s)
    assert test_squash_of_list(s)
    assert test_squash_of_non_list(s)


# Generated at 2022-06-25 04:57:10.165254
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = FieldAttributeBase()
    try:
        base_1.post_validate()
    except:
        print("Failed to post_validate the base class")
        assert False
    else:
        assert True



# Generated at 2022-06-25 04:57:17.532782
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    state = {
        't1': Task(),
        't2': Task(),
        't3': Task(),

        'i1': TaskInclude(),
        'i2': TaskInclude(),
        'i3': TaskInclude(),

        'r1': Role(),
        'r2': Role(),
        'r3': Role(),

        'p1': Play(),
        'p2': Play(),
        'p3': Play()
    }

    base_0 = Base()

    # call get_dep_chain on itself
    path = base_0.get_dep_chain()
    assert path == None

    # call get_dep_chain on t1, t2, i3, r3 and p3

# Generated at 2022-06-25 04:57:27.787353
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    base_0.vars = {}

    host = Host()
    host.name = "test_host"

    play_0 = Play()
    play_0.name = "test_play"
    play_0.vars = {}

    task_0 = Task()
    task_0.play = play_0
    task_0.role = None
    task_0.vars = {}
    task_0.action = None
    task_0.any_errors_fatal = None
    task_0.changed_when = None
    task_0.always_run = None
    task_0.block = None
    task_0.async_val = None
    task_0.async_hours = None
    task_0.async_seconds = None

# Generated at 2022-06-25 04:57:32.735162
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = FieldAttributeBase()
    base_1 = base_0.copy()

    if not isinstance(base_0, object):
        raise AssertionError('base_0 is not an object')
    if not isinstance(base_1, object):
        raise AssertionError('base_1 is not an object')
    if not isinstance(base_0, FieldAttributeBase):
        raise AssertionError('base_0 is not a FieldAttributeBase')
    if not isinstance(base_1, FieldAttributeBase):
        raise AssertionError('base_1 is not a FieldAttributeBase')

# Generated at 2022-06-25 04:57:42.793289
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    class ClassName(Base):
        field_name = attribute(isa='string')
        def __init__(self):
            self.field_name = None

    # ClassName has field name
    base_1 = ClassName()
    base_1.field_name = 'FieldName1'
    base_1.post_validate(templar=MockTemplar())

    base_2 = ClassName()
    base_2.field_name = 'FieldName2'
    base_2.post_validate(templar=MockTemplar())

    base_1.squash(base_2)
    assert base_1.field_name == base_2.field_name


# Generated at 2022-06-25 04:57:52.068105
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    ba0 = Base()
    fa0 = FieldAttributeBase('name0')

    name0 = "name0"
    value0 = "value0"
    attr0 = fa0

    print('[FieldAttributeBase] Testing get_validated_value method of class FieldAttributeBase')
    print('[FieldAttributeBase] attribute      = %s' % attr0)
    print('[FieldAttributeBase] name           = %s' % name0)
    print('[FieldAttributeBase] value          = %s' % value0)
    print('[FieldAttributeBase] attribute.isa  = %s' % attr0.isa)
    print('[FieldAttributeBase] result         = %s' % ba0.get_validated_value(name0, attr0, value0, None))


# Generated at 2022-06-25 04:57:59.541770
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    import os
    import tempfile
    import shutil
    import yaml

    # We need a temporary directory
    tmp_dir = tempfile.mkdtemp(prefix='ansible-test_FieldAttributeBase_from_attrs_')

    # Create a test file
    test_yaml = """
    tasks:
    - debug:
        msg: 'Hello world'

    vars:
      user: root
      password: password

    pre_tasks:
      - debug:
          var: password
    """

    test_yaml_path = os.path.join(tmp_dir, 'test.yaml')
    test_yaml_fd = os.open(test_yaml_path, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)

# Generated at 2022-06-25 04:58:12.658910
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    base = Base()


# Generated at 2022-06-25 04:58:17.500368
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_value = ['1','2','3','4','5','6','7','8','9','0']
    assert FieldAttributeBase.validate('vars', test_value, 'list') is True

# unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-25 04:58:20.316493
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    result = test_case_0.base_0.get_search_path()
    assert not result


# Generated at 2022-06-25 04:59:04.264912
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Test case 1: check if Base._search_path is not None
    base_0 = Base()
    assert(base_0.get_search_path() != None)



# Generated at 2022-06-25 04:59:14.446142
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_case_0()
    test_input = dict(name='string_input_0',
                      str_value=10,
                      isa='string')
    base_0 = Base()
    validate_string = base_0.get_validated_value(**test_input)
    assert validate_string == '10'
    test_input = dict(name='int_input_0',
                      str_value=10.0,
                      isa='int')
    validate_int = base_0.get_validated_value(**test_input)
    assert validate_int == 10
    test_input = dict(name='float_input_0',
                      str_value=10,
                      isa='float')
    validate_float = base_0.get_validated_value(**test_input)
    assert validate_

# Generated at 2022-06-25 04:59:21.616604
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # test case 1
    # Base.get_search_path() in __main__.Base object
    base_0 = Base()
    assert base_0.get_search_path() == []

    # test case 2
    # Base.get_search_path() in __main__.Vars.Variable object
    base_1 = Base()
    base_1._ds = 'base_1._ds'
    base_1._ds._line_number = 'base_1._ds._line_number'
    assert base_1.get_search_path() == ['base_1._ds:base_1._ds._line_number']

    # test case 3
    # Base.get_search_path() in __main__.Vars.Variable object
    base_2 = Base()

# Generated at 2022-06-25 04:59:25.596118
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field = FieldAttributeBase()
    result = field.dump_me()
    assert result is None, 'Unexpected result: %s' % result


# Generated at 2022-06-25 04:59:32.703694
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing import vault
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import is_reserved_name
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    base_0 = Base()
    base_1 = Base()
    base_0.copy(base_1)


# Generated at 2022-06-25 04:59:39.212420
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    test_obj = FieldAttributeBase()
    test_obj.test_key_1 = "test_value_1"
    test_obj.test_key_2 = "test_value_2"
    test_obj.test_key_3 = "test_value_3"
    test_obj.test_key_4 = None
    print(test_obj.dump_attrs())


# Generated at 2022-06-25 04:59:41.871467
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = Base()
    fieldattributeraw_0 = FieldAttributeRaw()
    data_str_0 = 'deprecated'
    deprecated_0 = fieldattributeraw_0.load_data(base_0, data_str_0)


# Generated at 2022-06-25 04:59:46.486420
# Unit test for method get_path of class Base
def test_Base_get_path():
    base_0 = Base()
    assert base_0.get_path() == ":None"


# Generated at 2022-06-25 04:59:51.457108
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = Base()
    base_0.load_data()


# Generated at 2022-06-25 04:59:54.879859
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attr_base_0 = FieldAttributeBase()
    assert field_attr_base_0.deserialize(True, [])


# Generated at 2022-06-25 05:00:57.657385
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()

    # Case 0:
    #  If the field is not finalised
    #  Method post_validate should raise FinalizeError.
    #
    try:
        base_0.post_validate()
        raise AssertionError("AnsibleAssertionError was not raised")
    except AnsibleAssertionError as e:
        if "should never be created in memory" not in str(e):
            raise


# Generated at 2022-06-25 05:01:08.253267
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    base_1 = Base()

    # test value None with isa set to string
    attr_1 = FieldAttributeBase('attr_1', isa='string', nullable=False)
    res_1 = base_1.get_validated_value('attr_1', attr_1, None, Templar())
    assert res_1 is None

    # test value u'xyz' with isa set to string
    attr_2 = FieldAttributeBase('attr_2', isa='string', nullable=False)
    res_2 = base_1.get_validated_value('attr_2', attr_2, u'xyz', Templar())
    assert res_2 == u'xyz'

    # test value b'xyz' with isa set to string

# Generated at 2022-06-25 05:01:18.461263
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    def assert_value(ds, name, value):
        base = Base(ds)
        print("Testing get_validated_value for value = {value}".format(value=value))
        ans = base._get_validated_value(name, value)
        print("The validating result is {ans}".format(ans=ans))
        if "error" in str(ans).lower():
            raise AssertionError("Field attribute type validating failed")
        print("Validating succeed")

    #test

# Generated at 2022-06-25 05:01:20.913635
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    ba = Base()
    # Case 0
    attr = FieldAttributeBase('pa','p')
    ba._get_validated_value('pa','p',None,None)


# Generated at 2022-06-25 05:01:26.994439
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test case 1
    base_0 = Base()
    templar_0 = Templar()
    val_0 = None
    # Test case 2
    base_1 = Base()
    templar_1 = Templar()
    val_1 = None
    # Test case 3
    base_2 = Base()
    templar_2 = Templar()
    val_2 = None
    # Test case 4
    base_3 = Base()
    templar_3 = Templar()
    val_3 = None
    # Test case 0
    try:
        test_case_0()
    except AnsibleParserError as e:
        assert True

    # Test case 1
    try:
        base_0.post_validate(templar_0)
    except AnsibleParserError as e:
        assert True

    #

# Generated at 2022-06-25 05:01:32.866654
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    # Initialize base_0
    base_0 = Base()

    # Check if data is a dict
    if not isinstance(data, dict):
        raise AnsibleAssertionError('data (%s) should be a dict but is a %s' % (data, type(data)))

# Generated at 2022-06-25 05:01:35.951946
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base_1 = FieldAttributeBase()
    if base_1.deserialize():
        raise Exception("Test failed: method deserialize of FieldAttributeBase failed")


# Generated at 2022-06-25 05:01:43.757094
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test case 1
    base_0 = Base()
    assert base_0.get_dep_chain() == None

    # Test case 2
    base_1 = Base()
    assert base_1.get_dep_chain() == None

    # Test case 3
    base_2 = Base()
    assert base_2.get_dep_chain() == None

    # Test case 4
    base_3 = Base()
    assert base_3.get_dep_chain() == None

    # Test case 5
    base_4 = Base()
    assert base_4.get_dep_chain() == None

    # Test case 6
    base_5 = Base()
    assert base_5.get_dep_chain() == None



# Generated at 2022-06-25 05:01:50.791542
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # Test dump_me with ignore_errors=False
    field = AnsibleFieldAttribute('name', required=False)
    assert field.dump_me() == 'name=None [type=None, required=False, default=None, aliases=[], choices=None]'

    # Test dump_me with ignore_errors=True
    field = AnsibleFieldAttribute('name', default=1)
    assert field.dump_me(ignore_errors=True) == 'name=None [type=None, required=False, default=1, aliases=[], choices=None]'

# Generated at 2022-06-25 05:01:59.414772
# Unit test for method get_validated_value of class FieldAttributeBase