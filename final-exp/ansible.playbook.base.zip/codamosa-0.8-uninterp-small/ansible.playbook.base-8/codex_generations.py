

# Generated at 2022-06-25 04:53:53.228084
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    test_case_0()
    if (hasattr(self, '_parent') and self._parent):
        return self._parent.get_dep_chain()
    else:
        return None


# Generated at 2022-06-25 04:53:56.141524
# Unit test for method get_path of class Base
def test_Base_get_path():
    first_base_obj = Base()
    result = first_base_obj.get_path()

    if not isinstance(result, str):
        print(result)
        assert 1
    assert 0



# Generated at 2022-06-25 04:54:02.142591
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Setup
    field_attribute_base_0 = FieldAttributeBase()

    ds = dict(args=dict(a=1, b=2))
    templar = Templar(loader=None, variables=ds)

    # Expected result
    expected = dict(a=1, b=2)

    # Result
    result = field_attribute_base_0.get_validated_value(name='args', attribute=FieldAttributeBase, value=ds, templar=templar)
    assert expected == result, "FieldAttributeBase_get_validated_value failed"


# Generated at 2022-06-25 04:54:12.651074
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    # set the values of the attribute
    field_attribute_base_0.attribute = None
    field_attribute_base_0.class_type = None
    field_attribute_base_0.default = None
    field_attribute_base_0.display_name = None
    field_attribute_base_0.env_var = None
    field_attribute_base_0.error_messages = None
    field_attribute_base_0.flag = None
    field_attribute_base_0.isa = None
    field_attribute_base_0.listof = None
    field_attribute_base_0.required = None
    field_attribute_base_0.static = False
    field_attribute_base_0.version_added = None

    field_attribute_0 = Field

# Generated at 2022-06-25 04:54:14.565718
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() is None


# Generated at 2022-06-25 04:54:18.437323
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Call function: method
    try:
        test_case_0()
    except Exception as e:
        print_exc()
        assert False, "Wrong exception raised: %s" % e
    else:
        assert True, "No exception raised"


# Generated at 2022-06-25 04:54:24.606644
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    name = 'name'
    attribute_name = 'attribute_name'
    value = 'value'
    # test with None values
    field_attribute_base_0.validate(name, attribute_name, None)
    # test with good values
    field_attribute_base_0.validate(name, attribute_name, value)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:54:26.575359
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.validate()
    assert field_attribute_base_0.is_valid()


# Generated at 2022-06-25 04:54:31.633996
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test with valid parameters
    field_attribute_base_0 = FieldAttributeBase()



# Generated at 2022-06-25 04:54:40.977167
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    # Create a FieldAttributeBase
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._squashed = True
    field_attribute_base_0._finalized = True
    field_attribute_base_0.vars = {'passed in': 'value'}

    # Call the FieldAttributeBase instance method dump_attrs
    result = field_attribute_base_0.dump_attrs()

    # Check that the result is a dict
    assert isinstance(result, dict)

    # Check the result
    expected = {'vars': {'passed in': 'value'}}
    assert result == expected


# Generated at 2022-06-25 04:55:06.315834
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    f = field_attribute_base_0.dump_me

    assert field_attribute_base_0.dump_me() == 'FieldAttributeBase'



# Generated at 2022-06-25 04:55:11.784139
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    dump_me_0_retval = field_attribute_base_0.dump_me()
    assert dump_me_0_retval is None


# Generated at 2022-06-25 04:55:19.214380
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    if field_attribute_base_0.get_validated_value("hosts", field_attribute_base_0._valid_attrs["hosts"], "localhost", MagicMock()) == 'localhost':
        assert True

    if field_attribute_base_0.get_validated_value("hostvars", field_attribute_base_0._valid_attrs["hostvars"], "localhost", MagicMock()) == 'localhost':
        assert True

    if field_attribute_base_0.get_validated_value("hostvars", field_attribute_base_0._valid_attrs["hostvars"], {"localhost": {}}, MagicMock()) == {"localhost": {}}:
        assert True


# Generated at 2022-06-25 04:55:29.776869
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_0 = field_attribute_base_0._valid_attrs.get('name')
    setattr(field_attribute_base_0, 'name', 'name')
    from ansible.template import Templar
    try:
        templar_0 = Templar(loader=None, variables=None)
    except AnsibleUndefinedVariable as e:
        print('Exception caught:')
        print(type(e))
        print(e.message)
    else:
        try:
            result = field_attribute_base_0.get_validated_value(name='name', attribute=field_attribute_0, value='name', templar=templar_0)
        except TypeError as e:
            print('Exception caught:')

# Generated at 2022-06-25 04:55:37.271316
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an entity of class FieldAttributeBase
    field_attribute_base_0 = FieldAttributeBase()

    # Execute the method post_validate
    field_attribute_base_method_res_0 = field_attribute_base_0.post_validate()

    # check if the result is equal to the expected result
    assert field_attribute_base_method_res_0 == None
    # check if the field _finalized has been correctly initialized
    assert field_attribute_base_0._finalized == False
    # check if the field _squashed has been correctly initialized
    assert field_attribute_base_0._squashed == False


# Generated at 2022-06-25 04:55:42.321895
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_case_0()
    test_obj_0 = FieldAttributeBase()


# Generated at 2022-06-25 04:55:49.172299
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    with pytest.raises(NotImplementedError) as excinfo:
        FieldAttributeBase().from_attrs()
    assert excinfo.value.args[0] == 'from_attrs() must be implemented by another class'


# Generated at 2022-06-25 04:55:51.163313
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = {}
    field_attribute_base_0.from_attrs(attrs)


# Generated at 2022-06-25 04:55:52.740926
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    baseMeta = BaseMeta(None, [], dict())

    if not isinstance(baseMeta, type):
        raise AssertionError("BaseMeta is not of type 'type'")


# Generated at 2022-06-25 04:55:58.075038
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    # Test for method from_attrs() of class FieldAttributeBase
    #>>> test_case_0()
    #>>> field_attribute_base_0.from_attrs({})
    #>>> field_attribute_base_0.from_attrs(dict(a=1,b=2,c=3))
    #>>> field_attribute_base_0.a
    #1
    #>>> field_attribute_base_0.b
    #2
    #>>> field_attribute_base_0.c
    #3
    #>>> field_attribute_base_0.from_attrs({a=1,b=2,c=3}) # doctest: +IGNORE_EXCEPTION_DETAIL
    #Traceback (most recent call last):
    #Type

# Generated at 2022-06-25 04:56:26.125425
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy()


# Generated at 2022-06-25 04:56:33.461575
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        mock_serialized = (1, )
        ansible_assert.assert_raises(AnsibleAssertionError,
                                     [field_attribute_base_0, 'deserialize', mock_serialized])
        field_attribute_base_0.deserialize(mock_serialized)
        assert False, "AssertionError not raised"
    except AssertionError as e:
        assert True


# Generated at 2022-06-25 04:56:38.030661
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    # Calling get_ds method of class FieldAttributeBase
    field_attribute_base_0.get_ds()


# Generated at 2022-06-25 04:56:41.320213
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    # This can be implemented when we have the test infrastructure done
    pass # field_attribute_base_0.load_data()


# Generated at 2022-06-25 04:56:43.127357
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Run unit tests for method from_attrs of class FieldAttributeBase
    '''
    obj_0 = FieldAttributeBase()
    obj_0.from_attrs({})
    return True


# Generated at 2022-06-25 04:56:47.068809
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_obj = FieldAttributeBase()
    output = field_attribute_base_obj.dump_me()
    assert output == {'__utils__': {}, '__aliases__': {}, '__defaults__': {}, '__vars__': {}, '__dependencies__': set()}


# Generated at 2022-06-25 04:56:54.871912
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    # Test without any arguments (defaults should be used)
    test_obj_0 = FieldAttributeBase()
    test_obj_1 = FieldAttributeBase()

    # Test with a populated dictionary
    test_dict_0 = {
    }
    test_obj_2 = FieldAttributeBase()
    test_obj_2.from_attrs(test_dict_0)
    assert test_obj_0 == test_obj_2


# Generated at 2022-06-25 04:56:59.994350
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.deserialize(None)
    except AnsibleAssertionError as e:
        assert e.message == 'data (None) should be a dict but is a <type \'NoneType\'>'



# Generated at 2022-06-25 04:57:03.488745
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """
    Test method post_validate of class FieldAttributeBase
    """
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.post_validate(templar=None)
    except NotImplementedError as e:
        assert(to_native(e) == "This should have been implemented in a subclass")


# Generated at 2022-06-25 04:57:05.266816
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = {}
    assert field_attribute_base_0.dump_attrs() == attrs


# Generated at 2022-06-25 04:57:34.377026
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fields = [
        'a',
        'b',
        'c'
    ]
    aliases = [
        'aa',
        'bb',
        'cc'
    ]
    field_attribute_base_0 = FieldAttributeBase(fields, aliases)
    res = field_attribute_base_0.dump_me()

    assert res['keys'] == ['a', 'b', 'c'], res['keys']
    assert res['aliases'] == ['aa', 'bb', 'cc'], res['aliases']
    assert res['defaults'] == {}, res['defaults']
    assert res['static'] == {}, res['defaults']
    assert res['required'] == {}, res['defaults']
    assert res['deprecated'] == {}, res['defaults']


# Generated at 2022-06-25 04:57:44.220585
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.vars = {}
    field_attribute_base_0.post_validate = lambda x:0
    field_attribute_base_0.module_defaults = {}
    field_attribute_base_0._post_validate_module_defaults = lambda x, y, z:0
    field_attribute_base_0.module_vars = {}
    field_attribute_base_0._post_validate_module_vars = lambda x, y, z:0
    field_attribute_base_0.delegate_to = None
    field_attribute_base_0._post_validate_delegate_to = lambda x, y, z:0
    field_attribute_base_0.become = None
    field_attribute_base

# Generated at 2022-06-25 04:57:48.604053
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()

    try:
        field_attribute_base_1 = field_attribute_base_0.copy()
    except Exception as exception:
        print("Exception: {}".format(exception))


# Generated at 2022-06-25 04:57:49.097255
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    test_case_0()


# Generated at 2022-06-25 04:57:58.861160
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_3 = FieldAttributeBase()

    field_attribute_base_0.finalize()
    field_attribute_base_1.finalize()
    field_attribute_base_2.finalize()
    field_attribute_base_3.finalize()


# Generated at 2022-06-25 04:58:04.889343
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.post_validate('templar')


# Generated at 2022-06-25 04:58:15.878989
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    field_attribute_base_0 = FieldAttributeBase()

    # test case 0
    try:
        name = 'name'
        attribute = FieldAttribute(isa='string', required=True)
        value = None
        templar = Templar()
        field_attribute_base_0.get_validated_value(name, attribute, value, templar)
    except AnsibleParserError as e:
        #print(e)
        assert(e.message == "the field '%s' is required but was not set" % name)

    # test case 1

# Generated at 2022-06-25 04:58:26.616560
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # (const) attribute isa set to 'class'
    # (const) isa = 'class'
    # (const) isa = 'bool'
    # (const) isa = 'float'
    # (const) isa = 'int'
    # (const) isa = 'list'
    # (const) isa = 'percent'
    # (const) isa = 'set'
    # (const) isa = 'dict'
    # (const) isa = 'string'

    field_attribute_base_0_inst = FieldAttributeBase()

    input0 = "str"
    input1 = "str"
    input2 = "str"
    input3 = "str"
    input4 = "str"
    input5 = "str"
    input6 = "str"

# Generated at 2022-06-25 04:58:29.533409
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_attrs() == {}, "dump_attrs return incorrect values"


# Generated at 2022-06-25 04:58:36.089917
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.deserialize(None)  # pass the test if no exception thrown
    except Exception as e:
        assert False, "Unexpected exception thrown"



# Generated at 2022-06-25 04:59:10.593666
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Instantiate an object
    my_attr = FieldAttributeBase()
    # Call the method
    my_attr.dump_attrs()


# Generated at 2022-06-25 04:59:13.991154
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # build test class
    try:
        # build test class
        test_class = BaseMeta.__new__(BaseMeta, 'TestClass', (), {})
    except AttributeError:
        pass
    except Exception as e:
        raise AssertionError(e)



# Generated at 2022-06-25 04:59:18.248288
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._attributes = dict(key1='value1')

    # no errors should be thrown
    try:
        field_attribute_base_0.dump_me()
    except Exception as e:
        raise AssertionError("Unexpected exception raised:", e)


# Generated at 2022-06-25 04:59:19.136114
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pass


# Generated at 2022-06-25 04:59:21.227268
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # tests
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:59:23.452772
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """
    This function tests validate of class FieldAttributeBase
    """
    ds0 = dict()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.validate(ds0)


# Generated at 2022-06-25 04:59:25.130024
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy()


# Generated at 2022-06-25 04:59:26.996561
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()


# Generated at 2022-06-25 04:59:36.004103
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    field_attribute_base = FieldAttributeBase(
        name='name',
        always_post_validate=True,
        class_type=None,
        default=None,
        default_in_v2_only=False,
        doc=None,
        isa=None,
        listof=None,
        priority=1,
        required=False,
        static=False)

    actual_copy = field_attribute_base.copy()

    assert isinstance(actual_copy, FieldAttributeBase)


# Generated at 2022-06-25 04:59:38.555236
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_from_attrs = FieldAttributeBase()
    field_attribute_base_from_attrs.from_attrs( {} )


# Generated at 2022-06-25 05:00:09.409483
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''
    FieldAttributeBase: FieldAttributeBase.validate
    '''
    base_0 = Base()
    FABase_0 = FieldAttributeBase(default=base_0.private_field, exclude=base_0.private_field, include=base_0.private_field,
                                  no_log=base_0.private_field, required=base_0.private_field, static=base_0.private_field)
    FABase_1 = FieldAttributeBase(default=base_0.private_field, exclude=base_0.private_field, include=base_0.private_field,
                                  no_log=base_0.private_field, required=base_0.private_field, static=base_0.private_field)

# Generated at 2022-06-25 05:00:11.171288
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert base.get_dep_chain() == None


# Generated at 2022-06-25 05:00:15.217312
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_0 = Base()
    base_2 = None
    base_3 = None
    base_0.ds = base_2
    base_1 = FieldAttributeBase()
    assert base_1.get_ds(base_0) == base_3


# Generated at 2022-06-25 05:00:17.606016
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    attribute = FieldAttributeBase()
    data = attribute.load_data(attr='attr')
    assert data == 'attr'


# Generated at 2022-06-25 05:00:26.565325
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()

    # case 0 (default)
    assert base_0.get_dep_chain() is None

    # case 1 (Chain 1)
    role_0 = Role()
    task_0 = Task()
    role_0._tasks = [task_0,]
    task_0._parent = role_0
    assert task_0.get_dep_chain() == [role_0]

    # case 2 (Chain 2)
    role_1 = Role()
    role_0._parent = role_1
    assert task_0.get_dep_chain() == [role_1, role_0]

    # case 3 (Chain 3)
    play_0 = Play()
    role_1._parent = play_0

# Generated at 2022-06-25 05:00:38.363598
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    attr = FieldAttribute(isa='int', default=0)
    value = base_0.get_validated_value(None, attr, 10.5, None)
    assert value == 10
    value = base_0.get_validated_value(None, attr, "3", None)
    assert value == 3
    attr = FieldAttribute(isa='list', listof=string_types)
    value = base_0.get_validated_value(None, attr, ["a", "b"], None)
    assert value == ["a", "b"]
    value = base_0.get_validated_value(None, attr, "a,b", None)
    assert value == ["a", "b"]
    assert value[1] == "b"
    attr = Field

# Generated at 2022-06-25 05:00:46.901357
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    # Simulate a string that is bool will be changed to boolean
    bool_true = base_0.get_validated_value('bool_value', FieldAttribute(isa='bool'), 'True', None)
    assert bool_true is True

    # A string that is not a bool will not change
    not_bool = base_0.get_validated_value('bool_value', FieldAttribute(isa='bool'), 'not_bool', None)
    assert not_bool == 'not_bool'

    # A bool that is not in string form will not change
    bool_true = base_0.get_validated_value('bool_value', FieldAttribute(isa='bool'), True, None)
    assert bool_true is True

    # A int that is in a string will be changed to an int

# Generated at 2022-06-25 05:00:47.893729
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    attribute = Base()
    attribute.dump_me()


# Generated at 2022-06-25 05:00:50.980026
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    base_0._parent = object
    base_0._parent.get_dep_chain = lambda: "abcd"
    assert base_0.get_dep_chain() == "abcd"

    base_1 = Base()
    base_1._parent = object
    base_1._parent.get_dep_chain = lambda: None
    assert base_1.get_dep_chain() == None


# Generated at 2022-06-25 05:00:57.004569
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_1 = Base()
    with pytest.raises(AnsibleAssertionError):
        base_1.load_data(None, 'load_data', None, None)
    with pytest.raises(AnsibleAssertionError):
        base_1.load_data(None, 'load_data1', None, None)


# Generated at 2022-06-25 05:01:28.353613
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    Assert(base_0._valid_attrs == {})

    base_1 = Base(ds=dict(
        a=1, b=2, c=555
    ))
    Assert(len(base_1._valid_attrs) == 3)
    Assert(base_1.a == 1)
    Assert(base_1.b == 2)
    Assert(base_1.c == 555)

    # Make sure we don't have a name attribute
    Assert(not hasattr(base_1, 'name'))

    base_2 = Base(name='blah', ds=dict(
        a=2, b=3
    ))
    Assert(base_2.name == 'blah')
    Assert(base_2.a == 2)
    Ass

# Generated at 2022-06-25 05:01:32.181920
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # ansible/lib/ansible/playbook/base.py,
    # class FieldAttributeBase
    raise NotImplementedError()


# Generated at 2022-06-25 05:01:36.544085
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    f1 = FieldAttributeBase()
    f1.load_data('name', 'foo')
    f1.load_data('no_log', True)
    f1.load_data('bad_name', 'foo')


# Generated at 2022-06-25 05:01:40.939896
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Create a FieldAttribute object
    fld_attr = FieldAttributeBase()
    fld_attr.validate(None)


# Generated at 2022-06-25 05:01:49.230635
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create a basic object to act on
    base_0 = Base()
    # Set the data structure
    base_0.set_ds({'name': 'base', 'version': 1})
    # Verify the ds was added to the object as expected
    assert base_0._ds == {'name': 'base', 'version': 1}



# Generated at 2022-06-25 05:01:54.590212
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base_0 = FieldAttributeBase(name='foo')
    if not isinstance(base_0, object):
        raise AssertionError(("Expected '%s' to be a %s") % (repr(base_0), 'object'))


# Generated at 2022-06-25 05:01:56.622001
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    if(base_0.get_dep_chain()!=None):
        raise AssertionError('Expected value: %s, Actual Value: %s' %(None,base_0.get_dep_chain()))

# Generated at 2022-06-25 05:02:04.037445
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()

    # TODO: This will be a problem for any attr that is a
    # FieldAttributeBase derived class, such as files
    # which will cause a failure.
    base_0.from_attrs({})
    base_0.from_attrs({'hosts': '127.0.0.1'})

    # test that serialize/deserialize works
    serialized = {'bar': 1, 'foo': 2}
    base_0.serialize = lambda: serialized
    repr = base_0.get_ds()
    assert repr['bar'] == 1
    rehydrated = Base()
    rehydrated.deserialize(repr)
    assert rehydrated.serialize() == serialized


# Generated at 2022-06-25 05:02:09.749194
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FieldAttributeBase()
    # hasattr is not yet implemented on the C side
    if not hasattr(attr, 'isa'):
        attr.isa = 'str'
        attr.required = False
        attr.default = ""

    base_0 = Base()
    base_0._valid_attrs = { }
    base_0._valid_attrs['foo'] = attr
    templar = Templar()
    base_0.post_validate(templar)



# Generated at 2022-06-25 05:02:20.268700
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    fa = FieldAttributeBase('foo', 'description', True, 'default')
    # Note the repr and str methods do not produce output that conforms to the
    # format used by assert_equal_repr
    assert repr(fa) == "FieldAttributeBase('foo', 'description', True, default='default')"
    assert str(fa) == "FieldAttributeBase('foo', 'description', True, default='default')"
    fa2 = fa.copy()
    assert fa2.name == 'foo'
    assert fa2.description == 'description'
    assert fa2.required == True
    assert fa2.default == 'default'
    assert fa2.always_post_validate == False

    fa3 = fa2.copy(name='foo2')
    assert fa3.name == 'foo2'