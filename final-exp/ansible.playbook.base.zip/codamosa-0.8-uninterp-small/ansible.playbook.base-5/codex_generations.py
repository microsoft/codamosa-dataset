

# Generated at 2022-06-25 04:54:00.471167
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    dep_chain = field_attribute_base_0.get_dep_chain()
    assert dep_chain is None, 'Base.get_dep_chain() returned %s instead of None' % dep_chain


# Generated at 2022-06-25 04:54:11.903278
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    # case 1
    try:
        assert field_attribute_base_0.validate('6')
        assert field_attribute_base_1.validate('6')
    except ExceptionType as e:
        print ("Unexpected Exception: %s", e)
    # case 2
    try:
        assert field_attribute_base_0.validate('4')
        assert field_attribute_base_1.validate('4')
    except ExceptionType as e:
        print ("Unexpected Exception: %s", e)
    # case 3
    try:
        assert field_attribute_base_0.validate('8')
    except ExceptionType as e:
        print ("Unexpected Exception: %s", e)
   

# Generated at 2022-06-25 04:54:13.123562
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:54:23.184632
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Testing all data types
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_3 = FieldAttributeBase()
    field_attribute_base_4 = FieldAttributeBase()
    field_attribute_base_5 = FieldAttributeBase()
    field_attribute_base_6 = FieldAttributeBase()
    field_attribute_base_7 = FieldAttributeBase()
    field_attribute_base_8 = FieldAttributeBase()
    templar = mock.Mock()
    assert field_attribute_base_0.get_validated_value("name0", field_attribute_base_1, "1804289383", templar) == 1804289383
    assert field_attribute_base_0.get

# Generated at 2022-06-25 04:54:27.541360
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_attrs()


# Generated at 2022-06-25 04:54:28.474835
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:54:30.428701
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    class_name = 'FieldAttributeBase'
    class_0 = field_attribute_base_0.dump_me()
    assert class_0 == class_name


# Generated at 2022-06-25 04:54:31.942327
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = Base()
    Base.get_dep_chain(obj)


# Generated at 2022-06-25 04:54:40.011923
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    # Call method get_validated_value of class FieldAttributeBase
    # with name='name', attribute='attribute', value='value', templar='templar'
    # TODO: This test is incomplete.
    field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')


# Generated at 2022-06-25 04:54:44.077084
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # create an instance of class FieldAttributeBase
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_ds() == None


# Generated at 2022-06-25 04:55:20.491004
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1.dump_attrs() == {}


# Generated at 2022-06-25 04:55:22.355850
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    base.name = 'test'
    assert base.get_dep_chain() == None


# Generated at 2022-06-25 04:55:30.386839
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    # test assigning integer value
    val = field_attribute_base_base_0.get_validated_value('test', field_attribute.FieldAttribute(isa='int'), '10', None)
    assert isinstance(val, int)
    # test assigning string value
    val = field_attribute_base_base_0.get_validated_value('test', field_attribute.FieldAttribute(isa='string'), 'test string', None)
    assert isinstance(val, string_types)


# Generated at 2022-06-25 04:55:32.089702
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_me() is None


# Generated at 2022-06-25 04:55:40.560392
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = "name1"
    ds = {"name1": "v1"}
    templar = AnsibleTemplar(loader=None)
    try:
        field_attribute_base_0.validate(ds=ds, templar=templar)
    except AnsibleUndefinedVariable as e:
        assert True
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 04:55:44.544599
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_validated_value(name = 'test_name', 
                                             attribute = 'test_attribute', 
                                             value = 'test_value', 
                                             templar = 'test_templar') == 'test_value'


# Generated at 2022-06-25 04:55:52.632310
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create a test object of type FieldAttributeBase using the constructor
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._validated = True
    field_attribute_base_0._variable_manager = DataLoader()
    field_attribute_base_0._loader = DataLoader()
    field_attribute_base_0._uuid = 'aabdc6aa-3690-42f6-b7fc-c9c3e813e12d'
    field_attribute_base_0._finalized = True
    field_attribute_base_0._ds = DataLoader()
    field_attribute_base_0._loader_cache = 'aabdc6aa-3690-42f6-b7fc-c9c3e813e12d'

    # Create a sample variable dictionary
    variable

# Generated at 2022-06-25 04:55:54.997082
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # run test
    field_attribute_base_0 = FieldAttributeBase()
    try:
        result = field_attribute_base_0.dump_me()
    except ValueError as e:
        assert False


# Generated at 2022-06-25 04:56:03.249892
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test case A
    field_attribute_base_a = FieldAttributeBase()
    field_attribute_base_a.get_validated_value('name_a', 'attribute_a', 'value_a', 'templar_a')
    # Test case B
    field_attribute_base_b = FieldAttributeBase()
    field_attribute_base_b.get_validated_value('name_b', 'attribute_b', 'value_b', 'templar_b')
    # Test case C
    field_attribute_base_c = FieldAttributeBase()
    field_attribute_base_c.get_validated_value('name_c', 'attribute_c', 'value_c', 'templar_c')


# Generated at 2022-06-25 04:56:05.391042
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    if field_attribute_base_0.deserialize(__an_object__) == __an_object__:
        raise AssertionError()
    else:
        pass
    return


# Generated at 2022-06-25 04:56:45.457151
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # setup
    fake_class = type('FakeClass', (object,), {})
    fake_obj = fake_class()

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()

    # default test cases
    data = {'key0': 'value0'}
    field_attribute_base_0.load_data(fake_obj, data)
    assert fake_obj.key0 == 'value0'

    # corner cases
    try:
        data = {5: 'value0'}
        field_attribute_base_1.load_data(fake_obj, data)
    except TypeError:
        pass
    else:
        assert False, "Didn't catch TypeError"


# Generated at 2022-06-25 04:56:48.762806
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''FieldAttributeBase class.get_validated_value method unit test'''

    field_attribute_base_0 = FieldAttributeBase()

    # TODO: Replace this test stub with a real unit test.
    try:
        field_attribute_base_0.get_validated_value(None, None, None)
    except:
        pass


# Generated at 2022-06-25 04:56:54.660052
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    data = dict(name=dict(valid_when=lambda x: x is not None))
    field_attribute_base_0.load_data(data)
    assert field_attribute_base_0.name == dict(valid_when=lambda x: x is not None)


# Generated at 2022-06-25 04:57:01.221695
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Created a test object
    field_attribute_base_0 = FieldAttributeBase()
    # Dumps all attributes to a dictionary
    result = field_attribute_base_0.dump_attrs()
    assert result is not None
    assert len(result) == 0
    assert {'finalized': False, 'squashed': False, 'uuid': 'd1f50fb7-9cac-4a7e-bbc4-a7c24a663733'} == result


# Generated at 2022-06-25 04:57:05.145102
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._valid_attrs.update({'var_name': 'var_val'})
    field_attribute_base_0._attributes.update({'var_name': 'var_val'})
    expected_result = {'var_name': 'var_val'}
    assert field_attribute_base_0.dump_attrs() == expected_result



# Generated at 2022-06-25 04:57:11.113309
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1.validate(None, 'None', 'Static', 'Static')
    field_attribute_base_1.validate(None, 'None', 'Static', 'Static', 'Static')
    '''
    pass


# Generated at 2022-06-25 04:57:13.860002
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_1 = FieldAttributeBase()
    run_result = field_attribute_base_1.validate()
    assert run_result is None


test_case_0()

if __name__ == "__main__":
    test_FieldAttributeBase_validate()

# Generated at 2022-06-25 04:57:18.260365
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_path() == ""


# Generated at 2022-06-25 04:57:28.093179
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    desc = 'the field is of the wrong type'
    field_attribute_base = FieldAttributeBase()
    # None values should return None
    (attribute, value) = (FieldAttribute('test', None, 'dict'), None)
    res = field_attribute_base.get_validated_value('test', attribute, value, None)
    assert res is None and desc

    (attribute, value) = (FieldAttribute('test', None, 'int'), None)
    res = field_attribute_base.get_validated_value('test', attribute, value, None)
    assert res is None and desc

    # value is of the wrong type
    (attribute, value) = (FieldAttribute('test', None, 'dict'), [])

# Generated at 2022-06-25 04:57:30.354518
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    print("FieldAttributeBase: dump_attrs")
    print("=====================")
    result = field_attribute_base_0.dump_attrs()
    print(result)


# Generated at 2022-06-25 04:58:25.733686
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base()
    # Should do something with field_attribute_base_0.
    # Should do something with base_0.


# Generated at 2022-06-25 04:58:30.823449
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    test_object = FieldAttributeBase()
    test_object.foo = 'bar'
    test_object._vars = {'bam': 'baz'}

    result = test_object.dump_attrs()

    assert result == {'foo': 'bar', 'vars': {'bam': 'baz'}}


# Generated at 2022-06-25 04:58:33.722985
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    pass


# Generated at 2022-06-25 04:58:41.417241
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.default = 'somevalue'
    field_attribute_base_0.required = True
    field_attribute_base_0.static = False
    field_attribute_base_0.aliases = ['somekey']

    field_attribute_base_1 = field_attribute_base_0.copy()

    assert field_attribute_base_0.default == field_attribute_base_1.default
    assert field_attribute_base_0.required == field_attribute_base_1.required
    assert field_attribute_base_0.static == field_attribute_base_1.static
    assert set(field_attribute_base_0.aliases) == set(field_attribute_base_1.aliases)


# Generated at 2022-06-25 04:58:47.979267
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # create an empty FieldAttributeBase object
    field_attribute_base_0 = FieldAttributeBase()
    try:
        # call to get_dep_chain of FieldAttributeBase object
        field_attribute_base_0.get_dep_chain()
    except AttributeError:
        print('Attribute error !')
        print('The get_dep_chain method of Base class is not defined')


# Generated at 2022-06-25 04:58:55.572549
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()

    # Test attribute '_uuid'
    # Make sure we can use the same UUID
    # We don't use UUID1, as host specific
    uuid_0 = UUID('3c4b2a9b-94d4-4f4d-bcc4-10df39a8bacd')
    # Test attribute '_finalized'
    field_attribute_base_0._finalized = True

    # Test attribute '_squashed'
    field_attribute_base_0._squashed = True

    # Test attribute '_loader'
    # Test attribute '_variable_manager'
    # Test attribute '_validated'
    # Test attribute '_valid_attrs'
    # Test attribute '_deprecated_attrs'
    # Test attribute '

# Generated at 2022-06-25 04:58:58.836010
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    field_attribute_base_0 = test_case_0()
    assert field_attribute_base_0 is not None

    with pytest.raises(AnsibleAssertionError) as excinfo:
        field_attribute_base_0.from_attrs('string')

    assert 'data (string) should be a dict but is a <class \'str\'>' in to_native(excinfo.value)


# Generated at 2022-06-25 04:59:02.063388
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()

    field_attribute_base_0.dump_me()


# Generated at 2022-06-25 04:59:09.545360
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'field_attribute_base_0'
    field_attribute_base_1 = field_attribute_base_0.copy()
    field_attribute_base_1.name = 'field_attribute_base_1'
    assert field_attribute_base_0.name == 'field_attribute_base_0'
    assert field_attribute_base_1.name == 'field_attribute_base_1'


# Generated at 2022-06-25 04:59:13.301315
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    foo = FieldAttributeBase()
    val = 0
    exp = True
    res = foo.validate(val)
    assert res == exp


# Generated at 2022-06-25 04:59:49.212426
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # create base object
    base_0 = Base()

    # create data object
    data = {'foo': 'baz', 'bar': 'qux'}

    # call to the load_data method
    base_0.load_data(data)


# Generated at 2022-06-25 04:59:57.966241
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with normal values
    base_0 = Base()
    base_0._valid_attrs['role_name'] = FieldAttribute(isa='string')
    base_0._valid_attrs['role_name'].set_default(None)
    base_0.role_name = ''
    base_0._valid_attrs['test_case'] = FieldAttribute(isa='string')
    base_0._valid_attrs['test_case'].set_default(None)
    base_0.test_case = 'test_case_0'
    base_0._valid_attrs['date'] = FieldAttribute(isa='string')
    base_0._valid_attrs['date'].set_default(None)
    base_0.date = '21-10-2017'

# Generated at 2022-06-25 04:59:59.037034
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 05:00:03.917153
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base = Base()
    output = base.dump_attrs()
    assert len(output) == 2
    assert output['name'] == 'Base'
    assert isinstance(output['vars'], dict)

    # test for the case where name is set
    base = Base(name='foo')
    output = base.dump_attrs()
    assert len(output) == 2
    assert output['name'] == 'foo'
    assert isinstance(output['vars'], dict)


# Generated at 2022-06-25 05:00:06.054700
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr_base = FieldAttributeBase()
    attr_base._post_validate(None)
    attr_base.always_post_validate = True
    attr_base._post_validate(None)


# Generated at 2022-06-25 05:00:07.694909
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    try:
        base_0.from_attrs(False)
    except Exception as e:
        print('Exception raised: {0}'.format(e))


# Generated at 2022-06-25 05:00:15.834563
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create a new object and set some of it's attributes
    base_0 = Base()
    base_0.name = 'name_0'
    base_0.vars = dict({'key_0':'value_0', 'key_1':'value_1', 'key_2':'value_2'})
    attrs = base_0.serialize()

    # Create a new object and assign it's attributes
    base_1 = Base()
    base_1.from_attrs(attrs)
    assert base_1.name == 'name_0'


# Generated at 2022-06-25 05:00:17.465069
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field = FieldAttributeBase()
    assert field.dump_me() == '<FieldAttributeBase>'

# Generated at 2022-06-25 05:00:22.531972
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_field_attribute = FieldAttributeBase('bar')
    my_field_attribute.always_post_validate = False
    my_field_attribute.isa = 'class'
    my_task = Base()
    my_task.post_validate('templar')


# Generated at 2022-06-25 05:00:26.250424
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    class FieldAttributeBaseTest(object):
        def test_1(self):
            base_1 = FieldAttributeBase()
            base_2 = base_1.copy()
            assert base_1 == base_2
            base_1.name = 'a'
            assert base_1 != base_2


# Generated at 2022-06-25 05:01:39.077077
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    attr1 = FieldAttribute(isa='string')
    attr1_copy = attr1.copy()
    assert attr1_copy.isa == 'string' and attr1_copy.static == False

    attr2 = FieldAttribute(isa='string', static=True, required=True)
    attr2_copy = attr2.copy()
    attr3_copy = attr2.copy(required=False)
    assert attr2_copy.isa == 'string' and attr2_copy.static == True and attr2_copy.required == True
    assert attr3_copy.isa == 'string' and attr3_copy.static == True and attr3_copy.required == False


# Generated at 2022-06-25 05:01:46.070877
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    class FieldAttributeBase_Test(FieldAttributeBase):
        def __init__(self):
            super(FieldAttributeBase_Test, self).__init__()
            self.static = True
            self.always_post_validate = False
            self.required = True
            self.hashable = False
            self.unique = False
            self.type = 'type'
            self.aliases = ['alias1', 'alias2']
            self.label = 'label'
            self.description = 'description'
            self.private = True
            self.default = 'default'
            self.choices = ['c1', 'c2', 'c3']
            self.include_in_dump = True
            self.elements = ['e1', 'e2']
            self.class_type = Base

    f = FieldAttributeBase_Test

# Generated at 2022-06-25 05:01:55.792044
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    fake_loader = DictDataLoader({'test_inventory': '@test_data.txt'})
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list='test_inventory')

    # test the validation of each type and attributes
    b = Base()
    b.vars = {"test": "value"}

    # test string
    # check the type validation
    name = 'name'
    attribute = FieldAttribute(isa='string')
    value = 3
    templar = Templar(loader=None, variables=None)

# Generated at 2022-06-25 05:01:57.764371
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert True



# Generated at 2022-06-25 05:02:00.013035
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    t = Base()
    attr = {'isa': 'int'}
    t.get_validated_value('var_name', attr, 5, None)

# Generated at 2022-06-25 05:02:03.252444
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    test_obj = FieldAttributeBase()
    assert test_obj.squash == False


# Generated at 2022-06-25 05:02:13.147755
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base()

    # Test for correct error on incorrect 'isa' type
    base_1.attribute_0 = 'string'
    with pytest.raises(AnsibleParserError) as excinfo:
        base_1.post_validate(None)
    assert "the field 'attribute_0' has an invalid value (string), and could not be converted to an int." in to_text(excinfo)

    # Test for correct error on type error in 'listof'
    base_1.attribute_1 = ['string', 1]
    with pytest.raises(AnsibleParserError) as excinfo:
        base_1.post_validate(None)

# Generated at 2022-06-25 05:02:22.221922
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    fa = FieldAttributeBase('A')
    assert fa.isa == 'string'
    assert fa.required
    assert fa.default is None
    assert not fa.always_post_validate
    assert not fa.static

    fa = FieldAttributeBase('A', isa='string', required=True, default='z')
    assert fa.isa == 'string'
    assert fa.required
    assert fa.default == 'z'

    fa = FieldAttributeBase('A', isa='string', required=False)
    assert fa.isa == 'string'
    assert not fa.required
    assert fa.default is None

    fa = FieldAttributeBase('A', isa='string', listof=str)
    assert fa.isa == 'list'
    assert fa.listof == str
    assert not fa.required
    assert fa.default is None

# Generated at 2022-06-25 05:02:34.097601
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attribute = FieldAttribute()

    args = ('test',)
    kwargs = {
        'required': True,
        'always_post_validate': True,
        'static': True,
        'isa': 'string',
        'default': 'test',
        'listof': 'string',
    }

    # Check when name is not string
    try:
        attribute.validate(0, **kwargs)
    except TypeError as e:
        assert "name must be a string" in to_text(e)

    # Check when required is not boolean
    kwargs['required'] = 0
    try:
        attribute.validate(*args, **kwargs)
    except TypeError as e:
        assert "required must be a boolean" in to_text(e)
    kwargs['required'] = True

   

# Generated at 2022-06-25 05:02:39.542568
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class MyObject(object):
        def __init__(self):
            self.test = 'test'

    class MyAttribute(FieldAttributeBase):
        pass
