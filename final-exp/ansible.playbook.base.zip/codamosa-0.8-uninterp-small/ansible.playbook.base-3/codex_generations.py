

# Generated at 2022-06-25 04:54:34.876085
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    data = {
        'name': 'test_name',
        'param': 'a_param',
        'param1': 'a_param1',
        'param2': 'a_param2',
        'param3': 'a_param3',
        'param4': 'a_param4',
        'param5': 'a_param5',
        'param6': 'a_param6',
        'param7': 'a_param7',
        'list_of_integer': list(range(5)),
    }
    class TestActual(Base):
        integer_attribute = FieldAttribute(isa='int')
        list_of_integer_attribute = FieldAttribute(isa='list', listof='int')

    test_actual = TestActual()
    test_actual.name = data['name']
    test_actual.integer

# Generated at 2022-06-25 04:54:46.864192
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    ba = Base()

    # test string isa
    obj = {'a': 'a'}
    value = ba.get_validated_value('a', FieldAttribute(isa='string', required=True), obj, templar=None)
    assert value == 'a'

    # test int isa
    obj = {'a': '1'}
    value = ba.get_validated_value('a', FieldAttribute(isa='int', required=True), obj, templar=None)
    assert value == 1

    # test float isa
    obj = {'a': 1}
    value = ba.get_validated_value('a', FieldAttribute(isa='float', required=True), obj, templar=None)
    assert value == 1.0

    # test bool isa

# Generated at 2022-06-25 04:54:54.568414
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    attr = FieldAttribute(isa='string')
    attrs = base_0._get_validated_value('name', attr, None, None)
    assert attrs == None, 'Get None value when convert None to string type'
    attr = FieldAttribute(isa='int')
    attrs = base_0._get_validated_value('name', attr, None, None)
    assert attrs == None, 'Get None value when convert None to int type'
    attrs = base_0._get_validated_value('name', attr, 2, None)
    assert attrs == 2, 'Get 2 value when convert 2 to int type'
    attr = FieldAttribute(isa='float')

# Generated at 2022-06-25 04:55:00.123724
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    # attribute 4

    fa_0_a = FieldAttributeBase(isa="string", required=True)
    contraint_0 = Base()
    contraint_0.name = 'test'
    contraint_1 = Base()
    contraint_1.name = 'test'
    fa_0_a.constraints = [contraint_0, contraint_1]
    fa_0_a.post_validate()

    # attribute 5
    fa_0_a = FieldAttributeBase(isa="string", required=False)
    contraint_0 = Base()
    contraint_0.name = 'test'
    contraint_1 = Base()
    contraint_1.name = 'test'

# Generated at 2022-06-25 04:55:03.274571
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() == None



# Generated at 2022-06-25 04:55:13.217396
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base = Base()
    attr = FieldAttributeBase()
    attr.isa = 'string'
    value = base.get_validated_value('', attr, u'foo', None)
    assert value == 'foo'
    attr.isa = 'int'
    value = base.get_validated_value('', attr, '3', None)
    assert value == 3
    attr.isa = 'int'
    value = base.get_validated_value('', attr, '3.5', None)
    assert value == 3
    attr.isa = 'float'
    value = base.get_validated_value('', attr, '3.5', None)
    assert value == 3.5
    attr.isa = 'bool'

# Generated at 2022-06-25 04:55:14.129466
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta_0 = BaseMeta()


# Generated at 2022-06-25 04:55:17.064592
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = FieldAttributeBase(display_name='test_display_name_0', include_in_dump=False)
    assert base_0.dump_me() is False
    base_1 = FieldAttributeBase(display_name='test_display_name_1', include_in_dump=True)
    assert base_1.dump_me() is True


# Generated at 2022-06-25 04:55:26.782170
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pb = Playbook()
    t0 = Task()
    p0 = Play()
    p1 = Play()
    p2 = Play()
    r0 = Role()
    pb.tasks = [t0]
    pb.plays = [p0]
    p0.tasks = [t0]
    p0.plays = [p1]
    p1.plays = [p2]
    p1.tasks = [t0]
    t0.role = r0
    t0.role._role_path = '/home/user/roles/rolename'
    r0._role_path = '/roles/rolename'
    p0._play_path = '/home/user/playbook.yaml'
    p1._play_path = '/home/user/play.yaml'
   

# Generated at 2022-06-25 04:55:35.656466
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    class Base(BaseObject):
        FAKE_0 = FieldAttribute(isa='string')
        FAKE_1 = FieldAttribute(isa='bool')
        FAKE_2 = FieldAttribute(isa='int')
        FAKE_3 = FieldAttribute(isa='list')
        FAKE_4 = FieldAttribute(isa='list', listof=float)
        FAKE_5 = FieldAttribute(isa='list', listof=complex)
        FAKE_6 = FieldAttribute(isa='list', listof=dict)
        FAKE_7 = FieldAttribute(isa='list', listof=string_types)
        FAKE_8 = FieldAttribute(isa='dict')
        FAKE_9 = FieldAttribute(isa='set')
        FAKE_10 = FieldAttribute(isa='float')

# Generated at 2022-06-25 04:56:14.161040
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    att = FieldAttributeBase()
    att.deserialize({'name': 'name', 'isa': 'isa', 'default': 'default', 'static': 'static'})
    repr = att.serialize()
    assert repr == {'name': 'name', 'isa': 'isa', 'default': 'default', 'static': 'static'}


# Generated at 2022-06-25 04:56:19.242985
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta_0 = BaseMeta('Base', (), {})
    # assert base_meta_0.__name__ == 'Base'
    # assert base_meta_0.__bases__ == ()
    # assert base_meta_0.__dict__ == {}



# Generated at 2022-06-25 04:56:20.496672
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field0 = FieldAttributeBase()
    field1 = field0.copy()

# Generated at 2022-06-25 04:56:25.057466
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    import copy
    new_loader = Loader()
    new_vm = VariableManager()
    base_1 = Base(loader=new_loader, variable_manager=new_vm)
    base_2 = Base(loader=new_loader, variable_manager=new_vm)
    base_1.post_validate(Templar(loader=new_loader, variables=new_vm.get_vars()))
    base_2.post_validate(Templar(loader=new_loader, variables=new_vm.get_vars()))


# Generated at 2022-06-25 04:56:34.747874
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    base_0 = Base()
    base_1 = Base()

    # field_attribute = FieldAttributeBase()
    field_attribute = FieldAttributeBase(
            name='name',
            private=False,
            default=False,
            include=True,
            always_post_validate=True
        )

    base_0.test = 'base_0'
    base_1.test = 'base_1'

    base_0.test_attrs = field_attribute
    base_1.test_attrs = field_attribute

    # does it not bake if finalized is False
    assert base_0.squashed == False
    assert base_1.squashed == False

    base_0.finalize()
    base_1.finalize()

    # does squashing do nothing if finalized is True
    assert base_0.squashed

# Generated at 2022-06-25 04:56:46.035751
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    attr = FieldAttributeBase()
    # testing for 'yes'
    value_0 = 'yes'

    # Testing 'yes' as value_0
    try:
        attr.validate(value_0)
        raise AssertionError('Could validate %s as value_0' % (value_0))
    except AnsibleAssertionError as exc:
        # The above exception was raised, make sure it's the right type
        if not exc.args[0] == "The attribute '%s' only accepts strings and cannot be validated as a %s" % (attr.name, type(value_0)):
            raise AssertionError('The above exception was raised, make sure it\'s the right type')

    # testing for 2.0
    value_1 = 2.0

    # Testing 2.0 as value_1
   

# Generated at 2022-06-25 04:56:51.217750
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    def _test_post_validate(FieldAttributeClass, value, expected_value):
        field_attribute = FieldAttributeClass('test_attribute', default=None)
        field_attribute_base = FieldAttributeBase(field_attribute, 'test_attribute', {'test_attribute': field_attribute})
        field_attribute_base.post_validate(value)
        assert field_attribute_base.test_attribute == expected_value

    _test_post_validate(FieldAttributeClass, "test", "test")
    _test_post_validate(FieldAttributeClass, True, True)
    _test_post_validate(FieldAttributeClass, False, False)
    _test_post_validate(FieldAttributeClass, [], [])
    _test_post_validate(FieldAttributeClass, {}, {})
    _test_post_

# Generated at 2022-06-25 04:57:00.418181
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test: data=None
    try:
        attr = FieldAttributeBase()
        attr.load_data(None)
    except:
        pass
    else:
        print('Failed test: data=None')

    # test: data is not a dictionary
    try:
        attr = FieldAttributeBase()
        attr.load_data(False)
    except:
        pass
    else:
        print('Failed test: data is not a dictionary')


# Generated at 2022-06-25 04:57:05.595521
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fb = FieldAttributeBase()
    assert fb.load_data(None) is None
    assert fb.load_data(False) is False
    assert fb.load_data(True) is True


# Generated at 2022-06-25 04:57:11.297002
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    base_0 = Base()
    base_0._squashed = False
    base_0._attributes = {u'_from_parent': {u'from_parent': None,
                                            u'must_copy': False,
                                            u'static': False,
                                            u'omit': False,
                                            u'required': False,
                                            u'required_if': {u'fom_parent': True},
                                            u'is_sub_element': False,
                                            u'class_type': None}}
    base_0._variable_manager = VariableManager()
    base_0.name = u'test'
    base_0.version = 2
    base_0.tags = [u'tag_0', u'tag_1']
    base_0.from_parent

# Generated at 2022-06-25 04:57:39.639494
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test passing value as None and expecting exception
    with pytest.raises(AnsibleAssertionError):
        attr_base = FieldAttributeBase(name='test', always_post_validate=True, isa='string', default=None)
        attr_base.validate(None)

# Unit tests for method validate_value of class FieldAttributeBase

# Generated at 2022-06-25 04:57:41.665091
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    test_case_0()



# Generated at 2022-06-25 04:57:52.117767
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # test case 0
    base_0 = Base()
    base_0._ds = AttrDict(data_source=None, line_number=None)
    base_0._parent = None

    assert base_0.get_search_path() == []

    # test case 1
    base_1 = Base()
    base_1._ds = AttrDict(data_source=None, line_number=None)
    base_1._parent = AttrDict(play=AttrDict(ds=None, line_number=None, _role_path=None))
    base_1._parent._play._ds = AttrDict(data_source=None, line_number=None)
    base_1._parent._play._ds._data_source = None
    base_1._parent._play._ds._line_number

# Generated at 2022-06-25 04:57:53.487694
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
        import json

        # TODO: Implement test_case_1
        #test_case_1

# Generated at 2022-06-25 04:58:03.739940
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # test with when FieldAttributeBase.required is False and False
    fieldAttributeBase_instance = FieldAttributeBase(_field_name='_field_name_0', isa='isa_1', protected=False, default=None, required=False, always_post_validate=False)
    assert fieldAttributeBase_instance.dump_me() == {'_field_name': '_field_name_0', 'isa': 'isa_1', 'protected': False, 'static': False, 'default': None, 'required': False, 'always_post_validate': False, 'choices': set(), 'aliases': []}

    # test with when FieldAttributeBase.required is True and False

# Generated at 2022-06-25 04:58:12.397949
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class MockValidator():
        def __init__(self, name, value):
            self.name = name
            self.value = value
        def __call__(self):
            if isinstance(self.value, string_types):
                self.value = self.value.decode('utf-8')
            return self.value

    # Test that field attribute is initialized with specified
    # parameters. Test that default is used if not specified.
    base_0 = Base()
    assert base_0._valid_attrs['vars'].name == 'vars'
    assert base_0._valid_attrs['vars'].isa == dict
    assert callable(base_0._valid_attrs['vars'].default)
    assert base_0._valid_attrs['vars'].default() == dict()
    assert base

# Generated at 2022-06-25 04:58:15.716097
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = FieldAttributeBase()
    result = base_0.post_validate()
    assert result == None


# Generated at 2022-06-25 04:58:23.324413
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fields={'valid_attrs': {'name': {'default': None,
                                     'valid': 'all',
                                     'required': True,
                                     'no_log': False,
                                     'always_post_validate': True,
                                     'private': False,
                                     'immutable': False,
                                     'static': False,
                                     'isa': 'str'}},
            'attributes': {'name': None},
            '_loader': None,
            '_variable_manager': None,
            '_validated': False,
            '_finalized': False,
            '_uuid': '439a389f-75c1-45e8-a06b-7cf85d6a9c11'}

    obj = Base()
    obj.__dict__.update(fields)
   

# Generated at 2022-06-25 04:58:29.533598
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()
    base_0.dump_me()
    expected = '<FieldAttribute: name: `name` kind: `string` required: `False` default: `None`>'
    actual = str(base_0._valid_attrs['name'])
    assert actual == expected, "\nExpected\n%s\nbut got\n%s" % (expected, actual)


# Generated at 2022-06-25 04:58:40.655602
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    # Test basic usage
    base_0 = Base()
    attrs = {'name': "example", 'something': None, 'uuid': "123456"}
    base_0.from_attrs(attrs)
    assert base_0.name == 'example'
    assert base_0.something == None
    assert base_0._uuid == "123456"

    # Test with complex object
    base_0 = Base()
    attrs = {'name': "example", 'something': {'_name': 'complex_object'}, 'uuid': "123456"}
    base_0.from_attrs(attrs)
    assert base_0.name == 'example'
    assert base_0.something._name == 'complex_object'
    assert base_0._uuid == "123456"


# Generated at 2022-06-25 04:59:16.774716
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # setup test data
    data = {'ansible_ssh_host': 'tester', 'ansible_connection': 'ssh'}

    # create an instance of FieldAttributeBase as a class member
    ba = BaseAnsible()
    ba.async_val = 10

    assert ba._valid_attrs['async_val'].type == int
    assert ba._valid_attrs['async_val'].default == 10
    assert ba._valid_attrs['async_val'].choice == None

    # ensure that the data is a valid integer
    ba._post_validate_async_val(ba._valid_attrs['async_val'], 10, None)
    ba._post_validate_async_val(ba._valid_attrs['async_val'], 10.1, None)
   

# Generated at 2022-06-25 04:59:28.060643
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()


# Generated at 2022-06-25 04:59:37.987049
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    # Try the method on an object that has the '_parent' attribute and the attribute is not none
    base_0 = Base()
    base_0._parent = Base()
    base_0._parent._parent = None

    assert base_0.get_dep_chain() == [base_0._parent]

    # Try the method on an object that has no '_parent' attribute
    base_1 = Base()
    assert base_1.get_dep_chain() is None

    # Try the method on an object that has the '_parent' attribute but it is None
    base_2 = Base()
    base_2._parent = None
    assert base_2.get_dep_chain() is None



# Generated at 2022-06-25 04:59:44.493738
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # testing the method with an integer value
    fa = FieldAttributeBase('foo', int, 'the foo', '')
    assert None == fa.validate(None, '')
    assert 1 == fa.validate(1, 'the foo')
    # testing the method with a boolean value
    fa = FieldAttributeBase('foo', bool, 'the foo', '')
    assert None == fa.validate(None, '')
    assert True == fa.validate(True, 'the foo')
    # testing the method with a string value
    fa = FieldAttributeBase('foo', string_types, 'the foo', '')
    assert None == fa.validate(None, '')
    assert 'bar' == fa.validate('bar', 'the foo')
    # testing the method with an integer value that fails

# Generated at 2022-06-25 04:59:46.168822
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()

    # No parameters set
    base_0.post_validate(templar=None)

    # Parameters set
    base_0.post_validate(templar='')



# Generated at 2022-06-25 04:59:55.521163
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Init a field attribute object
    field_attribute_base_0 = FieldAttributeBase()
    # Init a field attribute object
    field_attribute_base_1 = FieldAttributeBase()
    # Test setting FieldAttributeBase.from_attrs
    # Test method from_attrs on field attribute object field_attribute_base_0
    test_object_0 = field_attribute_base_0.from_attrs({})
    # Test method from_attrs on field attribute object field_attribute_base_1
    test_object_1 = field_attribute_base_1.from_attrs({})


# Generated at 2022-06-25 05:00:05.125801
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    class FakeTask(object):
        pass

    fake_task = FakeTask()
    fake_task.positional_args = range(1,1)
    attribute = FieldAttributeBase()
    attribute.name = 'positional_args'
    assert attribute.squash(fake_task) == []

    fake_task = FakeTask()
    fake_task.positional_args = range(1,2)
    attribute = FieldAttributeBase()
    attribute.name = 'positional_args'
    assert attribute.squash(fake_task) == [1]

    fake_task = FakeTask()
    fake_task.positional_args = range(1,3)
    attribute = FieldAttributeBase()
    attribute.name = 'positional_args'
    assert attribute.squash(fake_task) == [1, 2]

    fake

# Generated at 2022-06-25 05:00:08.768296
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    f = FieldAttribute('name', required=True, static=False)
    assert f.validate('name', 'name', 0)
    f = FieldAttribute('name', required=True, static=False)
    assert f.validate('name', '', 0)
    f = FieldAttribute('name', required=False, static=False)
    assert f.validate('name', '', 0)
    f = FieldAttribute('name', required=True, static=True)
    assert f.validate('name', '', 0)


# Generated at 2022-06-25 05:00:09.896156
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FieldAttributeBase()


# Generated at 2022-06-25 05:00:20.529850
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test for method load_data of class FieldAttributeBase
    # Check default
    obj = FieldAttributeBase()
    assert obj.default is None
    # Check with a default sentinel object
    obj = FieldAttributeBase(default=Sentinel('test'))
    assert obj.default == Sentinel('test')
    # Check Unknown attribute
    obj = FieldAttributeBase(some_attrib='some_value')
    assert obj.some_attrib == 'some_value'
    # Check isa
    obj = FieldAttributeBase(isa='some_type')
    assert obj.isa == 'some_type'
    # Check type name
    obj = FieldAttributeBase()
    assert obj.type_name() == 'FieldAttributeBase'
    # Check static
    obj = FieldAttributeBase(static=True)
    assert obj.static
    # Check class type

# Generated at 2022-06-25 05:01:09.731884
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_0 = Base()



# Generated at 2022-06-25 05:01:12.556118
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fieldattributebase = FieldAttributeBase()
    result = fieldattributebase.post_validate()
    assert result is None


# Generated at 2022-06-25 05:01:21.083776
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    fa = FieldAttributeBase('name', isa='list')
    fa_copy = fa.copy()
    # check that the new instance has the same values as the original one
    assert fa_copy.name == 'name', \
        "The copy of a FieldAttributeBase instance should have 'name' attribute equal to the one of the original instance"
    assert fa_copy.attrname == 'name', \
        "The copy of a FieldAttributeBase instance should have 'attrname' attribute equal to the one of the original instance"
    assert fa_copy.isa == 'list', \
        "The copy of a FieldAttributeBase instance should have 'isa' attribute equal to the one of the original instance"

if __name__ == "__main__":
    import pytest
    pytest.main("-v")

# Generated at 2022-06-25 05:01:28.760266
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    f = FieldAttributeBase('name', 'description', False, None)
    f1 = FieldAttributeBase('name', 'description', True, None)
    f2 = FieldAttributeBase('name', 'description', True, None, True)
    f3 = FieldAttributeBase('name', 'description', True, 'asdf', True)
    f4 = FieldAttributeBase('name', 'description', True, None, True, True, True)

    assert not f.required
    assert f1.required
    assert f2.required
    assert f3.required
    assert f4.required

    assert not f.always_post_validate
    assert not f1.always_post_validate
    assert f2.always_post_validate
    assert f3.always_post_validate
    assert f4.always_post_validate


# Generated at 2022-06-25 05:01:39.397225
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class FieldAttributeBaseTest(FieldAttributeBase):
        def __init__(self, name, class_type=None, default=None, required=False, static=False, isa=None):
            FieldAttributeBase.__init__(self, name, class_type, default, required, static, isa)

    # test no overwrite
    a = FieldAttributeBaseTest('test')
    a.load_data(None)
    assert a.default is None
    assert a.required is False
    assert a.static is False
    assert a.isa is None

    # test overwrite
    a.load_data(dict(default='a', required=True, static=True, isa='b'))
    assert a.default == 'a'
    assert a.required is True
    assert a.static is True

# Generated at 2022-06-25 05:01:42.433736
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    attrs = base_0.dump_attrs()
    assert attrs is None, "base_0.dump_attrs() returned %s but expected %s" % (attrs, None)


# Generated at 2022-06-25 05:01:44.181849
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    fieldattributebase_0 = FieldAttributeBase()
    fieldattributebase_0.deserialize(5)

test_FieldAttributeBase_deserialize()


# Generated at 2022-06-25 05:01:47.859529
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Test_FieldAttributeBase({"attr_0" : True, "attr_1" : "Test"})


# Generated at 2022-06-25 05:01:52.517795
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_1 = FieldAttributeBase()
    try:
        field_1.load_data(test_case_0)
    except Exception as e:
        print("FAIL: Test #1 - unexpected exception")
        traceback.print_exc()
        return False
    return True


# Generated at 2022-06-25 05:01:54.010356
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    base_0.post_validate()


# Generated at 2022-06-25 05:02:45.806625
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """
    Test if the post_validate raise exception if the parameter is not str
    """
    fieldAttributeBase = FieldAttributeBase()
    fieldAttributeBase.default = None
    fieldAttributeBase.required = False
    fieldAttributeBase.always_post_validate = False
    with pytest.raises(AnsibleParserError) as e:
        fieldAttributeBase.post_validate('a_str', 1, 'a_str')
    assert e.value.message == "the field '1' has an invalid value (a_str), and could not be converted to an str."


# Generated at 2022-06-25 05:02:46.941935
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.post_validate()

# Generated at 2022-06-25 05:02:48.794220
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    base_0 = Base()
    base_0.validate()


# Generated at 2022-06-25 05:02:52.479278
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Testing for parameter attribute: type: FieldAttributeBase
    attribute = FieldAttributeBase()
    # Testing for parameter value: type: string
    value = 'test'
    # Testing for parameter name: type: string
    name = 'test'
    # Testing for exception: TypeError
    try:
        Base.get_validated_value(name, attribute, value, templar)
    except TypeError:
        pass



# Generated at 2022-06-25 05:03:02.588609
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    class TestObj(Base):
        _valid_attrs = dict(
            firstname = FieldAttribute(isa='string', default='Brian'),
            lastname  = FieldAttribute(isa='string', default='Zimmerman'),
            age       = FieldAttribute(isa='int', default=32),
            is_admin  = FieldAttribute(isa='bool', default=False),
            friends   = FieldAttribute(isa='list', default=list),
            user_dict = FieldAttribute(isa='dict', default=dict),
        )

    # these combinations of data should all work