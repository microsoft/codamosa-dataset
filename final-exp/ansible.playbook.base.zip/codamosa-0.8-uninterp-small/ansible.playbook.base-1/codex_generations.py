

# Generated at 2022-06-25 04:54:13.485043
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    data = {'test_key': 'test_value'}
    field_attribute_base_0.deserialize(data)
    return True


# Generated at 2022-06-25 04:54:15.720149
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_2.deserialize(data)


# Generated at 2022-06-25 04:54:23.664435
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    # Tests for exceptions raised for different parameters of method
    # validate of class FieldAttributeBase
    field_attribute_base_0.validate(validator=Sentinel)
    field_attribute_base_0.validate(validator=None)


# Generated at 2022-06-25 04:54:27.576261
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.load_data()


# Generated at 2022-06-25 04:54:33.524743
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-25 04:54:42.324637
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # create tasks from yml and validate them

# Generated at 2022-06-25 04:54:53.957034
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test the case where field_attribute is of type FieldAttribute
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_0 = FieldAttribute(name='FIELD', attribute=field_attribute_base_0)
    field_attribute_0.isa = 'bool'
    field_attribute_0.default = 'default'
    field_attribute_0.always_post_validate = 'always_post_validate'
    field_attribute_0.class_type = 'class_type'
    field_attribute_0.required = 'required'
    field_attribute_0.listof = 'listof'
    attribute_0 = field_attribute_0
    name_0 = 'NAME'
    value_0 = 'value'
    templar_0 = MockTemplar()
    # Call the method from the class


# Generated at 2022-06-25 04:54:55.959123
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()


# Generated at 2022-06-25 04:55:04.882820
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()

    # Test with values that should not break the dump_attrs method
    attrs = field_attribute_base_0.dump_attrs()
    for name in attrs.keys():
        assert attrs[name] == field_attribute_base_0._attributes[name]

    # There shouldn't be any elements in attrs that do not exist in _attributes
    assert set(attrs.keys()) == set(field_attribute_base_0._attributes.keys())


# Generated at 2022-06-25 04:55:07.167748
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.load_data()
        assert False, 'ExpectedException'
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 04:55:38.288949
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize({})


# Generated at 2022-06-25 04:55:39.220483
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    dep_chain = base_0.get_dep_chain()


# Generated at 2022-06-25 04:55:48.096829
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()

    field_attribute_base_0.name = 'foo'
    assert field_attribute_base_0.name == 'foo'

    field_attribute_base_0.from_attrs({'name': 'bar'})
    assert field_attribute_base_0.name == 'bar'

    field_attribute_base_0.name = 'foo'
    field_attribute_base_0.from_attrs({'name': 'bar', '_finalized': True})
    assert field_attribute_base_0.name == 'bar'


# Generated at 2022-06-25 04:55:48.712892
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass

# Generated at 2022-06-25 04:55:51.591621
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    data = {}
    assert field_attribute_base_0.from_attrs(data) == {}


# Generated at 2022-06-25 04:55:54.051341
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    tom = FieldAttributeBase()
    data = {"name": "tom", "age": 35, "height": "6'2"}
    output = tom.load_data("name", data)
    assert output == "tom"


# Generated at 2022-06-25 04:55:56.327624
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    method = getattr(Base, 'copy')
    assert callable(method)


# Generated at 2022-06-25 04:56:00.505454
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    # Test with an invalid value
    with pytest.raises(AnsibleParserError):
        field_attribute_base_0.get_validated_value("name", "attribute", "value", "templar")



# Generated at 2022-06-25 04:56:02.449524
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.get_validated_value(
        'name', 'attribute', 'value', 'templar')


# Generated at 2022-06-25 04:56:07.644178
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    dep_chain = field_attribute_base_0.get_dep_chain()
    assert dep_chain is None


# Generated at 2022-06-25 04:56:33.138415
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1.get_dep_chain() is None

# Generated at 2022-06-25 04:56:33.924755
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert False


# Generated at 2022-06-25 04:56:45.469245
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-25 04:56:46.564670
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = field_attribute_base_0.copy()


# Generated at 2022-06-25 04:56:56.658731
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Get a dynamic instance of FieldAttributeBase with dynamic attributes
    field_attribute_base_0 = FieldAttributeBase()
    attr_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'value0'
    field_attribute_base_0.isa = 'string'
    templar = '1a2b3c4d5e6f'
    value = '7g8h9i'
    # Call method get_validated_value of field_attribute_base_0 and check that it returns expected result
    assert field_attribute_base_0.get_validated_value(field_attribute_base_0.name, attr_0, value, templar) == value


# Generated at 2022-06-25 04:57:04.990403
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    task_0 = Task()
    templar_0 = Templar()
    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()
    variable_manager_0._extra_vars = dict()
    variable_manager_0._extra_vars['inventory_hostname'] = 'A'
    variable_manager_0._extra_vars['inventory_hostname_short'] = 'A'
    variable_manager_0._extra_vars['group_names'] = ['g']
    variable_manager_1._extra_vars = dict()
    variable_manager_1._extra_vars['inventory_hostname'] = 'A'
    variable_manager_1._extra_vars['inventory_hostname_short'] = 'A'
    variable_manager_1._extra_vars['group_names']

# Generated at 2022-06-25 04:57:06.665339
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        field_attribute_base_0.post_validate()

# Generated at 2022-06-25 04:57:11.363863
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.deserialize(None)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError("AnsibleAssertionError not raised")


# Generated at 2022-06-25 04:57:17.064315
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_me()


# Generated at 2022-06-25 04:57:18.282170
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.from_attrs(data={})


# Generated at 2022-06-25 04:57:43.287388
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    if field_attribute_base_0.validate() != 'Field attribute base' :
        raise AssertionError('test_FieldAttributeBase_validate failed - expected "Field attribute base" to be returned')

test_case_0()


# Generated at 2022-06-25 04:57:44.805808
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_attrs() == {}


# Generated at 2022-06-25 04:57:52.749673
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    templar = Templar(loader=None, variables=dict())

    # Verify that calling post_validate method raises exception
    # Note: We don't have a mock class that we can instantiate.
    #       This is because FieldAttributeBase was written in such a way
    #       that any calling of post_validate would raise an exception.
    #       A way around this is to create a subclass of FieldAttributeBase
    #       which also implements post_validate.
    assertRaises(Exception, field_attribute_base_0.post_validate, templar)


# Generated at 2022-06-25 04:58:00.257856
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    r = random.randint(0, 10)
    s = FieldAttributeBase()
    assert s.get_validated_value(r, 'int', '5') == 5
    assert s.get_validated_value(r, 'float', '3.4') == 3.4
    assert s.get_validated_value(r, 'bool', 'yes') is True
    assert s.get_validated_value(r, 'list', [1, 2, 3, 5, 7]) == [1, 2, 3, 5, 7]
    assert s.get_validated_value(r, 'percent', '33.4') == 33.4
    assert s.get_validated_value(r, 'percent', '33.4%') == 33.4

# Generated at 2022-06-25 04:58:12.691621
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_copy_0 = field_attribute_base_0.copy()
    assert(field_attribute_base_copy_0.name == 'value')
    assert(field_attribute_base_copy_0.isa == 'str')
    assert(field_attribute_base_copy_0.default is None)
    assert(field_attribute_base_copy_0.static is False)
    assert(field_attribute_base_copy_0.required is False)
    assert(field_attribute_base_copy_0.skip is False)
    assert(field_attribute_base_copy_0.version_added is None)
    assert(field_attribute_base_copy_0.version_removed is None)

# Generated at 2022-06-25 04:58:15.645514
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert None == base_0.get_dep_chain()


# Generated at 2022-06-25 04:58:24.756811
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_1 = FieldAttributeBase()
    data = {'field_attributes': {}}

    # test with bad data, should raise an exception
    try:
        field_attribute_base_1.deserialize(data={})
        assert False
    except AssertionError:
        pass

    # test with data which should pass
    field_attribute_base_1.deserialize(data)
    assert field_attribute_base_1._field_attributes == {}


# Generated at 2022-06-25 04:58:33.242859
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'module'
    field_attribute_base_0.isa = 'str'
    field_attribute_base_0.required = False
    name = 'setup'
    obj = 'Task'
    try:
        value = field_attribute_base_0.validate(name, obj)
        assert False, "Expected Exception not raised"
    except Exception as e:
        if isinstance(e, TypeError):
            assert True, "Expected Exception raised"

if __name__ == '__main__':
    #test_case_0()
    #test_FieldAttributeBase_validate()
    pass

# Generated at 2022-06-25 04:58:39.027734
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy()
    field_attribute_base_0.isa = 'isa'
    field_attribute_base_0.default = 'default'
    field_attribute_base_0.required = 'required'
    field_attribute_base_0.static = 'static'
    field_attribute_base_0.default(field_attribute_base_0)
    field_attribute_base_0.copy(field_attribute_base_0)

# Generated at 2022-06-25 04:58:42.359763
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy()


# Generated at 2022-06-25 04:59:30.136221
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.get_validated_value('', '', '', '')


# Generated at 2022-06-25 04:59:40.206481
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.name = 'name'
    field_attribute_base.isa = 'field'
    field_attribute_base.rw = True
    field_attribute_base.env = True
    field_attribute_base.required = True
    field_attribute_base.default = 'default'
    field_attribute_base.inherited = True
    field_attribute_base.always_post_validate = True
    field_attribute_base.assignment_template = 'template'
    field_attribute_base.choices = ['choice1', 'choice2']
    field_attribute_base.private = True
    field_attribute_base.description = 'description'


# Generated at 2022-06-25 04:59:46.796245
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    try:
        field_attribute_base_0 = FieldAttributeBase()
    except Exception as e:
        print('FAIL: test_FieldAttributeBase_validate()')
        raise e
    else:
        print('PASS: test_FieldAttributeBase_validate()')


# Generated at 2022-06-25 04:59:57.406704
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class FieldAttributeBaseTesting(FieldAttributeBase):
        def __init__(self):
            self._loader = Mock()
            self._variable_manager = Mock()
            self._validated = False
            self._finalized = False
            self._uuid = None
            self._attributes = {'name': FieldAttribute(isa='string'),
                                'int': FieldAttribute(isa='int'),
                                'int_list': FieldAttribute(isa='int', listof='int'),
                                'bool': FieldAttribute(isa='bool'),
                                'bool_list': FieldAttribute(isa='bool', listof='bool'),
                                'str_list': FieldAttribute(isa='string', listof='string')}

# Generated at 2022-06-25 05:00:01.486782
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    1. test for normal case
    '''
    # initialize the FieldAttributeBase object
    field_attribute_base_0 = FieldAttributeBase()

    try:
        ret_res_0 = field_attribute_base_0.dump_me()
    except Exception:
        res_0 = False
    else:
        res_0 = True

    assert res_0 is False


# Generated at 2022-06-25 05:00:03.119527
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        field_attribute_base_0.validate('name', 'default', 'required', 'class_type')


# Generated at 2022-06-25 05:00:05.240606
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 05:00:09.148045
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test = FieldAttributeBase()
    attrs = {
       "bar": "1",
       "bam": 2,
       "boo": 1.2,
       "foo": True,
    }
    test.from_attrs(attrs)
    assert test.bar == '1'
    assert test.bam == 2
    assert test.boo == 1.2
    assert test.foo


# Generated at 2022-06-25 05:00:12.434141
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = {'name': 'foo'}
    field_attribute_base_0.from_attrs(attrs)
    print()
    print(field_attribute_base_0.dump_attrs())


# Generated at 2022-06-25 05:00:24.137979
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.vault import VaultLib
    from six import StringIO


# Generated at 2022-06-25 05:02:48.714594
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    test_obj = FieldAttributeBase()
    test_obj._attributes = { 'a': 1, 'b': 2 }

    get_field_attrs = test_obj.dump_attrs()

    assert get_field_attrs['a'] == 1
    assert get_field_attrs['b'] == 2

# Generated at 2022-06-25 05:02:54.602879
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    """test_FieldAttributeBase_copy"""
    field_attributes = FieldAttributes()

    field_attribute_base_0 = FieldAttributeBase()
    field_attributes.add(attribute_name='x', attr=field_attribute_base_0)

    field_attribute_base_1 = FieldAttributeBase()
    field_attributes.add(attribute_name='y', attr=field_attribute_base_1)

    field_attribute_base_2 = FieldAttributeBase()
    field_attributes.add(attribute_name='z', attr=field_attribute_base_2)

    field_attribute_base_3 = field_attribute_base_0.copy(field_attributes)

    if field_attribute_base_0.name == field_attribute_base_3.name:
        raise AssertionError