

# Generated at 2022-06-25 04:53:56.996858
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    try:
        base_0.get_validated_value(attr='attr', attribute=1, value='1', templar='templar')
    except TypeError as e:
        assert type(e) == TypeError
    else:
        assert False, "Expected a TypeError"


# Generated at 2022-06-25 04:54:01.571488
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Test case 0
    base_0 = Base()
    assert base_0.get_path() == ''

    # Test case 1
    base_1 = Base()
    base_1._ds._data_source = 'test/test.yml'
    base_1._ds._line_number = 3
    assert base_1.get_path() == 'test/test.yml:3'


# Generated at 2022-06-25 04:54:03.402992
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = FieldAttributeBase()
    base_0.dump_me()

# Generated at 2022-06-25 04:54:12.762938
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    #
    # test get_validated_value method when attribute.isa is string and isa_value is string
    #
    base_1 = Base()
    str_value = "string"
    field_attribute = FieldAttributeBase(isa="string")
    # call assert_equals to validate test
    assert_equals(base_1.get_validated_value("name", field_attribute, str_value, templar=None), "string")
    #
    # test get_validated_value method when attribute.isa is string and isa_value is int
    #
    base_2 = Base()
    str_value = 1
    field_attribute = FieldAttributeBase(isa="string")
    # call assert_equals to validate test

# Generated at 2022-06-25 04:54:19.504700
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    post_validate_method = getattr(FieldAttributeBase, 'post_validate')

    # test for python versions < 3.5, where the ``inspect.signature`` method
    # is not available
    try:
        inspect.signature(post_validate_method)
    except (AttributeError, TypeError):
        return

    args = inspect.signature(post_validate_method).parameters
    assert len(args) == 2
    assert list(args.keys()) == ['self', 'templar']


# Generated at 2022-06-25 04:54:28.249600
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    """
    Test get_ds method of FieldAttributeBase.
    """
    mock_obj = Mock()
    mock_obj.get_ds.return_value = "test_ds"
    
    # test when no ds is set
    assert FieldAttributeBase.get_ds(mock_obj) == "test_ds"

    # test when a ds is set
    FieldAttributeBase.set_ds(mock_obj, "test_ds2")
    assert FieldAttributeBase.get_ds(mock_obj) == "test_ds2"


# Generated at 2022-06-25 04:54:34.325180
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    base_0 = Base()

    # Test 1
    # bool
    field_name = 'bool'
    field_value = True
    assert(base_0.get_validated_value(field_name, base_0._valid_attrs[field_name], field_value, None) == field_value)

    # Test 2
    # list
    field_name = 'list'
    field_value = ["a", "b"]
    assert(base_0.get_validated_value(field_name, base_0._valid_attrs[field_name], field_value, None) == field_value)

    # Test 3
    # set
    field_name = 'set'
    field_value = {"a", "b"}

# Generated at 2022-06-25 04:54:37.054229
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    # TODO: stub


# Generated at 2022-06-25 04:54:39.954414
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert base.get_dep_chain() == None


# Generated at 2022-06-25 04:54:43.808168
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # verify that an error is raised if the data argument is None
    with pytest.raises(AttributeError):
        FieldAttributeBase.deserialize(None)


# Generated at 2022-06-25 04:55:11.077725
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    loader.set_basedir('/path/to/playbook')
    variable_manager = VariableManager()

    # Injecting a few more variables to the hostvars

# Generated at 2022-06-25 04:55:17.141648
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test basic validations from FieldAttributeBase
    assert FieldAttributeBase._validate({'isa': 'str'}, None) == None
    assert FieldAttributeBase._validate({'isa': 'str'}, 'test') == 'test'
    assert FieldAttributeBase._validate({'isa': 'str'}, 42) == '42'
    assert FieldAttributeBase._validate({'isa': 'bool'}, 'true') == True
    assert FieldAttributeBase._validate({'isa': 'bool'}, 'yes') == True
    assert FieldAttributeBase._validate({'isa': 'bool'}, 'no') == False
    assert FieldAttributeBase._validate({'isa': 'bool'}, 'on') == True
    assert FieldAttributeBase._validate({'isa': 'bool'}, 'off') == False

# Generated at 2022-06-25 04:55:26.802234
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class TestObj(Base):
        _valid_attrs = {
            'attr1': FieldAttribute(isa='string', required=True),
            'attr2': FieldAttribute(isa='int', required=True),
            'attr3': FieldAttribute(isa='float', required=True),
            'attr4': FieldAttribute(isa='bool', required=True),
            'attr5': FieldAttribute(isa='bool', default=False),
            'attr6': FieldAttribute(isa='percent', required=True),
            'attr7': FieldAttribute(isa='list', listof=str, required=True),
            'attr8': FieldAttribute(isa='set', required=True),
            'attr9': FieldAttribute(isa='dict', required=True),
            'attr10': FieldAttribute(isa='class', class_type=TestObj),
        }

   

# Generated at 2022-06-25 04:55:32.839515
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Setup test
    base_0 = Base()

    attrs = {}
    attrs['_finalized'] = None
    attrs['_squashed'] = None
    attrs['_uuid'] = None


    # Execute code under test
    base_0.from_attrs(attrs)

    # Check results
    assert base_0._finalized is False
    assert base_0._squashed is False
    assert base_0._uuid is None


# Generated at 2022-06-25 04:55:44.377968
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import plugin_loader
    from ansible.module_utils import basic
    import ansible.constants as C

    context.CLIARGS = ImmutableDict(connection='smart', module_path=None, forks=10, become=False,
                                    become_method='sudo', become_user='root', check=False, diff=False,
                                    syntax=None, start_at_task=None, verbosity=5)

    args = {}
    args['host_list'] = get_host_list(inventory='localhost,')
    args['module_name']

# Generated at 2022-06-25 04:55:54.440960
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    data = {'name': 'blah', 'priority': 1}
    try:
        base_0.from_attrs(attrs=data)
    except Exception as e:
        raise AnsibleAssertionError('FieldAttributeBase.from_attrs method failed') from e

    try:
        base_0.from_attrs(attrs=None)
    except Exception as e:
        raise AnsibleAssertionError('FieldAttributeBase.from_attrs method failed') from e

    try:
        base_0.from_attrs(attrs=1)
    except Exception as e:
        raise AnsibleAssertionError('FieldAttributeBase.from_attrs method failed') from e



# Generated at 2022-06-25 04:56:03.023459
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fb = FieldAttributeBase()
    assert fb.from_attrs({'required': True, 'attribute': 'test'}) == {'required': True, 'attribute': 'test'}
    assert fb.from_attrs({'required': 'true', 'attribute': 'test'}) == {'required': 'true', 'attribute': 'test'}
    assert fb.from_attrs({'attribute': 'test'}) == {'attribute': 'test'}
    assert fb.from_attrs({}) == {}



# Generated at 2022-06-25 04:56:05.308728
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    dep_chain = base_0.get_dep_chain()
    assert isinstance(dep_chain, type(None))
    pass

# Generated at 2022-06-25 04:56:09.849500
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert base.get_dep_chain() is None
    base_1 = Base()
    base_1._parent = base
    base_2 = Base()
    base_2._parent = base_1
    base_3 = Base()
    base_3._parent = base_2
    base_4 = Base()
    base_4._parent = base_3
    assert base_4.get_dep_chain() == [base, base_1, base_2, base_3]

# Generated at 2022-06-25 04:56:21.345229
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f0 = FieldAttributeBase('test_field', default=True)
    f0_attrs = f0.dump_attrs()

    assert f0_attrs['name'] == 'test_field'
    assert f0_attrs['default'] == True
    assert f0_attrs['required'] == False
    assert f0_attrs['static'] == False
    assert f0_attrs['isa'] == None
    assert f0_attrs['class_type'] == None
    assert f0_attrs['listof'] == None

    f1 = FieldAttributeBase('test2_field', required=True, default=dict())
    f1_attrs = f1.dump_attrs()

    assert f1_attrs['name'] == 'test2_field'
    assert f1_attrs['default'] == dict

# Generated at 2022-06-25 04:56:49.066600
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # Test valid type
    b = FieldAttributeBase()
    assert b.validate("test", "type") is None

    # Test invalid type
    b = FieldAttributeBase()
    try:
        b.validate("test", None)
    except AssertionError as ex:
        assert "Object `test` " in ex.args[0] and " is not of type `type`" in ex.args[0]
    else:
        raise AssertionError("Failed to validate type")


# Generated at 2022-06-25 04:57:00.169067
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    base._dep_chain = []
    assert base.get_search_path() == []

    base._dep_chain = [Base(),]
    assert base.get_search_path() == []

    base._dep_chain = [Base(), Base()]
    assert base.get_search_path() == []

    base_0 = Base()
    base_0._role_path = 'role_path'
    base_1 = Base()
    base_1._role_path = 'role_path'
    base._dep_chain = [base_1, base_0]
    assert base.get_search_path() == ['role_path']

    base_0._role_path = 'role_path_0'
    base_1._role_path = 'role_path_1'
    assert base.get

# Generated at 2022-06-25 04:57:04.389768
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    def test_FieldAttributeBase_get_validated_value_case_0():
        arg_1 = FieldAttributeBase()
        arg_2 = ''
        arg_3 = ''
        arg_4 = ''
        # Call the unit_test method
        retval = arg_1.get_validated_value(arg_2, arg_3, arg_4)

    # Call unit_test methods
    test_FieldAttributeBase_get_validated_value_case_0()


# Generated at 2022-06-25 04:57:09.883975
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test_case_0
    print('case 0')
    base_0 = Base()
    # test_case_1
    print('case 1')
    base_1 = Base()


# Generated at 2022-06-25 04:57:13.442041
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Here, we prepare the test data
    value = True
    attribute = FieldAttribute(isa='bool')
    templar = AnsibleTemplar()

    # Now, we call the method
    result = Base.get_validated_value(value=value, attribute=attribute, templar=templar)

    # Finally, we can verify the expected outcome
    assert result == value


# Generated at 2022-06-25 04:57:15.360803
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    f = FieldAttributeBase()
    ansible.module_utils.basic.AnsibleModule(argument_spec=(dict(type='str', required=True), dict(type='str', required=False)))


# Generated at 2022-06-25 04:57:23.054355
# Unit test for method get_path of class Base
def test_Base_get_path():
    base_1 = Base()

    # call the method with no arguments
    # and test the result
    try:
        print("Testing method get_path() with no arguments")
        result = base_1.get_path()
        print("\tExpected result: empty string")
        print("\tActual result: %s" % result)
        assert result == ""
    except AssertionError as e:
        print("\tFailure: unexpected result")
        print("\t%s" % e)


# Generated at 2022-06-25 04:57:32.133314
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    bag = {
        "isa": "dict",
        "required": False
    }
    fb = FieldAttributeBase("name", **bag)
    fb.load_from_datasource = False
    fb.aliases = []
    fb.static = False

    templar = Templar(loader=DictDataLoader({'omit': None}))
    base = Base()

    # case when attribute isa is "dict"
    value = base.get_validated_value("name", fb, None, templar)
    assert value == {}

    # case when attribute isa is "dict" and value is not None
    value = base.get_validated_value("name", fb, "{{ ansible_default_ipv4 }}", templar)

# Generated at 2022-06-25 04:57:40.250866
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    name = 'test_data'
    attribute_0 = FieldAttributeBase(name)
    try:
        raise Exception("Failed to detect invalid isa type, if "
                        "invalid_isa_type is not a string.")
    except TypeError:
        pass
    else:
        raise Exception("Failed to detect invalid isa type, if "
                        "invalid_isa_type is not a string.")
    attribute_0.load_data('test_data')


# Generated at 2022-06-25 04:57:48.002873
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    base_0 = Base()
    attr = FieldAttributeBase()
    data = {}
    attr.validate(data)
    with pytest.raises(AnsibleUndefinedVariable):
        attr.validate(data, 'a')


# Generated at 2022-06-25 04:58:24.099789
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    print("test_BaseMeta_new")
    base_0 = test_case_0()
    print(base_0)

if __name__ == '__main__':
    test_BaseMeta___new__()


# Generated at 2022-06-25 04:58:30.848099
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    # test the method with empty objects
    try:
            base_0.post_validate()
    except Exception as e:
            assert type(e) is TypeError
    try:
            base_0.post_validate(None)
    except Exception as e:
            assert type(e) is TypeError


# Generated at 2022-06-25 04:58:39.708924
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from units.compat import unittest
    from units.compat.mock import Mock, patch
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    class TestBase(unittest.TestCase):

        def _test_get_dep_chain(self, base_obj, expected_result):
            self.assertEqual(base_obj.get_dep_chain(), expected_result)

        def test_get_dep_chain_with_handler(self):
            task = Task()
            handler = Handler()
            handler._parent = task
            play = Play()


# Generated at 2022-06-25 04:58:46.404511
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test of exact type
    a = FieldAttributeBase(isa='dict')
    assert a.validate({})[0]
    assert a.validate(dict())[0]
    assert not a.validate(dict([]))[0]
    assert not a.validate(dict({}))[0]
    assert not a.validate(list())[0]
    assert not a.validate(list([]))[0]
    assert not a.validate(list({}))[0]
    assert not a.validate(set())[0]
    assert not a.validate(set([]))[0]
    assert not a.validate(set({}))[0]
    assert not a.validate(1)[0]
    assert not a.validate(1.0)[0]

# Generated at 2022-06-25 04:58:55.291605
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    FA = FieldAttributeBase()
    attr_dict = {'foo': 'bar', 'bazz': 'bang'}
    FA.do_squash(attr_dict, None)
    assert attr_dict == {'foo': 'bar', 'bazz': 'bang'}, "Got {}, expected {}".format(attr_dict, {'foo': 'bar', 'bazz': 'bang'})

# Unit tests for class FieldAttributeBase

# Generated at 2022-06-25 04:59:04.201356
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    global _counter
    Attribute_1 =  FieldAttributeBase(is_static=True, is_required=True, always_post_validate=True, choices=['yes', 'no'], name='Attribute_1', isa='string')
    test_obj =  Base()
    templar =  Templar()
    valid_attrs = {'Attribute_1': Attribute_1} 
    test_obj._valid_attrs = valid_attrs
    test_obj.Attribute_1 = 'no'
    test_obj.Attribute_1 = 'yes'
    if (test_obj.Attribute_1 == 'yes'):
        _counter += 1
    test_obj.Attribute_1 = 'error'



# Generated at 2022-06-25 04:59:09.404210
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_1 = Base()
    assert 'foo' not in base_1._attributes
    # constructor method of Base should set the default values
    assert base_1.foo is None
    d = dict(foo='test')
    base_1.from_attrs(d)
    assert base_1.foo == 'test'


# Generated at 2022-06-25 04:59:19.392258
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_1 = Base()
    #
    # Test case with option: None
    #
    attr_1 = FieldAttributeBase(default=None, include=None, exclude=None, require=False)
    res_1_1 = attr_1.dump_me()

# Generated at 2022-06-25 04:59:21.409043
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """
    FieldAttributeBase method `validate` should resolve true for valid values
    """
    base_0 = Base()
    assert base_0._valid_attrs.module_defaults.required is False


# Generated at 2022-06-25 04:59:24.575717
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    assert obj.dump_me() == "FieldAttributeBase()"


# Generated at 2022-06-25 05:00:48.724497
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base(dict(name='base',))
    base_1.post_validate()
    return


# Generated at 2022-06-25 05:01:01.007031
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # This is a templar object required by the FieldAttributeBase class
    # which is serializing/deserializing
    templar = Templar(Loader())

    # Create an object
    base_obj = Base()

    # Serialize the created object
    base_obj_serialized = base_obj.serialize()

    # Deserialize this object
    base_obj_deserialized = Base()
    base_obj_deserialized.deserialize(base_obj_serialized)

    # Make sure the serialized and deserialized values match
    errmsg = "Attribute value ({0}) did not match in serialized and deserialized objects " \
             "({1}) for attribute ({2})".format
    for name, attribute in iteritems(base_obj._valid_attrs):
        serialized_val = base_obj_serialized

# Generated at 2022-06-25 05:01:02.440648
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    base_0.from_attrs(base_0.dump_attrs())


# Generated at 2022-06-25 05:01:05.517638
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    try:
        base_0.get_dep_chain()
        assert 0
    except IndexError:
        assert 1


# Generated at 2022-06-25 05:01:10.015114
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attribute_0 = FieldAttributeBase()
    attribute_0.isa = 'string'
    assert attribute_0.get_validated_value('name_0', attribute_0, 'value_0', None) == 'value_0'


# Generated at 2022-06-25 05:01:19.354066
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    base_0 = Base()
    item = FieldAttributeBase()
    item.name = 'foo'
    item.public = True
    item.isa = 'foobar' # should raise an error, but we can't test this easily
    item.required = False
    item.default = None
    item.static = True

    assert item.name == 'foo'
    assert item.public == True
    # assert item.isa == 'foobar' # should raise an error, but we can't test this easily
    assert item.required == False
    assert item.default == None
    assert item.static == True

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-25 05:01:20.508240
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    t = Base()
    t.get_search_path()

# Generated at 2022-06-25 05:01:26.669642
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-25 05:01:38.709967
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    print("Test FieldAttributeBase.from_attrs()")
    # Create object to test
    test_object = FieldAttributeBase()
    # Specific tests for from_attrs method
    test_value = 'foo'
    test_object.from_attrs(test_value)
    assert test_object.omit == test_value, "omit attribute not set correctly"
    test_value = 'bar'
    test_object.from_attrs(test_value)
    assert test_object.vars == test_value, "vars attribute not set correctly"
    test_value = 'baz'
    test_object.from_attrs(test_value)
    assert test_object.name == test_value, "name attribute not set correctly"
    test_value = 'buzz'
    test_object.from_attrs

# Generated at 2022-06-25 05:01:44.357769
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    attr = FieldAttributeBase('test', always_post_validate=True)
    attr.post_validate(loader)

    with pytest.raises(AnsibleParserError):
        attr.post_validate(None)

    with pytest.raises(AnsibleParserError):
        attr.post_validate(1)

    with pytest.raises(AnsibleParserError):
        attr.post_validate('a')

# Generated at 2022-06-25 05:02:47.981521
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base()
    try:
        base_1.post_validate(None)
        raise AssertionError
    except NotImplementedError:
        pass


# Generated at 2022-06-25 05:02:53.037252
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    attr = FieldAttributeBase()
    repr = attr.dump_me()

    assert repr['name'] == "base"
    assert repr['class_name'] == "FieldAttributeBase"
    assert repr['attribute'] == "base"
    assert repr['required'] == False
    assert repr['default'] == None
    assert repr['static'] == True
    assert repr['serialize_when_none'] == True
    assert repr['exclude_parent'] == False
    assert repr['exclude_child'] == False
    assert repr['always_post_validate'] == False
    assert repr['private'] == False
