

# Generated at 2022-06-25 04:54:10.035707
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # TODO: Create a test fixture here
    # Example: fixture = FieldAttributeBase()

    # TODO: Invoke the method being tested; assert the results
    # Example: assert fixture.dump_attrs() == (expected result)

    test_case_0()


# Generated at 2022-06-25 04:54:19.207718
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.play_context import PlayContext

    ctx = PlayContext()
    ctx.setdefaults(dict(
        become=False,
        become_user='root',
        become_method='sudo',
        become_flags='-H',
        verbosity=0,
        check=False,
        diff=False,
        environment=None,
        no_log=False))

    assert ctx.no_log == False

    ctx.no_log = True
    assert ctx.no_log == True


# Generated at 2022-06-25 04:54:28.168362
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with an integer
    ds = 34
    field_attribute_base_1 = FieldAttributeBase()
    result = field_attribute_base_1.load_data(ds)
    assert result == 34

    # Test with a list
    ds = [1, 2, 3]
    field_attribute_base_1 = FieldAttributeBase()
    result = field_attribute_base_1.load_data(ds)
    assert result == [1, 2, 3]

    # Test with a dictionary
    ds = {'a': 'b'}
    field_attribute_base_1 = FieldAttributeBase()
    result = field_attribute_base_1.load_data(ds)
    assert result == {'a': 'b'}

    # Test with a string
    ds = 'tee'
    field_attribute

# Generated at 2022-06-25 04:54:31.584073
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_2 = FieldAttributeBase()
    assert field_attribute_base_2._valid_attrs == dict()
    assert not field_attribute_base_2._finalized
    assert not field_attribute_base_2._squashed
    field_attribute_base_2._finalized = True
    field_attribute_base_2._squashed = True
    try:
        field_attribute_base_2.post_validate()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 04:54:41.750082
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    valid_attrs = {'name': 'fake', 'required': True, 'default': None, 'type': 'str'}
    name_0 = 'name_0'
    attribute_0 = FieldAttribute(valid_attrs)
    value_0 = 'test'
    templar_0 = FakeTemplar()
    real_value = field_attribute_base_0.get_validated_value(name_0, attribute_0, value_0, templar_0)
    my_assertEqual(real_value, value_0)
    templar_1 = FakeTemplar()
    my_assertEqual(templar_0.template_called, templar_1.template_called)
    return


# Generated at 2022-06-25 04:54:50.907204
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_0 = FieldAttribute()
    field_attribute_0.isa = 'int'
    field_attribute_0.priority = 2
    field_attribute_0.name = 'age'
    field_attribute_0.default = 18

    field_attribute_base_0.add_field(field_attribute_0)
    field_attribute_base_0.age = 12

    expected_value = {'age': 12}
    dump_me = field_attribute_base_0.dump_me()
    assert dump_me == expected_value


# Generated at 2022-06-25 04:54:54.931576
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    # Case 0 - Empty input
    if field_attribute_base_0.get_validated_value() != None:
        raise AssertionError()

    print('Test "FieldAttributeBase": [OK]')


# Generated at 2022-06-25 04:54:57.791434
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:55:05.972923
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    # Method get_path of class Base is tested in cases of different inputs
    # Case 0: Test for no input
    # Test for get_path method of class Base
    # Case 0
    try:
        field_attribute_base_0.get_path()
    except Exception as e:
        print('get_path method of class Base failed for case 0 with the following exception:')
        print(e)
        print('')


# Generated at 2022-06-25 04:55:11.195452
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_attrs()


# Generated at 2022-06-25 04:55:38.080056
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # FIXME: add test for FieldAttributeBase.deserialize(self, data) once it exists
    pass


# Generated at 2022-06-25 04:55:39.043886
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Not implemented
    pass


# Generated at 2022-06-25 04:55:50.054155
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test cases
    testcase_0 = {
        # Calls the __init__ method of FieldAttributeBase and checks that all
        # args are assigned correctly
        'args': None,
        'assertEqual': ('NotImplementedError', "'FieldAttributeBase' object has no attribute 'deserialize'"),
        'call_method': 'deserialize'
    }
    testcase_1 = {
        # Calls the __init__ method of FieldAttributeBase and checks that all
        # args are assigned correctly
        'args': {'FieldAttributeBase': 1, 'FieldAttributeBase': 2},
        'assertEqual': ('NotImplementedError', "'FieldAttributeBase' object has no attribute 'deserialize'"),
        'call_method': 'deserialize'
    }

    # Building test cases
    results = []
    results.append

# Generated at 2022-06-25 04:55:55.329550
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    dump_me_0 = FieldAttributeBase.dump_me(FieldAttributeBase())
    if not dump_me_0.keys() == []:
        print('test_FieldAttributeBase_dump_me: test dump_me_0 failed')
        return False
    return True


# Generated at 2022-06-25 04:55:58.494436
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0._attr_defaults is not None
    assert field_attribute_base_0._attributes is not None
    assert field_attribute_base_0._fixed_attrs is not None
    assert field_attribute_base_0._is_block is None
    assert field_attribute_base_0._valid_attrs is not None
    assert field_attribute_base_0.__class__.__name__ == 'FieldAttributeBase'


# Generated at 2022-06-25 04:55:59.530788
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FieldAttributeBase_obj = FieldAttributeBase()


# Generated at 2022-06-25 04:56:07.188108
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Base.get_path() is an abstract method and will be invoked by
    # its inheriting class. The inheriting class is defined inside the
    # constructor of Base. Therefore, let's make a call to
    # FieldAttributeBase to initialize an instance of Base to test
    # its method get_path.
    field_attribute_base_0 = FieldAttributeBase() # instantiation of an instance of Base should be done first

if __name__ == '__main__':
    test_case_0()

    test_Base_get_path()

# Generated at 2022-06-25 04:56:13.269314
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.from_attrs({u'name': u'foo'})
    field_attribute_base_0.from_attrs({u'name': u'foo'})


# Generated at 2022-06-25 04:56:23.643345
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # Validate with valid values
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = "name"
    field_attribute_base_0.isa = "dict"
    field_attribute_base_0.default = {}
    field_attribute_base_0.alt_name = None
    field_attribute_base_0.aliases = []
    field_attribute_base_0.required = False
    field_attribute_base_0.static = False
    field_attribute_base_0.final = False
    field_attribute_base_0.validate()

    # Validate with invalid values for name
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = None
    field_attribute_base_0.isa = "dict"
   

# Generated at 2022-06-25 04:56:27.169778
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.validate(None, FieldAttributeBase())

# Generated at 2022-06-25 04:56:51.415305
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # setup
    test_obj = Base()
    expected_obj = []

    # Execute the method with required param
    actual_obj = test_obj.get_search_path()

    # Assertion
    assert(actual_obj == expected_obj)


# Generated at 2022-06-25 04:57:03.034676
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    my_attr = MagicMock()
    my_attr.isa = 'string'
    my_attr.class_type = None
    my_attr.data_type = 'string'
    my_attr.required = True
    my_attr.default = None
    my_attr.private = False
    my_attr.aliases = []
    my_attr.always_post_validate = False

    base_1 = Base()
    base_1._validate_attributes = MagicMock(return_value='return_value')
    base_1._valid_attrs = MagicMock(return_value=[my_attr])
    base_1._get_attr_from_vars = MagicMock(return_value='attr_value')

    # test a dictionary with a 'class' isa
    my_attr_2 = Magic

# Generated at 2022-06-25 04:57:11.929412
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = Base()
    data = dict()

    setattr(base_0, 'test_attr', data)
    result = base_0.test_attr
    assert result == data

    setattr(base_0, 'test_attr', 'test_value')
    result = base_0.test_attr
    assert result == 'test_value'

    with pytest.raises(AnsibleParserError):
        setattr(base_0, 'test_attr', 0)


# Generated at 2022-06-25 04:57:15.296928
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Instantiating a field attribute
    default = 0
    fa = FieldAttributeBase(isa='int', default=default)

    # Instantiating a templar
    templar = Templar(loader=None, variables=None)

    # Testing post_validate method
    value = '1'
    result = fa.post_validate(value, templar)
    assert result == 1


# Generated at 2022-06-25 04:57:20.920775
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Case that no parent is set
    base_test = Base()
    ret = base_test.get_dep_chain()
    assert ret == None

    # Case that parent is set
    # TODO: more complicated test
    base_test.parent = Base()
    ret = base_test.get_dep_chain()
    assert ret != None


# Generated at 2022-06-25 04:57:28.256023
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    base_1 = Base()
    base_2 = Base()
    base_3 = Base()
    base_1._parent = base_2
    base_2._parent = base_3
    base_3._parent = None

    assert bool(base_1.get_dep_chain()) == False
    assert base_1.get_dep_chain() == None

    base_4 = Base()
    base_5 = Base()
    base_6 = Base()
    base_5._parent = base_6
    base_6._parent = base_4
    base_4._parent = None

    assert bool(base_5.get_dep_chain()) == False
    assert base_5.get_dep_chain() == None

    base_7 = Base()
    base_8 = Base()
   

# Generated at 2022-06-25 04:57:32.569959
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_1 = Base()
    base_1.name = 'test'
    base_1.test_attrib_1 = 'test1'
    base_1.test_attrib_2 = 'test2'
    assert base_1.dump_attrs() == {'name': 'test', 'test_attrib_1': 'test1', 'test_attrib_2': 'test2'}


# Generated at 2022-06-25 04:57:43.557171
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # test to_text
    test_list = [
        ['foo', 'foo'],
        [u'foo', 'foo'],
        [b'foo', 'foo'],
    ]
    for test in test_list:
        assert test[1] == to_text(test[0]), "failed, got (%s), expected (%s)" % (to_text(test[0]), test[1])

    # test get_validated_value()
    base = Base()
    name = "var"
    templar = Templar(loader=None, variables={})

    # test for isa 'string'
    attr = FieldAttributeBase(isa='string')

# Generated at 2022-06-25 04:57:50.272438
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase()

    #methods = [method for method in dir(obj) if callable(getattr(obj, method))]

    test_data = [
        {'name': 'test', 'default': 'val1'},
        {'name': 'test', 'default': 'val2'},
        {'name': 'test', 'default': 'val3'},
        {'name': 'test', 'default': 'val4'},
    ]

    # test the underlying attribute in case it ever changes
    if FieldAttributeBase._FIELD_ATTRIBUTE_CACHE_NAME != '_field_attribute_cache':
        raise AssertionError('FieldAttributeBase._FIELD_ATTRIBUTE_CACHE_NAME is not "_field_attribute_cache"')

    # test that we get the same FieldAttributeBase object

# Generated at 2022-06-25 04:57:53.401896
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base() 
        # An exception is raised if the initialize function is not implemented
    assert issubclass(AnsibleAssertionError, Exception)
    try:
        base_0.post_validate()
    except AnsibleAssertionError:
        pass  

## Unit test for method serialize of class FieldAttributeBase

# Generated at 2022-06-25 04:58:26.672999
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    FieldAttributeBase: dump_me()
    Ensure 'dump_me' returns a dict containing the expected keys and values.
    '''
    # First, create an instance of FieldAttributeBase
    #f = FieldAttributeBase(name="purple", public=False, default=None, always_post_validate=None, isa=None, choices=None, listof=None, required=False, static=False, class_type=None, private=None)

    # Now, make sure that the method returns a dict with the following keys
    # and values
    #assert Keys are: name, public, default, always_post_validate, isa, choices, listof, required, static, class_type, private
    #assert Values are: purple, False, None, None, None, None, None, False, False, None, None
   

# Generated at 2022-06-25 04:58:37.303820
# Unit test for method get_path of class Base
def test_Base_get_path():

    # we will start with the base class, which will have the least
    # attributes populated
    base_0 = Base()

    # then we will populate some attributes required to find a path
    base_0._ds = 'dummy_datasource'
    base_0._ds._data_source = 'dummy_data_source'
    base_0._ds._line_number = 'dummy_line_number'
    base_0._parent = 'dummy_parent'
    base_0._parent._play = 'dummy_play'
    base_0._parent._play._ds = 'dummy_play_ds'
    base_0._parent._play._ds._data_source = 'dummy_play_data_source'

# Generated at 2022-06-25 04:58:43.521057
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create an Base object
    base_0 = Base()
    # Assert that name is set to the default value
    assert base_0.name == 'Base'
    # Load attributes
    base_0.from_attrs({"name": "test base1",
                       "foo": "test foo"})
    # Assert that name is now set to test base1
    assert base_0.name == 'test base1'
    # Assert that foo is set to the default value
    assert base_0.foo is None
    # Get the value of the name attribute from the base_0 object
    base_0_name = base_0.name
    # Assert that the value is the expected value
    assert base_0_name == "test base1"
    # Assert that the value matches the name attribute in base_0
    assert base

# Generated at 2022-06-25 04:58:46.346820
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase('test_case')
    f.post_validate()


# Generated at 2022-06-25 04:58:54.813559
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    name = 'name'
    attribute = FieldAttributeBase(isa='string', private=True)
    value = 'some string'
    templar = AnsibleTemplar()
    obj = FieldAttributeBase()
    result = obj.get_validated_value(name, attribute, value, templar)
    expected = 'some string'
    assert result == expected


# Generated at 2022-06-25 04:58:59.072712
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # msi_dep_chain = Base().get_dep_chain()
    pass



# Generated at 2022-06-25 04:59:05.275628
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # Test if FieldAttributeBase.post_validate returns field_val if templar is None
    fvb = FieldAttributeBase()
    field_val = 'hello'
    assert fvb.post_validate(templar=None, field_val=field_val) == field_val


# Generated at 2022-06-25 04:59:09.314960
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()
    target = '{"__ansible_module__": "ansible.parsing.dataloader.base.Base"}'
    assert base_0.dump_me() == target


# Generated at 2022-06-25 04:59:14.141765
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_attr_base = BaseAttributeBase()
    t = 'TestValue'
    base_attr_base.post_validate(t)
    assert base_attr_base.post_validate(t) is None


# Generated at 2022-06-25 04:59:20.363518
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()
    assert base_0.dump_attrs() == {'name': '', 'connection': 'smart', 'delegate_to': None, 'run_once': False, 'tags': [], 'register': None, 'ignore_errors': False, 'vars': {}, 'when': [], 'failed_when': [], 'changed_when': [], 'until': [], 'always_run': False, 'poll': 0, 'notify': []}


# Generated at 2022-06-25 04:59:58.085021
# Unit test for method get_path of class Base
def test_Base_get_path():

    base_0 = Base()
    assert base_0.get_path() == ""

    base_1 = Base()
    base_1._ds = "test/test_ds"
    base_1._ds._line_number = 0

    assert base_1.get_path() == "test/test_ds:0"

    base_2 = Base()
    base_2._parent = base_1
    base_2._parent._play._ds = "test/test_play"
    base_2._parent._play._ds._line_number = 1

    assert base_2.get_path() == "test/test_play:1"


# Generated at 2022-06-25 05:00:08.781163
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Check the FieldAttributeBase object when attribute isa is set to int
    f = FieldAttributeBase(isa='int', default=0)
    assert f.validate_fail_on_error(None) is None
    assert f.validate_fail_on_error('a') is None
    assert f.validate_fail_on_error(f.default) is None
    assert f.validate_fail_on_error(1) == 1
    assert f.validate_fail_on_error(1.1) == 1.1

    # Check the FieldAttributeBase object when attribute isa is set to str
    f = FieldAttributeBase(isa='str', default='')
    assert f.validate_fail_on_error(None) is None
    assert f.validate_fail_on_error('') == ''
   

# Generated at 2022-06-25 05:00:11.304208
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base = Base()

# Generated at 2022-06-25 05:00:14.188031
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = FieldAttributeBase()
    data = [{'task': {'name': 'example task'}}, 'foo', 'bar']
    result = base_0.load_data(data, '/root/tmp/ansible_test.yml', 'tasks')
    assert result == [{'task': {'name': 'example task'}}, {'task': 'foo'}, {'task': 'bar'}], result


# Generated at 2022-06-25 05:00:20.911202
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Initializing object of class RoleInclude
    role_incl = RoleInclude()
    # Initializing object of class Role
    role = Role(parent_role=role_incl)
    # Initializing object of class Base with arguments parent and data_source
    base_0 = Base(parent=role)
    # Test case
    assert base_0.get_dep_chain() == [role_incl, role]


# Generated at 2022-06-25 05:00:28.645982
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    attrs = {"name": "nameValue", "default": "defaultValue", "aliases": ["aliasesElement"], "choices": ["choicesElement"], "required": False, "static": False, "always_post_validate": False, "priority": 0}
    base_0.from_attrs(attrs)
    assert base_0.name == "nameValue"
    assert base_0.default == "defaultValue"
    assert base_0.aliases == ["aliasesElement"]
    assert base_0.choices == ["choicesElement"]
    assert base_0.required == False
    assert base_0.static == False
    assert base_0.always_post_validate == False
    assert base_0.priority == 0


# Generated at 2022-06-25 05:00:38.239211
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    isa='string'
    required=True
    always_post_validate=True
    static=False
    choices=None
    default=None
    class_type=None
    listof=None
    value='some_string'
    attribute_class = FieldAttributeBase(isa, required, always_post_validate, static, choices, default, class_type, listof)
    value_returned_by_get_validated_value = attribute_class.get_validated_value('name', attribute_class, value, None)
    assert value_returned_by_get_validated_value == value


# Generated at 2022-06-25 05:00:46.555169
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fa_0 = FieldRef()
    fa_1 = FieldRef()
    fl_0= [fa_0, fa_1]
    fa_0.data = 'data_0'
    fa_1.data = 'data_1'
    for fa in fl_0:
        assert fa.data == fa.data
        assert fa.data == fa.data
    data_0= {'phash': fl_0, 'name_0': 'name_0'}
    data_1= {'phash': fl_0, 'name_1': 'name_1'}
    sta_0 = FieldAttributeBase()
    sta_0.load_data(data=data_0)
    assert sta_0.data == data_0
    asse

# Generated at 2022-06-25 05:00:49.860964
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    import tempfile

    base_0 = Base()
    (handle, fname) = tempfile.mkstemp()
    os.write(handle, '#!/bin/sh\nexit 0')
    os.close(handle)
    os.chmod(fname, 484)

    base_0.validate_attrs()
    base_0.post_validate(templar)
    os.remove(fname)


# Generated at 2022-06-25 05:00:52.818354
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass


# Generated at 2022-06-25 05:01:30.716812
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # test the case that the value is a float
    fa = FieldAttributeBase()
    fa.isa = 'float'
    value = '1'
    templar = Templar(loader=None, variables={})
    result = fa.post_validate(value, templar)
    assert 1.0 == result
    # test the case that the value is a percent
    fa = FieldAttributeBase()
    fa.isa = 'percent'
    value = '10%'
    templar = Templar(loader=None, variables={})
    result = fa.post_validate(value, templar)
    assert 10.0 == result

# Generated at 2022-06-25 05:01:42.229325
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    test_case_0()


# Generated at 2022-06-25 05:01:45.323535
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    base_0 = Base()
    base_1 = Base()
    
    base_0.set_loader(None)

    # Make sure we can handle a null loader
    try:
        base_0.dump_me()
    except:
        raise AssertionError()


# Generated at 2022-06-25 05:01:53.048635
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    Basic test to check dependency chains
    '''

    # first create the object base_0
    base_0 = Base()

    # test when the object is itself the head of the chain
    assert base_0.get_dep_chain() == None

    # create the object base_1
    base_1 = Base()
    base_1._parent = base_0

    # test when the object is base_1
    assert base_1.get_dep_chain() == [base_0]

    # create the object base_2
    base_2 = Base()
    base_2._parent = base_1

    # test when the object is base_2
    assert base_2.get_dep_chain() == [base_0, base_1]

    # create the test case for when the parent is itself
    base_

# Generated at 2022-06-25 05:01:58.390373
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    """
    FieldAttributeBase.dump_me() convenience method.
    """
    class Foo(Base):
        attr = FieldAttribute(isa='bool', required=True, always_post_validate=True, default=True)
        attr2 = FieldAttribute(isa='bool', required=True, default=False)
    a = Foo()
    assert a.dump_me('attr') == 'yes'
    assert a.dump_me('attr2') == 'no'
    assert a.dump_me('attr3') == 'unknown'


# Generated at 2022-06-25 05:02:05.228366
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    validate_attr = FieldAttributeBase()
    validate_attr.isa = 'string'
    value = 'success'
    templar = Templar(loader=None, variables={})
    assert validate_attr.get_validated_value('name', validate_attr, value, templar) == to_text(value)
    validate_attr.isa = 'int'
    value = 100
    assert validate_attr.get_validated_value('name', validate_attr, value, templar) == int(value)
    validate_attr.isa = 'float'
    value = 1000.00
    assert validate_attr.get_validated_value('name', validate_attr, value, templar) == float(value)
    validate_attr.isa = 'bool'
    value = True
    assert validate

# Generated at 2022-06-25 05:02:12.427098
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = Base()
    base_data_0 = dict(
            name='_name',
            value=None,
            type='str',
            priority=0,
            require=False,
            default=None,
            aliases=[],
            choices=None,
            inherit=False
            )
    base_attr_0 = FieldAttributeBase(name='_name', value=None, type='str', priority=0, require=False, default=None, aliases=[], choices=None, inherit=False)
    base_attr_0.load_data(base_data_0)
    assert base_attr_0.name == '_name'
    assert base_attr_0.value == None
    assert base_attr_0.type == 'str'
    assert base_attr_0.priority == 0
    assert base_attr_

# Generated at 2022-06-25 05:02:16.143225
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_0 = Base()
    # Method get_ds of class FieldAttributeBase.
    # Expecting it to return None.
    assert base_0.get_ds() is None


# Generated at 2022-06-25 05:02:22.437971
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    attrs = {u'name': u'foo', u'intval': u'1', u'listval': [u'one', u'two'], u'boolval': u'yes'}
    base_0.from_attrs(attrs)
    assert base_0.name == attrs['name']
    assert base_0.intval == int(attrs['intval'])
    assert base_0.boolval is True
    assert isinstance(base_0.listval, list)
    assert base_0.listval == [u'one', u'two']


# Generated at 2022-06-25 05:02:23.784202
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Unit test for method get_dep_chain of class Base
    assert Base.get_dep_chain(test_case_0) is None