

# Generated at 2022-06-25 04:54:07.167355
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    # Test case 1
    attr = FieldAttributeBase('test_attr')
    attr.isa = 'string'
    name = 'test'
    value = 'hello'
    templar = mock.MagicMock()
    templar.template.return_value = value
    expected = value
    obtained = base_0.get_validated_value(name, attr, value, templar)
    assert obtained == expected
    # Test case 2
    attr = FieldAttributeBase('test_attr')
    attr.isa = 'int'
    name = 'test'
    value = '1'
    templar = mock.MagicMock()
    templar.template.return_value = value
    expected = 1
    obtained = base_0.get_validated_value

# Generated at 2022-06-25 04:54:11.778654
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    expected_output = {'methods': [], 'omit': 'omit_default', 'type': 'FieldAttribute'}
    instance = FieldAttributeBase()
    output = instance.dump_me()
    assert(output == expected_output)


# Generated at 2022-06-25 04:54:16.255002
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    class TestObj:
        def __init__(self, ds):
            self.ds = ds
    field_0 = FieldAttributeBase()
    obj_0 = TestObj(1)
    assert field_0.get_ds(obj_0) == 1


# Generated at 2022-06-25 04:54:27.693017
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_obj = FieldAttributeBase()
    name,attribute,value,templar = 0, AnsibleUnsafeText('unsafe'),0,0
    assert test_obj.get_validated_value(name,attribute,value,templar) == value

    test_obj = FieldAttributeBase()
    name,attribute,value,templar = 'name', FieldAttribute(isa='string'),'myname',0
    assert test_obj.get_validated_value(name,attribute,value,templar) == u'myname'
    assert type(test_obj.get_validated_value(name,attribute,value,templar)) is text_type

    test_obj = FieldAttributeBase()
    name,attribute,value,templar = 'number', FieldAttribute(isa='int'),1,0
    assert test_obj

# Generated at 2022-06-25 04:54:38.211129
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import ansible.playbook.async_task as async_task
    import ansible.playbook.task_include as task_include
    import ansible.playbook.handler as handler
    import ansible.playbook.task as task
    import ansible.playbook.block as block
    import ansible.playbook.role as role
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play

    # test case 1
    base_1 = Base()
    assert base_1.get_dep_chain() == None

    # test case 2
    base_2 = Base()
    async_task_2 = async_task.AsyncTask(action=None, args=dict())
    assert base_2.get_dep_chain() == None

    # test case 3
    base_

# Generated at 2022-06-25 04:54:46.522354
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    class Foo(object):

        def __init__(self):
            self.a = None
            self.b = None

        def serialize(self):
            return dict(a=self.a, b=self.b)

        def deserialize(self, data):
            self.a = data['a']
            self.b = data['b']

    class Bar(Base):
        _valid_attrs = dict(
            foo=FieldAttribute(isa='class', class_type=Foo, default=dict(a=1, b=2)),
            c=FieldAttribute(isa='int', default=0),
            d=FieldAttribute(isa='int', default=1),
        )

    bar_0 = Bar()
    assert bar_0.c == 0
    assert bar_0.d == 1
    assert bar_0

# Generated at 2022-06-25 04:54:49.856301
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_0 = Base()
    input_value = {'foo': 'bar'}
    try:
        output_value = base_0.from_attrs(input_value)
    except AnsibleAssertionError as e:
        assert("data (bar) should be a dict but is a str" in e.message)
        assert("Assertion failed" in e.message)


# Generated at 2022-06-25 04:54:51.814711
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test_instance = FieldAttributeBase()
    try:
        test_instance.post_validate()
    except TypeError as e:
        assert e.args[0] == 'FieldAttributeBase.post_validate needs exactly 2 arguments'


# Generated at 2022-06-25 04:54:59.654880
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_1 = Base()
    field_attribute_base_1 = FieldAttributeBase(class_type=base_1, require_in_ansible_vars=True, require_in_vars=True)
    field_attribute_base_1_copy = field_attribute_base_1.copy()

    assert field_attribute_base_1.class_type == field_attribute_base_1_copy.class_type
    assert field_attribute_base_1.require_in_ansible_vars == field_attribute_base_1_copy.require_in_ansible_vars
    assert field_attribute_base_1.require_in_vars == field_attribute_base_1_copy.require_in_vars
    assert field_attribute_base_1.always_post_validate == field_attribute_base_1

# Generated at 2022-06-25 04:55:02.249858
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = Base()
    fb = base_0.FieldAttributeBase("name", required=True, default="some_name", always_post_validate=True)
    cfb = fb.copy()
    assert fb.required == cfb.required
    assert fb.default == cfb.default
    assert fb.always_post_validate == cfb.always_post_validate


# Generated at 2022-06-25 04:55:55.046292
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_1 = Base()
    base_1.vars = {'host': 'host'}
    base_1.tags = ['tag1', 'tag2']
    base_1.when = ['when1', 'when2']
    base_2 = Base()
    base_2.tags =['tag3', 'tag4']
    base_2.when = ['when3', 'when4']
    base_2.parent = base_1

    expected_result = {'tags': ['tag1', 'tag2'],
                       'when': ['when1', 'when2'],
                       'vars': {'host': 'host'}
                       }
    assert base_2.dump_attrs() == expected_result, \
        "AnsibleError: dump_attrs() of class FieldAttributeBase is broken"

#

# Generated at 2022-06-25 04:55:58.586117
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test one of each valid types
    assert FieldAttributeBase.validate('isa', 'string')
    assert FieldAttributeBase.validate('isa', 'int')
    assert FieldAttributeBase.validate('isa', 'float')
    assert FieldAttributeBase.validate('isa', 'bool')
    assert FieldAttributeBase.validate('isa', 'list')
    assert FieldAttributeBase.validate('isa', 'set')
    assert FieldAttributeBase.validate('isa', 'dict')
    assert FieldAttributeBase.validate('isa', 'class')

# Generated at 2022-06-25 04:56:01.767017
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base_0 = Base()
    path_lst = base_0.get_search_path()


# Generated at 2022-06-25 04:56:05.505843
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # test_case_0
    base_0 = Base()
    try:
        base_0.deserialize(1)
    except AnsibleAssertionError as e:
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-25 04:56:12.497132
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    class MyBase(Base):
        field1 = FieldAttribute(isa='int')
        field2 = FieldAttribute(isa='int', default=5)
        field3 = FieldAttribute(isa='int', default=5, always_post_validate=True)
        field4 = FieldAttribute(isa='int', required=True)

    base_1 = MyBase()

    # It should not raise any exceptions when field1 has a value, field2 has the default value,
    # and field3 has a value given the always_post_validate flag
    base_1.field1 = 0
    base_1.field2 = 5
    base_1.field3 = 5

    # It should not raise any exceptions when field1 has a value, and field2 and field3 have a
    # non-default value.
    base_1.field1 = 0


# Generated at 2022-06-25 04:56:13.434421
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attribute = FieldAttributeBase()
    assert attribute.validate() == False

# Generated at 2022-06-25 04:56:18.796311
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base = Base()
    attr = FieldAttributeBase()

    # Test the case when the value is a TemplatedValue
    try:
        attr.load_data(base, 'some_key', TemplatedValue('some_value'))
    except Exception as e:
        assert False, "Failed when the value is a TemplatedValue"

    # Test the case when the value is a basestring
    try:
        attr.load_data(base, 'some_key', 'some_value')
    except Exception as e:
        assert False, "Failed when the value is a basestring"

    # Test the case when the value is a integer

# Generated at 2022-06-25 04:56:27.792066
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base = Base()
    base.deserialize({'attributes': {'_valid_attrs': {u'field_attribute': {'isa': u'string', 'default': 'bar', 'name': u'field_attribute'}}}})

# Generated at 2022-06-25 04:56:35.679070
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    dummy_dep_chain = [1,2, 3]
    # Initialize a base object
    base_0 = Base()

    # Set parent attribute of base_0 with a role object
    role_0 = Role()
    role_0._role_path = 'path/to/role'
    base_0._parent = role_0
    # Assign dummy_dep_chain to attribute dep_chain of role_0
    role_0.dep_chain = dummy_dep_chain

    # Invoke method get_dep_chain on base_0
    dep_chain = base_0.get_dep_chain()

    # Assert that dep_chain has the value of dummy_dep_chain
    assert dep_chain == dummy_dep_chain


# Generated at 2022-06-25 04:56:41.907725
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    ba = FieldAttributeBase()
    # test case 0
    attr = FieldAttributeBase(default='_default_value')
    assert '_default_value' == attr.default

    # test case 1
    attr = FieldAttributeBase(default='_default_value', always_post_validate=True)
    assert '_default_value' == attr.default

# Generated at 2022-06-25 04:57:18.423113
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    dataloader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=dataloader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)
    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-25 04:57:23.690841
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_0 = FieldAttributeBase()
    base_1 = base_0.copy()
    assert(base_1.default == base_0.default)


# Generated at 2022-06-25 04:57:32.192049
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    def assert_get_validated_value(attr, val, exp_val):
        assert (attr.get_validated_value("", attr, val, templar=None) == exp_val)
    f1 = FieldAttribute("name_1", 'string', False)
    assert_get_validated_value(f1, "1w", "1w")
    f2 = FieldAttribute("name_2", 'int', False)
    assert_get_validated_value(f2, "3", 3)
    f3 = FieldAttribute("name_3", 'float', False)
    assert_get_validated_value(f3, "3.1", 3.1)
    f4 = FieldAttribute("name_4", 'bool', False)
    assert_get_validated_value(f4, True, True)

# Generated at 2022-06-25 04:57:35.031175
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert(callable(getattr(FieldAttributeBase, 'get_ds', None)))


# Generated at 2022-06-25 04:57:38.575201
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_0 = FieldAttributeBase()
    assert base_0.get_ds() == "", 'Expected: ""  Actual: %s' % base_0.get_ds()



# Generated at 2022-06-25 04:57:47.275433
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    class Base_0(Base):
        __start__ = FieldAttribute(isa='bool')
        __end__ = FieldAttribute(isa='bool')

    class Parent_0(Base):
        __start__ = FieldAttribute(isa='bool')
        __end__ = FieldAttribute(isa='bool')
        start = FieldAttribute(isa='bool')
        end = FieldAttribute(isa='bool')

        def __init__(self):
            super(Parent_0, self).__init__()

            # for testing, load up some attributes with values
            self.start = True
            self.end = False

    class Child_0(Base):
        __start__ = FieldAttribute(isa='bool')
        __end__ = FieldAttribute(isa='bool')
        start = FieldAttribute(isa='bool')
        end = FieldAttribute(isa='bool')

       

# Generated at 2022-06-25 04:57:52.412460
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    base_0 = Base()
    base_1 = Base()

    # Initial conditions for testcase
    assert(base_0.squashed == False)
    assert(base_1.squashed == False)

    # Test execution of method
    base_0.squash(base_1)

    # Post-test assertions
    assert(base_0.squashed == True)
    assert(base_1.squashed == True)


# Generated at 2022-06-25 04:57:57.559050
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    f = FieldAttribute()
    assert f.isa == 'str'
    assert f.default is None
    assert f.required is False

    # test the isa_name function
    f = FieldAttribute(isa='int')
    assert f.isa == 'int'

    f = FieldAttribute(isa='dict')
    f.validate({"foo": "bar"})

    with pytest.raises(TypeError):
        f.validate(['bad'])



# Generated at 2022-06-25 04:57:59.901454
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test_fa_0 = FieldAttributeBase()
    test_fa_0.post_validate()
    # Failing case for post_validate
    try:
        test_fa_0.post_validate(templar=123)
    except TypeError as e:
        print('TypeError exception properly raised')


# Generated at 2022-06-25 04:58:05.785056
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.isa = None
    field_attribute_base.default = None
    field_attribute_base.static = None
    field_attribute_base.private = None
    field_attribute_base.required = None
    field_attribute_base.removed = None
    field_attribute_base.version_added = None
    field_attribute_base.deprecated_since = None
    field_attribute_base.deprecated_at_date = None
    field_attribute_base.deprecated_for_removal = None
    field_attribute_base.removed_at_date = None
    field_attribute_base.aliases = None
    field_attribute_base.description = None
    field_attribute_base.description_features = None

    # get a dump_me method

# Generated at 2022-06-25 04:58:38.866844
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base()
    
    method_result = base_1.post_validate()
    assert method_result is None


# Generated at 2022-06-25 04:58:51.326507
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # testing class type
    fb = FieldAttributeBase(default=0, class_type=int)
    assert fb.validate(1) == 1
    assert fb.validate('1') == 1
    with pytest.raises(TypeError):
        fb.validate('abc')
    # testing invalid class type
    with pytest.raises(AnsibleAssertionError):
        FieldAttributeBase(default=0, class_type=str)

    # testing isa type
    fb = FieldAttributeBase(default=0, isa='int')
    assert fb.validate(1) == 1
    assert fb.validate('1') == 1
    with pytest.raises(ValueError):
        fb.validate('abc')
    # testing invalid isa type

# Generated at 2022-06-25 04:59:01.605180
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() is None
    base_1 = Base()
    base_1._parent = Base()
    assert base_1.get_dep_chain() is None
    base_2 = Base()
    base_2._parent = Base()
    base_2._parent._play = Base()
    assert base_2.get_dep_chain() is None
    base_3 = Base()
    base_3._parent = Base()
    base_3._parent._play = Base()
    base_3._parent._play._dep_chain = [Base(), Base(), Base()]
    base_3._parent._play._dep_chain[0]._name = "with_role"

# Generated at 2022-06-25 04:59:04.921422
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase('t_field')
    field_attribute_base_0.validate('t_field')


# Generated at 2022-06-25 04:59:14.973177
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FABA = FieldAttributeBase()

    FABA._tokenize = 'tokenize_string'
    FABA._validator = 'validator_string'

    FABA.isa = 'isa_string'

    FABA.default = 'default_string'

    FABA.aliases = ['aliases_string1', 'aliases_string2']

    FABA.class_type = 'class_type_string'

    FABA.static = 'static_string'

    FABA.always_post_validate = 'always_post_validate_string'

    FABA.required = 'required_string'

    FABA.choices = ['choices_string1', 'choices_string2']

    FABA.scalar = 'scalar_string'

    FABA.listof = 'listof_string'

    FA

# Generated at 2022-06-25 04:59:19.773603
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    base_0 = Base()
    result = base_0._valid_attrs['name'].validate("test", "name")
    assert result == "test"

    base_0 = Base()
    result = base_0._valid_attrs['name'].validate("0", "name")
    assert result == "0"

# Generated at 2022-06-25 04:59:21.006866
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_1 = Base()
    assert(base_1.get_dep_chain() is None)



# Generated at 2022-06-25 04:59:26.767368
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test case for validating valid values for isa
    f = FieldAttributeBase()
    f.isa = 'string'
    f.validate('string')
    f.validate(1.0)
    f.validate(1)
    f.validate(True)
    f.validate(None)

    f.isa = string_types
    f.validate('string')
    f.validate(1.0)
    f.validate(1)
    f.validate(True)
    f.validate(None)

    f.isa = 'int'
    f.validate('string')
    f.validate(1.0)
    f.validate(1)
    f.validate(True)
    f.validate(None)

    f.isa = integer_types
   

# Generated at 2022-06-25 04:59:37.012056
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_1 = Base()
    field = FieldAttributeBase(always_post_validate=True, class_type=Base, isa=type, priority=FieldAttributeBase.PRIORITY_HIGHEST)
    # test default constructor with default always_post_validate
    field2 = FieldAttributeBase(class_type=Base, isa=type, priority=FieldAttributeBase.PRIORITY_HIGHEST)
    assert field.always_post_validate
    assert not field2.always_post_validate
    # test get_class_priority
    assert field.get_class_priority() == FieldAttributeBase.PRIORITY_HIGHEST


# Generated at 2022-06-25 04:59:44.096168
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Set up data for the test
    valid_values = dict()
    valid_values['string'] = [u"string", "string"]
    valid_values['int'] = [1, "1"]
    valid_values['float'] = [1.0, "1.0"]
    valid_values['bool'] = [True, False, "true", "false"]
    valid_values['percent'] = [0.0, 50.0, 100.0]
    valid_values['list'] = [[1,2,3], "1,2,3", "1 2 3", u"1,2,3", u"1 2 3"]

# Generated at 2022-06-25 05:00:20.169796
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_1 = Base()
    base_2 = Base()
    base_2._parent = base_1
    base_3 = Base()
    base_3._parent = base_2
    dep_chain = base_3.get_dep_chain()
    assert dep_chain[0] == base_1
    assert dep_chain[1] == base_2
    assert dep_chain[2] == base_3
    assert base_1.get_dep_chain() == None


# Generated at 2022-06-25 05:00:21.949150
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_1 = Base()
    base_1.get_ds(ds='')


# Generated at 2022-06-25 05:00:26.664761
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader._vault = DummyVaultSecret()

    base_0 = Base()
    base_0.post_validate(templar=AnsibleLoader(loader=loader).load(ds=DataLoader))


# Generated at 2022-06-25 05:00:28.009379
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Try to get a list of search paths for a Base object.
    base_base = Base()
    path_stack = base_base.get_search_path()

    assert path_stack == []


# Generated at 2022-06-25 05:00:33.396124
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'test_name'
    field_attribute_base_0.default = 'test_default'
    assert(field_attribute_base_0.name == 'test_name')
    assert(field_attribute_base_0.default == 'test_default')
    field_attribute_base_0.isa = 'test_isa'
    field_attribute_base_0.required = True
    field_attribute_base_0.listof = 'test_listof'
    field_attribute_base_0.static = True
    field_attribute_base_0.class_type = object
    field_attribute_base_0.default = 'test_default'
    assert(field_attribute_base_0.default == 'test_default')


# Generated at 2022-06-25 05:00:36.839886
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test_case_0()

if __name__ == '__main__':
    test_FieldAttributeBase_post_validate()
    test_case_0()

# Generated at 2022-06-25 05:00:46.121712
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-25 05:00:47.986831
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert False


# Generated at 2022-06-25 05:00:49.351608
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase()
    obj = {'foo': 'bar'}
    attr.validate(obj, 'foo')


# Generated at 2022-06-25 05:01:00.998380
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Instanciation of class Base
    base_0 = Base()

    # Testing method get_validated_value and their type
    # Input: str
    value = '42'
    # Expected result: int
    # Type of expected result : int
    # This is a test for the isa 'int'
    expected_result = 42
    result = base_0.get_validated_value('test', FieldAttribute('test', 'int'), value, Sentinel)
    assert (expected_result == result)
    assert (isinstance(result, int))

    # Input: str
    value = '42.5'
    # Expected result: float
    # Type of expected result : float
    # This is a test for the isa 'float'
    expected_result = 42.5
    result = base_0.get_validated_

# Generated at 2022-06-25 05:01:38.967055
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    attr = field_attribute(isa='string')

    # Test case 1:
    temp_1 = base_0.get_validated_value('foo', attr, 'bar', None)
    assert temp_1 == 'bar'

    # Test case 2:
    temp_2 = base_0.get_validated_value('foo', attr, '', None)
    assert temp_2 == ''

    # Test case 3:
    temp_3 = base_0.get_validated_value('foo', attr, None, None)
    assert temp_3 == None



# Generated at 2022-06-25 05:01:42.752000
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_obj = Base()
    assert base_obj.get_dep_chain() is None
    wrapper = Task()
    wrapper._dep_chain = ["test_1", "test_2"]
    base_obj._parent = wrapper
    assert base_obj.get_dep_chain() == ["test_1", "test_2"]

# Generated at 2022-06-25 05:01:48.648461
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # Create dummy class to test
    class DummyClass():
        pass

    DummyClass.some_attr = FieldAttribute()

    # Assert dump_me() function can be called on attribute
    DummyClass.some_attr.dump_me()


# Generated at 2022-06-25 05:01:53.483964
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase()
    attr.name = 'test_attribute'
    attr.validate('test_value')


# Generated at 2022-06-25 05:01:58.370830
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = FieldAttributeBase()
    base_1.post_validate()


# Generated at 2022-06-25 05:02:00.520304
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FA=FieldAttributeBase()
    FA.load_data(name="Test Attribute", default=False, validate=boolean)
    assert FA.name == "Test Attribute"
    assert FA.default == False
    assert callable(FA.validate)


# Generated at 2022-06-25 05:02:05.342324
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base()
    assert base_1._validated == False
    assert base_1._finalized == False
    base_1.post_validate(Templar())
    assert base_1._validated == True
    assert base_1._finalized == True


# Generated at 2022-06-25 05:02:12.519280
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test case 0 - if the value is None and the default value is not set
    # the method should raise an AnsibleParserError
    with pytest.raises(AnsibleParserError):
        base_0 = Base()
        base_0._valid_attrs['no_default'] = FieldAttributeBase('no_default', isa='string')
        base_0.post_validate(None)

    # Test case 1 - if the value of an attribute is a boolean
    # and the isa is int, the method should raise an AnsibleParserError
    with pytest.raises(AnsibleParserError):
        base_1 = Base()
        base_1._valid_attrs['no_default'] = FieldAttributeBase('no_default', isa='int')
        base_1.no_default = True

# Generated at 2022-06-25 05:02:15.317932
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    repr_0 = base_0.dump_attrs()
    assert repr_0 == base_0._attributes

# Generated at 2022-06-25 05:02:23.159276
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    class TestClass(Base):
        def __init__(self):
            self._valid_attrs = dict(
                foo = dict(
                    type='str',
                    default='defaultfoo',
                    private=False),
                bar = dict(
                    type='str',
                    default='defaultbar',
                    private=True),
            )
            Base.__init__(self)

    # Testcase 1
    print('Testcase 1')
    print('Expected output:')
    print('{')
    print('    "_valid_attrs": {')
    print('        "bar": {')
    print('            "type": "str",')
    print('            "default": "defaultbar",')
    print('            "private": true')
    print('        },')
    print('        "foo": {')