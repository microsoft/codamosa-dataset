

# Generated at 2022-06-25 04:54:11.571387
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # setup test
    field_attribute_base_0 = FieldAttributeBase()



# Generated at 2022-06-25 04:54:21.982631
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_1 = FieldAttributeBase()

    # test for case where value is string
    value_2 = 'test'
    attribute_2 = FieldAttributeBase(isa='string')
    templar = None

    # set from private_test_Method
    result_2 = field_attribute_base_1.get_validated_value('', attribute_2, value_2, templar)
    assert value_2 == result_2

    # test for case where value is int
    value_3 = 123
    attribute_3 = FieldAttributeBase(isa='int')
    templar = None

    # set from private_test_Method

    result_3 = field_attribute_base_1.get_validated_value('', attribute_3, value_3, templar)
    assert value_3 == result_3

# Generated at 2022-06-25 04:54:29.072507
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # test case 1:
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.load_data({'new_name':'old_name', 'new_type':'old_type'})
    assert field_attribute_base.new_name == 'old_name'
    assert field_attribute_base.new_type == 'old_type'

    # test case 2:
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_2.load_data({'new_name':'old_name', 'new_type':'old_type'})
    assert field_attribute_base_2.new_name == 'old_name'
    assert field_attribute_base_2.new_type == 'old_type'



# Generated at 2022-06-25 04:54:31.160862
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_ds() == dict(uid='root', gid='root', user='root', group='root', mode='0644')


# Generated at 2022-06-25 04:54:34.271402
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # start a FieldAttributeBase object
    field_attribute_base_0 = FieldAttributeBase()

    test_data = {'id': 'abc'}
    field_attribute_base_0.load_data(test_data)

    # load_data() has been executed and changes the data
    assert field_attribute_base_0.data == {'id': 'abc'}


# Generated at 2022-06-25 04:54:45.945992
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    # data is a dict
    data = dict()
    # Test when the dict contains the key 'foo'
    data['foo'] = 'bar'
    assert field_attribute_base_0.deserialize(data) == field_attribute_base_0
    # Test when the dict does not contain the key 'foo'
    data.clear()
    assert field_attribute_base_0.deserialize(data) == field_attribute_base_0
    # data is not a dict
    # TypeError should be raised
    data = "foobar"
    with pytest.raises(TypeError):
        field_attribute_base_0.deserialize(data)


# Generated at 2022-06-25 04:54:51.893105
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # Create some FieldAttribute objects
    field_attribute_test_0 = FieldAttribute(default=None, inherit=False, priority=0)
    field_attribute_test_1 = FieldAttribute(default='test_default_1', inherit=False, priority=9999)
    field_attribute_test_2 = FieldAttribute(default=None, inherit=True, priority=0)
    field_attribute_test_3 = FieldAttribute(default='test_default_3', inherit=True, priority=9999)
    field_attribute_test_4 = FieldAttribute(default=None, inherit=False, priority=0)
    field_attribute_test_5 = FieldAttribute(default='test_default_5', inherit=False, priority=9999)

    # Create a class with a FieldAttribute

# Generated at 2022-06-25 04:54:59.673975
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # This import is needed to test this method
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # This import is needed to test this method
    from ansible.vars.hostvars import HostVars
    # This import is needed to test this method
    from ansible.errors import AnsibleUndefinedVariable
    # This import is needed to test this method
    import traceback
    # This import is needed to test this method
    import sys
    # This import is needed to test this method
    import tempfile
    # This import is needed to test this method
    import shutil
    # This import is needed to test this method
    import os
    # This import is needed to test this method
    import pwd
    # This import is needed to test this method
    import time
    # This import is needed

# Generated at 2022-06-25 04:55:01.907588
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    all_passed = True
    try:
        test_case_0()
    except Exception as inst:
        all_passed = False
        print(type(inst))
        print(inst)
        return all_passed

if __name__ == '__main__':
    test_FieldAttributeBase_post_validate()

# Generated at 2022-06-25 04:55:04.953815
# Unit test for method get_path of class Base
def test_Base_get_path():
    base_obj = Base()

    try:
        assert(base_obj.get_path() == ":0")
    except:
        print(base_obj.get_path())
        assert(False)


# Generated at 2022-06-25 04:55:38.219407
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    # Call get_validated_value method of FieldAttributeBase
    # with parameters: 'aliases', FieldAttribute('aliases', 'list'), '', TemplatedValue('vaulted pass with templated variable {{var_name}}')
    field_attribute_base_0.get_validated_value(name='aliases', attribute=FieldAttribute('aliases', 'list'), value='', templar=TemplatedValue('vaulted pass with templated variable {{var_name}}'))
    # Call get_validated_value method of FieldAttributeBase
    # with parameters: 'aliases', FieldAttribute('aliases', 'list'), '', TemplatedValue(['somevalue1', 'alt_value'])

# Generated at 2022-06-25 04:55:44.670300
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    global FieldAttribute
    FieldAttribute = FieldAttribute
    global FieldAttributeBase
    FieldAttributeBase = FieldAttributeBase
    global Attribute
    Attribute = Attribute
    global Base
    Base = Base

    base_0 = Base()
    field_attribute_base_0 = FieldAttributeBase()
    attributes_0 = Attribute()

    field_attribute_base_0.__init__(None, None, None)
    field_attribute_base_0.__init__(attributes_0, None, None)
    base_0.get_dep_chain()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:55:46.470184
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.load_data(ds=dict())


# Generated at 2022-06-25 04:55:49.980156
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0_copy = field_attribute_base_0.copy()
    assert type(field_attribute_base_0_copy) == FieldAttributeBase


# Generated at 2022-06-25 04:55:54.227823
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    fixture = Base()

    assert fixture
    assert callable(fixture.get_dep_chain)


# Generated at 2022-06-25 04:56:03.194286
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    # test for method get_validated_value of class FieldAttributeBase
    field_attribute_base_0.get_validated_value("name", 0, value, templar)

    # test for method post_validate of class FieldAttributeBase
    field_attribute_base_0.post_validate(templar)

    # test for method _extend_value of class FieldAttributeBase
    field_attribute_base_0._extend_value(value, new_value, prepend)

    # test for method dump_attrs of class FieldAttributeBase
    field_attribute_base_0.dump_attrs()

    # test for method from_attrs of class FieldAttributeBase
    field_attribute_base_0.from_attrs(attrs)

    # test for

# Generated at 2022-06-25 04:56:07.554540
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_post_validate_exception = None

# Generated at 2022-06-25 04:56:12.327070
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test_obj = FieldAttributeBase()
    attrs = {}
    test_obj.from_attrs(attrs)


# Generated at 2022-06-25 04:56:23.581727
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Make sure the post_validate method throws exceptions when called with
    bad arguments.

    :raises: TypeError, ValueError
    '''
    # Set up the empty test class
    class TestBase(object):
        _valid_attrs = dict(
            isa='integer',
            default=None,
            required=True,
        )

    # Set up a templar loader
    loader = DataLoader()

    # Set up a test value and check it against the integer test
    val = 1
    test_base_obj = TestBase()
    test_base_obj._post_validate_isa(test_base_obj._valid_attrs['isa'], val, loader)

    # Use a string value
    val = 'test'
    with pytest.raises(ValueError):
        test_base

# Generated at 2022-06-25 04:56:26.503451
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test = Base()
    assert test.get_search_path() == []

# Generated at 2022-06-25 04:57:00.629104
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    ds_0 = {}
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0._finalized = False
    field_attribute_base_0.post_validate(ds_0)
    field_attribute_base_0._finalized = True
    field_attribute_base_0.post_validate(ds_0)


# Generated at 2022-06-25 04:57:02.745331
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase(**{'name': 'foo'})
    field_attribute_base_0.from_attrs({'name': 'bar'})


# Generated at 2022-06-25 04:57:14.090899
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # test case:
    print("\n*** test get_search_path for runner_item")
    runner_item = RunnerItem(host="grover", task=Task(), action="setup", job_id=0, result=None)
    result = runner_item.get_search_path()
    print("test_result: %s\n" % result)

    # test case:
    print("\n*** test get_search_path for task")
    task = Task()
    result = task.get_search_path()
    print("test_result: %s\n" % result)

    # test case:
    print("\n*** test get_search_path for play")
    play = Play()
    result = play.get_search_path()
    print("test_result: %s\n" % result)

   

# Generated at 2022-06-25 04:57:19.345221
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()

    # Test with attribute 'action' being present in FieldAttributeBase
    # Test with attribute 'name' being present in FieldAttributeBase
    # Test with attribute 'action' being present in FieldAttributeBase
    # Test with attribute 'name' being present in FieldAttributeBase
    setattr(field_attribute_base_0, 'action', 'run')
    setattr(field_attribute_base_0, 'name', 'test_action_name')
    expected = {'action':'run', 'name':'test_action_name'}
    assert field_attribute_base_0.dump_attrs() == expected


# Generated at 2022-06-25 04:57:24.675234
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    attrs = {'attr_0': 0, 'attr_1': 1, 'attr_2': 2}
    if field_attribute_base_0.from_attrs(attrs):
        print("Error")


# Generated at 2022-06-25 04:57:33.438684
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class TestTask(Task):
        def __init__(self):
            super(TestTask, self).__init__()
            self.result = {}

        def _post_validate_foo(self, attribute, value, templar):
            self.result['foo'] = value
            return value

    tt = TestTask()
    tt.vars = dict(foo=dict(bar='bar'))
    tt.foo = dict(bar='{{ foo.bar }}')
    templar = Templar(loader=None, variables=tt.vars)
    tt.post_validate(templar=templar)
    assert tt.result == dict(foo=dict(bar='bar'))


# Generated at 2022-06-25 04:57:43.653301
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Create a new play_context instance
    play_context_0 = PlayContext()
    # Create a new play instance
    play_0 = Play()
    play_0._ds = Ds()
    play_0._ds._data_source = "test_case_0.yaml"
    play_0._ds._line_number = 1
    play_0._play_contexts = [play_context_0]
    play_0._parent = None
    play_0._valid_attrs = None
    play_0._finalized = False
    play_0._squashed = False
    play_0._uuid = "b547f953-1a71-4f71-957c-9a9c3a3af583"
    # Create a new task instance
    task_0 = Task()
    task_

# Generated at 2022-06-25 04:57:44.896723
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base_0 = Base()
    base_0.get_search_path()
    pass



# Generated at 2022-06-25 04:57:50.069934
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Simple test to verify dump_attrs.
    # @todo: Need more tests.
    field_attribute_base_0 = FieldAttributeBase()
    if field_attribute_base_0.dump_attrs() is None:
        print("FAIL: Value of dump_attrs() is None.")


# Generated at 2022-06-25 04:57:54.593250
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.post_validate() == None

if __name__ == "__main__":
    test_case_0()
    test_FieldAttributeBase_post_validate()
    print("success.")

# Generated at 2022-06-25 04:58:42.109915
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    class AnsibleUndefinedVariable(object):
        pass
    class UndefinedError(object):
        pass
    class boolean(object):
        def __init__(self):
            pass
    
    try:
        class AnsibleParserError(object):
            pass
    except Exception as err:
        pass

    try:
        class shallowcopy(object):
            def __init__(self):
                pass
    except Exception as err:
        pass
    try:
        shallowcopy_0 = shallowcopy()
    except Exception as err:
        pass
    try:
        shallowcopy_1 = shallowcopy()
    except Exception as err:
        pass
    try:
        shallowcopy_2 = shallowcopy()
    except Exception as err:
        pass

# Generated at 2022-06-25 04:58:52.650090
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    data = dict()
    data['name'] = 'my_name'
    data['no_log'] = True
    data['required'] = True
    data['default'] = 'my_default'
    data['aliases'] = ['alias_0','alias_1','alias_2','alias_3']
    data['choices'] = [0,5,10]
    data['version_added'] = '2.4'
    data['version_removed'] = '3.5'
    data['deprecated_for_removal'] = True
    data['deprecated_reason'] = 'Because I said so.'
    data['deprecated_since'] = '2.11'
    data['removed_in'] = '3.10'

# Generated at 2022-06-25 04:58:53.881555
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize(data={})


# Generated at 2022-06-25 04:59:01.944720
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """Unit test for method validate of class FieldAttributeBase
    """
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    # Test case where $value is None
    field_attribute_base_0.validate(None)
    # Test case where $value is a string
    field_attribute_base_1.validate("abc")


# Generated at 2022-06-25 04:59:04.168418
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    print(obj.dump_attrs())


# Generated at 2022-06-25 04:59:14.364681
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attribute_base_0 = FieldAttributeBase()
    # If we don't have a squas attribute, we don't need to squash
    assert field_attribute_base_0.squash is None
    assert field_attribute_base_0._squashed is False
    field_attribute_base_0._squashed = True
    field_attribute_base_0.squash = False
    assert field_attribute_base_0.is_squashed == False
    field_attribute_base_0.squash = True
    assert field_attribute_base_0.is_squashed == True
    field_attribute_base_0._squashed = False
    field_attribute_base_0.squash = False
    assert field_attribute_base_0.is_squashed == False
    field_attribute_base_0.squash = True
   

# Generated at 2022-06-25 04:59:18.668914
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    test_value_0 = FieldAttributeBase()
    try:
        test_value_0.squash()
    except Exception as exception_instance:
        if isinstance(exception_instance, AnsibleAssertionError):
            pass
        else:
            traceback.print_exc()
            raise AssertionError('Unexpected exception thrown: %s' % exception_instance)


# Generated at 2022-06-25 04:59:22.195620
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base = FieldAttributeBase()
    value = "66"
    attribute = FieldAttributeBase()
    attribute.isa = "int"
    templar = AnsibleBaseTemplar()
    assert field_attribute_base.get_validated_value("name", attribute, value, templar) == 66



# Generated at 2022-06-25 04:59:23.845192
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    field_attribute_base_0 = FieldAttributeBase()

    data_0 = {}
    field_attribute_base_0.deserialize(data=data_0)


# Generated at 2022-06-25 04:59:27.535840
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    a = FieldAttributeBase()
    b = FieldAttributeBase()
    b.value = 1
    c = FieldAttributeBase()
    c.value = 2
    a.squash(b, c)
    assert a.value == [1, 2]
    a.squash(c, None)
    assert a.value == [1, 2, None]



# Generated at 2022-06-25 05:00:00.200850
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    result = field_attribute_base_0.dump_attrs()
    assert result == {}, result


# Generated at 2022-06-25 05:00:06.021756
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.deserialize(data=None)
    except AnsibleAssertionError as e:
        print('Exception caught: %s' % to_text(e))


# Generated at 2022-06-25 05:00:10.252586
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    copy_0 = field_attribute_base_0.copy()


# Generated at 2022-06-25 05:00:21.583929
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    import pytest

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode

    # Test for when passing a string to the from attrs.
    with pytest.raises(Exception, match="data should be a dict but is a str"):
        AnsibleBaseYAMLObject(None).from_attrs('somestring')

    # Test for when passing a unicode string to the from attrs.
    with pytest.raises(Exception, match="data should be a dict but is a str"):
        AnsibleBaseYAMLObject(None).from_attrs(u'somestring')

    # Test for when passing a unicode string with a unicode character to the from attrs.

# Generated at 2022-06-25 05:00:29.614220
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Initialize
    field_attribute_base = FieldAttributeBase()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    attrs = {'a': 1, 'b': 2}

    # Execute code under test
    field_attribute_base.from_attrs(attrs)

    # Check the results
    assert field_attribute_base.a == 1, "field_attribute_base.a (%s) != 1" % field_attribute_base.a
    assert field_attribute_base.b == 2, "field_attribute_base.b (%s) != 2" % field_attribute_base.b
    assert field_attribute_base_0.a == None, "field_attribute_base_0.a (%s) != None" % field_attribute_base_0

# Generated at 2022-06-25 05:00:41.559633
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    class FieldAttributeBaseTest0(FieldAttributeBase):
        def __init__(self):
            self._loader = None
            self._variable_manager = None
            self._validated = False
            self._finalized = False
            self._uuid = uuid.uuid4()
            self._attributes = dict()
            self._attributes['attr1'] = FieldAttributeBaseAttribute()
            self._attributes['attr2'] = FieldAttributeBaseAttribute()
            self._attributes['attr3'] = FieldAttributeBaseAttribute()
            self.attr1 = 1
            self.attr2 = 2
            self.attr3 = 3
            self.attr4 = 4

    field_attribute_base_test_0 = FieldAttributeBaseTest0()
    field_attribute_base_test_0.dump_me(with_uuid=True)



# Generated at 2022-06-25 05:00:49.039845
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    # Test with hostvars
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'localhost'
    field_attribute_base_0.vars = dict()
    attrs = dict()
    attrs['name'] = 'localhost'
    attrs['vars'] = dict()
    field_attribute_base_0.from_attrs(attrs)

    assert (field_attribute_base_0.name == 'localhost')
    assert (field_attribute_base_0.vars == dict())
    assert (field_attribute_base_0._finalized == True)
    assert (field_attribute_base_0._squashed == True)
    field_attribute_base_0._finalized = False
    field_attribute_base_0._squashed = False

    # Test with

# Generated at 2022-06-25 05:00:51.758720
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert True

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 05:01:01.250162
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    # Case 1

# Generated at 2022-06-25 05:01:03.943802
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    data = {}
    try:
        field_attribute_base_0.deserialize(data)
    except AssertionError as exc:
        assert 'data' in str(exc)


# Generated at 2022-06-25 05:01:34.392784
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 05:01:38.167098
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    # get_dep_chain() return the dependency chain of the given task
    '''
    base_0 = Base()
    dep_chain_0 = base_0.get_dep_chain()
    assert dep_chain_0 == None


# Generated at 2022-06-25 05:01:48.158792
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test_case_data = [
        # Expected result, Input argument
        [ {'name': 'llt'}, {'name': 'llt'} ],
        [ {}, {} ],
        [ {'name': ''}, {'name': ''} ],
        [ {'name': '', 'uuid': ''}, {'name': '', 'uuid': ''} ]
    ]

    obj = FieldAttributeBase()
    passed = 0
    total = 0

    for exp, arg in test_case_data:
        total += 1

# Generated at 2022-06-25 05:01:52.293655
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test for isa = 'class'
    # The attribute must be of class type
    # The class must have a method post_validate
    test_object = AttributeTestObject()
    test_object.post_validate(None)


# Generated at 2022-06-25 05:01:53.136742
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass


# Generated at 2022-06-25 05:01:59.261766
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    """ FieldAttributeBase.get_validated_value() """

    # test class instantiation
    field_attribute_base_0 = FieldAttributeBase()

    # test get_validated_value function
    # get_validated_value function of field_attribute_base_0
    value = True
    attribute = Attribute.FieldAttribute(FieldAttributeBase.FieldAttribute, 'FieldAttribute', None, bool)
    assert isinstance(field_attribute_base_0.get_validated_value('FieldAttribute', attribute, value, None), bool)
    value = False
    attribute = Attribute.FieldAttribute(FieldAttributeBase.FieldAttribute, 'FieldAttribute', None, bool)
    assert isinstance(field_attribute_base_0.get_validated_value('FieldAttribute', attribute, value, None), bool)

# Generated at 2022-06-25 05:02:03.753784
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase.copy(field_attribute_base_0)


# Generated at 2022-06-25 05:02:05.017061
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass


# Generated at 2022-06-25 05:02:06.916919
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Basic validation test
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.validate() == True



# Generated at 2022-06-25 05:02:13.478708
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Checks if the post_validate method is working properly
    '''
    field_attribute_base_0 = FieldAttributeBase()

    contexts_0 = Context()
    # Set values for fields 'options' and 'dummy'
    fields_options = dict()
    fields_dummy = dict()
    fields_options['host_key_checking'] = True
    # Set values for fields 'run_once' and 'dummy'
    fields_run_once = dict()
    fields_dummy = dict()
    fields_run_once['enabled'] = True
    # Set values for fields 'name' and 'dummy'
    fields_name = dict()
    fields_dummy = dict()
    fields_name['name'] = 'dummy'
    # Set values for fields 'vars' and 'dummy'
   

# Generated at 2022-06-25 05:02:42.980009
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    assert(field_attribute_base_0.dump_attrs() is not None)

# Generated at 2022-06-25 05:02:46.890729
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    test_obj = BaseMeta()
    res = test_obj.__new__()



# Generated at 2022-06-25 05:02:47.635064
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass


# Generated at 2022-06-25 05:02:53.452844
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # create a FieldAttributeBase object
    # field_attribute_base = FieldAttributeBase()

    # create options argument that is passed to FieldAttributeBase.dump_me()
    options = None

    # call the method dump_me() of the class FieldAttributeBase
    # field_attribute_base = FieldAttributeBase()
    # field_attribute_base.dump_me(options)

    # check the field attribute contains the correct value
    # assert (field_attribute_base.dump_me(options) == None)
    # assert (field_attribute_base.dump_me(options) != None)

    # created FieldAttributeBase object
    field_attribute_base = FieldAttributeBase()

    print(field_attribute_base)



# Generated at 2022-06-25 05:03:02.715776
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Unit test for method from_attrs of class FieldAttributeBase
    '''

    # Create a Task instance
    test_task = Task()

    # Create the dictionary that would be returned by the serialize
    # method. This is what we would expect from the serialize method.
    # We would turn this around and pass it to from_attrs so we can
    # test that as well.
    test_dict = test_task.serialize()

    # Create a copy of the test_task and then call the from_attrs method
    # which in turn will set the attributes of the instance to the values
    # in the dictionary that was created above.
    test_task_from_dict = Task()
    test_task_from_dict.from_attrs(test_dict)

    # Check that the values of the instance before and after