

# Generated at 2022-06-25 04:54:38.795492
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Initialization
    sandbox = FieldAttributeBase.FieldAttributeBase()
    sandbox.from_attrs({'attribute_name': 'attr_value'})



# Generated at 2022-06-25 04:54:49.366006
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class FakeLoader:
        # Fake the loader
        def __init__(self, data=''):
            self.data = data

        def load_from_file(self, filename):
            return self.data

    class FakeVarsManager:
        # Fake the vars manager
        def __init__(self):
            self.host_vars = dict()
            self.group_vars = dict()
            self.group_vars_per_host = dict()
            self.all_vars = dict()
            self.extra_vars = dict()

        def get_host_vars(self, host, new_pb_basedir=None):
            return self.host_vars[host]

        def get_group_vars(self, group, new_pb_basedir=None):
            return self.group_

# Generated at 2022-06-25 04:54:51.046522
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute = FieldAttributeBase()
    assert field_attribute.get_validated_value(None, None, 10, None) == 10


# Generated at 2022-06-25 04:54:58.942900
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-25 04:55:09.248342
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # test for exception raising if isa is absent
    with pytest.raises(AnsibleAssertionError):
        FieldAttributeBase(name="toto")

    # test for exception raising if isa is not in ISA list
    with pytest.raises(AnsibleAssertionError):
        FieldAttributeBase(name="toto", isa="ananas")

    # test for exception raising when isa is in ISA list, but still not supported
    with pytest.raises(AnsibleAssertionError):
        FieldAttributeBase(name="toto", isa="list")
    with pytest.raises(AnsibleAssertionError):
        FieldAttributeBase(name="toto", isa="set")

# Generated at 2022-06-25 04:55:11.325556
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base_0 = FieldAttributeBase()
    # Run the deserialize with data equal to dict()
    data = dict()
    base_0.deserialize(data=data)


# Generated at 2022-06-25 04:55:15.092826
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_instance = Base()
    from_attrs_return_value = base_instance.from_attrs({"key":"value"})
    assert base_instance.key == "value"


# Generated at 2022-06-25 04:55:16.609718
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    dep_chain = base_0.get_dep_chain()
    assert dep_chain is None

# Generated at 2022-06-25 04:55:24.517978
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-25 04:55:34.205189
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # test a few cases that should not throw exceptions
    assert FieldAttributeBase._load_data(None, None, None, None) is None

    ansible_vars = dict(
        dict1=dict(
            dict2=dict(
                dict3=dict(
                    dict4=dict(
                        dict5=dict(
                            dict6=dict(
                                dict7=dict(
                                    dict8=dict(
                                        dict9=dict(
                                            dict10=dict(
                                                key10a="value10a",
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
    )

    # test that we can get all the way down to the end of the dictionary

# Generated at 2022-06-25 04:56:08.367833
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()
    base_1 = Base()
    # test if two _instances of Base have different uuid's
    assert base_0._uuid != base_1._uuid, "test_FieldAttributeBase_dump_me() failed"


# Generated at 2022-06-25 04:56:17.152566
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    templar = None
    name = "test_FieldAttributeBase_get_validated_value"
    attribute = FieldAttribute(isa='string', default='test_FieldAttributeBase_get_validated_value')
    value = "test_FieldAttributeBase_get_validated_value"
    try:
        base_0.get_validated_value(name, attribute, value, templar)
    except Exception as e:
        raise AssertionError('Exception raised %s' % e)


# Generated at 2022-06-25 04:56:18.452247
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    base_0.post_validate()


# Generated at 2022-06-25 04:56:24.052532
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    assert(base_0.dump_attrs() == {
        'delegate_to': None,
        'no_log': False,
        'register': None,
        'run_once': False,
        'tags': [],
        'when': None,
        'vars': {},
        'priority': 1,
        'environment': {},
        'async': 0,
        'poll': 0,
        'loop_control': {
            'loop': None,
            'index': None,
            'index_var': None
        }
    })


# Generated at 2022-06-25 04:56:31.627834
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    print("test_FieldAttributeBase_get_validated_value:")
    print("test_FieldAttributeBase_get_validated_value of class FieldAttributeBase:")
    base_0 = Base()
    attribute = FieldAttributeBase()
    value = 'test_value'
    templar = Templar()
    result = base_0.get_validated_value('test_name', attribute, value, templar)
    print(result)
    assert result == value


# Generated at 2022-06-25 04:56:35.358738
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:56:40.726791
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()
    attrname = "attr_name"
    attrvalue = "attr_value"
    attribute = FieldAttributeBase(attrname)
    attribute.add_field(base_0, attrvalue)
    attribute.dump_me()


# Generated at 2022-06-25 04:56:47.073489
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    Base.add_field('no_ds_updated')
    base_1 = Base()
    assert base_1.get_ds() == None

    Base.add_field('ds_updated')
    base_2 = Base()
    assert base_2.get_ds() == None

    base_2.ds_updated = 'ds_updated_value'
    assert base_1.get_ds() == None
    assert base_2.ds_updated == 'ds_updated_value'
    assert base_2.get_ds() == 'ds_updated_value'


# Generated at 2022-06-25 04:56:50.553660
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    repr_dict = Base(foo=5).dump_attrs()

    # Check that the return value is dictionary type
    assert isinstance(repr_dict, dict)

    # Check for presence of 'foo' in returned dictionary
    assert 'foo' in repr_dict

    # Check for correct value of 'foo' in returned dictionary
    assert repr_dict['foo'] == 5


# Generated at 2022-06-25 04:56:57.001755
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base = Base()
    test_value = 1
    assert base.get_validated_value('test_value', FieldAttribute(isa='int'), str(test_value), None) == test_value
    assert base.get_validated_value('test_value', FieldAttribute(isa='string'), test_value, None) == str(test_value)
    assert base.get_validated_value('test_value', FieldAttribute(isa='bool'), test_value, None) == boolean(test_value, strict=True)
    assert base.get_validated_value('test_value', FieldAttribute(isa='percent'), test_value, None) == float(test_value)


# Generated at 2022-06-25 04:57:27.636680
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase('test_key', 'test_field_name', 'test_default', 'test_isa', False, False)

    try:
        field_attribute_base_0.post_validate(None)
    except Exception as exception_0:
        if type(exception_0) is not NotImplementedError:
            raise



# Generated at 2022-06-25 04:57:34.471518
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test a block of type dict
    attr = FieldAttributeBase()
    data = dict(a=1, b=2)
    attr.load_data(data)
    assert attr.a == 1
    assert attr.b == 2
    assert attr.c is None
    assert attr.data is data

    # Test a block of type list
    attr = FieldAttributeBase()
    data = dict(a=1, b=2)
    attr.load_data([data])
    assert attr.a == 1
    assert attr.b == 2
    assert attr.c is None
    assert attr.data is data

    # Test a block of type that cannot be converted to dict
    attr = FieldAttributeBase()
    data = dict(a=1, b=2)

# Generated at 2022-06-25 04:57:44.250701
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_1 = Base()

    # get field_attributes from base_1
    v = base_1.field_attributes

    # get field_attributes as dict from base_1
    v = base_1.dump_me()
    assert v == {}

    # test_case_0 load vars
    base_1._load_vars('vars', 'a')
    base_1.post_validate(None)
    v = base_1.dump_me()
    # check that vars is not included in dump_me() output
    assert 'vars' not in v
    assert v == {}

    # test_case_1 load vars
    base_1._load_vars('vars', dict(test1='a'))
    base_1.post_validate(None)
    base_1

# Generated at 2022-06-25 04:57:53.347993
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    ds = dict(one=1, two=2, three=3, four=[1, 2, 3], five=[1, 2, 3])
    class A(Base):
        _valid_attrs = dict(one   = FieldAttribute(),
                            two   = FieldAttribute(squash=True),
                            three = FieldAttribute(squash=3),
                            four  = FieldAttribute(squash=True, listof=int),
                            five  = FieldAttribute(squash=True))
    a = A()
    try:
        a.load_data(ds)
    except AnsibleParserError as e:
        display.display("unexpected error: %s" % e)
        raise

    # default is no squash
    assert a._attributes['one'] == 1
    assert a._attributes['two'] == 2
   

# Generated at 2022-06-25 04:58:00.677426
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_a = FieldAttributeBase()
    field_a.type = 'FieldAttributeBase'
    field_a.isa = 'dict'

    # validate null values
    dict_a = dict()
    dict_a['dict_a'] = 'dict_a'
    field_a.nullable = True
    field_a.validate(None, None)
    try:
        field_a.validate(dict_a, 'dict_a')
    except AssertionError:
        pass
    else:
        raise Exception('expect AssertionError here')

    # validate allow empty
    field_a.nullable = True
    field_a.allow_empty = True
    field_a.validate(dict_a, 'dict_a')

    # validate not nullable
    field_a.nullable = False


# Generated at 2022-06-25 04:58:09.598737
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    base_0.attr_1 = "attr_1_val_0"
    base_0.attr_2 = "attr_2_val_0"
    expected_1 = {
        'attr_1': "attr_1_val_0",
        'attr_2': "attr_2_val_0",
    }
    result_1 = base_0.dump_attrs()
    assert expected_1 == result_1

test_case_0()
test_FieldAttributeBase_dump_attrs()

# Generated at 2022-06-25 04:58:19.342262
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class InvalidBase(Base):
        def __init__(self):

            super(InvalidBase, self).__init__()

            self._valid_attrs = dict(
                required_var = FieldAttribute(isa='string', required=True),
            )

    try:
        # post validate an object with a required
        # field that isn't set
        InvalidBase().post_validate(templar=None)
    except AnsibleParserError as e:
        if 'required but was not set' in to_text(e):
            pass
        else:
            raise e
    else:
        assert False



# Generated at 2022-06-25 04:58:27.208334
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_0 = Base()

    if is_py3:
        assert base_0._valid_attrs == {'_uuid': FieldAttribute(isa='string', default=UUID, static=False), u'_validated': FieldAttribute(isa='bool', default=False, static=False), u'_variable_manager': FieldAttribute(isa='class', default=UnsetParameter, static=False), u'_finalized': FieldAttribute(isa='bool', default=False, static=False), u'_squashed': FieldAttribute(isa='bool', default=False, static=False), u'_loader': FieldAttribute(isa='class', default=UnsetParameter, static=False)}

# Generated at 2022-06-25 04:58:37.785147
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Test method to check if FieldAttributeBase class method get_ds is working as expected.
    '''
    field_attribute = [
        FieldAttributeBase(name='count', isa='int', default=1, tags={'inheritance': 'include'}),
        FieldAttributeBase(name='include', isa='list', default=[]),
        FieldAttributeBase(name='exclude', isa='list', default=[], tags={'inheritance': 'exclude'})
    ]

    # field_attribute_1 contains raw data to be passed to FieldAttributeBase class
    field_attribute_1 = dict(
        count=5,
        include=['', '', 'prajneesh'],
        exclude=[]
    )

    obj = Base()
    obj._valid_attrs = dict()
    obj._ds

# Generated at 2022-06-25 04:58:43.700730
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # dump_me should return the FieldAttributeBase class instance as a dict
    attribute = FieldAttributeBase('test', always_post_validate=True, default=None, isa='string', listof=None, static=False)
    assert isinstance(attribute.dump_me(), dict), 'dump_me should return the class instance as a dict'


# Generated at 2022-06-25 04:59:33.881009
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base = FieldAttributeBase()
    var = 1
    attribute = FieldAttribute(isa=type(var))
    result = base.get_validated_value('name', attribute, '1', None)
    assert result == int(var)


# Generated at 2022-06-25 04:59:37.047345
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute = FieldAttributeBase()
    field_attribute.post_validate(1)


# Generated at 2022-06-25 04:59:40.403866
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # Call function under test
    try:
        test_case_0()
    except Exception as e:
        # Dump traceback for debugging
        import traceback
        traceback.print_exc()
        # AssertionError if exception was not expected
    # Test assertions
    assert True



# Generated at 2022-06-25 04:59:47.903691
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Create a test object
    base_1 = Base()
    base_1.get_search_path()

## unit test for get_vault_password method
#def test_Base_get_vault_password():
#    # create a test object
#    base_2 = Base()
#    return base_2.get_vault_password()


# Generated at 2022-06-25 04:59:57.815301
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import sys
    import os

    base_0 = Base()
    #with pytest.raises(AnsibleUndefinedVariable):
    #    base_0.get_search_path()
    assert base_0.get_search_path() == []

    base_1 = Base()
    setattr(base_1, '_parent', Base())
    setattr(base_1._parent, '_parent', Base())
    setattr(base_1._parent._parent, '_parent', Base())
    setattr(base_1._parent._parent._parent, '_parent', Base())
    setattr(base_1._parent._parent._parent._parent, '_parent', Base())
    setattr(base_1._parent._parent._parent._parent._parent, '_parent', Base())
    #with pytest.raises(

# Generated at 2022-06-25 04:59:59.915569
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FA = FieldAttribute('test', 'Path to a file')
    FA.load_data('test', '/tmp/foo')
    assert FA._value == '/tmp/foo'



# Generated at 2022-06-25 05:00:07.558586
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()

    base_0.name = 123
    assert isinstance(base_0.get_validated_value('name', base_0._valid_attrs['name'], 123, None), int)

    base_0.name = 'abc'
    assert isinstance(base_0.get_validated_value('name', base_0._valid_attrs['name'], 'abc', None), string_types)


# Generated at 2022-06-25 05:00:12.053542
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    templar = Templar(loader=None)
    pb = PlayContext()
    pb._post_validate_port(-1, None, templar)


# Generated at 2022-06-25 05:00:19.980365
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base = FieldAttributeBase()
    result = base.copy()
    assert result.default == None
    assert result.isa == 'string'
    assert result.priority == FieldAttributeBase.PRIORITY_DEFAULT
    assert result.required == False
    assert result.static == False
    assert result.module_attributes == False
    assert result.action_attributes == False
    assert result.play_attributes == False
    assert result.playbook_attributes == False



# Generated at 2022-06-25 05:00:24.971352
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert not base.get_dep_chain()
    base._parent = Base()
    assert not base.get_dep_chain()
    base._parent.get_dep_chain = MagicMock()
    base._parent.get_dep_chain.return_value = [1, 2]
    assert base.get_dep_chain() == [1, 2]

