

# Generated at 2022-06-25 04:54:11.906171
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Testing constructor FieldAttributeBase.__init__
    # 1st test
    field_attribute_base_0 = FieldAttributeBase()

    # Testing constructor FieldAttributeBase.__init__
    # 2nd test
    field_attribute_base_0 = FieldAttributeBase(String, default=None)

    # Testing constructor FieldAttributeBase.__init__
    # 3rd test
    field_attribute_base_0 = FieldAttributeBase(String, default='', required=True)

    # Testing constructor FieldAttributeBase.__init__
    # 4th test
    field_attribute_base_0 = FieldAttributeBase(String, default='', required=True, choices=['', '', '', ''])

    # Testing constructor FieldAttributeBase.__init__
    # 5th test

# Generated at 2022-06-25 04:54:20.032919
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    class TestFieldAttributeBase_dump_attrs(FieldAttributeBase):
        def __init__(self):
            self._valid_attrs = dict(
                    str=FieldAttribute('str', isa='string', default='abc'),
                    int=FieldAttribute('int', isa='int', default=0),
                    float=FieldAttribute('float', isa='float', default=0.0),
                    bool=FieldAttribute('bool', isa='bool', default=False),
                    list=FieldAttribute('list', isa='list', default=['a'])
                    )
            self._valid_attrs['int'].expanduser = True
            self._valid_attrs['float'].expanduser = True
            self._valid_attrs['bool'].expanduser = True
            self._valid_attrs['list'].expanduser

# Generated at 2022-06-25 04:54:23.939163
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Setup
    field_attribute_base_obj = FieldAttributeBase()
    # Teardown

    # Test
    field_attribute_base_obj.deserialize(data)


# Generated at 2022-06-25 04:54:30.382945
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # UUT
    field_attribute_base_1 = FieldAttributeBase()
    # UUT
    field_attribute_base_2 = FieldAttributeBase()
    # UUT
    field_attribute_base_3 = FieldAttributeBase()
    # UUT
    field_attribute_base_4 = FieldAttributeBase()
    # UUT
    field_attribute_base_5 = FieldAttributeBase()
    # UUT
    field_attribute_base_6 = FieldAttributeBase()
    # UUT
    field_attribute_base_7 = FieldAttributeBase()
    # UUT
    field_attribute_base_8 = FieldAttributeBase()
    # UUT
    field_attribute_base_9 = FieldAttributeBase()
    # UUT
    field_attribute_base_10 = FieldAttributeBase()
    # UUT
    field_attribute

# Generated at 2022-06-25 04:54:36.080998
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = "test-name"
    field_attribute_base_0.default = "test-default"
    field_attribute_base_0.isa = "test-isa"
    field_attribute_base_0.choices = "test-choices"
    field_attribute_base_0.private = "test-private"
    field_attribute_base_0.versionadded = "test-versionadded"
    field_attribute_base_0.position = "test-position"
    field_attribute_base_0.required = "test-required"
    field_attribute_base_0.aliases = "test-aliases"
    field_attribute_base_0.always_post_validate = "test-always_post_validate"

# Generated at 2022-06-25 04:54:38.116219
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.validate()


# Generated at 2022-06-25 04:54:42.141111
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.deserialize({'attrs': {}})


# Generated at 2022-06-25 04:54:46.637544
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 04:54:53.700516
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    def expected_result():
        return
    field_attribute_base_0 = FieldAttributeBase()
    data_0 = {}
    field_attribute_base_0.load_data(data_0)
    assert field_attribute_base_0.data == expected_result()


# Generated at 2022-06-25 04:54:59.785016
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_1 = FieldAttributeBase()
    attrs = field_attribute_base_1.dump_attrs()
    assert attrs is not None
    assert attrs == {}
    field_attribute_base_1.set_loader(Mock())
    attrs = field_attribute_base_1.dump_attrs()
    assert attrs is not None
    assert attrs == {}

# Generated at 2022-06-25 04:55:26.000173
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass


# Generated at 2022-06-25 04:55:30.330837
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()

test_cases_FieldAttributeBase = [
    test_case_0,
    test_FieldAttributeBase_validate
]


# Generated at 2022-06-25 04:55:34.756700
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Make sure post_validate is able to run as a static method
    FieldAttributeBase.post_validate(FieldAttributeBase(), [])
    try:
        # Calling it with the wrong number of arguments should fail
        FieldAttributeBase.post_validate()
    except TypeError:
        pass


# Generated at 2022-06-25 04:55:39.633932
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    mod_0 = importlib.import_module('ansible.parsing.yaml.objects')
    obj_0 = getattr(mod_0, 'Base')()
    result = obj_0.get_search_path()
    assert type(result) == list


# Generated at 2022-06-25 04:55:41.410325
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.dump_me()


# Generated at 2022-06-25 04:55:44.544672
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    def test_FieldAttributeBase_validate_0():
        field_attribute_base_0 = FieldAttributeBase()
        try:
            field_attribute_base_0.validate()
            ok = True
        except:
            ok = False
        assert(ok)



# Generated at 2022-06-25 04:55:45.736196
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 04:55:53.469071
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field = FieldAttributeBase()

    # test case 1: value is None
    field._valid_attrs = {'v1': FieldAttribute(isa="string")}
    field.v1 = None
    templar = Templar(loader=None, variables=None)
    assert field.get_validated_value("v1", field._valid_attrs["v1"], field.v1, templar) == None

    # test case 2: isa is string
    field.v1 = "Test string"
    assert field.get_validated_value("v1", field._valid_attrs["v1"], field.v1, templar) == "Test string"

    # test case 3: isa is string, value is unicode
    field.v1 = u"Test unicode string"
    assert field.get_validated

# Generated at 2022-06-25 04:55:59.077737
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.validate(field_attribute_base_0)
    except Exception as exception_0:
        assert isinstance(exception_0, AnsibleParserError)
        print('expected error: %s' % to_text(exception_0))


# Generated at 2022-06-25 04:56:06.237945
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.attr1 = 'attr1 value'
    field_attribute_base.attr2 = 'attr2 value'
    field_attribute_base.attr3 = 'attr3 value'

    assert field_attribute_base.dump_attrs() == {'attr1': 'attr1 value', 'attr2': 'attr2 value', 'attr3': 'attr3 value'}


# Generated at 2022-06-25 04:56:31.760068
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_me() == {}


# Generated at 2022-06-25 04:56:32.873631
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() is None


# Generated at 2022-06-25 04:56:44.221938
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    field_attribute_base_0._valid_attrs = {}
    setattr(field_attribute_base_0, 'vars', None)
    # test normal case (int)
    argument = ('vars', 1, 'int')
    expected = 1

    actual_result = field_attribute_base_0.get_validated_value(*argument)
    assert expected == actual_result

    # test normal case (float)
    argument = ('vars', 1.0, 'float')
    expected = 1.0

    actual_result = field_attribute_base_0.get_validated_value(*argument)
    assert expected == actual_result

    # test normal case (string)
    argument = ('vars', 'string', 'string')
    expected = 'string'



# Generated at 2022-06-25 04:56:51.598035
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    FieldAttributeBase: post_validate tests
    '''
    # Initialize a FieldAttributeBase class
    field_attribute_base_0 = FieldAttributeBase()
    test_data = dict(string='some text',
                     int=123,
                     float=3.14159,
                     bool=True,
                     percent=42.0,
                     list=[],
                     set=set(),
                     dict={},
                     )
    expected_post_validate_values = dict(string='some text',
                                         int=123,
                                         float=3.14159,
                                         bool=True,
                                         percent=42.0,
                                         list=[],
                                         set=set(),
                                         dict={},
                                         )

# Generated at 2022-06-25 04:56:57.413347
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_dep_chain() == None


# Generated at 2022-06-25 04:57:05.266834
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    f1 = FieldAttributeBase(isa='int')
    f2 = FieldAttributeBase(isa='class')
    f3 = FieldAttributeBase(isa='bool')
    f4 = FieldAttributeBase(isa='float')
    f5 = FieldAttributeBase(isa='list')
    f6 = FieldAttributeBase(isa='dict')
    f7 = FieldAttributeBase(isa='set')
    f8 = FieldAttributeBase(isa='str')
    f9 = FieldAttributeBase(isa='percent')

    d1 = FieldAttributeBase(isa='int', default=42)
    d2 = FieldAttributeBase(isa='class', default=42)
    d3 = FieldAttributeBase(isa='bool', default=42)
    d4 = FieldAttributeBase(isa='float', default=42)

# Generated at 2022-06-25 04:57:09.040269
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 04:57:12.452971
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Setup fixtures
    field_attribute_base = FieldAttributeBase()
    ds = { 'key': 'value' }

    # Exercise
    field_attribute_base.validate(ds)

    # Verify


# Generated at 2022-06-25 04:57:14.004681
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_attrs() == {}


# Generated at 2022-06-25 04:57:14.527525
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-25 04:57:40.740989
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()

    # Default test
    field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')


# Generated at 2022-06-25 04:57:48.320474
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    repr = {'tags': {'item_0': 'test_tag_0', 'item_1': 'test_tag_1'}}
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.deserialize(repr)


if __name__ == '__main__':
    import os
    import sys

    # These imports are needed to add the methods to the class.
    # Without them the tests will fail
    try:
        import json
        import yaml
        import lxml.etree
    except ImportError as e:
        print(e)
        print('Tests cannot be run without the following modules installed:')
        print('    yaml, json, and lxml')
        sys.exit(1)

    module_path = os.path.dirname(__file__)


# Generated at 2022-06-25 04:57:57.540139
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_2 = FieldAttributeBase(name='bobo', isa='bo')
    field_attribute_base_3 = FieldAttributeBase(name='unknown')
    obj = FakeField()
    try:
        field_attribute_base_1.validate(obj, 'value')
    except AnsibleAssertionError as ae:
        if ae.args[0] != 'expected the obj (%s) to have the base object (%s) as part of its mro' % (obj, BaseObject):
            raise
    field_attribute_base_2.validate(obj, 'value')

# Generated at 2022-06-25 04:57:59.012269
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.dump_me() == {}, 'test_FieldAttributeBase_dump_me #0'


# Generated at 2022-06-25 04:58:00.192942
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.get_path()


# Generated at 2022-06-25 04:58:01.974501
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    try:
        base_0.get_dep_chain()
    except ValueError as e:
        assert isinstance(e, ValueError)
        assert e.args[0] == "self._parent is not defined"



# Generated at 2022-06-25 04:58:12.840737
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()

    # At first, no class is registered
    assert field_attribute_base_0._valid_attrs == {}

    # Try to register an attribute
    field_attribute_base_0.register_attribute('test', FieldAttribute(isa='bool', default=True, private=True))

    # The attribute should now be in the list of registered attributes
    assert 'test' in field_attribute_base_0._valid_attrs
    assert field_attribute_base_0._valid_attrs['test'].isa == 'bool'
    assert field_attribute_base_0._valid_attrs['test'].default == True
    assert field_attribute_base_0._valid_attrs['test'].private == True

    # Try to register an attribute with an invalid type

# Generated at 2022-06-25 04:58:19.437507
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-25 04:58:25.149730
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method load_data of class FieldAttributeBase
    :return:
    '''
    field_attribute_base_0 = FieldAttributeBase()
    data = load_data_from_file('test/fixtures/load_data.yaml')
    field_attribute_base_0.load_data(data)
    assert field_attribute_base_0.__class__.__name__ == 'FieldAttributeBase'
    return field_attribute_base_0



# Generated at 2022-06-25 04:58:30.563107
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attribute_base_0 = FieldAttributeBase()
    # Test for existence of method:
    assert hasattr(field_attribute_base_0, "squash")
    # Test for method result:
    assert field_attribute_base_0.squash() is None


# Generated at 2022-06-25 04:59:01.028086
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    try:
        instance = FieldAttributeBase()
        instance.from_attrs(attrs=None)
    except AnsibleAssertionError as e:
        assert "data (None) should be a dict but is a <type 'NoneType'>" in e


# Generated at 2022-06-25 04:59:06.731200
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict(created_at='2015-12-18T20:24:54.991647')
    field_attribute_base_0 = FieldAttributeBase()
    deserialize_method = getattr(field_attribute_base_0, 'deserialize')
    deserialize_method(data)


# Generated at 2022-06-25 04:59:08.332723
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base = FieldAttributeBase()


# Generated at 2022-06-25 04:59:17.444036
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base(vars={"test_var_1": "test_value_1"}, name="base_0", uuid="base_0_uuid")
    assert base_0.get_search_path() == []
    base_0._ds = Mock()

    base_0._ds._data_source = 'task_source'
    base_0._ds._line_number = 'task_line_number'
    assert base_0.get_search_path() == ['task_source']

    base_0 = Base(vars={"test_var_1": "test_value_1"}, name="base_0", uuid="base_0_uuid")
    base_0._parent = Mock()
    base_0._parent._play = Mock()
   

# Generated at 2022-06-25 04:59:19.307284
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base()
    base_0.get_path()


# Generated at 2022-06-25 04:59:21.317763
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    expected_result = {}

    result = field_attribute_base_0.dump_attrs()

    assert result == expected_result


# Generated at 2022-06-25 04:59:24.211183
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_obj = FieldAttributeBase()
    test_obj.dump_me()


# Generated at 2022-06-25 04:59:30.107583
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    # make sure we can dump the attr dictionary
    data = dict()
    data['name'] = 'bob'
    data['age'] = 14
    data['uuid'] = 'asdfghjkl'
    data['finalized'] = False
    data['squashed'] = False

    field_attribute_base_0 = FieldAttributeBase()

    field_attribute_base_0.from_attrs(data)

    field_attribute_base_0_repr = field_attribute_base_0.dump_attrs()

    assert (field_attribute_base_0_repr == data)
    # test that we can load the object from the attrs

test_case_0()
test_FieldAttributeBase_dump_attrs()

# Generated at 2022-06-25 04:59:32.430306
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    field_attribute_base_0 = FieldAttributeBase()
    object_0 = object()
    object_1 = object()

    assert field_attribute_base_0.deserialize({"a": object_0, "b": object_1}, {"a": object_1, "b": object_0}) is None


# Generated at 2022-06-25 04:59:38.523951
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attribute_base_0 = FieldAttributeBase()
    with pytest.raises(NotImplementedError) as excinfo:
        field_attribute_base_0.squash()
    assert "FieldAttributeBase.squash(): This method must be implemented in subclasses." == excinfo.value.args[0]


# Generated at 2022-06-25 05:00:05.296619
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_1 = FieldAttributeBase()
    ds = {'required': False, 'always_post_validate': False}
    field_attribute_base_1._dump_me(ds)


# Generated at 2022-06-25 05:00:06.285229
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    play = dict2obj({'hosts': 'all'})
    assert isinstance(play.dump_attrs(), dict)


# Generated at 2022-06-25 05:00:18.040378
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base = FieldAttributeBase()
    collection_attribute = CollectionAttribute()
    # test when class name is FieldAttributeBase

# Generated at 2022-06-25 05:00:22.618835
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.from_attrs({'foo': 'bar'})
    assert field_attribute_base_0.foo == 'bar'


# Generated at 2022-06-25 05:00:25.740985
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    obj._finalized = False
    #print "Dump attrs:", obj.dump_attrs()
    assert obj.dump_attrs() == {'_finalized': False}


# Generated at 2022-06-25 05:00:35.008767
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'test'
    field_attribute_base_0.default = 'test'
    field_attribute_base_0.validator = None
    field_attribute_base_0.type = None
    field_attribute_base_0.required = False
    field_attribute_base_0.isatype = None
    instance = FieldAttributeBase()
    ret = field_attribute_base_0.validate(instance)
    assert ret is None


# Generated at 2022-06-25 05:00:36.526364
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base()
    result = base_0.get_dep_chain()
    assert result == None


# Generated at 2022-06-25 05:00:41.630933
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # 1) Call case
    field_attribute_base_0 = FieldAttributeBase()
    # val = validator | 
    assert not field_attribute_base_0.validate()
    assert field_attribute_base_0.default is None
    assert field_attribute_base_0.required is True


# Generated at 2022-06-25 05:00:45.392499
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.setup_defaults(
        'foo',
        required=False,
        validate=True,
        static=False,
        serialize=True,
        always_post_validate=False
    )
    field_attribute_base_0.copy()


# Generated at 2022-06-25 05:00:51.130726
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    def mock_get_dep_chain_1():
        def test():
            return None
        return test

    def mock_get_dep_chain_2():
        def test():
            return UNDEFINED
        return test

    def mock_get_dep_chain_3():
        def test():
            return None
        return test

    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_2 = FieldAttributeBase()

    Base.get_dep_chain = mock_get_dep_chain_1()
    class Base_0(Base):
        pass

    Base.get_dep_chain = mock_get_dep_chain_2()
    class Base_1(Base):
        pass

    Base.get_dep_chain = mock_get

# Generated at 2022-06-25 05:01:23.036466
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_obj = FieldAttributeBase()
    base_obj._ds = dict()
    base_obj._ds['somekey'] = "somevalue"
    base_obj.somekey = "somevalue"
    base_obj2 = FieldAttributeBase()
    base_obj2._ds = dict()
    base_obj2._ds['somekey'] = "somevalue"
    base_obj2.somekey = "somevalue"
    # TODO: add unit test for FieldAttributeBase.dump_attrs()
    #assert base_obj.dump_attrs() == base_obj2.dump_attrs()


# Generated at 2022-06-25 05:01:28.204133
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Create an instance of class Base
    base_0 =  Base()

    # Call method get_dep_chain with parameter base_0
    result = base_0.get_dep_chain()


# Generated at 2022-06-25 05:01:29.258161
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass


# Generated at 2022-06-25 05:01:36.388649
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """test_FieldAttributeBase_post_validate"""
    field_attribute_base_0 = FieldAttributeBase()
    templar_0 = Templar(loader=None, variables={'omit': None})
    field_attribute_base_0.post_validate(templar=templar_0)


# Generated at 2022-06-25 05:01:44.386071
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    class_DTT_0 = class_DTT()
    var_args_0 = {'foo': 'bar'}
    var_bool_0 = False
    var_fail_on_undefined_errors_0 = False
    var_fail_on_unsafe_templates_0 = False
    var_list_0 = [1, 2, 3]
    var_list_1 = []
    var_dict_0 = {'foo': 'bar'}
    var_filter_loader_0 = 'filter_loader'
    var_vault_password_0 = 'vault_password'
    var_tags_0 = ['foo', 'bar']
    var_str_0 = 'foo'
    var_str_1 = 'bar'
    var_templ

# Generated at 2022-06-25 05:01:48.059335
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_copy = field_attribute_base_0.copy()


# Generated at 2022-06-25 05:01:55.341072
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test with search path in role
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.__class__ = Role
    role_0 = Role()
    role_0.__class__ = Role
    role_0.set__playbook(playbook1)
    field_attribute_base_0.set__playbook(playbook1)
    field_attribute_base_0.set__parent(role_0)
    playbook1.set__roles([role_0])
    assert field_attribute_base_0.get_dep_chain() == []



# Generated at 2022-06-25 05:02:00.798461
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = 'name'
    field_attribute_base_0._valid_attrs = {'name':field_attribute_base_0.FieldAttribute(isa='string')}
    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 05:02:09.996727
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Create a test FieldAttributeBase object
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.required = True
    field_attribute_base_0.private = True
    field_attribute_base_0.always_post_validate = True
    field_attribute_base_0.static = True
    field_attribute_base_0.default = 'test'
    field_attribute_base_0.description = 'description'
    field_attribute_base_0.version_added = 'version_added'

    # Make a copy of the original and modify it
    field_attribute_base_1 = copy.deepcopy(field_attribute_base_0)
    field_attribute_base_0.required = False

    # Dump the original and check the result
    field_attribute_base_0_dump

# Generated at 2022-06-25 05:02:13.452648
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base_1 = FieldAttributeBase()
    attrs = {"instance instance":"A", "key":"value", "value":"key"}
    field_attribute_base_1.from_attrs(attrs)
    assert field_attribute_base_1.instance == "A"
    assert field_attribute_base_1.key == "value"
    assert field_attribute_base_1.value == "key"


# Generated at 2022-06-25 05:02:42.456255
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    ansible_dict = dict(name = 'test_name', isa = 'test_isa', required = 'test_required')
    actual = field_attribute_base_0.dump_me(ansible_dict)
    assert actual == ansible_dict

# Generated at 2022-06-25 05:02:48.350916
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1_dict = field_attribute_base_1.dump_attrs()
    assert field_attribute_base_1_dict is not None


# Generated at 2022-06-25 05:02:54.415169
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test if function raises TypeError when arguments are of wrong type
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.name = str
    field_attribute_base_0.isa = str
    field_attribute_base_0.default = str
    field_attribute_base_0.static = int
    field_attribute_base_0.required = int
    field_attribute_base_0.always_post_validate = int
    field_attribute_base_0.no_log = bool
    field_attribute_base_0.listof = str
    field_attribute_base_0.class_type = str

    try:
        field_attribute_base_0.post_validate()
    except TypeError:
        pass