

# Generated at 2022-06-25 04:54:00.098227
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    input_0 = dict()
    expected_0 = dict()
    actual_0 = FieldAttributeBase.deserialize(FieldAttributeBase(), input_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 04:54:02.158693
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # FIXME: Write unit test
    pass


# Generated at 2022-06-25 04:54:09.220420
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    class_dict = dict()
    data = dict()
    data['name'] = 'FieldAttributeBase'
    data['type'] = 'FieldAttributeBase'
    data['isa'] = 'str'
    data['default'] = 'FieldAttributeBase'
    data['required'] = False
    data['private'] = False
    data['class_name'] = 'FieldAttributeBase'
    data['aliases'] = []
    data['static'] = False
    data['attribute'] = AttributeError
    data['path'] = 'ansible.utils.field_attribute.FieldAttributeBase'
    data['class_path'] = 'ansible.utils.field_attribute.FieldAttributeBase'
    data['always_post_validate'] = False
    data['class_type'] = 'FieldAttributeBase'

# Generated at 2022-06-25 04:54:14.045114
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    try:
        fa = FieldAttributeBase()
        fa.post_validate(None, None)
        print('Unit test for method post_validate of class FieldAttributeBase: PASS')
    except Exception as e:
        print('Unit test for method post_validate of class FieldAttributeBase: FAIL')


# Generated at 2022-06-25 04:54:23.975099
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class Base(object):
        _valid_attrs = dict(attr=FieldAttribute(isa='bool', default=True))

    base_0 = Base()
    attr_0 = base_0._valid_attrs["attr"]
    value_0 = False
    templar_0 = None
    try:
        actual_0 = base_0.get_validated_value("attr", attr_0, value_0, templar_0)
    except Exception as exc_0:
        print(exc_0)

    # value = 'False'

# Generated at 2022-06-25 04:54:26.278369
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    t = Base()
    n = t.get_search_path()
    print (str(n))

if __name__ == '__main__':
    test_Base_get_search_path()

# Generated at 2022-06-25 04:54:28.393862
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # pass
    base_0 = Base()
    base_1 = Base()
    attr_0 = FieldAttributeBase(base_0, base_1)
    attr_0.post_validate()


# Generated at 2022-06-25 04:54:35.392574
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_0 = Base()
    base_0.set_search_path([])
    var_0 = base_0.get_search_path()
    var_1 = base_0._get_action_value("test_case_0")
    var_2 = base_0.get_search_path()



# Generated at 2022-06-25 04:54:38.236661
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Create status object
    base_0 = Base()
    assert base_0 is not None

    # Get the dep chain
    chain = base_0.get_dep_chain()
    assert chain is None


# Generated at 2022-06-25 04:54:47.044577
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    base_0 = Base()
    _process_parents = BaseMeta.__dict__['_process_parents']
    _create_attrs = BaseMeta.__dict__['_create_attrs']
    # TODO: add test cases
    try:
        _process_parents((base_0,), base_0.__dict__)
        _create_attrs(base_0.__dict__, base_0.__dict__)
        # test code
        assert True
    except:
        assert False

    try:
        a = 1
        assert True
    except:
        assert False

    try:
        a = 1
        assert True
    except:
        assert False


# Generated at 2022-06-25 04:55:12.198266
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_0 = Base()
    var_0 = base_0.get_ds()

# Generated at 2022-06-25 04:55:18.635153
# Unit test for method get_path of class Base
def test_Base_get_path():
    # check if the method returns the expected value
    temp = Base()
    temp._ds = fake_ds()
    assert temp.get_path() == 'fake_data_source:1'

# Unit tests for method get_search_path of class Base

# Generated at 2022-06-25 04:55:19.475861
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FieldAttributeBase()
    attr.post_validate(None)

# Generated at 2022-06-25 04:55:21.477753
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    base_0 = FieldAttributeBase()
    var_0 = base_0.squash(None)
    assert var_0 is None


# Generated at 2022-06-25 04:55:23.110892
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Instantiate test object
    child = FieldAttributeBase()

    # Call method
    child.dump_me()


# Generated at 2022-06-25 04:55:32.157815
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase(isa='string')
    test_real_obj = 'test'
    ret = f.post_validate(test_real_obj)
    assert ret == 'test'

    f = FieldAttributeBase(isa='string', listof='first', required=True)
    test_real_obj = ['test', 'test1', 'test2']
    try:
        ret = f.post_validate(test_real_obj)
        assert False
    except AnsibleParserError as e:
        assert 'field \'items\' is required' in e.message

    f = FieldAttributeBase(isa='string', listof='first', required=False)
    test_real_obj = ['test', 'test1', 'test2']
    ret = f.post_validate(test_real_obj)

# Generated at 2022-06-25 04:55:39.127736
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test_ds = dict()

    test_fieldattributebase = FieldAttributeBase()

    test_attrs = test_ds

    test_fieldattributebase.from_attrs(attrs=test_attrs)

    assert test_fieldattributebase.dump_attrs() == dict()


# Generated at 2022-06-25 04:55:41.191015
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()

    # Case 0
    attr_0 = base_0.dump_attrs()

    assert len(attr_0) == 9


# Generated at 2022-06-25 04:55:44.575262
# Unit test for method get_path of class Base
def test_Base_get_path():
    set_debugging(True)
    base_0 = Base()
    base_1 = Base()
    path_0 = base_0.get_path()
    path_1 = base_1.get_path()
    assert path_0 == ':0'
    assert path_1 == ''

# Generated at 2022-06-25 04:55:52.633082
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fld_0 = FieldAttributeBase()
    fld_1 = FieldAttributeBase()
    base_0 = fld_1.dump_me(base_0=base_0, attr='attr', value='value')
    # Invalid usage: wrong argument type for attribute value of FieldAttributeBase.dump_me
    base_0 = fld_1.dump_me(base_0='base_0', attr=fld_0, value='value')
    # Invalid usage: wrong argument type for attribute attr of FieldAttributeBase.dump_me
    base_0 = fld_1.dump_me(base_0=base_0, attr=True, value='value')
    # Invalid usage: wrong argument type for attribute value of FieldAttributeBase.dump_me

# Generated at 2022-06-25 04:56:21.616535
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FA = FieldAttributeBase('fake', isa='fake')
    faketemplar = 'faketemplar'
    name = 'name'
    attribute = FA
    value = 'value'
    FA.get_validated_value('name', FA, 'value', faketemplar)


# Generated at 2022-06-25 04:56:28.375822
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    fa = FieldAttributeBase(False, True)
    fa.post_validate(play_context)

if __name__ == "__main__":
    with mock.patch('os.path.exists') as mock_path:
        test_case_0()
    test_FieldAttributeBase_post_validate()

# Generated at 2022-06-25 04:56:32.263777
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_1 = Base()
    var_1 = FieldAttributeBase.load_data(base_1,'.\data', 'yml')
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 04:56:38.120005
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Instantiate the base object
    with pytest.raises(AnsibleParserError) as excinfo:
        base_1 = Base()
    # Test the method post_validate
    with pytest.raises(AnsibleParserError) as excinfo:
        base_1.post_validate()


# Generated at 2022-06-25 04:56:47.327459
# Unit test for method copy of class FieldAttributeBase

# Generated at 2022-06-25 04:56:57.290879
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test using a class that has no subclass of FieldAttributeBase
    class TestFieldAttributeBase(object):
        def __init__(self):
            self._finalized = False
        def get_search_path(self):
            assert not self._finalized, "Object not finalized"
        def post_validate(self, templar):
            assert not self._finalized, "Object not finalized"
            self._finalized = True
        def is_template(self, value_data):
            assert not self._finalized, "Object not finalized"
            return False
    templar = TestFieldAttributeBase()
    test_value = '123'
    test_name = 'name'
    test_attribute = FieldAttributeBase(isa='string')
    test_object = TestFieldAttributeBase()
    result = test_object.get_validated

# Generated at 2022-06-25 04:57:08.087823
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
   # Test case 1: Check if dep_chain returned by method get_dep_chain is a list.
   # Base class has no parent so this test case should call get_dep_chain of class Base.
   base_1 = Base()
   dep_chain_1 = base_1.get_dep_chain()
   assert isinstance(dep_chain_1, list)

   # Test case 2: Check if dep_chain returned by method get_dep_chain is a list.
   # Base class has a parent so this test case should call get_dep_chain of class Play.
   from ansible.playbook.play import Play
   play_2 = Play()
   base_2 = Base(parent=play_2)
   dep_chain_2 = base_2.get_dep_chain()
   assert isinstance(dep_chain_2, list)

# Generated at 2022-06-25 04:57:13.482821
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    real_path = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(real_path,"../../../../lib/ansible/playbook/base.py")

# Generated at 2022-06-25 04:57:19.125600
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    test_field_attr_base = FieldAttributeBase()
    test_ds = {"test1": "test1_value"}
    test_field_attr_base.ds = test_ds
    assert test_field_attr_base.get_ds() == test_ds


# Generated at 2022-06-25 04:57:22.619539
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_1 = FieldAttributeBase()
    var_1 = base_1.load_data(None)


# Generated at 2022-06-25 04:57:52.627390
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    obj_0 = FieldAttributeBase()
    base_0 = Base()

    # Test attribute: _valid_attrs
    # set up the object to get the default value
    obj_0._valid_attrs = obj_0.get_valid_attrs()
    obj_0.from_attrs({'name': 'foo', 'something': 'nope'})

    # now test that the attribute was set properly
    assert obj_0.name == 'foo'


# Generated at 2022-06-25 04:57:55.194723
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Global test variables
    var_0 = []
    base_0 = Base()
    var_1 = base_0.get_search_path()

    # Check test case
    assert var_1 == var_0


# Generated at 2022-06-25 04:57:56.525935
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta_0 = BaseMeta(name='async_wrapper', parents=(), dct={})


# Generated at 2022-06-25 04:58:02.254815
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class TestClass(Base):
        _valid_attrs = dict(
            foo=FieldAttribute(isa='string'),
            bar=FieldAttribute(isa='list', default=list)
        )

    test_obj = TestClass()
    test_data = dict(
        foo='hello',
        bar=['world']
    )

    test_obj.from_attrs(test_data)

    assert getattr(test_obj, 'foo') == 'hello'
    assert getattr(test_obj, 'bar') == ['world']
    assert test_obj._squashed is False
    assert test_obj._finalized is False


# Generated at 2022-06-25 04:58:04.557659
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta_obj_0 = BaseMeta()


# Generated at 2022-06-25 04:58:05.449995
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    print("Test method get_dep_chain of class Base")


# Generated at 2022-06-25 04:58:08.456668
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attribute = FieldAttributeBase(primary=True, required=True, private=False)
    test_obj_0 = Base()
    test_obj_0.post_validate(attribute)


# Generated at 2022-06-25 04:58:20.684616
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # Init test object
    fieldattributebase_0 = FieldAttributeBase(default=None)

    # Test with default value
    assert fieldattributebase_0._get_value(ds=None) == None

    # Test with given value
    assert fieldattributebase_0._get_value(ds=True) == True

    # Test with given invalid type value
    try:
        res = fieldattributebase_0._get_value(ds=0)
        assert False, 'An error should have occured since type is wrong'
    except TypeError as e:
        assert True

    # Test with None given
    assert fieldattributebase_0._get_value(ds=None) == None

    # Test with given value
    assert fieldattributebase_0._get_value(ds=False) == False

    # Test with given invalid type value

# Generated at 2022-06-25 04:58:26.233931
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_1 = Base()

# Generated at 2022-06-25 04:58:31.935251
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class MyFieldAttribute(FieldAttributeBase):
        _isa = integer = string = boolean = dict = None

    FieldAttributeBase.register_attribute(MyFieldAttribute)

    try:
        MyFieldAttribute.validate(None)
    except TypeError as e:
        print(e)
        print('Test successful')
    except:
        print('Unexpected exception')

test_case_0()
test_FieldAttributeBase_validate()

# Generated at 2022-06-25 04:59:23.402032
# Unit test for method get_path of class Base
def test_Base_get_path():

    # Test an object of class Base
    base_0 = Base()
    s = base_0.get_path()
    assert (s == ":0")

    # Test an object of class Role
    role_0 = Role()
    s = role_0.get_path()
    assert (s == ":0")

    # Test an object of class Play
    play_0 = Play()
    s = play_0.get_path()
    assert (s == ":0")


# Generated at 2022-06-25 04:59:29.293646
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader, module_loader

    class Task(Base):

        _optional_attrs = frozenset()
        _deprecated_attrs = frozenset()
        _exclude_attrs = frozenset()

        def _validate_become_user(self, attr, value):
            return self.get_validated_become_user(value)

        def _validate_connection(self, attr, value):
            return self.get_validated_connection(value, supported_connections=connection_loader.all())

        def get_ds(self):
            return 'file/1.yaml'

        def _validate_module_defaults(self, attr, value):
            return

# Generated at 2022-06-25 04:59:37.988031
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    base_1 =  Base()
    base_2 = Base()
    base_3 = Base()

    # check that the field attrs are alive and well
    base_1.post_validate(templar=None)
    base_2.post_validate(templar=None)
    base_3.post_validate(templar=None)

    # check that the field attrs are alive and well
    base_1.post_validate(templar=None)
    base_2.post_validate(templar=None)
    base_3.post_validate(templar=None)


# Generated at 2022-06-25 04:59:44.493213
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base_0 = Base()
    var_0 = base_0.get_search_path()
    assert var_0 == []

    base_1 = Base()
    var_1 = base_1.get_search_path()
    assert var_1 == []

    base_2 = Base()
    var_2 = base_2.get_search_path()
    assert var_2 == []

    base_3 = Base()
    var_3 = base_3.get_search_path()
    assert var_3 == []

    base_4 = Base()
    var_4 = base_4.get_search_path()
    assert var_4 == []

    base_5 = Base()
    var_5 = base_5.get_search_path()
    assert var_5 == []

    base_6 = Base()

# Generated at 2022-06-25 04:59:48.758086
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    f_a_0 = FieldAttributeBase(default=1)
    try:
        f_a_0.deserialize('string')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:59:59.269119
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_1 = Base()
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    buf = StringIO()
    if sys.version_info[0] == 2:
        import __builtin__
        original_open = __builtin__.open
        try:
            __builtin__.open = lambda path, mode: buf
            base_1.post_validate(templar=None)
        finally:
            __builtin__.open = original_open
    else:
        original_open = builtins.open
        try:
            builtins.open = lambda path, mode: buf
            base_1.post_validate(templar=None)
        finally:
            builtins.open = original_open


# Generated at 2022-06-25 05:00:06.131598
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import inspect

    frame = inspect.stack()[0]
    module = inspect.getmodule(frame[0])
    module_name = module.__name__
    class_name = 'Base'
    method_name = inspect.currentframe().f_code.co_name
    print('{}.{}.{}'.format(module_name, class_name, method_name))

    # print(dir(Base))
    print('Base.__dict__: {}'.format(Base.__dict__))
    my_base_0 = Base()
    print('{}.{}'.format(class_name, dir(my_base_0)))
    my_base_0.__dict__ = {'_parent': None}

    assert my_base_0.__dict__ == {'_parent': None}


# Generated at 2022-06-25 05:00:15.111639
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_0 = Base()
    attr_0 = dict()
    attr_0['isa'] = 'int'
    attr_0['required'] = True
    attr_0['static'] = True
    templar_0 = AnsibleTemplar()

    try:
        ans_0 = base_0.get_validated_value(name_0, attr_0, value_0, templar_0)
        if ans_0 != 1:
            raise ValueError()
    except ValueError:
        pass


# Generated at 2022-06-25 05:00:17.593707
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base_0 = Base()
    vars_0 = base_0.dump_attrs()
    assert 'name' in vars_0


# Generated at 2022-06-25 05:00:27.933123
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-25 05:01:24.755115
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_0 = Base()
    field_object = FieldAttributeBase('test data')
    base_0.load_data(field_object)


# Generated at 2022-06-25 05:01:27.529395
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    attr2 = FieldAttributeBase()
    attr1 = FieldAttributeBase()

    attr_copy = attr1.copy()
    assert( attr1 != attr2 )
    assert( attr1 == attr_copy )


# Generated at 2022-06-25 05:01:38.828535
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Initializations
    field_0 = 'Z'
    base_0 = Base()
    field_1 = 'Z'
    base_1 = Base()
    field_2 = 'Z'
    base_2 = Base()
    field_3 = 'Z'
    base_3 = Base()
    field_4 = 'Z'
    base_4 = Base()

    # Call method
    try:
        FieldAttribute(field=field_0, validate=None, always_post_validate=True, static=True,
                       fallback=('a',), class_type=dict, isa=dict, listof=dict, required=True,
                       default=None, choices=('a',), inherit=True).\
            validate()
    except TypeError:
        pass

# Generated at 2022-06-25 05:01:42.149465
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base_1 = Base()
    name_1 = 'test_name'
    isa_1 = 'test_isa'
    default_1 = 'test_default'
    cls_1 = 'test_cls'
    # TODO: implement this test



# Generated at 2022-06-25 05:01:52.436742
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-25 05:01:54.343277
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field = FieldAttributeBase('test_field')
    field_copy = field.copy()
    assert (field.attribute_class == field_copy.attribute_class)


# Generated at 2022-06-25 05:02:04.308798
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    role_name = 'test-role'
    play_context = PlayContext()

# Generated at 2022-06-25 05:02:10.297182
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fa = FieldAttributeBase()
    fa.required = False
    fa.static = True
    fa.default = 'default'
    fa.always_post_validate = True
    fa.isa = 'string'
    fa.name = 'name'
    fa.aliases = ['alias1']

    exp = {'required': False, 'static': True, 'default': 'default', 'always_post_validate': True,
           'isa': 'string', 'name': 'name', 'aliases': ['alias1']}

    assert exp == fa.dump_me()


# Generated at 2022-06-25 05:02:20.742935
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    # Set up mock object for FieldAttributeBase class
    mock_ds = Mock(name='mock_ds')
    mock_ds.name = "test_name"
    mock_ds.display_name = "test_display_name"
    mock_ds.default = "test_default"
    mock_ds.private = "test_private"
    mock_ds.required = "test_required"
    mock_ds.choices = "test_choices"
    mock_ds.aliases = "test_aliases"
    mock_ds.always_post_validate = "test_always_post_validate"
    mock_ds.class_type = "test_class_type"
    mock_ds.vars_parameter = "test_vars_parameter"

# Generated at 2022-06-25 05:02:28.369020
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Create a Base object
    base_0 = Base()

    # Call the get_path method of class Base 
    var_0 = base_0.get_path()
    # Assertions
    assert var_0 == ""

    # Create a Base object
    base_1 = Base()
    # Call the get_path method of class Base 
    var_1 = base_1.get_path()
    # Assertions
    assert var_1 == ""
