

# Generated at 2022-06-25 04:53:48.047276
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    test_value_0 = field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')
    assert test_value_0 == 'value'
    test_value_1 = field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')
    assert test_value_1 == 'value'
    test_value_2 = field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')
    assert test_value_2 == 'value'
    test_value_3 = field_attribute_base_0.get_validated_value('name', 'attribute', 'value', 'templar')
    assert test_value

# Generated at 2022-06-25 04:53:54.484372
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_0._copy_attr_defs(None, field_attribute_base_1)


# Generated at 2022-06-25 04:54:02.916514
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # NOTE: The code below will be used to test the method
    #       load_data of class
    #       FieldAttributeBase.
    # The test case setup starts here
    field_attribute_base_0 = FieldAttributeBase()
    # The definition of 'data' starts here
    data = {}
    # The definition of 'parent_ds' starts here
    parent_ds = {}
    # The definition of 'validate' starts here
    validate = True
    # The definition of 'follow_imports' starts here
    follow_imports = True
    # The definition of 'self_ds' starts here
    self_ds = {}
    # The definition of 'var_manager' starts here
    var_manager = {}
    # The definition of 'loader' starts here
    loader = {}
    # The definition of 'templar' starts here


# Generated at 2022-06-25 04:54:07.296921
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    f = FieldAttributeBase()
    assert(f.deserialize({'key': 'value'}) is None)


# Generated at 2022-06-25 04:54:18.688112
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.play import Play
    field_attribute_base_0 = FieldAttributeBase()
    play_0 = Play()
    play_0.post_validate(object())
    # Verify method dumps all attributes to a dictionary, by checking returned value
    assert field_attribute_base_0.dump_attrs() == play_0.dump_attrs()
    # Verify that the dict returned by dump_attrs() is a shallowcopy of internal dict
    play_1 = Play()
    play_1.post_validate(object())
    field_attribute_base_1_attrs = field_attribute_base_0.dump_attrs()
    field_attribute_base_1_attrs["vars"] = "updated"
    assert field_attribute_base_0._attributes["vars"] != field_attribute_base

# Generated at 2022-06-25 04:54:22.503308
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_copy_0 = field_attribute_base_0.copy()
    # Currently no assertions for this method

test_case_0()
test_FieldAttributeBase_copy()

# Generated at 2022-06-25 04:54:29.952750
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # The class to test
    class_to_test = FieldAttributeBase()

    # Assert if key already exists
    # setup params from var, or use defaults
    param_deserialize_data = {}

    try:
        class_to_test.deserialize(param_deserialize_data)
    except AnsibleAssertionError as e:
        assert "data ([{}]) should be a dict but is a " in to_native(e.args)


# Generated at 2022-06-25 04:54:35.719515
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase(isa='string')
    field_attribute_base_1 = FieldAttributeBase(isa='string')
    field_attribute_base_2 = FieldAttributeBase(isa='string')
    field_attribute_base_3 = FieldAttributeBase(isa='string')
    field_attribute_base_4 = FieldAttributeBase(isa='string')
    field_attribute_base_5 = FieldAttributeBase(isa='string')
    field_attribute_base_6 = FieldAttributeBase(isa='string')
    field_attribute_base_7 = FieldAttributeBase(isa='string')
    field_attribute_base_8 = FieldAttributeBase(isa='string')
    field_attribute_base_9 = FieldAttributeBase(isa='string')
    field_attribute_base_10 = FieldAttributeBase(isa='string')
   

# Generated at 2022-06-25 04:54:42.249880
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test class with FieldAttributeBase
    class TestAnsibleBase(FieldAttributeBase):
        def __init__(self):
            self._attrs = None
            self._finalized = False
            self._squashed = False

    field_attribute_base_0 = TestAnsibleBase()
    field_attribute_base_0.post_validate()


# Generated at 2022-06-25 04:54:45.941325
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.post_validate()


# Generated at 2022-06-25 04:55:21.047467
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 04:55:22.750569
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_1 = FieldAttributeBase()
    pattern = None

    field_attribute_base_1.validate(pattern)


# Generated at 2022-06-25 04:55:32.083960
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Initial test setup
    mainglobals = dict()
    mainglobals['__name__'] = '__main__'
    fake_loader = DictDataLoader({
        'bogus.py': "#!/usr/bin/python\n"
    })
    fake_inventory = InventoryManager(loader=fake_loader, sources=None, vault_password=None)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    from collections import namedtuple

# Generated at 2022-06-25 04:55:39.958565
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # Test without argument
    with pytest.raises(TypeError):
        FieldAttributeBase.validate()

    # Test with a good attribute
    bad_attr = FieldAttributeBase(name='toto', isa='string')
    good_attr = FieldAttributeBase(name='titi', isa='string')
    assert bad_attr.validate(good_attr) is True


# Generated at 2022-06-25 04:55:41.213057
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    base_meta_0 = BaseMeta


# Generated at 2022-06-25 04:55:45.057576
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base_0 = FieldAttributeBase()
    try:
        field_attribute_base_0.deserialize(1)
        # Should raise an exception
        assert False
    except AnsibleAssertionError as e:
        assert e.args[0] == "data (1) should be a dict but is a <type 'int'>"


# Generated at 2022-06-25 04:55:50.899815
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Test normal behaviour
    a = FieldAttributeBase()
    attrs = {'foo': 'bar'}
    a.from_attrs(attrs)

    # Test with empty attrs
    a = FieldAttributeBase()
    a.from_attrs({})

    # Test with invalid attrs
    a = FieldAttributeBase()
    attrs = 'invalid'
    with pytest.raises(AssertionError):
        a.from_attrs(attrs)


# Generated at 2022-06-25 04:55:54.860021
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    token_obj_0 = FieldAttributeBase()
    assert token_obj_0.validate() == False

#unit test for method _validate_attribute_names

# Generated at 2022-06-25 04:56:00.380606
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase(name = 'name')
    try:
        field_attribute_base_0.validate(name = 'name')
    except Exception as e:
        print("Exception in testcode while validating the field 'name', exception: %s"
              % (str(e),))



# Generated at 2022-06-25 04:56:06.214057
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # test case 0
    field_attribute_base_0 = FieldAttributeBase()
    name_0 = "name"
    attribute_0 = FieldAttribute(isa="string")
    value_0 = ""
    templar_0 = Templar()

    field_attribute_base_0.get_validated_value(name_0,
                                               attribute_0,
                                               value_0,
                                               templar_0)

    # test case 1
    field_attribute_base_1 = FieldAttributeBase()
    name_1 = "name"
    attribute_1 = FieldAttribute(isa="int")
    value_1 = ""
    templar_1 = Templar()


# Generated at 2022-06-25 04:56:50.068173
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_2 = FieldAttributeBase()
    field_attribute_base_3 = FieldAttributeBase()
    field_attribute_base_4 = FieldAttributeBase()
    field_attribute_base_5 = FieldAttributeBase()
    field_attribute_base_6 = FieldAttributeBase()
    field_attribute_base_7 = FieldAttributeBase()
    field_attribute_base_8 = FieldAttributeBase()
    field_attribute_base_9 = FieldAttributeBase()
    field_attribute_base_10 = FieldAttributeBase()
    field_attribute_base_11 = FieldAttributeBase()
    field_attribute_base_12 = FieldAttributeBase()
    field_attribute_base_13 = FieldAttributeBase()
    field_

# Generated at 2022-06-25 04:56:55.489121
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1.get_validated_value(name='name', attribute=FieldAttributeBase(), value=None, templar=None) == None
    assert field_attribute_base_1.get_validated_value(name='name', attribute=FieldAttributeBase(), value=True, templar=None) == True
    assert field_attribute_base_1.get_validated_value(name='name', attribute=FieldAttributeBase(), value=False, templar=None) == False
    assert field_attribute_base_1.get_validated_value(name='name', attribute=FieldAttributeBase(), value=0, templar=None) == 0

# Generated at 2022-06-25 04:57:00.940610
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    str_0 = "str"
    # it is not possible to write a good unit test for this method, since the method
    # has no return, and raises exceptions. So we will only check if the method
    # can be called without throwing exception
    field_attribute_base_0.validate(str_0, "int")


# Generated at 2022-06-25 04:57:04.579070
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    name = "foo"
    attribute = FieldAttribute()
    value = 1
    templar = templar.Templar(loader=loader.DataLoader())
    result = field_attribute_base_0.get_validated_value(name, attribute, value, templar)
    assert result == "foo"


# Generated at 2022-06-25 04:57:09.109872
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base_1 = FieldAttributeBase()
    assert field_attribute_base_1.get_ds()==None


# Generated at 2022-06-25 04:57:11.928370
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_0 = FieldAttributeBase()
    assert field_attribute_base_0.get_validated_value(name=None, attribute=None, value=None, templar=None)


# Generated at 2022-06-25 04:57:17.731335
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # initialize base class
    field_attribute_base_1 = FieldAttributeBase()
    field_attribute_base_1._post_validate_test_attr = test_attr
    field_attribute_base_1.test_attr = 'test attr'

    # initialize class
    test_object_1 = TestObject()

    FieldAttributeBase._post_validate(test_object_1,Mock())

    # check if deserialize raises a AnsibleAssertionError
    try:
        FieldAttributeBase._post_validate(field_attribute_base_1, Mock())
        raise Exception("Failed to raise AnsibleAssertionError")
    except AnsibleAssertionError:
        pass
    # check if post_validate_test_attr is called with required parameters
    test_post_validate_test_attr_args_

# Generated at 2022-06-25 04:57:23.745759
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base_0 = FieldAttributeBase()
    ansible_module_0 = AnsibleModule(argument_spec={}, supports_check_mode=False)
    dest_0 = dumps(field_attribute_base_0, ansible_module_0)
    assert True

# Generated at 2022-06-25 04:57:30.850125
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    class Mock_ds(object):
        def __init__(self, *args, **kwargs):
            self.vars = {'omit': 'value'}
        def __getitem__(self, *args, **kwargs):
            return self.vars.__getitem__(*args, **kwargs)
    class Mock_templar(object):
        def __init__(self, *args, **kwargs):
            self.vars = {}
            self.available_variables = {}
            self.fail_on_undefined_errors = False
        def is_template(self, *args, **kwargs):
            return False
        def template(self, *args, **kwargs):
            return 'templated'

# Generated at 2022-06-25 04:57:34.852158
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0.copy('copy_test')


# Generated at 2022-06-25 04:57:59.529338
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    m = BaseMeta('t1', (object,), {'k1': FieldAttributeBase()})
    print(m.__dict__)
    assert 'k1' in m.__dict__
    assert 't1' in str(m)
    assert 'k1' in str(m)
    assert 't1' in repr(m)
    assert 'k1' in repr(m)




# Generated at 2022-06-25 04:58:06.544913
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base_0 = FieldAttributeBase()
    test_attribute = FieldAttribute()
    try:
        test_attribute.validate(field_attribute_base_0)
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-25 04:58:07.747691
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    print("Test get_dep_chain of class Base")


# Generated at 2022-06-25 04:58:08.708238
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass


# Generated at 2022-06-25 04:58:16.348965
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Setup
    field_attribute_base = FieldAttributeBase()
    datum = object()
    object_name = 'object_name'

    # Invoke method
    res = field_attribute_base.validate(datum, object_name)

    # Verify
    assert res is None


# Generated at 2022-06-25 04:58:21.680410
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0 = FieldAttributeBase()
    field_attribute_base_0 = FieldAttributeBase()


# Generated at 2022-06-25 04:58:24.362385
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()
    if field_attribute_base_0.post_validate():
        raise AssertionError('Unreachable code')


# Generated at 2022-06-25 04:58:28.103364
# Unit test for method get_path of class Base
def test_Base_get_path():
    field_attribute_base_0 = FieldAttributeBase()
    base_0 = Base()
    assert base_0.get_path() == ""
    base_0.get_path()


# Generated at 2022-06-25 04:58:29.115031
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_0 = FieldAttributeBase()

# unit test for class

# Generated at 2022-06-25 04:58:37.082966
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Tests the case where the value is True
    # Tests the case where the value is False
    # Tests the case where the value is an str
    # Tests the case where the value is a list
    # Tests the case where the value is a dict
    # Tests the case where the value is None
    # Tests the case where the value is an int
    # Tests the case where the value is a float
    ensure_quick()


# Generated at 2022-06-25 04:59:05.528380
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    #
    # Test the get_dep_chain method of the Base class
    #
    class SubclassOfBase(Base):
        #
        # Test class to test method get_dep_chain of class Base
        #
        pass

    try:
        SubclassOfBase_instance = SubclassOfBase()
        SubclassOfBase_instance.get_dep_chain()
    except:
        print('Unexpected failure in Base.get_dep_chain.')
        raise


# Generated at 2022-06-25 04:59:13.429259
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    import types
    string_types = [types.UnicodeType, types.StringType]
    for cls in [FieldAttribute, FieldAttributeBase, Base]:
        for attr_type in [dict, list, bool, int, string_types, set]:
            cls(attr_type)
    try:
        cls(object)
        raise AssertionError("Unexpected success")
    except AssertionError:
        pass
    except:
        raise AssertionError("Unexpected failure")

# Generated at 2022-06-25 04:59:21.717439
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class MockBase(Base):
        def get_dep_chain(self):
            return None

    class MockDS:
        def __init__(self, data_source='/foo/bar/tasks', line_number=1):
            self._data_source = data_source
            self._line_number = line_number

    base_1 = MockBase()
    base_1._ds = MockDS()
    assert base_1.get_search_path() == ['/foo/bar']

    class MockBase2(Base):
        def get_dep_chain(self):
            return None

    class MockDS2:
        def __init__(self, data_source='/foo/bar/tasks', line_number=1):
            self._data_source = data_source
            self._line_number = line_number

   

# Generated at 2022-06-25 04:59:24.007007
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    test_case_0()


# Generated at 2022-06-25 04:59:30.373899
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test_case_1[1]: test load_data with a string type data
    # test_case_1[2]: value will be loaded from the data
    test_case_1 = [b'xyz', 'xyz']

    test_case_2 = [True, True]
    test_case_3 = [False, False]

    for test_case in [test_case_1, test_case_2, test_case_3]:
        base = Base()
        test = utils.random_string()
        attribute = base.add_field(test)
        base.load_from_datasource(test, test_case[1])

# Generated at 2022-06-25 04:59:32.217102
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_0 = Base()
    assert base_0.get_dep_chain() is None


# Generated at 2022-06-25 04:59:38.779223
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # FieldAttributeBase.validate() only calls its parent
    attribute = FieldAttributeBase()
    base = Base()
    some_value = "some_value"

    # Test - should validate any value
    assert attribute.validate(base, some_value) is True

    # Test - should validate any value
    assert attribute.validate(base, None) is True


# Generated at 2022-06-25 04:59:40.404152
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    attr_0 = FieldAttributeBase()
    attr_0.post_validate(base_0)


# Generated at 2022-06-25 04:59:42.589985
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    '''
    Make sure deserialize doesn't crash
    '''

    base_obj = Base()
    base_obj.deserialize({})


# Generated at 2022-06-25 04:59:48.417411
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attr = FieldAttributeBase('test_attr', 'string', {'required': True}, None)
    # test name
    assert attr.name == 'test_attr'

    # test isa
    assert attr.isa == 'string'
    attr.isa = 'int'
    assert attr.isa == 'int'

    # test doc
    assert attr.doc == None
    attr.doc = 'string'
    assert attr.doc == 'string'

    # test choices
    assert attr.choices == None
    attr.choices = [1, 2, 3]
    assert attr.choices == [1, 2, 3]

    # test private
    assert attr.private == False
    attr.private = True
    assert attr.private == True

    # test required

# Generated at 2022-06-25 05:00:21.153423
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    test_field_attribute_base_class = {
        'name': 'test_name',
        'class_type': Base,
        'takes_context': True,
        'default': False,
        'required': False,
        'static': False,
        'aliases': ['test_alias'],
        'private': True,
        'deprecated_aliases': ['test_deprecated_alias'],
        'always_post_validate': True,
        'listof': Base
    }
    test_field_attribute_base = FieldAttributeBase(**test_field_attribute_base_class)
    copied_field_attribute_base = test_field_attribute_base.copy()
    assert copied_field_attribute_base.get_attributes() == test_field_attribute_base.get_attributes()

#

# Generated at 2022-06-25 05:00:24.742044
# Unit test for method get_path of class Base
def test_Base_get_path():

    base_0 = Base()
    assert_equal(base_0.get_path(), '')


# case 1
test_case_0()
# case 2
test_Base_get_path()

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-25 05:00:35.781802
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():


    # test case with string value
    base_0 = Base()
    attr_0 = FieldAttributeBase()
    attr_0.isa = 'string'
    value = 'abc'
    expected_value = 'abc'
    new_value = base_0.get_validated_value('name', attr_0, value, 'templar')
    assert new_value == expected_value

    # test case with int value
    base_1 = Base()
    attr_1 = FieldAttributeBase()
    attr_1.isa = 'int'
    value = 1
    expected_value = 1
    new_value = base_1.get_validated_value('name', attr_1, value, 'templar')
    assert new_value == expected_value

    # test case with float value
    base

# Generated at 2022-06-25 05:00:44.157535
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class MyTask(Task):
        def __init__(self, task_name='test_task'):
            super(MyTask, self).__init__(task_name=task_name)
            self._valid_attrs['first_var'] = FieldAttribute(isa='string', required=True, static=True)
            self._valid_attrs['second_var'] = FieldAttribute(isa='string', static=True)
            self._valid_attrs['third_var'] = FieldAttribute(isa='list', static=True)

    t = MyTask('test_task')
    t.post_validate()
    return True


# Generated at 2022-06-25 05:00:54.803599
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class TestObj0(object):
        pass

    obj0 = TestObj0()
    obj0.foo = 'bar'

    # test_case 0
    attr0 = {
        'default' : '',
        'required' : True,
        'version_added' : '',
        'aliases' : [],
        'type' : 'str',
        'removed_in_version' : '',
        'always_post_validate' : False,
        'options' : [],
        'mutually_exclusive' : []
    }

    ds0 = {'bar': 'baz'}
    base_0 = Base()
    result = base_0._valid_attrs['connection'].load_data(attr0, obj0, ds0)

# Generated at 2022-06-25 05:00:57.169640
# Unit test for method get_path of class Base
def test_Base_get_path():
    base_1 = Base()
    base_1.get_path()


# Generated at 2022-06-25 05:00:58.740085
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base_0 = Base()
    assert base_0.get_search_path() is None


# Generated at 2022-06-25 05:00:59.751761
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    assert base.get_path() is ''


# Generated at 2022-06-25 05:01:09.126517
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    attrs = dict()

    # setup defaults
    for (name, attribute) in iteritems(Base._valid_attrs):
        if callable(attribute.default):
            attrs[name] = attribute.default()
        else:
            attrs[name] = attribute.default

    # generate random values for each attribute
    for (name, attribute) in iteritems(Base._valid_attrs):
        if attribute.isa == 'bool':
            attrs[name] = random.choice([True, False])
        elif attribute.isa == 'int':
            attrs[name] = random.randrange(0, 100000)
        elif attribute.isa == 'float':
            attrs[name] = random.randrange(0.0, 100000)
        elif attribute.isa == 'string':
            attrs[name]

# Generated at 2022-06-25 05:01:12.557113
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    attribute = FieldAttributeBase()
    attribute_copy = attribute.copy()
    assert attribute_copy is not attribute
    assert attribute_copy.__dict__ == attribute.__dict__
    return


# Generated at 2022-06-25 05:01:34.784921
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test case 0
    base_0 = Base()


# Generated at 2022-06-25 05:01:35.786889
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_case_0()


# Generated at 2022-06-25 05:01:37.626812
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    fa = FieldAttributeBase()
    assert fa is not fa.copy()


# Generated at 2022-06-25 05:01:48.103627
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field = FieldAttribute()
    base_0 = Base(vars={"var": {"foo": "bar"}, "var2": "{{ var }}"})


# Generated at 2022-06-25 05:01:53.103592
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base_1 = Base()
    field_attribute = FieldAttributeBase(default=base_1)

    # test of method copy
    result = field_attribute.copy()
    assert result is not field_attribute  # should be a new object
    assert result.default is base_1  # should point to the same object


# Generated at 2022-06-25 05:01:54.531607
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_0 = Base()
    base_0._post_validate_vars()


# Generated at 2022-06-25 05:02:04.344813
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    base = FieldAttributeBase()
    assert isinstance(base, Base)

    value = 'string'
    assert isinstance(value, string_types)
    base.isa = 'int'
    output = base.get_validated_value('name', base, value, None)
    assert output == 0

    base.isa = 'bool'
    output = base.get_validated_value('name', base, value, None)
    assert output == False

    base.isa = 'list'
    output = base.get_validated_value('name', base, value, None)
    assert output == [value]

    base.isa = 'set'
    output = base.get_validated_value('name', base, value, None)
    assert output == {value}


# Generated at 2022-06-25 05:02:13.194756
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    dummy_parent = MagicMock()
    dummy_parent.get_loader = MagicMock(return_value=MagicMock())
    dummy_parent.get_loader().get_basedir = MagicMock(return_value='some_basedir')
    dummy_parent.get_loader().path_dwim = MagicMock(side_effect=lambda x: 'some_basedir/%s' % x)

    ds = dict(result_dump=dict(dump_me=True, dump_uuid=True))
    attr = FieldAttributeBase(ds, name='dummy_attr')
    result = attr.dump_me(dummy_parent, 'some_value')


# Generated at 2022-06-25 05:02:17.660429
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    class FA(FieldAttributeBase):
        def __init__(self):
            self.static = False
            self.required = False
    f = FA()
    f.isa = 'int'
    f.default = 5
    f.choices = [1, 2, 3]
    assert f.dump_attrs() == {'static': False, 'required': False, 'isa': 'int', 'default': 5, 'choices': [1, 2, 3]}
    f.isa = 'bool'
    f.default = False
    assert f.dump_attrs() == {'static': False, 'required': False, 'isa': 'bool', 'default': False, 'choices': [1, 2, 3]}


# Generated at 2022-06-25 05:02:21.126887
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field = FieldAttributeBase()
    field.isa = "string"
    field.name = "test_string"

    try:
        field.post_validate('100')
        assert False, "int is not a valid string"
    except AnsibleParserError:
        assert True
