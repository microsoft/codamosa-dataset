

# Generated at 2022-06-23 05:52:59.710148
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Base1(object, metaclass=BaseMeta):
        pass

    class Base2(object, metaclass=BaseMeta):
        test = 42

    class Base3(object, metaclass=BaseMeta):
        test = 43

    class Test(Base1, Base2, Base3):
        class1 = FieldAttribute(isa='str', default="value1")
        class2 = FieldAttribute(isa='str', default="value2")

    assert Test._valid_attrs['class1'].default == "value1"
    assert Test._valid_attrs['class2'].default == "value2"
    assert Test._attr_defaults['class1'] == "value1"
    assert Test._attr_defaults['class2'] == "value2"
    assert Test._attributes['class1'] is Sentinel
    assert Test._

# Generated at 2022-06-23 05:53:01.434967
# Unit test for method get_path of class Base
def test_Base_get_path():
  c = Base()
  assert c.get_path() is None

# Generated at 2022-06-23 05:53:12.108393
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # data_structure_type is a list of DataStructure
    data_structure_type = [DataStructure]
    data_structure_type_instances = [DataStructure()]

    # Iterate over data_structure_type
    for index in range(len(data_structure_type)):
        # Setup
        data_structure_call_args = {}
        expected = data_structure_type_instances[index]

        # Test
        f = FieldAttributeBase(data_structure_type[index], data_structure_call_args)
        actual = f.get_ds()

        # Verify
        assert actual == expected, \
            "Expected: %s Actual: %s" % (expected, actual)


# Generated at 2022-06-23 05:53:21.562504
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method FieldAttributeBase.load_data of class FieldAttributeBase

    Make sure we can take a data structure and load the field attribute
    defaults, as well as any additional attributes passed in on the
    object.
    '''

    class TestClass(BaseObject):
        _test_counter = 0

        def __init__(self, **kwargs):
            if 'test_counter' not in kwargs:
                TestClass._test_counter += 1
                kwargs['test_counter'] = TestClass._test_counter
            super(TestClass, self).__init__(**kwargs)


# Generated at 2022-06-23 05:53:29.586635
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    '''
    from units.mock.loader import DictDataLoader

    # Data for testing.
    g_obj = FieldAttributeBase()
    g_attr = 'accessible'
    g_ds = {
        'play': {},
        '_ds': {
            'play': {},
            '_ds': {},
        },
    }
    g_ds_result = {
        'accessible': 'accessible',
        '_ds': {},
    }

    # Unit test for base class FieldAttributeBase, method dump_me
    def _test_dump_me(obj, attr, ds, ds_result):
        result = obj.dump_me(attr, ds)

# Generated at 2022-06-23 05:53:40.719755
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    ''' Test the method get_dep_chain of the class Base '''
    mock_dep_chain = [
        {'_uuid': 'uuid_1', 'name': 'role_1'},
        {'_uuid': 'uuid_2', 'name': 'role_2'},
    ]
    class_instance = Base()
    assert class_instance.get_dep_chain() is None

    class_instance._parent = {}
    assert class_instance.get_dep_chain() is None

    class_instance._parent = {'_play': {'_dep_chain': mock_dep_chain}}
    assert class_instance.get_dep_chain() == mock_dep_chain
    class_instance._parent = {'_dep_chain': mock_dep_chain}
    assert class_instance.get_dep_

# Generated at 2022-06-23 05:53:57.740940
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''

    # ansible/lib/ansible/parsing/dataloader.py
    from ansible.parsing.dataloader import DataLoader

    # ansible/lib/ansible/playbook/base.py
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    # This example shows a way to to add a class attribute, in this case a shared
    # attribute named _shared_value_ with the value of 42
    # It also shows how to add a FieldAttribute (which uses the dataloader)
    Base._shared_value = 42
    Base._valid_attrs = FieldAttribute(isa='string', default="foo")
    base = Base()
    assert base._shared_

# Generated at 2022-06-23 05:54:00.082247
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # this test cannot be executed as part of unit tests
    return


# Generated at 2022-06-23 05:54:11.944807
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test function load_data of class FieldAttributeBase

    # Create an object to test
    test_obj = FieldAttributeBase()

    # Test with a basic attribute
    test_args = {"name": "test_name", "attribute": "test_attribute"}
    test_obj.load_data(test_args)

    # Test with an alias
    test_args = {"name": "test_name", "attribute": "test_attribute", "aliases": ["test_alias"]}
    test_obj.load_data(test_args)

    # Test with a default defined
    default = lambda: 'foo'
    test_args = {"name": "test_name", "attribute": "test_attribute", "default": default}
    test_obj.load_data(test_args)

    # Test with a default defined as a variable
    test

# Generated at 2022-06-23 05:54:13.835891
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    f = FieldAttributeBase()
    assert f.get_loader() is not None


# Generated at 2022-06-23 05:54:16.117657
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FA = FieldAttributeBase()
    assert_raises(NotImplementedError, FA.validate, name=None, value=None)


# Generated at 2022-06-23 05:54:19.571369
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    my_task = Task()
    my_task.ds = {'a': 'b'}
    result = my_task.get_ds()
    assert result == {'a': 'b'}


# Generated at 2022-06-23 05:54:21.860990
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
  obj = FieldAttributeBase()
  assert obj.get_ds() == 'obj'


# Generated at 2022-06-23 05:54:24.202621
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base = FieldAttributeBase()
    base.deserialize({'name': 'test'})


# Generated at 2022-06-23 05:54:34.824112
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    class Play():
        def __init__(self):
            self._ds = None
            self._line_number = None
            self.dep_chain = None
            self.name = None
            self.vars = None
            self.roles = None
            self.roles_path = []
            self.tasks = None
            self.handlers = None
            self.pre_tasks = None
            self.post_tasks = None
            self.become = None
            self.become_user = None
            self.become_method = None
            self.tags = None
            self.gather_facts = None
            self.hosts = None
            self.any_errors_fatal = None
            self._parent = None
            self._included_path = None
            self._

# Generated at 2022-06-23 05:54:43.948310
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent(object):
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}

        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

    class Derived(Parent):
        one = Attribute(default=1)

    a = Derived()
    assert type(a.one) == int
    assert a.one == 1



# Generated at 2022-06-23 05:54:47.624574
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    FA = FieldAttributeBase('test', doc=None)
    FA.squash()
    assert FA._squashed is True


# Generated at 2022-06-23 05:54:48.958447
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    pass



# Generated at 2022-06-23 05:54:57.828503
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    all_attrs = []
    for base_class in all_base_classes:
        for class_name, cls in iteritems(base_class.__dict__):
            if class_name.startswith('_'):
                continue
            attrs = cls.dump_attrs()
            for k, v in iteritems(attrs):
                if v.dump_me:
                    all_attrs.append(class_name + '.' + k)
    assert len(all_attrs) > 0

# Generated at 2022-06-23 05:55:08.380447
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.color import stringc
    my_object = FieldAttributeBase()
    for name in my_object._valid_attrs.keys():
        if name in my_object._alias_attrs:
            continue
        my_object._attributes[name] = shallowcopy(my_object._attributes[name])
        my_object._attr_defaults[name] = shallowcopy(my_object._attr_defaults[name])
    my_object._loader = my_object._loader
    my_object._variable_manager = my_object._variable_manager
    my_object._validated = my_object._validated
    my_object._finalized = my_object._finalized
    my_object._uuid = my_object._

# Generated at 2022-06-23 05:55:19.867191
# Unit test for constructor of class Base
def test_Base():
    class A(Base):
        _name = 'foo'
        _connection = None
        _port = None
        _remote_user = None
        _vars = {}
        _environment = []
        _no_log = False
        _run_once = False
        _ignore_errors = False
        _ignore_unreachable = False
        _check_mode = None
        _diff = None
        _any_errors_fatal = C.ANY_ERRORS_FATAL
        _throttle = 0
        _timeout = C.TASK_TIMEOUT
        _debugger = ''
        _become = None
        _become_method = None
        _become_user = None
        _become_flags = None
        _become_exe = None

    # check the class attribute

# Generated at 2022-06-23 05:55:21.650589
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fab = FieldAttributeBase()
    assert fab is not None


# Generated at 2022-06-23 05:55:29.921408
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    class FakeTaskDep:
        def get_dep_chain(self):
            return "chain1"

    class FakeTaskParent:
        def __init__(self):
            self._parent = None

    class FakeTask:
        def __init__(self):
            self._parent = FakeTaskParent()

    task = FakeTask()

    expected = "chain1"
    actual = task.get_dep_chain()
    assert expected == actual

    task._parent._parent = FakeTaskDep()
    actual = task.get_dep_chain()
    assert expected == actual



# Generated at 2022-06-23 05:55:35.849001
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    b = FieldAttributeBase(**{'class_type':None,'isa':'dict'})
    ds = dict()
    attrs = dict()
    b.from_attrs(attrs)
    assert b.__class__.__name__ == 'FieldAttributeBase'



# Generated at 2022-06-23 05:55:38.018004
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Arrange
    test_object = FieldAttributeBase()

    # Act
    actual = test_object.squash()

    # Assert
    assert actual == Sentinel

# Generated at 2022-06-23 05:55:48.424593
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    for _ in range(10):
        data = {'isa':'isa', 'default':'default', 'required':'required',
                'choices':'choices', 'always_post_validate':'always_post_validate',
                'static':'static'}
        fa = FieldAttributeBase(**data)
        with pytest.raises(TypeError):
            fa.post_validate('templar')
            
    for _ in range(10):
        data = {'isa':'isa', 'default':'default', 'required':'required',
                'choices':'choices', 'always_post_validate':'always_post_validate',
                'static':'static'}
        fa = FieldAttributeBase(**data)
        with pytest.raises(TypeError):
            fa.post

# Generated at 2022-06-23 05:55:52.329167
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'finalized': True}
    a = AnsibleObject()
    a.deserialize(data)
    b = a._finalized
    assert b == True
    assert a._squashed == False
# === END ===

# === BEGIN ===

# === END ===


# Generated at 2022-06-23 05:55:59.715269
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class FakeFieldAttributeBase(FieldAttributeBase):
        def deserialize(self, data):
            super(FakeFieldAttributeBase, self).deserialize(data)

    fake_field_attribute_base = FakeFieldAttributeBase()

    with pytest.raises(AnsibleAssertionError, match=r"data \(.+\) should be a dict but is a <class 'int'>"):
        fake_field_attribute_base.deserialize(123)

# Generated at 2022-06-23 05:56:07.711895
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class _TestClass(FieldAttributeBase):
        _valid_attrs = dict(
            test_attr = dict(
                type='str',
                required=True,
                ),
        )

    test_instance = _TestClass()
    with pytest.raises(AnsibleError) as excinfo:
        test_instance.load_data({'name': 'test_name',})
    assert 'required field missing' in str(excinfo.value)


# Generated at 2022-06-23 05:56:20.326918
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase(isa='str')

    # test positive cases
    assert attr.validate('attr_name', 'a_string') == 'a_string'
    assert attr.validate('attr_name', None) is None
    assert attr.validate('attr_name', '') == ''

    # test non-string cases
    assert attr.validate('attr_name', ['a', 'list']) == 'a,list'
    assert attr.validate('attr_name', True) == 'True'

    # test negative cases
    with pytest.raises(AnsibleFilterError) as excinfo:
        attr.validate('attr_name', 45)
    assert "45 is not a valid string" in str(excinfo.value)



# Generated at 2022-06-23 05:56:28.955251
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base._valid_attrs == {}
    assert field_attribute_base.class_name == ""
    assert field_attribute_base.aliases == {}
    assert len(field_attribute_base._attributes) == 0
    assert len(field_attribute_base._attr_defaults) == 0
    # Test that method add_field works as expected
    field_attribute_base.add_field(name='_test_field', attribute=FieldAttribute(default=None, required=False, static=False))

# Generated at 2022-06-23 05:56:38.379379
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # Arguments for the mocker.patch decorator
    args = (
        'ansible_galaxy.galaxy_exceptions.GalaxyClientError',
        'ansible_galaxy.utils.get_collections_artifact_path',
        'ansible_galaxy.utils.get_collections_role_path',
    )

    # Arguments for the mock object creation
    kwargs = {
        'return_value': 'get_collections_artifact_path/get_collections_role_path',
    }

    # Additional keyword arguments for the mock object creation
    kwargs_extra = {}

    # The mock object returned by the decorator
    mocker_get_loader = mock.Mock()

    # The mock object returned by the decorated function

# Generated at 2022-06-23 05:56:50.112401
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base.vars == dict()
    assert base.environment == dict()
    assert base.run_once == False
    assert base.timeout == C.TASK_TIMEOUT
    assert base.module_defaults == list()
    assert base.module_defaults.prepend == True
    assert base.ignore_errors == False
    assert base.ignore_unreachable == False
    assert base.connection == context.CLIARGS['connection']
    assert base.become == context.CLIARGS['become']
    assert base.become_method == context.CLIARGS['become_method']
    assert base.become_user == context.CLIARGS['become_user']

# Generated at 2022-06-23 05:56:58.090623
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    FieldAttributeBase.__name__ = "FieldAttributeBase"
    FieldAttributeBase.__module__ = 'pytest'
    FieldAttributeBase.static = True
    FieldAttributeBase.required = True
    FieldAttributeBase.default = True
    FieldAttributeBase.type = 'type'
    FieldAttributeBase.isa = 'isa'
    FieldAttributeBase.listof = 'listof'
    FieldAttributeBase.class_type = 'class_type'
    FieldAttributeBase.include_defaults = True

    copy = FieldAttributeBase.copy()

    assert copy.static == True
    assert copy.required == True
    assert copy.default == True
    assert copy.type == 'type'
    assert copy.isa == 'isa'
    assert copy.listof == 'listof'
    assert copy.class_type == 'class_type'
   

# Generated at 2022-06-23 05:57:05.362322
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with the default attribute

    # Test with a valid attribute isa
    attr = FieldAttributeBase('name', default=0, isa='string')
    attr.isa = 'string'
    assert attr.isa == 'string'

    attr.isa = 'int'
    assert attr.isa == 'int'

    attr.isa = 'float'
    assert attr.isa == 'float'

    attr.isa = 'bool'
    assert attr.isa == 'bool'

    attr.isa = 'list'
    assert attr.isa == 'list'

    attr.isa = 'set'
    assert attr.isa == 'set'

    attr.isa = 'dict'
    assert attr.isa == 'dict'

    # Test with an invalid attribute isa

# Generated at 2022-06-23 05:57:12.950666
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    argument_spec = dict()
    argument_spec['post_validate'] = dict(type='str', required=False)
    argument_spec['aliases'] = dict(type='list', elements='str', required=False)
    argument_spec['elements'] = dict(type='str', required=False)
    argument_spec['class_type'] = dict(type='str', required=False)
    argument_spec['class_only'] = dict(type='bool', required=False)
    argument_spec['default'] = dict(required=False)
    argument_spec['fallback'] = dict(required=False)
    argument_spec['fallback_type'] = dict(type='str', required=False)
    argument_spec['required'] = dict(type='bool', required=False)

# Generated at 2022-06-23 05:57:22.950808
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os


# Generated at 2022-06-23 05:57:24.878434
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # TODO: possibly test this method
    pass


# Generated at 2022-06-23 05:57:37.513997
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class DummyClass(object):
        pass

    dummy_obj = DummyClass()

    class DummyAnsibleObject(AnsibleObject):
        def __init__(self):
            self._attributes = dict()

    obj = DummyAnsibleObject()
    # default init
    fa = FieldAttributeBase()
    assert fa.isa is None
    assert fa.class_type is None
    assert fa.class_name is None
    assert fa.default is None
    assert not fa.required
    assert fa.init is True
    assert fa.static is False
    assert fa.always_post_validate is False
    # init with parameters

# Generated at 2022-06-23 05:57:47.905224
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class Base_test:
        @property
        def _parent(self):
            return self._parent_value
        @_parent.setter
        def _parent(self, value):
            self._parent_value = value
    # Case 1: there is no path available in the self from which we can build the path_stack
    # So [Unraveled path_stack] == []
    test = Base_test()
    path_stack = test.get_search_path()
    assert len(path_stack) == 0

    # Case 2: Return the list of paths you should search for files, in order.
    # This follows role/playbook dependency chain.
    # So, Case 2--> Case 2.1:
    # Case 2.1: we have the self._parent and it has _role_path value.
    # And the item in the

# Generated at 2022-06-23 05:57:56.317914
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class A(object):
        def __init__(self):
            self.b = None

        def serialize(self):
            return self.b

    class B(object):
        def __init__(self):
            self.c = None
            self.d = None

        def serialize(self):
            return self.d

    class Test(AnsibleBase):
        x = FieldAttribute(isa='list', default=list)
        y = FieldAttribute(isa='int', default=1)
        z = FieldAttribute(isa='class', class_type=A)

    test = Test()
    test.x = ['a', 'b']
    test.y = 2
    test.z = A()
    test.z.b = B()
    test.z.b.d = 'test'


# Generated at 2022-06-23 05:58:01.698937
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    global variable_manager

    # test variables
    variable_manager = [1, 2, 3]

    # test that variable_manager is set
    variable_manager1 = variable_manager

    # test that variable_manager is set
    variable_manager2 = variable_manager

    # test that variable_manager is set
    variable_manager3 = variable_manager


    FieldAttributeBase.get_variable_manager()


# Generated at 2022-06-23 05:58:03.379987
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    arguments = {}
    obj = FieldAttributeBase(**arguments)
    obj.post_validate()



# Generated at 2022-06-23 05:58:17.222779
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Use cases: (value, kwargs, result)
    # Default case:
    yield (1, {}, 1)

    # If a function is provided, it is called and the result is returned.
    # The default value will always be returned when the value is None.
    yield (None, {'default': lambda: 5}, 5)
    yield (None, {'default': lambda: 5}, 5)
    yield (None, {'default': lambda: 5}, 5)
    yield (None, {'default': lambda: 5}, 5)

    yield (1, {'default': lambda: 5}, 1)
    yield (1, {'default': lambda: 5}, 1)
    yield (1, {'default': lambda: 5}, 1)
    yield (1, {'default': lambda: 5}, 1)


# Generated at 2022-06-23 05:58:18.290685
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert False, "Test not implemented"


# Generated at 2022-06-23 05:58:21.628999
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    field_attr_base = FieldAttributeBase()
    variable_manager = field_attr_base.get_variable_manager()
    assert variable_manager is None


# Generated at 2022-06-23 05:58:27.117097
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Test method squash of class FieldAttributeBase
    '''
    obj = FieldAttributeBase()

    # noop
    result = obj.squash()

    # AssertionError, because we can't compare Task() to None
    #self.assertIsNone(result)
    return


# Generated at 2022-06-23 05:58:37.563832
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit tests for FieldAttributeBase.post_validate()
    '''
    # pylint: disable=no-self-use,unused-argument

    class TestClass(FieldAttributeBase):
        '''
        Simple subclass of FieldAttributeBase to test the base implementation of post_validate()
        '''
        def __init__(self):
            super(TestClass, self).__init__()
            self._post_validate_called = False

        _valid_attrs = {
            'test': FieldAttribute(isa='bool'),
            'test2': FieldAttribute(isa='list', listof='str', required=True),
        }

        def _post_validate_test(self, attribute, value, templar):
            '''
            Post validate a boolean attribute, useful for unit testing
            '''



# Generated at 2022-06-23 05:58:48.188192
# Unit test for method get_path of class Base
def test_Base_get_path():
    class TestParent():
        def __init__(self):
            self._ds = 'test_ds'
            self._line_number = 'test_line_number'
            self._play = 'test_play'

    class TestDS():
        def __init__(self):
            self._data_source = 'test_data_source'
            self._line_number = 'test_line_number'

    x = Base()
    p = TestParent()
    d = TestDS()
    assert x.get_path() == ''
    x._parent = p
    assert x.get_path() == 'test_play:test_play'
    x._ds = d
    assert x.get_path() == 'test_data_source:test_line_number'


# Generated at 2022-06-23 05:58:55.703307
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    p = FieldAttributeBase()
    attr = p.get_attributes()
    assert attr[0]['name'] == 'static'
    assert attr[1]['name'] == 'serialize_when_none'
    assert attr[2]['name'] == 'required'
    attr = p.get_valid_attrs()

# Generated at 2022-06-23 05:58:56.333704
# Unit test for method get_path of class Base
def test_Base_get_path():
    pass

# Generated at 2022-06-23 05:59:01.179589
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
  BaseMeta.__new__(BaseMeta, 'name', tuple(), {'_valid_attrs': {}, '_alias_attrs': {}, '_attr_defaults': {}, '_attributes': {}})


# Generated at 2022-06-23 05:59:10.094580
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    """
    This unit test is meant to test BaseMeta.

    If this test fails, the BaseMeta class itself has an issue.
    """

    # pylint: disable=no-member,too-many-instance-attributes
    # pylint: disable=too-many-public-methods

    class TestClass():
        """
        This is a dummy test class with some attributes
        """
        def __init__(self):
            self.a = 1
            self.b = 2
            self._c = 3
            self._d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n

# Generated at 2022-06-23 05:59:21.486079
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    obj = FieldAttributeBase()

    repr = {'finalized': True, 
            'uuid': 'a7b2f9d6-38b3-41be-b0f3-d602f7ac1c9a',
           'squashed': True}

    with pytest.raises(AnsibleAssertionError):
        obj.deserialize('foo')

    result = obj.deserialize(repr)

    assert obj._finalized == True
    assert obj._squashed == True
    assert obj._uuid == 'a7b2f9d6-38b3-41be-b0f3-d602f7ac1c9a'

# Generated at 2022-06-23 05:59:27.413120
# Unit test for constructor of class Base
def test_Base():

    class TestObj(Base):
        _testattr = FieldAttribute(isa='string', default='testattr')
        _testattr2 = FieldAttribute(isa='string', default='testattr2')

    obj = TestObj()

    assert obj._testattr == 'testattr'
    assert obj._testattr2 == 'testattr2'
    assert obj._name == ''


#
# Any unit test for class Task or subclass of Task will be done in test_module_loader.py
#

# Generated at 2022-06-23 05:59:28.936317
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert True

# Generated at 2022-06-23 05:59:38.625367
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # import needed modules here
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import strip_internal_keys
    # initialize the class
    myobj = FieldAttributeBase()
    # test the result with a known 'good' result
    # we expect this to throw an exception
    try:
        myobj.serialize()
        raise Exception('Return of serialize did not throw exception as expected')
    except NotImplementedError:
        pass
    # init the source data

# Generated at 2022-06-23 05:59:44.880303
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase(10, 'test_FieldAttributeBase_dump_me')

    assert obj.dump_me is True
    assert obj.static is False
    assert obj.always_post_validate is False
    assert obj.required is True
    assert obj.name == 'test_FieldAttributeBase_dump_me'
    assert obj.isa is None
    assert obj.default is None

# Generated at 2022-06-23 05:59:54.973549
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    def _create_attrs(src_dict, dst_dict):
        props = set(src_dict) - set(dst_dict)
        for attr_name in props:
            value = src_dict[attr_name]
            if isinstance(value, FieldAttribute):
                if attr_name.startswith('_'):
                    attr_name = attr_name[1:]

                getter = _generic_g
                setter = _generic_s
                deleter = _generic_d
                
                dst_dict[attr_name] = getter
                dst_dict['_valid_attrs'][attr_name] = value
                dst_dict['_attributes'][attr_name] = ""
                dst_dict['_attr_defaults'][attr_name] = value.default


# Generated at 2022-06-23 05:59:55.921994
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass


# Generated at 2022-06-23 06:00:07.940308
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.playbook.attribute import FieldAttributeBase
    class DummyTask1(FieldAttributeBase):
        def __init__(self, a, b, c=None, d=None, e=None):
            self._valid_attrs=dict(a=FieldAttribute(), b=FieldAttribute(), c=FieldAttribute(default=False), d=FieldAttribute(default=[]), e=FieldAttribute(default={}))
            super(DummyTask1, self).__init__()
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
    dt = DummyTask1('a', 'b', ['c'], 23)
    dt.e['f'] = 43
    dt.e['g'] = 'f'
    dt_copy

# Generated at 2022-06-23 06:00:15.459826
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base = FieldAttributeBase()

    # test the code path where we do not want to filter sensitive fields
    base._valid_attrs = {'foo': 'bar'}
    assert base.dump_me() == base._valid_attrs

    # test the code path where we do want to filter sensitive fields
    base._valid_attrs = {'foo': 'bar', 'baz': 'boo'}
    base._no_log_fields = ['baz']
    assert base.dump_me() == {'foo': 'bar'}

# Generated at 2022-06-23 06:00:16.460514
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass


# Generated at 2022-06-23 06:00:26.298061
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent():
        _ansible_parent = FieldAttribute(default=None, inherit=True, priority=100)

    class Grandparent(Parent):
        _ansible_vg = FieldAttribute(default=None, inherit=False, priority=200)

    class BaseClass(Grandparent):
        _ansible_baseclass = FieldAttribute(default=None, inherit=False, priority=300)

        def _get_attr_ansible_baseclass(self):
            return True

        def _get_attr_ansible_vg(self):
            return True

    # Test attributes inherited from Grandparent
    my_baseclass = BaseClass()
    assert hasattr(my_baseclass, '_ansible_baseclass')
    assert hasattr(my_baseclass, '_ansible_vg')

# Generated at 2022-06-23 06:00:36.535938
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import unittest
    import pytest
    import os
    import sys
    import tempfile
    import shutil
    import json

    import ansible.constants as C
    import ansible.module_utils.facts.system.distribution as distribution 

    from ansible.module_utils.six import PY2

    from units.mock.loader import DictDataLoader

    if not PY2:
        from ansible.module_utils.facts.system.distribution import Distribution

        DISTRIBUTION_RHEL = Distribution(
            name="RedHat",
            id="RedHat",
            like="fedora",
            version="6.5",
            major_version='6',
        )

# Generated at 2022-06-23 06:00:47.636947
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class parent1(object):
        class Attr1(FieldAttribute):
            def __init__(self):
                super(parent1.Attr1, self).__init__(default='parent1.Attr1')
        class Attr2(FieldAttribute):
            def __init__(self):
                super(parent1.Attr2, self).__init__(default='parent1.Attr2')
        Attr1 = Attr1()
        Attr2 = Attr2()

    class parent2(object):
        class Attr3(FieldAttribute):
            def __init__(self):
                super(parent2.Attr3, self).__init__(default='parent2.Attr3')

# Generated at 2022-06-23 06:00:59.218275
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Parent1(object):
        def __init__(self):
            self._role_path = "first/path"

    class Parent2(object):
        def __init__(self):
            self._role_path = "second/path"

    class Parent3(object):
        def __init__(self):
            self._role_path = "third/path"

    class BaseTest(Base):
        def __init__(self):
            self._task_vars = None
            self._role_vars = None
            self._nonpersistent_fact_cache

# Generated at 2022-06-23 06:01:08.916446
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestClass(with_metaclass(BaseMeta, object)):
        _first = FieldAttribute(isa='str', inherit=True)
        _second = FieldAttribute(isa='int', inherit=True)

        def __init__(self):
            super(TestClass, self).__init__()
            self._first = 'foo'
            self._second = 42

    test_obj = TestClass()
    assert test_obj.first == 'foo'
    assert test_obj.second == 42

    test_obj.first = 'bar'
    test_obj.second = 'baz'
    assert test_obj.first == 'bar'
    assert test_obj.second == 'baz'
    test_obj.second = 1
    assert test_obj.second == 1
    test_obj.second = 2
    assert test_

# Generated at 2022-06-23 06:01:20.492677
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    path_stack = []
    path_stack.append("/roles/role_1")
    path_stack.append("/roles/role_1/tasks")
    path_stack.append("/roles/role_2")
    path_stack.append("/roles/role_2/tasks")
    path_stack.append("/playbook/tasks")

    def test_get_search_path(self, task_base):
        return path_stack

    BaseGetSearchPath = type('BaseGetSearchPath', (Base,), {'get_dep_chain': test_get_search_path})

    base = BaseGetSearchPath()

# Generated at 2022-06-23 06:01:25.594347
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    data_value = dict(
        name='example',
        host='example',
        port=89,
        user='admin',
        password='qwerty',
        timeout=30
    )
    a = FieldAttributeBase(**data_value)
    a.post_validate()



# Generated at 2022-06-23 06:01:37.503914
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    t = TestBase()
    attr_name = 'test'
    ds = 'string'
    class TestClass(TestBase): pass
    class TestAttribute(FieldAttributeBase):
        def __init__(self, cls=None):
            super(TestAttribute, self).__init__()
            self.name = attr_name
            self.isa = 'string'
            self.class_type = cls or None

    # it's a string
    attr = TestAttribute()
    if 'something' != t.get_validated_value(attr_name, attr, 'something', t.get_templar(dict(something='string'))):
        raise AssertionError('get_validated_value() with isa == string did not return the value passed to it')

    # it's an int
    attr

# Generated at 2022-06-23 06:01:48.112913
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.playbook.attribute import FieldAttributeBase
    from ansible import utils
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestFieldAttributeBase(FieldAttributeBase):
        def _post_validate_test_arg(self, attribute, value, templar):
            pass

        def _validate_test_arg(self, value, templar):
            pass

    test = TestFieldAttributeBase()
    assert test.get_validated_value('test_arg', test.test_arg, 'abc', 'templar') == 'abc'
    # not a real test, just making sure it is not None
    assert test.get_validated_value('test_arg', test.test_arg, None, 'templar') == None

# Generated at 2022-06-23 06:01:56.764441
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    context = Context("FieldAttributeBase","load_data")
    context.add_comment("Test case for method load_data of class FieldAttributeBase")
    context.print_comment("This test will check if method load_data of class FieldAttributeBase will return the data value")
    context.print_comment("input:")
    context.print_comment("    self = FieldAttributeBase()")
    context.print_comment("    obj = self")
    context.print_comment("    name = Dummy")
    context.print_comment("    attr = Dummy")
    context.print_comment("output:")
    context.print_comment("    value = Dummy")
    context.print_comment("    new_value = Dummy")
    context.print_comment("    expected_value = None")

# Generated at 2022-06-23 06:02:04.435825
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base = FieldAttributeBase()
    expected_names = ("test_name", "test_name2")
    field_attribute_base._valid_attrs = {
        "test_name": "test_value",
        "test_name2": "test_value2"
        }
    field_attribute_base.test_name = "test_value"
    field_attribute_base.test_name2 = "test_value2"
    attrs = field_attribute_base.dump_attrs()
    assert set(attrs.keys()) == set(expected_names)


# Generated at 2022-06-23 06:02:15.764884
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    play = Play()
    play._role_path = "./"
    assert play.get_search_path() == ['./']
    role_A = RoleInclude()
    role_A._role_path = "A"
    role_A._parent = play
    assert role_A.get_search_path() == ['A', './']
    role_B = RoleInclude()
    role_B._role_path = "B"
    role_B._parent = role_A
    assert role_B.get_search_path() == ['B', 'A', './']


# this is a bit of a hack, but allow us to inherit from Base() without recursion issues
Base.__bases__ = (object,)



# Generated at 2022-06-23 06:02:16.655929
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass


# Generated at 2022-06-23 06:02:26.597480
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fake_loader = DictDataLoader({
        '/a/b/c': '---\nfoo: bar',
        '/a/b/d': '---\nfoo: bar',
    })
    fake_inventory = Inventory(
        loader=fake_loader,
        host_list=['localhost'],
    )
    fake_variable_manager = VariableManager(
        loader=fake_loader,
        inventory=fake_inventory
    )
    fab = FieldAttributeBase()
    assert fab.from_attrs({}) is None
    attrs = {'a': 1}
    fab.from_attrs(attrs)
    # check if the value of 'a' is changed
    assert fab.a == 1
    attrs = {'a': None}
    fab.from_attrs(attrs)
    # check if the

# Generated at 2022-06-23 06:02:28.742293
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # FIXME: add proper unit tests for FieldAttributeBase once the class definition
    # is completed.
    pass

# Generated at 2022-06-23 06:02:30.529022
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    FieldAttributeBase.get_variable_manager()


# Generated at 2022-06-23 06:02:42.986944
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # 1. test_Base_get_search_path: dependencies in role playbook
    # playbook is in a role (dep_chain != None) and dep_chain contains _role_path
    path_stack = []
    base = Base()
    class Task1(object):
        def get_path(self):
            return 'PathofTask1'
        def get_dep_chain(self):
            return ['RoleA', 'RoleB']
    class RoleA(object):
        def __init__(self):
            self._role_path = 'PathofaRoleA'
    class RoleB(object):
        def __init__(self):
            self._role_path = 'PathofaRoleB'
    base._parent = Task1()
    base._parent.get_dep_chain = base.get_dep_chain
    dep_

# Generated at 2022-06-23 06:02:53.195094
# Unit test for constructor of class FieldAttributeBase