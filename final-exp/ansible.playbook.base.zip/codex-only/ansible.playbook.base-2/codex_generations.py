

# Generated at 2022-06-23 05:52:59.962677
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test attributes - start
    _field_name = 'test_field'
    _field_class = 'test_class'
    _field_isa = 'test_isa'
    _field_type = None
    _field_default = 'test_default'
    _field_require = True
    _field_static = True
    _field_metadata = {'key1': 'val1', 'key2': 'val2'}
    _field_aliases = ['alias1', 'alias2']
    _field_always_post_validate = False
    _field_path = 'test_path'
    _field_class_type = None
    _field_listof = None
    # Test attributes - end
    
    # Perform the test

# Generated at 2022-06-23 05:53:02.575605
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
  obj = FieldAttributeBase(dict(name="name", default=None, isa=None))
  assert obj.post_validate(obj) == None


# Generated at 2022-06-23 05:53:04.120941
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    obj_copy = obj.copy()
    assert obj_copy == obj



# Generated at 2022-06-23 05:53:11.480453
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    b = Base()
    def test_attributes():
        v = vars(b)
        for k, v in v.items():
            setattr(Base, k, v)
        del v
        del k
        del vars

    test_attributes()
    b._ds = types.SimpleNamespace()
    patch1 = patch.object(b, 'get_dep_chain', return_value=None)
    with patch1 as m1:
        assert b.get_search_path() == []
    patch2 = patch.object(b, 'get_dep_chain', return_value=[
        types.SimpleNamespace(
            _role_path='./role1'
        ),
        types.SimpleNamespace(
            _role_path='./role2'
        )
    ])
    b._ds._

# Generated at 2022-06-23 05:53:19.790760
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    import getpass
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.sentinel import Sentinel

    fixture = FieldAttributeBase()

    fixture.deserialize({'name': u'test'})
    assert fixture.name == u'test'

    fixture.deserialize({'name': (u'test')})
    assert fixture.name == u'test'

    fixture.deserialize({'name': (u'test',)})
    assert fixture.name == u'test'

    fixture.deserialize({'name': 'test'})
    assert fixture.name == u'test'

    fixture.deserialize({'name': 'test'})
    assert fixture.name == u'test'

    fixture.deserialize({'name': ['test']})
    assert fixture

# Generated at 2022-06-23 05:53:22.049717
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # FIXME: This method is not implemented.
    # NOTE: This method cannot be tested as it is abstract
    pass

# Generated at 2022-06-23 05:53:27.915127
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    FieldAttributeBase_instance = FieldAttributeBase()
    # Testing if it raises an error for wrong number of arguments
    with pytest.raises(TypeError):
        FieldAttributeBase_instance.serialize(1)


# Generated at 2022-06-23 05:53:30.598068
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert b.get_path() == ""

# ==============================================================
# Task


# Generated at 2022-06-23 05:53:35.583812
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    attribute = field_attribute_base.FieldAttribute(name='name', isa='string')
    templar = Templar(loader=None)
    FieldAttributeBase.post_validate(attribute, templar)
    assert attribute.name == 'name'


# Generated at 2022-06-23 05:53:45.600574
# Unit test for method squash of class FieldAttributeBase

# Generated at 2022-06-23 05:53:59.143984
# Unit test for method get_variable_manager of class FieldAttributeBase

# Generated at 2022-06-23 05:54:11.133667
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # get the attribute instance to test
    FieldAttributeBase_obj = FieldAttributeBase()
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.name = <some value>
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.default = <some value>
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.aliases = <some value>
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.required = <some value>
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.choices = <some value>
    # the setUp function set the value of the following attribute
    # FieldAttributeBase_obj.private = <some value>
    #

# Generated at 2022-06-23 05:54:12.728664
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert Base.get_search_path(None)==None



# Generated at 2022-06-23 05:54:15.060246
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
	_object = FieldAttributeBase()
	_object.ds = object()
	_object.get_ds()


# Generated at 2022-06-23 05:54:25.490402
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    valid_attrs = ('isa', 'default', 'required')
    valid_types = ('string', 'bool', 'dict', 'list', 'template', 'int', 'float', 'class', 'set')

    valid_classes = (
        'bool', 'dict', 'field', 'float', 'int', 'list', 'pathspec', 'set', 'string',
    )
    class_type = type(str('this is a string'))

    # Base class should be constructable with no arguments
    obj = FieldAttributeBase()
    # FieldAttributeBase() should have a _valid_attrs attribute which
    # is a dict
    assert hasattr(obj, '_valid_attrs')
    assert isinstance(obj._valid_attrs, dict)
    # FieldAttributeBase() should have a _variable_attributes attribute
    # which is a

# Generated at 2022-06-23 05:54:29.224792
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    base._parent = "parent"
    base._parent._play = "play"
    assert base.get_dep_chain() == "play"


# Generated at 2022-06-23 05:54:37.983039
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import ansible.utils.template as template

    class TestCallbacks(CallbackBase):
        def __init__(self, *args, **kwargs):
            self.event_log = []
            self.task_log = []
            super(TestCallbacks, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 05:54:38.679535
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass

# Generated at 2022-06-23 05:54:46.562441
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    name = 'test_FieldAttributeBase_dump_attrs'
    

# Generated at 2022-06-23 05:54:57.203322
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    repr = FieldAttributeBase(default=None, choices=None, required=False, private=False, inherit=False).serialize()
    assert repr == {'required': False, 'private': False, 'choices': None, 'inherit': False, 'default': None}

    repr = FieldAttributeBase(default='test_default', choices=None, required=False, private=False, inherit=False).serialize()
    assert repr == {'required': False, 'private': False, 'choices': None, 'inherit': False, 'default': 'test_default'}

    repr = FieldAttributeBase(default=FieldAttributeObject(), choices=None, required=False, private=False, inherit=False).serialize()

# Generated at 2022-06-23 05:55:07.794459
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    ''' Test that get_dep_chain() return a correct dependency chain. '''
    # Create some objects
    play = Play()
    play.name = 'test_play'
    play.connection = 'local'
    play.hosts = ['localhost']

    task1 = Task()
    task1.name = 'test_task1'
    task2 = Task()
    task2.name = 'test_task2'

    role_target = Role()
    role_target.name = 'test_role_target'
    role_target.tasks[0] = task1
    role_target.tasks[1] = task2

    role_parent = Role()
    role_parent.name = 'test_role_parent'
    role_parent.tasks[0] = task1

# Generated at 2022-06-23 05:55:10.443775
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    fb = FieldAttributeBase(name='name', default=None)
    assert fb.serialize() == {'name': 'name', 'default': None, 'serialize_always': False}


# Generated at 2022-06-23 05:55:18.826562
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Initialize basic objects for testing
    ds = dict()
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    templar = Templar(loader, variable_manager)

    # Build test object
    f = FieldAttributeBase(ds)
    # Raise exception on preprocess_data method call, to avoid calling the rest of the method and use template
    f._preprocess_data = MagicMock(side_effect=AnsibleParserError("AnsibleParserError"))

    ds_in = dict()
    expected = dict()
    result = f.preprocess_data(ds_in, templar)
    assert result == expected


# Generated at 2022-06-23 05:55:20.866265
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    assert FieldAttributeBase().deserialize(data) == (data)


# Generated at 2022-06-23 05:55:21.938055
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    assert True

# Generated at 2022-06-23 05:55:33.062662
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Unit test for method FieldAttributeBase.from_attrs of class FieldAttributeBase
    '''
    fake_loader = DictDataLoader({
        'test_ds': TEXT_DS[0]
    })

    # test_FieldAttributeBase_from_attrs#1
    # self.assertRaisesRegexp(AnsibleParserError, "^Vars in a .+ must be specified as a .+$", Task().from_attrs, 'test_ds')

    # test_FieldAttributeBase_from_attrs#2
    assert Task().from_attrs({'vars': 'test_ds'})

    # test_FieldAttributeBase_from_attrs#3
    assert Task().from_attrs({'vars': ['test_ds']})

    # test_FieldAttributeBase_from_attrs#

# Generated at 2022-06-23 05:55:44.193301
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # FieldAttributeBase should copy the following attrs:
    #
    # name, static, class_type, isa, **kwargs
    #
    fa = FieldAttributeBase()
    # fa.name doesn't exist so we expect an exception
    with pytest.raises(AttributeError):
        assert fa.copy() == None
    fa.name = 'foobar'
    # fa.static doesn't exist so we expect an exception
    with pytest.raises(AttributeError):
        assert fa.copy() == None
    fa.static = 'foobar'
    # fa.class_type doesn't exist so we expect an exception
    with pytest.raises(AttributeError):
        assert fa.copy() == None
    fa.class_type = 'foobar'
    # fa.isa doesn't exist so we expect an exception

# Generated at 2022-06-23 05:55:53.630022
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Ensure squash(other) works as expected
    '''
    # Create a simple field attribute
    attr = FieldAttribute()

    # Create a simple dictionary-derived object
    obj = DummmyObject()

    # Test that obj does not have attribute attr.name
    assert not obj.has_field(attr.name)

    # Test that squash is handled by FieldAttributeBase
    with pytest.raises(AnsibleAssertionError):
        attr.squash(obj)

    # Test that squash works when name is set
    attr.name = 'name'
    with pytest.raises(AnsibleAssertionError):
        attr.squash(obj)

    # Test that squash fails for first use of FieldAttribute.name()
    attr.name = 'name'

# Generated at 2022-06-23 05:56:02.330567
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    data = dict(
        foobar='foobar',
        foobar_int=1,
        foobar_list=[
            'abc',
            'def'
        ]
    )
    cls_to_test = FieldAttributeBase(
        foobar=dict(
            type='str',
            required=True
        ),
        foobar_int=dict(
            type='int',
            required=True
        ),
        foobar_list=dict(
            type='list',
            required=True
        )
    )
    repr_data = cls_to_test.from_attrs(data)
    assert repr_data == cls_to_test


# Generated at 2022-06-23 05:56:13.188763
# Unit test for method get_path of class Base
def test_Base_get_path():
    m = mock.mock_open()
    with mock.patch('ansible.parsing.yaml.constructor.Constructor.construct_scalar') as constructor:
        constructor.return_value = 'b'
        with mock.patch('ansible.parsing.yaml.constructor.open', m, create=True):
            with mock.patch('os.path.getsize', return_value=1024) as mock_getsize:
                obj = None
                if sys.version_info.major == 2:
                    obj = Base(dict(a=dict(key='value')))
                else:
                    obj = Base(YAML().load(dict(a=dict(key='value'))))
                obj.post_validate()
                assert obj.get_path() == ''


# Generated at 2022-06-23 05:56:25.658049
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class MyObject(BaseObject):
        _foo = FieldAttribute(isa='str', default=42)
        _bar = FieldAttribute(isa='str', default='BAR')

    obj = MyObject()

    assert obj._foo == '42'
    assert obj._bar == 'BAR'
    assert obj._get_parent_field_name('_foo') == 'foo'

    class MyObject(BaseObject):
        _foo = FieldAttribute(isa='str', default=42, serialize_when_none=False)
        _bar = FieldAttribute(isa='str', default='BAR', serialize_when_none=False)

    obj = MyObject()

    assert obj._foo == '42'
    assert obj._bar == 'BAR'
    assert obj._get_parent_field_name('_foo') == 'foo'



# Generated at 2022-06-23 05:56:36.780200
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    class TestObject(object):

        def __init__(self, val):
            self.test_val = val

        def serialize(self):
            return dict(test_val=self.test_val)

    one = TestObject(1)
    two = TestObject(2)


# Generated at 2022-06-23 05:56:47.708815
# Unit test for method copy of class FieldAttributeBase

# Generated at 2022-06-23 05:56:52.754124
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    FieldAttributeBase instance method "post_validate"
    '''
    f = FieldAttributeBase()
    assert isinstance(f, object)
    with pytest.raises(AnsibleParserError):
        f.post_validate(templar=object())



# Generated at 2022-06-23 05:57:01.853672
# Unit test for constructor of class Base
def test_Base():
  from ansible.compat.tests.mock import patch, MagicMock
  from ansible.errors import AnsibleParserError
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.play import Play
  from ansible.playbook.task import Task
  from ansible.playbook.block import Block
  import sys

  p = patch.dict(os.environ, {'ANSIBLE_REMOTE_USER': 'test_remote_user', 'ANSIBLE_CONNECTION': 'test_connection'})
  p.start()
  sys.modules['__main__'].cli = MagicMock()
  sys.modules['__main__'].cli.become_method = 'test_become_method'

# Generated at 2022-06-23 05:57:11.331534
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    temp_short = tempfile.NamedTemporaryFile()
    temp_short2 = tempfile.NamedTemporaryFile()
    temp_short2_1 = tempfile.NamedTemporaryFile()
    temp_short2_2 = tempfile.NamedTemporaryFile()

    assert 'file' in temp_short.name
    assert 'file' in temp_short2.name
    assert 'file' in temp_short2_1.name
    assert 'file' in temp_short2_2.name

    temp_short.close()
    temp_short2.close()
    temp_short2_1.close()
    temp_short2_2.close()

    file_writer = codecs.open(u'\u2603-ansible-tmp', 'w', encoding='utf-8')
    file_writer.write

# Generated at 2022-06-23 05:57:15.714583
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase(name='', isa='', required=False, default=None, static=False, always_post_validate=False)
    if  obj.validate() != obj:
        raise AssertionError("Expected (%s), got (%s)" % (obj, obj.validate()))
    return True


# Generated at 2022-06-23 05:57:25.039268
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import inspect

    class Source(object):
        pass

    class Parent(Source):
        def _get_attr_parent(self):
            return self._parent
        _parent = FieldAttribute(isa='str', inherit=True)

    class Child(Parent):
        _child = FieldAttribute(isa='str', inherit=True)

    parents = inspect.getmro(Child)
    dct = {'_child': FieldAttribute(isa='str', inherit=True)}

    ansible_base_meta = BaseMeta(__name__, parents, dct)

    assert hasattr(ansible_base_meta, '_attributes')
    assert hasattr(ansible_base_meta, '_attr_defaults')
    assert hasattr(ansible_base_meta, '_valid_attrs')

# Generated at 2022-06-23 05:57:33.416429
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class A(object):
        a = FieldAttribute(isa='string', default='A')
        b = FieldAttribute(isa='string', default='B')

    class B(object):
        a = FieldAttribute(isa='string', default='C')
        c = FieldAttribute(isa='string', default='D')

    class C(A, B):
        pass

    assert C.a == 'A'
    assert C.b == 'B'
    assert C.c == 'D'



# Generated at 2022-06-23 05:57:43.953971
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():

    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.base import Base
    class test_Base(Base):
        test_attribute = FieldAttribute(isa='str')
    test_base = test_Base()


# Generated at 2022-06-23 05:57:48.573089
# Unit test for method get_path of class Base
def test_Base_get_path():
    # TODO: Add test cases
    from six import StringIO

    a = Base()
    a._ds = StringIO("hello world")
    a._ds._line_number = 1
    assert a.get_path() == "hello world:1"


# Generated at 2022-06-23 05:57:56.725592
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # tests for method get_validated_value
    from ansible.module_utils.six import PY3
    attr = FieldAttributeBase()
    assert not attr.get_validated_value('name', attr, 'None', None)
    assert attr.get_validated_value('name', attr, None, None) is None
    assert attr.get_validated_value('name', attr, '123', None) == 123
    assert attr.get_validated_value('name', attr, '123', None) == 123 and not isinstance(attr.get_validated_value('name', attr, '123', None), bytes)

# Generated at 2022-06-23 05:57:58.831913
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    field_attribute = FieldAttributeBase()
    assert field_attribute.get_loader() == ['of', 'yaml', 'json']


# Generated at 2022-06-23 05:58:02.358772
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    """Test copy()"""

    a = FieldAttributeBase()
    b = a.copy()
    assert a == b
    a = FieldAttributeBase()
    b = a.copy()
    assert a is not b


# Generated at 2022-06-23 05:58:09.138884
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    cls = BaseMeta
    name = 'Test'
    parents = (object,)
    dct = {'_test': FieldAttribute(default=False)}
    method = '__new__'
    new_cls = cls.__new__(cls, name, parents, dct)
    assert getattr(new_cls, '_test', False)
    assert getattr(new_cls, '_attributes', False)
    assert getattr(new_cls, '_attr_defaults', False)
    assert getattr(new_cls, '_valid_attrs', False)


# Generated at 2022-06-23 05:58:21.237845
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Base:
        class __metaclass__(BaseMeta):
            pass

        class Attribute(Attribute):
            def __init__(self, default=None, validate=None, aliases=None, inherit=True):
                self.default = default
                self.validate = validate
                self.inherit = True
                self.aliases = aliases

        class FieldAttribute(FieldAttribute):
            def __init__(self, default=None, validate=None, aliases=None, inherit=True, required=False):
                self.default = default
                self.validate = validate
                self.inherit = True
                self.aliases = aliases
                self.required = required


# Generated at 2022-06-23 05:58:23.449722
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    assert_equal(obj.copy(), obj)

# Generated at 2022-06-23 05:58:26.366878
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # No exception should be thrown
    attr = FieldAttributeBase()
    attr.serialize()



# Generated at 2022-06-23 05:58:36.902718
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class MyParentClass(object):
        a = 'hi'
        b = 3
        c = {'d': 'e'}
        f = Attribute(required=True)
        g = Attribute(required=False)
        h = FieldAttribute(isidentifier=True, inherit=True)
        i = FieldAttribute(isidentifier=False, inherit=False)

    class MyClass(with_metaclass(BaseMeta, MyParentClass)):
        a = Attribute(default='hello')
        b = FieldAttribute(isidentifier=True)
        c = FieldAttribute(isidentifier=False)
        d = FieldAttribute(isidentifier=True, default='2')
        e = FieldAttribute(isidentifier=True, default='3', aliases=('e2', 'e3'))

# Generated at 2022-06-23 05:58:45.196701
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    args = dict(
        attribute=Mock(spec_set=FieldAttribute, isa='str', default='foo'),
        value='bar',
        obj=Mock(name='obj'),
    )
    ret = FieldAttributeBase(attribute=args['attribute'], value='bar', obj=args['obj'])
    obj = Mock(spec_set=FieldAttributeBase)
    ret.from_attrs = Mock(name='from_attrs')
    ret.from_attrs.return_value = ret._attribute = sentinel._attribute
    ret.from_json = Mock(name='from_json')
    ret.from_json.return_value = ret._attribute = sentinel._attribute
    obj._valid_attrs = {'foo': Mock(name='_valid_attrs_foo')}

# Generated at 2022-06-23 05:58:47.438764
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    base.deserialize(dict())


# *******************************************************************************


# Generated at 2022-06-23 05:58:57.974864
# Unit test for method deserialize of class FieldAttributeBase

# Generated at 2022-06-23 05:58:59.204122
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    a = FieldAttributeBase()
    assert isinstance(a, FieldAttributeBase)

# Generated at 2022-06-23 05:59:03.549772
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.play_context import PlayContext
    data_source = "~/play.yml"
    line_number = 1
    ds = PlayContext()
    ds._data_source = data_source
    ds._line_number = line_number
    a = Base()
    a._ds = ds
    assert a.get_path() == "%s:%s" % (data_source, line_number)


# Generated at 2022-06-23 05:59:16.490995
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    dump_attrs = FieldAttributeBase.dump_attrs
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()

# Generated at 2022-06-23 05:59:21.355712
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    base = FieldAttributeBase()
    base._valid_attrs = {
        "foo": FieldAttribute(isa='dict'),
        "bar": FieldAttribute(isa='list'),
    }
    base.foo = {}
    base.bar = []
    valid_attrs = base.dump_attrs()
    assert valid_attrs == {'foo': {}, 'bar': []}



# Generated at 2022-06-23 05:59:26.501391
# Unit test for method get_path of class Base
def test_Base_get_path():
    my_module = AnsibleModule()
    my_class = Base()
    my_class.module = my_module
    my_class._ds = os.path.abspath(__file__)
    my_class._ds._line_number = 11
    assert my_class.get_path() == os.path.abspath(__file__) + ":11"


# Generated at 2022-06-23 05:59:28.298878
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    meta = BaseMeta('TestClass', (), {})
    assert meta is not None
# EOC: Unit test for method __new__ of class BaseMeta


# Generated at 2022-06-23 05:59:30.376992
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    FieldAttributeBase.get_loader()

# Generated at 2022-06-23 05:59:39.998578
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.module_utils.six.moves import UserList

# Generated at 2022-06-23 05:59:42.974726
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    post_validate = FieldAttributeBase.post_validate.im_func
    assert post_validate(None, None, None) is None


# Generated at 2022-06-23 05:59:44.719114
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
  # FIXME: implement this test
  assert True


# Generated at 2022-06-23 05:59:52.401545
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class BaseMetaTest1():
        pass
    class BaseMetaTest2():
        pass
    class BaseMetaTest3(BaseMetaTest1, BaseMetaTest2):
        pass
    test_result = BaseMetaTest3.__bases__
    assert test_result == (BaseMetaTest1, BaseMetaTest2)

    class MyParent(Base):

        myfield = FieldAttribute(isa='string', inherit=False)

    class MyChild(MyParent):

        def _get_attr_myfield(self):
            return 'myfield'

    assert MyChild().myfield == 'myfield'



# Generated at 2022-06-23 05:59:55.113540
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    my_instance = FieldAttributeBase()
    result = my_instance.dump_attrs()
    assert result == {}


# Generated at 2022-06-23 05:59:57.673248
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    test_obj = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        test_obj.preprocess_data(ds=None, obj_loader=None)


# Generated at 2022-06-23 06:00:06.060521
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FAKE_INVENTORY_FILE = 'hosts'
    FAKE_INVENTORY_FOR_TEST = '''
    [test_hosts]
    localhost
    '''
    FAKE_TASK_FOR_TEST = '''
    - hosts: test_hosts
      tasks:
        - action:
            module: os
            args:
              cmd: "echo hello world"
        - action:
            module: os
            args:
              cmd: "echo hello world2"
    '''
    FAKE_PLAYBOOK_FOR_TEST = '''
    - hosts: test_hosts
      roles:
      - role: fake_role
        tasks_from: fake_task
    '''
    old_fake_dir = None
    old_fake_dir_2 = None
   

# Generated at 2022-06-23 06:00:08.118443
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = Base()
    assert obj.get_dep_chain()==None


# Generated at 2022-06-23 06:00:18.673319
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # setup
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import play
    import ansible.playbook.playbook
    import ansible.playbook.base
    reload(ansible.playbook.play)
    reload(ansible.playbook.playbook)
    reload(ansible.playbook.base)

    p = Play()
    t = Task()
    p.block = Block()
    p

# Generated at 2022-06-23 06:00:20.489344
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    """
    Test for method load_data of class FieldAttributeBase
    #TODO: provide test
    """
    pass


# Generated at 2022-06-23 06:00:28.504980
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    attributes = {
        'name': FieldAttribute(isa='string'),
        'age': FieldAttribute(isa='int', default=0, private=False),
        'sex': FieldAttribute(isa='bool', default=False, private=True)
    }

    class Person(FieldAttributeBase):
        _valid_attrs = attributes

        def __init__(self):
            super(Person, self).__init__()
            self.name = "test"
            self.age = 12

    p = Person()
    p_result = {
        "age": 12,
        "name": "test",
        "sex": False
    }
    assert(p.dump_attrs() == p_result), "dump attrs error"


# Generated at 2022-06-23 06:00:35.277760
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    with pytest.raises(TypeError):
        FieldAttributeBase()

    attribute = FieldAttributeBase(required=True)
    assert attribute.required is True
    assert attribute.static is False
    assert attribute.default is None
    assert attribute.always_post_validate is False
    assert attribute.listof is None
    assert attribute.class_type is None
    assert attribute.isa is None


# Generated at 2022-06-23 06:00:38.876452
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    set_trace()
    fieldAttributeBase = FieldAttributeBase()
    fieldAttributeBase.get_validated_value(name=None, attribute=None, value=None, templar=None)

# Generated at 2022-06-23 06:00:50.726371
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class Base(object):
        def __init__(self):
            self.foo = None

    base = Base()

    class BaseClass(FieldAttributeBase):
        def __init__(self):
            self.foo = FieldAttribute(isa='string', default='test_default')
            super(BaseClass, self).__init__()

    bc = BaseClass()
    bc.post_validate(base)
    assert base.foo == 'test_default'

    class BaseClass(FieldAttributeBase):
        def __init__(self):
            self.foo = FieldAttribute(isa='int', default='10')
            super(BaseClass, self).__init__()

    bc = BaseClass()
    bc.post_validate(base)
    assert base.foo == 10


# Generated at 2022-06-23 06:00:56.649667
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Set up mocked input data
    # No input data needed

    # set up the mocked AnsibleModule object
    am = AnsibleModuleMock()

    # set up the mocked Task object
    task = Task()

    # run the method under test
    result = task.dump_me()

    # make all assertions
    assert result is not None
    assert isinstance(result, dict)
    
test_FieldAttributeBase_dump_me()


# Generated at 2022-06-23 06:00:59.193915
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    f = FieldAttributeBase()
    assert isinstance(f.get_ds(), FieldAttributeBase) == True

# Generated at 2022-06-23 06:01:03.511517
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    b._parent._play._ds._data_source = 'test1'
    b._parent._play._ds._line_number = 'test2'
    assert b.get_dep_chain() is None
    assert b.get_path() == 'test1:test2'


# Generated at 2022-06-23 06:01:11.560539
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    c = FieldAttributeBase()
    c._valid_attrs['name'] = FieldAttribute(isa='string', default='some_name', static=False, always_post_validate=False)
    c._valid_attrs['args'] = FieldAttribute(isa='list', default=[], always_post_validate=False)
    c.name = 'something'
    c.args = ['banana', 'grape']
    d = c.dump_attrs()
    assert d['name'] == 'something'
    assert d['args'] == ['banana', 'grape']

# Generated at 2022-06-23 06:01:21.986952
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    from ansible.playbook.attribute import FieldAttribute

    class Foo(object):
        class Meta:
            test = FieldAttribute(isa='str')

    class Bar(Foo):
        class Meta:
            test2 = FieldAttribute(isa='str', inherit=True)

    class Baz(Bar):
        class Meta:
            test3 = FieldAttribute(isa='str')

    a = Foo()
    assert 'test' not in vars(a)
    try:
        a.test
    except AttributeError as e:
        assert 'does not exist' in str(e)
    try:
        a.test = 'a'
        del a.test
    except AttributeError as e:
        assert 'does not exist' in str(e)

    b = Bar()
    assert 'test' not in vars(b)


# Generated at 2022-06-23 06:01:33.173107
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase
    value = "test"
    attr = FieldAttributeBase(value, isa='string')
    # Initialize the object 
    test = BaseObject()
    setattr(test, 'name', attr)
    ansible_vars = {'test': ['one', 'two']}
    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=ansible_vars))
    # Run the method under test
    test.post_validate(templar)
    # Check the expected results
    assert test.name == "test"
    # Create an instance of FieldAttributeBase
    value = "test"
    attr = FieldAttributeBase(value, isa='string')
    # Initialize the object 
    test = BaseObject()

# Generated at 2022-06-23 06:01:42.357682
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    a = FieldAttributeBase(type='str', default='foo', always_post_validate=False)
    assert a.type == 'str'
    assert a.default == 'foo'
    assert a.always_post_validate is False

    try:
        a = FieldAttributeBase()
    except:
        pass
    else:
        assert False

    a = FieldAttributeBase(type='str', default='foo', required=True)
    try:
        a = FieldAttributeBase(type='str', default='foo', required=True, choices=['foo', 'bar'])
    except:
        pass
    else:
        assert False

    a = FieldAttributeBase(type='str', default='foo', choices=['foo', 'bar'])

# Generated at 2022-06-23 06:01:55.246406
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test for method __new__ of class BaseMeta
    # use mock class to record the attributes
    class MockClass():
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}
        _attr_name = None
        _value = None
        _inherit = False
        _alias = None
        def __init__(self, attr_name, value=None, inherit=False, alias=None):
            self._attr_name = attr_name
            self._value = value
            self._inherit = inherit
            self._alias = alias
        def __get__(self, obj, val=None):
            return self._value

    # set mock class to metaclass
    BaseMeta.Attr = MockClass

    # collect attributes for creating

# Generated at 2022-06-23 06:02:05.544753
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Set up mock objects
    d = dict()
    attr = mock.MagicMock()
    attribute = mock.MagicMock()
    attribute.always_post_validate = True
    attr.get.return_value = attribute
    d['attr'] = attr
    attribute.static = False
    attribute.required = False
    res = dict()
    res['attr'] = 'value'

    # Call method
    assert FieldAttributeBase().squash(
        d,
        res,
        'attr',
        'value',
        True
    ) == None
    d['attr'].get.assert_called_once_with('always_post_validate')
    d['attr'].set.assert_called_once_with('always_post_validate', True)
    assert d['attr'].static is True


# Generated at 2022-06-23 06:02:08.979581
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    test_instance = Base()
    assert test_instance.get_dep_chain() == None


# Generated at 2022-06-23 06:02:11.449141
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()

    result = obj.copy()
    assert isinstance(result, FieldAttributeBase)
    assert result == obj


# Generated at 2022-06-23 06:02:21.314002
# Unit test for constructor of class Base
def test_Base():
    from units.mock.loader import DictDataLoader

    # test empty constructor
    b = Base()
    assert not b._finalized
    assert not b._squashed
    assert not b._uuid

    # test constructor with data with module_defaults

# Generated at 2022-06-23 06:02:25.573321
# Unit test for method get_path of class Base
def test_Base_get_path():
    class fake_data_source():
        def __init__(self):
            pass

        def __str__(self):
            return "fake_data_source.__str__"

    class fake_parent():
        def __init__(self):
            pass

        def __str__(self):
            return "fake_parent.__str__"

    class fake_play():
        def __init__(self):
            self._ds = fake_data_source()
            self._line_number = 8

        def __str__(self):
            return "fake_play.__str__"

    class fake_Base(Base):
        def __init__(self):
            self._ds = fake_data_source()
            self._line_number = 8
            self._parent = fake_parent()
            self._parent._play = fake

# Generated at 2022-06-23 06:02:37.961906
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    '''
    Unit test for method deserialize of class FieldAttributeBase
    '''
    # Imports required for test
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import json

    # Init vars
    data = dict()
    callback = CallbackBase()
    variable_manager = VariableManager()
    loader = variable_manager.loader

    # Create LocalTemplar

# Generated at 2022-06-23 06:02:39.347874
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    pass


# Generated at 2022-06-23 06:02:50.667916
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    class Test(object):
        def serialize(self):
            return {}

    repr = {'name': 'test'}
    data = {'name': 'test'}

    # test invalid data
    invalid_data = 'invalid data'
    try:
        FieldAttributeBase.deserialize(invalid_data)
    except AnsibleAssertionError:
        pass
    else:
        assert False, 'Expected AnsibleAssertionError'

    # test data
    new_repr = {'name': 'test'}
    new_data = {'name': 'test'}

    assert FieldAttributeBase.deserialize(repr, data) == new_repr
    assert data == new_data

    # test alias value

# Generated at 2022-06-23 06:02:55.082342
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Method: get_variable_manager:
    #      Return: VariableManager object
    #
    # test_output1 = get_variable_manager()
    # assert test_output1 == VariableManager(), 'test_output1 is not correct'
    pass
