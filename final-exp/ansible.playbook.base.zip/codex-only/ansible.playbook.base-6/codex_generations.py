

# Generated at 2022-06-23 05:52:57.753518
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-23 05:53:01.271770
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
  fake_templar = create_autospec(Templar,spec_set=True,instance=True)
  a = FieldAttributeBase()
  a.post_validate(fake_templar)


# Generated at 2022-06-23 05:53:04.204760
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FieldAttributeBase()
    assert attr.post_validate() is None, "method post_validate() should return None"


# Generated at 2022-06-23 05:53:14.323668
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    dict_ds = dict()
    dict_ds['ds'] = dict()
    dict_ds['ds']['name'] = 'play'
    dict_ds['ds']['playbook'] = 'playbook'
    dict_ds['ds']['_line'] = 50
    dict_ds['ds']['_parent'] = dict()
    dict_ds['ds']['_parent']['ds'] = dict()
    dict_ds['ds']['_parent']['ds']['_line'] = 50
    dict_ds['ds']['_parent']['ds']['_parent'] = dict()
    dict_ds['ds']['_parent']['ds']['_parent']['ds'] = dict()

# Generated at 2022-06-23 05:53:18.166662
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    import abc
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import add_metaclass
    # test FieldAttributeBase.dump_me()
    args = dict(
        name='name',
        default=None,
        required=True,
        private=False,
        static=None,
        isa=None,
        always_post_validate=False,
        listof=None,
        class_type=None,
    )
    fa = FieldAttributeBase(**args)
    assert fa.dump_me() == args


# Generated at 2022-06-23 05:53:27.451700
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class ValidParentObject:
        attr_one = FieldAttribute(isa='string', default='one')
        attr_two = FieldAttribute(isa='string', default='two')

    class ValidBaseObject(Base, ValidParentObject):
        attr_three = FieldAttribute(isa='string', default='three')

    assert 'attr_one' in ValidBaseObject.__dict__
    assert 'attr_two' in ValidBaseObject.__dict__
    assert 'attr_three' in ValidBaseObject.__dict__

    assert '_attributes' in ValidBaseObject.__dict__
    assert '_attr_defaults' in ValidBaseObject.__dict__
    assert '_valid_attrs' in ValidBaseObject.__dict__
    assert '_alias_attrs' in ValidBaseObject.__dict__



# Generated at 2022-06-23 05:53:28.080218
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-23 05:53:32.558473
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    task = Base()
    task.get_path = Mock(return_value='')
    task.get_dep_chain = Mock(return_value='dependencychain')

    #return the list of paths you should search for files
    task.get_search_path()


# Generated at 2022-06-23 05:53:33.216555
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass

# Generated at 2022-06-23 05:53:34.354437
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    raise SkipTest # (yet) no tests implemented



# Generated at 2022-06-23 05:53:35.637718
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    pass # no code



# Generated at 2022-06-23 05:53:43.816977
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    data = {'key':'value'}
    attribute = 'attribute'
    value = 'value'
    parent_object = 'parent_object'
    ansible_object = 'ansible_object'
    loader = 'loader'
    variable_manager = 'variable_manager'
    fail_on_undefined = 'fail_on_undefined'
    depth = 'depth'
    parent_attrs = {'parent_attrs':'parent_attrs'}
    validate_only = 'validate_only'
    ignore_errors = 'ignore_errors'
    aliases = 'aliases'
    base_class = 'base_class'
    include_name = 'include_name'
    task_loader = 'task_loader'

# Generated at 2022-06-23 05:53:47.845328
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    assert FieldAttributeBase().preprocess_data(1, 1) == 1


# Generated at 2022-06-23 05:53:52.990094
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # [ ('_', None), ('_', None), ('_', None), ('_', None), ('_', None), ('_', None), ('_', None), ('_', None), ('_', None), ('_', None)
    pass

# Generated at 2022-06-23 05:54:02.558594
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # Create an instance of class AnsibleMapping
    ds = AnsibleMapping()

    # Create an instance of class FieldAttributeBase
    f = FieldAttributeBase('my_attr', ds=ds, always_post_validate=True)

    # Create an instance of class Base
    b = Base()

    # Create an instance of class VariableManager
    v = VariableManager()

    # Create an instance of class AnsibleTemplar
    t = AnsibleTemplar(variable_manager=v)

    # Call method post_validate of class FieldAttributeBase with parameters: b, t
    f.post_validate(b, t)


# Generated at 2022-06-23 05:54:10.874325
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    target = FieldAttributeBase()
    name = loader.load("""{% if foo == 'bar' %}baz{% else %}qux{% endif %}""")
    value = loader.load("""{% if foo == 'bar' %}baz{% else %}qux{% endif %}""")

    result = target.squash(name, value, loader)

    assert result == dict(name='baz', value='baz')

# Generated at 2022-06-23 05:54:21.005048
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    _create_attrs = lambda src_dict, dst_dict: True
    _process_parents = lambda parents, dst_dict: True
    _new_BaseMeta = lambda name, parents, dct: True
    setattr(_new_BaseMeta, '__bases__', object)
    setattr(_new_BaseMeta, '__name__', 'BaseMeta')
    _new_BaseMeta.attr_name = 'attr_name'
    _new_BaseMeta.attr_alias = 'attr_alias'
    _new_BaseMeta.src_dict = {}
    _new_BaseMeta.dct = {}
    _new_BaseMeta.parents = []
    _new_BaseMeta._attributes = {}
    _new_BaseMeta._attr_defaults = {}
    _new_BaseMeta._valid_attrs = {}
    _

# Generated at 2022-06-23 05:54:24.624660
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    x = FieldAttributeBase()
    attrs = {}
    try:
        x.from_attrs(attrs)
    except Exception as e:
        assert type(e) is AssertionError


# Generated at 2022-06-23 05:54:35.264514
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.utils.vars import combine_vars
    Base = BaseMeta("Base",object,{})
    class task(with_metaclass(Base, object)):
        def __init__(self,play,var=None):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}
            self.play = play
            self.var = var
        def __getattribute__(self,name):
            return super(task,self).__getattribute__(name)

    play = task(play, var=None)
    play.__new__()
    assert True

# Generated at 2022-06-23 05:54:39.231473
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    t = FieldAttributeBase()

    assert t.get_ds() == None



# Generated at 2022-06-23 05:54:42.428777
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Testing for TypeError raised when 'data' is not a dictionary
    attr = FieldAttributeBase('foo', 'bool')
    assert_raises(AnsibleAssertionError, attr.serialize, "this is not a dict")


# Generated at 2022-06-23 05:54:55.075714
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    class TestClass(object):
        def __init__(self):
            self._loader = None
            self._variable_manager = None
#            self._loader = AnsibleLoader(self._find_needle('library'), config.get_config_value('DEFAULT_MODULE_PATH'))

    def setUp(self):
        self.instance = TestClass()
        self.attr_base = FieldAttributeBase(self.instance)
        self.attr_base.__name__ = '_loader'

    def test_get_loader__no_attribute(self):
        self.assertIsNone(self.attr_base.get_loader())

    def test_get_loader__attribute_exists(self):
        self.attr_base.__value__ = True
        self.assertTrue(self.attr_base.get_loader())
#

# Generated at 2022-06-23 05:54:58.552668
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    data = dict(
        _task=dict(
        )
    )
    assert FieldAttributeBase.get_variable_manager(ansible_module_dict=data) == data.get('_task')


# Generated at 2022-06-23 05:55:10.277263
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.attribute import FieldAttributeBase
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.port = 22
    play_context.remote_addr = '10.10.10.10'
    play_context.remote_user = 'harry'
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'bob'
    play_context.become_pass = '123'

# Generated at 2022-06-23 05:55:13.195586
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    f = FieldAttributeBase(loader=False, attribute=True, default=True, always_post_validate=True, read_only=True)
    assert f.get_loader() == False

# Generated at 2022-06-23 05:55:21.173211
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class FakeFieldAttributeBase(FieldAttributeBase):
        def __init__(self):
            self.name = 'fake'

        _valid_attrs = dict(
            foo=FieldAttribute(isa='str'),
            bar=FieldAttribute(isa='int', default=42),
            foobar=FieldAttribute(isa='dict', default={'locked': True}),
            baz=FieldAttribute(isa='class', class_type='ansible.parsing.dataloader.DataLoader'),
        )

    obj = FakeFieldAttributeBase()

# Generated at 2022-06-23 05:55:31.264754
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = Task()
    obj.argspec = {"spec": [], "defaults": None, "varargs": None, "keywords": None, "kwonlyargs": [], "kwonlydefaults": None, "annotations": {}}
    target = Task()
    target.argspec = {"spec": [], "defaults": None, "varargs": None, "keywords": None, "kwonlyargs": [], "kwonlydefaults": None, "annotations": {}}
    try:
        assert obj.copy(target) == target
    except Exception as e:
        pytest.fail("Exception in test_copy: message={}, exception={}".format(e.message, type(e)))


# Generated at 2022-06-23 05:55:39.779065
# Unit test for constructor of class BaseMeta
def test_BaseMeta():

    # pylint: disable=too-few-public-methods
    class A(Base):
        foo = 'bar'

    class B(A):
        _foo = 'baz'

    class C(B):
        _foo = 'quz'

    res = C()._foo
    assert res == 'baz'



# Base class for all Ansible objects, which provides a number of common
# methods and attributes.
#
# This base class has a metaclass, which automatically creates the attributes
# for the object based on FieldAttribute and Attribute objects.

# Generated at 2022-06-23 05:55:42.493517
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    f = FieldAttributeBase()
    ds = dict()
    r = f.get_ds(ds)
    assert r == ds



# Generated at 2022-06-23 05:55:52.033130
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    #Tests if the dump_attrs method is working as intended.
    attr = BaseObject()

# Generated at 2022-06-23 05:55:52.950352
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    with pytest.raises(TypeError):
        FieldAttributeBase('required')


# Generated at 2022-06-23 05:55:57.846957
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    my_obj = FieldAttributeBase()
    my_var_mgr = my_obj.get_variable_manager()
    my_obj.set_variable_manager('my_var_mgr')
    my_obj.get_variable_manager()


# Generated at 2022-06-23 05:56:10.608839
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fixture_fd = open('../../lib/ansible/parsing/mod_args.yaml')
    fixture_data = yaml.safe_load(fixture_fd)
    fixture_fd.close()

    data = copy.deepcopy(fixture_data)
    attribute = FieldAttribute()
    attribute.name = 'foo'

    result = attribute.load_data(data)

    # Assertion 1
    assert result is data

    # Assertion 2
    assert len(attribute.aliases) == len(fixture_data['aliases'])
    assert attribute.aliases == fixture_data['aliases']

    # Assertion 3
    assert attribute.default == fixture_data['default']

    # Assertion 4
    assert attribute.required == fixture_data['required']

    # Assertion 5
   

# Generated at 2022-06-23 05:56:20.091954
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Not a great test at this point as it doesn't test any logic.
    # Just a smoke test.
    obj = FieldAttributeBase()
    obj._alias_attrs = {}
    obj._valid_attrs = {}
    obj._attributes = {}
    obj._attr_defaults = {}
    obj._loader = None
    obj._variable_manager = None
    obj._validated = False
    obj._finalized = False
    obj._uuid = None
    result = obj.dump_me()
    assert result is not None
    #assert len(result) == 6



# Generated at 2022-06-23 05:56:21.950016
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass

# Generated at 2022-06-23 05:56:23.837219
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    a = FieldAttributeBase(isa='test', default=True)
    assert a.get_ds()


# Generated at 2022-06-23 05:56:32.886989
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    This is the unit test for method get_dep_chain of class Base
    It tests the functionality of method by passing a mock 'self' instance to the method
    '''
    base_instance = Base()
    print('Testing get_dep_chain of class Base')
    try:
        base_instance.get_dep_chain()
    except AttributeError as e:
        print('Caught AttributeError exception:', e)
        print('Testcase passed: get_dep_chain()')
    else:
        print('Testcase failed: get_dep_chain()')


# Generated at 2022-06-23 05:56:33.298478
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass



# Generated at 2022-06-23 05:56:39.383304
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # In case of AnsibleCollectionRef
    # `ansible` is not defined, so `CollectionInventory` is not loaded
    # at the time of this test run, hence we need to mock it
    import mock
    with mock.patch("ansible.module_utils.facts.collection_loader.AnsibleCollectionRef"):
        a = BaseMeta("a", (object,), {})
        assert hasattr(a, "_attributes")
        assert hasattr(a, "_attr_defaults")
        assert hasattr(a, "_valid_attrs")
        assert hasattr(a, "_alias_attrs")



# Generated at 2022-06-23 05:56:40.808454
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # FIXME: need to write unit test for FieldAttributeBase

    pass


# Generated at 2022-06-23 05:56:46.097573
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    Make sure that we get the value from the attribute
    '''
    field_attribute_base = FieldAttributeBase(name='something', required=True, static=True)
    assert field_attribute_base.dump_me() == 'something'

# Generated at 2022-06-23 05:56:48.389688
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base._valid_attrs = {}
    assert field_attribute_base.serialize() == {}



# Generated at 2022-06-23 05:56:49.285824
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-23 05:56:56.202083
# Unit test for method get_path of class Base
def test_Base_get_path():
    parent_parent_obj=Base()
    parent_obj=Base()
    parent_obj._parent=parent_parent_obj
    test_obj=Base()
    test_obj._parent=parent_obj
    test_obj._ds=Base()
    test_obj._ds._data_source="test_data_source"
    test_obj._ds._line_number="test_line_number"
    assert test_obj.get_path()=="test_data_source:test_line_number"

# Generated at 2022-06-23 05:57:03.384073
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    def _create_attrs(src_dict, dst_dict):
        '''
        Helper method which creates the attributes based on those in the
        source dictionary of attributes. This also populates the other
        attributes used to keep track of these attributes and via the
        getter/setter/deleter methods.
        '''
        keys = list(src_dict.keys())
        for attr_name in keys:
            value = src_dict[attr_name]
            if isinstance(value, Attribute):
                if attr_name.startswith('_'):
                    attr_name = attr_name[1:]

                # here we selectively assign the getter based on a few
                # things, such as whether we have a _get_attr_<name>
                # method, or if the attribute is marked as not inheriting

# Generated at 2022-06-23 05:57:08.726673
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Car(object):
        wheel = FieldAttribute(isa='int', inherit=True)

    class Racecar(Car):
        wheel = FieldAttribute(isa='int')

    # construct metaclass
    class MyMeta(BaseMeta):
        pass

    # construct some test classes
    class MyClass1(Car):
        __metaclass__ = MyMeta
        wheel = FieldAttribute(isa='int')

        def _get_attr_wheel(self):
            return self._attributes['wheel'] + 1

    class MyClass2(MyClass1):
        wheel = FieldAttribute(isa='int')

    # test creation of classes
    assert type(MyClass1.wheel) == property
    assert type(MyClass2.wheel) == property

    # test the order of attribute resolution
    mc1 = MyClass1()
    mc2 = My

# Generated at 2022-06-23 05:57:13.478226
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Test the from_attrs method of FieldAttributeBase
    '''
    class TestObj(object):
        attr1 = FieldAttribute()

    to = TestObj()
    to.from_attrs({'attr1': 100})
    assert to.attr1 == 100, 'Expected that attribute is set by from_attrs method'



# Generated at 2022-06-23 05:57:21.027789
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Base(object):
        __metaclass__ = BaseMeta
        foo = Attribute()
        def _get_attr_foo(self):
            return 42
    class Test(Base):
        bar = Attribute()
        def __init__(self):
            super(Test, self).__init__()
            self.foo = 1
            self.bar = 2
    instance = Test()
    assert instance.foo == 42
    assert instance.bar == 2
    instance.bar = 1
    assert instance.bar == 1
    del instance.bar
    assert instance.bar == None


# Generated at 2022-06-23 05:57:29.285926
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['logical-interconnect-groups.yml'])
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='win_ping', args=''))
    ]), variable_manager=variable_manager, loader=loader)
    tqm = None

# Generated at 2022-06-23 05:57:41.498050
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create a class object and an attribute object.
    class_type = object
    attribute = FieldAttribute(isa='string')
    # Get the get_validated_value method of the class object.
    class_get_validated_value = class_type.get_validated_value
    # Create the FieldAttributeBase object.
    field_attribute_base_ = class_type(attribute)
    # Make a call to method get_validated_value of the FieldAttributeBase object with valid parameters.
    result1 = field_attribute_base_._get_validated_value('attribute', attribute, 42, 'templar')
    assert result1 == 42
    # Make a call to method get_validated_value of the FieldAttributeBase object with valid parameters.

# Generated at 2022-06-23 05:57:52.557491
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    from .action import ActionBase
    from .play import Play
    from .play import PlayContext
    from .play import PlayException
    
    # Test cases that might be good:
    #  Play() - many fields, simple and complex types
    #  PlayContext() - many fields, simple and complex types
    #  Task() - many fields, simple and complex types
    #  ActionBase() - simple types
    


# Generated at 2022-06-23 05:57:59.253674
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class A(object):
        a = FieldAttribute(isa='string')
        _b = FieldAttribute(isa='bool')

    # Test for class attributes
    assert A._valid_attrs['a'] == A.a
    assert A._valid_attrs['b'] == A._b
    assert A._valid_attrs['b'].alias == 'b'
    assert A._alias_attrs['b'] == '_b'

    # Test for properties
    assert A._attributes['_b'] is Sentinel
    a = A()
    assert a._attributes['_b'] is Sentinel
    a.b = True
    assert a._attributes['_b']

    # Test for property access
    assert A._valid_attrs['a'].default is None
    assert a.a is None
    a.a = 'hello'

# Generated at 2022-06-23 05:58:00.266282
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # TODO: implement this one
    pass

# Generated at 2022-06-23 05:58:09.564064
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    bad_type = 'dict'
    good_type = 'str'
    good_default = 'hi'
    good_isa = 'string'

    # Parameter validation
    # The message and raise statements for errors need to be identical,
    # and the types need to be the same, because the result is a regex match
    # The message is why the type is required, and the raise statement is what actually raises the error
    # In production, the error should have this exact message as well

    # Test for invalid type
    try:
        temp_attr = FieldAttributeBase(bad_type)
    except TypeError as e:
        assert 'type' in str(e)
        raise
    assert False, 'No exception was raised'

    # Test for invalid default

# Generated at 2022-06-23 05:58:21.483828
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test case 1
    def _create_attrs(src_dict, dst_dict):
        '''
        Helper method which creates the attributes based on those in the
        source dictionary of attributes. This also populates the other
        attributes used to keep track of these attributes and via the
        getter/setter/deleter methods.
        '''
        keys = list(src_dict.keys())
        for attr_name in keys:
            value = src_dict[attr_name]
            if isinstance(value, Attribute):
                if attr_name.startswith('_'):
                    attr_name = attr_name[1:]

                # here we selectively assign the getter based on a few
                # things, such as whether we have a _get_attr_<name>
                # method, or if the attribute

# Generated at 2022-06-23 05:58:33.000657
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

    task_path = "/tmp/ansible/foo/bar/tasks/main.yml"
    play_path = "/tmp/ansible/foo/bar/play.yml"
    role_path = "/tmp/ansible/foo/bar/roles/myrole"
    rolepaths = [role_path, play_path, task_path]
    dflt_ds = DataSource(task_path)
    role_ds = DataSource(role_path)
    play = Play()
    play._ds = DataSource(play_path)

    base = Base()

# Generated at 2022-06-23 05:58:37.861665
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
  obj = FieldAttributeBase(type)

  # Call method
  try:
    obj.squash()
  except NotImplementedError as err:
    # Check if Exception has been raised as expected
    assert type(err) == NotImplementedError
  else:
    # If no exception was raised, but expected, report error
    pytest.fail('ExpectedException not raised')


# Generated at 2022-06-23 05:58:48.709086
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    arg1 = FieldAttributeBase(isa='one', required=False)
    arg2 = FieldAttributeBase(isa='two', required=False)

    attrs = [arg1, arg2]

    def _squash_fake_method(obj):
        # This fakes the squash method which is added via the metaclass
        return obj

    for attr in attrs:
        attr.squash = _squash_fake_method

    # Normal use case
    test1 = FieldAttributeBase.squash(attrs)
    assert test1 == attrs

    # Test with None
    test2 = FieldAttributeBase.squash([None])
    assert test2 is None

    # Test with string
    test3 = FieldAttributeBase.squash(['string'])
    assert test3 == 'string'

    # Test with int
    test

# Generated at 2022-06-23 05:58:58.972018
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    import test_utils
    
    attr = dict(
    )

# Generated at 2022-06-23 05:59:05.806844
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
  if False:
    # Create a class to populate the test environment
    class TestClass(object):
      def __init__(self):
        self.test_object = FieldAttributeBase()
        self.test_value = "Test value for FieldAttributeBase"
  t = TestClass()
  # Testing method copy of class FieldAttributeBase
  t.test_object.copy(t.test_value)

# Generated at 2022-06-23 05:59:06.593100
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    pass

# Generated at 2022-06-23 05:59:19.180534
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.name = 'name'
    field_attribute_base.required = True
    field_attribute_base.static = False
    field_attribute_base.isa = 'string'
    field_attribute_base.listof = []
    field_attribute_base.default = {}
    field_attribute_base.always_post_validate = False
    field_attribute_base.fallback = (None,)
    field_attribute_base.aliases = []
    field_attribute_base.class_type = None
    field_attribute_base.deprecated = ('2.0', 'foo category')
    field_attribute_base.pii = False
    field_attribute_base.sample = []
    field_attribute_base.parse_default = False

    repr = field_

# Generated at 2022-06-23 05:59:23.312624
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_warnings

    mocked_ansible_module = Mock(name='mocked_ansible_module')
    mocked_ansible_module.configure_mock(name='Mocked Module')
    mocked_ansible_module.fail_json.side_effect = AnsibleFailJson

# Generated at 2022-06-23 05:59:27.816601
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    task=Task()
    task._parent=Play()
    assert task.get_dep_chain()==(task._parent.get_dep_chain())
    play = Play()
    play._parent = Playbook()
    assert play.get_dep_chain() == (play._parent.get_dep_chain())
    assert Base().get_dep_chain() == None

# Generated at 2022-06-23 05:59:29.985913
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    FieldAttributeBase()
####

# Generated at 2022-06-23 05:59:30.501013
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass



# Generated at 2022-06-23 05:59:35.369299
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FieldAttributeBase = ansible_collections.ansible.community.plugins.module_utils.common.FieldAttribute
    ds = None
    testobj = FieldAttributeBase(name='test', isa='test', private=False, default=None, always_post_validate=False, deprecated_versions=[], removed_versions=[])
    testobj.load_data(ds)


# Generated at 2022-06-23 05:59:49.721336
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    my_task = Base()
    my_task._parent = mock.Mock()
    my_task._parent.__class__ = 'Play'
    my_task._parent._ds = mock.Mock()
    my_task._parent._ds._line_number = '1'
    my_task._parent._ds._data_source = 'test.yaml'
    my_task._parent._play = mock.Mock()
    my_task._parent._play._ds = mock.Mock()
    my_task._parent._play._ds._line_number = '1'
    my_task._parent._play._ds._data_source = 'test.yaml'

    my_task._parent._play._parent = mock.Mock()
    my_task._parent._play._parent.__class__ = 'Role'
    my

# Generated at 2022-06-23 05:59:56.632907
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # Test new instance without parameters
    a = FieldAttributeBase()
    assert isinstance(a, FieldAttributeBase)
    assert isinstance(a.get_loader(), DataLoader)
    _loader = DataLoader()
    a = FieldAttributeBase(loader=_loader)
    assert isinstance(a, FieldAttributeBase)
    assert isinstance(a.get_loader(), DataLoader)

# Generated at 2022-06-23 06:00:03.754779
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    This is a unit test function for FieldAttributeBase
    '''

    attribute = FieldAttributeBase()
    assert attribute.name is None
    assert attribute.class_name is None
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.always_post_validate is False
    assert attribute.static is False

    attribute = FieldAttributeBase()
    assert attribute.name == 'name'
    assert attribute.class_name == 'class_name'
    assert attribute.default == 'default'
    assert attribute.required == False
    assert attribute.always_post_validate == False
    assert attribute.static == False


# Generated at 2022-06-23 06:00:08.544313
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Simple test to ensure that dump_attrs only returns field attributes
    obj = DummyClass()
    data = obj.dump_attrs()
    assert data.get('valid_attrs') is None
    assert data.get('_validated') is None



# Generated at 2022-06-23 06:00:13.365163
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    method = getattr(FieldAttributeBase, 'preprocess_data')

    # test with no args
    method()

    # test with invalid class
    try:
        method('invalid')
    except ValueError:
        None

    # test with valid class
    method(BaseObject)


# Generated at 2022-06-23 06:00:17.609654
# Unit test for method get_path of class Base
def test_Base_get_path():
    base1 = Base()
    base2 = Base()
    try:
        # debug_msg = base1.get_path()
        print("debug_msg=", debug_msg)
    except Exception as e :
        print(e)

    try:
        # debug_msg = base2.get_path()
        print("debug_msg=", debug_msg)
    except Exception as e :
        print(e)


# Generated at 2022-06-23 06:00:21.660402
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    # Test with default args
    data = FieldAttributeBase()
    target = FieldAttributeBase(data)
    assert target.static == False
    assert target.default == None
    assert target.required == True
    assert target.secret == False
    assert target.hash_name == True



# Generated at 2022-06-23 06:00:23.153978
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase()
    assert obj.squash() == {}


# Generated at 2022-06-23 06:00:35.643053
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class TestClass(Base):
        myfield = FieldAttribute(isa='string')

    # invalid isa
    try:
        class TestClass(Base):
            myfield = FieldAttribute(isa='invalid')
    except ValueError:
        pass

    # valid isa
    class TestClass(Base):
        myfield = FieldAttribute(isa='string')

    # valid isa, with default
    class TestClass(Base):
        myfield = FieldAttribute(isa='string', default='mydefault')

    # valid isa, with default, class_type
    class TestClass(Base):
        myfield = FieldAttribute(isa='class', class_type=TestClass, default='mydefault')

    # valid isa, with default, class_type

# Generated at 2022-06-23 06:00:40.822835
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    mock = MagicMock()
    mock.res = True
    # mock.assert_called_once_with()
    mock.assert_called_once_with()
    mock.assert_any_call()
    mock.return_value = True
    mock.return_value = False

    fa = FieldAttributeBase()
    result_val = fa.squash()

    assert result_val == False

# Generated at 2022-06-23 06:00:43.582760
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    FAObject = FieldAttributeBase()
    FAObject.deserialize({'task_name': 'test_task'})

# Generated at 2022-06-23 06:00:44.839932
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass


# Generated at 2022-06-23 06:00:54.704812
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Parent(object):
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

        def __getattr__(self, attr_name):
            try:
                return self._attributes[attr_name]
            except KeyError:
                raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, attr_name))

    class Child(Parent):
        a_attr = Attribute()
        a_attr.inherit = True
        a_attr.default = 'b'
        b_attr = Attribute()
        b_attr.inherit = True
        b_attr.default = 'c'


# Generated at 2022-06-23 06:01:05.029904
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    def test_attr(attr, empty=False):
        '''
        Test that attr is of FieldAttributeBase type
        '''
        if empty:
            assert isinstance(attr, FieldAttributeBase)
        else:
            assert False == isinstance(attr, FieldAttributeBase)

    # Test that an empty dict is not a valid attribute
    try:
        attr = FieldAttributeBase({})
        test_attr(attr, empty=True)
    except (AssertionError, TypeError):
        assert True

    # Test that an empty dict with a non-empty class_type is not a valid attribute
    try:
        attr = FieldAttributeBase({}, class_type=FakeTaskResult)
        test_attr(attr, empty=True)
    except (AssertionError, TypeError):
        assert True

    # Test that an

# Generated at 2022-06-23 06:01:07.161042
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    ds = {'key': 'value'}
    my_obj = FieldAttributeBase()
    assert my_obj.load_data(ds) == 'value'



# Generated at 2022-06-23 06:01:08.294949
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass


# Generated at 2022-06-23 06:01:11.951404
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Try simple copy
    fa_bf = FieldAttributeBase(isa='bool')
    fa_bf.copy()
    
    
    assert True

# Generated at 2022-06-23 06:01:19.320938
# Unit test for method get_path of class Base
def test_Base_get_path():
    class dummyClass():
        def __init__(self, ds, line_number):
            self._data_source = ds
            self._line_number = line_number
    class dummyClass2():
        def __init__(self, ds, line_number):
            self._ds = ds
            self._line_number = line_number
    class dummyClass3():
        def __init__(self, ds, line_number):
            self._play = dummyClass2(ds, line_number)
    b1 = Base()
    b1.set_ds(dummyClass("/testDir/test.yml", 4))
    assert b1.get_path() == "/testDir/test.yml:4"
    b2 = Base()

# Generated at 2022-06-23 06:01:28.445273
# Unit test for constructor of class Base
def test_Base():
    obj = Base()
    assert obj._name == ''
    assert obj._vars == {}
    assert obj._module_defaults == []
    assert obj._environment == []
    assert obj._no_log == False
    assert obj._run_once == False
    assert obj._ignore_errors == False
    assert obj._check_mode == context.CLIARGS['check']
    assert obj._diff == context.CLIARGS['diff']
    assert obj._any_errors_fatal == C.ANY_ERRORS_FATAL
    assert obj._become == context.CLIARGS['become']
    assert obj._become_method == context.CLIARGS['become_method']
    assert obj._become_user == context.CLIARGS['become_user']

# Generated at 2022-06-23 06:01:34.159537
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert b._name == ''
    assert b._connection == C.DEFAULT_TRANSPORT
    assert b._port is None
    assert b._remote_user == 'root'
    assert b._vars == {}
    assert b._module_defaults == []
    assert b._any_errors_fatal is False
    assert b._check_mode is False
    assert b._diff is None
    assert b._become is False
    assert b._become_method == 'sudo'
    assert b._become_user == 'root'
    assert b._become_flags == '-H'
    assert b._become_exe is None

# -- end base class --



# Generated at 2022-06-23 06:01:42.979786
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.plugins.loader import become_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C
    # create base object
    base = Base()
    # set search path
    path = "a"
    base._path = path
    # set role_path
    role_path = "b"
    base._role_path = role_path
    # create task result object
    taskRes = TaskResult()
    # Add task to task result
    taskRes._task = base
    # create task object
    task = Task()
    # Add task result to task object
    task._result = taskRes
   

# Generated at 2022-06-23 06:01:55.585945
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    __metaclass__ = BaseMeta
    class A(object):
        attr1 = FieldAttribute(isa='str', default='foo')
        attr2 = FieldAttribute(isa='str', default='foo')
        attr3 = FieldAttribute(isa='str', default='foo')

    a = A()
    for attr_name in ('_attributes', '_attr_defaults', '_valid_attrs', '_alias_attrs'):
        assert hasattr(a, attr_name)

    assert 'attr1' in a._attributes
    assert a._attributes['attr1'] is Sentinel
    assert a._attr_defaults['attr1'] == 'foo'
    assert a._valid_attrs['attr1'].default == 'foo'

    assert 'attr2' in a._attributes
    assert a._

# Generated at 2022-06-23 06:02:03.714879
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()
    data['uuid'] = 'uuid'
    data['finalized'] = False
    data['squashed'] = False
    data['_loader'] = None
    data['_validated'] = None
    data['_variable_manager'] = None
    data['_block'] = None
    data['_role'] = None
    data['_task'] = None
    data['_loop'] = None
    data['_use_unsafe_shell'] = None
    data['_no_log'] = None
    data['_always_run'] = None
    data['_any_errors_fatal'] = None
    data['_changed_when'] = None
    data['_check_mode'] = None
    data['_confirm_password'] = None
    data['_delay'] = 0.0
    data

# Generated at 2022-06-23 06:02:15.242325
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # BaseMeta.__new__() execution
    from ansible.executor.task_result import TaskResult
    a = BaseMeta()
    b = BaseMeta('a', (), {})
    c = BaseMeta('a', (), {
        'foo': 'bar',
    })
    d = BaseMeta('a', (), {
        '_foo': 'bar',
    })
    d2 = BaseMeta('a', (), {
        '_foo': FieldAttribute(default='bar'),
    })
    e = BaseMeta('a', (), {
        '_foo': 'bar',
        '_bar': 'baz',
        '_baz': FieldAttribute(default='bar'),
    })

# Generated at 2022-06-23 06:02:19.091349
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    Unit test for FieldAttributeBase.get_validated_value
    '''
    # initialization
    obj = FieldAttributeBase()

    # sample data
    attribute = None
    value = None

    # example call

# Generated at 2022-06-23 06:02:28.366225
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class DummyClass(FieldAttributeBase):
         def __init__(self):
             pass

    obj = DummyClass()
    # Test with no args
    assert obj.from_attrs() == None
    # Test with arguments

# Generated at 2022-06-23 06:02:29.763735
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Unit test for method FieldAttributeBase.squash
    '''
    pass

# Generated at 2022-06-23 06:02:36.688576
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
        # From /usr/lib/python3.6/unittest/case.py ...

        # (brief)
        class TestFieldAttributeBaseMethods(unittest.TestCase):

                def test_FieldAttributeBase_copy(self):
                        # Test the method

                        # Test with arg
                        # print('Test with arg')
                        pass


        unittest.main()



# Generated at 2022-06-23 06:02:44.117738
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansiblelint import Runner

    # from ansiblelint.rules.UseShellInsteadOfCommandRule import UseShellInsteadOfCommandRule
    # from ansiblelint.runner import Runner

    # content = '''
    # '''

    # runner = Runner(None, None, [], [], [UseShellInsteadOfCommandRule()], [])
    # runner.run_modeler()

    # for item in runner.get_results():
    #     print('{}:{}'.format(item.filename, item.linenumber))
    #     print(item.rule)
    #     print(item.message)


# Generated at 2022-06-23 06:02:46.167512
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FieldAttributeBase.get_validated_value()
test_FieldAttributeBase_get_validated_value.__test__ = False


# Generated at 2022-06-23 06:02:55.914820
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # test flat attributes
    fa = FieldAttributeBase()
    assert fa.squash(1) == 1
    assert fa.squash(1, 2) == 1
    assert fa.squash([1], [2]) == [1]
    # test list of list attributes
    fa.listof = list
    assert fa.squash(1, 2) == [1, 2]
    assert fa.squash([1], [2]) == [[1], [2]]
    assert fa.squash([1, 2], [3]) == [[1, 2], [3]]
    # test set of set attributes
    fa.listof = set
    assert fa.squash(1, 2) == {1, 2}
    assert fa.squash({1}, {2}) == {frozenset({1}), frozenset({2})}
