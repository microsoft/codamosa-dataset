

# Generated at 2022-06-23 05:52:59.323588
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    testobj = FieldAttributeBase()
    # set up the test objects
    testobj.uuid = "uuid"
    testobj.loader = "loader"
    testobj.variable_manager = "variable_manager"
    testobj.validated = "validated"
    testobj.finalized = "finalized"

    # call FieldAttributeBase.get_variable_manager with args
    testargs =  []
    testkwargs = {}
    result = testobj.get_variable_manager(*testargs, **testkwargs)

    # make assertions
    assert result == "variable_manager"

# Generated at 2022-06-23 05:53:01.179735
# Unit test for method get_path of class Base
def test_Base_get_path():
    obj = Base()
    assert obj.get_path() == ''


# Generated at 2022-06-23 05:53:04.055025
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    obj1 = FieldAttributeBase()

    obj1.validate(0,None,None)

    # test failing conditions
    # pass



# Generated at 2022-06-23 05:53:06.857043
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    """
      Test get_ds of FieldAttributeBase
    """
    obj = FieldAttributeBase()
    assert obj.get_ds() is None



# Generated at 2022-06-23 05:53:13.428519
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class BaseMeta_Test(object):
        __metaclass__ = BaseMeta
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}
    assert isinstance(BaseMeta_Test._attributes, dict)
    assert isinstance(BaseMeta_Test._attr_defaults, dict)
    assert isinstance(BaseMeta_Test._valid_attrs, dict)
    assert isinstance(BaseMeta_Test._alias_attrs, dict)



# Generated at 2022-06-23 05:53:21.273194
# Unit test for method get_path of class Base
def test_Base_get_path():
    # init the class
    try:
        base = Base()
    except NameError as e:
        assert False , "Could not find class Base"
    # init the vars
    base._ds = {}
    base._ds._data_source = "value1"
    base._ds._line_number = "value2"
    # call the method
    try:
        result = base.get_path()
    except AttributeError as e:
        assert False , "Could not call method get_path"
    # verify the result
    assert result=="value1:value2" , "Incorrect result"

# Generated at 2022-06-23 05:53:23.658463
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    f = FieldAttributeBase()
    g = dict()
    h = dict()
    assert f.get_validated_value(g, h) == None


# Generated at 2022-06-23 05:53:25.725278
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert 1 == 2
__new__ = BaseMeta.__new__


# Generated at 2022-06-23 05:53:37.956997
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # test_from_attrs_fixture with fixture
    task = Task()

# Generated at 2022-06-23 05:53:40.922790
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # add code here to ensure we get the right output
    raise AnsibleParserError("FieldAttributeBase: need implementation")


# Generated at 2022-06-23 05:53:50.371916
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = {}
    attribute = FieldAttributeBase(name='test_FieldAttributeBase', default='test_FieldAttributeBase_default_value')
    assert attribute.preprocess_data(data) == 'test_FieldAttributeBase_default_value'



# Generated at 2022-06-23 05:53:51.888930
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  class_instance = FieldAttributeBase(dict)
  assert class_instance.dump_attrs() == {}



# Generated at 2022-06-23 05:54:01.459333
# Unit test for constructor of class Base
def test_Base():
    # check default values
    obj = Base()
    assert obj._name == ''
    assert obj._connection == context.cliargs_deferred_get('connection')
    assert obj._port is None
    assert obj._remote_user == context.cliargs_deferred_get('remote_user')
    assert obj._vars == {}
    assert obj._module_defaults == []
    assert obj._environment == []
    assert obj._no_log is False
    assert obj._run_once is False
    assert obj._ignore_errors is False
    assert obj._ignore_unreachable is False
    assert obj._check_mode is context.cliargs_deferred_get('check')
    assert obj._diff is context.cliargs_deferred_get('diff')
    assert obj._any_errors_fatal is C.ANY_ERRORS_F

# Generated at 2022-06-23 05:54:08.779268
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.task_include import TaskInclude
    assert TaskInclude._valid_attrs == {'tasks': FieldAttribute(isa='raw', inherit=False, default=None, private=False)}
    assert TaskInclude._alias_attrs == {}
    assert TaskInclude._attr_defaults == {'tasks': None}
    assert TaskInclude._attributes == {'tasks': Sentinel}

# Unit test with function _create_attrs of BaseMeta

# Generated at 2022-06-23 05:54:20.503515
# Unit test for method get_path of class Base
def test_Base_get_path():
    import os
    import yaml
    from ansible.parsing.dataloader import DataLoader
    #from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import module_loader
    from ansible.cli import CLI
    cli = CLI()
    cli._options = lambda : None
    cli.options = lambda : None
    cli.options.connection = ''
    cli.options.module_

# Generated at 2022-06-23 05:54:32.203393
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    # Test code for from_attrs of class FieldAttributeBase
    # Loads attributes from a dictionary
    # For all fields specified in the dictionary, we set the appropriate
    # field attribute on the object.
    # We only call from_attrs on finalized tasks from the control side
    # and those attributes are the ones that are squashed on the TE
    # So we treat this object as finalized
    # Create a test object

    # Test with a test object
    test_obj = FieldAttributeBase()
    assert isinstance(test_obj, FieldAttributeBase)

    # Test with attrs
    attrs = {}
    test_obj.from_attrs(attrs)

    # Test with attrs
    attrs = {"int": 1}
    test_obj.from_attrs(attrs)

    # Test with attrs

# Generated at 2022-06-23 05:54:41.366282
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    # setup test of __new__ method of class BaseMeta
    meta = BaseMeta('test', (object,), {'test': FieldAttribute(default=123)})
    test = meta('test', (object,), {})
    assert test._get_attr_test() == 123

    # setup test of __new__ method of class BaseMeta with a parent
    meta = BaseMeta('test', (object,), {})
    test = meta('test', (object,), {'test': FieldAttribute(default=123)})
    assert test._get_attr_test() == 123

    # setup test of _get_parent_attribute method of class BaseMeta with a parent
    meta = BaseMeta('test', (object,), {})
    test = meta('test', (object,), {'_get_parent_attribute': lambda prop_name: 123})
   

# Generated at 2022-06-23 05:54:45.753520
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    f = FieldAttributeBase()
    try:
        f.get_variable_manager()
    except Exception:
        pass
    else:
        raise Exception("Expected exception")



# Generated at 2022-06-23 05:54:47.190668
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase()
    pass

# Generated at 2022-06-23 05:54:55.049528
# Unit test for constructor of class Base
def test_Base():
    '''
    Test Base class
    '''
    base = Base()
    assert base.name == ""
    assert base.connection == "smart"
    assert base.vars == {}
    assert base.module_defaults == []
    assert base.become is True
    assert base.become_method == "sudo"
    assert base.become_user == "root"
    assert base.become_flags == ""
    assert base.become_exe == ""



# Generated at 2022-06-23 05:55:03.327374
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    """
    Test if the constructor works with the only mandatory parameter 'isa'
    """

    # defining the constant for NoneType
    # pylint: disable=invalid-name
    NoneType = type(None)

    # this will be our list of supported 'isa'
    # if you plan to add to this list, also update VALID_TYPES
    # in __init__.py
    isa_list = [
        'string',
        'int',
        'float',
        'bool',
        'list',
        'dict',
        'set',
        'class',
        'percent',
    ]

    # ValidFieldAttribute is the only class that extends FieldAttributeBase
    # and has to have __init__ defined
    # pylint: disable=abstract-method

# Generated at 2022-06-23 05:55:10.007112
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_abstract_class.FunctionTestAbstractClass.test_abstract_class(
        FieldAttributeBase,
        'validate',
        [],
        {},
        [('instance', Attribute(isa='class', required=True, validate=True, class_type=FieldAttributeBase)),
         ('value', Attribute(isa=None, required=True, validate=True))],
        [('return', Attribute(isa=None, required=True, validate=False))]
    )

# Generated at 2022-06-23 05:55:13.201515
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():

    data = {}
    obj = FieldAttributeBase()
    obj.deserialize(data)


# Generated at 2022-06-23 05:55:21.278251
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    # test case where data is an empty string
    field_attribute_base_obj = FieldAttributeBase()
    assert field_attribute_base_obj.validate('') is None

    # test case where data is a string
    field_attribute_base_obj = FieldAttributeBase()
    assert field_attribute_base_obj.validate('string') == 'string'

    # test case where data is a boolean
    field_attribute_base_obj = FieldAttributeBase()
    assert field_attribute_base_obj.validate(True) == True
    assert field_attribute_base_obj.validate(False) == False

   

# Generated at 2022-06-23 05:55:29.215853
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    root = FieldAttributeBase()
    # debug("root._fail_on_missing_modules: %s" % root._fail_on_missing_modules)
    assert root._fail_on_missing_modules == True
    # debug("root._fail_on_undefined_errors: %s" % root._fail_on_undefined_errors)
    assert root._fail_on_undefined_errors == True
    # debug("root._variable_manager: %s" % root._variable_manager)
    assert root._variable_manager is None

# Generated at 2022-06-23 05:55:29.877294
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass

# Generated at 2022-06-23 05:55:32.803253
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 05:55:33.508994
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pass

# Generated at 2022-06-23 05:55:34.779242
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    data = Mock()

    assert data == FieldAttributeBase().serialize()


# Generated at 2022-06-23 05:55:37.102726
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    my_FieldAttributeBase = FieldAttributeBase()
    res_FieldAttributeBase = my_FieldAttributeBase.deserialize('data')


# Generated at 2022-06-23 05:55:38.644800
# Unit test for method get_path of class Base
def test_Base_get_path():
    a = Base()
    assert a.get_path() == ''

# Generated at 2022-06-23 05:55:43.786094
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    attributes = {'foo': 'bar'}
    self_ = FieldAttributeBase()
    self_._valid_attrs = attributes
    
    expected = {}
    actual = self_.dump_attrs()
    
    assert expected == actual, 'Expected: %s \n Actual: %s' % (expected, actual)


# Generated at 2022-06-23 05:55:45.971049
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class TestCase__BaseMeta__new__(Base):
        pass

    TestCase__BaseMeta__new__()

# Generated at 2022-06-23 05:55:52.623142
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Test get_loader
    '''
    test = FieldAttributeBase()
    test._loader = None
    assert test.get_loader() == None
test_FieldAttributeBase_get_loader.test_type = 'unit'
test_FieldAttributeBase_get_loader.test_case = 'unit.utbase.FieldAttributeBase.get_loader'
test_FieldAttributeBase_get_loader.test_module = 'unit.utbase.FieldAttributeBase'
test_FieldAttributeBase_get_loader.test_name = 'test_FieldAttributeBase_get_loader'

# Generated at 2022-06-23 05:55:55.369894
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    klass = FieldAttributeBase

    # Setup a FieldAttributeBase
    test_FieldAttributeBase = klass()

    # Test whether get_variable_manager throws an exception
    try:
        test_FieldAttributeBase.get_variable_manager()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 05:55:58.871288
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    test_obj = FieldAttributeBase()
    assert_equal(test_obj.copy(), None)

# Generated at 2022-06-23 05:56:00.353128
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    pass

# Generated at 2022-06-23 05:56:06.328550
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    class MyBase(Base):
        foo = FieldAttribute()
        test = FieldAttribute(default="test")
    my_base = MyBase()
    assert my_base.foo == my_base._attr_defaults['foo']



# Generated at 2022-06-23 05:56:09.487090
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    my_obj = FieldAttributeBase()
    my_obj.deserialize(data={"foo": "foo"})

# Generated at 2022-06-23 05:56:13.309565
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # field_attr = FieldAttributeBase(loader=None, variable_manager=None)
    # assert field_attr.get_variable_manager() == (None)
    pass



# Generated at 2022-06-23 05:56:14.698652
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass


# Generated at 2022-06-23 05:56:19.180205
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # test FieldAttributeBase constructor
    try:
        test_attr = FieldAttributeBase()
        assert test_attr is not None
    except Exception as e:
        raise ValueError("test_FieldAttributeBase: FieldAttributeBase constructor raise an unexpected error: " + str(e))



# Generated at 2022-06-23 05:56:19.902671
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass

# Generated at 2022-06-23 05:56:22.554562
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    bm = BaseMeta('BaseMeta', (), {})



# Generated at 2022-06-23 05:56:23.475992
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert BaseMeta is not None


# Generated at 2022-06-23 05:56:31.922914
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    FAKE_A = 'FAKE_A'    # field attribute A
    FAKE_B = 'FAKE_B'    # field attribute B
    FAKE_C = 'FAKE_C'    # field attribute C
    FAKE_D = 'FAKE_D'    # field attribute D

    # Set up FAKE_A, FAKE_B, FAKE_C FieldAttributes
    FAKE_A_FIELD_ATTRIBUTE = FieldAttribute(isa='bool', default=False)
    FAKE_B_FIELD_ATTRIBUTE = FieldAttribute(isa='bool')
    FAKE_C_FIELD_ATTRIBUTE = FieldAttribute(isa='bool', default=False)
    FAKE_D

# Generated at 2022-06-23 05:56:40.268391
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    o = FieldAttributeBase()
    o.finalized = True
    o.squashed = True
    o.vars = {'test_var': 'test_value'}

    # serialize - check that 'vars' is used
    repr = o.serialize()
    assert repr == {'vars': {'test_var': 'test_value'}, 'finalized': True, 'squashed': True}

    # deserialize
    o.deserialize(repr)
    assert o.vars == {'test_var': 'test_value'}

    # test we can change vars
    o.deserialize({'vars': {'new_var': 'new_value'}, 'finalized': True, 'squashed': True})

# Generated at 2022-06-23 05:56:46.697347
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection
    from ansible.playbook.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    mock_loader = MagicMock()



# Generated at 2022-06-23 05:56:57.970800
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import Include
    
    a = Base()
    b = Base()
    c = Base()
    d = Base()
    e = Base()
    f = Base()
    g = Base()
    h = Base()
    a._parent = b
    b._parent = c
    c._parent = d
    d._parent = e
    e._parent = f
    f._parent = g
    g._parent = h
    # A dep chain of h -> g -> f -> e -> d -> c -> b -> a
    assert h.get_dep_chain

# Generated at 2022-06-23 05:57:07.381378
# Unit test for method get_loader of class FieldAttributeBase

# Generated at 2022-06-23 05:57:10.207073
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    foo = FieldAttributeBase()
    assert isinstance(foo, FieldAttributeBase) is True
    assert foo.dump_me() == ""


# Generated at 2022-06-23 05:57:20.269586
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    obj = FieldAttributeBase()

    # Test with a value
    variable_manager = {}
    obj.set_variable_manager(variable_manager)
    returned_value = obj.get_variable_manager()
    assert returned_value is variable_manager

    # Test with a default
    obj.myattr = 'myvalue'
    returned_value = obj.get_variable_manager(default='myvalue')
    assert returned_value == 'myvalue'

    # Test with an override
    variable_manager = {}
    obj.set_variable_manager(variable_manager)
    returned_value = obj.get_variable_manager(default='myvalue')
    assert returned_value is variable_manager


# Generated at 2022-06-23 05:57:21.892334
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    default_value = {'product.price': 10.1, 'product.name': 'test', 'product.type': 'test'}
    repr = FieldAttributeBase.dump_attrs(default_value)
    assert repr == default_value


# Generated at 2022-06-23 05:57:23.462865
# Unit test for constructor of class Base
def test_Base():
    obj = Base()

    # test __init__()
    assert obj._always_post_validate
    assert obj._vars == {}



# Generated at 2022-06-23 05:57:27.131492
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    loader = DictDataLoader({})
    field = FieldAttributeBase(loader=loader)
    assert field.get_loader() == loader


# Generated at 2022-06-23 05:57:37.251538
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Setup
    class TestContainer(FieldAttributeBase):
        pass
    obj = TestContainer()
    obj.foo = 'foo'
    obj.bar = 'bar'
    obj.baz = 'baz'
    obj.child = TestContainer()
    obj.child.foo = 'child_foo'
    obj.child.bar = 'child_bar'

    # Execute
    copy_obj = obj.copy()

    # Assert outcome
    assert hasattr(copy_obj, 'child')
    assert len(dir(copy_obj.child)) == 2
    assert hasattr(copy_obj, 'foo')
    assert hasattr(copy_obj, 'bar')
    assert hasattr(copy_obj, 'baz')
    assert copy_obj.foo == 'foo'

# Generated at 2022-06-23 05:57:44.883850
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    cd = CallbackModule()
    play = Play()
    play.callback = cd
    play.post_validate(None)
    cd2 = CallbackModule()
    cd2.from_attrs(play.serialize().get('callback').get('__ansible_callback__'))
    assert cd2.serialize().get('__ansible_callback__') == cd.serialize().get('__ansible_callback__')

# Generated at 2022-06-23 05:57:54.488427
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # trying to access protected variable will raise error
    # FieldAttributeBase._FieldAttributeBase__valid_attrs
    # use a proxy class to bypass the protected variable
    class ProxyFieldAttributeBase(FieldAttributeBase):
        def get_attrs(self):
            return self.__valid_attrs


# Generated at 2022-06-23 05:57:58.704151
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base._connection == 'smart'
    assert base._remote_user == 'root'
    assert base._check_mode == False
    assert base._diff == False
    assert base._any_errors_fatal == True



# Generated at 2022-06-23 05:58:00.395997
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    o = FieldAttributeBase()
    assert o.get_loader() is None


# Generated at 2022-06-23 05:58:15.586312
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    '''
    Unit test for method dump_attrs of class FieldAttributeBase.
    '''
    # Test calling with a class that defines _valid_attrs
    data_class = FieldAttributeBase()
    data_class._valid_attrs = {
        'attr1': FieldAttribute(isa='string', default=dict(foo='bar')),
        'attr2': FieldAttribute(isa='bool', default=True),
        'attr3': FieldAttribute(isa='class', default=None),
        'attr4': FieldAttribute(isa='list', default=[]),
    }
    data_class.attr1 = 'attr1-val'
    data_class.attr2 = 'attr2-val'
    data_class.attr3 = 'attr3-val'
    data_class.attr4 = 'attr4-val'

    data

# Generated at 2022-06-23 05:58:17.266392
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    assert obj.get_ds() == None

# Generated at 2022-06-23 05:58:22.328865
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    class MyClass(with_metaclass(BaseMeta, Base)):
        some_field = FieldAttribute(isa='str', inherit=False)
    inst = MyClass()
    assert hasattr(inst.__class__, 'some_field')



# Generated at 2022-06-23 05:58:33.605294
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    def test_Base_get_dep_chain_1():
        # set the value of Base._play._parent to None
        Base._play._parent = None
        # call method get_dep_chain of class Base
        try:
            Base.get_dep_chain()
        except Exception as e:
            assert(isinstance(e, AttributeError))
        else:
            assert(False)
    def test_Base_get_dep_chain_2():
        # set the value of Base._play._parent to fake value
        Base._play._parent = "fake"
        # call method get_dep_chain of class Base
        try:
            Base.get_dep_chain()
        except Exception as e:
            assert(isinstance(e, AttributeError))
        else:
            assert(False)

# Generated at 2022-06-23 05:58:39.997694
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.ds = 'foobar'
    assert field_attribute_base.get_ds() == 'foobar'
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base.get_ds() == None

# Generated at 2022-06-23 05:58:40.729401
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-23 05:58:46.374776
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # create a task object
    t = Task()
    # create a search path, the result is a list of directories
    path_stack = t.get_search_path()
    # check if the result is a list
    assert isinstance(path_stack, list)
    # check if each element of the list is a directory
    for x in path_stack:
        assert os.path.isdir(x)


# Generated at 2022-06-23 05:58:54.055111
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FAKE_STDIN_FD = 5
    FAKE_STDOUT_FD = 6
    FAKE_STDERR_FD = 7
    with open('/dev/null', 'a') as stdin, open('/dev/null', 'a') as stdout, open('/dev/null', 'a') as stderr:
        # Set up mocked objects
        json_str = '{"hosts": "localhost"}'
        m__module = MagicMock(return_value=json_str)
        m_json = MagicMock()
        m_json.loads = MagicMock(return_value=json_str)
        m_os = MagicMock()
        m_os.dup2 = MagicMock()
        m_os.fstat = MagicMock(return_value=True)
        # Set up the context manager m

# Generated at 2022-06-23 05:58:55.174110
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    assert True

# Generated at 2022-06-23 05:58:58.752626
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    j = FieldAttributeBase()
    d = {}
    assert j.get_ds() == d


# Generated at 2022-06-23 05:59:08.169367
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():

    class a(Base):
        p1 = FieldAttribute(isa='int')
        b1 = FieldAttribute(isa='int')


    class b(a):
        p2 = FieldAttribute(isa='int')
        c1 = FieldAttribute(isa='int')

    class c(b):
        p3 = FieldAttribute(isa='int')
        d1 = FieldAttribute(isa='int')

    x = c()

    x.p1 = 1
    x.p2 = 2
    x.p3 = 3

    assert(x.p1 == 1)
    assert(x.p2 == 2)
    assert(x.p3 == 3)


# Generated at 2022-06-23 05:59:12.161933
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    o = object()
    assert FieldAttributeBase(o, 'attr_name').load_data(o, 'attr_name', 'attr_value') == 'attr_value'


# Generated at 2022-06-23 05:59:15.936657
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    a = Base()
    assert a.get_dep_chain() == None
    b = Base()
    a._parent = b
    assert a.get_dep_chain() == b


# Generated at 2022-06-23 05:59:26.479339
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    import six
    import inspect

    class TestClass(with_metaclass(BaseMeta, object)):
        attr = FieldAttribute(isa='str', default='test')
        attr2 = FieldAttribute(isa='str')

    assert TestClass._attr_defaults['attr'] == 'test'
    assert TestClass._attr_defaults['attr2'] == None
    assert TestClass._attributes['attr'] == Sentinel
    assert TestClass._attributes['attr2'] == Sentinel
    assert TestClass._valid_attrs['attr'] is TestClass.attr
    assert TestClass._valid_attrs['attr2'] is TestClass.attr2
    assert TestClass.attr.__doc__ == "FieldAttribute attribute"
    assert isinstance(TestClass.attr, property)

# Generated at 2022-06-23 05:59:31.977514
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    fixture = FieldAttributeBase()
    fixture.isa = None
    fixture.required = None

    # Invalid: 'name' is not a valid value for the attribute isa
    name = 'name'
    assert not fixture.validate(name)
    

# Generated at 2022-06-23 05:59:35.206507
# Unit test for method get_path of class Base
def test_Base_get_path():
    path = Base().get_path()
    print("return of Base().get_path() is %s" % path)



# Generated at 2022-06-23 05:59:46.911900
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.a_task_in_block import ATaskInBlock
    from ansible.playbook.a_task_in_role import ATaskInRole

    # FIXME: Temporary hack to find the datadir
    import os.path
    ansible

# Generated at 2022-06-23 05:59:49.481162
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass

# Generated at 2022-06-23 05:59:51.318388
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    assert True

# Generated at 2022-06-23 05:59:53.898874
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():

    expected = 'expected'

    o = FieldAttributeBase()
    o._ds = expected
    assert o.get_ds() == expected


# Generated at 2022-06-23 05:59:57.058707
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():

    t = AttributeClass()

    attr_val = "test"
    t.set_attribute("test", attr_val)

    assert(t.serialize() == attr_val)


# Generated at 2022-06-23 05:59:59.128334
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    f = FieldAttributeBase()
    x = FieldAttributeBase()
    assert x.preprocess_data(f) == None


# Generated at 2022-06-23 06:00:00.517068
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    c = FieldAttributeBase()
    c.squash()

# Generated at 2022-06-23 06:00:09.280803
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from units.compat.mock import patch
    from ansible.module_utils.six import PY2

    patch_path = 'ansible.parsing.yaml.representer.Representer.represent_unicode' if PY2 else 'ansible.parsing.yaml.representer.Representer.represent_str'

    with patch(patch_path) as mock_represent_unicode:
        mock_represent_unicode.return_value = ''
        _FieldAttributeBase = FieldAttributeBase()
        assert isinstance(_FieldAttributeBase, FieldAttributeBase)

        # When I call dump_attrs
        output = _FieldAttributeBase.dump_attrs()

        # I should get a dictionary as output
        assert isinstance(output, dict)



# Generated at 2022-06-23 06:00:11.299211
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # Constructor of class FieldAttributeBase
    FieldAttributeBase('test', required=False)


# Generated at 2022-06-23 06:00:18.471241
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = module_loader.find_plugin(Base._load_name(dict(name='debug')), class_only=True)
    parent1 = module_loader.find_plugin(Base._load_name(dict(name='debug')), class_only=True)
    parent2 = module_loader.find_plugin(Base._load_name(dict(name='debug')), class_only=True)
    obj._parent = parent1
    parent1._parent = parent2
    assert obj.get_dep_chain() == [parent1, parent2]



# Generated at 2022-06-23 06:00:22.072370
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Test function for get_ds of class FieldAttributeBase
    '''
    fb = FieldAttributeBase()
    # set ds with value
    fb.set_ds(obj=Sentinel)
    # Test return from sentinel, no error
    assert fb.get_ds() is Sentinel


# Generated at 2022-06-23 06:00:29.497929
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    '''
    Unit test for method preprocess_data of class FieldAttributeBase
    '''
    print("*** Unit test for method preprocess_data of class FieldAttributeBase ***")

# Generated at 2022-06-23 06:00:38.738199
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    p = Play.load({'id': '57bf666f-a648-462a-a26c-f07a1af8e9c7', 'hosts': 'webservers'})
    t = Task.load({'name': 'foo', 'with_items': '{{ websites }}', 'register': 'foo'}, p)
    t.squash()
    t.finalize()
    assert t.serialize()['name'] == 'foo'
    assert t.serialize()['with_items'] == '{{ websites }}'
    assert t.serialize()['register'] == 'foo'


# Generated at 2022-06-23 06:00:45.770542
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Setup
    attr = FieldAttribute()
    field = 'foo'
    ds = {'a': 'b'}
    templar = object()

    # Execute
    # FIXME: How can we test this?
    #assert_equals(attr.preprocess_data(field, ds, templar), None)
    # Teardown



# Generated at 2022-06-23 06:00:47.358359
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # test execution: tested in test_class.py
    pass


# Generated at 2022-06-23 06:00:48.503151
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass


# Generated at 2022-06-23 06:00:51.696005
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    FieldAttributeBase = ansible.module_utils.parsing.convert_bool.FieldAttributeBase
    pass



# Generated at 2022-06-23 06:00:54.548931
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Base(with_metaclass(BaseMeta)):
        """
        This is an example of a class which should be a subclass of Base.
        """
    (Base)


# Generated at 2022-06-23 06:01:03.932280
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Test1(object):
        prop1 = FieldAttribute(isa='string')
        prop2 = FieldAttribute(isa='string')

    class Test2(Test1):
        def _get_attr_prop1(self):
            return 'self'
    class Test3(Test2):
        prop2 = FieldAttribute(isa='string', inherit=False)

    assert 'prop1' in Test2._valid_attrs
    assert 'prop1' in Test2._attr_defaults
    assert 'prop1' in Test2._attributes
    assert Test2._attributes['prop1'] is Sentinel
    assert 'prop2' in Test2._valid_attrs
    assert 'prop2' in Test2._attr_defaults
    assert 'prop2' in Test2._attributes
    assert Test2._attributes['prop2'] is Sentinel


# Generated at 2022-06-23 06:01:07.181149
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    foo = Base()
    bar = Base()
    baz = Base()
    bar._parent = baz
    foo._parent = bar
    assert foo.get_dep_chain() == [baz, bar]



# Generated at 2022-06-23 06:01:16.322111
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Create a FieldAttributeBase object
    obj = FieldAttributeBase(name="test", always_post_validate=True,
                             attr_class=None, isa=unicode,
                             required=False, default=sentinel,
                             fallback=(sentinel, None), aliases=tuple(),
                             serialize_when_none=True,
                             # Inherited from @FieldAttributeClassBase
                             static=False, display=True, priority=FieldAttributePriority.DEFAULT)
    # Serialize the object
    json_obj = obj.serialize()
    # Check if result is correct

# Generated at 2022-06-23 06:01:28.886670
# Unit test for method dump_me of class FieldAttributeBase

# Generated at 2022-06-23 06:01:31.265598
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    my_object = _FieldAttributeBase()
    my_object.serialize()


# Generated at 2022-06-23 06:01:33.224611
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Tests dump_attrs() which is not implemented.
    pass

# Generated at 2022-06-23 06:01:34.721988
# Unit test for method get_path of class Base
def test_Base_get_path():
    data = Base()
    assert data.get_path() == ''



# Generated at 2022-06-23 06:01:44.542093
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fb = FieldAttributeBase()
    assert fb.dump_me() == {'name': '',
                            'private': False,
                            'required': False,
                            'isa': 'string',
                            'class_type': object,
                            'static': False,
                            'alt_attrs': None,
                            'aliases': [],
                            'default': None,
                            'always_post_validate': False,
                            'listof': string_types,
                            'implementation': None,
                            'description': ''}
							

# Generated at 2022-06-23 06:01:47.844514
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    res = obj.copy()
    assert isinstance(res, FieldAttributeBase)


# Generated at 2022-06-23 06:01:55.634369
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    from ansible.playbook.play import Play

    mock_play = Play()
    mocker_play = MagicMock(return_value=mock_play)
    patcher = patch.object(FieldAttributeBase, 'get_play_ds', mocker_play)
    patcher.start()
    mocker = MagicMock()
    mocker.get_play_ds.return_value = mock_play
    result = mocker.get_ds()
    patcher.stop()
    assert result == mock_play

# Generated at 2022-06-23 06:01:59.846707
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fieldattributebase_instance = FieldAttributeBase()

    # this test actually checks that exceptions raised in _load_ds
    # are passed through, which is the behavior we want
    assert_raises(Exception, fieldattributebase_instance.load_data, ds=0, attribute='foo')


# Generated at 2022-06-23 06:02:05.515387
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    # Test instantiation of FieldAttributeBase(self)

    o = FieldAttributeBase()
    attr_copy = o.copy()

    assert attr_copy._valid_attrs == o._valid_attrs
    assert repr(attr_copy) == repr(o)


# Generated at 2022-06-23 06:02:16.279877
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.base import Base
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple
    context._init_global_context(options=Options())

    task = Task()
    task.name = 'task1'
    task._ds = DataLoader()
    task._ds._data_source = './test.yml'
    task._ds._line_number = 1
    task._ds._search_paths = ['.']
    task_dep_chain = task.get_dep_chain()


# Generated at 2022-06-23 06:02:19.236049
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    FieldAttributeBase = get_class('FieldAttributeBase')
    field = FieldAttributeBase()
    assert field.post_validate(templar = None) == None


# Generated at 2022-06-23 06:02:22.120637
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Initialize "self"
    self = Base()
    # Perform the test
    result = self.get_dep_chain()
    # Check if the result is equal to the expected
    assert result == None


# Generated at 2022-06-23 06:02:24.958688
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    FieldAttributeBase_serialize_obj = FieldAttributeBase()
    FieldAttributeBase_serialize_obj.deserialize('test_FieldAttributeBase_serialize_attr')
    assert FieldAttributeBase_serialize_obj._squashed == False, 'Unit test for method serialize of class FieldAttributeBase'

# Generated at 2022-06-23 06:02:27.686422
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    base._ds = "./test_dir/test_file.yml"
    base._ds._line_number = 3
    assert base.get_path() == "./test_dir/test_file.yml:3"



# Generated at 2022-06-23 06:02:29.277683
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    assert True == FieldAttributeBase.squash



# Generated at 2022-06-23 06:02:30.632202
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass
    # TODO


# Generated at 2022-06-23 06:02:43.047220
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestBaseMeta(with_metaclass(BaseMeta, object)):
        some_attr = FieldAttribute(isa='str', inherit=True, default=None)
        another_attr = FieldAttribute(isa='str', inherit=False, default=None)

    test1 = TestBaseMeta()

    assert test1.some_attr is None
    assert test1.another_attr is None

    test1.some_attr = 'test_value'
    test1.another_attr = 'test_value2'

    assert test1.some_attr == 'test_value'
    assert test1.another_attr == 'test_value2'

    class TestBaseMetaSubclass(TestBaseMeta):
        some_attr = FieldAttribute(isa='str', inherit=False, default=None)

# Generated at 2022-06-23 06:02:47.542886
# Unit test for method get_path of class Base
def test_Base_get_path():
    global result
    Base.__name__ = "Base"
    Base._ds = "Base._ds"
    Base._line_number = "Base._line_number"
    result = Base.get_path()
    assert result == "Base._ds:Base._line_number"


# Generated at 2022-06-23 06:02:55.743365
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    _create_attrs = object.__new__(BaseMeta)
    _process_parents = object.__new__(BaseMeta)
    dct = {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}
    dct = _create_attrs(dct)
    dct = _process_parents(tuple({}.keys()), dct)
    for attr in dct.keys():
        if attr.startswith('test_') and callable(dct[attr]):
            dct[attr]()
test_BaseMeta___new__()

