

# Generated at 2022-06-23 05:52:53.070204
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    obj = FieldAttributeBase()
    print("FIXME: no test for " + "FieldAttributeBase")


# Generated at 2022-06-23 05:52:57.807527
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    from ansible.playbook.play_context import PlayContext
    data = PlayContext()
    f = FieldAttributeBase(isa='class', class_type=PlayContext)
    with pytest.raises(AnsibleAssertionError) as excinfo:
        f.get_ds()
    assert "Cannot get ds for an unbound attribute" in to_native(excinfo.value)

# Generated at 2022-06-23 05:53:00.887259
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    with pytest.raises(AnsibleAssertionError):
        with pytest.raises(AnsibleAssertionError):
            FieldAttributeBase().get_loader()

# Generated at 2022-06-23 05:53:08.492226
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.playbook.play import Play
  from ansible.playbook.task import Task
  from ansible.inventory.group import Group
  from ansible.inventory.host import Host
  loader = DataLoader()
  variable_manager = VariableManager()
  play = Play()
  play._variable_manager = variable_manager
  play._loader = loader
  task = Task()
  task._variable_manager = variable_manager
  task._loader = loader
  task.action = 'shell'
  task.args = 'echo hi'
  task.register = 'shell_out'
  task.delegate_to = 'myhost'
  play.post_validate(loader=loader, templar=None)

# Generated at 2022-06-23 05:53:10.427751
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass

# Generated at 2022-06-23 05:53:11.922171
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass
    # FIXME
    #raise NotImplementedError()


# Generated at 2022-06-23 05:53:16.378483
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    item = FieldAttributeBase()
    
    
    assert item.get_validated_value(None, None, 'test', None) == 'test'
    

# Generated at 2022-06-23 05:53:25.046948
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText
  real_data = dict(
    a=dict(
      b=dict(
        c=1,
        d=1.1,
      ),
      e=dict(
        f=[1,2,3],
        g=set([1,2,3]),
      ),
    )
  )
  data = copy.deepcopy(real_data)
  target = FieldAttributeBase('a')

  # Test normal behaviour
  target.load_data(data)

# Generated at 2022-06-23 05:53:29.017115
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    for variable in base_vars:
        variable.copy()



# Generated at 2022-06-23 05:53:40.259459
# Unit test for method get_search_path of class Base

# Generated at 2022-06-23 05:53:44.356474
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    # TEST: Base_get_dep_chain_01
    # DESCRIPTION: Test successful execution of method without providing values.
    # EXPECTED RESULT: Return value as expected
    print('Test Base_get_dep_chain_01')
    print('Description: Test successful execution of method without providing values.')
    print('Expected Result: Return value as expected')
    base1 = Base()
    assert(base1.get_dep_chain() == None)

    if True:
        print('Test succeeded')
    else:
        print('Test failed')

    # TEST: Base_get_dep_chain_02
    # DESCRIPTION: Test successful execution of method with parent attribute.
    # EXPECTED RESULT: Return value as expected
    print('Test Base_get_dep_chain_02')

# Generated at 2022-06-23 05:53:59.021198
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # TODO: implement this test

    # Setup test environment
    attrs = {}

    field_attribute_base = FieldAttributeBase(attrs)

# Generated at 2022-06-23 05:54:02.673807
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    #
    # Create a FieldAttributeBase class
    #
    fab = FieldAttributeBase(required=True)
    # Make sure the base class has the right field
    assert fab.required == True



# Generated at 2022-06-23 05:54:06.302420
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    path = '/home/ansible/test/test.yml'
    # Create a play to hold the task
    ds_test = DataloadedSoure(data=path, line_no=1)
    p = Play.load(ds_test, variable_manager=VariableManager(), loader=None)
    # Create Task and inject into the play
    ds_task = DataloadedSoure(data=path, line_no=2)
    t = Task(p)
    t._ds = ds_task
    # Invoke the method under test
    search_path = t.get_search_path()
    # Check results
    assert search_path == ['/home/ansible/test']


# Generated at 2022-06-23 05:54:06.721931
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    pass

# Generated at 2022-06-23 05:54:11.940427
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create the mock objects
    fake_self = FieldAttributeBase()

    # set initial values to attributes
    fake_self._valid_attrs = {}

    return_value = fake_self.dump_attrs()
    # This assertion is valid if the method dump_attr is not overwritten
    assert return_value == {}

# Generated at 2022-06-23 05:54:20.971839
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.objects.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.include.role import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.helpers import load_list_of_blocks

    parents = [
        Taggable, PlayContext, ModuleArgsParser
    ]

# Generated at 2022-06-23 05:54:31.655393
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass

    ###############################################
    # Base

    class Base(with_metaclass(BaseMeta, object)):

        # TODO: remove this attribute, it is currently defined on a number of subclasses so we declare it here and
        #       then override it on those classes later to keep it for backwards compatibility for anyone referencing
        #       this attribute manually (i.e. not through class methods).
        NO_CLONE = False

        def __init__(self, *args, **kwargs):
            self._initialize(kwargs)
            super(Base, self).__init__(*args, **kwargs)

        def _initialize(self, ds):
            # We use a set to be sure to not set the same property more than once
            attributes_to_set = set()

# Generated at 2022-06-23 05:54:40.978311
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Creates a task
    task = AnsibleTask(None, None)
    task._task_ds = './lib/ansible/playbook/task.py'
    task._task_ds._line_number = 1
    task._task_ds.path = './lib/ansible/playbook/task.py'
    task._task_ds._data_source = './lib/ansible/playbook/task.py'
    task._parent = None

    assert task.get_search_path() == ['./lib/ansible/playbook/task.py'], 'Base get_search_path method failed'

    # Creates a delegate_to variable
    variable = AnsibleVariable(None, None)
    variable._variable_ds = './lib/ansible/playbook/task.py'
    variable._variable_ds

# Generated at 2022-06-23 05:54:42.588614
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    """Test for method from_attrs of class FieldAttributeBase"""
    pi = FieldAttributeBase()



# Generated at 2022-06-23 05:54:45.007270
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    #  FIXME

    for obj in [
        AnsibleBaseYAMLObject(),
        AnsibleBaseYAMLObject(),
        AnsibleBaseYAMLObject(),
    ]:
        obj.post_validate(
        )


# Generated at 2022-06-23 05:54:50.981813
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    """
    Assure that the deserialize method works as expected.
    """
    name='The best test'
    value= 'PASS'

    my_obj = FieldAttributeBase(name=name)
    my_obj.deserialize(data={'name': 'The best test'})

    assert name == my_obj.name



# Generated at 2022-06-23 05:54:54.119456
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    templar = DictData()
    obj = FieldAttributeBase({'field': dict()}, {}, 'path')
    obj.post_validate(templar)
    pass


# Generated at 2022-06-23 05:54:57.053681
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_FieldAttributeBase = FieldAttributeBase()
    assert my_FieldAttributeBase.post_validate() == NotImplemented

# Generated at 2022-06-23 05:55:04.078614
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class Foo(object):
        def __init__(self, name):
            self.name = name

        def serialize(self):
            return self.name
    attrs = dict(foo=Foo(name='bar'))
    base_obj = FieldAttributeBase()
    base_obj.from_attrs(attrs)
    assert hasattr(base_obj, 'foo')
    assert type(base_obj.foo) == Foo
    assert base_obj.foo.name == 'bar'



# Generated at 2022-06-23 05:55:14.092555
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # pass
    obj = FieldAttributeBase()
    input_value = {"a": "b", "c": ["d", "e"], "f": {"g": "h"}}
    expected_value = {"a": "b", "c": ["d", "e"], "f": {"g": "h"}}
    actual_value = obj.preprocess_data(input_value)
    assert actual_value == expected_value

    input_value = [{"a": "b"}, "c", {"d": "e"}, ["f"], "g", ["h", "i", "j"]]
    expected_value = [{"a": "b"}, "c", {"d": "e"}, ["f"], "g", ["h", "i", "j"]]
    actual_value = obj.preprocess_data(input_value)
    assert actual_value

# Generated at 2022-06-23 05:55:17.515034
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    a = FieldAttributeBase()
    b = FieldAttributeBase()
    a.from_attrs(b.serialize())
    return a


# Generated at 2022-06-23 05:55:18.728315
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase()


# Generated at 2022-06-23 05:55:28.816030
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    a = FieldAttribute(isa='int', default=5, priority=12)

    class TestBase(BaseTask):
        __metaclass__ = TaskMeister
        b = a

    # from a different class
    assert a.is_valid_for_name('b') == True
    # from the same class
    a.set_class_name('b')
    assert a.is_valid_for_name('b') == False
    a.set_class_name(None)

    # test basic type validation
    a.validate(1)
    a.validate(8)
    with pytest.raises(AnsibleAssertionError):
        a.validate('a')


# Generated at 2022-06-23 05:55:30.739872
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    all_obj = FieldAttributeBase.copy()
    assert isinstance(all_obj, FieldAttributeBase)

# Generated at 2022-06-23 05:55:42.649337
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.mod_args import ModuleArgsParser
    h = Host(name='localhost')

# Generated at 2022-06-23 05:55:43.642198
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    pass

# Generated at 2022-06-23 05:55:51.917638
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    '''
    This unit test triggers BaseMeta.__new__ to create a new class
    (Base) from the class attributes constructed from the FieldAttribute
    available. This unit test also check that BaseMeta.__new__ does as
    expected when in the Base.__dict__ there is a _get_attr_<attribute>
    method available.
    '''
    class Base(with_metaclass(BaseMeta, object)):
        classname = FieldAttribute(isa='string')
        _get_attr_classname = lambda self: 'unit_test'
        use_parent = FieldAttribute(isa='string', inherit=True)
        use_sentinel = FieldAttribute(isa='string', default=Sentinel)
        use_none = FieldAttribute(isa='string', default=None)

# Generated at 2022-06-23 05:56:03.438383
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for FieldAttributeBase.get_ds
    '''

# Generated at 2022-06-23 05:56:06.269645
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    d = FieldAttributeBase()
    assert d.get_loader('bar') == 'bar', 'd.get_loader() returned unexpected value!'



# Generated at 2022-06-23 05:56:12.523221
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    foo = Task()
    ds = dict(hello='world')
    foo._ds = ds
    assert foo.get_ds() == ds

    with patch.object(Task, 'get_ds', return_value=ds):
        assert foo.get_ds() == ds


# Generated at 2022-06-23 05:56:18.012796
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    ''' test preprocess_data of class FieldAttributeBase '''

    f1 = FieldAttributeBase()
    f1.name = 'Test'

    f1.preprocess_data('')
    # AssertionError: should be called by the subclass of FieldAttributeBase


# Generated at 2022-06-23 05:56:30.821679
# Unit test for constructor of class Base
def test_Base():
    ds = dict(
        no_log=True,
        environment=dict(A='B', C='D'),
        vars=dict(a='b', c='d'),
        connection='local',
        remote_user=None,
        become=False,
        become_method='sudo',
        become_user='root',
        become_flags=None,
        become_exe=None,
        port=22,
        check_mode=False,
        diff=False,
        any_errors_fatal=True,
        module_defaults=dict(param1='val1', param2='val2'),
    )
    base = Base(ds)
    assert base._no_log == True
    assert base._environment == ['A=B', 'C=D']

# Generated at 2022-06-23 05:56:32.087549
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    Role = Role()
    Role.serialize()


# Generated at 2022-06-23 05:56:43.214187
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-23 05:56:55.967079
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    """
    Test the constructor of class FieldAttributeBase
    """
    ca = FieldAttributeBase()
    assert isinstance(ca, FieldAttributeBase)
    assert ca.required is True
    assert ca.default is None
    assert ca.aliases == []
    assert ca.always_post_validate is False
    assert ca.static is False
    assert ca.class_type == None
    assert ca.listof == None
    assert ca.isa == None

    ca = FieldAttributeBase(required=False, aliases=['p'], default='default')
    assert isinstance(ca, FieldAttributeBase)
    assert ca.required is False
    assert ca.default == 'default'
    assert ca.aliases == ['p']
    assert ca.always_post_validate is False
    assert ca.static is False
    assert ca.class_

# Generated at 2022-06-23 05:57:03.182953
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():

    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class Attr1(AnsibleBaseYAMLObject):
        yaml_loader = DataLoader()
        yaml_tag = u'!Attr1'
        _get_attr_1 = lambda self: 'attr_1'
        _get_attr_2 = lambda self: 'attr_2'

        def __init__(self, *args, **kwargs):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}
            super(Attr1, self).__init__(**kwargs)

        def __getattr__(self, key):
            if key in self._alias_attrs:
                return

# Generated at 2022-06-23 05:57:10.640511
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  test_object = FieldAttributeBase()
  assert test_object.dump_attrs() == {}
  test_object2 = FieldAttributeBase()
  assert test_object2.dump_attrs() == {}
  test_object3 = FieldAttributeBase()
  assert test_object3.dump_attrs() == {}
  test_object4 = FieldAttributeBase()
  assert test_object4.dump_attrs() == {}
  test_object5 = FieldAttributeBase()
  assert test_object5.dump_attrs() == {}
  test_object6 = FieldAttributeBase()
  assert test_object6.dump_attrs() == {}


# Generated at 2022-06-23 05:57:16.905834
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():

    # create a FieldAttributeBase object.
    fb = FieldAttributeBase()

    # the method to test is the get_variable_manager method.
    # If there is no loader, variable_manager is None, so
    # variable_manager is not set.
    assert fb.get_variable_manager() == None

    # If variable_manager is not None, we set variable_manager
    # to variable_manager
    fb._variable_manager = 'variable_manager'
    assert fb.get_variable_manager() == 'variable_manager'


# Generated at 2022-06-23 05:57:27.908832
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Create object instance
    base_instance = FieldAttributeBase()

    # Test expected case of variable being set and it is a string
    # Test whether is_template is called
    with mock.patch.object(FieldAttributeBase, 'is_template', autospec=True) as mock_is_template:
        mock_is_template.return_value = 'arg_is_template'
        assert base_instance.preprocess_data('arg_data', 'arg_variable_manager', 'arg_loader') == 'arg_is_template'
        mock_is_template.assert_called_once_with('arg_data', 'arg_variable_manager', 'arg_loader')

    # Test expected case of variable being set and it is a list
    # Test whether _preprocess_data_list is called

# Generated at 2022-06-23 05:57:33.269061
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base._aliases = {}
    field_attribute_base._valid_attrs = {'test_attribute': 'value'}
    field_attribute_base.test_attribute = 'test_value'

    assert field_attribute_base.dump_attrs() == {'test_attribute': 'test_value'}

# Generated at 2022-06-23 05:57:40.206207
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Ensure correct retun value for method get_ds of class FieldAttributeBase
    '''
    mock_self = Mock(name='FieldAttributeBase')

    #Arrange

    #Act
    with patch('ansible.parsing.vault.VaultLib.get_decrypted_text') as mock_get_decrypted_text:
        ret = FieldAttributeBase.get_ds(mock_self)

    #Assert
    assert ret is None


# Generated at 2022-06-23 05:57:44.169709
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Ensure we can get the ds from FieldAttributeBase
    '''
    field_attribute_base = FieldAttributeBase()
    field_attribute_base._ds = 'foo'
    assert field_attribute_base.get_ds() == 'foo'


# Generated at 2022-06-23 05:57:54.037939
# Unit test for method get_search_path of class Base

# Generated at 2022-06-23 05:58:05.069986
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    FA = FieldAttributeBase
    # test empty
    assert FA.preprocess_data({}, Sentinel) == {}, "empty"

    # test not set
    assert FA.preprocess_data({'foo': None}, Sentinel) == {}, "not set"

    # test set and defaults
    assert FA.preprocess_data({'foo': None, 'bar': 2}, Sentinel) == {'bar': 2}, "set and defaults"

    # test required
    try:
        FA.preprocess_data({'foo': None}, FA(required=True))
    except AnsibleParserError as e:
        assert 'required' in str(e), "required"
    else:
        raise AssertionError("missing expected Parser exception")

    # test isa types
    FA._do_validate = MagicMock(return_value=True)


# Generated at 2022-06-23 05:58:13.294428
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import ansible.playbook.role
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.role_include

    # construct a dependency chain.
    dep_chain_member1 = namedtuple('dep_chain_member', ['_role_path'])
    dep_chain_member1._role_path = '../../roles/test_role'
    dep_chain_member2 = namedtuple('dep_chain_member', ['_role_path'])
    dep_chain_member2._role_path = '../../roles/test_role_level2'

    dep_chain_list = list()

# Generated at 2022-06-23 05:58:24.301711
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-23 05:58:25.023720
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
  pass

# Generated at 2022-06-23 05:58:30.545995
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create a new instance of the class
    obj = FieldAttributeBase()
    # Check if get_validated_value raises the right exception
    with pytest.raises(TypeError) as error:
        obj.get_validated_value(None, None, None, None)
    # Check if string is returned
    assert isinstance(str(error), str)

# Generated at 2022-06-23 05:58:34.166256
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # make sure that things which haven't been initialized properly error out
    with pytest.raises(AnsibleParserError):
        obj = FieldAttributeBase()
        obj.dump_attrs()


# Generated at 2022-06-23 05:58:36.737264
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base_obj = FieldAttributeBase()
    assert base_obj.get_ds() == ''

# Generated at 2022-06-23 05:58:39.143412
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass


# Generated at 2022-06-23 05:58:43.393456
# Unit test for method get_path of class Base
def test_Base_get_path():
    Mock_Mediator_dict={'_data_source':'test_data_source','_line_number':'test_line_number'}
    Mock_Mediator=Mock(spec=Mediator, **Mock_Mediator_dict)
    assert Base().get_path() == ''


# Generated at 2022-06-23 05:58:48.409564
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # create test objects
    dep_chain = [Base()]
    base = Base()
    # set dependecy chain
    base._parent = dep_chain[0]
    dep_chain.append(base)

    # check
    assert base.get_dep_chain() == dep_chain


# Generated at 2022-06-23 05:58:49.153990
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-23 05:58:58.298604
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestMeta(with_metaclass(BaseMeta, object)):
        test_attr = FieldAttribute(isa='bool', inherit=True)

        def __init__(self):
            for name in self.__class__._valid_attrs:
                setattr(self, name, 'test')

    # Check that the attribute is initialized properly
    t = TestMeta()
    assert t.test_attr == 'test'
    # Check that the attribute is initialized properly with alias
    t.test_attr = True
    t.test = False
    assert t.test_attr == t.test == True
    assert t._get_attr_test_attr() == t._get_attr_test() == True



# Generated at 2022-06-23 05:59:06.014742
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    # Create an instance of FieldAttributeBase
    # and test getting its loader
    f = FieldAttributeBase()
    assert isinstance(f.get_loader(), DataLoader)

# Generated at 2022-06-23 05:59:11.632196
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for the dump_me method of the FieldAttributeBase class
    '''
    # The base class should have no dump_me method (FieldAttribute should have it through inheritance)
    a = FieldAttributeBase()
    result = a.dump_me(a)
    assert_equal(result, None)

# Generated at 2022-06-23 05:59:22.501113
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class TestClass(Base):
        attribute1 = FieldAttribute(isa='str', default='', ignore_type=True)
        attribute2 = FieldAttribute(isa='str', default='')
        attribute3 = FieldAttribute(isa='str', default='')
        attribute4 = FieldAttribute(isa='str', default='')
        attribute5 = FieldAttribute(isa='str', default='')
        attribute6 = FieldAttribute(isa='list', default=[])
        attribute7 = FieldAttribute(isa='str', default='')
        attribute8 = FieldAttribute(isa='str', default='')

        def __init__(self):
            super(TestClass, self).__init__()

    tc = TestClass()

    # if we set an attribute, it should remain
    tc.attribute1 = 'test'

# Generated at 2022-06-23 05:59:26.126156
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''
    field_attribute_base_obj = FieldAttributeBase()
    result = field_attribute_base_obj.get_variable_manager()
    assert not result


# Generated at 2022-06-23 05:59:32.687124
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    import pytest
    a = FieldAttributeBase(is_argument=False, is_static=False, required=False, static=False, isa=None)
    data = dict(required=False, static=False, isa=None)
    with pytest.raises(NotImplementedError):
        a.load_data(data)


# Generated at 2022-06-23 05:59:47.686852
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    import ansible.utils.collection_loader

    class BaseMetaClassTest(Base):
        _valid_attrs = dict()
        _squashed = False
        _finalized = False
        _attributes = dict()

        def __init__(self, x, y, z=None):
            pass

        def _get_attr_X(self):
            pass

        def _get_attr_Y(self):
            pass

    class X(BaseMetaClassTest):
        _valid_attrs = {
            'x': FieldAttribute(default='a'),
            'y': FieldAttribute(),
            'z': FieldAttribute(default='123', inherit=False),
            '_A': FieldAttribute(),
            '_x': FieldAttribute(),
            'b': FieldAttribute(default='a')
        }


# Generated at 2022-06-23 05:59:52.871502
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    Test the constructor of class FieldAttributeBase
    '''

    # Set up the test
    test_attr = 'test_attr'
    test_isa = 'test_isa'

    # Instantiate the class and make sure the attributes are set correctly
    obj = FieldAttributeBase(test_attr, test_isa)
    assert obj.name == test_attr
    assert obj.isa == test_isa


# Generated at 2022-06-23 06:00:00.703191
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    from ansible.utils.vars import combine_vars

    # -------------------------
    # Fail on invalid argument
    # -------------------------
    # name
    with pytest.raises(AssertionError):
        field_attrib = FieldAttributeBase(name=None)
    # name
    with pytest.raises(AssertionError):
        field_attrib = FieldAttributeBase(name='')
    # name
    with pytest.raises(AssertionError):
        field_attrib = FieldAttributeBase(name=1)

    # -------------------------
    # Fail on invalid argument
    # -------------------------
    # default
    with pytest.raises(AssertionError):
        field_attrib = FieldAttributeBase(name='test', default=FieldAttributeBase)
    # default

# Generated at 2022-06-23 06:00:02.637718
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    test_obj = FieldAttributeBase()
    result = test_obj.serialize()
    assert(result == {})



# Generated at 2022-06-23 06:00:06.785829
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        field_attribute_base.get_validated_value(None)

# Generated at 2022-06-23 06:00:09.577828
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit test for method FieldAttributeBase.post_validate
    '''
    # TODO - implement test_FieldAttributeBase_post_validate
    pass

# Generated at 2022-06-23 06:00:19.369542
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test_data = dict()
    # test_data['name'] = {
    #     'value': '',
    #     'error': TypeError
    # }
    # test_data['name'] = {
    #     'value': 'xxx',
    #     'error': TypeError
    # }
    # test_data['name'] = {
    #     'value': 'xxx',
    #     'error': TypeError
    # }
    # test_data['name'] = {
    #     'value': None,
    #     'error': TypeError
    # }
    # test_data['name'] = {
    #     'value': None,
    #     'error': TypeError
    # }
    # test_data['name'] = {
    #     'value': None,
    #     '

# Generated at 2022-06-23 06:00:22.833271
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    a = FieldAttributeBase()
    assert a.get_variable_manager() == None

# Generated at 2022-06-23 06:00:29.050211
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    baseds = DataSource({'type': 'blah', 'path': '/tmp/foo'})
    baseds.set_ds(baseds)
    base._ds = baseds

    # Test when path attribute of base._ds is set to '/tmp/foo' and line_number attribute is not set
    base._ds._line_number = None
    assert base.get_path() == '/tmp/foo:None'

    # Test when path attribute of base._ds is set to '/tmp/foo' and line_number attribute is set to 10
    base._ds._line_number = 10
    assert base.get_path() == '/tmp/foo:10'


# Generated at 2022-06-23 06:00:41.197541
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''

    # unit testing requires many of these objects which would normally be
    # initialized by the controller framework, so do it in this test

    # The controller also initializes a play context, which is used below
    pb = Playbook()
    pl = Play()
    pl._pb = pb

    # The controller also initializes the loader
    loader = DataLoader()
    pl._loader = loader

    # The controller also sets the variable manager on the play, which is used
    # below
    vars_manager = VariableManager()
    pl._variable_manager = vars_manager

    t = Task()
    t._play = pl

    vars_manager.set_nonpersistent_facts(dict(foo='bar'))

# Generated at 2022-06-23 06:00:43.555479
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():

    field_attribute_base = FieldAttributeBase()
    result = field_attribute_base.get_variable_manager()

    assert result is None

# Generated at 2022-06-23 06:00:53.053374
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class BaseMetaTester(object):
        __metaclass__ = BaseMeta
        _another_attr = FieldAttribute(isa='str', default='default')
    class BaseMetaTesterChild(BaseMetaTester):
        _attr1 = FieldAttribute(isa='str', default='default')
        _attr2 = FieldAttribute(isa='str', default='default')

    inst = BaseMetaTesterChild()
    assert hasattr(inst, 'attr1')
    assert hasattr(inst, 'attr2')
    assert hasattr(inst, 'another_attr')
    assert not hasattr(inst, '_attr1')
    assert not hasattr(inst, '_attr2')
    assert not hasattr(inst, '_another_attr')



# Generated at 2022-06-23 06:00:59.870549
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    my_dict = {'name': 'michael'}
    my_string = 'georgia'

    # Test with a dictionary, the name 'michael' should be extracted
    name = FieldAttributeBase.load_data({'name': 'michael'})
    assert name == 'michael'

    # Test with a string, the string 'georgia' should be returned
    name = FieldAttributeBase.load_data('georgia')
    assert name == 'georgia'


# Generated at 2022-06-23 06:01:00.955056
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass


# Generated at 2022-06-23 06:01:05.776376
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    obj.init_attributes()
    assert obj.dump_me() == {'name': 'this', 'default': None, 'isa': None, 'always_post_validate': False, 'private': False, 'aliases': [], 'class_type': None}


# Generated at 2022-06-23 06:01:11.676618
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    base = FieldAttributeBase()
    data = dict(
        name = 'test',
        weight = 100,
        required = False,
        default = 'null',
        choices = ['test']
    )
    base.deserialize(data)
    assert base.name == 'test'
    assert base.weight == 100
    assert base.required == False
    assert base.default == 'null'
    assert base.choices == ['test']

# Generated at 2022-06-23 06:01:12.826815
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert True is True


# Generated at 2022-06-23 06:01:23.421643
# Unit test for constructor of class Base
def test_Base():
    base1 = Base()
    base1.post_validate()

    # Test all the public attributes.
    # Attribute name, attribute type, expected default value.

# Generated at 2022-06-23 06:01:27.241677
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    d = dict(required=True, default=None)
    expected = dict(required=True, default=None, isa='scalar')
    assert FieldAttributeBase(**d) == expected
    assert FieldAttributeBase(**expected) == expected



# Generated at 2022-06-23 06:01:36.988958
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    for i in range(100):
        data = dict(
            a=1,
            b=2,
            c=[1, 2, 3],
            d=UnsafeBytes(b'foo'),
            e=AnsibleUnsafeText(u'foo'),
            f=dict(
                g=1,
                h=2,
                i=3,
            ),
        )
        obj = FieldAttributeBase(**data)
        result = obj.serialize()
        assert result.keys() == data.keys()
test_FieldAttributeBase_serialize()


# Generated at 2022-06-23 06:01:43.235964
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class TestFieldAttributeBase(FieldAttributeBase):
        def __init__(self):
            self.required=True

    obj = TestFieldAttributeBase()
    setattr(obj, 'name', 'test name')
    assert obj.name == 'test name'
    assert isinstance(obj.name, string_types)


# Generated at 2022-06-23 06:01:50.564428
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fixture_path = test_loader.get_fixture_path('')
    variables = ansible_vars.AnsibleVars({}, fixture_path, '', None)
    templar = Templar(variables=variables, loader=None)
    testobj = FieldAttributeBase(templar=templar)
    assert isinstance(testobj.dump_attrs(), dict)



# Generated at 2022-06-23 06:01:52.480033
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    assert False

# Generated at 2022-06-23 06:02:02.203274
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    me = FieldAttributeBase('mykey', None)
    me.class_type = 'foobar'
    me.default = 'some_default'
    me.required = True
    me.static = False
    me.description = 'description of the object'
    me.aliases = ['key', 'key2']
    me.always_post_validate = True
    me.copy = True
    me.default = 'default'
    me.required = True
    me.static = False
    me.description = 'description'
    me.always_post_validate = False
    attrs = me.dump_me()

# Generated at 2022-06-23 06:02:14.131396
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    import ansible.parsing.yaml.objects

    # TODO: File these tests under unit/playbook/
    class BaseTest():
        def test__init_generates_default_attributes(self):
            # The intialized object should have a default value for the
            # attributes that the subclass specifies using FieldAttribute
            f = self.obj()
            for (name, attribute) in iteritems(self.obj._valid_attrs):
                assert getattr(f, name) == attribute.default


# Generated at 2022-06-23 06:02:16.733890
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    with pytest.raises(AttributeError):
        # Testing if there is no _parent, the method should return None
        assert Base().get_dep_chain() is None


# Generated at 2022-06-23 06:02:18.996348
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert isinstance(b._valid_attrs, dict)
    assert b._name == ''
    assert b._port is None



# Generated at 2022-06-23 06:02:28.905117
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    valid_attrs = dict()
    self = FieldAttributeBase(valid_attrs)

    ## test non-null
    attr = type("FieldAttribute", (object,), {'isa': 'string'})()
    value = 'string_value'
    templar = type("Templar", (object,), {'template': lambda x: x})()
    validated_value = self.get_validated_value("name", attr, value, templar)
    assert validated_value == value

    ## test null
    attr = type("FieldAttribute", (object,), {'isa': 'int'})()
    value = None
    templar = type("Templar", (object,), {'template': lambda x: x})()

# Generated at 2022-06-23 06:02:32.579749
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test to validate method FieldAttributeBase.get_loader
    '''
    data = Mock()
    data.name = 'hello'
    data.loader = Mock()
    assert FieldAttributeBase.get_loader(data) == data.loader

# Generated at 2022-06-23 06:02:42.894025
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Unit test for method validate of class FieldAttributeBase
    # ... running validate()
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert not f.required
    # ... check type of FieldAttributeBase.default
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert f.required
    f = FieldAttributeBase()
    assert not f.required
    f = FieldAttributeBase()
    assert f.required
    f = FieldAttributeBase()
    assert f.required
    f = FieldAttributeBase()
    assert f.required


# Generated at 2022-06-23 06:02:53.906909
# Unit test for constructor of class Base
def test_Base():
    import json

    yaml_doc = '''
    ---
    - hosts: localhost
      tasks:
        - ping: { name: test }
        - block:
            - debug: msg="hello1"
            - debug: msg="hello2"
          rescue:
            - debug: msg="hello3"
          always:
            - debug: msg="hello4"
    '''

    tc = task_include.TaskInclude(play=None, variable_manager=variable_manager.VariableManager(), loader=None)
    results = tc.load_from_file(yaml.safe_load(yaml_doc))

    play = Play().load(results[0], variable_manager=variable_manager.VariableManager(), loader=None)

    # ensure base class constructor works
    b = Base()
    # ensure we can set attributes
   