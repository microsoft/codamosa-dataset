

# Generated at 2022-06-23 05:52:54.219291
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Fixture data
    args = {}
    name = '_task'
    value = {}
    task = Task()

    # Pass fixture data to method
    out = FieldAttributeBase.load_data(name, value, task, args)

    # Assert result
    assert out is None



# Generated at 2022-06-23 05:52:55.958885
# Unit test for method get_path of class Base
def test_Base_get_path():
    # FIXME: write a proper unit test
    b = Base()
    b.get_path()

# Generated at 2022-06-23 05:52:57.454708
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    """
    Test deserialize
    """
    pass



# Generated at 2022-06-23 05:53:06.363170
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method load_data of class FieldAttributeBase
    '''
    fake_class = type('fake_class', (object, ), {})
    fake_attributename = 'fake_attributename'
    attribute = FieldAttributeBase(fake_class, fake_attributename)

    fake_obj = FakeAnsibleObject([])
    fake_ds = 'fake_ds'
    fake_ds_type = 'fake_ds_type'
    fake_resolver = mock.MagicMock(spec=VariableManager)
    fake_resolver.list_templates.return_value = []
    fake_templar = Templar(loader=None, variables=fake_resolver)
    fake_task_vars = 'fake_task_vars'
    fake_preprocessor = 'fake_preprocessor'
   

# Generated at 2022-06-23 05:53:15.796730
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Setup
    fake_name = 'fake_name'
    fake_default = 'fake_default'
    fake_required = True
    fake_type = None
    fake_choices = None

    test_object = FieldAttributeBase(
        name=fake_name,
        default=fake_default,
        required=fake_required,
        type=fake_type,
        choices=fake_choices
    )

    # Exercise
    with pytest.raises(NotImplementedError) as error:
        test_object.validate()

    # Verify
    assert str(error.value) == "Cannot call validate on FieldAttributeBase"


# Generated at 2022-06-23 05:53:23.618238
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.task import Task
    print(Task._attributes)
    print(Task._alias_attrs)
    print(Task._attributes['name'])
    print(Task._attributes['tags'])
    print(Task._valid_attrs['name'])
    print(Task._valid_attrs['tags'])
    print(Task._alias_attrs['tags'])
    print(Task._alias_attrs['action'])


# Generated at 2022-06-23 05:53:27.941153
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    base._ds = AnnotatedDataSource.load_from_file('/home/vagrant/git/ansible/test/units/data/playbooks/playbook1.yml')
    path = base.get_path()
    assert path == '/home/vagrant/git/ansible/test/units/data/playbooks/playbook1.yml:5'


# Generated at 2022-06-23 05:53:30.651450
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    field = FieldAttributeBase()
    assert field.get_loader() == None


# Generated at 2022-06-23 05:53:34.249353
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    ba = FieldAttributeBase()

    assert(ba.serialize() == dict())

    ba.foo = 1

    assert(ba.serialize() == dict(foo=1))


# Generated at 2022-06-23 05:53:44.709895
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    class TestModule(object):
        def __init__(self):
            self.argument_spec = {}
            self.params = {}
            self.modules = {}
            self.deprecated = {}

    test_module = TestModule()
    arg_spec = {
        'name': {'required': True, 'type': 'str'},
        'new': {'required': False, 'type': 'bool', 'default': False},
    }

    parsed = ModuleParser.parse_argspec(test_module, arg_spec)
    assert parsed['name']['required'] is True
    assert parsed['name']['default'] == FieldAttributeBase.NO_DEFAULT
    assert parsed['name']['type'] == 'str'
    assert parsed['new']['required'] is False

# Generated at 2022-06-23 05:53:48.358479
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
	assert False, "TODO: Write unit tests for FieldAttributeBase.serialize"


# Generated at 2022-06-23 05:53:51.910464
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Given a FieldAttributeBase object
    # When we call preprocess_data
    # Then ensure the method return a string
    pass


# Generated at 2022-06-23 05:53:56.573356
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create a new FieldAttributeBase instance, then use the "copy" method
    # to create a copy of it
    fa_base_1 = FieldAttributeBase('foo')

    # Verify that the "copy" method works correctly
    assert fa_base_1.copy() == fa_base_1

# Generated at 2022-06-23 05:54:07.733904
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    p = PlayContext()
    t = Task()
    PC = PlayContext()
    pcb = PlayContext()
    pcb._loader = 'foo'
    pcb._variable_manager = 'bar'
    pcb._validated = True
    pcb._finalized = True
    pcb._uuid = 'baz'
    pcb._ds = {}
    pcb._ds['foo'] = 'bar'
    pct = pcb.copy()
    assert pct._uuid == pcb._uuid
    assert pct._ds['foo'] == pcb._ds['foo']
    assert pct

# Generated at 2022-06-23 05:54:12.521693
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase()
    assert not obj.deserialize("/")


# Generated at 2022-06-23 05:54:21.882105
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj1 = FieldAttributeBase()
    obj1.register_loader('loader', None)
    obj1.register_var_manager('var_manager', None)
    obj1.register_validator('validator', None)
    obj1.post_validate('templar')
    obj2 = FieldAttribute()
    obj2.raw = 1
    obj2.default = 'DEFAULT'
    obj2.default_var = 'DEFAULT_VAR'
    obj2.name = 'NAME'
    obj2.aliases = ['ALIASES']
    obj2.class_type = 1
    obj2.bool = True
    obj2.static = True
    obj2.final = True
    obj2.required = True
    obj2.always_post_validate = True
    obj2.no_log = True


# Generated at 2022-06-23 05:54:23.408139
# Unit test for constructor of class Base
def test_Base():
    b = Base()


# Generated at 2022-06-23 05:54:25.820169
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.deserialize(data)

# Generated at 2022-06-23 05:54:31.750358
# Unit test for method get_path of class Base
def test_Base_get_path():
    from units.mock.loader import DictDataLoader

    class TestClass(object):
        _ds = DictDataLoader({'path':'/test/path'})
        _ds._line_number = 10
        def __init__(self):
            pass

    test_class = TestClass()
    assert test_class.get_path() == "/test/path:10"


# Generated at 2022-06-23 05:54:37.432825
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Test fixture
    test_attrs = load_fixture('attributes.yaml')

    # create a test class and fill with data
    test_class = FieldAttributeBase()
    test_class.from_attrs(test_attrs)

    # check results
    assert hasattr(test_class, '_loader')
    assert hasattr(test_class, '_variable_manager')
    assert hasattr(test_class, '_validated')
    assert hasattr(test_class, '_finalized')
    assert hasattr(test_class, '_uuid')



# Generated at 2022-06-23 05:54:45.013110
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    we always want to return the ds field from the task or the host, or {}
    if neither are set
    '''
    f = FieldAttributeBase()
    assert f.get_ds() == {}

    f.set_ds('foo')
    assert f.get_ds() == 'foo'

    h = HostVars()
    h.set_ds('foo')
    f.set_ds(h)
    assert f.get_ds() == 'foo'

    t = Task()
    t.set_ds('bar')
    f.set_ds(t)
    assert f.get_ds() == 'bar'



# Generated at 2022-06-23 05:54:52.837872
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    A = FieldAttributeBase()
    B = FieldAttributeBase()
    a = A._squash
    b = B._squash
    assert a.__name__ == b.__name__
    assert a.__doc__ == b.__doc__
    assert inspect.getfile(a) == inspect.getfile(b)
    assert a.__closure__ == b.__closure__
    c = A._squash(None, None)
    assert c is None
# test_FieldAttributeBase_squash


# Generated at 2022-06-23 05:55:01.710500
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Load data from a task into an object
    def _test_load_data_from_task(count=0, path=None, task_vars=dict(), **kwargs):
        # If a playbook path is specified, load the playbook
        if path is not None:
            loader = DataLoader()
            pb = Playbook.load(path, variable_manager=VariableManager(), loader=loader)
            play = pb.get_plays()[0]
            tqm = None

            # Run the playbook
            play_context = PlayContext()
            run_once = True
            ds = None

# Generated at 2022-06-23 05:55:11.414325
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    # Declare a simple inheritance tree
    class A (object):
        f = FieldAttribute('f', inherit=True, default=None)

    class B (A):
        g = FieldAttribute('g', inherit=True, default=None)

    class C (B):
        h = FieldAttribute('h', inherit=True, default=None)

    # Declare a class BaseMeta_Test which is derived from the inheritance tree
    class BaseMeta_Test(with_metaclass(BaseMeta, C)):
        pass

    # Check class BaseMeta_Test is present and has __bases__
    assert(BaseMeta_Test)
    assert(BaseMeta_Test.__bases__)

    # Check class BaseMeta_Test has properties for all the attributes
    assert('f' in BaseMeta_Test.__dict__)

# Generated at 2022-06-23 05:55:13.244917
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass



# Generated at 2022-06-23 05:55:21.136184
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert False
# end unit test for method get_search_path of class Base

    def _get_parent_attribute(self, attr, from_cache=True, extend=False):
        if hasattr(self, '_parent') and self._parent:
            try:
                getter = getattr(self._parent, '_get_%s_attribute' % attr)
                val = getter(from_cache=from_cache)
                if val is not None:
                    return val
            except (AttributeError, AnsibleUndefinedVariable):
                pass

        if extend:
            return []
        else:
            return None

    def _get_name_attribute(self, from_cache=True):
        '''
        Returns the name of an object, or returns None if it is not set.
        '''


# Generated at 2022-06-23 05:55:31.214649
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Test method squash of class FieldAttributeBase.
    '''

    task = Task()
    task.name = 'mytask'
    task.description = 'mydescription'

    task_squashed = task.squash()

    task_attrs = task.dump_attrs()
    task_squashed_attrs = task_squashed.dump_attrs()


# Generated at 2022-06-23 05:55:35.593377
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_fieldattributebase = FieldAttributeBase()
    try:
        test_fieldattributebase.dump_me()
    except Exception as e:
        assert False, "An exception was raised: %s" % e


# Generated at 2022-06-23 05:55:40.901974
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestAttribute(Attribute):
        pass

    class TestParent(Base):
        test = TestAttribute(default='default_parent')

    class TestChild(TestParent):
        test = TestAttribute(default='default_child', inherit=False)

    assert hasattr(TestChild, 'test')
    assert hasattr(TestChild, '_valid_attrs')
    assert hasattr(TestChild, '_attributes')
    assert 'test' in TestChild._valid_attrs
    assert 'test' in TestChild._attributes
    assert TestChild.test == 'default_child'



# Generated at 2022-06-23 05:55:44.210073
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    test_cases = []
    # test_cases.append((1,2))
    return test_cases

# Generated at 2022-06-23 05:55:53.621713
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    def test_assert(condition, message):
        if not condition:
            raise AssertionError(message)

    fa = FieldAttributeBase('foo', 'foo', 'foo')
    test_assert(fa.name == 'foo', 'FieldAttributeBase.name != "foo"')
    test_assert(fa.private is False, 'FieldAttributeBase.private is True by default')
    test_assert(fa.static is False, 'FieldAttributeBase.static is True by default')
    test_assert(fa.required is False, 'FieldAttributeBase.required is True by default')

    fa = FieldAttributeBase('bar', 'bar', 'bar', private=True, static=True, required=True)
    test_assert(fa.name == 'bar', 'FieldAttributeBase.name != "bar"')

# Generated at 2022-06-23 05:55:56.360467
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    fieldattributebase = FieldAttributeBase()
    assert isinstance(fieldattributebase.get_variable_manager(), VariableManager)


# Generated at 2022-06-23 05:55:59.053447
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert b._connection == 'local'

    b = Base(connection='smart')
    assert b._connection == 'smart'

# ---

# Generated at 2022-06-23 05:56:08.836347
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = {
        'required': True,
        'default': 'value',
        'private': True,
        'choices': ['value1', 'value2'],
        'immutable': True,
        'aliases': ['var1', 'var2'],
        'parse_as': 'yaml',
        'post_validators': [],
        'always_post_validate': False,
    }
    expected = (['value1', 'value2'], 'yaml', False)
    actual = FieldAttributeBase._preprocess_data(data, 'choices')
    assert actual == expected



# Generated at 2022-06-23 05:56:15.346164
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    from ansible.loader.base import BaseLoader

# Generated at 2022-06-23 05:56:21.566577
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import unittest
    # create Base object
    base = Base()
    action = ActionBase()
    action._role_path = 'roles/test'
    base._parent = action
    assert base.get_search_path() == ['roles/test']

    # cover the case where None is returned
    action = ActionBase()
    base._parent = action
    assert base.get_search_path() == []



# Generated at 2022-06-23 05:56:25.914097
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    data = {"tag": "tag_value", "var": "var_value"}

    class TestClass(FieldAttributeBase):
        _valid_attrs = {
            "tag": FieldAttribute(isa='string'),
            "var": FieldAttribute(isa='string'),
        }

    obj = TestClass(data)
    result = obj.serialize()
    assert result == data

# Generated at 2022-06-23 05:56:28.160183
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    my_field = FieldAttributeBase()
    my_obj = {}
    my_field.load_data(my_obj)
    return True


# Generated at 2022-06-23 05:56:31.961301
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Initialize the test for the method copy of class FieldAttributeBase
    # TEST CASE: FieldAttributeBase.copy() returns a copy of itself
    from ansible.parsing.yaml.objects import FieldAttributeBase
    fa = FieldAttributeBase()
    fa2 = fa.copy()
    assert isinstance(fa2, FieldAttributeBase)



# Generated at 2022-06-23 05:56:34.047149
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase()
    # call method
    obj.squash()
    # test assert
    assert obj._squashed


# Generated at 2022-06-23 05:56:37.974590
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FieldAttributeBase._load_fields(__name__)
    assert FieldAttributeBase._field_names == ['FieldAttributeBase_field_name']
    return



# Generated at 2022-06-23 05:56:40.457761
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    # pass in some object that can be used by validator
    obj.validate(None)
    pass


# Generated at 2022-06-23 05:56:42.893129
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_obj=Base()
    base_obj._parent=Base()
    assert base_obj.get_dep_chain()!=None

# Generated at 2022-06-23 05:56:55.560123
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    attr = FieldAttributeBase('bool', 'foo', 'bar')
    assert attr.name == 'foo'
    assert attr.description == 'bar'
    assert attr.alias == []
    assert attr.choices is None
    assert attr.default is None
    assert attr.required is False
    assert attr.always_post_validate is False
    assert attr.delegate_to is None
    assert attr.deprecated is None
    assert attr.aliases == {}
    assert attr.version_added is None
    assert attr.version_removed is None
    assert attr.aliases == {}
    # Test setting options
    attr.choices = ('foo', 'bar', 'baz')
    assert attr.choices == ('foo', 'bar', 'baz')
   

# Generated at 2022-06-23 05:56:58.542531
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    b = AnsibleBaseYAMLObject()
    assert b.deserialize({'something': 'blah'}) == {'something': 'blah'}
# end class FieldAttributeBase


# Generated at 2022-06-23 05:57:08.264490
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task

    ##################################################
    # Test that constructor of BaseMeta class
    # creates some additional class attributes
    # _attributes, _attr_defaults, _valid_attrs, _alias_attrs
    ##################################################

    class TestBase(with_metaclass(BaseMeta, object)):
        pass

    assert hasattr(TestBase, '_attributes'), \
        "TestBase class should have _attributes class attribute"
    assert hasattr(TestBase, '_attr_defaults'), \
        "TestBase class should have _attr_defaults class attribute"

# Generated at 2022-06-23 05:57:15.820711
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Setting up variables for the test
    FABA_inst = FieldAttributeBase()
    FABA_inst._variable_manager = None

    # The assertion to check that the error is thrown if the FieldAttributeBase instance's variable_manager is None
    with pytest.raises(AnsibleAssertionError, match="field attribute base object's variable manager is None"):
        FABA_inst.get_variable_manager()



# Generated at 2022-06-23 05:57:23.692965
# Unit test for method preprocess_data of class FieldAttributeBase

# Generated at 2022-06-23 05:57:33.835142
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.default = None
    field_attribute_base.isa = None
    field_attribute_base.required = False
    field_attribute_base.always_post_validate = False
    field_attribute_base.static = False
    result = field_attribute_base.copy()
    assert isinstance(result, FieldAttributeBase)
    assert result.default == None
    assert result.isa == None
    assert result.required == False
    assert result.always_post_validate == False
    assert result.static == False

# Generated at 2022-06-23 05:57:34.986663
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass



# Generated at 2022-06-23 05:57:37.759184
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase()

    # No params should raise a TypeError
    with pytest.raises(TypeError):
        obj.load_data()
    

# Generated at 2022-06-23 05:57:46.119436
# Unit test for method get_path of class Base
def test_Base_get_path():
    module_utils.basic.ANSIBLE_MODULE_KWARGS = module_utils.basic.DEFAULT_KWARGS
    module_utils.basic._ANSIBLE_ARGS = module_utils.basic.DEFAULT_ARGS
    # Run the method
    try:
        get_path()
    except SystemExit:
        try:
            get_path()
        except SystemExit:
            pass
    module_utils.basic.ANSIBLE_MODULE_KWARGS = module_utils.basic.DEFAULT_KWARGS
    module_utils.basic._ANSIBLE_ARGS = module_utils.basic.DEFAULT_ARGS


# Generated at 2022-06-23 05:57:46.741685
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass

# Generated at 2022-06-23 05:57:52.021186
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create an instance of FieldAttributeBase
    fa = FieldAttributeBase()
    # Test that from_attrs raises expected exception
    with pytest.raises(AnsibleAssertionError) as excinfo:
        fa.from_attrs({})
    # Test that from_attrs raises expected exception
    with pytest.raises(AnsibleAssertionError) as excinfo:
        fa.from_attrs("")

# Generated at 2022-06-23 05:58:03.831915
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Foo(object):
        def __init__(self):
            self.__dict__ = {}
        @property
        def _(self):
            return self.__dict__
    foo = Foo()

    class Bar(object):
        def __init__(self):
            self.__dict__ = {}
        @property
        def _(self):
            return self.__dict__
    bar = Bar()

    class Baz(object):
        def __init__(self):
            self.__dict__ = {}
        @property
        def _(self):
            return self.__dict__
    baz = Baz()

    # create meta class
    meta = BaseMeta("BaseMeta", (object,), {})
    # create new class by meta class

# Generated at 2022-06-23 05:58:14.288590
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''
    # Test case 1
    # test_case1 = FieldAttributeBase()
    # The method FieldAttributeBase.get_variable_manager does not exist.
    # It raises AttributeError exception.
    # assert_raises(
    #     AttributeError,
    #     test_case1.get_variable_manager)


# Generated at 2022-06-23 05:58:15.476171
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
  pass # Not yet implemented


# Generated at 2022-06-23 05:58:16.532977
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    assert True



# Generated at 2022-06-23 05:58:26.079613
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    options = dict(
        default=None,
        private=True,
    )
    # create a FieldAttributeBase object
    f = FieldAttributeBase(options)

    data = dict(
        foo=5,
        bar=6,
        baz=7,
    )

    for option in options:
        assert not hasattr(f, option)

    f.load_data(data)

    # confirm the load worked
    for (key, value) in iteritems(data):
        assert hasattr(f, key)
        assert getattr(f, key) == value


# Generated at 2022-06-23 05:58:28.383178
# Unit test for constructor of class Base
def test_Base():
    assert Base()._connection == context.CLIARGS['connection']
    assert Base().get_search_path() == []


# Generated at 2022-06-23 05:58:31.453341
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    a = Attribute()
    b = FieldAttributeBase(name='foo')
    b.from_yaml('bar')
    return a.serialize() == b.serialize()

# Generated at 2022-06-23 05:58:37.194170
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase()
    attr = 'name'
    buf = ''
    expected = ''
    with pytest.raises(AnsibleAssertionError) as excinfo:
        buf = obj.deserialize(attr)
    assert str(excinfo.value) == 'data (%s) should be a dict but is a %s' % (attr, type(attr))






# Generated at 2022-06-23 05:58:45.449299
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    host = FakeHost()
    templar = Templar(loader=DataLoader(), variables={'omit': 'omit'})

    val = FieldAttributeBase(isa='bool', default=False)
    assert val.post_validate(templar) is False
    val = FieldAttributeBase(isa='bool', default=True)
    assert val.post_validate(templar) is True

    val = FieldAttributeBase(isa='float', default=0)
    assert val.post_validate(templar) == 0
    val = FieldAttributeBase(isa='float', default=1.1)
    assert val.post_validate(templar) == 1.1

    val = FieldAttributeBase(isa='int', default=0)
    assert val.post_validate(templar) == 0
    val = Field

# Generated at 2022-06-23 05:58:56.281018
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fa = FieldAttributeBase(isa='int', required=True)
    assert fa.get_validated_value('foo', fa, '123', None) == 123
    assert fa.get_validated_value('foo', fa, '1.23', None) == 1
    assert fa.get_validated_value('foo', fa, None, None) == 123
    assert fa.get_validated_value('foo', fa, 456, None) == 456
    fa.default = None
    try:
        fa.get_validated_value('foo', fa, None, None)
    except AnsibleParserError as e:
        assert 'required but was not set.' in to_text(e)
    else:
        assert False, "AnsibleParserError not raised"

# Generated at 2022-06-23 05:58:58.958115
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fa = FieldAttributeBase()
    assert fa.load_data('test') == 'test'


# Generated at 2022-06-23 05:59:03.960973
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base = FieldAttributeBase('var')
    dict_ = dict()
    dict_['var'] = "field"
    copy_ = field_attribute_base.copy(dict_)
    assert copy_ == dict_

# Generated at 2022-06-23 05:59:16.790865
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent():
        _one = FieldAttribute('one')
        _two = FieldAttribute('two', exclude=True)
        _three = FieldAttribute('three', inherit=False)
        _four = FieldAttribute('four', inherit=False)
        _five = FieldAttribute('five', default=True)

    class Child(Parent):
        _three = FieldAttribute('three', inherit=False)
        _four = FieldAttribute('four', inherit=False, default=False)
        _five = FieldAttribute('five', inherit=False, default=False)

    _meta = BaseMeta('Child', (Parent,), dict(Child.__dict__))
    assert _meta.__name__ == 'Child'
    assert _meta._attributes == dict(one=Sentinel, three=Sentinel, four=Sentinel, five=Sentinel)
    assert _meta._

# Generated at 2022-06-23 05:59:20.510437
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    f = FieldAttributeBase()
    data = {}
    f.deserialize(data)
    assert isinstance(f, FieldAttributeBase), 'FieldAttributeBase().deserialize() should return a FieldAttributeBase'
# test FileAttribute.deserialize

# Generated at 2022-06-23 05:59:21.878832
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    assert True



# Generated at 2022-06-23 05:59:23.176947
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = Base()
    assert obj.get_search_path() == None

# Generated at 2022-06-23 05:59:27.700667
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    data = dict(foo="bar")
    loader = DataLoader()
    obj = PlayContext(loader=loader)

    obj.deserialize(data)

    assert obj._loader is loader
    assert obj.foo == "bar"


# Generated at 2022-06-23 05:59:31.917499
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    args = [data]
    from ansible.playbook.task import Task
    task = Task()
    task.deserialize(data)


# Generated at 2022-06-23 05:59:41.093442
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    FABC = FieldAttributeBase
    # Test with value which is a type of FieldAttributeBase
    ABC = FABC()
    ABC._ds = "ABC"
    assert ABC.get_ds() == "ABC"
    # Test with value which is not a type of FieldAttributeBase
    FABC._ds = "FABC"
    assert FABC.get_ds() == "FABC"
    FABC._ds = None
    assert FABC.get_ds() == None

# Generated at 2022-06-23 05:59:44.301664
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_obj = FieldAttributeBase()
    assert test_obj.get_validated_value('name', 'attribute', 'value', 'templar') is None


# Generated at 2022-06-23 05:59:49.785517
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    import pytest
    # Test with the default values for args
    obj = FieldAttributeBase()
    # No exception should be raised
    with pytest.raises(NotImplementedError) as excinfo:
        obj.load_data()
    assert excinfo.value.args[0] == "FieldAttributeBase instances have no load_data() method"


# Generated at 2022-06-23 05:59:56.006040
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    This method is used to test the get_ds method of class FieldAttributeBase
    '''
    my_ds = {'a': 1}
    fdb = FieldAttributeBase()
    fdb._ds = my_ds
    assert fdb.get_ds() == my_ds

# Generated at 2022-06-23 06:00:00.097841
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    attr = FieldAttribute(isa = 'string')
    obj = FieldAttributeBase()
    obj._valid_attrs = {'attr': attr}
    obj._squashed = False
    obj.attr = 'foo'
    assert obj.attr == 'foo'
    obj.squash()
    assert obj.attr == 'foo'


# Generated at 2022-06-23 06:00:01.250863
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert Base().get_search_path() == []


# Generated at 2022-06-23 06:00:13.814803
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Pull in FieldAttribute class
    from ansible.utils.vars import FieldAttribute

    # Test vars
    name = 'foo'
    value = 'bar'
    templar = 'baz'

    # Instantiate FieldAttributeBase obj
    test_obj = FieldAttributeBase()

    # Test cases
    attr_cases = {'string': 'bar', 'int': 0, 'float': 0.0, 'bool': True, 'percent': 0.0, 'list': [], 'set': set(), 'dict': {}, 'class': ''}
    attr_types = [FieldAttribute(name=name, attribute_type=attr_types, isa=attr_type) for attr_type, attr_types in attr_cases.items()]


# Generated at 2022-06-23 06:00:24.779845
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # This is a description of how I would like to write unit tests in the future

    # First we create a class that inherits from FieldAttributeBase (or any other class)
    class ExampleClass(FieldAttributeBase):

        # Then we set the attribute _valid_attrs
        _valid_attrs = dict(
            one=FieldAttribute(isa='string'),
            two=FieldAttribute(isa='int', default=123),
            three=FieldAttribute(isa='bool', default=True),
        )

        # And finally we define the constructor
        def __init__(self):
            self._attributes['one'] = 'single'
            self._attributes['two'] = False
            self._attributes['three'] = False

    # After that we create a object from the class we just created
    obj = ExampleClass()

    # And we call the method

# Generated at 2022-06-23 06:00:32.974726
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # ensures that data of type dict is returned
    class _Test_FieldAttributeBase(FieldAttributeBase):

        def __init__(self):
            pass

        def dump_attrs(self):
            return {'one' : 1, 'two' : 2}

    expected_result = {'one' : 1, 'two' : 2}

    actual_result = _Test_FieldAttributeBase().dump_me()

    assert actual_result == expected_result, "%s != %s" % (actual_result, expected_result)

# Generated at 2022-06-23 06:00:38.949890
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test_list = ['play_lib', 'role_lib', 'playbook_dir']
    path_stack = Base().get_search_path()
    assert path_stack == test_list, 'Base.get_search_path() should return %s' % test_list

if __name__ == "__main__":
    test_Base_get_search_path()

    print("Done")

# Generated at 2022-06-23 06:00:51.185438
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # TODO: improve test
    global_vars_path = '~/ansible/test/units/lib/ansible/parsing/dataloader/vars'
    self = FieldAttributeBase(
        name='vars',
        default=None,
        doc='Playbook or task vars',
        vars_template=None,
        vars_prompt=None,
        always_post_validate=True,
        no_log=False,
        private=True,
        version_added=None,
        version_added_attribute=True,
        aliases=None,
        choices=None,
        free_form=None,
        type='dict',
        elements=None,
        skip_values=None,
        static=False,
        static_vars=None,
    )

# Generated at 2022-06-23 06:00:55.223601
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.block import Base
    from ansible.playbook.attribute import Attribute
    class Myclass(Base):
        name = Attribute(required=True)
    assert 'test_BaseMeta___new__' in dir(Myclass)


# Generated at 2022-06-23 06:01:03.960936
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Create a DemoFieldAttributeBase
    objFieldAttributeBase = FieldAttributeBase()
    # Create a dict obj_data
    obj_data = dict()
    # Call method deserialize of FieldAttributeBase with argument obj_data
    objFieldAttributeBase.deserialize(obj_data)


# Generated at 2022-06-23 06:01:11.958368
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping

    attrs = dict()
    attrs['_loader'] = None
    attrs['_variable_manager'] = None
    attrs['_valid_attrs'] = dict()
    attrs['_attributes'] = dict()
    attrs['_attributes']['delegate_to'] = AnsibleUnicode(u'localhost')
    attrs['_attributes']['run_once'] = False
    attrs['_attributes']['hosts'] = [AnsibleUnicode(u'localhost')]
    attrs['_attributes']['tags'] = set(u'test')

# Generated at 2022-06-23 06:01:15.314222
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # FIXME: This unit test assumes a non-standard setup of Ansible,
    # and will probably fail if run outside a full testsuite run.
    # Instead, it should use/test an internal loader instead.
    loader = get_loader()
    assert isinstance(loader, BaseLoader)


# Generated at 2022-06-23 06:01:17.657791
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    base._parent = Base()
    base._parent._parent = Base()
    base.get_dep_chain()


# Generated at 2022-06-23 06:01:29.058669
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    # class DummyClass(Base):
    #     foo = FieldAttribute(isa='string', default='foo')
    #     bar = FieldAttribute(isa='string', default='bar')
    #     _doubledash = FieldAttribute(isa='string', default='baz')
    class DummyClass(object, metaclass=BaseMeta):
        foo = FieldAttribute(isa='string', default='foo')
        bar = FieldAttribute(isa='string', default='bar')
        _doubledash = FieldAttribute(isa='string', default='baz')
    assert DummyClass.foo is DummyClass.bar, 'constructor of class BaseMeta did not work correctly'

# TODO: split class into mix-in and actual class?

# Generated at 2022-06-23 06:01:39.071143
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Set up test environment
    fixture_loader = FixtureLoader()
    name=''
    attribute = FieldAttributeBase()
    value = field_attribute_base_value_fixture
    templar = fixture_loader.load_fixture('templar')

    # Exercise SUT (System Under Test)
    # with
    # - a call to the SUT being executed and
    # - the assertion that the SUT must return a value (should not raise an exception)
    ansible_module_mock = AnsibleModule(argument_spec={})
    result = ansible_module_mock.get_validated_value(name, attribute, value, templar)
    # Verify assertions
    assert result is not None


# Generated at 2022-06-23 06:01:43.965666
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # set up a FieldAttributeBase object
    fieldattributebase_obj = FieldAttributeBase()
    # test FieldAttributeBase
    fieldattributebase_obj.load_data()
    # test FieldAttributeBase
    fieldattributebase_obj.load_data()

# Generated at 2022-06-23 06:01:45.924659
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 06:01:47.966769
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # data = self.get_ds()
    pass


# Generated at 2022-06-23 06:01:58.936384
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    def test_copy(self_data, self_cls, self_static, self_isa, self_default, self_required, self_always_post_validate, self_class_type, self_aliases, self_deprecate_aliases, self_listof, result):
        object = FieldAttributeBase(
            self_data, self_cls, self_static, self_isa, self_default, self_required, self_always_post_validate, self_class_type, self_aliases, self_deprecate_aliases, self_listof,
        )
        assert object.copy() == result


# Generated at 2022-06-23 06:02:01.875556
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    class Testable:
        loader = None
    testable = Testable()
    fa = FieldAttributeBase()
    result = fa.get_loader(testable)
    assert result == None, "result was not None, it was %s" % result


# Generated at 2022-06-23 06:02:13.957932
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from collections import OrderedDict

    # Note: need to use OrderedDict so that keys() returns the keys in order

# Generated at 2022-06-23 06:02:15.717898
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert Base().get_search_path() == []



# Generated at 2022-06-23 06:02:25.775919
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # we run the basic object test first, to ensure the difference
    # between the base object and object doesn't cause any issues
    test_BaseObject_dump_attrs()

    # dump_attrs should have the same behavior as object if no valid_attrs
    # is set
    assert BaseObject().dump_attrs() == {}

    # create a FieldAttributeBase with a valid_attrs field and values
    attrs = {
        'one': 'one',
        'two': 2,
        'three': 3.0,
        'four': True,
        'five': False,
        # list and dict are not isa supported
        'list': [1, 2, 3],
        'dict': {'one': 1, 'two': 2, 'three': 3}
    }
    base = FieldAttributeBase(**attrs)


# Generated at 2022-06-23 06:02:28.101753
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # TODO: Test name is missing in this test
    pass

# Generated at 2022-06-23 06:02:35.363798
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Set up mock
    expected = 'mock'
    attr = FieldAttributeBase('test attr', always_post_validate=False, default=None, isa=None, include=None, exclude=None, scope=None, static=False, listof=None)
    ds = 'mock_ds'
    validate=True

    # Invoke method
    attr.preprocess_data(expected, validate)

    # Tests
    assert expected == 'mock'


# Generated at 2022-06-23 06:02:38.402219
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method get_loader of class FieldAttributeBase
    '''
    obj = FieldAttributeBase()
    assert not obj.get_loader()



# Generated at 2022-06-23 06:02:48.250024
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base.copy() is not field_attribute_base
    assert type(field_attribute_base.copy()) == FieldAttributeBase
    # TODO create a test that checks copy() is not the same object as the original
    # TODO create a test that checks copy() is not the same object as the original
    # TODO create a test that checks copy() is not the same object as the original

# Generated at 2022-06-23 06:02:56.554511
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # 1. create MockDataSource
    play_ds = MockDataSource("fake_playbook")
    play_ds._line_number = 0
    # 2. create MockObject
    play = MockObject()
    play._ds = play_ds
    # 3. create MockDataSource
    role_ds = MockDataSource("fake_role")
    role_ds._line_number = 0
    # 4. create MockObject
    role = MockObject()
    role._ds = role_ds
    # 5. create MockObject
    play._role_path = "fake_role_path"
    # 6. create MockObject
    role._play = play
    # 7. create MockDataSource
    task_ds = MockDataSource("fake_task")
    task_ds._line_number = 0
    # 8. create MockObject
    task