

# Generated at 2022-06-23 05:52:55.238493
# Unit test for constructor of class Base
def test_Base():
    """ constructor of Base """
    base = Base()
    assert base._name == ''
    base2 = Base()
    base2._name = 'name'
    assert base2._name == 'name'


# Generated at 2022-06-23 05:53:03.800156
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Foo:
        def __init__(self):
            self.bar = 'baz'
        class Meta:
            a = FieldAttribute(isa='str')
            b = FieldAttribute(isa='str', inherit=False)

    class Bar(BaseMeta):
        __metaclass__ = BaseMeta
        c = FieldAttribute(isa='str')
        d = FieldAttribute(isa='str', alias='D')
        def _get_attr_c(self):
            return 'e'
        def _get_parent_attribute(self):
            return 'parent_attribute'
    class Foobar(Foo, Bar):
        def _get_attr_e(self):
            return 'f'
        pass
    assert Foobar().Meta.a == Foobar().Meta.b == 'parent_attribute'
    assert Foobar().Meta.d

# Generated at 2022-06-23 05:53:08.334396
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    # Setup
    task = Task()
    task.action = 'file'

    # Test
    attrs = task.to_task_include()
    task.action = 'user'
    task.from_attrs(attrs)

    # Verify
    assert task.action == 'file'


# Generated at 2022-06-23 05:53:16.871861
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    """
    Make sure the method serialize works as expected
    """
    class DummyObject(FieldAttributeBase):
        pass

    obj = DummyObject()
    assert obj.serialize() == {
        'uuid': None,
        'finalized': False,
        'squashed': False,
    }

    obj = DummyObject(
        uuid=1,
        finalized=True,
        squashed=True,
    )
    assert obj.serialize() == {
        'uuid': 1,
        'finalized': True,
        'squashed': True,
    }



# Generated at 2022-06-23 05:53:22.488411
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    parent = MagicMock(name='parent')

    instance = FieldAttributeBase(parent)

    pre_value = 'value'
    expected_result = 'value' # Should return the passed value

    result = instance.preprocess_data(pre_value)
    assert (result == expected_result)


# Generated at 2022-06-23 05:53:30.293852
# Unit test for method get_path of class Base
def test_Base_get_path():
    def func(path='/home/ansible/playbooks/test.yml'):
        # _ds=None is fine to initialize _ds because get_path function do not use _ds.
        # _ds=None will cause error only attribute "self._parent._play._ds._data_source" is used.
        # Since unit test need to initialize _ds class, we set _ds=None in unit test.
        self = Base(ds=None)
        self._ds = Mock(data_source=path)
        self._ds.data_source = path # mock object can not be updated, we need this to test get_path function.
        self._ds._line_number = 1 # mock object can not be updated, we need this to test get_path function.
        return self.get_path()


# Generated at 2022-06-23 05:53:40.524846
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from datetime import timedelta

    obj = FieldAttributeBase()
    assert_raises(AnsibleAssertionError, obj.from_attrs, ('foo', 'bar'))
    obj.from_attrs({'foo': 'bar'})

    obj = FieldAttributeBase(
        default='foobar',
        isa='string'
    )
    obj.from_attrs({'foo': 'bar'})
    assert obj.foo == 'foobar'

    obj = FieldAttributeBase(
        default='foobar',
        isa=int
    )
    obj.from_attrs({'foo': 'bar'})
    assert obj.foo == 'foobar', obj.foo

    obj = FieldAttributeBase(
        default='foobar',
        isa=list
    )

# Generated at 2022-06-23 05:53:41.324359
# Unit test for method get_path of class Base
def test_Base_get_path():
    pass

# Generated at 2022-06-23 05:53:50.851908
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    myhost = dict(name='fred')
    myhost['ansible_host'] = '1.1.1.1'
    myhost['ansible_user'] = 'joe'
    myhost['ansible_password'] = 'secret'
    myhost['ansible_port'] = '22'
    myhost['ansible_connection'] = 'smart'
    myhost['ansible_ssh_private_key_file'] = '/home/joe/.ssh/id_rsa'
    myhost['ansible_become_method'] = 'sudo'
    myhost['ansible_become_user'] = 'root'
    myhost['ansible_become_pass'] = 'too_secret'
    myhost['ansible_become_exe'] = '/usr/bin/sudo'

# Generated at 2022-06-23 05:53:53.127187
# Unit test for constructor of class Base
def test_Base():
    '''
    >>> Base()  #doctest.ELLIPSIS
    <ansible.utils.unsafe_proxy.AnsibleUnsafeText object at ...>
    '''

    pass
# ---- END: class Base ----


# Generated at 2022-06-23 05:53:58.858869
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    arg_spec = dict(
        foo='bar'
    )
    a = FieldAttributeBase(**arg_spec)

    a_copy = a.copy()

    assert isinstance(a_copy, FieldAttributeBase)
    assert a_copy is not a

    assert a_copy.foo == 'bar'
    assert a_copy.foo is not a.foo



# Generated at 2022-06-23 05:54:03.127963
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attr = FieldAttributeBase()

    data = dict()
    data['name'] = 'assigned'

    field_attr.deserialize(data)
    assert field_attr.get_name() == 'assigned'


# Generated at 2022-06-23 05:54:04.717735
# Unit test for method get_path of class Base
def test_Base_get_path():
    foo = Base()
    assert foo.get_path() == ""



# Generated at 2022-06-23 05:54:12.395204
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    """Unit test for method get_variable_manager of class FieldAttributeBase"""
    
    # Testing the constructor
    # We are instantiating the class with the following parameters
    # (to cover all possible types of parameters)
    #     self._valid_attrs = {}
    #     self._attribute_class = FieldAttribute
    #     self._alias_attrs = {}
    #     self._loader = None
    #     self._variable_manager = None
    #     self._validated = False
    #     self._finalized = False
    #     self._uuid = None
    #     self._ds = None
    #     self._data = None
    #     self._squashed = False
    #     self._deprecated_attrs = {}
    #     self._warn_only_deprecated_attrs = set()
    # 

# Generated at 2022-06-23 05:54:21.558323
# Unit test for method dump_attrs of class FieldAttributeBase

# Generated at 2022-06-23 05:54:33.089290
# Unit test for method get_path of class Base
def test_Base_get_path():
    # pylint: disable=unused-argument
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=no-member
    # pylint: disable=too-many-branches
    def return_ds():
        return None

    m_return_ds = MagicMock(side_effect=return_ds)

    def get_ds():
        return m_return_ds()
    # pylint: disable=protected-access
    Base._get_ds = get_ds
    # pylint: enable=protected-access
    # pylint: enable=no-member
    # pylint: enable=too-many-branches
    # pylint: enable=too-many-statements
    # pylint

# Generated at 2022-06-23 05:54:39.543151
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    # Test FieldAttributeBase is an abstract base class
    assert issubclass(FieldAttributeBase, object)
    assert 'isa' in FieldAttributeBase.__dict__
    assert 'default' in FieldAttributeBase.__dict__
    assert 'required' in FieldAttributeBase.__dict__
    assert 'always_post_validate' in FieldAttributeBase.__dict__
    assert 'static' in FieldAttributeBase.__dict__
    assert 'options' in FieldAttributeBase.__dict__
    assert 'serialize_when_none' in FieldAttributeBase.__dict__

# Generated at 2022-06-23 05:54:43.919701
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    assert FieldAttributeBase().default == None
    assert FieldAttributeBase().isa == None
    assert FieldAttributeBase().private == False
    assert FieldAttributeBase().required == True
    assert FieldAttributeBase().always_post_validate == False
    assert FieldAttributeBase().class_type == None

# Generated at 2022-06-23 05:54:48.135983
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    a = FieldAttributeBase()
    expected = FieldAttributeBase()
    result = a.copy()

    assert result == expected, "nope"


# Generated at 2022-06-23 05:54:52.101533
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    my_FieldAttributeBase = FieldAttributeBase()
    data = "data"
    assert_raises(AnsibleAssertionError, my_FieldAttributeBase.deserialize, data)


# Generated at 2022-06-23 05:55:01.200351
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play

    myblock = Block()
    myinclude_role = IncludeRole()
    myrole = Role()
    mytask = TaskInclude()
    myplay = Play()
    mycontext = PlayContext()

    block_dep_chain = myblock.get_dep_chain()
    include_role_dep_chain = myinclude_role.get_dep_chain()
    role_dep_chain = myrole.get_dep_chain()
    task_dep_chain = mytask.get_dep_

# Generated at 2022-06-23 05:55:04.441633
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class TestFieldAttributeBase(FieldAttributeBase):
        pass

    # Testing with no assert statements
    f = TestFieldAttributeBase()
    f.get_validated_value('', '', 0, '')



# Generated at 2022-06-23 05:55:08.290663
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # constructor without type_name
    assert FieldAttributeBase('boolean').type_name == 'boolean'
    # constructor with type_name
    assert FieldAttributeBase('string', type_name='my_type').type_name == 'my_type'


# Generated at 2022-06-23 05:55:17.611775
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    ds = dict()
    name = 'name'
    ds = ds
    attribute = dict()
    field_attribute = FieldAttributeBase(name, ds, attribute)
    mock_self = MagicMock(spec_set=FieldAttributeBase, name=name, ds=ds, attribute=attribute)
    value = dict()
    listof = dict()
    mock_self.get_validated_value.return_value = value
    result = field_attribute.load_data(mock_self, listof)
    assert result is value


# Generated at 2022-06-23 05:55:22.140963
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_inst = FieldAttributeBase()

    # test

    # test
    attribute = {}
    name = ''
    value = ''
    templar = ''
    ret = test_inst.get_validated_value(name, attribute, value, templar)
    assert ret == None



# Generated at 2022-06-23 05:55:28.304348
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Globals that can be used for building tests
    value = None
    expected = None
    result = None

    # Initialize a FieldAttributeBase object for testing
    field_attribute_base_obj = FieldAttributeBase(name="test_FieldAttributeBase_serialize", required=False, private=False)

    # Initialize a Sample FieldAttributeBase subclass
    class class_attribute_sample(FieldAttributeBase):
        pass
    # This is the class attribute of FieldAttributeBase
    class_attribute_obj = class_attribute_sample(name="test_FieldAttributeBase_serialize", required=True, private=False)

    # Test that a given string value is serialized to the corresponding AnsibleUnicode object
    value = 'some_string'
    expected = Ansible

# Generated at 2022-06-23 05:55:32.796201
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Get a FieldAttributeBase instance from a base class
    obj = self.get_task()
    # Calling the method creates AnsibleUnreachable
    # with self.assertRaises(AnsibleUnreachable):
    #     obj.get_ds()


# Generated at 2022-06-23 05:55:34.114270
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    assert False # TODO: implement your test here


# Generated at 2022-06-23 05:55:38.671517
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    class MockFieldAttributeBase(FieldAttributeBase):
        def __init__(self):
            FieldAttributeBase.__init__(self)
            self.name = None
            self.required = False
            self.serialize = True
            self.static = False
            self.always_post_validate = False
            self.default = None
            self.isa = None
            self.listof = None
            self.class_type = None
            self.no_log = False
            self.include_role = None
            self.include_tasks = None
            self.set = False
            self.internal = False
            self.aliases = []
            self.extend = False
            self.remove = False

        def __getattribute__(self, key):
            return FieldAttributeBase.__getattribute__(self, key)

       

# Generated at 2022-06-23 05:55:48.905457
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    '''
    Unit test for method dump_attrs of class FieldAttributeBase
    '''

    test_obj = FieldAttributeBase()

    # Check condition IF (True)
    if True:
        # Check condition IF (True)
        if True:
            test_obj.set_loader(AnsiballzLoader('test1', 'test2'))
            assert test_obj.dump_attrs() == {'_loader': AnsiballzLoader('test1', 'test2'), '_variable_manager': None, '_valid_attrs': {}, '_validated': False, '_finalized': False}
        # Check condition IF (True)
        if True:
            test_obj.set_loader(AnsiballzLoader('test1', 'test2'))

# Generated at 2022-06-23 05:56:01.280533
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    global _vars
    _vars = dict(
        h=dict(
            a=1,
            b=2,
        ),
        i=1,
    )
    f = FieldAttributeBase()
    v = f.validate(None, '{{h.a}}', _vars)
    assert v == 1, '%r != 1' % v

    v = f.validate(None, '{{i}}', _vars)
    assert v == 1, '%r != 1' % v

    v = f.validate(None, '{{j}}', _vars)
    assert v == None, '%r != None' % v

    v = f.validate(None, '{{j}}', _vars, allow_undefined=True)

# Generated at 2022-06-23 05:56:10.460957
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Test with a regular object
    obj = Mock()
    obj.get_variable_manager = Mock()
    obj.get_variable_manager.return_value = "foo"
    result = FieldAttributeBase.get_variable_manager(obj)
    assert result == "foo"

    # Test with a FieldAttributeBase object
    fb = FieldAttributeBase()
    fb.get_variable_manager = Mock()
    fb.get_variable_manager.return_value = "bar"
    result = FieldAttributeBase.get_variable_manager(fb)
    assert result == "bar"


# Generated at 2022-06-23 05:56:16.265258
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    t = Task()
    t.load_data(dict(action=dict(module='shell', args='ls'), name='fake_task_name'))
    assert t.action._plugin_type == 'action'
    assert t.action._plugin_name == 'shell'
    assert t.name == 'fake_task_name'



# Generated at 2022-06-23 05:56:20.152805
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase(name='foo')
    actual = obj.load_data(data=dict(foo=dict(bar=True, baz='abc')))
    assert actual == dict(bar=True, baz='abc')



# Generated at 2022-06-23 05:56:21.812029
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    #Can't unit test right now.  There is no way to instantiate the Base class.
    pass


# Generated at 2022-06-23 05:56:33.768690
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import collections
    import types

    class OldStyle():
        pass

    class NewStyle(object):
        pass

    class Base(with_metaclass(BaseMeta)):
        pass

    class AttributeTest(with_metaclass(BaseMeta, Base)):

        def __init__(self):
            # define __getattr__
            self.__getattr__ = self.__getattribute__

        attr_name = FieldAttribute(isa='str')

    class PropertyTest(with_metaclass(BaseMeta, Base)):

        @property
        def attr_name(self):
            return 'attr_name'

    class DefaultTest(with_metaclass(BaseMeta, Base)):

        attr_name = FieldAttribute(isa='str', default='some_default')


# Generated at 2022-06-23 05:56:43.440631
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    f0 = FieldAttributeBase()
    # test with default value for attr_name
    t0 = FauxTask()
    s0 = f0.squash(t0)
    assert isinstance(s0, dict)
    assert s0 == {}
    # test with overridden value for attr_name
    f1 = FieldAttributeBase(attr_name='faux_attr')
    t1 = FauxTask()
    s1 = f1.squash(t1)
    assert isinstance(s1, dict)
    assert s1.get('faux_attr') == 'a'


# Generated at 2022-06-23 05:56:56.202245
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # type: () -> None
    '''
    Test method get_search_path of class Base
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # Case 1, empty path_stack
    # try_files, is not escalated when using sudo or su
    try_files = Task.load(dict(
        include = 'try_files.yml',
        when = "false",
    ), play=dict(), loader=None, variable_manager=None, use_handlers=False)
    try_files._parent = Role()

    try_files._parent._role_path = 'included_roles/sub_role'
    assert try_files.get_search_path() == ['included_roles/sub_role']

    # Case 2, non-empty path

# Generated at 2022-06-23 05:56:58.256504
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    
    
    # unit test code here

    
    
    


# Generated at 2022-06-23 05:57:02.243385
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class MyBase(with_metaclass(BaseMeta)):
        a = FieldAttribute(isa='str')
        b = FieldAttribute(isa='str')

    class MyClass(MyBase):
        a = FieldAttribute(isa='str')
        c = FieldAttribute(isa='str')

    m = MyClass()
    assert m.a == None
    assert m.b == None
    assert m.c == None



# Generated at 2022-06-23 05:57:04.470399
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
   field_attribute_base = FieldAttributeBase()
   assert field_attribute_base.get_loader() == None

# Generated at 2022-06-23 05:57:06.551812
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    field_attribute_base_instance = FieldAttributeBase()
    field_attribute_base_instance.serialize()


# Generated at 2022-06-23 05:57:09.868416
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Create an object of FieldAttributeBase
    testObj = FieldAttributeBase('My Name', 1)
    expected = {'name': 'My Name', 'required': 1, 'static': True}
    actual = testObj.dump_me()
    assert expected == actual


# Generated at 2022-06-23 05:57:14.568371
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # container = AnsibleContainerBase(
    #     loa,
    #     variable_manager,
    #     loader,
    # )
    # assert isinstance(container, AnsibleContainerBase)
    assert True


# Generated at 2022-06-23 05:57:25.710216
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Test if method from_attrs of class FieldAttributeBase works as expected
    '''

    results = []
    for case in FieldAttributeBase_from_attrs_test_cases:
        (name, kwargs, expected) = case

        if 'data_type' in kwargs:
            data_type = kwargs['data_type']
            del kwargs['data_type']
        else:
            data_type = FieldData

        obj = data_type(**kwargs)
        results.append(obj)

    for index, case in enumerate(FieldAttributeBase_from_attrs_test_cases):
        (expected_name, expected_args, expected_value) = case
        result = results[index]

        # Assert that the object type is correct

# Generated at 2022-06-23 05:57:28.626572
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = Base()
    assert obj.get_dep_chain() == None


# Generated at 2022-06-23 05:57:40.009679
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()
    data['uuid'] = uuid4()
    data['finalized'] = True
    data['squashed'] = True
    # test with a simple class
    class TestFieldAttributeBase(FieldAttributeBase):
        def __init__(self):
            self._fields = dict(
                some_field=dict(isa='string', default='some'))
            self._finalized = False
            self._squashed = False
            self._uuid = None
    obj = TestFieldAttributeBase()
    obj.deserialize(data)
    assert obj._finalized is True
    assert obj._squashed is True
    assert obj._uuid == data['uuid']
    # test with a complex class
    class TestFieldAttributeBaseComplex(Base):
        def __init__(self):
            self._fields = dict

# Generated at 2022-06-23 05:57:46.599443
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # FieldAttributeBase is a private class and cannot be
    # directly instantiated.
    # Make sure that it passes unmodified through the dump_attrs
    # method
    new_me = FieldAttributeBase()
    data = {'one': 1, 'two': 2, 'three': 3}
    for key, value in data.items():
        setattr(new_me, key, value)
        data[key] = value
    assert(data == new_me.dump_attrs())
 

# Generated at 2022-06-23 05:57:52.437477
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    my_fieldattributebase = FieldAttributeBase()
    my_fieldattributebase_test = FieldAttributeBase()
    my_fieldattributebase._get_default_value = lambda: 42
    try:
        my_fieldattributebase.preprocess_data(ds=42, attribute=3)
    except TypeError as e:
        assert "unexpected keyword argument 'ds'" in str(e)
    else:
        raise AssertionError("Unexpected Exception")


# Generated at 2022-06-23 05:57:59.209315
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    # Ensure that all attributes are initialized by BaseMeta.__new__
    class Base(with_metaclass(BaseMeta, object)):
        foo = Attribute(default='bar')

    assert hasattr(Base, '_attributes')
    assert hasattr(Base, '_attr_defaults')
    assert hasattr(Base, '_valid_attrs')
    assert hasattr(Base, '_alias_attrs')

    # Ensure that attributes are not duplicated by multiple inheritance
    class A(with_metaclass(BaseMeta, object)):
        foo = Attribute(default='bar')

    class B(with_metaclass(BaseMeta, object)):
        foo = Attribute(default='bar')

    class B2(B):
        bar = Attribute(default='bar')


# Generated at 2022-06-23 05:58:08.344746
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    data = DummyModule()
    local_vars = DummyModule()
    local_vars.x1 = 1
    local_vars.x2 = 2
    local_vars.b1 = 0
    local_vars.b2 = 1

    # Test of function 'squash'
    data.squash = FieldAttributeBase.squash
    data.x1 = local_vars.x1
    data.x2 = local_vars.x2
    data._attributes = {'x1': local_vars.b1, 'x2': local_vars.b2}

    # Check the fields of the object data
    data.squash()
    assert data.x1 == 1
    assert data.x2 == 2


# Generated at 2022-06-23 05:58:12.658174
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    FieldAttributeBase: method dump_me
    '''
    attr = FieldAttributeBase(name='foo')
    assert attr.name == 'foo'
    # TODO: test output of dump_me

    
    
    
    

# Generated at 2022-06-23 05:58:18.153397
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Bar(object):
        __metaclass__ = BaseMeta
        foo = 42
        attr_one = FieldAttribute(isa='str', default='bar', inherit=True)
        attr_two = FieldAttribute(isa='bool', default=True, inherit=True)
        attr_three = FieldAttribute(isa='str', default='baz', inherit=False)

    class TestMeta(Bar):
        __metaclass__ = BaseMeta
        attr_four = FieldAttribute(isa='str', default='quux', inherit=True)

    test_meta = TestMeta()

    assert test_meta.foo == 42
    assert test_meta.attr_one == 'bar'
    assert test_meta.attr_two is True
    assert test_meta.attr_three == 'baz'
    assert test_meta.attr_four

# Generated at 2022-06-23 05:58:30.517486
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from ansible.module_utils._text import to_text
    from ansible import constants as C
    from yaml.constructor import ConstructorError

    module_loader = DictDataLoader({
        'test.yml': """
        ---
        a: 1
        """,
        'persistent.yml': """
        ---
        a: 2
        """
    })

    # apply defaults to get input data:
    input_data = {'a': None}

    variable_manager = VariableManager()
    variable_manager.set_loader(module_loader)

    # set the variable manager on the class, so variables are preprocessed
    FieldAttributeBase._variable_manager = variable_manager
    FieldAttributeBase._loader = module_loader

    # setup the loader search path for testing

# Generated at 2022-06-23 05:58:39.916570
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    value = Sentinel
    attr_name = "test"
    dst_dict = {
        "_attributes": {},
        "_attr_defaults": {},
        "_valid_attrs": {},
        "_alias_attrs": {},
    }

    _create_attrs({attr_name: value}, dst_dict)

    assert dst_dict == {
        "_attributes": {attr_name: Sentinel},
        "_attr_defaults": {attr_name: value},
        "_valid_attrs": {attr_name: value},
        "_alias_attrs": {},
        "test": property(_generic_g(attr_name, Sentinel), _generic_s(attr_name, Sentinel, Sentinel), _generic_d(attr_name, Sentinel))

    }



# Generated at 2022-06-23 05:58:42.316348
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert callable(Base._get_ds)
    assert not hasattr(Base, '_get_ds')


# Generated at 2022-06-23 05:58:46.835352
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase.__new__(FieldAttributeBase)
    data = 'data'
    # Call method
    try:
        result = obj.deserialize(data)
    except Exception as e:
        obj.deserialize(data, orig_exc=e)


# Generated at 2022-06-23 05:58:54.747529
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class BaseMetaMock(Base):
        def __init__(self, v1=1):
            self._attributes['v1'] = FieldAttribute(default=v1)

    class BaseMetaMock1(BaseMetaMock):
        def __init__(self, v2=2):
            self._attributes['v2'] = FieldAttribute(default=v2)
            super(BaseMetaMock1, self).__init__()

    class BaseMetaMock2(BaseMetaMock1):
        def __init__(self, v3=3):
            self._attributes['v3'] = FieldAttribute(default=v3)
            super(BaseMetaMock2, self).__init__()

    t1 = BaseMetaMock()
    t2 = BaseMetaMock1()
    t3 = BaseMetaMock

# Generated at 2022-06-23 05:59:03.594565
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    ds = DataLoader()
    pb = ds.load_from_file("./test/yaml_files/pb.yml")
    task1 = pb[0].tasks[0]
    assert task1.get_dep_chain() == None

    play1 = pb[1]
    assert play1.get_dep_chain() == None

    role1 = ds.load_from_file("./test/yaml_files/roles/role1/meta/main.yml")
    role2 = ds.load_from_file("./test/yaml_files/roles/role2/meta/main.yml")
    main_play = [play1]
    dependent_play = [play.copy() for play in play1.copy()._entries]

# Generated at 2022-06-23 05:59:12.116984
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Base._parent is not set
    b = Base()
    assert b.get_dep_chain() == None

    # Base._parent._play is not set
    b_parent = Base()
    b_parent._parent = b
    assert b_parent.get_dep_chain() == None

    # Base._parent._play is set
    b_play = Base()
    b_parent._parent._play = b_play
    assert b_parent.get_dep_chain() == b_play

# Generated at 2022-06-23 05:59:22.994802
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    host = HostVars()
    host.from_attrs({"ansible_host": "test"})
    assert host.hostvars_default == {}
    assert host.hostvars_alias == {}
    assert host.hostvars_class == {}
    assert host.hostvars_required == {}
    assert host.hostvars_attr == {}
    assert host.hostvars_container == {}
    assert host.hostvars_type == {}
    assert host.hostvars_name_var == 'inventory_hostname'
    assert host.hostvars_default['ansible_host'] == "test"
    assert host.hostvars_alias == {}
    assert host.hostvars_class == {}
    assert host.hostvars_required == {}
    assert host.hostvars_attr == {}
   

# Generated at 2022-06-23 05:59:27.202367
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
  obj = FieldAttributeBase()
  # failure case
  with pytest.raises(AnsibleParserError) as excinfo:
    obj._get_loader()
  # success case
  if C.DEFAULT_LOADER:
    assert obj._get_loader() == C.DEFAULT_LOADER


# Generated at 2022-06-23 05:59:37.898867
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(dict())
    variable_manager = VariableManager()
    variable_manager._vars = [hostvars]
    templar = Templar(loader=AnsibleLoader(None), variables=variable_manager)
    play_context = PlayContext()
    field_attribute_base = FieldAttributeBase(play_context)
    # Just test that it runs without error, no sane way to test
    # the template stuff
    field_attribute_base.post_validate(templar)


# Generated at 2022-06-23 05:59:40.029601
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()

    result = FieldAttributeBase.deserialize(data)
    assert result is None

# Generated at 2022-06-23 05:59:44.278051
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test for method validate(self, attrname, value).
    # Test with a valid value.
    attr = FieldAttributeBase()
    assert attr.validate(None, 0) == 0
    # Test with a value that's not the right type.
    try:
        attr.validate(None, '0')
        assert False, "attr.validate(None, '0') expected ValueError"
    except ValueError:
        pass


# Generated at 2022-06-23 05:59:49.736570
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FA = FieldAttributeBase()
    FA.attr1 = None
    FA.attr2 = None
    data = {u'attr1': u'val1', u'attr2': u'val2'}
    FA.load_data(data)
    assert FA.attr1 == 'val1'
    assert FA.attr2 == 'val2'

# Generated at 2022-06-23 05:59:52.531570
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    pass



# Generated at 2022-06-23 05:59:56.790764
# Unit test for method get_path of class Base
def test_Base_get_path():
    b = Base()
    b._ds = "ansible-playbook1.yml"
    b._ds._line_number = 20
    assert b.get_path() == "ansible-playbook1.yml:20"
    assert b.get_dep_chain() is None


# Generated at 2022-06-23 06:00:04.161655
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # FIXME: Fails on Python 3, see https://github.com/ansible/ansible/issues/52147
    return True
    a = 'a'
    b = 'b'
    c = 'c'
    fake_data = {
        a:{a:1,b:1,c:1},
        b:{a:1,b:1,c:1},
        c:{a:1,b:1,c:1}
    }
    obj = FakeFieldAttributeBase(fake_data)
    try:
        obj.post_validate()
    except:
        assert False, "Failed to post-validate a object"

# Generated at 2022-06-23 06:00:07.418778
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass
    #TODO: unit test

# Generated at 2022-06-23 06:00:09.838791
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    item = FieldAttributeBase()
    item1 = copy(item)
    assert type(item) == type(item1)

# Generated at 2022-06-23 06:00:14.534431
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    f = FieldAttributeBase(attr_name='attr_name')

    # Test with no params
    f.get_ds()

    # Test with params
    f.get_ds(ds='ds')



# Generated at 2022-06-23 06:00:24.953048
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    def test_parm(parm, expected, expected_exc=None):
        if expected_exc is not None:
            with pytest.raises(expected_exc):
                FieldAttributeBase(parm)
        else:
            obj = FieldAttributeBase(parm)
            assert obj.name == expected.get('name')
            assert obj.isa == expected.get('isa')
            assert obj.static == expected.get('static')
            assert obj.required == expected.get('required')
            assert obj.default == expected.get('default')
            assert obj.aliases == expected.get('aliases')
            assert obj.private == expected.get('private')

    params_allowlist = ['default', 'aliases', 'class_type', 'always_post_validate', 'encrypt', 'always_post_validate']

   

# Generated at 2022-06-23 06:00:28.601472
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # NOTE: This test doesn't do anything interesting, but does not raise any errors. 
    #       This test exists because FieldAttributeBase.dump_attrs() was added in 2.8.
    o = FieldAttributeBase()
    o.dump_attrs()



# Generated at 2022-06-23 06:00:31.891625
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method FieldAttributeBase.get_loader of class FieldAttributeBase
    '''
    d = {}
    assert False == isinstance(d, FieldAttributeBase)



# Generated at 2022-06-23 06:00:34.544099
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # test case 1
    yield assert_raises, TypeError, FieldAttributeBase.post_validate, FieldAttributeBase, 'foo', 'foo', 'foo'


# Generated at 2022-06-23 06:00:38.719111
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base._name == '', 'fails to set the default value of the attribute'
    assert base._connection == 'ssh', 'fails to set the default value of the attribute'



# Generated at 2022-06-23 06:00:50.959950
# Unit test for method get_path of class Base
def test_Base_get_path():
    """Unit test for method get_path of class Base"""


# Generated at 2022-06-23 06:01:01.166905
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    # base.DEFAULT_SEARCH_PATHS = [
    #     'roles/foo/tasks',
    #     'roles/foo/handlers',
    #     'roles/foo/defaults',
    #     'roles/foo/meta',
    #     'roles/foo/vars',
    #     'roles/foo/files',
    #     'roles/foo/templates',
    #     'roles/foo/library',
    #     'roles/foo/module_utils',
    #     'roles/foo/lookup_plugins',
    #     'roles/foo/tests',
    #     'roles/foo/webserver/files',
    #     'roles/foo/webserver/templates',
    #

# Generated at 2022-06-23 06:01:03.972353
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from metabat.fields import FieldAttributeBase
    obj = FieldAttributeBase()
    assert True


# Generated at 2022-06-23 06:01:05.075893
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass


# Generated at 2022-06-23 06:01:12.713396
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    '''
    This method is for unit testing of Base get_serarch_path method
    '''
    base_obj = Base()

    # inside role: add the dependency chain from current to dependent
    # case of get_dep_chain returning None
    assert base_obj.get_search_path() is None

    # case of get_dep_chain not returning None
    role_obj = Role()
    base_obj._parent = role_obj
    role_obj._role_path = "role_path"
    assert base_obj.get_search_path() == ["role_path"]

    # inside play: add the dep chain from current to dependent
    play_obj = Play()
    role_obj._parent = play_obj
    play_obj = Play()
    play_obj._ds = "ds"
    play_obj._line_

# Generated at 2022-06-23 06:01:16.878943
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Fixture:
    # make an instance of the object
    field_attribute_base = FieldAttributeBase()
    # call the method
    result = field_attribute_base.serialize()
    # validate the result
assert False,"TODO: Write this unit test"


# Generated at 2022-06-23 06:01:23.106493
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    data = dict(
        version=2,
        name='foo',
        foo="",
        bar='',
    )
    obj = Task()
    obj.from_attrs(data)
    assert obj.name == data['name']
    assert obj.foo is None
    assert obj.bar is None



# Generated at 2022-06-23 06:01:33.774601
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Create an instance of FieldAttributeBase, of type object
    # This test will not use any of the normal class construction
    # routines, since they make use of the FieldAttributeBase
    # class itself
    fb = FieldAttributeBase(isa='string', required=True, default=None)
    assert fb.isa == 'string'
    assert fb.required
    assert fb.default is None

    # Now try validating a simple string
    assert fb.validate('foo') == 'foo'

    # Now try validating a simple int
    with pytest.raises(AnsibleParserError):
        fb.validate(1)

    # Now try validating a simple bool
    with pytest.raises(AnsibleParserError):
        fb.validate(True)

    # Now try validating a simple dict

# Generated at 2022-06-23 06:01:46.418896
# Unit test for method serialize of class FieldAttributeBase

# Generated at 2022-06-23 06:01:50.465243
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    group_name = 'n'
    data = {}
    group_data = {}

    print(FieldAttributeBase(group_name, data, group_data, loader).dump_me())

if __name__ == '__main__':
    test_FieldAttributeBase_dump_me()



# Generated at 2022-06-23 06:01:51.675015
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass



# Generated at 2022-06-23 06:01:53.921054
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    v1 = FieldAttributeBase('test')
    assert v1.serialize() == 'test'

# Generated at 2022-06-23 06:01:56.504829
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    field_attr = FieldAttributeBase()
    assert field_attr.preprocess_data(None, None) is None



# Generated at 2022-06-23 06:02:00.637103
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    obj = Base()
    obj._parent = mock.Mock(spec=Base)
    obj._parent.get_dep_chain.return_value = 'foo'

    assert obj.get_dep_chain() == 'foo'
    assert obj._parent.get_dep_chain.call_count == 1


# Generated at 2022-06-23 06:02:11.217462
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create FieldAttributeBase instances for testing
    f1 = FieldAttributeBase()
    f2 = FieldAttributeBase()

    # Create a FieldAttributeBase instance by calling copy() with correct argument types on a FieldAttributeBase instance
    f3 = f1.copy()

    # Check that the returned object is a FieldAttributeBase instance
    if not isinstance(f3, FieldAttributeBase):
        return False

    # Check that the returned object is not the original object
    if f3 == f1:
        return False

    # Check that the returned object is not the same as another object
    if f3 == f2:
        return False

    return True


# Generated at 2022-06-23 06:02:21.088949
# Unit test for method get_path of class Base
def test_Base_get_path():
  # create a dummy class to create an object of class Base
  class Dummy(object):
    def __init__(self, ds, ln):
      self._ds = ds
      self._line_number = ln
  # create a dummy object of class Base
  db = Base()
  # test case 1: when the 'path' attribute is not set in the object
  db._parent = Dummy('test_playbook.yml', 1234)
  assert db.get_path() == 'test_playbook.yml:1234'
  # test case 2: when the 'path' attribute is set in the object
  db._parent = None
  db._ds = Dummy('test_playbook.yml', 1234)
  assert db.get_path() == 'test_playbook.yml:1234'


# Generated at 2022-06-23 06:02:22.507089
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    assert_raises(NotImplementedError, FieldAttributeBase().squash)

# Generated at 2022-06-23 06:02:27.480205
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    a = Base()
    b = Base()
    c = Base()
    d = Base()
    e = Base()
    f = Base()
    g = Base()
    a._parent = None
    b._parent = a
    c._parent = b
    d._parent = c
    e._parent = d
    f._parent = e
    g._parent = f

    assert a.get_dep_chain() == None
    assert b.get_dep_chain() == a
    assert c.get_dep_chain() == a
    assert d.get_dep_chain() == a
    assert e.get_dep_chain() == a
    assert f.get_dep_chain() == a
    assert g.get_dep_chain() == a

    assert a.get_dep_chain() == None

# Generated at 2022-06-23 06:02:30.519014
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''
    # Testing the capability of method get_variable_manager to throw exception
    pass

# Generated at 2022-06-23 06:02:32.644335
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FA = FieldAttributeBase(name='attribute_name')
    assert FA.name == 'attribute_name'


# Generated at 2022-06-23 06:02:38.850476
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleBaseYAMLObjectUnsafe
    from ansible.template import Templar
    task = AnsibleBaseYAMLObject()
    templar = Templar(loader=None)
    task.post_validate(templar)
    task._squash = True
    task.squash()

# Generated at 2022-06-23 06:02:50.329915
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestMetaClass(with_metaclass(BaseMeta, object)):
        attr1 = FieldAttribute(isa='str')
        attr2 = FieldAttribute(isa='int', inherit=True)
        attr3 = FieldAttribute(isa='list', listof='str')
        _private_attr4 = FieldAttribute(isa='dict')

        def _get_attr_private_attr4(self):
            return self.private_attr4

        def _get_parent_attribute(self, attr, from_parent=None, get_default=False):
            # noop method to simulate a parent object
            return

    t = TestMetaClass()

# Generated at 2022-06-23 06:02:57.162113
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    '''
    unit testing method BaseMeta.__new__()
    '''
    _attributes = {}
    _attr_defaults = {}
    _valid_attrs = {}
    _alias_attrs = {}

    def _create_attrs(src_dict, dst_dict):
        '''
        unit testing method BaseMeta.__new__()._create_attrs()
        '''
        keys = list(src_dict.keys())
        for attr_name in keys:
            value = src_dict[attr_name]
            if isinstance(value, Attribute):
                if attr_name.startswith('_'):
                    attr_name = attr_name[1:]

                # here we selectively assign the getter based on a few
                # things, such as whether we have a _get_attr