

# Generated at 2022-06-23 05:52:59.781127
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    '''
    Unit test for method deserialize of class FieldAttributeBase
    '''
    FieldAttributeBase_class_obj = FieldAttributeBase()
    data = { '_name': None, '_class': None, '_default': 'TestDefault', 'static': False, 'required': False, 'always_post_validate': False, 'isa': 'string', 'listof': None, 'class_type': None, 'callable': None, 'immutable': False, 'private': False, 'deprecated': False, 'aliases': [], 'aliases_with_deprecation': [] }
    data = DictObj(data)
    FieldAttributeBase_class_obj._valid_attrs = {'a': data }
    assert FieldAttributeBase_class_obj._valid_attrs['a']._name == None
    assert FieldAttribute

# Generated at 2022-06-23 05:53:01.968779
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass
# (End of test)



# Generated at 2022-06-23 05:53:09.870256
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # First test for class Base
    print("Testing for class Base")
    
    # Test attributes for class Base
    _name = "name"
    
    _connection = "local"
    
    _port = 0
    
    _remote_user = "root"
    
    _vars = dict()
    
    _module_defaults = list()
    
    _environment = list()
    
    _no_log = False
    
    _run_once = False
    
    _ignore_errors = False
    
    _ignore_unreachable = False
    
    _check_mode = False
    
    _diff = False
    
    _any_errors_fatal = C.ANY_ERRORS_FATAL
    
    _throttle = 0
    
    _timeout = C.TASK_

# Generated at 2022-06-23 05:53:11.002209
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass # TODO

# Generated at 2022-06-23 05:53:14.200193
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fld = FieldAttributeBase()
    fld._valid_attrs = {'test': 'str'}
    is_equal(fld.dump_attrs(), {'test': None}, 'Test dump_attrs #1 failed')

# Generated at 2022-06-23 05:53:18.256420
# Unit test for constructor of class Base
def test_Base():
    assert issubclass(Base, FieldAttributeBase)
    assert Base._name.__class__.__name__ == 'FieldAttribute'
    assert Base._name.default == ''
    assert Base._name.always_post_validate is True
    assert Base._name.inherit is False

    # check for connection/transport
    assert Base._connection.__class__.__name__ == 'FieldAttribute'
    assert Base._connection.default == context.cliargs_deferred_get_cache['connection']
    assert Base._port.__class__.__name__ == 'FieldAttribute'
    assert Base._remote_user.__class__.__name__ == 'FieldAttribute'
    assert Base._remote_user.default == context.cliargs_deferred_get_cache['remote_user']

    # check for variables
    assert Base._vars

# Generated at 2022-06-23 05:53:18.867583
# Unit test for constructor of class Base
def test_Base():
    Base()



# Generated at 2022-06-23 05:53:27.793157
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from copy import copy
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-23 05:53:29.458681
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # we never actually call copy, we just copy the dictionary entries
    pass


# Generated at 2022-06-23 05:53:35.638159
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host("localhost")
    obj = FieldAttributeBase()
    # result = obj.get_ds()
    # assertEqual(result, None)

# Generated at 2022-06-23 05:53:43.785010
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class BaseMetaTest(with_metaclass(BaseMeta, object)):
        __metaclass__ = BaseMeta

        def __init__(self):
            self._finalized = False
            self._loader = None
            self._attributes = {
                '_attributes': dict(),
                '_attr_defaults': dict(),
                '_valid_attrs': dict(),
                '_alias_attrs': dict()
            }

        hosts = FieldAttribute(isa='list', default=lambda: [], inherit=False, metavar='HOST')
        when = FieldAttribute(isa='list', default=lambda: [], inherit=False)
        name = FieldAttribute(isa='string', default='', inherit=False)
        become = FieldAttribute(isa='bool', default=False, inherit=True)
        become_user = FieldAttribute

# Generated at 2022-06-23 05:53:56.168775
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # the only thing we can do here is to test the boolean evaluation
    # but at least that is something
    # test types that we know should *not* evaluate to True
    for v in (None, False, 0, ""):
        assert not FieldAttributeBase.preprocess_data(v), "should test for False for value '%s' (%s) but got True" % (v, type(v))

    # test types that should eval to True
    for v in (True, True, 1, 1.0, -1, "a"):
        assert FieldAttributeBase.preprocess_data(v)


# Generated at 2022-06-23 05:54:04.569856
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """
    Test method post_validate of class FieldAttributeBase
    """
    # Check error handling of FieldAttributeBase post_validate
    # Create a FieldAttributeBase
    # There is no meaningful way to create one without subclassing.
    with pytest.raises(AnsibleError) as err:
        fa = FieldAttributeBase()
    assert "Cannot instantiate base class FieldAttributeBase" in to_native(err.value)
    assert "post_validate is an abstract method" in to_native(err.value)


# Generated at 2022-06-23 05:54:15.609120
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    o = FieldAttributeBase()
    assert o.__class__.__name__ == 'FieldAttributeBase'
    # Test with no arguments
    try:
        o.load_data()
    except TypeError as e:
        assert 'load_data() takes exactly 2 arguments (1 given)' in to_native(e)
    # Test with one argument
    try:
        o.load_data(None)
    except TypeError as e:
        assert 'load_data() takes exactly 2 arguments (1 given)' in to_native(e)
    # Test with two arguments
    try:
        o.load_data(None, None)
    except TypeError as e:
        assert 'load_data() takes exactly 2 arguments (1 given)' in to_native(e)
    # Test with three arguments

# Generated at 2022-06-23 05:54:21.828091
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    f = FieldAttributeBase()
    f._valid_attrs = {
        'foo': 'bar'
    }
    f._finalized = True

    f_copy = f.copy()

    # Validate the copy
    assert f._valid_attrs == f_copy._valid_attrs
    assert f._finalized == f_copy._finalized

    # Make sure they're not the same object
    assert f is not f_copy
    assert f._valid_attrs is not f_copy._valid_attrs


# Generated at 2022-06-23 05:54:31.849159
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class FieldTest():
        test_field = FieldAttribute()
    class InheritTest(FieldTest):
        inherit_test = FieldAttribute(inherit=True)

    field_test_metaclass = BaseMeta('FieldTest', (object,), {})
    inherit_test_metaclass = BaseMeta('InheritTest', (object,), {})

    #  Ensure that metaclass of FieldTest has field test_field
    assert BaseMeta.__new__(BaseMeta, 'FieldTest', (object,), {}).__dict__.get('test_field')
    assert getattr(field_test_metaclass, 'test_field', None)

    # Ensure that metaclass of InheritTest has field inherit_test

# Generated at 2022-06-23 05:54:34.198056
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    argspec = inspect.getfullargspec(FieldAttributeBase.preprocess_data)
    assert len(argspec.args) == 3

# Generated at 2022-06-23 05:54:34.887055
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass

# Generated at 2022-06-23 05:54:42.108597
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    attr = FieldAttributeBase('name')
    assert attr.name == 'name'
    assert not attr.static
    assert attr.isa == 'string'
    assert attr.required
    assert attr.default == ''
    assert attr.aliases == []
    assert attr.class_type == string_types
    assert not attr.ignore_errors


# Generated at 2022-06-23 05:54:51.848075
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.attribute import Attribute

    BaseMeta_obj = BaseMeta(None, None, None)
    BaseMeta_obj.__new__.assert_called_once()


# Generated at 2022-06-23 05:54:56.106005
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    host = HostVars(dict())
    templar = Templar(loader=None, variables=dict())
    FieldAttributeBase.post_validate(host,templar)


# Generated at 2022-06-23 05:55:06.739809
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.module_utils.six import create_bound_method
    def f1(_self_):
        return 1
    def f2(_self_,value):
        return 2
    def f3(_self_):
        return 3
    def f4(_self_,value):
        return 4
    class Test1(object):
        _attributes = {
            'x': Sentinel
        }
        _attr_defaults = {
            'x': 'test'
        }
        _valid_attrs = {
            'x': FieldAttribute(default='test')
        }
        _alias_attrs = {}
        _p = property(create_bound_method(f1, Test1()), create_bound_method(f2, Test1()), create_bound_method(f3, Test1()))
        del _

# Generated at 2022-06-23 05:55:08.771868
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''
    pass



# Generated at 2022-06-23 05:55:17.716772
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # set up some sensible defaults
    obj_data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'repr': 'test'
    }
    obj_data.update(FieldAttributeBase.defaults)
    obj_data.update(BaseObject.defaults)

    # create base object
    obj = BaseObject()
    attrs = obj.dump_attrs()

    # check defaults as set
    pass_obj = True
    for key, value in obj_data.items():
        if attrs[key] != value:
            fail('dump_attrs results do not match')

    # create base object from attrs
    obj2 = BaseObject()
    obj2.from_attrs(attrs)
    pass_obj = True

# Generated at 2022-06-23 05:55:20.589337
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    obj = FieldAttributeBase()
    try:
        obj._get_loader()
    except Exception as e:
        assert isinstance(e, NotImplementedError)

# Generated at 2022-06-23 05:55:31.925527
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase(isa='list', listof='string', choices=('yes', 'no'), default=[])
    class Obj(object):
        foobar = f
    obj = Obj()

    # test an invalid choice
    obj.foobar = ['this', 'that', 'other']
    with pytest.raises(AnsibleParserError) as exc:
        f.post_validate(obj, None, 'foobar')
    assert exc.value.obj == 'foobar'
    assert "The value 'this' is not valid" in to_text(exc.value)
    assert exc.value.orig_exc is None

    # test a valid choice
    obj.foobar = ['yes', 'no']

# Generated at 2022-06-23 05:55:43.275235
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
   field_attribute_base = FieldAttributeBase()
   field_attribute_base.field_type = None
   field_attribute_base.class_type = None
   field_attribute_base.default = None
   field_attribute_base.always_post_validate = False
   field_attribute_base.static = False
   field_attribute_base.required = False
   field_attribute_base.listof = None
   field_attribute_base.isa = None
   serialized = field_attribute_base.serialize()
   assert serialized == {}
   field_attribute_base.field_type = {}
   field_attribute_base.class_type = {}
   field_attribute_base.default = {}
   field_attribute_base.always_post_validate = True
   field_attribute_base.static = True
   field_attribute

# Generated at 2022-06-23 05:55:52.498848
# Unit test for constructor of class Base
def test_Base():
    '''
    Base class alpha-sorting of arguments.
    '''

    b = Base(vars=dict(a=1), foo=1, bar=1)
    assert b.vars == dict(a=1)
    assert hasattr(b, '_vars_priority')
    # The priorities of args should be set correctly based on their position
    assert sorted(b._vars_priority.values()) == [0, 1]
    # The positional args should be put into attrs in alpha-sorting order

# Generated at 2022-06-23 05:55:56.746835
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    '''
    unit test for main functionality of FieldAttributeBase.serialize()
    '''
    field_attr = FieldAttributeBase(isa='str')
    # assert, that isa defaults to str
    assert field_attr.isa == 'str'



# Generated at 2022-06-23 05:56:05.998918
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from units.mock.loader import DictDataLoader
    # create a mock PlayContext by hand (can't call PlayContext directly)
    set_context(PlayContext())
    # create a mock Task (can't call Base directly)
    b = Base()
    # mock role
    role = namedtuple('Role', '_role_path')(_role_path='/my/role')
    # mock role dependency chain
    dep_chain = [role]
    b._dep_chain = dep_chain
    # test result of method get_search_path()
    assert b.get_search_path() == ['/my/role']
    # test that path_stack does not have a None element
    path_stack = []
    set_context(PlayContext())
    # create a mock Task (can't call Base directly)
    b = Base

# Generated at 2022-06-23 05:56:14.427228
# Unit test for constructor of class BaseMeta
def test_BaseMeta():

    class TestClass(object):
        __metaclass__ = BaseMeta

        test_attr = Attribute()
        test_attr_two = Attribute(required=True)

    assert TestClass._attributes == {'test_attr': Sentinel, 'test_attr_two': Sentinel}
    assert TestClass._attr_defaults == {'test_attr': None, 'test_attr_two': None}
    assert TestClass._valid_attrs == {'test_attr': TestClass.test_attr, 'test_attr_two': TestClass.test_attr_two}
    assert TestClass._alias_attrs == {}

    assert TestClass().test_attr is None
    assert TestClass().test_attr_two is None



# Generated at 2022-06-23 05:56:17.045883
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # FIXME: unpossible to test this method without real data
    pass
Base._valid_attrs['get_dep_chain'] = FieldAttribute()



# Generated at 2022-06-23 05:56:29.959070
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    host = AnsibleHost()
    host.hostname = 'localhost'
    def mock_resolve_hostname_to_ip(hostname, port):
        if hostname == 'localhost' and port == 1234:
            return '127.0.0.1'
        else:
            return hostname
    host.resolve_hostname_to_ip = mock_resolve_hostname_to_ip
    field_attribute = FieldAttributeBase(
        name='name',
        description='description',
        default='default',
        isa='str',
        always_post_validate=True,
        required=False,
        static=False,
    )

# Generated at 2022-06-23 05:56:39.026149
# Unit test for constructor of class Base
def test_Base():

    # Check that all declared attributes are initialized.
    # This test is required to warn us at development time if
    # an attribute is added to a Base derived class and is
    # not initialized in its constructor.
    b = Base()
    for attribute in sorted(b._valid_attrs):
        if not hasattr(b, attribute):
            raise Exception("%s does not have attribute %s after __init__." % (b, attribute))

    # Check that all attributes initialized in constructor
    # are declared in _valid_attrs.
    # This test is required to catch a typo or to warn us
    # if an attribute is initialized that no longer needs
    # to be.

    # Handle attributes that are added as part of __init__
    # or that are not part of _valid_attrs.

# Generated at 2022-06-23 05:56:46.963894
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    import pytest
    # The FieldAttributeBase class is abstract, so we need to create a subclass that is not abstract to test
    class NotAbstractFieldAttributeBase(FieldAttributeBase):
        # The FieldAttributeBase class requires that these methods are implemented
        def _get_ds(self):
            return ''
        def serialize(self):
            return {}
    with pytest.raises(AttributeError):
        # We haven't set a value_type, so this should fail
        field_attribute_base = NotAbstractFieldAttributeBase()


# Generated at 2022-06-23 05:56:58.184048
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import ansible.playbook.base
    from ansible.playbook.attribute import FieldAttribute
    class Class_Test(ansible.playbook.base.Base):
        def __init__(self):
            super(Class_Test, self).__init__()
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}
            self._attributes['name'] = Sentinel
            self._attr_defaults['name'] = 'test'
            self._valid_attrs['name'] = FieldAttribute(default='test')
        def _get_attr_name(self):
            return self._attributes['name']
        name = property(_get_attr_name, _generic_s, _generic_d)
    a = Class_Test()
   

# Generated at 2022-06-23 05:57:05.419250
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.requiremenets import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    role_path = "./tests/test_data_files/roles/apb/tasks/main.yml"
    role_definition = RoleDefinition.load(loader=loader, path=role_path)
    role_definition._role_path = "./tests/test_data_files/roles/apb"
    dependant_role_definition = RoleDefinition.load(loader=loader, path=role_path)
    dependant_role

# Generated at 2022-06-23 05:57:07.717720
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    a = AnsibleBase()
    f = FieldAttributeBase()
    assert f.get_loader(a).__class__.__name__ == 'DataLoader'

# Generated at 2022-06-23 05:57:09.603884
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    pass # TODO - write real test for get_ds

# Generated at 2022-06-23 05:57:20.738746
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestModule(object):
        def __init__(self, **kwargs):
            for key, value in iteritems(kwargs):
                setattr(self, key, value)
        def __getattr__(self, name):
            return None
    class BaseTest(with_metaclass(BaseMeta, TestModule)):
        attr1 = FieldAttribute(isa='str')
        attr2 = FieldAttribute(isa='str')
        attr3 = FieldAttribute(isa='str', alias='my_alias')
    class Test1(BaseTest):
        attr1 = FieldAttribute(isa='str')
    class Test2(Test1):
        def _get_attr_attr1(self):
            return 'attr1'
    class Test3(Test1):
        attr1 = FieldAttribute(isa='str')
       

# Generated at 2022-06-23 05:57:22.294677
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base = FieldAttributeBase()
    

# Generated at 2022-06-23 05:57:24.244223
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    pass



# Generated at 2022-06-23 05:57:36.844057
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    import mock


    # Setup mock objects for serialize method
    attrs = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }
    mock_obj = mock.MagicMock(spec=dict)
    mock_obj.serialize.return_value = attrs

    f = FieldAttributeBase()

    # Setup mock objects for deserialize method
    data = {
        'key1': mock_obj,
        'key2': 'value 1',
        'key3': 'value 3',
    }

    # Call deserialize method
    result = f.from_attrs(data)

# Generated at 2022-06-23 05:57:38.315063
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert isinstance(b, Base)


# Generated at 2022-06-23 05:57:41.833976
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Create test environment
    obj = AnsibleBase()

    # Check if method get_variable_manager of class FieldAttributeBase return an instance of VariableManager
    assert(isinstance(obj.get_variable_manager(), VariableManager))



# Generated at 2022-06-23 05:57:52.919865
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    """Check the serialization of object's attributes."""
    # Test with a simple object
    with patch.object(FieldAttributeBase, 'serialize') as mocked_serialize:
        mocked_serialize.return_value = dict(attr='attr_value')
        obj = FieldAttributeBase()
        value = obj._dump_me()
        assert value == dict(attr='attr_value')
        mocked_serialize.assert_called_once_with()
    # Test with an object whose serialization raise an exception
    with patch.object(FieldAttributeBase, 'serialize') as mocked_serialize:
        mocked_serialize.side_effect = AnsibleAssertionError()
        obj = FieldAttributeBase()
        value = obj._dump_me()
        assert value == dict()
    # Test with a template object
    obj = FieldAttributeBase()

# Generated at 2022-06-23 05:57:59.533311
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Test if method get_ds of class FieldAttributeBase
    returns correct value
    '''
    fb = FieldAttributeBase()
    # Run get_ds method of class FieldAttributeBase
    result = fb.get_ds()

    assert result == {
        'class': FieldAttributeBase,
        'module': 'ansible.parsing.yaml.objects',
    }



# Generated at 2022-06-23 05:58:08.943388
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # Test basic instantiation
    attr = FieldAttributeBase()
    assert attr._name is None
    assert attr.default is None
    assert attr.isa is None
    assert attr.static is False
    assert attr.required is False
    assert attr.always_post_validate is False
    assert attr.listof is None
    assert attr.class_type is None

    # Test parsing of isa
    attr = FieldAttributeBase(isa='string')
    assert attr.isa == 'string'
    assert attr.static is True
    assert attr.required is True

    attr = FieldAttributeBase(isa='list')
    assert attr.isa == 'list'
    assert attr.static is True
    assert attr.required is True


# Generated at 2022-06-23 05:58:16.994278
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Base(object):
        __metaclass__ = BaseMeta

        foo = FieldAttribute(isa='string', default=dict())
        bar = FieldAttribute(isa='string', default=dict())

        _baz = FieldAttribute(isa='string', default=dict())

        def _get_attr_foo(self):
            return 'foo'

    assert not hasattr(Base(), 'foo')
    assert Base.foo == 'foo'
    assert Base().foo == 'foo'
    assert Base()._baz == dict()



# Generated at 2022-06-23 05:58:27.242652
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # The following code is equivalent to:
    # class A(object):
    #     a = FieldAttribute([str])
    #     _a = FieldAttribute([str])
    class A(object):
        a = FieldAttribute([str])
        _a = FieldAttribute([str])
    dct_A = {'a': A.a, '_a': A._a}
    dct_A['_attributes'] = {}
    dct_A['_attr_defaults'] = {}
    dct_A['_valid_attrs'] = {}
    dct_A['_alias_attrs'] = {}
    BaseMeta.__new__(BaseMeta, 'A', (object,), dct_A)
    assert 'a' in dir(A)
    assert '_a' in dir(A)

# Generated at 2022-06-23 05:58:38.577700
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class MockedFieldAttributeBase:
        _valid_attrs = dict(
            attr_int = dict(isa = 'int'),
            attr_float = dict(isa = 'float'),
            attr_bool = dict(isa = 'bool'),
            attr_percent = dict(isa = 'percent'),
            attr_list = dict(isa = 'list'),
            attr_dict = dict(isa = 'dict'),
            attr_vars = dict(isa = 'dict'),
            attr_class = dict(isa = 'class', class_type = MockedFieldAttributeBase)
        )
    base = MockedFieldAttributeBase()

    # _valid_attrs = dict(attr_int = dict(isa = 'int'))
    value = '10'

# Generated at 2022-06-23 05:58:41.420595
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    obj = FieldAttributeBase()
    # No tests here
    pass

# Generated at 2022-06-23 05:58:47.845556
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Since load_data is a class method, we need to use the class directly,
    # not an instance of it.
    FA = FieldAttributeBase
    assert FA.load_data('key', 'value') == dict(key='value')
    assert FA.load_data('key', ['value1', 'value2']) == dict(key=['value1', 'value2'])
    # TODO: Finish this test with more complex examples of input/output.


# Generated at 2022-06-23 05:58:54.994237
# Unit test for constructor of class Base
def test_Base():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    data = Base()
    assert data._connection == context.CLIARGS.get('connection')
    #assert data._parent == None

    data = Base(play=Play())
    assert data._connection == context.CLIARGS.get('connection')
    assert data._parent == None



# Generated at 2022-06-23 05:59:03.237400
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    host = Mock()
    getattr(host, 'name')
    getattr(host, '_source_file')
    getattr(host, '_line_number')
    host._attributes = dict()
    getattr(host, '_valid_attrs')
    getattr(host, '_variable_manager')

    # Unit test for method FieldAttributeBase.validate
    # Test with no value
    attr = FieldAttributeBase('name', FieldAttributeBase.REQUIRED)
    attr.validate(host, attribute_name='name', value=None, templar=None)

    # Test with a value
    attr = FieldAttributeBase('name', FieldAttributeBase.REQUIRED)
    attr.validate(host, attribute_name='name', value='value', templar=None)

# Generated at 2022-06-23 05:59:07.193052
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    import mock

    with mock.patch.object(FieldAttributeBase,
            '_get_variable_manager',
            return_value='fake_variable_manager'):
        var_manager = FieldAttributeBase.get_variable_manager()
        assert var_manager == 'fake_variable_manager'


# Generated at 2022-06-23 05:59:19.629806
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook import play
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.utils.path import unfrackpath
    my_role_path = unfrackpath(my_role_path)
    my_play_path = unfrackpath(my_play_path)
    my_task_path = unfrackpath(my_task_path)
    my_task_path_in_role = unfrackpath(my_task_path_in_role)
    my_play_path_in_role = unfrackpath(my_play_path_in_role)
    playbook_dir = os.path.dirname(my_play_path)
    my_play = Play.load(my_play_path)
    my_task = my_play

# Generated at 2022-06-23 05:59:20.929034
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    obj = FieldAttributeBase()

    assert obj.serialize() == {}


# Generated at 2022-06-23 05:59:23.997223
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    varmgr = VariableManager()
    f = FieldAttributeBase(varmgr=varmgr)
    assert f.get_variable_manager() == varmgr


# Generated at 2022-06-23 05:59:27.465566
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    fake_self = create_autospec(FieldAttributeBase)
    fake_self._datastore = '10'
    assert FieldAttributeBase.get_ds(fake_self) == '10'


# Generated at 2022-06-23 05:59:34.858081
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.common.loader import load_from_file
    from ansible.utils.vars import combine_vars

    data_file = "/tmp/ansible_testcase_base_meta_object"
    data = dict(
        attribute1 = dict(default=None, inherit=False),
    )
    with open(data_file, "w") as f:
        f.write(str(data))

    parent = load_from_file(data_file)

    new_cls = BaseMeta("TestCaseBaseMeta", (Base,), dict())

    Base_ = new_cls("TestCase", (Base,), dict())

    # assert Base_._attributes == dict()

# Generated at 2022-06-23 05:59:40.709711
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    print('Test for method copy of class FieldAttributeBase')
    try:
        fa = FieldAttributeBase(isa='class')
        fa.copy()
    except:
        print('Caught exception: ')
        traceback.print_exc()
        assert False



# Generated at 2022-06-23 05:59:43.287111
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()
    print(obj.get_validated_value('', '', '', ''))

# Generated at 2022-06-23 05:59:48.605923
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    config = dict(
        name='foo',
        required=True,
        default='bar'
    )
    fa = FieldAttributeBase()
    data = fa.load_data(config)

    assert data['name'] == 'foo'
    assert data['required'] == True
    assert data['default'] == 'bar'


# Generated at 2022-06-23 05:59:53.438450
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase()

    def testme():
        isinstance(obj, FieldAttributeBase)
    try:
        obj.deserialize("foo")
    except Exception as e:
        assert type(e) == AnsibleAssertionError
        assert str(e) == "data (foo) should be a dict but is a <class 'str'>"
        testme()

# Generated at 2022-06-23 05:59:57.639483
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    my_role = Role()
    my_task = Base()
    my_task._parent = my_role
    dep_chain = my_task.get_dep_chain()
    assert dep_chain == [my_role]
    assert dep_chain[0] == my_role

# Generated at 2022-06-23 05:59:59.404448
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass # since all tests of this class are unit tests, this method is not needed



# Generated at 2022-06-23 06:00:08.766115
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # TODO: Remove this when we can depend on python 2.7
    from nose.plugins.skip import SkipTest
    raise SkipTest

    class MyTask(Task):
        def __init__(self):
            self.name = "test"
            self.module_name = "test"
            self.uuid = "test"
            self.loader = DataLoader()
            self.variable_manager = VariableManager(loader=self.loader, inventory=InventoryManager(self.loader, "localhost,"))
            self.validated = False
            self._ds = None
            self._finalized = False
            self._squashed = False

            self._valid_att

# Generated at 2022-06-23 06:00:17.041503
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    fieldattributebase = FieldAttributeBase()

    # set the stage for running the method
    setattr(fieldattributebase, 'aliases', ["compile", "compiled", "assemple", "assembled"])

    # execute the method
    result = fieldattributebase.preprocess_data({"name": "package", "required": True});

    # verify the result
    assert result == {"name": "package", "compile": True, "compiled": True, "assemple": True, "assembled": True, "required": True}, \
        "FieldAttributeBase 'preprocess_data' method returned an unexpected result."

# Generated at 2022-06-23 06:00:19.852605
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash(): 
    obj = FieldAttributeBase()
    assert obj.squash() is None
    with pytest.raises(AttributeError):
        obj.squash = "foo"

# Generated at 2022-06-23 06:00:28.095747
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    testcase = TestCase()

    fake_self = MagicMock(FieldAttributeBase)
    fake_self.name = None
    fake_self.isa = 'foo'
    fake_self.default = 'bar'
    fake_self.static = False
    fake_self.required = None

    # Test 1: data is None, return default
    data = None
    res = FieldAttributeBase.preprocess_data(fake_self, data)
    testcase.assertEqual(res, 'bar')

    # Test 2: data is not None, return data
    data = 'not_none'
    res = FieldAttributeBase.preprocess_data(fake_self, data)
    testcase.assertEqual(res, 'not_none')



# Generated at 2022-06-23 06:00:40.205124
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.base import Base
    from ansible import context
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop

# Generated at 2022-06-23 06:00:47.104292
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {
        'a': 5,
        'b': 'b',
        'c': None,
    }
    fa = FieldAttributeBase()
    fa.deserialize(data)
    assert fa.a == 5
    assert fa.b == 'b'
    assert fa.c is None

    data = {
        'a': 'b',
    }
    fa = FieldAttributeBase()
    fa.deserialize(data)
    assert fa.a == 'b'
    assert fa.b == 'default'


# Generated at 2022-06-23 06:00:50.588228
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    Fail:
    >>> FieldAttributeBase()
    Traceback (most recent call last):
    ValueError: FieldAttributeBase is an abstract class
    '''


# Generated at 2022-06-23 06:00:54.355667
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    a = FieldAttributeBase()
    assert not a.static
    assert not a.required
    assert a.default is None
    assert a.always_post_validate is False
    assert a.aliases == []


# Generated at 2022-06-23 06:00:56.093959
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fixture = FieldAttributeBase()
    assert fixture.post_validate() == None, 'This function should return None'


# Generated at 2022-06-23 06:01:06.350614
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement

    # Play with include role
    task_1 = Task()
    role_include_1 = RoleInclude()
    role_include_1._role_path = 'role_include_1_path'
    role_include_1._parent = task_1
    role_include_1._role_name = 'role_include_1_name'
    task_1._parent = role_include_1

    dep_chain_1 = role_include_1.get_dep_chain()
    assert dep_chain_1 == [role_include_1]


# Generated at 2022-06-23 06:01:07.135123
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    a = FieldAttributeBase()

# Generated at 2022-06-23 06:01:12.097927
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    print('Testing for method copy of class FieldAttributeBase')
    fa = FieldAttributeBase(vartype='bool', required=False, default=None, static=False, choices=None, private=False, always_post_validate=False)
    fa.copy()


# Generated at 2022-06-23 06:01:18.553843
# Unit test for constructor of class Base
def test_Base():
    c1 = Base(name='test_base_obj')
    assert c1._name == 'test_base_obj'
    assert c1._parent is None
    assert c1._connection == context.cliargs['connection']
    assert c1._module_defaults == []
    assert c1._module_defaults == []
    assert "_diff" in c1._valid_attrs
    assert c1._diff == context.CLIARGS['diff']



# Generated at 2022-06-23 06:01:20.748761
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    args = dict()
    obj = FieldAttributeBase(**args)
    assert not obj.squash

# Generated at 2022-06-23 06:01:26.320462
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        field_attribute_base.deserialize({})
    assert 'data (dict) should be a dict but is a %s' % type({}) in str(excinfo.value)


# Generated at 2022-06-23 06:01:32.000276
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test with a valid value.
    # Test with None.
    # Test with more than one value in self._parent.
    # Test with self._parent is False.
    # Test with a empty value in self._parent.
    # Test with a empty value in self._parent._play._ds.
    pass


# Generated at 2022-06-23 06:01:37.733551
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    f_att_obj = FieldAttributeBase()
    assert f_att_obj.serialize() == {}


# Generated at 2022-06-23 06:01:48.224208
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.splitter import parse_kv
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    # class definition
    #
    # We need to create a class with a FieldAttribute property to test
    # the __new__ method of BaseMeta.
    class TestClass:
        test_attr = FieldAttribute(isa='string', default='foo')

    # precondition
    #
    # TestClass should has no attribute '_attributes', '_attr_defaults',
    # '_valid_attrs', '_alias_attrs'.
    assert not hasattr(TestClass, '_attributes')
    assert not hasattr(TestClass, '_attr_defaults')
    assert not has

# Generated at 2022-06-23 06:01:59.107096
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    fa = FieldAttributeBase()
    # noinspection PyUnusedLocal
    def test_set1(value):
        return value

    # noinspection PyUnusedLocal
    def test_set2(value):
        return value

    f = FieldAttributeBase(
        default=1,
        choices=["a", "b", "c"],
        set_function=test_set1,
        validate=test_set2
    )

    # noinspection PyUnusedLocal
    def test_setter(value):
        return value


    # noinspection PyUnusedLocal
    def test_validator(value):
        return value


    fa.set_default(1)
    fa.set_choices(["a", "b", "c"])
    fa.set_setter(test_setter)
   

# Generated at 2022-06-23 06:01:59.512394
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass


# Generated at 2022-06-23 06:02:08.032687
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class TestFieldAttributeBase(FieldAttributeBase):
        obj = FieldAttribute(isa='string', default='default')

    try:
        obj = TestFieldAttributeBase()
        assert isinstance(obj, TestFieldAttributeBase)
        assert obj.obj == 'default'
    except Exception as ex:
        _error = "exception raised %s" % str(ex)
        failed(_error)
        raise

    passed("TestFieldAttributeBase.validate")


# Generated at 2022-06-23 06:02:10.009222
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase()


# Generated at 2022-06-23 06:02:19.639797
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.vars import VariableManager
    def test(dep_chain, expected_result):
        b = Base()
        for obj in dep_chain:
            setattr(b, '_parent', obj)
        assert b.get_search_path() == expected_result
    b1 = Base()
    b1._role_path = '/path/to/role1'
    b2 = Base()
    b2._role_path = '/path/to/role2'
    b3 = Base()
    b3._role_path = '/path/to/role3'
    b4 = Base()
    b4._role_path = '/path/to/role4'
    b5 = Base()
    b5._role_path = '/path/to/role5'

# Generated at 2022-06-23 06:02:25.239578
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    try:
        f = FieldAttributeBase()
        assert False, 'FieldAttributeBase() should raise exception, got %s' % f
    except TypeError:
        pass

    # FieldAttributeBase() takes optional (default)
    # argument, which is passed to AbstractFieldAttribute
    f = FieldAttributeBase(default=0)
    assert f.default == 0, 'FieldAttributeBase().default should be 0, got %s' % f.default


# Generated at 2022-06-23 06:02:32.998930
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    import tempfile

    from os import getenv
    from os import unlink
    from os import environ
    from shutil import rmtree
    from tempfile import gettempdir

    from ansible.parsing.yaml import from_yaml
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import strip_internal_keys

    # Make a temporary directory to use as the Ansible config dir
    tmp_path = tempfile.mkdtemp()
    config_data = """
    [defaults]
    ansible_managed = Ansible managed: {file} modified on %Y-%m-%d %H:%M:%S by {uid} on {host}
    """

    config_file = os.path.join(tmp_path, "ansible.cfg")

# Generated at 2022-06-23 06:02:35.931201
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # default behavior
    o = FieldAttributeBase()
    o.copy()



# Generated at 2022-06-23 06:02:47.963869
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    field_attribute_mock = Attribute('field attribute mock')

    class BaseMetaTestHelper:
        class_attribute = field_attribute_mock

    class_attribute_mock = Attribute('class attribute mock')

    class BaseMetaTestChildren(BaseMetaTestHelper, BaseMeta):
        _class_attribute = class_attribute_mock
        something_else = 'something else' # Some random attribute, to test that it is ignored, and that
                                          # parent attributes are not retrieved, as this base class is not inherited

    class_attribute_mock.default = 'default class attribute mock'
    class_attribute_mock.alias = 'class_attribute_alias'
    class_attribute_mock.inherit = True

    field_attribute_mock.default = 'default field attribute mock'

# Generated at 2022-06-23 06:02:51.323621
# Unit test for method get_path of class Base
def test_Base_get_path():
    obj = Base()
    assert isinstance(obj.get_path(), string_types)
    obj = None

