

# Generated at 2022-06-11 09:37:03.985071
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.compat.six import PY3
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    # Create a class to test with
    class MockFieldAttributeBase(FieldAttributeBase):
        # Declare the fields to test with
        _valid_attrs = dict(attr1=FieldAttribute(isa='string', default= 'default_value'))

    # Create a FieldAttributeBase object to test with
    test_obj = MockFieldAttributeBase()

    # Exercise the code and assert with expected results
    if PY3:
        # Declare the expected result
        expected_result = {"attr1": "default_value"}

        # Exercise the code
        result = test_obj.dump_

# Generated at 2022-06-11 09:37:12.863848
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    f = FieldAttribute(default=1, required=True)
    f1 = f.copy()
    assert f.default == 1 and f1.default == 1, 'f.default == 1 and f1.default == 1'
    assert f.required == f1.required and f.required == True, 'f.required == f1.required and f.required == True'
    f1.default = 2
    assert f.default == 1 and f1.default == 2, 'f.default == 1 and f1.default == 2'
    f.required = False
    assert f.required == f1.required and f1.required == True, 'f.required == f1.required and f1.required == True'


# Generated at 2022-06-11 09:37:20.541270
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test that FieldAttributeBase._get_validated_value()
    # returns correct output for all defined isa values.

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    variable_manager = VariableManager(loader=dataloader)
    templar = Templar(loader=dataloader,
                      variables=variable_manager.get_vars(play=None,
                                                          include_hostvars=False,
                                                          include_delegate_to=False))


# Generated at 2022-06-11 09:37:23.137610
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Unit test for method FieldAttributeBase.squash
    '''
    set_global_deprecated_options()
    # Has no direct tests, but tested by other classes
    pass

# Generated at 2022-06-11 09:37:30.247580
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    t = Task()
    t.action = 'setup'
    assert t.action == 'setup', \
        "FieldAttributeBase.squash: Task().action == 'setup'"

    t.register = 'shell'
    assert t.register == 'shell', \
        "FieldAttributeBase.squash: Task().register == 'shell'"

    t.delegate_to = 'localhost'
    assert t.delegate_to == 'localhost', \
        "FieldAttributeBase.squash: Task().delegate_to == 'localhost'"

    t2 = t.copy()
    t2.action = 'shell'
    assert t2.action == 'shell', \
        "FieldAttributeBase.squash: t2 = t.copy(); t2.action = 'shell'"

    t2.register = 'result'

# Generated at 2022-06-11 09:37:32.588811
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    f = FieldAttributeBase()
    try:
        f.get_validated_value(None, '1')
    except:
        pass


# Generated at 2022-06-11 09:37:36.015308
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # init a simple field attribute
    fa = FieldAttributeBase(isa='string')

    # test boolean
    assert fa.post_validate(templar=Templar()) == True
    fa.required = True
    assert fa.post_validate(templar=Templar()) == False


# Generated at 2022-06-11 09:37:38.514405
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    target = obj.get_ds()
    with pytest.raises(AnsibleParserError):
        assert target == 'parsing error'


# Generated at 2022-06-11 09:37:41.020402
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    p = mock_runner()
    obj = FieldAttributeBase()
    obj._validate(p, 'a', 'b')
    assert p.called == False

# Generated at 2022-06-11 09:37:47.399304
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    ansible_obj = FieldAttributeBase()
    
    # Dumps all attributes to a dictionary
    attrs = {}
    for (name, attribute) in iteritems(ansible_obj._valid_attrs):
        attr = getattr(ansible_obj, name)
        if attribute.isa == 'class' and hasattr(attr, 'serialize'):
            attrs[name] = attr.serialize()
        else:
            attrs[name] = attr
    #assert attrs ==

# Generated at 2022-06-11 09:38:20.407743
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    '''
        Unit test for method get_search_path of class Base
    '''
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play = ansible.playbook.Play.load(dict(name='test play', host='test_host',
                                           roles=[dict(name='test_role', tasks=[dict(name='test_task')])]))
    role = play.get_roles()[0]
    block = Block.load(dict(name='test_block', tasks=[dict(name='test_task')]), play=play, parent_block=role)
    role._role_path = '/path/to/role'

# Generated at 2022-06-11 09:38:27.224306
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # An object of type FieldAttributeBase
    is_required=False
    isa='string'
    class_type=None
    choices=()
    listof=None
    default=None
    always_post_validate=False
    static=False
    attribute_name='test_attribute_name'
    display_name='test_display_name'
    default_if=None
    desc='test_not_none'
    FieldAttributeBase_obj_1 = FieldAttributeBase(is_required=is_required, isa=isa, class_type=class_type, choices=choices, listof=listof, default=default, always_post_validate=always_post_validate, static=static, attribute_name=attribute_name, display_name=display_name, default_if=default_if, desc=desc)


# Generated at 2022-06-11 09:38:29.224733
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    try:
        obj.post_validate()
    except (AnsibleUndefinedVariable, TypeError, ValueError):
        pass
    except (AssertionError):
        raise


# Generated at 2022-06-11 09:38:38.746954
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():


    # Create a FieldAttributeBase object
    obj = FieldAttributeBase()
    
    # Load an empty dictionary
    obj.load_data({})
    
    # Load a dictionary with bogus data
    data = dict(a=1, b='two', c=3.0)
    obj.load_data(data)
    
    # Load a dictionary with correct data
    data = dict(a=1, b='two', c=3.0)
    obj.load_data(data)
    
    assert(obj._attributes == dict(a=1, b='two', c=3.0))

# Generated at 2022-06-11 09:38:40.898972
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    ds = {}
    sut = FieldAttributeBase()
    assert(sut.dump_me(ds) == True)


# Generated at 2022-06-11 09:38:41.864775
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert True

# Generated at 2022-06-11 09:38:52.727562
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    def _validate_variable_keys(ds):
        for key in ds:
            if not isidentifier(key):
                raise TypeError("'%s' is not a valid variable name" % key)
    task = Task()
    task._load_vars = lambda attr, ds: ds
    task._valid_attrs = {'vars': FieldAttribute(isa='dict'), 'name': FieldAttribute(isa='string')}
    task._variable_manager = Mock()
    task._validated = False
    task._finalized = False
    task._squashed = False
    ds = {}
    attrs = {'name': 'test_task', 'vars': {'foo': 'bar'}}
    task.from_attrs(attrs)
    assert task.name == 'test_task'

# Generated at 2022-06-11 09:39:03.757065
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # 
    # Test a simple integer
    # 
    local_temp_dir = tempfile.mkdtemp()
    dummy_loader = DataLoader()
    dummy_inventory = Inventory(loader=dummy_loader, variable_manager=VariableManager(), host_list=[])
    temp_vars = dict(a="1")
    temp_vars_obj = VariableManager(loader=dummy_loader, inventory=dummy_inventory)._hostvars = temp_vars

    obj = FieldAttributeBase(parent_object=None)
    obj.isa = "int"
    obj.default = 0
    obj.required = True
    obj.always_post_validate = True

# Generated at 2022-06-11 09:39:04.665657
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass

# Generated at 2022-06-11 09:39:13.356847
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    ds = dict(_ds=dict(type='dict', required=True))
    valid_attrs = dict(_valid_attrs=dict(name=dict(isa='dict', default=dict(), required=True)))
    base = type('base', (FieldAttributeBase, object), dict(ds=ds, valid_attrs=valid_attrs))
    attribute = dict(isa='string', default='')
    value = 'foo'

    dd = base()
    actual = dd.get_validated_value('name', attribute, value)
    assert actual == 'foo'

    attribute = dict(isa='int', default=0)
    value = '1'

    dd = base()
    actual = dd.get_validated_value('name', attribute, value)
    assert actual == 1


# Generated at 2022-06-11 09:39:41.905516
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method FieldAttributeBase._copy
    '''

    # test empty obj
    obj = FieldAttributeBase()
    new_obj = obj._copy()
    assert obj._copy() == obj, 'Bad test spec: obj._copy() == obj'


# Generated at 2022-06-11 09:39:42.807094
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-11 09:39:45.140949
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base_object = Base()
    assert base_object.get_dep_chain() == None


# Generated at 2022-06-11 09:39:55.865606
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    attr_calls = {

    }

    attr_calls['from'] = []

    config = utils.config.Loader()
    config.set_config_data({u'gathering': u'explicit'})
    config.set_basedir(u'/home/centos/ansible_test/')

    def test_data_callback(arg):
        attr_calls['from'].append(arg)
        return None


# Generated at 2022-06-11 09:39:59.203851
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    # Create the object
    f = FieldAttributeBase()

    # Run the actual test
    result = f.dump_attrs()

    assert result == {}

# Generated at 2022-06-11 09:40:00.775207
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    #TODO: validate the data passes from loader to the object
    pass

# Generated at 2022-06-11 09:40:02.052254
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    assert True


# Generated at 2022-06-11 09:40:12.442652
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    attrs = dict(
         uuid='123-123-123',
         finalized=False,
         squashed=False
    )
    data=dict(
        name='foo.yml',
        connection='local',
        forks=1,
        gather_facts=True,
        roles=[],
        tasks=[],
        vars={},
        handlers=[],
        compile_task=False,
        roles_path=[],
        play_hosts=['127.0.0.1']
    )

    myobj = object()
    for (attr, value) in iteritems(data):
        if attr in myobj._valid_attrs:
            attribute = myobj._valid_attrs[attr]
            if attribute.isa == 'class' and isinstance(value, dict):
                obj = attribute.class_type()

# Generated at 2022-06-11 09:40:20.648578
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # test deserialize

    seq = None
    attr = FieldAttributeBase(isa='seq', default=seq)
    assert attr.default == seq

    class MyClass(object):
        attr = FieldAttributeBase(isa='int', default=10)
        def __init__(self):
            self.attr = 20
    mc = MyClass()
    assert mc.attr == 20
    mc.deserialize({'attr': 30})
    assert mc.attr == 30
    mc.deserialize({})
    assert mc.attr == 20
    mc.deserialize({'attr': "invalid"})
    assert mc.attr == 20



# Generated at 2022-06-11 09:40:30.153448
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class MyClass(FieldAttributeBase):
        foo = FieldAttribute(isa='int', required=True, default=1000)
        bar = FieldAttribute(isa='int', required=False, default='{{ foo }}')
        baz = FieldAttribute(isa='list', required=False, default='{{ foo }}')
        boo = FieldAttribute(isa='dict', required=False, default='{{ foo }}')
        yay = FieldAttribute(isa='float', required=False, default='{{ foo }}')
        par = FieldAttribute(isa='set', required=False, default='{{ foo }}')

    my_obj = MyClass()
    my_obj.post_validate({'foo': '4', 'bar': '8', 'baz': '12', 'boo': '16', 'yay': '20', 'par': '24'})
    assert my

# Generated at 2022-06-11 09:41:24.128367
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    given_arguments = {'name': 'foo', 'attribute': 'bar', 'value': 'baz', 'templar': 'qux'}
    expected_output = 'baz'
    test_instance = FieldAttributeBase()
    actual_output = test_instance.get_validated_value(**given_arguments)
    assert expected_output == actual_output

# Generated at 2022-06-11 09:41:35.918292
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attr = FieldAttributeBase()

    # testing type conversion for 'string'
    value = attr.get_validated_value('', attr, 'some string', None)
    assert isinstance(value, str)

    # testing type conversion for 'int'
    value = attr.get_validated_value('', attr, '123', None)
    assert isinstance(value, int)
    assert value == 123

    # testing type conversion for 'float'
    value = attr.get_validated_value('', attr, '123.45', None)
    assert isinstance(value, float)
    assert value == 123.45

    # testing type conversion for 'bool'
    value = attr.get_validated_value('', attr, 'yes', None)
    assert isinstance(value, bool)
   

# Generated at 2022-06-11 09:41:41.961476
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    assert b.get_dep_chain() is None
    class Task:
        _parent = None
    class Play:
        _parent = Task()
    b = Base()
    b._parent = Play()
    assert b.get_dep_chain() == Play()
    b._parent = None
    assert b.get_dep_chain() is None



# Generated at 2022-06-11 09:41:44.199115
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field = FieldAttributeBase()
    assert field.from_attrs()
    return True


# Generated at 2022-06-11 09:41:45.969150
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Placeholder for proper testing
    assert True == True


# Generated at 2022-06-11 09:41:54.137951
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    # 1) test with a task without dependencies
    t = Task()
    assert t.get_search_path() == ['.'], 'search path should be current dir if no dependency'

    # 2) test with a task with a dep chain
    t1 = Task()
    t1._ds = "file2"
    t2 = Task()
    t2._ds = "file1"
    r1 = RoleDefinition()
    r1._role_path = "role1"
    r2 = RoleDefinition()
    r2._role_path = "role2"
    t2._parent = r2
    r2._parent = r1
    r1._

# Generated at 2022-06-11 09:42:05.710113
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    attr = FieldAttributeBase()

    try:
        attr.validate(None)
        assert 'expected an exception when passing a None'
    except AnsibleUndefinedVariable as e:
        assert isinstance(to_text(e), string_types)

    try:
        attr.validate(AnsibleUnsafeText(u'abc'))
        assert 'expected an exception when passing an unsafe string'
    except AnsibleUndefinedVariable as e:
        assert isinstance(to_text(e), string_types)

    try:
        attr.validate(u'abc')
    except AnsibleUndefinedVariable as e:
        assert 'Unexpected exception'


# Generated at 2022-06-11 09:42:09.275618
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Any zero argument calls to a method should be replaced by
    # a call to the next method down the MRO from that class
    assert get_ds != FieldAttributeBase.get_ds

    assert True



# Generated at 2022-06-11 09:42:10.398530
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    import copy
    fa = FieldAttributeBase()
    fa_copy = fa.copy()
    assert fa == fa_copy
    assert fa is not fa_copy


# Generated at 2022-06-11 09:42:13.749972
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict(_attributes=dict(foo='bar'))
    MyFieldAttributeBase = FieldAttributeBase()
    repr = MyFieldAttributeBase.deserialize(data)
    assert repr == dict(data)


# Generated at 2022-06-11 09:42:43.247089
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    Unit test for method get_validated_value of class FieldAttributeBase
    '''
    # TODO: rewrite these tests as unit tests with mocks
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("Not implemented")  # Unsupported arg type:
    #self.fail("

# Generated at 2022-06-11 09:42:52.966152
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    strRequest = """
    {
      "variable": "request",
      "tasks": [
        {
          "name": "test_task",
          "command": "echo \"{{ request.args.key1 }} {{ request.args.key2 }} {{ request.args.key3 }} {{ request.args.key4 }}\" > /tmp/ansible-test/test.txt"
        }
      ]
    }
    """
    jsonRequest = json.loads(strRequest)
    repr = serializer.serializer_safe_dump(jsonRequest)
    serializer.deserialize(repr)
    assert repr


# Generated at 2022-06-11 09:43:02.193006
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # Initialize class instance
    instance = FieldAttributeBase()

    # Set attributes for test purposes
    instance._valid_attrs = {'string': FieldAttribute('string', isa='string'), 'int': FieldAttribute('int', isa='int'), 'float': FieldAttribute('float', isa='float'), 'percent': FieldAttribute('percent', isa='percent'), 'list': FieldAttribute('list', isa='list', listof=None), 'liststring': FieldAttribute('liststring', isa='list', listof=string_types), 'listobject': FieldAttribute('listobject', isa='list', listof=BaseObject), 'dict': FieldAttribute('dict', isa='dict'), 'class': FieldAttribute('class', isa='class')}
    instance._alias_attrs = {}
    instance._loader = TestFieldAttributeBase__loader
    instance._variable

# Generated at 2022-06-11 09:43:09.643926
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.utils.vars import combine_vars
    import os

    class TestDS(Base):
        _test = FieldAttribute(isa='string')

    ds = TestDS()

    ds._test = 'foo'

    o1 = ds.copy()
    o2 = ds.copy()

    assert o1 == o2



# Generated at 2022-06-11 09:43:15.636818
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = AnsibleBase()
    # Test with a dict as data
    attr_name = None
    attr_isa = None
    attr_class_type = None
    attr_default = None
    attr_static = None
    attr_required = None
    attr_allows_suboptions = None
    attr_aliases = None
    attr_always_post_validate = None
    attr_attr_name = None
    attr_attr_type = None
    attr_attr_default = None
    attr_attr_static = None
    attr_attr_required = None
    attr_attr_aliases = None
    attr_listof = None
    attr_validater = None
    attr_choices = None
    attr_warn_only = None
   

# Generated at 2022-06-11 09:43:18.986640
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    Ensure FieldAttributeBase.squash() is callable.
    '''
    attribute = FieldAttribute()
    assert_equal(attribute.squash(None, None, None), None)



# Generated at 2022-06-11 09:43:27.849053
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Uncomment below for test data
    # valid_attrs =
    # required =
    # args =
    # kwargs =

    from ansible.module_utils._text import to_bytes
    if not isinstance(expected_result, dict):
        expected_result = dict(expected_result)

    for key, value in iteritems(expected_result):
        if isinstance(value, str):
            expected_result[key] = to_bytes(value, errors='surrogate_or_strict')

    field_attribute_base = FieldAttributeBase(valid_attrs, required, *args, **kwargs)
    field_attribute_base.deserialize(data)
    assert result == expected_result

# Generated at 2022-06-11 09:43:28.487276
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass

# Generated at 2022-06-11 09:43:29.147441
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass

# Generated at 2022-06-11 09:43:29.779170
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass

# Generated at 2022-06-11 09:44:18.098274
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Testing with good and bad data:
    BaseField.from_attrs({"name": "bob", "age": 20, "sex": "male"})
    BaseField.from_attrs({"name": "bob", "age": 50, "sex": "male", "job": "developer"})
    BaseField.from_attrs({"name": "bob", "age": 100, "sex": "male", "job": "developer", "attributes": ["attrib 1", "attrib 2", "attrib 3"]})

# Generated at 2022-06-11 09:44:18.772379
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-11 09:44:30.671294
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    '''
    Unit test for method get_search_path of class Base.
    '''
    def mock_get_dep_chain():
        return ['_parent._role_path']

    test_obj = Base()
    test_obj._parent = Base()
    test_obj._parent._role_path = 'role_path'

    monkeypatch.setattr(Base, 'get_dep_chain', mock_get_dep_chain)
    # Test for exception for path_stack
    test_obj._ds = Base()
    path_stack = test_obj.get_search_path()
    assert path_stack == [], 'path_stack is not empty.'

    # Test for exception for task_dir
    test_obj._parent._play = Base()
    test_obj._parent._play._ds = Base()

# Generated at 2022-06-11 09:44:32.975584
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase('')
    data = dict()
    assert obj.validate(data) == False



# Generated at 2022-06-11 09:44:36.354432
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = {'foo': 'bar'}
    base = FieldAttributeBase()
    base.from_attrs(attrs)
    assert base.foo == 'bar'


# Generated at 2022-06-11 09:44:38.542941
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    """
    Test for ansible.utils.object_attributes.FieldAttributeBase.dump_attrs
    """
    assert False



# Generated at 2022-06-11 09:44:47.031657
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # Load test data from test/units/parsing/attribute_values.json
    tests = None
    with open("tests/unit/parsing/attribute_values.json", "r") as f:
        tests = json.load(f)

    for test in tests:

        for testcase in test['cases']:

            fixture = testcase
            fixture_args = {
                "value": fixture[0],
                "instance_cls": fixture[1],
                "attribute": fixture[2],
                "loader": fixture[3],
                "variable_manager": fixture[4],
                "ds": fixture[5],
            }


# Generated at 2022-06-11 09:44:50.342231
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Test method from_attrs of class FieldAttributeBase.
    '''
    new_obj = FieldAttributeBase.from_attrs(dict(
        )
    )

    assert isinstance(new_obj, FieldAttributeBase)

# Generated at 2022-06-11 09:44:58.651996
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    # This should not fail
    module.params = FieldAttributeBase().validate(module, 'test', None)
    # This should fail because 'test' is not an integer
    try:
        module.params = FieldAttributeBase().validate(module, 'test', 'test')
    except Exception as e:
        if not "must be an integer" in str(e):
            raise Exception("The test case did not fail with the expected message when validation failed with reason as expected")


# Generated at 2022-06-11 09:45:06.037483
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attributes = dict(
        attribute1='value1',
        attribute2='value2',
    )
    entity = FieldAttributeBase(**attributes)
    
    assert entity
    assert entity.attribute1 == 'value1'
    assert entity.attribute2 == 'value2'
    assert entity._is_valid_attr('attribute1')
    assert entity._is_valid_attr('attribute2')
    assert entity._get_attr('attribute1') == 'value1'
    assert entity._get_attr('attribute2') == 'value2'
    assert entity._get_attrs() == attributes

# Generated at 2022-06-11 09:45:34.558131
# Unit test for method __new__ of class BaseMeta

# Generated at 2022-06-11 09:45:44.228823
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    mock_1 = MagicMock()
    mock_1.isa = 'string'
    mock_1.required = False
    mock_1.static = False
    mock_1.listof = None
    mock_1.class_type = None
    mock_1.default = None
    mock_1.always_post_validate = False
    _attributes = {
        'mock': mock_1,
    }
    mock_2 = MagicMock()
    mock_2.isa = 'int'
    mock_2.required = False
    mock_2.static = False
    mock_2.listof = None
    mock_2.class_type = None
    mock_2.default = None
    mock_2.always_post_validate = False
    _attributes['mock_2'] = mock_

# Generated at 2022-06-11 09:45:54.903489
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    print('Test get_validated_value...')
    attr = assert_type_str = assert_type_int = assert_type_bool = assert_type_percent = assert_type_list = assert_type_set = assert_type_dict = assert_type_class = None
    obj = FieldAttributeBase()
    attr = {'isa': 'str', 'default': 'default_value', 'required': False, 'always_post_validate': False, 'static': False}
    obj.get_validated_value('key', attr, 'value', 'templar')
    attr = {'isa': 'int', 'default': 'default_value', 'required': False, 'always_post_validate': False, 'static': False}

# Generated at 2022-06-11 09:46:03.588449
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # String attribute with boolean isa
    obj = FieldAttributeBase('name', isa='bool')
    obj.value = 'yes'
    assert obj.post_validate(None) is True
    # String attribute with string isa
    obj = FieldAttributeBase('name', isa='string')
    obj.value = 'abc'
    assert obj.post_validate(None) == 'abc'
    # String attribute with int isa
    obj = FieldAttributeBase('name', isa='int')
    obj.value = '123'
    assert obj.post_validate(None) == 123
    # String attribute with float isa
    obj = FieldAttributeBase('name', isa='float')
    obj.value = '123.456'
    assert obj.post_validate(None) == 123.456
    # String attribute with

# Generated at 2022-06-11 09:46:08.209989
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestNamespace(AnsibleBaseYAMLObject):
        pass
    class TestBase(Base, metaclass=BaseMeta):
        _field_name_attribute_map = {
            'name': FieldAttribute(attribute=Attribute(default='default_value'), field_name='name'),
        }
        def _load_name(self):
            return self._attributes['name']
    class Test(TestBase):
        def __init__(self, name, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self._attributes['name'] = name