

# Generated at 2022-06-11 09:36:50.940781
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():

    def mock_from_attrs(self, obj):
        assert(isinstance(obj, dict))
        for attr, value in iteritems(obj):
            if attr in self._valid_attrs:
                attrib = self._valid_attrs[attr]
                if isinstance(value, dict) and attrib.isa == 'class':
                    obj = attrib.class_type()
                    obj.deserialize(value)
                    setattr(self, attr, obj)
                else:
                    setattr(self, attr, value)

    def mock_serialize(self):
        repr = {}
        for (name, attribute) in iteritems(self._valid_attrs):
            attr = getattr(self, name)
            if isinstance(attr, dict) and attribute.isa == 'class':
                repr

# Generated at 2022-06-11 09:36:52.876150
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert True, 'TODO: Implement your tests here'

# Generated at 2022-06-11 09:36:55.841135
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    my_obj = FieldAttributeBase()
    assert my_obj.load_data(None, None, None) is None



# Generated at 2022-06-11 09:36:58.838397
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    assertion = False
    try:
        obj.copy()
    except NotImplementedError:
        assertion = True
    finally:
        assert assertion



# Generated at 2022-06-11 09:37:04.838286
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # ansible.ModuleArgs requires a subclass of Base to implement attribute_class and module_name
    class FakeModuleArgs(ModuleArgs):
        @staticmethod
        def attribute_class():
            return 'module_utils.module_common.ModuleBase'

        @staticmethod
        def module_name():
            return 'FakeModuleArgs'

    def testfunc():
        pass

    x = FieldAttribute(isa=string_types, required=False)
    assert x.post_validate(None) is None

    x = FieldAttribute(isa='list', required=False)
    assert x.post_validate([]) == []
    assert x.post_validate(None) is None

    x = FieldAttribute(isa='list', listof=int)
    assert x.post_validate([]) == []

# Generated at 2022-06-11 09:37:14.217692
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.template.vars import Templar
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-11 09:37:16.711921
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Setup
    result = None
    data = 'foo'
    obj = FieldAttributeBase(data)

    # Execute
    result = obj.dump_attrs()

    # Assert
    assert result == {'data': 'foo'}



# Generated at 2022-06-11 09:37:25.092113
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    
    # the class defined in this test
    class A(Base):
        pass
    # a parent class of Base
    class B(A):
        pass

    # get task_dir from method get_path of class Base
    task = B()
    task._ds = {}
    task._ds._data_source = "test.yml"
    task._ds._line_number = 1

    # test _parent is Base
    if A != Base:
        task._parent = A()
        assert task.get_search_path() == task.get_search_path()

    # test _parent is not None and _parent is not Base
    task._parent = {}
    task._parent._play = B()
    task._parent._play._ds = {}
    task._parent._play._ds._data_source = "play.yml"

# Generated at 2022-06-11 09:37:26.293437
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    raise SkipTest  # TODO: implement your test here


# Generated at 2022-06-11 09:37:27.970125
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # base = FieldAttributeBase()
    # assert base.dump_attrs() == {}
    assert 'not tested' == 'FIXME'


# Generated at 2022-06-11 09:37:49.200259
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    print(">> valid FieldAttributeBase.post_validate")
    try:
        f = FieldAttributeBase()
        f.post_validate()
        print(">>  success '%s'" % f)
    except Exception:
        print(">> fail '%s'" % f)
        return False
    return True

# Generated at 2022-06-11 09:38:01.793844
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVarsModule
    from ansible.vars.hostvars import HostVarsLookupModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    #Test 1

# Generated at 2022-06-11 09:38:05.163538
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    FA = FieldAttributeBase()
    ds = dict()
    FA_dump = FA.dump_me(ds)
    assert FA_dump == None


# Generated at 2022-06-11 09:38:15.716922
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    loader = DataLoader()
    variable_manager = VariableManager()
    kwargs = {}
    kwargs['loader'] = loader
    kwargs['variable_manager'] = variable_manager
    f = FieldAttributeBase(**kwargs)
    b_path = "/home/ansible/ansible/test/units/module_utils/test_module_utils.py"
    b_ds = {}
    attribute = {'name': 'attrib'}
    # ValueError
    with pytest.raises(ValueError):
        f.load_data(b_path, b_ds, attribute)
    attribute = {'name': 'path'}
    # Error
    with pytest.raises(Error):
        f.load_data(b_path, b_ds, attribute)

# Generated at 2022-06-11 09:38:21.118950
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    fieldattrib = FieldAttributeBase()
    assert fieldattrib.__class__.__name__ == 'FieldAttributeBase'
    assert fieldattrib._dump_me() == None


# Generated at 2022-06-11 09:38:25.933537
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # test with a valid value
    ok_(FieldAttributeBase(isa='list').validate(['foo', 'bar', 'baz']))

    # test with an invalid value
    error_raised = False
    try:
        FieldAttributeBase(isa='list').validate('foo')
    except:
        error_raised = True
    ok_(error_raised)


# Generated at 2022-06-11 09:38:30.561129
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    myobj = FieldAttributeBase()
    myobj.post_validate(object)
    myobj.get_validated_value(name=object, attribute=object, value=object, templar=object)


# Generated at 2022-06-11 09:38:38.053129
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    inst = FieldAttributeBase()
    data = 'foo'
    result = inst.get_ds(data)
    assertEqual(result.get('_ds'), data)
    # Make sure the _ds attribute is removed from the returned data
    data = {'foo': 'bar', '_ds': 'bar'}
    result = inst.get_ds(data)
    assertEqual(result.get('_ds'), None)

# Generated at 2022-06-11 09:38:42.036745
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = {}
    name = None
    attribute = None
    Attribute = None
    ansible_module = None
    result = FieldAttributeBase.from_attrs(attrs, name, attribute, Attribute, ansible_module)
    # FIXME: modify expected result



# Generated at 2022-06-11 09:38:43.360237
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    assert obj.get_ds() is None

# Generated at 2022-06-11 09:39:12.138517
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass


# Generated at 2022-06-11 09:39:15.077522
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # When we call method from_attrs() of class FieldAttributeBase
    # we serialized object of type FieldAttributeBase
    # should be returned
    assert (type(FieldAttributeBase.from_attrs(None)) is FieldAttributeBase)


# Generated at 2022-06-11 09:39:24.669418
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test_play = Play()
    test_play._ds = Ds()
    test_play._ds._data_source = 'test_playbook'
    test_play._ds._line_number = 12
    test_task = Task()
    test_task._ds = Ds()
    test_task._ds._data_source = './test_file'
    test_task._ds._line_number = 15
    test_task._role_path = './test_path'
    test_task._parent = test_play
    test_task._name = 'test_task'
    assert test_task.get_search_path() == ['./test_file', 'test_playbook:12']


# Generated at 2022-06-11 09:39:26.179677
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    data.update(data)




# Generated at 2022-06-11 09:39:27.244284
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    assert True


# Generated at 2022-06-11 09:39:34.530251
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''Unit test for FieldAttributeBase.dump_me'''

    class FakeA(object):
        def __init__(self, attr=None):
            self.attr = attr
        def dump_me(self):
            return self.attr

    class FakeBase(Base):
        _default_attributes = {'attr': FakeA()}

    b = FakeBase()
    assert b.dump_me() == {'attr': None}

    b.attr.attr = 'foo'
    assert b.dump_me() == {'attr': 'foo'}

# Generated at 2022-06-11 09:39:46.616425
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    FA = FieldAttributeBase()
    FA._post_validate(FA, None)
    FA.required = True
    FA.static = True
    FA.always_post_validate = True
    FA.isa = "int"
    FA.class_type = None
    FA.default = None
    FA.class_type2 = None
    FA.name = "name"
    FA.listof = list
    FA.listof2 = None
    FA.final = False
    FA.aliases = []
    FA.vars_only_attrs = []
    FA.db_name = "name"
    FA.keytype = "name"
    FA.keytype2 = None
    FA.keytype3 = None
    FA.key_attr = "name"
    FA.key_attr2 = None

# Generated at 2022-06-11 09:39:49.215251
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    object_ = FieldAttributeBase()
    assert object_.get_validated_value() == None



# Generated at 2022-06-11 09:39:57.683263
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    testData = [
        { '_finalized': False, '_squashed': False, '_uuid': 'b0f55f392dfc44a7b6d8c2738b75e158' },
        { '_finalized': False, '_squashed': False, '_uuid': 'b0f55f392dfc44a7b6d8c2738b75e158' },
        { '_finalized': False, '_squashed': False, '_uuid': 'b0f55f392dfc44a7b6d8c2738b75e158' },
    ]
    for testdata in testData:
        testdata = BaseTest(testdata)
        u = testdata._finalized
        v = testdata._squashed
        w = testdata._uuid
        x

# Generated at 2022-06-11 09:40:02.304457
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a valid list to check for exceptions
    # Check for expected output
    for test_data in valid_DATAFILE_content:
        data = test_data
        f = FieldAttributeBase()
        f.deserialize(data)

# Generated at 2022-06-11 09:40:32.342591
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attrs = dict(
        name=dict(
            required=False,
            required_if=False,
            aliases=['task'],
            deprecated_aliases=[],
            override=True,
            attr_class=False,
            always_post_validate=False,
            mutually_exclusive=[],
            removed_in_version=None,
            internal=False,
            default=None,
            default_in_check_mode=None,
            env_fallback=None,
            no_log=False,
            type=str,
            tags=set(),
            choices=set(),
            strict=False,
            ignore_errors=False,
            isa=None,
            listof=None,
            class_type=None,
            static=False,
        )
    )

    a = Ans

# Generated at 2022-06-11 09:40:39.300322
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    assert Play.validate(dict(hosts="all", name=None, gather_facts=True, roles=[], tasks=[], vars={})) is None
    assert Play.validate(dict(name="test", gather_facts=True, roles=[], tasks=[], vars={})) is None
    # replay stuff
    assert Play.validate(dict(name="test", gather_facts=True, roles=[], tasks=[], vars={}, post_tasks=[], pre_tasks=[], handlers=[], rescue=[], always=[], no_log=True)) is None


# Generated at 2022-06-11 09:40:49.172477
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext

    # Test case for a static, immutable field attribute
    name = 'foo'
    def_val = 'bar'
    attr = FieldAttribute(isa='string', static=True, immutable=True)
    attr.set_default(def_val)
    attr.name = name

    attr_copy = attr.copy()

    assert attr_copy.isa == 'string'
    assert attr_copy.name == 'foo'
    assert attr_copy.static is True
    assert attr_copy.immutable is True
    assert attr_copy.default == def_val

    # Test case for a static, mutable field attribute
    name = 'foo'

# Generated at 2022-06-11 09:40:51.283488
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test_obj = FieldAttributeBase()
    assert test_obj is not None


# Generated at 2022-06-11 09:40:52.407266
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FieldAttributeBase()  # no error



# Generated at 2022-06-11 09:41:03.202486
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    hostvars = dict()
    group_vars = dict()
    group_vars['group_one'] = dict(one='1', two='2')
    group_vars['group_two'] = dict(three='3', four='4')

    for p in ('group_one', 'group_two'):
        if p not in hostvars:
            hostvars[p] = dict()
        hostvars[p].update(group_vars[p])

    avail_vars = dict()
    avail_vars['inventory_hostname'] = 'host0'
    avail_vars['inventory_hostname_short'] = 'host0'
    avail_vars['group_names'] = ['group_one', 'group_two']
    avail_vars.update(hostvars['group_one'])

# Generated at 2022-06-11 09:41:05.240330
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base.validate() == None


# Generated at 2022-06-11 09:41:09.779459
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    '''
    # Default case
    # Test 1
    fb = FieldAttributeBase()
    result = fb.dump_me()
    assert_equal(exp_result=None, act_result=result)
    os.close(tf.name)

# Generated at 2022-06-11 09:41:20.014505
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    my_class = type('TestBaseObject', (BaseObject,), {})
    my_class._valid_attrs = dict(a="a", b="b")
    my_class._finalized = True
    my_class._squashed = True

    obj = my_class()
    assert obj.dump_attrs() == dict(a=None, b=None)

    my_class._valid_attrs = dict(a="a", b="int", c="float", d="bool", e=FieldAttribute("list", []))
    my_class._finalized = True
    my_class._squashed = True

    obj = my_class()
    obj.b = 1
    obj.c = 1.0
    obj.d = True
    obj.e = [1, 2]


# Generated at 2022-06-11 09:41:21.996386
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fields = FieldAttributeBase().dump_attrs()

    assert fields == {}



# Generated at 2022-06-11 09:41:53.713796
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FAKE_DATA_1 = dict(
        _valid_attrs=dict(
            x=FieldAttribute(isa='string'),
            y=FieldAttribute(isa='int')
        ),
        x='foo',
        y=5
    )

    FAKE_DATA_2 = dict(
        _valid_attrs=dict(
            x=FieldAttribute(isa='string'),
            y=FieldAttribute(isa='class')
        ),
        x='foo',
        y=dict(
            _valid_attrs=dict(
                x=FieldAttribute(isa='string'),
                y=FieldAttribute(isa='int')
            ),
            x='foo',
            y=5
        )
    )

    # test 1: simple case where only basic types are serialized
    f = FieldAttributeBase()
    f._valid_att

# Generated at 2022-06-11 09:42:05.439562
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def in_memory_inventory(loader, variable_manager):
        variable_manager.set_inventory(InventoryManager(loader=loader, sources=['127.0.0.1']))

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    in_memory_inventory(loader, variable_manager)

    # test valid cases

# Generated at 2022-06-11 09:42:15.550487
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.utils.path import unfrackpath
    fake_loader = DictDataLoader({
        "a_role/vars/main.yml": """
            ---
            bar: baz
        """
    })
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])

    # NOTE: we use the _ansible_no_log here to make sure we don't get logged
    # as sensitive information
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory, version_info=VersionInfo.fake("2.4"))
    fake_variable_manager.set_host_variable("fake_host", "_ansible_no_log", True)
    fake_variable_manager.set_host_variable("fake_host", "ansible_log_path", "/dev/null")
   

# Generated at 2022-06-11 09:42:16.821989
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass


# Generated at 2022-06-11 09:42:27.805298
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.color import stringc

    a = FieldAttributeBase()
    a.post_validate(None)

    a.static = True
    a.post_validate(None)
    assert a.static == True

    a.static = False
    a.required = True
    a.post_validate(None)
    assert a.static == False

    templar = MagicMock()
    templar.template.return_value = True
    a = FieldAttributeBase()
    a.post_validate(templar)
    assert a.static == False

    a.static = False
    a.required = True

# Generated at 2022-06-11 09:42:29.412193
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert Base.get_dep_chain('') == None

# Generated at 2022-06-11 09:42:36.421203
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase()
    setattr(obj, '_valid_attrs', {'name': 'value', 'name2': 'value2'})
    name = 'name'
    value = 'value'
    data = {name: value}
    obj._load_data(data)
    assert getattr(obj, name) == value
    assert isinstance(getattr(obj, name), string_types)
    assert getattr(obj, 'name2') == 'value2'

# Generated at 2022-06-11 09:42:44.640537
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    hostvars = {"test_foo": "bar", "test_baz": "qux"}
    self = FieldAttributeBase(None)
    self.hostvars = hostvars
    self.get_hostvars = lambda: hostvars
    elem = {"name": "test", "hosts": ["test_host"]}

    #With attrs is a dict
    with patch.object(FieldAttributeBase, 'dump_attrs', return_value = {"name": "test", "hosts": ["test_host"]}):
        res = self.dump_me()
        assert res == {"name": "test", "hosts": ["test_host"]}

    #With attrs is not a dict

# Generated at 2022-06-11 09:42:46.243430
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass


# Generated at 2022-06-11 09:42:53.396495
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {"module_name": "dummy", "module_args": "dummy_params", "async": 0}
    test_obj = Task()
    test_obj.deserialize(data)
    if not (test_obj.module_name == "dummy" and test_obj.module_args == "dummy_params"):
        raise AnsibleAssertionError('FieldAttributeBase.deserialize() did not work as expected')


# Generated at 2022-06-11 09:44:02.070920
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    repr_ = repr
    attr_class = FieldAttributeBase
    obj = attr_class(name='foo', default='bar', include=['fie', 'fum'], exclude=['foe'],
                     omit=False, require=['fum'])
    attrs = obj.dump_attrs()
    assert attrs == {'name': 'foo', 'default': 'bar', 'include': ['fie', 'fum'], 'exclude': ['foe'],
                     'omit': False, 'require': ['fum'], 'static': True}
    # We don't use pytest.raises as we want to access the exception

# Generated at 2022-06-11 09:44:12.396771
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # The function get_validated_value of class FieldAttributeBase,
    # which is used to simplify the statements and avoid
    # redundancy in code. This function applies some rules
    # depending the input type to obtain a value of the
    # corresponding type.
    ##############################################
    # Unit Tests for function get_validated_value #
    ##############################################
    #
    # Unit test setup
    from ansible.plugins.loader import module_loader
    templar = Templar(loader=module_loader)
    class Object(object):
        pass
    ds = Object()
    ds.module_name = 'system'

    # Unit test: value type string
    name = 'test string'
    attribute = FieldAttributeBase()
    attribute.isa = 'string'
    value = '5'
    result = ds

# Generated at 2022-06-11 09:44:19.734676
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # test with only str
    attribute = FieldAttributeBase('test', 'str', default='test_default')

    assert attribute.get_validated_value('test', attribute, 'test_value') == 'test_value'
    attribute.get_validated_value.called_with('test', attribute, 'test_value')

    # test with int
    attribute = FieldAttributeBase('test', 'int', default=0)

    assert attribute.get_validated_value('test', attribute, '1') == 1
    attribute.get_validated_value.called_with('test', attribute, '1')

    # test with float
    attribute = FieldAttributeBase('test', 'float', default=0.0)

    assert attribute.get_validated_value('test', attribute, '1.1') == 1.1
    attribute.get_valid

# Generated at 2022-06-11 09:44:31.618842
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    def _find_class(name, module_name, base_class=None):
        if base_class is None:
            base_class = object
        for cls in inspect.getmembers(sys.modules[module_name], inspect.isclass):
            if cls[1].__module__ == module_name and cls[0] == name:
                return cls[1]
        raise AssertionError('Failed to find class %s in module %s' % (name, module_name))

    class TestFieldAttributeBase(FieldAttributeBase):
        def _finalize_me(self, attr, value):
            return value

    class TestBase(Base):
        pass


# Generated at 2022-06-11 09:44:32.703584
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass


# Generated at 2022-06-11 09:44:37.369408
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    sample_obj = FieldAttributeBase()

    sample_obj.foo = 'abc'
    sample_obj.bar = 'def'

    result = sample_obj.dump_attrs()
    assert result['foo'] == 'abc'
    assert result['bar'] == 'def'


# Generated at 2022-06-11 09:44:45.510347
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data_str = r"""data = dict(
    name = None,
    default = None,
    required = None,
    always_post_validate = None,
    ignore_errors = None,
    isa = None,
    type = None,
    choices = None,
    aliases = None,
    version_added = None,
    version_removed = None,
    no_log = None,
    private = None,
    deprecated_aliases = None,
    removed_in_version = None,
    converted_to = None,
)
"""
    data = eval(data_str, dict(FieldAttributeBase=FieldAttributeBase))

    obj = FieldAttributeBase()
    obj.deserialize(data)

    assert obj is not None

# Generated at 2022-06-11 09:44:55.724719
# Unit test for method get_search_path of class Base

# Generated at 2022-06-11 09:45:01.681342
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    data['key1'] = 'value1'
    data['_uuid'] = 'uuid1'
    data['finalized'] = False
    data['squashed'] = False
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.key1 == 'value1'
    assert obj._uuid == 'uuid1'
    assert obj._finalized == False
    assert obj._squashed == False



# Generated at 2022-06-11 09:45:03.997893
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    host_1 = HostVars({})
    templar = Templar(variables=host_1.vars)
    
    

    
    
    

# Generated at 2022-06-11 09:46:05.364493
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass
# END Unit test for method deserialize of class FieldAttributeBase

