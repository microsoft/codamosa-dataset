

# Generated at 2022-06-11 09:36:42.982462
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    data = dict(
        test_attr=FieldAttributeBase('test_attr', required=True, default=None)
    )
    obj = FieldAttributeBase(data=data)
    assert obj.dump_me() == 'attribute "test_attr" of class FieldAttributeBase'



# Generated at 2022-06-11 09:36:45.381751
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''Unit test for method copy of class FieldAttributeBase'''

    assert True

# Generated at 2022-06-11 09:36:46.556540
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    pass # TODO

# Generated at 2022-06-11 09:36:50.387230
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    task = Task()
    task.from_attrs({'name': 'foo', 'action': 'bar'})
    assert task.name == 'foo'
    assert task.action == 'bar'



# Generated at 2022-06-11 09:37:01.126795
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    task = Task()

# Generated at 2022-06-11 09:37:05.513039
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'name': 'fake_name', 'test': 'fake_test'}
    repr = FieldAttributeBase()
    repr.deserialize(data)
    # assert repr.name == 'fake_name'
    # assert repr.test == 'fake_test'

# Generated at 2022-06-11 09:37:14.581562
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Create base test object
    base = Base()

    # Check without path
    assert base.get_search_path() == []

    # Create palybook test object and add path to it
    playbook = Playbook()
    playbook._ds = Attribute()
    playbook._ds._data_source = "test"

    # Create task test object and add path to it
    task = Task(playbook=playbook, ds=Attribute())
    task._ds._data_source = "test"

    # Add task to playbook
    playbook.add_tasks(task)

    # Check with path
    assert base.get_search_path() == ["test"]

    # Add other test object to task
    task2 = Task(playbook=playbook, ds=Attribute())
    task2._ds._data_source = "test2"
   

# Generated at 2022-06-11 09:37:16.262990
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    obj = FieldAttributeBase()
    obj.copy()


# Generated at 2022-06-11 09:37:24.573233
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # tests the FieldAttributeBase.post_validate method

    # test string
    field = FieldAttribute('string', 'test_name', 'test_description')
    field.post_validate(templar, 'string')
    assert field._value == 'string'
    # test int
    field = FieldAttribute('int', 'test_name', 'test_description')
    field.post_validate(templar, 1)
    assert field._value == 1
    # test float
    field = FieldAttribute('float', 'test_name', 'test_description')
    field.post_validate(templar, 1.1)
    assert field._

# Generated at 2022-06-11 09:37:26.105915
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
   f = FieldAttributeBase()
   assert f._dump_me(None) == None


# Generated at 2022-06-11 09:37:56.373750
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    data = {'fieldname': 'test_name'}
    attr = FieldAttributeBase('test')
    attr.load_data(data, 'fieldname', 'test_default')
    assert attr._data == 'test_name'
    data = {'fieldname': None}
    attr = FieldAttributeBase('test')
    attr.load_data(data, 'fieldname', 'test_default')
    assert attr._data == 'test_default'


# Generated at 2022-06-11 09:37:57.295983
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    pass

# Generated at 2022-06-11 09:38:04.584804
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class DummyClass:
        def __init__(self):
            self.args = None
        def post_validate(self, templar):
            pass
    class_ = DummyClass()
    instance = FieldAttributeBase()
    instance.value = 'test'
    instance.post_validate(class_, class_.args)
    assert class_.args == 'test'

# Generated at 2022-06-11 09:38:11.887515
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    cls = FieldAttributeBase
    # test with a basic field attribute that has no special post validation
    ds = dict(
        name='bool_choice',
        required=True,
        isa=bool,
        choices=[False, True],
        default=False,
        )
    fa = cls(**ds)
    ai = cls(**ds)
    obj = TestBaseObject(None, None)
    obj.bool_choice = 'True'
    obj.post_validate(FakeTemplar())
    # No assertion



# Generated at 2022-06-11 09:38:13.256796
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    instance = FieldAttributeBase()
    assert instance.validate() is False

# Generated at 2022-06-11 09:38:23.400808
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # initializing setUp parameters
    param1 = {}
    param2 = {}
    param3 = {}

    # initializing TestCase Class object
    TestCaseObj = Task()

    # initializing instance objects for testing
    TestObjA = FieldAttributeBase(param1, param2, param3)
    TestObjB = FieldAttributeBase(param1, param2, param3)

    # Call the method - the assert statements will be called
    # The proper return value is being tested, not the thrown exception

    # The method should always return None
    assert TestObjA.post_validate(param1) == None
    assert TestObjB.post_validate(param1) == None

    # The method should raise an AnsibleParserError exception if callable(attribute.default) returns false
    # The exception should be handled inside the method and not be returned


# Generated at 2022-06-11 09:38:36.081746
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test 1: Default test for method post_validate
    par = dict(name = 'FieldAttributeBase',
               isa = 'FieldAttributeBase',
               default = 'FieldAttributeBase',
               )
    
    
    # Test 2: Test failure case for method post_validate
    par = dict(name = 'FieldAttributeBase',
               isa = 'FieldAttributeBase',
               default = 'FieldAttributeBase',
               )
    
    
    # Test 3: Test case with an alternate value for 'always_post_validate'
    par = dict(name = 'FieldAttributeBase',
               isa = 'FieldAttributeBase',
               default = 'FieldAttributeBase',
               always_post_validate = 'FieldAttributeBase',
               )
    
    
    # Test 4: Test case with an alternate value for 'priority'
    par

# Generated at 2022-06-11 09:38:43.199124
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # prepare
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    b = Base()
    p = Play()
    pc = PlayContext()
    b._parent = p
    p._parent = pc
    b._ds = 'file'
    b._ds._line_number = '100'
    p._ds = 'file'
    p._ds._line_number = '100'
    pc.search_path = ['a', 'b', 'c']
    b._role_path = 'd'

    # invoke
    search_path = b.get_search_path()

    # assert
    assert(search_path == ['d'])

# Generated at 2022-06-11 09:38:45.900226
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # init the object
    FieldAttributeBase.__init__(self)

    # init return value

# Generated at 2022-06-11 09:38:53.449813
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    import pytest
    attr = FieldAttributeBase(name='foo', always_post_validate=True)
    cls = Mock()
    cls.name = 'foo'
    obj = Mock()
    obj.get_ds = Mock(return_value='ds')
    templar = Mock()
    with pytest.raises(NotImplementedError):
        attr.load_data(cls=cls, attribute=None)

# Generated at 2022-06-11 09:39:28.501508
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FA = FieldAttributeBase


# Generated at 2022-06-11 09:39:38.423994
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    a = dict(
        _loader=object(),
        _variable_manager=object(),
        _validated=False,
        _finalized=False,
        _uuid=None,
        _ds=dict(
            meta=dict(
            )
        ),
        _valid_attrs=dict(
        ),
        _attributes=dict(
        ),
        _attr_defaults=dict(
        ),
        _warnings=None,
        _deprecations=None,
        _task_blocks=dict(),
        _role_blocks=dict(),
        _playbook_blocks=dict(),
        _aliases=None,
        _debugger=None
    )
    object.__setattr__(a, 'name', None)
    object.__setattr__(a, 'connection', None)
    object

# Generated at 2022-06-11 09:39:41.575007
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    FAB = FieldAttributeBase

    # simple test data
    data = {
        "foo": "bar",
        "baz": 123
    }

    # test
    field = FAB('foo')
    field.deserialize(data)
    assert field.foo == "bar"
    assert field.baz == 123

# Generated at 2022-06-11 09:39:47.227411
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    from ansible.parsing.yaml import objects as ansible_objects

    field_attribute = ansible_objects.FieldAttribute()
    field_attribute.deserialize({})

    with pytest.raises(AnsibleAssertionError):
        field_attribute.deserialize('xyz')

# Generated at 2022-06-11 09:39:49.044040
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Create an instance of FieldAttributeBase
    obj = FieldAttributeBase()

    # Call method
    obj.squash()

    # Check result
    assert obj.squashed == True



# Generated at 2022-06-11 09:39:53.004451
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field_attribute_base = FieldAttributeBase()
    try:
        field_attribute_base_result = field_attribute_base.dump_me()
    except Exception as e:
        field_attribute_base_result = False
    assert field_attribute_base_result

# Generated at 2022-06-11 09:39:59.254352
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    for valid_attrs in (
            {'name': 'arg', 'cmnd': 'cmnd_name', 'version_added': '2.0', 'required': True},
            {'name': 'arg', 'cmnd': 'cmnd_name', 'version_added': '2.0', 'required': False},
            {'name': 'arg', 'cmnd': 'cmnd_name', 'version_added': '2.0', 'required': None, 'default': 'my_default'}
    ):
        with pytest.raises(AnsibleParserError) as cm:
            get_argspec(valid_attrs)
        assert to_text(cm.value).startswith('The field \'required\' has an invalid value')

# Generated at 2022-06-11 09:39:59.982915
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  pass


# Generated at 2022-06-11 09:40:06.035392
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    foo = FieldAttributeBase(attribute=None, FieldAttribute=None, always_post_validate=None, default=None, class_type=None, class_children=None, isa=None, listof=None, static=None, secret=None, required=None)
    res = foo.copy()
    assert isinstance(res, FieldAttributeBase)
    assert res.__class__.__name__ == 'FieldAttributeBase'

# Generated at 2022-06-11 09:40:09.010062
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    my_task = Task()
    my_task.deserialize({'name': 'test'})
    assert my_task.name == 'test'


# Generated at 2022-06-11 09:40:42.608586
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    uut = FieldAttributeBase(None, None)

    class MyTestObject(FieldAttributeBase):
        def __init__(self):
            self._attributes = {
                'data': { 'class': 'MyTestDataClass1' },
            }
            self._valid_attrs = {
                'data': FieldAttribute(isa='class', class_type=MyTestDataClass1),
            }

    class MyTestDataClass1(FieldAttributeBase):
        def __init__(self):
            self._attributes = {
                'item': { 'class': 'MyTestDataClass2' },
            }
            self._valid_attrs = {
                'item': FieldAttribute(isa='class', class_type=MyTestDataClass2),
            }


# Generated at 2022-06-11 09:40:48.922576
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    fields = {}
    attr = FieldAttributeBase(isa='string', default='foo')
    fields['test'] = attr
    obj = FieldAttributeBase(fields=fields)
    ds = {}
    templar = {}
    setattr(obj, '_fields', fields)
    setattr(obj, '_loader', 'foo')
    obj.post_validate(fields=fields, templar=templar)



# Generated at 2022-06-11 09:40:54.837058
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    '''
    my_obj = FieldAttributeBase(name='test', private=True)

    # AssertionError: Expected assertion to fail with argument: <AnsibleAssertionError: The method 'dump_me' is not implemented for this attribute class (FieldAttributeBase)>
    #assert my_obj.dump_me() is None

# Generated at 2022-06-11 09:40:57.238431
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    a = FieldAttributeBase()
    s = AnsibleMock()
    a.post_validate(s)

# Generated at 2022-06-11 09:41:07.045924
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    _attribute = "FieldAttributeBase"
    _attr = FieldAttributeBase()
    # Check for Invalid values for the attribute
    with pytest.raises(ValueError):
        # Attribute not present in valid attributes list
        _attr.validate(_attribute, {'invalid_attribute_1': 'test'})
    with pytest.raises(ValueError):
        # Attribute present but value is not of type
        _attr.validate(_attribute, {'name': 233})
    # Check for valid values for the attribute
    _attr.validate(_attribute, {'name': 'test'})
    _attr.validate(_attribute, {'name': 'test', 'another_valid_attribute': 'test'})



# Generated at 2022-06-11 09:41:16.870515
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''
    Unit tests for the method validate of class FieldAttributeBase
    '''
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types

    FieldAttributeBase().validate(None, 'string') is None
    if PY3:
        with pytest.raises(TypeError):
            FieldAttributeBase().validate(b'bytes', 'string')

    with pytest.raises(TypeError):
        FieldAttributeBase().validate(object(), 'string')

    with pytest.raises(TypeError):
        FieldAttributeBase().validate(set(), 'string')

    with pytest.raises(TypeError):
        FieldAttributeBase().validate(string_types, 'string')



# Generated at 2022-06-11 09:41:18.350392
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test = FieldAttributeBase()
    test.load_data(None)



# Generated at 2022-06-11 09:41:24.705163
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fixture = AnsibleBase
    fixture2 = load_fixture('test_module_parameters_attrs.py')

    obj = fixture.load_from_file(fixture2, adapter=None, attribute_class='Task', loader=None, class_name='Task')
    result = obj.dump_attrs()
    assert result['name'] == 'test'
    assert result['tags'] == ['foo', 'bar']
    assert result['when'] == 'never'


# Generated at 2022-06-11 09:41:26.599941
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    a = FieldAttributeBase()
    assert a.from_attrs([]) == None


# Generated at 2022-06-11 09:41:38.705057
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # test_BaseMeta___new__ #
    # Constructor for BaseMeta
    #    def __new__(cls, name, parents, dct):
    # test_BaseMeta___new__ #
    # We override method __new__ to create a dummy object
    # where we can call method __new__ of BaseMeta
    class Wrapper():
        val = None

        def __new__(cls, val):
            cls.val = val
            return super(Wrapper, cls).__new__(cls)
    # Assert if BaseMeta constructor give us an Exception
    w = Wrapper("test_BaseMeta___new__")
    try:
        bm = BaseMeta("BaseMeta", (Wrapper,), {"__init__":None})
    except:
        assert False



# Generated at 2022-06-11 09:42:36.237134
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FieldAttributeBase()
    setattr(attr, 'isa', 'string')
    setattr(attr, 'static', True)
    from _ast import Str

    param_1 = Str(s='foo')
    param_2 = Str(s='bar')
    param_3 = Str(s='baz')
    # expected = 
    assert attr.post_validate(param_1, param_2, param_3) == expected



# Generated at 2022-06-11 09:42:44.520761
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Would call AnsibleParserError on a parse error, but we won't test that here
    parser = PlaybookParser(Playbook.load(None, vault_password='pass'))
    data_block = parser._load_data_from_file('test_data/playbook.yml')
    if data_block is None:
        raise AssertionError('PlaybookParser._load_data_from_file returned None')
    playbooks, ds = Playbook.load_from_file('test_data/playbook.yml', vault_password='pass')
    if playbooks is None:
        raise AssertionError('Playbook.load_from_file returned None')
    if len(playbooks) != 1:
        raise AssertionError('len(playbooks)=%s' % len(playbooks))

# Generated at 2022-06-11 09:42:48.737093
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    attr = FieldAttributeBase()
    try:
        attr._load_data(None)
        assert False, "expected error"
    except Exception as ex:
        assert type(ex) == TypeError


# Generated at 2022-06-11 09:42:52.431489
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    o = FieldAttributeBase()
    o._valid_attrs = { 'foo' : FieldAttribute() }
    o.foo = 'bar'
    assert o.dump_attrs() == { 'foo': 'bar'}

# Generated at 2022-06-11 09:42:54.267515
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    base_obj = FieldAttributeBase()
    assert base_obj.load_data() == None



# Generated at 2022-06-11 09:43:01.351163
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Setup
    object = object()
    object.name = 'a'
    object.attr = 'b'
    object.attr1 = 'c'
    object.__dict__ = {'name': 'a', 'attr': 'b', 'attr1': 'c', 'attr2': object}

    # Test
    attrs = object.dump_attrs()

    # Verify
    assert attrs['name'] == 'a'
    assert attrs['attr'] == 'b'
    assert attrs['attr1'] == 'c'
    assert attrs['attr2'] == object


# Generated at 2022-06-11 09:43:09.119770
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.task import Task
    
    
    
    
    

    task = Task.load(dict(action=dict(module='copy', args=dict(src='/src', dest='/dest'))))

    assert task.serialize() == dict(action=dict(module='copy', args=dict(src='/src', dest='/dest')), uuid=None, finalized=True, squashed=True, _ansible_no_log=False)

    # TODO: How to test this?
    #task._ansible_no_log=True
    #assert task.serialize() == dict(action=dict(module='copy', args=dict(src='/src', dest='/dest')), uuid=None, finalized=True, squashed=True, _ansible_no_log=False)

# Unit

# Generated at 2022-06-11 09:43:10.114515
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    assert (Base().get_dep_chain() == None)


# Generated at 2022-06-11 09:43:12.811800
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    # Invalid call of FieldAttributeBase.validate()
    with pytest.raises(TypeError) as excinfo:
        obj.validate()
    assert 'descriptor \'validate\' of \'object\' object needs an argument' in to_native(excinfo.value)


# Generated at 2022-06-11 09:43:15.920845
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    base_obj = FieldAttributeBase()
    # Test with bare return
    return base_obj.dump_me()



# Generated at 2022-06-11 09:43:52.104463
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # Build Mock Object
    mockObject = FieldAttributeBase()
    field_attribute = FieldAttribute()
    templar = Templar()

    # Test with required attributes
    value = mockObject.get_validated_value('name', 'attribute', 'value', templar)
    assert value == 'value'

    # Test with required and optional attributes
    value = mockObject.get_validated_value('name', 'attribute', 'value', 'templar')
    assert value == 'value'

    # Test with required and all attributes
    value = mockObject.get_validated_value('name', field_attribute, 'value', templar)
    assert value == 'value'

# Generated at 2022-06-11 09:43:56.283512
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    '''
    FieldAttributeBase should return a dict of all subelements.
    '''
    expected = dict(vars=dict(a=1))
    result = FieldAttributeBase(dict(vars=dict(a=1))).squash()
    assert_equal(expected, result)

# Generated at 2022-06-11 09:43:58.419818
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test = MyFieldAttribute(default=None)
    test.post_validate()
    assert test.val == None


# Generated at 2022-06-11 09:43:59.120186
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass

# Generated at 2022-06-11 09:44:09.239551
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    test_obj = FieldAttributeBase()
    # test_data will be a dict of dicts
    test_data = dict()
    test_data['test1'] = dict()
    test_data['test1']['isa'] = 'dict'
    test_data['test1']['type'] = 'dict'
    test_data['test1']['default'] = {}
    test_data['test1']['required'] = False
    test_data['test2'] = dict()
    test_data['test2']['isa'] = 'class'
    test_data['test2']['type'] = 'class'
    test_data['test2']['default'] = {}
    test_data['test2']['required'] = False
    test_data['finalized'] = False

# Generated at 2022-06-11 09:44:17.479231
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    error_patterns = [
        'is a <(type|class) \'dict\'>',
    ]
    try:
        fieldattributebase = FieldAttributeBase()
        fieldattributebase.deserialize(data)
        raise AssertionError('AnsibleAssertionError not raised')
    except AssertionError as e:
        for error_pattern in error_patterns:
            if not re.search(error_pattern, to_native(e)):
                raise AssertionError("Exception message does not match "
                                     "expected pattern:\n%s" %
                                     to_native(e))
    else:
        raise AssertionError('AnsibleAssertionError not raised')


# Generated at 2022-06-11 09:44:29.334206
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    a = AnsibleModuleTest()
    t = AnsibleModuleTest()
    assert a.test_validate_required(t) == 'the field \'test1\' is required but was not set'
    assert a.test_validate_falsy(t) == 'the field \'test2\' is set to False but must be set'
    assert a.test_validate_validated_only(t) == 'the field \'test3\' is required but was not set'
    assert a.test_validate_dont_validate_nonrequired(t) == 'the field \'test4\' is required but was not set'
    assert a.test_validate_default(t) == 'ok'
    assert a.test_validate_default_override(t) == 'ok'

# Generated at 2022-06-11 09:44:33.420884
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    failed = False
    try:
        # Setup test data
        attribute = 'attribute_value'

        # Invoke method
        FieldAttributeBase.validate(attribute)
    except Exception as e:
        failed = True
    assert failed, 'Expected raised exception not encountered'

# Generated at 2022-06-11 09:44:42.708909
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    set_module_args({})
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar

    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    dummy_loader = DictDataLoader({})
    dummy_inventory = Inventory(loader=dummy_loader, variable_manager=VariableManager())
    callback = CallbackModule(display=Display())
    templar = Templar(loader=dummy_loader, variables=variable_manager.get_vars(loader=dummy_loader, play=None), vault_secrets=VaultLib(loader=dummy_loader))
    assert True

# Generated at 2022-06-11 09:44:47.877099
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # fixture
    play = Play()
    attribute_base = FieldAttributeBase(name='test', doc=None, default=None, required=True, isa=dict, inherit=True,
                                        listof=str, default_factory=None, env_var=[], aliases=[], choices=[])

    # test
    result = attribute_base.dump_me(play)

    # assert
    assert result == {'name': 'test', 'required': True, 'doc': None, 'isa': 'dict', 'default': None, 'inherit': True,
                      'listof': 'str', 'aliases': [], 'env_var': [], 'choices': [], 'default_factory': None}



# Generated at 2022-06-11 09:46:00.735473
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-11 09:46:01.895794
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    example = FieldAttributeBase()
    example.validate('example')

# Generated at 2022-06-11 09:46:02.821659
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert True is True


# Generated at 2022-06-11 09:46:04.448239
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    assert b.get_dep_chain() == None