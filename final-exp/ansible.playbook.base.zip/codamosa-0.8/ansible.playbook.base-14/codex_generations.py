

# Generated at 2022-06-11 09:37:00.996628
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.role_name import RoleName
    import collections
    # ################
    # Test case 1: 
    # ################
    # 1.1 create an object with _parent set to None
    # 1.2 get dep_chain
    # 1.3 assert expected chain
    test_obj = Base()
    test_obj._parent = None
    dep_chain = test_obj.get_dep_chain()
    assert dep_chain is None, 'Test 1.1 failed'

    # ################
    # Test case 2: 
    # ################
    # 2.1 create an object

# Generated at 2022-06-11 09:37:04.422956
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fieldattributebase = FieldAttributeBase()
    assert fieldattributebase.from_attrs() is None, 'Expected None but got %s' % fieldattributebase.from_attrs()


# Generated at 2022-06-11 09:37:08.661668
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test_obj = FieldAttributeBase(name='test_attribute', class_type=BaseObject, init=True)
    test_obj.load_data(name='test_attribute', class_type=BaseObject, init=True)


# Generated at 2022-06-11 09:37:10.367355
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_obj = FieldAttributeBase()
    # test that attributes are dumped
    assert test_obj.dump_me() == {}


# Generated at 2022-06-11 09:37:17.937160
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    dct = {
        '_valid_attrs': {},
        '_alias_attrs': {}
    }
    class MyBaseMeta(BaseMeta):
        attr1 = FieldAttribute(isa='dict', default={})
        attr2 = FieldAttribute(isa='list', default=[])

    dct.update({
        '_attributes': {'attr1': Sentinel, 'attr2': Sentinel},
        '_attr_defaults': {'attr1': {}, 'attr2': []},
        'attr1': property(_generic_g, _generic_s, _generic_d),
        'attr2': property(_generic_g, _generic_s, _generic_d)
    })
    class MyBaseMeta2(BaseMeta):
        _valid_attrs = {}
        _alias_attrs = {}

    d

# Generated at 2022-06-11 09:37:19.168163
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    testobj = FieldAttributeBase()
    testobj.dump_me()


# Generated at 2022-06-11 09:37:22.401130
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create a new instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase()

    # Test with no arguments
    field_attribute_base.copy()

    # Test with argument
    field_attribute_base.copy('arg1')


# Generated at 2022-06-11 09:37:29.779442
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # testing an instance method
    prefix = 'FieldAttributeBase.post_validate'
    # method args
    _self, templar = None, None

    # test 1
    name = '{}.1'.format(prefix)
    # try to call method
    try:
        # call method
        FieldAttributeBase._post_validate(_self, templar)
    # compare the result with expected value
    except AnsibleParserError as e:
        assert e.message == ("The field 'name' is required but was not set"), message(name, e.message)
        assert e.obj == (FieldAttributeBase), message(name, e.obj)
        assert e.orig_exc == (None), message(name, e.orig_exc)
    else:
        raise Exception("Expected exception was not raised")

# Generated at 2022-06-11 09:37:37.807666
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field = FieldAttribute()
    obj = DefinedClass()
    obj.attr = field
    obj.attr = '1'
    field.isa = 'int'
    obj.post_validate()
    assert obj.attr == 1
    field.isa = 'bool'
    obj.attr = 'True'
    obj.post_validate()
    assert obj.attr is True
    field.isa = 'string'
    obj.attr = 'True'
    obj.post_validate()
    assert obj.attr == 'True'
    field.isa = 'class'
    field.class_type = FieldAttribute
    obj.attr = 'True'
    try:
        obj.post_validate()
    except TypeError:
        pass
    else:
        assert False
    obj.attr = FieldAttribute()

# Generated at 2022-06-11 09:37:41.901008
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    base._ds = MagicMock()
    base._ds._data_source = 'mock_data_source'
    base._ds._line_number = 'mock_line_number'

    assert base.get_path() == 'mock_data_source:mock_line_number'

# Generated at 2022-06-11 09:38:14.297170
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-11 09:38:18.464637
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    try:
        field_attribute_base.post_validate()
    except SystemExit as e:
        assert e.code == -1

    # check that we get a TypeError if the attribute is not a class of the
    # requested type

# Generated at 2022-06-11 09:38:26.335155
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    t = Task()
    assert t.get_dep_chain() == None
    t1 = Task()
    t2 = Task()
    t3 = Task()
    t1.set_loader(DictDataLoader({}))
    t2.set_loader(DictDataLoader({}))
    t3.set_loader(DictDataLoader({}))
    # dependency chain is [t1, t2, t3]
    t1._parent = t2
    t2._parent = t3
    assert t1.get_dep_chain() == [t1, t2, t3]
    assert t2.get_dep_chain() == [t1, t2, t3]
    assert t3.get_dep_chain() == [t1, t2, t3]
    # dependency chain is [t1

# Generated at 2022-06-11 09:38:37.689777
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    stack1 = []
    task1 = Task()
    task1._role_path = "/test/path"
    task1._parent = None
    task1._play = object
    task2 = Task()
    task2._role_path = "/tmp/path"
    task2._parent = object
    task2._play = object
    task3 = Task()
    task3._role_path = "/tmp/path3"
    task3._parent = object
    task3._play = object
    stack1.append(task1)
    stack1.append(task2)
    stack1.append(task3)
    assert stack1 == task3.get_dep_chain()

# Generated at 2022-06-11 09:38:42.358502
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # NOTE: this is not the real answer, it is just what I get with Python 2.7.13 on Linux.
    #       The point of this unit test is to detect changes in the output, not to verify
    #       the correctness of the output.
    assert FieldAttributeBase.get_validated_value('name', 'attribute', 'value', 'templar') == 'value'


# Generated at 2022-06-11 09:38:44.342733
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    data = dict()
    attribute = FieldAttributeBase()
    result = attribute.validate(data)
    assert result is None

# Generated at 2022-06-11 09:38:49.721089
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    global test_FieldAttributeBase
    if test_FieldAttributeBase is None:
        test_FieldAttributeBase = get_test_object(FieldAttributeBase())
    assert test_FieldAttributeBase.get_ds() == {"_uuid": "d41d8cd98f00b204e9800998ecf8427e", "_finalized": False, "_squashed": False}

# Generated at 2022-06-11 09:39:01.532464
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Foo:
        def __init__(self):
            self.__dict__ = {}
            self.__bases__ = ()
    class Bar:
        def __init__(self):
            self.__dict__ = {}
            self.__bases__ = ()
    class Baz:
        def __init__(self):
            self.__dict__ = {}
            self.__bases__ = ()
    class Test:
        __metaclass__ = BaseMeta
        def __init__(self):
            self.__dict__ = {}
            self.__bases__ = (Bar, Baz)
        a = FieldAttribute(isa='string')
        b = FieldAttribute(isa='string', default="foo", inherit=True)
        _c = FieldAttribute(isa='string')

# Generated at 2022-06-11 09:39:08.682458
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    config = {
        "name": 'foo',
        "description": "my custom attribute",
        "private": False,
        "default": '',
        "required": False,
        "static": False,
        "listof": 'string',
        "isa": 'string',
    }

    field = FieldAttributeBase(**config)

    data = {'foo': 'bar'}

    field.deserialize(data)

    assert hasattr(field, 'foo'), "Deserialize is not properly setting the field attributes"



# Generated at 2022-06-11 09:39:14.257462
# Unit test for method get_path of class Base
def test_Base_get_path():
    data_source = 'hosts'
    line_number = 0
    file_name = 'hosts'
    object_type = 'playbook'
    task_type = 'playbook'
    task_action = ''
    task_args = {}
    module_name = ''
    xtra = {}
    task = Base(data_source, line_number, file_name, object_type, task_type, task_action, task_args, module_name, **xtra)
    assert task.get_path() == 'hosts:0'



# Generated at 2022-06-11 09:39:48.011518
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    def setUpModule():
        pass
    def tearDownModule():
        pass
    def setUp():
        pass
    def tearDown():
        pass
    def test_class_method_get_validated_value_01():
        '''
        Testing method get_validated_value of class FieldAttributeBase
        '''
        print('Testing method get_validated_value of class FieldAttributeBase')
        FieldAttributeBase_obj = FieldAttributeBase()
        name = 'something'
        attribute = 'something'
        value = 'something'
        templar = 'something'
        #self.assertIsInstance(FieldAttributeBase_obj.get_validated_value(name, attribute, value, templar), )
        #self.assertEqual(FieldAttributeBase_obj.get_validated_value(name, attribute, value,

# Generated at 2022-06-11 09:39:49.582676
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    a = FieldAttributeBase()
    b = FieldAttributeBase()


# Generated at 2022-06-11 09:39:51.772197
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    cls, module, config = get_objects()
    obj = cls()
    data = {}
    obj.from_attrs(attrs=data)

# Generated at 2022-06-11 09:40:03.501162
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    
    # initialization of test objects
    # test object FieldAttributeBase
    FieldAttributeBase_obj = FieldAttributeBase()

    # Check of test object FieldAttributeBase
    # check of method 'get_validated_value'
    # initialization of test variables
    FieldAttributeBase_get_validated_value_name = 'name'
    FieldAttributeBase_get_validated_value_attribute = 'attribute'
    FieldAttributeBase_get_validated_value_value = 'value'
    FieldAttributeBase_get_validated_value_templar = 'templar'

    # check the method

# Generated at 2022-06-11 09:40:08.343464
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    try:
        data = dict(a=1,b=dict(c=2))
        test_obj = FieldAttributeBase(**{})
        ret = test_obj.dump_me(data)
    except Exception as e:
        raise AssertionError("Failed to dump_me: %s" % str(e))


# Generated at 2022-06-11 09:40:18.519687
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    #
    # AnsibleMapping.post_validate()
    #
    test_class = type('test_class', (object,), {'_valid_attrs':{'test_field': FieldAttribute(isa='bool', default=False, required=True)}, 'get_ds': lambda self: self})

# Generated at 2022-06-11 09:40:20.944047
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.get_validated_value(1, 1, 1, 1)


# Generated at 2022-06-11 09:40:21.896827
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    return (True, None)

# Generated at 2022-06-11 09:40:29.220882
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test_base = Base()
    test_base._ds = FakeClass()
    test_base._ds._data_source = "./test_data_souce"
    test_base._ds._line_number = 1
    test_base._parent = FakeClass()
    test_base._parent._play = FakeClass()
    test_base._parent._play._ds = FakeClass()
    test_base._parent._play._ds._data_source = "./test_data_souce"
    test_base._parent._play._ds._line_number = 2
    test_base.get_search_path()


# Generated at 2022-06-11 09:40:35.584176
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    fieldattributebase = FieldAttributeBase(
        default='default',
  class_type=None,
  always_post_validate=False,
  required=False,
  attribute=False,
  isa='isa',
  include=None,
  name='name'
    )
    data = dict(
        foo='bar',
        baz=1
    )
    fieldattributebase.deserialize(data)
    assert fieldattributebase.baz == 1
    assert fieldattributebase.foo == 'bar'

# Generated at 2022-06-11 09:41:04.018225
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fixture = _FieldAttributeBase()

    assert fixture.__class__ is _FieldAttributeBase
    assert fixture._finalized is False
    assert fixture._squashed is False
    assert fixture.argument_spec == dict()



# Generated at 2022-06-11 09:41:10.670924
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # TEST CASE: The method get_search_path succeed when it is called for a Base object
    from ansible.playbook.base import Base
    base = Base()
    base.get_search_path()

    # TEST CASE: The method get_search_path raise an exception when it is called for an object that is not a Base object
    base = object()
    try:
        base.get_search_path()
        # Should not happen
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-11 09:41:19.530235
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import sys
    import test.support
    import test.support.__main__
    from test.support.script_helper import assert_python_ok
    from test import test_base

    try:
        # Create a temporary file for python test
        test_file = test.support.TESTFN
        with open(test_file, "w") as fp:
            fp.write("import test_base\n")
            fp.write("test_base.test_Base_get_search_path()")

        # Run the temporary file
        assert_python_ok('-m', test_file)

    finally:
        # Remove the temporary file
        os.remove(test_file)



# Generated at 2022-06-11 09:41:29.312312
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test if get_dep_chain() returns the correct dependency chain
    # Tasks are ordered by their dependency chain
    tasks = [Base(), Base(), Base(), Base(), Base(), Base()]
    tasks[0]._parent = tasks[2]
    tasks[1]._parent = tasks[2]
    tasks[2]._parent = tasks[3]
    tasks[3]._parent = tasks[5]
    tasks[4]._parent = tasks[5]
    for i in range(5):
        assert tasks[i].get_dep_chain() == tasks[i+1:], "get_dep_chain() returns wrong dependency chain"
    assert tasks[5].get_dep_chain() == None, "get_dep_chain() returns wrong dependency chain"


# Generated at 2022-06-11 09:41:35.637195
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # given
    attribute = mock.MagicMock()
    instance = mock.MagicMock()
    cls = FieldAttributeBase()
    # when
    cls.validate(instance, attribute, 'test_value')
    # then
    instance.get_validated_value.assert_called_once_with('name', attribute, 'test_value', None)


# Generated at 2022-06-11 09:41:47.300658
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from collections import namedtuple
    import os.path
    Result = namedtuple('Result', ['result_path', 'expected_path', 'result_msg'])
    Base.unfiltered_data_structures = []
    os.path.exists = lambda path: True
    os.path.isdir = lambda path: True

    # tests for Base.get_search_path()

    # case: base with path and no parent
    test_case = Base()
    test_case._ds = dict(
        _data_source = 'a',
        _line_number = 1,
    )
    assert test_case.get_search_path() == [os.path.dirname(test_case.get_path())]

    # case: base with role_path and no parent
    test_case = Base()
    test_

# Generated at 2022-06-11 09:41:54.661955
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    yaml_data = '''
{foo: bar}
'''

    attrs = dict()
    attrs['foo'] = 'bar'
    f = FieldAttributeBase(allow_duplicates=False, always_post_validate=False, attribute=None, cli_name=None, cli_type=None, cli_metavar=None,
                           choices=None, default=None, env_name=None, isa=None, include=None, required_if=None, required_one_of=None,
                           required_together=None, type=None, version_added=None, version_removed=None, aliases=None)
    f.from_data(yaml_data)
    assert f.dump_attrs() == attrs

# Generated at 2022-06-11 09:42:00.912659
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    global FieldAttributeBase
    f = FieldAttributeBase()
    global field_attribute
    field_attribute_value = mock_ansible_module.params.get('field_attribute')
    f.field_attribute = field_attribute_value
    global itervalues
    itervalues_value = mock_ansible_module.params.get('itervalues')
    f.itervalues = itervalues_value

# Generated at 2022-06-11 09:42:12.807065
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    import __main__
    import os
    import sys
    import types
    try:
        import ansible.playbook.play
        import ansible.playbook.task
        import ansible.playbook.block
    except ImportError:
        #Skip this test if ansible is not available
        return

    #Create a mock play
    play_data = dict(
        hostvars=dict()
    )
    play = ansible.playbook.play.Play().load(play_data, variable_manager=ansible.playbook.play.variable_manager.VariableManager(), loader=ansible.parsing.dataloader.DataLoader())

    #Create a mock task

# Generated at 2022-06-11 09:42:16.254957
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    cls = FieldAttributeBase()
    value = 'test'
    attr = cls.validate(value)
    assert attr == value, ("FieldAttributeBase.validate('%s') == '%s' but "
                           "'%s' was expected") % (value, attr, value)


# Generated at 2022-06-11 09:43:14.514289
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    # Test with no parameters
    rep = FieldAttributeBase()
    assert rep.squash == False

    # Test with invalid parameter types
    with pytest.raises(AssertionError):
        rep = FieldAttributeBase(squash="Hello World")

    # Test valid values
    rep = FieldAttributeBase(squash=False)
    assert rep.squash == False
    rep = FieldAttributeBase(squash=True)
    assert rep.squash == True


# Generated at 2022-06-11 09:43:15.647225
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    FieldAttributeBase.dump_me()



# Generated at 2022-06-11 09:43:17.328875
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    assert not False, "Ansible failed to provide an implementation"

# Generated at 2022-06-11 09:43:19.309605
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fieldattributebase = FieldAttributeBase()
    fieldattributebase.post_validate()


# Generated at 2022-06-11 09:43:27.784968
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Initializing test_obj which is of class FieldAttributeBase
    test_obj = FieldAttributeBase(class_name="Task", spec={})
    # Initializing name which is of type string
    name = "name"
    # Initializing attribute which is of type dict
    attribute = { "isa" : "int", "required" : True }
    # Initializing value which is of type string
    value = "value"
    # Initializing templar which is of type object
    templar = object()
    # Calling get_validated_value of class FieldAttributeBase
    test_obj.get_validated_value(name=name, attribute=attribute, value=value, templar=templar)

# Generated at 2022-06-11 09:43:29.178948
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    FieldAttributeBase.deserialize(Data())


# Generated at 2022-06-11 09:43:36.921788
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    key = 'key_1562997674905'
    value = 'value_1562997674906'

    # Pass
    data = dict()
    data[key] = value
    ret = FieldAttributeBase.get_ds(data)
    assert ret == value

    # Non-existent option, key does not exist
    data = dict()
    key = 'key_1562997674907'
    ret = FieldAttributeBase.get_ds(data)
    assert ret == None

    # Non-existent option, value is None
    data = dict()
    data[key] = None
    ret = FieldAttributeBase.get_ds(data)
    assert ret == None

# Generated at 2022-06-11 09:43:45.146638
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # setup
    playbook = Playbook()
    play = Play()
    playbook._entries = [play]
    task_block = TaskBlock()
    play._task_blocks = [task_block]
    task = Task()
    task_block._block = [task]

    # test when dep_chain is None
    result = task.get_search_path()
    assert result == []

    # test when dep_chain is not none
    dep_chain = [Role(), Role()]
    task._parent = task_block
    task_block._parent = play
    play._dep_chain = dep_chain

    result = task.get_search_path()
    assert result == [reversed(dep_chain)]



# Generated at 2022-06-11 09:43:54.060188
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Import module and class to test
    import ansible.parsing.mod_args
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # Set up object and test variables
    obj = AnsibleBaseYAMLObject()
    obj.deserialize({'foo': 'bar'})
    deserialize = obj.deserialize
    obj._squashed = 'a string'
    obj._uuid = 'a string'
    obj._finalized = 'a string'
    # Call the method and check for expected results
    assert isinstance(deserialize({'foo': 'bar'}), dict)
    assert obj.foo == 'bar'
    # Add some test code here 
    #
    # Call the method a second time, with different values for the test
    # variables. This is

# Generated at 2022-06-11 09:43:58.845521
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    def obase_dump_attrs(self):
        return dict(a=1, b=2)

    FieldAttributeBase._dump_attrs = obase_dump_attrs
    res = FieldAttributeBase().dump_attrs()
    exp = dict(a=1, b=2)
    assert res == exp

# Generated at 2022-06-11 09:45:50.955773
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    data = {
        'valid_attrs': {}
    }
    instance = FieldAttributeBase(**data)

    # set up the mocks
    with patch.object(AnsibleModule, 'fail_json') as mock_fail_json:
        # call the method
        instance.validate()

        # now check the results
        assert not mock_fail_json.called, \
            'AnsibleModule.fail_json() should not have been called'

# Generated at 2022-06-11 09:45:55.416278
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    ''' 
    Test if the dep_chain attribute of a Base object is returned correctly
    '''
    # create a Base object
    obj=Base()
    print('obj:',obj)
    print(type(obj))
    print('path:',obj.get_path())
    #assert obj.get_dep_chain() == None
    

# Generated at 2022-06-11 09:45:56.990816
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # TODO: Implement test
    assert False, "Unimplemented test"

# Generated at 2022-06-11 09:45:59.033714
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    value = FieldAttributeBase(name='foo')
    value.post_validate( templar=templar )


# Generated at 2022-06-11 09:46:07.523087
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # test with a playbook
    b = Base()
    b._dep_chain = ['/path/to/roles/1', '/path/to/roles/2', '/path/to/playbook']
    b._parent = None
    assert b.get_search_path() == ['/path/to/roles/1',
                                    '/path/to/roles/2',
                                    '/path/to/playbook']

    # test with role's task
    b = Base()
    b._parent = Base()
    b._parent._role_path = '/path/to/roles/1'
    b._parent._dep_chain = ['/path/to/roles/2']
    b._parent._parent = Base()
    b._parent._parent._role_path = '/path/to/roles/2'
