

# Generated at 2022-06-11 09:36:58.588068
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fmt = 'json'
    b_cls = 'meta'
    obj = FieldAttributeBase()
    result = obj.dump_me(fmt, b_cls)
    assert result == dict(
        fmt='json', b_cls='meta'
    )


# Generated at 2022-06-11 09:37:09.838374
# Unit test for method __new__ of class BaseMeta

# Generated at 2022-06-11 09:37:17.129080
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for the function load_data
    '''

    # Return value specifiers
    # dict: A dictionary of attribute value pairs to return

# Generated at 2022-06-11 09:37:25.445266
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    play = Play()
    block = Block()
    block1 = Block()
    include = IncludeRole()
    task = Task()

    block.vars = {'role_path': 'role_path1'}
    block.parent = play
    include.block = block
    include.dep_chain = [block, block1]

    task.block = block1
    task.task_include = include
    task.ds = {'data_source': 'data_source', 'line_number': 'line_number'}

    print(task.get_search_path())

# Generated at 2022-06-11 09:37:28.815624
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    a = Base()
    b = Base()
    c = Base()
    a._parent = b
    b._parent = c
    x = a.get_dep_chain()
    assert x[0] is c
    assert x[1] is b
    assert x[2] is a
    assert len(x) == 3

# Generated at 2022-06-11 09:37:31.871599
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.attribute import FieldAttributeBase

    BaseObj = FieldAttributeBase()
    BaseObj.testattr = 'test'

    assert BaseObj.dump_attrs() == {'testattr': 'test'}

# Generated at 2022-06-11 09:37:32.952276
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    assert FieldAttributeBase().get_validated_value == 'This method is up to the inheriting classes'

# Generated at 2022-06-11 09:37:34.669002
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''Unit test for copy'''
    fieldattribute = FieldAttributeBase('test', 'test', 'test')
    fieldattribute.copy()
    pass

# Generated at 2022-06-11 09:37:36.413639
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    assert isinstance(obj.dump_me(), dict) # TODO: test assert


# Generated at 2022-06-11 09:37:37.920426
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase(None)
    raise NotImplementedError("Test not written for FieldAttributeBase.dump_attrs")



# Generated at 2022-06-11 09:38:08.481789
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    task_vars = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()

    # Create an instance of FieldAttributeBase and test get_validated_value
    m = FieldAttributeBase(name='name', private=True, default=False, always_post_validate=False, isa=None, validate=None, compile_type=None, confine_value=None)
    with pytest.raises(TypeError):
        m.get_validated_value(name=None, attribute=None, value=None, templar=None)


# Generated at 2022-06-11 09:38:18.995864
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class TestPlay(object):
        def __init__(self, variable_manager=None, loader=None):
            self.vars = dict()
            self.variable_manager = variable_manager
            self.loader = loader
            self.id = 1234

    def test_post_validate(obj, templar):
        return templar.template(obj)

    field = FieldAttributeBase(post_validate=test_post_validate)

    # test the post validator when no value is used
    play = TestPlay()
    field.post_validate(play, '', 'name')

    # test the post validator when a default value is used
    field = FieldAttributeBase(default='foo', post_validate=test_post_validate)
    field.post_validate(play, '', 'name')



# Generated at 2022-06-11 09:38:25.588211
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch
    from ansible.errors import AnsibleAssertionError
    from ansible.parsing.yaml.objects import FieldAttributeBase

    data = {}
    obj = FieldAttributeBase()
    with patch.object(FieldAttributeBase, '__init__', lambda x, y: None):
        pass
    with patch.object(obj, "_valid_attrs", mock.MagicMock()):
        with pytest.raises(AnsibleAssertionError):
            obj.deserialize(data)
    pass


# Generated at 2022-06-11 09:38:26.719475
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    FieldAttributeBase = FieldAttributeBase()


# Generated at 2022-06-11 09:38:37.214158
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    obj._valid_isa = (string_types, int)
    obj.isa = 'str'
    assert obj.validate(5) == 5
    assert obj.validate(5.5) == 5.5
    assert obj.validate('5') == '5'
    pytest.raises(TypeError, obj.validate, [])
    pytest.raises(TypeError, obj.validate, None)
    pytest.raises(TypeError, obj.validate, {})
    pytest.raises(TypeError, obj.validate, ())

# Generated at 2022-06-11 09:38:45.753723
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class BaseTest(object):
        __metaclass__ = BaseMeta
    class ParentTest(BaseTest):
        _attribute1 = FieldAttribute(isa='str')
        _attribute2 = FieldAttribute(isa='str', default='default_value')
    class ChildTest(ParentTest):
        _attribute3 = FieldAttribute(isa='str', inherit=True)
        _attribute4 = FieldAttribute(isa='str', inherit=False, default='default_value')
        def _get_attr_attribute3(self):
            return self._attribute3

    parent_test = ParentTest()
    assert parent_test.attribute1 == None
    assert parent_test.attribute2 == 'default_value'

# Generated at 2022-06-11 09:38:57.719034
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    global FAKE_HOSTVAR_RESULT

    my_task = Task()

# Generated at 2022-06-11 09:39:08.377294
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit test for method FieldAttributeBase.post_validate of class FieldAttributeBase
    '''
    from units.mock.loader import DictDataLoader
    from units.compat.mock import patch

    valid_attrs = FieldAttributeBase._valid_attrs
    field_attribute = FieldAttributeBase()
    data_loader_mock = DictDataLoader({})
    template_dir_mock = os.path.join(os.path.dirname(__file__), 'templates')
    variable_manager_mock = VariableManager(loader=data_loader_mock, variables={'hostvars':{}})

# Generated at 2022-06-11 09:39:12.599542
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    data = dict(
        name="mytest",
        default=None,
        required=True
    )

    field_attribute_base = FieldAttributeBase(**data)
    result = field_attribute_base.copy()

    assert result.name == "mytest"
    assert result.default is None
    assert result.static == True
    assert result.required == True

# Generated at 2022-06-11 09:39:22.954448
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    BaseObj = collections.namedtuple('BaseObj', 'UUID name template')
    var = 'name'
    baseobj = BaseObj(UUID = None, name = 'myobj', template = BaseObj(UUID = None, name = None, template = None))
    ansible = collections.namedtuple('ansible', 'inventory')
    inventory = collections.namedtuple('inventory', 'host_vars')
    host_vars = collections.namedtuple('host_vars', 'get')
    ansible.inventory = inventory(host_vars = host_vars(get = lambda a: None))
    templar = collections.namedtuple('templar', 'avail_vars is_template _fail_on_undefined_errors template')

# Generated at 2022-06-11 09:39:57.356686
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from six import PY3
    from nose.plugins.skip import SkipTest

    # suppress deprecation warnings from internal usage of the deprecated
    # field attribute classes
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        o = FieldAttributeBase()

    obj = o()
    if PY3:
        raise SkipTest('unittest not implemented in python3')
    else:
        with assert_raises(NotImplementedError) as cm:
            obj.squash()
        eq_(str(cm.exception), 'squash() must be implemented by a subclass')



# Generated at 2022-06-11 09:40:08.701234
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    def test_from_attrs_from(from_attrs):
        r = from_attrs
        return True
    def test_from_attrs_from_other():
        r = from_attrs
        return True
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs
    assert from_attrs == from_attrs


# Generated at 2022-06-11 09:40:11.670953
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.yaml.objects import AnsibleMapping
    obj = FieldAttributeBase()
    data = AnsibleMapping()
    assert obj.deserialize(data) is None


# Generated at 2022-06-11 09:40:21.719007
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    _FA = FieldAttributeBase()
    # Replace the stubs
    _FA.name = 'name'
    _FA.attribute = 'attribute'
    _FA.required = 'required'
    _FA.default = 'default'
    _FA.aliases = 'aliases'
    _FA.always_post_validate = 'always_post_validate'
    _FA.reject = 'reject'
    _FA.choices = 'choices'
    _FA.class_type = 'class_type'
    _FA.static = 'static'
    _FA.isidentifier = 'isidentifier'
    
    # Test the return type

# Generated at 2022-06-11 09:40:31.128379
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable

    mocker.patch('ansible.playbook.play.Handler.post_validate')

    field_attribute_base = FieldAttributeBase()

    ds = {'name': 'localhost', 'value': 'custom', 'key': 10}

    mock_templar = mocker.Mock(spec=Templar)
    mock_templar.available_variables = {'omit': 'whatever'}

    mock_ansible_undefined_variable = mocker.Mock(spec=AnsibleUndefinedVariable)
    mock_ansible_unsafe_text = mocker.Mock(spec=AnsibleUnsafeText)

    type_value = 'string'
    value = 10
   

# Generated at 2022-06-11 09:40:40.506647
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attribute = FieldAttributeBase()
    value = 'foo'
    assert attribute.validate(value)
    value = 3
    with pytest.raises(AnsibleParserError):
        attribute.validate(value)
        assert False
    attribute.isa = 'int'
    assert attribute.validate(value)
    attribute.isa = 'string'
    assert attribute.validate(value)
    with pytest.raises(AnsibleParserError):
        attribute.isa = 'dict'
        attribute.validate(value)
        assert False
    attribute.isa = 'bool'
    assert attribute.validate(value)
    attribute.isa = 'float'
    assert attribute.validate(value)
    attribute.isa = 'list'
    value = [3]
    assert attribute.validate(value)
    value

# Generated at 2022-06-11 09:40:50.813658
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args='')),
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    play.post_validate(templar=variable_manager.get_vars())

# Generated at 2022-06-11 09:40:53.063137
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create an instance of FieldAttributeBase
    # This instance is not used in this test.
    g = FieldAttributeBase()
    

# Generated at 2022-06-11 09:41:04.018230
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    x = FieldAttributeBase()
    x._validated = True
    x._finalized = True

    a = wrap_var(3)
    b = wrap_var(0)
    c = wrap_var(0)
    d = wrap_var(0)
    e = wrap_var(0)
    f = wrap_var(0)
    g = wrap_var([])
    h = wrap_var([])
    i = wrap_var([])
    j = wrap_var([])

    assert(x.get_validated_value('a', x, a, templar=None) == 3)

# Generated at 2022-06-11 09:41:10.772932
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    p = Play()
    o = Play.load(dict(name='test', hosts={'all': {}}))
    my_var = dict(foo='bar')
    p.vars = my_var
    o.post_validate(MockTemplar(dict(foo='bar')))
    o.vars = my_var
    o.post_validate(MockTemplar(dict(foo='bar')))
    assert o.vars == my_var


# Generated at 2022-06-11 09:41:43.197171
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class_name = 'FieldAttributeBase'
    base_class_name = 'field_attribute'
    class_meta = {}
    params = {'required': False, 'default': None, 'static': False, 'serialize_when_none': True, 'always_post_validate': False, 'extras': ['test']}
    module = AnsibleModule(argument_spec={})
    module.params = params
    field_attribute = FieldAttributeBase(**params)
    field_attribute.module = module
    field_attribute.class_name = class_name
    field_attribute.name = base_class_name
    field_attribute.class_meta = class_meta
    assert field_attribute is not None


# Generated at 2022-06-11 09:41:44.399730
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass



# Generated at 2022-06-11 09:41:50.994197
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()

    f = StringAttribute(required=True)
    f.post_validate()
    assert f.required

    f = StringAttribute(required=False)
    f.post_validate()
    assert not f.required

    f = StringAttribute(required=True)
    f.default = 'test'
    f.post_validate()
    assert not f.required

    f = StringAttribute(required=True, default='test')
    f.post_validate()
    assert not f.required

    f = StringAttribute()
    f.post_validate()
    assert f.required

    f = Attribute()
    f.post_validate()
    assert f.required


# Generated at 2022-06-11 09:41:53.381158
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # FIXME: write real tests
    field_attribute_base_test_instance = FieldAttributeBase()
    assert field_attribute_base_test_instance.dump_attrs() is None


# Generated at 2022-06-11 09:41:56.896419
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    attribute = mock.MagicMock()
    ds = mock.MagicMock()
    templar = mock.MagicMock()
    obj.post_validate(templar=templar)



# Generated at 2022-06-11 09:42:09.177238
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    test1 = FieldAttributeBaseDef(name='test1', default=None, isa='str')
    assert FieldAttributeBase.dump_attrs({'test1': 'a'}, test1) == 'a'
    assert FieldAttributeBase.dump_attrs(None, test1) is None
    assert FieldAttributeBase.dump_attrs(5, test1) == '5'

    test2 = FieldAttributeBaseDef(name='test2', default=None, isa='int')
    assert FieldAttributeBase.dump_attrs({'test2': 5}, test2) == 5
    assert FieldAttributeBase.dump_attrs({'test2': 5.0}, test2) == 5
    assert FieldAttributeBase.dump_attrs(None, test2) is None

# Generated at 2022-06-11 09:42:10.289241
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert False # No test defined

# Generated at 2022-06-11 09:42:18.279384
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from collections import Mapping, MutableMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    f = FieldAttributeBase()
    obj_templar = MagicMock()
    obj_templar.is_template.return_value = False
    name = 'foo'
    value = 1
    attribute = MagicMock()

    #Test string
    attribute.isa = 'string'
    attribute.listof = None
    attribute.required = None
    attribute.always_post_validate = None
    attribute.class_type = None
    assert f.get_validated_value(name, attribute, value, obj_templar) == b'1'

    #Test int
    attribute.isa = 'int'
   

# Generated at 2022-06-11 09:42:20.655370
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.copy()

# Generated at 2022-06-11 09:42:25.861122
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base = FieldAttributeBase()
    parameter_list = [
        [[], {'name' : 'testname', 'attribute' : 'testattribute', 'value' : 'testvalue'}, 'testtemplar']
    ]

    for parameters in parameter_list:
        assert base.get_validated_value(*parameters[:-1]) == parameters[-1]


# Generated at 2022-06-11 09:42:52.628483
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    BaseObject = FieldAttributeBase
    attribute = FieldAttributeBase()
    obj = BaseObject()
    attr = ''
    ds = ''
    assert obj.load_data(attribute, attr, ds) is None


# Generated at 2022-06-11 09:42:55.406279
# Unit test for method get_path of class Base
def test_Base_get_path():
    a = Base()
    a._ds._data_source = 'b'
    a._ds._line_number = 1
    assert a.get_path() == 'b:1'



# Generated at 2022-06-11 09:42:56.072727
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-11 09:42:58.911620
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for FieldAttributeBase.dump_me
    '''
    obj = FieldAttributeBase()
    result = obj.dump_me()
    assert result == {}


# Generated at 2022-06-11 09:42:59.892112
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FieldAttributeBase()



# Generated at 2022-06-11 09:43:02.726980
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    attr = FieldAttribute()
    data = 'test_value'
    obj = FieldAttributeBase()
    attr.deserialize(data)
    assert attr == 'test_value'


# Generated at 2022-06-11 09:43:07.236825
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test = FieldAttributeBase()
    target = object()
    attrs = {'_valid_attrs': target}
    test.from_attrs(attrs)
    assert test._valid_attrs == target
# unit tests for class FieldAttributeBase

# unit tests for class FieldAttribute

# unit tests for class TaskAttribute

# unit tests for class BlockAttribute

# unit tests for class PlayAttribute

# unit tests for class DataAttribute


# Generated at 2022-06-11 09:43:13.553790
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    _loader = MagicMock()
    _validated = False
    _finalized = False
    _vars = {'var1': 'value1'}
    _variable_manager = MagicMock()
    _loader.get_variable_manager.return_value = _variable_manager


# Generated at 2022-06-11 09:43:16.915251
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    task = Task()
    field_attribute_base = FieldAttributeBase(task)
    field_attribute_base_object = field_attribute_base.copy()
    assert field_attribute_base_object



# Generated at 2022-06-11 09:43:18.471845
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    """
    Base.get_search_path()
    """
    pass


# Generated at 2022-06-11 09:43:46.027831
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase()
    assert obj.squash is False


# Generated at 2022-06-11 09:43:48.774559
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    my_fieldattrib = FieldAttributeBase('foo', default='bar', private=True)
    my_validate = my_fieldattrib.validate
    return my_validate


# Generated at 2022-06-11 09:43:49.767291
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()



# Generated at 2022-06-11 09:43:51.751560
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    expected = 10
    fixture = FieldAttributeBase(default=expected)
    actual = fixture.validate(expected)
    assert actual == expected


# Generated at 2022-06-11 09:44:01.090248
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    FA = FieldAttributeBase(name='some_attr', default=None, always_post_validate=False)
    assert FA.name == 'some_attr'
    assert FA.default == None
    assert FA.required == False
    assert FA.static == False
    assert FA.always_post_validate == False

    FA.name = 'some_other_attr'
    assert FA.name == 'some_other_attr'
    FA.default = 'some_default'
    assert FA.default == 'some_default'
    FA.required = True
    assert FA.required == True
    FA.static = True
    assert FA.static == True
    FA.always_post_validate = True
    assert FA.always_post_validate == True


# Generated at 2022-06-11 09:44:11.381200
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # from ansible.vars.manager import VariableManager
    # from ansible.parsing.dataloader import DataLoader
    # from ansible.vars.unsafe_proxy import wrap_var
    # loader = DataLoader()
    # variable_manager = VariableManager()
    # temp_vars = variable_manager.get_vars(loader=loader, play=dict(name='test-play'))
    # variable_manager._extravars = wrap_var(temp_vars)
    variable_manager = dict(
        _extravars=dict(
            test_var_1='test'
        )
    )
    templar = dict(
        available_variables=dict(
            omit = None
        )
    )

# Generated at 2022-06-11 09:44:13.466223
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert isinstance(FieldAttributeBase().get_ds(), dict)


# Generated at 2022-06-11 09:44:15.025374
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fieldattributebase = FieldAttributeBase()
    fieldattributebase.post_validate()

# Generated at 2022-06-11 09:44:26.213531
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    obj._valid_attrs = {'a': obj}
    obj._variable_manager = 'b'
    obj._loader = 'c'
    obj.post_validate = lambda *args, **kwargs: 0
    obj.__class__.__name__ = 'd'
    obj.name = 'e'
    obj.default = 'f'
    obj.isa = 'g'
    obj.required = 'h'
    obj.always_post_validate = 'i'
    obj.static = 'j'
    obj.priorities = ['k']

    # Make sure the post_validate call is not called
    result = obj.dump_me()

# Generated at 2022-06-11 09:44:27.766876
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    fa = FieldAttributeBase()
    assert fa.validate(1)


# Generated at 2022-06-11 09:45:17.117006
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase()
    r = repr(f)
    assert r == '<FieldAttributeBase>'

# Generated at 2022-06-11 09:45:26.504702
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    try:
        obj_base_0 = FieldAttributeBase()
        obj_base_1 = FieldAttributeBase()
        obj_base_2 = FieldAttributeBase()
        obj_base_3 = FieldAttributeBase()
        obj_base_4 = FieldAttributeBase()
        obj_base_5 = FieldAttributeBase()
        obj_base_6 = FieldAttributeBase()
        obj_base_7 = FieldAttributeBase()
        obj_base_8 = FieldAttributeBase()
        obj_base_9 = FieldAttributeBase()
        obj_base_10 = FieldAttributeBase()
        obj_base_11 = FieldAttributeBase()

        # Tests for method dump_attrs
        attrs = dict()
        print(attrs)

    except Exception:
        raise

# Generated at 2022-06-11 09:45:27.649765
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fa1 = FieldAttributeBase()



# Generated at 2022-06-11 09:45:36.541823
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class DummyRole(Base):
        def __init__(self, role_path=None):
            self._role_path = role_path
    class DummyPlay(Base):
        _parent = DummyRole(role_path='/tmp/1')
        _ds = Base._ds
    class DummyTask(Base):
        _parent = DummyPlay()
        _ds = Base._ds
    path_stack = DummyTask().get_search_path()
    assert '/tmp/1' == path_stack[0]

    class DummyPlay2(Base):
        _parent = DummyRole(role_path='/tmp/1')
        _ds = Base._ds
    path_stack2 = DummyTask().get_search_path()
    assert '/tmp/1' == path_stack2[0]


# Generated at 2022-06-11 09:45:39.590039
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Input is an instance object
    myinstance = FieldAttributeBase()
    attr = 'test'
    # Check type of returned value
    assert isinstance(myinstance.dump_me(attr), bool)

# Generated at 2022-06-11 09:45:44.477246
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fixture_loader = FixtureLoader()
    validator = Validator()
    templar = Templar(loader=fixture_loader, variables={'foo':'bar'}, fail_on_undefined=True)
    field = FieldAttributeBase(name='test', validate_method=validator)
    obj = ValueData(test=None)
    field.post_validate(obj, templar)

# Generated at 2022-06-11 09:45:46.653237
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    o = FieldAttributeBase()
    assert o.dump_me() == {}



# Generated at 2022-06-11 09:45:49.631440
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    testobj = FieldAttributeBase()
    output = testobj.copy()
    assert type(output) == FieldAttributeBase


# Generated at 2022-06-11 09:45:52.029897
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.task import Task

    task = Task()
    task.post_validate()
    assert task._finalized == True


# Generated at 2022-06-11 09:45:53.095877
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    assert True

