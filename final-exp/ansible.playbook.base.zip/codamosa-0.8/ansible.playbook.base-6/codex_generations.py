

# Generated at 2022-06-11 09:36:35.948936
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-11 09:36:38.561070
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    base._ds = None
    assert base.get_path() == ''

# unit test for method get_search_path of class Base

# Generated at 2022-06-11 09:36:50.815578
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test basic dump_attrs
    ds = AnsibleLoader(None, None).load('''
    tasks:
      - name: test task
        shell: /bin/true
    ''')[0]

    f = ds.get_task_list()[0]
    assert f.name == 'test task'
    #assert f.actions == [{'__ansible_action__': 'shell', '__ansible_arguments__': 'echo "hello"'}]
    assert not f.async_val
    assert not f.async_seconds
    assert f.changed_when == 'False'
    assert f.failed_when == 'False'
    assert f.poll == 0
    assert f.register == None
    assert f.ret

# Generated at 2022-06-11 09:36:58.036407
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field = FieldAttributeBase(required=True, default=None)
    attr = field.deserialize({'name': 'stephen', 'age': 22})
    assert attr.name == 'stephen'
    attr = field.deserialize({'name': 'flynn'})
    assert attr.name == 'flynn'
    attr = field.deserialize({})
    assert attr.name is None



# Generated at 2022-06-11 09:37:04.097096
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class MockParent(object):
        def __init__(self):
            self._play = 1
            self._role_name = 2
    class MockSelf(object):
        def __init__(self):
            self._parent = None
    base = Base()
    parent1 = MockParent()
    parent2 = MockParent()
    self1 = MockSelf()
    self1._parent = parent1
    self2 = MockSelf()
    self2._parent = parent2
    parent1._parent = self1
    parent2._parent = self2
    parent3 = MockParent()
    parent3._parent = parent1

    base._parent = parent3
    assert base.get_dep_chain() == [parent3, parent1, self1]


# Generated at 2022-06-11 09:37:12.074664
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # This test is for class FieldAttributeBase, but since it is not
    # exposed to the outside world it must be tested here.
    # NOTE: This test is trivial. Ideally it should be expanded when the
    # test coverage of the class is increased.
    class BaseTask(FieldAttributeBase):
        pass

    base_task = BaseTask()
    base_task.vars = dict(one=1, two=2,)

    dumped = base_task.dump_me()
    assert dumped['vars']['one'] == 1
    assert dumped['vars']['two'] == 2


# Generated at 2022-06-11 09:37:12.965982
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    assert True


# Generated at 2022-06-11 09:37:18.964721
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    global display
    display = Display()
    class Base():
        def __init__(self):
            self._attributes = {}
            self._valid_attrs = {}
            self._attr_defaults = {}
            self._alias_attrs = {}
    # Construct attributes
    cls = BaseMeta('name', Base, {})
    assert cls.__name__ == 'name'
    assert cls._attributes == {}
    assert cls._valid_attrs == {}
    assert cls._attr_defaults == {}
    assert cls._alias_attrs == {}

test_BaseMeta___new__()


# Generated at 2022-06-11 09:37:23.178365
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # sample base object
    base_object = FieldAttributeBase()
    base_object._valid_attrs = {
        "attr1": "value1",
        "attr2": "value2"
    }
    # call the method
    output = base_object.dump_attrs()
    # assert the result
    assert isinstance(output, dict)


# Generated at 2022-06-11 09:37:25.052012
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    host = FakeContainer()
    host.name = 'test1'
    result = host.dump_me()
    assert result is not None



# Generated at 2022-06-11 09:38:13.434732
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a "normal" class

    class TestFieldAttributeBase(FieldAttributeBase):

        def __init__(self, parent, attrname):
            FieldAttributeBase.__init__(self, parent, attrname)

    test_obj = TestFieldAttributeBase('parent', 'attrname')

    assert test_obj.validate(TestFieldAttributeBase, 'attrname') is None
    assert test_obj.validate('parent', 'attrname') is None

    # Test with a class that overrides __eq__

    class TestEqFieldAttributeBase(FieldAttributeBase):

        def __init__(self, parent, attrname):
            FieldAttributeBase.__init__(self, parent, attrname)

        def __eq__(self, other):
            return True

        def __ne__(self, other):
            return

# Generated at 2022-06-11 09:38:18.845928
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    u = FieldAttributeBase()
    c = FieldAttributeBase()
    c.choices = {'a', 'b', 'c'}
    u.choices = None
    assert u.validate('a') == True
    assert u.validate('d') == True
    assert c.validate('a') == True
    assert c.validate('d') == False


# Generated at 2022-06-11 09:38:20.818436
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.validate()

# Generated at 2022-06-11 09:38:32.122834
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansiblelint.rules import RulesCollection
    from ansiblelint.rules.FileModeShouldBeUpperCase import FileModeShouldBeUpperCase
    from ansiblelint.runner import Runner
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(
                name = 'debug',
                debug= 'var=test_variable'
            )
        ]
    )

    runner = Runner(RulesCollection(), play_source, play_source, [], [], [])
    rule = FileModeShouldBeUpperCase()
    testob = rule.dump_attrs(runner)
    assert "name" in testob
    assert "names" not in testob
    assert "hosts" in testob

# Generated at 2022-06-11 09:38:38.645251
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    task = Mock()
    task.name = 'test'
    task.args = dict(a=1, b=2)
    task.vars = dict()
    task.post_validate(Mock())
    assert task.name == 'test'
    assert task.args == dict(a=1, b=2)
    assert task.vars == dict()



# Generated at 2022-06-11 09:38:46.534834
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # explicitely call FieldAttributeBase because of the way the class hierarchy works in the class
    a = FieldAttributeBase()

    assert a.get_validated_value('name', FieldAttributeBase(isa='string'), 'string_value', None) == 'string_value'
    assert a.get_validated_value('name', FieldAttributeBase(isa='int'), '42', None) == 42
    assert a.get_validated_value('name', FieldAttributeBase(isa='float'), '42.0', None) == 42.0
    assert a.get_validated_value('name', FieldAttributeBase(isa='bool'), 'true', None) == True
    assert a.get_validated_value('name', FieldAttributeBase(isa='bool'), 'false', None) == False

# Generated at 2022-06-11 09:38:58.483287
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
  field_attribute_base = FieldAttributeBase()
  field_attribute_base._valid_attrs = {}
  field_attribute_base._validated = False
  field_attribute_base._finalized = False
  field_attribute_base._squashed = False
  field_attribute_base._loader = None
  field_attribute_base._variable_manager = None
  field_attribute_base._uuid = '1c60a2a2a4924dd9b9f5b029c35d44ed'
  field_attribute_base._alias_attrs = set([])

  assert field_attribute_base.get_validated_value('name',attribute,value,templar) == '123'
  assert field_attribute_base._valid_attrs == {}
  assert field_attribute_base._validated == False
  assert field

# Generated at 2022-06-11 09:39:05.355629
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    temp_ds = dict()
    error_msg = 'isinstance(obj, self.class_type)'
    with patch.object(FieldAttributeBase, '__init__') as mock_init:
        mock_init.return_value = None
        obj = FieldAttributeBase(temp_ds)
    with pytest.raises(AnsibleAssertionError) as excinfo:
        obj.squash()
    assert error_msg in to_text(excinfo.value)


# Generated at 2022-06-11 09:39:13.798942
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class NameAttribute(FieldAttributeBase):
        def __init__(self):
            FieldAttributeBase.__init__(self, isa='string', default='test_test_test')
        def post_validate(self, value, templar):
            # Convert string values to Title Case
            if isinstance(value, string_types):
                return value.title()
            return value

    class NameObject(Base):
        def __init__(self):
            self._valid_attrs = dict(
                name=NameAttribute(),
            )
            super(NameObject, self).__init__()

        def _pre_finalize_field_attributes(self):
            pass
        def post_validate(self, templar):
            pass

    t1 = NameObject()

    # test simple case
    t2 = t1

# Generated at 2022-06-11 09:39:16.711746
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Test(with_metaclass(BaseMeta)):
        a=FieldAttribute(isa='str', inherit=True)
    assert Test().a is None

# Base class for other Ansible object types.

# Generated at 2022-06-11 09:39:58.100347
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    try:
        FA = FieldAttributeBase()
        FA.dump_attrs()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-11 09:40:07.851147
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    a = FieldAttributeBase()
    try:
        a.validate(False, 'test_name')
    except AnsibleParserError as e:
        assert e.message == "[test_name] is not yet used to test FieldAttributeBase class."
        assert e.obj == {}
    else:
        raise AssertionError("Expected failure did not occur")

    try:
        a.validate('test_name', 'test_name')
    except AnsibleParserError as e:
        assert e.message == "[test_name] is not yet used to test FieldAttributeBase class."
        assert e.obj == {}
    else:
        raise AssertionError("Expected failure did not occur")


# Generated at 2022-06-11 09:40:18.226494
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class DepChain(Base):
        _dep_chain = {'test': 123}

    class Play(Base):
        _dep_chain = DepChain()

    class Playbook(Base):
        _dep_chain = Play()

    def test_1():
        ds = 'this is ds'
        dep_chain = {'test': 123}
        dep = DepChain()
        dep._ds = ds
        dep._dep_chain = dep_chain
        assert dep.get_dep_chain() == dep_chain

    def test_2():
        ds = 'this is ds'
        dep_chain = {'test': 123}
        play = Play()
        play._ds = ds
        play._dep_chain = dep_chain
        assert play.get_dep_chain() == dep_chain


# Generated at 2022-06-11 09:40:23.465527
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    attrs = obj.dump_attrs()
    assert attrs == {'no_log': False, 'required': False, 'deprecated_aliases': [], 'version_added': None, 'deprecated_for_removal': False, 'always_post_validate': False, 'deprecated_reason': None, 'aliases': [], 'static': False}



# Generated at 2022-06-11 09:40:25.596467
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    instance = FieldAttributeBase()
    instance.get_validated_value('name', 'attribute', 'value', 'templar')

# Generated at 2022-06-11 09:40:28.415166
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    f1 = FieldAttributeBase()
    f2 = FieldAttributeBase()
    FieldAttributeBase.squash(f1, f2)
    # TODO: Implement test for squash
    assert True

# Generated at 2022-06-11 09:40:37.749666
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Unit tests for method '_FieldAttributeBase.post_validate'
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.context import CLIContext
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleParserError

    # set up the test class
    class TestFieldAttributeBase(FieldAttributeBase):
        test_attr = FieldAttribute(isa='string', default='foo')
        list_attr = FieldAttribute(isa='list', default=[])
        set_attr = FieldAttribute(isa='set', default=set())

# Generated at 2022-06-11 09:40:41.555563
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Input params sample

    # Output return sample

    db_task = dict(action=dict(module='shell', args='echo blah'), name='test')
    task = Task()
    task.deserialize(db_task)
    assert task.serialize() == db_task


# Generated at 2022-06-11 09:40:51.973970
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class MockBase(Base):
        def __init__(self, dep_chain=None):
            self._dep_chain = dep_chain
        def get_dep_chain(self):
            return self._dep_chain

    class MockRole(object):
        def __init__(self, role_path):
            self._role_path = role_path
    class TestCase(unittest.TestCase):
        def test_case(self):
            b = MockBase()
            self.assertEqual(b.get_search_path(), [os.path.dirname(b.get_path())])

            b._dep_chain = []
            self.assertEqual(b.get_search_path(), [os.path.dirname(b.get_path())])


# Generated at 2022-06-11 09:41:02.757567
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from .field_attribute import FieldAttributeBase
    from . import FieldAttributeBase as FieldAttributeBase_mod
    from .field_attribute import FieldAttribute
    from . import FieldAttribute as FieldAttribute_mod
    from .fields import BaseField

    FieldAttributeBase_obj = FieldAttributeBase()
    FieldAttributeBase_obj._valid_attrs = {'_valid_attrs':FieldAttributeBase_mod._valid_attrs}
    FieldAttributeBase_obj._valid_attrs['_valid_attrs'].static = True
    #
    FieldAttributeBase_obj._loader = {'_valid_attrs':FieldAttributeBase_mod._loader}
    FieldAttributeBase_obj._loader['_valid_attrs'].static = True
    #

# Generated at 2022-06-11 09:41:50.610453
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    play = Play()
    play.vars = {}
    play.set_loader(DictDataLoader({}))

    play.deserialize({'hosts': "{{ host }}", 'vars': None, 'name': "Test"})
    assert play.hosts == "{{ host }}"
    assert play.vars == {}
    assert play.name == "Test"

    play.deserialize({'hosts': "{{ test }}", 'vars': None, 'name': "Test2"})
    assert play.hosts == "{{ test }}"
    assert play.vars == {}
    assert play.name == "Test2"

    play.deserialize({'hosts': "{{ test2 }}", 'vars': dict(), 'name': "Test3"})

# Generated at 2022-06-11 09:41:53.345010
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Initialize the context
    test_object = Base()

    # Call the method
    result = test_object.dump_attrs()

    # Check the result
    assert result == {}, (result, {},)



# Generated at 2022-06-11 09:41:56.853600
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    class Foo(object):

        def post_validate(self, attr, value, templar):
            return True
        def get_validated_value(self, name, attribute, value, templar):
            return value

# Generated at 2022-06-11 09:42:09.176049
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit test for method post_validate of class FieldAttributeBase
    Checks that a templar error is raised if a default value is used as a string type,
    and that a ValueError is raised if a default value is used as a boolean type.
    '''

    # Declare the objects used to test the method post_validate of class FieldAttributeBase
    test_field_attribute_base = MockFieldAttributeBase()

    # test that a templar error is raised if a default value is used as a string type
    try:
        test_field_attribute_base.post_validate_string()
    except AnsibleParserError:
        pass
    else:
        assert False

    # test that a ValueError is raised if a default value is used as a boolean type

# Generated at 2022-06-11 09:42:13.663948
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    task = MockTask()
    assert isinstance(task, BaseTask)
    assert isinstance(task, FieldAttributeBase)
    task.deserialize({'uuid':'uuid_value'})
    assert isinstance(task._uuid, text_type)
    assert task._uuid == 'uuid_value'

# Generated at 2022-06-11 09:42:17.727616
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Testing the required methods on a data structure to
    # ensure the dump_me method works
    assert FieldAttributeBase.dump_me(None, None) == "None", "Value of dump_me() should be \"None\""


# Generated at 2022-06-11 09:42:20.122143
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    _testObj = FieldAttributeBase()
    assert _testObj.dump_me() is None

# Generated at 2022-06-11 09:42:24.980927
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test that it can serialize a simple object into dict
    obj = FieldAttributeBase(name='test_me')
    obj.test = 42
    obj.test2 = 'foo'
    rval = obj.dump_me()

    assert rval == {'test': 42, 'test2': 'foo'}


# Generated at 2022-06-11 09:42:27.150733
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    obj.validate(None)
    #assert isinstance(actual, expected)
    

# Generated at 2022-06-11 09:42:34.673346
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.module_utils._text import to_text
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    mytask = PlaybookIncludeLoader(
        play_file=to_text("/tmp/playbook/playbook.yml"),
        host_file=to_text("/tmp/playbook/hosts"),
        loader=DictDataLoader({}),
    ).load()

    assert mytask.get_path() == '<module>:1'

# Generated at 2022-06-11 09:43:36.765223
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class MyInventory(InventoryManager):
        def __init__(self, *args, **kwargs):
            super(MyInventory, self).__init__(*args, **kwargs)


# Generated at 2022-06-11 09:43:40.707351
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    data = dict(
        foo='bar',
        number=1,
        baz=[1,2,3],
    )
    obj = mock.Mock()
    obj.__class__ = FieldAttributeBase
    assert obj.load_data(data) == data, "Return value not as expected"


# Generated at 2022-06-11 09:43:44.613726
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    def load_data_impl(attribute):
        # Initialization and setup
        attr = attribute.load_data({})

        # Test processing
        assert isinstance(attr, FieldAttributeBase)

    with pytest.raises(AnsibleAssertionError):
        load_data_impl(1)

# Generated at 2022-06-11 09:43:53.515336
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    args = dict()
    curarg_token = None
    curarg_dict = None
    curarg_index = None
    curarg_default = None
    curarg_required = None
    curarg_isa = None
    curarg_listof = None
    curarg_static = False

    # Call method
    ret = FieldAttributeBase(args)
    ret_copy = ret.copy()

    # Test attributes
    assert isinstance(ret, FieldAttributeBase)
    assert not hasattr(ret, "curarg_token")
    assert not hasattr(ret, "curarg_dict")
    assert not hasattr(ret, "curarg_index")
    assert not hasattr(ret, "curarg_default")
    assert not hasattr(ret, "curarg_required")

# Generated at 2022-06-11 09:43:54.571380
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    assert True

# Generated at 2022-06-11 09:44:04.666767
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.plugins.loader import connection_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:44:08.943891
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = 'foo'
    with pytest.raises(AnsibleAssertionError) as excinfo:
        FieldAttributeBase().deserialize(data)
    assert 'data (foo) should be a dict but is a <class \'str\'>' in str(excinfo.value)

# Generated at 2022-06-11 09:44:09.408639
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass

# Generated at 2022-06-11 09:44:12.534244
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    #
    # Test setup
    #
    # Test setup
    #

    # Test execution
    result = FieldAttributeBase().dump_attrs()
    assert None is result


# Generated at 2022-06-11 09:44:22.866888
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class Base(object):
        def __init__(self):
            pass
        def get_dep_chain(self):
            return None
    class Host(Base):
        def __init__(self):
            super(Host, self).__init__()

    class Role(Base):
        def __init__(self):
            super(Role, self).__init__()

    class Play(Base):
        def __init__(self):
            super(Play, self).__init__()

    class Task(Base):
        def __init__(self):
            super(Task, self).__init__()
            self._parent = Play()
            self._parent._parent = Role()

    obj = Task()
    assert obj.get_dep_chain() is None


# Generated at 2022-06-11 09:45:32.513260
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    FA = FieldAttributeBase
    FA().squash(obj=AnsibleUnsafeText('0'), attr='0')
    FA().squash(obj=AnsibleUnsafeText('1'), attr='0', new_value=AnsibleUnsafeText('0'))
    FA().squash(obj=AnsibleUnsafeText('1'), attr='0', new_value='0')
    FA().squash(obj=AnsibleUnsafeText('1'), attr='0', new_value=AnsibleUnsafeText('0'), prepend=True)

# Generated at 2022-06-11 09:45:34.250125
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute = FieldAttributeBase()
    # Placeholder test, replace it with something better
    assert True

# Generated at 2022-06-11 09:45:43.706499
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible import errors
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    example = Task()

    assert example.get_validated_value('name', 'attribute', 'value', Templar(loader=DataLoader(), variables=VariableManager())) == 'value'
    assert example.get_validated_value('name', 'attribute', 17, Templar(loader=DataLoader(), variables=VariableManager())) == 17
    assert example.get_validated_value('name', 'attribute', 17.2, Templar(loader=DataLoader(), variables=VariableManager())) == 17.2
    assert example.get_validated_

# Generated at 2022-06-11 09:45:54.442904
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Post-validate is done on a per-type basis, so we need to test that the right methods are called
    # for each type

    class Tmp(FieldAttributeBase):
        pass

    tmp = Tmp()

    # The bool test is an interesting one because it's special cased
    attr = FieldAttribute(isa='bool', private=True, default=False, always_post_validate=True)
    tmp._valid_attrs['foo'] = attr

    # Test the bool validator
    mock_templar = mock.MagicMock()
    tmp.post_validate(templar=mock_templar)
    assert tmp._attributes['foo'] is False

    # Test other validators can be called
    tmp._attributes['foo'] = 'True'

# Generated at 2022-06-11 09:45:56.067119
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase()
    assert attr._validate(None, None) == None


# Generated at 2022-06-11 09:45:57.726570
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_obj = FieldAttributeBase()
    assert test_obj.validate(None) is None


# Generated at 2022-06-11 09:46:06.465060
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    f = FieldAttributeBase()
    f.vars = "this"
    f.parent = "that"
    f.hostvars = HostVars("hostvars")
    f.play_context = FieldAttributeBase()
    f.play_context.connection = "green"
    f.play_context.network_os = "red"
    f.play_context.become = FieldAttributeBase()
    f.play_context.become.become_method = "blue"
    f.play_context.become.become_user = AnsibleVaultEnc