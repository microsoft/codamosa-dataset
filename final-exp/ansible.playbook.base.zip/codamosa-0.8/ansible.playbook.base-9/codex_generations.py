

# Generated at 2022-06-11 09:36:57.471290
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    Unit test for method get_validated_value of class FieldAttributeBase
    '''
    # Invalid values for test, None for this case
    # For example: 
    #   test_obj = FieldAttributeBase(None)
    #   expected_result = class_instance
    #   test_obj.get_validated_value(None)
    #   assert(expected_result == test_obj.get_validated_value())

    # Create the object of class FieldAttributeBase with default values
    test_obj = FieldAttributeBase(None)

    # get the reference of method get_validated_value of class FieldAttributeBase
    method = getattr(test_obj, 'get_validated_value')

    # The expected result of method get_validated_value
    expected_result = None

    # Execute the method get

# Generated at 2022-06-11 09:37:09.161444
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class Dependent:
        def __init__(self):
            self.list = []

        def set_parent(self, parent):
            self.list.append(parent)

        def get_dep_chain(self):
            return self.list


    class TestObject(Base):
        def __init__(self):
            self._uuid = "id"
            self._finalized = True
            self._squashed = False
            self._parent = Dependent()

        @property
        def _vars(self):
            return {}

    # test for role dependency chain
    obj = TestObject()
    parent = TestObject()
    parent._parent = Dependent()
    obj._parent.set_parent(parent)
    assert obj.get_dep_chain() == [parent]

    # test for task without parent
    obj2

# Generated at 2022-06-11 09:37:10.591080
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # TODO: Implement text_FieldAttributeBase_dump_me
    pass


# Generated at 2022-06-11 09:37:12.151691
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
  # Assert: Call obj.validate(value)
  raise NotImplementedError()

# Generated at 2022-06-11 09:37:14.643054
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  # Make sure that we can dump the data properly
  field = FieldAttributeBase('name')
  assert isinstance(field, FieldAttributeBase)
  assert isinstance(field, object)
  assert field.name == 'name'


# Generated at 2022-06-11 09:37:22.687634
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    loader = DictDataLoader({
        'roles': {
            'bar.yml': """
                ---
                - name: A task
                  ping: data
                """,
        },
    })
    vault_secrets = [('default', VaultLib([('default', 'dummypass')]))]
    variables = VariableManager(loader=loader, vault_secrets=vault_secrets)
    templar = Templar(loader=loader, variables=variables, vault_secrets=vault_secrets)

    # Test class with a templatable attribute

# Generated at 2022-06-11 09:37:23.629474
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    f = FieldAttributeBase()


# Generated at 2022-06-11 09:37:30.576701
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FakeFieldAttribute(isa='class')
    attr2 = FakeFieldAttribute(isa='class')
    attr3 = FakeFieldAttribute(isa='class', required=True)
    attr4 = FakeFieldAttribute(isa='class')
    attr5 = FakeFieldAttribute(isa='class', default='xyz')
    attr6 = FakeFieldAttribute(isa='class')
    attr7 = FakeFieldAttribute(isa='class')

    field_attributes = {
        'attr': attr,
        'attr2': attr2,
        'attr3': attr3,
        'attr4': attr4,
        'attr5': attr5,
        'attr6': attr6,
        'attr7': attr7,
    }

    class FakeBase:
        _valid_attrs = field

# Generated at 2022-06-11 09:37:31.637088
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.post_validate()

# Generated at 2022-06-11 09:37:37.618419
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {
        'foo': 1,
        'bar': 2,
        'baz': [3, 4, 5],
    }
    class Test(FieldAttributeBase):
        _valid_attrs = dict(
            foo=FieldAttribute(isa='int'),
            bar=FieldAttribute(isa='int', default=10),
            baz=FieldAttribute(isa='list'),
        )
    test = Test()
    test.deserialize(data)
    assert test.foo == 1
    assert test.bar == 2
    assert test.baz == [3, 4, 5]



# Generated at 2022-06-11 09:38:06.529180
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fake_loader = DictDataLoader({})
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    my_action = ActionModule()
    my_action._valid_attrs = ActionModule._valid_attrs
    my_action._loader = fake_loader
    my_action._variable_manager = fake_variable_manager
    my_action._task = Task()

    my_action.from_attrs({'action': 'my_action.yml'})
    assert my_action._attributes['action'].value == 'my_action.yml'



# Generated at 2022-06-11 09:38:08.392772
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base = FieldAttributeBase()
    assert base.dump_attrs() == {}


# Generated at 2022-06-11 09:38:12.298896
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    test_case = dict()
    setattr(Base(),'_parent',[])
    test_case['Base._parent'] = [Base()]
    setattr(Base(),'_parent',[])
    assert Base.get_dep_chain() is not None


# Generated at 2022-06-11 09:38:22.610186
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = fixture_loader.load_fixture('field_attribute_base.json')
    obj = FieldAttributeBase()
    obj.deserialize(data)
# class HostVars:

#     def __init__(self, inventory, host, variables=None):

#         self._host = host
#         self._variables = variables
#         self._inventory = inventory

#         self._variable_manager = VariableManager()
#         self._variable_manager.add_collection(inventory)
#         if self._variables is not None:
#             self._variable_manager.set_nonpersistent_facts(self._variables)

#     def __getitem__(self, var):
#         return self.__getattr__(var)

#     def __getattr__(self, var):
#         return self._

# Generated at 2022-06-11 09:38:34.610312
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import base
    import __main__

    __main__.__file__ = 'test_Base_get_search_path.py'  # fakes the module name of the calling file
    __main__.__loader__ = None

    dep_chain = [base.Base(parent=None, loader=None, data={"name": "task_0", "action": "action_A"}),
                 base.Base(parent=None, loader=None, data={"name": "task_1", "action": "action_B",
                                                          "depends_on": "task_0"}),
                 base.Base(parent=None, loader=None, data={"name": "task_2", "action": "action_C",
                                                          "depends_on": "task_1"})]
    dep_chain[0]._

# Generated at 2022-06-11 09:38:36.135584
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
  pass


# Generated at 2022-06-11 09:38:43.400840
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit test for method post_validate of class FieldAttributeBase

    Tests for when the object has a method called '_post_validate_<field>'
    '''

    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar

    f = FieldAttributeBase()
    templar = Templar(loader=DictDataLoader(), variables=VariableManager())

    def post_validate_test(attr, value, templar):
        return value + '.post_validated'
    f._post_validate_test = post_validate_test
    f.test = 'value'
    f.post_validate(templar=templar)
    assert f.test == 'value.post_validated'


# Generated at 2022-06-11 09:38:50.623540
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    # Test with a valid structure
    obj = FieldAttributeBase()
    data = {"finalized": False, "uuid": "7bc8bc04-e2a0-4815-b9b9-963be3aaf0d6"}
    obj.deserialize(data)

    assert obj._finalized == False
    assert obj._uuid == "7bc8bc04-e2a0-4815-b9b9-963be3aaf0d6"



# Generated at 2022-06-11 09:38:51.929715
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    assert True


# Generated at 2022-06-11 09:38:58.421956
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Setup args for testing
    FieldAttributeBase(name='test_name', default=None, attribute=None,
                       always_post_validate=False, isa=None, priority=None,
                       required=False, static=False,)
    name = ""
    attribute = ""
    value = ""
    templar = ""

    ret = FieldAttributeBase.get_validated_value(name, attribute, value, templar)
    print(ret)

# Generated at 2022-06-11 09:39:23.396447
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    class MyClass(FieldAttributeBase):
        my_list = FieldAttribute(isa='list', required=True)
        my_attr = FieldAttribute()

    obj = MyClass()

    assert obj.dump_attrs() == {
        'my_list': [],
        'my_attr': None,
    }

# Generated at 2022-06-11 09:39:33.386657
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class Class(object):
        class_var = FieldAttribute(isa='string', default='a_value')
        is_static = FieldAttribute(isa='bool', default=False)
        isa = FieldAttribute(isa='string', default='string', make_copy=True)
        required = FieldAttribute(isa='bool', default=True)
        default = FieldAttribute(isa='string', default='string')

        def __init__(self, ds):
            self._valid_attrs = dict(
                class_var=self.class_var,
                static_var=self.static_var,
                is_static=self.is_static,
                isa=self.isa,
                required=self.required,
                default=self.default,
            )

            self.class_var = 'a_value'
            self._is

# Generated at 2022-06-11 09:39:34.429129
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    f = FieldAttributeBase()


# Generated at 2022-06-11 09:39:37.152854
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    templar = {}
    assert str(obj.post_validate(templar=templar)) == ""


# Generated at 2022-06-11 09:39:38.259616
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    base = FieldAttributeBase('FieldAttributeBase')
    assert base.copy().name == 'FieldAttributeBase'


# Generated at 2022-06-11 09:39:40.950009
# Unit test for method copy of class FieldAttributeBase

# Generated at 2022-06-11 09:39:53.356242
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.parsing.yaml.objects import AnsibleMapping
    field_attribute_base = FieldAttributeBase()

    # Method is overridden
    # Value is not an instance of <class 'ansible.module_utils.six.string_types'> or <class 'str'>
    a1 = b""
    e1 = "b''"
    r1 = field_attribute_base.dump_me(a1)
    assert (r1 == e1)


    # Method is overridden
    # Value is not an instance of <class 'ansible.module_utils.six.string_types'> or <class 'str'>
    a1 = u""
    e1 = "''"
    r1 = field_attribute_base.dump_me(a1)
    assert (r1 == e1)


    # Method

# Generated at 2022-06-11 09:39:54.753834
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    assert False, "No test for method copy of class FieldAttributeBase"

# Generated at 2022-06-11 09:40:03.551254
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    host = dict(name="test", foo="bar")
    host_object = Task()
    try:
        Task.from_attrs(host)
    except AssertionError as exc:
        assert str(exc) == "data (test) should be a dict but is a <class 'str'>"
    else:
        raise AssertionError("Task.from_attrs did not raise AssertionError")

    host_object.from_attrs(host)
    assert host_object.name == "test"
    assert host_object.foo == "bar"



# Generated at 2022-06-11 09:40:05.389888
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    FieldAttributeBase = objects.FieldAttributeBase

    fb = FieldAttributeBase()

    fb.copy()

# Generated at 2022-06-11 09:40:35.738778
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    #Create a FieldAttributeBase

    #Call method get_validated_value
    pass


# Generated at 2022-06-11 09:40:45.202906
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class DummyVarsModule(object):
        def __init__(self):
            self.omit = None
    # Save the test data

# Generated at 2022-06-11 09:40:50.088401
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    @fields.Fields.register
    class TestClass(FieldAttributeBase):
        fields = {
            'a': fields.FieldAttribute(isa='int'), # type: ignore
        }

    obj = TestClass()
    obj.a = 1
    assert obj.dump_attrs() == {'a': 1}

# Generated at 2022-06-11 09:41:00.837116
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.templating import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    ds1 = {}
    attribute1 = FieldAttributeBase(default=None)
    attribute1.always_post_validate = False
    attribute1.required = False
    attribute1.static = False
    attribute1.isa = 'dict'
    attribute1.name = 'var2'
    obj1 = AnsibleBaseYAMLObject.load({'var2': ds1}, loader=DataLoader())

# Generated at 2022-06-11 09:41:06.256192
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attr = FieldAttributeBase(isa='dict', always_post_validate=True, always_precedence=True)    
    attr.name = 'dict_field'
    obj = FieldAttributeBase()
    obj._post_validate(attr, 'some_value')
    assert obj.get_validated_value('some_field') is not None
    

# Generated at 2022-06-11 09:41:16.476799
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field = FieldAttributeBase()
    field.isa = 'string'
    field.default = None
    field.required = False
    field.always_post_validate = True
    field.aliases = []
    field.class_type = []
    field.class_restrictions = []
    field.choices = []
    field.assumed_if_missing = []
    field.default_if_missing = None
    field.isatty = False
    field.choices_description = []
    field.statics = []
    field.static = False
    field.template = False
    field.listof = []

    assert field.get_validated_value(name='name', attribute=field, value=None, templar=Templar(loader=DictDataLoader())) == None
    

# Generated at 2022-06-11 09:41:24.044692
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    @attr.s
    class FakeAnsibleObject(FieldAttributeBase):
        example_attr = FieldAttribute(isa='str', default="")

        def __init__(self, example_attr):
            self.example_attr = example_attr
            super(FakeAnsibleObject, self).__init__()

    test_obj = FakeAnsibleObject("test_obj")

    # Does not raise an error
    test_obj.post_validate(MockTemplar())

    assert test_obj.example_attr == "test_obj"



# Generated at 2022-06-11 09:41:25.458696
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Set up test environment
    # test the code
    assert False

# Generated at 2022-06-11 09:41:37.325112
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    dct = {
        '_test_attr_01': FieldAttribute(isa='dict'),
        '_test_attr_02': FieldAttribute(isa='str'),
        '_test_attr_03': FieldAttribute(isa='str'),
    }
    name = 'BaseMeta'
    parents = (object, )
    new_cls = BaseMeta(name, parents, dct)
    assert isinstance(new_cls, type)
    assert isinstance(new_cls, BaseMeta)
    assert hasattr(new_cls, '_attributes')
    assert hasattr(new_cls, '_attr_defaults')
    assert hasattr(new_cls, '_valid_attrs')
    assert hasattr(new_cls, '_alias_attrs')

# Generated at 2022-06-11 09:41:48.800370
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from collections import MutableMapping
    from ansible import __version__, constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class TaskOptions(MutableMapping):
        def __init__(self, options=None, *args, **kwargs):
            self._dict = dict(options) if options else dict()
            super(TaskOptions, self).__init__(*args, **kwargs)

        def __getitem__(self, key):
            return self._dict[key]

        def __setitem__(self, key, value):
            self._dict[key] = value

        def __delitem__(self, key):
            del self._dict[key]


# Generated at 2022-06-11 09:42:20.655011
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Init vars
    attrs_obj = dict()
    # Create an instance of class FieldAttributeBase
    fieldattributebase_obj = FieldAttributeBase()
    # Test method from_attrs
    try:
        fieldattributebase_obj.from_attrs(attrs_obj)
    except:
        fail("""Unable to use method from_attrs of class FieldAttributeBase.""")

# Generated at 2022-06-11 09:42:30.773984
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    def _assert_equal(self, expected_result, actual_result):
        if expected_result != actual_result:
            raise AssertionError()

    def _assert_not_equal(self, expected_result, actual_result):
        if expected_result == actual_result:
            raise AssertionError()

    def _assert_is_none(self, variable):
        if variable is not None:
            raise AssertionError()

    def _assert_is(self, variable, value):
        if variable is not value:
            raise AssertionError()

    def _assert_false(self, variable):
        if variable:
            raise AssertionError()

    def _assert_true(self, variable):
        if not variable:
            raise AssertionError()


# Generated at 2022-06-11 09:42:40.952128
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttribute(isa='str')

    # Check valid values
    attr.validate('str')
    attr.validate(None)

    # Check invalid types
    try:
        attr.validate(42)
        assert False, "Validation should have failed for type int"
    except TypeError:
        pass
    try:
        attr.validate(12.3)
        assert False, "Validation should have failed for type float"
    except TypeError:
        pass
    try:
        attr.validate(dict())
        assert False, "Validation should have failed for type dict"
    except TypeError:
        pass
    try:
        attr.validate(list())
        assert False, "Validation should have failed for type list"
    except TypeError:
        pass
   

# Generated at 2022-06-11 09:42:51.703656
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    pb = Play.load(dict(
        name='myplay',
        connection='local',
        hosts=['otherhost'],
        gather_facts='no',
        serial=5
    ), loader=Mock())
    results = pb.dump_attrs()
    assert results['name'] == 'myplay'
    assert results['connection'] == 'local'
    assert results['hosts'] == ['otherhost']
    assert results['gather_facts'] == 'no'
    pb.post_validate(Mock())
    results = pb.dump_attrs()
    assert results['name'] == 'myplay'
    assert results['connection'] == 'local'

# Generated at 2022-06-11 09:42:53.260936
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  pass
# Unit tests for class FieldAttributeBase

# Generated at 2022-06-11 09:42:59.593366
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.attribute import FieldAttributeBase
    attr = FieldAttributeBase('test',0,0,0)
    attr2 = attr.copy()
    assert attr2 is not attr
    assert attr2.name == attr.name
    assert attr2.required == attr.required
    assert attr2.aliases == attr.aliases
    assert attr2.static == attr.static

# Generated at 2022-06-11 09:43:01.651686
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    assert not b.get_dep_chain()
test_Base_get_dep_chain()



# Generated at 2022-06-11 09:43:06.741321
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_config = {
        '_ansible_omit_placeholder': '__omit_placeholder__',
        'nested': {
            'value': '2'
        }
    }
    my_loader = None
    my_variable_manager = VariableManager(loader=my_loader, inventory=Inventory())

    my_final = False
    my_squashed = False
    my_uuid = uuid.uuid4()
    

# Generated at 2022-06-11 09:43:09.549755
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Setup
    obj = FieldAttributeBase()
    # Exercise
    expected = dict(
        name=obj._name,
        isa=obj._isa,
        required=obj._required,
        default=obj._default,
    )
    # Verify
    assert expected == obj.dump_me()


# Generated at 2022-06-11 09:43:12.281058
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # test with good data
    field = FieldAttribute(isa='string')
    value = 'good string'
    field.validate(value)

    # test with bad data
    with pytest.raises(TypeError):
        value = [1, 2, 3]
        field.validate(value)


# Generated at 2022-06-11 09:43:48.576373
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_obj = AnsibleBase()._valid_attrs['test_field']
    assert test_obj.isa == 'string'
    assert test_obj.default is None
    assert test_obj.required is False
    assert test_obj.migratable is True
    assert test_obj.static is False
    assert test_obj.choices is None
    assert test_obj.aliases is None
    assert test_obj.always_post_validate is False
    assert test_obj.class_type is None
    assert test_obj.listof is None
    # Unit test for method __repr__ of class FieldAttributeBase

# Generated at 2022-06-11 09:43:58.071005
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    #
    # Test creation of a FieldAttributeBase without a parent
    #
    mock_ds = Mock()
    mock_ds = Mock()
    mock_templar = MagicMock()
    mock_templar.template = Mock(return_value=False)
    mock_templar.is_template = Mock(return_value=False)
    mock_templar.template.return_value = False
    mock_templar.is_template.return_value = False

    ba = FieldAttributeBase(parent=None)
    ba.get_ds= Mock(return_value=mock_ds)

    #
    # Test creation of a FieldAttributeBase with a parent
    #
    mock_parent = Mock()
    mock_parent.get_ds= Mock(return_value=mock_ds)


# Generated at 2022-06-11 09:44:08.100214
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-11 09:44:17.261993
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-11 09:44:29.179758
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    my_data = {
        'foo': True,
        'roles': [],
    }

    # Populate the data by merging in the vars
    # Merging in vars is done in the load_data method
    # of the JSON deserializer. This is the first place
    # where the data gets massaged
    base = AnsibleBase()
    base.load_data(my_data)

    assert base.vars == {}
    assert base.roles == []
    assert base.foo == True

    my_data = {
        'vars': {
            'foo': 'bar'
        },
        'roles': [
            'web-server'
        ],
        'foo': True
    }

    base = AnsibleBase()
    base.load_data(my_data)


# Generated at 2022-06-11 09:44:39.658890
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    all_attrs = FieldAttributeBase.__dict__.keys()
    method_names = []
    for attr_name in all_attrs:
        if attr_name.startswith('_') and attr_name.endswith('_'):
            method_names.append(attr_name)

    for method_name in method_names:
        if method_name.startswith('__'):
            method = getattr(FieldAttributeBase, method_name)
            setattr(FieldAttributeBase, method_name, lambda x: None)

    obj = FieldAttributeBase()
    data = {
        '__validate__': [1, 2, 3],
        '__default__': [4, 5, 6],
    }

    # call method
    obj.from_attrs(data)


# Generated at 2022-06-11 09:44:42.355951
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    """ Unit test for method copy of class FieldAttributeBase """

    # TODO - this test needs to be fixed, because it is not unit testing copy
    # instead it is using it as a helper function
    pass


# Generated at 2022-06-11 09:44:48.155875
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    _valid_attrs = {'x': FieldAttribute(isa='string', priority=127, exclude=['y']), 'y': FieldAttribute(isa='int', choices=[1, 2, 3], priority=127)}
    obj = FieldAttributeBase(_valid_attrs)
    obj._validated = True
    obj._finalized = True
    templar = Templar(variables={})
    with pytest.raises(AnsibleParserError) as exec_info:
        obj.get_validated_value('x', FieldAttribute(isa='string'), '', templar)
    assert "the field 'x' is required but was not set" in to_native(exec_info.value)

# Generated at 2022-06-11 09:44:58.741214
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test_obj = Base()
    test_obj._role_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    test_obj._ds =  {'_line_number': 1, '_data_source': os.path.dirname(test_obj._role_path)}
    test_obj._parent = {'_play': {'_ds': test_obj._ds}}
    assert test_obj.get_search_path()

    test_obj = Base()
    test_obj._role_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

# Generated at 2022-06-11 09:45:03.637725
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.playbook.task import Task

    # test from_attrs
    d_task = dict(action='foo', module='bar', become_user=None)
    task = Task()
    task.from_attrs(d_task)
    assert task.action == 'foo'
    assert task.module == 'bar'
    assert task.become_user is None
