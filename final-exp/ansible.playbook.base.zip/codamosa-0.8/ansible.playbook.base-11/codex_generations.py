

# Generated at 2022-06-11 09:36:58.166598
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # create an empty mock object
    obj = BaseObject()
    # create a mock of the templar
    templar = MagicMock()
    templar.available_variables = dict()
    templar.available_variables['omit'] = 'omit'

    # testing the always_post_validate of the class
    # 1) always_post_validate == True and required == True, test if type is "Task"
    field = FieldAttributeBase(always_post_validate=True, required=True)
    assert field.always_post_validate and field.required
    assert field.name == ""
    assert field.isa == "dict"
    assert field.static == False
    assert field.class_type == BaseObject
    assert field.default == dict()


# Generated at 2022-06-11 09:36:59.315426
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # TODO
    pass


# Generated at 2022-06-11 09:37:10.083101
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute

    class TestBaseMeta___new__(Base):
        # Create attributes
        attr1 = FieldAttribute(isa='str')
        _attr2 = FieldAttribute(isa='str')
        attr2 = FieldAttribute(isa='str', alias='alias2')

        # Create attributes which will be removed
        _invalid1 = 'string'
        _invalid2 = 1
        _invalid3 = dict()

    # Check the attributes of class
    assert 'attr1' in TestBaseMeta___new__.__dict__
    assert '_attr1' not in TestBaseMeta___new__.__dict__
    assert 'attr2' in TestBaseMeta___new__.__dict__
    assert 'alias2' in TestBaseMeta

# Generated at 2022-06-11 09:37:15.359549
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Check to see if dump_me works at all
    f = FieldAttributeBase()
    dump_me_output = f.dump_me()
    assert dump_me_output is not False, 'dump_me failed to generate a dictionary'

    #
    # Check to see if the returned dictionary has correct keys
    #

    # Check to see if the returned dictionary has the correct keys
    #
    # Check to see if the returned dictionary has the correct keys
    #
    # Check to see if the returned dictionary has the correct keys
    #


# Generated at 2022-06-11 09:37:16.160136
# Unit test for method get_path of class Base
def test_Base_get_path():
    assert False

# Generated at 2022-06-11 09:37:17.965424
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    obj = FieldAttributeBase()
    attrs = dict()
    assert obj.from_attrs(attrs) == None


# Generated at 2022-06-11 09:37:19.199906
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # TODO implement test
    assert False


# Generated at 2022-06-11 09:37:22.112588
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # First we construct an object of the class we are going to test
    bot = FieldAttributeBase()

    # Since the method is abstract we don't expect it to do anything
    bot.validate('')
    pass

# Generated at 2022-06-11 09:37:26.809779
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    x = FieldAttributeBase("TestValue")
    # Get the actual value of the method
    output = x.get_validated_value("TestInput")
    # Make sure the output matches the expected results
    assert isinstance(output, FieldAttribute)
    assert output.name == "TestInput"
    assert output.default == "TestValue"
    assert output.required is False



# Generated at 2022-06-11 09:37:27.844500
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    assert Base().get_search_path() == []


# Generated at 2022-06-11 09:38:23.475941
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    dep_chain_parent = Base()
    dep_chain_child = Base()
    dep_chain_parent._parent = dep_chain_child
    dep_chain_child._parent = None

    assert dep_chain_parent.get_dep_chain() == None
    assert dep_chain_child.get_dep_chain() == [dep_chain_child]

# Generated at 2022-06-11 09:38:26.719048
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    expected = (False, 'Host address is not valid.', {}, {})
    actual = FieldAttributeBase(name='host').post_validate(templar=Mock())
    assert expected == actual


# Generated at 2022-06-11 09:38:39.619542
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.template.vars import AnsibleVars

    # Note: we intentionally are using a class with no methods.
    #       On Python 3, this will result in a "TypeError("isinstance() arg 2 must be a type or tuple of types",)"
    #       when calling the copy method.
    class test_FieldAttributeBase_copy_MyClass: pass
    class test_FieldAttributeBase_copy_MyClass2(FieldAttributeBase):
        _valid_attrs = FieldAttributeDict()

        def __init__(self):
            self.name = FieldAttribute(isa='string')
            self.value = FieldAttribute(isa='string')


    my_test_fieldattributebase = FieldAttributeBase()
    my_test_fieldattributebase.name = 'my_test_fieldattributebase'

# Generated at 2022-06-11 09:38:49.073087
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    b = wrap_var('foo')
    c = wrap_var(['foo'])
    d = wrap_var(b)
    e = wrap_var(c)
    attr = FieldAttributeBase('foo', True, None, None, None, None, 'bar', [b, c, d, e])
    attr.isa = 'list'
    attr.listof = AnsibleUnsafeText

    result = attr.dump_me()


# Generated at 2022-06-11 09:38:56.863559
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fb = FieldAttributeBase('foo', True)
    # check default value
    assert fb.dump_me() == {'name': 'foo', 'default': None, 'required': True, 'isa': 'string', 'static': False}
    # check that default value is overriden
    fb.default = 'default'
    assert fb.dump_me() == {'name': 'foo', 'default': 'default', 'required': True, 'isa': 'string', 'static': False}


# Generated at 2022-06-11 09:39:07.670961
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    print("test_BaseMeta___new__")
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute

    class Test(with_metaclass(BaseMeta, Base)):
        a = Attribute()
    t = Test()
    t.__dict__['_attributes'] = {'b': 1}
    test_m = BaseMeta.__new__
    result = test_m(BaseMeta, 'Test3', (object,), {'a': 1})

    # print('result:', result)
    # print(result.__dict__)
    # print('result:', result)

    assert result == type
    assert result.__dict__['__name__'] == 'Test3'
    assert result.__dict__['__bases__'] == (object,)
    assert result

# Generated at 2022-06-11 09:39:09.014915
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert hasattr(Base, 'get_dep_chain')

# Generated at 2022-06-11 09:39:15.709598
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Initialize a fake attribute
    attribute_class_fake = mock.MagicMock()
    attribute_class_fake.isa = 'class'

    attr_fake = mock.MagicMock()
    attr_fake.serialize.return_value = 'fake_serialize_result'
    attribute_class_fake.class_type.return_value = attr_fake

    # Initialize a fake variable manager
    variable_manager_fake = mock.MagicMock()

    # Initialize a fake loader
    loader_fake = mock.MagicMock()

    # Initialize a fake task
    task_fake = mock.MagicMock()

    # Initialize a fake field attribute base

# Generated at 2022-06-11 09:39:26.475151
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # initialize mock data
    Base_get_dep_chain_mock_data = {}
    Base_get_dep_chain_mock_data['_parent'] = Base_get_dep_chain_mock_data.copy()
    Base_get_dep_chain_mock_data['_parent']['_parent'] = Base_get_dep_chain_mock_data.copy()
    Base_get_dep_chain_mock_data['_parent']['_parent']['_parent'] = Base_get_dep_chain_mock_data.copy()
    Base_get_dep_chain_mock_data['_parent']['_parent']['_parent']['_parent'] = None
    Base_get_dep_chain_mock_data['_play'] = 'play1'
    Base

# Generated at 2022-06-11 09:39:36.493270
# Unit test for method get_path of class Base
def test_Base_get_path():
    # scaffolding for testing
    class DataSource(object):
        def __init__(self):
            self._data_source = '/path/to/file'
            self._line_number = 23

    class FakeParent(object):
        def __init__(self):
            self._play = Play()

    class Play(object):
        def __init__(self):
            self._ds = DataSource()

    # test setup
    play = Play()
    play._ds._data_source = '/path/to/playbook'
    play._ds._line_number = 42

    task = Task()
    task._ds = DataSource()
    task._ds._data_source = '/path/to/task'
    task._ds._line_number = 24
    task._parent = FakeParent()

    # test case 1 - just task


# Generated at 2022-06-11 09:41:00.923982
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    field_attribute_base = ansible.module_utils.common._Ansible_base._FieldAttributeBase()
    assert field_attribute_base.post_validate( None ) == None



# Generated at 2022-06-11 09:41:02.917005
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    result = FieldAttributeBase.dump_attrs()
    assert result is not None

# Generated at 2022-06-11 09:41:13.320240
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-11 09:41:19.115173
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    task = Task()
    task._validated = True
    task._squashed = False
    task._finalized = False
    mock_templar = MagicMock()
    mock_templar.template.return_value = 'some_template'
    mock_templar._fail_on_undefined_errors = False
    task.post_validate(templar=mock_templar)


# Generated at 2022-06-11 09:41:20.275027
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    test_obj = Base()

# Generated at 2022-06-11 09:41:23.426166
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """
    Tests FieldAttributeBase().validate()
    """

    """
    Base class that all field attribute classes inherit from
    """
    # Init the class
    u1 = FieldAttributeBase()


# Generated at 2022-06-11 09:41:24.766800
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    FA = FieldAttributeBase()
    FA.ds = "abcd"
    result = FA.get_ds()
    assert result == "abcd"


# Generated at 2022-06-11 09:41:29.820624
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()
    name = 'string'
    attribute = FieldAttribute(isa='string')
    value = 'string'
    templar = mock.Mock()
    r = obj.get_validated_value(name, attribute, value, templar)
    assert r is value and r == 'string'
    name = 'int'
    attribute = FieldAttribute(isa='int')
    value = '42'
    r = obj.get_validated_value(name, attribute, value, templar)
    assert r is value and r == 42
    name = 'float'
    attribute = FieldAttribute(isa='float')
    value = '42'
    r = obj.get_validated_value(name, attribute, value, templar)
    assert r is value and r == 42.0
    name

# Generated at 2022-06-11 09:41:37.775669
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class MockBase (Base):
        def __init__(self, parent):
            self._parent = parent
    class MockRole (Role):
        def __init__(self, path):
            self._role_path = path
    base = MockBase(None)
    assert base.get_dep_chain() == None
    role = MockRole('./test_role')
    dep_chain = [role]
    base = MockBase(role)
    assert base.get_dep_chain() == dep_chain

# Generated at 2022-06-11 09:41:49.170823
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    task = Task()
    data = task.serialize()

# Generated at 2022-06-11 09:44:25.272528
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    assert 1 == 1



# Generated at 2022-06-11 09:44:28.154220
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_a = FieldAttributeBase()
    templar = None
    my_a.post_validate(templar)  # TODO: implement


# Generated at 2022-06-11 09:44:36.135900
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    args = dict(
        name = 'name',
        default = None,
        required = True,
        private = False,
        isa = None,
        listof = None,
        always_post_validate = False,
    )
    f = FieldAttributeBase(**args)
    assert f.name == 'name'
    assert f.default == None
    assert f.required == True
    assert f.private == False
    assert f.isa == None
    assert f.listof == None
    assert f.always_post_validate == False



# Generated at 2022-06-11 09:44:39.388556
# Unit test for method squash of class FieldAttributeBase

# Generated at 2022-06-11 09:44:41.708401
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # Implicit setup for method validate of class FieldAttributeBase
    f = FieldAttributeBase()

    # Implicit teardown for method validate of class FieldAttributeBase
    return


# Generated at 2022-06-11 09:44:45.433166
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    attr = FieldAttributeBase()
    attr.name = "name"
    attr.default = "default"
    attr.isa = "isa"
    attr.required = False
    assert attr.dump_me() == {'name': 'name', 'default': 'default', 'isa': 'isa', 'required': False}



# Generated at 2022-06-11 09:44:47.068558
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    test_object = FieldAttributeBase()
    assert test_object.copy() is not None



# Generated at 2022-06-11 09:44:48.969703
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    assert isinstance(obj.dump_attrs(), dict) == True

# Generated at 2022-06-11 09:44:50.643553
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Tested by ActionBase.from_attrs, since it's the same code
    pass


# Generated at 2022-06-11 09:44:54.651255
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fld = FieldAttributeBase()
    assert fld.get_validated_value("name", None, '1', None) == '1'
    assert fld.get_validated_value("name", None, None, None) is None
