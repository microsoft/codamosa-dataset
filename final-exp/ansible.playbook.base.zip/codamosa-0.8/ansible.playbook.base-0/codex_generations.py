

# Generated at 2022-06-11 09:37:13.953635
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    test = {}
    # Test set-up
    FieldAttributeBase = FieldAttributeBase()
    FieldAttributeBase._valid_attrs = {'test': test}
    FieldAttributeBase.test = 'test_text'
    # Test execution
    try:
        FieldAttributeBase.dump_attrs()
    except SystemExit as e:
        pass
    except Exception as e:
        error = e
    # Test verification
    assert(dict == type(FieldAttributeBase.dump_attrs()))


# Generated at 2022-06-11 09:37:21.821951
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # A test for an int
    obj = FieldAttributeBase()
    name = 'my_field'
    value = '42'
    parsed_value = int(value)
    attribute = attr.FieldAttribute(isa='int', required=True)
    templar = 'a templar'
    assert obj.get_validated_value(name, attribute, value, templar) == parsed_value

    # A test for a float
    obj = FieldAttributeBase()
    name = 'my_field'
    value = '42.42'
    parsed_value = float(value)
    attribute = attr.FieldAttribute(isa='float', required=True)
    templar = 'a templar'
    assert obj.get_validated_value(name, attribute, value, templar) == parsed_value

   

# Generated at 2022-06-11 09:37:27.939842
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    base = Base()
    attribute = FieldAttributeBase()
    string = "string"

    # Test with first argument as name and the rest as per docstring of the method
    # TODO: Add tests
    # xfail: py3.5 (blocking in py3.5: to_native is not available)
    # xfail: py3.6 (blocking in py3.6: to_text is not available)
    # xfail: py3.7 (blocking in py3.7: to_text is not available)
    # xfail: py3.8 (blocking in py3.8: to_text is not available)



# Generated at 2022-06-11 09:37:29.737502
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    with pytest.raises(AnsibleParserError):
        with pytest.raises(Exception):
            pass

# Generated at 2022-06-11 09:37:31.746240
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    test_obj = FieldAttributeBase()
    source_value = {}
    test_obj.copy(source_value)


# Generated at 2022-06-11 09:37:32.714313
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FieldAttributeBase()
    pass


# Generated at 2022-06-11 09:37:40.333962
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    data = dict(
        name='string',
        default='default value',
        choices=('foo', 'bar'),
        required=True,
        private=True,
        alias=('alias1', 'alias2'),
        always_post_validate=True
    )

    field_attribute = FieldAttributeBase('test name')

    field_attribute.load_data(data)

    assert field_attribute.name == 'string', \
        '''_load_data should have set field_attribute.name to 'string'.'''

    assert field_attribute.default == 'default value', \
        '''_load_data should have set field_attribute.default to 'default value'.'''


# Generated at 2022-06-11 09:37:41.309944
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    assert True

# Generated at 2022-06-11 09:37:49.464027
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    
    # Create a new FieldAttributeBase object
    obj = FieldAttributeBase()
    
    # Create mock values and assign them to variable name.
    name = "name"
    attribute = "attribute"
    value = "value"
    templar = MagicMock()
    
    # Call the method.
    result = obj.get_validated_value(name, attribute, value, templar)
    
    # Check if result is the expected one.
    if (result is not None):
        raise AssertionError("expected:", None, "actual:", result)
    


# Generated at 2022-06-11 09:37:51.983973
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # test function for FieldAttributeBase.get_validated_value()
    # TODO: create tests
    pass



# Generated at 2022-06-11 09:38:39.336217
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleMapping
    text = '''---
- name: it should check the presence of `name` field
  hosts: 127.0.0.1
  gather_facts: no
  tasks:
  - debug:
      msg: add dict into dict
    vars:
      dict1:
        name: dict1
      dict2:
        name: dict2
    with_dict:
      - "{{ dict1 }}"
      - "{{ dict2 }}"
'''
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['127.0.0.1'])

# Generated at 2022-06-11 09:38:41.119673
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field = FieldAttributeBase("name", default=None)
    field.validate("name", "value")


# Generated at 2022-06-11 09:38:47.804361
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    dump_attrs_module_mock = MagicMock(return_value={'dump_attrs': 'dump_attrs'})
    attrs_module_mock = {'dump_attrs': dump_attrs_module_mock}
    with patch.dict('ansible.utils.module_docs_fragments.ATTRIBUTES_DOCUMENTATION', attrs_module_mock, clear=True):
        ansible_module_mock = MagicMock()
        with patch.object(ansible_module_mock, '_load_params') as mock_load_params:
            with patch.dict(ansible_module_mock.argument_spec, {}, clear=True):

                # arrange
                loader_mock = MagicMock()
                variable_manager_mock = MagicMock()
               

# Generated at 2022-06-11 09:38:54.991174
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
  TestFieldAttributeBase = construct_FieldAttributeBase()
  data = {}
  test_instance = TestFieldAttributeBase()
  expected_result = None
  actual_result = test_instance.deserialize(data)
  assert actual_result == expected_result, 'Expected: %s, Actual: %s' % (expected_result, actual_result)
# end of unit test for method deserialize of class FieldAttributeBase


# Generated at 2022-06-11 09:39:02.690200
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    """
    this test is desgined to test the method get_dep_chain of class Base
    NOTE:test_Base_get_dep_chain can only be executed after the class Base is defined
    """
    # when the dependent is not given
    a = Base()
    x = a.get_dep_chain()
    assert x == None

    # when the dependent is given
    a = Base()
    b = Base()
    a._parent = b
    x = a.get_dep_chain()
    assert x == b


# Generated at 2022-06-11 09:39:12.274030
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    base_config = load_fixture_config(FIXTURE_DIR, CONFIG_FILE)
    global display
    display = Display()

    # Pass in the mock_spec parameter to mock any module that is imported by the module being tested.
    # Use autospec=True so the mock_spec (a mock) will behave like the real module it is mocking.
    # The mock_spec's attributes will also be mocked.
    # When you mock a module, the whole module is mocked.
    # This is necessary so that the class, objects and attributes of the class are also mocked.
    # If you specify the spec for the class, only the objects and attributes of the class will be automatically mocked.
    # If you don't specify a spec, the objects and attributes will not be mocked.

# Generated at 2022-06-11 09:39:14.569930
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    data = dict()
    name = 'test'
    self = FieldAttributeBase()
    result = self.load_data(data, name)
    assert result == None


# Generated at 2022-06-11 09:39:19.391853
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = dict(a=u'2',b=u'3')
    ansible_metadata_base = AnsibleBase()
    ansible_metadata_base.from_attrs(attrs=attrs)
    assert ansible_metadata_base.attributes == dict(a=u'2',b=u'3')

# Generated at 2022-06-11 09:39:21.447109
# Unit test for method get_path of class Base
def test_Base_get_path():
    name="TestBaseGetPath"
    obj = Base(name)
    assert obj._name == name

# Generated at 2022-06-11 09:39:23.622112
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field = FieldAttributeBase()
    assert field.post_validate() == None

# Generated at 2022-06-11 09:40:01.994244
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    data = {}
    a = FieldAttributeBase(name='name', description='description', default=data, always_post_validate=True)
    # a.dump_me()
    # Add tests here
    assert False



# Generated at 2022-06-11 09:40:10.511363
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    base=Base()
    task_include=TaskInclude()
    task_include._ds=None
    task_include._parent=None
    base._parent=task_include
    block=Block()
    block._role_path='abc'
    base._parent._dep_chain=[]
    base._parent._dep_chain.append(block)
    base._parent._role_path="xyz"

# Generated at 2022-06-11 09:40:14.665135
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fab = FieldAttributeBase()
    conn = Connection()
    fab.get_validated_value("name", type("attribute", (object,), {"isa": "string", "required": False, "static": False}), "value", conn)
    
    

# Generated at 2022-06-11 09:40:24.304145
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:40:33.625551
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    f = FieldAttributeBase()
    ds = u'my_ds'
    my_arg = u'my_arg'
    my_value = u'my_value'
    my_attr = u'my_attr'
    my_class = u'my_class'
    my_obj = u'my_obj'
    my_obj2 = u'my_obj2'
    # Try calling it with a dictionary
    ds_type = type(ds)
    ds_type2 = type(ds)
    # Create a mock of the returned object
    ds2 = mock.Mock()
    ds2._attributes = {}
    ds_proxy = mock.Mock()
    ds_proxy.__getitem__ = lambda self, key: my_obj2

# Generated at 2022-06-11 09:40:42.876626
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    # Arguments for FieldAttributeBase
    field_attribute_base_args = {
        'required': True,
        'default': None,
        'static': True,
        'private': False,
        'always_post_validate': True,
    }

    # Instantiating a FieldAttributeBase object
    field_attribute_base = FieldAttributeBase(**field_attribute_base_args)

    # Calling the validate method
    value = list()
    field = 'field_name'
    actual_output = field_attribute_base.validate(value, field)
    expected_output = list()

    if actual_output != expected_output:
        raise AssertionError(
            'Expected: {}\nActual:   {}'.format(
                expected_output,
                actual_output,
            )
        )




# Generated at 2022-06-11 09:40:44.770902
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    foo = FieldAttributeBase()
    assert isinstance(foo.dump_attrs(), dict)

# Generated at 2022-06-11 09:40:55.491612
# Unit test for method get_path of class Base
def test_Base_get_path():
    # test for method get_path of class Base
    # This class is a baseclass for several other classes
    # It does not have any functionality that is testable within
    # the context of unit tests.
    # Test for method get_path of class Base
    # will test that that its return value is the expected value for
    # that method.

    # Create a mock object for use in the test
    class test_Base(Base):
        def __init__(self):
            self._ds = mock.Mock()
            self._ds._data_source = "test_data_source"
            self._ds._line_number = 1

    # run the get_path method and save the test results
    test_obj = test_Base()
    test_results = test_obj.get_path()

    # Check that test_results is the expected value

# Generated at 2022-06-11 09:41:06.289306
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.six import PY2
    if PY2:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf-8')

    b = Base()
    tqm = Base()
    play_context = PlayContext()
    play = Play()
    role_include = IncludeRole()
   

# Generated at 2022-06-11 09:41:16.520489
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.six import string_types
    valid_attrs = dict()
    valid_attrs.update(FieldAttributeBase.VALID_ATTRIBUTES)
    valid_attrs.update(FieldAttributeBase.SPECIAL_ATTRIBUTES)
    valid_attrs.update(FieldAttributeBase.DOCUMENTATION_ATTRIBUTES)
    valid_attrs.update(FieldAttributeBase.COMMON_ATTRIBUTES)
    def __init__(self):
        self

# Generated at 2022-06-11 09:41:45.593710
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    new_fa = FieldAttributeBase()
    data = {}

    # TODO investigate other ways to test this method
    try:
        new_fa.load_data(data)
    except:
        pass


# Generated at 2022-06-11 09:41:53.510645
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    foo = FieldAttributeBase()
    assert foo.validate(1) is True
    assert foo.validate(0) is True
    assert foo.validate(None) is True
    assert foo.validate('foo') is True
    assert foo.validate('bar') is True
    assert foo.validate(['foo', 'bar']) is True
    assert foo.validate(['foo', 'bar']) is True
    assert foo.validate('foo', required=True) is True
    assert foo.validate('bar', required=True) is True
    assert foo.validate(['foo', 'bar'], required=True) is True
    assert foo.validate(['foo', 'bar'], required=True) is True



# Generated at 2022-06-11 09:41:59.614984
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase(
        [dict(name='name0'), dict(name='name1'), dict(name='name2')],
        name='name',
    )
    assert obj == [dict(name='name0'), dict(name='name1'), dict(name='name2')]
    obj.squash()
    assert obj == [dict(name='name0'), dict(name='name1'), dict(name='name2')]

# Generated at 2022-06-11 09:42:11.773041
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class TestException(Exception):
        pass

    class StringAttribute(FieldAttributeBase):
        def __init__(self):
            self._instance = None

        def set_instance(self, instance):
            self._instance = instance

        def get_instance(self):
            return self._instance

        def __get__(self, instance, owner):
            return self.get_instance()

        def __set__(self, instance, value):
            self.set_instance(value)

        def is_template(self):
            return isinstance(self.get_instance(), string_types)

        def finalize(self, templar):
            if not self.is_template():
                return

            value = templar.template(self.get_instance())
            if value == 'raise_exception':
                raise TestException()

           

# Generated at 2022-06-11 09:42:18.934863
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FAIO = FieldAttributeBase(name="FAIO", required=False, default=True)
    FABO = FieldAttributeBase(name="FABO", required=False, default='')
    FAFS = FieldAttributeBase(name="FAFS", required=False, default='FAFS', isa='string')
    FAFI = FieldAttributeBase(name="FAFI", required=False, default=12, isa='int')
    FAFFLOAT = FieldAttributeBase(name="FAFFLOAT", required=False, default=12.1, isa='float')
    FAFBOOL = FieldAttributeBase(name="FAFBOOL", required=False, default=True, isa='bool')
    FAFPERCENT = FieldAttributeBase(name="FAFPERCENT", required=False, default=12, isa='percent')

# Generated at 2022-06-11 09:42:22.643375
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for FieldAttributeBase.dump_me
    '''

    repr = repr(AttributeName)

    # Can't really assert on anything here, just check that the method didn't error
    assert True


# Generated at 2022-06-11 09:42:32.722429
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # Make a temporary module that is any subclass of FieldAttributeBase
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    class_dict = {FieldAttributeBase._FieldAttributeBase__class_registry.popitem()[0]: FieldAttributeBase}
    FieldAttributeBase = type('FieldAttributeBase', (FieldAttributeBase, object), class_dict)
    module = type('FieldAttributeBase', (object,), class_dict)

    # Load the FieldAttributeBase class attributes into the module dict
    module.__dict__.update(FieldAttributeBase.__dict__)
    module.__name__ = FieldAttributeBase.__name__

    # Load the FieldAttributeBase module into the AnsibleCollectionLoader
    loader = AnsibleCollectionLoader()
    loader._modules[(__name__, module.__name__)] = module

    # Setup the FieldAttributeBase

# Generated at 2022-06-11 09:42:42.593030
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    play_obj = Play.load(dict(name='foo',
                              hosts='all',
                              roles=[]))

# Generated at 2022-06-11 09:42:46.722040
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    fieldattributebase = FieldAttributeBase()
    with pytest.raises(NotImplementedError) as excinfo:
        fieldattributebase.squash()
    assert to_native(excinfo.value) == 'squash method not implemented'

# Generated at 2022-06-11 09:42:49.570126
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # BaseMeta.__new__(name, parents, dct)
    # TODO: implementation of BaseMeta test
    pass


# Generated at 2022-06-11 09:43:16.199170
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """Test post_validate method.

        This test does not use pytest asserts, because it does not
        call the tested function, but rather returns the exception
        that should be raised.
        The method is called in an outer scope, so all the variables
        are correctly defined, and the exception is correctly raised.
    """
    # This method will be called with self=self, attribute=attribute,
    # value=value, templar=templar, and will return value
    def _post_validate_test_value(self, attribute, value, templar):
        return value
    # This method will be called with self=self, attribute=attribute,
    # task_vars=task_vars, templar=templar, and will return self.vars

# Generated at 2022-06-11 09:43:25.391935
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field = FieldAttributeBase(
        none_type, null=True
    )

    assert field.dump_me() == {
        'null': True,
        'static': False,
        'display': None,
        'doc': None,
        'required': False,
        'default': None,
        'choices': None,
        'version_added': None,
        'version_removed': None,
        'aliases': [],
        'always_post_validate': False,
        'deprecated_aliases': [],
        'type': 'none',
        'class_type': None,
        'listof': None,
    }


# Generated at 2022-06-11 09:43:31.398560
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    def fake_task_squash():
        return "fake_task_squash"

    def fake_block_squash():
        return "fake_block_squash"

    def fake_play_role_squash():
        return "fake_play_role_squash"

    def fake_play_host_squash():
        return "fake_play_host_squash"

    def fake_not_squash():
        return "fake_not_squash"

    def fake_attribute_squash():
        return "fake_attribute_squash"

    def fake_attribute_post():
        return "fake_attribute_post"


    class Base:
        def __init__(self):
            pass

        def get_ds(self):
            return "get_ds"


# Generated at 2022-06-11 09:43:34.606543
# Unit test for method get_path of class Base
def test_Base_get_path():
    t = Base()
    t._ds = DummyDS()
    t._ds._data_source = 'foo'
    t._ds._line_number = 1
    assert t.get_path() == 'foo:1'



# Generated at 2022-06-11 09:43:43.694680
# Unit test for method from_attrs of class FieldAttributeBase

# Generated at 2022-06-11 09:43:50.423373
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    FieldAttributeBase = FieldAttribute()
    __instance = FieldAttributeBase
    # Test exceptions
    try:
        __instance.from_attrs()
        raise AssertionError('AnsibleAssertionError not raised')
    except AnsibleAssertionError as e:
        # the code should be different than 0
        if e.code == 0:
            raise AssertionError('AnsibleAssertionError code 0 does not match')

    # Test default return
    assert __instance.from_attrs() is None, 'Return value does not match'

# Generated at 2022-06-11 09:43:59.998334
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_text
    from ansible.utils.vars import combine_vars

    args_parser = ModuleArgsParser(VARIABLE_MANAGER=VariableManager(),
                                   LOADER=loader,
                                   INVENTORY_MANAGER=InventoryManager())
    templar = Templar(loader=loader,
                      variables=VariableManager())
    hostvars = dict()

    task = Task()
    task.vars = dict()

    templar._available_vari

# Generated at 2022-06-11 09:44:10.157284
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pb = Playbook()
    p1 = Play.load(dict(
        name="p1",
        hosts='all',
        gather_facts='no',
        roles=[]
    ), pb, pb)
    t1 = Task.load(dict(
        name="t1",
        debug=dict(
            var=1
        )
    ), p1, p1)
    assert t1.get_dep_chain() == []
    r1 = Role()
    p1.dependencies = [r1]
    p1.post_validate()
    assert r1.get_dep_chain() == [r1]
    assert t1.get_dep_chain() == [r1]
    r2 = Role()
    r1.dependencies = [r2]
    r1.post_validate

# Generated at 2022-06-11 09:44:12.841479
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    attr = 'testattr'
    with pytest.raises(AnsibleAssertionError):
        obj.copy(attr)

# Generated at 2022-06-11 09:44:19.995918
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar

    # Initialize a vault for any test that needs it.

# Generated at 2022-06-11 09:44:55.990560
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Test post_validate method of class FieldAttributeBase
    '''
    # Create an instance of class FieldAttributeBase
    my_FieldAttributeBase = FieldAttributeBase()
    # Test the state of my_FieldAttributeBase
    assert my_FieldAttributeBase.name == 'FieldAttributeBase'
    assert my_FieldAttributeBase.private == False
    assert my_FieldAttributeBase.required == False
    assert my_FieldAttributeBase.always_post_validate == False
    assert my_FieldAttributeBase.isa == None
    assert my_FieldAttributeBase.default == None
    assert my_FieldAttributeBase.listof is None
    assert my_FieldAttributeBase.static == False
    assert my_FieldAttributeBase.class_type is None
    assert my_FieldAttributeBase.validate is None



# Generated at 2022-06-11 09:44:57.997930
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase()
    assert f.dump_attributes() == {}


# Generated at 2022-06-11 09:45:01.884429
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    """Unit test for method FieldAttributeBase.validate of class FieldAttributeBase"""
    a = FieldAttributeBase()
    assert not a.validate()

    a.isa = 'class'
    assert not a.validate()

    a.isa = 'foo'
    assert a.validate()


# Generated at 2022-06-11 09:45:11.749618
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    class test_obj(FieldAttributeBase):

        class AttributeError(Exception):
            pass

        def __init__(self):
            pass

    field_attribute = test_obj()
    # Test the case with attrname is not a string or unicode
    with pytest.raises(AnsibleAssertionError) as cm:
        field_attribute.load_data(123, 'value_to_set')
    assert to_native(cm.value) == 'attrname should be a string but is a int'

    # Test the case with value is not a supported Ansible object
    with pytest.raises(AnsibleAssertionError) as cm:
        field_attribute.load_data('attr_name', 123)

# Generated at 2022-06-11 09:45:14.083624
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_obj = FieldAttributeBase()

    assert test_obj.dump_me() == {'ignore_errors': False, 'default': None}

# Generated at 2022-06-11 09:45:19.533100
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase(string='/')
    data = {'uuid': 'uuid1', 'finalized': False, 'squashed': False, 'string': '/'}
    obj.deserialize(data)
    assert obj._uuid == 'uuid1'
    assert obj._finalized == False
    assert obj._squashed == False

# Generated at 2022-06-11 09:45:23.543582
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base=Base()
    # test case 1
    assert base.get_dep_chain() == None
    # test case 2
    base._parent=Base()
    assert base.get_dep_chain() == None
    # test case 3
    base._parent._play=Base()
    assert base.get_dep_chain() == None


# Generated at 2022-06-11 09:45:25.219714
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    my_fieldattributebase = FieldAttributeBase()

    # Ensure that the validate method is available
    assert hasattr(my_fieldattributebase, 'validate')
    assert callable(getattr(my_fieldattributebase, 'validate'))


# Generated at 2022-06-11 09:45:27.058907
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fieldbase = FieldAttributeBase()
    assert fieldbase.dump_attrs() == {}



# Generated at 2022-06-11 09:45:29.449816
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    obj = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        obj.post_validate(templar=obj)

# Generated at 2022-06-11 09:46:06.022622
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    my_block = FieldAttributeBase()

    with pytest.raises(NotImplementedError):
        my_block.post_validate(None)

