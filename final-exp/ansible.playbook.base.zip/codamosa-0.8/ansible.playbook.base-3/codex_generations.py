

# Generated at 2022-06-11 09:37:20.086460
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # TODO: implement this test.
    import pytest
    pytest.fail()

# Generated at 2022-06-11 09:37:28.122959
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    import ansible.parsing.yaml.objects
    
    # Initialization of test data
    self = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject()
    self._loader = ""
    self._variable_manager = ""
    self._validated = ""
    self._finalized = ""
    self._uuid = ""
    self._valid_attrs = {}
    self._alias_attrs = {}
    self._attributes = {}
    self._attr_defaults = {}
    name = ""
    attribute = ""
    value = ""
    templar = ""
    
    # initialize the object with values from test data
    self._loader = ""
    self._variable_manager = ""
    self._validated = ""
    self._finalized = ""
    self._uuid

# Generated at 2022-06-11 09:37:30.576890
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method load_data of class FieldAttributeBase
    '''
    collection = FieldAttributeBase()
    assert not collection.load_data()



# Generated at 2022-06-11 09:37:36.813029
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Setup
    self=FieldAttributeBase()
    name='name'
    attribute='attribute'
    value='value'
    templar='templar'
    expected_type_error=False
    expected_value_error=False
    expected=None
    # Exercise
    # Result
    try:
        actual = self.get_validated_value(name, attribute, value, templar)
    except Exception as e:
        actual = e
        if isinstance(actual, TypeError):
            expected_type_error = True
        if isinstance(actual, ValueError):
            expected_value_error = True

    if not expected_type_error and not expected_value_error:
        assert actual == expected
    if expected_type_error:
        assert isinstance(actual, TypeError)

# Generated at 2022-06-11 09:37:42.302956
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase("test_FieldAttributeBase_copy")
    obj.class_type = ModuleDeprecationWarning
    obj.default = datetime
    obj.always_post_validate = False
    obj.class_only = False
    obj.display = 'module_deprecation_warning_display'
    obj.filter_type = 'module_deprecation_warning_filter_type'
    obj.filter_choices = object
    obj.filter_mutually_exclusive = object
    obj.filter_required = False
    obj.filter_relates = object
    obj.filter_version = 'module_deprecation_warning_filter_version'
    obj.filter_hints = object
    obj.filter_naming = 'module_deprecation_warning_filter_naming'
    obj.filter_converter

# Generated at 2022-06-11 09:37:50.690292
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fixture = LoaderModuleFixture()
    obj = fixture.load_module('ansible_collections.ansible.community.plugins.module_utils.ansible_free_form.FieldAttributeBase')

    actual = obj.dump_me()

    assert actual == dict(
        name='FieldAttributeBase',
        required=False,
        default=None,
        always_post_validate=False,
        alias=None,
        removed_in_version=None,
        isa=None,
        class_type=None,
        post_validate=None,
        listof=None
    )

# Generated at 2022-06-11 09:38:03.862725
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    #################################
    #
    # Setup test cases
    #
    #################################

    # Test 1 - test of copy attribute with no fields set
    #
    # FieldAttributeBase with (name = None, default = None, include = None, exclude = None, include_global = None, exclude_global = None, exclude_unsupported = False, omit = False, always_post_validate = False)
    test_obj = FieldAttributeBase(name = None, default = None, include = None, exclude = None, include_global = None, exclude_global = None, exclude_unsupported = False, omit = False, always_post_validate = False)
    test_obj_copy = test_obj.copy()

    # equality test
    assert test_obj == test_obj_copy

    # equality test
    assert test_obj is not test_obj_copy

# Generated at 2022-06-11 09:38:12.573122
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    mock_task = MockBase()
    mock_task._parent = None
    assert mock_task.get_dep_chain() == None

    mock_task2 = MockBase()
    mock_task2._parent = mock_task
    assert mock_task2.get_dep_chain() == None

    mock_task3 = MockBase()
    mock_task3._parent = mock_task2
    assert mock_task3.get_dep_chain() == None

    dep_chain = [mock_task, mock_task2, mock_task3]
    mock_task3._parent = None
    assert mock_task3.get_dep_chain() == dep_chain



# Generated at 2022-06-11 09:38:16.056138
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_obj = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        test_obj.validate()

#Unit test for method _dump_attrs of class FieldAttributeBase

# Generated at 2022-06-11 09:38:24.937212
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    class DummyAttribute(FieldAttributeBase):
        class_type = 'DummyAttribute'

    d = DummyAttribute()
    assert d._name is None
    assert d.aliases == []
    assert d.class_type == 'DummyAttribute'
    assert d.default is None
    assert d.required is False
    assert d.static is False
    assert d.always_post_validate is False
    assert d.listof is None
    assert d.isa == 'class'

    class DummyAttribute(FieldAttributeBase):
        class_type = 'DummyAttribute'
        isa = 'dict'

    d = DummyAttribute()
    assert d._name is None
    assert d.aliases == []
    assert d.class_type == 'DummyAttribute'
    assert d.default is None
    assert d.required

# Generated at 2022-06-11 09:39:02.748257
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FA = FieldAttributeBase()
    attr = FieldAttribute(isa='int', required=True)
    assert FA.get_validated_value("name",  attr, "1", None) == 1
    attr = FieldAttribute(isa='float', required=True)
    assert FA.get_validated_value("name",  attr, "3.14", None) == 3.14
    attr = FieldAttribute(isa='bool', required=True)
    assert FA.get_validated_value("name",  attr, "True", None) == True
    assert FA.get_validated_value("name",  attr, "False", None) == False
    assert FA.get_validated_value("name",  attr, "t", None) == True

# Generated at 2022-06-11 09:39:09.753408
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class Foo(object):
        attributes = dict(attr1 = FieldAttribute())
    x = Foo(attr1 = "Hello")
    y = Foo(attr1 = 1)
    assert y.get_validated_value(name='attr1', attribute = y.attributes['attr1'], value = 1, templar = None) == 1
    assert y.get_validated_value(name='attr1', attribute = y.attributes['attr1'], value = "2", templar = None) == 2


# Generated at 2022-06-11 09:39:10.868028
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    attr = FieldAttributeBase()
    
    


# Generated at 2022-06-11 09:39:11.500501
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass

# Generated at 2022-06-11 09:39:21.244088
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import ansible.module_utils.six
    assert ansible.module_utils.six.PY2, 'Method get_dep_chain of class Base is not supported on PY3'
    # TODO: Implement test case for function: _get_uuid of class Base

    # TODO: Implement test case for function: _get_parent of class Base

    # TODO: Implement test case for function: _get_ds of class Base

    # TODO: Implement test case for function: __init__ of class Base

    # TODO: Implement test case for function: get_validated_value of class Base

    # TODO: Implement test case for function: post_validate of class Base

    # TODO: Implement test case for function: _load_vars of class Base

    # TODO: Implement test case for function: _extend_value of class

# Generated at 2022-06-11 09:39:22.343578
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase()


# Generated at 2022-06-11 09:39:30.035723
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Testing with an instance of class FieldAttributeBase
    # test obj, type is a class
    FA = FieldAttributeBase('name', class_type=str)
    # str as that is what class_type takes.
    FA._validate_class_type(FA.class_type, FA.name)

    # test obj, type is not a class
    FA = FieldAttributeBase('name', class_type='not a class')
    # ValueError as class_type is not a class
    FA._validate_class_type(FA.class_type, FA.name)



# Generated at 2022-06-11 09:39:38.294761
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    target = FieldAttributeBase('test')
    target.aliases = ['test']
    target.name = 'test'
    target.required = False
    target.static = False
    target.callbacks = {}
    target.default = None
    target.always_post_validate = True
    source = FieldAttributeBase('test')
    source.aliases = ['test']
    source.name = 'test'
    source.required = False
    source.static = False
    source.callbacks = {}
    source.default = None
    source.always_post_validate = True
    result = target.copy(source)
    assert isinstance(result, FieldAttributeBase)


# Generated at 2022-06-11 09:39:42.417915
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    host = 'testhost'
    play = Play().load({}, variable_manager=VariableManager(), loader=Mock())
    task = Task()
    task.name = 'setup'
    task.action = 'setup'
    task.args = {}
    play.add_task(task)
    play.post_validate(templar=Mock())
    play.handlers = []
    assert play.play_hosts == [host]
    


# Generated at 2022-06-11 09:39:45.246448
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test functional test.
    #
    # This simple test ensures the functional test itself is working.
    assert True

# Generated at 2022-06-11 09:40:21.204455
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Run unit test for method get_validated_value of class FieldAttributeBase
    fab = FieldAttributeBase(required=True, isa='int')
    '''
    Test the use of None for value
    '''
    setattr(fab, 'required', False)
    res = fab.get_validated_value(name='key1', attribute=None, value=None, templar=None)
    assert res is None, 'Expected result to be None, but got %s' % (res,)
    '''
    Test the use of an integer for value
    '''
    setattr(fab, 'required', True)
    res = fab.get_validated_value(name='key1', attribute=None, value=3, templar=None)

# Generated at 2022-06-11 09:40:30.625685
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import isidentifier
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.parsing.convert_bool import boolean
    b = FieldAttributeBase(always_post_validate=True)
    # test post-validate_vars
    setattr(b, 'vars', {'foo': {'a': 'b'}})
    ds = dict()
    ds['vars'] = {'foo': {'a': 'b'}}


# Generated at 2022-06-11 09:40:31.226537
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass

# Generated at 2022-06-11 09:40:40.516930
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    import ansible.parsing.dataloader
    # Method accepts three arguments
    attr = FieldAttributeBase('name', description='desc', always_post_validate=True)
    assert attr.always_post_validate is True
    assert attr._validator is None
    assert attr._transform is None

    # If the method _post_validate_<name> presents in the object,
    # calls it
    obj = MyObject()
    obj._post_validate_name = MagicMock()
    obj.post_validate(None)
    assert obj._post_validate_name.called

    # If the attribute contains a variable, calls templar.template on it
    obj._post_validate_name.side_effect = None

# Generated at 2022-06-11 09:40:42.608164
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field = FieldAttributeBase()
    repr = field.dump_attrs()
    assert repr == None, repr


# Generated at 2022-06-11 09:40:45.290020
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field = FieldAttributeBase()
    try:
        field.validate(None)
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 09:40:56.105774
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create a mock object
    fieldattributebase_mock = FieldAttributeBase()

    # Create a mock object
    fieldattribute_mock = FieldAttribute(
        include_defaults=False,
        required=False,
        static=False,
        always_post_validate=False,
        isa=None,
        exclude_parent=False,
        default=None,
        listof=None,
        version_added=None,
        version_removed=None,
        deprecated_for=None,
        deprecated_since=None,
        removed_in=None,
        class_type=None,
        expand_more=False,
        allow_duplicates=False,
        validate=None)

    # Mock _valid_attrs method (returns a dict of attr:FieldAttribute)

# Generated at 2022-06-11 09:40:58.074457
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    play_instance = Base()
    assert play_instance.get_dep_chain() is None



# Generated at 2022-06-11 09:41:00.836582
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    ds = b'foo'
    obj.set_ds(ds)
    assert obj.get_ds() == ds

# Generated at 2022-06-11 09:41:05.840368
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    objAttrBase = FieldAttributeBase(description='description', required=False, always_post_validate=True, omit=None)
    try:
        objAttrBase.post_validate(templar=None)
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)
    return True


# Generated at 2022-06-11 09:41:27.936006
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-11 09:41:36.016645
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_object = FieldAttributeBase('test')
    old_value = test_object
    name = 'test'
    attribute = test_object
    value = 'test'
    templar = MagicMock()
    result = test_object.get_validated_value(name, attribute, value, templar)
    assert isinstance(result, to_text) == True
    assert isinstance(result, to_bytes) == False
    assert result == 'test'
    assert test_object == old_value

# Generated at 2022-06-11 09:41:47.691673
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from units.mock.loader import DictDataLoader

# Generated at 2022-06-11 09:41:55.013786
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # Tests for BaseMeta.__new__
    bm = BaseMeta("BaseMeta", (), {})
    class testBase(Base):
        _valid_attrs = {"_attributes": "", "_attr_defaults": "", "_valid_attrs": "", "_alias_attrs": ""}
    # bm.__new__(BaseMeta, "BaseMeta", (), {})
    test_cls = bm.__new__(bm, "testBase", (testBase,), {"_attributes": {}, "_attr_defaults": {}, "_valid_attrs": {}, "_alias_attrs": {}})
    # test_cls.__new__(test_cls, "testBase", (testBase,), {"_attributes": "", "_attr_defaults": "", "_valid_attrs": "", "_alias

# Generated at 2022-06-11 09:41:58.693368
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    args = dict(
        required=False,
        name='validate',
        aliases=['validate'],
        default=None,
    )
    obj = FieldAttributeBase(**args)
    assert obj

# Generated at 2022-06-11 09:42:10.794145
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class TestBase(Base):
        pass
    class TestBaseParent(Base):
        pass
    class TestBaseDependency(Base):
        pass
    a = TestBase()
    b = TestBase()
    c = TestBase()
    d = TestBase()
    e = TestBaseParent()
    a._ds = type('FakeDS', (object,), {'_data_source': '/dir/dir/dir/dir/dir', '_line_number': 1})
    b._ds = type('FakeDS', (object,), {'_data_source': '/dir/dir/dir/dir/dir/dir', '_line_number': 2})

# Generated at 2022-06-11 09:42:15.050572
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    FA = FieldAttributeBase
    f = FA(isa='foo', required=True)
    assert f.post_validate(None) is None # NOQA
    f.get_validated_value = lambda *a, **kw: None
    assert f.post_validate(None) is None # NOQA


# Generated at 2022-06-11 09:42:18.837109
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
  loader = dict()
  variable_manager = dict()
  data = dict()
  f = FieldAttributeBase( loader=loader, variable_manager=variable_manager )
  f.load_data(data)



# Generated at 2022-06-11 09:42:29.502875
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test load_data of ansible.parsing.yaml.objects.AnsibleUnicode
    myobj = AnsibleUnicode('mytest')
    data = myobj.load_data('mytest')
    assert 'mytest' == data, "Test case failed"
    assert 'mytest' == repr(data), "Test case failed"

    # test load_data of ansible.parsing.yaml.objects.AnsibleSequence
    myobj = AnsibleSequence([])
    data = myobj.load_data([])
    assert [] == data, "Test case failed"
    assert '[]' == repr(data), "Test case failed"

    # test load_data of ansible.parsing.yaml.objects.AnsibleMapping
    myobj = AnsibleMapping({})
   

# Generated at 2022-06-11 09:42:38.731364
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for class FieldAttributeBase
    '''

    data = {
        '_instance': None,
        '_name': 'required',
        '_class_type': None,
        '_required': True,
        '_default': None,
        '_aliases': [],
        '_inherit': True,
        '_private': False,
        '_vars': None,
        '_static': False,
        '_always_post_validate': False,
        '_serialize': True,
        '_internal': False
    }

    dump_me = FieldAttributeBase().dump_me()

    assert dump_me == data


# Generated at 2022-06-11 09:43:05.849558
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_FieldAttributeBase = FieldAttributeBase()
    FieldAttributeBase.validate(test_FieldAttributeBase)

# Generated at 2022-06-11 09:43:08.033038
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase()
    obj.squash = MagicMock()
    obj.squash.return_value = "foo"
    result = obj.squash()
    assert result == "foo"


# Generated at 2022-06-11 09:43:10.053756
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    c = FieldAttributeBase()
    c._valid_attrs = {'foo':'bar'}
    assert c.dump_attrs() == {'foo':'bar'}

# Generated at 2022-06-11 09:43:11.516086
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # TODO implement unit test
    # assert FieldAttributeBase: post_validate(self, templar)
    assert False # Implement me

# Generated at 2022-06-11 09:43:14.758018
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    assert FieldAttributeBase(init_default=True, always_post_validate=True, class_type=None, isa=None, listof=None, required=True).copy('attr', 'value') == {'always_post_validate': True, 'class_type': None, 'init_default': True, 'isa': None, 'listof': None, 'name': 'attr', 'required': True}

# Generated at 2022-06-11 09:43:25.603125
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.register_type('bool', FieldAttributeType.BOOL)
    field_attribute_base.register_type('string', FieldAttributeType.STRING)
    field_attribute_base.register_type('int', FieldAttributeType.INT)
    field_attribute_base.register_type('float', FieldAttributeType.FLOAT)
    field_attribute_base.register_type('list', FieldAttributeType.LIST)
    assert field_attribute_base.validate('dict', 'string') is None
    assert field_attribute_base.validate('bool', 'string') is None
    assert field_attribute_base.validate('string', 'string') is None
    assert field_attribute_base.validate('int', 'string') is None
    assert field_attribute_base

# Generated at 2022-06-11 09:43:27.980810
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    task = Task()
    task.deserialize({'name': 'my name', 'vars': {}})
    assert task.name == "my name"
    assert task.vars == {}


# Generated at 2022-06-11 09:43:29.347696
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    raise SkipTest  # TODO: implement your test here


# Generated at 2022-06-11 09:43:34.484429
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.base import Base
    loader = DataLoader()
    variable_manager = VariableManager()
    obj = Base(loader=loader, variable_manager=variable_manager)
    try:
        obj.dump_me()
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-11 09:43:43.574350
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from .loader import DataLoader

    loader = DataLoader()
    fabb = FieldAttributeBase()
    new_fabb = fabb.copy()

    assert fabb._vars == new_fabb._vars, "Expected _vars to be %s but got %s" % (fabb._vars, new_fabb._vars)
    assert fabb._loader == new_fabb._loader, "Expected _loader to be %s but got %s" % (fabb._loader, new_fabb._loader)
    assert fabb._variable_manager == new_fabb._variable_manager, "Expected _variable_manager to be %s but got %s" % (fabb._variable_manager, new_fabb._variable_manager)

# Generated at 2022-06-11 09:44:19.204866
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 09:44:25.329233
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    print('Test get_validated_value')
    my_field_attr = FieldAttributeBase()
    attr = 'My Attribute'
    value = 'My value'
    templar = 'My templar'
    assert my_field_attr.get_validated_value(attr, my_field_attr, value, templar) is None

# Generated at 2022-06-11 09:44:26.440321
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass


# Generated at 2022-06-11 09:44:30.774715
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attr = FieldAttribute()
    obj = FieldAttributeBase()
    ds = {'test': 'string'}

    attr.type = 'str'
    assert obj.get_validated_value('name', attr, 'value', ds) == 'value'



# Generated at 2022-06-11 09:44:40.608018
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    p = Base()
    p.from_attrs({})
    assert deep_eq(p.serialize(),
                   {'_finalized': True,
                    '_squashed': False,
                    '_uuid': None})

    data = {'_uuid': str(uuid.uuid4()), '_finalized': True}
    data.update({'_valid_attrs': {'foo': FieldAttribute(isa='int', default=42)}})
    p = Base()
    p.deserialize(data)
    assert deep_eq(p.serialize(),
                   {'foo': 42,
                    '_finalized': True,
                    '_squashed': False,
                    '_uuid': data['_uuid']})


# Generated at 2022-06-11 09:44:44.129787
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method FieldAttributeBase.load_data of class FieldAttributeBase
    '''
    f = FieldAttributeBase()
    assert main.load_data(f, None, 'foo') == 'foo'
    assert main.load_data(f, None, 'foo') == 'foo'


# Generated at 2022-06-11 09:44:53.932058
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    args = dict(
        no_log=dict(default=False),
        always_run=dict(default=False),
    )

# Generated at 2022-06-11 09:44:55.444860
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    reload(FieldAttributeBase)
    reload(FieldAttributeBase)


# Generated at 2022-06-11 09:45:04.931488
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    import collections
    import inspect
    import sys

    old_counter = FieldAttributeBase._uuid_counter
    FieldAttributeBase._uuid_counter = 0


# Generated at 2022-06-11 09:45:08.268622
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    ###############
    #Creating new parent variable and making it as task instance
    parent = 'parent'
    task = Task()
    task._parent = parent
    assert task.get_dep_chain() == parent
    ###############


# Generated at 2022-06-11 09:46:04.864727
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # TODO: Please add unit test for method validate of class FieldAttributeBase
    pass

# Generated at 2022-06-11 09:46:13.387974
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from yaml import load
    from ansible.playbook.play import Play
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])