

# Generated at 2022-06-11 09:36:54.618076
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    Unit test for method get_validated_value of class FieldAttributeBase
    '''
    from ansible.plugins.loader import ActionBase
    from ansible.inventory.host import Host

    # Make an instance of the class for testing
    action = ActionBase()

    # Make another instance of the class for testing
    host = Host()

    # Prepare the test data
    # test_data is a list of dictionaries.
    # Each dictionary has the following keys:
    #   desc - description of the test.
    #   field_name - the name of the field.
    #   isa - the isa attribute of the field.
    #   value - the value to be validated.
    #   result - the expected result of the test.
    #   exception - the expected exception of the test.
    #   exception_msg - the

# Generated at 2022-06-11 09:36:56.015100
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass
#

# Generated at 2022-06-11 09:37:07.269909
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar, AnsibleUndefinedVariable

    class MockVaultLib(object):
        @staticmethod
        def decrypt(encrypted):
            return encrypted

    class MockSystemRandom(object):
        @staticmethod
        def randint(low, high):
            return low

    FAIL_STRING = 'YOU SHOULDN\'T SEE THIS, SOMETHING FAILED'


# Generated at 2022-06-11 09:37:08.893986
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    args = dict(
    )
    cmd = FieldAttributeBase(**args)
    cmd.post_validate()


# Generated at 2022-06-11 09:37:14.455196
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from collections import Mapping

    task = Task()

    attrs = {
        'name': 'test',
        'connection': 'local',
        'hosts': ['localhost'],
        'roles': [],
        'vars': {},
        'block': None,
    }

    assert isinstance(task.dump_attrs(), Mapping)
    assert isinstance(task.from_attrs(attrs), Task)

    task.deserialize(attrs)
    assert isinstance(task.serialize(), Mapping)
    assert task.name == 'test'



# Generated at 2022-06-11 09:37:16.086771
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = dict()
    assert attrs == FieldAttributeBase(attrs).from_attrs(attrs)


# Generated at 2022-06-11 09:37:18.502201
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = dict()
    obj = FieldAttributeBase()
    obj.from_attrs(attrs)
    assert not obj._finalized
    assert not obj._squashed


# Generated at 2022-06-11 09:37:19.713134
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # test methods on FieldAttributeBase object
    pass


# Generated at 2022-06-11 09:37:21.328880
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # FieldAttributeBase - dump_attrs()
    my_FieldAttributeBase = FieldAttributeBase()


# Generated at 2022-06-11 09:37:29.082356
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
  from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleUnicode
  from ansible.parsing.yaml.constructor import AnsibleConstructor
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.task import Task
  #
  # create some test data
  #
  sample = '''
---
- hosts: localhost
  gather_facts: no
  tasks:
    - shell: /bin/echo hello
      register: echo
  pre_tasks:
    - debug: msg="hello"
  post_tasks:
    - debug: msg="goodbye"
'''

# Generated at 2022-06-11 09:37:58.964534
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    ret = FieldAttributeBase.dump_attrs()
    assert type(ret) == dict


# Generated at 2022-06-11 09:37:59.779073
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-11 09:38:02.211223
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    assert b.get_dep_chain() == None



# Generated at 2022-06-11 09:38:12.848723
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    import ansible.constants as C
    from ansible.module_utils.six import binary_type
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

    fake_ds = AnsibleMapping(
        loader=AnsibleLoader(
            stream=binary_type(
                'fake_ds_content'
            )
        ),
        constructor=AnsibleMapping,
        uri="file"
    )
    TestFields = type('TestFields', (FieldAttributeBase,), {})
    obj = TestFields()

# Generated at 2022-06-11 09:38:23.069120
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Fields should be validated for the right type
    arg1 = ''
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None
    arg9 = None

    with pytest.raises(AnsibleParserError) as excinfo:
        # Fields should be validated for the right type
        FieldAttributeBase.validate(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
    assert 'all fields must be defined' in str(excinfo.value)
    # Fields should be validated for the right type
    arg1 = 'A'
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
   

# Generated at 2022-06-11 09:38:27.019955
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    instance = FieldAttributeBase()
    # Test with no params
    result = instance.copy()
    assert result is not None and result != instance
    # Test with param
    result = instance.copy( '2' )
    assert result is not None and result != instance


# Generated at 2022-06-11 09:38:33.335161
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    data = dict()
    try:
        field_attribute_base.deserialize(data)
        assert False, "AnsibleAssertionError not raised"
    except AnsibleAssertionError as exc:
        assert exc.args[0] == 'data () should be a dict but is a <class \'dict\'>'

# Generated at 2022-06-11 09:38:43.604574
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class foo(object):
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}
        _get_attr_bar = lambda self: 'bar'
        _get_attr_baz = lambda self: 'baz'

    class Bar(Base, foo):

        baz = FieldAttribute(isa='str', inherit=True)
        bar = FieldAttribute(isa='str', inherit=False)

        def __init__(self):
            super(Bar, self).__init__()
    obj = Bar()
    obj.baz = 'mybaz'
    obj.bar = 'mybar'
    assert obj.baz == 'mybaz'
    assert obj.bar == 'mybar'



# Generated at 2022-06-11 09:38:49.072365
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase('foo')
    assert field_attribute_base.name == 'foo'
    assert field_attribute_base.isa == 'string'
    assert field_attribute_base.default == None
    assert field_attribute_base.required == True
    assert field_attribute_base.static == False
    assert field_attribute_base.always_post_validate == False


# Generated at 2022-06-11 09:38:53.876026
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Create my_task
    my_task = Task()

    # Perform test
    with pytest.raises(Exception) as excinfo:
        result = my_task.dump_me()
    assert 'Not implemented' in str(excinfo.value)


# Generated at 2022-06-11 09:39:34.970395
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # load_data method of FieldAttributeBase
    # TODO: Implement unit test

    pass

# Generated at 2022-06-11 09:39:40.281826
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase(default={"a": "x", "b": "y"})
    assert f.dump_me() == {'default': {'a': 'x', 'b': 'y'}, 'name': 'FieldAttributeBase', 'always_post_validate': False, 'static': False, 'required': False, 'prio': 0}


# Generated at 2022-06-11 09:39:52.205372
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    def _get_unnamed_class(ClassName, BaseClasses):
        class UnnamedClass(BaseClasses):
            pass
        UnnamedClass.__name__ = ClassName
        return UnnamedClass

    class_name = "class_name"
    mocker = Mocker()

    _get_unnamed_class(class_name, (object,))
    instance = FieldAttributeBase()
    data_dict = dict()
    data_dict['loader'] = mocker.mock()
    data_dict['loader'].get_basedir()
    mocker.result('loader_basedir')
    instance.load_data(data_dict)

    assert instance.loader == data_dict['loader']
    assert instance.basedir == 'loader_basedir'

# Generated at 2022-06-11 09:39:54.156575
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    f = FieldAttributeBase()
    assert isinstance(f.dump_attrs(), dict)
    assert f.dump_attrs() == {}

# Generated at 2022-06-11 09:39:57.823265
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    fixture = FieldAttributeBase(isa='class')
    value = Task()
    result = fixture.validate(value)
    assert result is not None
    assert result == value
    assert fixture is not None


# Generated at 2022-06-11 09:39:58.725713
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    pass

# Generated at 2022-06-11 09:40:00.481963
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    f = FieldAttributeBase()
    assert f.squash is False

# Generated at 2022-06-11 09:40:02.152971
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # FIXME: Try to test default parameter
    assert True


# Generated at 2022-06-11 09:40:12.585971
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # We'll use OrderedDict to ensure the output positions.
    expected = OrderedDict()
    
    # Test with an input that is an instance of FieldAttributeBase
    input = FieldAttributeBase(name='foo', help_text='msg for foo')
    output = input.validate()
    expected['name'] = 'foo'
    expected['alternative_names'] = []
    expected['help_text'] = 'msg for foo'
    expected['attr_type'] = None
    expected['static'] = False
    expected['required'] = False
    expected['default'] = None
    expected['always_post_validate'] = False
    expected['alt_required'] = []
    expected['choices'] = None
    expected['private'] = False
    expected['class_type'] = None
    assert output == expected

    # Test

# Generated at 2022-06-11 09:40:22.470071
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # builtins stub
    @ModuleType.register()
    class builtins():

        @staticmethod
        def hasattr(obj, name):
            if name == '__dict__':
                return True
            return False

        @staticmethod
        def type(obj):
            return obj.__class__

        @staticmethod
        def isinstance(obj, cls):
            return isinstance(obj, cls)

        @staticmethod
        def isidentifier(obj):
            return obj.isidentifier()

        @staticmethod
        def isstring(obj):
            return isinstance(obj, str)

        @staticmethod
        def islinestring(obj):
            return isinstance(obj, str)

        @staticmethod
        def islist(obj):
            return isinstance(obj, list)


# Generated at 2022-06-11 09:40:54.439180
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert Base().get_dep_chain() is None



# Generated at 2022-06-11 09:40:56.762974
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()
    assert obj
    obj.post_validate(templar=None)
    assert obj


# Generated at 2022-06-11 09:41:00.361990
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():

    # setup of mocks
    ds = Mock()
    self = Mock(ds=ds)

    # invocation of tested method
    result = FieldAttributeBase.get_ds(self)

    # assertions
    assert result == ds

# Generated at 2022-06-11 09:41:01.924875
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FieldAttributeBase().dump_attrs()


# Generated at 2022-06-11 09:41:07.196753
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    class FieldAttributeBaseSubClass(FieldAttributeBase):
        def __init__(self, **kwargs):
            super(FieldAttributeBaseSubClass, self).__init__(**kwargs)
            self._ds = None

    myFieldAttributeBaseSubClass = FieldAttributeBaseSubClass()
    assert myFieldAttributeBaseSubClass.get_ds() is None

# Generated at 2022-06-11 09:41:07.904227
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass

# Generated at 2022-06-11 09:41:18.116480
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    x = Play()
    x.vars = {'a': 'b'}
    x.vars_prompt = [dict(name='foo', prompt='bar', default='baz')]
    x.vars_files = ['/path/to/baz']
    x.hosts = 'host'
    x.post_validate(VariableManager)
    print("Dumping %s" % (x,))

# Generated at 2022-06-11 09:41:22.097815
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # set up
    field_attr = FieldAttributeBase()
    try: 
        # action
        field_attr.post_validate(templar=None)
    except:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-11 09:41:33.393859
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    assert base.get_search_path() == []
    class Task(Base):
        pass
    task = Task()
    task._ds = type('data_source', (object,), {'_data_source': 'data_source', '_line_number': 'line_number'})
    assert task.get_search_path() == ['data_source']
    task._parent = type('parent', (object,), {'_play': type('play', (object,), {'_ds': type('play_ds', (object,), {'_data_source': 'play_data_source', '_line_number': 'play_line_number'})})})
    assert task.get_search_path() == ['play_data_source']

# Generated at 2022-06-11 09:41:37.382699
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # FIXME: This test won't work because of the way squash works
    return

    # Test of the method squash for object FieldAttributeBase
    # A FieldAttributeBase object is created
    field = FieldAttributeBase()




# Generated at 2022-06-11 09:42:24.982130
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    a = FieldAttributeBase('foo', isa='bar', required=True)
    assert a.dump_me() == {'name': 'foo', 'required': True, 'isa': 'bar'}


# Generated at 2022-06-11 09:42:35.168595
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    file1 = StringIO()
    file2 = StringIO()
    file3 = StringIO()
    file4 = StringIO()

    (file1, file2, file3, file4) = prepare_playbooks(file1, file2, file3, file4)

    file1.name = 'file1.yml'
    file2.name = 'file2.yml'
    file3.name = 'file3.yml'
    file4.name = 'file4.yml'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test one play
   

# Generated at 2022-06-11 09:42:41.401979
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # BaseMeta.__new__() -> 'BaseMeta' object
    t = BaseMeta(name=list, parents=(list,), dct={})
    assert type(t).__dict__.get('_alias_attrs') is not None
    assert type(t).__dict__.get('_valid_attrs') is not None
    assert type(t).__dict__.get('_attr_defaults') is not None
    assert type(t).__dict__.get('_attributes') is not None



# Generated at 2022-06-11 09:42:42.255065
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert False, "No test for method get_dep_chain of class Base"


# Generated at 2022-06-11 09:42:53.794894
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()

    with pytest.raises(AnsibleParserError):
        obj.get_validated_value('foo', 'foo', 'foo', 'foo')

    obj.get_validated_value('foo', FieldAttribute('foo', default=10), 'foo', 'foo') == 10
    obj.get_validated_value('foo', FieldAttribute('foo', default=10), 10, 'foo') == 10
    obj.get_validated_value('foo', FieldAttribute('foo', default=10), True, 'foo') == 10
    obj.get_validated_value('foo', FieldAttribute('foo', default=10), 10.0, 'foo') == 10.0

    obj.get_validated_value('foo', FieldAttribute('foo', default=10), '10', 'foo') == 10

# Generated at 2022-06-11 09:43:03.026826
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    Test method get_dep_chain of class Base.
    '''

    # Tests for get_dep_chain method, also test get_search_path and get_path
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    test_obj = Base()
    test_obj._parent = Conditional()
    test_obj._parent._parent = Handler()
    test_obj._parent._parent._parent = Task()
    test_obj._parent._parent._parent._parent = Play()
    test_obj._parent._parent._parent._parent._parent

# Generated at 2022-06-11 09:43:04.579093
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    base_instance = Base()
    assert 0 == len(base_instance.get_search_path())



# Generated at 2022-06-11 09:43:05.198182
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    pass

# Generated at 2022-06-11 09:43:11.912856
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    # Create a new instance of FieldAttributeBase
    class FieldAttributeBaseClass(object):
        
        def __init__(self):
            pass
        
        def get_validated_value(self, name, attribute, value, templar):
            return 'some string'

    FieldAttributeBase = FieldAttributeBaseClass()
    FieldAttributeBase.name = "some string"
    FieldAttributeBase.default = "some string"
    FieldAttributeBase.required = True
    FieldAttributeBase.aliases = ["some string"]
    FieldAttributeBase.attrtype = "some string"
    FieldAttributeBase.attrname = "some string"
    FieldAttributeBase.always_post_validate = True
    FieldAttributeBase.static = True
    FieldAttributeBase.private = True
    FieldAttributeBase.versionadded = "some string"

# Generated at 2022-06-11 09:43:24.506437
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class A(Base):
        @classmethod
        def get_dep_chain(self):
            return dep_chain
    a = A()
    # test case 1
    dep_chain = [A(), A(), A()]
    tmp = a.get_search_path()
    assert tmp == [], "Search path is wrong. Expected [], but %s" % tmp
    print("Search path is correct. Expected [], got %s" % tmp)
    # test case 2
    dep_chain = []
    dep_chain[0] = A()
    dep_chain[0]._role_path = 'role1'
    dep_chain[1] = A()
    dep_chain[1]._role_path = 'role2'
    dep_chain[2] = A()
    dep_chain[2]._role

# Generated at 2022-06-11 09:44:23.347451
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_obj = FieldAttributeBase()
    attr = {'isa': 'string'}
    value = 'abc'
    templar = 'abc'
    assert test_obj.get_validated_value(attr, value, templar) == value
    attr = {'isa': 'int'}
    value = '1'
    templar = 'abc'
    assert test_obj.get_validated_value(attr, value, templar) == int(value)
    attr = {'isa': 'float'}
    value = '1.2'
    templar = 'abc'
    assert test_obj.get_validated_value(attr, value, templar) == float(value)
    attr = {'isa': 'float'}
    value = '1.2'


# Generated at 2022-06-11 09:44:31.566405
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test = FieldAttributeBase()
    test.required = None
    test.default = None
    test.always_post_validate = None
    test.isa = None
    test.choices = None
    test.static = None
    test.parse = None
    test.deprecated = None
    test.deprecated_aliases = None
    test.removed_in_version = None
    test.removed_at_date = None
    test.removed_from_collection = None

    print('NO TEST FOR test')
    # TODO: implement test



# Generated at 2022-06-11 09:44:35.633776
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Fetch a base object
    obj = FieldAttributeBase()
    # Get the value of each attribute
    assert obj.get_validated_value(obj, obj, obj, obj) == obj.get_validated_value(obj, obj, obj, obj)
    return

# Generated at 2022-06-11 09:44:44.600589
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    my_base = FieldAttributeBase()
    my_base.isa = 'list'

    assert my_base.validate(['a', 'b', 'c']) == (True, ['a', 'b', 'c'])
    assert not my_base.validate(['a', 'b', 'c'])[0]
    assert not my_base.validate('not a list')[0]
    assert not my_base.validate(42)[0]

    my_base.isa = 'string'
    assert my_base.validate('this is a string') == (True, 'this is a string')
    assert not my_base.validate(42)[0]
    assert not my_base.validate(['not', 'a', 'string'])[0]


# Generated at 2022-06-11 09:44:54.601015
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play_context import PlayContext

    base = Base()
    base._parent = PlayContext()
    base._parent.vars = dict(name='play_context_parent')
    base._parent._name = 'play_context_parent'
    base._parent._parent = None
    base._parent._ds = MockData()
    base.vars = dict(name='base')
    base._name = 'base'

    dep_chain = [PlayContext()]
    dep_chain[0].vars = dict(name='play_context1')
    dep_chain[0]._name = 'play_context1'
    dep_chain[0]._parent = base._parent
    dep_chain[0]._ds = MockData()

# Generated at 2022-06-11 09:44:58.174935
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    with pytest.raises(AssertionError, message="data (1) should be a dict but is a <class 'int'>"):
        FieldAttributeBase().from_attrs(1)

# ===========================================


# Generated at 2022-06-11 09:44:58.882981
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass

# Generated at 2022-06-11 09:45:02.043549
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        FA = FieldAttributeBase()
        FA.dump_me()
    assert 'not implemented by subclass' in str(excinfo.value)


# Generated at 2022-06-11 09:45:06.570765
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    ta = Task()
    assert ta._finalized == False
    assert ta._squashed == False
    attr_dict = dict(name='test')
    ta.from_attrs(attr_dict)
    assert ta.name == 'test'
    assert ta._finalized == True
    assert ta._squashed == True

# Generated at 2022-06-11 09:45:16.918572
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    attr = FieldAttributeBase()
    ansible = import_module('ansible')
    playbook = import_module('ansible.playbook')
    templar = import_module('ansible.template')
    obj = ansible.parsing.dataloader.DataLoader()
    obj.set_basedir('/root/ansible')
    obj.path_exists = lambda path: path == '/root/ansible'
    obj._data = {'key': {'name': 'value'}}
    obj.get_basedir = lambda: '/root/ansible'
    obj.path_dwim = lambda path: '/root/ansible/' + path
    obj.path_dwim_relative = lambda path, dirname, root: '/root/ansible/' + path
    var_manager = playbook.variable_