

# Generated at 2022-06-11 09:36:55.113790
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Test if method post_validate of class FieldAttributeBase works properly.
    '''
    # Create an instance of FieldAttributeBase
    field_a_base = FieldAttributeBase(
        name='foo',
        parent='bar',
        default='baz',
        #isa='int',
        hash=False,
        required=True,
    )

    # Test if method post_validate exists
    if not field_a_base.post_validate:
        raise AssertionError('FieldAttributeBase.post_validate: function does not exist')

    # Make sure AttributeError is raised when calling without arguments
    try:
        field_a_base.post_validate()
    except AttributeError:
        pass

# Generated at 2022-06-11 09:37:03.146589
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    def _call_method(self):
        return self.validate(None, None)
    # Empty instance
    obj = FieldAttributeBase()
    assert obj._attributes is None
    assert obj._initial_defaults == {}
    assert obj._validated == 0
    with pytest.raises(AttributeError):
        _call_method(obj)
    # Instance with attrs
    attrs = {
        'test_attribute': FieldAttribute(isa='bool', default=True),
        'test_attribute2': FieldAttribute(isa='list', default=[])
    }
    obj = FieldAttributeBase(attrs)
    assert obj._attributes == attrs
    assert obj._initial_defaults == {'test_attribute': True, 'test_attribute2': []}
    assert obj._validated == 0

# Generated at 2022-06-11 09:37:06.707204
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    foo = FieldAttributeBase()
    with pytest.raises(AnsibleParserError):
        foo.post_validate(templar=None)


# Generated at 2022-06-11 09:37:13.514682
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    data_in = { 'value': '23.04', 'attribute': FieldAttribute(isa='float'), 'templar' : None}
    from ansible.parsing.dataloader import DataLoader
    data_in['templar'] = Templar(loader=DataLoader())
    f = FieldAttributeBase('name', FieldAttribute(name='name', isa='float'))
    f._attributes['name'] = data_in['value']

    data_out = f.get_validated_value('name', data_in['attribute'], data_in['value'], data_in['templar'])
    assert data_out == 23.04



# Generated at 2022-06-11 09:37:14.865369
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    args = dict()
    obj = FieldAttributeBase()
    obj.from_attrs(args)




# Generated at 2022-06-11 09:37:18.117603
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    a = FieldAttributeBase()

    with pytest.raises(AnsibleAssertionError) as excinfo:
        a.deserialize("whatever")
    assert "data (whatever) should be a dict but is a <class 'str'>" in str(excinfo.value)



# Generated at 2022-06-11 09:37:21.957629
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase with default arguments
    obj = FieldAttributeBase()
    assert isinstance(obj, FieldAttributeBase)

    # call post_validate without arguments, run default case
    obj.post_validate()

    # Create an instance of FieldAttributeBase with some args
    obj = FieldAttributeBase(required=True)
    assert isinstance(obj, FieldAttributeBase)

    # call post_validate without arguments, run default case
    obj.post_validate()


# Generated at 2022-06-11 09:37:24.531675
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_obj = FieldAttributeBase()
    args = [1]
    kwargs = {}
    assert test_obj.validate(*args, **kwargs) == NotImplemented


# Generated at 2022-06-11 09:37:28.596438
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # AssertionError test
    # If a skippable exception is raised in the code, then it will be skipped by the test runner
    # AssertionError is not a skippable exception, so it should fail the test
    with pytest.raises(AssertionError):
        test_object = FieldAttributeBase()
        test_object.get_validated_value(None, None, None, None)


# Generated at 2022-06-11 09:37:30.666398
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    my_object = FieldAttributeBase()
    result = my_object.squash()
    assert result == False


# Generated at 2022-06-11 09:38:00.519992
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # data setup
    attrs = {'aliases': [], 'default': None, 'isa': 'string', 'listof': None, 'required': False, 'static': False}
    # test method
    f = FieldAttributeBase()
    r = f.from_attrs(attrs)
    assert r is None

# Generated at 2022-06-11 09:38:07.752881
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base = FieldAttributeBase()
    base._valid_attrs = (("a", FieldAttribute("a", "a")), ("b", FieldAttribute("b", "b")), ("c", FieldAttribute("c", "c")))
    base.a = "a"
    base.b = 123
    base.c = True
    result = base.dump_attrs()
    assert result == {'a': 'a', 'b': 123, 'c': True}


# Generated at 2022-06-11 09:38:09.514315
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    my_test = FieldAttributeBase()
    assert my_test.get_validated_value() == None


# Generated at 2022-06-11 09:38:20.229754
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    class Tmeta(type):
        def __new__(cls, name, parents, dct):
            return super(Tmeta, cls).__new__(cls, name, parents, dct)
    class T1(object):
        __metaclass__ = Tmeta
        a = Attribute()
    class T2(T1):
        b = Attribute()
    class T3(T2):
        c = Attribute()
    class T4(T3):
        __metaclass__ = BaseMeta
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

# Generated at 2022-06-11 09:38:27.155910
# Unit test for method from_attrs of class FieldAttributeBase

# Generated at 2022-06-11 09:38:31.484940
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a field of False
    expected = False
    test_obj = FieldAttributeBase(always_post_validate=expected)
    actual = test_obj.always_post_validate

    assert actual == expected
    pass


# Generated at 2022-06-11 09:38:33.218227
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # TODO: This test method needs to be made robust.
    pass

# Generated at 2022-06-11 09:38:39.889411
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    obj = Base()
    res = obj.get_dep_chain()
    assert res == None
    obj = Base()
    obj._parent = None
    res = obj.get_dep_chain()
    assert res == None
    obj = Base()
    obj._parent = {'_play': None}
    res = obj.get_dep_chain()
    assert res == None


# Generated at 2022-06-11 09:38:41.908858
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Base.get_dep_chain() is used in the 'include' component
    # do not verify it for the moment
    return


# Generated at 2022-06-11 09:38:52.790520
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_instance = BaseObject()
    assert test_instance.get_validated_value('name', FieldAttribute('isa', 'int', required=True, always_post_validate=True), '23', 'templar') == 23
    assert test_instance.get_validated_value('name', FieldAttribute('isa', 'dict', required=True, always_post_validate=True), '{"A": "a"}', 'templar') == {'A': 'a'}
    assert test_instance.get_validated_value('name', FieldAttribute('isa', 'class', required=True, always_post_validate=True), 'class_object', 'templar') == 'class_object'

# Generated at 2022-06-11 09:39:24.132375
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import collections
    import sys
    import ansible.playbook.task_include
    import ansible.playbook.play
    import ansible.playbook.block
    playbook_obj1 = ansible.playbook.play.Play()
    role_incl2 = ansible.playbook.task_include.TaskInclude()
    from ansible.utils.unsafe_proxy import wrap_var
    import ansible.parsing.yaml.objects
    ds3 = ansible.parsing.yaml.objects.AnsibleMapping()
    ds3._line_number = 1
    ds3._data_source = "test/ansible/playbook/test_base.yml"
    setattr(role_incl2, '_ds', ds3)

# Generated at 2022-06-11 09:39:25.123500
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # TODO
    pass



# Generated at 2022-06-11 09:39:27.422932
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase()
    test_data = b'A random string'
    obj.deserialize(test_data)


# Generated at 2022-06-11 09:39:37.502788
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-11 09:39:43.817529
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 09:39:46.805106
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    field_attribute_base_instance = FieldAttributeBase()
    assert field_attribute_base_instance.get_validated_value() == None


# Generated at 2022-06-11 09:39:56.583426
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    e = FieldAttributeBase()
    e.isa = 'string'
    e.name = 'test'
    templar = mock.MagicMock()
    library = mock.MagicMock()
    library._get_plugin_loader.return_value = 'plugin'
    templar._load_vars.return_value = {}
    templar._get_vars.return_value = {}
    templar.template_vars = {}
    templar.available_templates = {}
    templar._available_variables = {}
    templar._load_plugins = mock.MagicMock()
    templar._load_plugins.return_value = library

    value = "Test"

# Generated at 2022-06-11 09:40:07.694693
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    f = FieldAttributeBase()

    # value is None, attribute.isa is string
    expected = None
    actual = f.get_validated_value(None, None, None)
    assert actual == expected, \
        'FieldAttributeBase:get_validated_value returned "%s", expected "%s"' % (actual, expected)

    # value is None, attribute.isa is dict
    expected = {}
    actual = f.get_validated_value(None, None, None, attribute_isa='dict')
    assert actual == expected, \
        'FieldAttributeBase:get_validated_value returned "%s", expected "%s"' % (actual, expected)

    # value is None, attribute.isa is list
    expected = []
    actual = f.get_validated_value(None, None, None, attribute_isa='list')
   

# Generated at 2022-06-11 09:40:12.489448
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    FieldAttributeBase
    "post_validate" method
    '''

    obj = FieldAttributeBase()

    # no exception raised
    obj.post_validate(templar=templar)

    # no exception raised
    obj.post_validate(templar=templar)

# Generated at 2022-06-11 09:40:22.426599
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class FieldAttributeBase(object):
        '''  '''
        def __init__(self, **kwargs):
            pass

        def get_validated_value(self, name, attribute, value, templar):
            if attribute.isa == 'string':
                value = to_text(value)
            elif attribute.isa == 'int':
                value = int(value)
            elif attribute.isa == 'float':
                value = float(value)
            elif attribute.isa == 'bool':
                value = boolean(value, strict=True)

# Generated at 2022-06-11 09:40:55.811239
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test passing structure and expected result
    testvals = {'spam': {'a': 1, 'b': 2, 'c': 3}}
    # This is the parametrized test.
    # With *[testvals] all keys and values are taken from testvals.
    # With **testvals the key and value are taken from testvals.
    @pytest.mark.parametrize("data,expected", list(itertools.product(*[testvals])))
    def do_test(data, expected):
        obj = FieldAttributeBase()
        for (attr, value) in data.items():
            setattr(obj, attr, value)
        assert data == obj.dump_me()
    # Run the test.
    do_test()

# Generated at 2022-06-11 09:41:06.638355
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fieldattributebase = FieldAttributeBase()
    fieldattributebase._valid_attrs = {
        "attr1": "attr1",
        "attr2": "attr2",
        "attr3": "attr3",
        "attr4": "attr4",
    }
    fieldattributebase._alias_attrs = {
        "alias1": "alias2",
        "alias2": "alias3",
        "alias3": "alias4",
    }
    fieldattributebase._attributes = {
        "attr1": "attr1",
        "attr2": "attr2",
        "attr3": "attr3",
        "attr4": "attr4",
    }

# Generated at 2022-06-11 09:41:16.783601
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    """ Test FieldAttributeBase._deserialize """

    # return initialized instance of this class unit test
    def _get_instance(args=None, kwargs=None):
        a = FieldAttributeBase()
        return a

    # test if expected exception was thrown
    def _test_exception(exception_class, args=None, kwargs=None):
        a = _get_instance(args, kwargs)

        with pytest.raises(exception_class):
            a._deserialize()

    # test method with non-class-specific parameters (all should pass)
    def _test_non_class_specific(args=None, kwargs=None):
        a = _get_instance(args, kwargs)

        a._deserialize()

        # assertions
        assert True  # base class does not implement

# Generated at 2022-06-11 09:41:21.898275
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Object of type FieldAttributeBase
    cb = FieldAttributeBase(None, None, None)
    attr = FieldAttribute(name='name', isa='str', private=True)
    item = getattr(cb, 'name', attr)
    assert isinstance(item, FieldAttribute)
    assert item.name == 'name'
    assert item.private is True

# Generated at 2022-06-11 09:41:23.381869
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
  assert True # TODO: implement your test here


# Generated at 2022-06-11 09:41:35.118723
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # Create mock object
    task_obj = Task()
    task_obj._parent = Play()
    play_obj = Play()
    play_obj._role_path = "."
    play_obj._parent = Play()
    play_obj._parent._role_path='opt/ansible/roles'
    task_obj._parent._parent= play_obj
    assert task_obj.get_search_path() == ['.', 'opt/ansible/roles']
    assert play_obj.get_search_path() == ['.']
    assert task_obj.get_dep_chain() == [play_obj._parent, play_obj]
    assert play_obj.get_dep_chain() == [play_obj._parent]
    assert play_obj._parent.get_dep_chain() == None
    # No parent for task

# Generated at 2022-06-11 09:41:40.896471
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict(
        _uuid = 'dummy_uuid',
        finalized = False,
        squashed = False
    )
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert(obj.uuid == 'dummy_uuid')
    assert(obj.finalized == False)
    assert(obj.squashed == False)
    


# Generated at 2022-06-11 09:41:46.093726
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    temp_1_obj = FieldAttributeBase()
    temp_1_obj._validated = True
    temp_1_obj._variable_manager = DictData()
    assert temp_1_obj.get_validated_value('name', attribute, value, templar) == None

# Generated at 2022-06-11 09:41:50.572203
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Setup
    test_obj = FieldAttributeBase()

    # Try a value that works
    test_obj.validate('a_valid_value')

    # Now test some invalid values
    for value in [None, 1234, True, 1.234]:
        try:
            test_obj.validate(value)
        except:
            pass
        else:
            assert False



# Generated at 2022-06-11 09:41:56.451083
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    field_attribute_base_obj = FieldAttributeBase()
    test_name = 'test name'
    test_required = True
    test_val = 'test value'
    test_aliases = ['one', 'two', 'three']
    test_class_type = 'test class type'
    field_attribute_base_obj.name = test_name
    field_attribute_base_obj.required = test_required
    field_attribute_base_obj.default = test_val
    field_attribute_base_obj.aliases = test_aliases
    field_attribute_base_obj.class_type = test_class_type

    # Check that all attributes set correctly
    assert field_attribute_base_obj.name == test_name
    assert field_attribute_base_obj.required == test_required
    assert field_attribute_base

# Generated at 2022-06-11 09:42:29.903171
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    attr = FieldAttributeBase('name', 'int', default=0, always_post_validate=True)
    obj = FieldAttributeBase(None, None, None, None)
    obj._valid_attrs = dict(name=attr)
    templar = MagicMock()
    templar.is_template = template_flag = MagicMock(return_value=True)
    templar.template = template = MagicMock(return_value=123)
    obj.name = '123'
    obj.post_validate(templar)
    assert obj.name == 123
    assert template_flag.call_count == 1
    assert template.call_count == 1
    obj.name = '123'
    template_flag.reset

# Generated at 2022-06-11 09:42:32.854286
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # try to get valid value for string, int, float, bool, percent
    # The expected result should be a object of the corresponding type
    # try to convert a float to dict, should raise TypeError
    pass


# Generated at 2022-06-11 09:42:42.667514
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''
    Test for method validate
    '''
    field = FieldAttribute()
    value = DummyClass()
    
    msg = "FieldAttributeBase.validate should raise an exception when value is not None"
    with pytest.raises(AnsibleAssertionError, message=msg):
        field.validate()
    
    msg = "FieldAttributeBase.validate should raise an exception when value is not None"
    with pytest.raises(AnsibleAssertionError, message=msg):
        field.validate("string")
    
    msg = "FieldAttributeBase.validate should not raise an exception when value is None"
    field.validate(value=None)
    
    msg = "FieldAttributeBase.validate should not raise an exception when value is DummyClass"

# Generated at 2022-06-11 09:42:44.667609
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field = FieldAttributeBase()
    attrs = {}
    field.from_attrs(attrs)


# Generated at 2022-06-11 09:42:55.977769
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
   base = Base()
   base._parent = Base()
   base._parent.__class__._play = Base()
   base._parent.__class__._play._ds = Base()
   base._parent.__class__._play._ds._data_source = "test_source"
   base._parent.__class__._play._ds._line_number = "test_line_number"

   dep_chain = base.get_dep_chain()
   assert dep_chain is None
   assert base.get_path() == "test_source:test_line_number"

   base._parent = Base()
   base._parent.__class__._play = Base()
   base._parent.__class__._play._ds = Base()
   base._parent.__class__._play._ds._data_source = "test_source"
   base._

# Generated at 2022-06-11 09:43:04.467714
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    args = dict(
        a=0,
        b="test",
        c=0.0,
        d=True,
        e=['a', 'b'],
        f={'a': 1, 'b': 2}
    )
    obj1 = FieldAttributeBase(**args)

    obj2 = TestField()
    obj2.from_attrs(obj1.dump_attrs())

    assert obj2.a == 0
    assert obj2.b == "test"
    assert obj2.c == 0.0
    assert obj2.d is True
    assert obj2.e == ['a', 'b']
    assert obj2.f == {'a': 1, 'b': 2}


# Generated at 2022-06-11 09:43:06.776612
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    bMeta = BaseMeta('name', 'parents', 'dct')
    b = Base()
    assert bMeta.__new__(BaseMeta, 'Base', (Base,), b.__dict__) is None


# Generated at 2022-06-11 09:43:09.179007
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Ensure we can get the attributes of an object
    '''
    data = dict(
        x=1,
        y=2,
        z=3,
    )

    test_obj = FieldAttributeBase(**data)
    assert sorted(test_obj.dump_attrs().keys()) == sorted(data.keys())

# Generated at 2022-06-11 09:43:15.278317
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play = Play()
    serialized_play = play.serialize()
    for name, attribute in iteritems(play._valid_attrs):
        assert serialized_play[name] == attribute.default, "Serialized data in play is wrong: %s" % serialized_play[name]


# Generated at 2022-06-11 09:43:16.836208
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
   assert Base().get_dep_chain is not None


# Generated at 2022-06-11 09:44:08.893103
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Method variables
    FieldAttributeBase._load_vars = lambda self, attr, ds: {'foo': 'bar'}
    test_instance = FieldAttributeBase('json')
    # test_instance._validated = False
    test_instance.name = 'foo'
    test_instance.default = 'bar'
    test_instance.required = False
    #test_instance.always_post_validate = True
    # test_instance.static = False
    test_instance.vars = {'foo': 'bar'}
    test_instance._loader = DictDataLoader({'foo': 'bar'})
    test_instance._variable_manager = None
    test_instance._validated = True
    test_instance._finalized = True
    test_instance._uuid = 'yadda'


# Generated at 2022-06-11 09:44:13.223326
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    """Unit test for method deserialize of class FieldAttributeBase"""
    obj = FieldAttributeBase('name', 'str')
    data = {"name": "Matteo", "age": "32"}
    assert obj.deserialize(data) is None, "FieldAttributeBase.deserialize did not return None"

# Generated at 2022-06-11 09:44:14.787834
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    assert obj.dump_attrs() == {}


# Generated at 2022-06-11 09:44:21.090605
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    loader = AnsibleLoader if yaml.__with_libyaml__ is True else None


# Generated at 2022-06-11 09:44:23.346260
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    instance = FieldAttributeBase()
    # need to be instantiated with args
    assert False


# Generated at 2022-06-11 09:44:27.092211
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    get_validated_value - does not convert values correctly
    '''

    # Call method
    res = FieldAttributeBase.get_validated_value(ds, name)
    assert res == expected



# Generated at 2022-06-11 09:44:33.896929
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase('test_attr')
    value = 'test string'
    assert(attr.validate(value) == 'test string')
    value = ['a', 'b', 'c']
    assert(attr.validate(value) == ['a', 'b', 'c'])
    value = 13
    assert(attr.validate(value) == 13)
    value = object()
    assert(attr.validate(value) == object())


# Generated at 2022-06-11 09:44:40.489866
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    uncopyable_attrs = {
        '_loader': None,
        '_variable_manager': None,
        '_validated': None,
        '_finalized': None,
    }
    for attr in uncopyable_attrs:
        obj = FieldAttributeBase()
        setattr(obj, attr, True)

        # Copy the object
        obj_copy = copy.deepcopy(obj)

        assert obj_copy.get_attr_value(attr) is None


# Generated at 2022-06-11 09:44:46.573512
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    o = FieldAttributeBase()
    a = 'test_attr'
    b = 'vault_encrypted_test_attr'

    try:
        # Testing invalid attribute `a`
        o.load_data(a, None)
        assert(False)
    except (AnsibleParserError, AttributeError):
        assert(True)

    try:
        # Testing invalid attribute `b`
        o.load_data(b, None)
        assert(False)
    except (AnsibleParserError, AttributeError):
        assert(True)


# Generated at 2022-06-11 09:44:56.971769
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test for the basic types int, float, bool and string
    f = FieldAttributeBase()
    assert f.get_validated_value("int", FieldAttribute("foo", "int"), "42", None) == 42
    assert f.get_validated_value("float", FieldAttribute("foo", "float"), "42.0", None) == 42.0
    assert f.get_validated_value("bool", FieldAttribute("foo", "bool"), "yes", None) is True
    assert f.get_validated_value("string", FieldAttribute("foo", "string"), 42, None) == "42"
    # Test for percent type
    assert f.get_validated_value("percent", FieldAttribute("foo", "percent"), "42", None) == 42.0

# Generated at 2022-06-11 09:45:51.051371
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():

    # Arguments of method get_search_path of class Base
    test_args = []
    # Initialization
    test_object = Base()
    # Execution
    test_output = test_object.get_search_path()
    print("test_output: %s" % test_output)
    
    

# Generated at 2022-06-11 09:45:59.799276
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    tqm = None

# Generated at 2022-06-11 09:46:08.429856
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    def prepare_obj(obj, **kwargs):
        var_manager = MagicMock()
        ds = MagicMock()
        obj._valid_attrs = {
            'test_attr': FieldAttribute(isa='int')
        }
        obj._variable_manager = var_manager
        setattr(obj, 'test_attr', kwargs.get('value', None))
        obj._ds = ds
        return obj

    obj = MagicMock()
    templar = MagicMock()
    obj = prepare_obj(obj, value=1)
    obj.get_validated_value('test_attr', obj._valid_attrs['test_attr'], obj.test_attr, templar)
    assert obj.test_attr == 1

    obj = prepare_obj(obj, value='1')
    obj