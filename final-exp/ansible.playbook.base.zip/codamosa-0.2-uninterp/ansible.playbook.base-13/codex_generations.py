

# Generated at 2022-06-17 06:54:59.326053
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.become import Become
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.loop_control import LoopControl
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.when import When

# Generated at 2022-06-17 06:55:04.478595
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj._valid_attrs = {'test': 'test'}
    obj.test = 'test'
    assert obj.dump_attrs() == {'test': 'test'}

    # Test with an invalid object
    obj = FieldAttributeBase()
    obj._valid_attrs = {'test': 'test'}
    assert obj.dump_attrs() == {}


# Generated at 2022-06-17 06:55:08.778526
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a valid value
    attr = FieldAttributeBase('test', isa='string', required=True)
    attr.validate('test')

    # Test with an invalid value
    with pytest.raises(AnsibleParserError):
        attr.validate(1)

    # Test with a valid value and a validator
    attr = FieldAttributeBase('test', isa='string', required=True, validator=lambda x: x == 'test')
    attr.validate('test')

    # Test with an invalid value and a validator
    with pytest.raises(AnsibleParserError):
        attr.validate('invalid')


# Generated at 2022-06-17 06:55:19.471432
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class TestBaseMeta(with_metaclass(BaseMeta, object)):
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}
            self._squashed = False
            self._finalized = False
        def _get_parent_attribute(self, attr_name):
            return None
        def _get_attr_name(self):
            return None
        def _get_attr_age(self):
            return None
        def _get_attr_gender(self):
            return None
        def _get_attr_address(self):
            return None
        def _get_attr_phone(self):
            return None
        def _get_attr_email(self):
            return None


# Generated at 2022-06-17 06:55:25.478274
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a valid object
    obj = FieldAttributeBase()
    assert obj.dump_me() == {}

    # Test with a valid object with attributes
    obj = FieldAttributeBase()
    obj._valid_attrs = {'test': 'test'}
    assert obj.dump_me() == {'test': 'test'}

    # Test with a valid object with attributes and aliases
    obj = FieldAttributeBase()
    obj._valid_attrs = {'test': 'test'}
    obj._alias_attrs = {'test': 'test'}
    assert obj.dump_me() == {'test': 'test'}


# Generated at 2022-06-17 06:55:32.224692
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 06:55:34.824923
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Setup
    field_attribute_base = FieldAttributeBase()

    # Test
    field_attribute_base.get_validated_value()


# Generated at 2022-06-17 06:55:47.856029
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # test_data is a dict of dicts, where the keys are the test names
    # and the values are dicts with the following keys:
    #
    #   'args' - the args to pass to the method
    #   'assert' - the expected return value
    #   'raises' - the exception to expect, if any
    #
    test_data = {
        'deserialize_dict': {
            'args': [{'foo': 'bar'}],
            'assert': None,
            'raises': None,
        },
        'deserialize_not_dict': {
            'args': [42],
            'assert': None,
            'raises': AnsibleAssertionError,
        },
    }

    for test_name, test in iteritems(test_data):
        obj = Field

# Generated at 2022-06-17 06:55:59.465253
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.task_meta import TaskMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleTasks

# Generated at 2022-06-17 06:56:09.751300
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Test with a simple task
    task = Task()
    task.from_attrs({'name': 'test', 'action': 'ping'})
    assert task.name == 'test'
    assert task.action == 'ping'

    # Test with a task with a complex attribute
    task = Task()
    task.from_attrs({'name': 'test', 'action': 'ping', 'when': {'test': 'test'}})
    assert task.name == 'test'
    assert task.action == 'ping'
    assert task.when.test == 'test'

    # Test with a task with a complex attribute that is a list
    task = Task()
    task.from_attrs({'name': 'test', 'action': 'ping', 'when': [{'test': 'test'}]})
    assert task.name

# Generated at 2022-06-17 06:56:51.499777
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Base(with_metaclass(BaseMeta, object)):
        def __init__(self, **kwargs):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}
            self._squashed = False
            self._finalized = False
            self._parent = None
            self._parents = []
            self._deprecated_attrs = {}
            self._deprecated_aliases = {}
            self._deprecated_defaults = {}
            self._deprecated_warnings = {}
            self._deprecated_removed = {}
            self._deprecated_removed_aliases = {}
            self._deprecated_removed_warnings = {}
            self._deprecated_removed_defaults = {}
            self._dep

# Generated at 2022-06-17 06:57:02.626534
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 06:57:03.963573
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # TODO: implement test
    pass


# Generated at 2022-06-17 06:57:14.168899
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.isa = 'string'
    attr.required = True
    attr.always_post_validate = True
    attr.default = 'test'
    attr.static = False
    attr.class_type = None
    attr.listof = None
    attr.private = False
    attr.aliases = []
    attr.post_validate(templar=None)
    assert attr.value == 'test'
    assert attr.static == True
    assert attr.private == False
    assert attr.aliases == []
    assert attr.class_type == None
    assert attr.listof == None
    assert attr.default == 'test'
    assert attr.always_post_valid

# Generated at 2022-06-17 06:57:21.821762
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create a mock object
    mock_obj = Mock()
    mock_obj._valid_attrs = {'test': 'test'}
    mock_obj.test = 'test'
    # Call the method
    result = FieldAttributeBase.dump_attrs(mock_obj)
    # Check the result
    assert result == {'test': 'test'}


# Generated at 2022-06-17 06:57:34.254484
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test with a valid value
    attr = FieldAttributeBase('name', 'string', required=True)
    attr.post_validate(None, 'value', None)

    # Test with an invalid value
    attr = FieldAttributeBase('name', 'string', required=True)
    with pytest.raises(AnsibleParserError):
        attr.post_validate(None, None, None)

    # Test with a valid value
    attr = FieldAttributeBase('name', 'string', required=False)
    attr.post_validate(None, 'value', None)

    # Test with an invalid value
    attr = FieldAttributeBase('name', 'string', required=False)
    attr.post_validate(None, None, None)


# Generated at 2022-06-17 06:57:45.837533
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a valid value
    attr = FieldAttributeBase('test', isa='string', default='test')
    attr.validate('test')

    # Test with an invalid value
    attr = FieldAttributeBase('test', isa='string', default='test')
    with pytest.raises(AnsibleParserError):
        attr.validate(1)

    # Test with a valid value and a validator
    attr = FieldAttributeBase('test', isa='string', default='test', validator=lambda x: x == 'test')
    attr.validate('test')

    # Test with an invalid value and a validator
    attr = FieldAttributeBase('test', isa='string', default='test', validator=lambda x: x == 'test')

# Generated at 2022-06-17 06:57:47.022743
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'foo': 'bar'}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.foo == 'bar'


# Generated at 2022-06-17 06:57:48.372985
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj._uuid == None
    assert obj._finalized == False
    assert obj._squashed == False

# Generated at 2022-06-17 06:57:54.495679
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Test case 1
    # Test when self._parent is None
    # Expected result: []
    base = Base()
    base._parent = None
    assert base.get_search_path() == []

    # Test case 2
    # Test when self._parent._play is None
    # Expected result: []
    base = Base()
    base._parent = Base()
    base._parent._play = None
    assert base.get_search_path() == []

    # Test case 3
    # Test when self._parent._play._ds is None
    # Expected result: []
    base = Base()
    base._parent = Base()
    base._parent._play = Base()
    base._parent._play._ds = None
    assert base.get_search_path() == []

    # Test case 4
    # Test when self

# Generated at 2022-06-17 06:59:06.370553
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-17 06:59:14.539430
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 06:59:21.382277
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with no data
    obj = FieldAttributeBase()
    obj.load_data(None)
    assert obj.data is None
    # Test with data
    obj = FieldAttributeBase()
    obj.load_data(dict(a=1, b=2))
    assert obj.data == dict(a=1, b=2)

# Generated at 2022-06-17 06:59:27.869567
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create an instance of FieldAttributeBase
    fieldattributebase = FieldAttributeBase()
    # Call method dump_attrs of fieldattributebase
    # No exception should be thrown
    fieldattributebase.dump_attrs()


# Generated at 2022-06-17 06:59:37.270466
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a simple value
    attr = FieldAttributeBase('test_attr', default=None)
    assert attr.dump_me() == 'test_attr'

    # Test with a complex value
    attr = FieldAttributeBase('test_attr', default=None, isa='list')
    assert attr.dump_me() == 'test_attr: list'

    # Test with a complex value and a description
    attr = FieldAttributeBase('test_attr', default=None, isa='list', description='Test description')
    assert attr.dump_me() == 'test_attr: list (Test description)'


# Generated at 2022-06-17 06:59:40.639129
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.validate('test')

    # Test with an invalid value
    attr = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        attr.validate(None)


# Generated at 2022-06-17 06:59:51.268423
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.task.block import TaskBlock
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.handler import Handler
    from ansible.playbook.handler.block import HandlerBlock
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin

# Generated at 2022-06-17 06:59:55.476884
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a string
    value = 'test'
    attribute = FieldAttributeBase(isa='string')
    assert FieldAttributeBase.get_validated_value('name', attribute, value, None) == 'test'

    # Test with an int
    value = '1'
    attribute = FieldAttributeBase(isa='int')
    assert FieldAttributeBase.get_validated_value('name', attribute, value, None) == 1

    # Test with a float
    value = '1.0'
    attribute = FieldAttributeBase(isa='float')
    assert FieldAttributeBase.get_validated_value('name', attribute, value, None) == 1.0

    # Test with a bool
    value = 'true'
    attribute = FieldAttributeBase(isa='bool')

# Generated at 2022-06-17 07:00:03.879356
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a FieldAttributeBase object
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.isa = 'string'
    obj.default = 'test'
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test'
    obj.listof = 'test'
    obj.private = True
    obj.aliases = ['test']
    obj.choices = ['test']
    obj.deprecated_choices = ['test']
    obj.deprecated_aliases = ['test']
    obj.deprecated_names = ['test']
    obj.version_added = 'test'
    obj.version_removed = 'test'
    obj.no_log = True

# Generated at 2022-06-17 07:00:11.958744
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars_file
    from ansible.utils.vars import load_options_vars_file
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys

# Generated at 2022-06-17 07:00:59.035141
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 07:01:06.385589
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_block import TaskBlock
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.requiremenets import RoleRequirement

# Generated at 2022-06-17 07:01:12.971965
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute

    class TestBase(with_metaclass(BaseMeta, Base)):
        _test_attr = FieldAttribute(isa='str', default='test')
        _test_attr_2 = FieldAttribute(isa='str', default='test2')
        _test_attr_3 = FieldAttribute(isa='str', default='test3')

        def _get_attr__test_attr(self):
            return 'test_attr'

        def _get_attr__test_attr_2(self):
            return 'test_attr_2'

        def _get_attr__test_attr_3(self):
            return 'test_attr_3'

    tb = TestBase()

# Generated at 2022-06-17 07:01:22.036316
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Test with a simple object
    obj = FieldAttributeBase()
    obj._ds = 'test_ds'
    assert obj.get_ds() == 'test_ds'

    # Test with a complex object
    obj = FieldAttributeBase()
    obj._ds = {'test_ds': 'test_ds'}
    assert obj.get_ds() == {'test_ds': 'test_ds'}


# Generated at 2022-06-17 07:01:32.969105
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.tasks import RoleTasks


# Generated at 2022-06-17 07:01:43.306559
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a valid data
    data = {'name': 'test', 'uuid': 'test_uuid', 'finalized': True, 'squashed': True}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj._uuid == 'test_uuid'
    assert obj._finalized == True
    assert obj._squashed == True
    assert obj.name == 'test'

    # Test with a invalid data
    data = 'test'
    obj = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        obj.deserialize(data)
    assert 'data (test) should be a dict but is a' in str(excinfo.value)


# Generated at 2022-06-17 07:01:50.948332
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:01:56.428044
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test with a valid value
    attr = FieldAttributeBase('test_attr', 'test_isa', 'test_description', 'test_default')
    attr.post_validate('test_value')

    # Test with an invalid value
    with pytest.raises(AnsibleParserError):
        attr.post_validate(None)


# Generated at 2022-06-17 07:02:02.435239
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create a FieldAttributeBase object
    field_attribute_base_obj = FieldAttributeBase()
    # Call method post_validate of FieldAttributeBase with a specific parameters
    # post_validate(self, templar)
    # TODO: Not yet implemented
    pass


# Generated at 2022-06-17 07:02:06.926257
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    fieldattributebase_instance = FieldAttributeBase()
    # Test the method get_validated_value
    # TODO: Implement your test here
    raise Exception("Test if implemented.")


# Generated at 2022-06-17 07:03:05.824118
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUn

# Generated at 2022-06-17 07:03:14.350308
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 07:03:25.247036
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    import os
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude

# Generated at 2022-06-17 07:03:29.660720
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.load_data('test_value')
    assert attr.value == 'test_value'
    # Test with an invalid value
    attr = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        attr.load_data(None)


# Generated at 2022-06-17 07:03:40.006717
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a simple object
    class TestObject(FieldAttributeBase):
        def __init__(self):
            self.test_field = 'test_value'
            self.test_field2 = 'test_value2'
            self.test_field3 = 'test_value3'

    test_obj = TestObject()
    assert test_obj.dump_attrs() == {'test_field': 'test_value', 'test_field2': 'test_value2', 'test_field3': 'test_value3'}

    # Test with a complex object
    class TestObject2(FieldAttributeBase):
        def __init__(self):
            self.test_field = 'test_value'
            self.test_field2 = 'test_value2'
            self.test_field3 = 'test_value3'


# Generated at 2022-06-17 07:03:45.982489
# Unit test for method copy of class FieldAttributeBase

# Generated at 2022-06-17 07:03:53.239210
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a simple object
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.value = 'value'
    obj.value2 = 'value2'
    obj.value3 = 'value3'
    obj.value4 = 'value4'
    obj.value5 = 'value5'
    obj.value6 = 'value6'
    obj.value7 = 'value7'
    obj.value8 = 'value8'
    obj.value9 = 'value9'
    obj.value10 = 'value10'
    obj.value11 = 'value11'
    obj.value12 = 'value12'
    obj.value13 = 'value13'
    obj.value14 = 'value14'
    obj.value15 = 'value15'
    obj.value16 = 'value16'


# Generated at 2022-06-17 07:03:56.604383
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase(name='name', isa='string', default='default')
    assert obj.get_validated_value('name', obj, 'value', 'templar') == 'value'

# Generated at 2022-06-17 07:04:04.825168
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.isa = 'string'
    obj.default = 'test'
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test'
    obj.listof = 'test'
    obj.private = True
    obj.aliases = ['test']
    obj.choices = ['test']
    obj.deprecated_choices = ['test']
    obj.deprecated_aliases = ['test']
    obj.deprecated_names = ['test']
    obj.version_added = 'test'
    obj.version_removed = 'test'
    obj.aliases = ['test']

# Generated at 2022-06-17 07:04:14.575141
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode
    from ansible.parsing.yaml.composer import AnsibleComposer
    from ansible.parsing.yaml.scanner import AnsibleScan