

# Generated at 2022-06-17 06:54:47.916112
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    # Test with no parameters
    obj = FieldAttributeBase()
    obj.copy()
    # Test with valid parameters
    obj = FieldAttributeBase()
    obj.copy(True)

# Generated at 2022-06-17 06:54:54.502258
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a simple value
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.isa = 'string'
    obj.default = 'test'
    obj.required = False
    obj.static = False
    obj.always_post_validate = False
    obj.class_type = None
    obj.listof = None
    obj.aliases = []
    obj.choices = []
    obj.private = False
    obj.deprecated = False
    obj.removed_at_date = None
    obj.removed_from_collection = None
    obj.version_added = None
    obj.version_removed = None
    obj.aliases = []
    obj.choices = []
    obj.private = False
    obj.deprecated = False
    obj.removed_at_

# Generated at 2022-06-17 06:55:07.763375
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a valid data
    data = {'name': 'test_name', 'isa': 'test_isa', 'default': 'test_default', 'required': True, 'private': True, 'aliases': ['test_alias'], 'choices': ['test_choice'], 'class_type': 'test_class_type', 'static': True, 'always_post_validate': True, 'listof': 'test_listof', 'version_added': 'test_version_added', 'version_removed': 'test_version_removed'}
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.load_data(data)
    assert field_attribute_base.name == 'test_name'
    assert field_attribute_base.isa == 'test_isa'

# Generated at 2022-06-17 06:55:12.936683
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test with a valid value
    test_obj = FieldAttributeBase()
    test_obj.post_validate(templar=None)
    assert test_obj._finalized == True
    assert test_obj._squashed == False

# Generated at 2022-06-17 06:55:26.255449
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a string
    value = 'test'
    field = FieldAttributeBase(isa='string')
    assert value == field.get_validated_value('name', field, value, None)

    # Test with a int
    value = '1'
    field = FieldAttributeBase(isa='int')
    assert 1 == field.get_validated_value('name', field, value, None)

    # Test with a float
    value = '1.0'
    field = FieldAttributeBase(isa='float')
    assert 1.0 == field.get_validated_value('name', field, value, None)

    # Test with a bool
    value = 'True'
    field = FieldAttributeBase(isa='bool')
    assert True == field.get_validated_value('name', field, value, None)

    # Test

# Generated at 2022-06-17 06:55:27.336817
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert Base().get_dep_chain() is None


# Generated at 2022-06-17 06:55:38.891538
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import RoleTasks
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.handlers import RoleHandlers
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.meta.main import RoleMetaMain

# Generated at 2022-06-17 06:55:51.702000
# Unit test for method get_search_path of class Base

# Generated at 2022-06-17 06:56:02.752301
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a string
    assert FieldAttributeBase.get_validated_value('name', FieldAttribute(isa='string'), 'value', None) == 'value'
    # Test with an integer
    assert FieldAttributeBase.get_validated_value('name', FieldAttribute(isa='int'), '42', None) == 42
    # Test with a float
    assert FieldAttributeBase.get_validated_value('name', FieldAttribute(isa='float'), '42.0', None) == 42.0
    # Test with a boolean
    assert FieldAttributeBase.get_validated_value('name', FieldAttribute(isa='bool'), 'true', None) is True
    # Test with a percent
    assert FieldAttributeBase.get_validated_value('name', FieldAttribute(isa='percent'), '42%', None) == 42.0
    # Test with a

# Generated at 2022-06-17 06:56:14.367030
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-17 06:56:41.776735
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.validate(None)

    # Test with an invalid value
    with pytest.raises(AnsibleAssertionError):
        attr.validate(1)


# Generated at 2022-06-17 06:56:51.848296
# Unit test for method post_validate of class FieldAttributeBase

# Generated at 2022-06-17 06:57:03.036950
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test with a simple string
    attr = FieldAttributeBase('test', 'string', required=True)
    assert attr.post_validate('test') == 'test'

    # Test with a string containing a variable
    attr = FieldAttributeBase('test', 'string', required=True)
    assert attr.post_validate('{{ test }}') == '{{ test }}'

    # Test with a string containing a variable and a templar
    attr = FieldAttributeBase('test', 'string', required=True)
    templar = Templar(loader=None, variables={'test': 'test'})
    assert attr.post_validate('{{ test }}', templar) == 'test'

    # Test with a string containing a variable and a templar with fail_on_undefined_errors
    attr = FieldAttribute

# Generated at 2022-06-17 06:57:04.087546
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:57:15.598235
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a string
    value = 'string'
    attribute = FieldAttributeBase(isa='string')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == value

    # Test with a int
    value = '1'
    attribute = FieldAttributeBase(isa='int')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == 1

    # Test with a float
    value = '1.0'
    attribute = FieldAttributeBase(isa='float')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == 1.0

    # Test with a bool
    value = 'true'
    attribute = FieldAttributeBase(isa='bool')
    assert FieldAttributeBase.get_validated

# Generated at 2022-06-17 06:57:17.761348
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    assert obj.dump_attrs() == {}


# Generated at 2022-06-17 06:57:26.036163
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance.copy()
    # Test with an instance of FieldAttributeBase
    test_instance = FieldAttributeBase()
    test_instance

# Generated at 2022-06-17 06:57:39.163676
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.pre_tasks import PreTask

# Generated at 2022-06-17 06:57:48.986082
# Unit test for method get_search_path of class Base

# Generated at 2022-06-17 06:57:49.800078
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 06:58:20.915933
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 06:58:30.798263
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a FieldAttributeBase object
    obj = FieldAttributeBase()
    obj.load_data(None, None, None)
    assert obj._valid_attrs == {}
    assert obj._loader == None
    assert obj._variable_manager == None
    assert obj._validated == False
    assert obj._finalized == False
    assert obj._uuid == None
    assert obj._attributes == {}
    assert obj._attr_defaults == {}
    assert obj._ds == None
    assert obj._squashed == False
    assert obj._loader == None
    assert obj._variable_manager == None
    assert obj._validated == False
    assert obj._finalized == False
    assert obj._uuid == None
    assert obj._attributes == {}
    assert obj._attr_defaults == {}
    assert obj._ds == None
   

# Generated at 2022-06-17 06:58:35.507415
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a string
    value = 'string'
    attribute = FieldAttributeBase(isa='string')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == 'string'

    # Test with an int
    value = '1'
    attribute = FieldAttributeBase(isa='int')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == 1

    # Test with a float
    value = '1.1'
    attribute = FieldAttributeBase(isa='float')
    assert FieldAttributeBase.get_validated_value(None, 'name', attribute, value, None) == 1.1

    # Test with a bool
    value = 'true'
    attribute = FieldAttributeBase(isa='bool')
    assert FieldAttributeBase.get_

# Generated at 2022-06-17 06:58:43.320575
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Test with a simple dictionary
    data = dict(a=1, b=2, c=3)
    result = FieldAttributeBase.squash(data)
    assert result == data

    # Test with a dictionary with a list
    data = dict(a=1, b=2, c=[1, 2, 3])
    result = FieldAttributeBase.squash(data)
    assert result == data

    # Test with a dictionary with a dictionary
    data = dict(a=1, b=2, c=dict(a=1, b=2, c=3))
    result = FieldAttributeBase.squash(data)
    assert result == data

    # Test with a dictionary with a dictionary with a list

# Generated at 2022-06-17 06:58:54.574532
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeArgs

# Generated at 2022-06-17 06:59:01.872303
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'name': 'test_name', 'uuid': 'test_uuid', 'finalized': True, 'squashed': True}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.name == 'test_name'
    assert obj._uuid == 'test_uuid'
    assert obj._finalized == True
    assert obj._squashed == True


# Generated at 2022-06-17 06:59:12.744103
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a simple object
    obj = FieldAttributeBase()
    obj._valid_attrs = {'foo': 'bar'}
    obj.foo = 'baz'
    assert obj.dump_attrs() == {'foo': 'baz'}
    # Test with an object with a nested object
    obj = FieldAttributeBase()
    obj._valid_attrs = {'foo': 'bar'}
    obj.foo = FieldAttributeBase()
    obj.foo._valid_attrs = {'bar': 'baz'}
    obj.foo.bar = 'qux'
    assert obj.dump_attrs() == {'foo': {'bar': 'qux'}}
    # Test with an object with a nested object that has a nested object
    obj = FieldAttributeBase()

# Generated at 2022-06-17 06:59:15.125728
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 06:59:19.445313
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.load_data('foo')
    assert attr.value == 'foo'

    # Test with an invalid value
    attr = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        attr.load_data(1)

# Generated at 2022-06-17 06:59:26.002573
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.play_include import PlayInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block_include import HandlerBlockInclude

# Generated at 2022-06-17 06:59:57.101124
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create a FieldAttributeBase object
    obj = FieldAttributeBase()
    # Copy the object
    obj_copy = obj.copy()
    # Check if the copy is a FieldAttributeBase object
    assert isinstance(obj_copy, FieldAttributeBase)
    # Check if the copy is not the same object
    assert obj_copy is not obj
    # Check if the copy is equal to the original
    assert obj_copy == obj

# Generated at 2022-06-17 07:00:01.323915
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase
    f = FieldAttributeBase()
    # Call method post_validate of FieldAttributeBase
    f.post_validate()

# Generated at 2022-06-17 07:00:05.901201
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test with a simple case
    test_play = Play()
    test_task = Task()
    test_task._parent = test_play
    test_play._parent = None
    assert test_task.get_dep_chain() == None
    # Test with a more complex case
    test_play = Play()
    test_task = Task()
    test_task._parent = test_play
    test_play._parent = test_play
    assert test_task.get_dep_chain() == test_play


# Generated at 2022-06-17 07:00:08.938122
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create a test object
    obj = FieldAttributeBase()

    # Create a test dictionary
    data = dict()

    # Call the method
    obj.from_attrs(data)

    # Check the results
    assert obj._finalized == True
    assert obj._squashed == True

# Generated at 2022-06-17 07:00:12.063214
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.load_data('foo')
    assert attr.value == 'foo'

    # Test with an invalid value
    attr = FieldAttributeBase()
    attr.load_data(None)
    assert attr.value is None


# Generated at 2022-06-17 07:00:25.506738
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler.task import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude

# Generated at 2022-06-17 07:00:35.948730
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:00:36.857373
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # TODO: implement test
    pass

# Generated at 2022-06-17 07:00:44.966042
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with no args
    obj = FieldAttributeBase()
    assert obj.dump_me() == {}

    # Test with args
    obj = FieldAttributeBase(name='test', default=None, required=True, private=True,
                             aliases=['test_alias'], always_post_validate=True,
                             static=True, isa='test_isa', listof=None, class_type=None)
    assert obj.dump_me() == {'name': 'test', 'default': None, 'required': True, 'private': True,
                             'aliases': ['test_alias'], 'always_post_validate': True,
                             'static': True, 'isa': 'test_isa', 'listof': None, 'class_type': None}


# Generated at 2022-06-17 07:00:52.910476
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.from_attrs({'name': 'test'})
    assert obj.name == 'test'
    assert obj._finalized == True
    assert obj._squashed == True
    # Test with an invalid object
    obj = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        obj.from_attrs(['test'])

# Generated at 2022-06-17 07:01:21.922519
# Unit test for method get_search_path of class Base

# Generated at 2022-06-17 07:01:25.518088
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase
    field_attribute_base_instance = FieldAttributeBase()
    # Test the method post_validate of class FieldAttributeBase
    # TODO: implement your test here
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-17 07:01:32.640364
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a dict
    data = {'name': 'test', 'uuid': 'test_uuid', 'finalized': True, 'squashed': False}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj._attributes['name'] == 'test'
    assert obj._uuid == 'test_uuid'
    assert obj._finalized == True
    assert obj._squashed == False
    # Test with a non-dict
    data = 'test'
    obj = FieldAttributeBase()
    try:
        obj.deserialize(data)
        assert False
    except AnsibleAssertionError:
        assert True


# Generated at 2022-06-17 07:01:43.536584
# Unit test for method load_data of class FieldAttributeBase

# Generated at 2022-06-17 07:01:51.647864
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Setup
    obj = FieldAttributeBase()
    name = 'name'
    attribute = FieldAttributeBase()
    value = 'value'
    templar = 'templar'

    # Exercise
    result = obj.get_validated_value(name, attribute, value, templar)

    # Verify
    assert result == 'value'


# Generated at 2022-06-17 07:01:56.918969
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase
    fieldattributebase_instance = FieldAttributeBase()
    # post_validate() Not implemented error
    with pytest.raises(NotImplementedError) as excinfo:
        fieldattributebase_instance.post_validate()
    assert 'post_validate() not implemented on FieldAttributeBase' in str(excinfo.value)

# Generated at 2022-06-17 07:02:02.822685
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'_uuid': 'a', 'finalized': False, 'squashed': False}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj._uuid == 'a'
    assert obj._finalized == False
    assert obj._squashed == False


# Generated at 2022-06-17 07:02:12.640140
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.isa = 'string'
    obj.default = 'test'
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test'
    obj.listof = 'test'
    obj.private = True
    obj.aliases = ['test']
    obj.choices = ['test']
    obj.deprecated_choices = ['test']
    obj.deprecated_aliases = ['test']
    obj.deprecated_for = 'test'
    obj.deprecated_since = 'test'
    obj.deprecated_removed_in = 'test'
    obj.deprecated_replacement = 'test'
    obj.dep

# Generated at 2022-06-17 07:02:26.644586
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultVersionedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultUnicode

# Generated at 2022-06-17 07:02:35.291533
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.name = "test"
    obj.isa = "test"
    obj.default = "test"
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = "test"
    obj.listof = "test"
    obj.aliases = "test"
    obj.private = True
    obj.version_added = "test"
    obj.version_removed = "test"
    obj.deprecated_for = "test"
    obj.removed_in_version = "test"
    obj.aliases = "test"
    obj.private = True
    obj.version_added = "test"
    obj.version_removed = "test"

# Generated at 2022-06-17 07:03:26.329341
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    f = FieldAttributeBase()
    assert f.get_ds() == None

# Generated at 2022-06-17 07:03:31.760362
# Unit test for method dump_attrs of class FieldAttributeBase

# Generated at 2022-06-17 07:03:41.959480
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.name = 'test_name'
    obj.value = 'test_value'
    obj.required = True
    obj.isa = 'test_isa'
    obj.default = 'test_default'
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test_class_type'
    obj.listof = 'test_listof'
    obj.choices = 'test_choices'
    obj.aliases = 'test_aliases'
    obj.version_added = 'test_version_added'
    obj.version_removed = 'test_version_removed'
    obj.deprecated_for_removal = True

# Generated at 2022-06-17 07:03:51.821159
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Create an instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new_new = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new_new_new = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new_new_new_new = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new_new_new_new_new = FieldAttributeBase()

    # Create a new instance of FieldAttributeBase
    field_attribute_base_new_new_new_new_new_new = FieldAttribute

# Generated at 2022-06-17 07:04:02.390261
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a FieldAttributeBase object
    obj = FieldAttributeBase()
    obj.name = 'test_name'
    obj.isa = 'test_isa'
    obj.default = 'test_default'
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test_class_type'
    obj.listof = 'test_listof'
    obj.static = True
    obj.priority = 1
    obj.aliases = ['test_alias']
    obj.choices = ['test_choice']
    obj.deprecated_choices = ['test_deprecated_choice']
    obj.deprecated_aliases = ['test_deprecated_alias']
    obj.version_added = 'test_version_added'
    obj.version_

# Generated at 2022-06-17 07:04:08.833846
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a valid object
    obj = FieldAttributeBase()
    obj.name = 'test_name'
    obj.required = True
    obj.default = 'test_default'
    obj.isa = 'test_isa'
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test_class_type'
    obj.listof = 'test_listof'
    obj.private = True
    obj.aliases = ['test_aliases']
    obj.version_added = 'test_version_added'
    obj.version_removed = 'test_version_removed'
    obj.deprecated_for = 'test_deprecated_for'
    obj.deprecated_since = 'test_deprecated_since'

# Generated at 2022-06-17 07:04:15.915895
# Unit test for method dump_attrs of class FieldAttributeBase