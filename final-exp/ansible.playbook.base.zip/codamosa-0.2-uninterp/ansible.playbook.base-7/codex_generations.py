

# Generated at 2022-06-17 06:54:59.439953
# Unit test for method dump_me of class FieldAttributeBase

# Generated at 2022-06-17 06:55:10.465386
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()
    data['uuid'] = 'test_uuid'
    data['finalized'] = True
    data['squashed'] = True
    data['name'] = 'test_name'
    data['action'] = 'test_action'
    data['args'] = 'test_args'
    data['async_val'] = 'test_async_val'
    data['async_seconds'] = 'test_async_seconds'
    data['become'] = 'test_become'
    data['become_user'] = 'test_become_user'
    data['become_method'] = 'test_become_method'
    data['become_flags'] = 'test_become_flags'
    data['become_info'] = 'test_become_info'

# Generated at 2022-06-17 06:55:18.196665
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a simple object
    obj = FieldAttributeBase()
    obj.foo = 'bar'
    obj.baz = 'qux'
    assert obj.dump_attrs() == {'foo': 'bar', 'baz': 'qux'}

    # Test with an object that has a serialize method
    class Serializable(object):
        def serialize(self):
            return {'foo': 'bar'}

    obj = FieldAttributeBase()
    obj.foo = Serializable()
    assert obj.dump_attrs() == {'foo': {'foo': 'bar'}}


# Generated at 2022-06-17 06:55:25.534564
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:55:30.668053
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.composer import AnsibleComposer

# Generated at 2022-06-17 06:55:32.005666
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # TODO: implement this test
    assert False


# Generated at 2022-06-17 06:55:43.936905
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:55:47.458877
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Create a FieldAttributeBase object
    field_attribute_base = FieldAttributeBase()
    # Test the method dump_me
    field_attribute_base.dump_me()


# Generated at 2022-06-17 06:55:56.513685
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Test with a valid value
    attrs = {'name': 'test', 'foo': 'bar'}
    obj = FieldAttributeBase()
    obj.from_attrs(attrs)
    assert obj.name == 'test'
    assert obj.foo == 'bar'
    assert obj._finalized == True
    assert obj._squashed == True

    # Test with an invalid value
    attrs = {'name': 'test', 'foo': 'bar'}
    obj = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        obj.from_attrs(123)


# Generated at 2022-06-17 06:56:00.825496
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Create an instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase()
    # Check if the method get_ds of FieldAttributeBase is working correctly
    assert field_attribute_base.get_ds() == None


# Generated at 2022-06-17 06:56:33.703723
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.requiremenets import RoleRequirement
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import TaskInclude
    from ansible.playbook.role.tasks import TaskIncludeArgs
    from ansible.playbook.role.tasks import TaskIncludeRole
    from ansible.playbook.role.tasks import TaskIncludeVars


# Generated at 2022-06-17 06:56:34.304429
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # TODO: implement
    pass


# Generated at 2022-06-17 06:56:42.667155
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_context import ROLE_CACHE
    from ansible.playbook.role_context import ROLE_CACHE_MAX_SIZE

# Generated at 2022-06-17 06:56:44.925509
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 06:56:54.704719
# Unit test for method get_validated_value of class FieldAttributeBase

# Generated at 2022-06-17 06:57:05.572893
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a dict
    data = dict()
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj._valid_attrs == dict()
    assert obj._attributes == dict()
    assert obj._attr_defaults == dict()
    assert obj._loader is None
    assert obj._variable_manager is None
    assert obj._validated is False
    assert obj._finalized is False
    assert obj._uuid is None
    assert obj._squashed is False
    assert obj._ds is None
    # Test with a str
    data = 'test'
    obj = FieldAttributeBase()

# Generated at 2022-06-17 06:57:13.638366
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # Test with a dict
    data = {'foo': 'bar'}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.foo == 'bar'
    # Test with a non-dict
    data = 'foo'
    obj = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError) as excinfo:
        obj.deserialize(data)
    assert 'data (foo) should be a dict but is a' in to_native(excinfo.value)


# Generated at 2022-06-17 06:57:26.097468
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test case 1:
    # Test if the method returns the dependency chain of the object
    # when the object is a task
    # Expected result:
    # The method should return the dependency chain of the object
    # when the object is a task
    test_task = Task()
    test_task._parent = Play()
    test_task._parent._parent = Playbook()
    test_task._parent._parent._parent = Role()
    test_task._parent._parent._parent._parent = Role()
    assert test_task.get_dep_chain() == [test_task._parent._parent._parent, test_task._parent._parent._parent._parent]

    # Test case 2:
    # Test if the method returns None
    # when the object is a play
    # Expected result:
    # The method should return None
    #

# Generated at 2022-06-17 06:57:31.667522
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_block import TaskBlock
   

# Generated at 2022-06-17 06:57:43.579390
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
   

# Generated at 2022-06-17 06:58:34.564692
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Test with a valid FieldAttributeBase object
    obj = FieldAttributeBase()
    obj.name = 'test_name'
    obj.isa = 'test_isa'
    obj.default = 'test_default'
    obj.static = 'test_static'
    obj.required = 'test_required'
    obj.always_post_validate = 'test_always_post_validate'
    obj.class_type = 'test_class_type'
    obj.listof = 'test_listof'
    obj.private = 'test_private'
    obj.aliases = 'test_aliases'
    obj.choices = 'test_choices'
    obj.deprecated_choices = 'test_deprecated_choices'
    obj.deprecated_aliases = 'test_deprecated_aliases'
   

# Generated at 2022-06-17 06:58:43.664213
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Test case 1:
    #   Test get_search_path() with a task inside a role
    #   The search path should be the path of the role
    #   and the path of the task
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.basedefs import BaseDefs
    from ansible.playbook.become import Become
   

# Generated at 2022-06-17 06:58:51.150519
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    # Create an instance of class FieldAttributeBase
    field_attribute_base_instance = FieldAttributeBase()

    # Test the method get_ds of class FieldAttributeBase
    # TODO: implement your test here
    assert True # remove this line and write your test here


# Generated at 2022-06-17 06:58:52.496585
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # TODO: implement test_FieldAttributeBase_validate
    pass


# Generated at 2022-06-17 06:58:58.343246
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of FieldAttribute
    field_attribute = FieldAttribute()

    # Create an instance of AnsibleParserError
    ansible_parser_error = AnsibleParserError()

    # Create an instance of AnsibleUndefinedVariable
    ansible_undefined_variable = AnsibleUndefinedVariable()

    # Create an instance of UndefinedError
    undefined_error = UndefinedError()

    # Create an instance of AnsibleAssertionError
    ansible_assertion_error = AnsibleAssertionError()

    # Create an instance of AnsibleParserError
    ansible_parser_error = AnsibleParserError()

    # Create an

# Generated at 2022-06-17 06:59:05.407419
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Create a FieldAttributeBase object
    fieldattributebase_obj = FieldAttributeBase()
    # Create a copy of the FieldAttributeBase object
    fieldattributebase_copy = fieldattributebase_obj.copy()
    # Check if the copy is a FieldAttributeBase object
    assert isinstance(fieldattributebase_copy, FieldAttributeBase)
    # Check if the copy is not the same object as the original
    assert fieldattributebase_copy is not fieldattributebase_obj
    # Check if the copy has the same attributes as the original
    assert fieldattributebase_copy.__dict__ == fieldattributebase_obj.__dict__


# Generated at 2022-06-17 06:59:08.379542
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # Test with a valid value
    attr = FieldAttributeBase()
    attr.validate(None)

    # Test with an invalid value
    attr = FieldAttributeBase()
    with pytest.raises(AnsibleAssertionError):
        attr.validate(1)

# Generated at 2022-06-17 06:59:16.216320
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    obj = FieldAttributeBase()

    # Test get_validated_value with valid data
    assert obj.get_validated_value('name', 'attribute', 'value', 'templar') == 'value'

    # Test get_validated_value with invalid data
    with pytest.raises(AnsibleParserError):
        obj.get_validated_value('name', 'attribute', 'value', 'templar')

# Generated at 2022-06-17 06:59:23.845776
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    field_attribute_base_instance = FieldAttributeBase()
    # Test the method with different inputs
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttributeBase_get_validated_value()
    # test_FieldAttribute

# Generated at 2022-06-17 06:59:30.288266
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # Test with a valid value
    attr = FieldAttributeBase(isa='string', default='foo')
    attr.load_data('bar')
    assert attr.value == 'bar'

    # Test with an invalid value
    attr = FieldAttributeBase(isa='string', default='foo')
    with pytest.raises(AnsibleParserError):
        attr.load_data(42)


# Generated at 2022-06-17 07:00:22.317824
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a FieldAttributeBase object
    test_obj = FieldAttributeBase()
    test_obj.name = 'test_name'
    test_obj.isa = 'test_isa'
    test_obj.default = 'test_default'
    test_obj.required = True
    test_obj.static = True
    test_obj.always_post_validate = True
    test_obj.class_type = 'test_class_type'
    test_obj.listof = 'test_listof'
    test_obj.aliases = ['test_alias']
    test_obj.choices = ['test_choice']
    test_obj.private = True
    test_obj.deprecated = True
    test_obj.removed_in_version = 'test_removed_in_version'
    test_obj.version

# Generated at 2022-06-17 07:00:34.645137
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Test with a simple object
    obj = FieldAttributeBase()
    obj.foo = 'bar'
    obj.baz = 'qux'
    assert obj.dump_attrs() == {'foo': 'bar', 'baz': 'qux'}
    # Test with a nested object
    obj = FieldAttributeBase()
    obj.foo = FieldAttributeBase()
    obj.foo.bar = 'baz'
    obj.foo.qux = 'quux'
    assert obj.dump_attrs() == {'foo': {'bar': 'baz', 'qux': 'quux'}}
    # Test with a nested object that has a serialize method
    obj = FieldAttributeBase()
    obj.foo = FieldAttributeBase()
    obj.foo.bar = 'baz'

# Generated at 2022-06-17 07:00:44.966815
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a default value
    attr = FieldAttributeBase(default=1)
    assert attr.dump_me() == 1
    # Test with a value
    attr = FieldAttributeBase(default=1)
    attr.value = 2
    assert attr.dump_me() == 2
    # Test with a value and a default
    attr = FieldAttributeBase(default=1)
    attr.value = 2
    assert attr.dump_me(default=3) == 2
    # Test with no value and a default
    attr = FieldAttributeBase()
    assert attr.dump_me(default=3) == 3
    # Test with a value and no default
    attr = FieldAttributeBase()
    attr.value = 2
    assert attr.dump_me() == 2


# Generated at 2022-06-17 07:00:57.132891
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()
    data['uuid'] = 'uuid'
    data['finalized'] = True
    data['squashed'] = True
    data['name'] = 'name'
    data['action'] = 'action'
    data['args'] = 'args'
    data['async_val'] = 'async_val'
    data['async_seconds'] = 'async_seconds'
    data['become'] = 'become'
    data['become_method'] = 'become_method'
    data['become_user'] = 'become_user'
    data['become_flags'] = 'become_flags'
    data['changed_when'] = 'changed_when'
    data['check_mode'] = 'check_mode'
    data['connection'] = 'connection'

# Generated at 2022-06-17 07:00:59.295295
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # TODO: Implement unit test for method get_validated_value of class FieldAttributeBase
    pass


# Generated at 2022-06-17 07:01:03.561608
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Setup
    # Run
    result = FieldAttributeBase.copy()
    # Verify
    assert isinstance(result, FieldAttributeBase)


# Generated at 2022-06-17 07:01:10.995511
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Create an instance of FieldAttributeBase
    fieldattributebase_instance = FieldAttributeBase()
    # Create an instance of AnsibleParserError
    ansibleparsererror_instance = AnsibleParserError()
    # Create an instance of AnsibleUndefinedVariable
    ansibleundefinedvariable_instance = AnsibleUndefinedVariable()
    # Create an instance of UndefinedError
    undefinederror_instance = UndefinedError()
    # Create an instance of TypeError
    typeerror_instance = TypeError()
    # Create an instance of ValueError
    valueerror_instance = ValueError()
    # Create an instance of Templar
    templar_instance = Templar()
    # Create an instance of Attribute
    attribute_instance = Attribute()
    # Create an instance of string_types
    string_types_instance = string_types()
    # Create an instance

# Generated at 2022-06-17 07:01:18.332736
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsAllGroupVars
    from ansible.vars.hostvars import HostVarsFileVars

# Generated at 2022-06-17 07:01:29.440872
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Base(with_metaclass(BaseMeta)):
        pass

    class Test(Base):
        a = FieldAttribute(isa='str')
        b = FieldAttribute(isa='str')

    assert Test._valid_attrs == {'a': Test.a, 'b': Test.b}
    assert Test._alias_attrs == {}
    assert Test._attr_defaults == {'a': None, 'b': None}
    assert Test._attributes == {'a': Sentinel, 'b': Sentinel}
    assert Test.a == Sentinel
    assert Test.b == Sentinel

    class Test2(Test):
        c = FieldAttribute(isa='str')

    assert Test2._valid_attrs == {'a': Test.a, 'b': Test.b, 'c': Test2.c}
    assert Test2._alias_

# Generated at 2022-06-17 07:01:39.889655
# Unit test for method from_attrs of class FieldAttributeBase

# Generated at 2022-06-17 07:03:02.292952
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {'name': 'test', 'description': 'test', 'foo': 'bar'}
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.name == 'test'
    assert obj.description == 'test'
    assert obj.foo == 'bar'


# Generated at 2022-06-17 07:03:13.253520
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    '''
    Test the method get_search_path of class Base
    '''
    # Create a mock object of class Base
    base_obj = Base()
    # Create a mock object of class Play
    play_obj = Play()
    # Create a mock object of class Role
    role_obj = Role()
    # Create a mock object of class Task
    task_obj = Task()
    # Create a mock object of class Task
    task_obj2 = Task()
    # Create a mock object of class Task
    task_obj3 = Task()
    # Create a mock object of class Task
    task_obj4 = Task()
    # Create a mock object of class Task
    task_obj5 = Task()
    # Create a mock object of class Task
    task_obj6 = Task()
    # Create a mock object of class Task
   

# Generated at 2022-06-17 07:03:20.321690
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Test with a FieldAttributeBase object
    field_attribute_base_obj = FieldAttributeBase()
    field_attribute_base_obj.copy()


# Generated at 2022-06-17 07:03:31.524827
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.vault import VaultSecret
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars


# Generated at 2022-06-17 07:03:36.740654
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict(a=1, b=2)
    obj = FieldAttributeBase()
    obj.deserialize(data)
    assert obj.a == 1
    assert obj.b == 2


# Generated at 2022-06-17 07:03:43.573535
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a FieldAttributeBase object
    obj = FieldAttributeBase()
    assert obj.dump_me() == {}
    # Test with a FieldAttributeBase object with attributes
    obj = FieldAttributeBase()
    obj.name = 'test'
    obj.isa = 'test'
    obj.default = 'test'
    obj.static = 'test'
    obj.required = 'test'
    obj.always_post_validate = 'test'
    obj.class_type = 'test'
    obj.listof = 'test'
    assert obj.dump_me() == {'name': 'test', 'isa': 'test', 'default': 'test', 'static': 'test', 'required': 'test', 'always_post_validate': 'test', 'class_type': 'test', 'listof': 'test'}

#

# Generated at 2022-06-17 07:03:53.090695
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create an instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase()
    # Create an instance of AnsibleParserError
    ansible_parser_error = AnsibleParserError()
    # Create an instance of string
    string = string()
    # Create an instance of int
    int = int()
    # Create an instance of float
    float = float()
    # Create an instance of bool
    bool = bool()
    # Create an instance of list
    list = list()
    # Create an instance of set
    set = set()
    # Create an instance of dict
    dict = dict()
    # Create an instance of class
    class_ = class_()
    # Create an instance of templar
    templar = templar()
    # get_validated_value(self, name, attribute, value, tem

# Generated at 2022-06-17 07:03:58.440867
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Test with a FieldAttributeBase object
    obj = FieldAttributeBase()
    obj.name = 'test_name'
    obj.isa = 'test_isa'
    obj.default = 'test_default'
    obj.required = True
    obj.static = True
    obj.always_post_validate = True
    obj.class_type = 'test_class_type'
    obj.listof = 'test_listof'
    obj.private = True
    obj.aliases = ['test_alias1', 'test_alias2']
    obj.choices = ['test_choice1', 'test_choice2']
    obj.deprecated_choices = ['test_deprecated_choice1', 'test_deprecated_choice2']

# Generated at 2022-06-17 07:04:06.134974
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class Base_mock(Base):
        def __init__(self, parent):
            self._parent = parent
    class Role_mock(Role):
        def __init__(self, parent):
            self._parent = parent
    class Play_mock(Play):
        def __init__(self, parent):
            self._parent = parent
    class Task_mock(Task):
        def __init__(self, parent):
            self._parent = parent
    class Playbook_mock(Playbook):
        def __init__(self, parent):
            self._parent = parent
    class PlayContext_mock(PlayContext):
        def __init__(self, parent):
            self._parent = parent
    class TaskExecutor_mock(TaskExecutor):
        def __init__(self, parent):
            self

# Generated at 2022-06-17 07:04:15.377101
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test with a task
    task = Task()
    task._parent = Play()
    task._parent._parent = Playbook()
    assert task.get_dep_chain() == [task._parent, task._parent._parent]

    # Test with a play
    play = Play()
    play._parent = Playbook()
    assert play.get_dep_chain() == [play._parent]

    # Test with a playbook
    playbook = Playbook()
    assert playbook.get_dep_chain() == None

    # Test with a role
    role = Role()
    role._parent = Playbook()
    assert role.get_dep_chain() == [role._parent]

    # Test with a block
    block = Block()
    block._parent = Task()
    block._parent._parent = Play()
    block._parent._parent._parent