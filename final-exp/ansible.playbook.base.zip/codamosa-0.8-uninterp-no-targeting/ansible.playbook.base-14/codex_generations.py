

# Generated at 2022-06-21 00:12:39.292814
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    # The following are all copied from the example above

    class Parent(object):
        name = FieldAttribute(isa='string')
        num = FieldAttribute(isa='int', default=5)


    class Child(Parent):
        name = FieldAttribute()
        num = FieldAttribute()
        thing = FieldAttribute(isa='list', default=[])
        other = FieldAttribute(isa='list', default=[])
        more = FieldAttribute(isa='list', default=[])
        repeat = FieldAttribute(isa='list', default=[])

    p = Parent()
    c = Child()
    p.name = 'parent'
    p.num = 5
    c.name = 'child'
    c.num = 10
    c.thing = 'foo'
    c.other = 'bar'
    c.more = 'baz'
    c.repeat

# Generated at 2022-06-21 00:12:47.428940
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    parameters = {'name': 'foo', 'isa': 'string'}
    field_attribute_base = FieldAttributeBase(**parameters)
    value = 'foo'
    templar = AnsibleMock({'omit': 'omit', 'template': lambda x: x})
    result = field_attribute_base.get_validated_value('foo', field_attribute_base, value, templar=templar)
    assert result == value



# Generated at 2022-06-21 00:12:50.228339
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method dump_me of class FieldAttributeBase
    '''
    # TODO: ...
    pass


# Generated at 2022-06-21 00:12:54.099442
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class BaseA(object):
        # A method is defined
        def _get_attr_inherit(self):
            return True
        def _get_attr_missing(self):
            return True
        _attr_inherit = FieldAttribute(isa='bool', inherit=True, default=True)
        _attr_missing = FieldAttribute(isa='bool', inherit=False, default=True)
        _attr_hidden = FieldAttribute(isa='bool', inherit=False, default=True, hidden=True)
        _attr_alias = FieldAttribute(isa='bool', default=True, alias='_alias')
        _attr_alias_alias = FieldAttribute(isa='bool', default=True, alias='_alias_alias')
        def get_attr_alias(self):
            return True

# Generated at 2022-06-21 00:12:59.365263
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    parser = MockParser()
    loader = MockLoader()
    mock_variable_manager = MagicMock(VariableManager)
    mock_variable_manager.get_vars.return_value = {'foo': 'foo_val'}

    obj = FieldAttributeBase()
    obj.set_loader(loader)
    obj.set_variable_manager(mock_variable_manager)

    assert obj.get_variable_manager() == mock_variable_manager


# Generated at 2022-06-21 00:13:00.956169
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    assert "Not Implemented" == FieldAttributeBase.serialize()


# Generated at 2022-06-21 00:13:13.515514
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class A:
        _f_a = FieldAttribute(isa='str', default='a')

    class B(A):
        _f_b = FieldAttribute(isa='str', default='b')
        def _get_attr_f_b(self):
            return 'c'

    class C(B):
        def _get_parent_attribute(self, child, attr_name):
            return 'g'

    class D(C):
        _f_d = FieldAttribute(isa='str', default='d', inherit=False)

    class E(C):
        _f_b = FieldAttribute(isa='str', default='b')

    class F(E):
        def _get_parent_attribute(self, child, attr_name):
            return 'g'

    class G(F):
        pass


# Generated at 2022-06-21 00:13:19.826784
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    ansible = Ansible()
    ansible._config_data = dict()
    ansible._config_data['DEFAULT'] = dict()
    ansible._config_data['DEFAULT']['DEPRECATION_WARNINGS'] = False
    ansible.version_info = dict()
    ansible.version_info['RELEASE'] = '2.9.4'
    ansible.version = '2.9.4'
    values = dict()
    values['ansible'] = ansible
    values['self'] = ansible
    values['value'] = 'a string'
    # initializing instance of class FieldAttributeBase
    obj = FieldAttributeBase(values)
    values = dict()
    values['ansible'] = ansible
    values['self'] = ansible
    values['value'] = 'a string'
    # initializing

# Generated at 2022-06-21 00:13:21.709171
# Unit test for constructor of class Base
def test_Base():
    '''
    Construct a Base object with only required arguments
    '''
    Base()



# Generated at 2022-06-21 00:13:22.805772
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pass


# Generated at 2022-06-21 00:13:47.138909
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    pass

# Generated at 2022-06-21 00:13:53.483127
# Unit test for method get_path of class Base
def test_Base_get_path():
    parent = Base()
    parent._ds = object()
    parent._ds._data_source = "test_Base_get_path"
    parent._ds._line_number = 0
    assert parent.get_path() == "test_Base_get_path:0"


# Generated at 2022-06-21 00:14:03.583927
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    import unittest
    import unittest.mock as mock
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)
    playbook = PlayContext(loader=data_loader, variable_manager=variable_manager, vault_password=None)
    role = Role(loader=data_loader)
    role.vars = dict

# Generated at 2022-06-21 00:14:13.477521
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    class_attributes_base = {'_name': FieldAttribute(isa='string', default=None), '_aliases': FieldAttribute(isa='list', default=None), '_uuid': FieldAttribute(isa='string', default=None), '_loader': FieldAttribute(isa='string', default=None), '_variable_manager': FieldAttribute(isa='string', default=None), '_validated': FieldAttribute(isa='boolean', default=False), '_finalized': FieldAttribute(isa='boolean', default=False), '_attributes': FieldAttribute(isa='dict', default=None), '_attr_defaults': FieldAttribute(isa='dict', default=None), '_valid_attrs': FieldAttribute(isa='dict', default=None), '_alias_attrs': FieldAttribute(isa='dict', default=None)}
    class_attributes_

# Generated at 2022-06-21 00:14:17.013487
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test method:
        get_variable_manager()

    Purpose:
        Provides an alias for _variable_manager for backwards compatibility
    '''
    print('')


# Generated at 2022-06-21 00:14:20.059228
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    obj = FieldAttributeBase()
    fixture_value_1 = None
    assert obj.get_variable_manager() == fixture_value_1



# Generated at 2022-06-21 00:14:20.771335
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass

# Generated at 2022-06-21 00:14:23.883877
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    n = FieldAttributeBase()
    assert n.preprocess_data('foo', 'foo') == 'foo'


# Generated at 2022-06-21 00:14:34.993922
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    a = FieldAttributeBase()
    assert isinstance(a.default, Sentinel)

    a = FieldAttributeBase(default='test')
    assert a.default == 'test'

    a = FieldAttributeBase(default=42)
    assert a.default == 42

    assert a.required is False
    a = FieldAttributeBase(required=True)
    assert a.required is True

    assert a.alias is None
    a = FieldAttributeBase(alias='test')
    assert a.alias == 'test'

    assert a.always_post_validate is False
    a = FieldAttributeBase(always_post_validate=True)
    assert a.always_post_validate is True

    assert a.static is False
    a = FieldAttributeBase(static=True)
    assert a.static is True


# Generated at 2022-06-21 00:14:40.406092
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # Arrange
    class BaseTest(with_metaclass(BaseMeta, object)):
        a_attribute = FieldAttribute(isa='str')

    # Act
    base_test = BaseTest()
    base_test.a_attribute

    # Assert
    assert isidentifier(base_test.a_attribute)



# Generated at 2022-06-21 00:15:49.944165
# Unit test for method get_search_path of class Base

# Generated at 2022-06-21 00:16:02.365814
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

    play = dict(
        name = "A play",
        hosts = "all",
        gather_facts = False,
        vars = [
            dict(x=1, y=2, z=3),
            dict(x=4, y=5, z=6)
        ]
    )

    yaml_obj = AnsibleBaseYAMLObject()
    yaml_obj.ansible_pos = (1, 0)
    yaml_obj.ansible_line = 1
    yaml_obj.root_ds = dict(name='')
    yaml_obj._ds = dict

# Generated at 2022-06-21 00:16:09.307160
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultAwareUnsafeLoader, VaultAwareUnsafeDumper

    # Create a fake templar object
    obj_vaultlib = VaultLib()
    obj_vaultlib.password = ''
    obj_VariableManager = VariableManager()
    obj_VariableManager.vault_password = obj_vaultlib.password
    obj_vaultlib._get_vault_password = obj_VariableManager.get_vault_password
    obj_loader = VaultAwareUnsafeLoader(stream=None)
    obj_dumper = VaultAwareUnsafeDumper(stream=None)
    obj_vault

# Generated at 2022-06-21 00:16:11.022807
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    # Arguments
    templar = {}

    # Return value
    return (None)

# Generated at 2022-06-21 00:16:15.153298
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method FieldAttributeBase.get_loader
    '''
    field_attribute_base = FieldAttributeBase()
    loader = field_attribute_base.get_loader()
    assert loader is None


# Generated at 2022-06-21 00:16:20.753976
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    f = yaml.load(dedent(u'''
    hostname: {{ ansible_ssh_host }}
    '''))
    result = FieldAttributeBase._load_data(f)
    assert result == {u'hostname': {u'ansible_ssh_host': u'{{ ansible_ssh_host }}'}}, result


# Generated at 2022-06-21 00:16:23.687058
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    f = FieldAttributeBase()
    assert(None == f.get_loader())



# Generated at 2022-06-21 00:16:35.491157
# Unit test for constructor of class Base
def test_Base():

    # prevent accidental use of cli args
    context.CLIARGS = {}

    b1 = Base()

    assert b1._connection == ''
    assert b1._port is None
    assert b1._remote_user == 'root'
    assert b1._vars == {}
    assert b1._module_defaults == []
    assert b1._environment == []
    assert b1._no_log is False
    assert b1._run_once is False
    assert b1._ignore_errors is False
    assert b1._ignore_unreachable is False
    assert b1._check_mode is False
    assert b1._diff is False
    assert b1._any_errors_fatal is False
    assert b1._throttle == 0
    assert b1._timeout == C.TASK_TIMEOUT
    assert b1

# Generated at 2022-06-21 00:16:41.612975
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # NOTE: this is only a test of the parts of __set__ that are common to all FieldAttribue subclasses
    fldattr = FieldAttributeBase()
    value = mock.MagicMock()
    value.foo = 'bar'
    obj = mock.MagicMock()
    obj.foo = 'value'
    with pytest.raises(AnsibleAssertionError) as excinfo:
        fldattr.__set__(obj, value, name='foo')
    assert excinfo.value.args[0] == "value (%s) should be a type in %s but is a %s" % ('foo', 'list', type('foo'))



# Generated at 2022-06-21 00:16:52.369638
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    """Test for preprocess_data of FieldAttributeBase"""

    obj = FieldAttributeBase()

    # Get an instance of the FieldAttributeBase class
    FieldAttributeBase_instance = FieldAttributeBase()

    # Initializing the "_default" variable
    FieldAttributeBase_instance._default = "yes"

    # The "_default" variable should be "yes"
    assert FieldAttributeBase_instance._default == "yes"

    # "final_value" should updated to be "yes".
    # (For comparison, the default value would be None.)
    final_value = obj.preprocess_data("yes", FieldAttributeBase_instance)

    # "final_value" should be equal to "yes"
    assert final_value == "yes"

# Generated at 2022-06-21 00:17:58.749315
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from mock import MagicMock
    instance = FieldAttributeBase()
    assert not hasattr(instance, '_post_validate_')


# Generated at 2022-06-21 00:18:09.918196
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    validator = FieldAttributeBase()
    f = FieldAttribute()
    validator._valid_attrs = {
        'string': f,
        'int': f,
        'float': f,
        'bool': f,
        'percent': f,
        'list': f,
        'set': f,
        'dict': f
    }
    templar = MagicMock()
    templar.available_variables = {'omit': 'omit'}
    templar.is_template = MagicMock(return_value=False)
    validator.get_validated_value('string', validator.string, 'string', templar)
    validator.get_validated_value('int', validator.int, 1, templar)

# Generated at 2022-06-21 00:18:16.111661
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    # Test a FieldAttributeBase object with no base_class
    #   make sure the correct exception is raised
    obj = FieldAttributeBase()
    try:
        obj.squash()
    except Exception as e:
        if type(e) is not TypeError:
            raise AssertionError("expected TypeError, got %s" % type(e))

    # Test a FieldAttributeBase object with a base_class that is not
    #   derived from BaseObject
    #   make sure the correct exception is raised
    obj = FieldAttributeBase(base_class=dict)
    try:
        obj.squash()
    except Exception as e:
        if type(e) is not TypeError:
            raise AssertionError("expected TypeError, got %s" % type(e))

    # Test a FieldAttributeBase object with a base_class that

# Generated at 2022-06-21 00:18:17.829504
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass



# Generated at 2022-06-21 00:18:21.071800
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
  # Declare class to be tested
  class UnderTest(Base):
    pass
  # Declare parent class of class to be tested
  class UnderTest_parent(Base):
    pass
  # Create instance of a parent class of class to be tested
  undertest_parent = UnderTest_parent()
  # Create instance of class to be tested
  undertest = UnderTest()
  # Set parent of instance of class to be tested
  undertest._parent = undertest_parent
  # Verify method when parent is set
  assert undertest.get_dep_chain() == None, "One parameter passed to test case"



# Generated at 2022-06-21 00:18:31.608180
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    ansible_posix_system = ansible_system
    if sys.platform == 'win32':
        ansible_posix_system = 'Linux'

    # test the default values
    with pytest.raises(AnsibleAssertionError):
        FieldAttribute(None)
    with pytest.raises(AnsibleAssertionError):
        FieldAttribute('')
    with pytest.raises(AnsibleAssertionError):
        FieldAttribute({})
    # check if we always get an instance back
    assert FieldAttribute('bool') is not None
    assert FieldAttribute('bool', default=True) is not None
    assert FieldAttribute('bool', default=False) is not None
    assert FieldAttribute('bool', default=None) is not None

# Generated at 2022-06-21 00:18:32.398493
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pass

# Generated at 2022-06-21 00:18:36.436107
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    my_FieldAttributeBase = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        my_FieldAttributeBase.dump_me()

# Generated at 2022-06-21 00:18:42.368881
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    print(__file__)
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.isa = None
    field_attribute_base.required = None
    field_attribute_base.default = None
    field_attribute_base.static = None
    field_attribute_base.always_post_validate = None
    field_attribute_base.class_type = None
    field_attribute_base.listof = None
    # TODO(rhaen): unittest.mock.patch()?
    args = None
    kwargs = {'name':None, 'attribute':None, 'value':None, 'templar':None}
    actual = field_attribute_base.get_validated_value(**kwargs)
    expected = None
    assert actual == expected


# Generated at 2022-06-21 00:18:44.952351
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()
    assert obj.get_validated_value() == None

# Generated at 2022-06-21 00:21:17.298646
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test_field = FieldAttributeBase()
    with pytest.raises(AnsibleParserError) as exc:
        test_field.load_data()
    assert 'the field \'None\' is required but was not set' in str(exc)



# Generated at 2022-06-21 00:21:28.363042
# Unit test for constructor of class Base
def test_Base():
    from ansible.playbook.play_context import PlayContext

    # Create Base object with data