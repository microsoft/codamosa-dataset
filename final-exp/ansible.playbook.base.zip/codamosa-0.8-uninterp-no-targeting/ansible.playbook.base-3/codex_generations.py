

# Generated at 2022-06-21 00:12:45.941864
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    # TODO: Should be able to replace this with a test_type() call to
    # base class, and confirm that deserialize() is exposed
    pass

# Generated at 2022-06-21 00:12:56.785423
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    global __dir__
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader

    # Yaml(hosts=['localhost'], roles={}, name=None, vars={}, include_tasks=None, tasks=[])
    # BEGIN of test code for attribute "vars"
    vars = {}
    # END of test code for attribute "vars"
    # BEGIN of test code for attribute "include_tasks"
    include_tasks = None
    # END of test code for attribute "include_tasks"
    # BEGIN of test code for attribute "roles"
    roles = {}
    # END of test code for attribute "roles"
    # BEGIN of test code for attribute "task_var"

# Generated at 2022-06-21 00:13:04.343502
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
  fb = FieldAttributeBase()
  fb._validated = False
  fb._finalized = False
  fb._uuid = ''
  assert fb._validated == False
  assert fb._finalized == False
  assert fb._uuid == ''
  fb.post_validate(templar)
  assert fb._validated == True
  assert fb._finalized == True
  assert fb._uuid == ''


# Generated at 2022-06-21 00:13:15.697330
# Unit test for method copy of class FieldAttributeBase

# Generated at 2022-06-21 00:13:16.431146
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
  pass

# Generated at 2022-06-21 00:13:26.089187
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    # create fake ds, to represent where the object was instantiated in the playbook
    fake_ds = FakeDS(root_dir="./")
    # create fake parent objective
    class MockParent(object):
        def __init__(self):
            self._dep_chain = [1, 2, 3]
    # create fake Base object
    baseObj = Base()

    # check if the return value is true
    obj = baseObj.get_dep_chain()
    assert obj is None

    # check the return value when obj has parent
    baseObj._parent = MockParent()
    obj = baseObj.get_dep_chain()
    assert obj == [1, 2, 3]


    obj = baseObj.get_path()
    assert obj == ""

    # check the return value when obj has parent
    baseObj._parent = Mock

# Generated at 2022-06-21 00:13:31.367544
# Unit test for constructor of class Base
def test_Base():
    '''
    Test constructor of class Base.
    '''

    # The class is abstract and used as base class, there is no need
    # to instantiate the class directly.
    b = Base()

    assert isinstance(b, Base)

    with pytest.raises(AnsibleError):
        b.validate()



# Generated at 2022-06-21 00:13:33.591705
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    result = FieldAttributeBase.validate(None, None)
    assert result is None



# Generated at 2022-06-21 00:13:36.389733
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class A(object):
        __metaclass__ = BaseMeta
        _metadata = FieldAttribute(isa='dict')



# Generated at 2022-06-21 00:13:45.938255
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    dict_val = dict()
    dict_val = dict(attr = 'value')
    dict_val = dict(attr = 'value', attr2 = 'value2')
    dict_val = dict(attr = [])
    dict_val = dict(attr = [1,2,3])
    dict_val = dict(attr = dict())
    dict_val = dict(attr = dict(attr = 'value'))
    dict_val = dict(attr = dict(attr = 'value', attr2 = 'value2'))
    dict_val = dict(attr = dict(attr = dict()))
    dict_val = dict(attr = dict(attr = dict(attr = 'value')))
    dict_val = dict(attr = dict(attr = dict(attr = 'value', attr2 = 'value2')))
    dict_

# Generated at 2022-06-21 00:14:10.076594
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me(): # noqa
    # make instance and call dump_me
    my_instance = FieldAttributeBase()

    # check that the returned value is correct
    assert my_instance.dump_me() == {}


# Generated at 2022-06-21 00:14:11.538697
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    obj = FieldAttributeBase()
    assert obj.get_loader() is None

# Generated at 2022-06-21 00:14:16.298472
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    field_attributes_base = FieldAttributeBase()
    field_attributes_base._finalized = True
    field_attributes_base.__class__ = type('newclass', (FieldAttributeBase,), {'name': 'FieldAttributeBase'})
    assert False == field_attributes_base.squash()



# Generated at 2022-06-21 00:14:29.333457
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    obj = FieldAttributeBase(default='foo')
    assert isinstance(obj, FieldAttributeBase)
    assert obj.default == 'foo'
    assert obj.required == True
    assert obj.static == False
    assert obj.always_post_validate == False
    assert obj.aliases == []
    assert obj.isidentifier == False
    assert obj.scope is None
    assert obj.scope_term is None
    assert obj.scope_plugin_keyword is None
    assert obj.delete_action == 'delete'
    assert obj.update_action == 'replace'
    assert obj.version_added == None
    assert obj.version_removed is None
    assert obj.version_added_tags == set()
    assert obj.version_removed_tags == set()
    assert obj.deprecated_aliases == []

# Generated at 2022-06-21 00:14:32.190425
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    b = FieldAttributeBase()
    assert b.get_validated_value('name', 'attribute', 'value', 'templar') == 'value'

# Generated at 2022-06-21 00:14:32.913164
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
	pass



# Generated at 2022-06-21 00:14:44.065921
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    set_gather_facts = Task._valid_attrs['gather_facts'].value
    Task._valid_attrs['gather_facts'].value = False
    set_tags = Task._valid_attrs['tags'].value
    Task._valid_attrs['tags'].value = []
    set_any_errors_fatal = Task._valid_attrs['any_errors_fatal'].value
    Task._valid_attrs['any_errors_fatal'].value = False
    set_changed_when = Task._valid_attrs['changed_when'].value
    Task._valid_attrs['changed_when'].value = ''
    set_failed_when = Task._valid_attrs['failed_when'].value
    Task._valid_attrs['failed_when'].value = ''
    set_

# Generated at 2022-06-21 00:14:47.668752
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    f = FieldAttributeBase()
    f.from_attrs({'testattrib': 'testvalue'})
    assert f.testattrib == 'testvalue'


# Generated at 2022-06-21 00:14:49.492766
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    fieldattributebase = FieldAttributeBase()
    assert fieldattributebase.post_validate(object) is None

# Generated at 2022-06-21 00:14:52.665754
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
  ds = {'foo': 'bar'}
  value = FieldAttributeBase._serialize(ds)
  assert value == '{"foo": "bar"}'


# Generated at 2022-06-21 00:15:27.169640
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent(object):
        a = 'parent a'
        b = 'parent b'
        c = 'parent c'

    class Child(Parent):
        d = 'child d'
        e = 'child e'
        f = 'child f'

    class GrandChild(Child):
        a = 'grandchild a'
        b = 'grandchild b'
        g = 'grandchild g'
        h = 'grandchild h'

    assert GrandChild.a == 'grandchild a'
    assert GrandChild.b == 'grandchild b'
    assert GrandChild.c == 'parent c'
    assert GrandChild.d == 'child d'
    assert GrandChild.e == 'child e'
    assert GrandChild.f == 'child f'
    assert GrandChild.g == 'grandchild g'
    assert GrandChild.h

# Generated at 2022-06-21 00:15:29.165525
# Unit test for method get_path of class Base
def test_Base_get_path():
    # this test has to be written
    assert True



# Generated at 2022-06-21 00:15:38.703205
# Unit test for method get_path of class Base
def test_Base_get_path():
    parser = Parser()
    blocks = parser.parse_playbooks(['./test/units/parser/data/tasks_path.yml'])
    assert len(blocks) == 2
    pb = PlayBook(playbook='./test/units/parser/data/tasks_path.yml', inventory=InventoryManager(loader=None, sources="localhost"))
    pb._blocks = blocks
    for play in pb.get_plays():
        for t in play.get_tasks():
            assert t.get_path() == "./test/units/parser/data/tasks_path.yml:6"


# Generated at 2022-06-21 00:15:40.708064
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    f = FieldAttributeBase()
    assert f.dump_me() == None


# Generated at 2022-06-21 00:15:50.337006
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class BaseMetaDummy(object):
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

        def __getattribute__(self, attr):
            # Called when accessing attribute(s) of class
            if attr == '_attributes':
                return getattr(self, attr)
            elif attr == '_attr_defaults':
                return getattr(self, attr)
            elif attr == '_valid_attrs':
                return getattr(self, attr)
            elif attr == '_alias_attrs':
                return getattr(self, attr)
            else:
                return 'Value of _attributes attribute'


# Generated at 2022-06-21 00:15:52.996436
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Not possible to test this method because we can't call set_variable_manager
    # before calling get_variable_manager
    assert False


# Generated at 2022-06-21 00:15:55.507801
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Test for method serialize(self)
    # This class is an abstract base class, and cannot be tested directly
    pass


# Generated at 2022-06-21 00:16:08.540843
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    """Method to unit test method get_search_path of class Base"""
    # Create a Base object
    base_obj = Base()
    # Create a new Base object and assign it to attribute _parent of Base object
    base_obj._parent = Base()
    # Create a new Base object and assign it to attribute _parent of Base object
    base_obj._parent._parent = Base()
    # Assign a role path to role path attribute of both the Base object
    base_obj._parent._role_path = 'role_path1'
    base_obj._parent._parent._role_path = 'role_path2'
    # Assign a data source to data_source attribute of both the Base object
    base_obj._parent._ds = 'data_source'
    base_obj._parent._parent._ds = 'data_source'
    # Assign

# Generated at 2022-06-21 00:16:13.975182
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Assert that get_variable_manager doesn't raise an exception when the object was properly initialized
    attribute = FieldAttributeBase()
    object = Base.__new__(Base)
    object.__init__(loader=Mock(), variable_manager=Mock())
    attribute.attach_to_object(object)
    attribute.get_variable_manager()



# Generated at 2022-06-21 00:16:26.535099
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Used to test inheritance, in this case being able to accept
    # a task with a name of an AnsibleModule and a string as a field
    # (in this case name)
    class AnsibleModuleTask(Task):
        pass

    class BaseObject(Base):

        _valid_attrs = dict(
            test_string=FieldAttribute(isa='string', default=['abc', 'xyz'], inherit=True),
            test_special=FieldAttribute(isa='special_string', default=[u'abc', u'xyz']),
        )

    class DerivedObject(BaseObject):

        _valid_attrs = dict(
            derived_attr=FieldAttribute(isa='string', default=['derived']),
        )


# Generated at 2022-06-21 00:17:02.564426
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent(object):
        pass

    class Child(Parent):
        parent_attr = FieldAttribute(isa='str', default='parent')
        child_attr = FieldAttribute(isa='int', default=1)

    parent = Parent()
    parent.attr = FieldAttribute(isa='str', default='parent')
    parent.grandparent_attr = FieldAttribute(isa='str', default='grandparent')

    assert hasattr(parent, 'attr')
    assert hasattr(parent, 'grandparent_attr')
    assert not hasattr(parent, 'child_attr')
    assert not hasattr(parent, 'parent_attr')

    child = Child()
    child.attr = FieldAttribute(isa='str', default='child')

    assert hasattr(child, 'attr')
    assert hasattr(child, 'child_attr')
    assert hasattr

# Generated at 2022-06-21 00:17:15.229927
# Unit test for constructor of class BaseMeta
def test_BaseMeta():

    class A(object):  # noqa: F811
        foo = FieldAttribute(isa='str')

    class A2(A):  # noqa: F811
        pass

    class B(object):  # noqa: F811
        grault = FieldAttribute(isa='str')

    class C(A, B):  # noqa: F811
        bar = FieldAttribute(isa='str')
        plugh = FieldAttribute(isa='str', inherit=False)

    class D(A, B):  # noqa: F811
        plugh = FieldAttribute(isa='str', inherit=False)
    actual = set(C._valid_attrs)
    expected = set(['foo', 'bar', 'grault', 'plugh'])
    assert actual == expected

# Generated at 2022-06-21 00:17:23.878591
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # Initializing a task with default values.
    my_task = Task()

    my_task.name = 'foo'
    my_task.action = 'bar'
    my_task.args = ''

    # This is how the task would be stored in the database
    # (we are skipping additional values that are not fields
    #  since they are of no importance in this test case).

# Generated at 2022-06-21 00:17:25.789710
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test_object = FieldAttributeBase()
    assert test_object.validate() == NotImplementedError


# Generated at 2022-06-21 00:17:37.924300
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    meth_def = FieldAttributeBase._FieldAttributeBase__dump_me.__func__
    meth = MethodType(meth_def, FieldAttributeBase)

    obj = FieldAttributeBase()
    obj._valid_attrs = {'foo': object()}

    try:
        meth(obj, 'foo')
    except AnsibleInternalError:
        pass
    else:
        assert False, "AnsibleInternalError was not raised"

    obj._valid_attrs = {'foo': BaseAttribute(isa='string', private=True)}

    try:
        meth(obj, 'foo')
    except AnsibleUndefinedVariable:
        pass
    else:
        assert False, "AnsibleUndefinedVariable was not raised"

    obj._valid_attrs = {'foo': BaseAttribute(isa='string')}

# Generated at 2022-06-21 00:17:39.588296
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    host = FakeHost()
    ds = dict(a=3, b=True)
    obj = FieldAttributeBase(host, ds)
    actual = obj.copy()
    assert host.get_expanded_vars() == dict(a=3, b=True)



# Generated at 2022-06-21 00:17:47.143203
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # test cases

    # default
    path_stack = Base().get_search_path()
    assert path_stack == []

    # path stack
    test_Base = Base()
    test_Base._ds._data_source = 'test/ds.yml'
    test_Base._ds._line_number = 1
    test_Base._parent._play._ds._data_source = 'test/test_Base_get_search_path.yml'
    test_Base._parent._play._ds._line_number = 1
    path_stack = test_Base.get_search_path()
    assert path_stack == []

    # inside role: add the dependency chain from current to dependent
    test_Base = Base()
    test_Base._ds._data_source = 'test/ds.yml'
    test_Base._ds._

# Generated at 2022-06-21 00:17:48.759031
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # post_validate(templar)
    # TODO: mock templar and add tests
    pass


# Generated at 2022-06-21 00:17:53.774295
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    def attribute_base_test():
        # Test base behaviour
        base_attribute = AnsibleBaseFieldAttribute(default=True)
        assert base_attribute.default is True
        assert base_attribute.deserialize(False) is False
    attribute_base_test()

# Generated at 2022-06-21 00:17:58.648444
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Create a task object to test
    task = Task()
    task.vars = {'my_var': 'hello'}
    var_manager = task.get_variable_manager()
    assert var_manager.get_vars(loader=None) == {'my_var': 'hello'}

# Generated at 2022-06-21 00:18:36.809303
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    def test_func(self, name, attribute):
        return attr_helper(self, name, attribute)
    setattr(FieldAttributeBase, 'test_func', test_func)

    try:
        FieldAttributeBase.test_func(None, None, None)
    except Exception as e:
        print("FieldAttributeBase.get_loader(): %s" % e)
    finally:
        delattr(FieldAttributeBase, 'test_func')



# Generated at 2022-06-21 00:18:37.518759
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    assert True


# Generated at 2022-06-21 00:18:39.562943
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    my_object = FieldAttributeBase()
    print(my_object.dump_attrs())


# Generated at 2022-06-21 00:18:42.093390
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    my_object = FieldAttributeBase()

    # Insert your test code here
    assert True # TODO: implement your test here


# Generated at 2022-06-21 00:18:43.701855
# Unit test for constructor of class Base
def test_Base():
    assert Base()



# Generated at 2022-06-21 00:18:45.317491
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert BaseMeta('BaseMeta', [], {}) is not None



# Generated at 2022-06-21 00:18:55.176308
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    fun = FieldAttributeBase._get_validated_value
    obj = FieldAttributeBase()

    # Test when attribute.isa is string
    assert fun(obj, 'name', FieldAttribute('name', str, False, False), 'abc') == 'abc'

    # Test when attribute.isa is int
    assert fun(obj, 'name', FieldAttribute('name', int, False, False), '123') == 123

    # Test when attribute.isa is float
    assert fun(obj, 'name', FieldAttribute('name', float, False, False), '123.123') == 123.123

    # Test when attribute.isa is bool
    assert fun(obj, 'name', FieldAttribute('name', bool, False, False), 'yes') is True

    # Test when attribute.isa is percent

# Generated at 2022-06-21 00:19:00.933827
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # setup
    attrs_1 = dict()
    # from_attrs
    try: # attrs contains unexpected keys
        fieldattributebase_1 = FieldAttributeBase()
        fieldattributebase_1.from_attrs(attrs_1)
    except AssertionError as e:
        print(e)
        pass

# Generated at 2022-06-21 00:19:10.195789
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field = FieldAttributeBase(isa='string', required=True, aliases=['bar'])
    field2 = FieldAttributeBase(isa='string', required=True, aliases=['bar'])
    fa = FieldAttributeBase(isa='class')
    fa._valid_attrs = {'field': field, 'field2': field2}
    fa.field = None
    fa.field2 = None
    fa2 = FieldAttributeBase(isa='class')
    fa2._valid_attrs = {'field': field, 'field2': field2}
    fa2.field = None
    fa2.field2 = None
    fa.from_attrs({'field': 'val1', 'field2': 'val2'})
    assert fa.field == 'val1'
    fa2.from_attrs(fa.serialize())
   

# Generated at 2022-06-21 00:19:14.690817
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
	my_attribute_value = FieldAttributeBase()
		
	# Load test values into method
	name = 'adhoc'
	attribute = None
	value = ['adhoc']
	templar = None
	test_values = [name, attribute, value, templar]
	
	# Run test and check for exceptions
	my_attribute_value.get_validated_value(*test_values)



# Generated at 2022-06-21 00:19:51.513368
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from collections import namedtuple
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    def check_get_search_path(obj):
        # TODO: make assertion here
        return obj.get_search_path()

    # load PlayContext
    PlayContext.load_context_from_args(Task.load_context_from_args(Base()))
    # load Play
    play = Play.load(
        dict(
            name="the_play",
            hosts="all",
        ),
        PlayContext(),
        loader=None,
        variable_manager=None
    )


# Generated at 2022-06-21 00:19:56.899102
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = [{'key1': 'value1', 'key2': 'value2'}, 'value3', None]

    expect = [{'key1': 'value1', 'key2': 'value2'}, 'value3']

    results = FieldAttributeBase.preprocess_data(data)

    assert results == expect, \
        "{0} != {1}".format(results, expect)

# Generated at 2022-06-21 00:20:09.316866
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class AnsibleBase:
        def __init__(self):
            self._loader = None
            self._variable_manager = None
            self._validated = None
            self._finalized = None
            self._aliases = None
            self._uuid = None
            self._attributes = None
            self._attr_defaults = None
            self._valid_attrs = None
            self._deprecations = {'<AnsibleBase>': {}}
            self._deprecated_names = {}
            self._aliases = {'<AnsibleBase>': {}}
            self._valid_attrs = {'<AnsibleBase>': {}}
            self._deprecated_aliases = {'<AnsibleBase>': {}}
            self.provider_name = None
            self._initialize_field_att

# Generated at 2022-06-21 00:20:16.118275
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # Check attributes of FieldAttributeBase class
    _attributes = ('required', 'default', 'fallback', 'always_post_validate', 'aliases', 'choices')
    for attr in _attributes:
        if not hasattr(FieldAttributeBase, attr):
            raise AssertionError("Class '%s' does not have expected attribute '%s'" % (FieldAttributeBase.__name__, attr))

    for attr in _attributes:
        value = getattr(FieldAttributeBase, attr)
        if not isinstance(value, property):
            raise AssertionError("'%s' should be a property" % attr)

    # Check that a FieldAttributeBase can be instantiated with no parameters
    f = FieldAttributeBase()
    assert f.required is None
    assert f.default == ''

# Generated at 2022-06-21 00:20:28.467732
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Test 1. Test get_dep_chain of action plugin
    test_action1 = module_loader.get('copy', class_only=True)
    test_action1._parent = None
    assert test_action1.get_dep_chain() is None

    # Test 2. Test get_dep_chain of Play
    test_play = Play()
    test_play._parent = None
    test_play._name = 'test_play'
    assert test_play.get_dep_chain() is None

    # Test 3. Test get_dep_chain of Role
    test_role = Role()
    test_role._name = 'test_role'
    test_role._parent = None
    assert test_role.get_dep_chain() is None

    # Test 4. Test get_dep_chain of Task in root play
    test

# Generated at 2022-06-21 00:20:31.111557
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    f = FieldAttributeBase()
    assert f.get_ds() is None


# Generated at 2022-06-21 00:20:31.816933
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
  pass

# Generated at 2022-06-21 00:20:41.275206
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    attr = FieldAttributeBase(default=None, always_post_validate=False, include_in_dump=True, default_in_dump=False, isa=None, class_type=None, static=False, required=False)
    data = dict()
    data_type = None
    post_validate_name = None
    templar = Templar(loader=None, variables={}, vault_secrets=vault)
    result = attr.preprocess_data(data, data_type, post_validate_name, templar)
    assert result is None


# Generated at 2022-06-21 00:20:44.144522
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
# Failed test, exit code: 1

    pass

# Generated at 2022-06-21 00:20:55.458256
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.dependency import RoleDependency
    from ansible.playbook.block import Block
    from ansible.playbook.include.role import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    base = Base()
    module_defaults = [{'new_key': 'new_value'}]
    environment = [{'new_key': 'new_value'}]
    vars = {}
    tags = ['tag1']
