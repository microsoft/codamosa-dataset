

# Generated at 2022-06-21 00:13:00.995665
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    FA = FieldAttributeBase()
    FA._valid_attrs = {
        "name": FieldAttribute(isa='str', default="test_name"),
        "vars": FieldAttribute(isa='dict', default={}),
        "test_task": FieldAttribute(isa='class', 
            class_type=Task, default=Task.defaults(),
            inherit=True, inherit_level=1)
    }

    FA.vars = {'a': 'b', 'c': 2}
    FA.name = "name1"
    FA.test_task = Task()
    FA.test_task.name = "task1"
    FA.test_task.vars = {'a': 'b1', 'c': 3}

# Generated at 2022-06-21 00:13:13.565475
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from .module_utils.six import PY3
    from .module_utils.common.collections import ImmutableDict
    class TestClass(object):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)
    # test with empty attrs
    attrs = ImmutableDict()
    e = AnsibleExitJson(attrs=attrs)
    assert(e.dump_attrs() == {})
    # test with one attr
    attrs = ImmutableDict(
        test_attr1={'type': 'str', 'default': 'test_str'})
    e = AnsibleExitJson(attrs=attrs)
    assert(e.dump_attrs() == {u'test_attr1': u'test_str'})
   

# Generated at 2022-06-21 00:13:23.866890
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from unittest import TestCase
    class MockRole(object):
        
        def get_dep_chain(self):
            return ['role_dep_chain']
            
    class MockBase(Base):
        @property
        def _parent(self):
            return MockRole()
            
    class MockBase_WithoutParent(Base):
        pass
            
    class TestBase(TestCase):
        
        def test_Base_get_dep_chain_with_parent(self):
            obj = MockBase()
            self.assertEqual(obj.get_dep_chain(), ['role_dep_chain'])
            
            
        def test_Base_get_dep_chain_without_parent(self):
            obj = MockBase_WithoutParent()
            self.assertEqual(obj.get_dep_chain(), None)
        

# Generated at 2022-06-21 00:13:30.142167
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class Fake_parent():
        _role_path = 'some_path'
        def __init__(self):
            self._role_path = Fake_parent._role_path
        def get_dep_chain(self):
            print("Fake_parent.get_dep_chain")
            return Fake_parent._role_path
    class Fake_base():
        def __init__(self):
            self._parent = Fake_parent()

    b = Fake_base()
    b.get_dep_chain()


# Generated at 2022-06-21 00:13:41.491893
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    class BaseObject():
        ''' Base class for all objects in the model, provides some common behaviour '''

        # These should be overridden to provide the specific type of the object
        _type_name = 'base'
        _type_short_name = 'base'

        def __init__(self):
            # All objects have a unique UUID
            self._uuid = uuid.uuid4()
            # Boolean to track if finalize() has been called
            self._finalized = False
            # Boolean to track if squashed() has been called
            self._squashed = False

        @property
        def uuid(self):
            ''' Returns the UUID of the object '''
            return self._uuid

        def __str__(self):
            ''' Human readable string representation of the object '''
            return self._to_str

# Generated at 2022-06-21 00:13:48.736251
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    data_set = [
        # attr_defaults, ds, expected
        # test:
        #   function input value
        #   expected output value
        #   output value datatype
        #   (optional) exception raised
        #   (optional) expected exception
        [
            {},
            None,
            None,
        ],
        [
            {'_ds': {'a': 'b'}},
            None,
            {'a': 'b'},
        ],
        [
            {'_ds': None},
            {'c': 'd'},
            {'c': 'd'},
        ],
        [
            {'_ds': {'a': 'b'}},
            {'c': 'd'},
            {'c': 'd'},
        ],
    ]

# Generated at 2022-06-21 00:13:50.384377
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass

# Generated at 2022-06-21 00:14:01.492807
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # test trivial path
    play1 = Play()
    play1._ds = Mock()
    play1._ds._data_source = "/tmp/a"
    play1._ds._line_number = 444
    assert play1.get_search_path() == ['/tmp/a']

    # test role dependency
    role2 = Role()
    role2._role_path = "/tmp/role2"
    role2._parent = play1
    role1 = Role()
    role1._role_path = "/tmp/role1"
    role1._parent = role2
    play3 = Play()
    play3._parent = role1
    play3._ds = Mock()
    play3._ds._data_source = "/tmp/b"
    play3._ds._line_number = 111
    assert play3.get_search_

# Generated at 2022-06-21 00:14:11.676499
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # base_path = os.path.dirname(__file__)
    # ansible_base_path = os.path.dirname(ansible.__file__)
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    # initialize a Base object, set path, and initialize a TaskInclude object
    base = Base()
    task = TaskInclude()
    # Initialize a list of role_path

# Generated at 2022-06-21 00:14:24.466653
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
  import copy
  import uuid

  def test_FieldAttributeBase_copy_FieldAttributeBase_class():
    base_obj = FieldAttributeBase()
    test_obj = base_obj.copy()
    
    assert isinstance(base_obj, FieldAttributeBase)
    assert isinstance(test_obj, FieldAttributeBase)
    assert test_obj == base_obj
    assert test_obj is not base_obj
    
  def test_FieldAttributeBase_copy_FieldAttributeBase_init_static_class(static_class='static_class'):
    base_obj = FieldAttributeBase(static_class=static_class)
    test_obj = base_obj.copy()
    
    assert isinstance(base_obj, FieldAttributeBase)
    assert isinstance(test_obj, FieldAttributeBase)
    assert test_obj == base_

# Generated at 2022-06-21 00:15:01.031304
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from ansible.compat.tests import unittest

    from ansible.compat.tests.mock import patch
    from ansible.module_utils import six
    from ansible.module_utils._text import to_text

    # Patch ansible.module_utils.six.moves.input to generate a test case for a "ansible.module_utils.basic._ANSIBLE_ARGS" invocation
    with patch.object(six.moves, 'input', lambda *args: to_text(u'ANSIBLE_MODULE_ARGS')):
        import ansible.module_utils.basic
        ansible_module_args = ansible.module_utils.basic._ANSIBLE_ARGS

    # Patch ansible.module_utils.urls.open_url to generate a test case for a "ansible.module_utils.urls.

# Generated at 2022-06-21 00:15:02.337998
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # FIXME: implement unit test
    pass


# Generated at 2022-06-21 00:15:06.546757
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    testdata = {}
    testobj = FieldAttributeBase()
    testobj.deserialize(testdata)

    # assert that AttributeError is raised on failure
    with pytest.raises(AnsibleAssertionError):
        testdata = None
        testobj = FieldAttributeBase()
        testobj.deserialize(testdata)

# Generated at 2022-06-21 00:15:09.481639
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    fa = FieldAttributeBase()
    loader = fa.get_loader()
    assert isinstance(loader, DataLoader)


# Generated at 2022-06-21 00:15:11.754286
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    print (obj.dump_me())
    assert True


# Generated at 2022-06-21 00:15:13.320718
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    obj = FieldAttributeBase()
    assert obj.squash is None


# Generated at 2022-06-21 00:15:17.588422
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    _host = 'hostname'
    _task = FieldAttributeBase()
    data = dict(a=1, b=2)

    _task.deserialize(data)
    assert _task.a == data['a']
    assert _task.b == data['b']

# Generated at 2022-06-21 00:15:19.047715
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    test_fieldattributebase = FieldAttributeBase()


# Generated at 2022-06-21 00:15:27.509614
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-21 00:15:39.461974
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    t = FieldAttributeBase()

    # only class_type is required
    # also test if subclass will be accepted
    t.class_type = TestModuleSpec
    t.validate(TestModuleSpec)

    # check other parameters
    t.static = False
    t.required = False
    t.default = None
    t.always_post_validate = False
    t.no_log = False
    t.no_lookup = False
    t.module_name = True
    t.task_name = True
    t.block_name = True
    t.no_log = True
    t.server_side_absent_data = True
    t.hash_name = True
    t.path_name = True
    t.load_name = True
    t.private_name = True
    t.finder_name

# Generated at 2022-06-21 00:16:34.846177
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base._name == ''
    assert base._connection is None
    assert base._port is None
    assert base._vars == {}
    assert base._module_defaults == []
    assert base._environment == []
    assert base._no_log is False
    assert base._run_once is False
    assert base._ignore_errors is False
    assert base._ignore_unreachable is False
    assert base._check_mode is False
    assert base._diff is False
    assert base._any_errors_fatal is True
    assert base._throttle is False
    assert base._timeout == 10
    assert base._debugger is None
    assert base._become is False
    assert base._become_method == 'sudo'
    assert base._become_user == ''

# Generated at 2022-06-21 00:16:37.451994
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = get_test_data("FieldAttributeBase-1.json")
    template = FieldAttributeBase()
    res = template.preprocess_data(data)
    assert res == data

# Generated at 2022-06-21 00:16:40.483015
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():

    # Make an instance
    fb = FieldAttributeBase()
    # get_ds() should raise an AssertionError when passed a single value
    # that isn't of type DataLoader or Task
    assert_raises(AnsibleAssertionError, fb.get_ds, [])



# Generated at 2022-06-21 00:16:43.188571
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Create an instance of class FieldAttributeBase
    obj = FieldAttributeBase(name='foo', default='bar')
    

# Generated at 2022-06-21 00:16:54.842246
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class AnsibleParserError(Exception):
        pass
    class AnsibleUndefinedVariable(Exception):
        pass
    class AnsibleUnsafeVariableError(Exception):
        pass
    class UndefinedError(Exception):
        pass
    class AnsibleAssertionError(Exception):
        pass
    class AnsibleAction(object):
        pass
    class AnsibleActionFail(AnsibleAction):
        pass
    class AnsibleActionDelay(AnsibleAction):
        pass
    class _AnsibleModule(object):
        pass
    class AnsibleModule(_AnsibleModule):
        pass
    class AnsiblePlaybook(object):
        pass
    class AnsibleUnicode(object):
        pass
    class AnsibleUnicodeMixin(AnsibleUnicode):
        pass

# Generated at 2022-06-21 00:16:58.750734
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    """
    Test for from_attrs
    """
    test_class = FieldAttributeBase
    foo = mock.Mock()
    foo.deserialize.return_value = True
    foo_dict = {'foo': foo}
    assert test_class.from_attrs(foo_dict) == None


# Generated at 2022-06-21 00:17:09.884721
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # simple test to make sure that dump_attrs of FieldAttributeBase
    # returns a dict containing the data of the fields
    results = FieldAttributeBase().dump_attrs()
    assert type(results) == dict, 'dump_attrs did not return a dict, instead it returned: {0}'.format(results)
    assert len(results) == 2, 'dump_attrs returned a dict with {0} results, instead of 2'.format(len(results))
    assert 'static' in results, 'dump_attrs did not contain the field name "static"'
    assert results['static'] == True, 'dump_attrs did not contain the field value True for the field "static"'
    assert 'required' in results, 'dump_attrs did not contain the field name "required"'

# Generated at 2022-06-21 00:17:11.058820
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert FieldAttributeBase.squash() == ()



# Generated at 2022-06-21 00:17:21.565523
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible import errors
    test_object = FieldAttributeBase()
    from ansible.vars.manager import VariableManager
    test_object_VariableManager = VariableManager()
    test_object.variable_manager = test_object_VariableManager
    test_object.variable_manager.set_play_context(play_context=None)
    from ansible.template import Templar
    test_object_Template = Templar(loader=None, variables=dict())
    test_object.variable_manager = test_object_VariableManager
    test_object.variable_manager.set_play_context(play_context=None)
    test_object.variable_manager.set_loader(loader=None)
    test_object._post_validate_name = lambda name: 'name'

# Generated at 2022-06-21 00:17:32.054256
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    playbook_obj = playbook.Playbook()
    mock_ds = MagicMock()
    mock_ds._data_source = "/path/to/playbook.yml"
    mock_ds._line_number = 1
    playbook_obj._ds = mock_ds

    # create an IncludeRole object inside playbook
    mock_ds = MagicMock()
    mock_ds._data_source = "/path/to/playbook.yml"
    mock_ds._line_number = 2
    include_role = irole.IncludeRole()
    include_role._ds = mock_ds

    # link IncludeRole to Playbook
    include_role._parent = playbook_obj

    # create a Role object inside IncludeRole
    mock_ds = MagicMock()

# Generated at 2022-06-21 00:18:03.891936
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    assert True

# Generated at 2022-06-21 00:18:10.137427
# Unit test for method get_path of class Base
def test_Base_get_path():
    # read yaml file
    data = read_yaml('./test/unit/model_data/task_include_task.yml')
    # serialize data into task object
    my_task = Task().load(data[0], variable_manager=VariableManager(), loader=None)
    # set expected path
    expected_path = "./test/unit/model_data/task_include_task.yml:1"

    result = my_task.get_path()

    assert result == expected_path


# Generated at 2022-06-21 00:18:11.699132
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fb = FieldAttributeBase()
    result = fb.load_data()


# Generated at 2022-06-21 00:18:15.664522
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():

    data = '''
    %YAML 1.1
    ---
    '''

    attr_name = 'attr_name'
    base = FieldAttributeBase(isa='isa', name=attr_name)
    setattr(base, attr_name, data)

    assert base.get_validated_value(attr_name, attr_name, data, None) == data, \
        "FieldAttributeBase.get_validated_value does not produce the expected result"


# Generated at 2022-06-21 00:18:28.810195
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleSequence

    mocked_self = MagicMock()
    mocked_self.to_string = lambda x: x
    mocked_self.to_bool = lambda x: x

    # value is not a string, return it immediately
    assert FieldAttributeBase.preprocess_data(mocked_self, 123) == 123

    # value is a string, not starting with @
    assert FieldAttributeBase.preprocess_data(mocked_self, 'foobar') == 'foobar'

    # value is a string, starting with @
    # and file is not a string or file exists
    mocked_self.templar.is_template.return_value = False
    mocked_self.loader.path_dwim_relative.return_value = 'foobar'

# Generated at 2022-06-21 00:18:36.866899
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    ansible = Ansible()
    module_loader = ModuleLoader()
    playbook_loader = PlaybookLoader(loader=module_loader)
    temp_collection = AnsibleCollection(loader=module_loader, playbooks=playbook_loader)
    ansible._collections = [temp_collection]
    vars_manager = VarsModule()
    # TODO: Add more assertions here.
    assert 1 == 1 # unit test stub

# Generated at 2022-06-21 00:18:43.702143
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    ds = dict(
        backref=None,
        class_type='dict',
        choices='a',
        default='foo',
        isa='bool',
        listof='a',
        name='foo',
        no_log='yes',
        required='yes'
    )

    obj = FieldAttributeBase(**ds)

    for k, v in iteritems(ds):
        assert getattr(obj, k) == v


# Generated at 2022-06-21 00:18:44.504205
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
  pass # TBD


# Generated at 2022-06-21 00:18:48.389873
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    attr = FieldAttributeBase()
    obj = object()
    obj.ds = object()
    attr.field_object = obj
    # Test the non-caching path
    assert attr.get_ds() == obj.ds
    # Test the caching path
    assert attr.get_ds() == obj.ds
    # Test that we can change the ds
    new_ds = object()
    attr.set_ds(new_ds)
    assert attr.get_ds() == new_ds
    assert attr.get_ds() == new_ds


# Generated at 2022-06-21 00:18:53.616810
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    attrs = {'vars': {}}
    task = Task()
    task.from_attrs(attrs)
    # Test that method from_attrs works for class derived from FieldAttributeBase
    # Assures that _squashed and _finalized are on if from_attrs is called
    assert task.finalized
    assert task.squashed


# Generated at 2022-06-21 00:19:33.755010
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    set_runner_iochannels_encoding(force=True)
    attr=FieldAttributeBase(name='asdf', default=None, include=None, exclude=None, include_default=False, exclude_default=False, fail_if_not_set=False, always_post_validate=True, static=False, class_type=None, listof=None, isa=None, required=True)
    assert attr.name == 'asdf', "must be 'asdf'"
    assert attr.default == None, "must be None"
    assert attr.include == None, "must be None"
    assert attr.exclude == None, "must be None"
    assert attr.include_default == False, "must be False"

# Generated at 2022-06-21 00:19:35.317063
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    search_path = base.get_search_path()
    assert search_path is None



# Generated at 2022-06-21 00:19:45.935960
# Unit test for constructor of class Base
def test_Base():
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({
        "playbook.yaml": """
- name: playbook
  hosts: all
""",
    })
    p = Play.load(loader=loader, file_name="playbook.yaml", name="playbook", role_names=[], task_include=dict(role=[""]), variable_manager=None, loader=None)
    t = Task()
    assert t._name == "", "Task name should be empty string"
    assert t._connection == "local", "Task connection should be local"
    assert t._port is None, "Task port should be None"
    assert t._remote_user == "root", "Task remote_user should be root"
    assert t._vars == {}, "Task vars should be {}"

# Generated at 2022-06-21 00:19:51.933586
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    frm = 'ansible.playbook.attribute.FieldAttributeBase'
    attribute = FieldAttributeBase()
    assert isinstance(attribute, FieldAttributeBase)
    loader = attribute.get_loader()
    for name, obj in inspect.getmembers(loader):
        if name == '__init__':
            continue
        assert inspect.isfunction(getattr(loader, name)), \
            'The attribute "%s.%s" is not a function' % (frm, name)


# Generated at 2022-06-21 00:20:03.107918
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    base._parent = Base()
    base._parent._play = Base()
    base._parent._play._ds = Base()
    base._parent._play._ds._data_source = 'test_task'
    base._parent._play._ds._line_number = '10'
    base._parent._play._ds._ds = 'included_from'

    base._parent._play._parent = Base()
    base._parent._play._parent._role = Base()
    base._parent._play._parent._role._role_path = '../test_role/'

    base._parent._play._parent._parent = Base()
    base._parent._play._parent._parent._role = Base()
    base._parent._play._parent._parent._role._role_path = '../test_role/'
    assert base.get

# Generated at 2022-06-21 00:20:05.751567
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # get_search_path is tested in unit tests for Role and TaskInclude
    return


# Generated at 2022-06-21 00:20:08.018293
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    module = FieldAttributeBase()
    assert module.get_variable_manager() == None



# Generated at 2022-06-21 00:20:10.941491
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    test = FieldAttributeBase()
    test.name = 'foo'
    # check copy of FieldAttributeBase
    result = test.copy()
    assert result.name == 'foo'


# Generated at 2022-06-21 00:20:23.271161
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from collections import namedtuple
    from units.compat import unittest

    class Base(object):
        def get_dep_chain(self):
            return self.dep_chain
    VariableManager = namedtuple('VariableManager', ('extra_vars', 'template_vars', 'defaults'))
    class Play(Base):
        def __init__(self, dep_chain=None):
            self.dep_chain = dep_chain
    class Role(Base):
        def __init__(self, dep_chain=None):
            self.dep_chain = dep_chain
    class RoleDependency(object):
        def __init__(self, role):
            self.role = role
    class Task(Base):
        def __init__(self, play=None, role=None):
            if role:
                self

# Generated at 2022-06-21 00:20:24.288563
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    pass

# Generated at 2022-06-21 00:21:29.636376
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Create an instance of FieldAttributeBase for testing
    obj = FieldAttributeBase()

    # Create a dictionary of arguments to pass to object.
    # We need to create a new dictionary because we will modify
    # its contents during testing.
    args = {}

    # Attempt to serialize object
    # Exception is raised during serialization in `def
    # serialize(self, data):` at line number 77
    with pytest.raises(AnsibleAssertionError):
        obj.serialize(**args)
