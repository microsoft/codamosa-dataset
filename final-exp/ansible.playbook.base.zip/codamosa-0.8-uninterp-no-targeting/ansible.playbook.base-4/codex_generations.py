

# Generated at 2022-06-21 00:12:22.950988
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    obj = FieldAttributeBase()
    attrs = {}
    obj.from_attrs(attrs)


# Generated at 2022-06-21 00:12:30.998631
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    tb1 = Base()
    tb2 = Base()
    tb3 = Base()
    tb1.role = Role()
    tb1._parent = tb2
    tb2._parent = tb3
    tb3._parent = None

    assert tb1.get_dep_chain() == None
    assert tb2.get_dep_chain() == [tb1]
    assert tb3.get_dep_chain() == [tb1, tb2]


# Generated at 2022-06-21 00:12:39.304498
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.collections import ImmutableDict
    loader = DataLoader()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '192.168.0.1'
    play_context.connection = 'local'
    play_context.port = 22
    play_context.remote_user = 'admin'
    play_context.become = 1
    play_context

# Generated at 2022-06-21 00:12:40.260638
# Unit test for method get_path of class Base
def test_Base_get_path():
    myBase = Base()
    assert myBase.get_path() == None




# Generated at 2022-06-21 00:12:40.922305
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    pass


# Generated at 2022-06-21 00:12:41.526706
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert False

# Generated at 2022-06-21 00:12:47.834700
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class DummyBase(object):
        def __init__(self, value):
            self.value = value

    test_object = FieldAttributeBase(DummyBase(123))
    assert isinstance(test_object, FieldAttributeBase)
    assert isinstance(test_object.value, DummyBase)


# Generated at 2022-06-21 00:12:52.741859
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():

    class TestFieldAttributeBase(object):
        def __init__(self, some_value):
            self.some_value = some_value
    a = FieldAttributeBase(TestFieldAttributeBase)
    b = TestFieldAttributeBase(some_value = 'foo')
    a.validate(b)
    

# Generated at 2022-06-21 00:12:59.328047
# Unit test for constructor of class Base
def test_Base():
    a = Base()
    assert a is not None

    assert a._name == ''
    assert a._connection == 'smart'
    assert a._remote_user == 'root'
    assert a._port is None
    assert a._vars == {}
    assert a._module_defaults == []
    assert a._environment == []
    assert a._no_log == False
    assert a._run_once == False
    assert a._ignore_errors == False
    assert a._ignore_unreachable == False
    assert a._check_mode == False
    assert a._diff == False
    assert a._any_errors_fatal == False
    # assert a._diff == C.DEFAULT_DIFF



# Generated at 2022-06-21 00:13:00.551871
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass



# Generated at 2022-06-21 00:13:25.578591
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    obj = FieldAttributeBase('key', required=False, default='key_default')
    assert(obj.serialize() == dict(key='key'))


# Generated at 2022-06-21 00:13:26.468973
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    pass


# Generated at 2022-06-21 00:13:37.984277
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secrets
    from ansible.parsing.vault import load_vault_secrets
    from ansible.parsing.vault import update_vault_secrets
    from ansible.parsing.vault import get_vault_password
    from ansible.parsing.vault import get_auto_vault_secret
    vault_secrets = get_file_vault_secret('/root/ansible/test/unit/lib/ansible_test/_data/vault_pass')
    _loader=DummyLoader()

# Generated at 2022-06-21 00:13:40.780307
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    Unit test for method get_dep_chain of class Base
    '''
    item = Base()
    item.get_dep_chain()
    return True

# Generated at 2022-06-21 00:13:42.795495
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    obj = FieldAttributeBase()
    assert isinstance(obj.get_loader(), DataLoader) is True


# Generated at 2022-06-21 00:13:46.731657
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for :class:`ansible.utils.FieldAttributeBase.get_loader`
    '''
    obj = FieldAttributeBase()
    assert not hasattr(obj, '_loader')
    class_name = obj.get_loader()
    assert hasattr(obj, '_loader')
    assert class_name == 'AnsibleLoader'



# Generated at 2022-06-21 00:13:59.399260
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    test_data = dict()
    test_data['_valid_attrs'] = dict()
    test_data['_valid_attrs']['noop_run'] = FieldAttribute(isa='dict', default='noop_run')
    test_data['_valid_attrs']['notify'] = FieldAttribute(isa='list', default='notify')
    test_data['_valid_attrs']['register'] = FieldAttribute(isa='string', default='register')
    test_data['_valid_attrs']['delegate_to'] = FieldAttribute(isa='dict', default='delegate_to')
    test_data['_valid_attrs']['changed_when'] = FieldAttribute(isa='string', default='changed_when')

# Generated at 2022-06-21 00:14:00.504165
# Unit test for constructor of class Base
def test_Base():

    # Base class has no fields by itself, but we at least
    # want to test that it doesn't crash
    base = Base()
    assert base

# Generated at 2022-06-21 00:14:10.780594
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # Test object initialization
    fa = FieldAttribute()
    repr(fa)
    repr(fa())
    repr(fa(isa='int'))
    repr(fa(isa='int', default=42))
    repr(fa(isa='int', default=42, always_post_validate=True))
    repr(fa(isa='class', class_type=Task, default=None))
    repr(fa(isa='class', class_type=Task, default=None, always_post_validate=True))
    repr(fa(isa='list', listof=string_types, default=[], always_post_validate=True))
    repr(fa(isa='list', listof=string_types, default=[], always_post_validate=True, require_in_list=True))

# Generated at 2022-06-21 00:14:12.498853
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    a = FieldAttributeBase()
    assert a.preprocess_data(None, None) is None


# Generated at 2022-06-21 00:14:47.425116
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class parent_class(object):
        test1 = FieldAttribute()
        test2 = FieldAttribute(default=1)
        test3 = FieldAttribute(default=2, alias='alias_3')

    class child_class(parent_class):
        test4 = FieldAttribute()

        def _get_attr_test4(self):
            return 4

    class grandchild_class(child_class):
        test5 = FieldAttribute()

    for test_class in [parent_class, child_class, grandchild_class]:
        result = test_class()
        assert test_class.test1 == property(_generic_g, _generic_s, _generic_d)
        assert test_class.test2 == property(_generic_g, _generic_s, _generic_d)

# Generated at 2022-06-21 00:14:58.604648
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    assert FieldAttributeBase.__doc__ == FieldAttributeBase.__doc__.strip()
    assert 'FieldAttributeBase' in repr(FieldAttributeBase)
    assert FieldAttributeBase.__module__.startswith('ansible.parsing')

    assert isinstance(FieldAttributeBase.__bases__, tuple)  # should be tuple, not list
    assert len(FieldAttributeBase.__bases__) == 0  # should not be keyword argument default

    assert FieldAttributeBase.default is None

    # should not be keyword arguments
    with pytest.raises(TypeError) as excinfo:
        FieldAttributeBase(default=None)
    assert 'got an unexpected keyword argument' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        FieldAttributeBase(default=None, required=True)


# Generated at 2022-06-21 00:15:06.297186
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    class TestFieldAttributeBase(FieldAttributeBase):
        def __init__(self, attrs):
            super(TestFieldAttributeBase, self).__init__(attrs)

        def get_ds(self):
            return None

    task_attrs = dict(name='mytask', action='myaction', args=dict(a=1), uuid='12345678', finalized=True, squashed=True)
    test_obj = TestFieldAttributeBase(task_attrs)
    test_obj.from_attrs(task_attrs)
    assert test_obj.name == 'mytask'
    assert test_obj._uuid == '12345678'
    assert test_obj._finalized is True
    assert test_obj._squashed is True



# Generated at 2022-06-21 00:15:17.107914
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    t = Task()
    t.name = 'test_task'
    t2 = Task()
    t2.name = 'test_task'

    # Test on the 'name' attribute
    if t.name != t2.name:
        pytest.fail("Failed to squash the field attribute 'name'")

    # Test on a new attribute
    t._valid_attrs.update(test_attr=FieldAttribute(isa='string'))
    t.test_attr = 'test1'
    t2.test_attr = 'test2'
    t2.squash(t)

    if t.test_attr != t2.test_attr:
        pytest.fail("Failed to squash the field attribute 'test_attr'")

# Generated at 2022-06-21 00:15:21.855635
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # test with FieldAttributeBase('name')
    attr = FieldAttributeBase('name')
    # check the returned value is of expected type
    assert (isinstance(attr.get_validated_value("name", attr, value=1, templar=Templar(loader=DictDataLoader())), str))

# Generated at 2022-06-21 00:15:23.209649
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    b = Base()
    assert_equal(b.get_dep_chain(), None)


# Generated at 2022-06-21 00:15:32.812014
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Note: This will test the correct preprocessing logic, but it won't test if a given data
    # structure is valid or not as this is not the goal of the test.
    attr_base = FieldAttributeBase()

    # test the old behavior (used within Ansible core)
    attr_base.preprocess_data(Mapping, 'localhost', {'localhost': {'var': 'val'}})
    attr_base.preprocess_data(Mapping, 'localhost', {'other': {'var': 'val'}})

    # test the new behavior (used within collections)
    attr_base.preprocess_data(Mapping, 'localhost', {'localhost': {'var': 'val'}}, allow_unmatched_keys=True)

# Generated at 2022-06-21 00:15:44.986847
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    task1 = Base()
    task2 = Base()
    task3 = Base()
    task4 = Base()
    task5 = Base()
    task6 = Base()
    task7 = Base()
    task8 = Base()
    task9 = Base()
    # task1 does not have a search path
    task1._ds = DsFake()
    task1._ds._data_source = '/tmp/test/roles/role1/tasks/main.yml'
    task1._ds._line_number = 1
    # task2 does not have a search path
    task2._ds = DsFake()
    task2._ds._data_source = '/tmp/test/roles/role1/tasks/main.yml'
    task2._ds._line_number = 2
    # task3 has a search path

# Generated at 2022-06-21 00:15:46.002697
# Unit test for method get_path of class Base
def test_Base_get_path():
    # TODO
    pass

# Generated at 2022-06-21 00:15:50.297453
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    base = FieldAttributeBase()
    assert base.required is True
    assert base.static is False

    base = FieldAttributeBase(True, False)
    assert base.required is True
    assert base.static is False

    base = FieldAttributeBase(False, True)
    assert base.required is False
    assert base.static is True

    base = FieldAttributeBase(False, False)
    assert base.required is False
    assert base.static is False



# Generated at 2022-06-21 00:16:25.275304
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    from ansible.parsing.vault import VaultLib
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    # test with vault_password_files
    inventory = Inventory('hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory, vault_password_files=['passwordFile'])
    test = FieldAttributeBase(vault_password_files=['passwordFile'])

    result = test.get_variable_manager(variable_manager)
    assert result == variable_manager

    # test with vault_password
    inventory = Inventory('hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    test = FieldAttributeBase(vault_password='vault_password')

    result = test.get_variable_manager(variable_manager)
    vault_password_

# Generated at 2022-06-21 00:16:34.373519
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    a = FieldAttributeBase()
    test_obj = MagicMock()
    test_obj.post_validate = MagicMock()
    a.class_type = test_obj
    a.isa = 'class'
    attr_name = 'test_attr_name'
    attr_value = 'test_attr_value'
    templar = MagicMock()
    a.post_validate(attr_name, attr_value, templar)
    test_obj.post_validate.assert_called_once_with(templar=templar)


# Generated at 2022-06-21 00:16:37.983241
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    field_attribute_base = FieldAttributeBase(loader=None)
    assert field_attribute_base.get_loader() is None

# Generated at 2022-06-21 00:16:39.404214
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    me = FieldAttributeBase()
    me._valid_attrs = {'vars': {}}
    assert me.dump_attrs() == {}

# Generated at 2022-06-21 00:16:39.909275
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
  pass

# Generated at 2022-06-21 00:16:43.089987
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Test the squash method of FieldAttributeBase
    # Assert that the given value is the same as the value produced by the function
    assert FieldAttributeBase.squash('something') == 'something'


# Generated at 2022-06-21 00:16:54.726451
# Unit test for method serialize of class FieldAttributeBase

# Generated at 2022-06-21 00:17:02.423998
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # initialize args
    argument_spec = {"arg_0": "foo",
                     "arg_1": "bar",
                     }
    fields = {"arg_0": "foo",
              "arg_1": "bar",
              }

    # initialize fixture
    fixture_obj = copy.deepcopy(FieldAttributeBase())
    fixture = FieldAttributeBase()

    # initialize test object
    obj = FieldAttributeBase()

    # test squash without args
    fixture = fixture.squash(argument_spec=None, fields=None)
    result = obj.squash(argument_spec=None, fields=None)
    assert fixture == result

    # test squash with args
    fixture = fixture.squash(argument_spec=argument_spec, fields=fields)
    result = obj.squash(argument_spec=argument_spec, fields=fields)


# Generated at 2022-06-21 00:17:03.518429
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    assert True is True

# Generated at 2022-06-21 00:17:16.048222
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # create object
    obj = FieldAttributeBase()

    # object should be of type FieldAttributeBase
    assert type(obj) is FieldAttributeBase
    # object should have attributes:
    #     _valid_attrs
    #     _final_attrs
    #     _priority

    # check if _valid_attrs is empty
    assert obj._valid_attrs == {}
    # check if _final_attrs is empty
    assert obj._final_attrs == {}
    # check if _priority is None
    assert obj._priority is None
    # check if get_validated_value works as expected
    assert obj.get_validated_value(
        "test",
        None,
        "testvalue",
        None
    ) == "testvalue"


# Generated at 2022-06-21 00:17:45.854053
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = {
        'from_deserialize': 'from_deserialize',
        '_uuid': 'test_uuid',
        '_finalized': True,
        '_squashed': False,
    }
    test_object = FieldAttributeBase()
    setattr(test_object, 'from_deserialize', 'from_deserialize')
    setattr(test_object, 'from_init', 'from_init')
    setattr(test_object, '_loaded_from', '_loaded_from')
    setattr(test_object, '_loader', '_loader')
    setattr(test_object, '_variable_manager', '_variable_manager')
    setattr(test_object, '_validated', '_validated')

# Generated at 2022-06-21 00:17:55.434353
# Unit test for constructor of class Base
def test_Base():
    '''
    >>> task = Base()
    >>> task._name
    ''
    >>> task._vars
    {}
    >>> task._module_defaults
    []
    >>> task._any_errors_fatal
    False
    >>> task._no_log
    False
    >>> task._run_once
    False
    >>> task._environment
    []
    >>> task._check_mode
    False
    >>> task._connection
    'smart'
    >>> task._become
    False
    >>> task._become_user
    'root'
    >>> task._become_method
    'sudo'
    '''



# Generated at 2022-06-21 00:17:58.548494
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_obj = FieldAttributeBase()
    print('FieldAttributeBase=%s' % test_obj)
    assert test_obj is not None


# Generated at 2022-06-21 00:18:07.850827
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class MyClass(FieldAttributeBase):
        _valid_attrs = dict(
            attr = FieldAttribute(isa='boolean', default=False),
            vars = FieldAttribute(isa='dict', default=dict()),
        )

        def _load_attr(self, ds):
            return ds

        def _load_vars(self, ds):
            return ds

    x = MyClass()
    x.load_data(dict(attr=True, vars=dict(foo='bar')))
    assert x.attr is True
    assert x.vars == dict(foo='bar')

# Generated at 2022-06-21 00:18:15.469955
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    base = FieldAttributeBase()

    data = AnsibleMapping()
    data.yaml_set_start_mark(None, 0, 0)
    data.yaml_add_end_mark(None, 0, 0)

    data['foo'] = 42
    data['bar'] = 'asdf'
    data['baz'] = AnsibleSequence()
    data['baz'].yaml_set_start_mark(None, 0, 0)
    data['baz'].yaml

# Generated at 2022-06-21 00:18:16.273759
# Unit test for constructor of class Base
def test_Base():
    obj = Base()
    return (obj.__class__)


# Generated at 2022-06-21 00:18:20.649808
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    '''
    Unit test for method: FieldAttributeBase.dump_me
    '''
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base.dump_me() == 'unknown'

# Generated at 2022-06-21 00:18:22.412607
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    assert True == True

# Generated at 2022-06-21 00:18:32.136543
# Unit test for constructor of class Base
def test_Base():
    b1 = Base()
    assert b1.name == ""
    assert b1.connection == context.CLIARGS['connection']
    assert b1.port is None
    assert b1.remote_user == context.CLIARGS['remote_user']
    assert b1.vars == {}
    assert b1.module_defaults == []
    assert b1.environment == []
    assert b1.no_log == False
    assert b1.run_once == False
    assert b1.ignore_errors == False
    assert b1.ignore_unreachable == False
    assert b1.check_mode == context.CLIARGS['check']
    assert b1.diff == context.CLIARGS['diff']
    assert b1.any_errors_fatal == C.ANY_ERRORS_FATAL


# Generated at 2022-06-21 00:18:44.951921
# Unit test for method get_path of class Base
def test_Base_get_path():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    '''return the absolute path of the playbook object and its line number'''
    loader = DataLoader()
    initial_data = dict(
        connection='smart',
        remote_user='root',
        become=False,
        become_method=None,
        become_user=None,
        become_exe=None,
        become_flags=None,
        check=False,
        diff=False,
    )
    context.CLIARGS = AttributeDict(**initial_data)
    playbook_path = os.path.abspath('./playbook.yml')
    ds = DataParser().parse_from_file(playbook_path)
    connection = 'ssh'
    result = Base

# Generated at 2022-06-21 00:20:40.943748
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # create a dummy dict
    dct = dict()

    # create some additional class attribute
    dct['_attributes'] = {}
    dct['_attr_defaults'] = {}
    dct['_valid_attrs'] = {}
    dct['_alias_attrs'] = {}

    BaseMeta.__new__(BaseMeta, "test", (object,), dct)
    # test right attributes have been created in dct
    assert "__dict__" in dct
    assert len(dct['__dict__']) == 0
    assert "_attributes" in dct
    assert dct['_attributes'] == {}
    assert "_attr_defaults" in dct
    assert dct['_attr_defaults'] == {}
    assert "_valid_attrs" in dct

# Generated at 2022-06-21 00:20:46.754575
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    test_data = {
        'required': False,
        'isa': 'str',
        'default': None,
        'static': True,
    }

    attr = FieldAttribute(**test_data)
    assert attr.required == test_data['required']
    assert attr.isa == test_data['isa']
    assert attr.default == test_data['default']
    assert attr.static == test_data['static']

    attr_str = attr.dump_me()
    assert len(attr_str) == sum([len(v) for v in test_data.values()])


# Generated at 2022-06-21 00:20:51.576432
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    obj = Task()
    t = Templar(loader=None, variables={})

    obj.post_validate(templar=t)


# Generated at 2022-06-21 00:20:53.075305
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    yield _FieldAttributeBase_get_ds_1



# Generated at 2022-06-21 00:20:58.084199
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    f = FieldAttributeBase("foo", choices=['bar', 'baz'])
    assert f.validate("bar") is True, "bad result from FieldAttributeBase.validate(bar)"
    assert f.validate("foo") is False, "bad result from FieldAttributeBase.validate(foo)"

# Generated at 2022-06-21 00:21:08.249882
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.plugins.loader import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    import json
    import os

    class A(Base, object):
        _test = FieldAttribute(isa='dict', default=dict())
    assert A._test._get_default() == dict()
    assert A._test._default == dict()
    aa = A(module_loader=module_loader)
    assert aa._attributes == {'_test': Sentinel}
    assert aa._attr_defaults == {'_test': dict()}
    assert aa._valid_attrs == {'_test': A._test}
    assert aa

# Generated at 2022-06-21 00:21:09.744153
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass


# Generated at 2022-06-21 00:21:21.713559
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field1 = FieldAttributeBase(isa='string', required=True, priority=0)
    assert field1.validate("example") == "example"
    field2 = FieldAttributeBase(isa='list', required=True, priority=0)
    assert field2.validate("example") == ["example"]
    field3 = FieldAttributeBase(isa='list', required=True, priority=0, listof='string')
    assert field3.validate("example") == ["example"]
    field4 = FieldAttributeBase(isa='list', required=True, priority=0, listof='string')
    assert field4.validate(None) == []
    field5 = FieldAttributeBase(isa='list', required=True, priority=0, listof='string', default=[])
    assert field5.validate(None) == []
    field6 = Field

# Generated at 2022-06-21 00:21:31.139935
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    dict_attr = dict(class_type='TestClass')
    field_attribute_base = FieldAttributeBase('name', 'list', False, False, False, False, False, None, 'TestClass')
    assert field_attribute_base.copy() == field_attribute_base
    field_attribute_base = FieldAttributeBase('name', 'list', True, False, False, False, False, None, 'TestClass')
    assert field_attribute_base.copy() == field_attribute_base
    field_attribute_base = FieldAttributeBase('name', 'list', True, True, False, False, False, None, 'TestClass')
    assert field_attribute_base.copy() == field_attribute_base
    field_attribute_base = FieldAttributeBase('name', 'list', True, True, True, True, False, None, 'TestClass')
   