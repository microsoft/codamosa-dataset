

# Generated at 2022-06-21 00:12:34.531479
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    from ansible.playbook.base import FieldAttributeBase
    from ansible.playbook.attribute import FieldAttribute

    obj = FieldAttributeBase()
    ds = obj.get_ds()
    assert ds is None

    obj = FieldAttributeBase(ds=object())
    ds = obj.get_ds()
    assert ds is not None

    # FieldAttributeBase() inherits from FieldAttribute() which
    # resets the value of 'ds' to the default in __init__()
    obj = FieldAttributeBase(ds=object())
    assert ds == obj.ds


# Generated at 2022-06-21 00:12:41.917962
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class BaseA(metaclass=BaseMeta):
        def get_foo(self):
            return "foobar"
        foo = FieldAttribute(isa='str', parent_attribute=False)
        bar = FieldAttribute(isa='str', parent_attribute=False)
    class BaseB(BaseA):
        _bar = FieldAttribute(isa='str', parent_attribute=False)
    class BaseC(BaseB):
        def get_bar(self):
            return "foobar"
        def get_fiz(self):
            return "foobar"
        fiz = FieldAttribute(isa='str', parent_attribute=False)
    class BaseD(BaseB, BaseC):
        pass
    assert BaseB._valid_attrs["foo"].parent_attribute
    assert BaseB._valid_attrs["_bar"].parent_attribute

# Generated at 2022-06-21 00:12:54.745854
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    import pytest
    from ansiblelint import Runner
    from ansiblelint.rules import RulesCollection
    from ansiblelint.rules.TaskHasNameRule import TaskHasNameRule

    field_attribute_base_any = FieldAttributeBase()
    field_attribute_base_any.name = 'name'
    assert field_attribute_base_any.copy()

    content = '''
    - hosts: localhost
      tasks:
        - name: test
          ping:
          when: true
          action: ping
    '''

    runner = Runner(RulesCollection(), {}, [], [], [])
    runner.run_playbooks(playbooks=[content])
    results = runner.get_results()
    assert results

    assert results[0].rule == 'TASK_HAS_NAME'
    assert results[0].filename

# Generated at 2022-06-21 00:12:58.802634
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    x = FieldAttributeBase()
    y = FieldAttributeBase()
    assert x != y
    assert x == x
    assert isinstance(x, FieldAttributeBase)
    assert isinstance(x.get_validated_value(1,2,3,4), object)

if __name__ == "__main__":
    pytest.main()

# Generated at 2022-06-21 00:13:11.463381
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    o = FieldAttributeBase()
    assert o.get_validated_value("string", FieldAttribute("string"), "1234", "templar") == "1234"
    assert o.get_validated_value("int", FieldAttribute("int"), "1234", "templar") == 1234
    assert o.get_validated_value("float", FieldAttribute("float"), "1234", "templar") == 1234
    assert o.get_validated_value("percent", FieldAttribute("percent"), "1234", "templar") == 1234
    assert o.get_validated_value("percent", FieldAttribute("percent"), "1234%", "templar") == 1234
    assert o.get_validated_value("list", FieldAttribute("list"), "1234", "templar") == ["1234"]


# Generated at 2022-06-21 00:13:14.295701
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    # array of return values
    rv = []
    # isa
    isa = None

    # todo: fill this in
    assert False

# Generated at 2022-06-21 00:13:17.444935
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Test get_ds method of FieldAttributeBase
    '''

    my_obj = FieldAttributeBase()
    assert my_obj.get_ds() == None, "Testcase is broken"



# Generated at 2022-06-21 00:13:18.080620
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
  obj = BaseMeta()
  assert isinstance(obj, BaseMeta)



# Generated at 2022-06-21 00:13:27.238523
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Provided the arg 'name' does not exist in the obj
    # we should return the default value
    with pytest.raises(TypeError):
        obj = BaseObject()
        obj.squash()
    # If the argument is not a dict it should raise an
    # error
    with pytest.raises(TypeError):
        obj = BaseObject()
        obj.squash(name=23)
    # If the argument does not contain the required field
    # we should return the default value
    with pytest.raises(TypeError):
        obj = BaseObject()
        obj.squash(name={'key1': 'val1'})
    # args is a list, we should return the first value
    obj = BaseObject()
    obj.squash(name={'args': ['arg1', 'arg2']})
   

# Generated at 2022-06-21 00:13:29.026095
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    test_obj = FieldAttributeBase()
    assert test_obj.preprocess_data(None) is None


# Generated at 2022-06-21 00:14:11.408729
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    test = FieldAttributeBase()


# Generated at 2022-06-21 00:14:15.209310
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_obj = FieldAttributeBase()
    try:
        my_obj.post_validate(templar=None)
    except (AnsibleParserError, TypeError, ValueError) as e:
        pass
    else:
        raise AssertionError("Expected (AnsibleParserError, TypeError, ValueError), got None")


# Generated at 2022-06-21 00:14:28.191490
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    args = dict(
        name='name',
        required=True,
        serialize_when_none=True,
        always_post_validate=True,
        load_from='name',
        default='default',
    )

    a = FieldAttributeBase(**args)

    b = dict(name='foo')
    a.deserialize(b)
    assert a.name == 'foo'
    assert a.required == True
    assert a.serialize_when_none == True
    assert a.always_post_validate == True
    assert a.load_from == 'name'
    assert a.default == 'default'
    c = dict(value='bar')
    a.deserialize(c)
    assert a.name == 'name'
    assert a.required == True
    assert a.serialize_

# Generated at 2022-06-21 00:14:37.518081
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from ansible.module_utils.six import string_types

    # Test setting static and static_inherited
    static = False
    static_inherited = False
    test_obj = FieldAttributeBase(static=static, static_inherited=static_inherited)
    assert test_obj.static == static
    assert test_obj.static_inherited == static_inherited
    
    # Test that load_data raises an error when data is not string_types
    test_data = 2
    with pytest.raises(AnsibleAssertionError) as exc:
        test_obj.load_data(test_data)
    assert exc.value.message == 'data (2) should be a string but is a %s' % type(test_data)


# Generated at 2022-06-21 00:14:39.652455
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    pass

# Generated at 2022-06-21 00:14:42.764553
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    raise SkipTest

    # Additional test for method get_ds of class FieldAttributeBase


# Generated at 2022-06-21 00:14:47.536170
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    my_obj = FieldAttributeBase()
    my_attrs = dict()
    my_obj.from_attrs(attrs=my_attrs, loader=None, variable_manager=None, all_vars=dict())


# Generated at 2022-06-21 00:14:58.689766
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    _loader = DictDataLoader({
        "dev": {
            "hosts": ["some"]
        },
        "all": {
            "hosts": [{
                "name": "some",
                "foo": "bar"
            }]
        },
        "ungrouped": {
            "hosts": ["some", "other"]
        }
    })

    attribute = FieldAttribute(isa='dict')
    attribute.load_data('/home/dag/global_thing', _loader)
    assert attribute.value == {}

    attribute = FieldAttribute(isa='hosts')
    attribute.load_data('/home/dag/global_thing', _loader)
    assert attribute.value == []

    attribute = FieldAttribute(isa='hosts')

# Generated at 2022-06-21 00:15:06.742215
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    a = FieldAttributeBase(description='Description',
                           always_post_validate=True,
                           required=True,
                           default=True,
                           always_run=True,
                           aliases=[1, 2],
                           yaml_name=5,
                           data_type='Data Type',
                           init_type=[1, 2],
                           choices=[1, 2],
                           see_also=[1, 2],
                           listof='List Of',
                           class_type='Class Type',
                           isa='Is A',
                           ignore_errors=True,
                           required_if='Required If')

    assert a.description == 'Description'
    assert a.always_post_validate is True
    assert a.required is True
    assert a.default is True
    assert a.always_

# Generated at 2022-06-21 00:15:12.500407
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # serialize(self)
    # serialize the object derived from the base object into
    # a dictionary of values. This only serializes the field
    # attributes for the object, so this may need to be overridden
    # for any classes which wish to add additional items not stored
    # as field attributes.
    pass


# Generated at 2022-06-21 00:15:47.007748
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Analysis(with_metaclass(BaseMeta, object)):
        """
        This class defines a base set of variables which are used to
        define arguments or parameters to the module.  These generally
        are not used by the module itself and are used to create the
        valid arguments to the module.

        Example:
        >>> attributes = Analysis()._valid_attrs
        >>> attributes['foo'].default
        None
        """

        foo = FieldAttribute(isa='str')

        def _get_attr_foo(self):
            pass
    assert 'foo' in Analysis().__dict__


# Generated at 2022-06-21 00:15:57.166184
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    from ansible.template import Templar
    
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    
    loader = DataLoader()
    templar = Templar(loader=loader)
    context._init_global_context(loader=loader)
    

# Generated at 2022-06-21 00:16:02.471554
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    test_base = Base()
    test_base._parent = '_parent'
    assert test_base.get_dep_chain() == '_parent'
    test_base._parent = None
    assert test_base.get_dep_chain() == None


# Generated at 2022-06-21 00:16:06.279207
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    field_attribute_base = FieldAttributeBase()

# Generated at 2022-06-21 00:16:07.647662
# Unit test for method get_path of class Base
def test_Base_get_path():
    obj = Base()
    assert obj.get_path() == ""

# Generated at 2022-06-21 00:16:10.679943
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    test_obj = FieldAttributeBase()
    assert not test_obj.deserialize(dict(a=1))
# #############################################################################
# ############# Implementation of class FieldAttribute #########################
# #############################################################################


# Generated at 2022-06-21 00:16:12.211692
# Unit test for method get_path of class Base
def test_Base_get_path():
    base = Base()
    assert base.get_path() == ''

# Generated at 2022-06-21 00:16:24.625197
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    import copy

    test_data = {"attr2": "attr2value", "attr1": "attr1value", "attr3": "attr3value"}

    # test without 'default'

    f1 = FieldAttributeBase()
    f1.deserialize(copy.copy(test_data))

    assert f1.attr1 == "attr1value"
    assert f1.attr2 == "attr2value"
    assert f1.attr3 == "attr3value"

    # test with 'default':

    f2 = FieldAttributeBase()
    f2.deserialize(copy.copy(test_data))

    assert f2.attr1 == "attr1value"
    assert f2.attr2 == "attr2value"
    assert f2.attr3 == "attr3value"

    # test with 'default' by type:

# Generated at 2022-06-21 00:16:36.214308
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    """
    The method is used to set the value of the field attribute
    to the specified value. The value to be set is expected to be of the same
    type as the attribute.
    """

    # no parameter calling squash method
    with pytest.raises(AnsibleAssertionError) as excinfo:
        with set_context(DATA_CTX):
            test_attributes=dict(var1="1")
            _attribute_base._squash(test_attributes)
    assert excinfo.match(r'required keyword argument \
        .* is missing')

    # passing valid value
    with set_context(DATA_CTX):
        test_attributes=dict(var1="1")
        _attribute_base._squash(test_attributes, value="2")
        assert test_attributes["var1"]

# Generated at 2022-06-21 00:16:43.648358
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    fa = FieldAttributeBase()

    # tests for invalid value types
    for kwargs in [
        {'class_type': None, 'isa': 'class'},
    ]:
        with pytest.raises(AnsibleAssertionError) as exc:
            FieldAttributeBase(**kwargs)

        assert to_text(exc.value) == 'conditional type must be class type if isa is class.'

    # tests for invalid values of isa
    for kwargs in [
        {'class_type': None, 'isa': 'foo'},
        {'class_type': None, 'isa': None},
    ]:
        with pytest.raises(AnsibleAssertionError) as exc:
            FieldAttributeBase(**kwargs)


# Generated at 2022-06-21 00:17:15.107093
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    args = dict(
        attribute=FieldAttribute(),
        hostvars=Mock(return_value={}),
        taskvars={},
        variables={},
        omit={},
        fail_on_undefined=False,
        templar=dict(
            available_variables={}
        )
    )

    with pytest.raises(AnsibleAssertionError):
        # can't call directly
        FieldAttributeBase.preprocess_data(args)

    field = Mock()
    FieldAttributeBase.preprocess_data(field, args) == field.preprocess_data.return_value
    field.preprocess_data.assert_called_once_with(args)


# Generated at 2022-06-21 00:17:23.763954
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class MyClass(with_metaclass(BaseMeta, object)):
        _is_debug = True
        _host_regex = FieldAttribute(isa='string')
        _host_list = FieldAttribute(isa='list')
        _host_list_regex = FieldAttribute(isa='string')
        _host_exclude_list = FieldAttribute(isa='list')
        _host_exclude_list_regex = FieldAttribute(isa='string')

        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name', 'none')

    # Instantiate the class
    obj = MyClass(name='test')

    # Use attributes
    obj._host_regex = 'test'
    assert isinstance(obj._host_regex, string_types)
    assert obj._host

# Generated at 2022-06-21 00:17:35.853480
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():

    h = Host('test_host')
    t = Task()
    t.name = 'test_task'

    t._attributes['name'] = 'test'
    t._attributes['hosts'] = ['test_host']
    t._attributes['roles'] = ['test_role']

    t.post_validate()
    t.finalize()

    assert t._squashed is False
    t.squash()
    assert t._squashed is True

    assert h._squashed is False
    h.squash()
    assert h._squashed is True

    # make sure the UUID is not squashed
    assert hasattr(t, '_uuid')
    assert hasattr(h, '_uuid')


# Generated at 2022-06-21 00:17:45.685646
# Unit test for method get_path of class Base

# Generated at 2022-06-21 00:17:51.574589
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    host = get_host_list(get_test_file('test_play.yml'))[0]
    host.vars = {'test_var': 'foo'}
    host.deserialize(dict(vars=dict(bar='baz')))
    assert host.vars == {'test_var': 'foo', 'bar': 'baz'}



# Generated at 2022-06-21 00:17:54.513265
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    field_attr = FieldAttributeBase()
    with pytest.raises(AssertionError):
        field_attr.get_variable_manager()


# Generated at 2022-06-21 00:18:06.556331
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import ansible.plugins.loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import get_unique_id
    from ansible.utils.vars import isidentifier
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.attribute import FieldAttribute
    import ansible.module_utils.parsing.convert_bool
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleAssertionError

# Generated at 2022-06-21 00:18:12.071838
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    fixture = FieldAttributeBase(
        name='name',
        private=True,
        default=None,
        choices=[],
        aliases=[],
        inherit=False,
        priority=128,
        static=True,
        required=False,
        always_post_validate=False,
        listof=None,
        class_type=None,
        isa=None,
        is_bool=False,
        is_list=False
    )

    # Minimal test with a given parameter returning a boolean value
    assert fixture.deserialize([]) is False




# Generated at 2022-06-21 00:18:12.965400
# Unit test for method get_path of class Base
def test_Base_get_path():
    assert False


# Generated at 2022-06-21 00:18:20.473579
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # TODO: Test case for FieldAttributeBase.get_ds

    # FIXME: Test runner is currently unable to run test method
    # test_FieldAttributeBase_get_ds, but it can run the test
    # case method test_FieldAttributeBase.
    #
    # As of this writing a test case method cannot be added
    # to class FieldAttributeBase. It is not clear at this
    # time why this is. The following is just a placeholder
    # for the above mentioned test case method.
    assert True



# Generated at 2022-06-21 00:18:47.783336
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    # Add your test values here

# Generated at 2022-06-21 00:18:51.967836
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # FAB is an abstract class, we can't directly test it,
    # but we can test its subclasses
    fab = FieldAttributeBase()
    # FAB is an abstract class and so should not be able to be instantiated
    assert fab is None


# Generated at 2022-06-21 00:18:58.541207
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    valid_attrs = dict()
    _valid_attrs = dict()
    attrs = dict()
    boolean = None
    _loader = None
    _variable_manager = None
    _block = None
    play = None
    _uuid = None
    _validated = None
    _deprecated_action = None
    _delegate_to = None
    _loop = None
    runner_warnings = None
    _deprecations = None
    _deprecation_errors = None
    _local_action = None
    _connection_warnings = None
    _no_log = None
    LineNumber = None
    FileLineNumber = None
    block = None
    _finalized = None
    _squashed = None



# Generated at 2022-06-21 00:19:00.092012
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    #repr = obj.dump_me()
    assert False

# Generated at 2022-06-21 00:19:02.450873
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    with pytest.raises(NotImplementedError) as excinfo:
        FieldAttributeBase()

# Generated at 2022-06-21 00:19:06.338026
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    f1 = FieldAttributeBase()
    a = f1.dump_attrs()
    assert a is not None, 'Unexpected non None value'
    assert a == {}, 'Unexpected value for a: {0}'.format(a)

# Generated at 2022-06-21 00:19:10.238630
# Unit test for method get_path of class Base
def test_Base_get_path():
    #source_path = __file__.split('.')[0]
    #task = Task.load(dict(action=dict(module='ping', args=dict())), variable_manager=VariableManager(), loader=DictDataLoader())
    #assert source_path == task.get_path(), 'Task source path is incorrect.'
    pass



# Generated at 2022-06-21 00:19:13.091358
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    (ok, before, after) = compare_yaml_files('ansible/utils/field_attribute.py')
    assert ok, before + after



# Generated at 2022-06-21 00:19:21.778010
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    dict_copy = dict.copy
    dict_getitem = dict.__getitem__
    dict_setitem = dict.__setitem__
    dict_delitem = dict.__delitem__
    dict_hasattr = dict.__contains__
    dict_setdefault = dict.setdefault
    attr_dict = dict()
    f = field_attribute()
    attr_dict['_valid_attrs'] = attr_dict
    attr_dict['_attr_defaults'] = attr_dict
    attr_dict['_attributes'] = attr_dict
    attr_dict['_alias_attrs'] = attr_dict
    attr_dict['foo'] = f
    attr_dict['_get_attr_foo'] = f

    # run method

# Generated at 2022-06-21 00:19:26.494414
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class TestClass(Base):
        my_attribute = FieldAttribute(isa='str', defaults='this is a string')

    test_obj = TestClass()
    assert(test_obj._valid_attrs['my_attribute'].isa == 'str')
    assert(test_obj._valid_attrs['my_attribute'].default == 'this is a string')
    assert(test_obj._valid_attrs['my_attribute'].attribute_class == FieldAttribute)
    assert(isinstance(test_obj._valid_attrs['my_attribute'], FieldAttribute))


# Generated at 2022-06-21 00:20:04.438993
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    obj = FieldAttributeBase(None, None)
    with pytest.raises(NotImplementedError) as excinfo:
        obj.from_attrs(None)
    assert 'from_attrs is not implemented for FieldAttributeBase' == str(excinfo.value)

# Generated at 2022-06-21 00:20:09.564566
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    myobj = FieldAttributeBase()
    myclass = 'myclass'
    myparams = {'myparam': 'myvalue'}
    myobj._dump_me(myclass, myparams)
    assert myobj._dump_me_params == (myclass, myparams)


# Generated at 2022-06-21 00:20:20.006015
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import wrap_var
    # Case 1: object is not a list
    data = '''
    ---
    test: hello
    '''
    obj = AnsibleLoader(data).get_single_data()
    assert obj.squash() == obj
    # Case 2: object is a list
    data = '''
    ---
    - test: hello
    '''
    objs = AnsibleLoader(data).get_single_data()
    assert len(objs) == 1
    assert objs.squash() == objs[0]
    # Case 3: object is a list of complex objects

# Generated at 2022-06-21 00:20:31.226127
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    _loader = DictDataLoader({
        u'file1.yml': """
first_thing: 1
second_thing: 2
third_thing:
    - 1
    - 2
    - 3
""",
    })
    _loader.set_basedir(u'file1.yml')
    _variable_manager = VariableManager()
    obj = FieldAttributeBase()
    obj._loader = _loader
    obj._variable_manager = _variable_manager
    ds = u'file1.yml'
    result = obj.load_data(ds)
    assert result == {u'first_thing': 1, u'second_thing': 2, u'third_thing': [1, 2, 3]}



# Generated at 2022-06-21 00:20:37.956373
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    ds = dict(
        name='this is a test',
        quux='this is another test',
    )

    obj = FieldAttributeBase(
        'name',
        {},
        {},
        None,
        True,
        )

    obj.load_data(ds)
    assert(obj.name == 'this is a test')
    assert(obj.quux == '__ansible_undefined__')



# Generated at 2022-06-21 00:20:44.552221
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Put up a stub to intercept calls to super()
    parent_mock = mock.MagicMock()

    # Set up test object in a known configuration
    test_object = FieldAttributeBase(parent=parent_mock)
    test_object._ds = [1, 2]

    # Call method under test
    result = test_object.get_ds()

    # Ensure that the call to super() happened as expected
    parent_mock.assert_not_called()

    # Verify expected result
    assert result == [1, 2]


# Generated at 2022-06-21 00:20:55.749310
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.runner.return_data import ReturnData
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

# Generated at 2022-06-21 00:20:59.823167
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test for when name is ``vars``, attribute is ``g``, value is `None` and templar is ``j``
    # TODO: implement your test here
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-21 00:21:02.604426
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    attribute = FieldAttributeBase()
    with pytest.raises(NotImplementedError, match="squash not implemented"):
        assert attribute.squash() == Sentinel



# Generated at 2022-06-21 00:21:06.324755
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():

    # Testing with proper input    
    Base._play = ""
    Base._parent = ""
    assert Base.get_dep_chain() == None

    Base._parent = ""
    Base._play = "test"
    assert Base.get_dep_chain() == "test"

    Base._parent = "test"
    Base._play = "test1"
    Base._parent._play = "test2"
    assert Base.get_dep_chain() == "test2"
