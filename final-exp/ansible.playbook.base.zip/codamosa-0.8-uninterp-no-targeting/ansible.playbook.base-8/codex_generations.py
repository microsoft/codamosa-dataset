

# Generated at 2022-06-21 00:12:34.735388
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base.get_path() == ''
    assert base.get_dep_chain() is None
    assert base.get_search_path() == []


# Generated at 2022-06-21 00:12:36.401573
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    o = FieldAttributeBase()
    o.post_validate('templar')



# Generated at 2022-06-21 00:12:39.291452
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    path_stack = []
    path = os.path.abspath(os.path.dirname(__file__))
    if path not in path_stack:
        path_stack.append(path)
    assert path_stack == Base.get_search_path()


# Generated at 2022-06-21 00:12:52.229167
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # This is a stub implementation of load_data, just to show the API
    # and the return value
    #
    # The actual implementation should not use "self", but rather be a
    # true function, as shown in _load_vars
    def _load_vars(self, attr, ds):
        '''
        Vars in a play can be specified either as a dictionary directly, or
        as a list of dictionaries. If the later, this method will turn the
        list into a single dictionary.
        '''

        def _validate_variable_keys(ds):
            for key in ds:
                if not isidentifier(key):
                    raise TypeError("'%s' is not a valid variable name" % key)


# Generated at 2022-06-21 00:13:00.505493
# Unit test for constructor of class Base
def test_Base():
    host_vars = load_vars_from_dir(path_dwim("one/vars"))
    host_vars.update({"var_two": "host var two", "var_one": "host var one"})
    all_vars = combine_vars(host_vars)
    templar = Templar(loader=DictDataLoader({}), variables=all_vars)
    base = Base()
    base.post_validate(templar)
    assert base.vars is not None
    assert base.name == ''
    assert base.check_mode == context.CLIARGS['check']
    assert base.diff == context.CLIARGS['diff']
    assert base.debugger is None
    assert base.port is None
    assert base.remote_user == context.CLIAR

# Generated at 2022-06-21 00:13:13.072481
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult

    b = Base()
    b._parent = Play()
    dep_chain = [TaskResult(),TaskResult()]
    b._parent._dep_chain = dep_chain
    dep_chain[0]._role_path = '/tmp/role1'
    dep_chain[1]._role_path = '/tmp/role2'
    b._ds = object()
    b._ds._data_source = '/tmp/playbook'
    b._ds._line_number = 1
    assert(b.get_search_path() == ['/tmp/role2', '/tmp/role1', '/tmp/playbook'])

    del b._parent._dep_chain

# Generated at 2022-06-21 00:13:23.430538
# Unit test for method get_path of class Base
def test_Base_get_path():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_pathsep_unix
    from units.mock.path import mock_unfrackpath_pathsep_win
    from units.mock.path import mock_unfrackpath_tilde
    from units.mock.path import mock_unfrackpath_verylong
    from units.mock.path import mock_unfrackpath_space

    # get path of play
    p = Play()
    p.vars = dict()
    p._ds = DictDataLoader({None: dict(hosts='all')}).get_basedir()
    p._ds._data_source = 'playbook.yml'

# Generated at 2022-06-21 00:13:25.185634
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    obj = FieldAttributeBase()
    obj2 = obj.copy()
    return True

# Generated at 2022-06-21 00:13:31.547149
# Unit test for method get_path of class Base
def test_Base_get_path():


    #test palybook
    playbook_test = Playbook()
    playbook_test._ds._data_source="playbook1.yml"
    playbook_test._ds._line_number=9
    
    
    #test play
    play_test = Play()
    play_test._ds._data_source="play1.yml"
    play_test._ds._line_number=3
    play_test._parent=playbook_test
    
    
    #test handler
    handler_test = Handler()
    handler_test._ds._data_source="handler1.yml"
    handler_test._ds._line_number=6
    handler_test._parent=play_test
    
    
    #test task
    task_test = Task()

# Generated at 2022-06-21 00:13:42.795042
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # tests that the returned value is coerced to the specified type

    field_attr_base = FieldAttributeBase()
    test_value = 'test_value'

    # test string type
    assert field_attr_base.get_validated_value('test', FieldAttribute('test', True, 'string'), test_value, DummyTemplar()) == \
           to_text(test_value)

    # test int type
    assert field_attr_base.get_validated_value('test', FieldAttribute('test', True, 'int'), test_value, DummyTemplar()) == \
           int(test_value)

    # test float type

# Generated at 2022-06-21 00:14:08.233992
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
  pat = FieldAttributeBase()
  t = Patcher()
  t.patch_object(pat, '_valid_attrs', {})
  t.patch_object(pat, '_loader', {})
  t.patch_object(pat, '_variable_manager', {})
  with t:
    assert not pat.dump_me()

# Generated at 2022-06-21 00:14:13.963874
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    global FAKE_FIELDATTRIBUTE_INIT_VARIABLE_MANAGER

    FAKE_FIELDATTRIBUTE_INIT_VARIABLE_MANAGER = FakeVariableManager()
    # create a 'FieldAttribute' object
    fieldattribute = FieldAttributeBase()
    # check that the 'get_variable_manager' method is working
    assert fieldattribute.get_variable_manager() == FAKE_FIELDATTRIBUTE_INIT_VARIABLE_MANAGER

# Generated at 2022-06-21 00:14:16.439389
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    attribute = FieldAttribute()
    attribute.post_validate(templar=Templar(loader=DictDataLoader({})))


# Generated at 2022-06-21 00:14:29.679401
# Unit test for method from_attrs of class FieldAttributeBase

# Generated at 2022-06-21 00:14:38.136458
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
  #Basic case
  base_obj = Base()
  assert base_obj.get_search_path() == []

  #Test case with dep_chain
  dep_chain = [Base(), Base()]
  dep_chain[0]._role_path = "path0"
  dep_chain[0]._parent = dep_chain[1]
  base_obj = Base()
  base_obj._parent = dep_chain[0]
  base_obj.set_path("path2")

  assert base_obj.get_search_path() == ["path0", "path2"]
  dep_chain[1]._role_path = "path1"
  assert base_obj.get_search_path() == ["path0", "path1", "path2"]

  #Test case with role_path
  base_obj = Base()

# Generated at 2022-06-21 00:14:47.475196
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    set_loader()

    test_attr = FieldAttributeBase()
    hostvars = HostVars()
    test_attr._value = hostvars

    # this test should pass even there isn't a new_attr
    new_attr = test_attr.dump_me()

    # this test should pass even there isn't a new_attr._value
    assert new_attr.__class__.__name__ == 'FieldAttributeBase'


if __name__ == '__main__':
    # Run local unit tests
    test_FieldAttributeBase_dump_me()



# Generated at 2022-06-21 00:14:51.580773
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    def mock_get_dep_chain():
        return None
    def mock_get_path():
        return 'hello'
    import os.path
    import unittest
    import unittest.mock
    _p = patch('ansible.playbook.Base.get_dep_chain', new=mock_get_dep_chain)
    _p.start()
    Base._module_defaults = None    # fix for a test
    Base._become = None             # fix for a test
    Base._become_method = None      # fix for a test
    Base._connection = None         # fix for a test
    Base._become_user = None        # fix for a test
    Base._become_flags = None       # fix for a test
    Base._become_exe = None         # fix for a test
    Base

# Generated at 2022-06-21 00:15:02.292627
# Unit test for method get_path of class Base
def test_Base_get_path():

    play_source = dict(
        name="Ansible Play 007",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ifconfig')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    play._ds._data_source = '/home/xyz/playbooks/pb.yaml'
    play._ds.set_basedir('/home/xyz/playbooks/')

    play._tasks[0]._ds._line_number = 5

# Generated at 2022-06-21 00:15:05.541827
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    usr_args = dict(
    )
    with pytest.raises(Exception, match=r"^unsupported operand type\(s\) for -: 'FieldAttributeBase' and 'FieldAttributeBase'$"):
        FieldAttributeBase.load_data(usr_args)


# Generated at 2022-06-21 00:15:10.939962
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    import pytest
    l_obj = BaseObject()
    l_data = dict(name='test')
    l_attr = FieldAttribute()
    l_obj._valid_attrs = dict(name=l_attr)
    l_obj.deserialize(l_data)

# Generated at 2022-06-21 00:15:42.582815
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    print("test_FieldAttributeBase_preprocess_data")
    # Method calls tested
    #
    # def preprocess_data(self, ds, templar, validate_targets=True):

    # NOTE: Probably should develop these tests

    module = null_module
    templar = Templar(loader=FakeLoader(), variables=GoodScript())
    defaults = dict(
        required=False,
        default=None,
        always_post_validate=False,
        choices=None,
        aliases=[],
        version_added=None,
    )
    attr = FieldAttributeBase()
    ds = {'ds_name': 'data_source'}

    # Testing choices
    attr = FieldAttributeBase(**defaults)
    attr.choices = 'choice1, choice2'
    assert attr

# Generated at 2022-06-21 00:15:49.943587
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    a = Base()
    assert a.get_search_path() == []

    b = Base()
    setattr(b, '_parent', a)
    setattr(b, '_role_path', 'role_path')
    assert b.get_search_path() == ['role_path']

    c = Base()
    setattr(c, '_parent', b)
    setattr(c, '_role_path', 'role_path')
    assert c.get_search_path() == ['role_path', 'role_path']

if __name__ == "__main__":
    test_Base_get_search_path()


# Generated at 2022-06-21 00:15:54.379864
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    from ansible.vars.manager import VariableManager

    fixture_obj = FieldAttributeBase()
    fixture_obj._variable_manager = VariableManager()
    fixture_val = fixture_obj.get_variable_manager()

    assert fixture_val == fixture_obj._variable_manager

# Generated at 2022-06-21 00:16:06.550527
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    with pytest.raises(AssertionError):
        FieldAttributeBase('description', choices=True, attribute_type='description')
    FieldAttributeBase('description', choices='foo bar', attribute_type='description')
    with pytest.raises(AssertionError):
        FieldAttributeBase('description', choices=[1, 2], attribute_type='description')
    with pytest.raises(AssertionError):
        FieldAttributeBase('description', choices={'foo': 'bar'}, attribute_type='description')
    FieldAttributeBase('description', attribute_type='description')
    FieldAttributeBase('description', choices=True, attribute_type='choice', choices_type='list')
    with pytest.raises(AssertionError):
        FieldAttributeBase('description', choices=True, attribute_type='choice', choices_type='hash')
   

# Generated at 2022-06-21 00:16:14.105717
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    f = FieldAttributeBase("testing")

    assert not f.required
    assert f.isa == 'string'
    assert f.default == None
    assert not f.always_post_validate
    assert not f.choices

    assert not f.validate()

    f.default = 'testing'

    assert not f.validate()

    f.required = True

    assert f.validate()

    f.choices = ['test']

    assert f.validate()

    f.default = 'blaat'

    assert not f.validate()
    assert f.value == 'test'

    f.default = 'testing'

    assert not f.validate()

    f.choices = ['test', 'ing']

    assert f.validate()

    f.isa = 'int'

    assert not f.valid

# Generated at 2022-06-21 00:16:17.363662
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    load_fixture('test_FieldAttributeBase_get_variable_manager')
    a = FieldAttributeBase()
    a.get_variable_manager() == None



# Generated at 2022-06-21 00:16:29.886255
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    FA = FieldAttributeBase()
    FA.isa = 'string'
    assert FA.get_validated_value('test_attr', FA, 'test_value', {}) == 'test_value'
    FA.isa = 'int'
    assert FA.get_validated_value('test_attr', FA, '1', {}) == 1
    FA.isa = 'float'
    assert FA.get_validated_value('test_attr', FA, '1.0', {}) == 1.0
    FA.isa = 'bool'
    assert FA.get_validated_value('test_attr', FA, 'true', {}) == True
    FA.isa = 'percent'
    assert FA.get_validated_value('test_attr', FA, '1', {}) == 1.0
    FA.isa = 'list'


# Generated at 2022-06-21 00:16:35.622091
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    Unit test for method get_dep_chain of class Base
    '''
    b = Base()
    assert not b.get_dep_chain()
    b = Base()
    b._parent = Base()
    assert not b.get_dep_chain()
    b._parent = Base()
    b._parent._play = 'a'
    assert not b.get_dep_chain()


# Generated at 2022-06-21 00:16:42.047682
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Testing Attribute with name 'name' and static False
    foo = FieldAttributeBase(
        name='name',
        static=False,
        default='default',
        alias='name_alias'
    )
    assert foo.squash(val='val') == 'val'
    # Testing Attribute with name 'name' and static True
    foo = FieldAttributeBase(
        name='name',
        static=True,
        default='default',
        alias='name_alias'
    )
    assert foo.squash(val='val') == 'val'
    # Testing Attribute with name 'name' and static None
    foo = FieldAttributeBase(
        name='name',
        static=None,
        default='default',
        alias='name_alias'
    )

# Generated at 2022-06-21 00:16:46.220847
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    _loader = DataLoader()
    _object = FieldAttributeBase()
    assert _object.preprocess_data(1, _loader) == 1


# Generated at 2022-06-21 00:17:19.605624
# Unit test for method serialize of class FieldAttributeBase

# Generated at 2022-06-21 00:17:21.861332
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
  # Test with valid positional arguments
  data = dict()
  assert FieldAttributeBase().deserialize(data) == None


# Generated at 2022-06-21 00:17:32.482899
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Test1(object):
        # test that underscores are stripped from FieldAttribute names
        _att1 = FieldAttribute(default=1)
        # test that an attribute can be aliased
        _att2 = FieldAttribute(aliases=['att2_alias'], default=2)
        # test that the FieldAttribute is stored
        _att3 = FieldAttribute(default=3)

    class Test2(object):
        # test a new attribute
        _att4 = FieldAttribute(default=4)
        # test that an existing attribute can be overridden
        _att1 = FieldAttribute(default=5)

    class Test3(Test1, Test2):
        # test an attribute with a getter
        _att5 = FieldAttribute(default=6)

        def _get_attr_att5(self):
            return 7


# Generated at 2022-06-21 00:17:43.261934
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    repr = dict()
    field_attribute_base.deserialize(repr)

    repr = dict()
    repr['name'] = 'test'
    repr['required'] = True
    repr['always_post_validate'] = False
    repr['default'] = dict()
    repr['default']['makedirs'] = True
    repr['options'] = dict()
    repr['options']['choices'] = ['a', 'b', 'c']
    field_attribute_base.deserialize(repr)

    repr = dict()
    repr['name'] = 'test'
    repr['required'] = False
    repr['always_post_validate'] = False
    repr['default'] = dict()
    repr['default']['makedirs'] = True
   

# Generated at 2022-06-21 00:17:44.449879
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    o = FieldAttributeBase()


# Generated at 2022-06-21 00:17:55.537841
# Unit test for constructor of class Base
def test_Base():
    #setup
    test_obj = Base()

    # testing constructor
    assert test_obj._valid_attrs.keys() == ['_name', '_connection', '_port', '_remote_user',
                                            '_vars', '_module_defaults', '_environment', '_no_log',
                                            '_run_once', '_ignore_errors', '_ignore_unreachable',
                                            '_check_mode', '_diff', '_any_errors_fatal',
                                            '_throttle', '_timeout', '_debugger', '_become',
                                            '_become_method', '_become_user', '_become_flags',
                                            '_become_exe']
    assert test_obj._name == ''
    assert test_obj._connection

# Generated at 2022-06-21 00:18:07.718749
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test normal operation
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = DictDataLoader({})
    mock_ds = MagicMock()
    mock_value = MagicMock()
    mock_ds.get.return_value = mock_value
    # call the operation
    result = FieldAttributeBase.load_data(loader, mock_ds, 2)
    assert not hasattr(result, '__ansible_vault')
    assert not hasattr(result, '__ansible_vault_version')
    assert not hasattr(result, '__ansible_vault_password')
    assert isinstance(result, DataLoader)
    assert result.path == 'path/to/data'
    assert result.name == '2'
    # verify the results

# Generated at 2022-06-21 00:18:14.630296
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from mock import Mock
    from mock import patch
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._fact_cache = {}
    variable_manager.set_available_variables({u'inventory_hostname': u'foo', u'omit': u'OMITTED', u'groups': [u'bar', u'baz'], u'group_names': [u'bar', u'baz'], u'inventory_hostname_short': u'foo'})

    play_context = Mock()

# Generated at 2022-06-21 00:18:18.110513
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    f = FieldAttributeBase('foo')
    f.default = 'bar'
    new_f = f.copy()
    assert new_f.default == 'bar'

# Generated at 2022-06-21 00:18:24.593289
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # init
    task = Task()
    attrs = task.serialize()

    # deserialize
    new_task = Task()
    new_task.deserialize(attrs)

    # assert
    assert new_task._finalized
    assert new_task._squashed
    assert new_task._uuid is not None



# Generated at 2022-06-21 00:18:55.874136
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # First, we test the meta class
    class Test1(object):
        meta = BaseMeta
        __metaclass__ = meta
    cls = Test1()
    assert cls._attributes == {}
    assert cls._valid_attrs == {}
    assert cls._alias_attrs == {}

    # Second, we test the meta class of a class with a attribute
    class Test2(object):
        meta = BaseMeta
        __metaclass__ = meta
        attr1 = FieldAttribute()
    cls = Test2()
    assert cls._attributes == {}
    assert cls._valid_attrs == {'attr1': FieldAttribute()}
    assert cls._alias_attrs == {}

    # Third, we test the meta class of a class with a valid attribute

# Generated at 2022-06-21 00:19:04.556100
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    # Setup
    fa = FieldAttributeBase()

    # Testing
    result = copy(fa)

    # Verify
    assert fa is not result
    assert fa._name is result._name
    assert fa.required is result.required
    assert fa.aliases is result.aliases
    assert fa.always_post_validate is result.always_post_validate
    assert fa.default is result.default
    assert fa.version_added is result.version_added
    assert fa.version_removed is result.version_removed


# Generated at 2022-06-21 00:19:06.110916
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    obj = FieldAttributeBase()
    obj.serialize()


# Generated at 2022-06-21 00:19:14.613616
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    '''
    field_attributes.py:175: FieldAttributeBase:preprocess_data
    '''
    #
    # Test for method preprocess_data
    #
    # FIXME: add tests here
    #

    # testing a specific field attribute
    from ansible.utils.vars import combine_vars

    test_data = dict(
        test1='test1',
        test2=dict(test2='test2'),
        test3=[dict(test3='test3'), dict(test4='test4')],
        test4=[{'test5': 'test5', 'test6': 'test7'}, dict(test8='test8', test9='test9')],
        test10=1,
        test11=True,
        test12=None,
    )


# Generated at 2022-06-21 00:19:17.376218
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    #This is a base class method, it should raise NotImplementedError
    with pytest.raises(NotImplementedError):
        obj.get_ds()



# Generated at 2022-06-21 00:19:20.496184
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attribute_base = FieldAttributeBase()
    value = ''
    name = None
    parent_object = FieldAttributeBase()
    msg = field_attribute_base.validate(value, name, parent_object)
    assert msg is None


# Generated at 2022-06-21 00:19:24.543270
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pl = Play()

    pl_copy = pl.copy()

    assert pl_copy is not pl

    assert pl_copy._loader is pl._loader

    assert pl_copy._variable_manager is pl._variable_manager

    assert pl_copy._validated == pl._validated

    assert pl_copy._finalized == pl._finalized

    assert pl_copy._uuid == pl._uuid



# Generated at 2022-06-21 00:19:28.996874
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    class MyFieldAttributeBase(FieldAttributeBase):
        def __init__(self, loader):
            super(MyFieldAttributeBase, self).__init__(loader=loader)
    f = MyFieldAttributeBase(loader=DictDataLoader({}))
    a = f.get_loader()
    assert type(a) == DictDataLoader



# Generated at 2022-06-21 00:19:29.596316
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass

# Generated at 2022-06-21 00:19:40.442866
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Test with a value that is correct for boolean
    validator = FieldAttributeBase()
    name = 'name'
    attribute = FieldAttribute(isa='bool')
    value = 'false'
    templar = 'templar'
    assert validator.get_validated_value(name, attribute, value, templar) is False

    # Test with a wrong value
    validator = FieldAttributeBase()
    name = 'name'
    attribute = FieldAttribute(isa='bool')
    value = 'test_value'
    templar = 'templar'
    raised = False
    try:
        validator.get_validated_value(name, attribute, value, templar)
    except TypeError as e:
        raised = True
    assert raised

    # Test with a value that is correct for int
    valid

# Generated at 2022-06-21 00:20:14.414245
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    args = get_fixture_data('get_loader.yml')[0]
    attr = FieldAttributeBase()
    if args.get('exception'):
        with pytest.raises(args['exception']): attr.get_loader()
    else:
        assert attr.get_loader() == args['return']

# Generated at 2022-06-21 00:20:27.275422
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    test_obj = FieldAttributeBase()
    test_name = u'test_name'
    test_attribute = u'test_attribute'
    test_value = u'test_value'
    test_templar = u'test_templar'
    test_obj.get_validated_value(test_name, int, test_value, test_templar)
    test_obj.get_validated_value(test_name, float, test_value, test_templar)
    test_obj.get_validated_value(test_name, bool, True, test_templar)
    test_obj.get_validated_value(test_name, bool, False, test_templar)

# Generated at 2022-06-21 00:20:30.212721
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    mybase = FieldAttributeBase()

    lu = ansible_module_loader.Loader()
    myclass = type('', (object,), {})
    myobject = lu.load_module_source('dummy', 'test.yml')
    myobject.__class__ = myclass
    myclass.ds = myobject
    myds = myobject.ds
    mybase.get_ds() == myds

# Generated at 2022-06-21 00:20:32.621651
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    obj = FieldAttributeBase()
    attrs = {}
    assert obj.from_attrs(attrs) == None


# Generated at 2022-06-21 00:20:34.548427
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    assert obj.get_ds() == 'None'


# Generated at 2022-06-21 00:20:38.365614
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():

    attr = FieldAttributeBase()
    actual = attr.serialize()
    assert actual == 'FieldAttributeBase'
    attr.name = 'test'
    actual = attr.serialize()
    assert actual == 'FieldAttributeBase:test'



# Generated at 2022-06-21 00:20:43.208908
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
  x = FieldAttributeBase()
  try:
    if not x.get_variable_manager():
      assert False
    if hasattr(x, '_variable_manager'):
      assert True
    else:
      assert False
  except Exception as e:
    print(e)
test_FieldAttributeBase_get_variable_manager()


# Generated at 2022-06-21 00:20:54.940265
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():

    def test_data(value, expected):
        attribute = FieldAttributeBase('foo')
        got = attribute.preprocess_data(value)
        assert expected == got, 'expected %s, but got %s' % (expected, got)

    test_data(None, [])
    test_data(1, [])
    test_data([], [])
    test_data(dict(), [])
    test_data({}, [])
    test_data([None], [])
    test_data(['1'], ['1'])
    test_data([1], [1])
    test_data([1, 2], [1, 2])
    test_data([1, 2, 3], [1, 2, 3])
    test_data({'foo': 'bar'}, [{'foo': 'bar'}])
# Unit

# Generated at 2022-06-21 00:21:00.436125
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    f = FieldAttributeBase()

    # set _variable_manager to some random value
    f._variable_manager = "foo"

    # get _variable_manager, which should now be "foo"
    result = f.get_variable_manager()

    # _variable_manager should now be "foo"
    assert result == "foo"



# Generated at 2022-06-21 00:21:04.498005
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class MyClass():
        __metaclass__ = BaseMeta
        dummy_field = FieldAttribute(isa='bool', default=False)

    assert isinstance(MyClass().dummy_field, bool)
    assert isinstance(MyClass().dummy_field, property)

