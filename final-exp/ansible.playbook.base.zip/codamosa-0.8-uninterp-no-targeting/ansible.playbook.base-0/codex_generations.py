

# Generated at 2022-06-21 00:12:39.292165
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    obj = Base()

    # path stack is empty when dep chain is None
    obj.get_dep_chain = MagicMock(return_value=None)
    assert obj.get_dep_chain() is None
    assert obj.get_search_path() == []

    # path stack includes dir of task and list of roles in dep chain,
    # in reverse order from dep to dependency
    obj.get_dep_chain = MagicMock(return_value=['path_role'])
    obj.get_path = MagicMock(return_value='path_task')
    obj._role_path = 'path_role'
    obj.get_dep = MagicMock(return_value=['A', 'B'])
    path_stack = ['path_role', 'path_task']
    assert obj.get_search_path() == path

# Generated at 2022-06-21 00:12:39.914973
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    pass

# Generated at 2022-06-21 00:12:49.193023
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    FA = FieldAttributeBase
    assert FA('one', FieldAttributeBase.STRING, 'two').preprocess_data('testing', {}) == 'testing'
    assert FA('one', FieldAttributeBase.STRING, 'two').preprocess_data(['testing', 'ing'], {}) == 'testing'
    assert FA('one', FieldAttributeBase.STRING, 'two').preprocess_data(['testing', 'ing'], {'one': 'not'}) == 'not'
# END class FieldAttributeBase


# Generated at 2022-06-21 00:12:55.210399
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method get_loader of class FieldAttributeBase.
    '''
    a_FieldAttributeBase = FieldAttributeBase()
    try:
        a_FieldAttributeBase.get_loader()
    except NotImplementedError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 00:13:01.607840
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # FIXME: tweak to test
    obj = FieldAttributeBase()
    name = 'foo'
    attribute = 'bar'
    value = 'baz'
    templar = 'qux'

    # call the method (skipping the first three args)
    method = getattr(obj, 'get_validated_value')
    retval = method(attribute, value, templar)
    assert retval is not None

    # make sure the method only accepts 3 argument
    argspec = getargspec(method)
    assert len(argspec.args) == len(argspec.defaults) + 1
    assert argspec.varargs is None
    assert argspec.keywords is None

# Generated at 2022-06-21 00:13:04.830534
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Create a FieldAttributeBase object
    FieldAttributeBase = FieldAttributeBase()
    assert False # TODO: implement your test here


# Generated at 2022-06-21 00:13:16.113475
# Unit test for constructor of class Base
def test_Base():
    assert Base().get_search_path() == []
    assert Base(connection='connection_value')._connection == 'connection_value'
    assert Base(port='port_value')._port == 'port_value'
    assert Base(remote_user='remote_user_value')._remote_user == 'remote_user_value'
    assert Base(vars='vars_value')._vars == 'vars_value'
    assert Base(module_defaults='module_defaults_value')._module_defaults == 'module_defaults_value'
    assert Base(environment='environment_value')._environment == 'environment_value'
    assert Base(no_log='no_log_value')._no_log == 'no_log_value'

# Generated at 2022-06-21 00:13:20.310904
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    data = {
    'extra_vars': {'k': 'v'},
    'name': 'test',
    'vars': {'a': 'b'}
    }
    expected = {
    'extra_vars': {'k': 'v'},
    'name': 'test',
    'vars': {'a': 'b'}
    }
    obj = BaseObject()
    obj.deserialize(data)
    assert obj.dump_attrs() == expected
    return True

# Generated at 2022-06-21 00:13:21.845058
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    FieldAttributeBase.test(test_FieldAttributeBase_from_attrs_run)

# Generated at 2022-06-21 00:13:23.491043
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    base = FieldAttributeBase()

    my_dict = {'a': 'b'}

    base._attributes = my_dict
    base._variable_manager = dict()

# Generated at 2022-06-21 00:13:57.369065
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():  # noqa
    FieldAttributeBase._instances = []

    x = FieldAttributeBase(default=None, inherit=False, priority=0,
                           isa=None, static=False, listof=None, class_type=None, always_post_validate=False,
                           required=False, validate=None, include_in_dump=False)

    # Test for correct exception for incorrect number of arguments
    try:
        x.copy()
    except TypeError as excobj:
        if excobj.args == ("copy() takes exactly 2 arguments (1 given)",):
            pass
        else:
            raise
    # Test whether copy returned an object of correct type
    assert isinstance(x.copy(None), FieldAttributeBase)
    # Test whether copy returned a copy of the object
    assert x.copy(None) is not x




# Generated at 2022-06-21 00:14:00.596381
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    '''
    Unit test for method get_dep_chain of class Base
    '''
    test_obj = Base('whatever', None, None)
    res = test_obj.get_dep_chain()
    assert res is None


# Generated at 2022-06-21 00:14:10.926317
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Make sure we trigger TypeError if the data type is not right
    '''
    # Test to make sure we raise TypeError if FieldAttributeBase is not subclassed
    attr = FieldAttributeBase
    attr.isa = 'string'
    attr.static = False
    # Create a templar object
    templar = Templar()
    try:
        # Ensure we raise TypeError since this is an instance of FieldAttributeBase
        f = attr.post_validate(templar)
    except TypeError:
        pass
    else:
        raise Exception("TypeError not raised")
    # Test to make sure we trigger TypeError if the data type is not right
    # Test to make sure we trigger TypeError if the data type is not right
    attr = FieldAttributeBase
    attr.isa = 'string'


# Generated at 2022-06-21 00:14:13.551623
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():

    t = FieldAttributeBase()
    data = dict()
    assert isinstance(data, dict)
    assert t.deserialize(data) is None
    assert not hasattr(t, 'name')


# Generated at 2022-06-21 00:14:26.730042
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    data = dict()
    data['name'] = "temp_file_content"
    data['required'] = True
    data['allowed_choices'] = None
    data['always_post_validate'] = False
    data['always_post_validate_on_template'] = False
    data['static'] = False
    data['aliases'] = None
    data['version_added'] = None
    data['deprecated_for_removal'] = False
    data['deprecated_since'] = None
    data['deprecated_reason'] = None
    data['removed_in_version'] = None
    data['extended_default'] = None
    data['default'] = None
    data['required_if'] = []
    data['required_one_of'] = []
    data['mutually_exclusive'] = []
    data

# Generated at 2022-06-21 00:14:28.914523
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    """
    Tests serialize method
    """

    my_obj = FieldAttributeBase(
        name='test_string',
        static=True,
        default='hello',
        isa='string'
    )

    assert my_obj.serialize() == "hello"

# Generated at 2022-06-21 00:14:30.244360
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass


# Generated at 2022-06-21 00:14:38.464683
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import add_all_plugin_dirs

    t = Task.load(dict(name='test'))
    assert t.get_search_path() == [t.get_path()]

    t2 = Task.load(dict(name='test2'))
    t._parent = t2
    assert t.get_search_path() == [t2.get_path(), t.get_path()]

    t2._parent = t

# Generated at 2022-06-21 00:14:49.000337
# Unit test for constructor of class Base
def test_Base():
    obj = Base()
    assert obj._become is False
    assert obj._become_method == 'sudo'
    assert obj._become_user == 'root'
    assert obj._connection == 'smart'
    assert obj._debugger is None
    assert obj._environment == []
    assert obj._ignore_errors is False
    assert obj._ignore_unreachable is False
    assert obj._module_defaults == []
    assert obj._no_log is False
    assert obj.name == ''
    assert obj._remote_user == 'root'
    assert obj._port is None
    assert obj._become_flags == ''
    assert obj._become_exe is None

# Generated at 2022-06-21 00:14:54.088029
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    '''
    Tests method dump_attrs of class FieldAttributeBase
    '''
    # Create an instance of class FieldAttributeBase
    test_obj = FieldAttributeBase()

    # Try calling method dump_attrs of class FieldAttributeBase with required arguments.
    result = test_obj.dump_attrs()


# Generated at 2022-06-21 00:15:25.323826
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    #Unit test for get_dep_chain of class Base.
    #Input: _parent of task is not None, _dep_chain of task is not None
    #Output: dep_chain
    from Units.Mock.loader import Ds
    from Units.Mock.loader import DataLoader
    from Units.Mock.vault import VaultLib
    from Units.Mock.vars import VarsModule
    from Units.Mock.task_queue_manager import TaskQueueManager
    from Units.Mock.action_factory import ActionFactory
    global_loader = DataLoader()
    global_vars_fact = VarsModule()
    global_vault = VaultLib()
    global_action_fact = ActionFactory(global_vault)

# Generated at 2022-06-21 00:15:36.540720
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.taggable import TagBase

    class MyMetaclass(BaseMeta):
        pass

    class MyClass(with_metaclass(MyMetaclass, object)):
        pass

    obj = MyClass()
    assert hasattr(obj, '_attributes')
    assert hasattr(obj, '_attr_defaults')
    assert hasattr(obj, '_valid_attrs')
    assert hasattr(obj, '_alias_attrs')
    assert not hasattr(obj, '_get_attr_name')

    class MyClass(with_metaclass(MyMetaclass, object)):
        name = FieldAttribute(isa='str', default='test name')



# Generated at 2022-06-21 00:15:47.615455
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Unit test for method from_attrs of class FieldAttributeBase
    '''
    print("test_FieldAttributeBase_from_attrs")

    # Setup
    fake_attr = 'fake attribute'
    fake_attrs = {fake_attr: 'fake value'}

    class TestFieldAttributeBase(FieldAttributeBase):
        def __init__(self):
            self._valid_attrs = dict()
            self._valid_attrs[fake_attr] = FieldAttribute(isa='str')
            self._valid_attrs[fake_attr].default = 'default'

    obj = TestFieldAttributeBase()
    obj.from_attrs(fake_attrs)

    # Test
    result = getattr(obj, fake_attr)

    # Verify

# Generated at 2022-06-21 00:15:51.175502
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # Creating object of type FieldAttributeBase
    obj = FieldAttributeBase()

    #Checking for correctness of test case
    assert obj.get_ds() == None, "Test case for method get_ds of class FieldAttributeBase failed"
    return obj



# Generated at 2022-06-21 00:16:03.667357
# Unit test for method get_path of class Base
def test_Base_get_path():
    global play_context
    play_context = PlayContext()
    context.CLIARGS = ImmutableDict(connection='local', become=False, become_method=None, become_user=None,
                                    check=False, diff=False, remote_user=None, timeout=30,
                                    inventory_hostname='foo.example.org', forks=5,
                                    module_path=DEFAULT_MODULE_PATH,
                                    module_name='foo',
                                    module_args=None,
                                    role_names=[],
                                    step=False,
                                    start_at_task=None,
                                    args=[])
    context.CLIARGS['module_path'] = DEFAULT_MODULE_PATH
    context.CLIARGS['module_name'] = 'foo'

# Generated at 2022-06-21 00:16:05.752102
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    fieldbase = FieldAttributeBase()
    fieldbase._serialize()
    fieldbase._deserialize()

# Generated at 2022-06-21 00:16:08.540750
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field_attr = FieldAttributeBase()
    assert field_attr is not None


# Generated at 2022-06-21 00:16:20.196922
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # mock

    class Object(object):
        def __init__(self, *args, **kwargs):
                self._finalized = False

    # actual
    o = Object()

# Generated at 2022-06-21 00:16:23.009330
# Unit test for method get_path of class Base
def test_Base_get_path():
    c = Base()
    if str(c.get_path()) != ":0":
        return False
    return True

# Generated at 2022-06-21 00:16:28.380486
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    FieldAttributeBase.copy
    '''

    my_attr = FieldAttributeBase(default='my_default')

    new_attr = my_attr.copy()

    assert isinstance(new_attr, FieldAttributeBase)
    assert new_attr.default == 'my_default'

# Generated at 2022-06-21 00:16:59.945392
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    b = FieldAttributeBase()
    with pytest.raises(NotImplementedError):
        b.squash()

# Generated at 2022-06-21 00:17:11.229999
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # testing constructor
    field_attribute_base = FieldAttributeBase("test", None)
    assert field_attribute_base.name == "test"
    assert field_attribute_base.required == False
    assert field_attribute_base.always_post_validate == False
    assert field_attribute_base.aliases == tuple()
    assert field_attribute_base.class_type is None
    assert field_attribute_base.default is None
    assert field_attribute_base.isa == 'str'
    assert field_attribute_base.listof is None
    assert field_attribute_base.private == False
    assert field_attribute_base.static == False

    # Test isa parameter
    field_attribute_base = FieldAttributeBase("test", None, isa='int')
    assert field_attribute_base.isa == "int"

# Generated at 2022-06-21 00:17:19.691312
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_obj = Base()
    assert test_obj.get_path() == ''
    play_context = PlayContext()
    test_obj._ds = play_context
    test_obj._parent = play_context
    test_obj._parent._play = play_context
    test_obj._parent._play._ds = play_context
    ret = test_obj.get_path()
    assert isinstance(ret, str)


# Generated at 2022-06-21 00:17:30.105393
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    instance = FieldAttributeBase()
    data = {'key': 'value'}
    data = dict((to_text(key, errors='surrogate_or_strict'), value) for key, value in iteritems(data))
    expected = AnsibleDumper(None, width=1000).represent_dict(data, flow_style=False)
    actual = instance._load_data(data, 'some_name')
    assert isinstance(actual, AnsibleUnsafeText) or isinstance(actual, AnsibleUnicode)
    assert len(actual) == len(expected)

# Generated at 2022-06-21 00:17:41.245894
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    myBase = FieldAttributeBase()
    myBase._valid_attrs["my_attr"] = FieldAttribute(isa="class", default=None, class_type="Task")
    myBase._valid_attrs["my_attr2"] = FieldAttribute(isa="class", default=None, class_type="Task", private=True)
    myBase._variable_manager = VariableManager()
    myBase._loader = "some_loader"
    myBase._validated = True
    myBase._finalized = True
    myBase._ds = "some_ds"
    myBase._attributes["my_attr"] = "some_attributes"
    myBase._attributes["my_attr2"] = "some_attributes_2"
    myBase._attr_defaults["my_attr"] = "some_attr_defaults"
    myBase

# Generated at 2022-06-21 00:17:46.093727
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    class Foo(object):
        def __init__(self):
            self.ds = 'ds'
    obj = FieldAttributeBase()
    obj.__class__ = Foo
    assert 'ds' == obj.get_ds()
    obj.ds = 'ds'
    assert 'ds' == obj.get_ds()
    obj.ds = None
    assert None == obj.get_ds()


# Generated at 2022-06-21 00:17:49.119801
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method get_loader of class FieldAttributeBase
    '''
    field_attribute_base = FieldAttributeBase()
    assert field_attribute_base.get_loader() == None

# Generated at 2022-06-21 00:17:54.256327
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():

    FieldAttributeBase = collections.namedtuple('FieldAttributeBase', 'name isa default')

    fa = FieldAttributeBase(name='test_name', isa='bool', default='True')
    assert fa.dump_attrs() == {'test_name': 'True'}



# Generated at 2022-06-21 00:17:56.751270
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    lab = FieldAttributeBase()
    # FIXME: implement this test
    # assert lab.dump_me() == 'FIXME'

# Generated at 2022-06-21 00:17:59.004870
# Unit test for method get_path of class Base
def test_Base_get_path():
    # call method get_path of class Base
    test_object = Base()
    test_object.get_path()

# Generated at 2022-06-21 00:18:21.626820
# Unit test for method get_path of class Base
def test_Base_get_path():
    a = Base()
    if a.get_path() != "":
        print("Error get_path(self) method: returns: "+a.get_path())
    else:
        print("get_path(self) method is ok")

# Generated at 2022-06-21 00:18:26.675771
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    DataSource = namedtuple('DataSource', 'data_source line_number')

    raw = """
    - hosts: myhosts
      tasks:
        - name: test task
          debug:
            msg: "This is a test"
    """
    myhosts = AnsibleUnicode('myhosts')
   

# Generated at 2022-06-21 00:18:33.969703
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    """
    # Unit tests for FieldAttributeBase.copy
    """
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    _FieldAttributeBase = FieldAttributeBase()
    _FieldAttributeBase.always_post_validate = True
    _FieldAttributeBase.class_type = AnsibleUnsafeText
    _FieldAttributeBase.default = None
    _FieldAttributeBase.display = None
    _FieldAttributeBase.env = 'str'
    _FieldAttributeBase.field_name = 'myfield'
    _FieldAttributeBase.isa = 'dict'
    _FieldAttributeBase.listof = AnsibleUnsafeText
    _FieldAttributeBase.module = None
    _FieldAttributeBase.priority = 0
    _FieldAttributeBase.required = True
    _FieldAttributeBase.static = False
    _FieldAttributeBase.suboptions

# Generated at 2022-06-21 00:18:43.759945
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    fname = 'test_FieldAttributeBase_squash'
    mod = AnsibleModule(argument_spec={'x': dict(type='dict', required=True)})
    in_dict = getattr(mod.params, 'x')
    out_dict = FieldAttributeBase.squash(in_dict)
    yield _assert_eq, out_dict, in_dict

    # Test that default is ignored
    in_dict = {'a': 1, 'b': 2}
    out_dict = FieldAttributeBase.squash(in_dict)
    yield _assert_eq, out_dict, in_dict


# Generated at 2022-06-21 00:18:50.833056
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    class_module = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    field_module = 'ansible.utils.unsafe_proxy.AnsibleUnsafeText'
    field_attribute_base = FieldAttributeBase(class_module=class_module, field_module=field_module, default='name')
    variable_manager = 'name'
    variable_manager = field_attribute_base.get_variable_manager(variable_manager='name')
    return variable_manager

# Generated at 2022-06-21 00:18:56.316165
# Unit test for method get_path of class Base
def test_Base_get_path():
    class FakeDS():
       _data_source = 'filename'
       _line_number = 100
    class FakeParent():
       _play = FakeDS
    class FakeVars():
      pass
    obj = Base(FakeParent(), FakeVars())
    assert obj.get_path() == 'filename:100'

    class FakeParent2():
        _play = None
    class FakeParent3():
        _play = FakeParent2
    obj = Base(FakeParent3(), FakeVars())
    assert obj.get_path() == ''


# Generated at 2022-06-21 00:19:02.311118
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Get a test field attribute to test
    field_attribute = FieldAttributeBase()
    # test_object is a FieldAttributeBase
    test_object = field_attribute.get_validated_value(name=None, attribute=None, value=None, templar=None)
    assert isinstance(test_object, FieldAttributeBase)



# Generated at 2022-06-21 00:19:07.801741
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    s = sentinel
    attr = FieldAttributeBase('name', s.isa, s.required, s.static, s.default)
    assert attr.squash() is s.isa
    attr = FieldAttributeBase('name', s.isa, s.required, s.static, s.default, s.squash)
    assert attr.squash() is s.squash



# Generated at 2022-06-21 00:19:09.737434
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    import tempfile
    f = tempfile.TemporaryFile()
    with f as tempfile:
        pass


# Generated at 2022-06-21 00:19:10.286565
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    pass



# Generated at 2022-06-21 00:21:14.558448
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Initializing field attribute base object
    obj = FieldAttributeBase()
    # Dump method call of instance
    res = obj.dump_me()
    assert isinstance(res, dict)


# Generated at 2022-06-21 00:21:25.459730
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    '''
    Testcase to make sure the BaseMeta constructor behaves as expected.
    '''
    def _getter(self):
        return 'test'

    def _setter(self, value):
        pass

    class _Parent(object):
        __metaclass__ = BaseMeta

        _field1 = FieldAttribute(isa='str', default='field1', inherit=True)
        _field2 = FieldAttribute(isa='str', default='field2', inherit=False)

        def _get_attr_field2(self):
            return 'overridden'

    class BaseClass(_Parent):
        __metaclass__ = BaseMeta

        _field1 = FieldAttribute(isa='str', default='field1', inherit=True)
        _field2 = FieldAttribute(isa='str', default='field2', inherit=False)


# Generated at 2022-06-21 00:21:26.776967
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert False

# Generated at 2022-06-21 00:21:31.112079
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
  import unittest
  class FieldAttributeBase_dump_attrs_no_arguments(unittest.TestCase):
    def test(self):
      # the constructor
      x = C.FieldAttributeBase()
      # the test
      with self.assertRaises(AnsibleUndefinedVariable):
        x.dump_attrs()
  unittest.main(verbosity=2)