

# Generated at 2022-06-21 00:12:38.023579
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    fb = FieldAttributeBase()
    fb.is_string = False
    arg = "test"
    result = fb.preprocess_data(arg)
    assert result is arg, "Expected: %s\n Got: %s" % (arg, result)

    fb.is_string = True
    result = fb.preprocess_data(arg)
    assert result == "test", "Expected: %s\n Got: %s" % ("test", result)

    fb.is_string = "auto"
    result = fb.preprocess_data(arg)
    assert result == "test", "Expected: %s\n Got: %s" % ("test", result)

    # auto converts to string if the key is not in the datastructure
    fb.is_string = "auto"


# Generated at 2022-06-21 00:12:39.707632
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    c = FieldAttributeBase()
    c._variable_manager = 100

    expected = 100
    actual = c.get_variable_manager()

    assert expected == actual

# Generated at 2022-06-21 00:12:46.094978
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    # FieldAttributeBase
    fake_value = 1
    fake_fake_value = 1
    fake_attr = 1
    fake_value = 1
    object_fieldattributebase = FieldAttributeBase(fake_value, fake_fake_value)
    object_fieldattributebase.from_attrs(fake_attr)
    assert True



# Generated at 2022-06-21 00:12:56.871324
# Unit test for method get_path of class Base
def test_Base_get_path():
    from . import module_common
    # Test for method get_path for class Base
    # create a Base object, with a parent and a ds
    module_common.parent = Base()
    module_common.parent._ds = Base()
    # set the datasource to a file and line number
    module_common.parent._ds._data_source = "/etc/ansible/hosts"
    module_common.parent._ds._line_number = 2
    p = module_common.parent.get_path()
    # check the path generated
    assert p == "/etc/ansible/hosts:2"
    # test a second path with different line number
    module_common.parent._ds._line_number = 3
    p = module_common.parent.get_path()

# Generated at 2022-06-21 00:13:09.211870
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    def mock_shallowcopy():
        return {}
    FieldAttributeBase.shallowcopy = mock_shallowcopy
    # Initial partial testing of method 'get_validated_value'
    # set up required classes
    class TestFieldAttributeBasepost_validate(object):
        '''
        A class to support testing.
        '''
        def __init__(self):
            self._valid_attrs = {}

    class TestFieldAttributeBasepost_validate_get_validated_value:
        '''
        A class to support testing.
        '''
        def __init__(self):
            self.ds = TestFieldAttributeBasepost_validate()
            self.always_post_validate = False
            self.isa = 'bool'
            self.required = False
            self.default = None
            self

# Generated at 2022-06-21 00:13:11.643576
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    assert BaseMeta.__new__(BaseMeta, 'test_BaseMeta___new__', (Base,), {})

# Generated at 2022-06-21 00:13:12.590403
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    f = FieldAttributeBase()
    assert f.post_validate() == None

# Generated at 2022-06-21 00:13:20.603072
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # Arguments for FieldAttributeBase
    args = {}
    args['loader'] = None
    args['variable_loader'] = None
    # Initialize instance of FieldAttributeBase
    field_attribute_base = FieldAttributeBase(**args)
    loader = field_attribute_base.get_loader()
    assert loader is None
    field_attribute_base._loader = MockLoader()
    loader = field_attribute_base.get_loader()
    assert loader is not None
    assert loader.__class__.__name__ == 'MockLoader'
    assert not field_attribute_base._loader._set

# Generated at 2022-06-21 00:13:24.916732
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    """FieldAttributeBase.load_data: test cases for load_data for obj"""

    # Test obj is instance method
    # This is done because this function is called from
    # the init of AnsibleParser, which is not yet
    # initialized
    #
    # This test should be moved to the unit test of AnsibleParser
    pass



# Generated at 2022-06-21 00:13:26.754323
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    fixture = FieldAttributeBase()
    fixture.set_ds('ds')

    assert fixture.get_ds() == 'ds'

# Generated at 2022-06-21 00:14:02.331146
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    global __runner
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch

    class TestFieldAttributeBase_serialize(unittest.TestCase):
        def setUp(self):
            self.mock_FieldAttributeBase = create_autospec(FieldAttributeBase)


        @patch('ansible.parsing.yaml.safe_dump')
        @patch('ansible.parsing.yaml.safe_load')
        def test_FieldAttributeBase_serialize_failing_value_error(self, mock_safe_load, mock_safe_dump):
            '''
            Test generic method serialize on class FieldAttributeBase failing with ValueError
            '''

# Generated at 2022-06-21 00:14:12.542784
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    test_obj = FieldAttributeBase()

# Generated at 2022-06-21 00:14:25.423701
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar


# Generated at 2022-06-21 00:14:35.889318
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    # setup
    name = 'BaseMeta'
    parents = 'BaseMeta'
    dct = {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}
    dct['_attributes'] = {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}
    dct['_attr_defaults'] = {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}
    dct['_valid_attrs'] = {'_attributes': {}, '_attr_defaults': {}, '_valid_attrs': {}, '_alias_attrs': {}}


# Generated at 2022-06-21 00:14:42.222703
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():

    # set up the test variables
    ds = dict(a=1, b=2)

    # get the class being tested
    cls = FieldAttributeBase
    obj = cls(name='fork', default='a', inherit=False)

    # single run of the method being tested
    res = obj.get_ds(ds)

    # test assertions
    # success condition
    assert res == ds


# Generated at 2022-06-21 00:14:49.428058
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    data = {'vars': ['attr:value', 'attr2:value2']}
    task = Task()
    task.load_data(data=data)
    assert not hasattr(task, '_validated')
    task.post_validate(MagicMock())
    assert hasattr(task, '_validated')
    assert task.vars == {'attr': 'value', 'attr2': 'value2'}


# Generated at 2022-06-21 00:14:53.040556
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    print('Running test_BaseMeta___new__()')
    test_class = BaseMeta.__new__(BaseMeta, '', (), {})
    assert isinstance(test_class, type)


# Generated at 2022-06-21 00:14:54.762965
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-21 00:14:56.520658
# Unit test for constructor of class Base
def test_Base():

    test_base = Base()
    print("Vars: " + str(test_base.vars))



# Generated at 2022-06-21 00:15:01.655882
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.play_context import PlayContext as pc
    from ansible.playbook.play import Play as p
    from ansible.playbook.task import Task as t
    from ansible.playbook.block import Block as b

    bc = b()
    bc.block = [t()]
    bc.block[0].name = 'first task'

    p_context = pc()
    p_context._ds = bc # Set a block to '_ds' (like in playbook.py)
    p_context._ds._line_number = 30  # Set an linenumber to '_line_number' (like in playbook.py)

    play = p()
    play._ds = bc # Set a block to '_ds' (like in playbook.py)
    play._ds._data_source = 'abc.yml'

# Generated at 2022-06-21 00:15:36.599405
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    # create a dummy class to use while testing
    class DummyClass(object):
        pass

    check_obj = DummyClass()
    check_obj.__name__ = 'dummy'

    # make sure default has right type
    f = FieldAttributeBase(isa='class_type')
    f.default = 'bob'
    assert f.isa == 'class_type'
    with pytest.raises(AnsibleAssertionError):
        f.validate(check_obj)

    # make sure listof has right type
    f = FieldAttributeBase(isa='list', listof='class_type')
    f.default = ['bob']
    assert f.isa == 'list'
    with pytest.raises(AnsibleAssertionError):
        f.validate(check_obj)

    #

# Generated at 2022-06-21 00:15:47.352413
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    FA = FieldAttributeBase
    class Tmp(object):
        define_field_attribute('f', FA.DefaultAttribute, default=1, secret=True)
        define_field_attribute('g', FA.DefaultAttribute, default=2)
    t = Tmp()
    assert t.f == 1
    assert t.g == 2
    t.g = 3
    assert t.g == 3
    assert t._get_attribute_value('g') == 3
    assert t._get_attribute_value('f') is None
    t.load_data(dict(f=3))
    assert t.f == 3
    assert t.g == 3
    assert t._get_attribute_value('g') == 3
    assert t._get_attribute_value('f') == 3



# Generated at 2022-06-21 00:15:48.939978
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():

    base_meta = BaseMeta('TestNew', object, {})
    assert base_meta is not None


# Generated at 2022-06-21 00:15:49.618741
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass

# Generated at 2022-06-21 00:15:52.584087
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    Test if FieldAttributeBase class can be created
    '''
    field = FieldAttributeBase()
    assert isinstance(field, object)


# Generated at 2022-06-21 00:16:05.141684
# Unit test for method validate of class FieldAttributeBase

# Generated at 2022-06-21 00:16:13.229421
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Foo(object):
        def __init__(self):
            self.foo = 1
    class Bar(object):
        _bar    = FieldAttribute(isa='boolean', default=False)
        baz     = FieldAttribute(isa='dict')
        _hidden = FieldAttribute(isa='int', default=5)
        __slots__ = ()
    class Baz(Bar, Foo):
        quux = FieldAttribute(isa='list', default=[])

    assert 'foo' in dir(Baz), "base class not inherited"
    assert 'baz' in dir(Baz), "base class attributes not inherited"
    assert '_hidden' in dir(Baz), "base class attributes not inherited"
    assert 'quux' in dir(Baz), "direct class attributes not inherited"


# Generated at 2022-06-21 00:16:18.391851
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():

    """
    FieldAttributeBase.get_loader:

    :raises:  TODO
    """
    # unit test for method "get_loader" of class "FieldAttributeBase"
    # we don't test this method, as it is always overriden in another
    # class.
    raise SkipTest 

# Generated at 2022-06-21 00:16:19.617874
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FieldAttributeBase().validate(None)

# Generated at 2022-06-21 00:16:20.390085
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    pass

# Generated at 2022-06-21 00:16:49.852992
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Setup
    f = FieldAttributeBase()
    f.attribute = 1
    field_name = '1'
    data = {}
    validate_required = True
    loader = '1'
    variable_manager = '1'
    all_vars = '1'
    
    # Test preprocess_data
    f.preprocess_data(field_name, data, validate_required, loader, variable_manager, all_vars)
    
    # Cleanup
    del f



# Generated at 2022-06-21 00:17:00.107379
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    def _load_data(self, data):
        '''
        Loads the data for a field, validating it according to the field
        definition. The data is stored in the object in a standardized
        manner for later use.
        '''

        # if 'self' does not have a setter, we are now done, since 'self' is a
        # field definition class, not an instance of a class
        if attribute.static:
            return

        if name in self._alias_attrs:
            attribute = self._alias_attrs[name]

        if self._squashed:
            # if the object is already squashed, don't attempt to validate or set defaults
            # (all objects should be validated before squashing, so this is safe)
            setattr(self, name, data)
            return

        # finally, store the value
       

# Generated at 2022-06-21 00:17:01.684517
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    attr = FieldAttributeBase(init=True)
    assert attr.copy() is not attr



# Generated at 2022-06-21 00:17:13.918493
# Unit test for method dump_me of class FieldAttributeBase

# Generated at 2022-06-21 00:17:23.405409
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Parent(object):
        __metaclass__ = BaseMeta
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}
    # if not isinstance(value, Attribute)
    class Child(Parent):
        __metaclass__ = BaseMeta
        _attributes = {}
        _attr_defaults = {}
        _valid_attrs = {}
        _alias_attrs = {}
        a = 'a'
        _b = Attribute('b')
    @classproperty
    def _c(cls):
        'c'
    assert Child._valid_attrs.get('b') == 'b'
    assert Child._attributes == {'b': Sentinel}

# Generated at 2022-06-21 00:17:23.946579
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    pass



# Generated at 2022-06-21 00:17:25.838170
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
	field_test = FieldAttributeBase()

	assert field_test.get_ds() == None


# Generated at 2022-06-21 00:17:39.406319
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    '''
    Unit test FieldAttributeBase serialize
    '''

    # Create an instance of FieldAttributeBase called foo
    foo = FieldAttributeBase()
    # Create an instance of FieldAttribute called attribute
    attribute = FieldAttribute()
    # Assign value to the serialize property of attribute
    attribute.serialize = 'test'
    # Assign attribute to the key copy of the valid_attrs of foo
    foo._valid_attrs['copy'] = attribute
    # Create an instance of FieldAttribute called attribute
    attribute = FieldAttribute()
    # Assign value to the serialize property of attribute
    attribute.serialize = 'test'
    # Assign attribute to the key copy of the valid_attrs of foo
    foo._valid_attrs['copy'] = attribute
    # Create an instance of FieldAttribute called attribute
    attribute = FieldAttribute()


# Generated at 2022-06-21 00:17:43.825284
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    attr = FieldAttributeBase()
    # Test no exception raised
    attr.validate('key', 'value')
    attr.validate('key', 1)

    # Test exception raised
    with pytest.raises(AnsibleParserError):
        attr.validate('key', 1.2)


# Generated at 2022-06-21 00:17:54.151379
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    fb = FieldAttributeBase()
    # We are initializing the object, so the squash should be false
    assert fb.squashed == False
    # We are initializing the object, so the finalized should be false
    assert fb.finalized == False
    fb.finalize()
    # We have finalized the object, so the finalized should be true
    assert fb.finalized == True
    # We have finalized the object, so the squash should be false
    assert fb.squashed == False
    fb.squash()
    # We have squashed the object, so the squash should be true
    assert fb.squashed == True
    # We have squashed the object, so the finalized should be true
    assert fb.finalized == True


# Generated at 2022-06-21 00:18:17.834017
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    pass



# Generated at 2022-06-21 00:18:23.424378
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    this_obj = FieldAttributeBase()
    this_obj.variable_manager = {'k1': 'v1'}
    ret = this_obj.get_variable_manager()
    assert ret == {'k1': 'v1'}


# Generated at 2022-06-21 00:18:28.982266
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    class TestClass(Base):
        def __init__(self, *args, **kwargs):
            super(TestClass, self).__init__(*args, **kwargs)
    cls = TestClass()._cls_name
    assert cls == 'TestClass', cls
    name = 'TestClass'
    parents = [Base]
    dct = {}

# Generated at 2022-06-21 00:18:38.166535
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # from ansible.vars import VariableManager
    # from ansible.module_utils._text import to_text
    # from ansible.module_utils.common._collections_compat import Mapping
    m_class = FieldAttributeBase()
    m_class._variable_manager = VariableManager()
    m_class.vars = dict()
    m_attrs = dict()
    result = m_class.get_variable_manager(m_attrs)
    assert result is not None



# Generated at 2022-06-21 00:18:49.546429
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import pdb
    # pdb.set_trace()
    class A(object):
        a = Attribute()

    class B(A):
        b = Attribute()

    class C(B):
        c = Attribute()

    dct = C.__dict__
    assert(dct['_attributes'] == {})
    assert(dct['_attr_defaults'] == {})
    assert(dct['_valid_attrs'] == {})
    assert(dct['_alias_attrs'] == {})
    assert(dct['a'] != None)
    assert(dct['b'] != None)
    assert(dct['c'] != None)

#     _process_parents([A, B], dct)
    test_BaseMeta__create_attrs()


# Generated at 2022-06-21 00:18:54.263934
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from collections import Mapping
    # Run tests for FieldAttributeBase.validate() method
    test_attr = FieldAttributeBase()

    # Test for correct return for correct input
    assert test_attr.validate('name', True) == Sentinel

    # test for correct return for incorrect input
    assert test_attr.validate('name', 'abc') == 'abc'

# Generated at 2022-06-21 00:19:06.476884
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for method load_data of class FieldAttributeBase

    Loads data into this field attribute.
    '''
    # Pass a mock data structure to FieldAttributeBase to get a mock class
    # This will allow the method under test to access the data structure
    mock_data = {
        '_valid_attrs': {},
        '_variable_manager': DictDataManager(),
        '_loader': DictDataManager(),
        '_attributes': {},
        '_attr_defaults': {},
        '_loader_data': {},
    }
    with patch.multiple(FieldAttributeBase, **mock_data):
        # Create the class under test
        f = FieldAttributeBase()
        # Create a mock data structure

# Generated at 2022-06-21 00:19:08.102529
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    obj = FieldAttributeBase()
    output = obj.get_ds()
    assert output is None



# Generated at 2022-06-21 00:19:11.292635
# Unit test for constructor of class BaseMeta
def test_BaseMeta():

    class Foo(object):
        _test = FieldAttribute(isa='str', default='hi')

    with pytest.raises(AttributeError):
        getattr(Foo(), 'test')

    foo = Foo()
    assert foo._test == 'hi'



# Generated at 2022-06-21 00:19:19.680487
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    hostvars = dict(
        localhost=dict(
            ansible_connection='local',
            inventory_hostname='localhost',
            group_names=['all', 'local']
        )
    )
    variable_manager = VariableManager(loader=None)

# Generated at 2022-06-21 00:20:50.788176
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    # Simple test to test Base class method get_dep_chain.
    # The method's functionality is tested in unit tests for its derived
    # classes only. This is to avoid calling method _post_validate_name()
    # which is not required for this class.

    set_loader()
    set_inventory()

    test_base_obj = Base()
    assert test_base_obj.get_dep_chain() is None
# test_Base_get_dep_chain()


# Generated at 2022-06-21 00:20:52.802702
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    attribute = FieldAttributeBase(isa='field')
    assert attribute.serialize() == dict(isa='field')

# Generated at 2022-06-21 00:20:56.017352
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    attr = FieldAttributeBase(default=None, name=None, include=None, exclude=None, strip=False)
    assert(False == attr.dump_me())


# Generated at 2022-06-21 00:21:06.877502
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    def _preprocess_data_a_data():
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
        return wrap_var(123)
    class _preprocess_data_a(object):
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
        def __init__(self, data):
            self.data = data
        def post_validate(self, templar):
            self.data = templar.template(self.data)
    class _preprocess_data_b(object):
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
        def foo(self):
            return self
        def __init__(self, var):
            self.data = var

# Generated at 2022-06-21 00:21:16.415111
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    'FieldAttribute object should serialize to a dict'
    data = dict()
    data['name'] = u'test name'
    data['uuid'] = u'test uuid'
    data['finalized'] = False
    data['squashed'] = False
    ds = dict()
    ds['vars'] = dict()
    ds['vars']['var1'] = u'test var'
    ds['vars']['var2'] = u'test var2'
    field_attribute_base = FieldAttributeBase(ds)
    repr = field_attribute_base.serialize()
    assert repr == data


# Generated at 2022-06-21 00:21:27.512137
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # Create a mock object of FieldAttributeBase
    fieldattributebase = FieldAttributeBase()

    # Set some attributes
    fieldattributebase.name = 'bar'
    fieldattributebase.isa = 'foo'
    fieldattributebase.description = 'baz'
    fieldattributebase.class_type = 'buz'
    fieldattributebase.default = True
    fieldattributebase.required = True
    fieldattributebase.value = True
    fieldattributebase.always_post_validate = True
    fieldattributebase.static = True

    #get the repr of the mock object
    repr_of_fieldattributebase = fieldattributebase.dump_me()
