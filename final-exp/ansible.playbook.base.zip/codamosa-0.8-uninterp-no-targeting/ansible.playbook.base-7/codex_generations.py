

# Generated at 2022-06-21 00:12:38.393919
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    fake_loader = DictDataLoader({})

    # Initialize a FieldAttributeBase object
    base_obj = FieldAttributeBase()

    # Test with a non-template value
    ds = dict(name='foobar')
    expected = dict(name='foobar')
    result = base_obj.load_data(ds, fake_loader)
    assert result == expected, \
        "'%s' != '%s'" % (result, expected)
    
    # Test with a template value
    ds = dict(name='{{foobar}}')
    templar = Templar(loader=fake_loader)
    expected = dict(name='{{foobar}}')
    result = base_obj.load_data(ds, templar, fake_loader)
    assert result == expected, \
        "'%s' != '%s'"

# Generated at 2022-06-21 00:12:39.412285
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    n = FieldAttributeBase()
    n.deserialize(None)

# Generated at 2022-06-21 00:12:45.616497
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class TestClass(Base):
        def __init__(self):
            super(TestClass, self).__init__()

    obj = TestClass()
    repr(obj)
    assert 'TestClass' in repr(obj)
    assert obj._loader is not None
    assert obj._variable_manager is not None


# Generated at 2022-06-21 00:12:56.525810
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Set up mocked instances of the classes needed by
    # the method to be tested
    encoded_errors = sys.stdout
    templar = templar(encoded_errors=encoded_errors,
                      disable_lookups=False,
                      fail_on_undefined_errors=False,
                      environment=None,
                      loader=None,
                      shared_loader_obj=None,
                      variable_manager=None,
                      role_cache=None)


    test_instance = FieldAttributeBase()

    # The data inputs used in the tests
    name1 = 'ansible_connection'

    attribute_isa1 = 'string'
    attribute_isa2 = 'int'
    attribute_isa3 = 'float'
    attribute_isa4 = 'bool'
    attribute_isa5 = 'percent'

# Generated at 2022-06-21 00:12:57.014250
# Unit test for method get_path of class Base
def test_Base_get_path():
    pass

# Generated at 2022-06-21 00:13:09.447208
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():

    import copy
    import pytest

    # Data to be used in these unit tests

# Generated at 2022-06-21 00:13:14.819666
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    fb = FieldAttributeBase()
    assert fb.required is False, \
        "test_FieldAttributeBase: instantiation of FieldAttributeBase failed, expecting required=False, got %s" % fb.required
    assert fb.default is None, \
        "test_FieldAttributeBase: instantiation of FieldAttributeBase failed, expecting default=None, got %s" % str(fb.default)

# Generated at 2022-06-21 00:13:23.565960
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from ansible.plugins.loader import module_loader

    data = dict(
        first=dict(one=1, two=2, three=3, four=4),
        second=dict(a=1, b=2, c=3, d=4),
        third=dict(foo=1, bar=2, bam=3, baz=4),
    )

    for task_name, task_data in iteritems(data):
        task = Task.load(task_name, task_data, module_loader=module_loader, variable_manager=variable_manager)
        assert task.post_validate(templar=templar)



# Generated at 2022-06-21 00:13:25.105764
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    t = Base()
    assert t.get_dep_chain() is None


# Generated at 2022-06-21 00:13:29.164279
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():

    # set up test
    attr = FieldAttributeBase(None, None)
    attr.name = 'some_attr'


    # run test
    result = attr.preprocess_data('hello world')


    # Assertions
    assert_equal(result, 'hello world')




# Generated at 2022-06-21 00:13:54.803215
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    obj = FieldAttributeBase()
    data =  {}
    obj.deserialize(data)


# Generated at 2022-06-21 00:13:58.365099
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    args = dict()
    f_attribute_base = FieldAttributeBase(**args)
    # test the property
    if not f_attribute_base.loader:
        pytest.fail("Failed to get the property: loader")

# Generated at 2022-06-21 00:14:08.407749
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''Unit test for FieldAttributeBase.get_loader'''
    raises = False
    try:
        f = FieldAttributeBase()
        with patch.object(FieldAttributeBase, 'get_loader') as mock_get_loader:
            # Assign return value for the mocked method, get_loader
            mock_get_loader.return_value = 'Kermit'

            # Call method to test
            result = f.get_loader()

            # Ensure the expected value was returned
            assert result == 'Kermit'

            # Ensure the mocked method was called as expected
            mock_get_loader.assert_called_once_with()
    except Exception:
        # If an exception was raised during the test, indicate the test case failed
        raises = True

# Generated at 2022-06-21 00:14:16.406840
# Unit test for method get_path of class Base
def test_Base_get_path():
    class DummyDS:
        def __init__(self):
            self._data_source = '/foo/bar.yaml'
            self._line_number = 5
    class DummyParent:
        def __init__(self):
            self._play = DummyDS()

    assert Base(ds=DummyDS()).get_path() == '/foo/bar.yaml:5'
    assert Base(parent=DummyParent(), ds=None).get_path() == '/foo/bar.yaml:5'
    assert Base(parent=DummyParent(), ds=DummyDS()).get_path() == '/foo/bar.yaml:5'
    assert Base(parent=None, ds=DummyDS()).get_path() == '/foo/bar.yaml:5'



# Generated at 2022-06-21 00:14:29.381816
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class A(object):
        b = FieldAttribute(isa='int', default=5)
        def _get_attr_b(self):
            return 42

    class B(object):
        def _get_parent_attribute(self, attr_name):
            if attr_name == 'b':
                return 3
            else:
                raise AttributeError("'%s' object has no attribute '%s'" % (self.__class__.__name__, attr_name))

        c = FieldAttribute(isa='int', default=10)

    class C(B, A):
        pass

    c = C()
    # Check the class attributes
    assert hasattr(c, 'b')
    assert hasattr(c, 'c')
    assert hasattr(c, '_attributes')

# Generated at 2022-06-21 00:14:31.764164
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    fieldattributebase = FieldAttributeBase()
    assert fieldattributebase.copy() is not None, "FieldAttributeBase.copy should return a FieldAttributeBase object"
    assert fieldattributebase.copy() == fieldattributebase, "FieldAttributeBase.copy should return a FieldAttributeBase object"

# Generated at 2022-06-21 00:14:38.260875
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    C = AnsibleCollection()
    with open('../ansible_collections/ansible_collections/core/plugins/modules/core.yml') as f:
        C._data = yaml.safe_load(f)
    C.load()
    M = C.get_module('ping')
    F = M.get_plugin()
    O = F.apply_options(dict(a=1, b=2,c=3))
    assert O.dump_attrs() == dict(a=1, b=2, c=3)

# Generated at 2022-06-21 00:14:42.223093
# Unit test for method get_path of class Base
def test_Base_get_path():
    # 1. Create object
    base = Base()
    # 2. Unit test
    try:
        base.get_path()
        # 3. Assertion
        assert False
    except:
        assert True

# Generated at 2022-06-21 00:14:44.580719
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    obj = FieldAttributeBase()
    assert obj.validate(None, None) is None


# Generated at 2022-06-21 00:14:48.085609
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Unit test for method get_variable_manager of class FieldAttributeBase
    '''
    # FIXME: implement test in FieldAttributeBase



# Generated at 2022-06-21 00:15:29.607474
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    test_obj = FieldAttributeBase()
    assert test_obj


# Generated at 2022-06-21 00:15:32.586043
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    target = FieldAttributeBase()
    expected = {
        'vars': {}
    }
    actual = target.serialize()
    assert_equal(actual, expected)


# Generated at 2022-06-21 00:15:39.966919
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # Test that an error is thrown if _loader was never set
    a = FieldAttributeBase()
    try:
        loader = a.get_loader()
        assert False, "AnsibleAssertionError not raised"
    except AnsibleAssertionError:
        pass
    # Test that the _loader correctly gets returned
    a = FieldAttributeBase()
    a._loader = "foo loader"
    assert a._loader == a.get_loader()


# Generated at 2022-06-21 00:15:49.913796
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # Testing for parent class FieldAttributeBase
    exec("class DummyClass(FieldAttributeBase): pass\n")
    # Testing for object DummyClass
    DummyClass_s = DummyClass()
    DummyClass_s.__dict__ = {'_ancestors': {}, '_valid_attrs': None, '_variable_manager': None, '_loader': None, '_uuid': 'FieldAttributeBase_uuid', '_finalized': False, '_attributes': {}, '_attr_defaults': {}, '_validated': False, '_ds': None}
    assert DummyClass_s.dump_attrs() == {}
    # Testing for object DummyClass
    DummyClass_s = DummyClass()

# Generated at 2022-06-21 00:16:02.366214
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.executor.module_common import DEFAULT_COMPLEX_ARGS_KEYS

# Generated at 2022-06-21 00:16:11.870492
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    fb = FieldAttributeBase()
    fb._attributes = {'a': 'foo'}
    fb._attribute_class = FieldAttribute
    fb._validated = True
    fb._finalized = True
    fb._uuid = '123'

    fb2 = fb.copy()
    assert fb is not fb2
    assert fb._attributes == fb2._attributes
    assert fb._attribute_class == fb2._attribute_class
    assert fb._validated == fb2._validated
    assert fb._finalized == fb2._finalized
    assert fb._uuid == fb2._uuid
    assert not (hasattr(fb, '_ds') and hasattr(fb2, '_ds'))

# Generated at 2022-06-21 00:16:18.098399
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    mock_self = MagicMock()
    mock_self.name = 'foo'
    mock_self.isa = 'class'
    mock_self.class_type = MagicMock()

    base = FieldAttributeBase(mock_self)

    assert base.validate('foo', MagicMock()) is None
    assert not mock_self.class_type.validate.called


# Generated at 2022-06-21 00:16:30.478083
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    import ansible.utils.unsafe_proxy
    from ansible.vars.manager import VariableManager, HostVars
    from ansible.vars import HostVarsVars

# Generated at 2022-06-21 00:16:36.605907
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class Parent(object):
        a = FieldAttribute()
        b = FieldAttribute()
        def _get_attr_a(self):
            return self._attributes["a"]
        def _get_attr_b(self):
            return self._attributes["b"]
    class Child(Parent):
        c = FieldAttribute()
        __metaclass__ = BaseMeta
        def _get_attr_c(self):
            return self._attributes["c"]
    child = Child()
    child.a = "a_value"
    child.b = "b_value"
    child.c = "c_value"
    assert child.a == "a_value"
    assert child.b == "b_value"
    assert child.c == "c_value"


# Generated at 2022-06-21 00:16:38.392503
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    field_attributes_base = FieldAttributeBase()
    field_attributes_base.ds = ["foo"]
    assert field_attributes_base.get_ds() == ["foo"]


# Generated at 2022-06-21 00:17:43.620758
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    try:
        base.get_dep_chain()
        assert False
    except AttributeError:
        assert True

    class Base2(Base):
        pass

    base2 = Base2()
    try:
        base2.get_dep_chain()
        assert False
    except AttributeError:
        assert True

    class Play3(Base):
        def __init__(self):
            self._parent = Base()
    play3 = Play3()
    try:
        play3.get_dep_chain()
        assert False
    except AttributeError:
        assert True

    class Play4(Base):
        def __init__(self):
            self._parent = 'string'
    play4 = Play4()

# Generated at 2022-06-21 00:17:45.344069
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play import Play
    play = Play()
    play.test_base_get_dep_chain()


# Generated at 2022-06-21 00:17:51.653908
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from .play_context import PlayContext
    from .task import Task
    from .play import Play

    base = Base()
    assert base.get_dep_chain() is None

    # when this object is not a child of a task or a play, what is being returned is None
    task = Task.load(dict(name="it's a task"))
    base = Base()
    base._parent = task
    assert base.get_dep_chain() is None

    # when this is a child of a task and the parent of this object is not a play, what is being returned is None
    play = Play()
    task = Task.load(dict(name="it's a task"))
    base = Base()
    base._parent = task
    task._parent = play
    assert base.get_dep_chain() is None

    # when this is a

# Generated at 2022-06-21 00:18:03.892221
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Test(with_metaclass(BaseMeta, object)):
        attr = FieldAttribute(isa='str')
        attr2 = FieldAttribute(isa='str', default='test')

        def __init__(self):
            self._attributes['attr'] = 'test'
            self._attributes['attr2'] = 'test2'

    assert hasattr(Test, 'attr')
    assert hasattr(Test, 'attr2')
    assert not hasattr(Test, 'attr3')
    assert Test().attr == 'test'
    assert Test().attr2 == 'test2'
    test = Test()
    test.attr3 = 'test3'
    assert test.attr3 == 'test3'
    assert test._attributes['attr3'] == 'test3'

# Generated at 2022-06-21 00:18:10.172242
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    x = FieldAttributeBase()
    data = {}
    # test with no exception
    x.deserialize(data)
    with pytest.raises(AnsibleAssertionError) as excinfo:
        x.deserialize("not a dict")
    assert "not a dict" in to_text(excinfo.value)
    assert "data should be a dict but is a" in to_text(excinfo.value)
# end unit test for FieldAttributeBase_deserialize



# Generated at 2022-06-21 00:18:13.797040
# Unit test for method get_path of class Base
def test_Base_get_path():
    '''
    AnsibleBase: get_path
    '''
    base = Base()
    base._ds = AnsibleFileLoader(filename='test/test_file')
    base._ds._line_number = 2
    result = base.get_path()
    # Check result
    assert result == 'test/test_file:2'


# Generated at 2022-06-21 00:18:19.452485
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    path_stack='path_stack'
    dep_chain='dep_chain'
    role_path='role_path'
    task_dir='task_dir'
    b = Base()
    b.get_dep_chain = Mock(return_value= dep_chain)
    b.__dict__.update(dict(_role_path= role_path))
    b.get_path = Mock(return_value=task_dir)
    with patch('os.path.dirname') as mock_path:
        with patch('builtins.reversed') as mock_reversed:
            mock_path.return_value= task_dir
            mock_reversed.return_value = path_stack
            assert b.get_search_path() == path_stack

# Generated at 2022-06-21 00:18:30.789332
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    """Tests if the desired output is achieved for the given input"""

    a = FieldAttributeBase(
        name='a',
        always_post_validate=False,
        default=1,
        required=True,
        isa=int,
        static=False,
        listof=None,
        class_type=None
    )
    b = FieldAttributeBase(
        name='b',
        always_post_validate=False,
        default=True,
        required=True,
        isa='bool',
        static=False,
        listof=None,
        class_type=None
    )
    my_dict = {'a':2, 'b':'yes'}
    choice = 'option1'


# Generated at 2022-06-21 00:18:40.469163
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    serialize = FieldAttributeBase._serialize

    # Test
    assert serialize(None) is None

    # Test
    assert serialize(1) == 1

    # Test
    assert serialize(1.1) == 1.1

    # Test
    assert serialize('1.1') == '1.1'

    # Test
    assert serialize(dict(a=1)) == dict(a=1)

    # Test
    assert serialize(list()) == list()

    # Test
    assert serialize(set(['a', 'b'])) == set(['a', 'b'])


# Generated at 2022-06-21 00:18:43.613243
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    FA = object()
    class MockFieldAttributeBase(object):
        def __init__(self):
            self._loader = FA
    base = MockFieldAttributeBase()
    expected = FA

    actual = base.get_loader()

    assert actual == expected, 'FieldAttributeBase.get_loader returned %s instead of %s' % (actual, expected)