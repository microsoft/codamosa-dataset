

# Generated at 2022-06-21 00:13:07.322874
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    class TestFieldAttributeBase(unittest.TestCase):
        def test_preprocess_data(self):
            f = FieldAttributeBase('test_preprocess_data', required=True, listof=None, always_post_validate=True)
            value = f.preprocess_data(None)
            self.assertEqual(value, None, 'value != None with None')
            value = f.preprocess_data(None, 1)
            self.assertEqual(value, [1], 'value != [1] with None and 1')
            value = f.preprocess_data([1], 2)
            self.assertEqual(value, [1, 2], 'value != [1, 2] with [1] and 2')
    unittest.main()

# Generated at 2022-06-21 00:13:09.288994
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    target = FieldAttributeBase()
    assert True


# Generated at 2022-06-21 00:13:10.430195
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    assert True

# Generated at 2022-06-21 00:13:19.189955
# Unit test for method get_path of class Base
def test_Base_get_path():
    ansible.utils.plugins.module_finder.add_directory(os.path.join(os.path.dirname(__file__), '..', 'test', 'units', 'test_module_loader'))
    ds = DataLoader().load_from_file(path.join(path.dirname(__file__), '..', 'test', 'units', 'modules', 'download_mimetypes.yml'))
    ds = ds[0]
    ds._line_number = 10
    ds._data_source = "/usr/ansible/data"
    print(Base().get_path())


# Generated at 2022-06-21 00:13:21.846328
# Unit test for method get_path of class Base
def test_Base_get_path():
    from ansible.playbook.task import Task
    t = Task()
    assert t.get_path() == None
    assert t.get_search_path() == []

# Generated at 2022-06-21 00:13:30.710295
# Unit test for constructor of class Base
def test_Base():

    t = Base(None)

    assert t._name == ''
    assert t._connection == context.CLIARGS['connection']
    assert t._port is None
    assert t._remote_user == context.CLIARGS['remote_user']
    assert t._vars == {}
    assert t._module_defaults == []
    assert t._environment == []
    assert t._no_log is False
    assert t._run_once is False
    assert t._ignore_errors is False
    assert t._ignore_unreachable is False
    assert t._check_mode == context.CLIARGS['check']
    assert t._diff == context.CLIARGS['diff']
    assert t._any_errors_fatal is True
    assert t._throttle == 0
    assert t._timeout == C.TASK_TIME

# Generated at 2022-06-21 00:13:33.410563
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    set_trace()
    mod, path = get_calling_module(skip=3)
    # Test code goes here
    
    

# Generated at 2022-06-21 00:13:37.075709
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    '''
    Unit test for method copy of class FieldAttributeBase
    '''
    # No exception is raised
    assert isinstance(FieldAttributeBase.copy(), FieldAttributeBase)


# Generated at 2022-06-21 00:13:45.868617
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    from ansible.compat import to_text
    # FieldAttributeBase.dump_attrs()
    # FieldAttributeBase.dump_attrs()
    # test 1
    # Test that the vars attribute is returned as a serialized list
    # of dictionaries
    
    
    # test 2
    # The test below was causing an error on some versions of python
    # the exact versions causing errors vary based on the version of Ansible
    # used.  The error is in AttributeErrorHandler.handle_exception.
    # The _Default object is not valid for this version of python
    # just skip the test for this version.
    
    
    # test 3
    # FIXME:
    
    

    
    



# Generated at 2022-06-21 00:13:47.447054
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base.deserialize()

# Generated at 2022-06-21 00:14:17.844644
# Unit test for constructor of class Base
def test_Base():
    assert issubclass(Base, FieldAttributeBase)
    assert Base._name.name == 'name'
    assert Base._name.isa == 'string'
    assert Base._name.default == ''
    assert Base._name.always_post_validate
    assert Base._name.inherit is False
    assert Base._connection.name == 'connection'
    assert Base._connection.isa == 'string'
    assert isinstance(Base._connection.default, CallableValue)
    assert Base._connection.deprecated_aliases == ('ansible_connection',)
    assert Base._port.name == 'port'
    assert Base._port.isa == 'int'
    assert Base._port.default is None
    assert Base._remote_user.name == 'remote_user'
    assert Base._remote_user.isa == 'string'
    assert Base

# Generated at 2022-06-21 00:14:18.808654
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    pass

# Generated at 2022-06-21 00:14:31.924774
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    loader, inventory, variable_manager = _init_loader()
    task = Task()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader, play=None))
    task.post_validate(templar)

    assert task.name is None
    assert task.action is None
    assert task.async_val == 0
    assert task.async_val == 0
    assert task.poll == 0
    assert task.register == None
    assert task.ignore_errors == False
    assert task.delegate_to is None
    assert task.loop is None
    assert task.changed_when is None
    assert task.failed_when is None
    assert task.until is None
    assert task.retries == 0
    assert task.delay == 0
    assert task.first_

# Generated at 2022-06-21 00:14:41.902555
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    import __main__
    import sys
    import os

    # Setup mock module for imports
    sys.modules['__main__'] = __main__

    # Test basic execution
    data = dict()
    data['name'] = dict()
    data['name']['_loader'] = dict()
    data['name']['_loader']['_basedir'] = 'basedir'
    data['name']['_loader']['get_basedir'] = lambda *args, **kwargs: 'basedir'
    data['name']['_loader']['path_dwim'] = lambda *args, **kwargs: 'basedir'
    data['name']['_variable_manager'] = dict()
    data['name']['_variable_manager']['extra_vars'] = dict()

# Generated at 2022-06-21 00:14:45.514407
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    b = FieldAttributeBase()
    b.get_validated_value('foo','bar', 'foobar', 'helloworld')
    assert True


# Generated at 2022-06-21 00:14:56.881703
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    obj = FieldAttributeBase()
    fields_with_values = {"_valid_attrs": {'attr1': "abcd", 'attr1': "abcd"}, "_alias_attrs": {'attr2': "abcd", 'attr2': "abcd"}, "_loader": "abcd",
                          "_variable_manager": "abcd", "_validated": False, "_finalized": False, "_uuid": "abcd", "name": "abcd", "ds": "abcd"}
    obj_without_keys = {}
    for key in obj.__dict__.keys():
        obj_without_keys[key] = None
    name = "abcd"
    attribute = "abcd"
    value = "abcd"
    templar = "abcd"

# Generated at 2022-06-21 00:14:59.264619
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    # No special logic to be tested here
    pass

# Generated at 2022-06-21 00:15:07.041538
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition

    ###############################################################################
    #
    # Test case 1, task x -> task y -> task z, all belonging to different roles
    #
    ###############################################################################

    role_path_x = '/home/user/ansible/roles/role_x'
    role_path_y = '/home/user/ansible/roles/role_y'
    role_path_z = '/home/user/ansible/roles/role_z'

    playbook_dir = '/home/user/ansible/playbooks'
    playbook_path

# Generated at 2022-06-21 00:15:08.381562
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass


# Generated at 2022-06-21 00:15:19.724758
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.become_plugin import BecomePlugins
    class Role:
        def __init__(self, ansible_play_name, playbook, collection_list = [], collection_name = None, collection_help = ''):
            self._metadata = None
            self._loader = DataLoader()
            self._collection_list = collection_list
            self._collection_name = collection_name
            self._collection_help = collection_help
            self._task_cache = {}
            self._vars_cache = {}
            self._parent = None
            self._children = []

# Generated at 2022-06-21 00:15:52.712980
# Unit test for constructor of class Base
def test_Base():
    # Test constructor of Base
    test_attr = Base()

    assert test_attr._name == ''
    assert test_attr._uuid is not None
    assert test_attr._vars == {}
    assert test_attr._connection == context.cliargs_deferred_get('connection')
    assert test_attr._port is None
    assert test_attr._remote_user == context.cliargs_deferred_get('remote_user')
    assert test_attr._run_once is False
    assert test_attr._no_log is False
    assert test_attr._ignore_errors is False
    assert test_attr._ignore_unreachable is False
    assert test_attr._any_errors_fatal is C.ANY_ERRORS_FATAL

# Generated at 2022-06-21 00:16:05.236158
# Unit test for method get_ds of class FieldAttributeBase

# Generated at 2022-06-21 00:16:09.699098
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    '''
    Unit test for method from_attrs of class FieldAttributeBase
    '''
    fieldattributebase = FieldAttributeBase()
    assert fieldattributebase.from_attrs('attrs') == fieldattributebase.from_attrs('attrs')

# Generated at 2022-06-21 00:16:21.943885
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class FooParent(object):

        def bar(self):
            pass

        class Meta:
            pass

        class Field:
            pass

    class Foo(with_metaclass(BaseMeta, FooParent)):

        _field = FieldAttribute(isa='string', default='abc')
        _field2 = FieldAttribute(isa='string')
        _field3 = FieldAttribute(isa='string')
        _field3.alias = 'field_alias'
        field_alias = None

        def _get_attr_field2(self):
            return 'def'

        def _get_parent_attribute(self, attr_name):
            return 'def'

    foo = Foo()

    assert len(foo._attributes) == len(Foo._valid_attrs) == len(Foo._attr_defaults) == 3

    assert foo

# Generated at 2022-06-21 00:16:25.273146
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    f = FieldAttributeBase()
    g = VariableManager()
    f._variable_manager = g
    result = f.get_variable_manager()
    #assert result is g
    assert result == g




# Generated at 2022-06-21 00:16:31.151163
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    '''
    Unit test for method get_ds of class FieldAttributeBase
    '''
    my_object = FieldAttributeBase()
    my_object._ds = {'test': True}
    assert my_object.get_ds() == my_object._ds, 'FieldAttributeBase.get_ds returns incorrect value.'



# Generated at 2022-06-21 00:16:40.027007
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # The tests below assume that the code is a string, which is
    # not necessarily the case on all platforms.  If the tests run
    # on a platform where a string is not needed, we'll substitute
    # the platform-specific type needed, otherwise we'll use a string.
    if AI(sys.version_info) >= AI('3.0.0'):
        # Python 3 does not have the 'basestring' type
        basestring = str
    else:
        basestring = basestring
    def my_test_class(BaseObject):
        class TestClass(BaseObject):
            _valid_attrs = dict(name1=FieldAttribute(isa='string'),
                                name2=FieldAttribute(isa='string'),
                                name3=FieldAttribute(isa='string'))

# Generated at 2022-06-21 00:16:42.472108
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    import pytest

    assert FieldAttributeBase().deserialize({"foo": "bar"}) == {"foo": "bar"}

# Generated at 2022-06-21 00:16:44.952442
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    obj = FieldAttributeBase()
    ret = obj.dump_me()
    assert isinstance(ret, string_types)
    assert ret


# Generated at 2022-06-21 00:16:47.061300
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    test1 = FieldAttributeBase()
    assert test1.validate() == None

# Generated at 2022-06-21 00:17:18.594606
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
  print("Test dump_me")
  obj = FieldAttributeBase(name='name_of_obj', default='default value')
  assert obj.dump_me() == {'name': 'name_of_obj',
                           'default': 'default value'}


# Generated at 2022-06-21 00:17:22.790413
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # set up FieldAttributeBase instance
    inst = FieldAttributeBase()
    assert inst._squashed == False
    # set up args
    inherit = False
    task = '''First task'''
    # invoke squash on inst with args
    ret_val = inst.squash(inherit, task)
    # make asserts
    assert ret_val == None



# Generated at 2022-06-21 00:17:24.095392
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    base = Base()
    assert(base.get_dep_chain() is None)

# Generated at 2022-06-21 00:17:36.179632
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Parent(object):
        def __init__(self):
            self.test1 = FieldAttribute(isa='test1')
            self.test2 = FieldAttribute(isa='test2')

    class TestClass(Base):
        __metaclass__ = BaseMeta
        test1 = FieldAttribute(isa='test1')
        test3 = FieldAttribute(isa='test3')

    assert TestClass._valid_attrs == {'test1': FieldAttribute(isa='test1'), 'test2': FieldAttribute(isa='test2'), 'test3': FieldAttribute(isa='test3')}
    assert TestClass._attr_defaults == {'test1': None, 'test2': None, 'test3': None}
    assert TestClass._alias_attrs == {}
    assert hasattr(TestClass, 'test1')

# Generated at 2022-06-21 00:17:45.975119
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Create an instance of Play
    play = Play()
    
    # Create an instance of RoleDependency
    role_dependency1 = RoleDependency()
    role_dependency1._role_path = 'a'
    play._parent = role_dependency1
    
    # Create an instance of RoleDependency
    role_dependency2 = RoleDependency()
    role_dependency2._role_path = 'b'
    role_dependency1._parent = role_dependency2
    
    # Create an instance of RoleDependency
    role_dependency3 = RoleDependency()
    role_dependency3._role_path = 'c'
    role_dependency2._parent = role_dependency3
    
    play._ds._data_source = 'd'
    play._ds._line

# Generated at 2022-06-21 00:17:57.801244
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    dct = BaseMeta("test_BaseMeta___new__", ["test_BaseMeta___new__"], {"a":"b"})
    assert dct.__name__ == "test_BaseMeta___new__"
    assert dct.__bases__[0] == "test_BaseMeta___new__"
    assert dct.__dict__["a"] == "b"
    assert dct._attributes['a'] == Sentinel
    assert dct._valid_attrs['a'] == "b"
    assert dct._attr_defaults['a'] == "b"
    assert dct._alias_attrs == {}
    dct = BaseMeta("test_BaseMeta___new__", ["test1","test2","test3"], {"a":"b"})
    assert dct.__name__ == "test_BaseMeta___new__"


# Generated at 2022-06-21 00:18:00.734891
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    field_attrib = FieldAttributeBase()
    assert field_attrib.get_loader() is DataLoader()


# Generated at 2022-06-21 00:18:10.912177
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():

    # get mock object
    loader = HostVarsLoader()
    variable_manager = BaseVariableManager(loader=loader)
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # gen object
    obj = FieldAttributeBase(loader=loader, variable_manager=variable_manager)

    # test method and assert result
    with pytest.raises(Exception):
        obj.load_data({'a': '{{a}}'}, templar, False)

    with pytest.raises(Exception):
        obj.load_data({'a': 'a'}, templar, True)

    assert obj.load_data({'a': 'b'}, templar, False) == {'a': 'b'}

# Generated at 2022-06-21 00:18:12.240275
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():

    v1 = FieldAttributeBase()
    assert v1.get_variable_manager() == None


# Generated at 2022-06-21 00:18:15.102622
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    tmp = FieldAttributeBase()
    # Example of how to set the method's arguments. We need:
    # - data: in this case we can use the dict object.
    from collections import defaultdict
    data = defaultdict(lambda: defaultdict(lambda: defaultdict()))
    tmp.deserialize(data)



# Generated at 2022-06-21 00:19:52.029523
# Unit test for method get_path of class Base
def test_Base_get_path():
    import os
    import yaml
    yaml_str = '''
- hosts: localhost
  tasks:
    - name: a
      shell: echo hi
      yum: name=httpd
    - debug: var=hostvars[inventory_hostname]
      when: ansible_os_family != 'RedHat'
    - name: b
      shell: echo hi
  roles:
    - rolex
    - role
      foo=bar
      roles:
        - roley
'''
    playbook_yaml = '''
- name: test
  hosts: localhost
  gather_facts: no
  tasks:
    - include: test_Base_get_path.yaml
'''
    scripts_path = os.path.join(os.path.dirname(__file__), 'scripts')
    open

# Generated at 2022-06-21 00:19:56.122710
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    b = Base()
    assert b._base_meta__new__(type(b).__name__, type(b).__bases__, type(b).__dict__) == None



# Generated at 2022-06-21 00:20:08.746349
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    # Ensure the default ValueError is raised correctly
    with pytest.raises(ValueError):
        FieldAttributeBase()

    # Ensure the isa validation checks work correctly
    with pytest.raises(ValueError):
        FieldAttributeBase(isa='fail')

    # Save the supported types
    supported_types = FieldAttributeBase.supported_types

    # Ensure the default type works correctly
    assert FieldAttributeBase(isa='class').isa == 'class'
    assert FieldAttributeBase(isa='class').class_type == object

    # Ensure the class type validation works correctly
    with pytest.raises(TypeError):
        FieldAttributeBase(isa='class', class_type=str)
    with pytest.raises(TypeError):
        FieldAttributeBase(isa='class', class_type=object)

    # Ensure the class type works correctly
   

# Generated at 2022-06-21 00:20:11.637441
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    instance, field_attribute, name, value = (TestFieldAttributeBase(), FieldAttribute,
       'name', 'my_name')
    assert instance.copy(field_attribute, name, value) == {}


# Generated at 2022-06-21 00:20:12.542382
# Unit test for constructor of class Base
def test_Base():
    pass


# Generated at 2022-06-21 00:20:20.875108
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Create the object
    obj1 = FieldAttributeBase()
    # the "squashed" attribute should be false
    assert obj1._squashed == False
    
    obj2 = FieldAttributeBase()
    # the "squashed" attribute should be false
    assert obj2._squashed == False
    
    # Do the squash
    FieldAttributeBase.squash(obj1, obj2)

    # Test that the attribute "squashed" has been set to true
    assert obj2._squashed == True



# Generated at 2022-06-21 00:20:24.864519
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():

    from unit.mock import Mock

    m = Mock()
    m._ds = "mocked_ds"
    obj = FieldAttributeBase()

    result = obj.get_ds(m)
    assert result == "mocked_ds"

# Generated at 2022-06-21 00:20:26.417549
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # the inventory is not supported
    assert False

# Generated at 2022-06-21 00:20:28.167455
# Unit test for constructor of class Base
def test_Base():
    with pytest.raises(TypeError):
        Base()


# Generated at 2022-06-21 00:20:31.035298
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    cls = FieldAttributeBase
    obj = cls(name='name')
    data = {}
    try:
        obj.deserialize(data)
    except Exception as e:
        assert isinstance(e, AnsibleAssertionError)
        assert str(e) == 'data (%s) should be a dict but is a %s' % (data, type(data))
    else:
        fail('Exception not raised')