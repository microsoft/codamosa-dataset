

# Generated at 2022-06-21 00:12:55.414958
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    global test_Base_get_search_path

    ### Unit tests for method get_search_path of class Base begin ###
    #
    # In actual tests, the method is invoked from an object of class
    # Role or Task.  So, the class Base is invoked through an
    # indirection.  For example, it can be invoked as
    #   self._parent.get_search_path()
    #
    # To test the method independently of the class Role or Task, a
    # class SearchPathTester is defined below.  The class has a
    # constructor that accepts paths as inputs, which are then assigned
    # to the object.  It also defines an instance method _parent to
    # enable indirection.
    #
    # To invoke the method on an object of class SearchPathTester,
    # define the object with the desired input. 

# Generated at 2022-06-21 00:12:57.759709
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    attr = FieldAttributeBase()
    attr.loader = Mock()
    try:
        attr.get_loader()
    except Exception as e:
        fail('get_loader raised an exception: ' + str(e))


# Generated at 2022-06-21 00:13:01.599111
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    set_runner()
    my_obj = FieldAttributeBase()
    assert(my_obj.get_ds() == None)
    assert(my_obj.get_ds(False) == None)

# Generated at 2022-06-21 00:13:05.637747
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    #TODO fix this test
    #a = FieldAttributeBase()
    #b = a.dump_me()
    #c = to_text(b)
    pass


# Generated at 2022-06-21 00:13:16.935239
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class MockAttribute(object):
        isa = None

    # use the class to create a mock attribute object
    mock_attribute = MockAttribute()

    obj = FieldAttributeBase(1234)
    # mock a valid value
    mock_value = 1234
    assert obj.get_validated_value('mock_name', mock_attribute, mock_value, None) == 1234

    # mocking a valid value, with a string type
    mock_value = '1234'
    assert obj.get_validated_value('mock_name', mock_attribute, mock_value, None) == '1234'

    # mocking a valid value, with a number type
    mock_value = 1234
    assert obj.get_validated_value('mock_name', mock_attribute, mock_value, None) == 1234

    # mocking a

# Generated at 2022-06-21 00:13:26.505243
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    spec = dict(
        name=FieldAttribute(isa='string', default=None),
        src=FieldAttribute(isa='string', default=None),
        aType=FieldAttribute(isa='string', default=''),
        isa=FieldAttribute(isa='string', default=''),
        default=FieldAttribute(isa='string', default=''),
        static=FieldAttribute(isa='bool', default=False),
        choices=FieldAttribute(isa='list', default=[])
    )
    data = dict(
        name='name',
        src='src',
        aType='type',
        isa='isa',
        default='default',
        static=True,
        choices=['one', 'two']
    )
    fieldattribute = FieldAttributeBase(spec, data)
    fieldattribute.load_data(data)
    assert field

# Generated at 2022-06-21 00:13:27.828638
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # TODO: refactor
    pass

# Generated at 2022-06-21 00:13:29.997550
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    loader = BaseLoader()
    attribute = FieldAttributeBase("desc", loader=loader)
    assert attribute.get_loader() is loader



# Generated at 2022-06-21 00:13:34.888419
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    MyObj = make_class('MyObj', (FieldAttributeBase,), {
        'name': FieldAttribute(isa='string'),
        'foo': FieldAttribute(isa='string', default='blah')
    })

    myobj = MyObj()

    myobj.dump_attrs()

# Generated at 2022-06-21 00:13:45.273366
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute, FieldAttribute
    class A(Base):
        _foo = FieldAttribute('_foo')
        _bar = FieldAttribute('_bar', inherit=True)
        _baz = FieldAttribute('_baz', inherit=False)
        _default = FieldAttribute('_default', default='hello world')
        _alias = FieldAttribute('_alias', alias='_subalias')
        def _get_attr__foo(self):
            pass
        def _get_attr__bar(self):
            pass
    class B(A):
        _foo_b = FieldAttribute('_foo_b')
        _bar_b = FieldAttribute('_bar_b', inherit=True)

# Generated at 2022-06-21 00:14:15.584897
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    # Both the class Role() and class Play() are derived from the class Base()
    # All the interfaces of class Base() have been tested in the test classes:
    # test_Role_get_search_path()
    # test_Play_get_search_path()
    pass

    # All the interfaces of class Base() have been tested in the test classes:
    # test_Role_get_search_path()
    # test_Play_get_search_path()

    ## Notice:
    # 1. the file test_base.py: if the test_*() method is defined in the class Base()
    #    the test_*() method is defined in the class test_Base()
    # 2. the file test_role.py: if the test_*() method is defined in the class Role()
    #    the test_*() method is defined

# Generated at 2022-06-21 00:14:19.889913
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    FA = FieldAttributeBase('hi')
    c = FA.copy()
    assert FA == c
    FA = FieldAttributeBase({'x': 5}, isa='dict')
    c = FA.copy()
    assert FA == c


# Generated at 2022-06-21 00:14:32.368217
# Unit test for constructor of class Base
def test_Base():
    base = Base(sentinel.ds)
    assert base._ds == sentinel.ds
    assert base._data_source == sentinel.ds._data_source
    assert base._line_number == sentinel.ds._line_number
    assert base._name == ''
    assert base._connection == context.cliargs_deferred_get('connection')
    assert base._remote_user == context.cliargs_deferred_get('remote_user')
    assert base._vars == {}
    assert base._module_defaults == []
    assert base._environment == []
    assert base._no_log is False
    assert base._run_once is False
    assert base._ignore_errors is False
    assert base._ignore_unreachable is False
    assert base._check_mode == context.cliargs_deferred_get('check')

# Generated at 2022-06-21 00:14:36.219934
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Add code that tests the correct functioning of your class here
    # This example shows the basics of how to write a unit test
    ab = FieldAttributeBase()
    assert isinstance(ab.copy(), FieldAttributeBase)
    assert ab.copy() != ab
    # assert 'value' == 'othervalue'
    # assert 1 == 0



# Generated at 2022-06-21 00:14:48.780662
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Test with a playbook with no data source
    b = Base()
    assert b.get_path() == ":0"

    # Test with a playbook with no ds line number
    b = Base()
    b._ds = object()
    assert b.get_path() == ":0"

    # Test with a playbook with no parent
    b = Base()
    b._ds = object()
    b._ds._data_source = 'ds1'
    b._ds._line_number = 10
    assert b.get_path() == 'ds1:10'

    # Test with a playbook with no parent, ds == ''
    b = Base()
    b._ds = object()
    b._ds._data_source = ''
    b._ds._line_number = 10

# Generated at 2022-06-21 00:14:59.945785
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    fa1 = FieldAttributeBase()
    assert fa1.name is None
    assert fa1.isa is None
    assert fa1.static is False
    assert fa1.required is False
    assert fa1.default is None
    assert fa1.class_type is None
    assert fa1.metadata is None
    assert fa1.choices == []
    assert fa1.allow_duplicates is False
    assert fa1.always_post_validate is False

    fa2 = FieldAttributeBase('name',
                             isa='bool',
                             static=True,
                             required=True,
                             default=False,
                             class_type=bool,
                             metadata={},
                             choices=[True, False],
                             allow_duplicates=True,
                             always_post_validate=True)

   

# Generated at 2022-06-21 00:15:08.194898
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    # get_ds(name, value, ds)
    # Test with a valid "name" parameter to check a valid "value" parameter
    test_obj = FieldAttributeBase()
    assert test_obj.get_ds("name", "value", "ds") == "value", 'Expected: value. Actual: {0!r}.'.format(test_obj.get_ds("name", "value", "ds"))
    # Test with an invalid name parameter to check an invalid value parameter
    test_obj = FieldAttributeBase()
    assert test_obj.get_ds("", "", "ds") == "ds", 'Expected: ds. Actual: {0!r}.'.format(test_obj.get_ds("", "", "ds"))



# Generated at 2022-06-21 00:15:10.677733
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    base = Play()
    base._ds = {}
    assert base.get_ds() == {}


# Generated at 2022-06-21 00:15:21.330109
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class DummyBase(Base):
        """Base class for a test case"""
        dummy_attr_1 = FieldAttribute(isa='str', default="This is attr 1")
        dummy_attr_2 = FieldAttribute(isa='str', default="This is attr 2", inherit=True)
        dummy_attr_3 = FieldAttribute(isa='str', default="This is attr 3", inherit=False)

    class DummyClass1(DummyBase):
        """Class to test the BaseMeta metaclass"""
        dummy_attr_2 = FieldAttribute(isa='str', default="Overridden attr 2")
    class DummyClass2(DummyClass1):
        """Class to test the BaseMeta metaclass"""
        pass

    dummy_obj = DummyClass2()

# Generated at 2022-06-21 00:15:23.471487
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    # FIXME: This test is not written well
    pa = FieldAttributeBase()
    assert pa.get_loader() == None


# Generated at 2022-06-21 00:16:17.618440
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import pytest
    assert BaseMeta.__new__('BaseMeta', 'parents', 'dct') == 'BaseMeta.__new__(BaseMeta, parents, dct)'

# Generated at 2022-06-21 00:16:20.254084
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert isinstance(b, Base)
    assert b._name == ''
    assert b._vars == {}

# Generated at 2022-06-21 00:16:30.785340
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    import datetime

    class A(object):
        class_field = FieldAttribute(isa="class")

    # Test normal flow
    x = A()
    assert x.class_field is None
    x.from_attrs({'class_field': datetime.datetime})
    assert x.class_field == datetime.datetime

    # Test data is not a dict
    x = A()
    assert x.class_field is None
    try:
        x.from_attrs('data')
        assert False, "data is not a dict"
    except AssertionError as e:
        raise e
    except Exception as e:
        assert True


# Class FieldAttribute

# Generated at 2022-06-21 00:16:39.841584
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    hosts = ['host1', 'host2']
    myPlay = Play().load({'hosts': hosts, 'name': 'my_play'})
    myTask = Task().load({'name': 'my_task'})
    myPlay.add_task(myTask)
    myTask._parent = myPlay
    myTask._ds = myPlay._ds = DataLoader()
    myPlay._role = myRole = Role()
    myPlay._role._path = 'my_role_path'
    myPlay._role._roles_path = 'my_roles_path'
    myPlay._play = myPlay
    myRole._parent = myPlay
    myRole._play = myPlay
    myRole._ds = myPlay._ds
    dep_chain = myTask.get_dep_chain()

# Generated at 2022-06-21 00:16:51.456996
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    class_name = 'FieldAttributeBase'
    class_obj = FieldAttributeBase
    args_spec = {
        'class_name': class_name,
        'class_obj': class_obj,
        'args': None,
        'kwargs': {}
    }
    test_case_strs = {
        0: 'ok',
        1: 'fail',
    }
    args = args_spec['args']
    kwargs = args_spec['kwargs']
    test_class = class_obj(*args, **kwargs)

# Generated at 2022-06-21 00:16:59.916088
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    attr = FieldAttributeBase()

    assert attr.isa == 'string'
    assert attr.default is None
    assert attr.always_post_validate is False
    assert attr.static is False
    assert attr.required is False

    attr.isa = 'int'
    attr.default = 'foo'
    attr.required = True
    attr.always_post_validate = True
    attr.static = True

    assert attr.isa == 'int'
    assert attr.default == 'foo'
    assert attr.required is True
    assert attr.always_post_validate is True
    assert attr.static is True



# Generated at 2022-06-21 00:17:01.214731
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    assert False # TODO: implement your test here


# Generated at 2022-06-21 00:17:13.173811
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestMeta(object):
        __metaclass__ = BaseMeta
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

        foo = FieldAttribute(isa='bool', default='bar')
    test = TestMeta()
    assert test.foo is True
    assert test._attributes['foo'] is True
    assert test._valid_attrs['foo'].default is 'bar'
    assert test._attr_defaults['foo'] is 'bar'
    assert test._alias_attrs == {}

    class TestMeta(object):
        __metaclass__ = BaseMeta
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self

# Generated at 2022-06-21 00:17:15.044065
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    FA = FieldAttributeBase()
    assert FA.dump_me() == {}

# Generated at 2022-06-21 00:17:17.385568
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    fieldattributebase = FieldAttributeBase()
    assert isinstance(fieldattributebase.get_variable_manager(), AnsibleVariableManager)


# Generated at 2022-06-21 00:18:11.107493
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    class TestParent(object):
        def get_dep_chain(self):
            return []
    class TestRole(object):
        def __init__(self, _play):
            self._play = _play
    class TestDS(object):
        def __init__(self, data_source, line_number):
            self._data_source = data_source
            self._line_number = line_number
    parent = TestParent()
    role = TestRole(None)
    ds = TestDS('/tmp/test.yml', 1)
    base = Base(ds, parent)

    # check without any parent
    assert base.get_dep_chain() is None

    # check with _parent with parent
    base._parent = parent
    assert base.get_dep_chain() == []

    base._parent._play = role

# Generated at 2022-06-21 00:18:11.957203
# Unit test for method get_path of class Base
def test_Base_get_path():
   pass


# Generated at 2022-06-21 00:18:17.241505
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    t = AnsibleBaseYAMLObject()

    try:
        t.FieldAttributeBase('foo', bool, FieldAttributeBase.CONFIG)
        raise AssertionError('Expected a TypeError')
    except TypeError:
        pass

    try:
        t.FieldAttributeBase('foo', None)
        raise AssertionError('Expected a TypeError')
    except TypeError:
        pass

    t.FieldAttributeBase('foo', string_types)


# Generated at 2022-06-21 00:18:29.354766
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    host = MagicMock()
    host.name = 'myhost'
    host.get_variable.return_value = False
    loader = MagicMock()
    templar = Templar(loader=loader, variables={'inventory_hostname': 'myhost'})
    task = Task()
    task._variable_manager = MagicMock()
    task._variable_manager.get_vars.return_value = dict()
    task._host = host
    task._host.get_vars.return_value = dict()
    task._variable_manager.extra_vars = dict()
    
    attr = FieldAttributeBase(is_sub_attr=False)
    attribute = attr.preprocess_data(templar, task, 'some_val')
    assert attribute == 'some_val'




# Generated at 2022-06-21 00:18:42.250722
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    dict_data = dict(
        key_1='value_1',
        key_2='value_2',
        key_3='value_3',
        key_4='value_4'
    )
    list_data = [
        'key_6',
        'value_6',
        'key_7',
        'value_7',
        'key_8',
        'value_8',
        'key_9',
        'value_9',
    ]
    string_data = 'key_10=value_10 key_11=value_11 key_12=value_12 key_13=value_13'
    for test_data in [dict_data, list_data, string_data]:
        pd = FieldAttributeBase.preprocess_data(test_data)

# Generated at 2022-06-21 00:18:53.453985
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    from ansible import context
    from collections import namedtuple
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, module_loader, module_utils_loader, test_loader, vars_loader
    from ansible.utils.plugin_docs import get_docstring
    #StringIO = context._clean_module('StringIO')
    #ModuleDocFragment = context._clean_module('ModuleDocFragment')
    #argparse = context._clean_module('argparse')
    #docutils = context._clean_module('docutils')
    #nose = context._clean_module('nose')
    options = context.CLIARGS._get_args()

# Generated at 2022-06-21 00:18:59.785229
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    self = FieldAttributeBase('name', default=None, required=True)
    self._validated = True
    data = {}
    with pytest.raises(AnsibleAssertionError) as e:
        self.deserialize(data)
    with pytest.raises(AnsibleAssertionError) as e:
        self.deserialize(data)

# Generated at 2022-06-21 00:19:06.519282
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    config = dict(
        something = 'foo',
    )
    b = FieldAttributeBase( FieldAttribute('something', 'The thing', True, 'str', {}) )
    b.something = 'bar'

    assert b.get_ds() == 'foo'

    c = FieldAttributeBase( FieldAttribute('something', 'The thing', False, 'str', {}) )
    assert c.get_ds() is None



# Generated at 2022-06-21 00:19:14.970476
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    '''
    Ensure FieldAttributeBase.validate does what we expect
    '''
    # FIXME: Add tests for FieldAttributeBase.validate
    # Unit test for method validate_container of class FieldAttributeBase
    def test_FieldAttributeBase_validate_container():

        def should_not_raise():
            class Foo(object):
                def __init__(self):
                    self.x = 10
                    self.y = 20

            class Bar(Foo):
                def __init__(self):
                    super(Bar, self).__init__()
                    self.z = 30

            class Baz(Foo):
                def __init__(self):
                    self.z = 40


# Generated at 2022-06-21 00:19:15.605782
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    pass

# Generated at 2022-06-21 00:20:22.055333
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    # test field with default
    value = 'default'
    default = 'default'
    attribute = FieldAttributeBase(default=default)
    assert attribute.load_data(value) == value
    assert attribute.load_data(None) == default

    # test field with no default
    attribute = FieldAttributeBase(default=None)
    assert attribute.load_data(value) == value
    assert attribute.load_data(None) == None


# Generated at 2022-06-21 00:20:24.593443
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    obj = FieldAttributeBase()

    ds = {}
    result = obj.preprocess_data(ds)
    assert result is None


# Generated at 2022-06-21 00:20:36.407196
# Unit test for method get_dep_chain of class Base

# Generated at 2022-06-21 00:20:38.404984
# Unit test for constructor of class Base
def test_Base():

    base_obj = Base()
    for key in base_obj.__dict__:
        if not key.startswith('_'):
            raise Exception("'%s' field of Base class should not be public" % key)


# Generated at 2022-06-21 00:20:46.782728
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from collections import namedtuple
    from ansible import module_common
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    playbook = namedtuple('FakeBook', ['vars'])
    playbook.vars = {
        'inventory_dir': '/usr/share/ansible/inventories',
        'playbook_dir': '/etc/ansible'
    }
    play=Play()
    play_ds = namedtuple('FakeDS', ['_line_number'])
    play_ds._line_number=99
    play._ds = play_ds
    play._playbook = playbook
    task=Task()
    task._parent = play
    task._ds

# Generated at 2022-06-21 00:20:48.709867
# Unit test for constructor of class Base
def test_Base():

    # Empty constructor
    b = Base()
    assert b.module_defaults == []


# Generated at 2022-06-21 00:20:49.967989
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    obj = FieldAttributeBase()
    assert obj.dump_attrs() == {}

# Generated at 2022-06-21 00:21:01.589647
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    # Set up mock objects
    FieldAttributeBase.__init__ = MagicMock(return_value=None)
    FieldAttributeBase._validated = MagicMock(return_value=None)
    FieldAttributeBase._finalized = MagicMock(return_value=None)
    FieldAttributeBase._squashed = MagicMock(return_value=None)
    FieldAttributeBase._loader = MagicMock(return_value=None)
    FieldAttributeBase._variable_manager = MagicMock(return_value=None)
    FieldAttributeBase.get_ds = MagicMock(return_value=None)
    FieldAttributeBase._valid_attrs = {'mock': MagicMock(return_value=None)}
    FieldAttributeBase.dump_attrs = MagicMock(return_value=None)
    FieldAttributeBase._uuid = MagicM

# Generated at 2022-06-21 00:21:10.061080
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    raise SkipTest()  # FIXME
    from ansible.playbook.attribute import Attribute, FieldAttribute
    # test the basic types
    for val in ['test', '', '1test', 'test1', '_test', 'TEST']:
        fa = FieldAttribute(isa='string', default=val)
        assert fa.deserialize(val) == val
    for val in [True, False]:
        fa = FieldAttribute(isa='bool', default=val)
        assert fa.deserialize(val) == val
    for val in [1, 1.0]:
        fa = FieldAttribute(isa='int', default=val)
        assert fa.deserialize(val) == val
    # test a type
    val = True
    fa = FieldAttribute(isa=bool, default=val)
    assert fa.deserialize

# Generated at 2022-06-21 00:21:12.041975
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():

    FieldAttributeBase(kwargs='Testing')
