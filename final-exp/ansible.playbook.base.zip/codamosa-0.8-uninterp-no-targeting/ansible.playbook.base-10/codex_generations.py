

# Generated at 2022-06-21 00:12:47.018778
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    task = Task()
    task2 = Task()
    assert task.post_validate() == task2.post_validate()



# Generated at 2022-06-21 00:12:49.906380
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FA = FieldAttributeBase(isa="test")
    foo = FA.validate("foo")
    assert foo is not None


# Generated at 2022-06-21 00:12:54.258583
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    # Testing with both types of vars
    for vars in [dict(), struct()]:
        obj1 = FieldAttributeBase()
        obj1.vars = vars
        value = obj1.squash()
        assert value == vars, "Expected vars got: %s" % (value,)



# Generated at 2022-06-21 00:13:01.657204
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Unit test for method get_loader of class FieldAttributeBase
    '''
    # Setups
    test_loader = DictDataLoader({
        "test_action.yml": """
              name: test_action
              action: test_action
              my_attr: 'test_attr'
        """,
    })
    test_file = test_loader.path_dwim('test_action.yml')
    ansible_loader = DataLoader()

    # Tests
    res1 = FieldAttributeBase.get_loader(None)
    res2 = FieldAttributeBase.get_loader(ansible_loader)
    res3 = FieldAttributeBase.get_loader(test_loader)
    res4 = FieldAttributeBase.get_loader(test_file)
    assert res1 == ansible_loader
    assert res2

# Generated at 2022-06-21 00:13:05.292522
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
  d = Data()
  d.variable_manager = 'dummy_variable_manager'
  assert d.get_variable_manager() == 'dummy_variable_manager'

# Generated at 2022-06-21 00:13:08.573643
# Unit test for constructor of class Base
def test_Base():
    base = Base()
    assert base.name == ''
    assert base.connection == 'local'
    assert base.vars == {}
    assert base.become == False


# Generated at 2022-06-21 00:13:09.269476
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    pass

# Generated at 2022-06-21 00:13:19.988488
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    # noinspection PyUnusedLocal
    @patch.object(FieldAttributeBase, '__init__', return_value=None)
    @patch.object(FieldAttributeBase, '__attrs__', new_callable=PropertyMock)
    @patch.object(FieldAttributeBase, '__name__', new_callable=PropertyMock)
    @patch.object(FieldAttributeBase, '__additional_fields__', new_callable=PropertyMock)
    def test_01(mocked_init, mocked___attrs__, mocked___name__, mocked___additional_fields__):

        mocked_init.return_value = None
        mocked___additional_fields__.return_value = None
        mocked___attrs__.return_value = None
        mocked___name__.return_value = None

        # test
        test

# Generated at 2022-06-21 00:13:22.719539
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    Unittest to ensure code is working as expected
    '''

    fa = FieldAttribute(isa='list', default=list())



# Generated at 2022-06-21 00:13:29.584491
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class TestBaseMeta(Base):
        attr1 = FieldAttribute(isa='str', default='test1')
        attr2 = FieldAttribute(isa='str', default='test2')

    class Test2BaseMeta(TestBaseMeta):
        attr3 = FieldAttribute(isa='str', default='test3')

    assert Test2BaseMeta.attr1.default == 'test1'
    assert Test2BaseMeta.attr2.default == 'test2'
    assert Test2BaseMeta.attr3.default == 'test3'
    assert hasattr(Test2BaseMeta, 'attr1')
    assert hasattr(Test2BaseMeta, 'attr2')
    assert hasattr(Test2BaseMeta, 'attr3')
    assert 'attr1' in Test2BaseMeta._valid_attrs
    assert 'attr2' in Test2BaseMeta

# Generated at 2022-06-21 00:13:53.483096
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Test get_variable_manager on FieldAttributeBase
    '''
    assert True

# Generated at 2022-06-21 00:14:02.081955
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    f = FieldAttributeBase()
    assert not f.static and not f.required and f.default is None

    f = FieldAttributeBase(static=True)
    assert f.static and not f.required and f.default is None

    f = FieldAttributeBase(always_post_validate=True)
    assert not f.static and not f.required and f.default is None and f.always_post_validate

    f = FieldAttributeBase(required=True, static=True, default=['a', 'b'])
    assert not f.always_post_validate and f.required and f.static and f.default == ['a', 'b']


# Generated at 2022-06-21 00:14:12.301428
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Ensure FieldAttributeBase.get_variable_manager() works.
    '''
    import mock
    import os
    import tempfile
    import textwrap

    # Setup the test data
    temp_path = tempfile.mkdtemp()
    playbook_path = os.path.join(temp_path, 'test.yml')
    with open(playbook_path, 'wt') as f:
        f.write(textwrap.dedent(
            '''
            ---
            - hosts: localhost
              gather_facts: false
              tasks:
                - debug: msg="Hello, World!"
            '''
        ))

    # This is the default value of the fake
    fake_loader = mock.Mock()
    fake_loader.path_dwim.return_value = playbook_path

    # This is

# Generated at 2022-06-21 00:14:16.198776
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = {'a': 1, 'b': 2}
    result = FieldAttributeBase.preprocess_data(data)
    assert result == {'a': FieldAttribute('a', 1), 'b': FieldAttribute('b', 2)}


# Generated at 2022-06-21 00:14:21.474261
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():

    # Initializing arguments
    attribute_name = None
    loader = None

    # Setup arguments for the method call
    attribute_name = 'foo'

    # Constructing the method call
    call = FieldAttributeBase.get_loader(attribute_name, loader)

    # Testing the method call
    assert call is None

# Generated at 2022-06-21 00:14:33.640152
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    """
    FieldAttributeBase.from_attrs

    Replay a task from an attrs dict
    """

    # Extracted from tests/integration/targets/test_async.py
    # Ansible-2.10.1
    # Tested via test_tasks() in test_async
    # Tested via test_tasks_regression() in test_async
    # Tested via test_async_handlers() in test_async
    # Tested via test_async_meta() in test_async
    # Tested via test_async_post_task() in test_async

    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.loader import tasks_loader


    # FIXME: from_attrs fails to set self._finalized = True
    #

# Generated at 2022-06-21 00:14:34.522132
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
	# FIXME
	pass

# Generated at 2022-06-21 00:14:42.710553
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from tower_cli.models import base


    class Base(base.Base):
        foo = 'bar'
        baz = 23
        cub = AnsibleVaultEncryptedUnicode('vault-vault-vault')

    assert Base.serialize() == {'baz': 23, 'foo': 'bar', 'cub': '', 'uuid': '', 'finalized': False, 'squashed': False}


# Generated at 2022-06-21 00:14:55.071114
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    '''
    Unit test for FieldAttributeBase.load_data
    '''

    p = Mock()
    p._attributes = {}
    p._loader = None
    p._finalized = False
    p._uuid = None
    p._variable_manager = None
    p.get_ds = Mock()

    # Fail case no.1:
    # ValueError: invalid literal for int() with base 10: ''
    p.vars = {}
    attr = Mock()
    attr._validate_value = Mock(return_value=None)
    attr._set_fail_if_no_value = Mock(return_value=None)
    attr._get_attr_default = Mock(return_value=None)
    attr._validate_attr_type = Mock(return_value=None)
    attr

# Generated at 2022-06-21 00:15:04.544715
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    base = FieldAttributeBase()
    assert isinstance(base, FieldAttributeBase)
    assert base.default == None
    assert base.class_type == None
    assert base.isa == 'str'
    assert base.required == False
    assert base.static == False
    assert base.aliases == []
    assert base.listof is None
    assert base.always_post_validate == False
    assert base.private == False

    ba = FieldAttributeBase(
        default='new_def',
        class_type='classtype',
        isa='isa',
        required=True,
        static=True,
        aliases=['a', 'b'],
        listof='lo',
        always_post_validate=True,
        private=True,
    )

    assert isinstance(ba, FieldAttributeBase)


# Generated at 2022-06-21 00:15:59.359966
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    '''
    Unit test for method get_validated_value of class FieldAttributeBase
    '''
    argument_spec = {}
    argument_spec['attribute'] = dict()
    argument_spec['value'] = dict()
    argument_spec['templar'] = dict()

    fake_field_attribute_base = FieldAttributeBase()

    # Get the facts
    expected_dict = { 'value': "string", 'attribute': {'name': 'string', 'isa': 'string'} , 'templar': {'variables': {}, 'template_vars': {}} }

    # Call method
    result = fake_field_attribute_base.get_validated_value('string', fake_field_attribute_base.attribute , 'string', fake_field_attribute_base.templar)

    # Check the results
    assert result

# Generated at 2022-06-21 00:16:07.432060
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # create an instance of the object, and set some initial hello attrs
    mobj = FieldAttributeBase()
    mobj.set_initial_attributes(hello='world')
    # test some other types of objects
    mobj.set_initial_attributes(hello='5')
    assert mobj.hello == 5

    test_str = '''{'hello': '{{foo}}'}'''
    mobj.set_initial_attributes(hello=test_str)
    assert mobj.hello == test_str


# Generated at 2022-06-21 00:16:11.335731
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Foo(object):
        __metaclass__ = BaseMeta

        bar = FieldAttribute()

    f = Foo()
    f.bar = 'test'
    assert f.bar == 'test'
    assert f._attributes['bar'] == 'test'
    assert f._valid_attrs['bar'].default is None



# Generated at 2022-06-21 00:16:16.051984
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    fld_attr_b = FieldAttributeBase()
    assert fld_attr_b.preprocess_data(data=None) is None
    assert fld_attr_b.preprocess_data(data={"foo": "bar"}) == {"foo": "bar"}


# Generated at 2022-06-21 00:16:28.711551
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase('name', 'test')
    # Check with empty defaults and empty data
    assert obj.load_data({}) is None
    # Check with empty defaults and data
    obj.default = {}
    obj.value = {}
    assert obj.load_data({'foo': 'bar', 'fie': 1}) == {'foo': 'bar', 'fie': 1}
    assert obj.value == {'foo': 'bar', 'fie': 1}
    # Check with defaults and empty data
    obj.default = {'baz': 'baz', 'buz': 2}
    obj.value = {}
    assert obj.load_data({}) == {'baz': 'baz', 'buz': 2}
    assert obj.value == {'baz': 'baz', 'buz': 2}
   

# Generated at 2022-06-21 00:16:38.580922
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    from ansible.utils.vars import combine_vars

    # Setup some valid attributes for a Task
    FIELDS = Task.FIELDS = FieldAttributeBase()
    FIELDS.register_field('action', FieldAttribute(isa='class', class_type=ActionBase))
    FIELDS.register_field('ignore_errors', FieldAttribute(isa='boolean', default=False, always_post_validate=True))
    FIELDS.register_field('when', FieldAttribute(isa='list', listof=string_types, default=[]))
    FIELDS.register_field('async_val', FieldAttribute(isa='int', default=0, always_post_validate=True))

# Generated at 2022-06-21 00:16:40.306454
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    test__from_attrs = FieldAttributeBase()
    assert test__from_attrs.from_attrs() == None, 'The assertion failed'


# Generated at 2022-06-21 00:16:42.884034
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    FieldAttributeBase.squash(any_old_object, any_old_object, any_old_object, any_old_object)


# Generated at 2022-06-21 00:16:54.537776
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    field_attribute_base = FieldAttributeBase(
        name='name',
        default=None,
        doc=None,
        isa=None,
        data_type=None,
        include=None, # path to a file to include in the docstring
        private=False, # whether this is a private or public attribute
        constant=False, # whether this is a constant attribute
        always_post_validate=False, # whether post_validate is always called after validation
        required=False, # whether this is a required attribute
        listof=None, # list of objects this attribute should be
        class_type=None, # which class_type is this attribute
        static=False, # whether this value is static or templated
        version_added=None, # the version this was added in
    )
    task = AnsibleTask()
   

# Generated at 2022-06-21 00:16:56.197841
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    assert_raises(TypeError, FieldAttributeBase)


# Generated at 2022-06-21 00:17:33.868722
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    #
    # Create a test fixture
    #
    attr = FieldAttributeBase('test', FieldAttributeBase.STRING, 'test', 'test')

    #
    # Execute the method to be tested
    #
    result = attr.serialize()

    #
    # Check the results
    #
    assert result == {'default': 'test', 'isa': 'string', 'name': 'test', 'required': True, 'static': False}, \
        'Expected different result: %s' % result


# Generated at 2022-06-21 00:17:44.337528
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    loader = DictDataLoader({
        "_data": {
            "tasks": [
                {
                    "include_tasks": {
                        "yaml_value": "tasks/other.yml"
                    },
                    "name": "Include File",
                    "tags": [
                        "include_tasks"
                    ]
                }
            ]
        },
        "_basedir": "/tmp",
        "playbooks": [
            {
                "filename": "/tmp/play1.yml",
                "hosts": [
                    "localhost"
                ]
            }
        ]
    })

# Generated at 2022-06-21 00:17:55.384297
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    base = Base()
    def test_get_search_path_inner(base, path_stack, is_included):
        # assert get_search_path's behavior
        assert base.get_search_path() == path_stack, "get_search_path %s should give %s, but gives %s" % (base.get_path(), path_stack, base.get_search_path())
        assert base.path_included_in_search_path() == is_included, "get_search_path %s should give %s, but gives %s" % ("path_included_in_search_path", is_included, base.path_included_in_search_path())

# Generated at 2022-06-21 00:18:07.533176
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():

    # Imports needed to set up the test objects
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext

    # generate a global fake loader for this test
    loader = DictDataLoader({})

    # generate a fake variable manager for this test
    variable_manager = VariableManager()

    # generate a fake base object for this test
    base_obj = AnsibleBaseYAMLObject()

    # generate fake args for this test
    args = [0, 1, 2, 3]

    # generate a fake delegate_to for this test
    delegate_to = None

    # generate a fake name for this test
    name = None

    # generate a fake play_context for this test

# Generated at 2022-06-21 00:18:15.108369
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    class Base1(object):
        x = FieldAttribute(isa='string')
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

    class Base2(object):
        y = FieldAttribute(isa='string')
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs = {}

    class Base3(Base1, Base2):
        z = FieldAttribute(isa='string')
        def __init__(self):
            self._attributes = {}
            self._attr_defaults = {}
            self._valid_attrs = {}
            self._alias_attrs

# Generated at 2022-06-21 00:18:16.089441
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    assert True == True

# Generated at 2022-06-21 00:18:23.475687
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    from ansible.module_utils.six import with_metaclass
    class M(with_metaclass(BaseMeta)):
        a = Attribute(default=Sentinel)
    assert hasattr(M, 'a')
    assert not hasattr(M, 'b')
    assert M._attributes['a'] is Sentinel



# Generated at 2022-06-21 00:18:32.347556
# Unit test for constructor of class Base
def test_Base():
    # Test case 1: Check if the default values are correctly assigned
    b1 = Base()
    assert b1._name == ''
    assert b1._connection == 'smart'
    assert b1._port is None
    assert b1._remote_user == C.DEFAULT_REMOTE_USER
    assert b1._vars == {}
    assert b1._module_defaults == []
    assert b1._environment is None
    assert b1._no_log is False
    assert b1._run_once is False
    assert b1._ignore_errors is False
    assert b1._ignore_unreachable is False
    assert b1._check_mode is False
    assert b1._diff is False
    assert b1._any_errors_fatal is C.ANY_ERRORS_FATAL
    assert b1._throttle == 0

# Generated at 2022-06-21 00:18:37.297217
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    var = 'some string'
    myarg = FieldAttributeBase(isa='str', default=None, validator=lambda x: True if isinstance(x, string_types) else False)
    myarg.validate(var)


# Generated at 2022-06-21 00:18:44.568137
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    data = dict(a_b_c='asdf', b_c_d='jkl;')
    attrbase = FieldAttributeBase()

    attrbase.deserialize(data)

    assert attrbase._attributes['a_b_c'] == 'asdf'
    assert attrbase._attributes['b_c_d'] == 'jkl;'

# Generated at 2022-06-21 00:19:13.138001
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    r1 = FieldAttributeBase()
    args = (1, 2, 3)
    r2 = r1.preprocess_data(*args)

    assert (r1.args == args)
    assert (r2 == args)


# Generated at 2022-06-21 00:19:15.553575
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    FieldAttributeBase._valid_attrs = {}
    f = FieldAttributeBase()
    assert isinstance(f, FieldAttributeBase)
    assert f == FieldAttributeBase()


# Generated at 2022-06-21 00:19:18.781237
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    C = FieldAttributeBase()
    # Be sure to test all types of data, not just a list.
    # Correct data will be a list.
    assert C.load_data(["A", "B"]) == ["A", "B"]

# Generated at 2022-06-21 00:19:25.929646
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    yield(
        u'_valid_attrs: {}',
        {'_valid_attrs': {}},
        '_valid_attrs: {}'
    )
    yield(
        u'_valid_attrs: {a_int: <ansible.parsing.yaml.objects.FieldAttribute object at 0x7f5ba0d8e208>}',
        {'_valid_attrs': {'a_int': FieldAttribute('a_int', 'int', True, None)}},
        '_valid_attrs: a_int: auto'
    )

# Generated at 2022-06-21 00:19:36.027389
# Unit test for method get_validated_value of class FieldAttributeBase
def test_FieldAttributeBase_get_validated_value():
    # Create test class
    class TestClass(object):
        class_attr = FieldAttributeBase(isa='string', default=None)
        def __init__(self, *args, **kwargs):
            pass
    
    test_class = TestClass()
    
    # Create attribute object
    fake_attribute = FieldAttributeBase(isa='string', default=None)
    fake_attribute.isa = 'bool'
    
    # Run tests
    try:
        test_class.get_validated_value('test_attr', fake_attribute, True, None)
        assert True
    except TypeError:
        assert False
    
    try:
        test_class.get_validated_value('test_attr', fake_attribute, 'a string value', None)
        assert False
    except TypeError:
        assert True
    


# Generated at 2022-06-21 00:19:46.499446
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    base = FieldAttributeBase('name', 'description', default=None, always_post_validate=True, always_run=True, required=False, static=True, isa=None, supports_check_mode=True, require_if=None, context=None)
    attrs = base.dump_attrs()
    assert attrs['default'] == None, attrs['default']
    assert attrs['always_post_validate'] == True, attrs['always_post_validate']
    assert attrs['always_run'] == True, attrs['always_run']
    assert attrs['required'] == False, attrs['required']
    assert attrs['static'] == True, attrs['static']
    assert attrs['isa'] == None, attrs['isa']
    assert attrs['supports_check_mode'] == True

# Generated at 2022-06-21 00:19:48.919987
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    fieldattributebase_obj = FieldAttributeBase()
    assert fieldattributebase_obj.dump_attrs() == {}



# Generated at 2022-06-21 00:19:55.873727
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    '''
    This is a very simple test to verify that the constructor
    for class FieldAttributeBase will not raise
    exceptions. The attributes are required and have
    default values.
    '''
    f1 = FieldAttributeBase('name')
    f2 = FieldAttributeBase('name', False)
    f3 = FieldAttributeBase('name', False, True)
    f4 = FieldAttributeBase('name', False, True, None)
    f5 = FieldAttributeBase('name', False, True, None, None)
    f6 = FieldAttributeBase('name', False, True, None, None, None)
    f7 = FieldAttributeBase('name', False, True, None, None, None, None)
    f8 = FieldAttributeBase('name', False, True, None, None, None, None, None)

# Generated at 2022-06-21 00:20:00.564466
# Unit test for constructor of class Base
def test_Base():
    b = Base()
    assert b._always_post_validate is True
    assert b._name == ''
    assert b._connection == 'local'
    assert b._remote_user is None
    assert b._vars == {}
    assert b._become is False


# Generated at 2022-06-21 00:20:02.347413
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    field = FieldAttributeBase()
    assert field.validate() is None


# Generated at 2022-06-21 00:20:33.681409
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    pass

# Generated at 2022-06-21 00:20:37.831823
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    class TestClass(Base):
        _valid_attrs = frozenset()
    test_object = TestClass()
    expected_result = None
    result = test_object.get_loader()
    assert type(result) == type(expected_result)

# Generated at 2022-06-21 00:20:44.453644
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    # Initialize the object
    obj = FieldAttributeBase()

    #Test without loading the dict
    testobj = obj.get_variable_manager()
    assert testobj is obj._variable_manager

    # Load the dict with some data
    obj._variable_manager = {
        'key1': 1,
        'key2': 2,
        'key3': 3
    }

    #Test with loading the dict
    testobj = obj.get_variable_manager()
    assert testobj is obj._variable_manager


# Generated at 2022-06-21 00:20:46.766679
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    obj = FieldAttributeBase()
    assert not obj.preprocess_data(None, None, None, None)



# Generated at 2022-06-21 00:20:48.709133
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Test to return the variable manager reference
    '''
    pass  # TODO


# Generated at 2022-06-21 00:21:00.539658
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    attribute = FieldAttributeBase()
    attribute.loader = _load_list_of_blocks(attribute)
    attribute.loader = _load_name(attribute)
    attribute.loader = _load_boolean(attribute)
    attribute.loader = _load_string(attribute)
    attribute.loader = _load_is_new_str(attribute)
    attribute.loader = _load_is_new_list(attribute)
    attribute.loader = _load_is_task_action(attribute)
    attribute.loader = _load_is_task_args(attribute)
    attribute.loader = _load_list_of_strings(attribute)
    attribute.loader = _load_attributes(attribute)
    attribute.loader = _load_block_list(attribute)
    attribute.loader = _load_is_role_name(attribute)

# Generated at 2022-06-21 00:21:09.408673
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    ti = TaskInclude.load(dict(name='foo', tasks='bar', when='yes'))
    ti.post_validate(DictTemplate({}))
    # Make sure the attribute for name is read-only.
    try:
        ti.from_attrs(dict(name='bar'))
        assert False, 'Should fail to set read-only attribute.'
    except ValueError:
        pass
    # Make sure we can set other attributes.
    ti.from_attrs(dict(tasks='bar', when='yes'))
    assert ti.tasks == ['bar']
    assert ti.when == True
    # Make sure the vars field works.
    vars = dict(a=1)
    ti = TaskInclude.load(dict(name='foo', vars=vars))
    ti.post_valid

# Generated at 2022-06-21 00:21:10.116965
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
  pass

# Generated at 2022-06-21 00:21:21.995326
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class ParentClass(object):
        attr_a = FieldAttribute(isa='bar')
        attr_b = FieldAttribute(isa='baz')
        attr_c = FieldAttribute(isa='baz')

    class TestClass(with_metaclass(BaseMeta, object)):
        attr_b = FieldAttribute(isa='baz')
        attr_c = FieldAttribute(isa='baz')
        attr_d = FieldAttribute(isa='baz')

    assert hasattr(TestClass, 'attr_a')
    assert hasattr(TestClass, 'attr_b')
    assert hasattr(TestClass, 'attr_c')
    assert hasattr(TestClass, 'attr_d')
    assert hasattr(TestClass, '_attributes')

# Generated at 2022-06-21 00:21:27.010394
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    field_attribute_base_instance = FieldAttributeBase('hosts', 'hosts', required=True, default=Sentinel, serialize_when_none=False)
    assert field_attribute_base_instance.preprocess_data is None, "Expected:<None>, Actual:<%s>" % field_attribute_base_instance.preprocess_data