

# Generated at 2022-06-21 00:12:23.226618
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    attr = FieldAttribute()
    attr.name = 'test'
    with pytest.raises(AnsibleParserError) as execinfo:
        attr.squash(None)
    assert 'squash() must be implemented by FieldAttribute' in to_text(execinfo.value)


# Generated at 2022-06-21 00:12:25.665807
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    assert Base().get_dep_chain() == None



# Generated at 2022-06-21 00:12:27.116219
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    f = FieldAttributeBase()
    f.from_attrs({})

# Generated at 2022-06-21 00:12:30.734664
# Unit test for method get_path of class Base
def test_Base_get_path():
    b = Base()
    b._ds = object()
    b._ds._line_number = 2
    b._ds._data_source = 'test'
    assert b.get_path() == 'test:2'


# Generated at 2022-06-21 00:12:38.489989
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    import inspect
    import os
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    def __init__(self, loader, variable_manager, host_list):
      super(Host, self).__init__()
      self.variable

# Generated at 2022-06-21 00:12:39.740187
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
    f = FieldAttributeBase()
    assert f.get_ds() is None


# Generated at 2022-06-21 00:12:52.742540
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # Test constructor
    t = FieldAttributeBase()
    if t.required or t.always_post_validate or t.from_prompt or t.from_ansible_vars \
            or t.from_yaml or t.static or t.label or t.choices or t.required_if \
            or t.deprecated_if or t.required_one_of or t.conflicts or t.removed:
        raise AssertionError('FieldAttributeBase.__init__ not initialized properly')

    # Test all_attributes_set which is a static method

# Generated at 2022-06-21 00:12:55.210446
# Unit test for constructor of class Base
def test_Base():
    #check the constructor
    b = Base()
    # FIXME: implement this



# Generated at 2022-06-21 00:12:56.697838
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    a = FieldAttributeBase()
    b = a.get_variable_manager()
    assert isinstance(b, VariableManager)



# Generated at 2022-06-21 00:12:57.970318
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    a = FieldAttributeBase()
    b = a.get_loader()

# Generated at 2022-06-21 00:13:44.064392
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    data = {
        'name': 'first/second/third',
        '_finalized': True,
        '_squashed': True
    }

    class ATestFieldAttribute(FieldAttributeBase):
        def __init__(self):
            self.fields = {
                'name': FieldAttribute(isa='str', default=None),
                '_finalized': FieldAttribute(isa='bool', default=False),
                '_squashed': FieldAttribute(isa='bool', default=False),
                '_uuid': FieldAttribute(isa='str', default=None)
            }
            super(ATestFieldAttribute, self).__init__()
        def set_foodata(self):
            self.foo = 100

    a = ATestFieldAttribute()
    a.from_attrs(data)

# Generated at 2022-06-21 00:13:47.602723
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # test constructor with no argument
    FieldAttributeBase()

    # test constructor with invalid argument
    def test():
        FieldAttributeBase('meow')
    assert_raises(AnsibleAssertionError, test)

    # test constructor with correct argument
    FieldAttributeBase('foo')


# Generated at 2022-06-21 00:13:53.205096
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    from pprint import pprint
    obj = FieldAttributeBase('name', static=True)
    ds = 'ds'

    # TODO: unittest
    obj.preprocess_data(ds)


# Generated at 2022-06-21 00:14:03.396738
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    q = FieldAttributeBase()
    q.setattr = FieldAttributeBase.setattr.im_func
    q.getattr = FieldAttributeBase.getattr.im_func
    q._valid_attrs = FieldAttributeBase._valid_attrs
    q._finalized = False
    q.post_validate = FieldAttributeBase.post_validate.im_func
    q.serialize = FieldAttributeBase.serialize.im_func
    q.deserialize = FieldAttributeBase.deserialize.im_func
    q.uuid = FieldAttributeBase.uuid.fget.im_func
    q.uuid.fset = FieldAttributeBase.uuid.fset.im_func
    q.uuid.fdel = FieldAttributeBase.uuid.fdel.im_func

    assert q.dump_attrs()

# Generated at 2022-06-21 00:14:13.361190
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class Foo(object):
        pass

    # valid FieldAttributeBase constructor
    try:
        attr = FieldAttributeBase(isa='str')
    except Exception as e:
        assert False, "Exception: {}".format(e)

    # invalid FieldAttributeBase constructor
    with pytest.raises(TypeError) as e:
        attr = FieldAttributeBase()
    assert "needs isa" in to_native(e.value)

    # unknown isa
    with pytest.raises(TypeError) as e:
        attr = FieldAttributeBase(isa="bar")
    assert "bar is not supported" in to_native(e.value)

    # Boolean type, with string value
    attr = FieldAttributeBase(isa='bool')

# Generated at 2022-06-21 00:14:24.693088
# Unit test for method get_path of class Base
def test_Base_get_path():
    config = _ConfigParser()
    config._parse_options()
    config._parse_configs()
    config._post_validate_conf()
    config.load_extra_plugins()
    config.populate_inventory()
    config.populate_hostvars()
    config.populate_playbook()
    config.populate_basedirs()
    config.populate_basedirs()
    config.init_dep_chain()
    config.init_ds()

    base_obj = Base(ds=config._ds, dep_chain=config.dep_chain, name='test_base')
    base_obj.validate()
    print(base_obj.get_path())



# Generated at 2022-06-21 00:14:27.711912
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    with pytest.raises(Exception):
        base_obj = FieldAttributeBase()
        attrs = base_obj.dump_attrs()


# Generated at 2022-06-21 00:14:28.844342
# Unit test for constructor of class Base
def test_Base():
    base = Base()


# Generated at 2022-06-21 00:14:38.260568
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    class TestClass(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    test_attr = TestClass(field_name='test')
    test_obj = TestClass(data=None, field_name='data')
    test_class = FieldAttributeBase()
    test_module_name, test_class_name = 'test_module', 'TestClass'
    test_class.load_data(test_obj, test_attr, test_module_name, test_class_name)
    assert test_attr == test_obj.data
    assert test_obj.module_name == test_module_name
    assert test_obj.class_name == test_class_name


# Generated at 2022-06-21 00:14:45.573708
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = {'foo': 'bar'}
    bare = FieldAttributeBase()
    field = FieldAttribute(default='baz')
    bare.from_attrs(data)
    field.from_attrs(data)
    assert getattr(bare, 'foo') == 'bar'
    assert getattr(field, 'foo') == 'bar'


# Generated at 2022-06-21 00:15:24.289019
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    import tempfile
    test_dir = tempfile.mkdtemp()

    my_field = 'test_field'
    my_file = os.path.join(test_dir, 'test.txt')
    with open(my_file, 'wb') as f:
        f.write(b'SOMEDATA')
    data = my_file
    vars = dict()
    field = FieldAttributeBase()
    field._loader = DictDataLoader({})

    # These are the conditions we want to test for
    # Replace this list with a set of dicts, where the dicts contain
    # the data we want to pass in, and the expected result.

# Generated at 2022-06-21 00:15:25.611088
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    field = FieldAttributeBase()
    assert field.dump_attrs() == {}


# Generated at 2022-06-21 00:15:27.560539
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    fail = False
    try:
        dump_me()
    except TypeError as e:
        fail = True

    assert fail, "Test dump_me() function with no argument has Failed"



# Generated at 2022-06-21 00:15:30.699825
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    t = Task()
    t.deserialize({'action': 'test_object'})
    assert getattr(t, 'action') == 'test_object'

# Generated at 2022-06-21 00:15:42.581070
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():
    # Initialize AnsibleModule module_args dict
    module_args=dict()
    module_args['name'] = 'value'
    module_args['path'] = '/path/to/file'
    module_args['other'] = 'foo'
    module_args['hosts'] = 'me'
    module_args['omit'] = '127.0.0.1'
    module_args['diff'] = False
    module_args['force'] = True
    module_args['config_file'] = "/path/to/ansible.cfg"
    module_args['verbosity'] = 9

    import ansible.module_utils.basic

# Generated at 2022-06-21 00:15:45.871349
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    field_attribute_base = FieldAttributeBase()
    field_attribute_base._variable_manager = 'ABC'
    assert field_attribute_base.get_variable_manager() == 'ABC'


# Generated at 2022-06-21 00:15:49.237184
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
  ansible_module = AnsibleModule(argument_spec=dict())
  FieldAttributeBase = FieldAttributeBase()
  # FIXME: Maybe Mock complex type here?
  data = ''
  FieldAttributeBase.deserialize(ansible_module, data)
# End of Unit test

# Generated at 2022-06-21 00:16:01.458280
# Unit test for method squash of class FieldAttributeBase
def test_FieldAttributeBase_squash():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    # instantiate the class object we are testing
    o = FieldAttributeBase(make_attribs_from_dict(dict(name='attribute',
        help='some documentation',
        required=True,
        priority=1000,
        private=False,
        static=False,
        always_post_validate=False
        )))

    # test the basic structure and elements of the object
    assert isinstance(o, FieldAttribute)
    assert isinstance(o.name, string_types)


# Generated at 2022-06-21 00:16:02.934984
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    class_to_test = FieldAttributeBase
    test_instance = class_to_test('test_attribute_name')
    assert test_instance.attribute_name == 'test_attribute_name'


# Generated at 2022-06-21 00:16:07.420597
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    # Create an instance of FieldAttributeBase
    f = FieldAttributeBase()
    # Gather arguments for method preprocess_data
    ds = 'foo'
    # Execute the code to be tested
    result = f.preprocess_data(ds)
    # Verify the result
    assert result == ds


# Generated at 2022-06-21 00:16:40.586599
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    # Dumps all attributes to a dictionary

    # Create an instance of class FieldAttributeBase
    obj = FieldAttributeBase()

    # Attempt to call method dump_attrs and check if it fails
    try:
        result = obj.dump_attrs()

    # Check if AttributeError is raised and access attribute _valid_attrs
    except AttributeError as e:
        assert re.search(r"_valid_attrs", str(e))
    else:
        assert False

# Generated at 2022-06-21 00:16:53.490781
# Unit test for method from_attrs of class FieldAttributeBase
def test_FieldAttributeBase_from_attrs():
    fake_loader = DictDataLoader({
        "test_playbook.yaml": """
        ---
        - hosts: all
          gather_facts: no
        """,
    })
    fake_inventory = InventoryManager(loader=fake_loader, sources="test_inventory")

    playbook = Playbook.load(fake_loader.path_dwim("test_playbook.yaml"), variable_manager=VariableManager(loader=fake_loader, inventory=fake_inventory), loader=fake_loader, options=Options())
    test_host = Host(name="testhost")
    test_host.set_variable("ansible_user", "nobody")
    test_host.set_variable("ansible_password", "123")

    test_task = Task()
    test_task.name = "Test task"
    test_task.action

# Generated at 2022-06-21 00:17:01.698394
# Unit test for method get_dep_chain of class Base
def test_Base_get_dep_chain():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    block = Block()
    play = Play()
    block._parent = play
    handler = Handler()
    handler._parent = play
    task = Task()
    task._parent = block
    task2 = Task()
    task2._parent = handler
    role_dep = RoleDependency()
    role_dep._parent = task2
    play_context = PlayContext()
    role_dep._play_context = play_context


# Generated at 2022-06-21 00:17:07.059831
# Unit test for method get_variable_manager of class FieldAttributeBase
def test_FieldAttributeBase_get_variable_manager():
    '''
    Test for method get_variable_manager of class FieldAttributeBase
    '''
    attr = FieldAttributeBase()
    vm = VariableManager()
    attr.set_variable_manager(vm)
    vm_from_attr = attr.get_variable_manager()
    assert vm_from_attr == vm


# Generated at 2022-06-21 00:17:09.069226
# Unit test for method load_data of class FieldAttributeBase
def test_FieldAttributeBase_load_data():
    obj = FieldAttributeBase()
    assert not obj.load_data()


# Generated at 2022-06-21 00:17:18.317050
# Unit test for method get_loader of class FieldAttributeBase
def test_FieldAttributeBase_get_loader():
    '''
    Test method get_loader of class FieldAttributeBase
    '''
    attr = FieldAttributeBase()
    attr.loader = None
    try:
        assert attr.get_loader() == None
    except AssertionError as e:
        print('Expected {}, but got {}.'.format(None, attr.get_loader()))
    attr.loader = 'foo'
    try:
        assert attr.get_loader() == 'foo'
    except AssertionError as e:
        print('Expected {}, but got {}.'.format('foo', attr.get_loader()))

# Generated at 2022-06-21 00:17:25.373364
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():

    # Test basic constructor
    a = FieldAttributeBase('a')
    assert a.name == 'a'
    assert a.required is False
    assert a.default is None
    assert a.private is False
    assert a.aliases == []

    # Test constructor with all keyword arguments
    a = FieldAttributeBase('a', required=True, default='b', private=True, aliases=('c', 'd'))
    assert a.name == 'a'
    assert a.required is True
    assert a.default == 'b'
    assert a.private is True
    assert a.aliases == ['c', 'd']

    # Test constructor with deprecated keyword arguments
    with pytest.raises(AnsibleDeprecationWarning):
        a = FieldAttributeBase('a', default='b', omit=True)


# Generated at 2022-06-21 00:17:32.235319
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    '''
    Unit test for method post_validate of class FieldAttributeBase
    '''
    # create object without calling __init__
    obj = FieldAttributeBase()
    # Default values for parameters
    attr = None
    value = None
    templar = None

    # unit test
    assert isinstance(obj.post_validate(attr, value, templar), NotImplementedError)

# Generated at 2022-06-21 00:17:33.344073
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    FieldAttributeBase.preprocess_data()

# Generated at 2022-06-21 00:17:35.800788
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    instance = FieldAttributeBase()
    assert isinstance(instance, FieldAttributeBase) == True


# Generated at 2022-06-21 00:18:14.121917
# Unit test for method __new__ of class BaseMeta
def test_BaseMeta___new__():
    class base(object):
        __metaclass__ = BaseMeta

    class foo(base):
        _test = Attribute()

    assert foo().test == None

    class bar(foo):
        pass

    assert bar().test == None

    class baz(bar):
        _test = Attribute(default='foo')

    assert baz().test == 'foo'

    class qux(baz):
        pass

    assert qux().test == 'foo'

    class quux(qux):
        _test = Attribute(default='bar')

    assert quux().test == 'bar'



# Generated at 2022-06-21 00:18:19.670682
# Unit test for constructor of class BaseMeta
def test_BaseMeta():
    # Create a class B with one attribute 'x' and one method 'show_x'.
    class B(object):
        def show_x(self):
            return self.x
    B.x = FieldAttribute(isa='str', doc='test')

    # Create a class A with one attribute 'y' and one method 'show_y'.
    class A(object):
        def show_y(self):
            return self.y
    A.y = FieldAttribute(isa='str', doc='test')

    # Create a class C which is derived from A and B.
    # Create a class D which is derived from C and Base.
    class C(A, B):
        pass

    class D(C, Base):
        pass

    # Check that show_y and show_x can be called on an object of class D.

# Generated at 2022-06-21 00:18:26.027694
# Unit test for method copy of class FieldAttributeBase
def test_FieldAttributeBase_copy():

    # Setup test data
    field_attribute_base_instance = FieldAttributeBase()

    # Invoke method
    result = field_attribute_base_instance.copy()

    # Verify expected result
    assert isinstance(result, FieldAttributeBase)
    assert result == field_attribute_base_instance
    assert result is not field_attribute_base_instance




# Generated at 2022-06-21 00:18:33.743337
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    FieldAttributeBase._valid_attrs = \
        {'name': FieldAttribute(isa='string', required=True, default='', encoded=False),
         'task': FieldAttribute(isa='string', required=False, default='', encoded=False),
         'owner': FieldAttribute(isa='string', required=False, default='', encoded=False)}

    obj = FieldAttributeBase()
    result = obj.deserialize({'task': 'task'})
    assert(result == None)

    attr = FieldAttributeBase._valid_attrs['task']
    assert(attr.default == '')
    assert(obj.task == 'task')

    attr = FieldAttributeBase._valid_attrs['owner']
    assert(attr.default == '')
    assert(obj.owner == '')


# Generated at 2022-06-21 00:18:35.968598
# Unit test for method get_path of class Base
def test_Base_get_path():
    # Test case 1
    assert Base().get_path() == ""

# Generated at 2022-06-21 00:18:46.754787
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    data = Mock()
    templar = Mock()

    test_obj = FieldAttributeBase()

    # call the method we're testing
    result = test_obj.preprocess_data(data, templar)
    assert result == data

    # additionally test that things work as expected if
    # templar.is_template is true
    templar.is_template = lambda x: True
    result = test_obj.preprocess_data(data, templar)
    assert result == data

    # make sure we error on non-string types
    templar.is_template = lambda x: False
    with pytest.raises(AnsibleParserError):
        test_obj.preprocess_data(2, templar)



# Generated at 2022-06-21 00:18:50.518604
# Unit test for method serialize of class FieldAttributeBase
def test_FieldAttributeBase_serialize():
    example_object = FieldAttributeBase(default=None)

    serialized = example_object.serialize()
    assert serialized == {
        "default": None,
        "aliases": [],
        "required": False
    }


# Generated at 2022-06-21 00:18:57.105519
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    import pytest
    from ansiblelint.rules import RulesCollection
    from ansiblelint.runner import Runner

    rulesdir = 'test/twiggy-rules'
    rules = RulesCollection.create_from_directory(rulesdir)
    runner = Runner(rules, None, [], [], [])
    task = {
        "include_tasks": "tasks/main.yml"
    }
    from ansiblelint.rules.FromTaskIncludeRule import FromTaskIncludeRule
    tester = FromTaskIncludeRule(runner)
    tester.task = task
    tester.from_task_include()
    assert tester.results == []


# Generated at 2022-06-21 00:18:58.538603
# Unit test for method validate of class FieldAttributeBase
def test_FieldAttributeBase_validate():
    FieldAttributeBase()



# Generated at 2022-06-21 00:19:09.293796
# Unit test for constructor of class FieldAttributeBase
def test_FieldAttributeBase():
    # Check that field has proper attributes
    field = FieldAttributeBase()
    assert isinstance(field, FieldAttributeBase)
    assert not field.required
    assert not field.static
    assert not field.choices
    assert field.default == None
    assert field.class_type == None
    assert field.listof == None
    assert field.always_post_validate == False
    assert field.class_type == None
    assert field.isa == None

    # Modifying attributes of field should throw exception, since this class
    # is not supposed to be modified
    with pytest.raises(AnsibleAssertionError) as excinfo:
        field.required = True
    assert "failed to modify required" in to_text(excinfo.value)


# Generated at 2022-06-21 00:20:27.933117
# Unit test for method deserialize of class FieldAttributeBase
def test_FieldAttributeBase_deserialize():
    def test_args(data):
        with pytest.raises(AnsibleAssertionError) as excinfo:
            class MyClass(object):
                field_my_field = FieldAttribute('my_field', required=True)
                my_field = 'abc'
                obj = FieldAttributeBase()
                obj.deserialize(data)
        assert to_text(excinfo.value) == 'data (False) should be a dict but is a <type \'bool\'>'

    for arg in [False, True]:
        yield test_args, arg

# Generated at 2022-06-21 00:20:39.832549
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    from ansible.plugins.loader import get_all_plugin_loaders
    import os.path
    import sys
    import builtins
    import mock


    # Return a Mock object which can be used as a function
    def mock_func(*args, **kwargs):
        return mock.Mock()

    # Placeholder for real method

# Generated at 2022-06-21 00:20:50.537703
# Unit test for method post_validate of class FieldAttributeBase
def test_FieldAttributeBase_post_validate():
    my_object = {}
    my_object['_AnsibleContainer_post_validate_overrides'] = {}
    my_object['_AnsibleContainer_post_validate_overrides']['vars'] = {'ansible_python_interpreter': '/usr/bin/python'}
    my_object['_AnsibleContainer_valid_attrs'] = {}
    my_object['_AnsibleContainer_valid_attrs']['foo'] = {'required': True, 'always_post_validate': True, 'isa': 'string'}
    my_object['_AnsibleContainer_valid_attrs']['foo']['default'] = None

# Generated at 2022-06-21 00:20:52.133925
# Unit test for method dump_me of class FieldAttributeBase
def test_FieldAttributeBase_dump_me():
    field = FieldAttributeBase()
    field.dump_me()


# Generated at 2022-06-21 00:20:54.889733
# Unit test for method preprocess_data of class FieldAttributeBase
def test_FieldAttributeBase_preprocess_data():
    result = FieldAttributeBase.preprocess_data('name', dict(foo=dict(bar='baz')))
    assert result is None

# Generated at 2022-06-21 00:21:06.010867
# Unit test for method dump_attrs of class FieldAttributeBase
def test_FieldAttributeBase_dump_attrs():
    p = Play()
    p.name = 'name'
    p.vars = {'name': 'name'}
    p.vars_prompt = {'name': 'name'}
    p.vars_files = ['name']
    p.tasks = [Task()]
    p.handlers = [Handler()]
    p.pre_tasks = [Task()]
    p.post_tasks = [Task()]
    p.roles = [Role()]
    p.dependencies = ['name']
    p.defaults = {'name': 'name'}
    p.no_log = False
    p.serialize()
    p.deserialize({'name': 'name'})
    p.post_validate('templar')
    p.get_variable_manager()
   

# Generated at 2022-06-21 00:21:17.743890
# Unit test for method get_search_path of class Base
def test_Base_get_search_path():
    class TestClass(Base):
        _name = FieldAttribute(isa='string', default='', always_post_validate=True, inherit=False)
    tc = TestClass()
    #tc._ds=object()
    #tc._ds._data_source='test file'
    #tc._ds._line_number=1
    #tc._parent=object
    #tc._parent._play=object
    #tc._parent._play._ds=object
    #tc._parent._play._ds._data_source='test file'
    #tc._parent._play._ds._line_number=2
    #tc._parent._role=object()
    #tc._parent._role._role_path='test role path'
    search_path = tc.get_search_path()
    assert search_path == []



# Generated at 2022-06-21 00:21:28.814578
# Unit test for method get_ds of class FieldAttributeBase
def test_FieldAttributeBase_get_ds():
  '''
  Unit test for method get_ds of class FieldAttributeBase
  '''
  import collections
  import jinja2
  import sys
  import yaml
  import unittest

  from ansible.utils.unsafe_proxy import AnsibleUnsafeText

  test_data_directory = os.path.join(os.path.dirname(__file__), 'test_data')

  # load in data
  attr_data = open(os.path.join(test_data_directory, 'attr_data.yaml'), 'r').read()
  attr_data_from_yaml = yaml.load(attr_data, Loader=yaml.SafeLoader)

  # create objects from data