

# Generated at 2022-06-24 11:32:00.736473
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    args = ["https://www.youtube.com/watch?v=2QKg5SZ_35I"]
    fd.params['format'] = 'bestvideo+bestaudio'
    fd._do_download(args)
    assert True
test_FileDownloader_slow_down()


# Generated at 2022-06-24 11:32:03.830695
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader({})
    assert fd.to_screen(None) == None
    assert fd.to_screen('Test') == None
    
    

# Generated at 2022-06-24 11:32:12.951948
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00:00'
    assert FileDownloader.format_seconds(1) == '0:00:01'
    assert FileDownloader.format_seconds(2) == '0:00:02'
    assert FileDownloader.format_seconds(59) == '0:00:59'
    assert FileDownloader.format_seconds(60) == '0:01:00'
    assert FileDownloader.format_seconds(61) == '0:01:01'
    assert FileDownloader.format_seconds(3599) == '0:59:59'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format

# Generated at 2022-06-24 11:32:22.103025
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    dl = FileDownloader({})
    extcalls_args_list = []
    extcalls_kwargs_list = []

    def extcalls(arg1, arg2, kwarg1=None, kwarg2=None):
        extcalls_args_list.append((arg1, arg2))
        extcalls_kwargs_list.append((kwarg1, kwarg2))

    dl.add_progress_hook(extcalls)
    assert extcalls_args_list == []
    assert extcalls_kwargs_list == []

    dl._hook_progress({'foo': 'bar'})
    assert extcalls_args_list == [({'foo': 'bar'},)]
    assert extcalls_kwargs_list == [({},)]



# Generated at 2022-06-24 11:32:25.379138
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    f = FileDownloader(DummyYDL(), {'noprogress': True})
    f.to_screen = lambda *x: None
    f.report_unable_to_resume()
    assert True

# Generated at 2022-06-24 11:32:26.734021
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader()
    fd.to_stderr('test')

# Generated at 2022-06-24 11:32:38.473628
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    class FileDownloader_tester(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
        def report_error(self, *args, **kargs):
            assert False
        def report_warning(self, *args, **kargs):
            assert False
    params = {
        'continuedl': True,
    }
    def reset_file(filename):
        with open(encodeFilename(filename), 'wb') as f:
            f.write(b'Test')
    def check_file(filename, str):
        with open(encodeFilename(filename), 'rb') as f:
            assert f.read() == str

    fd = FileDownloader_tester(params)
    reset_file('test')
    fd.try_rename

# Generated at 2022-06-24 11:32:43.363024
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    # Test the method with given values
    fd = FileDownloader({})
    assert fd.calc_percent(2786,1028) == 27
    assert fd.calc_percent(23,12) == 0
    assert fd.calc_percent(30,0) == 0
    assert fd.calc_percent(234,300) == 78
    assert fd.calc_percent(94,56) == 60
    

# Generated at 2022-06-24 11:32:53.498258
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    fd = FileDownloader()
    fd.trouble('foo is unable to download videos')
    fd.trouble('foo is unable to download videos', 'more details')
    fd.trouble('foo is unable to download videos', None, 'https://repo.org')
    fd.trouble('foo is unable to download videos', 'more details', 'https://repo.org')
    fd.trouble('foo is unable to download videos', 'more details', 'https://repo.org', 'upgrade foo')
    fd.trouble('foo is unable to download videos', 'more details', 'https://repo.org', 'upgrade foo', 'on the line: %s' % 1)

test_FileDownloader_trouble()

 

# Generated at 2022-06-24 11:33:01.100396
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    ydl = FileDownloader({})
    class MyHook:
        def __init__(self):
            self.report = {
                'myhook': [],
            }
        def __call__(self, status):
            assert 'filename' in status, 'status dict must contain filename'
            assert 'status' in status, 'status dict must contain status'
            assert isinstance(status['filename'], str), 'filename must be str'
            assert isinstance(status['status'], str), 'status must be str'
            assert status['status'] in ('downloaded', 'finished'), 'status must be downloaded or finished'
            self.report['myhook'] += [(status['filename'], status['status'])]


# Generated at 2022-06-24 11:33:11.822708
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from .utils import DateRange

    # Create a FileDownloader object
    fd = FileDownloader({})
    fd.params['ratelimit'] = '2K'
    
    start_time = 0
    for i in range(0, 6):
        fd.slow_down(start_time, start_time + 0.01 * i, i * 1000)
        time.sleep(0.1)

    # Speed should be 1K/s and sleep time should be 0
    fd.slow_down(start_time, start_time + 0.1, 1)

    # Speed should be 1K/s and sleep time should be 0
    fd.slow_down(start_time, start_time + 0.5, 1)

    # Speed should be 2K/s and sleep time should be 0.5 (seconds)
   

# Generated at 2022-06-24 11:33:15.193426
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({}, {})
    assert fd.undo_temp_name('a.part') == 'a'
    assert fd.undo_temp_name('a.part.part') == 'a.part'
    assert fd.undo_temp_name('a') == 'a'

# Generated at 2022-06-24 11:33:21.827450
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    """
    Method report_file_already_downloaded returns the message
    that the file has already been downloaded when a file exists
    """
    try:
        os.mkdir("test_dir")
        path = "test_dir/test_file"
        f = open(path, "w")
        f.close()
        downloader = FileDownloader(downloader_options_default, "test_dir")
        assert downloader.report_file_already_downloaded("test_file")
        assert downloader.report_file_already_downloaded(path)
    finally:
        os.remove(path)
        os.removedirs("test_dir")


# Generated at 2022-06-24 11:33:31.427216
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    d = FileDownloader(YoutubeDL(params={}), {'url': 'http://localhost/'})
    d.to_screen = lambda s: s
    prev = None
    assert d.format_percent(0.0) == '0.0%'
    assert d.format_percent(0.1234) == '12.3%'
    assert d.format_percent(1.0) == '100.0%'
    assert d.format_percent(1.00001) == '>100%'
    assert d.format_eta(0) == '0:00'
    assert d.format_eta(1) == '0:01'

# Generated at 2022-06-24 11:33:41.594283
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Test with default value of infinite retries
    fd = FileDownloader(None)
    assert fd.format_retries(float('inf')) == 'inf'

    # Test with default value of 10 retries
    fd = FileDownloader(None)
    assert fd.format_retries(10) == '10'

    # Test with default value of 0 retries
    fd = FileDownloader(None)
    assert fd.format_retries(0) == '0'

if __name__ == '__main__':
    from youtube_dl.YoutubeDL import YoutubeDL
    test_FileDownloader_format_retries()
    fd = FileDownloader(YoutubeDL({}), {})
    fd.add_progress_hook(lambda s: print(s))
    fd.report_

# Generated at 2022-06-24 11:33:43.879951
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    assert (FileDownloader.report_error(None, 'message')) == 'message'



# Generated at 2022-06-24 11:33:54.697580
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 4
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 8
    assert fd.best_block_size(0, 7) == 8
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-24 11:34:04.359060
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    """
    Test format_speed method of FileDownloader class.
    """
    # Test format_speed method for FileDownloader class
    assert FileDownloader.format_speed(0) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(1) == '%10s' % '1.00b/s'
    assert FileDownloader.format_speed(10) == '%10s' % '10.0b/s'
    assert FileDownloader.format_speed(100) == '%10s' % '100b/s'
    assert FileDownloader.format_speed(1024) == '%10s' % '1.00KiB/s'

# Generated at 2022-06-24 11:34:13.321496
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    from io import StringIO as base_StringIO
    class StringIO (base_StringIO):
        def getvalue(self):
            return base_StringIO.getvalue(self).replace(os.linesep, '\n')
    # Test FileDownloader.to_stderr(message=None, skip_eol=False)
    out_stream = StringIO()
    ydl = YoutubeDL({'outtmpl': 'test.%(ext)s', 'verbose': True})
    ydl.to_screen = lambda x, y=0: print(x, file=out_stream, end='')
    ydl.to_stderr('Test 1')
    assert out_stream.getvalue() == '[debug] Test 1\n', 'Test 1 failed: ' + repr(out_stream.getvalue())
    out_

# Generated at 2022-06-24 11:34:23.089496
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader(None)
    assert fd.format_percent(1) == '  1.0%'
    assert fd.format_percent(1.2) == '  1.2%'
    assert fd.format_percent(1.23) == '  1.2%'
    assert fd.format_percent(1.234) == '  1.2%'
    assert fd.format_percent(1.2345) == '  1.2%'
    assert fd.format_percent(12.345) == ' 12.3%'
    assert fd.format_percent(123.45) == '123.5%'
    assert fd.format_percent(1234.5) == '1234.5%'


# Generated at 2022-06-24 11:34:27.156284
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader(None)
    assert fd.format_speed(10) == '%10s' % '10.0b/s'
    assert fd.format_speed(5000) == '%10s' % '4.8Kb/s'
    assert fd.format_speed(2000000) == '%10s' % '1.9Mb/s'
    assert fd.format_speed(2000000000) == '%10s' % '1.9Gb/s'



# Generated at 2022-06-24 11:34:33.674543
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    from youtube_dl.YoutubeDL import YoutubeDL
    youtube_dl = YoutubeDL(FileDownloader.params)
    # Test the case where err is an error 'string'
    file_downloader = FileDownloader(youtube_dl, {})
    file_downloader.report_retry(
        'Error 522', count=5, retries=float('inf'))
    # Test the case where err is an Exception object
    file_downloader = FileDownloader(youtube_dl, {})
    file_downloader.report_retry(
        IOError('Error 522'), count=5, retries=float('inf'))



# Generated at 2022-06-24 11:34:41.141791
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader()
    if compat_os_name == 'nt':
        fd.to_console_title('t')
        import ctypes
        title = ctypes.create_unicode_buffer(1024)
        ctypes.windll.kernel32.GetConsoleTitleW(ctypes.byref(title), len(title)-1)
        assert 't' in title.value



# Generated at 2022-06-24 11:34:49.741144
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({'nooverwrites': True}, None)
    with open(os.path.join(os.path.dirname(__file__), 'unicode_filename_test'), 'w') as f:
        f.write('foobar')

    try:
        assert(fd.report_file_already_downloaded('unicode_filename_test') == True)
        assert(fd.report_file_already_downloaded(u'unicode_filename_test') == True)
    finally:
        os.remove(os.path.join(os.path.dirname(__file__), 'unicode_filename_test'))

    fd = FileDownloader({'nooverwrites': True, 'continuedl': True, 'nopart': True}, None)

# Generated at 2022-06-24 11:34:53.482760
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    ydl = YoutubeDL()
    ydl.to_screen = lambda *args, **kwargs: None
    fd = FileDownloader(ydl, {})
    fd.to_screen = lambda *args, **kwargs: print(args[0])
    fd.report_retry(None, 1, 2)
    fd.report_retry(None, 1, float('inf'))
    fd.report_retry('blah blah blah', 1, 2)


# Generated at 2022-06-24 11:35:01.994056
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    test_case = [
        ('abc.mp4', 'abc.mp4'),
        ('abc.mp4.part', 'abc.mp4'),
        ('path/to/abc.mp4', 'path/to/abc.mp4'),
        ('path/to/abc.mp4.part', 'path/to/abc.mp4'),
        ('abc.part', 'abc.part'),
        ('path/to/abc.part', 'path/to/abc.part'),
    ]
    print('Testing undo_temp_name of FileDownloader ...')
    for i in range(len(test_case)):
        if (FileDownloader.undo_temp_name(test_case[i][0]) == test_case[i][1]):
            print('Case %d passed!' %i)

# Generated at 2022-06-24 11:35:06.473684
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, params={'ratelimit': 100})
    for i in range(100, 0, -10):
        # download speed is 200 bytes/second
        fd.slow_down(start_time=time.time()-0.1, now=None, byte_counter=200)
        assert fd._sleep_time == i
        assert fd.params['ratelimit'] == 100


# Generated at 2022-06-24 11:35:15.109776
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def _test(start, now, current, total, expected_eta):
        assert FileDownloader.calc_eta(start, now, current, total) == expected_eta

    _test(0, 0, 0, 0, None)  # Impossible values
    _test(0, 0, 1, 1, 0)
    _test(0, 0, 1, 2, 0)
    _test(0, 1, 1, 2, 1)
    _test(0, 2, 1, 2, 0)
    _test(0, 3, 1, 2, 1)



# Generated at 2022-06-24 11:35:21.205046
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    mock_url = 'http://www.example.com/fake_video.mp4'
    mock_fatal_err = 'Some fatal error'
    mock_non_fatal_err = 'Some non fatal error'
    mock_fatal_reason = (1, mock_fatal_err)
    mock_non_fatal_reason = (2, mock_non_fatal_err)

    sample_downloader = FileDownloader(
        YoutubeDL({}),
        params={
            'format': 'fake_format',
            'fixup': 'warn'
        })
    sample_downloader.to_screen = mock_to_screen = Mock()
    sample_downloader.report_error = mock_report_error = Mock()


# Generated at 2022-06-24 11:35:31.518171
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import pytest
    from io import BytesIO
    from ytdl_server.ytdl.FileDownloader import FileDownloader
    import ytdl_server.ytdl.YoutubeDL as YoutubeDL
    from ytdl_server.ytdl.postprocessor.ffmpeg import FFmpegFixupM4aPP
    from ytdl_server.ytdl.postprocessor.ffmpeg import FFmpegMetadataPP
    ydl_opts = {
        'format': 'bestaudio/best',
        'verbose': True,
        'continue_dl': True,
        'nopart': False,
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }


# Generated at 2022-06-24 11:35:37.598003
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def time_t_side_effect(name):
        if name.endswith('.ytdl'):
            return 1234
        return 2345

    import datetime
    test_filename = 'testfile'
    dummy_downloader = FileDownloader({})
    dummy_downloader.try_utime(test_filename,
                               datetime.datetime.utcfromtimestamp(timeconvert('2013-11-12T10:37:37Z')).strftime('%s'))
    dummy_downloader.try_utime(test_filename, '1234')
    with open(encodeFilename(test_filename), 'wb') as testfile:
        testfile.write(b'\0')
    dummy_downloader.try_utime(test_filename, '1234')

# Generated at 2022-06-24 11:35:48.329501
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    code = 'test_code'
    msg = 'test_msg'
    # Test CASE: trouble(), no exception
    fd = FileDownloader(None, {'usenetrc': False})
    fd.trouble(code, msg)
    # Test CASE: trouble(), exception
    fd = FileDownloader(None, {'proxy': '...', 'usenetrc': False})
    try:
        fd.trouble(code, msg)
        # We can't test if an exception has been raised ...
    except Exception as e:
        # ... so just check if we have an exception
        assert e is not None

# Generated at 2022-06-24 11:35:55.927884
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    downloader = FileDownloader(YoutubeDL(params={}), params={})
    best_block_size = downloader.best_block_size
    assert best_block_size(1, 1) == 512
    assert best_block_size(1, 512) == 512
    assert best_block_size(5, 1024) == 1024
    assert best_block_size(10, 2048) == 2048
    assert best_block_size(4, 512) == 1024
    assert best_block_size(12, 2048) == 4096
    assert best_block_size(2, 512) == 256
    assert best_block_size(3, 1024) == 1024



# Generated at 2022-06-24 11:35:58.707517
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd=FileDownloader(params=None,ydl=None)
    assert fd.report_error('error') == False


# Generated at 2022-06-24 11:36:01.557237
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader({}, {})
    fd.to_screen = lambda *a, **k: ()
    fd.report_resuming_byte(42)
    # test that no exception is raised


# Generated at 2022-06-24 11:36:12.508242
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def assertEquals(a, b):
        if a != b:
            raise AssertionError('%r is not equal to %r' % (a, b))

    fd = FileDownloader({})
    assertEquals(fd.calc_speed(2, 3, 1024), 1024 / 1)
    assertEquals(fd.calc_speed(2, 4, 1024), 1024 / 2)
    assertEquals(fd.calc_speed(2, 5, 1024), 1024 / 3)
    assertEquals(fd.calc_speed(2, 6, 1024), 1024 / 4)

    # High precision
    assertEquals(fd.calc_speed(2, 3.5, 1024), 1024 / 1.5)

# Generated at 2022-06-24 11:36:20.513084
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    if not sys.version_info >= (3, 0, 0):
        return
    fd = FileDownloader(None)
    assert fd.format_speed(300) == '     300b/s'
    assert fd.format_speed(800) == '    0.8k/s'
    assert fd.format_speed(2304) == '    2.3k/s'
    assert fd.format_speed(2400) == '    2.4k/s'
    assert fd.format_speed(184320) == '  180.0k/s'
    assert fd.format_speed(1500000) == '    1.5M/s'
    assert fd.format_speed(15000000) == '    15M/s'
    assert fd.format_speed(1500000000)

# Generated at 2022-06-24 11:36:30.146378
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    def test(total, current, expected):
        assert FileDownloader.calc_percent(total, current) == expected
    test(100, 0, 0)
    test(100, 1, 1)
    test(100, 99, 99)
    test(100, 100, 100)
    test(100, -1, 0)
    test(100, 101, 100)
    test(100, 50, 50)
    test(None, None, 0)
    test(None, 1, 0)
    test(1, None, 0)
    test(1, 0, 0)
    test(1, 1, 100)
    test(1, 2, 100)


# Generated at 2022-06-24 11:36:38.635799
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    fd = FileDownloader(None, params={})
    # test format_eta
    assert fd.format_eta(None) == '--:--'
    assert fd.format_eta(0) == '0:00'
    assert fd.format_eta(1) == '0:01'
    assert fd.format_eta(60) == '1:00'
    assert fd.format_eta(61) == '1:01'
    assert fd.format_eta(3600) == '1:00:00'
    assert fd.format_eta(3601) == '1:00:01'
    assert fd.format_eta(3661) == '1:01:01'
    assert fd.format_eta(86400) == '1:00:00:00'

# Generated at 2022-06-24 11:36:50.592049
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    import tempfile
    fd1 = tempfile.NamedTemporaryFile(prefix='tsvf', suffix='.tsv')
    fd2 = tempfile.NamedTemporaryFile(prefix='tsvf', suffix='.tsv')
    fd1.write('1\n' * 100000)
    fd2.write('0\n')
    fd1.flush()
    fd2.flush()
    assert(None == FileDownloader().calc_speed(0, 0, 0))
    assert(None == FileDownloader().calc_speed(0, 1, 0))
    assert(0 == FileDownloader().calc_speed(0, 1, 100))
    assert(None == FileDownloader().calc_speed(1, 0, 100))

# Generated at 2022-06-24 11:36:51.761630
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # TODO
    pass

# Generated at 2022-06-24 11:37:02.115175
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Test bug at https://github.com/rg3/youtube-dl/issues/1500
    fd = FileDownloader(YoutubeDL({}))
    assert fd.best_block_size(10.0, 1024) == 40960
    assert fd.best_block_size(0.1, 1024) == 40960
    assert fd.best_block_size(0.1, 64) == 160
    assert fd.best_block_size(6.0, 64) == 160

    assert fd.best_block_size(10.0, 1) == 4
    assert fd.best_block_size(0.1, 1) == 4
    assert fd.best_block_size(0.1, 0) == 1
    assert fd.best_block_size(6.0, 0) == 1



# Generated at 2022-06-24 11:37:12.900665
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    with patch('youtube_dl.YoutubeDL.to_screen') as mock_to_screen, patch('youtube_dl.YoutubeDL.to_console_title') as mock_to_console_title:
        mock_to_screen.return_value = None
        mock_to_console_title.return_value = None
        ############################
        ### Start of function test###
        ############################
        fd = FileDownloader(YoutubeDL())
        def dummy(prog):
            pass
        fd.add_progress_hook(dummy)
        assert fd._progress_hooks == [dummy]
        ############################
        ### End of function test###
        ############################


# Generated at 2022-06-24 11:37:17.545831
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    downloader = FileDownloader()
    message = 'test'
    assert downloader.to_stderr(message) == 'test'
    message = None
    assert downloader.to_stderr(message) == None


# Generated at 2022-06-24 11:37:20.761493
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader({'outtmpl': '-'})
    filename = fd.download('-', {'ext': 'mp4'})
    assert filename == "-"


# Generated at 2022-06-24 11:37:24.837019
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # This is just a smoke test
    testargs = type('args', (object,), {})()
    testargs.verbose = True
    ydl = YoutubeDL(testargs)
    fd = FileDownloader(ydl, {}, {})
    fd.report_warning('dummy message')


# Generated at 2022-06-24 11:37:28.961322
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # Create a test message
    message = 'A test message'

    # Create a FileDownloader
    FileDownloader(YoutubeDL())

    # Pass the message to FileDownloader.report_warning()
    FileDownloader.report_warning(message)

    # Check that a logged warning contains the message
    assert(logg.last_warning['message'] == message)



# Generated at 2022-06-24 11:37:39.153926
# Unit test for method format_eta of class FileDownloader

# Generated at 2022-06-24 11:37:47.550236
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test of the FileDownloader.download method
    # 1 - Test the case where it is executed successfully
    # 2 - Test the case where the download fails

    # TEST 1
    # Create a MockYoutubeDL object
    ydl = mock.Mock()
    ydl.download_retcode = 0
    # Create a MockInfoDict object
    info = mock.Mock()
    name = 'name'

    # Declare expected values
    expected = True

    # Create a FileDownloader object
    fd = FileDownloader(ydl, info, name)
    # Call the download method and get the result
    result = fd.download(name, info)

    assert result == expected

    # TEST 2
    # Create a MockYoutubeDL object
    ydl = mock.Mock()
    ydl.download_retcode

# Generated at 2022-06-24 11:37:51.944584
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    t = 0.5
    s = 20
    expected = 40.0
    r = FileDownloader.calc_speed(t, s)
    assert(r == expected)



# Generated at 2022-06-24 11:37:53.895545
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # Tested method
    FileDownloader.report_retry(None, None, None)


# Generated at 2022-06-24 11:38:02.393933
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    from pytest import raises
    from collections import namedtuple

    fake_Dict = namedtuple("FakeDict", ["get"])
    fake_ydl = namedtuple("FakeYDL", ["ydl"])

    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    def dummy_hook(name):
        pass

    def dummy_hook_list(name):
        pass

    def dummy_hook_list_2(name):
        pass

    # Create a FileDownloader object
    f = TestFileDownloader(fake_ydl(fake_Dict(None)))

    # If a non-callable object is passed to add_progress_hook, raise
    # TypeError

# Generated at 2022-06-24 11:38:06.987775
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    obj = FileDownloader({})
    obj.to_screen = lambda x, y = False: None
    obj.to_console_title = lambda x: None
    obj.report_unable_to_resume()
#Unit test for method report_deleted_console_title of class FileDownloader

# Generated at 2022-06-24 11:38:11.334443
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({'noprogress': True}, None)
    assert fd.to_console_title(None) is None
    fd.to_console_title('testmsg')

if __name__ == '__main__':
    test_FileDownloader_to_console_title()
 
# vim:set ts=4 sw=4 sts=4 expandtab:

# Generated at 2022-06-24 11:38:21.652827
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    import sys
    if sys.version_info < (3, 0):
        FileDownloader._write_string = lambda s, bs: s.write(bs.decode('ascii', 'ignore'))

    fd = FileDownloader({})

    assert fd.format_percent(None, None) == '---.-%'
    assert fd.format_percent(254, None) == '  0.0%'
    assert fd.format_percent(255, None) == '  0.0%'
    assert fd.format_percent(256, None) == '  0.4%'
    assert fd.format_percent(511, None) == '  0.8%'
    assert fd.format_percent(512, None) == '  1.0%'
    assert fd.format_percent

# Generated at 2022-06-24 11:38:33.004591
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(0) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(42) == '%10s' % '42b/s'
    assert FileDownloader.format_speed(42 * 1024) == '%10s' % '42.0KiB/s'
    assert FileDownloader.format_speed(42 * 1024**2) == '%10s' % '42.0MiB/s'
    assert FileDownloader.format_speed(42 * 1024**3) == '%10s' % '42.0GiB/s'
    assert FileDownloader.format_speed(42 * 1024**4) == '%10s' % '42.0TiB/s'
    assert FileDownloader.format_speed(42 * 1024**5)

# Generated at 2022-06-24 11:38:38.787900
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert '00:00' == FileDownloader.format_seconds(0)
    assert '00:00' == FileDownloader.format_seconds(0.0)
    assert '00:01' == FileDownloader.format_seconds(1)
    assert '00:01' == FileDownloader.format_seconds(1.5)
    assert '00:59' == FileDownloader.format_seconds(59)
    assert '01:00' == FileDownloader.format_seconds(60)
    assert '01:00' == FileDownloader.format_seconds(60.4)
    assert '01:01' == FileDownloader.format_seconds(61.9)
    assert '01:59' == FileDownloader.format_seconds(119)
    assert '02:00' == FileDownloader.format_seconds(120)
   

# Generated at 2022-06-24 11:38:44.694074
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():

    fd = FileDownloader({})
    assert fd.undo_temp_name("temp123.part") == "temp123"
    assert fd.undo_temp_name("temp123.part4") == "temp123.part4"
    assert fd.undo_temp_name("temp123.m4a.part") == "temp123.m4a"

# Generated at 2022-06-24 11:38:48.303558
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None, None)

    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('bar') == 'bar'



# Generated at 2022-06-24 11:38:57.157822
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def print_status(status):
        print(status)
    # Initialize a FileDownloader
    fd = FileDownloader("", {}, {})
    fd.add_progress_hook(print_status)
    # Test FileDownloader.download()
    fd.download("out.mp3", {'title': 'Movie Title', 'id': 'Z65p_aRJsao'})
    # Test FileDownloader.real_download()
    # fd.real_download("out.mp3", {'title': 'Movie Title', 'id': 'Z65p_aRJsao'})
    # Compare file size with the result of API
    API_URL = 'http://youtube.com/get_video_info?video_id='

# Generated at 2022-06-24 11:39:04.869867
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    downloader = FileDownloader(params={})
    retry_count = [0]

    def reporthook(x):
        if not x['status'] == 'finished':
            retry_count[0] += 1
            if retry_count[0] >= 6:
                nonlocal done
                done = True

    done = False
    downloader.add_progress_hook(reporthook)
    downloader.slow_down(time.time(), None, 0)
    while not done:
        downloader.slow_down(0, time.time(), 100)
    assert retry_count == [6]



# Generated at 2022-06-24 11:39:16.542055
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    params = {
        'username': 'user',
        'password': 'pass',
        'usenetrc': '~/.netrc',
        'verbose': True,
        'quiet': True,
    }
    fd = FileDownloader(params)
    params['sleep_interval'] = 2
    fd = FileDownloader(params)
    params['max_sleep_interval'] = 2.3
    fd = FileDownloader(params)
    params['retries'] = 3
    fd = FileDownloader(params)

    # _parseOpts
    opts = fd._parseOpts([])
    opts = fd._parseOpts(['-u', 'user', '-p', 'pass123'])
    assert opts['username'] == 'user'
    assert opts['password']

# Generated at 2022-06-24 11:39:22.693583
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader(None)
    assert fd.ytdl_filename('foo') == 'foo.ytdl'
    assert fd.ytdl_filename('foo.ytdl') == 'foo.ytdl'
    assert fd.ytdl_filename('foo.txt') == 'foo.txt.ytdl'
    return True


# Generated at 2022-06-24 11:39:31.193549
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    f = FileDownloader({})
    f.to_console_title('test')
    assert f.to_console_title('test')


if __name__ == '__main__':
    parser = optparse.OptionParser()
    parser.add_option(
        '-v',
        action='store_true',
        dest='verbose',
        help='Activate verbose output')
    parser.add_option(
        '--test-to_console_title',
        dest='test_to_console_title',
        # Default value of 100 means no test in this case
        default=100,
        action='store_const',
        const=0,
        help='Run test on function to_console_title')
    (options, args) = parser.parse_args()


# Generated at 2022-06-24 11:39:41.445695
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '0:01'
    assert FileDownloader.format_eta(59) == '0:59'
    assert FileDownloader.format_eta(60) == '1:00'
    assert FileDownloader.format_eta(61) == '1:01'
    assert FileDownloader.format_eta(3599) == '59:59'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(3601) == '1:00:01'
    assert FileDownloader.format_eta(3659) == '1:00:59'
    assert FileDownloader.format_eta(3660) == '1:01:00'

# Generated at 2022-06-24 11:39:52.220440
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class DL(object):
        def __init__(self):
            self.ratelimit = None

        def to_screen(self, msg):
            pass

        def trouble(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

    class FD(FileDownloader):
        def __init__(self):
            self.dl = DL()

        def real_download(self, filename, info_dict):
            pass

    fd = FD()
    fd.dl.ratelimit = 8192
    fd._sleep_time = 0

    fd.slow_down(time.time() - 6, time.time() - 3, 8193)
    assert fd._sleep_time > 0

# Generated at 2022-06-24 11:39:55.046276
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    d = FileDownloader(params={'noprogress': True})
    out = six.StringIO()
    d.to_screen = out.write
    d.report_unable_to_resume()
    assert out.getvalue() == '[download] Unable to resume\n'
    out.close()


# Generated at 2022-06-24 11:40:06.539877
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(5) == '0:05'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(36000) == '10:00:00'
    assert FileDownloader.format_seconds(360000) == '100:00:00'
    assert FileDownloader.format_seconds(3600000) == '1000:00:00'
    assert FileDownloader.format_seconds(3600001) == '1000:00:01'

# Generated at 2022-06-24 11:40:16.558479
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    if FileDownloader.parse_bytes('1') != 1:
        raise AssertionError()
    if FileDownloader.parse_bytes('1k') != 1024:
        raise AssertionError()
    if FileDownloader.parse_bytes('1K') != 1024:
        raise AssertionError()
    if FileDownloader.parse_bytes('1m') != 1024 * 1024:
        raise AssertionError()
    if FileDownloader.parse_bytes('1M') != 1024 * 1024:
        raise AssertionError()
    if FileDownloader.parse_bytes('1g') != 1024 * 1024 * 1024:
        raise AssertionError()
    if FileDownloader.parse_bytes('1G') != 1024 * 1024 * 1024:
        raise AssertionError()

# Generated at 2022-06-24 11:40:26.652689
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    params = {'usenetrc': False,
              'username': 'foo',
              'password': 'bar'}
    d = FileDownloader({'usenetrc': False}, params, None)

    # Test authentication
    assert d.authentication_requested('http://example.com/', None)
    assert d.authentication_requested('http://example.com/', 'example.com')
    assert not d.authentication_requested('http://xample.com/', None)
    assert not d.authentication_requested('http://xample.com/', 'example.com')

    assert d.authentication_requested('http://example.com/', None, True)
    assert d.authentication_requested('http://example.com/', 'example.com', True)
    assert not d.authentication

# Generated at 2022-06-24 11:40:38.122869
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    (tmpfd, tmpfile) = tempfile.mkstemp(prefix='youtube-dl-test-', suffix='.tmp')
    os.close(tmpfd)
    class FakeFD:
        def __init__(self, file):
            self.file = file
            self.bytes_read = 0
        def read(self, num_bytes):
            self.bytes_read += num_bytes
            return b'a'
        def close(self):
            self.file.close()
    class FakeInfoDict:
        def get(self, key, default):
            if key == 'filepath':
                return tmpfile
            return default
        def __getitem__(self, key):
            if key == 'filepath':
                return tmpfile
            raise KeyError(key)

# Generated at 2022-06-24 11:40:49.594150
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    cases = [
        (-1, '0:00:00'),
        (0, '0:00:00'),
        (1, '0:00:01'),
        (59, '0:00:59'),
        (60, '0:01:00'),
        (61, '0:01:01'),
        (3599, '0:59:59'),
        (3600, '1:00:00'),
        (3602, '1:00:02'),
        (39080, '10:51:20'),
        (86400, '24:00:00'),
        (86500, '24:01:40'),
        (129600, '36:00:00'),
    ]
    for input, expected in cases:
        actual = FileDownloader.format_seconds(input)
        assert_

# Generated at 2022-06-24 11:40:59.143868
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(YoutubeDL())
    assert fd.parse_bytes('100') == 100
    assert fd.parse_bytes('100k') == 100 * 1024
    assert fd.parse_bytes('100m') == 100 * 1024 * 1024
    assert fd.parse_bytes('100g') == 100 * 1024 * 1024 * 1024
    assert fd.parse_bytes('100K') == 100 * 1024
    assert fd.parse_bytes('100M') == 100 * 1024 * 1024
    assert fd.parse_bytes('100G') == 100 * 1024 * 1024 * 1024
    assert fd.parse_bytes('1.5K') == int(1.5 * 1024)
    assert fd.parse_bytes('5e6') == 5000000
    assert fd.parse_bytes('5E6') == 5000000


# Generated at 2022-06-24 11:41:08.645337
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():

    # Setup
    file_downloader = FileDownloader(
        params={},
        to_screen=lambda *args, **kargs: print(*args, **kargs),
        to_stderr=lambda *args, **kargs: print(*args, **kargs),
        to_console_title=lambda *args, **kargs: print(*args, **kargs),
        trouble=lambda *args, **kargs: print(*args, **kargs),
        report_warning=lambda *args, **kargs: print(*args, **kargs),
        report_error=lambda *args, **kargs: print(*args, **kargs)
    )

    # Run
    file_downloader.report_resuming_byte(100)

    # Verify
    output = sys.stdout.getvalue().strip()

# Generated at 2022-06-24 11:41:17.931552
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    def test_file_already_downloaded(downloader, filename, expected_output):
        with no_deprecation_warnings():
            downloader.report_file_already_downloaded(filename)
            assert downloader._screen_file.getvalue() == expected_output

    fd = FileDownloader({'nooverwrites': True})
    fd._screen_file = io.StringIO()
    filename = 'The filename'

    test_file_already_downloaded(fd, filename, '[download] %s has already been downloaded\n' % filename)

    fd = FileDownloader({'nooverwrites': True})
    fd._screen_file = io.StringIO()
    filename = 'The filename with unicode: ваше имя'

    test_file_al

# Generated at 2022-06-24 11:41:21.704814
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    msg = 'Test for method calc_speed of class FileDownloader'
    assert isinstance(FileDownloader.calc_speed(1,1.1,1), float), msg
    assert FileDownloader.calc_speed(1,1,1) is None, msg
    assert FileDownloader.calc_speed(1,0.9,1) is None, msg


# Generated at 2022-06-24 11:41:28.512069
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    ydl = MockYoutubeDL({})
    fd = FileDownloader(ydl, {'nooverwrites': False})
    assert fd.ytdl_filename('abc') == 'abc.ytdl'
    assert fd.ytdl_filename('abc.ytdl') == 'abc.ytdl'
    assert fd.ytdl_filename('.ytdl') == '.ytdl'
    assert fd.ytdl_filename('/path/to/.ytdl') == '/path/to/.ytdl'
    assert fd.ytdl_filename('/path/to/abc') == '/path/to/abc.ytdl'

# Generated at 2022-06-24 11:41:39.750459
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '00:01'
    assert FileDownloader.format_seconds(1.01) == '00:01'
    assert FileDownloader.format_seconds(10) == '00:10'
    assert FileDownloader.format_seconds(61) == '01:01'
    assert FileDownloader.format_seconds(3600 + 61) == '01:01:01'
    assert FileDownloader.format_seconds(60 * 60 * 24 + 3600 + 61) == '1 day, 01:01:01'
    assert FileDownloader.format_seconds(60 * 60 * 24 + 3600 * 24 * 2 + 61) == '2 days, 01:01:01'

# Generated at 2022-06-24 11:41:48.296904
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """
    Test FileDownloader.real_download
    """
    # Test FileDownloader.real_download without content
    dl = FileDownloader({'noprogress': True, 'quiet': True}, {})
    dl.to_screen = lambda *x, **xx: None
    dl.report_destination = lambda *x, **xx: None
    result = dl.real_download(None, {'url': 'http://example.org', 'http_headers': {'content-length': '123'}})
    assert not result, 'without data'
    assert dl.ydl.headers.get('content-length') == '123', 'content-length'

    # Test FileDownloader.real_download with content
    dl = FileDownloader({'noprogress': True}, {})
    dl

# Generated at 2022-06-24 11:41:54.192953
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    import tempfile
    import os
    import shutil
    with tempfile.TemporaryDirectory() as d:
        shutil.copy(__file__, d)
        fd = FileDownloader({})
        fn = os.path.join(d, os.path.basename(__file__))
        fd.try_rename(fn, fn + '.test')
        assert os.path.isfile(fn + '.test')
test_FileDownloader_try_rename()


# Generated at 2022-06-24 11:42:00.845960
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader()
    fd.to_screen = lambda msg: print(msg)
    fd.report_retry(HTTPError('502'), 2, 6)
    fd.report_retry(HTTPError('504'), 6, 6)
    fd.to_screen = lambda msg: print(msg)
    fd.report_retry(HTTPError('504'), 6, float('inf'))
    fd.to_screen = lambda msg: print(msg)
    fd.report_retry(RtmpError('502'), 1, 2)
    fd.report_retry(RtmpError('504'), 2, 2)
    fd.report_retry(ContentTooShortError(100, 200), 1, 2)