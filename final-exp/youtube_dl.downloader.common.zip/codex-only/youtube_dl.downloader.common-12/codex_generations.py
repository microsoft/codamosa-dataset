

# Generated at 2022-06-24 11:32:01.583058
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def _check(s, expected):
        assert FileDownloader.format_seconds(s) == expected
    _check(0, '0:00')
    _check(123, '2:03')
    _check(45.67, '0:46')
    _check(-123, '-2:03')

if __name__ == '__main__':
    test_FileDownloader_format_seconds()

# Generated at 2022-06-24 11:32:04.741228
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    if sys.version_info < (2, 7):
        return

    import doctest
    print(doctest.testmod(FileDownloader, verbose=False)[0])



# Generated at 2022-06-24 11:32:08.279068
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    ydl = YoutubeDL(dict())
    fd = FileDownloader(ydl, {})
    fd.report_destination('destination')


# Generated at 2022-06-24 11:32:14.854357
# Unit test for method report_resuming_byte of class FileDownloader

# Generated at 2022-06-24 11:32:26.484293
# Unit test for method trouble of class FileDownloader

# Generated at 2022-06-24 11:32:31.337666
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # In order to run this unit test run youtue-dl with:
    #   youtube-dl --rm-cache-dir --no-warnings --dump-intermediate-pages --ignore-errors --no-progress --no-check-certificate
    #               -o '%(autonumber)s.%(ext)s'
    #               --max-sleep-interval 1.5 --min-sleep-interval 1.5
    #               --test
    #               https://www.youtube.com/watch?v=t3iizqBqn1E
    fd = FileDownloader(Params())
    fd.report_resuming_byte(123)


# Generated at 2022-06-24 11:32:39.102348
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test temporary names
    fd = FileDownloader(None, {})
    test_filenames = ['normalname.mp4',
                      'bad..chars.mp4',
                      'trailingbadchar.',
                      'trailingbadchar ',
                      '   leadingbadchar',
                      'newdir/normalname.mp4',
                      'newdir/bad..chars.mp4',
                      'newdir/trailingbadchar.',
                      'newdir/trailingbadchar ',
                      'newdir/   leadingbadchar',
                      'c:\\windows\\system32\\calc.exe']
    for test_filename in test_filenames:
        temp_name = fd.temp_name(test_filename)
        new_name = fd.undo_temp_name(temp_name)

# Generated at 2022-06-24 11:32:40.949484
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # TODO: find a way to test console output
    print("TODO: find a way to test console output")


# Generated at 2022-06-24 11:32:51.555751
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # the FileDownloader for testing
    file_downloader = FileDownloader({}, None)

    # destination filename, destination output (dest=None)
    destination = "test"
    destination_output = "[download] Destination: {0}".format(destination)

    # destination filename, destination output (dest="")
    destination2 = ""
    destination2_output = "[download] Destination: {0}".format(destination2)

    # destination filename, destination output (dest="-")
    destination3 = "-"
    destination3_output = "[download] Destination: {0}".format(destination3)

    # destination filename, destination output (dest="test.txt")
    destination4 = "test.txt"
    destination4_output = "[download] Destination: {0}".format(destination4)

    # destination filename, destination output

# Generated at 2022-06-24 11:32:55.081696
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader({})
    fd.to_screen = MagicMock()
    fd.report_unable_to_resume()
    fd.to_screen.assert_called_with('[download] Unable to resume')

# Generated at 2022-06-24 11:33:02.016741
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    # Empty
    assert FileDownloader.format_speed(None) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(0) == '%10s' % '0.0b/s'
    # B
    assert FileDownloader.format_speed(3) == '%10s' % '3.0b/s'
    assert FileDownloader.format_speed(0.1) == '%10s' % '0.1b/s'
    assert FileDownloader.format_speed(0.017) == '%10s' % '0.0b/s'
    assert FileDownloader.format_speed(0.023) == '%10s' % '0.0b/s'

# Generated at 2022-06-24 11:33:06.921167
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'verbose': True})
    message = 'Unit test for FileDownloader_to_stderr'
    fd.to_stderr(message)
    assert(message == sys.stderr.getvalue())



# Generated at 2022-06-24 11:33:16.013429
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert FileDownloader.try_utime(
        'test_filename',
        'Wed, 20 Jul 2016 13:24:41 GMT'
    ) == 1469070281

    # Our local time is GMT+2
    assert abs(FileDownloader.try_utime(
        'test_filename',
        'Wed, 20 Jul 2016 13:24:41 GMT'
    ) - 1469070281) == 7200

    assert FileDownloader.try_utime(
        'test_filename',
        'Wed, 20 Jul 2016 13:24:41 GMT'
    ) == 1469070281

    assert FileDownloader.try_utime(
        'test_filename',
        'Wed, 20 Jul 2016 13:24:41 +0000'
    ) == 1469070281


# Generated at 2022-06-24 11:33:22.381347
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    from ad_util import FFmpegPostProcessor
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_str, compat_urlparse, compat_urllib_parse_unquote

    # Create test objects
    ydl = YoutubeDL({})
    ie = InfoExtractor(ydl, {})
    fd = FileDownloader(ydl, {})
    fd.report_resuming_byte(100000)


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 11:33:30.196827
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    import unittest
    import mock

    class TestDownloader(object):
        params = {'retries': 0}

        def __init__(self, *args, **kwargs):
            self.trouble = mock.Mock()

        def to_screen(self, *args, **kwargs):
            pass

    class FileDownloader_test(unittest.TestCase):

        def test_format_retries(self):
            fd = FileDownloader(TestDownloader(), '', {})
            self.assertEqual(fd.format_retries(1), '1')
            self.assertEqual(fd.format_retries(1.0), '1')

            TestDownloader.params['retries'] = 1
            self.assertEqual(fd.format_retries(1), 'inf')
           

# Generated at 2022-06-24 11:33:32.026454
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(None, None)
    fd.report_error('msg')


# Generated at 2022-06-24 11:33:42.676042
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(None) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(1) == '%10s' % '1b/s'
    assert FileDownloader.format_speed(1000) == '%10s' % '1000b/s'
    assert FileDownloader.format_speed(234234) == '%10s' % '230k/s'
    assert FileDownloader.format_speed(800000) == '%10s' % '780k/s'
    assert FileDownloader.format_speed(800000 * 1000) == '%10s' % '781M/s'
    assert FileDownloader.format_speed(800000 * 1000 * 1000) == '%10s' % '781G/s'
    assert FileDownloader.format

# Generated at 2022-06-24 11:33:48.529195
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader = FileDownloader()
    utime = file_downloader.try_utime("/dev/null", "Wed, 27 May 2018 12:22:56 GMT")
    assert utime == 1527483376
    utime = file_downloader.try_utime("/dev/null", None)
    assert utime is None


# Generated at 2022-06-24 11:33:56.631425
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader()
    assert fd.undo_temp_name('') == ''
    assert fd.undo_temp_name('a') == 'a'
    assert fd.undo_temp_name('.a') == '.a'
    assert fd.undo_temp_name('.a.part') == '.a'
    assert fd.undo_temp_name('a.part') == 'a'
    assert fd.undo_temp_name('a.part.') == 'a.part.'
    assert fd.undo_temp_name('a.part.b') == 'a.part.b'
    assert fd.undo_temp_name('a.b.part') == 'a.b'

# Generated at 2022-06-24 11:34:01.419963
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    downloader = FileDownloader()
    start = time.time()
    time.sleep(0.5)
    now = time.time()
    bytes = 1024*1024
    speed = downloader.calc_speed(start, now, bytes)
    assert speed == bytes / (now - start)


# Generated at 2022-06-24 11:34:11.958601
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader(params={'format': 'best', 'outtmpl': '%(id)s.%(ext)s', 'verbose': False})

# Generated at 2022-06-24 11:34:21.168787
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader('DUMMY URL', {})
    fn_str = os.path.join(os.path.dirname(__file__), 'DUMMY FILENAME')
    fn_unicode = compat_os_text_type(fn_str)
    fd.report_file_already_downloaded(fn_str)
    fd.report_file_already_downloaded(fn_unicode)
    fd.report_file_already_downloaded(None)
    try:
        from io import BytesIO
    except ImportError:
        from StringIO import StringIO as BytesIO
    fd.report_file_already_downloaded(BytesIO())
    fd.report_file_already_downloaded(sys.stdout)


test_FileDownloader_report_

# Generated at 2022-06-24 11:34:24.359215
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0.000000001, 0) is None
    assert fd.calc_speed(0, 0.000000001, 1024) == 0
    assert fd.calc_speed(0.1, 0.3, 1024 * 12) == 8



# Generated at 2022-06-24 11:34:33.137263
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    ydl = YoutubeDL({'outtmpl': '%(autonumber)s-%(title)s.%(ext)s'})
    dl = FileDownloader(ydl, {'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'})

    # Non-unicode string
    dl.to_console_title('This is a test')
    assert sys.stdout.getvalue() == ''
    assert sys.stderr.getvalue() == ''

    # Unicode string
    dl.to_console_title('æ')
    assert sys.stdout.getvalue() == ''
    assert sys.stderr.getvalue() == '\r\x1b]2;æ\x07'

    # Unicode string with ANSI escape codes
    dl.to_

# Generated at 2022-06-24 11:34:45.509427
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({'nopart': False}, {'url': 'foo'})
    assert_equal(fd.temp_name('bar'), 'bar.part')
    fd = FileDownloader({'nopart': True}, {'url': 'foo'})
    assert_equal(fd.temp_name('bar'), 'bar')
    fd = FileDownloader({'nopart': True}, {'url': None})
    assert_equal(fd.temp_name('bar'), 'bar')
    fd = FileDownloader({'nopart': False}, {'url': None})
    assert_equal(fd.temp_name('bar'), 'bar.part')
    fd = FileDownloader({'nopart': False}, {'url': None})

# Generated at 2022-06-24 11:34:56.927174
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def _test(D, current, total, start, now, expected):
        assert D.calc_eta(start, now, current, total) == expected

    D = FileDownloader({})
    _test(D, 0, 100, 0, 0, None)
    _test(D, 0, 100.0, 0, 0, None)
    _test(D, 0, 100, 0, 2, 0)
    _test(D, 0, 100.0, 0, 2, 0)
    _test(D, 0, 100, 0, 2.5, 0)
    _test(D, 0, 100.0, 0, 2.5, 0)
    _test(D, 10, 100, 0, 2, 0)
    _test(D, 10, 100.0, 0, 2, 0)

# Generated at 2022-06-24 11:35:03.466593
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Test case: file is already downloaded
    fd = FileDownloader(FakeYDL(), {'nooverwrites': 'True'})
    assert fd.report_file_already_downloaded('test_video.mp4') == True
    # Test case: file is not downloaded
    fd = FileDownloader(FakeYDL(), {'nooverwrites': 'True'})
    assert fd.report_file_already_downloaded('test_video_2.mp4') == False


# Generated at 2022-06-24 11:35:09.740196
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    f = FileDownloader({})

    # Test without parameters
    assert f.try_utime('filename') is None

    # Test with an invalid header
    assert f.try_utime('filename', 'saturday at six') is None

    # Test with a header in the future
    future = time.time() + 100000000
    future_header = time.strftime('%Y%m%d%H%M%S', time.gmtime(future))
    assert f.try_utime('filename', future_header) is None

    # Test with a valid header
    now = time.time()
    now_header = time.strftime('%Y%m%d%H%M%S', time.gmtime(now))
    # time.mtime(filename) can return a rounded number
    # that's why we use .isclose

# Generated at 2022-06-24 11:35:18.442750
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(FakeYDL(), {'noprogress': True, 'continuedl': True, 'nooverwrites': True})
    fd.to_screen = MagicMock()
    fd.report_resuming_byte(10)
    fd.to_screen.assert_called_once_with('[download] Resuming download at byte 10')


# Generated at 2022-06-24 11:35:27.925147
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    with tempfile.TemporaryDirectory() as tmpdir:
        ydl = YoutubeDL(params={'logger': TestLogger(), 'outtmpl': os.path.join(tmpdir, 'test.%(ext)s')})
        fd = FileDownloader({'outtmpl': 'test.%(ext)s', 'noprogress': True}, ydl)

        fd.trouble(u'Test\u1234')
        test_log = 'ERROR: Test\u1234'
        assert fd.ydl.logger.logs == [test_log]



# Generated at 2022-06-24 11:35:33.866909
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    assert callable(FileDownloader.to_screen)
    # Make sure we don't call any sys.exit()
    FileDownloader.to_screen(None, 'message', skip_eol=False)
    FileDownloader.to_screen(None, 'message', skip_eol=True)
    # Make sure we don't call any sys.stdout.write()
    FileDownloader.to_screen(None, b'message', skip_eol=False)
    FileDownloader.to_screen(None, b'message', skip_eol=True)



# Generated at 2022-06-24 11:35:43.471023
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    # Test for method to_screen(self, *args, **kargs)
    # self.params = {}
    # Should print to stderr message
    #
    # self.params['outtmpl'] = ''
    # Should print message to stderr
    #
    # self.params['outtmpl'] = '/tmp'
    # Should print to stdout message
    test_FileDownloader = FileDownloader(params={})
    test_FileDownloader.to_screen('Testing to_screen')
    test_FileDownloader.params['outtmpl'] = ''
    test_FileDownloader.to_screen('Testing to_screen')
    test_FileDownloader.params['outtmpl'] = '/tmp'
    test_FileDownloader.to_screen('Testing to_screen')
#


# Generated at 2022-06-24 11:35:49.488490
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    downloader = FileDownloader(None)

    def to_screen(message):
        assert message == '[download] Got server HTTP error: HTTP Error 500: Internal Server Error. Retrying (attempt 1 of 10)...'

    downloader.to_screen = to_screen
    downloader.report_retry(Exception('HTTP Error 500: Internal Server Error'), 1, 10)



# Generated at 2022-06-24 11:36:02.240644
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    DummyYtdl.report_retry_test_expectation = None
    DummyYtdl.report_retry_test_result = None

    # Test normal use
    DummyYtdl.report_retry_test_expectation = (
        '', 3, 5
    )

    FileDownloader(DummyYtdl(), DummyYtdl.params).report_retry(
        '', 3, 5
    )
    assert DummyYtdl.report_retry_test_result == (
        '[download] Got server HTTP error: . Retrying (attempt 3 of 5)...'
    )

    # Test with HTTP interrupted
    DummyYtdl.report_retry_test_expectation = (
        IncompleteRead('', None), 1, 5
    )


# Generated at 2022-06-24 11:36:14.430150
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-24 11:36:21.379009
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    class TestNoOp(object):
        def to_screen(self, *args, **kargs):
            pass
    print('Running unit test on FileDownloader.format_speed')
    print('Please wait...')
    downloader = FileDownloader(TestNoOp())

# Generated at 2022-06-24 11:36:32.253065
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(0) == '  0.00b/s'
    assert FileDownloader.format_speed(10) == ' 10.00b/s'
    assert FileDownloader.format_speed(100) == '100.00b/s'
    assert FileDownloader.format_speed(999) == '999.00b/s'
    assert FileDownloader.format_speed(1000) == '  1.00k/s'
    assert FileDownloader.format_speed(1001) == '  1.00k/s'
    assert FileDownloader.format_speed(1001.999) == '  1.00k/s'
    assert FileDownloader.format_speed(1000 * 1000) == '1000.00k/s'

# Generated at 2022-06-24 11:36:40.132764
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    import sys
    import StringIO
    sys.stdout = StringIO.StringIO()
    ydl_opts = {'verbose': True}
    ydl = YoutubeDL(ydl_opts)
    fd = FileDownloader(ydl, ydl_opts)
    #  test for ascii and unicode
    text = 'ascii and unicode'
    fd.to_screen(text)
    assert text in sys.stdout.getvalue()
    text = u'ascii and unicode'
    fd.to_screen(text)
    assert text in sys.stdout.getvalue()
    #  test for str() error
    class A(str):
        pass
    text = A('str() error')
    fd.to_screen(text)

# Generated at 2022-06-24 11:36:41.877783
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {})
    assert fd.ytdl_filename('foo') == 'foo.ytdl'


# Generated at 2022-06-24 11:36:52.169314
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(00) == u'0:00'
    assert FileDownloader.format_seconds(00.0) == u'0:00'
    assert FileDownloader.format_seconds(0.0) == u'0:00'
    assert FileDownloader.format_seconds(.0) == u'0:00'
    assert FileDownloader.format_seconds(.00) == u'0:00'

    assert FileDownloader.format_seconds(10) == u'0:10'
    assert FileDownloader.format_seconds(.1) == u'0:00'
    assert FileDownloader.format_seconds(.01) == u'0:00'
    assert FileDownloader.format_seconds(.001) == u'0:00'

# Generated at 2022-06-24 11:37:02.351361
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from .YoutubeDL import YoutubeDL
    
    # Init downloader
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {})
    
    # Init download speed measurement
    start_time = time.time()
    byte_counter = 0
    
    # Report progress
    status = {
        'status': 'downloading',
        'downloaded_bytes': 435,
        'elapsed': 1,
        'speed': bytex_second(byte_counter, start_time)
    }
    fd.report_progress(status)
    
    # Report progress
    status = {
        'status': 'finished',
        'total_bytes': 532,
        'elapsed': 2,
    }
    fd.report_progress(status)

    # Report progress

# Generated at 2022-06-24 11:37:15.536827
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # test seconds
    f = FileDownloader({})
    gray = '\033[37m'  # make tests work on terminals without ANSI color codes support
    green = '\033[32m'
    normal = '\033[0m'
    assert f.format_seconds(0) == green + '0:00' + normal
    assert f.format_seconds(0.4) == green + '0:00' + normal
    assert f.format_seconds(5.4) == green + '0:05' + normal
    assert f.format_seconds(59.4) == green + '0:59' + normal
    assert f.format_seconds(60) == green + '1:00' + normal
    assert f.format_seconds(61.4) == green + '1:01' + normal
    assert f.format

# Generated at 2022-06-24 11:37:20.993647
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(0) == u'0'
    assert FileDownloader.format_retries(1) == u'1'
    assert FileDownloader.format_retries(2) == u'2'
    assert FileDownloader.format_retries(float('inf')) == u'inf'
    assert FileDownloader.format_retries(None) == u'inf'


# Generated at 2022-06-24 11:37:27.693952
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    ydl = FakeYDL()
    fd = FileDownloader(ydl)
    x = []
    def _write_string(s):
        x.append(s)

    fd._write_string = _write_string

    fd.to_console_title('hi')
    assert(x[0] == u'\033]0;hi\007')

    # Test that non-ascii characters are stripped
    fd.to_console_title('hí')
    assert(x[1] == u'\033]0;hi\007')


# Generated at 2022-06-24 11:37:31.429822
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None)
    fd.to_screen = lambda msg: print(msg)
    fd.report_file_already_downloaded('filename')
    fd.report_file_already_downloaded('filename' * 1000)

# Generated at 2022-06-24 11:37:41.459818
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    import unittest
    import sys

    if sys.version_info[0] >= 3 and sys.version_info[1] >= 3:
        def parse_bytes(bytestr):
            return FileDownloader.parse_bytes(bytestr)

        class TestFileDownloader(unittest.TestCase):
            def test_parse_bytes_exact_multiples(self):
                self.assertEqual(parse_bytes('0B'), 0)
                self.assertEqual(parse_bytes('1K'), 1024)
                self.assertEqual(parse_bytes('42K'), 44032)
                self.assertEqual(parse_bytes('1M'), 1048576)
                self.assertEqual(parse_bytes('2M'), 2097152)

# Generated at 2022-06-24 11:37:49.499517
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader(None, None)
    assert fd.format_seconds(0) == '0:00'
    assert fd.format_seconds(1) == '0:01'
    assert fd.format_seconds(62) == '1:02'
    assert fd.format_seconds(120) == '2:00'
    assert fd.format_seconds(1000000) == '2777:46:40'
    assert fd.format_seconds(1000001) == '2777:46:41'
    assert fd.format_seconds(10000000) == '27775:53:20'


# Generated at 2022-06-24 11:38:00.003770
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader({'outtmpl': None})

    class TestFD(object):
        def __init__(self, expected):
            self.expected = expected
            self.written = []

        def write(self, s):
            self.written.append(s)

    # We shouldn't write anything if not in verbose mode
    fd.params['verbose'] = False
    test = TestFD([])
    fd.to_screen('a-string', file=test)
    assert test.written == []

    # Test verbose. Should print everything, even if it doesn't end in \n
    fd.params['verbose'] = True
    test = TestFD(['a-string', 'another-string\n'])
    fd.to_screen('a-string', file=test)
    fd

# Generated at 2022-06-24 11:38:02.133608
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader({'outtmpl': 'output.txt'})
    fd.report_unable_to_resume()


# Generated at 2022-06-24 11:38:11.829796
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    # pylint: disable=missing-docstring
    downloader = FileDownloader(params={'ytdl_filename': 'filename'})
    assert downloader.ytdl_filename('test') == 'test.ytdl'
    downloader = FileDownloader(params={'ytdl_filename': 'filename.ytdl'})
    assert downloader.ytdl_filename('test') == 'test.ytdl'
    downloader = FileDownloader(params={'ytdl_filename': 'dir/filename'})
    assert downloader.ytdl_filename('test') == 'dir/filename'
    downloader = FileDownloader(params={'ytdl_filename': 'dir/filename.ytdl'})

# Generated at 2022-06-24 11:38:17.249862
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test 1
    fd = FileDownloader(FakeYDL(), {})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('/bar/foo.part') == '/bar/foo'
    assert fd.undo_temp_name('foo') == 'foo'



# Generated at 2022-06-24 11:38:28.516637
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader({}).temp_name('abc') == 'abc.part'
    assert FileDownloader({'nopart': True}).temp_name('abc') == 'abc'
    assert FileDownloader({'nopart': True}).temp_name('-') == '-'
    assert FileDownloader({'nopart': True}).temp_name('does_not_exist') == 'does_not_exist'
    assert FileDownloader({'nopart': True}).temp_name('does_not_exist.part') == 'does_not_exist.part'
    
    fd = FileDownloader({'nopart': True})
    class MockDir:
        def __init__(self):
            self.mkd()
            

# Generated at 2022-06-24 11:38:37.468413
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    ae(FileDownloader.format_percent(0), '0%')
    ae(FileDownloader.format_percent(0.1), '0%')
    ae(FileDownloader.format_percent(0.01), '0%')
    ae(FileDownloader.format_percent(0.001), '0%')
    ae(FileDownloader.format_percent(0.0001), '0%')
    ae(FileDownloader.format_percent(0.00001), '0%')
    ae(FileDownloader.format_percent(0.000001), '0%')
    ae(FileDownloader.format_percent(0.00000001), '0%')
    ae(FileDownloader.format_percent(0.000000001), '0%')

# Generated at 2022-06-24 11:38:44.693001
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    'Test FileDownloader.report_destination method'
    from youtube_dl.YoutubeDL import YoutubeDL

    class FakeFD(FileDownloader):
        def __init__(self, ydl):
            self._ydl = ydl

    fd = FakeFD(YoutubeDL({}))
    fd.report_destination(b'foo.bar')
    assert (fd.screen_output.getvalue() ==
            '[download] Destination: foo.bar\n')
    assert fd.screen_output.getvalue().encode('utf-8') == b'[download] Destination: foo.bar\n'

# Generated at 2022-06-24 11:38:53.350815
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Create a subprocess that pretends to be youtube-dl
    #infile_desc, infile = tempfile.mkstemp(prefix='yt-dl-input-', text=True)
    import tempfile
    infile = tempfile.TemporaryFile()
    infile_desc = infile.fileno()
    outfile_desc, outfile = tempfile.mkstemp(prefix='yt-dl-output-', text=True)
    errfile_desc, errfile = tempfile.mkstemp(prefix='yt-dl-output-', text=True)

# Generated at 2022-06-24 11:39:01.953340
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    from .utils import FakeYDL

    expected_status = '[download] Got server HTTP error: Test. Retrying (attempt 2 of 5)...'
    expected_status2 = '[download] Got server HTTP error: Test. Retrying (attempt 5 of 20)...'
    expected_status3 = '[download] Got server HTTP error: Test. Retrying (attempt 8 of inf)...'

    def test_retry(error, count, retries):
        # pylint: disable=unused-argument
        return retries

    ydl = FakeYDL()
    ydl.params = {
        'retries': 5,
        'noprogress': False,
        'nooverwrites': False,
        'continuedl': True,
        'nopart': False,
    }

# Generated at 2022-06-24 11:39:06.164353
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    fd = FileDownloader({}, {})
    assert fd.ydl is None
    assert fd.params is None
    assert fd._progress_hooks == []

if __name__ == '__main__':
    test_FileDownloader()

# Generated at 2022-06-24 11:39:17.119865
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    import os
    import tempfile
    import  unittest.mock as mock
    import urllib.parse

    import pytest

    from youtube_dl.downloader.http import HttpFD


# Generated at 2022-06-24 11:39:26.331907
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1.2) == '1.2s'
    assert FileDownloader.format_seconds(1) == '1.0s'
    assert FileDownloader.format_seconds(0.0) == '0.0s'
    assert FileDownloader.format_seconds(60.0) == '1.0m'
    assert FileDownloader.format_seconds(61.0) == '1.0m'
    assert FileDownloader.format_seconds(3601.0) == '1.0h'
    assert FileDownloader.format_seconds(3661.0) == '1.0h'
    assert FileDownloader.format_seconds(86400.0) == '1.0d'
    assert FileDownloader.format_seconds(86401.0) == '1.0d'

# Generated at 2022-06-24 11:39:29.251679
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    d = FileDownloader({})
    assert d.ydl is None
    assert d.params == {}
    assert d._progress_hooks == []



# Generated at 2022-06-24 11:39:39.706282
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    try:
        os.unlink('testutime')
    except OSError:
        pass

    fd = io.open('testutime', 'w')
    fd.write('hello')
    fd.close()
    f = FileDownloader(
        FakeYDL(),
        {'format': 'best', 'nooverwrites': True, 'outtmpl': 'test%(ext)s'})
    filenames = ['testutime', 'testutime.data', 'testutime.part']
    for n in filenames:
        f.to_screen('[debug] Testing '+n)
        # Check that files without last modified header
        outtmpl = '%s.%%(ext)s' % n
        f.params['outtmpl'] = outtmpl

# Generated at 2022-06-24 11:39:48.866947
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    def _test(func, expected):
        ydl = YoutubeDL({'logger': MockLogger()})
        fd = FileDownloader({'logger': ydl.logger}, ydl)
        func(fd)
        assert ydl.logger.messages == expected

    _test(
        lambda fd: fd.report_warning('spam spam spam spam'),
        ['WARNING: spam spam spam spam']
    )
    _test(
        lambda fd: fd.report_warning('spam %s spam', 'eggs'),
        ['WARNING: spam eggs spam']
    )

# Generated at 2022-06-24 11:39:55.551273
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test with empty filename
    with pytest.raises(ValueError):
        FileDownloader(None, None).temp_name('')

    # Test with not empty filename
    FileDownloader(None, None).temp_name('filename')

    # Test with not empty filename, --no-part and file exist
    class _FileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True
    _FileDownloader(None, None, 'nopart').temp_name('.gitignore')



# Generated at 2022-06-24 11:40:02.965647
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    assert FileDownloader.ytdl_filename('a') == 'a.ytdl'
    assert FileDownloader.ytdl_filename(u'\u043a') == u'\u043a.ytdl'
    assert FileDownloader.ytdl_filename('a.b') == 'a.b.ytdl'
    assert FileDownloader.ytdl_filename('a.b.c') == 'a.b.c.ytdl'



# Generated at 2022-06-24 11:40:13.217823
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def t(v):
        f = FileDownloader(None, None)
        return f.temp_name(v)
    assert t('x') == 'x.part'
    assert t('x.part') == 'x.part'
    assert t('x.part.part') == 'x.part.part'
    assert t('x.flv.part') == 'x.flv.part'
    assert t('x.flv.tmp') == 'x.flv.tmp'
    assert t('x-flv-tmp') == 'x-flv-tmp.part'
    assert t('x.ytdl') == 'x.ytdl.part'
    assert t('x/y') == 'x/y'
    assert t('x/y.part') == 'x/y.part'

# Generated at 2022-06-24 11:40:21.113608
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    #
    # Test no rate limit
    #
    fd = FileDownloader('dummy')
    fd.params['ratelimit'] = None
    _start_t = time.time()
    fd.slow_down(_start_t, _start_t, 0)
    assert 0.0 == time.time() - _start_t  # No sleep
    fd.slow_down(_start_t, _start_t, 1000)
    assert 0.0 == time.time() - _start_t  # No sleep
    fd.slow_down(_start_t, _start_t+1.0, int(1000 / 1.0))
    assert 0.0 == time.time() - _start_t  # No sleep

# Generated at 2022-06-24 11:40:29.761506
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .compat import StringIO
    from .compat import is_py2
    from .__main__ import FakeYdl


# Generated at 2022-06-24 11:40:35.174448
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    d = FileDownloader(params={})

    assert d.format_percent(0.5) == "50%"
    assert d.format_percent(1.0) == "100%"
    assert d.format_percent(1.5) == "150%"
    assert d.format_percent(0.05) == "5%"



# Generated at 2022-06-24 11:40:40.418413
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    ydl = YoutubeDL()
    dl = FileDownloader(ydl, {'outtmpl': '%(id)s'})

if __name__ == '__main__':
    test_FileDownloader()

# Generated at 2022-06-24 11:40:42.386780
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(FileDownloaderParams())

    # Call method report_error with specified
    fd.report_error("Test Error Message")



# Generated at 2022-06-24 11:40:52.364000
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, {'nooverwrites': True})

    # Test #1
    assert fd.best_block_size(1.0, 4194304) == 4194304
    assert fd.best_block_size(1.0, 1) == 2
    assert fd.best_block_size(1.0, 2) == 2
    assert fd.best_block_size(1.0, 1024) == 1024
    assert fd.best_block_size(1.0, 512) == 1024
    assert fd.best_block_size(1.0, 1023) == 1024

    # Test #2
    assert fd.best_block_size(0.1, 4194304) == 4194304
    assert fd.best_block_size(0.1, 1)

# Generated at 2022-06-24 11:40:56.016404
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    downloader = FileDownloader({'ignoreerrors': 'False'})
    try:
        a = 1 / 0
    except Exception as err:
        downloader.report_warning(
            'Test warning: %s' % error_to_compat_str(err))

# Generated at 2022-06-24 11:41:06.744238
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import pickle
    from tempfile import NamedTemporaryFile, TemporaryDirectory
    import urllib.parse
    import youtube_dl.utils

    def mock_hook(status):
        nonlocal hooks_called
        hooks_called = status

    def mock_downloader(ydl, *args, **kargs):
        nonlocal hooks_called

        # mock real_download
        def mock_real_download(filename, info_dict):
            nonlocal hooks_called
            # simulate overlap of previous download
            hooks_called['downloaded_bytes'] = hooks_called['total_bytes'] // 2
            hooks_called['speed'] = hooks_called['total_bytes'] // 2

            return True
        ydl.real_download = mock_real_download

        return ydl.download(*args, **kargs)


# Generated at 2022-06-24 11:41:15.633589
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    app = Application()
    downloader = FileDownloader(app)
    downloader.to_screen = lambda x: None
    downloader.report_file_already_downloaded('-')
    os.chdir(sys.path[0])
    downloader.report_file_already_downloaded('test.py')
    downloader.report_file_already_downloaded('youtube-dl')

if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-24 11:41:19.780281
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FileDownloader({'outtmpl': '%(id)s'}, YoutubeDL())
    fd.report_destination('123.mp4')
    fd.report_destination('456.mp4')
    fd.report_destination('789.txt')
test_FileDownloader_report_destination()

# Generated at 2022-06-24 11:41:25.648839
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    params = { 'usenetrc': False, 'username': 'test', 'password': 'test', 'ap_username': 'test', 'ap_password': 'test', 'ap_mso': 'test', 'verbose': True}
    fd = FileDownloader(params)

    assert fd.params['usenetrc'] == False
    assert fd.params['username'] == 'test'
    assert fd.params['password'] == 'test'
    assert fd.params['ap_username'] == 'test'
    assert fd.params['ap_password'] == 'test'
    assert fd.params['ap_mso'] == 'test'
    assert fd.params['verbose'] == True

# Generated at 2022-06-24 11:41:37.499564
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile

    def urllib2_urlopen(c, url, data=None):
        if url.startswith('http://localhost/'):
            return MockUrlOpenerResponse(url, data)
        else:
            return urllib.request.urlopen(url, data)

    def urllib_urlretrieve(c, url, filename, data=None):
        if url.startswith('http://localhost/'):
            return (filename, MockUrlOpenerResponse(url, data))
        else:
            return urllib.request.urlretrieve(url, filename, data)

    def urllib_urlopen(c, url, data=None):
        if url.startswith('http://localhost/'):
            return MockUrlOpenerResponse(url, data)
        else:
            return

# Generated at 2022-06-24 11:41:47.364212
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    #rate limit=None
    f = FileDownloader({'ratelimit':None})
    assert f.calc_speed(0, 0, 0) == None
    f.slow_down(0, 0, 0)
    #rate limit = 0
    f = FileDownloader({'ratelimit':0})
    assert f.calc_speed(0, 0, 0) == None
    f.slow_down(0, 0, 0)
    #rate limit = 2
    f = FileDownloader({'ratelimit':2})
    assert f.calc_speed(0, 0, 0) == None
    f.slow_down(0, 0, 0)
    assert f.calc_speed(0, 0.5, 1) == 2.0
    f.slow_down(0, 1, 1) # elapsed time: 1

# Generated at 2022-06-24 11:41:56.171063
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader(YoutubeDL())
    fd.try_rename('path_to_file', 'path_to_file')
    fd.try_rename('path_to_file.part', 'path_to_file')
    try:
        os.makedirs('test_dir')
    except OSError:
        pass
    open('test_dir/file', 'w').close()
    fd.try_rename('test_dir/file.part', 'test_dir/file')
    fd.try_rename('test_dir/file', 'test_dir/file.part')
    fd.try_rename('test_dir/file.part', 'test_dir/file.part')