

# Generated at 2022-06-24 11:31:59.449874
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    import sys
    import io

    fd = FileDownloader(params={})

    fd.to_screen('Hello')
    assert sys.stdout.getvalue() == 'Hello\n'
    sys.stdout = io.StringIO()

    # Unicode
    fd.to_screen('\u00e9')
    assert sys.stdout.getvalue() == '\u00e9\n'
    sys.stdout = io.StringIO()

    # Skip eol
    fd.to_screen('Hello', skip_eol=True)
    assert sys.stdout.getvalue() == 'Hello'
    sys.stdout = io.StringIO()

    # Unicode with skip eol
    fd.to_screen('\u00e9', skip_eol=True)
    assert sys.stdout

# Generated at 2022-06-24 11:32:04.410876
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader({})
    fd.ydl = YoutubeDL()

    fd.to_stderr('foo')
    assert YoutubeDL.ret_code == 0

    fd.to_stderr('bar')
    assert YoutubeDL.ret_code == 1
# Test for method calc_percent

# Generated at 2022-06-24 11:32:13.210997
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    path = './test_calc_speed/'
    os.system('rm -r '+path)
    os.system('mkdir '+path)
    os.system('touch '+path+'test.mp4')
    test_file = open(path+'test.mp4', 'w+')
    start = time.time()
    size = 1024
    for i in range(0,100):
        test_file.write(b'1'*size)
        size *= 2
        fd = FileDownloader({}, {'outtmpl': path+'test.mp4'})
        time.sleep(0.1)
        rest_time = fd.calc_eta(start, size, test_file.tell())
        if rest_time < 0:
            assert(False)
    test_file

# Generated at 2022-06-24 11:32:22.287236
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    def test(seconds, expected):
        actual = FileDownloader.format_eta(seconds)
        if actual != expected:
            raise AssertionError(
                'Expected %s but got %s for input %s' % (
                    expected, actual, seconds))
    # Test
    test(0, '0:00')
    test(1, '0:01')
    test(59, '0:59')
    test(60, '1:00')
    test(61, '1:01')
    test(3599, '59:59')
    test(3600, '1:00:00')
    test(3601, '1:00:01')
    test(3661, '1:01:01')
    test(86399, '23:59:59')

# Generated at 2022-06-24 11:32:26.899602
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({})
    if compat_os_name == 'nt':
        fd.to_console_title('Testing')
        assert win_unicode_console is not None
    else:
        fd.to_console_title('Testing')


if __name__=="__main__":
    test_FileDownloader_to_console_title()

# Generated at 2022-06-24 11:32:37.600238
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # test for method report_retry of class FileDownloader
    obj = object.__new__(FileDownloader)
    obj.ydl = object.__new__(YoutubeDL)
    obj.ydl.report_warning = lambda *args, **kargs: None
    stderr_orig = sys.stderr

    class StderrMock(object):
        def isatty(self):
            return True

        def write(self, msg):
            assert '\r' not in msg
            assert '\n' in msg


# Generated at 2022-06-24 11:32:39.508465
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Not tested (hard to test)
    pass



# Generated at 2022-06-24 11:32:47.379670
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    download = FileDownloader({}, {'outtmpl': '%(id)s.%(ext)s'}, {'_sleep_interval': 0}, None)

    # Test nooverwrites -- if a local file exists, the download is skipped
    fd, existing_filename = tempfile.mkstemp()
    os.close(fd)
    assert download.download(existing_filename, {}) is True
    assert os.path.exists(existing_filename)

    # Test continuedl -- if a local file exists, the download continues
    fd, continuedl_filename = tempfile.mkstemp()
    os.close(fd)
    assert download.download(continuedl_filename, {'continue': True}) is True
    # Download cannot be resumed
    os.remove(continuedl_filename)
    assert download.download

# Generated at 2022-06-24 11:32:57.095222
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    import unittest
    from . import FakeDownloader
    from .Downloader import speed_to_str

    fd = FakeDownloader()
    fd.params['noprogress'] = True
    fd.params['verbose'] = True
    fd.params['ratelimit'] = 1000

    def speedfor(time, bytes):
        return fd.format_speed(fd.calc_speed(0, time, bytes))

    def check(time, bytes, speed):
        assert speedfor(time, bytes) == speed

    check(0, 0, '%10s' % '---b/s')
    check(0.1, 0, '%10s' % '---b/s')
    check(0.1, 10**6, '%10s' % '10.0MB/s')
    check

# Generated at 2022-06-24 11:33:08.865900
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    class TimeFile(file):
        """ A subclass of file that keeps track of line count, and
            allows to set the timestamp of each line
        """

        def __init__(self, name, mode='r', bufsize=None, time_seq=None):
            file.__init__(self, name, mode, bufsize)
            self.lines_count = 0
            self._time_seq = time_seq
            self._utime_calls = []

        def readline(self):
            result = file.readline(self)
            if result:
                self.lines_count += 1
            return result

        def utime(self, time_tuple):
            self._utime_calls.append(time_tuple)

    #-------------------------------------------------------------------------
    # We test the function try_utime
    #-------------------------------------------------------------------------

   

# Generated at 2022-06-24 11:33:12.710270
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(params={})
    fd.to_screen = lambda *args: args
    fd.report_resuming_byte(42)
    assert fd.to_screen.call_args[0] == ('[download] Resuming download at byte 42',)


# Generated at 2022-06-24 11:33:20.657571
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    def _test_format_eta(base, value, expected):
        assert (FileDownloader.format_eta(base + value) == expected)
        assert (FileDownloader.format_eta(base - value) == expected)

    _test_format_eta(0, 0, '00:00')
    _test_format_eta(0, 1, '00:01')
    _test_format_eta(0, 59, '00:59')
    _test_format_eta(0, 60, '01:00')
    _test_format_eta(0, 60 + 59, '01:59')
    _test_format_eta(0, 60 * 60, '01:00:00')
    _test_format_eta(0, 60 * 60 + 59, '01:00:59')
    _test_format_eta

# Generated at 2022-06-24 11:33:29.490389
# Unit test for method undo_temp_name of class FileDownloader

# Generated at 2022-06-24 11:33:34.878179
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # Instantiate object
    fileDownloader = FileDownloader(None, None)
    # Testing 
    try:
        # Testing first report_warning method
        fileDownloader.report_warning('test warning')
    except UnicodeEncodeError:
        pass
    # Testing second report_warning method
    fileDownloader.report_warning('test warning', 'Test warning', True)


# Generated at 2022-06-24 11:33:43.538816
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    ydl = YoutubeDL()  # use to_screen method of this class for testing
    dl = FileDownloader(ydl, params={})

    print("test 1")
    dl.to_screen("test1")  # nothing's happend
    print("test 2")
    dl.to_screen("test2", skip_eol=True)
    print("test 3")
    dl.to_screen("test3", skip_eol=False)
    print("test 4")
    dl.to_screen("test4", skip_eol=True)
    print("test 5")
    dl.to_screen("test5")
    print("test 6")
    dl.to_screen("test6", force_printing=True, skip_eol=True)
    print("test 7")
    d

# Generated at 2022-06-24 11:33:54.469605
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    class FakeYDL:
        def __init__(self):
            self.my_hooks = []

        def add_progress_hook(self, ph):
            self.my_hooks.append(ph)

    class FakeInfoDict:
        def __init__(self):
            self.info = {'status': 'finished', 'filename': 'a',
                         'total_bytes': 100, 'downloaded_bytes': 100}

        def get(self, k, d=None):
            return self.info.get(k, d)

    # This test fails if d is None
    d = FileDownloader(FakeYDL(), {})
    assert d is not None

    def ph(s):
        pass

    d.add_progress_hook(ph)
    assert len(d._progress_hooks) == 1
   

# Generated at 2022-06-24 11:34:04.809643
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    # Arrange
    def calc_eta(total_bytes, start, now=None, current=0):
        # Act
        time.sleep(2)
        # Assert
        return FileDownloader.calc_eta(total_bytes, start, now, current)
    assert calc_eta(1000, time.time()) is None
    assert calc_eta(1000, 0) is None

test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_eta()
test_FileDownloader_calc_

# Generated at 2022-06-24 11:34:11.958116
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('42') == 42
    assert FileDownloader.parse_bytes('42k') == 42 * 1024
    assert FileDownloader.parse_bytes('42K') == 42 * 1024
    assert FileDownloader.parse_bytes('42m') == 42 * 1024 * 1024
    assert FileDownloader.parse_bytes('42M') == 42 * 1024 * 1024
    assert FileDownloader.parse_bytes('42g') == 42 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('42G') == 42 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('42x') is None



# Generated at 2022-06-24 11:34:21.165042
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 1024) == 1024
    assert fd.best_block_size(10, 1024) == 1024
    assert fd.best_block_size(1024 / 4, 1024) == 256
    assert fd.best_block_size(1024 / 2, 1024) == 512
    assert fd.best_block_size(1024, 1024) == 1024
    assert fd.best_block_size(2 * 1024, 1024) == 1024
    assert fd.best_block_size(4 * 1024, 1024) == 2048
    assert fd.best_block_size(1024 * 1024, 1024) == 4194304
    assert fd.best_block_size(1024 * 1024 * 1024, 1024) == 4194304
    assert fd.best_block_

# Generated at 2022-06-24 11:34:23.873969
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    fd = FileDownloader({})
    assert fd.report_destination('foo') == 'foo'


# Generated at 2022-06-24 11:34:32.757091
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    fd = FileDownloader({})
    assert fd.calc_percent(0, 0) == 0
    assert fd.calc_percent(0, 1) == 0
    assert fd.calc_percent(1, 0) == 100
    assert fd.calc_percent(1, 1) == 100
    assert fd.calc_percent(1000, 1001) == 99.9
    assert fd.calc_percent(1000, 9001) == 99.9
    assert fd.calc_percent(0, 0, 1000) == 0
    assert fd.calc_percent(0, 1, 1000) == 0
    assert fd.calc_percent(1, 0, 1000) == 100
    assert fd.calc_percent(1, 1, 1000) == 100

# Generated at 2022-06-24 11:34:39.221993
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    dl = FileDownloader({})
    assert dl.ytdl_filename("test.txt") == "test.txt.ytdl"
    assert dl.ytdl_filename("test.txt.part") == "test.txt.part.ytdl"

test_FileDownloader_ytdl_filename()


# Generated at 2022-06-24 11:34:42.563941
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    """
    Test method to_stderr of class FileDownloader
    """
    f = FileDownloader(params = {})
    # Call method to_stderr of class FileDownloader
    f.to_stderr("test")
    return
test_FileDownloader_to_stderr() # Execute method

 

# Generated at 2022-06-24 11:34:45.178565
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(10.3) == '10'



# Generated at 2022-06-24 11:34:55.488392
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    def _test(b, e, c, expected):
        actual = FileDownloader.best_block_size(b, e, c)
        assert expected == actual, '%s != %s: %s %s %s (actual: %s)' % (expected, actual, b, e, c, FileDownloader.best_block_size(b, e, c))

    _test(0, 1, 1, 2)
    _test(0, 1, 2, 2)
    _test(-1, 1, 2, 2)
    _test(-1, 0.5, 2, 1)
    _test(-1, 0, 2, 1)
    _test(0, -1, 1, 1)



# Generated at 2022-06-24 11:35:05.322417
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    test_cases = {
        0: '  0.0%',
        1: '  0.1%',
        10: '  1.0%',
        100: '100.0%',
        101: '100.5%',
        102: '101.0%',
        999: '999.5%',
        1000: '999.9%',
        1001: '999.9%',
        1010: '999.9%',
        float('inf'): '999.9%',
    }
    for inp, outp in test_cases.items():
        assert FileDownloader.format_percent(inp) == outp


# Generated at 2022-06-24 11:35:16.284161
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    global fd

    start_time = None

    def get_time():
        global start_time
        if start_time is None:
            return 0
        return time.time() - start_time

    def my_sleep(seconds):
        global fd
        fd.time_sleep(seconds)

    fd = FileDownloader(None, params={'verbose': True})
    fd.report_progress = lambda s: None
    fd.to_screen = lambda s: None

    fd.time_sleep = my_sleep
    fd.get_time = get_time

    def slow_down(byte_counter):
        global start_time, fd
        start_time = time.time()
        fd.slow_down(start_time, start_time, byte_counter)

    # Test if sleeping

# Generated at 2022-06-24 11:35:23.537068
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    downloader = FileDownloader(None)
    assert downloader.calc_percent(1, 100) == 1
    assert downloader.calc_percent(99, 100) == 99
    assert downloader.calc_percent(100, 100) == 100
    assert downloader.calc_percent(50,100) == 50
    assert downloader.calc_percent(1000, 100) == 1000

test_FileDownloader_calc_percent()


# Generated at 2022-06-24 11:35:27.706702
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    import youtube_dl.YoutubeDL
    class MockYoutubeDL(youtube_dl.YoutubeDL.YoutubeDL):
        def __init__(self, params):
            self._params = params
        def report_error(self, *args, **kargs):
            pass
    ydl = MockYoutubeDL({'verbose': True, 'logger': MockYoutubeDL})
    fd = FileDownloader({}, ydl)
    fd.report_error('something happened')
    assert(len(msg.args[0]) > 0)
    fd = FileDownloader({'verbose': True, 'logger': MockYoutubeDL}, ydl)
    fd.report_error('something different happened')
    assert(len(msg.args[0]) > 0)

# Generated at 2022-06-24 11:35:39.671673
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('2M') == 2 * 1024 ** 2
    assert FileDownloader.parse_bytes('3 G') == 3 * 1024 ** 3
    assert FileDownloader.parse_bytes('4.5  TB') == 4.5 * 1024 ** 4

    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('-1') is None
    assert FileDownloader.parse_bytes('-1k') is None
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('a') is None
    assert FileDownloader.parse_bytes('1a') is None
    assert FileDownloader.parse_bytes

# Generated at 2022-06-24 11:35:51.691410
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fobj = FileDownloader({})

# Generated at 2022-06-24 11:36:04.597751
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    from youtube_dl.YoutubeDL import YoutubeDL

    class FileDownloaderMock(FileDownloader):

        def __init__(self):
            self.ydl = YoutubeDL({})
            self.params = {}

    fd = FileDownloaderMock()

    # Test for normal return
    fd.report_destination('test')
    assert open(get_temp_file_name(extension='test')).read() == '\n'
    os.remove(get_temp_file_name(extension='test'))

    # Test that it doesn't crash
    fd.report_destination('test\ntest')
    assert open(get_temp_file_name(extension='test\ntest')).read() == '\n'

# Generated at 2022-06-24 11:36:08.754078
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    # test function defined in class FileDownloader. All attributes
    # set to default values
    YDL = YoutubeDL()
    filename = 'default filename' # test filename
    downloader = FileDownloader(YDL, {'filename': filename} )
    downloader.report_unable_to_resume()


# Generated at 2022-06-24 11:36:10.976718
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader()
    assert(fd.to_stderr('message') == fd.to_screen('message'))

# Generated at 2022-06-24 11:36:19.536486
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test for calc_speed
    # Test for calc_speed when rate=0
    assert(FileDownloader.calc_speed(0, 0, 0) is None)

    # Test for calc_speed when rate=1
    assert(FileDownloader.calc_speed(0, 1, 1) == 1)

    # Test for calc_speed when rate=0.5
    assert(FileDownloader.calc_speed(0, 1, 0.5) == 0.5)

    # Test for calc_speed when rate=0.5, dif=1.5
    assert(FileDownloader.calc_speed(0, 1.5, 0.5) == 0.5)

    # Test for calc_speed when rate=0.5, dif=0.5

# Generated at 2022-06-24 11:36:23.828655
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(None)
    for resume_len in [None, 0, 12345, 12121121212]:
        fd.report_resuming_byte(resume_len)
test_FileDownloader_report_resuming_byte()


# Generated at 2022-06-24 11:36:28.680479
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd = FileDownloader('')
    def _ph(status):
        pass
    fd.add_progress_hook(_ph)
    assert _ph in fd._progress_hooks, 'progress hook not called'

# Generated at 2022-06-24 11:36:37.778629
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    test_args = {
    "test_msg": "verbose more than zero",
    "test_msg1": "verbose less than zero",
    "test_msg2": "verbose is zero"
    }

# Generated at 2022-06-24 11:36:42.113418
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    expected_msg = 'an error has occurred'
    retries = 1
    count = 1

    class TestFileDownlader(FileDownloader):
        '''A FileDownloader class that stores the last error msg'''
        def to_screen(self, msg, skip_eol=False):
            self.last_to_screen_msg = msg

    test_FD = TestFileDownlader(None, {'verbose': True})
    test_FD.report_retry(expected_msg, count, retries)
    assert test_FD.last_to_screen_msg == '[download] Got server HTTP error: an error has occurred. Retrying (attempt 1 of inf)...'

# Generated at 2022-06-24 11:36:52.239528
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class MockFD(object):
        def __init__(self):
            self.lines = []

        def to_screen(self, line):
            self.lines.append(line)

        def pprint_lines(self):
            return '\n'.join(self.lines)

    filename = 'foo'
    err = Exception('HTTP Error')
    max_retries = 5

    fd = MockFD()
    fd1 = FileDownloader(fd, DummyYoutubeDL())
    fd1.report_retry(err, 1, max_retries)
    assert fd.pprint_lines() == (
        '[download] Got server HTTP error: HTTP Error. '
        'Retrying (attempt 1 of 5)...'
    )

    fd = MockFD()

# Generated at 2022-06-24 11:37:02.391034
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader('FakeYdl').format_retries(float("inf")) == 'inf'
    assert FileDownloader('FakeYdl').format_retries(0) == '0'
    assert FileDownloader('FakeYdl').format_retries(1) == '1'
    assert FileDownloader('FakeYdl').format_retries(7) == '7'
    assert FileDownloader('FakeYdl').format_retries(13) == '13'
    assert FileDownloader('FakeYdl').format_retries(3.0) == '3'
    assert FileDownloader('FakeYdl').format_retries(5.5) == '5'
    # ensure that format_retries() returns str and not int
    assert type(FileDownloader('FakeYdl').format_retries(3)) == compat_str


# Generated at 2022-06-24 11:37:15.537193
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-24 11:37:24.292484
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader()
    assert fd.calc_eta(1000, 18, None) == (18, (1, 1))
    assert fd.calc_eta(1000, 100, 18) == (18, (1, 1))
    assert fd.calc_eta(1000, 0, 0) == (None, (1, 1))
    assert fd.calc_eta(1000, 0, 100) == (None, (1, 1))
    assert fd.calc_eta(1000, 100, 100) == (0, (1, 1))

    assert fd.calc_eta(10, 0, 100) == (None, (1, 10))

    assert fd.calc_eta(None, 100, 0) == (None, (1, 1))
    assert fd.calc_

# Generated at 2022-06-24 11:37:31.679020
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    import tempfile
    test_trouble_messages = [('error message', 'ERROR: error message'),
                             ('remark message', 'ERROR: remark message')]
    test_trouble0_messages = [('error message', 'ERROR: error message',
                               'ERROR: error message')]

    for (message, expected) in test_trouble_messages:
        sio = StringIO()
        fd = FileDownloader({'outtmpl': '-'}, {}, sio)
        fd.trouble(message)
        assert sio.getvalue() == expected + '\n'

    # verbose specified
    fd = FileDownloader({'outtmpl': '-', 'verbose': True}, {'fulltitle': 'video'}, None)

# Generated at 2022-06-24 11:37:35.545590
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fname = "file"
    fd = FileDownloader({'continuedl': True, 'nopart': False}, None)
    fd.report_unable_to_resume()



# Generated at 2022-06-24 11:37:45.738248
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    file_path = os.path.join(temp_dir, 'foo.txt')
    file_handle = open(file_path, 'w')
    file_handle.write('foobar')
    file_handle.close()

    # Create FileDownloader object
    fd = FileDownloader({})
    # Set last modified header containing a valid date
    last_modified_hdr = 'Sat, 08 Aug 2015 15:53:44 GMT'
    # Set last modified time of temporary file
    fd.try_utime(file_path, last_modified_hdr)

    # Get last modified time and verify it

# Generated at 2022-06-24 11:37:50.567468
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    import io
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(dict())
    fd = FileDownloader(ydl, {}, {})
    fd.to_screen = lambda s: _print_to('screen', s)
    fd.report_destination('foo')
    assert _get_printed_lines() == ['[download] Destination: foo']



# Generated at 2022-06-24 11:38:00.569257
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    class Test_FileDownloader1(FileDownloader):
        """Test FileDownloader"""
        def __init__(self, ydl, params):
            super(Test_FileDownloader1, self).__init__(ydl, params)
            self.info_dict = {}
            self.filename = ''
            self.status = {}

        def real_download(self, filename, info_dict):
            self.info_dict = info_dict
            self.filename = filename
            return False

        def _debug_cmd(self, args):
            self.status['params'] = self.params
            self.status['args'] = args

        def report_warnings(self, warnings):
            self.status['warnings'] = warnings

        def report_error(self, msg):
            self.status['error'] = msg


# Generated at 2022-06-24 11:38:06.166028
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader({}, FakeYDL(), None)
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(2) == '2'

    assert fd.report_retry(None, 1, float('inf')) == None
    assert fd.report_retry(None, 1, 2) == None

# Test unit for method format_eta of class FileDownloader

# Generated at 2022-06-24 11:38:14.816026
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    for speed_int in range(500000):
        # Test for all int
        assert(FileDownloader.format_speed(speed_int) == '%10s' % ('%s/s' % format_bytes(speed_int)))

# Generated at 2022-06-24 11:38:23.785602
# Unit test for method report_resuming_byte of class FileDownloader

# Generated at 2022-06-24 11:38:34.836382
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 100) is None
    assert fd.calc_eta(0, 100, 0) == float('inf')
    assert fd.calc_eta(0, 100, 100) == float('inf')
    assert fd.calc_eta(100, 0, 0) is None
    assert fd.calc_eta(100, 0, 100) is None
    assert fd.calc_eta(100, 100, 0) == 0
    assert fd.calc_eta(100, 100, 100) == 0
    assert fd.calc_eta(0, 100, 10) == 10

# Generated at 2022-06-24 11:38:43.323162
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {})

    # Test to verify that it is printed correctly
    fd.to_stderr('test')
    assert sys.stderr.getvalue() == 'test\n'

    # Test to verify that it is printed correctly the error in utf-8
    fd.to_stderr(error_to_compat_str(UnicodeEncodeError('ascii', '', 0, 0, 'test')))
    assert sys.stderr.getvalue() == 'test\ntest\n'

# Generated at 2022-06-24 11:38:54.589145
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(FatalPagedYoutubeDL({}), {})

    # No information provided
    assert fd.calc_eta(None, None, None, None) is None

    # Time left unknown
    assert fd.calc_eta(10, None, 1, None) is None
    assert fd.calc_eta(None, 20, 1, None) is None

    # Should take 10 seconds
    assert fd.calc_eta(0, 0, 10, 10) == 10

    # Download started 1 second ago
    assert fd.calc_eta(10, 0, 1, 1) == 10

    # Download started 10 seconds ago
    assert fd.calc_eta(10, 0, 1, 10) == 90

    # Download completed 50% ago
    assert fd.calc_eta

# Generated at 2022-06-24 11:39:04.833455
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # class FileDownloader:
    # def report_resuming_byte(self, resume_len):
    # """Report attempt to resume at given byte."""
    # self.to_screen('[download] Resuming download at byte %s' % resume_len)

    # Test case 1
    fd = FileDownloader(FakeYDL())
    fd.to_screen = Mock()
    resume_len = '11111'
    fd.report_resuming_byte(resume_len)
    fd.to_screen.assert_called_once_with(
        '[download] Resuming download at byte ' + resume_len)

    # Test case 2
    fd = FileDownloader(FakeYDL())
    fd.to_screen = Mock()
    resume_len = 11111
    fd.report_resuming

# Generated at 2022-06-24 11:39:16.541138
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    fd = FileDownloader({})
    assert fd
    assert fd.ydl is fd
    assert not fd.params.get('outtmpl')
    assert fd.params.get('verbose') == False
    assert fd.params.get('ratelimit') == None
    assert fd.params.get('nooverwrites') == False
    assert fd.params.get('continuedl') == True
    assert fd.params.get('noprogress') == False
    assert fd.params.get('logger') == fd.to_screen
    assert not hasattr(fd, '_err_file')
    assert not hasattr(fd, '_out_file')

    fd = FileDownloader({'outtmpl': 'outtmpl'})
    assert fd

# Generated at 2022-06-24 11:39:22.392430
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader(YoutubeDL({'logger': SimpleLogger()}), {})
    assert_equals('', fd.ydl.to_stderr_output.getvalue())
    for i in range(5):
        fd.to_console_title('test %d' % i)



# Generated at 2022-06-24 11:39:27.675638
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader({'verbose': True})
    fd.to_stderr('Hello world')
    fd.to_stderr('Hello world 2')
fd.to_stderr('Hello world 3')

test_FileDownloader_to_stderr()


# Generated at 2022-06-24 11:39:36.534226
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    """
    Test report_warning method of class FileDownloader
    """
    class FakeYoutubeDl(object):

        def __init__(self):
            self.count = 0

        def to_screen(self, string):
            if string == 'WARNING: unable to set Taikonyan status code':
                self.count += 1

    fd = FileDownloader(FakeYoutubeDl())
    fd.report_warning('WARNING: unable to set Taikonyan status code')
    fd.report_warning('WARNING: unable to set Taikonyan status code')
    assert fd.ydl.count == 1


# Generated at 2022-06-24 11:39:41.503526
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Just test if it's doing anything at all
    class Hook(object):
        def __init__(self):
            self.called = False

        def __call__(self, status):
            self.called = True

    fd = FileDownloader({})
    h = Hook()
    fd.add_progress_hook(h)
    fd._hook_progress({})
    assert h.called



# Generated at 2022-06-24 11:39:52.245388
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """
    Unit test for FileDownloader.download() method
    """
    class MockYoutubeDL(object):
        def __init__(self, params):
            self.params = params

        def to_screen(self, message):
            pass

        def to_console_title(self, message):
            pass

        def trouble(self, message, tb):
            raise Exception(message)

        def report_warning(self, message):
            pass

        def report_error(self, message):
            pass


    class MockFileDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, MockYoutubeDL(params))

        def real_download(self, filename, info_dict):
            # TODO: more tests on info_dict
            return True


   

# Generated at 2022-06-24 11:39:59.656532
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(YoutubeDL(), {'nopart': False, 'continuedl': True, 'logger': YoutubeDL().logger})
    returnCode = 0
    for i in range(0,1):
        if(fd.undo_temp_name('/')!='/'):
            returnCode = 1
            break
        if(fd.undo_temp_name('/test.txt.part')!='/test.txt'):
            returnCode = 1
            break
        if(fd.undo_temp_name('C:\\test.txt.part')!='C:\\test.txt'):
            returnCode = 1
            break
        if(fd.undo_temp_name('C:\\test.txt.part.part')!='C:\\test.txt'):
            returnCode = 1
           

# Generated at 2022-06-24 11:40:04.571416
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd = FileDownloader(
        params={},
        ydl=FakeYDL(),
        progress_hooks=[],
    )
    fd.add_progress_hook(lambda x: None)
    assert fd._progress_hooks

# Generated at 2022-06-24 11:40:15.097628
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    # Create downloader
    downloader = FileDownloader({})
    # Create DummyYdl
    class DummyYdl():
        def __init__(self):
            self.trouble = []
            self.message = []
        def to_screen(self, msg):
            self.message.append(msg)
        def trouble(self, msg):
            self.trouble.append(msg)
    dummy_ydl = DummyYdl()
    downloader.ydl = dummy_ydl
    # Test
    downloader.report_error('foo')
    assert len(dummy_ydl.trouble) == 1
    assert len(dummy_ydl.message) == 1
    assert dummy_ydl.message[0] == 'foo'
    assert dummy_ydl.trouble[0]

# Generated at 2022-06-24 11:40:21.574669
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # Test case 1
    f = FileDownloader(params = {}, info_dict = {})
    f.report_resuming_byte(4444)
    assert "4444" in f.to_screen_buffer[0]
    f.to_screen_buffer = []
    # Test case 2
    f.report_resuming_byte(int('4444'))
    assert "4444" in f.to_screen_buffer[0]

# Generated at 2022-06-24 11:40:28.262413
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader()
    fd.to_screen = lambda x: x
    fd.report_error = lambda *args: None
    temp_file = u'temppp'
    file_name = u'fileee'
    f = open(temp_file, 'w').close()
    fd.try_rename(temp_file, file_name)
    assert_false(os.path.exists(temp_file))
    assert_true(os.path.exists(file_name))
    os.remove(file_name)



# Generated at 2022-06-24 11:40:40.366907
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    class fake_console:
        def __init__(self):
            self.last_title = None

        def set_title(self, title):
            self.last_title = title

    class fake_FileDownloader:
        def __init__(self, console=None):
            self.ydl = None
            if console is None:
                self.console = fake_console()
            else:
                self.console = console

    class fake_youtube_dl:
        def __init__(self):
            self.params = {}

    class fake_ydl:
        def __init__(self):
            self.params = {}
            self.to_screen = None

    # test without console
    fd = fake_FileDownloader()
    assert fd.console.last_title is None
    fd.to_console_

# Generated at 2022-06-24 11:40:50.783012
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('test.part') == 'test'
    assert FileDownloader.undo_temp_name('test.partt') == 'test.partt'
    assert FileDownloader.undo_temp_name('test.downtest.part') == 'test.downtest'
    assert FileDownloader.undo_temp_name('test.downtest.parttt') == 'test.downtest.parttt'
    assert FileDownloader.undo_temp_name('test.downtest.parttt.part') == 'test.downtest.parttt'
    assert FileDownloader.undo_temp_name('test.part.part') == 'test'
    assert FileDownloader.undo_temp_name('test.part.part.part') == 'test'
    assert FileDownloader.undo_

# Generated at 2022-06-24 11:41:00.222923
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    ydl = YoutubeDL(YoutubeDL())
    ydl.params = {}
    ydl.to_screen = lambda *args, **kargs: None
    ydl.to_stderr = lambda *args, **kargs: None
    ydl.process_info = lambda *args: None
    ydl.report_error = lambda *args: None
    ydl.report_warning = lambda *args: None
    ydl.report_destination = lambda *args: None
    downloader = FileDownloader(ydl, {}, None)
    downloader.to_screen = lambda *args, **kargs: None
    downloader.to_stderr = lambda *args, **kargs: None
    downloader.report_progress = lambda *args: None
    downloader.report_resuming_byte = lambda *args: None

# Generated at 2022-06-24 11:41:06.197348
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    downloader = FileDownloader(params={'ydl_offline':False})
    class Markout(object):
        def __init__(self):
            self.output = ''
        def write(self,s):
            self.output+=s
    m = Markout()
    downloader.to_screen = m.write
    downloader.report_unable_to_resume()
    assert m.output == '[download] Unable to resume\n'

# Generated at 2022-06-24 11:41:18.170794
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(params={})
    assert fd.best_block_size(1.0, 10240) == 4194304
    assert fd.best_block_size(1.0, 10240) == 4194304
    assert fd.best_block_size(1.0, 1) == 4194304
    assert fd.best_block_size(0.1, 10240) == 10240
    assert fd.best_block_size(0.1, 10240) == 10240
    assert fd.best_block_size(0.1, 1) == 4194304
    assert fd.best_block_size(0.01, 10240) == 5120
    assert fd.best_block_size(0.001, 10240) == 2560
    assert fd.best_block_

# Generated at 2022-06-24 11:41:23.123843
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    log.setLevel(logging.DEBUG)
    t = time.time()
    size = 0
    while time.time() - t < 10:
        size += 1024 * 1024 / 16
        FileDownloader.slow_down(t, time.time(), size)
        log.debug("Rate: %s" % FileDownloader.calc_speed(t, time.time(), size))
        time.sleep(0.1)

if __name__ == '__main__':
    test_FileDownloader_slow_down()

# Generated at 2022-06-24 11:41:29.843710
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    from .extractor import get_info_extractor
    from .extractor.http import HttpIE

    # Prepare the test
    compat_urllib_request.urlopen = lambda url, data=None: FakeSocket('''HTTP/1.0 200 OK\r\nContent-Length: 47\r\nContent-Type: text/plain\r\nLast-Modified: Fri, 06 Jul 2012 06:46:37 GMT\r\n\r\nThis is the file content''')
    ydl = YoutubeDL()
    ydl.params['quiet'] = True
    ydl.params['logger'] = DummyLogger()
    ydl._ies = [get_info_extractor(HttpIE.ie_key())]

# Generated at 2022-06-24 11:41:39.609148
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():

    fd = FileDownloader({})

    print(fd.format_eta(0))
    print(fd.format_eta(1))
    print(fd.format_eta(60))
    print(fd.format_eta(1000))
    print(fd.format_eta(3600))
    print(fd.format_eta(3601))
    print(fd.format_eta(36000))
    print(fd.format_eta(360000))  # 100 hours
    print(fd.format_eta(3600000))  # 1000 hours
    print(fd.format_eta(36000000))  # 10000 hours
    print(fd.format_eta(315360000))  # 10000 hours in a year


# Generated at 2022-06-24 11:41:43.119999
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    # Call the method with the file name as parameter
    fd.report_file_already_downloaded('test.mp4')

# Generated at 2022-06-24 11:41:52.641072
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(
        params={'nopart': True},
        outtmpl='foo',
        progress_hooks=[])
    assert 'foo' == downloader.temp_name('foo')

    downloader = FileDownloader(
        params={},
        outtmpl='foo',
        progress_hooks=[])
    assert 'foo.part' == downloader.temp_name('foo')
    downloader = FileDownloader(
        params={},
        outtmpl='foo.%(ext)s',
        progress_hooks=[])
    assert 'foo.part' == downloader.temp_name('foo.bar')
    assert 'foo.bar.part' == downloader.temp_name('foo.bar.baz')
