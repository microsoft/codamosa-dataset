

# Generated at 2022-06-24 11:31:56.110481
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    pass


# Generated at 2022-06-24 11:32:09.042963
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    ydl = YoutubeDL({'ratelimit': 100})
    fd = FileDownloader(ydl, {'url': 'http://localhost/'})
    fd.start_time = time.time() - 1
    fd.last_downloaded_bytes = 100
    time.sleep(1)  # Let's say it took one second
    fd.slow_down(fd.start_time, time.time(), 100)  # Should not sleep
    fd.last_downloaded_bytes = 200
    time.sleep(1)  # Sleep one more second
    fd.slow_down(fd.start_time, time.time(), 200)  # Should sleep one second
    fd.last_downloaded_bytes = 400
    time.sleep(1)

# Generated at 2022-06-24 11:32:12.528217
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    cal = FileDownloader()
    # ETA for test case when elapsed time = 0 or downloaded bytes = 0
    print(cal.calc_eta(0, 0, 1))
    print(cal.calc_eta(1, 0, 1))
    # ETA for normal case
    print(cal.calc_eta(1, 2, 10))



# Generated at 2022-06-24 11:32:18.881926
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Create a test downloader
    fd = FileDownloader(DownloaderParams())
    p_hooks = []
    fd.add_progress_hook(lambda x: p_hooks.append(x))
    # Test if the progress_hooks is working as expected
    fd._hook_progress('dummy')
    if len(p_hooks) != 1:
        raise Exception('Test for add_progress_hook of class FileDownloader has failed.')

# Generated at 2022-06-24 11:32:28.653009
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    test_inputs = [
        (0, '0:00'),
        (1, '0:01'),
        (30, '0:30'),
        (60, '1:00'),
        (120, '2:00'),
        (3600, '1:00:00'),
        (3601, '1:00:01'),
        (86399, '23:59:59'),
        (86400, '1 day, 0:00:00'),
        (86401, '1 day, 0:00:01'),
        (90061, '1 day, 1:00:01'),
        (864000, '10 days, 0:00:00'),
        (1728000, '20 days, 0:00:00'),
        (31536001, '1 year, 0:00:01'),
    ]
   

# Generated at 2022-06-24 11:32:41.309304
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from ytdl_info_cache import ytdl_info_cache_get
    from ytdl_info_extractor import ytdl_extractor_apply_info_dict
    def _hook_progress(status):
        print('progress: %s' % status)

    def _download(filename, info_dict):
        print('downloading "%s"' % filename)
        return True

    file_dler = FileDownloader()
    info_dict = ytdl_extractor_apply_info_dict(
        ytdl_info_cache_get(
            'http://www.youtube.com/watch?v=BaW_jenozKc'),
        {})

    file_dler.add_progress_hook(_hook_progress)
    file_dler.real_download = _download
    assert file_dler

# Generated at 2022-06-24 11:32:43.086927
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None)
    assert fd.best_block_size(1.0, 12345) == 4192

# Generated at 2022-06-24 11:32:53.279117
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    test_cases = [
        # dlnow, dltotal, res
        (10, 10, 100.0),  # The only downlaod 100% done
        (0, 10, 0.0),  # The only 0% download
        (None, 10, 0.0),  # A download with a total size and no current
        (10, None, None)  # A download with no total size and a current one
    ]
    fd = FileDownloader(None, {})
    passed = True
    for dlnow, dltotal, res in test_cases:
        obtained = fd.calc_percent(dlnow, dltotal)

# Generated at 2022-06-24 11:32:58.046726
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    """
    Test if 'FileDownloader.try_rename' method gives proper result.
    """
    fd = FileDownloader({})
    fd.report_error = lambda *args, **kargs: None
    filename_old = os.path.join(os.path.dirname(__file__), "test.txt")
    filename_new = os.path.join(os.path.dirname(__file__), "test_tmp.txt")
    # Check if 'test.txt' file exists.

# Generated at 2022-06-24 11:33:09.330338
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    ydl = FileDownloader({})
    tests = [
        [ydl.temp_name('filename'), 'filename'],
        [ydl.temp_name('filename.ext'), 'filename.ext'],
        [ydl.temp_name('filename.ext'), 'filename.ext.part'],
        [ydl.temp_name('filename.ext.part'), 'filename.ext.part'],
        [ydl.temp_name('filename.ext.part'), 'filename.ext.part.part'],
    ]
    for i, t in enumerate(tests):
        assert t[0] == t[1], 'Test #%d: %r != %r' % (i + 1, t[0], t[1])


# Generated at 2022-06-24 11:33:17.885350
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    from ytdl_filedownloader import FileDownloader
    fd = FileDownloader(None, None)

    def test_pair(secs, eta_str):
        assert fd.format_eta(secs) == eta_str

    test_pair(0, "00:00")
    test_pair(1, "00:01")
    test_pair(59, "00:59")
    test_pair(60, "01:00")
    test_pair(119, "01:59")
    test_pair(3599, "59:59")
    test_pair(3600, "01:00:00")
    test_pair(3601, "01:00:01")
    test_pair(7199, "01:59:59")

# Generated at 2022-06-24 11:33:29.657162
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Testing this function is tricky (it invokes os.utime and cannot be tested
    # directly in a non-Unix platform).
    #
    # Here is the general idea:
    #
    # * We create an output file and write some text on it.
    # * Then, we create a FileDownloader instance and call its try_utime
    # * method with the name of the output file.
    # * Finally, we check that the file modification time has changed.
    #
    # Notice that the test will be skipped if outputFile is not present in
    # the working dir.
    outputFile = 'out_filename'
    if (not os.path.exists(outputFile)):
        raise Exception(
            "This test requires that the file 'out_filename' exists in the working directory.")

# Generated at 2022-06-24 11:33:39.786739
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encode_compat_str, format_bytes, format_time
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from pytest import raises

    def testmethod():
        pass

    ydl = YoutubeDL(None)
    ydl.to_screen = testmethod
    ydl.report_error = testmethod
    ydl.trouble = testmethod
    ydl.report_warning = testmethod
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['ignoreerrors'] = False
    ydl.params['verbose'] = False
    ydl.params['quiet'] = False
    ydl.params['simulate'] = False
    ydl.params['forceduration'] = False


# Generated at 2022-06-24 11:33:44.564836
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader()

    assert fd.calc_speed(10, 20, 0) is None
    assert fd.calc_speed(10, 20, 5) == 0.5  # 5 bytes / 10 secs
    assert fd.calc_speed(10, 15, 10) == 1  # 10 bytes / 5 secs
    assert fd.calc_speed(10, 15, 5) == 0.5  # 5 bytes / 5 secs


# Generated at 2022-06-24 11:33:55.228046
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {'continuedl': True})
    fd.to_screen('hello')
    fd.to_screen('hello %s' % 'world')
    fd.to_screen(u'hello %s' % u'world')
    fd.to_screen(u'héllo %s' % u'world')
    fd.to_screen(u'héllo'),
    fd.to_screen(u'héllo', skip_eol=True)
    fd.to_screen(u'héllo', skip_eol=True),
    fd.to_screen(u'héllo', skip_eol=True),
    fd.to_

# Generated at 2022-06-24 11:33:59.539079
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    x = FileDownloader(FakeYoutubeDl())
    x.to_screen = lambda s: s
    x.report_warning("This is a warning")
    x.report_warning("This is a %(name)s", {'name': 'warning'})

# Generated at 2022-06-24 11:34:07.493510
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc'
    fd.params['nopart'] = True
    assert fd.temp_name('abc') == 'abc'
    assert fd.temp_name('/a/b/c') == '/a/b/c'
    assert fd.temp_name('./a/b/c') == './a/b/c'
    fd.params['nopart'] = False
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('/a/b/c') == '/a/b/c.part'
    assert fd.temp_name('./a/b/c') == './a/b/c.part'



# Generated at 2022-06-24 11:34:16.892776
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader(YoutubeDL({'quiet': True, 'forceurl': True, 'forcetitle': True, 'forcefilename': True, 'forcethumbnail': True, 'forceduration': True, 'format': 'best', 'outtmpl': '%(id)s.%(ext)s'}))
    fd.to_screen('Example file downloaded')
    assert fd.ydl.params['outtmpl'] == '%(id)s.%(ext)s'


# Generated at 2022-06-24 11:34:25.305850
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    from YoutubeDL import YoutubeDL
    from Downloader import Downloader
    from FileDownloader import FileDownloader
    from fake_filesystem_unittest import TestCase
    import sys
    import sys
    import sys
    class MyFileDownloader(FileDownloader):
        def __init__(self, ydl):
            FileDownloader.__init__(self, ydl)
            self.fd = open('/dev/null', 'wb')

        def to_screen(self, msg):
            sys.__stdout__.write(msg + '\n')

        def temp_name(self, filename):
            return '/tmp/t'

        def report_destination(self, filename):
            pass

        def real_download(self, filename, info_dict):
            pass


# Generated at 2022-06-24 11:34:31.332883
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    """
    Logic of the method will be tested
    """
    ##############
    # Test case 1
    ##############
    # Input parameters
    filename = "D:/Download/3.mp3"

    # Expected value
    expected_value = None

    # Create object
    downloader = FileDownloader({})

    # Execute function
    return_value = downloader.report_destination(filename)

    # Validating test case
    assert return_value is None

# Generated at 2022-06-24 11:34:44.042496
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    import shutil
    from .YoutubeDL import YoutubeDL
    from .utils import encodeFilename, decodeFilename
    ydl = YoutubeDL()
    fd = FileDownloader(ydl)
    assert '__test_FileDownloader_try_rename' not in os.listdir('.')
    try:
        fd.try_rename('__test_FileDownloader_try_rename', '__test_FileDownloader_try_rename_2')
        assert False, 'File not present, but no exception raised'
    except (IOError, OSError) as err:
        assert 'No such file' in str(err) or 'No such file' in decodeFilename(err.filename)

# Generated at 2022-06-24 11:34:55.946509
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """Test various methods of class FileDownloader"""
    import pytest

    # Create our own FileDownloader subclass with the real_download method
    # mocked to generate a mock-file
    class MockFD(FileDownloader):
        def real_download(self, filename, info_dict):
            # Generate a mock file
            fs = io.BytesIO(b'foo')
            fs.name = filename
            fsize = len(fs.getvalue())
            self._hook_progress({
                'downloaded_bytes': fsize,
                'total_bytes': fsize,
                'filename': filename,
                'status': 'finished',
            })
            return fs

    # ======================================================
    # Test if download generates a correct temporary filename
    fd_no_temp = MockFD({})
    fd_no_temp.params

# Generated at 2022-06-24 11:35:05.863548
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test conflicts
    # --------------
    # Test invalid file
    # -----------------
    # Test valid file
    # ---------------
    # Test invalid timestr
    fd = FileDownloader(FakeYDL(), {})

    try:
        assert fd.try_utime('no-such-file', 'thundercats') == None
    except (IOError, OSError) as err:
        print(err)
        assert False

    try:
        assert fd.try_utime('test_try_utime.txt', 'thundercats') == None
    except (IOError, OSError) as err:
        print(err)
        assert False

    assert fd.try_utime('test_try_utime.txt', '20151006') == timeconvert('20151006')

   

# Generated at 2022-06-24 11:35:10.986703
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    tests = [
        #(total, amount, percent)
        (1000000, 1, 0),
        (1000000, 0, 0),
        (1000000, 500000, 50),
        (1000000, 1000000, 100),
    ]
    for total, amount, perc in tests:
        assert FileDownloader.calc_percent(total, amount) == perc


# Ugly hack to handle broken pipes (playlist downloader)
# (TODO: maybe rewrite all that thing properly to handle exceptions, if needed)

# Generated at 2022-06-24 11:35:14.478501
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader()
    fd.report_unable_to_resume()
    actual = fd.ydl.screen_data
    assert actual[0].endswith('Unable to resume')


# Generated at 2022-06-24 11:35:24.294487
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fake_to_screen = []
    def fake_to_screen_append(a):
        fake_to_screen.append(a)
    fd = FileDownloader(FakeInfoExtractor(), params={'sleep_interval':0.1,
                                                     'nooverwrites':True,
                                                     'continuedl':True,
                                                     'nopart':False,
                                                     'verbose':False})
    fd.to_screen = fake_to_screen_append
    fd.report_unable_to_resume()
    assert (fake_to_screen ==
            [u'[download] Unable to resume'])

# Generated at 2022-06-24 11:35:26.807925
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader()
    fd.report_unable_to_resume()
    assert True


# Generated at 2022-06-24 11:35:34.770968
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader({})
    assert fd.format_seconds(1) == '0:01'
    assert fd.format_seconds(5) == '0:05'
    assert fd.format_seconds(10) == '0:10'
    assert fd.format_seconds(60) == '1:00'
    assert fd.format_seconds(60 * 2) == '2:00'

    assert fd.format_seconds(60 * 60) == '1:00:00'
    assert fd.format_seconds(60 * 60 * 2) == '2:00:00'
    assert fd.format_seconds(60 * 60 * 2 + 2) == '2:00:02'

# Generated at 2022-06-24 11:35:44.014633
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    filenames = ('abc', 'abc.part', 'abc.part.tmp',)
    temp_names = ('abc.part', 'abc.part.1', 'abc.part.2',)
    for filename in filenames:
        for temp_name in temp_names:
            fd = FileDownloader({})
            fd.to_screen = lambda msg: None
            fd.report_error = lambda msg: None
            if isinstance(filename, bytes):
                filename = filename.decode('utf-8')
            if isinstance(temp_name, bytes):
                temp_name = temp_name.decode('utf-8')
            assert fd.temp_name(filename) == temp_name

    # test undo_temp_name
    fd = FileDownloader({})

# Generated at 2022-06-24 11:35:47.526722
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # type: (str) -> None
    """Test for method to_console_title of class FileDownloader"""
    fd = FileDownloader(None, None)
    fd.to_console_title("hello")

# Generated at 2022-06-24 11:35:56.330487
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(YoutubeDL())
    assert fd.parse_bytes(None) is None
    assert fd.parse_bytes('1234') == 1234
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1234k') == 1234 * 1024
    assert fd.parse_bytes('1M') == 1024 ** 2
    assert fd.parse_bytes('1G') == 1024 ** 3
    assert fd.parse_bytes('1T') == 1024 ** 4
    assert fd.parse_bytes('1P') == 1024 ** 5
    assert fd.parse_bytes('1E') == 1024 ** 6
    assert fd.parse_bytes('1Z') == 1024 ** 7
    assert fd.parse_bytes('1Y') == 1024 ** 8

# Unit

# Generated at 2022-06-24 11:36:07.827858
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader = FileDownloader()
    assert file_downloader.parse_bytes('-1024') == None
    assert file_downloader.parse_bytes('a-1024') == None
    assert file_downloader.parse_bytes('a-1024b') == None
    assert file_downloader.parse_bytes('1024-b') == None
    assert file_downloader.parse_bytes('1024b') == 1024
    assert file_downloader.parse_bytes('1024k') == 1024 * 1024
    assert file_downloader.parse_bytes('1024m') == 1024 * 1024 * 1024
    assert file_downloader.parse_bytes('1024g') == 1024 * 1024 * 1024 * 1024
    assert file_downloader.parse_bytes('1024t') == 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-24 11:36:09.654824
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    FileDownloader.to_stderr("Hello")
    assert(True)


# Generated at 2022-06-24 11:36:16.901371
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})

    assert fd.format_speed(0) == '%10s' % '---b/s'
    assert fd.format_speed(None) == '%10s' % '---b/s'
    assert fd.format_speed(.1) == '%10s' % '100b/s'
    assert fd.format_speed(50) == '%10s' % '50.0KiB/s'
    assert fd.format_speed(5000) == '%10s' % '4.9MiB/s'


# Generated at 2022-06-24 11:36:20.182754
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(None, fake_params)
    fd.to_screen = lambda msg: msg
    assert fd.report_resuming_byte(123) == '[download] Resuming download at byte 123'


# Generated at 2022-06-24 11:36:29.203524
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    """Unit test for method format_percent of class FileDownloader"""

    assert FileDownloader.format_percent(None) == '  0%'
    assert FileDownloader.format_percent(0.0) == '  0%'
    assert FileDownloader.format_percent(0.01) == '  0%'
    assert FileDownloader.format_percent(0.01234) == '  1%'
    assert FileDownloader.format_percent(0.09999) == ' 10%'
    assert FileDownloader.format_percent(0.10) == ' 10%'
    assert FileDownloader.format_percent(0.10001) == ' 10%'
    assert FileDownloader.format_percent(0.12345) == ' 12%'

# Generated at 2022-06-24 11:36:38.025750
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():

    #Testing without unicode support
    downloader = FileDownloader(YoutubeDL())
    old_title = os.getenv('TERM_TITLE')
    downloader.to_console_title('Unicode')

    # Tests if title is the same as the message
    assert os.getenv('TERM_TITLE') == 'Unicode'

    # Tests if title is the same as the previous title
    downloader.to_console_title('Unicode')
    assert os.getenv('TERM_TITLE') == 'Unicode'

    # Tests if the title is cleared
    downloader.to_console_title('')
    #assert os.getenv('TERM_TITLE') == ''
    assert os.getenv('TERM_TITLE') == 'Unicode'


# Generated at 2022-06-24 11:36:50.025138
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():


    def fd_download(filename, info_dict):
        return True

    def fd_report_debug(msg):
        return None

    fd = FileDownloader(progress_hooks=['fd_report_debug'])
    fd.fd_report_debug = fd_report_debug
    fd.real_download = fd_download

    fd.params['nooverwrites'] = True
    fd.params['continuedl'] = False

    filename = 'filename'

    assert fd.download(filename, {}) == True

    fd.params['nooverwrites'] = False
    fd.params['continuedl'] = True

    assert fd.download(filename, {}) == True

    fd.params['nooverwrites'] = True

# Generated at 2022-06-24 11:37:00.630682
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """Test cases for method download of class FileDownloader."""
    try:
        import http.client
    except ImportError:  # Python 2
        import httplib as http_client

    socket_socket = socket.socket

    # Mock socket.socket to make it return a MOCK_SOCKET on connect
    def socket_mock_connect(family, type, proto):
        return MOCK_SOCKET

    MOCK_SOCKET = mock.MagicMock()

    BAD_SERVER_REPLY = "HTTP/1.0 500 Internal Server Error\n\n"
    GOOD_SERVER_REPLY = "HTTP/1.0 200 OK\nFoo: Bar\n\n"

    # Mock socket.socket to return a known packet for each recv

# Generated at 2022-06-24 11:37:12.337999
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    global tmpfilename
    tmpfd, tmpfilename = mkstemp(prefix='youtubedl-test-trouble-')
    os.close(tmpfd)

    fd = FileDownloader({})
    fd.to_screen = lambda s: None
    del os.environ['http_proxy']
    del os.environ['https_proxy']

    e = MaxDownloadsReachedError()
    fd.trouble(e.msg, e.args)

    e = UnavailableVideoError()
    fd.trouble(e.msg, e.args)

    e = MaxFileSizeExceededError()
    fd.trouble(e.msg, e.args)

    e = FileNotFoundError()
    fd.trouble(e.msg, e.args)


# Generated at 2022-06-24 11:37:24.348450
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    fd = FileDownloader({})
    fd.params['outtmpl'] = '%(title)s'
    fd.params['title'] = 'filename.mp4'
    fd.report_destination() == "[download] Destination: filename.mp4"
    fd.params['outtmpl'] = None
    fd.report_destination() == "[download] Destination: filename.mp4"
    fd.params['outtmpl'] = '%(title)s.%(ext)s'
    fd.params['ext'] = 'mkv'
    fd.report_destination() == "[download] Destination: filename.mp4.mkv"
    fd.params['autonumber_size'] = 3

# Generated at 2022-06-24 11:37:33.664449
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, {}, None)
    assert fd.calc_eta(0, 0, 100, 0) is None
    assert fd.calc_eta(0, 0, 0, 0) is None
    assert fd.calc_eta(1, 0, 100, 1) is None
    assert fd.calc_eta(1, 1, 100, 0) is None
    assert fd.calc_eta(1, 1, 100, 100) is None
    assert fd.calc_eta(2, 1, 100, 100) is None
    assert fd.calc_eta(2, 1, 100, 50) is None
    assert fd.calc_eta(2, 1, 50, 100) is None

# Generated at 2022-06-24 11:37:37.722952
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    assert FileDownloader.ytdl_filename('foo') == 'foo.ytdl'
    assert FileDownloader.ytdl_filename('foo.bar.ytdl') == 'foo.bar.ytdl'


# Generated at 2022-06-24 11:37:41.458971
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test exceptions
    # Test assertion
    # Test normal use cases
    # Test special cases
    assert True 

# Generated at 2022-06-24 11:37:42.891491
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    FileDownloader.to_console_title("Hola")



# Generated at 2022-06-24 11:37:47.131996
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():

    # Start
    print('Testing FileDownloader.format_percent()')

    # Setup
    file_downloader = FileDownloader({})
    assert file_downloader.format_percent(None) == 'Unknown %'
    assert file_downloader.format_percent(3.1415926) == '3.1%'
    assert file_downloader.format_percent(300) == '300%'

    # End
    print('FileDownloader.format_percent()')



# Generated at 2022-06-24 11:37:55.111326
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader(None)

    for inf in [float('inf'), float('infinity'), float('-inf'), float('-infinity')]:
        assert fd.format_retries(inf) == 'inf'
    if hasattr(float, 'is_integer') and float('inf').is_integer():
        assert fd.format_retries(float('inf')) == 'inf', 'is_integer() but not is_infinite()'
        assert fd.format_retries(float('-inf')) == 'inf', 'is_integer() but not is_infinite()'

    assert fd.format_retries(0.0) == '0'
    assert fd.format_retries(1.0) == '1'

# Generated at 2022-06-24 11:38:07.480186
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    #test for 2 methods; to_screen, to_stderr, format_time
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    stdout = sys.stdout = io.BytesIO()
    stderr = sys.stderr = io.BytesIO()

    fd = FileDownloader({})
    fd.to_screen('hello stdout')
    fd.to_stderr('hello stderr')
    sys.stdout = orig_stdout
    sys.stderr = orig_stderr
   
    print(stdout)
    print(stderr)
    
    assert stdout.getvalue().decode('utf-8') == 'hello stdout\n'
    assert stderr.getvalue().decode('utf-8')

# Generated at 2022-06-24 11:38:15.626829
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    print()
    print("* Testing FileDownloader try_rename")
    fd = FileDownloader({}, YDL())
    fd.ydl.to_screen = printer
    fd.ydl.report_error = printer
    #Method try_rename requires encodeFilename() to be added
    def encodeFilename(filename):
        return filename
    # File not exist, try to rename: no error
    fd.ydl.to_screen('File exist: %s' % (os.path.isfile('testFile_1.txt')))
    fd.try_rename('testFile_1.txt', 'testFile_2.txt')
    # File exist, try to rename: no error

# Generated at 2022-06-24 11:38:26.706508
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    ydl = FakeYtdl({})
    fd = FileDownloader(ydl, {})
    fd.report_warning('warning')
    assert ydl.msgs == ['[warning] warning']
    fd.report_warning('warning with format', {'a': str})
    assert ydl.msgs == ['[warning] warning with format a']
    fd.report_warning('warning with format', {'a': 'A'}, '%s')
    assert ydl.msgs == ['[warning] warning with format A']
    fd.report_warning('warning with format', {'a': 'A'}, '%s')
    assert ydl.msgs == ['[warning] warning with format A']
    ydl = FakeYtdl({'verbose': True})

# Generated at 2022-06-24 11:38:34.220695
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # test if report_warning is working
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl)
    fd.report_warning('warn')
    if len(ydl._warned_about) == 1:
        if 'warn' in ydl._warned_about:
            fd.report_warning('warn')
            if len(ydl._warned_about) == 1:
                if 'warn' in ydl._warned_about:
                    return True
    return False


# Generated at 2022-06-24 11:38:41.218289
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader({})
    assert fd.format_seconds(1) == '00:01'
    assert fd.format_seconds(10) == '00:10'
    assert fd.format_seconds(60) == '01:00'
    assert fd.format_seconds(3600) == '01:00:00'
    assert fd.format_seconds(360000) == '100:00:00'


# Generated at 2022-06-24 11:38:44.138581
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    f = FileDownloader({})
    f.to_screen = lambda s: s
    f.report_resuming_byte(1)
    print("[test] report_resuming_byte: Success")


# Generated at 2022-06-24 11:38:54.910100
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():

    # Check that the error message is written to standard output for the first
    # five errors
    for retry_count in range(5):
        ydl = FakeYoutubeDl()
        test_fd = FileDownloader(ydl, {'nooverwrites': True})
        test_fd.report_retry(
            IOError('test error'), retry_count, retries=float('inf'))
        assert len(ydl.msgs) == 1
        assert ydl.msgs[0] == 'Got server HTTP error: test error. Retrying (attempt %d of inf)...' % (retry_count + 1)
        ydl.msgs = []
    # Check that no error message is written to standard output for more than
    # five errors
    for retry_count in range(5, 10):
        y

# Generated at 2022-06-24 11:38:58.459087
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader(None)
    try:
        fd.to_console_title('Downloading ')
    except NotImplementedError:
        pass


# Generated at 2022-06-24 11:39:06.635748
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0.5) == '50%'

if __name__ == '__main__':
# Unit tests for method format_eta of class FileDownloader
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(None) == 'Unknown ETA'
# Unit tests for method format_seconds of class FileDownloader
    assert FileDownloader.format_seconds(60) == '01:00'
    assert FileDownloader.format_seconds(1) == '00:01'
    assert FileDownloader.format_seconds(3600) == '1:00:00'


# Generated at 2022-06-24 11:39:16.158349
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def calc_speed(fdl, start, now, bytes):
        return fdl.calc_speed(start, now, bytes)

    fdl = FileDownloader({})
    assert calc_speed(fdl, 0.0, 0.0, 0) is None
    assert calc_speed(fdl, 1.0, 2.0, 10) == 5.0
    assert calc_speed(fdl, 0.0, 2.0, 10) == 5.0
    assert calc_speed(fdl, 0.0, 2.0, 0) is None
    assert calc_speed(fdl, 0.0, 0.0, 10) is None



# Generated at 2022-06-24 11:39:25.391273
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    from YoutubeDL import YoutubeDL
    ydl=YoutubeDL()
    fd=FileDownloader(ydl, {}, {}, {})
    # Method report_error with only one parameter
    fd.report_error("This is an error")
    # Method report_error with too few parameters
    with pytest.raises(TypeError):
        fd.report_error()
    # Method report_error with too many parameters
    with pytest.raises(TypeError):
        fd.report_error("This is an error", "This is another error")
    # Method report_error with incompatible type as parameter
    with pytest.raises(TypeError):
        fd.report_error(b"This is an error")


# Generated at 2022-06-24 11:39:30.873204
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    fd = FileDownloader(params={'outtmpl': '%(id)s.%(ext)s'})
    assert fd.ydl is fd

    fd = FileDownloader(
        ydl=MockYDL(), params={'outtmpl': '%(id)s.%(ext)s'})
    assert fd.ydl is not fd

# Generated at 2022-06-24 11:39:41.158347
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def _get_status():
        return {
            'downloaded_bytes': 11,
            'total_bytes': 30,
            'eta': None,
            'status': 'downloading',
            'speed': 400,
            'elapsed': 10,
            'filename': 'video.mp4'
        }
    ok_(FileDownloader.report_progress({}) is None)
    td = FileDownloader({'noprogress': True})
    ok_(td.report_progress(_get_status()) is None)
    for noprogress in (False, True):
        # testing that report_progress does not raise error with noprogress True
        for st in ('downloading', 'finished'):
            # TODO test 'finished' status
            td = FileDownloader({'noprogress': noprogress})
           

# Generated at 2022-06-24 11:39:50.500743
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    from .YoutubeDL import YoutubeDL
    from .utils import DateRange
    fd = FileDownloader({
        'format': '22/worst/18/best/best',
        'outtmpl': '%(id)s.%(ext)s',
        'nooverwrites': True,
        'continuedl': True,
        'noprogress': False,
        'logger': YoutubeDL(DateRange('fake'),params={})})
    assert 'Unknown %' == fd.format_percent(None)
    assert 'Unknown %' == fd.format_percent(None, 100)
    assert '100%' == fd.format_percent(100, 100)
    assert '100%' == fd.format_percent(100, 101)

# Generated at 2022-06-24 11:39:56.666349
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    def second_downloaded_hook(d):
        raise Exception('Forced failure')
    def first_downloaded_hook(d):
        d.add_progress_hook(second_downloaded_hook)

    ydl = FakeYDL()
    ydl.params = {'nooverwrites': True}
    fd = FileDownloader(ydl, {'id': 'testid'})
    fd.add_progress_hook(first_downloaded_hook)
    fd.report_destination('testtarget')
    fd.try_rename('src', 'dst')
    fd.report_retry('e', 2, 20)
    fd.to_screen('text')
    fd.report_progress({'status': 'finished', 'total_bytes': 10, 'elapsed': None})


# Generated at 2022-06-24 11:40:03.004228
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import stat
    import pytest
    from io import BytesIO
    from collections import namedtuple
    import subprocess

    """

    Test effect of various parameters on FileDownloader.download() method

    """

    pytestmark = pytest.mark.usefixtures('mkdtemp')

    if os.name != 'nt':
        pytest.xfail(reason='failing on windows')

    tmpdir = os.getcwd()

    # Namedtuple to hold a test case
    TestCase = namedtuple('TestCase', 'params test_filename expected_filename')

    # Test cases for download() method

    # The "cwd" parameter is not used in the tests here

# Generated at 2022-06-24 11:40:12.554704
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    ydl = FileDownloader(YoutubeDl(), {'logger': YoutubeDlLogger()})
    ydl.to_screen('test %s %d %f' % ('string', 1, 2.0))
    ydl.to_screen('%%(percent)s %(percent)s')
    ydl.to_screen('%%(bad)s %(bad)s')
    ydl.to_screen('%%a %a')
    ydl.to_screen('%(bad', '%(bad')
    ydl.to_screen()
    ydl.to_screen(None)
    ydl.to_screen('\n')
    ydl.to_screen('%s\r\r')



# Generated at 2022-06-24 11:40:20.657842
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader(FakeYDL(), {})
    assert fd.format_percent(0) == '  0%'
    assert fd.format_percent(0.0) == '  0%'
    assert fd.format_percent(1) == '  1%'
    assert fd.format_percent(0.01) == '  1%'
    assert fd.format_percent(0.001) == '  0%'
    assert fd.format_percent(0.499) == '  0%'
    assert fd.format_percent(0.5) == '  1%'
    assert fd.format_percent(0.99) == ' 99%'
    assert fd.format_percent(0.9999) == ' 99%'

# Generated at 2022-06-24 11:40:25.664072
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    print('Attempting unit test')
    try:
        expected_output = 'Resuming download at byte 5'
        actual_output = FileDownloader.report_resuming_byte(None, 5)
        print(actual_output)
        assert expected_output == actual_output
        print('Unit test success')
    except AssertionError:
        print('Unit test fail')

# Generated at 2022-06-24 11:40:36.941703
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    from unittest.case import TestCase

    class TestFormatSpeed(TestCase):
        def testIt(self):
            fd = FileDownloader({})
            self.assertEqual('%10s' % ('%s/s' % format_bytes(4)), fd.format_speed(4))
            self.assertEqual('%10s' % ('%s/s' % format_bytes(8)), fd.format_speed(8))
            self.assertEqual('%10s' % ('%s/s' % format_bytes(1024)), fd.format_speed(1024))
            self.assertEqual('%10s' % ('%s/s' % format_bytes(2**10)), fd.format_speed(2**10))

# Generated at 2022-06-24 11:40:44.313094
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print('TEST: FileDownloader_report_progress()')
    import sys
    sleep(1)
    filename = '-'
    FD = FileDownloader(None, filename)
    s = {}
    s['status'] = 'downloading'
    s['total_bytes'] = 100000
    s['downloaded_bytes'] = 100000
    s['elapsed'] = 10
    s['speed'] = None
    FD.report_progress(s)
    s['status'] = 'finished'
    FD.report_progress(s)
    s['status'] = 'downloading'
    s['downloaded_bytes'] = 5000
    FD.report_progress(s)
    # Expected : ' 100% of 100000 at Unknown speed ETA Unknown ETA'
    # ' [download] Download completed
    # ' 60% of 100

# Generated at 2022-06-24 11:40:47.201503
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    yd = FileDownloader({})
    
    yd.ytdl_filename('a')

# Generated at 2022-06-24 11:40:54.407357
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    info_dict = {}
    params = {'outtmpl': '%(extractor)s-%(id)s.%(ext)s'}
    ydl = object()
    before = FileDownloader(ydl,params)
    assert(before.params == params)
    assert(before.ydl ==ydl)
    assert(before.params["outtmpl"] =='%(extractor)s-%(id)s.%(ext)s')
    before.report_unable_to_resume()


# Generated at 2022-06-24 11:41:01.712430
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('a.part') == 'a'
    assert FileDownloader.undo_temp_name('a.part.part') == 'a.part'
    assert FileDownloader.undo_temp_name('a.part') == 'a'
    assert FileDownloader.undo_temp_name('a.part.b') == 'a.part.b'
    assert FileDownloader.undo_temp_name('a.part.b.part') == 'a.part.b'

# Generated at 2022-06-24 11:41:14.003537
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('abc') is None
    assert FileDownloader.parse_bytes('  1') is None
    assert FileDownloader.parse_bytes('1   ') is None
    assert FileDownloader.parse_bytes('1.2') is None
    assert FileDownloader.parse_bytes('1 2') is None
    assert FileDownloader.parse_bytes('-1') is None
    assert FileDownloader.parse_bytes('-1.2') is None
    assert type(FileDownloader.parse_bytes('1')) is int
    assert type(FileDownloader.parse_bytes('-1k')) is int
    assert type(FileDownloader.parse_bytes('1k')) is int

# Generated at 2022-06-24 11:41:18.061970
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    fd = TestFileDownloader({})
    fd.slow_down(10, 11, 11)
    fd.set_params({'ratelimit':10})
    fd.slow_down(10, 11, 11)

# Generated at 2022-06-24 11:41:25.212148
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    """
    Unit test for parse_bytes()
    """
    pb = FileDownloader.parse_bytes

    assert pb('0') == 0
    assert pb('1') == 1
    assert pb('1.4') == 1
    assert pb('1.6') == 2
    assert pb('1.6k') == 1664
    assert pb('1.6M') == 1664 * 1024
    assert pb('1.6G') == 1664 * 1024 * 1024

    try:
        pb('a')
    except:
        pass
    else:
        assert False

    try:
        pb('1.6Q')
    except:
        pass
    else:
        assert False

# Generated at 2022-06-24 11:41:36.974999
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def ret_progress(dummy1, dummy2, dummy3):
        return {'elapsed_time': 10,
                'total_bytes': 1e6,
                'downloaded_bytes': 5e5,
                'speed': 1e5}

    class FakeYDL:
        def __init__(self, downloader):
            self.downloader = downloader
        def to_screen(self, *args, **kargs):
            pass
        def to_console_title(self, *args, **kargs):
            pass
        def trouble(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
        def report_warning(self, *args, **kargs):
            pass
        def add_progress_hook(self, ph):
            ph

# Generated at 2022-06-24 11:41:40.331168
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    for stderr in ['dummy_stderr', None]:
        fd = FileDownloader(params={'stderr': stderr})
        assert fd.params['stderr'] == stderr

# Generated at 2022-06-24 11:41:47.009856
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    expected_output = 'ERROR: Unable to download webpage: <urlopen error [Errno 111] Connection refused>'
    output = StringIO()
    fd = FileDownloader(params={'format': 'best'})
    fd.to_screen = lambda s: output.write(s + '\n')
    fd.report_error('Unable to download webpage: <urlopen error [Errno 111] Connection refused>')

    assert expected_output == output.getvalue().strip(), 'Failed to report error'


# Generated at 2022-06-24 11:41:48.260787
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(1) == '1%'


# Generated at 2022-06-24 11:41:54.502899
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert 'inf' == FileDownloader.format_retries(float('inf'))
    assert '2' == FileDownloader.format_retries(2.0)
    assert '1' == FileDownloader.format_retries(1.0)
    assert '1' == FileDownloader.format_retries(1.5)
    assert '1' == FileDownloader.format_retries(1.9)

# =========================== #

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:41:57.349804
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    ydl = YoutubeDL(params={})
    fd = FileDownloader(ydl, {})
    assert fd.report_resuming_byte(10) == None
    print("test_FileDownloader_report_resuming_byte passed successfully")
    return True
