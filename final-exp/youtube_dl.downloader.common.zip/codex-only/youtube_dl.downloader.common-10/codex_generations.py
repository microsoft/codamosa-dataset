

# Generated at 2022-06-24 11:32:05.416775
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    from ytdl_fnmatch import fnmatch


# Generated at 2022-06-24 11:32:10.958482
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    import pprint
    import random
    download_files = [
        ('http://example.com/index.html', 'index.html'),
        ('http://example.com/index.html', 'index.html'),
        ('http://example.com/index.html', 'index.html'),
        ('http://example.com/index.html', 'index.html'),
        ]

    class MyFD(FileDownloader):
        def real_download(filename, info_dict):
            self.trouble(filename, info_dict)
            return False

    myFD = MyFD()
    myFD.params['outtmpl'] = '%(id)s'
    myFD.params['noprogress'] = True
    myFD.params['retries'] = 10

    # Create a fake ytdl object

# Generated at 2022-06-24 11:32:16.854621
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FileDownloader({'continuedl': True, 'format': 'best', 'outtmpl': '%(id)s-%(title)s.%(ext)s'}, YoutubeDL())
    return fd



# Generated at 2022-06-24 11:32:22.668504
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    ydl = MockYDL()
    dl = FileDownloader(ydl, {})
    assert dl.ytdl_filename('foo') == 'foo.ytdl'
    assert dl.ytdl_filename('foo bar') == 'foo bar.ytdl'
    assert dl.ytdl_filename('foo bar.ytdl') == 'foo bar.ytdl'
    assert dl.ytdl_filename('foo bar.ytdl.ytdl') == 'foo bar.ytdl.ytdl'
    assert dl.ytdl_filename('foo.bar') == 'foo.bar.ytdl'
    assert dl.ytdl_filename('.foo') == '.foo.ytdl'

# Generated at 2022-06-24 11:32:31.037635
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def test(str, expect):
        got = FileDownloader.parse_bytes(str)
        if got != expect:
            raise ValueError(
                'Invalid value returned for parse_bytes(%r)' % str)

    test('', None)
    test('foobar', None)
    test('1', 1)
    test('0', 0)
    test('-1', None)
    test('1.1', None)
    test('1024', 1024)
    test('1000', 1000)
    test(' 1 KB ', 1024)
    test('1.5', None)
    test(' 1.5 KB ', 1536)
    test('2KB', 2048)
    test('2.5KB', 2560)
    test('1MB', 1048576)
    test('1.5MB', None)

# Generated at 2022-06-24 11:32:36.196505
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '0:00:00'
    assert FileDownloader.format_eta(1) == '0:00:01'
    assert FileDownloader.format_eta(2) == '0:00:02'
    assert FileDownloader.format_eta(60) == '0:01:00'
    assert FileDownloader.format_eta(61) == '0:01:01'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(360000) == '100:00:00'
    assert FileDownloader.format_eta(None) == '--:--'



# Generated at 2022-06-24 11:32:42.611502
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    file_downloader = FileDownloader(None)

    assert eq(file_downloader.undo_temp_name("test"), "test")
    assert eq(file_downloader.undo_temp_name("test.part"), "test")
    assert eq(file_downloader.undo_temp_name("test.txt.part"), "test.txt")
    assert eq(file_downloader.undo_temp_name("test.abc.def.part"), "test.abc.def")
    assert eq(file_downloader.undo_temp_name("test.part.part"), "test.part")
    assert eq(file_downloader.undo_temp_name("test.part.txt.part"), "test.part.txt")


__all__ = ['FileDownloader']


# Generated at 2022-06-24 11:32:50.047340
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test case 0 - rate limit = 50000 and speed = 70000. So no sleep
    # duration = 5 secs elapsed time = 2 secs current bytes = 7000000
    # start time = 1 secs
    test_case_0 = {
        'ratelimit': 50000,
        'elapsed': 2.0,
        'speed': 70000.0,
        'start_time': 1.0,
        'current': 7000000,
    }

    # Test case 1 - rate limit = 50000 and speed = 40000. So sleep duration
    # duration = 1 sec elapsed time = 5 secs current bytes = 2000000
    # start time = 0 secs

# Generated at 2022-06-24 11:32:52.251356
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Temp name is a random temp file path
    assert os.path.isabs(FileDownloader(None).temp_name('abc'))



# Generated at 2022-06-24 11:33:00.325991
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    f = FileDownloader({'nopart': True})
    assert f.temp_name('f') == 'f'
    assert f.temp_name('f.txt') == 'f.txt'
    assert f.temp_name('f.mp4') == 'f.mp4'
    assert f.temp_name('f.f.f') == 'f.f.f'

    f = FileDownloader({'nopart': False, 'outtmpl': 'f.mp4'})
    assert f.temp_name('f') == 'f.part'
    assert f.temp_name('f.txt') == 'f.txt.part'
    assert f.temp_name('f.mp4') == 'f.mp4.part'

# Generated at 2022-06-24 11:33:06.250652
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    print('test_FileDownloader_calc_speed')
    assert FileDownloader.calc_speed(0, 0, 0) is None
    assert FileDownloader.calc_speed(0, 0.001, 2) == 2000
    assert FileDownloader.calc_speed(0, 10, 10) == 1

# Generated at 2022-06-24 11:33:14.750143
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    # Verify that format_eta produces a string in the format HH:MM:SS
    seconds = 20
    time_str = FileDownloader.format_eta(seconds)
    assert(re.search('^[0-9][0-9]:[0-9][0-9]:[0-9][0-9]$', time_str))
    while seconds >= 60:
        assert time_str[0] == '0'
        seconds = seconds / 60
        time_str = time_str[1:]
    assert time_str[0] != '0'

# Generated at 2022-06-24 11:33:20.156692
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    ydl = FileDownloader({})
    assert ydl.best_block_size(0.0, 10) == 2
    assert ydl.best_block_size(0.0, 1) == 1
    assert ydl.best_block_size(0.0, 1024) == 1024
    assert ydl.best_block_size(0.0, 10 ** 20) == 4194304
    assert ydl.best_block_size(1.0, 1048576) == 4194304


# Generated at 2022-06-24 11:33:30.041598
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-24 11:33:36.575386
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    """Unit test for method report_resuming_byte of class FileDownloader """
    file_obj = io.StringIO()
    downloader = FileDownloader({
        'outtmpl': '%(id)s',
        'verbose': True,
    }, {}, False, file_obj)
    downloader.report_resuming_byte(1)
    assert file_obj.getvalue() == '[download] Resuming download at byte 1\n'



# Generated at 2022-06-24 11:33:39.939794
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'}, None)
    fd.slow_down(time.time(), time.time(), 1024)
    fd.slow_down(time.time(), time.time(), 1024)



# Generated at 2022-06-24 11:33:51.678696
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.version import __version__
    from youtube_dl.utils import DownloadError
    ydl = YoutubeDL({'cachedir' : False, 'nocheckcertificate' : True})
    fd = FileDownloader(ydl, {})
    fd.report_error('An error message', True)
    fd.report_error('Another error message', True)
    fd.report_error('An error message again', False)
    fd.report_error('Another error message again', False)
    fd.report_error(DownloadError('test error'), True)

# Generated at 2022-06-24 11:33:55.993450
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # Test for method real_download of class FileDownloader
    FileDownloader.real_download([], [])



# Generated at 2022-06-24 11:34:05.220826
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '0.00%'
    assert FileDownloader.format_percent(0.1) == '0.10%'
    assert FileDownloader.format_percent(0.01) == '0.01%'
    assert FileDownloader.format_percent(0.001) == '0.00%'
    assert FileDownloader.format_percent(0.05) == '0.05%'
    assert FileDownloader.format_percent(3.141592653) == '3.14%'
    assert FileDownloader.format_percent(99.9) == '99.90%'
    assert FileDownloader.format_percent(100) == '100.00%'
    assert FileDownloader.format_percent(100.0) == '100.00%'

# Generated at 2022-06-24 11:34:10.463788
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader({})

    assert(fd.format_seconds(1) == '00:01')
    assert(fd.format_seconds(10) == '00:10')
    assert(fd.format_seconds(60) == '01:00')
    assert(fd.format_seconds(3600) == '01:00:00')
    assert(fd.format_seconds(3601) == '01:00:01')
    assert(fd.format_seconds(36000) == '10:00:00')


# Generated at 2022-06-24 11:34:22.809705
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """
    this functions tests if real_download method behaves as expected
    """

# Generated at 2022-06-24 11:34:28.410095
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    fd = FileDownloader({'extract-audio':True})
    fd.to_screen = lambda *args:args
    assert fd.report_destination('song.mp3') == (
        "[download] Destination: song.mp3")
    assert fd.report_destination('"cool song.mp3"') == (
        "[download] Destination: \"cool song.mp3\"")


# Generated at 2022-06-24 11:34:41.646505
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # setup
    from types import ModuleType
    from io import BytesIO
    import sys
    import tempfile
    import youtube_dl

    def null_hook(*args):
        pass

    def info_dict():
        return {
            'title': 'video title',
            'id': 'video_id',
            'url': 'video_url',
            'ext': 'mp4',
            'webpage_url': 'videopage.url',
            'ie_key': 'Youtube',
            'fulltitle': 'video title',
        }

    def get_cwd():
        return tempfile.mkdtemp()

    def get_fd(*args, **kwargs):
        return BytesIO(b'video contents')

    def download(filename, info_dict):
        assert isinstance(filename, str)


# Generated at 2022-06-24 11:34:46.981039
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # pylint: disable=missing-docstring
    dler = FileDownloader({'logger': DummyLogger()})
    dler.report_warning('test')
    assert dler.logger.msgs == ['WARNING: test']
    dler.report_warning('test %s %s', 'a', 'b')
    assert dler.logger.msgs == ['WARNING: test a b']


# Generated at 2022-06-24 11:34:55.766562
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl=YoutubeDL()
    fd=FileDownloader(ydl=ydl)
    #to get the method
    dll=fd.__class__.__dict__
    for key,value in dll.items():
        if key=='try_rename':
            s=value
    if s is not None:
        if  not hasattr(s,'__call__'):
            s=None
    if s is not None:
        assert s('a','b') is not None
    else:
        assert s is not None

# Generated at 2022-06-24 11:35:06.245386
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    def test_report_error_func(ydl):
        # Check that errors are reported
        assert ydl.report_error('foo bar') == True
        # Check that no errors are reported
        assert ydl.report_error('foo bar', False) == None
        # Check that fatal errors are raised
        try:
            ydl.report_error('foo bar', True)
        except Exception as e:
            assert True
        # Check that no fatal error is raised
        try:
            ydl.report_error('foo bar', False, True)
        except Exception as e:
            assert True
    # Prepare YoutubeDL object for unit test
    ydl = YoutubeDL({'logger': MockLogger()})
    # Call unit test
    test_report_error_func(ydl)


# Generated at 2022-06-24 11:35:09.846943
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    fd = FileDownloader({})
    with patch('youtube_dl.downloader.common.Warning.format_warning', return_value='test message'):
        fd.report_warning('test warning')


# Generated at 2022-06-24 11:35:19.178497
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # FileDownloader.best_block_size tests #1
    assert FileDownloader.best_block_size(0.0, 0) is 4194304

    # FileDownloader.best_block_size tests #2
    assert FileDownloader.best_block_size(0.0, 1) is 4194304

    # FileDownloader.best_block_size tests #3
    assert FileDownloader.best_block_size(0.0, -1) is 1

    # FileDownloader.best_block_size tests #4
    assert FileDownloader.best_block_size(0.0, 10) is  4194304

    # FileDownloader.best_block_size tests #5
    assert FileDownloader.best_block_size(0.0, 100) is  4194304

    # FileDownloader.best_

# Generated at 2022-06-24 11:35:24.049907
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    print("test report_file_already_downloaded of class FileDownloader")
    result = URLDownloader_Class.report_file_already_downloaded('test_file')
    assert result == None
    

# Generated at 2022-06-24 11:35:29.443712
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'outtmpl': '%(format_id)s.flv'})

    test_input = [
        ('foo.flv', 'foo.flv.ytdl'),
        ('foo.flv.part', 'foo.flv.part.ytdl'),
        ('%(format_id)s.flv', '%(format_id)s.flv.ytdl'),
        ('%(format_id)s.flv.part', '%(format_id)s.flv.part.ytdl'),
    ]


# Generated at 2022-06-24 11:35:39.876935
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    ydl = YoutubeDL()
    # in order to make this test work, the report_destination function has to be
    # removed from the YoutubeDL class, since it will override the stub
    del ydl.report_destination
    fd = FileDownloader(ydl, {'progress_with_newline': False})
    fd.report_destination('foo')
    fd.report_destination('foo.part')
    fd.report_destination('foo.ytdl')
    fd.report_destination('bar')
    fd.report_destination('bar.part')
    fd.report_destination('bar.ytdl')


# Generated at 2022-06-24 11:35:51.930870
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    from io import BytesIO
    from urllib.parse import parse_qs
    from .YoutubeDL import YoutubeDL

    y = YoutubeDL({'quiet': True, 'progress_with_newline': True})

    data = {'status': 'finished', 'filename': 'abc.mp3', 'total_bytes': 15}

    class FakeHttpResponse(object):

        def info(self):
            return parse_qs('Content-Length: 15')

    class FakeOpener(object):

        def open(self, request, timeout=None):
            return FakeHttpResponse()

    y.add_progress_hook(lambda status: data.update(status))

    fd = FileDownloader(y, {'test': 'http://example.com'}, {})

    fd.report_destination('abc.mp3')
    fd

# Generated at 2022-06-24 11:36:04.782429
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    class DummyYtdl(object):
        def __init__(self):
            self.trouble = lambda *args, **kargs: None

    # Test for UnicodeEncodeError
    try:
        from urllib2 import URLError
    except ImportError:
        from urllib.error import URLError
    try:
        from urlparse import urljoin
    except ImportError:
        from urllib.parse import urljoin
    try:
        from urllib2 import HTTPError
    except ImportError:
        from urllib.error import HTTPError

# Generated at 2022-06-24 11:36:14.092793
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    import json
    xd = FileDownloader({})
    assert xd.calc_percent(100, 100) == 100
    assert xd.calc_percent(100, 50) == 50
    assert xd.calc_percent(100, 200) == 200
    assert xd.calc_percent(100, 0) == 0
    assert xd.calc_percent(100, -1) == -1
    assert xd.calc_percent(100, 'a') == 0
    assert xd.calc_percent(100, '') == 0
    assert xd.calc_percent(1.1, 1.1) == 100
    assert xd.calc_percent(1.0, 1.1) == 110


# Generated at 2022-06-24 11:36:21.054261
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta((None, None, None)) is None
    assert fd.calc_eta((None, None, 0)) is None
    assert fd.calc_eta((None, None, float('inf'))) is None
    assert fd.calc_eta((None, -1.0, None)) is None
    assert fd.calc_eta((None, 0.0, None)) is None
    assert fd.calc_eta((None, 1.0, None)) is None
    assert fd.calc_eta((None, float('inf'), None)) is None
    assert fd.calc_eta((None, -1.0, 0)) is None
    assert fd.calc_eta((None, 0.0, 0)) is None
   

# Generated at 2022-06-24 11:36:24.540193
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    print("test_FileDownloader_report_error")
    fd = FileDownloader({})
    fd.add_progress_hook = lambda a: a
    fd.report_error('test_error')
    

# Generated at 2022-06-24 11:36:35.433566
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Initialize downloader
    downloader = FileDownloader(params={'noprogress': False})

    # Initialize test object
    class TestClass:
        def __init__(self):
            self.counter = 0

        def test_function(self, status):
            self.counter += 1

    test_object = TestClass()

    # Register function
    downloader.add_progress_hook(test_object.test_function)

    # Check basic progress call
    downloader.report_progress({'status': 'downloading'})
    assert(test_object.counter == 1)

    # Check that new line is only printed to stderr if
    # progress_with_newline is True
    downloader.report_progress({'status': 'finished'})
    assert(test_object.counter == 2)

    # Check

# Generated at 2022-06-24 11:36:47.072977
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    from .utils import date_from_str
    from .compat import compat_http_client
    from .CompatPatch import ClientCookie
    from .CompatPatch import ClientForm

    fd, fname = tempfile.mkstemp()
    os.close(fd)

    metadata = {
        'date': 'Tue, 06 Dec 2016 17:00:00 GMT',
    }

    fd = FileDownloader({'continuedl': True, 'nooverwrites': True}, FakeYDL())
    fd.try_utime(fname, metadata['date'])

    ftime1 = os.stat(encodeFilename(fname)).st_mtime

    assert ftime1 == date_from_str(metadata['date']).timestamp()

    # Make sure that it can be overwritten
    fd

# Generated at 2022-06-24 11:36:50.444502
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    fd = FileDownloader()
    # FileDownloader.report_warning(msg: str)
    assert fd.report_warning('test_FileDownloader_report_warning') == None

# Generated at 2022-06-24 11:37:00.676242
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader({})
    assert fd.format_seconds(1) == '1.00s'
    assert fd.format_seconds(10) == '10.0s'
    assert fd.format_seconds(60) == ' 1m 0s'
    assert fd.format_seconds(600) == '10m 0s'
    assert fd.format_seconds(3660) == ' 1h 1m'
    assert fd.format_seconds(36000) == '10h 0m'
    assert fd.format_seconds(None) == 'unknown'
    assert fd.format_seconds('NaN') == '0s'
    assert fd.format_seconds(float('NaN')) == '0s'



# Generated at 2022-06-24 11:37:12.418376
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    def tt(speed, expected):
        fd = FileDownloader({}, FakeYDL())
        formatted = fd.format_speed(speed).strip()
        assert formatted == expected, '%s != %s for speed %s' % (formatted, expected, speed)

    tt(0, '0b/s')
    tt(1, '1.0b/s')
    tt(8, '8.0b/s')
    tt(10, '10b/s')
    tt(11, '11b/s')
    tt(17, '17b/s')
    tt(50, '50b/s')
    tt(70, '70b/s')
    tt(1000, '1000b/s')

# Generated at 2022-06-24 11:37:23.240674
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def _check(expected, string, msg):
        assert FileDownloader.parse_bytes(string) == expected, msg
    _check(0, '0', 'Test failed (bytes = 0)')
    _check(1, '1', 'Test failed (bytes = 1)')
    _check(1023, '1023', 'Test failed (bytes = 1023)')
    _check(1024, '1k', 'Test failed (kilobytes = 1)')
    _check(1024, '1K', 'Test failed (kilobytes = 1)')
    _check(10240, '10k', 'Test failed (kilobytes = 10)')
    _check(10240, '10K', 'Test failed (kilobytes = 10)')

# Generated at 2022-06-24 11:37:32.460399
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import time
    import tempfile
    file_downloader = FileDownloader(DummyYoutubeDl(), None)
    f = tempfile.mkstemp()
    os.close(f[0])
    file_downloader.try_utime(f[1], None)
    assert file_downloader.try_utime(f[1], "Fri, 09 Aug 2013 23:54:35 GMT") == 1376163675
    assert file_downloader.try_utime(f[1], "I'm not a valid timestamp") == None
    assert file_downloader.try_utime(f[1], "1376163675") == None
    assert file_downloader.try_utime(f[1], "1376163675 ") == None
    assert file_downloader.try_utime

# Generated at 2022-06-24 11:37:44.046240
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    import youtube_dl.YoutubeDL

    fd = FileDownloader({})
    assert fd.params == {}
    assert fd.ydl is None
    assert fd.info_dict is None
    assert fd.add_progress_hook(lambda x: None) is None

    fd2 = FileDownloader({
        'progress_hooks': []
    })
    fd2.add_progress_hook(lambda x: x)

    assert fd2.params == {
        'progress_hooks': [lambda x: x]
    }

    fd3 = FileDownloader({
        'progress_hooks': [lambda x: x]
    }, youtube_dl.YoutubeDL({}))

    assert fd3.params == {
        'progress_hooks': [lambda x: x]
    }



# Generated at 2022-06-24 11:37:48.531591
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # SETUP
    dler = FileDownloader({})
    # TEST
    dler.to_console_title('Foo Bar')
    # VERIFY
    assert dler.to_console_title('Foo Bar') is None
if __name__ == "__main__":
    test_FileDownloader_to_console_title()


# Generated at 2022-06-24 11:37:59.689796
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader(YoutubeDL())
    assert fd.format_speed(None) == '%10s' % '---b/s'
    assert fd.format_speed(100) == '%10s' % '100b/s'
    assert fd.format_speed(2000) == '%10s' % '1.9Kb/s'
    assert fd.format_speed(7200) == '%10s' % '7.0Kb/s'
    assert fd.format_speed(1000000) == '%10s' % '976Kb/s'
    assert fd.format_speed(20000000) == '%10s' % '19Mb/s'

# Generated at 2022-06-24 11:38:06.756696
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None)

    assert fd.best_block_size(2.0, 100) == 50
    assert fd.best_block_size(2.0, 102) == 51
    assert fd.best_block_size(2.0, 500) == 250
    assert fd.best_block_size(2.0, 750) == 375
    assert fd.best_block_size(1.0, 1000) == 500
    assert fd.best_block_size(1.0, 7500) == 3750
    assert fd.best_block_size(2.0, 750) == 375
    assert fd.best_block_size(2.0, 1000) == 500
    assert fd.best_block_size(2.0, 2000) == 1000
    assert fd.best

# Generated at 2022-06-24 11:38:17.377462
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    dl = FileDownloader(NullYoutubeDL(), {'nooverwrites': True})
    start_time = time.time()
    bytes_counter = 0
    def progress_hook(status):
        nonlocal bytes_counter
        bytes_counter = status['downloaded_bytes']
    dl.add_progress_hook(progress_hook)
    dl.slow_down(start_time, None, bytes_counter)
    dl.params['ratelimit'] = 1000
    dl.slow_down(start_time, None, 0)
    dl.slow_down(start_time, None, bytes_counter)
    dl.slow_down(start_time, None, bytes_counter)
    dl.slow_down(start_time, None, bytes_counter)
    time.sleep(0.6)

# Generated at 2022-06-24 11:38:22.304471
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # start and now must be different
    speed = FileDownloader.calc_speed(now=2, start=1, bytes=1024)
    assert speed == 1024.0
    speed = FileDownloader.calc_speed(now=3, start=2, bytes=1024)
    assert speed == 1024.0/2.0


# Generated at 2022-06-24 11:38:33.255214
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
  from youtube_dl.downloader.FileDownloader import FileDownloader
  fd = FileDownloader({"test_param":True})
  dest_1 = "test_file.ytdl"
  dest_2 = "test_file.txt"
  try:
    with open(dest_1, "a"):
      pass
    fd.try_rename(dest_1, dest_2)
    assert not os.path.isfile(dest_1)
    assert os.path.isfile(dest_2)
    os.remove(dest_2)
    fd.try_rename(dest_1, dest_1)
    assert not os.path.isfile(dest_1)
  except:
    os.remove(dest_1)


# Generated at 2022-06-24 11:38:36.662116
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    outfd = io.BytesIO()
    fd = FileDownloader(
        params=dict(verbose=True, to_stderr=True, outtmpl='outtmpl'),
        out=outfd
    )
    fd.to_stderr('foo bar')
    assert outfd.getvalue() == b'foo bar\n'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:38:45.544596
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys
    sys.stderr = open(os.devnull, 'w')
    # Initialize a downloader object
    FileDownloader.YOUTUBE_URL = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = FileDownloader()
    ydl.params['format'] = 'bestaudio/best'
    ydl.params['noplaylist'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['restrictfilenames'] = True
    ydl.params['logger'] = MyLogger()
    ydl.params['ignoreerrors'] = False
    ydl.params['forcefilename'] = True
   

# Generated at 2022-06-24 11:38:49.756552
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    #Create object
    fd = FileDownloader()
    #Assert type and value for attributes of the object
    assert fd.ydl == None
    assert fd._progress_hooks == []
    #Call method
    fd.to_stderr('message')


# Generated at 2022-06-24 11:38:58.461868
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(100) == '%10s' % '100b/s'
    assert FileDownloader.format_speed(4000) == '%10s' % '3.9KiB/s'
    assert FileDownloader.format_speed(4000000) == '%10s' % '3.8MiB/s'
    assert FileDownloader.format_speed(4000000000) == '%10s' % '3.7GiB/s'



# Generated at 2022-06-24 11:39:08.399724
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    from ytdl_info import YdlInfo
    from ydl_opts import YdlOpts
    from ydl_params import YdlParams
    from downloader import YtdlDownloader
    ydl_params = YdlParams({'noprogress':True})
    ydl_info = YdlInfo({})
    ydl_opts = YdlOpts([])
    ydl_downloader = YtdlDownloader(ydl_params,ydl_info,ydl_opts)
    file_downloader = FileDownloader(ydl_downloader,ydl_params)
    try:
        file_downloader.report_unable_to_resume()
    except Exception as e:
        print("test_FileDownloader_report_unable_to_resume_failed")

# Generated at 2022-06-24 11:39:16.374211
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # From RFC 1123 Monday, 16-Jan-06 15:04:05 GMT
    time_string = 'Mon, 16 Jan 2006 15:04:05 GMT'
    filetime = timeconvert(time_string)
    filename = 'test-file'
    f = open(filename, 'w')
    f.close()
    fd = FileDownloader({}, None)
    fd.try_utime(filename, time_string)
    assert filetime == int(os.path.getmtime(filename))
    os.remove(filename)

# Generated at 2022-06-24 11:39:24.047692
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    for c in range(5000):
        try:
            # Generate a random string
            input_string = ''.join(random.choice(string.ascii_letters) for i in range(random.randint(0,64)))
            # Generate a byte string
            byte_string = input_string.encode('utf-8')
            # Call the function
            result = FileDownloader.report_destination(byte_string)
        except Exception:
            # The function must return true if the test fails
            return False
    return True


# Generated at 2022-06-24 11:39:35.558898
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    """
    return: [test passed (True/False), test id]
    """
    print("[..] testing test_FileDownloader_parse_bytes...")
    fd = FileDownloader(params={}, ydl=None)
    test_vals = [['1.5K',1536],['1.0G',1073741824],['500B',500],['1M',1048576],['5k',5120]]
    test_passed = True
    for test_val in test_vals:
        result = fd.parse_bytes(test_val[0])

# Generated at 2022-06-24 11:39:41.704742
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    import unittest
    import sys
    fd = FileDownloader(FakeYDL(), None)
    fd.ignoreconfig = True
    fd.params = fd.ydl_opts = {}
    fd.to_screen = lambda x: sys.stdout.write(x + '\n')
    fd.report_resuming_byte(1234)
    assert sys.stdout.getvalue().strip() == '[download] Resuming download at byte 1234'


# Generated at 2022-06-24 11:39:55.833965
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(12) == '0:12'
    assert FileDownloader.format_seconds(123) == '2:03'
    assert FileDownloader.format_seconds(1234) == '20:34'
    assert FileDownloader.format_seconds(12345) == '3:25:45'
    assert FileDownloader.format_seconds(123456) == '34:17:36'
    assert FileDownloader.format_seconds(1234567) == '4:03:25:45'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3600.1) == '1:00:00.10'
    assert re.match

# Generated at 2022-06-24 11:40:02.211287
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assert FileDownloader.calc_eta(0, 100, 0) is None
    assert FileDownloader.calc_eta(100, 200, 100) == 100
    assert FileDownloader.calc_eta(100, 200, 10) == 900
    assert FileDownloader.calc_eta(0, 0, 100) is None
    assert FileDownloader.calc_eta(0, 100, 0) is None
    assert FileDownloader.calc_eta(0, 100, 50) == 100
    assert FileDownloader.calc_eta(0, 100, 150) == 50
    assert FileDownloader.calc_eta(200, 100, 50) == 200
    assert FileDownloader.calc_eta(200, 100, -50) == 400
    # Test for floating point inaccuracy
    assert FileDownloader.calc_

# Generated at 2022-06-24 11:40:11.108818
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    import filecmp
    import tempfile
    
    safe_extract = lambda s, e=None: re.findall(r'ytdl\.py:(.*?)\n(?:ytdl\.py:[^\n]*\n)*?(?=ytdl\.py:|$)', s, re.DOTALL)[0] if e is None else re.findall(r'ytdl\.py:(.*?)\n(?:ytdl\.py:[^\n]*\n)*?(?=ERROR:|ytdl\.py:|$)', s, re.DOTALL)[e]
    url = 'https://www.youtube.com/watch?v=9q3_7bkYBrY'
    filename = 'silence.mp3'
    

# Generated at 2022-06-24 11:40:20.473157
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import shutil
    import tempfile
    tmpfd, tmpf = tempfile.mkstemp(prefix='ytdl_')
    tmpfd2, tmpf2 = tempfile.mkstemp(prefix='ytdl_')
    os.write(tmpfd, 'test')
    os.close(tmpfd)
    os.close(tmpfd2)

# Generated at 2022-06-24 11:40:29.290788
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    params = {
        'sleep_interval': 1,
        'max_sleep_interval': 1,
        'verbose': True,
        'outtmpl': '%(id)s.%(ext)s',
    }
    fd = FileDownloader({
        'id': '0Bmhjf0rKe8',
        'ext': 'mp4',
    }, params)

    fd.report_destination('0Bmhjf0rKe8.mp4')


# Generated at 2022-06-24 11:40:40.698747
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():

    fd = FileDownloader('', {})

    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('2k') == 2*1024
    assert fd.parse_bytes('3M') == 3*1024*1024
    assert fd.parse_bytes('4G') == 4*1024*1024*1024
    assert fd.parse_bytes('5T') == 5*1024*1024*1024*1024
    assert fd.parse_bytes('6p') == 6*1024*1024*1024*1024*1024
    assert fd.parse_bytes('7e') == 7*1024*1024*1024*1024*1024*1024

    assert fd.parse_bytes(' 1 ') == 1
    assert fd.parse_bytes(' 2k ') == 2*1024
    assert fd.parse_bytes

# Generated at 2022-06-24 11:40:51.076397
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def tst(expected, *args):
        if expected is None:
            expected = float('nan')
        obtained = FileDownloader.calc_eta(*args)
        if math.isnan(expected) and math.isnan(obtained):
            return
        assert obtained == expected
    tst(None, 0, 100, 0)
    tst(None, 0, 100, 1)
    tst(100, 1, 100, 2)
    tst(10, 0, 10, 0)
    tst(10, 0, 10, 1)
    tst(None, 10, 0, 0)
    tst(None, 10, 0, 1)
    tst(None, 0, 0, 0)
    tst(None, 0, 0, 1)
    # https://github.com/rg3/youtube-

# Generated at 2022-06-24 11:40:55.810245
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    """Test FileDownloader.report_retry function
    """

    downloader = FileDownloader({})
    assert downloader.report_retry(urllib.error.URLError('url error'), count=1,
                                   retries=float('inf')) == '[download] Got server HTTP error: url error. Retrying (attempt 1 of inf)...'


# Generated at 2022-06-24 11:41:03.739773
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    import unittest
    t = unittest.TestCase()
    t.assertEqual(FileDownloader.parse_bytes('2'), 2)
    t.assertEqual(FileDownloader.parse_bytes('2k'), 2048)
    t.assertEqual(FileDownloader.parse_bytes('2M'), 2097152)
    t.assertEqual(FileDownloader.parse_bytes('2G'), 2147483648)
    t.assertEqual(FileDownloader.parse_bytes('2T'), 2199023255552)
    t.assertEqual(FileDownloader.parse_bytes('2P'), 2251799813685248)
    t.assertEqual(FileDownloader.parse_bytes('2E'), 2270277555565554)

# Generated at 2022-06-24 11:41:14.425958
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import re
    def test(fmt, in_dict, out_re_fmt):
        in_dict['_percent_str'] = 'X'
        in_dict['_total_bytes_str'] = 'Y'
        in_dict['_speed_str'] = 'Z'
        in_dict['_eta_str'] = 'W'

        msg = fmt % in_dict

        out_re = re.compile('\[download\] ' + out_re_fmt % in_dict)

        if not out_re.search(msg):
            pytest.fail('%r does not match %r' % (msg, out_re.pattern))


# Generated at 2022-06-24 11:41:22.493018
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    # Create an instance of the FileDownloader class
    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    })
    # Test normal cases
    assert ydl.ytdl_filename('foo.mp4') == 'foo.mp4.ytdl'
    # Test weird cases
    assert ydl.ytdl_filename('/foo.mp4') == '/foo.mp4.ytdl'
    assert ydl.ytdl_filename('foo/bar/baz') == 'foo/bar/baz.ytdl'
    #

# Generated at 2022-06-24 11:41:34.021345
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    p = lambda s, e: format_eta(e).startswith(s)

    m = lambda a, b: (((a - 0.0001) < b < (a + 0.0001)))

    assert p('0:00:00', 0)
    assert p('0:00:00', 0.4)
    assert p('0:00:01', 0.5)
    assert p('0:00:01', 0.9)
    assert p('0:00:01', 1)
    assert p('0:00:01', 1.1)
    assert p('0:00:01', 1.9)
    assert p('0:00:02', 2)
    assert p('0:00:02', 2.49)

    assert p('0:01:00', 59.9)

# Generated at 2022-06-24 11:41:44.975436
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader({})
    assert fd.format_percent(0) == '0.0%'
    assert fd.format_percent(0.0) == '0.0%'
    assert fd.format_percent(0.01) == '0.1%'
    assert fd.format_percent(0.012) == '0.1%'
    assert fd.format_percent(0.018) == '0.2%'
    assert fd.format_percent(0.1) == '0.1%'
    assert fd.format_percent(1) == '1.0%'
    assert fd.format_percent(10) == '10.0%'
    assert fd.format_percent(100) == '100.0%'
    assert fd.format_percent

# Generated at 2022-06-24 11:41:50.736457
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    assert FileDownloader.calc_speed(0, 0, 0) is None
    assert FileDownloader.calc_speed(0, 1000, 0) is None
    assert FileDownloador.calc_speed(0, 0, 1000) == 0
    assert FileDownloader.calc_speed(0, 1000, 1000) == 1000



# Generated at 2022-06-24 11:41:54.543473
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, None, {})
    fd.report_destination("test")
    assert ydl.list_info_to_screen == ["[download] Destination: test"]

test_FileDownloader_report_destination()