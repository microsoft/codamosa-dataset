

# Generated at 2022-06-24 11:31:56.648378
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({'ratelimit': None})
    # Test that we get at least 1 KByte for the first test
    assert fd.best_block_size(0, 1024) > 1024
    # Test that we get some more for the second test
    assert fd.best_block_size(0, 1024 * 2) > 1024



# Generated at 2022-06-24 11:32:02.266218
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    fd = FileDownloader(params={})
    assert fd.format_eta(1) == '0:00:01'
    assert fd.format_eta(61) == '0:01:01'
    assert fd.format_eta(3661) == '1:01:01'

# Generated at 2022-06-24 11:32:12.300012
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import io
    fd = io.BytesIO()
    fd.write(b'some data')
    fd.seek(0)
    now = time.time()
    fd.name = '/tmp/test_FileDownloader_try_utime'
    fd.content_length = len(fd.getvalue())
    dler = FileDownloader({}, {})
    dler.report_retry_max = 5
    dler.report_retry = lambda err: (
        None if dler.report_retry_count < dler.report_retry_max else err)
    dler.report_retry_count = 0
    dler.to_screen = lambda x: None
    dler.report_destination(fd.name)

# Generated at 2022-06-24 11:32:21.704955
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """Tests FileDownloader.real_download method"""
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    outtmpl = '%(id)s.%(ext)s'
    ydl = YoutubeDL({'outtmpl': outtmpl})
    ie = ydl._ies[0]

    old_real_download = FileDownloader.real_download
    def new_real_download(self, filename, info):
        old_real_download(self, filename, info)
        fd, test_filename = tempfile.mkstemp()
        os.write(fd, self.ydl.cache.load('BaW_jenozKc'))
        os.close(fd)
       

# Generated at 2022-06-24 11:32:30.384478
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    from .YoutubeDl import YoutubeDL
    fd = FileDownloader(YoutubeDL(), {}, {}, None)
    with patch('sys.stdout', new_callable=StringIO) as fake_stdout:
        prefix = '[download] '
        fd.to_screen(u'abc')
        assert fake_stdout.getvalue() == prefix + 'abc\n'
        fd.to_screen(u'äbc')
        assert fake_stdout.getvalue() == prefix + 'abc\n' + prefix + 'äbc\n'
        fd.to_screen(u'a\nb')
        assert fake_stdout.getvalue() == prefix + 'abc\n' + prefix + 'äbc\n' + prefix + 'a\n' + prefix + 'b\n'



# Generated at 2022-06-24 11:32:41.337146
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    #Test FileDownloader.report_retry()
    fd = FileDownloader(params={'outtmpl': '%(id)s%(ext)s'},
                        ydl=FakeYDL({'logger': DummyLogger()}))
    fd.report_retry(TypeError(), 1, 10)
    assert fd.ydl.msgs == ['[download] Got server HTTP error: TypeError. Retrying (attempt 1 of 10)...']
    fd.ydl.msgs = []
    fd.report_retry(IOError('my error'), 2, 5)
    assert fd.ydl.msgs == ['[download] Got server HTTP error: my error. Retrying (attempt 2 of 5)...']

    #Test FileDownloader.report_retry() #2
    fd = File

# Generated at 2022-06-24 11:32:44.516337
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'outtmpl': '%(id)s.%(ext)s'})
    assert fd.ytdl_filename('1234.5678.mp4') == '1234.5678.mp4.ytdl'
    assert fd.ytdl_filename('-'     ) == '-.ytdl'
    assert fd.ytdl_filename('-f playlist'     ) == '-f playlist.ytdl'



# Generated at 2022-06-24 11:32:54.359725
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader({})
    assert fd.format_percent(1.2) == '12%'
    assert fd.format_percent(0) == '0%'
    assert fd.format_percent(0.05) == '5%'
    assert fd.format_percent(1.0) == '100%'
    assert fd.format_percent(0.001) == '0%'
    assert fd.format_percent(0.009) == '1%'
    assert fd.format_percent(0.099) == '10%'
    assert fd.format_percent(0.99) == '99%'

    assert fd.format_percent(0.95111) == '95%'

# Generated at 2022-06-24 11:32:57.255442
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    x = FileDownloader(None)

# Generated at 2022-06-24 11:33:05.171149
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader()
    assert fd.undo_temp_name('video.mp4') == 'video.mp4'
    assert fd.undo_temp_name('video.mp4.part') == 'video.mp4'
    assert fd.undo_temp_name('video.mp4.part-1') == 'video.mp4.part-1'
    assert fd.undo_temp_name('-') == '-'


# Generated at 2022-06-24 11:33:14.426845
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import pytest
    import sys
    import tempfile
    from os.path import abspath
    # TODO: use tempfile.TemporaryDirectory()
    temp_dir = tempfile.gettempdir()
    file_name = "temp_file"
    temp_file = temp_dir + "/" + file_name
    info_dict = {
        "id": "some_id",
        "title": "some title",
        "url": "www.youtube.com",
        "thumbnail": "www.youtube.com/thumbnail"
    }

    fd = FileDownloader({
        'download_archive': os.path.abspath('./download_archive'),
        'outtmpl': temp_file,
    })

    # No exception, no assert

    # Testing _debug_cmd
    # TODO:

# Generated at 2022-06-24 11:33:17.298830
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader()
    assert fd.undo_temp_name('filename') == 'filename'
    assert fd.undo_temp_name('filename.part') == 'filename'
    assert fd.undo_temp_name('filename.part.part') == 'filename.part'
test_FileDownloader_undo_temp_name()

test_encode_compat_str = partial(test_encode, prefix='[youtube] ')


# Generated at 2022-06-24 11:33:25.041714
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import shutil
    import tempfile
    import os
    import time

    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-24 11:33:29.603355
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader({})
    fd.report_retry(None, 1, 0)
    fd.report_retry(None, 1, 1)
    fd.report_retry(None, 1, 2)
# Created by pyminifier (https://github.com/liftoff/pyminifier)

# Generated at 2022-06-24 11:33:39.748108
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    def my_test(test_case, **kwargs):
        fdl = FileDownloader(params=dict(verbose=True))
        filename = 'hello world'
        fdl.report_destination(filename)

        # We don't care about the whole line, just make sure 'hello world'
        # is contained within it in some way
        assert(filename in test_case.last_message)

    yield my_test
    print('Test passed')

if __name__ == '__main__':
    try:
        my_test()
    except AssertionError as e:
        if not hasattr(e, 'last_message'):
            print('Test failed - last output not found')
        else:
            print('Test failed - last output: \'%s\'' % e.last_message)

# Generated at 2022-06-24 11:33:51.350790
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os

    def _check_utime(filename, last_modified_hdr, filetime):
        fd, filename = tempfile.mkstemp()
        if filename is None:
            return
        fh = os.fdopen(fd, 'wb')
        fh.write(b'xx')
        fh.close()
        fd = FileDownloader({'noprogress': True, 'quiet': True},
                            youtube_dl.YoutubeDL({}))
        if filetime is None:
            fd.try_utime(filename, last_modified_hdr)
            mtime = os.path.getmtime(filename)
            os.remove(filename)
            return mtime
        fd.try_utime(filename, last_modified_hdr)

# Generated at 2022-06-24 11:33:57.923737
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({})
    #  If a TITLE environment variable isn't set, assume the shell doesn't
    #  support setting console title and expect an exception.
    #  Otherwise the test program is going to be running with a modified
    #  title.
    old_title = os.environ.get('TITLE')
    os.environ.pop('TITLE', None)
    fd.to_console_title('TEST')
    try:
        assert old_title == os.environ['TITLE']
    except KeyError:
        assert old_title is None
    finally:
        os.environ['TITLE'] = old_title



# Generated at 2022-06-24 11:34:06.466651
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():

    class InfoDict(dict):
        def __getattr__(self, name):
            return self[name]

    info_dict = InfoDict()
    info_dict['url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict['ext'] = 'flv'
    info_dict['webpage_url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict['title'] = 'test'
    info_dict['id'] = 'BaW_jenozKc'
    info_dict['format'] = '6 - 17'

    test_FileDownloader = FileDownloader(params={})
    retval = test_FileDownloader.real_download('/tmp/test.flv', info_dict)

# Generated at 2022-06-24 11:34:14.279413
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(params=None, auto_init=False)
    # Test normal values
    assert fd.try_utime('foo', 'Sat, 07 Sep 2013 12:45:26 GMT') == 1378571926
    assert fd.try_utime('foo', 'Sat, 07 Sep 2013 13:45:26 GMT') == 1378571926
    assert fd.try_utime('foo', 'Sat, 07 Sep 2013 14:45:26 GMT') == 1378571926
    assert fd.try_utime('foo', 'Sun, 08 Sep 2013 14:45:26 GMT') == 1378571926
    assert fd.try_utime('foo', 'Mon, 09 Sep 2013 22:45:26 GMT') == 1378571926

# Generated at 2022-06-24 11:34:21.134763
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1
    assert FileDownloader.slow_down(1, 2, 3) is None, \
        'Expected: None, Result: ' + FileDownloader.slow_down(1, 2, 3)
    # Test 2
    assert FileDownloader.slow_down(1, 2, 0) is None, \
        'Expected: None, Result: ' + FileDownloader.slow_down(1, 2, 0)
    # Test 3
    assert FileDownloader.slow_down(1, 0.001, 3) is None, \
        'Expected: None, Result: ' + FileDownloader.slow_down(1, 0.001, 3)

# Generated at 2022-06-24 11:34:28.714785
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    import pytest
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(float('+inf')) == 'inf'
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    with pytest.raises(ValueError):
        FileDownloader.format_retries(-2)
    assert FileDownloader.format_retries('inf') == 'inf'
    assert FileDownloader.format_retries('2') == '2'



# Generated at 2022-06-24 11:34:34.044228
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    """
    Test for the method format_retries of the class FileDownloader. This method
    should return the empty string when its parameter is equal to the
    floating point infinity.
    """

    from .YoutubeDL import FileDownloader

    assert "inf" == FileDownloader.format_retries(float('inf'))


# Generated at 2022-06-24 11:34:46.056211
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def format_seconds_test(sec, expected):
        if FileDownloader.format_seconds(sec) != expected:
            raise ValueError('%f seconds formatted as %s, not %s' %
                             (sec, FileDownloader.format_seconds(sec), expected))
        if FileDownloader.format_seconds(sec + 0.1) != expected:
            raise ValueError('%f seconds formatted as %s, not %s' %
                             (sec + 0.1, FileDownloader.format_seconds(sec + 0.1), expected))
        if FileDownloader.format_seconds(sec - 0.1) != expected:
            raise ValueError('%f seconds formatted as %s, not %s' %
                             (sec - 0.1, FileDownloader.format_seconds(sec - 0.1), expected))


# Generated at 2022-06-24 11:34:54.959039
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    t = FileDownloader({})
    t.ydl = DummyYdl()
    t.report_warning('a', 'b')
    t.report_warning('b', 'c', 'd')
    assert t.ydl.messages == [
        ('WARNING: a: b',), ('WARNING: b: c: d',)]
    del t.ydl.messages[:]
    t.report_warning('a')
    assert t.ydl.messages == [
        ('WARNING: a',)]
    del t.ydl.messages[:]


# Generated at 2022-06-24 11:34:57.368035
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(YoutubeDL({'logger': MockLogger()}))
    fd.report_error(101, 'Description')



# Generated at 2022-06-24 11:35:02.535186
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    ydl = YoutubeDL()
    ydl.params['logger'] = MockLogger()
    ufd = FileDownloader(ydl)
    ufd.to_stderr('msg1')
    assert ufd.ydl.params['logger'].messages == ['msg1']
    ufd.to_stderr('msg2')
    assert ufd.ydl.params['logger'].messages == ['msg1', 'msg2']


# Generated at 2022-06-24 11:35:06.081535
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    f = FileDownloader({})
    f.report_error('test')
    f.report_warning('test')

    f.params['verbose'] = True
    f.to_screen('test')

    f.params['verbose'] = False
    f.to_screen('test')



# Generated at 2022-06-24 11:35:13.081150
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    import sys
    from yt_dl.youtube_dl.extractor import get_info_extractor
    from yt_dl.youtube_dl.FileDownloader import FileDownloader
    from yt_dl.youtube_dl.YoutubeDL import YoutubeDL
    import unittest

    ie = get_info_extractor(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    sec = 1337
    speed = 13371337
    status = {
        'downloaded_bytes': 1337,
        'elapsed': sec,
        'speed': speed,
        'total_bytes': None
    }

    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True


# Generated at 2022-06-24 11:35:24.851509
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.YoutubeDL import DEFAULT_OUTTMPL
    from youtube_dl.compat import compat_shlex_quote
    import tempfile
    import os
    import shutil
    import sys

    print("Testing FileDownloader.report_unable_to_resume()")

    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # Set up dummy file and directory
    dummy_outtmpl_file = os.path.join(tempdir, 'temp_file')
    dummy_outtmpl_dir = os.path.join(tempdir, 'temp_dir')
    shutil.rmtree(dummy_outtmpl_file, ignore_errors=True)

# Generated at 2022-06-24 11:35:33.478598
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Test 1
    assert FileDownloader.parse_bytes('1.3k') == 1366
    # Test 2
    assert FileDownloader.parse_bytes('0.5l') == 512
    # Test 3
    assert FileDownloader.parse_bytes('12E') == 12288
    # Test 4
    assert FileDownloader.parse_bytes('2.0k') == 2048
    # Test 5
    assert FileDownloader.parse_bytes('1e') == 1024
    # Test 6
    assert FileDownloader.parse_bytes('1i') == None
    # Test 7
    assert FileDownloader.parse_bytes('-1e') == None
    # Test 8
    assert FileDownloader.parse_bytes('1.0e') == None



# Generated at 2022-06-24 11:35:40.030183
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    downloader = FileDownloader(None)
    assert downloader.format_retries(float('inf')) == 'inf'
    assert downloader.format_retries(1.0) == '1'
    assert downloader.format_retries(1.5) == '1'
    assert downloader.format_retries(1.8) == '1'
    assert downloader.format_retries(2.0) == '2'



# Generated at 2022-06-24 11:35:41.338458
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    pass

# Generated at 2022-06-24 11:35:49.997453
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(601) == '10:01'
    assert FileDownloader.format_eta(3601) == '1:00:01'

if __name__ == '__main__':
    # Unit tests
    test_FileDownloader_format_eta()
    print('FileDownloader unit tests passed.')

# Generated at 2022-06-24 11:36:02.538869
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    import youtube_dl.YoutubeDL as ytdl
    import youtube_dl.FileDownloader as fd
    import os
    import tempfile
    import unittest

    class FakeYoutubeDL(object):
        def __init__(self):
            self.params = {"forcefilename": True,
                           "forcetitle": True,
                           "format": "best",
                           "outtmpl": "%(title)s.%(ext)s",
                           "restrictfilenames": True,
                           "simulate": True}
            self.cache = {}
            self.ydl_opts = {'progress_hooks': []}
        def to_screen(self, message):
            print(message)
        def to_console_title(self, message):
            print(message)

# Generated at 2022-06-24 11:36:13.715269
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    fd = FileDownloader(
        None,
        {
            'format': test_calc_percent_format_string,
            'noprogress': True,
        }
    )
    fd.to_screen = lambda s: result.append(s)
    result = []
    fd.calc_percent(1000, 400)
    assert result == [
        '[download] Downloading video 1 of 1',
        '[download] Test.mp4 has already been downloaded'
    ]
    assert fd.percent == 40

    fd.calc_percent(1000, None)
    assert fd.percent == 0

    fd.calc_percent(None, 400)
    assert fd.percent == 0

# Generated at 2022-06-24 11:36:26.185807
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('12') == 12
    assert FileDownloader.parse_bytes('123') == 123
    assert FileDownloader.parse_bytes('123k') == 123000
    assert FileDownloader.parse_bytes('1234k') == 1234000
    assert FileDownloader.parse_bytes('123.4k') == 123.4 * 1000
    assert FileDownloader.parse_bytes('123456k') == 123456000
    assert FileDownloader.parse_bytes('123.4M') == 123.4 * 1000 * 1000
    assert FileDownloader.parse_bytes('123.4KiB') == 123.4 * 1024

# Generated at 2022-06-24 11:36:31.716597
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})
    assert fd.format_speed(1000) == '%10s' % '9.8 kB/s'
    assert fd.format_speed(10 * 1024) == '%10s' % '98.0 kB/s'
    assert fd.format_speed(100 * 1024) == '%10s' % '976 kB/s'
    assert fd.format_speed(1024 ** 2) == '%10s' % '1.0 MB/s'
    assert fd.format_speed(1024 ** 3) == '%10s' % '1.0 GB/s'
    assert fd.format_speed(1024 ** 4) == '%10s' % '1.0 TB/s'



# Generated at 2022-06-24 11:36:39.781855
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    #
    # test_FileDownloader_temp_name
    #
    # Test cases can be run individually by calling
    # python -m unittest TestDownloadVideo.test_FileDownloader_temp_name
    #
    def test_FileDownloader_temp_name_1():
        """
        Check temp_name returns filename.part if params['nopart'] is False and
        filename doesn't exist and is not a directory.
        """
        params = {'nopart': False}
        dummy_filename = '/tmp/filename'
        os.remove(dummy_filename)
        fd = FileDownloader({}, params)
        actual_result = fd.temp_name(dummy_filename)
        expected_result = dummy_filename + '.part'
        assert (actual_result == expected_result)


# Generated at 2022-06-24 11:36:51.170608
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-24 11:37:01.609066
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    fd = FileDownloader({})
    assert_raises(TypeError, fd.report_destination, None)
    assert_raises(TypeError, fd.report_destination, {'filename': 'test_from_dict'})
    assert_raises(TypeError, fd.report_destination, {'filename': None})
    assert_raises(TypeError, fd.report_destination, {'filename': 1})
    assert_raises(TypeError, fd.report_destination, {'filename': 'test'}, None)

    assert_equals(fd.report_destination(1), None)
    assert_equals(fd.report_destination(None), None)
    assert_equals(fd.report_destination(1.0), None)

# Generated at 2022-06-24 11:37:13.557439
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    fd = FileDownloader(downloader.YoutubeDL(params={}), params={})
    class _time:
        time = 0.0
    fd._time = _time
    assert fd.format_eta(0.0) == '0:00'
    assert fd.format_eta(5.0) == '0:05'
    assert fd.format_eta(60.0) == '1:00'
    assert fd.format_eta(60.5) == '1:01'
    assert fd.format_eta(3601) == '1:00:01'
    assert fd.format_eta(7261) == '2:01:01'
    _time.time = -5.0
    assert fd.format_eta(0.0) == '5:00'
   

# Generated at 2022-06-24 11:37:22.978252
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    import sys
    
    # Method definition
    def report_unable_to_resume(self):
        """Report it was impossible to resume download."""
        self.to_screen('[download] Unable to resume')
    
    
    
    
    
    
    
    
    
    
    # Function definition
    def test():
        fd = FileDownloader({})
        fd.to_screen = lambda *args, **kargs: sys.stdout.write(args[0] + '\n')
        
        report_unable_to_resume(fd)
    
    
    
    
    
    
    
    
    
    
    
    
    # Main
    test()

# Generated at 2022-06-24 11:37:32.104246
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes(None) is None
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('  \t\n\r') is None
    assert FileDownloader.parse_bytes('garbage') is None
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('2.3') == 2
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1.5K') == 1536
    assert FileDownloader.parse_bytes('2.6M') == 2621440
    assert FileDownloader.parse_bytes('3.7G') == 3865470560
    assert FileDownloader.parse_bytes('3.7g') == 3865470560


# Generated at 2022-06-24 11:37:43.862347
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    class TestDownloader(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl
            self.params = {}

    ydl = object()
    fd = TestDownloader(ydl)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('.part') == '.part'
    assert fd.undo_temp_name('foo.part.mp4') == 'foo.part.mp4'
    assert fd.undo_temp_name('foo.parta') == 'foo.parta'
    assert fd.undo_temp_name('foo.part.a') == 'foo.part.a'
    assert fd.undo

# Generated at 2022-06-24 11:37:49.020451
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader(None)
    # Testing with different number of spaces in error message
    fd.report_retry(HTTPError('123', '  The  Test  Message  '), 1, 2)
    fd.report_retry(HTTPError('123', 'The  Test  Message'), 1, 2)
    fd.report_retry(HTTPError('123', '      The  Test  Message'), 1, 2)


# Generated at 2022-06-24 11:37:52.357456
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(None, params={'verbose': True})
    fd.report_error('wrong')
    # ok
test_FileDownloader_report_error()


# Generated at 2022-06-24 11:37:59.471451
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(10,20,1000) == 50
    assert fd.calc_speed(15,20,1000) == 40
    assert fd.calc_speed(1,1,1000) == 1000
    assert fd.calc_speed(0,1,1000) == 1000
    assert fd.calc_speed(10,15,0) == 0
    assert fd.calc_speed(15,20,0) == 0
    assert fd.calc_speed(10,10,1000) == None

# Generated at 2022-06-24 11:38:06.597568
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    import copy
    import tempfile

    class MockYoutubeDl:
        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []
            self.to_console_title_calls = []
            self.tmpfilename = None

        def to_screen(self, message):
            self.to_screen_calls.append(message)

        def to_console_title(self, message):
            self.to_console_title_calls.append(message)

        def temp_name(self, filename):
            self.tmpfilename = tempfile.mkdtemp(prefix='youtubedl')
            return os.path.join(self.tmpfilename, filename)


# Generated at 2022-06-24 11:38:15.072744
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '  0.0%'
    assert FileDownloader.format_percent(0.0) == '  0.0%'
    assert FileDownloader.format_percent(0.01) == '  0.0%'
    assert FileDownloader.format_percent(0.1) == '  0.1%'
    assert FileDownloader.format_percent(1) == '  1.0%'
    assert FileDownloader.format_percent(1.23) == '  1.2%'
    assert FileDownloader.format_percent(10.23) == ' 10.2%'
    assert FileDownloader.format_percent(100.0) == '100.0%'

# Generated at 2022-06-24 11:38:22.806390
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    """Basic test for constructor of class FileDownloader."""
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'continuedl': True, 'nooverwrites': True})
    filename = 'testvideo.flv'
    test_dict = dict(
        id='test video',
        title='test video for youtube-dl',
        url='http://localhost/testvideo.mp4',
        ext='mp4',
        player_url='http://localhost/swf/player.swf'
    )
    assert fd.download(filename, test_dict) == True # Test file already downloaded

    os.remove(filename)


# Generated at 2022-06-24 11:38:34.027021
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    def _test(speed, min, max, expected):
        fd = FileDownloader({'limit-rate': speed + 'k'}, None)
        assert fd.best_block_size(0, 0) == expected


# Generated at 2022-06-24 11:38:40.502613
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    fd = FileDownloader({})
    #percent should be zero when now - start less than 0.001
    start = time.time() + 0.1
    percent = fd.calc_percent(start, 0, 100)
    assert percent == 0, "Percent should be 0, got %d" % percent
    #percent should be the same when now - start more than 0.001 and less then 0.5
    now = time.time()
    percent = fd.calc_percent(start, 0, 100)
    assert percent == 0, "Percent should be 0, got %d" % percent
    #percent should be the same when now - start more than 0.5
    time.sleep(0.6)
    now = time.time()
    percent = fd.calc_percent(start, 0, 100)
    assert percent

# Generated at 2022-06-24 11:38:47.248577
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader('',{})
    #assert fd.to_stderr('error') == None
    fd.to_stderr('error')
    return True

test_FileDownloader_to_stderr()


# Generated at 2022-06-24 11:38:55.415802
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    class FakeYDL(object):
        def __init__(self):
            self.calls = []

        def to_console_title(self, s):
            self.calls.append(s)

    f = FileDownloader({}, FakeYDL())
    # simple test
    f.to_console_title('test')
    assert f.ydl.calls == ['test']

    f.to_console_title('abc' * 1000)
    assert f.ydl.calls == ['abc' * 1000]

    f.to_console_title(unicode_str('\u9f8d\u86cb'))
    assert f.ydl.calls == ['\u9f8d\u86cb']

# Unit tests for method format_bytes of class FileDownloader

# Generated at 2022-06-24 11:39:05.218395
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert 0  == FileDownloader.parse_bytes('0');
    assert 1  == FileDownloader.parse_bytes('1');
    assert 10 == FileDownloader.parse_bytes('10');
    assert 10 == FileDownloader.parse_bytes('10b');
    assert 10 == FileDownloader.parse_bytes('10B');
    assert 10*1024  == FileDownloader.parse_bytes('10k');
    assert 10*1024  == FileDownloader.parse_bytes('10K');
    assert 10*1024*1024  == FileDownloader.parse_bytes('10m');
    assert 10*1024*1024  == FileDownloader.parse_bytes('10M');
    assert 10*1024*1024*1024  == FileDownloader.parse_bytes('10g');
    assert 10*1024*1024*1024  == FileDownloader.parse_

# Generated at 2022-06-24 11:39:16.581364
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('test.txt') == 'test.txt'
    assert FileDownloader.undo_temp_name('test.txt.part') == 'test.txt'
    assert FileDownloader.undo_temp_name('test.txt.part.part') == 'test.txt.part'
    assert FileDownloader.undo_temp_name('test') == 'test'
    assert FileDownloader.undo_temp_name('test.part') == 'test'
    assert FileDownloader.undo_temp_name('test.part.part') == 'test.part'
    assert FileDownloader.undo_temp_name('test..part') == 'test..part'
    assert FileDownloader.undo_temp_name('test...part') == 'test...part'
    assert FileDownloader.undo_temp_name

# Generated at 2022-06-24 11:39:22.905739
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    """
    Method: 'format_seconds' of class FileDownloader
    """
    assert '0:00' == FileDownloader.format_seconds(0)
    assert '0:01' == FileDownloader.format_seconds(1)
    assert '0:10' == FileDownloader.format_seconds(10)
    assert '1:00' == FileDownloader.format_seconds(60)
    assert '1:01' == FileDownloader.format_seconds(61)
    assert '1:10' == FileDownloader.format_seconds(70)
    assert '2:00' == FileDownloader.format_seconds(120)
    assert '10:00' == FileDownloader.format_seconds(600)
    assert '10:01' == FileDownloader.format_seconds(601)

# Generated at 2022-06-24 11:39:25.447489
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(1.414) == '1'
    assert FileDownloader.format_retries(2.414) == '2'

# Generated at 2022-06-24 11:39:32.418337
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    d = FileDownloader({})
    assert d._progress_hooks == []

    def ph1(x):
        pass

    def ph2(x):
        pass

    def ph3(x):
        pass

    d.add_progress_hook(ph1)
    d.add_progress_hook(ph2)
    d.add_progress_hook(ph3)

    assert d._progress_hooks == [ph1, ph2, ph3]


# Generated at 2022-06-24 11:39:42.114241
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader(None, {})
    fd.report_progress = lambda _: None
    fd.to_screen = lambda _, **__: None

    fd.real_download = lambda _, __: True
    assert fd.download('-', {})

    fd.params['nooverwrites'] = True
    fd.params['nopart'] = True
    fd.to_screen = lambda *a: None

    fd.report_destination = lambda _: None
    fd.report_progress = lambda _: None
    fd.report_resuming_byte = lambda _: None
    fd.report_retry = lambda *a: None
    fd.report_unable_to_resume = lambda *a: None

    # Check file already present

# Generated at 2022-06-24 11:39:54.275923
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    """Test that FileDownloader.report_warning() reports the warning
    """
    f = FileDownloader(None)
    w = 'test warning message'
    sys.stderr.truncate(0)
    sys.stderr.seek(0)
    f.report_warning(w)
    stderr_text = sys.stderr.getvalue()
    assert(stderr_text.startswith('WARNING: '))  # The warning has the expected prefix
    assert(stderr_text.endswith(w + '\n'))  # The warning has the expected text
 

# Generated at 2022-06-24 11:40:06.238880
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    def test(block, elapsed_time, bytes):
        if not isinstance(block, int):
            raise ValueError('block must be an integer')
        if not isinstance(elapsed_time, float):
            raise ValueError('elapsed_time must be a float')
        if not isinstance(bytes, int):
            raise ValueError('bytes must be an integer')
        return block

    fd = FileDownloader({})
    fd.best_block_size = types.MethodType(test, fd)

    class TestCase:
        def __init__(self, block, elapsed_time, bytes, expected):
            self.block = block
            self.elapsed_time = elapsed_time
            self.bytes = bytes
            self.expected = expected

# Generated at 2022-06-24 11:40:16.303579
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': True})
    fd.to_screen = Mock()
    fd.to_console_title = Mock()

    # test status not downloading
    fd.report_progress({'status': 'not downloading'})
    fd.to_screen.assert_not_called()
    fd.to_console_title.assert_not_called()
    fd.to_screen.reset_mock()
    fd.to_console_title.reset_mock()

    # test status download finished without noprogress
    fd.params['noprogress'] = False
    fd.report_progress({'status': 'finished'})

# Generated at 2022-06-24 11:40:26.411777
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    """Unit test for to_stderr method of FileDownloader class."""
    
    def _fake_to_screen_fn(msg):
        to_screen_fn_called.append(msg)

    def _fake_to_console_title_fn(msg):
        to_console_title_fn_called.append(msg)

    msg = 'Fake message'
    to_screen_fn_called = []
    to_console_title_fn_called = []

    fd = FileDownloader({'verbose': True})
    fd.to_screen = _fake_to_screen_fn
    fd.to_console_title = _fake_to_console_title_fn
    fd.to_stderr(msg)

    assert fd.params['verbose']

# Generated at 2022-06-24 11:40:29.922302
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    assert FileDownloader({}).report_destination('file') == 'file'
    FileDownloader({'verbose': True}).report_destination('file') == 'file'

# Generated at 2022-06-24 11:40:33.009898
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(YoutubeDL({}), {})
    fd.report_file_already_downloaded('file.tmp')

# Generated at 2022-06-24 11:40:42.756394
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(None) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(0) == '%10s' % '0b/s'
    assert FileDownloader.format_speed(1) == '%10s' % '1b/s'
    assert FileDownloader.format_speed(10) == '%10s' % '10b/s'
    assert FileDownloader.format_speed(99) == '%10s' % '99b/s'
    assert FileDownloader.format_speed(100) == '%10s' % '100b/s'
    assert FileDownloader.format_speed(1000) == '%10s' % '1000b/s'

# Generated at 2022-06-24 11:40:52.506737
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    downloader = FileDownloader()
    assert downloader.parse_bytes('1') == 1
    assert downloader.parse_bytes('2k') == 2 * 1024
    assert downloader.parse_bytes('2M') == 2 * 1024 * 1024
    assert downloader.parse_bytes('2m') == 2 * 1024 * 1024
    assert downloader.parse_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert downloader.parse_bytes('2g') == 2 * 1024 * 1024 * 1024
    assert downloader.parse_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024
    assert downloader.parse_bytes('2p') == 2 * 1024 * 1024 * 1024 * 1024 * 1024
    assert downloader.parse_bytes('2e') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert downloader

# Generated at 2022-06-24 11:41:01.506240
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    """ testing FileDownloader.report_file_already_downloaded method """
    # creating FileDownloader object
    fd = FileDownloader(params={}, ydl=YoutubeDL())
    
    
    # testing regular strings
    fd.report_file_already_downloaded('test_file.mp3')
    fd.report_file_already_downloaded('test_file.wav')
    fd.report_file_already_downloaded('test_file.mp4')
    
    
    # testing special strings
    fd.report_file_already_downloaded('<script>alert(1)</script>')
    fd.report_file_already_downloaded('`ls`')
    fd.report_file_already_downloaded('"ls"')
    fd.report

# Generated at 2022-06-24 11:41:07.665970
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    """Test function to_console_title of class FileDownloader"""
    # Test function inside class FileDownloader
    test_file_downloader = FileDownloader(params={})
    test_file_downloader.to_console_title('test string')

# Generated at 2022-06-24 11:41:14.459446
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader()
    fd.extract_info = lambda x, download=True: {
        '_type': 'url',
        'ie_key': 'Generic',
        'url': 'http://example.com',
    }
    fd.ydl.params['retries'] = 1
    fd.report_retry(IOError('Exception'), 1, float('inf'))



# Generated at 2022-06-24 11:41:16.757932
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader({'noprogress': '1'}, FakeYDL())
    assert fd.report_resuming_byte(0) is None


# Generated at 2022-06-24 11:41:21.379831
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda d: None)
    fd = FileDownloader({'format': 'bestaudio/best', 'outtmpl': '%(id)s'},
                        ydl)
    assert isinstance(fd.params, dict)
    assert fd.params['format'] == 'bestaudio/best'
    assert isinstance(fd.ydl, YoutubeDL)



# Generated at 2022-06-24 11:41:23.370814
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader(None)
    fd.to_screen = print
    fd.report_unable_to_resume()


# Generated at 2022-06-24 11:41:25.617829
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    assert FileDownloader(YoutubeDL()).trouble("ERROR: unable to download video data: HTTP Error 403: Forbidden") == -1
test_FileDownloader_trouble()

# Generated at 2022-06-24 11:41:37.452237
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    fd, file_name = tempfile.mkstemp()
    file_size = os.stat(file_name).st_size
    f = os.fdopen(fd, 'wb')
    f.write(b'1' * file_size)  # fill the file with '1'
    f.close()

    # write the file to '2'
    f = open(file_name, 'wb')
    f.write(b'2' * file_size)
    f.close()

    test_file = FileDownloader(None, {'outtmpl': file_name})
    test_file.try_utime(file_name, None)
    f = open(file_name, 'rb')
    new_content = f.read()
    f.close()
    assert new_content

# Generated at 2022-06-24 11:41:47.339547
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})
    assert(fd.format_speed(0) == '%10s' % '---b/s')
    assert(fd.format_speed(1000) == '%10s' % '1.00KiB/s')
    assert(fd.format_speed(10000) == '%10s' % '9.77KiB/s')
    assert(fd.format_speed(20000) == '%10s' % '19.5KiB/s')
    assert(fd.format_speed(20000) == '%10s' % '19.5KiB/s')
    assert(fd.format_speed(1024 ** 2) == '%10s' % '1.00MiB/s')

# Generated at 2022-06-24 11:41:56.134748
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    from .test import mock_test
    import unittest
    import unittest.mock

    def _test_best_block_size(s, expected, elapsed=None, bytes=None):
        t = FileDownloader(None)
        if elapsed is None:
            elapsed = t._elapsed_time
        if bytes is None:
            bytes = t._bytes_counter
        t._elapsed_time = elapsed
        t._bytes_counter = bytes
        actual = t.best_block_size(s.get('elapsed_time'), s.get('bytes'))
        assert actual == expected, '%r != %r' % (actual, expected)

    def _test_best_block_size_exception(s):
        _test_best_block_size(s, None)
