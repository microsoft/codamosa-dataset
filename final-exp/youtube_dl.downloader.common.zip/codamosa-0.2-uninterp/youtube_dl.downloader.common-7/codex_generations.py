

# Generated at 2022-06-18 12:56:58.751235
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte/s
    fd = FileDownloader({'ratelimit': 1})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.01
    fd.slow_down(start, start, 1)
    assert time.time() - start < 0.01
    fd.slow_down(start, start, 2)
    assert time.time() - start >= 0.01
    fd.slow_down(start, start, 3)
    assert time.time() - start >= 0.02
    fd.slow_down(start, start, 4)
    assert time.time() - start >= 0.03

    # Test with rate limit of 2 bytes/s

# Generated at 2022-06-18 12:57:11.389810
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import time
    import random
    import re
    import socket
    import ssl
    import threading
    import urllib.parse
    import http.server
    import socketserver
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import http.cookiejar
    import http.cookies
    import email.utils
    import email.message
    import email.policy
    import email.parser
    import email.generator
    import email.header
    import email.headerregistry
    import email.utils
    import email.feedparser
    import email.message
    import email.policy
    import email.parser
    import email.generator

# Generated at 2022-06-18 12:57:23.396067
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo\nbar')
    fd.report_file_already_downloaded('foo\nbar\nbaz')
    fd.report_file_already_downloaded('foo\nbar\nbaz\nqux')
    fd.report_file_already_downloaded('foo\nbar\nbaz\nqux\nquux')
    fd.report_file_already_downloaded('foo\nbar\nbaz\nqux\nquux\nquuz')

# Generated at 2022-06-18 12:57:35.663499
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 12:57:45.801273
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test download method of FileDownloader
    # Create a FileDownloader object
    fd = FileDownloader({})

    # Test download method with a file that already exists
    # Create a file
    f = open('test.txt', 'w')
    f.close()
    # Test download method
    assert fd.download('test.txt', {})

    # Test download method with a file that does not exist
    # Remove the file
    os.remove('test.txt')
    # Test download method
    assert fd.download('test.txt', {})

    # Test download method with a file that already exists and
    # the nooverwrites option is set to True
    # Create a file
    f = open('test.txt', 'w')
    f.close()
    # Set the nooverwrites option to True
   

# Generated at 2022-06-18 12:57:57.770583
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Test with float('inf')
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    # Test with a number
    assert FileDownloader.format_retries(5) == '5'
    # Test with a float number
    assert FileDownloader.format_retries(5.5) == '5'
    # Test with a negative number
    assert FileDownloader.format_retries(-5) == 'inf'
    # Test with a negative float number
    assert FileDownloader.format_retries(-5.5) == 'inf'
    # Test with a string
    assert FileDownloader.format_retries('5') == 'inf'
    # Test with a float string
    assert FileDownloader.format_retries('5.5') == 'inf'
    # Test with a negative string


# Generated at 2022-06-18 12:58:01.647685
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a valid date
    fd = FileDownloader({})
    assert fd.try_utime('test', 'Wed, 09 Feb 1994 22:23:32 GMT') == 784111312

    # Test with an invalid date
    assert fd.try_utime('test', 'invalid date') is None


# Generated at 2022-06-18 12:58:13.633495
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '1k'})
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 0, 1024)
    fd.slow_down(0, 0, 1025)
    fd.slow_down(0, 0, 2048)
    fd.slow_down(0, 0, 2049)
    fd.slow_down(0, 0, 4096)
    fd.slow_down(0, 0, 4097)
    fd.slow_down(0, 0, 8192)
    fd.slow_down(0, 0, 8193)
    fd.slow_down(0, 0, 16384)

# Generated at 2022-06-18 12:58:25.394088
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader(None, None)
    fd.try_rename('test.txt', 'test.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_rename('test.txt', 'test2.txt')
    fd.try_ren

# Generated at 2022-06-18 12:58:36.778082
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd

# Generated at 2022-06-18 12:58:49.877934
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader(None)
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(3) == '3'
    assert fd.format_retries(4) == '4'
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(6) == '6'
    assert fd.format_retries(7) == '7'
    assert fd.format_retries(8) == '8'
    assert fd.format_retries(9) == '9'

# Generated at 2022-06-18 12:59:01.376179
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': None}
    fd.slow_down(0, 0, 0)
    fd.params = {'ratelimit': 1}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 0, 2)
    fd.slow_down(0, 0, 3)
    fd.slow_down(0, 0, 4)
    fd.slow_down(0, 0, 5)
    fd.slow_down(0, 0, 6)
    fd.slow_down(0, 0, 7)
    fd.slow_down(0, 0, 8)

# Generated at 2022-06-18 12:59:07.026326
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('test')
    assert fd.to_screen('[download] test has already been downloaded') == '[download] test has already been downloaded'


# Generated at 2022-06-18 12:59:18.735997
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-18 12:59:28.986364
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import time
    import random
    import sys
    import io
    import re
    import http.client
    import urllib.parse
    import urllib.error
    import urllib.request
    import http.cookiejar
    import ssl
    import socket
    import json
    import base64
    import hashlib
    import subprocess
    import email.utils
    import email.message
    import email.policy
    import email.parser
    import collections
    import functools
    import itertools
    import operator
    import mimetypes
    import threading
    import queue
    import locale
    import platform
    import stat
    import traceback
    import warnings
    import atexit
    import signal
    import shutil
    import tempfile
   

# Generated at 2022-06-18 12:59:39.762145
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from io import BytesIO
    from time import sleep
    from collections import namedtuple
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'ratelimit': None,
                'retries': 0,
                'sleep_interval': 0,
                'max_sleep_interval': 0,
            }
            self.to_screen = lambda *args, **kargs: None
            self.to_console_title = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.trouble = lambda *args, **kargs: None


# Generated at 2022-06-18 12:59:49.543234
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import time
    import random
    import re
    import urllib.parse
    import urllib.request
    import http.server
    import socketserver
    import threading
    import socket
    import ssl
    import hashlib
    import base64
    import json
    import signal
    import atexit
    import traceback
    import unittest
    import unittest.mock
    import http.client
    import queue
    import io
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import time
    import random
    import re
    import urllib.parse
    import urllib.request
    import http.server
    import socketserver
    import threading

# Generated at 2022-06-18 13:00:00.644539
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from io import StringIO
    from collections import namedtuple
    from youtube_dl.utils import DateRange

    class FakeYDL:
        def __init__(self):
            self.to_screen_buffer = StringIO()
            self.to_console_title_buffer = StringIO()

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_buffer.write(msg)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

        def to_console_title(self, msg):
            self.to_console_title_buffer.write(msg)
            self.to_console_title_buffer.write('\n')


# Generated at 2022-06-18 13:00:12.659358
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader(None, None)
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1000000)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time + 1, 1000000)
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time + 1, 1000000)
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time + 2, 1000000)

# Generated at 2022-06-18 13:00:23.248633
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    assert fd.try_utime(None, None) is None
    assert fd.try_utime('', None) is None
    assert fd.try_utime('', '') is None
    assert fd.try_utime('', 'invalid') is None
    assert fd.try_utime('', '0') is None
    assert fd.try_utime('', '1') == 1
    assert fd.try_utime('', '1.0') == 1
    assert fd.try_utime('', '1.1') == 1
    assert fd.try_utime('', '1.9') == 1
    assert fd.try_utime('', '2') == 2

# Generated at 2022-06-18 13:00:41.963936
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd._report_progress_status = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 100, 'speed': 1})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 100, 'speed': 1, 'eta': 1})

# Generated at 2022-06-18 13:00:52.828386
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'elapsed': 1.0,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 10,
        'eta': 5,
    })

# Generated at 2022-06-18 13:01:04.536463
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'

# Generated at 2022-06-18 13:01:17.716164
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, {'noprogress': False})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None

    # Test with total_bytes
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': 1000,
        'elapsed': 1,
        'eta': 1,
        'speed': 100,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 200,
        'total_bytes': 1000,
        'elapsed': 2,
        'eta': 1,
        'speed': 100,
    })

# Generated at 2022-06-18 13:01:22.889934
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test that slow_down does not sleep if rate_limit is None
    fd = FileDownloader({'ratelimit': None}, None)
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 1, 1)
    fd.slow_down(1, 1, 1)
    fd.slow_down(1, 1, 0)
    fd.slow_down(1, 2, 1)
    fd.slow_down(1, 2, 2)
    fd.slow_down(1, 2, 3)
    fd.slow_down(1, 2, 4)
    fd.slow_down(1, 2, 5)
    fd.slow_down(1, 2, 6)


# Generated at 2022-06-18 13:01:35.210589
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None

    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'elapsed': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 50,
        'eta': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes_estimate': 100,
        'downloaded_bytes': 50,
        'speed': 50,
        'eta': 1,
    })


# Generated at 2022-06-18 13:01:43.772603
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1000)
    assert time.time() - start_time > 0.1
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 10000)
    assert time.time() - start_time > 0.9
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time, 100000)
    assert time.time() - start_time > 9.9
   

# Generated at 2022-06-18 13:01:55.904991
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1.5') == 1.5
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1.5K') == 1536
    assert FileDownloader.parse_bytes('1.5m') == 1572864
    assert FileDownloader.parse_bytes('1.5M') == 1572864
    assert FileDownloader.parse_bytes('1.5g') == 1610612736
    assert FileDownloader.parse_bytes('1.5G') == 1610612736
    assert FileDownloader.parse_bytes('1.5t') == 1649267441664
    assert FileDownloader.parse_bytes('1.5T') == 1649267441664

# Generated at 2022-06-18 13:02:05.980012
# Unit test for method download of class FileDownloader

# Generated at 2022-06-18 13:02:17.195168
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_al

# Generated at 2022-06-18 13:02:37.761675
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 10) == 1
    assert fd.best_block_size(0, 100) == 1
    assert fd.best_block_size(0, 1000) == 1
    assert fd.best_block_size(0, 10000) == 1
    assert fd.best_block_size(0, 100000) == 1
    assert fd.best_block_size(0, 1000000) == 1
    assert fd.best_block_size(0, 10000000) == 1
    assert fd.best_block_size(0, 100000000) == 1

# Generated at 2022-06-18 13:02:49.373107
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:03:00.480634
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: rate limit is None
    fd = FileDownloader({'ratelimit': None})
    assert fd.slow_down(0, 0, 0) is None
    assert fd.slow_down(0, 0, 1) is None
    assert fd.slow_down(0, 1, 0) is None
    assert fd.slow_down(0, 1, 1) is None
    assert fd.slow_down(1, 0, 0) is None
    assert fd.slow_down(1, 0, 1) is None
    assert fd.slow_down(1, 1, 0) is None
    assert fd.slow_down(1, 1, 1) is None

    # Test 2: rate limit is not None
    fd = FileDownloader({'ratelimit': 1})
    assert fd

# Generated at 2022-06-18 13:03:08.954322
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:03:21.624290
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:32.549747
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte/s
    fd = FileDownloader({'ratelimit': 1})
    start_time = time.time()
    fd.slow_down(start_time, start_time + 1, 1)
    assert time.time() - start_time == 1
    fd.slow_down(start_time, start_time + 1, 1)
    assert time.time() - start_time == 2
    fd.slow_down(start_time, start_time + 1, 1)
    assert time.time() - start_time == 3
    fd.slow_down(start_time, start_time + 1, 1)
    assert time.time() - start_time == 4
    # Test with rate limit of 2 byte/s
    fd = FileDownloader({'ratelimit': 2})

# Generated at 2022-06-18 13:03:44.967788
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test.txt'))

    # Convert the modification time to a datetime object
    mtime_dt = datetime.datetime.fromtimestamp(mtime)

    # Convert the modification time to an email format date

# Generated at 2022-06-18 13:03:56.259123
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': 10})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.01
    fd.slow_down(start, start, 10)
    assert time.time() - start < 0.01
    fd.slow_down(start, start, 20)
    assert time.time() - start > 0.01
    fd.slow_down(start, start, 10)
    assert time.time() - start < 0.01
    fd.slow_down(start, start, 20)
    assert time.time() - start > 0.01
    fd.slow_down(start, start, 10)
    assert time.time() - start < 0.01

# Generated at 2022-06-18 13:04:03.500816
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:04:13.526664
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 13:04:35.492858
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('/abc/def/ghi') == '/abc/def/ghi.part'
    assert fd.temp_name('/abc/def/ghi.part') == '/abc/def/ghi.part'
    assert fd.temp_name('/abc/def/ghi.part.part') == '/abc/def/ghi.part.part'
    assert fd.temp_name('/abc/def/') == '/abc/def/.part'

# Generated at 2022-06-18 13:04:46.955967
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 16) == 16
    assert fd.best_block_size(0, 32) == 32
    assert fd.best_block_size(0, 64) == 64
    assert fd.best_block_size(0, 128) == 128
    assert fd.best_block_size(0, 256) == 256
    assert fd.best_block_

# Generated at 2022-06-18 13:04:55.393432
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(last_modified_hdr, expected_result):
        tmpdir = tempfile.mkdtemp()
        try:
            filename = os.path.join(tmpdir, 'test')
            with open(filename, 'wb') as f:
                f.write(b'foobar')
            fd = FileDownloader({})
            fd.to_screen = lambda *args, **kargs: None
            fd.report_error = lambda *args, **kargs: None
            result = fd.try_utime(filename, last_modified_hdr)
            assert result == expected_result
        finally:
            shutil.rmtree(tmpdir)

    _test_try_ut

# Generated at 2022-06-18 13:05:05.937242
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte/s
    fd = FileDownloader({'ratelimit': 1})
    # Downloading 10 bytes in 10 seconds
    fd.slow_down(0, 10, 10)
    # Downloading 10 bytes in 1 second
    fd.slow_down(0, 1, 10)
    # Downloading 10 bytes in 0.5 seconds
    fd.slow_down(0, 0.5, 10)
    # Downloading 10 bytes in 0.1 seconds
    fd.slow_down(0, 0.1, 10)
    # Downloading 10 bytes in 0.01 seconds
    fd.slow_down(0, 0.01, 10)
    # Downloading 10 bytes in 0.001 seconds
    fd.slow_down(0, 0.001, 10)
    # Downloading 10 bytes

# Generated at 2022-06-18 13:05:18.221599
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:05:26.692410
# Unit test for method download of class FileDownloader

# Generated at 2022-06-18 13:05:37.962878
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:05:49.719045
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:05:59.263106
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time

    tmpdir = tempfile.mkdtemp()