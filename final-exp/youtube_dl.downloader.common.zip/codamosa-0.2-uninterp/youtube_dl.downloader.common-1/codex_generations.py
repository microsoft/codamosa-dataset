

# Generated at 2022-06-18 12:56:57.621959
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3.14) == '3'
    assert FileDownloader.format_retries(3.5) == '3'
    assert FileDownloader.format_retries(3.6) == '4'
    assert FileDownloader.format_retries(3.9) == '4'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'



# Generated at 2022-06-18 12:57:09.331161
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 1, 3) == 2
    assert fd.calc_eta(0, 2, 1) == 1
    assert fd.calc_eta(0, 2, 2) == 1
    assert fd.calc_eta(0, 2, 3) == 2

# Generated at 2022-06-18 12:57:22.032886
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import time
    import urllib.parse
    import re
    import http.server
    import threading
    import socket
    import random

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encodeFilename, decodeFilename

    class TestServer(http.server.HTTPServer):
        def __init__(self, server_address, handler):
            http.server.HTTPServer.__init__(self, server_address, handler)
            self.ready = threading.Event()

    class TestHandler(http.server.BaseHTTPRequestHandler):
        def do_HEAD(s):
            s.send_response(200)
            s.send_header('Content-Type', 'text/plain')

# Generated at 2022-06-18 12:57:34.406626
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpfname = tempfile.mkstemp(dir=tmpdir)
    # Close the temporary file
    os.close(tmpfd)
    # Create a FileDownloader instance
    fd = FileDownloader({})

    # Test 1: None
    fd.try_utime(tmpfname, None)
    # Test 2: Invalid date
    fd.try_utime(tmpfname, 'Invalid date')
    # Test 3: Invalid date
    fd.try_utime(tmpfname, 'Sat, 01 Jan 0001 00:00:00 +0000')
    # Test 4

# Generated at 2022-06-18 12:57:44.941525
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(1, 0, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 2, 1) == 0
    assert fd.calc_eta(0, 2, 2) == 0
    assert fd.calc_eta(0, 2, 3) == 1

# Generated at 2022-06-18 12:57:57.606016
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:58:06.335150
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import subprocess
    import urllib.request
    import urllib.error
    import http.client
    import http.server
    import socketserver
    import threading
    import re
    import ssl
    import socket
    import errno
    from io import BytesIO
    from unittest import TestCase
    from unittest.mock import patch, Mock, MagicMock, call, ANY
    from collections import namedtuple
    from tempfile import NamedTemporaryFile
    from http.server import BaseHTTPRequestHandler
    from http.server import HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import urlparse, parse_qs
    from urllib.request import Request
   

# Generated at 2022-06-18 12:58:15.572207
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Get the file modification time
    file_mtime = os.stat(tmpfile.name).st_mtime
    # Set the file modification time to a known value
    known_mtime = 123456789
    os.utime(tmpfile.name, (known_mtime, known_mtime))
    # Test the method try_utime
    fd = FileDownloader(None, {'outtmpl': tmpfile.name})

# Generated at 2022-06-18 12:58:20.213737
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Create a FileDownloader object
    fd = FileDownloader(params={})
    # Call method download
    fd.download(filename='test', info_dict={})


# Generated at 2022-06-18 12:58:28.859791
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 1, 3) == 2
    assert fd.calc_eta(0, 2, 1) == 0
    assert fd.calc_eta(0, 2, 2) == 0
    assert fd.calc_eta(0, 2, 3) == 1

# Generated at 2022-06-18 12:58:42.124502
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Test with a filename that can be encoded with the system's default encoding
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test')
    # Test with a filename that can't be encoded with the system's default encoding
    fd.report_file_already_downloaded('test\u2603')


# Generated at 2022-06-18 12:58:47.990825
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import shutil
    import tempfile
    import time
    import unittest

    class FileDownloaderTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, 'test.tmp')
            with open(self.filename, 'wb') as f:
                f.write(b'foobar')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_try_utime(self):
            fd = FileDownloader({})
            # Test with a valid timestamp
            fd.try_utime(self.filename, 'Thu, 01 Jan 1970 00:00:00 +0000')

# Generated at 2022-06-18 12:58:59.860612
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:59:12.400587
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp(dir=temp_dir)
    # Close the temporary file
    os.close(fd)
    # Delete the temporary file
    os.remove(temp_file_path)

    # Create a FileDownloader object
    fd = FileDownloader({})

    # Test with a non-existing file
    assert fd.try_utime(temp_file_path, None) is None
    assert fd.try_utime(temp_file_path, 'Thu, 01 Jan 1970 00:00:00 +0000') is None

    # Create the temporary file
    open

# Generated at 2022-06-18 12:59:23.131267
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(float('inf') - 1) == 'inf'
    assert FileDownloader.format_retries(float('inf') + 1) == 'inf'
    assert FileDownloader.format_retries(float('inf') * 2) == 'inf'
    assert FileDownloader.format_retries(float('inf') / 2) == 'inf'
    assert FileDownloader.format_retries(float('nan')) == 'inf'

# Generated at 2022-06-18 12:59:35.287965
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('/tmp/foo') == '/tmp/foo.part'
    assert fd.temp_name('/tmp/foo.part') == '/tmp/foo.part'
    assert fd.temp_name('/tmp/foo.part.part') == '/tmp/foo.part.part'
    assert fd.temp_name('/tmp/foo.bar.part') == '/tmp/foo.bar.part'
    assert fd.temp_name('/tmp/foo.bar') == '/tmp/foo.bar.part'
    assert fd.temp_name('/tmp/foo.bar.baz') == '/tmp/foo.bar.baz.part'

# Generated at 2022-06-18 12:59:44.019273
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert fd.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part.part'

# Generated at 2022-06-18 12:59:55.197797
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')

# Generated at 2022-06-18 13:00:06.980164
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 16) == 16
    assert fd.best_block_size(0, 32) == 32
    assert fd.best_block_size(0, 64) == 64
    assert fd.best_block_size(0, 128) == 128
    assert fd.best_block_size(0, 256) == 256
    assert fd.best_block_

# Generated at 2022-06-18 13:00:18.620906
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_error = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    fd.trouble = lambda *args, **kargs: None
    fd.params = {}
    fd.params['nooverwrites'] = False
    fd.params['nopart'] = False
    fd.params['continuedl'] = True
    fd.params['sleep_interval'] = None
    fd.params['max_sleep_interval'] = None
    fd.params['verbose'] = False
    fd.params['quiet'] = False
    fd.params['ratelimit'] = None
    fd

# Generated at 2022-06-18 13:00:39.253414
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_al

# Generated at 2022-06-18 13:00:50.087426
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 1024,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 512,
        'total_bytes': 1024,
        'speed': 1024,
        'eta': 10,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 512,
        'total_bytes_estimate': 1024,
        'speed': 1024,
        'eta': 10,
    })

# Generated at 2022-06-18 13:01:01.367021
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': '10'}
    start_time = time.time()
    fd.slow_down(start_time, start_time, 10)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 20)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 5)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10)
    assert time.time

# Generated at 2022-06-18 13:01:14.134510
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    from youtube_dl.utils import FileDownloader
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import timeconvert
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import error_to_compat_str
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import format_eta
    from youtube_dl.utils import format_percent
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_speed
    from youtube_dl.utils import format_retries
    from youtube_dl.utils import shell_quote
    from youtube_dl.utils import decodeArgument
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import match_filter_func

# Generated at 2022-06-18 13:01:26.995952
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:01:38.686299
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(timestr, expected_filetime):
        tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:01:50.922473
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:02:03.003187
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-18 13:02:13.130160
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    from collections import namedtuple
    from youtube_dl.utils import encode_compat_str

    class FakeYDL:
        def __init__(self):
            self.to_screen_value = ''
            self.to_console_title_value = ''

        def to_screen(self, message, skip_eol=False):
            self.to_screen_value += message
            if not skip_eol:
                self.to_screen_value += '\n'

        def to_console_title(self, message):
            self.to_console_title_value = message

    class FakeFD(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params


# Generated at 2022-06-18 13:02:22.448720
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:01.729478
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10, 'total_bytes_estimate': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10, 'total_bytes_estimate': 200})

# Generated at 2022-06-18 13:03:09.649347
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params={'noprogress': False})
    fd.to_screen = lambda x: None
    fd.to_console_title = lambda x: None

    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024, 'elapsed': 10})
    fd.report_progress({'status': 'downloading', 'total_bytes': 1024, 'downloaded_bytes': 512, 'speed': 10, 'eta': 10})
    fd.report_progress({'status': 'downloading', 'total_bytes_estimate': 1024, 'downloaded_bytes': 512, 'speed': 10, 'eta': 10})
   

# Generated at 2022-06-18 13:03:21.670015
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a file that exists
    fd = FileDownloader(None, None)
    fd.params = {'outtmpl': '%(title)s.%(ext)s'}
    fd.to_screen = lambda x: None
    fd.report_error = lambda x: None
    fd.report_warning = lambda x: None
    fd.try_rename = lambda x, y: None
    fd.report_destination = lambda x: None
    fd.report_progress = lambda x: None
    fd.report_resuming_byte = lambda x: None
    fd.report_retry = lambda x, y, z: None
    fd.report_file_already_downloaded = lambda x: None

# Generated at 2022-06-18 13:03:32.625572
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 5})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 5})

# Generated at 2022-06-18 13:03:45.076578
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024 * 1024)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time

# Generated at 2022-06-18 13:03:56.386700
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1.1') == 1
    assert FileDownloader.parse_bytes('1.5') == 2
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1.1k') == 1024
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1m') == 1048576
    assert FileDownloader.parse_bytes('1.1m') == 1048576
    assert FileDownloader.parse_bytes('1.5m') == 1572864
    assert FileDownloader.parse_bytes('1g') == 1073741824
    assert FileDownloader.parse_bytes('1.1g') == 1073741824

# Generated at 2022-06-18 13:04:06.348338
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test FileDownloader.try_utime with a file that exists
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.report_error = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    fd.params = {'verbose': False}
    fd.try_utime('test_FileDownloader_try_utime.tmp', 'Thu, 01 Jan 1970 00:00:00 +0000')
    assert os.path.getmtime('test_FileDownloader_try_utime.tmp') == 0
    os.remove('test_FileDownloader_try_utime.tmp')

    # Test FileDownloader.try_utime with a file that does not exist


# Generated at 2022-06-18 13:04:16.012713
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:04:25.742323
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from collections import namedtuple

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []
            self.to_console_title_calls = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_calls.append((msg, skip_eol))

        def to_console_title(self, msg):
            self.to_console_title_calls.append(msg)

    class FakeFD(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl
            self.params = {
                'noprogress': False,
                'progress_with_newline': False,
            }


# Generated at 2022-06-18 13:04:36.549756
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part.baz') == 'foo.bar.part.baz.part'
    assert fd.temp_name('foo.bar.part.baz.part') == 'foo.bar.part.baz.part'

# Generated at 2022-06-18 13:05:57.613548
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the modification time of the temporary file
    file_mtime = os.stat(tmpfile).st_mtime

    # Create a FileDownloader instance
    fd = FileDownloader({})

    # Call the method
    fd.try_utime(tmpfile, None)

    # Check that the modification time of the temporary file has not changed
    assert os.stat(tmpfile).st_mtime == file_mtime

    # Call the method with a valid timestamp