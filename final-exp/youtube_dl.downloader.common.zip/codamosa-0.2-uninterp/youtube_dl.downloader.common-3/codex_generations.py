

# Generated at 2022-06-18 12:56:57.101184
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import encodeFilename

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            InfoExtractor.__init__(self, downloader)


# Generated at 2022-06-18 12:57:08.816628
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('abc.part') == 'abc'
    assert fd.undo_temp_name('abc.part.part') == 'abc.part'
    assert fd.undo_temp_name('abc') == 'abc'
    assert fd.undo_temp_name('abc.part.part.part') == 'abc.part.part'
    assert fd.undo_temp_name('abc.part.part.part.part') == 'abc.part.part.part'
    assert fd.undo_temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part'

# Generated at 2022-06-18 12:57:21.504560
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.params = {
        'noprogress': False,
        'ratelimit': None,
        'retries': 10,
        'continuedl': True,
        'nopart': False,
        'sleep_interval': None,
        'max_sleep_interval': None,
        'verbose': False,
        'nooverwrites': False,
        'progress_with_newline': False,
    }

    # Test status finished
    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })
    assert fd.to_screen.called_once_with('[download] 100% of Unknown size in Unknown time')

    f

# Generated at 2022-06-18 12:57:28.360971
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time

    def _test_try_utime(last_modified_hdr, expected_utime):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:57:41.024289
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import pytz

    def _test_try_utime(last_modified_hdr, expected_filetime):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:57:54.692670
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert fd.undo_temp_name('foo.bar.part.part.part') == 'foo.bar.part.part'

# Generated at 2022-06-18 12:58:04.561552
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 2, 1) == 0
    assert fd.calc_eta(0, 2, 2) == 0
    assert fd.calc_eta(0, 2, 3) == 1
    assert fd.calc_eta(0, 3, 2) == 0
    assert fd.calc_eta(0, 3, 3) == 0

# Generated at 2022-06-18 12:58:16.454784
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:58:27.265544
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 12:58:38.482552
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 12:58:56.181378
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time + 1, 1024)
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time + 1, 2048)
    assert time.time() - start_time > 1.9
    fd.slow_down(start_time, start_time + 1, 512)
    assert time.time() - start_time < 1.1



# Generated at 2022-06-18 12:59:03.763826
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 2, 1) == 0
    assert fd.calc_eta(0, 2, 2) == 1
    assert fd.calc_eta(0, 2, 3) == 1
    assert fd.calc_eta(0, 3, 2) == 0

# Generated at 2022-06-18 12:59:15.895523
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 * 1024
    assert FileDownloader.parse_bytes('1g') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1t') == 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1p') == 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1e') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1.5k') == 1024 + 512

# Generated at 2022-06-18 12:59:24.232608
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(timestr, expected_filetime):
        tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:59:36.296316
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-18 12:59:44.609013
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:59:55.937659
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '10'})
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 20)
    fd.slow_down(0, 0, 30)
    fd.slow_down(0, 0, 40)
    fd.slow_down(0, 0, 50)
    fd.slow_down(0, 0, 60)
    fd.slow_down(0, 0, 70)
    fd.slow_down(0, 0, 80)
    fd.slow_down(0, 0, 90)
    fd.slow_down(0, 0, 100)
    fd.slow_down(0, 0, 110)
    f

# Generated at 2022-06-18 13:00:07.759604
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda x: x
    fd.to_console_title = lambda x: x
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 10})
    fd.report_progress({'status': 'finished', 'total_bytes': 10, 'elapsed': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 10, 'downloaded_bytes': 5, 'speed': 5})
    fd.report_progress({'status': 'downloading', 'total_bytes': 10, 'downloaded_bytes': 5, 'speed': 5, 'eta': 1})

# Generated at 2022-06-18 13:00:19.335358
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_already_downloaded('test.mp4')
    fd.report_file_al

# Generated at 2022-06-18 13:00:28.424865
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:01:26.875920
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 13:01:38.595937
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-18 13:01:50.911600
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test download method of FileDownloader
    # This test is not complete, it only tests the cases that are not tested in
    # other tests.

    # Create a FileDownloader object
    fd = FileDownloader({})

    # Test download of a file that already exists
    fd.params['nooverwrites'] = True
    fd.report_file_already_downloaded = lambda x: None
    fd.real_download = lambda x, y: None
    assert fd.download('test', {})

    # Test download of a file that already exists and continuedl is True
    fd.params['continuedl'] = True
    fd.params['nopart'] = False
    fd.report_file_already_downloaded = lambda x: None

# Generated at 2022-06-18 13:02:03.005105
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:02:13.128618
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.params = {'noprogress': False}
    assert fd.report_progress({'status': 'finished'}) == None
    assert fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 10}) == None
    assert fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10}) == None
    assert fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50}) == None

# Generated at 2022-06-18 13:02:22.484346
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'downloaded_bytes': 100,
        'elapsed': 5,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 10,
        'eta': 5,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes_estimate': 100,
        'downloaded_bytes': 50,
        'speed': 10,
        'eta': 5,
    })

# Generated at 2022-06-18 13:02:35.449199
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params['ratelimit'] = 10
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 20)
    fd.slow_down(0, 0, 30)
    fd.slow_down(0, 0, 40)
    fd.slow_down(0, 0, 50)
    fd.slow_down(0, 0, 60)
    fd.slow_down(0, 0, 70)
    fd.slow_down(0, 0, 80)
    fd.slow_down(0, 0, 90)
    fd.slow_down(0, 0, 100)

# Generated at 2022-06-18 13:02:46.659073
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 * 1024
    assert FileDownloader.parse_bytes('1M') == 1024 * 1024
    assert FileDownloader.parse_bytes('1g') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1G') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1x') is None
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1.5K') == 1536
    assert FileDownloader.parse_bytes('1.5m') == 1536 * 1024
   

# Generated at 2022-06-18 13:02:57.933030
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 * 1024
    assert FileDownloader.parse_bytes('1M') == 1024 * 1024
    assert FileDownloader.parse_bytes('1g') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1G') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1t') == 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1p') == 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:03:02.464307
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test_file')
    assert fd.to_screen.called
    assert fd.to_screen.call_args[0][0] == '[download] test_file has already been downloaded'


# Generated at 2022-06-18 13:03:53.394394
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def test_speed(speed, expected_sleep_time):
        fd = FileDownloader(None, None)
        fd.params['ratelimit'] = speed
        start_time = time.time()
        fd.slow_down(start_time, None, speed)
        elapsed_time = time.time() - start_time
        assert elapsed_time >= expected_sleep_time, '%s < %s' % (elapsed_time, expected_sleep_time)

    test_speed(1, 0)
    test_speed(10, 0)
    test_speed(100, 0)
    test_speed(1000, 0)
    test_speed(10000, 0)
    test_speed(100000, 0)

    test_speed(1.1, 0.1)

# Generated at 2022-06-18 13:04:01.929819
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 13:04:12.232989
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10240'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 10240)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10240 * 2)
    assert time.time() - start_time > 0.1
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 10240 * 4)
    assert time.time() - start_time > 0.2
    assert time.time() - start_time < 0.4
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_

# Generated at 2022-06-18 13:04:20.342045
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('/a/b/c') == '/a/b/c.part'
    assert fd.temp_name('/a/b/c.part') == '/a/b/c.part'
    assert fd.temp_name('/a/b/c.part.part') == '/a/b/c.part.part'
    assert fd.temp_name('-') == '-'
    assert fd.temp_name('-.part') == '-.part'
    assert fd

# Generated at 2022-06-18 13:04:31.074797
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    import time
    from .YoutubeDL import YoutubeDL
    from .utils import DateRange

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = io.StringIO()
            self.to_console_title_buffer = io.StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

        def to_console_title(self, message):
            self.to_console_title_buffer.write(message)
            self.to_

# Generated at 2022-06-18 13:04:42.330566
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10000)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time + 1, 10000)
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time + 1, 20000)

# Generated at 2022-06-18 13:04:51.492585
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Create a FileDownloader object
    fd = FileDownloader({'ratelimit': '1k'})

    # Test with a rate limit of 1 KiB/s
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1

    # Test with a rate limit of 1 MiB/s
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024 * 1024)
    assert time.time() - start_time < 0.1

    # Test with a rate limit of 1 MiB/s and a download speed of 2 MiB/s
    start_time = time.time()

# Generated at 2022-06-18 13:04:58.776638
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 50, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes_estimate': 100})

# Generated at 2022-06-18 13:05:10.368348
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('/abc/def') == '/abc/def.part'
    assert fd.temp_name('/abc/def.part') == '/abc/def.part'
    assert fd.temp_name('/abc/def.part.part') == '/abc/def.part.part'
    assert fd.temp_name('/abc/def.part.part') == '/abc/def.part.part'

# Generated at 2022-06-18 13:05:22.296762
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10240'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10240)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 102400)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 1024000)
    assert time.time() - start_

# Generated at 2022-06-18 13:05:58.551371
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader(None, None)
    fd.params = {'noprogress': True}
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100})
    # Test with progress
    fd.params = {}
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes_estimate': 100})