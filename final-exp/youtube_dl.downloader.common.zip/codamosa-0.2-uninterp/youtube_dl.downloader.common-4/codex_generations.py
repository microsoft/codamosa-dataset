

# Generated at 2022-06-18 12:57:06.194866
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo-001.bar.part') == 'foo-001.bar.part'
    assert fd.temp_name('foo-001.bar') == 'foo-001.bar.part'
    assert f

# Generated at 2022-06-18 12:57:18.704813
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': 1000,
        'total_bytes_estimate': 1000,
        'speed': 100,
        'eta': 10,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': None,
        'total_bytes_estimate': 1000,
        'speed': 100,
        'eta': 10,
    })

# Generated at 2022-06-18 12:57:30.212803
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start = time.time()
    fd.slow_down(start, start, 1024)
    assert time.time() - start < 0.1
    fd.slow_down(start, start, 1024 * 10)
    assert time.time() - start > 0.9
    fd.slow_down(start, start, 1024 * 10)
    assert time.time() - start > 1.9
    fd.slow_down(start, start, 1024 * 10)
    assert time.time() - start > 2.9
    fd.slow_down(start, start, 1024 * 10)
    assert time.time() - start > 3.9
    fd.slow_down(start, start, 1024 * 10)

# Generated at 2022-06-18 12:57:42.392642
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10, 'total_bytes_estimate': 200})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': 100, 'elapsed': 10})

# Generated at 2022-06-18 12:57:55.307668
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: rate_limit = None
    fd = FileDownloader({'ratelimit': None})
    start_time = time.time()
    fd.slow_down(start_time, None, 100)
    assert time.time() - start_time < 0.1

    # Test 2: rate_limit = 0
    fd = FileDownloader({'ratelimit': 0})
    start_time = time.time()
    fd.slow_down(start_time, None, 100)
    assert time.time() - start_time < 0.1

    # Test 3: rate_limit = 10
    fd = FileDownloader({'ratelimit': 10})
    start_time = time.time()
    fd.slow_down(start_time, None, 100)
    assert time.time() - start_time

# Generated at 2022-06-18 12:57:59.545779
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestFileDownloader(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tempdir, 'test.tmp')
            with open(self.filename, 'wb') as f:
                f.write(b'foo')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_try_utime(self):
            fd = FileDownloader(None, None)
            #

# Generated at 2022-06-18 12:58:06.520724
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encodeFilename

    def _test_download(ydl, params):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:58:18.215453
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 2, 2) == 1.0
    assert fd.calc_speed(0, 3, 2) == 0.6666666666666666
    assert fd.calc_speed(0, 3, 3) == 1.0
    assert fd.calc_speed(0, 4, 3) == 0.75

# Generated at 2022-06-18 12:58:27.936997
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-18 12:58:38.549037
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import namedtuple
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.screen_file = StringIO()

        def to_screen(self, message, skip_eol=False):
            self.screen_file.write(message)
            if not skip_eol:
                self.screen_file.write('\n')

    def test_report_progress(fd, s, expected):
        fd.report_progress(s)
        assert fd.ydl.screen_file.getvalue() == expected


# Generated at 2022-06-18 12:59:03.095338
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.params = {'noprogress': False}

    # Test 1
    s = {'status': 'downloading', 'downloaded_bytes': 0, 'elapsed': 0, 'eta': None, 'speed': None, 'total_bytes': None, 'total_bytes_estimate': None}
    fd.report_progress(s)
    assert s['_percent_str'] == '0.0%'
    assert s['_speed_str'] == 'Unknown speed'
    assert s['_eta_str'] == 'Unknown ETA'

    # Test 2

# Generated at 2022-06-18 12:59:15.309679
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 10, 'elapsed': 1})
    fd.report_progress({'status': 'finished', 'total_bytes': 10, 'elapsed': 1, 'eta': 1})
    fd.report_progress({'status': 'finished', 'total_bytes': 10, 'elapsed': 1, 'eta': 1, 'speed': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 10, 'elapsed': 1, 'eta': 1, 'speed': 1})
    fd

# Generated at 2022-06-18 12:59:24.105001
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'error'})

    # Test with progress
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'error'})

    # Test with progress and total_bytes
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report

# Generated at 2022-06-18 12:59:36.205916
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2048)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 512)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0

# Generated at 2022-06-18 12:59:44.560133
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None, None)
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('1m') == 1024 ** 2
    assert fd.parse_bytes('1M') == 1024 ** 2
    assert fd.parse_bytes('1g') == 1024 ** 3
    assert fd.parse_bytes('1G') == 1024 ** 3
    assert fd.parse_bytes('1t') == 1024 ** 4
    assert fd.parse_bytes('1T') == 1024 ** 4
    assert fd.parse_bytes('1p') == 1024 ** 5
    assert fd.parse_bytes('1P') == 1024 ** 5
    assert fd.parse

# Generated at 2022-06-18 12:59:55.897389
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from collections import namedtuple
    from io import StringIO

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_buffer = StringIO()
            self.to_console_title_buffer = StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

        def to_console_title(self, message):
            self.to_console_title_buffer.write(message)
            self.to_console_title_buffer.write('\n')


# Generated at 2022-06-18 13:00:07.713681
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(1, 0, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 1, 0.5) == 2
    assert fd.calc_eta(0, 1, -1) is None
    assert fd.calc_eta(0, -1, 1) is None

# Generated at 2022-06-18 13:00:19.241438
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part.part') == 'foo.bar.part.part'
    assert fd.temp_name('foo.bar.part.part.part') == 'foo.bar.part.part.part'
    assert fd.temp_name('foo.bar.part.part.part.part')

# Generated at 2022-06-18 13:00:28.352116
# Unit test for method try_rename of class FileDownloader

# Generated at 2022-06-18 13:00:39.604674
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.params = {'noprogress': False}
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'elapsed': 10,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 10,
        'eta': 5,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 10,
    })

# Generated at 2022-06-18 13:01:10.302423
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert FileDownloader.undo_temp_name('foo.bar.part.bar') == 'foo.bar.part.bar'

# Generated at 2022-06-18 13:01:23.080865
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 2, 1) == 0
    assert fd.calc_eta(0, 2, 2) == 1
    assert fd.calc_eta(0, 2, 3) == 1
    assert fd.calc_eta(0, 3, 2) == 0
    assert fd.calc_eta(0, 3, 3) == 1

# Generated at 2022-06-18 13:01:35.834293
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:01:44.146615
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import tempfile
    import shutil
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.server
    import socketserver
    import threading

    class MyHandler(http.server.SimpleHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'application/octet-stream')
            self.send_header('Content-Disposition', 'attachment; filename="%s"' % self.path.split('/')[-1])
            self.end_headers()
            self.wfile.write(b'content')

    class MyServer(socketserver.TCPServer):
        allow_reuse_address = True


# Generated at 2022-06-18 13:01:56.264511
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import subprocess
    import re
    import urllib.parse
    import http.client
    import http.server
    import socketserver
    import threading
    import socket
    import ssl
    import json

    from youtube_dl.utils import encode_data_uri


# Generated at 2022-06-18 13:02:06.098450
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from youtube_dl.utils import FileDownloader

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:02:17.281704
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 13:02:27.080219
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.partbar.part') == 'foo.partbar'
    assert fd.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
   

# Generated at 2022-06-18 13:02:39.055303
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Create a FileDownloader object
    fd = FileDownloader({})
    # Create a fake info_dict

# Generated at 2022-06-18 13:02:50.460993
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a valid date
    fd = FileDownloader(None, None)
    assert fd.try_utime('foo', 'Tue, 15 Nov 1994 12:45:26 GMT') == 784111726.0
    # Test with an invalid date
    assert fd.try_utime('foo', 'Invalid date') is None
    # Test with a date in the future
    assert fd.try_utime('foo', 'Fri, 31 Dec 9999 23:59:59 GMT') is None
    # Test with a date in the past
    assert fd.try_utime('foo', 'Fri, 31 Dec 1999 23:59:59 GMT') == 946684799.0
    # Test with a date in the past (year < 1900)

# Generated at 2022-06-18 13:03:06.041291
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'continuedl': True})
    fd.report_destination = lambda *args: None
    fd.to_screen = lambda *args: None
    fd.real_download = lambda *args: None
    fd.report_progress = lambda *args: None
    fd.report_error = lambda *args: None
    fd.report_warning = lambda *args: None
    fd.report_retry = lambda *args: None
    fd.report_resuming_byte = lambda *args: None
    fd.report_unable_to_resume = lambda *args: None
    fd.report_file_already_downloaded = lambda *args: None
   

# Generated at 2022-06-18 13:03:17.582217
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import re
    import subprocess
    import socket
    import http.server
    import urllib.parse
    import threading
    import ssl
    import json
    import hashlib
    import base64
    import zlib
    import http.client
    import queue
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import ur

# Generated at 2022-06-18 13:03:29.567768
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('abc.part') == 'abc'
    assert fd.undo_temp_name('abc.part.part') == 'abc.part'
    assert fd.undo_temp_name('abc') == 'abc'
    assert fd.undo_temp_name('abc.part.part.part') == 'abc.part.part'
    assert fd.undo_temp_name('abc.part.part.part.part') == 'abc.part.part.part'
    assert fd.undo_temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part'

# Generated at 2022-06-18 13:03:38.757878
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:39.829349
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # TODO
    pass


# Generated at 2022-06-18 13:03:52.370455
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import stat
    import errno
    import random
    import string

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, filename = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a FileDownloader instance
    fd = FileDownloader({})

    # Test with a non-existing file
    assert fd.try_utime('nonexisting', None) is None
    assert fd.try_utime('nonexisting', 'Thu, 01 Jan 1970 00:00:00 +0000') is None

    # Test with an existing file
    assert fd.try_utime(filename, None) is None
    assert f

# Generated at 2022-06-18 13:04:01.340900
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.params = {'noprogress': False}
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 1024,
        'total_bytes': 2048,
        'total_bytes_estimate': 4096,
        'eta': 300,
        'speed': 1024,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 2048,
        'total_bytes': 2048,
        'total_bytes_estimate': 4096,
        'eta': 300,
        'speed': 1024,
    })
    f

# Generated at 2022-06-18 13:04:10.957910
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: rate limit is None
    fd = FileDownloader(None, None)
    fd.params['ratelimit'] = None
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 1, 1)
    fd.slow_down(1, 1, 1)

    # Test 2: rate limit is not None
    fd.params['ratelimit'] = 1
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 1, 1)
    fd.slow_down(1, 1, 1)


# Generated at 2022-06-18 13:04:19.357532
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert FileDownloader.undo_temp_name('foo.bar.part.bar') == 'foo.bar.part.bar'

# Generated at 2022-06-18 13:04:29.841127
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:04:46.921737
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(None, None)
    assert fd.try_utime('/tmp/foo', None) is None
    assert fd.try_utime('/tmp/foo', 'foobar') is None
    assert fd.try_utime('/tmp/foo', 'Thu, 01 Jan 1970 00:00:00 +0000') == 0
    assert fd.try_utime('/tmp/foo', 'Thu, 01 Jan 1970 00:00:01 +0000') == 1
    assert fd.try_utime('/tmp/foo', 'Thu, 01 Jan 1970 00:00:01 GMT') == 1
    assert fd.try_utime('/tmp/foo', 'Thu, 01 Jan 1970 00:00:01 +0000') == 1

# Generated at 2022-06-18 13:04:55.294151
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.downloader.dash import DashSegmentsFD
    from youtube_dl.downloader.rtmp import RTMPFD
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.ism import IsmFD
    from youtube_dl.downloader.hds import HdsFD

# Generated at 2022-06-18 13:05:02.889862
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024 * 1024)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1


# Generated at 2022-06-18 13:05:14.634776
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import subprocess
    import http.server
    import threading
    import urllib.parse
    import urllib.request
    import urllib.error
    import json
    import re
    import ssl
    import socket
    import errno
    import io
    import hashlib
    import http.client
    import functools
    import traceback
    import unittest
    import unittest.mock
    import http.cookiejar
    import email.utils
    import datetime
    import platform
    import stat
    import warnings
    import collections
    import queue
    import contextlib
    import itertools
    import tempfile
    import shutil
    import os
    import sys
    import time

# Generated at 2022-06-18 13:05:25.047397
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import os
    import shutil
    import time
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:05:36.564634
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import time
    import random
    import re
    import urllib.request
    import urllib.error
    import http.client
    import socket
    import ssl
    import errno
    import json
    import hashlib
    import io
    import traceback
    import warnings
    import unittest
    import unittest.mock
    import http.server
    import socketserver
    import threading
    import queue
    import email.utils
    import email.message
    import email.policy
    import email.parser
    import email.generator
    import email.header
    import email.headerregistry
    import email.utils
    import email.charset
    import email.encoders

# Generated at 2022-06-18 13:05:44.957719
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0.0, 0) == 1
    assert fd.best_block_size(0.0, 1) == 1
    assert fd.best_block_size(0.0, 1024) == 1024
    assert fd.best_block_size(0.0, 1025) == 2048
    assert fd.best_block_size(0.0, 1048576) == 1048576
    assert fd.best_block_size(0.0, 1048577) == 4194304
    assert fd.best_block_size(0.0, 4194304) == 4194304
    assert fd.best_block_size(0.0, 4194305) == 4194304
    assert fd.best_block_

# Generated at 2022-06-18 13:05:55.977247
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    from youtube_dl.utils import FileDownloader

    def _test_try_utime(last_modified_hdr, expected_time):
        tmpdir = tempfile.mkdtemp()
        try:
            fd = FileDownloader({})
            filename = os.path.join(tmpdir, 'test.txt')
            with open(filename, 'w') as f:
                f.write('test')
            fd.try_utime(filename, last_modified_hdr)
            assert os.path.getmtime(filename) == expected_time
        finally:
            shutil.rmtree(tmpdir)

    _test_try_utime(None, None)
    _test_try_utime('', None)
    _test

# Generated at 2022-06-18 13:06:00.187672
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': 1000,
        'total_bytes_estimate': 1000,
        'speed': 10,
        'eta': 10,
        'elapsed': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': None,
        'total_bytes_estimate': 1000,
        'speed': 10,
        'eta': 10,
        'elapsed': 1,
    })
