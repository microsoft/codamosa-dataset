

# Generated at 2022-06-18 12:57:06.397084
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    import tempfile
    import shutil
    import os
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # Create a FileDownloader object
    fd = FileDownloader(params={})
    # Rename the temporary file
    fd.try_rename(tmp_file.name, tmp_file.name + '.part')
    # Check that the file was renamed
    assert os.path.isfile(tmp_file.name + '.part')
    # Remove the temporary directory
    shutil.rmtree(tmp_dir)


# Generated at 2022-06-18 12:57:18.969908
# Unit test for method download of class FileDownloader

# Generated at 2022-06-18 12:57:30.461706
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    import unittest
    from youtube_dl.utils import format_bytes

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []
            self.to_console_title_calls = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_calls.append((msg, skip_eol))

        def to_console_title(self, msg):
            self.to_console_title_calls.append(msg)

    class FakeFD(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl

# Generated at 2022-06-18 12:57:42.659984
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'

# Generated at 2022-06-18 12:57:55.735249
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None)
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'elapsed': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 10,
        'speed': 10,
        'eta': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes_estimate': 100,
        'downloaded_bytes': 10,
        'speed': 10,
        'eta': 1,
    })

# Generated at 2022-06-18 12:58:06.237089
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Test 1: block size should be between 1 and 4 MB
    assert 1 <= FileDownloader.best_block_size(1, 100) <= 4194304

    # Test 2: block size should be between 1 and 4 MB
    assert 1 <= FileDownloader.best_block_size(10, 100) <= 4194304

    # Test 3: block size should be between 1 and 4 MB
    assert 1 <= FileDownloader.best_block_size(100, 100) <= 4194304

    # Test 4: block size should be between 1 and 4 MB
    assert 1 <= FileDownloader.best_block_size(1000, 100) <= 4194304

    # Test 5: block size should be between 1 and 4 MB
    assert 1 <= FileDownloader.best_block_size(10000, 100) <= 4194304

    # Test 6: block size should be

# Generated at 2022-06-18 12:58:18.166651
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': '10k'}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 100)
    fd.slow_down(0, 0, 1000)
    fd.slow_down(0, 0, 10000)
    fd.slow_down(0, 0, 100000)
    fd.slow_down(0, 0, 1000000)
    fd.slow_down(0, 0, 10000000)
    fd.slow_down(0, 0, 100000000)
    fd.slow_down(0, 0, 1000000000)

# Generated at 2022-06-18 12:58:27.902801
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 10) == 1
    assert fd.best_block_size(0, 100) == 1
    assert fd.best_block_size(0, 1000) == 1
    assert fd.best_block_size(0, 10000) == 1
    assert fd.best_block_size(0, 100000) == 1
    assert fd.best_block_size(0, 1000000) == 1
    assert fd.best_block_size(0, 10000000) == 1
    assert fd.best_block_size(0, 100000000) == 1

# Generated at 2022-06-18 12:58:38.564691
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params={})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 12345})
    fd.report_progress({'status': 'finished', 'total_bytes': 12345, 'elapsed': 1.23})
    fd.report_progress({'status': 'downloading', 'total_bytes': 12345, 'downloaded_bytes': 1234, 'speed': 123.45})

# Generated at 2022-06-18 12:58:44.377175
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': '10k'}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 100)
    fd.slow_down(0, 0, 1000)
    fd.slow_down(0, 0, 10000)
    fd.slow_down(0, 0, 100000)
    fd.slow_down(0, 0, 1000000)
    fd.slow_down(0, 0, 10000000)
    fd.slow_down(0, 0, 100000000)
    fd.slow_down(0, 0, 1000000000)

# Generated at 2022-06-18 12:59:13.882669
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Test with float('inf')
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    # Test with a number
    assert FileDownloader.format_retries(5) == '5'
    # Test with a number with decimal part
    assert FileDownloader.format_retries(5.5) == '5'
    # Test with a number with decimal part
    assert FileDownloader.format_retries(5.5) == '5'
    # Test with a string
    assert FileDownloader.format_retries('5') == '5'
    # Test with a string with decimal part
    assert FileDownloader.format_retries('5.5') == '5'
    # Test with a string with decimal part
    assert FileDownloader.format_retries('5.5') == '5'

# Generated at 2022-06-18 12:59:23.563350
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(2) == '0:02'
    assert FileDownloader.format_seconds(59) == '0:59'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(62) == '1:02'
    assert FileDownloader.format_seconds(3599) == '59:59'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'

# Generated at 2022-06-18 12:59:35.735119
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(last_modified_hdr, expected_filetime):
        tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:59:44.295312
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:59:55.674859
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: rate limit is None
    fd = FileDownloader({'ratelimit': None})
    assert fd.slow_down(0, 0, 0) is None

    # Test 2: rate limit is not None
    fd = FileDownloader({'ratelimit': 10})
    assert fd.slow_down(0, 0, 0) is None
    assert fd.slow_down(0, 0, 10) is None
    assert fd.slow_down(0, 0, 11) is None
    assert fd.slow_down(0, 0, 20) is None
    assert fd.slow_down(0, 0, 21) is None
    assert fd.slow_down(0, 0, 30) is None
    assert fd.slow_down(0, 0, 31) is None
    assert fd

# Generated at 2022-06-18 13:00:07.461052
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:00:19.013240
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a valid date
    fd = FileDownloader({})
    assert fd.try_utime('/tmp/foo', 'Thu, 25 Feb 2010 22:12:01 GMT') == 1267251521

    # Test with an invalid date
    fd = FileDownloader({})
    assert fd.try_utime('/tmp/foo', 'Thu, 25 Feb 2010 22:12:01') is None

    # Test with a non-existing file
    fd = FileDownloader({})
    assert fd.try_utime('/tmp/foo', 'Thu, 25 Feb 2010 22:12:01 GMT') is None

    # Test with a directory
    fd = FileDownloader({})
    os.mkdir('/tmp/foo')

# Generated at 2022-06-18 13:00:28.171102
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import namedtuple
    from io import StringIO
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import encode_compat_str
    from youtube_dl.utils import encode_data_uri
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import error_to_compat_str
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_percent
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import get_filesystem_encoding
    from youtube_dl.utils import iso8601_to_unix
    from youtube_dl.utils import make_HTTPS_handler
    from youtube_dl.utils import match_filter_func
    from youtube_dl.utils import parse_filesize

# Generated at 2022-06-18 13:00:39.406208
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import time
    import random
    import sys
    import re
    import subprocess
    import urllib.request
    import urllib.error
    import http.client
    import http.server
    import socketserver
    import ssl
    import threading
    import socket
    import hashlib
    import base64
    import json
    import io
    import email.utils
    import functools
    import unittest
    import unittest.mock
    import errno
    import warnings
    import contextlib
    import http.cookiejar
    import urllib.parse
    import http.cookies
    import queue
    import traceback
    import collections
    import gzip
    import zlib
    import io
    import os
    import shutil


# Generated at 2022-06-18 13:00:50.269203
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte/s
    fd = FileDownloader(None, params={'ratelimit': 1})
    start = time.time()
    fd.slow_down(start, None, 1)
    assert time.time() - start >= 1.0
    fd.slow_down(start, None, 2)
    assert time.time() - start >= 2.0

    # Test with rate limit of 2 bytes/s
    fd = FileDownloader(None, params={'ratelimit': 2})
    start = time.time()
    fd.slow_down(start, None, 1)
    assert time.time() - start >= 0.5
    fd.slow_down(start, None, 2)
    assert time.time() - start >= 1.0

# Generated at 2022-06-18 13:01:12.126302
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    import time
    import unittest
    import unittest.mock
    from youtube_dl.downloader.common import FileDownloader

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_value = ''
            self.to_console_title_value = ''

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_value += msg
            if not skip_eol:
                self.to_screen_value += '\n'

        def to_console_title(self, msg):
            self.to_console_title_value = msg


# Generated at 2022-06-18 13:01:25.061106
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import tempfile
    import shutil
    import re
    import sys
    import subprocess
    import time
    import random
    import string
    import json
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import http.server
    import socketserver
    import threading
    import unittest
    import unittest.mock
    from io import BytesIO
    from collections import namedtuple
    from functools import partial
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import DEFAULT

# Generated at 2022-06-18 13:01:37.253238
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert fd.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part.part'

# Generated at 2022-06-18 13:01:44.860984
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 20)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 30)
    assert time.time() - start_time > 0.2
    fd.slow_down(start_time, start_time, 40)
    assert time.time() - start_time > 0.

# Generated at 2022-06-18 13:01:57.307363
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import re
    import subprocess
    import urllib.parse
    import http.client
    import threading
    import socket
    import ssl
    import json
    import hashlib
    import base64
    import binascii
    import email.utils
    import email.header
    import email.message
    import http.server
    import socketserver
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse

# Generated at 2022-06-18 13:02:06.493460
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    assert fd.report_file_already_downloaded('foo.bar') == '[download] foo.bar has already been downloaded'
    assert fd.report_file_already_downloaded(u'\u05d0\u05d1\u05d2.bar') == '[download] \u05d0\u05d1\u05d2.bar has already been downloaded'
    assert fd.report_file_already_downloaded(u'\u05d0\u05d1\u05d2.bar'.encode('utf-8')) == '[download] \u05d0\u05d1\u05d2.bar has already been downloaded'
    assert fd.report_file_

# Generated at 2022-06-18 13:02:17.699951
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.part.part') == 'foo.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part') == 'foo.part.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part.part') == 'foo.part.part.part.part'

# Generated at 2022-06-18 13:02:28.208410
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import unittest
    import sys
    from io import StringIO

    class TestFileDownloader(FileDownloader):
        def __init__(self, params):
            super(TestFileDownloader, self).__init__(params)
            self.to_screen_buffer = StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

    class TestFileDownloaderReportProgress(unittest.TestCase):
        def setUp(self):
            self.fd = TestFileDownloader({})


# Generated at 2022-06-18 13:02:39.786727
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat
    import sys

    def get_mtime(filename):
        return os.stat(filename)[stat.ST_MTIME]

    def get_atime(filename):
        return os.stat(filename)[stat.ST_ATIME]

    def get_ctime(filename):
        return os.stat(filename)[stat.ST_CTIME]

    def get_utime(filename):
        return os.stat(filename)[stat.ST_ATIME], os.stat(filename)[stat.ST_MTIME]

    def set_utime(filename, atime, mtime):
        os.utime(filename, (atime, mtime))


# Generated at 2022-06-18 13:02:51.185420
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test for status 'finished'
    fd = FileDownloader({})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10, 'speed': 10})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10, 'speed': 10, 'eta': 10})

# Generated at 2022-06-18 13:03:10.179608
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    import unittest
    from youtube_dl.utils import FileDownloader

    class TestReportProgress(unittest.TestCase):
        def setUp(self):
            self.fd = FileDownloader({})
            self.fd.to_screen = lambda x: sys.stdout.write(x + '\n')
            self.fd.to_console_title = lambda x: sys.stdout.write(x + '\n')

        def test_report_progress(self):
            self.fd.report_progress({
                'status': 'finished',
                'total_bytes': 100,
                'elapsed': 1,
            })

# Generated at 2022-06-18 13:03:21.941540
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # Get the file modification time
    filemtime = os.stat(tmpfile.name).st_mtime
    # Set the file modification time to the past
    os.utime(tmpfile.name, (filemtime, filemtime - 3600))
    # Create a FileDownloader instance
    fd = FileDownloader({})
    # Set the file modification time to the future

# Generated at 2022-06-18 13:03:32.809274
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'temp_file')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Get the last modification time of the file
    last_modified_time = os.path.getmtime(tmp_file)

    # Create a FileDownloader instance
    fd = FileDownloader({})

    # Test the method with a valid time string
    time_str = time.strftime('%Y%m%d%H%M%S', time.gmtime(last_modified_time))

# Generated at 2022-06-18 13:03:45.288267
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
    assert fd.undo_temp_name('.part') == ''
    assert fd.undo_temp_name('') == ''
    assert fd.undo_temp_name('.') == '.'

# Generated at 2022-06-18 13:03:56.521076
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': 10})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 10)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 11)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 20)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 21)
    assert time.time() - start_time > 0.2


# Generated at 2022-06-18 13:04:06.551341
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None)
    assert fd.temp_name('/tmp/foo') == '/tmp/foo.part'
    assert fd.temp_name('/tmp/foo.part') == '/tmp/foo.part'
    assert fd.temp_name('/tmp/foo.part.part') == '/tmp/foo.part.part'
    assert fd.temp_name('/tmp/foo.part.part.part') == '/tmp/foo.part.part.part'
    assert fd.temp_name('/tmp/foo.part.part.part.part') == '/tmp/foo.part.part.part.part'
    assert fd.temp_name('/tmp/foo.part.part.part.part.part') == '/tmp/foo.part.part.part.part.part'


# Generated at 2022-06-18 13:04:16.182739
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3661) == '1:01:01'
    assert FileDownloader.format_seconds(36000) == '10:00:00'

# Generated at 2022-06-18 13:04:26.014648
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    from collections import OrderedDict
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.to_screen = lambda *args, **kargs: sys.stdout.write(args[0])
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    assert sys.stdout.getvalue() == '[download] 100% of Unknown size in Unknown time\n'
    sys.stdout = io.StringIO()
    fd.report_progress({'status': 'finished', 'total_bytes': 1000, 'elapsed': 10})
    assert sys.stdout.getvalue()

# Generated at 2022-06-18 13:04:36.882425
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with total_bytes
    s = {
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 10,
        'speed': 10,
        'eta': 10,
    }
    fd = FileDownloader(None, None)
    fd.report_progress(s)
    assert fd._report_progress_prev_line_length == 0
    assert fd._report_progress_status_string == '10% of 100 at 10/s ETA 00:00'

    # Test with total_bytes_estimate
    s = {
        'status': 'downloading',
        'total_bytes_estimate': 100,
        'downloaded_bytes': 10,
        'speed': 10,
        'eta': 10,
    }
    fd = FileDownloader

# Generated at 2022-06-18 13:04:48.103083
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:05:10.552346
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: rate limit is None
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': None}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 1, 0)
    fd.slow_down(0, 1, 1)
    fd.slow_down(1, 0, 0)
    fd.slow_down(1, 0, 1)
    fd.slow_down(1, 1, 0)
    fd.slow_down(1, 1, 1)

    # Test 2: rate limit is not None
    fd.params = {'ratelimit': 1}
    fd.slow_down(0, 0, 0)
    f

# Generated at 2022-06-18 13:05:22.501232
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    import random
    import unittest
    from .YoutubeDL import YoutubeDL
    from .utils import encodeFilename

    class TestFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(TestFileDownloader, self).__init__(ydl, params)
            self.sleep_time = 0

        def slow_down(self, start_time, now, byte_counter):
            super(TestFileDownloader, self).slow_down(start_time, now, byte_counter)
            self.sleep_time = time.time() - now

    class TestYoutubeDL(YoutubeDL):
        def __init__(self, params):
            super(TestYoutubeDL, self).__init__(params)
            self.sleep_time = 0


# Generated at 2022-06-18 13:05:35.576421
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('/abc/def') == '/abc/def.part'
    assert fd.temp_name('/abc/def.part') == '/abc/def.part'
    assert fd.temp_name('/abc/def.part.part') == '/abc/def.part.part'
    assert fd.temp_name('/abc/def.part.part') == '/abc/def.part.part'

# Generated at 2022-06-18 13:05:48.209806
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'
    assert FileDownloader.format_seconds(3660) == '1:01:00'

# Generated at 2022-06-18 13:05:58.199486
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar
    import pytz
    import re

    def _test_try_utime(timestr, expected_filetime):
        tmpdir = tempfile.mkdtemp()
        try:
            filename = os.path.join(tmpdir, 'foo')
            with open(filename, 'wb') as f:
                f.write(b'foo')
            fd = FileDownloader(None, {'outtmpl': filename})
            filetime = fd.try_utime(filename, timestr)
            assert filetime == expected_filetime
        finally:
            shutil.rmtree(tmpdir)

    _test_try_utime(None, None)

# Generated at 2022-06-18 13:06:08.695926
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import subprocess
    import socket
    import http.server
    import threading
    import urllib.parse
    import urllib.request
    import urllib.error
    import ssl
    import re
    import json
    import hashlib
    import base64
    import email.utils
    import http.cookies
    import http.client
    import io
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import shutil
    import tempfile
    import functools
    import collections
    import contextlib
    import http.cookiejar
    import http.cookies
    import io
    import os
    import posix