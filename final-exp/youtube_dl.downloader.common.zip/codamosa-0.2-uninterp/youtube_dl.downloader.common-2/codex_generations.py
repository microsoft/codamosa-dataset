

# Generated at 2022-06-18 12:56:48.290596
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None, 'speed': None, 'eta': None})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None, 'speed': None, 'eta': 0})

# Generated at 2022-06-18 12:56:59.680387
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import unittest
    import sys

    class TestFileDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_screen_buffer = []
            self.to_console_title_buffer = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_buffer.append(msg)

        def to_console_title(self, msg):
            self.to_console_title_buffer.append(msg)

    class TestFileDownloaderReportProgress(unittest.TestCase):
        def setUp(self):
            self.fd = TestFileDownloader({})

        def test_no_progress(self):
            self.fd.params['noprogress'] = True
            self.fd

# Generated at 2022-06-18 12:57:12.047462
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 12:57:23.997144
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 12:57:36.837972
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert fd.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part.part'

# Generated at 2022-06-18 12:57:46.054466
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': False})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'downloaded_bytes': 100,
        'elapsed': 1,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 100,
        'elapsed': 1,
        'speed': 100,
        'eta': 0,
    })

# Generated at 2022-06-18 12:57:57.807729
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.FileDownloader import FileDownloader

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.to_screen_buffer = StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

    def check_report_progress(expected, status):
        fd = FileDownloader({}, FakeYDL({}))
        fd.report_progress(status)
        assert fd.ydl.to_screen

# Generated at 2022-06-18 12:58:09.204744
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    fd.report_file_already_downloaded('test')
    f

# Generated at 2022-06-18 12:58:21.062887
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 1, 3) == 2
    assert fd.calc_eta(0, 1, 4) == 3
    assert fd.calc_eta(0, 2, 1) == 1
    assert fd.calc_eta(0, 2, 2) == 1

# Generated at 2022-06-18 12:58:29.335159
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0.001, 0) is None
    assert fd.calc_speed(0, 0.001, 1000) == 1000000.0
    assert fd.calc_speed(0, 0.001, 1024) == 1024000.0
    assert fd.calc_speed(0, 0.001, 1048576) == 1048576000.0
    assert fd.calc_speed(0, 0.001, 1073741824) == 1073741824000.0
    assert fd.calc_speed(0, 0.001, 1099511627776) == 1099511627776000.0

# Generated at 2022-06-18 12:58:41.877727
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 1, 1024) == 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024) == 1024.0 * 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024) == 1024.0 * 1024.0 * 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024 * 1024) == 1024.0 * 1024.0 * 1024.0 * 1024.0
    assert fd.calc

# Generated at 2022-06-18 12:58:47.858124
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(1, 0, 0) is None
    assert fd.calc_eta(1, 1, 1) == 0
    assert fd.calc_eta(1, 1, 2) == 1
    assert fd.calc_eta(1, 1, 0.5) == 1
    assert fd.calc_eta(1, 2, 1) == 1
    assert fd.calc_eta(1, 2, 2) == 1
    assert fd.calc_eta(1, 2, 3)

# Generated at 2022-06-18 12:58:59.787057
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 12:59:06.190624
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    assert fd.report_file_already_downloaded('foo') == 'foo has already been downloaded'
    assert fd.report_file_already_downloaded('foo\u0400') == 'The file has already been downloaded'


# Generated at 2022-06-18 12:59:17.979964
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(3.14) == '3'
    assert fd.format_retries(3.5) == '3'
    assert fd.format_retries(3.6) == '3'
    assert fd.format_retries(3.9) == '3'
    assert fd.format_retries(4) == '4'
    assert fd.format_retries(5) == '5'
    assert fd.format_ret

# Generated at 2022-06-18 12:59:27.844501
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 12:59:38.912882
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) == None
    assert fd.calc_speed(0, 0.001, 0) == None
    assert fd.calc_speed(0, 0.001, 1) == 1000
    assert fd.calc_speed(0, 0.001, 1024) == 1024000
    assert fd.calc_speed(0, 0.001, 1024 * 1024) == 1024000000
    assert fd.calc_speed(0, 0.001, 1024 * 1024 * 1024) == 1024000000000
    assert fd.calc_speed(0, 0.001, 1024 * 1024 * 1024 * 1024) == 1024000000000000

# Generated at 2022-06-18 12:59:48.685287
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({'nopart': True})
    assert fd.temp_name('abc') == 'abc'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:59:59.441994
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    def _test_try_utime(timestr, expected_time):
        tmpdir = tempfile.mkdtemp()
        try:
            filename = os.path.join(tmpdir, 'test.txt')
            with open(filename, 'w') as f:
                f.write('test')
            fd = FileDownloader({})
            fd.try_utime(filename, timestr)
            st = os.stat(filename)
            assert st.st_mtime == expected_time
        finally:
            shutil.rmtree(tmpdir)

    _test_try_utime('Thu, 10 Jul 2014 07:00:49 GMT', 1405002849)

# Generated at 2022-06-18 13:00:11.528701
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader(None, None)
    assert fd.format_seconds(0) == '0:00'
    assert fd.format_seconds(1) == '0:01'
    assert fd.format_seconds(10) == '0:10'
    assert fd.format_seconds(60) == '1:00'
    assert fd.format_seconds(61) == '1:01'
    assert fd.format_seconds(70) == '1:10'
    assert fd.format_seconds(600) == '10:00'
    assert fd.format_seconds(601) == '10:01'
    assert fd.format_seconds(610) == '10:10'
    assert fd.format_seconds(3600) == '1:00:00'
    assert f

# Generated at 2022-06-18 13:01:09.522806
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '50k'})
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 0, 1024)
    fd.slow_down(0, 0, 1025)
    fd.slow_down(0, 0, 1026)
    fd.slow_down(0, 0, 1027)
    fd.slow_down(0, 0, 1028)
    fd.slow_down(0, 0, 1029)
    fd.slow_down(0, 0, 1030)
    fd.slow_down(0, 0, 1031)
    fd.slow_down(0, 0, 1032)

# Generated at 2022-06-18 13:01:22.343472
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(timestr, expected_time):
        fd, filename = tempfile.mkstemp()
        os.close(fd)

# Generated at 2022-06-18 13:01:34.582362
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part-1') == 'foo.part-1'
    assert fd.undo_temp_name('foo.part-1.part') == 'foo.part-1'
    assert fd.undo_temp_name('foo.part-1.bar') == 'foo.part-1.bar'
    assert fd.undo_temp_name('foo.part-01')

# Generated at 2022-06-18 13:01:43.472657
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.to_screen = lambda x: x
    assert fd.report_progress({'status': 'finished'}) is None
    assert fd.report_progress({'status': 'downloading'}) is None

    # Test with progress
    fd = FileDownloader({'noprogress': False})
    fd.to_screen = lambda x: x
    assert fd.report_progress({'status': 'finished'}) is None
    assert fd.report_progress({'status': 'downloading'}) is None
    assert fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'elapsed': 0}) is None

# Generated at 2022-06-18 13:01:45.968955
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('test')
    assert fd.to_screen('[download] test has already been downloaded') == '[download] test has already been downloaded'


# Generated at 2022-06-18 13:01:58.345713
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(2.5) == '2'
    assert FileDownloader.format_retries(2.9) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(3.5) == '3'
    assert FileDownloader.format_retries(3.9) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_

# Generated at 2022-06-18 13:02:06.964708
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part.part') == 'foo.bar.part.part'

# Generated at 2022-06-18 13:02:18.129067
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.bar') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert FileDownloader.undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert FileDownloader.undo_temp_name('foo.bar.part.bar') == 'foo.bar.part.bar'

# Generated at 2022-06-18 13:02:28.620383
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('.part') == '.part'
    assert fd.undo_temp_name('') == ''
    assert fd.undo_temp_name('foo.part.part.part') == 'foo.part.part'

# Generated at 2022-06-18 13:02:40.129456
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'finished'})

    # Test with progress
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'finished'})

    # Test with progress and total_bytes
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished'})

# Generated at 2022-06-18 13:03:21.486877
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with no rate limit
    fd = FileDownloader({'ratelimit': None})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.1

    # Test with rate limit
    fd = FileDownloader({'ratelimit': 100})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.1

    start = time.time()
    fd.slow_down(start, start, 100)
    assert time.time() - start < 0.1

    start = time.time()
    fd.slow_down(start, start, 200)
    assert time.time() - start > 0.1

    # Test with negative rate limit
    f

# Generated at 2022-06-18 13:03:32.431264
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.part.part') == 'foo.bar.part.part'
    assert fd.temp_name('foo.bar.baz') == 'foo.bar.baz.part'

# Generated at 2022-06-18 13:03:44.806130
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:56.157248
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    def _test_try_utime(timestr, expected_filetime):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:04:03.452436
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit = None
    fd = FileDownloader({'ratelimit': None})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.1

    # Test with rate limit = 0
    fd = FileDownloader({'ratelimit': 0})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.1

    # Test with rate limit = 10
    fd = FileDownloader({'ratelimit': 10})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time

# Generated at 2022-06-18 13:04:13.440548
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024, 'elapsed': 1.0})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024, 'elapsed': 1.0})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024, 'elapsed': 1.0})
    fd.report_progress({'status': 'finished', 'total_bytes': 1024, 'elapsed': 1.0})

# Generated at 2022-06-18 13:04:17.692513
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    assert fd.report_file_already_downloaded('foo') == '[download] foo has already been downloaded'
    assert fd.report_file_already_downloaded('foo\x00bar') == '[download] The file has already been downloaded'


# Generated at 2022-06-18 13:04:27.562857
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'elapsed': 1, 'downloaded_bytes': 50, 'eta': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'elapsed': 1, 'downloaded_bytes': 50, 'eta': 1, 'speed': 1})

# Generated at 2022-06-18 13:04:38.316450
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0.0, 0) == 1
    assert fd.best_block_size(0.0, 1) == 1
    assert fd.best_block_size(0.0, 2) == 2
    assert fd.best_block_size(0.0, 3) == 4
    assert fd.best_block_size(0.0, 4) == 4
    assert fd.best_block_size(0.0, 5) == 8
    assert fd.best_block_size(0.0, 6) == 8
    assert fd.best_block_size(0.0, 7) == 8
    assert fd.best_block_size(0.0, 8) == 8
    assert fd.best

# Generated at 2022-06-18 13:04:49.049936
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo')
    fd.report_

# Generated at 2022-06-18 13:05:39.129827
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from collections import namedtuple
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.utils import format_bytes

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.screen_file = StringIO()
            self.title_file = StringIO()

        def to_screen(self, msg, skip_eol=False):
            self.screen_file.write(msg + ('\n' if not skip_eol else ''))

        def to_console_title(self, msg):
            self.title_file.write(msg)


# Generated at 2022-06-18 13:05:51.095541
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.def') == 'abc.def.part'
    assert fd.temp_name('abc.def.ghi') == 'abc.def.ghi.part'
    assert fd.temp_name('/abc/def') == '/abc/def.part'
    assert fd.temp_name('/abc/def.ghi') == '/abc/def.ghi.part'
    assert fd.temp_name('/abc/def.ghi.jkl') == '/abc/def.ghi.jkl.part'
    assert fd.temp_name('/abc/def/ghi.jkl') == '/abc/def/ghi.jkl.part'

# Generated at 2022-06-18 13:05:59.844798
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.3
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.4
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0