

# Generated at 2022-06-18 12:57:07.625420
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit = None
    fd = FileDownloader(None, None)
    fd.params['ratelimit'] = None
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 100)
    fd.slow_down(0, 0, 1000)
    fd.slow_down(0, 0, 10000)
    fd.slow_down(0, 0, 100000)
    fd.slow_down(0, 0, 1000000)
    fd.slow_down(0, 0, 10000000)
    fd.slow_down(0, 0, 100000000)
    fd.slow_down(0, 0, 1000000000)

# Generated at 2022-06-18 12:57:20.050510
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 1) == 1
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 1, 2) == 2
    assert fd.calc_speed(0, 2, 2) == 1
    assert fd.calc_speed(0, 3, 2) == 0.6666666666666666
    assert fd.calc_speed(0, 2, 3) == 1.5

# Generated at 2022-06-18 12:57:28.861795
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(3.14) == '3'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(-1) == '0'
    assert FileDownloader.format_retries(float('NaN')) == '0'
    assert FileDownloader.format_retries(float('-inf')) == '0'


# Generated at 2022-06-18 12:57:41.485071
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    import tempfile
    import os
    import shutil
    import time
    import random
    import sys
    import re
    import subprocess
    import json

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            InfoExtractor.__init__(self, downloader, ie_key, ie_desc)
            self.num_downloads = 0
            self.returned_information = []

        def _real_extract(self, url):
            self.num_downloads += 1
            return self.returned_information.pop(0)


# Generated at 2022-06-18 12:57:54.740998
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:58:04.604944
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 12:58:16.501194
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(FakeYDL(), {})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 1, 1024) == 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024) == 1024.0 * 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024) == 1024.0 * 1024.0 * 1024.0
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024 * 1024) == 1024.0 * 1024.0 * 1024.0 * 1024.0

# Generated at 2022-06-18 12:58:27.270270
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    import time
    from collections import namedtuple
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import format_bytes

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.screen_file = io.StringIO()
            self.title_file = io.StringIO()

        def to_screen(self, message, skip_eol=False):
            self.screen_file.write(message)
            if not skip_eol:
                self.screen_file.write('\n')


# Generated at 2022-06-18 12:58:38.482018
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start = time.time()
    fd.slow_down(start, start, 1024)
    assert time.time() - start < 0.1
    fd.slow_down(start, start, 2048)
    assert time.time() - start > 0.1
    fd.slow_down(start, start, 512)
    assert time.time() - start < 0.1
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.1
    fd.slow_down(start, start, 1024)
    assert time.time() - start < 0.1
    fd.slow_down(start, start + 1, 1024)
    assert time.time() - start < 0.1

# Generated at 2022-06-18 12:58:44.263355
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfd, tmpfname = tempfile.mkstemp(dir=tmpdir)
    # Close the file
    os.close(tmpfd)
    # Remove the file
    os.remove(tmpfname)

    # Create a FileDownloader instance
    fd = FileDownloader(None, None)

    # Test 1: try_utime with a non-existing file
    assert fd.try_utime(tmpfname, None) is None

    # Test 2: try_utime with a non-existing file and a non-existing time

# Generated at 2022-06-18 12:59:01.653282
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    import random
    from .utils import encodeFilename
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['ratelimit'] = 10
    ydl.params['retries'] = 0
    ydl.params['verbose'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['continuedl'] = True
    ydl.params['noprogress'] = True
    ydl.params['logger'] = MockLogger()
    ydl.params['outtmpl'] = encodeFilename('%(id)s')
    fd = FileDownloader(ydl, {'id': 'test'}, {'url': 'http://127.0.0.1:8080/'})
    fd.report_destination('test')

# Generated at 2022-06-18 12:59:14.562799
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    import time

    def get_output(f):
        # Python 2 and 3 compatible
        if sys.version_info < (3, 0):
            return f.getvalue()
        else:
            return f.getvalue().decode('utf-8')

    # Test with noprogress
    fd = FileDownloader({'noprogress': True})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'downloading', 'speed': '42'})

# Generated at 2022-06-18 12:59:23.773534
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1
    assert fd.calc_speed(0, 1, 2) == 2
    assert fd.calc_speed(0, 1, 1024) == 1024
    assert fd.calc_speed(0, 1, 1024 * 1024) == 1024 * 1024
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024) == 1024 * 1024 * 1024
    assert fd.calc_speed(0, 1, 1024 * 1024 * 1024 * 1024) == 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-18 12:59:35.874707
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:59:44.383467
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    # Test 1
    assert fd.best_block_size(0.0, 0) == 1
    # Test 2
    assert fd.best_block_size(0.0, 1) == 1
    # Test 3
    assert fd.best_block_size(0.0, 10) == 1
    # Test 4
    assert fd.best_block_size(0.0, 100) == 1
    # Test 5
    assert fd.best_block_size(0.0, 1000) == 1
    # Test 6
    assert fd.best_block_size(0.0, 10000) == 1
    # Test 7
    assert fd.best_block_size(0.0, 100000) == 1
    # Test 8
    assert fd.best_block

# Generated at 2022-06-18 12:59:55.763861
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 2, 2) == 1.0
    assert fd.calc_speed(0, 3, 2) == 0.6666666666666666
    assert fd.calc_speed(0, 3, 3) == 1.0
    assert fd.calc_speed(0, 4, 3) == 0.75

# Generated at 2022-06-18 13:00:07.552830
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader(None, None)
    start_time = time.time()
    fd.slow_down(start_time, None, 100)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, None, 100000)
    assert time.time() - start_time >= 0.1
    fd.slow_down(start_time, None, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, None, None)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, time.time(), 100)
    assert time.time() - start_time < 0.1

# Generated at 2022-06-18 13:00:19.106487
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte/s
    fd = FileDownloader({'ratelimit': 1})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2)
    assert time.time() - start_time >= 0.1
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 3)
    assert time.time() - start_time >= 0.2

# Generated at 2022-06-18 13:00:28.246000
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': '1k'}
    start_time = time.time()
    fd.slow_down(start_time, None, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, None, 2048)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, None, 512)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, None, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, None, 1024)
    assert time.time() - start_time < 0.1

# Generated at 2022-06-18 13:00:39.509338
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import time
    import random
    import re
    import socket
    import threading
    import http.server
    import urllib.parse
    import urllib.request
    import urllib.error
    import ssl
    import hashlib
    import base64
    import email.utils
    import json
    import io
    import traceback
    import unittest
    import unittest.mock
    import warnings
    import http.client
    import socketserver
    import posixpath
    import posix
    import stat
    import errno
    import fcntl
    import select
    import functools
    import queue
    import collections
    import contextlib
    import itertools
    import gzip


# Generated at 2022-06-18 13:01:02.878667
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:01:15.281091
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    from youtube_dl.utils import encode_data_uri

    def _test_download(fd, filename, data):
        fd.download(filename, {'id': 'test', 'url': encode_data_uri(data)})
        assert os.path.exists(encodeFilename(filename))
        with open(encodeFilename(filename), 'rb') as f:
            assert f.read() == data

    def _test_download_to_stdout(fd, data):
        fd.download('-', {'id': 'test', 'url': encode_data_uri(data)})
        assert sys.stdout.buffer.read() == data

    def _test_download_to_fileobj(fd, data):
        f = tempfile.Tem

# Generated at 2022-06-18 13:01:28.009581
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:01:29.409064
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # TODO: implement
    pass


# Generated at 2022-06-18 13:01:40.527817
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import re
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encode_data_uri

    def _test_download(ydl, params, expected_status, expected_content):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:01:52.663959
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader({})
    fd.try_rename('a', 'b')
    fd.try_rename('a', 'a')
    fd.try_rename('a', 'a.part')
    fd.try_rename('a.part', 'a')
    fd.try_rename('a.part', 'a.part')
    fd.try_rename('a.part', 'b')
    fd.try_rename('a.part', 'b.part')
    fd.try_rename('a.part', 'b.part.part')
    fd.try_rename('a.part.part', 'b.part')
    fd.try_rename('a.part.part', 'b.part.part')

# Generated at 2022-06-18 13:01:53.901826
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # TODO
    pass


# Generated at 2022-06-18 13:02:04.848697
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 4
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 8
    assert fd.best_block_size(0, 10) == 8
    assert fd.best_block_size(0, 11) == 16
    assert fd.best_block_size(0, 20) == 16
    assert fd.best_block_size(0, 21) == 32
    assert fd.best

# Generated at 2022-06-18 13:02:15.622604
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test'), 'w')
    f.write('test')
    f.close()

    # Get the modification time of the file
    mtime = os.path.getmtime(os.path.join(tmpdir, 'test'))

    # Create a FileDownloader instance
    fd = FileDownloader({})

    # Test the method try_utime
    fd.try_utime(os.path.join(tmpdir, 'test'), None)

# Generated at 2022-06-18 13:02:24.122365
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:27.263745
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import namedtuple
    from io import StringIO
    from sys import stderr

    # Mock the stderr
    stderr = StringIO()

    # Create a FileDownloader object
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: stderr.write(args[0] + '\n')

    # Create a namedtuple to simulate a status dict
    Status = namedtuple('Status', ['status', 'downloaded_bytes', 'total_bytes', 'speed', 'eta', 'elapsed'])

    # Test the report_progress method
    fd.report_progress(Status('downloading', 0, None, None, None, None))

# Generated at 2022-06-18 13:03:35.276636
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import calendar

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-18 13:03:47.858373
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with rate limit of 1 byte per second
    fd = FileDownloader(params={'ratelimit': 1})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2)
    assert time.time() - start_time > 0.9
    assert time.time() - start_time < 1.1
    # Test with rate limit of 2 bytes per second
    fd = FileDownloader(params={'ratelimit': 2})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1)
    assert time.time() - start_time < 0.1

# Generated at 2022-06-18 13:03:58.640632
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.params = {
        'noprogress': False,
        'progress_with_newline': False,
    }

    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'downloaded_bytes': 100,
        'elapsed': 0.5,
    })

# Generated at 2022-06-18 13:04:08.958776
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:04:18.017051
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'finished'})

    # Test with progress
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 50, 'total_bytes': 100})

# Generated at 2022-06-18 13:04:27.929176
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from .utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []
            self.to_console_title_calls = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_calls.append((msg, skip_eol))

        def to_console_title(self, msg):
            self.to_console_title_calls.append(msg)

    class FakeFD(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl
            self.params = {
                'noprogress': False,
                'progress_with_newline': False,
            }


# Generated at 2022-06-18 13:04:38.894099
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 10) == 1
    assert fd.best_block_size(0, 100) == 1
    assert fd.best_block_size(0, 1000) == 1
    assert fd.best_block_size(0, 10000) == 1
    assert fd.best_block_size(0, 100000) == 1
    assert fd.best_block_size(0, 1000000) == 1
    assert fd.best_block_size(0, 10000000) == 1
    assert fd.best_block_size(0, 100000000) == 1

# Generated at 2022-06-18 13:04:49.411226
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('foo')
    fd.report_file_already_downloaded('foo\u1234')
    fd.report_file_already_downloaded('foo\u1234\u5678')
    fd.report_file_already_downloaded('foo\u1234\u5678\u9abc')
    fd.report_file_already_downloaded('foo\u1234\u5678\u9abc\udef0')
    fd.report_file_already_downloaded('foo\u1234\u5678\u9abc\udef0\u4321')
    fd.report_file_already_

# Generated at 2022-06-18 13:04:58.098134
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.metadata import BaseMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import AudioConversionError
    from youtube_dl.postprocessor.ffmpeg import PostProcessingError