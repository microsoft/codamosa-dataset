

# Generated at 2022-06-18 12:56:47.005015
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'

# Generated at 2022-06-18 12:56:58.183588
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 1})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 1, 'total_bytes': 1})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 1, 'total_bytes': 2})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 1, 'total_bytes': 2, 'speed': 1})

# Generated at 2022-06-18 12:57:10.725732
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import re
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encode_data_uri

    def _test_download(ydl, params, expected_status, expected_filename,
                       expected_status_dict):
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tmpfilename = tf.name

# Generated at 2022-06-18 12:57:14.747716
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('filename')
    assert fd.to_screen('[download] filename has already been downloaded')


# Generated at 2022-06-18 12:57:27.344216
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(61) == '01:01'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(3661) == '01:01:01'
    assert FileDownloader.format_eta(86400) == '24:00:00'

# Generated at 2022-06-18 12:57:40.056110
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    from .YoutubeDL import YoutubeDL
    from .compat import compat_urllib_request
    from .extractor import get_info_extractor
    from .utils import encodeFilename

    def _test_download(ydl, ie, params, expected_status, expected_filename, expected_status_msg):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:57:47.626723
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2048)
    assert time.time() - start_time > 0.1
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 512)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1

# Generated at 2022-06-18 12:57:58.545938
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test download method of FileDownloader
    #
    # This test is not complete, but it should be enough to detect
    # major changes in the code.
    #
    # Run it with:
    #   $ python -m youtube_dl.FileDownloader --test-download
    #
    # It will download a video and compare the result with a reference
    # file.

    import doctest
    import tempfile
    import shutil
    import os
    import sys
    import difflib

    from .YoutubeDL import YoutubeDL
    from .compat import compat_urllib_request

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 12:58:06.388980
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(1, 1) == 1
    assert fd.best_block_size(1, 2) == 2
    assert fd.best_block_size(1, 4) == 4
    assert fd.best_block_size(1, 8) == 4
    assert fd.best_block_size(1, 16) == 4
    assert fd.best_block_size(1, 32) == 4
    assert fd.best_block_size(1, 64) == 4
    assert fd.best_block_size(1, 128) == 4
    assert fd.best_block_size(1, 256) == 4
    assert fd.best_block_size(1, 512) == 4
    assert fd.best_block_

# Generated at 2022-06-18 12:58:15.660355
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best

# Generated at 2022-06-18 12:58:49.177770
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': 200,
        'total_bytes_estimate': 200,
        'speed': 50,
        'eta': 10,
    })
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100,
        'total_bytes': 200,
        'total_bytes_estimate': 200,
        'speed': 50,
        'eta': None,
    })

# Generated at 2022-06-18 12:59:00.867810
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0.001, 0) is None
    assert fd.calc_speed(0, 0.001, 1) == 1000
    assert fd.calc_speed(0, 0.001, 1000) == 1000000
    assert fd.calc_speed(0, 0.001, 1000000) == 1000000000
    assert fd.calc_speed(0, 0.001, 1000000000) == 1000000000000
    assert fd.calc_speed(0, 0.001, 1000000000000) == 1000000000000000
    assert fd.calc_speed(0, 0.001, 1000000000000000) == 1000000000000000000
    assert fd.calc

# Generated at 2022-06-18 12:59:13.557202
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(61) == '01:01'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(3661) == '01:01:01'
    assert FileDownloader.format_eta(86400) == '24:00:00'
    assert FileDownloader.format_eta(86401) == '24:00:01'
    assert FileDownloader.format_eta(90061)

# Generated at 2022-06-18 12:59:23.448432
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_desc=None):
            self._downloader = downloader
            self._type = ie_key
            self._WORKING = True
            self.IE_NAME = ie_desc

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 12:59:35.589540
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def _test_slow_down(rate_limit, start, now, byte_counter, expected_sleep_time):
        fd = FileDownloader(None, params={'ratelimit': rate_limit})
        fd.slow_down(start, now, byte_counter)
        assert fd._sleep_time == expected_sleep_time

    _test_slow_down(None, 0, 0, 0, 0)
    _test_slow_down(None, 0, 0, 1, 0)
    _test_slow_down(None, 0, 1, 1, 0)
    _test_slow_down(None, 0, 1, 2, 0)
    _test_slow_down(None, 0, 1, 1024, 0)
    _test_slow_down(None, 0, 1, 1025, 0)
    _test

# Generated at 2022-06-18 12:59:44.079586
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a valid date
    assert FileDownloader.try_utime('/tmp/foo', 'Tue, 07 Feb 2012 12:13:14 GMT') == 1328651594

    # Test with an invalid date
    assert FileDownloader.try_utime('/tmp/foo', 'Tue, 07 Feb 2012 12:13:14') is None

    # Test with a date that is too old
    assert FileDownloader.try_utime('/tmp/foo', 'Tue, 07 Feb 2012 12:13:14 GMT') == 1328651594
    assert FileDownloader.try_utime('/tmp/foo', 'Tue, 07 Feb 2012 12:13:14 GMT') == 1328651594

    # Test with a date that is too new

# Generated at 2022-06-18 12:59:55.497763
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 2, 2) == 1.0
    assert fd.calc_speed(0, 3, 2) == 0.6666666666666666
    assert fd.calc_speed(0, 3, 3) == 1.0
    assert fd.calc_speed(0, 4, 3) == 0.75

# Generated at 2022-06-18 13:00:02.344352
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test for FileDownloader.report_progress
    # Create a FileDownloader object
    fd = FileDownloader({})
    # Test for status 'finished'
    fd.report_progress({'status': 'finished'})
    # Test for status 'downloading'
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 10})


# Generated at 2022-06-18 13:00:14.199022
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '10k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 1000)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 10000)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 100000)
    assert time.time() - start_time > 0.01


# Generated at 2022-06-18 13:00:24.650748
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with noprogress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 0})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes_estimate': 0})

# Generated at 2022-06-18 13:00:44.961416
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert FileDownloader.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part.part'
    assert FileDownloader.undo_

# Generated at 2022-06-18 13:00:55.690326
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.bar.part') == 'foo.bar.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.bar.baz') == 'foo.bar.baz.part'
    assert fd.temp_name('foo.bar.baz.qux') == 'foo.bar.baz.qux.part'

# Generated at 2022-06-18 13:01:07.960984
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-18 13:01:20.837417
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params['ratelimit'] = '10k'
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10 * 1024)
    fd.slow_down(0, 0, 20 * 1024)
    fd.slow_down(0, 0, 30 * 1024)
    fd.slow_down(0, 0, 40 * 1024)
    fd.slow_down(0, 0, 50 * 1024)
    fd.slow_down(0, 0, 60 * 1024)
    fd.slow_down(0, 0, 70 * 1024)
    fd.slow_down(0, 0, 80 * 1024)
    fd.slow_down(0, 0, 90 * 1024)
    fd

# Generated at 2022-06-18 13:01:32.957998
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test with a file that exists
    fd = FileDownloader({'nooverwrites': True}, {})
    fd.report_file_already_downloaded = lambda x: None
    fd.real_download = lambda x, y: None
    fd.to_screen = lambda x: None
    assert fd.download('test', {}) == True

    # Test with a file that doesn't exist
    fd = FileDownloader({'nooverwrites': True}, {})
    fd.report_file_already_downloaded = lambda x: None
    fd.real_download = lambda x, y: None
    fd.to_screen = lambda x: None
    assert fd.download('test', {}) == False

    # Test with a file that exists and continuedl is True
    fd

# Generated at 2022-06-18 13:01:42.716215
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.part.part') == 'foo.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part') == 'foo.part.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part.part') == 'foo.part.part.part.part'

# Generated at 2022-06-18 13:01:55.155582
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 8) == 4
    assert fd.best_block_size(0, 16) == 4
    assert fd.best_block_size(0, 32) == 4
    assert fd.best_block_size(0, 64) == 4
    assert fd.best_block_size(0, 128) == 4
    assert fd.best_block_size(0, 256) == 4
    assert fd.best_block_

# Generated at 2022-06-18 13:02:05.554558
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'
    assert FileDownloader.format_retries(9) == '9'

# Generated at 2022-06-18 13:02:16.829850
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    import random
    import subprocess
    import tempfile
    import shutil
    import os
    import sys
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.server
    import threading
    import socket
    import ssl
    import atexit
    import re
    import json
    import base64
    import hashlib
    import zlib
    import http.cookiejar
    import email.utils
    import email.message
    import email.parser
    import mimetypes
    import io
    import traceback
    import warnings
    import functools
    import subprocess
    import collections
    import concurrent.futures
    import queue
    import tempfile
    import shutil
    import os
    import sys
    import urllib.request

# Generated at 2022-06-18 13:02:25.866599
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None)
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('1m') == 1024 ** 2
    assert fd.parse_bytes('1M') == 1024 ** 2
    assert fd.parse_bytes('1g') == 1024 ** 3
    assert fd.parse_bytes('1G') == 1024 ** 3
    assert fd.parse_bytes('1t') == 1024 ** 4
    assert fd.parse_bytes('1T') == 1024 ** 4
    assert fd.parse_bytes('1p') == 1024 ** 5
    assert fd.parse_bytes('1P') == 1024 ** 5
    assert fd.parse_bytes

# Generated at 2022-06-18 13:02:43.093939
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '0:00'
    assert FileDownloader.format_eta(1) == '0:01'
    assert FileDownloader.format_eta(10) == '0:10'
    assert FileDownloader.format_eta(60) == '1:00'
    assert FileDownloader.format_eta(61) == '1:01'
    assert FileDownloader.format_eta(70) == '1:10'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(3601) == '1:00:01'
    assert FileDownloader.format_eta(3610) == '1:00:10'

# Generated at 2022-06-18 13:02:54.776224
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:03:05.645856
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import subprocess
    import re
    import urllib.parse
    import http.server
    import socketserver
    import threading
    import socket
    import ssl
    import hashlib
    import json
    import io
    import base64
    import binascii
    import http.client
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.cookiejar
    import email.utils
    import email.message
    import email.parser
    import email.policy
    import collections
    import functools
    import traceback
    import locale
    import platform
    import stat
    import struct
    import fcntl
    import errno

# Generated at 2022-06-18 13:03:10.968218
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: x
    fd.report_file_already_downloaded('test.mp4')
    assert fd.to_screen.called
    assert fd.to_screen.call_args[0][0] == '[download] test.mp4 has already been downloaded'


# Generated at 2022-06-18 13:03:23.586136
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.FileDownloader import FileDownloader
    from youtube_dl.utils import DateRange

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.to_screen_buffer = StringIO()

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_buffer.write(msg)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

        def to_console_title(self, msg):
            pass


# Generated at 2022-06-18 13:03:33.344202
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'eta': 10})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'eta': 10, 'speed': 10})

# Generated at 2022-06-18 13:03:45.970087
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 2, 2) == 1.0
    assert fd.calc_speed(0, 2, 3) == 1.5
    assert fd.calc_speed(0, 3, 2) == 0.6666666666666666
    assert fd.calc_speed(0, 3, 3) == 1.0

# Generated at 2022-06-18 13:03:51.603886
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '00:01'
    assert FileDownloader.format_seconds(10) == '00:10'
    assert FileDownloader.format_seconds(60) == '01:00'
    assert FileDownloader.format_seconds(3601) == '01:00:01'
    assert FileDownloader.format_seconds(36010) == '10:00:10'
    assert FileDownloader.format_seconds(360000) == '100:00:00'
    assert FileDownloader.format_seconds(3600000) == '1000:00:00'
    assert FileDownloader.format_seconds(36000000) == '10000:00:00'
    assert FileDownloader.format_seconds(360000000) == '100000:00:00'
    assert FileDownloader.format_seconds

# Generated at 2022-06-18 13:03:58.346106
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a file that exists
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_error = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    fd.params['outtmpl'] = '%(id)s'
    fd.params['restrictfilenames'] = True
    fd.params['nooverwrites'] = True
    fd.params['continuedl'] = True
    fd.params['nopart'] = True
    fd.params['sleep_interval'] = True
    fd.params['max_sleep_interval'] = True
    fd.params['verbose'] = True

    # Test with a file that exists


# Generated at 2022-06-18 13:04:08.626928
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(36000) == '10:00:00'
    assert FileDownloader.format_seconds(360000) == '100:00:00'
    assert FileDownloader.format_seconds(3600000) == '1000:00:00'
    assert FileDownloader.format_seconds(36000000) == '10000:00:00'
    assert FileDownloader.format_seconds(360000000) == '100000:00:00'
    assert FileDownloader.format_seconds

# Generated at 2022-06-18 13:04:27.831256
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-18 13:04:38.797723
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.params = {'noprogress': False}
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 1})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 50, 'eta': 1})

# Generated at 2022-06-18 13:04:49.376255
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'

# Generated at 2022-06-18 13:04:58.098214
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0.001, 0) is None
    assert fd.calc_speed(0, 0.001, 1) == 1000
    assert fd.calc_speed(0, 0.001, 1024) == 1024000
    assert fd.calc_speed(0, 0.001, 1024 * 1024) == 1024000000
    assert fd.calc_speed(0, 0.001, 1024 * 1024 * 1024) == 1024000000000
    assert fd.calc_speed(0, 0.001, 1024 * 1024 * 1024 * 1024) == 1024000000000000

# Generated at 2022-06-18 13:05:09.662814
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader(None, None)
    assert fd.try_rename('a', 'b') is None
    assert fd.try_rename('a', 'a') is None
    assert fd.try_rename('a', 'a.part') is None
    assert fd.try_rename('a.part', 'a') is None
    assert fd.try_rename('a.part', 'a.part') is None
    assert fd.try_rename('a.part', 'b.part') is None
    assert fd.try_rename('a.part', 'b') is None
    assert fd.try_rename('a', 'b.part') is None
    assert fd.try_rename('a.part', 'b.part') is None
    assert fd

# Generated at 2022-06-18 13:05:21.650662
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'

# Generated at 2022-06-18 13:05:34.545925
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime
    import pytest

    def _test_try_utime(fd, filename, last_modified_hdr, expected_result):
        fd.try_utime(filename, last_modified_hdr)
        assert os.path.getmtime(filename) == expected_result

    def _test_try_utime_raises(fd, filename, last_modified_hdr):
        with pytest.raises(Exception):
            fd.try_utime(filename, last_modified_hdr)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:05:43.477450
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'
    assert FileDownloader.format_seconds(3660) == '1:01:00'

# Generated at 2022-06-18 13:05:55.120317
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:06:06.544447
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.part.part') == 'abc.part.part.part'
    assert fd.temp_name('abc.part.part.part.part') == 'abc.part.part.part.part'
    assert fd.temp_name('abc.part.part.part.part.part') == 'abc.part.part.part.part.part'