

# Generated at 2022-06-18 12:56:58.257243
# Unit test for method download of class FileDownloader

# Generated at 2022-06-18 12:57:10.724864
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 1)
    assert time.time() - start_time < 0.01
    fd.slow_down(start_time, start_time, 2)
    assert time.time() - start_time > 0.01
    fd.slow_down(start_time, start_time, 3)
    assert time.time() - start_time > 0.01
    fd.slow_down(start_time, start_time, 4)
    assert time.time() - start_time > 0.

# Generated at 2022-06-18 12:57:22.939697
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part.part') == 'abc.part.part'
    assert fd.temp_name('abc.part.mp3') == 'abc.part.mp3'
    assert fd.temp_name('abc.part.mp3.part') == 'abc.part.mp3.part'
    assert fd.temp_name('abc.mp3') == 'abc.mp3.part'
    assert fd.temp_name('abc.mp3.part') == 'abc.mp3.part'
    assert fd.temp_name('abc.mp3.part.part')

# Generated at 2022-06-18 12:57:35.195819
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import datetime

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 12:57:45.471355
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best

# Generated at 2022-06-18 12:57:57.730822
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.FileDownloader import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen_buffer = StringIO()
            self.to_console_title_buffer = StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')


# Generated at 2022-06-18 12:58:09.112604
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '10'}, None)
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 1)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 11)
    fd.slow_down(0, 0, 100)
    fd.slow_down(0, 0, 101)
    fd.slow_down(0, 0, 1000)
    fd.slow_down(0, 0, 1001)
    fd.slow_down(0, 0, 10000)
    fd.slow_down(0, 0, 10001)
    fd.slow_down(0, 0, 100000)

# Generated at 2022-06-18 12:58:20.969478
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2048)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time > 0

# Generated at 2022-06-18 12:58:29.309021
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'

# Generated at 2022-06-18 12:58:39.187473
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert fd.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part'
    assert fd.undo_

# Generated at 2022-06-18 12:58:58.957913
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params['ratelimit'] = '1k'
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1024)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 2048)
    assert time.time() - start_time > 0.1
    fd.slow_down(start_time, start_time, 512)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 1024)
    assert time.time()

# Generated at 2022-06-18 12:59:11.689900
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 100, 'total_bytes': None})

    # Test with progress
    fd = FileDownloader({'noprogress': False})

# Generated at 2022-06-18 12:59:22.245379
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None
    fd.report_progress({'status': 'finished', 'total_bytes': 100})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 5})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 5})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10, 'eta': 5})
    fd

# Generated at 2022-06-18 12:59:34.394070
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(0) == '0'
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(4) == '4'
    assert FileDownloader.format_retries(5) == '5'
    assert FileDownloader.format_retries(6) == '6'
    assert FileDownloader.format_retries(7) == '7'
    assert FileDownloader.format_retries(8) == '8'

# Generated at 2022-06-18 12:59:43.509998
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(params={})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.part.part') == 'foo.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part') == 'foo.part.part.part'
    assert fd.undo_temp_name('foo.part.part.part.part.part') == 'foo.part.part.part.part'

# Generated at 2022-06-18 12:59:54.640462
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader(None)
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(3) == '3'
    assert fd.format_retries(4) == '4'
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(6) == '6'
    assert fd.format_retries(7) == '7'
    assert fd.format_retries(8) == '8'

# Generated at 2022-06-18 13:00:06.561429
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test slow_down with rate limit
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': 10}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 20)
    fd.slow_down(0, 0, 30)
    fd.slow_down(0, 0, 40)
    fd.slow_down(0, 0, 50)
    fd.slow_down(0, 0, 60)
    fd.slow_down(0, 0, 70)
    fd.slow_down(0, 0, 80)
    fd.slow_down(0, 0, 90)

# Generated at 2022-06-18 13:00:18.260113
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import namedtuple
    Status = namedtuple('Status', ['status', 'downloaded_bytes', 'total_bytes', 'speed', 'eta', 'elapsed'])
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd._report_progress_status = lambda *args, **kargs: None
    fd.report_progress(Status('downloading', 0, None, None, None, None))
    fd.report_progress(Status('downloading', 0, None, 0, None, None))
    fd.report_progress(Status('downloading', 0, None, 0, 0, None))
    fd.report_progress(Status('downloading', 0, None, 0, 0, 0))

# Generated at 2022-06-18 13:00:27.549703
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(0, 1, 1) == 0
    assert fd.calc_eta(0, 2, 1) == 1
    assert fd.calc_eta(0, 1, 2) == 1
    assert fd.calc_eta(0, 2, 2) == 1
    assert fd.calc_eta(0, 3, 2) == 1
    assert fd.calc_eta(0, 2, 3) == 1
    assert fd.calc_eta(0, 3, 3) == 1

# Generated at 2022-06-18 13:00:38.506412
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os
    import time
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:00:56.239183
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '1'})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert time.time() - start < 0.1
    fd.slow_down(start, start, 1)
    assert time.time() - start > 0.1
    fd.slow_down(start, start, 2)
    assert time.time() - start > 0.2
    fd.slow_down(start, start, 3)
    assert time.time() - start > 0.3
    fd.slow_down(start, start, 4)
    assert time.time() - start > 0.4
    fd.slow_down(start, start, 5)
    assert time.time() - start > 0.5
    f

# Generated at 2022-06-18 13:01:08.901973
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.to_console_title = lambda *args, **kargs: None

    # Test with total_bytes
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 10,
        'speed': 10,
        'eta': 10,
    })
    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 100,
        'downloaded_bytes': 20,
        'speed': 10,
        'eta': 10,
    })

# Generated at 2022-06-18 13:01:21.743493
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader({'noprogress': True})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})

    # Test with progress
    fd = FileDownloader({'noprogress': False})
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0})
    fd.report_progress({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None})

# Generated at 2022-06-18 13:01:33.993962
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3661) == '1:01:01'
    assert FileDownloader.format_seconds(86400) == '1:00:00:00'
    assert FileDownloader.format_seconds(86401) == '1:00:00:01'
    assert FileDownloader.format_seconds

# Generated at 2022-06-18 13:01:43.164763
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 ** 2
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1g') == 1024 ** 3
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1t') == 1024 ** 4
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1p') == 1024 ** 5
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_

# Generated at 2022-06-18 13:01:55.474315
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('foo') == 'foo.part'
    assert fd.temp_name('foo.bar') == 'foo.bar.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.part') == 'foo.part.part'
    assert fd.temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.temp_name('foo.part.bar.part') == 'foo.part.bar.part'
    assert fd.temp_name('foo.part.bar.part.part') == 'foo.part.bar.part.part'
    assert fd.temp_name('foo.part.bar.part.part.part')

# Generated at 2022-06-18 13:02:05.735126
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader({})
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('1m') == 1024 * 1024
    assert fd.parse_bytes('1M') == 1024 * 1024
    assert fd.parse_bytes('1g') == 1024 * 1024 * 1024
    assert fd.parse_bytes('1G') == 1024 * 1024 * 1024
    assert fd.parse_bytes('1.5k') == 1024 + 512
    assert fd.parse_bytes('1.5K') == 1024 + 512
    assert fd.parse_bytes('1.5m') == 1024 * 1024 + 512 * 1024

# Generated at 2022-06-18 13:02:17.060135
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 0, 1) is None
    assert fd.calc_eta(0, 1, 0) is None
    assert fd.calc_eta(1, 0, 0) is None
    assert fd.calc_eta(1, 0, 1) is None
    assert fd.calc_eta(1, 1, 0) is None
    assert fd.calc_eta(1, 1, 1) == 0
    assert fd.calc_eta(1, 2, 1) == 1
    assert fd.calc_eta(1, 2, 2) == 0

# Generated at 2022-06-18 13:02:24.760625
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test for FileDownloader.download
    # Create a FileDownloader object
    fd = FileDownloader({})
    # Create a fake info dict

# Generated at 2022-06-18 13:02:37.129710
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import io
    import time
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.FileDownloader import FileDownloader
    from youtube_dl.utils import format_bytes
    from youtube_dl.compat import compat_os_name

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            super(FakeYDL, self).__init__(params)
            self.to_screen_buffer = io.StringIO()
            self.to_console_title_buffer = io.StringIO()

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')


# Generated at 2022-06-18 13:03:08.864954
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.common import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM4aPP

# Generated at 2022-06-18 13:03:21.577829
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:03:32.511620
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 1024) == 1024
    assert fd.best_block_size(0, 1025) == 2048
    assert fd.best_block_size(0, 1048576) == 1048576
    assert fd.best_block_size(0, 1048577) == 4194304
    assert fd.best_block_size(0, 4194304) == 4194304
    assert fd.best_block_size(0, 4194305) == 4194304
    assert fd.best_block_size(1, 0) == 1
    assert fd.best_block_size

# Generated at 2022-06-18 13:03:44.912668
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test with a non-existing file
    fd = FileDownloader({})
    assert fd.try_utime('/non/existing/file', 'Thu, 01 Jan 1970 00:00:00 +0000') is None

    # Test with a file that exists
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_error = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    fd.trouble = lambda *args, **kargs: None
    fd.params['nopart'] = True
    fd.params['continuedl'] = False
    fd.params['nooverwrites'] = True

# Generated at 2022-06-18 13:03:56.203386
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import time
    from io import StringIO
    from collections import namedtuple

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_buffer = StringIO()
            self.to_console_title_buffer = StringIO()

        def to_screen(self, msg, skip_eol=False):
            if not skip_eol:
                msg += '\n'
            self.to_screen_buffer.write(msg)

        def to_console_title(self, msg):
            self.to_console_title_buffer.write(msg)

    class FakeFD(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl

# Generated at 2022-06-18 13:04:02.752880
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'


# Generated at 2022-06-18 13:04:12.958878
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part.part') == 'foo.part'
    assert fd.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part') == 'foo.part.bar'
    assert fd.undo_temp_name('foo.part.bar.part.part') == 'foo.part.bar.part'
    assert fd.undo_temp_name('foo.part.bar.part.part.part') == 'foo.part.bar.part'
    assert fd

# Generated at 2022-06-18 13:04:20.640268
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    fd = FileDownloader(None, None)
    fd.params['noprogress'] = True
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})

    # Test with progress
    fd.params['noprogress'] = False
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'downloading'})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50})
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'downloaded_bytes': 50, 'speed': 10})

# Generated at 2022-06-18 13:04:31.296293
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test for FileDownloader.report_progress
    # Create a FileDownloader object
    fd = FileDownloader({})
    # Test for status = 'finished'
    fd.report_progress({'status': 'finished', 'total_bytes': 100, 'elapsed': 10})
    # Test for status = 'downloading'
    fd.report_progress({'status': 'downloading', 'total_bytes': 100, 'elapsed': 10, 'eta': 10, 'speed': 10})
    # Test for status = 'error'
    fd.report_progress({'status': 'error'})
    # Test for status = 'error'
    fd.report_progress({'status': 'error'})
    # Test for status = 'error'
    fd.report_progress({'status': 'error'})
    #

# Generated at 2022-06-18 13:04:42.557711
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    fd.params = {'ratelimit': 10}
    fd.slow_down(0, 0, 0)
    fd.slow_down(0, 0, 10)
    fd.slow_down(0, 0, 20)
    fd.slow_down(0, 0, 30)
    fd.slow_down(0, 0, 40)
    fd.slow_down(0, 0, 50)
    fd.slow_down(0, 0, 60)
    fd.slow_down(0, 0, 70)
    fd.slow_down(0, 0, 80)
    fd.slow_down(0, 0, 90)
    fd.slow_down(0, 0, 100)
    fd.slow_down

# Generated at 2022-06-18 13:05:16.693346
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(0, 2) == 2
    assert fd.best_block_size(0, 3) == 2
    assert fd.best_block_size(0, 4) == 4
    assert fd.best_block_size(0, 5) == 4
    assert fd.best_block_size(0, 6) == 4
    assert fd.best_block_size(0, 7) == 4
    assert fd.best_block_size(0, 8) == 8
    assert fd.best_block_size(0, 9) == 8
    assert fd.best_block_

# Generated at 2022-06-18 13:05:25.826523
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    fd = FileDownloader({'ratelimit': '10'})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 10)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time, 20)
    assert time.time() - start_time > 0.1
    assert time.time() - start_time < 0.2
    fd.slow_down(start_time, start_time, 5)
    assert time.time() - start_time < 0.1
    fd.slow_down(start_time, start_time + 0.1, 5)
    assert time.time() - start_time < 0.2

# Generated at 2022-06-18 13:05:37.292444
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '1k'})
    start_time = time.time()
    fd.slow_down(start_time, start_time + 1, 1024)
    assert time.time() - start_time < 1.1
    fd.slow_down(start_time, start_time + 1, 1024 * 10)
    assert time.time() - start_time > 0.9
    fd.slow_down(start_time, start_time + 1, 1024 * 100)
    assert time.time() - start_time > 0.9
    fd.slow_down(start_time, start_time + 1, 1024 * 1000)
    assert time.time() - start_time > 0.9

# Generated at 2022-06-18 13:05:45.392918
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import random
    import re
    import subprocess
    import socket
    import http.client
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.server
    import threading
    import ssl
    import json
    import zlib
    import base64
    import hashlib
    import email.utils
    import email.message
    import email.parser
    import io
    import gzip
    import http.cookiejar
    import http.cookies
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import http.server
    import http.cookies
    import http

# Generated at 2022-06-18 13:05:56.300451
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1024 * 1024
    assert FileDownloader.parse_bytes('1M') == 1024 * 1024
    assert FileDownloader.parse_bytes('1g') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1G') == 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1.5k') == 1024 + 512
    assert FileDownloader.parse_bytes('1.5K') == 1024 + 512
    assert FileDownloader.parse_bytes('1.5m') == 1024 * 1024 + 512 * 1024