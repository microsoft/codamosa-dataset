

# Generated at 2022-06-22 06:40:14.739832
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    # TODO test RateLimitRetry
    # TODO test external downloader

    # Test download to file
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        fd = FileDownloader(parameters={'outtmpl': tf.name})
        assert fd.download('dummy1', {'url': 'dummy2'})

    with tempfile.NamedTemporaryFile() as tf:
        fd = FileDownloader(parameters={'outtmpl': tf.name, 'verbose': True})
        assert fd.download('dummy1', {'url': 'dummy2'})
        assert os.path.getsize(tf.name) == 0

    # Test noprogress

# Generated at 2022-06-22 06:40:23.205775
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '  0%'
    assert FileDownloader.format_percent(1) == '  1%'
    assert FileDownloader.format_percent(10) == ' 10%'
    assert FileDownloader.format_percent(100) == '100%'
    assert FileDownloader.format_percent(1000) == '???'
    assert FileDownloader.format_percent(101) == ' 10%'
    assert FileDownloader.format_percent(110) == ' 10%'



# Generated at 2022-06-22 06:40:28.985191
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd = FileDownloader({})
    fd._debug_cmd = lambda *args, **kargs: None
    fd._hook_progress = lambda *args, **kargs: None
    class ProgressHook:
        def __init__(self):
            self.x = ''
        def __call__(self, d):
            self.x += d['status']
    ph = ProgressHook()
    fd.add_progress_hook(ph)
    fd._hook_progress({'status': 'abc'})
    assert ph.x == 'abc'

# Generated at 2022-06-22 06:40:37.834481
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    print("Testing FileDownloader_slow_down method")
    fd=FileDownloader(params)
    start=time.time()
    for i in range(10):
        start=time.time()
        fd.slow_down(start,None,1000000)
        print("Test iteration ",i,time.time()-start)
        if i>=1:
            if (time.time()-start)<=2:
                print("test_FileDownloader_slow_down test failed")
                return
    print("test_FileDownloader_slow_down test passed")


# Generated at 2022-06-22 06:40:43.933126
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(YoutubeDL(), {})
    fd.to_screen = lambda x: x
    assert fd.report_file_already_downloaded('foo') == '[download] foo has already been downloaded'
    assert fd.report_file_already_downloaded('foo bar') == '[download] The file has already been downloaded'

# Generated at 2022-06-22 06:40:55.813694
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """
    Unit test for method report_progress of class FileDownloader

    """
    def test(cmd):
        class MockInfoDict():
            pass

        info_dict = MockInfoDict()
        info_dict.total_bytes = cmd['total_bytes']
        info_dict.total_bytes_estimate = cmd['total_bytes_estimate']
        info_dict.status = cmd['status']
        info_dict.eta = cmd['eta']
        info_dict.downloaded_bytes = cmd['downloaded_bytes']
        info_dict.elapsed = cmd['elapsed']
        info_dict.speed = cmd['speed']

        class MockYDL():
            def to_screen(s, l):
                print('to_screen_call, l=%r' % l)
                assert l == cmd['expected']

# Generated at 2022-06-22 06:41:03.476305
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    filename = 'filename'
    old_filename = 'old_' + filename
    new_filename = 'new_' + filename
    fd = FileDownloader({'outtmpl': filename})

    try_rename_mock = Mock(return_value=None)

    with patch('youtube_dl.downloader.os.rename', try_rename_mock):
        fd.try_rename(old_filename, new_filename)

        try_rename_mock.assert_called_once_with(
            encodeFilename(old_filename), encodeFilename(new_filename))

# Generated at 2022-06-22 06:41:09.368440
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader(None)

    e = (
        (0, '  0%'),
        (0.1, ' 10%'),
        (0.123, ' 12%'),
        (0.125, ' 12%'),
        (0.5, ' 50%'),
        (0.99, ' 99%'),
        (0.999, '100%'),
        (1, '100%'),
        (1.0, '100%'),
        (1.001, '100%'),
        (None, 'Unknown %'),
    )

    for (pct, res) in e:
        assert (fd.format_percent(pct)) == res

# Generated at 2022-06-22 06:41:20.650415
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    fd = FileDownloader({'continuedl': True, 'noprogress': True})
    fd.add_progress_hook(lambda d: None)

    # Check if the FileDownloader was created correctly
    assert fd.params['continuedl'] == True
    assert fd.params['noprogress'] == True

    # Check if the progress hook was added correctly
    assert len(fd._progress_hooks) == 1 and callable(fd._progress_hooks[0])

    # Check if the FileDownloader has a correct set of methods
    assert callable(fd.report_progress)
    assert callable(fd.report_resuming_byte)
    assert callable(fd.report_retry)
    assert callable(fd.report_file_already_downloaded)

# Generated at 2022-06-22 06:41:32.202021
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    # Create a temporary file that has the same name as the downloaded file
    temp_file = tempfile.NamedTemporaryFile()
    temp_file_name = temp_file.name
    file_downloader = FileDownloader({}, YoutubeDL({}))
    # Test that the file can be renamed (that is, the temporary file has been created)
    assert(file_downloader.try_rename(temp_file_name, temp_file_name))
    # Test that the temporary file has been correctly renamed
    file_downloader.try_rename(temp_file_name, temp_file_name + '_renamed')
    assert(os.path.isfile(temp_file_name + '_renamed'))
    assert(not os.path.isfile(temp_file_name))
    temp_file.close()



# Generated at 2022-06-22 06:41:48.645102
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # The test values are:
    #   A: [best_block_size, expected_eta]
    #   B: [elapsed_time, block_size]
    #
    # For each test, the last block is downloaded in an elapsed time
    # that varies from the nominal rate, either:
    #    - slower (B[0] < A[0] * B[1])
    #    - faster (B[0] > A[0] * B[1])
    # In both cases, the upload rate of the next block should be
    # increased/decreased so that the ETA is the same as the expected one.
    A = [[      1,   100],
         [     10,    10],
         [    100,     1]]

# Generated at 2022-06-22 06:41:58.033998
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    # Test with invalid input
    assert(FileDownloader.format_eta(None)=='--:--')
    # Test with valid input
    assert(FileDownloader.format_eta(0)=='00:00')
    assert(FileDownloader.format_eta(10)=='00:10')
    assert(FileDownloader.format_eta(60)=='01:00')
    assert(FileDownloader.format_eta(120)=='02:00')
    assert(FileDownloader.format_eta(3600)=='01:00:00')



# Generated at 2022-06-22 06:42:07.592371
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({})
    fd.to_screen = lambda *args: None
    # No speed limit
    fd.slow_down(time.time(), time.time() + 2, 50)

    fd.params['ratelimit'] = 10
    # Speed slower than ratelimit
    fd.slow_down(time.time(), time.time() + 2, 10)

    # Speed faster than ratelimit for 1 second
    fd.slow_down(time.time(), time.time() + 1, 20)

    # Speed faster than ratelimit for 10 second
    fd.slow_down(time.time(), time.time() + 10, 20)


# Generated at 2022-06-22 06:42:19.236682
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    def _test_trouble(error, expected_msg):
        fd = FileDownloader({})
        # Test 1: trouble() with a string argument
        fd.report_error(error)
        assert(fd.ydl.error_message == expected_msg)

        # Test 2: trouble() with a Exception argument
        fd.report_error(URLError(error))
        assert(fd.ydl.error_message == expected_msg)

        # Test 3: trouble() with a non-string argument
        fd.report_error(ValueError())
        assert(fd.ydl.error_message != expected_msg)

    _test_trouble('test', 'test')
    _test_trouble('test\nwith\nnewlines', 'test with newlines')
    _test_trouble

# Generated at 2022-06-22 06:42:28.419222
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    dler = FileDownloader(None, None)
    assert dler.undo_temp_name('abc') == 'abc'
    assert dler.undo_temp_name('abc.part') == 'abc'
    assert dler.undo_temp_name('abc.part.part') == 'abc.part'
    assert dler.undo_temp_name('/home/xyz/abc') == '/home/xyz/abc'
    assert dler.undo_temp_name('/home/xyz/abc.part') == '/home/xyz/abc'
    assert dler.undo_temp_name('/home/xyz/abc.part.part') == '/home/xyz/abc.part'
    assert dler.undo_temp_name('abc') == 'abc'

# Generated at 2022-06-22 06:42:31.479889
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fdl = FileDownloader({})
    fdl.to_screen('hola')
    fdl.to_screen('adios')
    return

# Generated at 2022-06-22 06:42:42.478359
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({'nopart': True})
    assert (fd.temp_name('/a/b/c')) == '/a/b/c'
    assert (fd.temp_name('abc')) == 'abc'
    fd = FileDownloader({})
    assert (fd.temp_name('/a/b/c')) == '/a/b/c.part'
    assert (fd.temp_name('abc')) == 'abc.part'
    assert (fd.temp_name('/a/b/c.mp4')) == '/a/b/c.mp4.part'
    assert (fd.temp_name('abc.mp4')) == 'abc.mp4.part'

# Generated at 2022-06-22 06:42:50.232800
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    out = StringIO()
    fd = FileDownloader(out)
    fd.report_unable_to_resume()
    fd.report_unable_to_resume()
    fd.report_unable_to_resume()
    fd.report_unable_to_resume()
    assert out.getvalue() == """\
[download] Unable to resume
[download] Unable to resume
[download] Unable to resume
[download] Unable to resume
"""

# Generated at 2022-06-22 06:43:00.345875
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader(None, None)
    import tempfile
    tmpfd, tmpname = tempfile.mkstemp()
    tmp2fd, tmp2name = tempfile.mkstemp()

    fd.try_rename(tmpname, tmp2name)
    assert os.path.exists(tmp2name)
    assert not os.path.exists(tmpname)

    # don't overwrite files
    with open(tmpname, 'wb') as stuff:
        stuff.write(b'foo')
    assert fd.try_rename(tmpname, tmp2name) == None
    with open(tmpname, 'rb') as stuff:
        assert stuff.read() == b'foo'
    with open(tmp2name, 'rb') as stuff:
        assert stuff.read() == b''

    #

# Generated at 2022-06-22 06:43:11.670636
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    for s, r in [('123456789', 123456789),
                 ('1.23456789', 12345678),
                 ('123', 123),
                 ('123e3', 123000),
                 ('12.3e3', 12300),
                 ('12.3e5', 1230000),
                 ('12.3e-5', 0),
                 ('12.3E5', 1230000),
                 ('12.3E-5', 0),
                 ('12.3e+5', 1230000),
                 ('12.3E+5', 1230000),
                 ('12.3e456789', 1230000000000000000000000000)]:
        assert FileDownloader.parse_bytes(s) == r
    for s in ['12,3e5', '12.3f5', '123ef', 'hello world']:
        assert File

# Generated at 2022-06-22 06:43:31.869909
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    params = {'usenetrc': '-u u -p p -a n', 'username': 'u', 'password': 'p', 'noprogress': True, 'quiet': True}
    InfoExtractor(FileDownloader(params))
    params = {'usenetrc': '-a n', 'noprogress': True, 'quiet': True}
    InfoExtractor(FileDownloader(params))
    params = {'usenetrc': '-a n', 'noprogress': True, 'quiet': True, 'username': 'u'}
    InfoExtractor(FileDownloader(params))
    params = {'usenetrc': '-a n', 'noprogress': True, 'quiet': True, 'username': 'u', 'password': 'p'}

# Generated at 2022-06-22 06:43:43.889859
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    fileobj = tempfile.NamedTemporaryFile()
    fileobj.close()
    filename = fileobj.name
    for s in [
            '2011-01-01T01:01:01.000001',
            '2011-01-01T01:01:01',
            '2011-01-01T01:01',
            '2011-01-01T01',
            '2011-01-01',
            '2011-01',
            '2011',
            0,
    ]:
        fd = FileDownloader({})
        fd.try_utime(filename, s)
        assert os.path.getmtime(filename) == timeconvert(s)



# Generated at 2022-06-22 06:43:50.024660
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():

    class FakeYDL:
        def to_screen(self, message):
            pass

    ydl = FakeYDL()
    to_stderr = lambda message: print(message)
    fd = FileDownloader(ydl)
    fd.to_stderr = to_stderr
    fd.to_stderr("test message")


# Generated at 2022-06-22 06:44:01.381380
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '   0%'
    assert FileDownloader.format_percent(1) == '   1%'
    assert FileDownloader.format_percent(10) == '  10%'
    assert FileDownloader.format_percent(100) == ' 100%'
    assert FileDownloader.format_percent(1000) == '1000%'
    assert FileDownloader.format_percent(0.1) == '   0%'
    assert FileDownloader.format_percent(1.1) == '   1%'
    assert FileDownloader.format_percent(10.1) == '  10%'
    assert FileDownloader.format_percent(100.1) == ' 100%'
    assert FileDownloader.format_percent(1000.1) == '1000%'

# Unit

# Generated at 2022-06-22 06:44:12.693445
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Cheat and use the internals of FileDownloader
    fd = FileDownloader({}, None)
    fd._progress_hooks = []
    assert not fd._progress_hooks
    noargs_hook = lambda: None
    fd.add_progress_hook(noargs_hook)
    assert fd._progress_hooks == [noargs_hook]
    withargs_hook = lambda x: None
    fd.add_progress_hook(withargs_hook)
    assert fd._progress_hooks == [noargs_hook, withargs_hook]
    fd.add_progress_hook(withargs_hook)
    assert fd._progress_hooks == [noargs_hook, withargs_hook, withargs_hook]


# Generated at 2022-06-22 06:44:19.837041
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import shutil

    tmpdir = os.path.join(os.path.dirname(__file__), 'test_temp_dir')
    shutil.rmtree(tmpdir, ignore_errors=True)
    os.mkdir(tmpdir)


# Generated at 2022-06-22 06:44:23.471608
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader({'format': 'best', 'noplaylist': True, 'nocheckcertificate': True, 'quiet':True})
    filename = 'video.mp4'
    print(fd.temp_name(filename))
    print(fd.download(filename, {"True":True}))

test_FileDownloader_download()


# Generated at 2022-06-22 06:44:27.022198
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Known cases
    D = FileDownloader({})
    assert D.best_block_size(2.0, 1024) == 512
    assert D.best_block_size(2.0, 10240) == 1536
    assert D.best_block_size(2.0, 102400) == 6144
    assert D.best_block_size(2.0, 10240000) == 98304
    assert D.best_block_size(2.0, 1024000000) == 4194304
    assert D.best_block_size(2.0, 102400000000) == 4194304



# Generated at 2022-06-22 06:44:29.873817
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(DummyYoutubeDl(), {})

    assert fd.undo_temp_name('abc.part') == 'abc'
    assert fd.undo_temp_name('abc.txt.part') == 'abc.txt'
    assert fd.undo_temp_name('abc') == 'abc'
    assert fd.undo_temp_name('') == ''


# Generated at 2022-06-22 06:44:30.315022
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    assert 1 == 1

# Generated at 2022-06-22 06:44:55.608034
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def fake_time():
        return 1
    old_time = time.time
    time.time = fake_time
    a = FileDownloader(None)
    assert a.try_utime('ya.txt', 'Thu, 16 Jul 2009 07:02:51 GMT') == 1247802571
    time.time = old_time

# Generated at 2022-06-22 06:45:00.360278
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    from pytube.compat import is_win32, get_filesystem_encoding
    from pytube.exceptions import SameFileError
    try:
        import io as StringIO
    except ImportError:
        from io import StringIO
    from pytube import FileDownloader
    from pytube.tests.compat import patch

    # setup
    fd = FileDownloader({}, {}, None)

    if is_win32:
        assert fd.try_rename('a', 'a') is None

    # test

# Generated at 2022-06-22 06:45:02.465502
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # This method is tested by the unit test test_calc_min_sleep_interval
    pass



# Generated at 2022-06-22 06:45:07.505741
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(FakeYDL(), {})
    err = OSError('Some message')
    # Call method
    fd.report_error('requesting', err)
    # Check result
    assert fd.ydl.msgs[-1] == 'ERROR: request failed: Some message'


# Generated at 2022-06-22 06:45:16.504449
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(0) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(1234567) == '%10s' % '1.15 MB/s'
    assert FileDownloader.format_speed(12345678) == '%10s' % '11.5 MB/s'
    assert FileDownloader.format_speed(123456789) == '%10s' % '115.5 MB/s'
    assert FileDownloader.format_speed(1234567890) == '%10s' % '1.13 GB/s'

# Generated at 2022-06-22 06:45:22.940748
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader()
    assert fd.undo_temp_name('foo.bar') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.part') == 'foo.bar'
    assert fd.undo_temp_name('foo.bar.partaaa') == 'foo.bar.partaaa'
    assert fd.undo_temp_name('foo.bar.part.baz') == 'foo.bar.part'


# Generated at 2022-06-22 06:45:26.614813
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # Active code for testing
    f = FileDownloader({})
    f.to_console_title('test')
    f.to_screen('testing')

# Generated at 2022-06-22 06:45:37.131196
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # Initialization
    ydl = YoutubeDL({})

    # Test with default values
    ydl.to_screen = MagicMock()
    fd = FileDownloader(ydl, {})
    fd.report_retry(OSError(404, 'Unable to download'), 5, float('inf'))
    assert ydl.to_screen.call_count == 1
    assert ydl.to_screen.call_args[0] == (
        '[download] Got server HTTP error: Unable to download. Retrying (attempt 5 of inf)...',)
    ydl.to_screen.reset_mock()

    # Test with custom values
    ydl.to_screen = MagicMock()

# Generated at 2022-06-22 06:45:39.363057
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    downloader = FileDownloader(params={})
    assert downloader.format_retries(5) == '5'
    assert downloader.format_retries(float('inf')) == 'inf'



# Generated at 2022-06-22 06:45:42.663309
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    file_downloader = FileDownloader
    assert file_downloader.format_retries(0) == '0'
    assert file_downloader.format_retries(1) == '1'
    assert file_downloader.format_retries(2) == '2'
    assert file_downloader.format_retries(10) == '10'

# Generated at 2022-06-22 06:46:10.880413
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader(None, None).undo_temp_name('foo') == 'foo'
    assert FileDownloader(None, None).undo_temp_name('foo.part') == 'foo'
    assert FileDownloader(None, None).undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader(None, None).undo_temp_name('foo.bar.part.part') == 'foo.bar.part'
    assert FileDownloader(None, None).undo_temp_name('.part') == ''
    assert FileDownloader(None, None).undo_temp_name('.foo.part') == '.foo'
    

# Generated at 2022-06-22 06:46:22.997821
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    from sys import stdout
    from time import time

    fd = FileDownloader({
        'outtmpl': '-'
    })

    def assert_correct_output(output, *args, **kargs):
        fd.to_screen(*args, **kargs)
        assert(output == stdout.getvalue())
        stdout.truncate(0)

    # Simulates the call to_screen('\r')
    fd.prev_line_len = 0
    stdout.truncate(0)

    assert_correct_output('[download] foo.mkv\n', '[download] foo.mkv')

    assert_correct_output('bar\r', 'bar', skip_eol=True)

    # Tests that the progress is well displayed
    fd.prev_line_len = 0
    std

# Generated at 2022-06-22 06:46:25.679055
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    s = {'retries': 2}
    assert format_retries(s) == '2'
    assert format_retries(s, float('inf')) == 'infinite'


# Generated at 2022-06-22 06:46:36.373292
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({}, FakeYDL())
    # Test typical values (including edge values)
    assert fd.best_block_size(3.14, 16 * 1024 * 1024) == 16 * 1024 * 1024
    assert fd.best_block_size(3.14, 1 * 1024 * 1024) == 1 * 1024 * 1024
    assert fd.best_block_size(3.14, 2 * 1024 * 1024) == 2 * 1024 * 1024
    assert fd.best_block_size(3.14, 2 * 1024 * 1024 + 1) == 4 * 1024 * 1024
    # Test abnormal values
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(None, None) == 4 * 1024 * 1024

# Generated at 2022-06-22 06:46:47.328530
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(9) == '0:09'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(11) == '0:11'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(71) == '1:11'
    assert FileDownloader.format_seconds(3609) == '1:00:09'

# Generated at 2022-06-22 06:46:56.755893
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    if os.environ.get('YOUTUBE_DL_FORCE_UTF8_SYS_STDOUT'):
        return

    assert FileDownloader.format_eta(52.3) == '52'
    assert FileDownloader.format_eta(52.5) == '53'
    assert FileDownloader.format_eta(51.8) == '52'
    assert FileDownloader.format_eta(0.2) == '00:00'
    assert FileDownloader.format_eta(0.9) == '00:01'
    assert FileDownloader.format_eta(5.8) == '00:06'
    assert FileDownloader.format_eta(62.7) == '01:03'
    assert FileDownloader.format_eta(3599.9) == '59:59'

# Generated at 2022-06-22 06:47:07.251548
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil

    def create_test_file(test_dir):
        fd, test_file = tempfile.mkstemp(dir=test_dir)
        os.close(fd)
        return test_file

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 06:47:14.533869
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    assert FileDownloader.calc_percent(None, None, None) == 0
    assert FileDownloader.calc_percent(100, 100, 0) == 100.0
    assert FileDownloader.calc_percent(100, 200, 0) == 50.0
    assert FileDownloader.calc_percent(100, 200, 50) == 100.0
    assert FileDownloader.calc_percent(0, 200, 50) == 25.0



# Generated at 2022-06-22 06:47:26.111570
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    fd.best_block_size = None

    def test(expected_block_size, elapsed_time, bytes, expected_return_value):
        assert fd.best_block_size(elapsed_time, bytes) == expected_block_size
        # Return value is the same as block_size on Python 3.2 and older
        # because of a bug in urllib.request.
        assert fd.best_block_size(elapsed_time, bytes,
                                  expected_return_value) == expected_return_value

    test(1024, 0.04, 50000, 1048576)
    test(1048576, 0.04, 50000, 1048576)
    test(2000000, 5, 10000000, 2000000)

# Generated at 2022-06-22 06:47:35.688164
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    dl = FileDownloader({})
    test_cases = [
        # (expected, elapsed_time, bytes)
        (1, 0.0, 0),
        (2, 0.2, 1),
        (3, 1.0, 1),
        (5, 1.0, 2),
        (8192, 1.0, 2**13),
        (16384, 1.0, 2**14),
        (32767, 1.0, 2**15 - 1),
        (32768, 1.0, 2**15),
        (65536, 1.0, 2**16),
        (4194304, 1.0, 2**22),
        (4194304, 1.0, 2**22 * 2**10),
    ]

# Generated at 2022-06-22 06:48:22.728493
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    import tempfile
    temp_dir = tempfile.gettempdir()
    ydl = youtube_dl.YoutubeDL({'outtmpl': os.path.join(temp_dir, '%(id)s-%(uploader)s-%(title)s-%(ext)s')})
    fd = FileDownloader(ydl, {'id': 'test'}, {
        'url': 'http://www.test.com/test.m4a',
        'uploader': 'Test Uploader',
        'title': 'Test Title',
    })

if __name__ == '__main__':
    test_FileDownloader()

# Generated at 2022-06-22 06:48:27.068437
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(400, 400) == 1024
    assert fd.best_block_size(400, 300) == 512
    assert fd.best_block_size(400, 800) == 2048



# Generated at 2022-06-22 06:48:38.978275
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    # create a mock object for youtube_dl/YoutubeDL
    ydl_mock = Mock()
    ydl_mock.params = {}
    ydl_mock.params['verbose'] = False
    # create a mock object for youtube_dl/FileDownloader
    fd_mock = FileDownloader(ydl_mock)
    # test trouble with different parameters
    fd_mock.trouble(u'error', u'error message', 59)
    fd_mock.trouble(u'unavailable format', u'http://www.youtube.com/watch?v=_HSylqgVYQI', 0)

# Generated at 2022-06-22 06:48:51.067804
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    # Expected results for method calc_percent
    results = [
        [0, 0, 0, None],
        [0, 0, 1, 0],
        [0, 1, 0, None],
        [0, 1, 1, 0],
        [1, 0, 0, None],
        [1, 0, 1, 0],
        [1, 1, 0, None],
        [1, 1, 1, 50],
        [1, 1, 2, 50],
        [1, 2, 1, 50],
        [1, 2, 2, 50],
        [1, 2, 3, 67],
        [1, 3, 2, 33],
        [1, 3, 3, 50],
        [1, 3, 4, 67],
        [1, 4, 3, 25],
        ]


# Generated at 2022-06-22 06:48:54.494801
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader({})
    fd.to_screen =  lambda x: x
    assert(fd.report_resuming_byte(1000) is None)


# Generated at 2022-06-22 06:48:57.773637
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    print(FileDownloader.to_screen)
    assert(FileDownloader.to_screen is not None)
test_FileDownloader_to_screen()

# Generated at 2022-06-22 06:49:09.360873
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader(None, {}).temp_name('%(id)s.%(ext)s') == '%(id)s.%(ext)s.part'
    assert FileDownloader(None, {}).temp_name('%(fn)s.%(ext)s') == '%(fn)s.%(ext)s.part'
    assert FileDownloader(None, {}).temp_name('abc') == 'abc.part'
    assert FileDownloader(None, {}).temp_name('abc.mp4') == 'abc.mp4.part'
    assert FileDownloader(None, {}).temp_name('/dir1/dir2/abc') == '/dir1/dir2/abc.part'

# Generated at 2022-06-22 06:49:21.130451
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    def check(filename, expected):
        if expected is None:
            expected = filename + '.ytdl'
        assert FileDownloader.ytdl_filename(filename) == expected
    # Filename containing invalid characters
    check('foo?bar.txt', None)
    # Filename containing only valid characters
    check('foobar1.txt', 'foobar1.txt.ytdl')
    # Filename containing directory separators
    check('foo/bar\\baz\\qux.txt', 'foo/bar\\baz\\qux.txt.ytdl')

    with tempfile.NamedTemporaryFile(suffix='.ytdl') as f:
        # File name with ytdl suffix
        check(f.name, f.name)


# Generated at 2022-06-22 06:49:31.268409
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from StringIO import StringIO
    fd = FileDownloader(YoutubeDL(), {})
    fd.to_screen = lambda x : None
    fd.to_stderr = lambda x : None
    fd.to_console_title = lambda x : None
    # test speed
    s = {'speed': 1000}
    fd.report_progress(s)
    assert s['_speed_str'] == '1000.0B/s'
    s = {'speed': 2 ** 20}
    fd.report_progress(s)
    assert '1.0MiB/s' == s['_speed_str']
    s = {'speed': 2 ** 30}
    fd.report_progress(s)
    assert s['_speed_str'] == '1.0GiB/s'
    s