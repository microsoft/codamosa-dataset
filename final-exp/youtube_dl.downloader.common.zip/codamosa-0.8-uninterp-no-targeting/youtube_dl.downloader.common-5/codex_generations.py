

# Generated at 2022-06-22 06:40:16.520022
# Unit test for method report_destination of class FileDownloader

# Generated at 2022-06-22 06:40:23.493078
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader({})
    assert fd.ytdl_filename('abc.txt.part') == 'abc.txt.part.ytdl'
    assert fd.ytdl_filename('abc.tar.gz.part') == 'abc.tar.gz.part.ytdl'
    assert fd.ytdl_filename('abc.part') == 'abc.part.ytdl'



# Generated at 2022-06-22 06:40:34.019387
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-22 06:40:36.400143
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # TODO: Some day I should write this test
    pass

# Generated at 2022-06-22 06:40:41.570374
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # pylint: disable=protected-access
    ydl = FileDownloader(params={})
    ydl.add_progress_hook(lambda x: None)
    assert len(ydl._progress_hooks) == 1
    assert ydl._progress_hooks[0] is None



# Generated at 2022-06-22 06:40:47.444439
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    f = FileDownloader()
    assert f.format_retries(float('inf')) == 'inf'
    assert f.format_retries(10) == '10'
    assert f.format_retries(1) == '1'
    assert f.format_retries(0) == '0'


# Generated at 2022-06-22 06:40:52.106874
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader()

    # Test normal messages
    fd.to_screen('Testing msg')
    sys.stdout.seek(0)
    assert sys.stdout.read() == 'Testing msg\n'
    sys.stdout.close()
    sys.stdout = sys.__stdout__

    # Test unicode messages
    fd.to_screen('Testing \u03a0\u03bf\u03c3\u03c4\u03ac')
    sys.stdout.seek(0)
    assert sys.stdout.read() == 'Testing \xce\xa0\xce\xbf\xcf\x83\xcf\x84\xce\xac\n'
    sys.stdout.close()
    sys.stdout = sys.__stdout__

#

# Generated at 2022-06-22 06:41:02.017872
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():

    # Test FileDownloader.to_screen without verbose

    FileDownloader.params = {
        'verbose': False
    }
    FileDownloader.to_screen('[download] Downloading foo')
    assert sys.stdout.getvalue() == ''
    sys.stdout.truncate(0)

    # Test FileDownloader.to_screen with verbose
    FileDownloader.params = {
        'verbose': True,
        'quiet': False
    }
    FileDownloader.to_screen('[download] Downloading foo')
    assert sys.stdout.getvalue() == '[download] Downloading foo\n'
    sys.stdout.truncate(0)

    # Test FileDownloader.to_screen with quiet

    FileDownloader.params = {
        'quiet': True
    }
   

# Generated at 2022-06-22 06:41:09.104673
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    from ydl.YoutubeDL import YoutubeDL
    from ydl.FileDownloader import FileDownloader

    ydl = YoutubeDL(params=dict())
    ydl.params['verbose'] = False
    ydl.params['logger'] = YoutubeDL.write_string
    ydl.params['warnings'] = []
    fd = FileDownloader(ydl, {})

    def get_warnings():  # TODO: find a better way to get the warnings
        warnings = fd.ydl.params['warnings']
        fd.ydl.params['warnings'] = []
        return warnings
    # no warning
    fd.report_warning('a')
    assert get_warnings() == []
    # warnings
    fd.ydl.params['verbose'] = True
    fd.report_warning

# Generated at 2022-06-22 06:41:19.790392
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})
    assert fd.format_speed(1000) == '1,000.00b/s'
    assert fd.format_speed(10000) == '9.77Kb/s'
    assert fd.format_speed(100000) == '97.66Kb/s'
    assert fd.format_speed(1000000) == '976.56Kb/s'
    assert fd.format_speed(10000000) == '9.54Mb/s'
    assert fd.format_speed(100000000) == '95.37Mb/s'
    assert fd.format_speed(1000000000) == '953.67Mb/s'

# Generated at 2022-06-22 06:41:43.617108
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    def hook1(self, status):
        return
    def hook2(self, status):
        return
    class FakeYDL:
        def to_screen(self, text):
            return
    class FakeInfoDict:
        def __init__(self):
            return
        class FakeInfo:
            def get(self, key, val):
                return val
        info = FakeInfo()
    fake_ydl = FakeYDL()
    fd = FileDownloader(fake_ydl, {})
    fd.add_progress_hook(hook1)
    assert hook1 in fd._progress_hooks
    fd.add_progress_hook(hook2)
    assert hook2 in fd._progress_hooks



# Generated at 2022-06-22 06:41:51.395592
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader()
    fd.to_screen('Unit test for method best_block_size of class FileDownloader')
    
    fd.to_screen('Test 1')
    fd.to_screen(fd.best_block_size(0.001, 0))
    fd.to_screen('')
    
    fd.to_screen('Test 2')
    fd.to_screen(fd.best_block_size(0.001, 1000))
    fd.to_screen('')

# Generated at 2022-06-22 06:42:03.154983
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    ydl = FileDownloader({})
    assert ydl.ytdl_filename('abc') == 'abc.ytdl'
    assert ydl.ytdl_filename('abc.py') == 'abc.py.ytdl'
    assert ydl.ytdl_filename('abc.py.py.py') == 'abc.py.py.py.ytdl'
    assert ydl.ytdl_filename('abc.py-recovered.py') == 'abc.py-recovered.py.ytdl'
    assert ydl.ytdl_filename('./abc.py') == './abc.py.ytdl'
    assert ydl.ytdl_filename('/abc.py') == '/abc.py.ytdl'

# Generated at 2022-06-22 06:42:12.829278
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(1, 1024) == 1024
    assert fd.best_block_size(1, 4096) == 4096
    assert fd.best_block_size(1, 1025) == 2048
    assert fd.best_block_size(1, 8192) == 4096
    assert fd.best_block_size(1, 0) == 1
    assert fd.best_block_size(1, float('inf')) == 4194304
    assert fd.best_block_size(5, 10240) == 512
    assert fd.best_block_size(10, 10240) == 1024
    assert fd.best_block_size(10, 81920) == 4096
    assert fd.best_block_size(10, 0) == 1

# Generated at 2022-06-22 06:42:22.267770
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class FakeDownloader(FileDownloader):
        def __init__(self):
            FileDownloader.__init__(self, FakeYoutubeDl())

    import calendar
    import os
    import sys
    import tempfile
    import time

    if os.name == 'nt':
        import win32api

        def getmtime(filename):
            t = win32api.GetFileAttributes(filename)
            return calendar.timegm(time.gmtime(t))

    else:
        def getmtime(filename):
            return os.stat(filename).st_mtime

    fd, filename = tempfile.mkstemp()
    os.close(fd)

    def try_to_set_file_mtime(timestr):
        f = FakeDownloader()
        f.to_screen = lambda x: None


# Generated at 2022-06-22 06:42:33.835955
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import error_to_compat_str
    fd = FileDownloader(YoutubeDL())
    e = OSError('foo')
    # Setting encoding to None (for example by setting LANG=C) makes repr(b'\xE2\x9D\xA4') return a
    # byte string in Python 3:
    fd.report_error('\xE2\x9D\xA4', exception=e)
    assert fd.ydl.err == 'ERROR: \xE2\x9D\xA4'

# Generated at 2022-06-22 06:42:40.285440
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    class F:
        def __init__(self):
            self.TITLE_TEMPLATE = '%s [%s]'
        def to_console_title(self, title):
            msg = self.TITLE_TEMPLATE % (title, 'foo')
            assert(msg == 'youtube-dl - foo [foo]')
    f = FileDownloader(F())
    f.to_console_title('youtube-dl - foo')
test_FileDownloader_to_console_title()

# Generated at 2022-06-22 06:42:48.922816
# Unit test for method to_screen of class FileDownloader

# Generated at 2022-06-22 06:42:59.142242
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(FileDownloaderParams())

    # These are some common formats
    timestr = '2012-02-27 17:59:51'
    converted = fd.try_utime('/tmp/filename', timestr)
    assert isinstance(converted, time.struct_time)

    timestr = 'Mon, 19 Jan 2009 19:43:50 GMT'
    converted = fd.try_utime('/tmp/filename', timestr)
    assert isinstance(converted, time.struct_time)

    timestr = '01/03/2016 15:30:12'
    converted = fd.try_utime('/tmp/filename', timestr)
    assert isinstance(converted, time.struct_time)


# Generated at 2022-06-22 06:43:08.565619
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    import unittest
    import sys

    class TestFileDownloaderFormatSpeed(unittest.TestCase):
        def test_format_speed_1(self):
            self.assertEqual(FileDownloader.format_speed(0), '%10s' % '---b/s')

        def test_format_speed_2(self):
            self.assertEqual(FileDownloader.format_speed(0.4), '%10s' % '400b/s')

        def test_format_speed_3(self):
            self.assertEqual(FileDownloader.format_speed(768), '%10s' % '768b/s')


# Generated at 2022-06-22 06:43:39.302054
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    FileDownloader.to_console_title('test')

# Generated at 2022-06-22 06:43:50.291605
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-22 06:44:02.402506
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    info1 = {
        'id': 'abc123',
        'title': 'Sample video 1',
    }
    info2 = {
        'id': 'def456',
        'title': 'Sample video 2',
    }
    info3 = {
        'id': 'ghi789',
        'title': 'Sample video 3',
    }
    infos = [info1, info2, info3]

    class InfoList(list):
        def __init__(self, *args):
            self.extend(args)
        def __getitem__(self, k):
            # Overwrite this to test non-dict items
            return dict.__getitem__(self[k], 'id')

    class ProgressLogger(object):
        def __init__(self):
            self.status = None
            self.count

# Generated at 2022-06-22 06:44:10.679884
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    yrl = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeDL()
    ydl._setup_opener()
    info_dict = ydl.extract_info(yrl, download=False)
    filename = 'test.mp4'
    downloader = FileDownloader(ydl, {'outtmpl': filename})
    assert not os.path.exists(filename)
    assert downloader.real_download(filename, info_dict)
    assert os.path.exists(filename)

# Generated at 2022-06-22 06:44:22.750538
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    FileDownloader.format_seconds(1) == '0:01'
    FileDownloader.format_seconds(2) == '0:02'
    FileDownloader.format_seconds(60) == '1:00'
    FileDownloader.format_seconds(61) == '1:01'
    FileDownloader.format_seconds(120) == '2:00'
    FileDownloader.format_seconds(121) == '2:01'
    FileDownloader.format_seconds(3600) == '1:00:00'
    FileDownloader.format_seconds(3601) == '1:00:01'
    FileDownloader.format_seconds(3660) == '1:01:00'
    FileDownloader.format_seconds(3661) == '1:01:01'
    FileDownloader.format_

# Generated at 2022-06-22 06:44:29.184151
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    mock_name = 'mock_name'
    fd = FileDownloader({}, {})
    fd.to_console_title(mock_name)
    assert fd.ydl.to_console_title.call_count == 1
    assert fd.ydl.to_console_title.call_args[0] == (mock_name,)

# Generated at 2022-06-22 06:44:36.276338
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test 1: calc_speed(start_time, now, bytes)
    # Test 2: calc_speed(start_time, now, bytes)
    # Test 3: calc_speed(start_time, now, bytes)
    assert FileDownloader.calc_speed(1.1, 2.2, 33) == 15.0
    assert FileDownloader.calc_speed(3.3, None, 66) == None
    assert FileDownloader.calc_speed(4.4, 5.5, 0) == None


# Generated at 2022-06-22 06:44:47.154041
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import os

    # Create a fake file
    fd, filename = tempfile.mkstemp(prefix='youtube-dl')
    os.write(fd, b'foobar')
    os.close(fd)

    # Use a real example
    #info_dict = {
            #'id': 'BaW_jenozKcj',
            #'ext': 'mp4',
            #'format': '720p',
            #'format_id': '22',
            #'url': 'https://r1---sn-x5uxaxjvh-1gis.googlevideo.com/videoplayback?pl=16&lmt=1442780761602715&requiressl=yes&ms=au&mv=m&mt=1442875466&ipbits=0&m

# Generated at 2022-06-22 06:44:53.082115
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    class TestYDL:
        def __init__(self):
            pass
        class error:
            def __init__(self,message):
                self.message = message
            def parse_it(self):
                return self.message

    class TestFD(FileDownloader):
        def __init__(self):
            self.ydl = TestYDL()
            self.params = {'verbose': True}

    lf = TestFD()
    lf.to_stderr('Test message')
    lf.to_stderr('Test %s %s', 'verb', 'message')

    lf.params = {'verbose': False}
    lf.to_stderr('Test message')
    lf.to_stderr('Test %s %s', 'verb', 'message')

    lf

# Generated at 2022-06-22 06:44:59.051530
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({'skip_download': True})

    assert fd.format_retries(None) == 'inf'
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(150) == '150'

if __name__ == '__main__':
    test_FileDownloader_format_retries()

# Generated at 2022-06-22 06:45:50.676874
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({'retries': 5}, False)
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(5.0) == '5'
    assert fd.format_retries(0) == '0'


test_FileDownloader_format_retries()

# Generated at 2022-06-22 06:45:55.485547
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    assert fd.try_utime('test', 'Sun, 23 Mar 2014 12:40:40 GMT') == 1395651240


if __name__ == '__main__':
    test_FileDownloader_try_utime()

# Generated at 2022-06-22 06:45:57.871069
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = common.FileDownloader()
    assert fd.to_stderr("test") is None


# Generated at 2022-06-22 06:46:06.588385
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test for Python >= 2.7.4 and >= 3.3
    if os.name != 'nt' and hasattr(os, '_getfinalpathname') and hasattr(os, 'symlink'):
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tmpfilename = tf.name
            shorttmpfilename = os.path.basename(tf.name)
            linkname = 'FileDownloader_test_file'
            os.symlink(tmpfilename, linkname)

            fd = FileDownloader({})
            assert fd.temp_name(tmpfilename) == tmpfilename + '.part'
            assert fd.temp_name(shorttmpfilename) == tmpfilename + '.part'
            assert fd.temp_name(linkname) == tmpfilename + '.part'
            os.un

# Generated at 2022-06-22 06:46:12.304513
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    test_case = FileDownloader(params={'verbosity': 1})
    expected_output = '[youtube] this is the error message\n'
    real_output = ''
    
    try:
        raise Exception('this is the error message')
    except Exception as e:
        with ytdl_test_sf.captured_output() as (out, err):
            test_case.report_error(e)

    real_output = out.getvalue()
    assert real_output == expected_output
    

# Generated at 2022-06-22 06:46:21.538695
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    from .version import version
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl)


# Generated at 2022-06-22 06:46:23.979964
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    assert(FileDownloader(YoutubeDL()).report_unable_to_resume() is None)
# Test code for class FileDownloader end


# Generated at 2022-06-22 06:46:34.007595
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    # This test ensures that the expected string is returned
    # by the method format_eta of the class FileDownloader
    assert FileDownloader.format_eta(0) == '0:00:00'
    assert FileDownloader.format_eta(59) == '0:00:59'
    assert FileDownloader.format_eta(60) == '0:01:00'
    assert FileDownloader.format_eta(61) == '0:01:01'
    assert FileDownloader.format_eta(3599) == '0:59:59'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(3601) == '1:00:01'
    assert FileDownloader.format_eta(360000) == '100:00:00'


# Generated at 2022-06-22 06:46:46.006127
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('Infinite') is None
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('Blah') is None
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('5b') == 5
    assert FileDownloader.parse_bytes('5k') == 5 * 1024
    assert FileDownloader.parse_bytes('5kB') == 5 * 1024
    assert FileDownloader.parse_bytes('5kib') == 5 * 1024
    assert FileDownloader.parse_bytes('5kb') == 5 * 1024
    assert FileDownloader.parse_bytes('5.9k') == 5.9 * 1024

# Generated at 2022-06-22 06:46:52.269891
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    """Checks if method to_stderr of class FileDownloader works as it's supposed to.
    It's important because it is used to show errors to the user."""
    # Constructor
    # Input: class object instance of type FileDownloader
    # Output: class object instance of type FileDownloader
    def test_FileDownloader__init__():
        downloader = FileDownloader(YoutubeDL(), params={})
        assert isinstance(downloader, FileDownloader)

    # Output: None
    test_FileDownloader__init__()

    # Method: to_stderr
    # Input: class object instance of type FileDownloader, message
    # Output: message
    def test_FileDownloader__to_stderr(message):
        # Constructor
        downloader = FileDownloader(YoutubeDL(), params={})


# Generated at 2022-06-22 06:48:22.778852
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL(params={})
    fd = FileDownloader(ydl, params={})
    for err, msg in [
            (socket.error('a', 'b', 'c'), 'socket error: c'),
            (IOError, 'IOError'),
            (EOFError, 'EOFError'),
    ]:
        fd.report_retry(err, 1, 5)
        assert fd.ydl.msgs[-1] == ('[download] Got server HTTP error: %s. '
            'Retrying (attempt 1 of %s)...') % (msg, fd.format_retries(5))

if __name__ == '__main__':
    test_FileDownloader_report_retry()

# Generated at 2022-06-22 06:48:28.005019
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("teste.something") == "teste.something"
    assert FileDownloader.undo_temp_name("teste.part") == "teste"
test_FileDownloader_undo_temp_name()
 
######################################################################################################################
#       End of methods of class FileDownloader                                                                       #
######################################################################################################################

#    PlaylistBase class

# Generated at 2022-06-22 06:48:39.120038
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Tests for the calc_speed method of the FileDownloader class
    print('Testing calc_speed method of FileDownloader class.')
    print('Test 1.')
    print('Input:')
    start = 0
    now = 10
    bytes = 10
    print('start = %s' % start)
    print('now = %s' % now)
    print('bytes = %s' % bytes)
    print('')
    print('Expected Output:')
    print('1.0')
    print('')
    print('Actual Output:')
    print(FileDownloader.calc_speed(start, now, bytes))
    print('')
    
    print('Test 2.')
    print('Input:')
    start = 0
    now = 0
    bytes = 10

# Generated at 2022-06-22 06:48:40.750207
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    assert FileDownloader(object(), object()).report_resuming_byte(0) == None

# Generated at 2022-06-22 06:48:52.553620
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    if sys.version_info < (3,3):
        return '%s.%s' % (sys.version_info[0],sys.version_info[1])

    fd = FileDownloader({})
    assert fd.format_eta(None) == '--:--'
    assert fd.format_eta(0) == '00:00'
    assert fd.format_eta(60) == '01:00'
    assert fd.format_eta(60*60) == '01:00:00'
    assert fd.format_eta(60*60+60) == '01:01:00'
    assert fd.format_eta(24*60*60) == '24:00:00'

# Generated at 2022-06-22 06:49:02.592422
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    import unittest
    class Test__calc_percent(unittest.TestCase):
        def setUp(self):
            self.fd = FileDownloader(None, {'outtmpl': '-'})
        def test_first_second(self):
            self.assertEqual(self.fd.calc_percent(0, 0, 10, 1), 0)
        def test_second_and_third_second(self):
            self.assertEqual(self.fd.calc_percent(10, 0, 10, 2), 10)
            self.assertEqual(self.fd.calc_percent(10, 0, 10, 3), 5)
    suite = unittest.TestLoader().loadTestsFromTestCase(Test__calc_percent)
    unittest.TextTestRunner(verbosity=2).run

# Generated at 2022-06-22 06:49:07.122227
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    _total_bytes = 10485760
    _downloaded_bytes = 1048576

    fd = FileDownloader({})
    _calc_percent = fd.calc_percent(_total_bytes, _downloaded_bytes)
    assert _calc_percent == 10


# Generated at 2022-06-22 06:49:10.230678
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    pass
assert __name__ == '__main__' , "This file must be run as main"
print('*'*10)

test_FileDownloader_to_stderr()

# Generated at 2022-06-22 06:49:11.953549
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    #TODO
    pass    
    

# Generated at 2022-06-22 06:49:23.227549
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    for s in ['1', '1.0', '1.1', '1.01', '.1', '.01', '1.234', '0.2345']:
        assert FileDownloader.parse_bytes(s) == 1024
    for s in ['2', '2.0', '2.1', '2.01', '2.12', '2.123', '2.1234']:
        assert FileDownloader.parse_bytes(s) == 2048
    for s in ['0.0', '1.', '.1', '1.0', '2.0']:
        assert FileDownloader.parse_bytes(s) == 1024
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('-1') is None