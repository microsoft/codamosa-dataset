

# Generated at 2022-06-22 06:39:55.520508
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    """Unit test for method report_retry of class FileDownloader"""

# Generated at 2022-06-22 06:39:57.792291
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    fd = FileDownloader()
    fd.to_screen = lambda msg: print(msg)
    fd.report_warning('test_report_warning')


# Generated at 2022-06-22 06:40:01.242583
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    # Checks the functionality of the method to_stderr of the class FileDownloader
    downloader = FileDownloader({})
    downloader.to_stderr('test')
    assert(True)


# Generated at 2022-06-22 06:40:11.538100
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    def eq(first, second):
        return cmp(fd.format_eta(fd.calc_eta(first[0], first[1], first[2])),
                   fd.format_eta(second)) == 0

    assert eq((0, 0, 267), None)
    assert eq((0, 267, 0), None)
    assert eq((0, 267, 267), 0)
    assert eq((0, 534, 267), 0)
    assert eq((0, 267, 534), 1)
    assert eq((0, 534.5, 267), 0)
    assert eq((0, 534, 267.5), 1)
    assert eq((0, 534.5, 267.5), 0)
    assert eq((0, 801, 267.5), 1)

# Generated at 2022-06-22 06:40:17.069992
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd=FileDownloader({"noprogress":True, "quiet":True})
    assert fd.undo_temp_name("file.part") == "file"
    assert fd.undo_temp_name("file2") == "file2"

# Generated at 2022-06-22 06:40:27.799723
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})

# Generated at 2022-06-22 06:40:39.427062
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # Check that the function is reflexive
    for normal in 0, 1, 2, 60, 61, 62, 60 * 60, 60 * 60 + 1, 60 * 60 + 2, 60 * 60 * 24, 60 * 60 * 24 + 1, 60 * 60 * 24 + 2, 60 * 60 * 24 * 30, 60 * 60 * 24 * 30 + 1, 60 * 60 * 24 * 30 + 2:
        assert normal == FileDownloader.format_seconds(FileDownloader.format_seconds(normal))

    # Check non-reflexive cases
    assert 61 == FileDownloader.format_seconds(60 + 1)
    assert 62 == FileDownloader.format_seconds(60 + 2)
    assert 60 * 60 + 2 == FileDownloader.format_seconds(60 * 60 + 1 + 1)
    assert 60 * 60 + 1 == FileDownloader.format_

# Generated at 2022-06-22 06:40:46.832635
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(FakeYDL(), {})
    now = time.time()
    eta_15s = fd.calc_eta(now, now + 15, 100, 100)
    eta_15s_plus = fd.calc_eta(now, now + 15 + 0.1, 100, 100)
    eta_half = fd.calc_eta(now, now + 30, 100, 200)
    assert 0 <= eta_15s <= 15
    assert eta_15s_plus is None
    assert 15 <= eta_half <= 30
    assert fd.calc_eta(now, now - 15, 100, 100) is None
    assert fd.calc_eta(now, now + 15, 0, 100) is None



# Generated at 2022-06-22 06:40:57.389833
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    """
    Test method trouble of class FileDownloader
    """
    def _test_FileDownloader_trouble(test_func, *args, **kwargs):
        with io.StringIO() as fake_stderr:
            ydl = YoutubeDL(params={'logger': YoutubeDLStderrLogger(fake_stderr)})
            test_func(ydl, *args, **kwargs)
            stderr_lines = fake_stderr.getvalue().splitlines()
        return stderr_lines
    def test_FileDownloader_trouble_without_exc_info(ydl):
        ydl.to_screen = lambda s: None
        ydl.report_error = lambda s: None
        ydl.trouble(None)

# Generated at 2022-06-22 06:41:01.674238
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # Very basic test.
    f = FileDownloader(None, params={})
    def to_screen(s):
        assert(s == '[download] Resuming download at byte 100')
    f.to_screen = to_screen
    f.report_resuming_byte(100)



# Generated at 2022-06-22 06:41:43.947100
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class TestDownloader(FileDownloader):
        to_screen = mock.MagicMock(side_effect=to_screen)

    with compat_patch(compat_urllib_error, 'HTTPError', HTTPError):
        url = 'http://www.example.com'
        dl = TestDownloader(FileDownloader(YoutubeDL(), dict()), dict(), url)
        dl.report_retry(HTTPError(501, 'Not Implemented', None, None, None), 1, 3)

        dl.to_screen.assert_any_call(
            '[download] Got server HTTP error: HTTP Error 501: Not Implemented. Retrying (attempt 1 of 3)...'
        )
        assert dl.to_screen.call_count == 1

# Generated at 2022-06-22 06:41:46.379840
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({})
    fd.to_console_title("Downloading")

test_FileDownloader_to_console_title()


# Generated at 2022-06-22 06:41:59.991357
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    # check if the rate is not exceeded
    fd = FileDownloader(YoutubeDL(), Parameters())
    limit = fd.params.get('ratelimit')
    start = time.time()
    now = time.time()
    bytes = 8192
    fd.slow_down(start, now, bytes)
    dif = time.time() - start
    rate = float(bytes) / dif
    assert rate <= limit

    # check if the rate is exceeded (the method is going to sleep)
    fd = FileDownloader(YoutubeDL(), Parameters())
    limit = fd.params.get('ratelimit')
    start = time.time()
    now = time.time()
    bytes = limit * 2
    fd.slow_down(start, now, bytes)
    dif = time.time() - start


# Generated at 2022-06-22 06:42:12.035020
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def _test(seconds, expected):
        result = FileDownloader.format_seconds(seconds)
        assert result == expected, 'FileDownloader.format_seconds(%f) returned %s instead of %s' % (seconds, result, expected)

    # simple cases
    _test(0, '0:00')
    _test(1, '0:01')
    _test(9, '0:09')
    _test(10, '0:10')
    _test(59, '0:59')
    _test(60, '1:00')
    _test(61, '1:01')
    _test(3599, '59:59')
    _test(3600, '1:00:00')
    _test(3660, '1:01:00')

    # complex cases
    _test

# Generated at 2022-06-22 06:42:23.495868
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():  # noqa:E501
    import pytest

    # We need to mock _make_cmd so that the real_download method of
    # FileDownloader doesn't really try to execute any command.
    from types import MethodType
    from youtube_dl.downloader.fragment import FragmentFD

    def _make_cmd_stub(self, info_dict, filename, more_opts):
        return []

    # We need a 'verbose' parameter to be passed.
    def download(self, filename, info_dict, **kwargs):
        self.params = kwargs
        self.params['verbose'] = True
        return self.real_download(filename, info_dict)
    # Now we can run a test

    # Sanity checks.
    with pytest.raises(TypeError):
        fd = FileDownload

# Generated at 2022-06-22 06:42:26.631053
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    ydl = FakeYoutubeDl()
    fd = FileDownloader(ydl)
    fd.to_console_title('hello')

# Generated at 2022-06-22 06:42:28.475618
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    # Create a FileDownloader object
    FileDownloader()


# Generated at 2022-06-22 06:42:36.043859
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    def BoolRet(val):
        return lambda _: val
    log = mock.Mock()
    fd = FileDownloader({}, None, {'logger': log})
    fd.report_error("Foo", "Bar")
    assert log.error.call_count == 1
    assert log.error.call_args[1] == {"exc_info": ("Bar", "Foo", None)}

    assert fd.report_error("Foo", "Bar", fatal=False) is False
    assert fd.report_error("Foo", "Bar", fatal=True) is True

    fd.params["ignoreerrors"] = True
    assert fd.report_error("Foo", "Bar") is False
    assert fd.report_error("Foo", "Bar", fatal=True) is False


# Generated at 2022-06-22 06:42:43.506044
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    ydl = YoutubeDL()
    ydl.to_screen = mock.MagicMock()
    ydl.params = {'verbose': True}

    fd = FileDownloader(ydl, {}, {})
    fd.format_retries = mock.MagicMock(return_value='5')
    fd.report_retry('video gone', 2, 5)

    ydl.to_screen.assert_called_once_with(
        '[download] Got server HTTP error: video gone. Retrying (attempt 2 of 5)...'
    )

# Generated at 2022-06-22 06:42:55.104115
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import unittest
    from io import BytesIO

    # file_exists
    class FileDownloaderTest(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    def file_exists(path):
        filename = path
        if isinstance(filename, bytes):
            filename = filename.decode('utf-8')
        return filename == 'filename'

    # file_exists_false
    class FileDownloaderTest(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    def file_exists_false(path):
        filename = path
        if isinstance(filename, bytes):
            filename = filename.decode('utf-8')
        return filename == 'false'

    # test_nooverwrites_and_ex

# Generated at 2022-06-22 06:43:11.714831
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader(YoutubeDL(), 'http://www.youtube.com/watch?v=BaW_jenozKc')
    fd.report_unable_to_resume
    pass

# Generated at 2022-06-22 06:43:18.261961
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    curdir = os.path.dirname(os.path.abspath(__file__))
    test_folder = os.path.join(curdir, "test")
    assert not os.path.exists(test_folder)
    os.makedirs(test_folder)
    os.chdir(test_folder)
    ydl = YoutubeDL({'progress_with_newline': False})

# Generated at 2022-06-22 06:43:30.380658
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    import pytest
    from youtube_dl.utils import is_outdated_pyyaml, update_self
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl import version

    xd = YoutubeDL()
    fd = FileDownloader(xd)
    assert fd._progress_hooks == []

    # YoutubeDL object is created and given to FileDownloader object
    assert isinstance(fd.ydl, YoutubeDL)

    # Prints empty string
    fd.params['verbose'] = False
    fd.print_debug_header()

    # For some reason we have to assert fd.to_stderr() in order to be able to call it
    assert fd.to_stderr
    fd

# Generated at 2022-06-22 06:43:40.609885
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({})
    if compat_os_name == 'nt':
        res = fd.to_console_title('foo')
        assert res is None
    else:
        true_title = '\x1b]2;foo\x07'
        true_bytes = true_title.encode('utf-8')
        false_bytes = fd.to_console_title('foo')
        assert isinstance(false_bytes, bytes)
        assert len(false_bytes) == len(true_bytes)
        assert false_bytes != true_bytes
        assert false_bytes == b'foobar\x07\x07\x07\x07\x07\x07\x07'
        assert len(fd.to_console_title('')) == 0


# Generated at 2022-06-22 06:43:53.444638
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    eta = fd.calc_eta(0, 0, 0)
    assert eta is None
    eta = fd.calc_eta(0, 0, 100)
    assert eta is None
    eta = fd.calc_eta(0, 0, 10)
    assert eta == 0
    eta = fd.calc_eta(0, 1, 10)
    assert eta == 0
    eta = fd.calc_eta(9, 10, 100)
    assert eta == 9
    eta = fd.calc_eta(50, 50, 100)
    assert eta is None
    eta = fd.calc_eta(0, 2, 100)
    assert eta == 50

# Generated at 2022-06-22 06:44:04.715971
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(None) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(0) == '%10s' % '0.0b/s'
    assert FileDownloader.format_speed(1000) == '%10s' % '1000.0b/s'
    assert FileDownloader.format_speed(1024) == '%10s' % '1.0KiB/s'
    assert FileDownloader.format_speed(10240) == '%10s' % '10.0KiB/s'
    assert FileDownloader.format_speed(1024000) == '%10s' % '1000.0KiB/s'

# Generated at 2022-06-22 06:44:13.581863
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    # Cases where calc_percent must return None
    print('None')
    for current in [0, None]:
        for total in [0, None]:
            for start in [None, 0]:
                for now in [None, 0]:
                    ydl = FileDownloader({})
                    assert ydl.calc_percent(current, total, start, now) == None
    # Cases where calc_percent must return an integer value
    print('int')
    for current in [1, 1024, 1024 * 1024, 1024 * 1024 * 1024]:
        for total in [current, current + 1]:
            for start in [0, 0.1]:
                for now in [start, start + 0.1]:
                    ydl = FileDownloader({})
                    percent = round(float(current) / total * 100)
                    assert ydl.calc_percent

# Generated at 2022-06-22 06:44:25.436697
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    import time
    #
    # Different byte rates in bytes/sec
    #
    byte_rates = [
        100,  # 100 bytes/sec
        1024,  # 1 kibibyte/sec
        1024 ** 2,  # 1 mebibyte/sec
        1024 ** 3,  # 1 gibibyte/sec
    ]

    #
    # Different elapsed times in seconds
    #
    elapsed_times = [
        1,  # 1 second
        60,  # 1 minute
        60 * 60,  # 1 hour
        60 * 60 * 24,  # 1 day
        60 * 60 * 24 * 7,  # 1 week
    ]

    #
    # For each combination of byte rates and elapsed times
    #

# Generated at 2022-06-22 06:44:26.802905
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    #TODO
    pass


# Generated at 2022-06-22 06:44:31.116412
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    import unittest
    suite = unittest.TestSuite()
    # Test format_percent method of FileDownloader class
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestFormatPercent))
    return suite

# Generated at 2022-06-22 06:45:10.386046
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    tests = [
        ((0, 1, 0), None),
        ((0, 1, 1), None),
        ((4, 0, 0), None),
        ((4, 0, 1), 1),
        ((4, 1, 0), 0),
        ((4, 5, 1), 5),
        ((4, 6, 2), 3),
        ((4, 12, 3), 4),
        ((4, 110, 3), 37),
        # Check that we don't get divide by zero
        ((4, 110, 0), None),
    ]
    for (start, now, bytes), expected in tests:
        got = FileDownloader.calc_speed(start, now, bytes)
        assert expected == got, 'Expected %s, got %s' % (expected, got)



# Generated at 2022-06-22 06:45:22.169548
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    import sys
    origin_stdout = sys.stdout

    class MockFile(object):
        """Mock file-like object"""
        def __init__(self):
            self.buf = []

        def write(self, str):
            self.buf.append(str)

        def read(self):
            return ''.join(self.buf)

    def test_str(str):
        """Test to_screen method with str argument"""
        sf = MockFile()
        sys.stdout = sf
        fd = FileDownloader({'verbose': True})
        fd.to_screen(str)
        sys.stdout = origin_stdout
        assert sf.read() == '[debug] ' + str

    def test_unicode(str):
        """Test to_screen method with unicode argument"""


# Generated at 2022-06-22 06:45:34.248110
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1024 ** 0
    assert FileDownloader.parse_bytes('1k') == 1024 ** 1
    assert FileDownloader.parse_bytes('1M') == 1024 ** 2
    assert FileDownloader.parse_bytes('1G') == 1024 ** 3
    assert FileDownloader.parse_bytes('1T') == 1024 ** 4
    assert FileDownloader.parse_bytes('1P') == 1024 ** 5
    assert FileDownloader.parse_bytes('1E') == 1024 ** 6
    assert FileDownloader.parse_bytes('1Z') == 1024 ** 7
    assert FileDownloader.parse_bytes('1Y') == 1024 ** 8
    assert FileDownloader.parse_bytes('-1') is None
    assert FileDownloader.parse_bytes('1g') is None

# Generated at 2022-06-22 06:45:41.992518
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import tempfile, shutil
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-22 06:45:48.016630
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    try:
        raise Exception('test')
    except Exception as e:
        ydl = YoutubeDL({})
        fd = FileDownloader(ydl, {})
        fd.report_retry(e, 1, 2)
    print('test finished')

# test_FileDownloader_report_retry()

 

# Generated at 2022-06-22 06:45:55.589766
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # create object of class FileDownloader
    fd = FileDownloader({}, None)
    # create and assert some values
    resume_len = 100.0
    assert resume_len == 100.0 # assert resume_len is 100
    # call function, assert executed properly
    fd.report_resuming_byte(resume_len)
    # done
    print("test_FileDownloader_report_resuming_byte: success")


# Generated at 2022-06-22 06:45:59.612794
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    ydl = YoutubeDL('https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    fd = FileDownloader({}, ydl)
    fd.to_stderr('works')
    assert True

# Generated at 2022-06-22 06:46:09.513977
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '1.0s'
    assert FileDownloader.format_seconds(0) == '0.0s'
    assert FileDownloader.format_seconds(1.0 / 60.0) == '0.0s'
    FileDownloader.format_seconds(0.001) == '0.0s'
    FileDownloader.format_seconds(1.01) == '1.0s'
    # Test for Issue #24
    assert FileDownloader.format_seconds(1.1) == '1.1s'
    assert FileDownloader.format_seconds(11.1) == '11.1s'
    assert FileDownloader.format_seconds(60.1) == '1:00.1'

# Generated at 2022-06-22 06:46:11.453089
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    FileDownloader.report_warning('test_FileDownloader_report_warning: hello world!')

# Generated at 2022-06-22 06:46:16.794628
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    """
    Test for method report_unable_to_resume of class FileDownloader.
    It prints '[download] Unable to resume' on screen.
    """
    fd=FileDownloader()
    fd.report_unable_to_resume()
    assert 'Download not able to resume'
    return

# Generated at 2022-06-22 06:47:22.257411
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import youtube_dl
    import tempfile

    class FileDownloaderTmp(youtube_dl.FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    fd = FileDownloaderTmp({'progress_with_newline': True})

    # Test speed not specified
    out = []
    fd.to_screen = lambda x: out.append(x)
    fd.report_progress({
        'downloaded_bytes': 0,
        'percent_str': '0.0%',
        'status': 'downloading',
        'total_bytes': None,
        'total_bytes_estimate': None,
        'eta': None,
        'elapsed': None,
        'speed': None
    })

# Generated at 2022-06-22 06:47:33.623011
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class FileDownloaderSubclass(FileDownloader):
        def __init__(self, *args, **kwargs):
            self._outtmpl = '%%(id)s.%%(ext)s'
            FileDownloader.__init__(self, *args, **kwargs)
    testcases = {}
    testcases[None] = None
    testcases['Sun, 06 Nov 1994 08:49:37 GMT'] = 784111777.0
    testcases['Sun, 06 Nov 1994 08:49:37 GMT+1'] = 784111777.0
    testcases['Sun, 06 Nov 1994 08:49:37 +1'] = 784111777.0
    testcases['Sun, 06 Nov 1994 08:49:37 -1'] = 784111777.0

# Generated at 2022-06-22 06:47:46.011356
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from io import BytesIO
    from .common import FakeYDL

    def _slow_down(start, now, bytes):
        assert now - start <= 0.01
        assert bytes == 10

    def _sleep(t):
        assert t <= 0.004

    class FakeFileDownloader(FileDownloader):
        def __init__(self):
            self.params = {'nooverwrites': True}

        def slow_down(self, start, now, bytes):
            return _slow_down(start, now, bytes)

    ydl = FakeYDL()
    fd = FakeFileDownloader()
    fd.ydl = ydl
    fd._sleep = _sleep
    fd._report_progress({'speed': float(10), 'total_bytes': 100})

    # test with max rate of 0


# Generated at 2022-06-22 06:47:50.199869
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({'noprogress': True})
    fd.to_screen = lambda s: s
    fd.to_screen('[download] %s has already been downloaded' % "file")


# Generated at 2022-06-22 06:48:01.560537
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import time
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 06:48:10.541730
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader(None, {})
    try:
        fd.to_screen(u"téléchargé")
        assert True
    except UnicodeEncodeError:
        assert False

    if sys.version_info < (3, 0):
        try:
            fd.to_screen(u"téléchargé", "latin-1")
            assert False
        except UnicodeEncodeError:
            assert True

    try:
        fd.to_screen(u"téléchargé", "utf-8")
        assert True
    except UnicodeEncodeError:
        assert False



# Generated at 2022-06-22 06:48:14.654628
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # In this test we will check if the method report_retry shows the 
    # message correctly, when we have a HTTP error 5xx
    params = {"verbose": True, "format": "json", "ignoreerrors": False,
                  "no_warnings": True, "outtmpl": "/Users/fran/Desktop/S2/%(title)s.%(ext)s",
                  "quiet": False}
    ydl = YoutubeDL(params)
    fd = FileDownloader(ydl)
    fd.report_retry(2, 3, 3)

# Generated at 2022-06-22 06:48:19.177447
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    loader = FileDownloader({}, None)
    with patch('logging.Logger.warning') as mock:
        loader.report_warning('test warning')
        assert mock.call_count == 1
        mock.assert_called_with('test warning')

# Generated at 2022-06-22 06:48:20.920937
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    assert_raises(AttributeError, FileDownloader, {}).to_screen('foo bar')

# Generated at 2022-06-22 06:48:25.742784
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    """
    Test report destination of FileDownloader
    """
    fn = 'test_FileDownloader_report_destination'