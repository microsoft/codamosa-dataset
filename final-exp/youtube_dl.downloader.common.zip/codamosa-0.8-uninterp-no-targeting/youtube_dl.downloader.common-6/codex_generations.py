

# Generated at 2022-06-22 06:40:39.081105
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    downloader = FileDownloader({})

    assert downloader.format_retries(None) == '--'
    assert downloader.format_retries(float('inf')) == 'inf'

    assert downloader.format_retries(1) == '1'
    assert downloader.format_retries(10) == '10'
    assert downloader.format_retries(100) == '100'
    assert downloader.format_retries(1000) == '1,000'
    assert downloader.format_retries(10000) == '10,000'
    assert downloader.format_retries(100000) == '100,000'
    assert downloader.format_retries(1000000) == '1,000,000'
    assert downloader.format_retries(10000000) == '10,000,000'

# Generated at 2022-06-22 06:40:51.654684
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    import os
    import sys
    import unittest

    def _call_try_rename(fd, old, new):
        from types import MethodType
        # Thanks to http://stackoverflow.com/a/1695250
        return MethodType(fd.try_rename, None, fd.__class__)(old, new)

    def _mock_os_failing_tried(fd, old, new):
        if fd._os_rename_tried:
            raise OSError('Error')
        fd._os_rename_tried = True

    def _mock_os_failing(fd, old, new):
        raise OSError('Error')

    def _mock_os_rename(fd, old, new):
        fd._os_rename_called = True

# Generated at 2022-06-22 06:41:01.674420
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({'outtmpl': '%(id)s'})

    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('a.BC') == 'a.BC.part'
    assert fd.temp_name('A.B.part') == 'A.B.part'
    assert fd.temp_name('A.B.part.part') == 'A.B.part.part'
    assert fd.temp_name('aBc') == 'aBc.part'
    assert fd.temp_name('aBc.part') == 'aBc.part'
    assert fd.temp_name('aBc.part.part') == 'aBc.part.part'
    assert fd.temp_name('-')

# Generated at 2022-06-22 06:41:08.882488
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(params={'verbose': True})
    assert fd.calc_eta(10, 0, 100) is None
    assert fd.calc_eta(0, 10, 100) is None
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(10, 0, 0) is None
    assert fd.calc_eta(0, 10, 0) is None
    assert fd.calc_eta(0, 10, 100) is not None
    assert fd.calc_eta(100, 10, 100) == 0
    assert fd.calc_eta(10, 100, 100) == 0
    assert fd.calc_eta(10, 0, 100) == 90

# Generated at 2022-06-22 06:41:19.580927
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class T:
        to_screen_calls = []

        def to_screen(self, message):
            self.to_screen_calls.append(message)

    t = T()
    fd = FileDownloader(t, {})

    # Test download to an already existing file
    fd.report_file_already_downloaded('bar')

    t.to_screen_calls = []

    # Test download from stdout
    fd.report_file_already_downloaded('-')

    t.to_screen_calls = []

    # Test download to a non-existing file
    fd.report_file_already_downloaded('baz')

    assert t.to_screen_calls == []



# Generated at 2022-06-22 06:41:27.257374
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-22 06:41:38.166462
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():

    calc_eta = FileDownloader.calc_eta

    assert calc_eta(0, None, 0) is None
    assert calc_eta(0, 0, 0) is None
    assert calc_eta(0, 1, 0) is None
    assert calc_eta(0, 0, 1) is None

    assert calc_eta(0, 1, 1) == 0

    assert calc_eta(0, 2, 1) == 1
    assert calc_eta(0, 4, 2) == 2
    assert calc_eta(0, 6, 2) == 3

    assert calc_eta(100, 1, 1) is None
    assert calc_eta(100, 10, 1) is None
    assert calc_eta(100, 10, 10) == 100


# Generated at 2022-06-22 06:41:49.465684
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    def format_eta(seconds):
        return FileDownloader.format_eta(seconds)
    assert '0:00' == format_eta(0)
    assert '0:01' == format_eta(1)
    assert '0:09' == format_eta(9)
    assert '0:10' == format_eta(10)
    assert '0:11' == format_eta(11)
    assert '0:18' == format_eta(18)
    assert '0:19' == format_eta(19)
    assert '0:59' == format_eta(59)
    assert '1:00' == format_eta(60)
    assert '5:00' == format_eta(5 * 60)
    assert '8:30' == format_eta(8 * 60 + 30)

# Generated at 2022-06-22 06:41:52.586386
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    x = FileDownloader()
    x.params['verbose'] = True
    x.report_warning('blah')
    x.params['verbose'] = False
    x.report_warning('blah')


# Generated at 2022-06-22 06:42:04.073498
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert('0:00:00' == FileDownloader.format_seconds(0))
    assert('0:00:01' == FileDownloader.format_seconds(1))
    assert('0:00:10' == FileDownloader.format_seconds(10))
    assert('0:01:00' == FileDownloader.format_seconds(60))
    assert('0:01:01' == FileDownloader.format_seconds(61))
    assert('0:10:00' == FileDownloader.format_seconds(60 * 10))
    assert('0:10:01' == FileDownloader.format_seconds(60 * 10 + 1))
    assert('1:00:00' == FileDownloader.format_seconds(60 * 60))

# Generated at 2022-06-22 06:42:16.231527
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    # Filename with extension
    test = FileDownloader(YoutubeDL())
    assert '.ytdl' == test.ytdl_filename('.mp3')

    # Filename without extension
    test = FileDownloader(YoutubeDL())
    assert '.ytdl' == test.ytdl_filename('.ytdl')

# Generated at 2022-06-22 06:42:21.127693
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    class MockYoutubeDL(object):
        def __init__(self):
            self.warnings = []
        def report_warning(self, msg):
            self.warnings.append(msg)
    ydl = MockYoutubeDL()
    fd = FileDownloader(ydl)
    fd.report_warning("Warning msg")
    assert ydl.warnings==["Warning msg"]

# Generated at 2022-06-22 06:42:30.773939
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test downloader.download()
    test_output = []

    def test_hook(status):
        test_output.append(status)

    # Test proper error message with unknown URL
    ydl = FileDownloader({'outtmpl': u'%(id)s%(ext)s'})
    ydl.add_progress_hook(test_hook)
    ydl.download(['http://example.com/'])
    assert test_output[-1]['status'] == 'error'
    assert u'unsupported URL protocol' in test_output[-1]['exc_info'][1]

    # Test proper error message with non-existing file: scheme URL
    ydl = FileDownloader({'outtmpl': u'%(id)s%(ext)s'})
    ydl.add_progress_hook

# Generated at 2022-06-22 06:42:41.698680
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    fd = FileDownloader({'quiet': True})

    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(1, 1, -1) is None
    assert fd.calc_speed(10, 11, 0) is None

    assert fd.calc_speed(1, 5, 20) == 4.0
    assert fd.calc_speed(100, 200, 300) == 1.5
    assert fd.calc_speed(100, 200, 400) == 2.0
    assert fd.calc_speed(100, 200, 500) == 2.5
    assert fd.calc_speed(100, 200, 200) == 1.0
    assert fd.calc_speed(1000, 2000, 2000) == 1.0
   

# Generated at 2022-06-22 06:42:49.747986
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader(
        params={
            'progress_with_newline': False,
            'noprogress': False,
            'retries': 3
        },
        ydl=YoutubeDL(params={
            'skip_download': True,
            'logger': MyLogger(),
        }))
    fd._report_progress_prev_line_length = 0

    assert fd.report_retry(None, 1, 3) is None
    assert sys.stdout.getvalue() == (
        '\r[download] Got server HTTP error: None. Retrying (attempt 1 of 3)... '
        '                                                                      \n'
    )

    assert fd.report_retry(None, 0, float('inf')) is None

# Generated at 2022-06-22 06:42:51.896143
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    status = MagicMock()
    downloader = FileDownloader(status)
    downloader.report_resuming_byte(50)


# Generated at 2022-06-22 06:42:54.022906
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert(FileDownloader.format_speed(0) == '%10s' % '---b/s')



# Generated at 2022-06-22 06:43:03.995368
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(61) == '01:01'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(3661) == '01:01:01'
    assert FileDownloader.format_eta(86400) == '1 day, 00:00:00'
    assert FileDownloader.format_eta(86401) == '1 day, 00:00:01'
    assert FileDownloader.format

# Generated at 2022-06-22 06:43:10.088670
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    a = FileDownloader()
    assert a.ytdl_filename('whatever') == 'whatever.ytdl'
    assert a.ytdl_filename('whatever.txt') == 'whatever.txt.ytdl'
    assert a.ytdl_filename('whatever.ytdl.txt') == 'whatever.ytdl.txt.ytdl'



# Generated at 2022-06-22 06:43:13.874892
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    import youtube_dl as ydl
    class TestFileDownloader(ydl.FileDownloader):
        def to_console_title(self, title):
            ydl.FileDownloader.to_console_title(self, title)
            return title
    print(TestFileDownloader.to_console_title(None, 'hello'))


# Generated at 2022-06-22 06:43:31.190279
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    x = FileDownloader('youtube-dl', {'nopart': True})
    assert x.temp_name(u'abc') == u'abc'
    assert x.temp_name(u'abc') == u'abc'



# Generated at 2022-06-22 06:43:33.194232
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # TODO(ytdl-team): Find a way to test this function
    pass


# Generated at 2022-06-22 06:43:41.625530
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    Logger.warning = lambda *args, **kargs: None
    fd = FileDownloader(None, None)
    assert fd.format_seconds(60) == '01:00'
    assert fd.format_seconds(61) == '01:01'
    assert fd.format_seconds(3600) == '01:00:00'
    assert fd.format_seconds(3600.5) == '01:00:00'
    assert fd.format_seconds(3601) == '01:00:01'
    assert fd.format_seconds(None) == '00:00'
    assert fd.format_seconds(8.39092034) == '00:08'



# Generated at 2022-06-22 06:43:53.643782
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    f = FileDownloader(params={})
    assert f._calc_percent(0, 1000, 0) == 0.0
    assert f._calc_percent(0, 1000, 100) == 10.0
    assert f._calc_percent(0, 1000, 500) == 50.0
    assert f._calc_percent(0, 1000, 999) == 99.9
    assert f._calc_percent(0, 1000, 1000) == 100.0
    assert f._calc_percent(0, 1000, -1000) == 0.0
    assert f._calc_percent(0, 1000, 2000) == 100.0
    assert f._calc_percent(0, 1000, -42) == 0.0
    assert f._calc_percent(0, 1000, 42) == 4.2

# Generated at 2022-06-22 06:43:55.080232
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # TODO
    pass


# Generated at 2022-06-22 06:44:01.781030
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    print('Testing FileDownloader.calc_percent')
    fd = FileDownloader({})
    assert fd.calc_percent(1000, 2000) == 50
    assert fd.calc_percent(1000, -1) is None
    assert fd.calc_percent(-1, 2000) is None
    assert fd.calc_percent(-1, -1) is None
    print('Test success')



# Generated at 2022-06-22 06:44:04.882656
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader({})
    fd.to_screen('Just a test')
    fd.to_screen('Test with params:', {'foo': 'bar'})



# Generated at 2022-06-22 06:44:11.816360
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    ydl = YoutubeDL()
    ydl.params['verbose'] = False
    fd = FileDownloader(ydl, {'url': 'http://very.sexy/', 'http_headers': {'Referer': 'http://somewhere.not/'}, 'format': 'Testing', 'nooverwrites': False, 'continuedl': True, 'nopart': False})
    fd.report_retry(OSError('err'), 1, 2)
    assert_equals(fd._screen_file.getvalue(), '')



# Generated at 2022-06-22 06:44:23.093364
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(params={})
    fd.trouble = lambda *args, **kw: True
    fd.to_screen = lambda *args, **kw: None
    fd.report_error = lambda *args, **kw: None
    fd.report_warning = lambda *args, **kw: None
    fd.slow_down = lambda *args, **kw: None
    assert fd.calc_speed(10.0, 20.0, 0) is None
    assert fd.calc_speed(10.0, 20.0, 1) == 0.1
    assert fd.calc_speed(10.0, 10.0, 1) is None
    assert fd.calc_speed(10.0, 10.0001, 1) == 0.0999

# Generated at 2022-06-22 06:44:34.870137
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # test when ratelimit is not set
    params = {'ratelimit': None}
    fd = FileDownloader(params)
    fd.slow_down(0, 0, 0)

    # test when ratelimit = 5 and speed = 6
    params = {'ratelimit': 5}
    fd = FileDownloader(params)
    fd.slow_down(0, 3, 16)

    # test when ratelimit = 5 and speed = 4
    params = {'ratelimit': 5}
    fd = FileDownloader(params)
    fd.slow_down(0, 3, 12)

    # test when ratelimit = 5 and speed = 3
    params = {'ratelimit': 5}
    fd = FileDownloader(params)
    fd.slow_down(0, 3, 9)

    #

# Generated at 2022-06-22 06:44:53.161971
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    class ProgressHooker(object):
        def __init__(self, test_obj):
            self.test_obj = test_obj
            self._downloader = None

        def __call__(self, status):
            assert status['status'] == 'downloading'
            assert status['downloaded_bytes'] == 1500
            assert status['total_bytes'] == 50000
            assert status['filename'] == 'test.mp4'
            assert status['tmpfilename'] == 'test.mp4.part'
            assert status['eta'] == 10
            assert status['speed'] == 1000
            assert status['_percent_str'] == '3.0%'
            assert status['_eta_str'] == '0:00:10'
            assert status['_total_bytes_str'] == '48.0KiB'

# Generated at 2022-06-22 06:45:05.040548
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Calling FileDownloader._hook_progress should result in the methods of
    # the progress hooks being called (if any)
    class DummyHook():
        def __init__(self):
            self.status = None
        def __call__(self, status):
            self.status = status
    hook1 = DummyHook()
    hook2 = DummyHook()
    fd = FileDownloader(params={})
    fd.add_progress_hook(hook1)
    fd.add_progress_hook(hook2)
    fd._hook_progress({'foo': 'bar'})

    assert hook1.status == {'foo': 'bar'}
    assert hook2.status == {'foo': 'bar'}
    assert len(fd._progress_hooks) == 2

# unit tests

# Generated at 2022-06-22 06:45:15.600979
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(9.05, 524288) == 16384
    assert fd.best_block_size(4.01, 131072) == 8192
    assert fd.best_block_size(0.98, 65536) == 4096
    assert fd.best_block_size(0.5, 32768) == 2048
    assert fd.best_block_size(0.1, 16384) == 256
    assert fd.best_block_size(0.01, 4096) == 32
    assert fd.best_block_size(0.001, 1024) == 16
    assert fd.best_block_size(4.0, 4096) == 1024


#

# Generated at 2022-06-22 06:45:25.359257
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})

    assert fd.best_block_size(1.0, 10) == 2
    assert fd.best_block_size(1.0, 65536) == 4194304
    assert fd.best_block_size(1.0, 131072) == 4194304
    assert fd.best_block_size(1.0, 131073) == 4194304
    assert fd.best_block_size(1.0, 131074) == 4194304
    assert fd.best_block_size(1.0, 786430) == 4194304
    assert fd.best_block_size(1.0, 786431) == 4194304
    assert fd.best_block_size(1.0, 786432) == 4194304

# Generated at 2022-06-22 06:45:36.422179
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    print(FileDownloader.format_seconds(1))
    print(FileDownloader.format_seconds(10))
    print(FileDownloader.format_seconds(100))
    print(FileDownloader.format_seconds(1000))
    print(FileDownloader.format_seconds(10000))
    print(FileDownloader.format_seconds(100000))
    print(FileDownloader.format_seconds(1000000))
    print(FileDownloader.format_seconds(10000000))
    print(FileDownloader.format_seconds(100000000))
    print(FileDownloader.format_seconds(1000000000))


# Generated at 2022-06-22 06:45:43.357450
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(0, 1, 100) == 100.0
    assert fd.calc_speed(0, 1, 125) == 125.0
    assert fd.calc_speed(0, 1, 1000) == 1000.0
    assert fd.calc_speed(0, 1000000, 1000) == 1.0
    assert fd.calc_speed(0, 1000000, 1) == 0.000001
    assert fd.calc_speed(0, 1, 0) == 0.0
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, -1)

# Generated at 2022-06-22 06:45:52.003473
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            self.report_retry(HTTPError('http error msg', 'http error errno', 'http error url'), 1, 2)
            return True


# Generated at 2022-06-22 06:46:02.671868
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-22 06:46:08.042517
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 10000, 0) is None
    assert fd.calc_speed(0, 0, 1000000) is None
    assert fd.calc_speed(0, 10000, 1000000) == 100
    assert fd.calc_speed(10, 10010, 1000000) == 100


# Generated at 2022-06-22 06:46:11.794625
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    class FakeYDL:
        def to_screen(self, msg):
            return

    fd = FileDownloader(FakeYDL(), None, None)
    assert fd.to_stderr("Hello") == None


# Generated at 2022-06-22 06:47:29.764550
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    # Set up logging
    logging.basicConfig(filename='test_log.txt', level=logging.DEBUG, filemode='w')
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 06:47:33.261556
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    def do_test(inp, expected):
        assert FileDownloader.undo_temp_name(inp) == expected
    do_test('abc', 'abc')
    do_test('abc.part', 'abc')

# Generated at 2022-06-22 06:47:36.821988
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    arg1 = FileDownloader()

    # Test 1
    arg1.report_unable_to_resume()



# Generated at 2022-06-22 06:47:41.932533
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    data = FileDownloader({})
    data._screen_file = io.StringIO()
    # call it
    data.report_unable_to_resume()
    # test the result
    assert data._screen_file.getvalue() == 'value: [download] Unable to resume\n', data._screen_file.getvalue()



# Generated at 2022-06-22 06:47:53.149122
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(0) == '0:00'
    assert FileDownloader.format_eta(1) == '0:01'
    assert FileDownloader.format_eta(59) == '0:59'
    assert FileDownloader.format_eta(60) == '1:00'
    assert FileDownloader.format_eta(61) == '1:01'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(3601) == '1:00:01'
    assert FileDownloader.format_eta(3660) == '1:01:00'

# Generated at 2022-06-22 06:47:54.668757
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    print(FileDownloader.report_unable_to_resume())

# Generated at 2022-06-22 06:48:04.414863
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    from youtube_dl.YoutubeDL import YoutubeDL
    import io
    import sys
    class DL(FileDownloader):
        def __init__(self, params):
            self.ydl = YoutubeDL(params)

    sout = io.StringIO()
    ydl = DL({'verbose': True, 'logger': MyLogger(), 'outtmpl': '%(id)s'})
    ydl.to_screen = lambda *args, **kargs: sout.write(' '.join(args)+'\n')
    # test report_warning
    ydl.report_warning('This is a warning message')
    if not 'WARNING: This is a warning message' in sout.getvalue():
        print('Unexpected log: %s' % sout.getvalue())
        return False
    # test report_warning with

# Generated at 2022-06-22 06:48:15.192068
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    def _test_ytdl_filename(filename, expected):
        fd = FileDownloader({})
        assert fd.ytdl_filename(filename) == expected
    _test_ytdl_filename('foo.mp4', 'foo.mp4.ytdl')
    _test_ytdl_filename('foo.webm', 'foo.webm.ytdl')
    _test_ytdl_filename('foo.mp3', 'foo.mp3.ytdl')
    _test_ytdl_filename('foo.m4a', 'foo.m4a.ytdl')
    _test_ytdl_filename('bar', 'bar.ytdl')
    _test_ytdl_filename('', '.ytdl')


# Generated at 2022-06-22 06:48:20.165810
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def _run_tests(tests, verbose=False):
        fd = FileDownloader(FakeYDL(), {})
        for filename, timestr, expected_result in tests:
            result = fd.try_utime(filename, timestr)
            if verbose:
                print(('%s\n%s\n%s\n' %
                       (result, expected_result,
                        result == expected_result)))
            assertEqual(result, expected_result)


# a is a list of arguments to pass to the FileDownloader.

# Generated at 2022-06-22 06:48:21.170209
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    pass


# Generated at 2022-06-22 06:49:10.845396
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '0.00%'
    assert FileDownloader.format_percent(0.1) == '0.10%'
    assert FileDownloader.format_percent(0.01) == '0.01%'
    assert FileDownloader.format_percent(0.001) == '0.00%'
    assert FileDownloader.format_percent(1) == '1.00%'
    assert FileDownloader.format_percent(3.14159) == '3.14%'
    assert FileDownloader.format_percent(99) == '99.00%'
    assert FileDownloader.format_percent(100) == '100.00%'
    assert FileDownloader.format_percent(101) == '101.00%'


# Generated at 2022-06-22 06:49:17.314172
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Dummy URL
    url = 'http://127.0.0.1/'
    # Dummy Template for filename
    filename_template = 'dummy_template'
    # Dummy info_dict
    info_dict = {'title': 'Dummy Title', 'id': 'this_is_an_id'}
    
    
    
    

# Generated at 2022-06-22 06:49:26.947445
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(YoutubeDL({}))

    # No modification time given
    assert fd.try_utime(os.path.join(os.getcwd(), 'test_FileDownloader_try_utime.tmp'), None) is None

    # Invalid modification time given
    assert fd.try_utime(os.path.join(os.getcwd(), 'test_FileDownloader_try_utime.tmp'), 'asdf') is None

    # Valid modification time
    assert fd.try_utime(os.path.join(os.getcwd(), 'test_FileDownloader_try_utime.tmp'), 'Thu, 01 Jan 1970 00:00:00 +0000') == 0

