

# Generated at 2022-06-22 06:40:08.050556
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(FakeYDL(), {})
    # One millisecond
    assert fd.calc_speed(0, 0, 0) is None
    # One millisecond
    assert fd.calc_speed(0, 0.001, 0) is None
    assert fd.calc_speed(0, 0.001, 1) == 1000



# Generated at 2022-06-22 06:40:12.844507
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: None

    msgs = []
    fd.to_console_title = lambda msg: msgs.append(msg)

    fd.report_progress({'status': 'downloading'})
    assert len(msgs) == 1 and msgs[0] == 'youtube-dl  %'

    msgs = []
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 0})
    assert len(msgs) == 1 and msgs[0] == 'youtube-dl  0%'

    msgs = []
    fd.report_progress({
        'status': 'downloading',
        'downloaded_bytes': 100})

# Generated at 2022-06-22 06:40:25.339905
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'outtmpl': '-'})
    fd.report_file_already_downloaded('filename')
    fd.report_file_already_downloaded('출력')
    fd.report_file_already_downloaded('')
    fd.to_screen = lambda *args: None
    fd.report_file_already_downloaded('filename')
    fd.report_file_already_downloaded('출력')
    fd.report_file_already_downloaded('')
if __name__ == '__main__':
    print('No unit test')

# Generated at 2022-06-22 06:40:35.214510
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    downloader = FileDownloader({})
    test_cases = [
        ('test.txt.part', 'test.txt'),
        ('test.part', 'test'),
        ('test.txt', 'test.txt'),
        ('test.txt.part.part', 'test.txt.part'),
        ('test.txt.part.txt', 'test.txt.part.txt'),
        ('test.txt.part.part.part', 'test.txt.part.part'),
    ]
    for input, expected in test_cases:
        assert expected == downloader.undo_temp_name(input)



# Generated at 2022-06-22 06:40:39.701327
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(None, None, None)
    fd.to_screen = Mock()
    fd.report_resuming_byte(0)
    fd.to_screen.assert_called_with('[download] Resuming download at byte 0')

# Generated at 2022-06-22 06:40:52.091081
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    class MockYoutubeDL():
        pass

    fd = FileDownloader(MockYoutubeDL(), {'noprogress': True, 'verbose': True})

    assert fd.calc_speed(1, 2, 1) == 1
    assert fd.calc_speed(1, 2, 2) == 2
    assert fd.calc_speed(1, 0.5, 1) == 2
    assert fd.calc_speed(1, 0.5, 2) == 4
    # Bounded upper
    assert fd.calc_speed(1, 1e100, 1) == 4194304
    assert fd.calc_speed(1, 1e100, 2) == 8388608
    assert fd.calc_speed(1, 1e100, 4194304) == 4194304
   

# Generated at 2022-06-22 06:41:02.017003
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    class DummyYoutubeDL(object):
        class params(object):
           ProxyBasicAuth = None

# Generated at 2022-06-22 06:41:08.624624
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd1 = FileDownloader({}, None)
    fd2 = FileDownloader({}, None)

    status1 = []
    fd1.add_progress_hook(lambda s: status1.append(s))

    status2 = []
    fd2.add_progress_hook(lambda s: status2.append(s))

    assert status1 == []
    assert status2 == []

    fd1._hook_progress({'foo': 1})
    assert status1 == [{'foo': 1}]
    assert status2 == []

    fd2._hook_progress({'bar': 2})
    assert status1 == [{'foo': 1}]
    assert status2 == [{'bar': 2}]



# Generated at 2022-06-22 06:41:19.828003
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def test_status(status, expected_output):
        status_message = FileDownloader._format_progress_line(status)
        assert status_message == expected_output

    test_status({
        'downloaded_bytes': 0,
        'elapsed': 0,
        'eta': None,
        'speed': 0,
        'total_bytes': None,
        'total_bytes_estimate': None,
    }, 'Unknown % at Unknown speed')

    test_status({
        'downloaded_bytes': 10,
        'elapsed': 0,
        'eta': None,
        'speed': None,
        'total_bytes': None,
        'total_bytes_estimate': None,
    }, '10.0 KiB at Unknown speed')


# Generated at 2022-06-22 06:41:31.516728
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    ydl = YoutubeDL()
    dl = FileDownloader(ydl, {'continuedl': True, 'noprogress': True})
    assert dl.best_block_size(0.0, 0) == 1
    assert dl.best_block_size(0.0, 1) == 1
    assert dl.best_block_size(0.0, 2) == 2
    assert dl.best_block_size(0.0, 4) == 4
    assert dl.best_block_size(0.0, 8) == 8
    assert dl.best_block_size(0.0, 16) == 16
    assert dl.best_block_size(0.0, 32) == 32
    assert dl.best_block_size(0.0, 64) == 64
    assert d

# Generated at 2022-06-22 06:41:49.421345
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test for a number of iterations, for the calc_speed method of the FileDownloader class
    # This method returns the estimated rate of download in bytes per second, given an initial date and time,
    # the current date and time, and the number of bytes downloaded between these two dates
    # It is called within the reporthook function in FileDownloader

    # One millisecond since epoch
    ONE_MILLISECOND_SINCE_EPOCH = (1 / 1000) + FileDownloader.EPOCH
    # One millisecond before current time
    ONE_MILLISECOND_BEFORE_NOW = time.time() - ONE_MILLISECOND_SINCE_EPOCH

    # Test tuple format: start time, current time, bytes downloaded, expected value

# Generated at 2022-06-22 06:42:01.985016
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    """
    Unit test for method FileDownloader.calc_eta
    """

    import datetime

    fd = FileDownloader(params={})

    curr = 1000
    total = 10000
    start = time.time()
    # Arbitrary values
    start = start - datetime.timedelta(seconds=10).total_seconds()
    now = start + datetime.timedelta(seconds=5).total_seconds()
    assert fd.calc_eta(start, now, curr, total) == 60

    start = start - datetime.timedelta(seconds=5).total_seconds()
    now = start + datetime.timedelta(seconds=10).total_seconds()
    assert fd.calc_eta(start, now, curr, total) == 10

    curr = 2000
    assert f

# Generated at 2022-06-22 06:42:14.093934
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # Tester for FileDownloader.real_download
    # Usage: set debug to True in FileDownloader.real_download to see results
    # (no output while running unit tests)
    class TestFileDownloader(FileDownloader):
        def __init__(self, params, outtmpl):
            FileDownloader.__init__(self, params)
            self.outtmpl = outtmpl

        def real_download(self, filename, info_dict):
            self.ydl.to_screen('[debug] real_download called')
            self.ydl.to_screen('[debug] filename: ' + filename)
            self.ydl.to_screen('[debug] outtmpl: ' + self.outtmpl)

# Generated at 2022-06-22 06:42:23.042185
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    import platform
    from youtube_dl import YoutubeDL

    if platform.system() != 'Windows':
        return

    # the following if statement is the same as the platform if statement
    # without the condition that requires this to not be in a virtualenv
    # and we will ignore it
    # if hasattr(sys, 'real_prefix'):
    #     return

    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'outtmpl': '%(autonumber)s.%(ext)s'})

    fd.to_console_title('test')



# Generated at 2022-06-22 06:42:32.318600
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    cases = [
        ((0, 0, 0), None),
        ((0, 0, 1), None),
        ((1, 0, 0), None),
        ((1, 1, 1), 1),
        ((1.1, 1, 1), 1.1),
        ((1, 1, 1.1), 0.9090909090909091),
    ]

    downloader = FileDownloader(None, None)

    for case in cases:
        assert downloader.calc_speed(case[0][0], case[0][1], case[0][2]) == case[1]



# Generated at 2022-06-22 06:42:35.570537
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    #  Test argument is the name of a class
    if True:
        #  Instantiate an object of the class
        fd = FileDownloader(params={})
        #  Call the function
        fd.report_warning('Test warning message')
        #  Check the result
    if True:
        print('Success')

# Generated at 2022-06-22 06:42:45.580319
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Preparation
    class MockFileDownloader(FileDownloader):
        def __init__(self):
            # Call to parent constructor
            FileDownloader.__init__(self, None)
            self._test_method = self.try_utime

        @staticmethod
        def _test_create_files(name, mtime):
            # Create the file
            f = open(encodeFilename(name), 'w')
            f.write('Sample text')
            f.close()
            # Change the modification time
            os.utime(encodeFilename(name), (mtime, mtime))
            # Check if it was really changed
            assert(os.path.getmtime(encodeFilename(name)) == mtime)

    # Tests
    fd = MockFileDownloader()
    fd.params['nopart']

# Generated at 2022-06-22 06:42:51.372487
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.to_screen = lambda s: s
    fd = FileDownloader(ydl, {})
    fd.to_screen = lambda s: s
    assert fd.report_warning('xyz') == 'WARNING: xyz'



# Generated at 2022-06-22 06:43:01.821404
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(YoutubeDL(), {})
    fd.to_screen = lambda *x: None
    fn = 'test_FileDownloader_try_utime.tmp'

    def try_utime(timestr):
        if os.path.isfile(fn):
            os.remove(fn)
        open(fn, 'w').close()
        return fd.try_utime(fn, timestr)

    assert try_utime('asdasd') is None
    assert try_utime('@asdasd') is None
    assert try_utime('Thu, 13 May 2010 22:23:35 GMT') == 1273722015

    assert try_utime('now') == int(time.time())


# Generated at 2022-06-22 06:43:12.758154
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    downloader = FileDownloader(DummyYDL(), {})


# Generated at 2022-06-22 06:43:31.816431
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    filename_t = tempfile.NamedTemporaryFile(delete=False)
    filename = filename_t.name
    filename_t.close()
    os.unlink(filename)
    info_dict = {}
    info_dict['url'] = 'http://127.0.0.1:8791/'
    info_dict['http_headers'] = {}
    info_dict['http_headers']['Header1'] = 'Value1'
    info_dict['http_headers']['Header2'] = 'Value2'
    info_dict['http_headers']['Header3'] = 'Value3'

    # Test basic normal download

# Generated at 2022-06-22 06:43:44.892379
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """
    Verify that FileDownloader._try_utime() truncates file times
    to whole days.
    """
    import tempfile
    import time

    tmpfile = tempfile.NamedTemporaryFile()

    # Save the time of the last modification, as reported by the operating
    # system.
    then = os.path.getmtime(tmpfile.name)

    # Advance the system time by a fractional number of seconds.
    time.sleep(0.5)
    os.utime(tmpfile.name, None)
    now = os.path.getmtime(tmpfile.name)
    assert then != now

    # Advancing the system clock by a fractional number of seconds should
    # not change the file modification time reported by the operating system.
    fd = FileDownloader({})
    fd.try_

# Generated at 2022-06-22 06:43:56.469838
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    # Test with file absent
    tn1 = fd.temp_name('/tmp/aaa.file')
    assert(tn1 == '/tmp/aaa.file.part')
    # Test with file present
    tn2 = fd.temp_name('/tmp/aaa.file')
    assert(tn2 == '/tmp/aaa.file.part')
    # Test without file (using stdout)
    tn3 = fd.temp_name('-')
    assert(tn3 == '-')
    # Test without file (using stdout) with nopart
    fd = FileDownloader({'nopart': True})
    tn4 = fd.temp_name('-')
    assert(tn4 == '-')
    # Test without file (using stdout) with

# Generated at 2022-06-22 06:43:59.397284
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():

	fd = FileDownloader()
	assrt_equal(fd.calc_percent(0,0), 0)
	assrt_equal(fd.calc_percent(0,1), 0)
	assrt_equal(fd.calc_percent(1,1), 100)
	assrt_equal(fd.calc_percent(1000,100), 10)


# Generated at 2022-06-22 06:44:10.848305
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # Init
    f = FileDownloader({})
    count = 44
    retries = 3
    err = "err.msg"
    # Try to set up a catch for the output
    import io
    import sys
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    capturedOutput = io.StringIO()                  # Create StringIO object
    sys.stdout = capturedOutput                     #  and redirect stdout.
    sys.stderr = capturedOutput
    # Now call the method
    f.report_retry(err,count,retries)

    # The output should be something like:
    # [download] Got server HTTP error: err.msg. Retrying (attempt 5 of 3)...
    # So it should contain the error message, the count and the number of retries
    assert err

# Generated at 2022-06-22 06:44:22.901517
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None)
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('1000') == 1000
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('+1k') == 1024
    assert fd.parse_bytes('-1k') == -1024
    assert fd.parse_bytes('+1.5k') == 1536
    assert fd.parse_bytes('-1.5k') == -1536
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('-1k0001') == -1024
    assert fd.parse_bytes('-1.5k01') == -1536
    assert fd.parse_bytes('1.5k') == 1536
   

# Generated at 2022-06-22 06:44:34.728410
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    tester = FileDownloader(None, None)
    tester.to_screen = lambda *x: x
    # No exception raised
    assert tester.report_error('In get_info') == 'In get_info'
    assert tester.report_error('In get_info', expected=True) == 'In get_info'
    
    # No exception raised
    orig_stderr = sys.stderr
    try:
        sys.stderr = FakeStderr()
        assert tester.report_error('In get_info') == 'In get_info'
        assert tester.report_error('In get_info', expected=True) == 'In get_info'
    finally:
        sys.stderr = orig_stderr
        
    # Non-fatal error: no exception should be raised

# Generated at 2022-06-22 06:44:45.489976
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(0) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(1) == '%10s' % '1.00b/s'
    assert FileDownloader.format_speed(9.99) == '%10s' % '9.99b/s'
    assert FileDownloader.format_speed(10) == '%10s' % '10.0b/s'
    assert FileDownloader.format_speed(10.01) == '%10s' % '10.0b/s'
    assert FileDownloader.format_speed(99) == '%10s' % '99.0b/s'
    assert FileDownloader.format_speed(100) == '%10s' % '100b/s'
    assert File

# Generated at 2022-06-22 06:44:57.498605
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(1) == '100.0%'
    assert FileDownloader.format_percent(0.37) == '37.0%'
    assert FileDownloader.format_percent(0.12345) == '12.3%'
    assert FileDownloader.format_percent(0.123) == '12.3%'
    assert FileDownloader.format_percent(0.12) == '12.0%'
    assert FileDownloader.format_percent(0.1) == '10.0%'
    assert FileDownloader.format_percent(0.01) == '1.0%'
    assert FileDownloader.format_percent(0.0) == '0.0%'
    assert FileDownloader.format_percent(0.049) == '4.9%'
   

# Generated at 2022-06-22 06:45:06.372692
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader({})
    assert fd.format_percent(0) == '0%'
    assert fd.format_percent(1) == '1%'
    assert fd.format_percent(99) == '99%'
    assert fd.format_percent(100) == '100%'
    assert fd.format_percent(199) == '99%'
    assert fd.format_percent(1.0 / 3.0) == '0%'
    assert fd.format_percent(2.0 / 3.0) == '1%'



# Generated at 2022-06-22 06:45:36.389218
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():

    dl = FileDownloader({'simulate': False}, YoutubeDL())

    def test(seconds, expected):
        res = dl.format_seconds(seconds)

# Generated at 2022-06-22 06:45:46.995986
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    from .YoutubeDL import YoutubeDL
    from .PostProcessor import PostProcessor
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'test': 'val'})
    pp = PostProcessor(ydl, fd._test_trouble_hook, {'test': 'val'})
    fd.report_error('msg %s %d', 'str', 2)
    fd.report_warning('msg %s %d', 'str', 2)
    fd.trouble(u'msg')
    pp.run()
    assert fd._test_trouble_hook_value == 'ERROR: msg str 2\nWARNING: msg str 2\n'



# Generated at 2022-06-22 06:45:50.466983
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    fd = FileDownloader({"_real_download": lambda *a: True}, ".")
    fd.real_download("_1_foo.bar", None)
    

# Generated at 2022-06-22 06:46:01.853843
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader()


# Generated at 2022-06-22 06:46:07.039527
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class DummyYDL(object):
        def __init__(self):
            pass
        def to_screen(self, message):
            print(message)
    class DummyFD(FileDownloader):
        def __init__(self):
            self.ydl = DummyYDL()
    dummyfd = DummyFD()
    dummyfd.report_retry(ValueError, 3, 15)


# Generated at 2022-06-22 06:46:13.833039
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(42) == "42.0%"
    assert FileDownloader.format_percent(42.0) == "42.0%"
    assert FileDownloader.format_percent(42.42) == "42.4%"
    assert FileDownloader.format_percent(42.5) == "42.5%"
    assert FileDownloader.format_percent(42.57) == "42.6%"



# Generated at 2022-06-22 06:46:25.837827
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def _test_calc_eta(start, now, total, current, expected):
        assert FileDownloader.calc_eta(start, now, total, current) == expected

    _test_calc_eta(0, 0, 100, 0, 0)
    _test_calc_eta(0, 10, 100, 10, 90)
    _test_calc_eta(0, 10, 100, 0, 100)
    _test_calc_eta(0, 10, 100, 100, 0)
    # Try to trick with float numbers
    _test_calc_eta(0.1, 10.1, 100.0, 10.0, 90)
    _test_calc_eta(0.1, 10.1, 100.0, 0.0, 100)

# Generated at 2022-06-22 06:46:36.512764
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test if it works in simple cases
    fd = FileDownloader({'nopart': True, 'verbose': True})
    # Already ends with .part
    assert fd.temp_name(u'a.part') == u'a.part'
    # Already ends with .part.part
    assert fd.temp_name(u'a.part.part') == u'a.part.part'
    # Base name is empty
    assert fd.temp_name(u'') == u''

    # Test that it keeps directory name
    assert fd.temp_name(u'abc/def/a.txt') == u'abc/def/a.txt.part'
    # Test that it can handle directory names which end with .part

# Generated at 2022-06-22 06:46:44.394313
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(10.0, 1000) == 500
    assert FileDownloader.best_block_size(10.0, 2) == 1
    assert FileDownloader.best_block_size(10.0, 10) == 10
    assert FileDownloader.best_block_size(10.0, 2000) == 1024
    assert FileDownloader.best_block_size(10.0, 5000) == 1024
    assert FileDownloader.best_block_size(0.0, 10) == 10


# Generated at 2022-06-22 06:46:47.766792
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    fd = FileDownloader('http://a', {})
    fd.trouble(u'ERRORERRORERROR')
    pass

if __name__ == '__main__':
    test_FileDownloader_trouble()

# Generated at 2022-06-22 06:47:42.035588
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    _items = [
        # input, expected output
        (
            'foo',
            'foo',
        ),
        (
            'foo.part',
            'foo',
        ),
        (
            'foo\\bar.part',
            'foo\\bar',
        ),
        (
            r'foo\bar.part',
            r'foo\bar',
        ),
        (
            'foo\\\\\\bar.part',
            'foo\\\\\\bar',
        ),
        (
            r'foo\\\bar.part',
            r'foo\\\bar',
        ),
    ]
    for input_s, output_s in _items:
        assert FileDownloader.undo_temp_name(input_s) == output_s
import unittest

# Generated at 2022-06-22 06:47:53.246599
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    """
    Unit test for function parse_bytes of class FileDownloader
    """
    assert FileDownloader.parse_bytes("42") == 42, "parse_bytes do not return correct value."
    assert FileDownloader.parse_bytes("42KiB") == 42 * (1 << 10), "parse_bytes do not return correct value."
    assert FileDownloader.parse_bytes("42KB") == 42 * (1 << 10), "parse_bytes do not return correct value."
    assert FileDownloader.parse_bytes("42K") == 42 * (1 << 10), "parse_bytes do not return correct value."
    assert FileDownloader.parse_bytes("42kB") == 42 * (1 << 10), "parse_bytes do not return correct value."

# Generated at 2022-06-22 06:48:03.332205
# Unit test for method report_retry of class FileDownloader

# Generated at 2022-06-22 06:48:08.745771
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    from_seconds = FileDownloader.format_seconds

    assert from_seconds(0) == '0:00'
    assert from_seconds(4) == '0:04'
    assert from_seconds(60) == '1:00'
    assert from_seconds(601) == '10:01'
    assert from_seconds(3601) == '1:00:01'
    assert from_seconds(7261) == '2:01:01'
    assert from_seconds(3607261) == '1001:01:01'



# Generated at 2022-06-22 06:48:20.605480
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    fd = FileDownloader(
        YoutubeDL({'quiet': False}),
        {}, None, 'http://www.youtube.com/watch?v=BaW_jenozKc')
    assert fd.format_eta(4) == '00:00:04'
    assert fd.format_eta(14) == '00:00:14'
    assert fd.format_eta(60) == '00:01:00'
    assert fd.format_eta(85) == '00:01:25'
    assert fd.format_eta(3600 + 1) == '01:00:01'
    assert fd.format_eta(3601 * 2) == '02:00:01'
    assert fd.format_eta(7200 + 7201) == '02:01:01'

# Generated at 2022-06-22 06:48:28.966479
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    class MockYoutubeDL():
        params = {}

    fd = FileDownloader({}, MockYoutubeDL())
    assert fd.ytdl_filename('foo.bar') == 'foo.bar.ytdl'
    assert fd.ytdl_filename('foo') == 'foo.ytdl'
    assert fd.ytdl_filename('foo.') == 'foo..ytdl'
    assert fd.ytdl_filename('foo.bar.ytdl') == 'foo.bar.ytdl.ytdl'

# Generated at 2022-06-22 06:48:39.839185
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    def check(func):
        # Make sure that the method doesn't raise exceptions,
        # and always return a string type
        try:
            retval = func()
            assert isinstance(retval, str)
            return
        except Exception:
            print('%r raised exception' % (func,))
            raise

    class MockFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            pass

    downloader = MockFileDownloader()

    # Check that simple strings always succeed
    check(lambda: downloader.try_rename('first_name', 'second_name'))
    check(lambda: downloader.try_rename('first_name', 'second_name.part'))

# Generated at 2022-06-22 06:48:51.809478
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    import unittest
    class TestFormatEta(unittest.TestCase):
        def test_format_eta(self):
            dl = FileDownloader({})
            self.assertEqual(dl.format_eta(None), '--:--')
            self.assertEqual(dl.format_eta(0), '0:00')
            self.assertEqual(dl.format_eta(60), '1:00')
            self.assertEqual(dl.format_eta(61), '1:01')
            self.assertEqual(dl.format_eta(121), '2:01')
            self.assertEqual(dl.format_eta(3600), '1:00:00')
            self.assertEqual(dl.format_eta(3600 + 60), '1:01:00')
            self

# Generated at 2022-06-22 06:49:02.177277
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FileDownloader(YoutubeDL({'retries': 5}), {}, False)
    for i in range(1, 5):
        fd.report_retry(Exception('test error'), i, 5)
    assert fd.ydl.msgs == ['[download] Got server HTTP error: test error. Retrying (attempt 1 of 5)...',
                           '[download] Got server HTTP error: test error. Retrying (attempt 2 of 5)...',
                           '[download] Got server HTTP error: test error. Retrying (attempt 3 of 5)...',
                           '[download] Got server HTTP error: test error. Retrying (attempt 4 of 5)']
    fd.report_retry(Exception('test error'), 5, 5)


# Generated at 2022-06-22 06:49:06.570046
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    downloader = FileDownloader({})
    now_str = 'Thu, 04 May 2017 08:17:04 GMT'
    now = timeconvert(now_str)
    assert downloader.try_utime('download_test.tmp', now_str) == now
    os.remove('download_test.tmp')