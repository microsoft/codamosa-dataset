

# Generated at 2022-06-22 06:40:25.393899
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(0) == '      0b/s'
    assert FileDownloader.format_speed(1024) == '   1.00k/s'
    assert FileDownloader.format_speed(1024*1024) == ' 976.56k/s'
    assert FileDownloader.format_speed(1024*1024*1024) == '   1.00M/s'
    assert FileDownloader.format_speed(1024*1024*1024*1024) == ' 953.67M/s'
    assert FileDownloader.format_speed(1024*1024*1.7) == '   1.65k/s'
    assert FileDownloader.format_speed(1024*1024*1.7, True) == '   1.7k/s'

# Generated at 2022-06-22 06:40:36.563268
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    ydl = YoutubeDL(params={})
    fd = FileDownloader(ydl, {
        'id': 'test',
        'url': 'http://www.example.com/'
    })
    fd.report_error('unable to download video data: HTTP Error')
    assert(str(fd.ydl.downloader.exc_info).startswith('<type \'exceptions.IOError\'>:'))
    assert(fd.ydl.downloader.exc_info.args[0] == 'unable to download video data')
    assert(fd.ydl.downloader.exc_info.args[1] == 'HTTP Error')

# Unit test method download of class FileDownloader

# Generated at 2022-06-22 06:40:41.740474
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({}, None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0.001, 1) == 1000
    assert fd.calc_speed(1, 3, 500) == 166.66666666666666

# Generated at 2022-06-22 06:40:49.020451
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    """ FileDownloader.format_retries - test normal use of method """
    ydl = YoutubeDL()
    ydl.params['retries'] = 5
    ydl.params['max_retries'] = 999
    fd = FileDownloader(ydl=ydl)
    expected = '5'
    assert fd.format_retries(5) == expected, 'FileDownloader.format_retries failed'


# Generated at 2022-06-22 06:40:58.341235
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    # Tests if download succeeds when only ratelimit is specified and download
    # is interrupted, and if the file size equals the expected size.
    print('\n[info] Testing FileDownloader.report_error().')
    url = 'http://ipv4.download.thinkbroadband.com/10MB.zip'
    temp_name = 'test_file.tmp'
    file_size = 10218756
    params = {'ratelimit': '100k'}
    ydl = YoutubeDL(params)
    fd = FileDownloader(ydl, {'url': url, 'id': 'test_FileDownloader',
                          'title': 'test_FileDownloader'})
    fd.report_destination(temp_name)
    fd.download(temp_name)

# Generated at 2022-06-22 06:41:06.373995
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test whether FileDownloader.download raises on HTTP error 5xx
    class TestDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            if "retry_strategy" in info_dict:
                raise NotImplementedError("No double-execution for retry_strategy")
            # Do not really download files
            self.to_screen("[download] This is a test message. " + filename)
            return True

        def temp_name(self, filename):
            return filename


# Generated at 2022-06-22 06:41:12.824348
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader({'noprogress': True, 'quiet': True})
    # On Windows, the first call to to_console_title() fails for me
    # fd.to_console_title('hello')
    # fd.to_console_title('')
    fd.to_console_title('hello2')
    fd.to_console_title('hello3')


# Generated at 2022-06-22 06:41:18.566454
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(YoutubeDL({}), {})
    assert fd.best_block_size(0.0, 1) == 1
    assert fd.best_block_size(0.0, 1000) == 1000
    assert fd.best_block_size(1.0, 1024) == 1024



# Generated at 2022-06-22 06:41:28.534772
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    ydl = YoutubeDL()
    ydl.params['ratelimit'] = RateLimit()
    fd = FileDownloader(ydl, {'url': 'myurl'}, 'myouttmpl')
    assert fd.ydl is ydl
    assert fd.info_dict is ydl.ydl_opts
    assert fd.params is ydl.params
    assert fd.info_dict['url'] == 'myurl'
    assert fd.params['outtmpl'] == 'myouttmpl'
    # Test outtmpl_format
    assert fd.outtmpl_format['%(id)s'] == 'myurl'

if __name__ == '__main__':
    test_FileDownloader()

# Generated at 2022-06-22 06:41:34.329553
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class TestFDL(FileDownloader):
        def __init__(self, ydl, params):
            self.to_screen_buffer = []
            self.to_cons_title_buffer = []
            self.params = params
            FileDownloader.__init__(self, ydl, params)

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.append(message)

        def to_console_title(self, message):
            self.to_cons_title_buffer.append(message)

        def format_retries(self, retries):
            return '{}'.format(retries)

        def trouble(self, message, tb=None):
            pass

    params = {
        'format': 'best',
    }
    ydl = FakeYDL

# Generated at 2022-06-22 06:41:56.769302
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class FileDownloaderStub(FileDownloader):
        def __init__(self, *args, **kargs):
            FileDownloader.__init__(self, *args, **kargs)
            self.real_download_calls = []

        @staticmethod
        def _make_info_dict():
            return {'id': 'testid'}

        def real_download(self, filename, info_dict):
            self.real_download_calls.append(filename)
# End of unit test for method download of class FileDownloader

# Generated at 2022-06-22 06:42:07.910929
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def test(rate, sleep, expected_time):
        speed = rate
        start_time = 0
        now = sleep
        byte_counter = (sleep - start_time) * rate
        fd = FileDownloader(None, params={'ratelimit': rate})
        fd.slow_down(start_time, now, byte_counter)
        if now != expected_time:
            return False
        return True

    assert test(10, 4, 0) == True
    assert test(10, 5, 1) == True
    assert test(10, 9, 5) == True
    assert test(10, 10, 5) == True
    assert test(10, 11, 6) == True
    assert test(10, 19, 10) == True
    assert test(10, 20, 10) == True

# Generated at 2022-06-22 06:42:08.576279
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    pass

# Generated at 2022-06-22 06:42:20.118999
# Unit test for method format_retries of class FileDownloader

# Generated at 2022-06-22 06:42:28.446828
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    import datetime

    def test_cases(cases):
        for start, now, current, total, eta in cases:
            eta_secs = FileDownloader.calc_eta(start, now, current, total)
            assert eta_secs == eta

    cases = [
        # end - beginning = duration
        # current * duration / current = duration
        (1000, 1000, 0, 1000, None),
        (1000, 2000, 500, 1000, 500),
        (1000, 2000, 1000, 1000, 0),
        (1000, 3000, 1500, 2000, 1000),
        # current * (end - beginning) / total = duration_left
        (1000, 1000, 0, 2000, None),
        (1000, 2000, 500, 1000, 0),
        (1000, 3000, 2000, 1000, 1000),
    ]


# Generated at 2022-06-22 06:42:39.879880
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test case: Regular filename
    assert FileDownloader.undo_temp_name(
        FileDownloader.temp_name('abc.part')) == 'abc'

    # Test case: Filename that ends in '.part'
    assert FileDownloader.undo_temp_name(
        FileDownloader.temp_name('abc.part.part')) == 'abc.part'

    # Test case: Filename that ends in '.part' but the user explicitly asked
    # for filename to have '.part' suffix
    assert FileDownloader.undo_temp_name(
        FileDownloader.temp_name('abc.part.part', 20), 20) == 'abc.part'

    # Test case: - as filename (special case for stdout)
    assert FileDownloader.undo_temp_name(
        FileDownloader.temp_name('-'))

# Generated at 2022-06-22 06:42:43.216922
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader(None, None, None)
    try:
        fd.report_unable_to_resume()
        assert True
    except:
        assert False
        

# Generated at 2022-06-22 06:42:54.422033
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import io

    # test 1: file already present
    testparams = {'nooverwrites': True}
    testinfodict = {}
    testfilename = 'myfile.mp3'
    open(encodeFilename(testfilename), 'w').close()
    fd = FileDownloader(FakeYDL(), testparams)
    ret = fd.download(testfilename, testinfodict)
    assert(ret)
    os.remove(encodeFilename(testfilename))
    # test 2: file name not present (normal download)
    open(encodeFilename(testfilename), 'w').close()
    fd = FileDownloader(FakeYDL(), testparams)
    ret = fd.download(testfilename, testinfodict)
    assert(ret)
    os.remove(encodeFilename(testfilename))
   

# Generated at 2022-06-22 06:43:03.173206
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    v = {"youtube_dl.FileDownloader": [
        "to_console_title"
    ]}

    b = {
        "youtube_dl.FileDownloader.to_console_title": "msg"
    }

    d = {
        "youtube_dl.FileDownloader": {
            "to_console_title": "msg"
        }
    }

    t = {
        "youtube_dl.FileDownloader.to_console_title": ["msg"]
    }

    e = {
        "youtube_dl.FileDownloader": {
            "to_console_title": "msg"
        }
    }

    return (v, b, d, t, e)

# Generated at 2022-06-22 06:43:11.815174
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    import io
    import os
    from io import BytesIO
    from io import StringIO
    try:
        from urllib.request import HTTPErrorProcessor
    except ImportError:
        from urllib2 import HTTPErrorProcessor
    import socket
    import tempfile
    import zipfile
    try:
        import gzip
    except ImportError:
        gzip = None
    import json
    import pycurl

# Generated at 2022-06-22 06:43:35.240140
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # Input output example
    # Input: self, message
    # Output: 'youtube-dl ' + filename
    # Test:
    # fn = FileDownloader({'verbose': False}, {'youtube-dl':'youtube-dl'})
    # fn.to_console_title('filename')
    # Output: "youtube-dl filename"
    fn = FileDownloader({'verbose': False}, {'youtube-dl':'youtube-dl'})
    fn.to_console_title('filename')
    # Check if output equals to the example
    # If test passes, output will be "youtube-dl filename"
    assert fn.to_console_title('filename') == 'youtube-dl filename'


# Generated at 2022-06-22 06:43:38.444028
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    # Test to print message to console
    #assert to_stderr('hello') == 'hello'
    assert True

# Generated at 2022-06-22 06:43:49.699671
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader({}, None)
    assert(fd.ytdl_filename('asdf') == 'asdf.ytdl')
    assert(fd.ytdl_filename('asdf.ytdl') == 'asdf.ytdl')
    assert(fd.ytdl_filename('asdf' + os.sep + 'asdf') == 'asdf' + os.sep + 'asdf.ytdl')
    assert(fd.ytdl_filename(os.sep + 'asdf') == os.sep + 'asdf.ytdl')
    assert(fd.ytdl_filename(os.sep + 'asdf.ytdl') == os.sep + 'asdf.ytdl')

# Generated at 2022-06-22 06:44:01.654206
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(DummyYoutubeDL(), None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 0, 1) is None
    assert fd.calc_speed(0, 1, 1) == 1.0
    assert fd.calc_speed(1, 0, 1) is None
    assert fd.calc_speed(0, 1000, 2) == 2.0
    assert fd.calc_speed(10, 1000, 2) == 2.0
    assert fd.calc_speed(200, 1000, 2) == 2.0
    assert fd.calc_speed(800, 1000, 2) == 2.0
   

# Generated at 2022-06-22 06:44:11.416640
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import pytest
    from .jsinterp import JSInterpreter
    from .extractor import get_info_extractor

    all_downloaders = [
    ('FakeFileDownloader', FakeFileDownloader),
    ('AtomFileDownloader', AtomFileDownloader),
    ('WgetFileDownloader', WgetFileDownloader),
    ('Aria2cFileDownloader', Aria2cFileDownloader),
    ('ExternalFD', ExternalFD),
    ('FFmpegFD', FFmpegFD),
    ('HlsFD', HlsFD),
    ('HttpFD', HttpFD),
    ('RtmpFD', RtmpFD),
    ('YtdlFD', YtdlFD),
    ('PostProcessor', PostProcessor),
    ('TemplateFD', TemplateFD),
    ]

    if has_rtmpdump():
        all_

# Generated at 2022-06-22 06:44:13.125719
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd.real_download(filename, info_dict)




# Generated at 2022-06-22 06:44:15.770405
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    downloader = FileDownloader(None, {}, {})
    assert downloader.report_resuming_byte(0) == None


# Generated at 2022-06-22 06:44:28.015022
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    s = {
        'downloaded_bytes': 100,
        'total_bytes': 1000,
        'elapsed': 1,
        'eta': 60,
        'ratelimit': 3000,
        'speed': 100
    }

    s['status'] = 'finished'
    assert fd.report_progress(s) == None
    s['status'] = 'downloading'
    assert fd.report_progress(s) == None

    s['downloaded_bytes'] = None
    s['total_bytes'] = None

    s['total_bytes_estimate'] = 1000
    s['eta'] = 60
    assert fd.report_progress(s) == None

    s['downloaded_bytes'] = None
    s['total_bytes_estimate'] = None


# Generated at 2022-06-22 06:44:29.448276
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader()
    fd.try_rename('test_test.mp4.mp4', 'test_test.mp4')



# Generated at 2022-06-22 06:44:33.450640
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    Fd = FileDownloader({'ratelimit': '5'})
    start_time = time.time()
    Fd.slow_down(start_time, start_time, 100)
    assert time.time() - start_time < 0.01, 'The download should not be delayed if the download speed is less than ratelimit'
    Fd.slow_down(start_time, start_time, 5000000)
    assert time.time() - start_time > 0.1, 'The download should be delayed if the download speed is great than ratelimit'

# Generated at 2022-06-22 06:44:56.932488
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    downloaded_bytes = 22
    total_bytes = None
    filename = "D:\\YouTube\\#KapusoMo,JessicaSoho:Datu Abdul-ra" + \
               "up,nagsampa ng kaso laban sa mga negosyanteng m" + \
               "anloloko sa publiko sa pagbebenta ng illegal na" + \
               " abaka.mp4"
    retries = 5

# Generated at 2022-06-22 06:45:02.301696
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test with no progress
    params = {}
    fd = FileDownloader(params)
    assert fd.params.get('noprogress')
    fd.report_progress({'status': 'finished'})

    # Test report_progress
    params = {'noprogress': False}
    fd = FileDown

# Generated at 2022-06-22 06:45:12.964427
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    import unittest
    class DummyLogger(object):
        def __init__(self):
            self.messages = []
        def debug(self, *args):
            self.messages.append({
                'level': 'debug',
                'args': args
            })
        def warning(self, *args):
            self.messages.append({
                'level': 'warning',
                'args': args
            })
        def error(self, *args):
            self.messages.append({
                'level': 'error',
                'args': args
            })

    class DummyYoutubeDL(object):
        def __init__(self, logger):
            self.params = {'verbose': True}
            self.logger = logger
        def to_screen(self, *args):
            pass


# Generated at 2022-06-22 06:45:23.917055
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    import unittest

    # Test vectors from http://en.wikipedia.org/wiki/Gigabyte

# Generated at 2022-06-22 06:45:26.614854
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('video.mp4')

# Generated at 2022-06-22 06:45:30.088746
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    fd = FileDownloader({})
    fd.to_screen = lambda text: text
    assert fd.report_destination("aaa") == "[download] Destination: aaa"


# Generated at 2022-06-22 06:45:39.749371
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    default_ydl_opts = {}
    ydl = YoutubeDL(default_ydl_opts)
    dl = FileDownloader(ydl, {})
    # test 1: when raise_fatal is false, raise an error
    for err in [KeyError("foo"), UnicodeError("bar"), IOError("baz"), UnavailableVideoError("qux", "http://www.youtube.com/watch?v=12345")]:
        # Since report_error does not return anything, I use assertRaises to test for exception throwing
        assertRaises(YoutubeDLError, dl.test_report_error, err, False)
    # test 2: when raise_fatal is true, raise an error

# Generated at 2022-06-22 06:45:44.607676
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    import sys
    import textwrap
    from io import StringIO
    from collections import namedtuple

    TestFileDownloader = namedtuple('TestFileDownloader',
                                    'params to_screen_expected')

# Generated at 2022-06-22 06:45:51.114784
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    """test_FileDownloader_trouble: raises error on trouble"""
    fd = FileDownloader('', {})
    thrown = False
    try:
        fd.trouble(u'error')
    except DownloadError as e:
        thrown = True
        msg = str(e)
        assert msg.startswith('error')
    assert thrown


# Generated at 2022-06-22 06:45:55.416789
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():  # pass
    from .YoutubeDL import YoutubeDL  # noqa
    from .extractor import gen_extractors

    gen_extractors()
    ydl = FileDownloader(YoutubeDL(), {'noprogress': True})
    ydl.report_resuming_byte(3)


# Generated at 2022-06-22 06:46:23.260533
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os

    # Create dummy file
    f = open("f.txt", "w")
    f.close()

    # Try to set the last-modified time of the given file to the date
    # of the file itself
    fd = FileDownloader({})
    assert fd.try_utime("f.txt", os.path.getmtime("f.txt")) == \
        os.path.getmtime("f.txt")

    # Try to set the last-modified time of the given file 2000 seconds
    # in the future
    now = time.time()
    later = now + 2000
    assert fd.try_utime("f.txt", later) == now

    # Remove dummy file
    os.remove("f.txt")

# Generated at 2022-06-22 06:46:25.566651
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    fd = FileDownloader({})
    fd.params['logger'] = DummyLogger()
    fd.report_warning('Test warning')


# Generated at 2022-06-22 06:46:31.802088
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    from .utils import FileDownloader

    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(5) == '0:05'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(90) == '1:30'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(4567) == '1:16:07'
    assert FileDownloader.format_seconds(5 * 3600 + 34 * 60 + 13) == '5:34:13'
    assert FileDownloader.format_seconds(3600 * 24 + 5 * 3600 + 34 * 60 + 13) == '1 day, 5:34:13'

# Generated at 2022-06-22 06:46:39.213986
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    # Test with all parameters
    fd_all_params = FileDownloader.FileDownloader({},False)
    fd_all_params.to_screen("test message",True)
    fd_all_params.to_screen("test message",True,False)
    # Test with parameters skipping
    fd_skip_params = FileDownloader.FileDownloader({},False)
    fd_skip_params.to_screen("test message")
    fd_skip_params.to_screen("test message",False)

# Generated at 2022-06-22 06:46:49.931307
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader("")
    assert fd.temp_name("file.name") == "file.name"
    assert fd.temp_name("file") == "file.part"
    assert fd.temp_name("") == ""
    assert fd.temp_name(None) is None
    assert fd.temp_name("file.name.part") == "file.name.part"
    assert fd.temp_name("file.name .part") == "file.name .part"
    assert fd.temp_name("file.name.part.txt") == "file.name.part.txt"
    assert fd.temp_name("file.name.part.txt.part") == "file.name.part.txt.part"

# Generated at 2022-06-22 06:46:54.591912
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    fd = FileDownloader()
    err = OSError('err')
    assert re.search(r'\[download\] Got server HTTP error: err. Retrying \(attempt 1 of inf\).', fd.report_retry(err, 1, float('inf')))

# Generated at 2022-06-22 06:47:05.036226
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    # Function must return a string
    assert isinstance(FileDownloader.format_percent(0), compat_str)
    assert isinstance(FileDownloader.format_percent(1), compat_str)
    assert isinstance(FileDownloader.format_percent(99), compat_str)
    assert isinstance(FileDownloader.format_percent(100), compat_str)
    assert isinstance(FileDownloader.format_percent(101), compat_str)

    # Function must return a four character long string
    assert len(FileDownloader.format_percent(0)) == 4
    assert len(FileDownloader.format_percent(1)) == 4
    assert len(FileDownloader.format_percent(99)) == 4
    assert len(FileDownloader.format_percent(100)) == 4

# Generated at 2022-06-22 06:47:17.313934
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    ydl = object()
    fd = FileDownloader(ydl, {})
    assert fd.ytdl_filename('a') == 'a.ytdl'
    assert fd.ytdl_filename('a.txt') == 'a.txt.ytdl'
    assert fd.ytdl_filename('.a') == '.a.ytdl'
    assert fd.ytdl_filename('a/b/c') == 'a/b/c.ytdl'
    assert fd.ytdl_filename('a/b/c.txt') == 'a/b/c.txt.ytdl'
    assert fd.ytdl_filename('a/b/c.txt.ytdl') == 'a/b/c.txt.ytdl'


# Generated at 2022-06-22 06:47:23.221974
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    #Test no retry
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(100) == '100'



# Generated at 2022-06-22 06:47:34.181005
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    dl = FileDownloader({}, None, None, None)
    assert dl.temp_name('/path/to/file') == '/path/to/file'
    assert dl.temp_name('-') == '-'
    assert dl.temp_name('file') == 'file'
    assert dl.temp_name('.file') == '.file'

    dl = FileDownloader({'nopart': True}, None, None, None)
    assert dl.temp_name('file') == 'file'
    assert dl.temp_name('/path/to/file') == '/path/to/file'
    assert dl.temp_name('-') == '-'
    assert dl.temp_name('.') == '.'
    assert dl.temp_name('.file') == '.file'



# Generated at 2022-06-22 06:48:14.331733
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    # Initialize the object
    fd = FileDownloader(params={})
    fd.to_screen(u'Pesho')
    fd.to_screen(u'Пешо')
    fd.to_screen(b'Pesho')
    fd.to_screen(b'\xd0\x9f\xd0\xb5\xd1\x88\xd0\xbe')



# Generated at 2022-06-22 06:48:17.278223
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assert calc_eta("", "", "") == 3

test_FileDownloader_calc_eta()



# Generated at 2022-06-22 06:48:26.665096
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    import sys
    import StringIO
    ydl = FakeYoutubeDl()
    params = {
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s',
    }
    fd = FileDownloader(ydl, params)
    fd.add_info_extractor('FakeIE', ['fake'])
    info = {
        'id': 'blabla',
        'ext': 'avi',
        'title': 'blabla',
        'url': 'http://fakeurl/blabla.avi',
        'extractor': 'FakeIE',
        'extractor_key': 'fake'
    }
    if sys.platform == 'win32':
        print('Running windows test')

# Generated at 2022-06-22 06:48:34.870054
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '0s'
    assert FileDownloader.format_eta(1) == '0s'
    assert FileDownloader.format_eta(60) == '1m 0s'
    assert FileDownloader.format_eta(65) == '1m 5s'
    assert FileDownloader.format_eta(3601) == '1h 0m 1s'
    assert FileDownloader.format_eta(3665) == '1h 1m 5s'



# Generated at 2022-06-22 06:48:38.457584
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # TODO: Add a better test when #27 is fixed
    obj = FileDownloader()
    obj.to_screen = lambda m: print(m)
    obj.report_file_already_downloaded('filename')

# Generated at 2022-06-22 06:48:50.621839
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    class FakeLogger:
        def __init__(self):
            self.messages = []

        def debug(self, msg):
            self.messages.append(msg)

    class FakeYoutubeDL:
        def __init__(self):
            self.params = {}
            self.to_screen_lock = threading.RLock()
            self.logger = FakeLogger()

    fake_ydl = FakeYoutubeDL()
    fd = FileDownloader(fake_ydl, {'outtmpl': 'blah'})

    # call with newline
    fd.to_screen('foo')
    fd.to_screen('bar')

    assert fake_ydl.logger.messages == ['[download] foo', '[download] bar']

    # call without newline

# Generated at 2022-06-22 06:48:56.947338
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    class DummyYoutubeDL(object):
        """Dummy YoutubeDL class for FileDownloader constructor unit test."""
        params = {'nooverwrites': True, 'continuedl': True, 'nopart': True}

    downloader = FileDownloader(DummyYoutubeDL())
    assert downloader.params == DummyYoutubeDL().params

if __name__ == '__main__':
    test_FileDownloader()

# Generated at 2022-06-22 06:49:08.529134
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():

    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.format_retries = FileDownloader.format_retries

    assert ydl.format_retries(float('inf')) == 'inf'
    assert ydl.format_retries(3) == '3'
    assert ydl.format_retries(1.5) == '2'
    assert ydl.format_retries(2.5) == '2'
    assert ydl.format_retries(3.5) == '3'
    assert ydl.format_retries(4.5) == '4'
    assert ydl.format_retries(5.5) == '5'
    assert ydl.format_retries(6.5) == '6'
    assert ydl.format_retries

# Generated at 2022-06-22 06:49:17.046206
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    test_cases = [
      ('', ''),
      ('-', '-'),
      ('foo', 'foo'),
      ('foo.part', 'foo'),
      ('foo.part-part', 'foo.part-part'),
      ('foo.part.part', 'foo'),
    ]
    for inp, out in test_cases:
        assert(FileDownloader.undo_temp_name(inp) == out)
    # test exception is not raised on non-string input
    FileDownloader.undo_temp_name(1)


# Generated at 2022-06-22 06:49:23.228015
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    progress_status = {'downloaded_bytes': 0, 'elapsed': 0, 'eta': 0, 'speed': 0, 'status': 'downloading', 'total_bytes': None, 'total_bytes_estimate': None}
    for i in range(10):
        progress_status['downloaded_bytes'] = i
        fd.report_progress(progress_status)
        time.sleep(0.2)