

# Generated at 2022-06-22 06:40:24.906178
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    # Create a fake FileDownloader instance
    fd = FileDownloader(None, None)

    # Call the method
    assert fd.ytdl_filename('foo') == 'foo.ytdl'



# Generated at 2022-06-22 06:40:27.509523
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    dler = FileDownloader({})
    result = dler.real_download('filename', 'info_dict')
    assert result is False
# End of unit test for method real_download


# Generated at 2022-06-22 06:40:39.136412
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    ret = FileDownloader.best_block_size(elapsed_time=0, bytes=0)
    assert ret == 1024*1024*4

    ret = FileDownloader.best_block_size(elapsed_time=0.001, bytes=1024*1024)
    assert ret == 1024*1024*4

    ret = FileDownloader.best_block_size(elapsed_time=0.999, bytes=1024*1024)
    assert ret == 1024*1024*4

    ret = FileDownloader.best_block_size(elapsed_time=1.0, bytes=1024*1024*2)
    assert ret == 1024*1024*4

    ret = FileDownloader.best_block_size(elapsed_time=10.0, bytes=1024*1024*2)
    assert ret == 1024*1024

    ret = FileDownloader

# Generated at 2022-06-22 06:40:51.707460
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    eta_str = fd.format_eta(fd.calc_eta(101, 100, 1, 11))
    assert eta_str == '0:00', 'Unexpected eta %s' % eta_str

    eta_str = fd.format_eta(fd.calc_eta(101, 0, 1, 11))
    assert eta_str == '0:00', 'Unexpected eta %s' % eta_str

    eta_str = fd.format_eta(fd.calc_eta(101, 1, 101, 11))
    assert eta_str == '0:00', 'Unexpected eta %s' % eta_str


# Generated at 2022-06-22 06:40:55.909496
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(0.0, 1024) == 1024
    assert FileDownloader.best_block_size(1.0, 512 * 1024) == 512 * 1024
    assert FileDownloader.best_block_size(0.5, 1024) == 2 * 1024



# Generated at 2022-06-22 06:41:00.875820
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    pass



# Generated at 2022-06-22 06:41:08.064417
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # Test for wrong number of arguments
    with pytest.raises(TypeError):
        FileDownloader.report_retry("command", "test", "test")
    # Test for no retries arg
    with pytest.raises(TypeError):
        FileDownloader.report_retry("command", "test", retries=1.2)
    # Test for None retries arg
    with pytest.raises(TypeError):
        FileDownloader.report_retry("command", "test", retries=None)
    # Test for wrong type of retries arg
    with pytest.raises(TypeError):
        FileDownloader.report_retry("command", "test", retries="test")
    # Test for correct args
    FileDownloader.report_retry("command", "test", retries=10)




# Generated at 2022-06-22 06:41:18.991463
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    # assert_raises does not support multiple exception types
    try:
        FileDownloader.calc_eta(0, 0, 0)
    except (AssertionError, ValueError):
        pass
    else:
        assert False

    assert_raises(AssertionError, FileDownloader.calc_eta, 1000, 0, 0)
    assert_raises(AssertionError, FileDownloader.calc_eta, 0, 1000, 0)
    assert_raises(AssertionError, FileDownloader.calc_eta, 0, 0, 1000)

    assert FileDownloader.calc_eta(1, 1, 1) == 1
    assert FileDownloader.calc_eta(0, 0, 0) is None


# Generated at 2022-06-22 06:41:26.819083
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # Define class for testing
    class TestFd(FileDownloader):
        def __init__(self, ydl, params):
            FileDownloader.__init__(self, ydl, params)
            self.testout = bytearray()

        def to_screen(self, message, skip_eol=False, check_quiet=False, **kwargs):
            self.testout.extend(message.encode('utf-8'))
            if not skip_eol:
                self.testout.extend(b'\n')

    # Create a FileDownloader object with a particular encoding

# Generated at 2022-06-22 06:41:38.165198
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    """Test for method report_retry of class FileDownloader"""

    # Constructor test
    inf_dl = FileDownloader()

    # Set of valid parameters
    inf_dl.report_retry(retries=float('inf'), count=1)
    # Set of valid parameters
    inf_dl.report_retry(retries=1, count=1)
    # Set of valid parameters
    inf_dl.report_retry(retries=0, count=1)
    # Set of valid parameters
    inf_dl.report_retry(retries=-1, count=1)
    # Set of valid parameters
    inf_dl.report_retry(retries=-1, count=1)


# Code for checking if a process is running and kill it if it is running

# Generated at 2022-06-22 06:42:03.041406
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    """Test FileDownloader trouble method"""
    filename = 'testoutput'
    ydl = YoutubeDL({'outtmpl': filename})
    fd = FileDownloader(
        ydl,
        {
            'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
            'id': 'BaW_jenozKc',
            'title': 'youtube-dl test video "\'/\\ä↭`"',
            'ext': 'mp4',
        },
        {
            'format': '22',
            'nooverwrites': True,
            'noprogress': True,
            'continuedl': True,
        })
    fd.report_error('Test')
    fd.trouble('Test')
    fd.report_destination('test')

# Generated at 2022-06-22 06:42:12.710537
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert '%10s' % ('%s/s' % format_bytes(0)) == FileDownloader.format_speed(0)
    assert '%10s' % ('%s/s' % format_bytes(1)) == FileDownloader.format_speed(1)
    assert '%10s' % ('%s/s' % format_bytes(1039)) == FileDownloader.format_speed(1039)
    assert '%10s' % ('%s/s' % format_bytes(1049)) == FileDownloader.format_speed(1049)
    assert '%10s' % ('%s/s' % format_bytes(1050)) == FileDownloader.format_speed(1050)
    assert '%10s' % ('%s/s' % format_bytes(5013)) == FileDownloader.format

# Generated at 2022-06-22 06:42:16.827572
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # Normal case
    f = FileDownloader()
    f.report_destination('hello.mp4')

    # Special case: Destination is '-'
    f = FileDownloader()
    f.report_destination('-')


# Generated at 2022-06-22 06:42:18.853236
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader()
    fd.to_stderr("Test")

# Generated at 2022-06-22 06:42:25.722340
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    ydl = YoutubeDL()
    ydl.params['ignoreerrors'] = False
    ydl.params['quiet'] = True
    ydl.to_screen = lambda x: None
    fd = FileDownloader(ydl, {'url': 'http://example.com/', 'filepath': '-'}, False)
    fd.report_error('error')
    fd.report_error('error', expected=True)
    fd.report_error('error', fatal=True)
    assert_equal(fd.ydl.return_code, 1)



# Generated at 2022-06-22 06:42:37.665008
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():

    ydl = YoutubeDL({'forcejson': True, 'nooverwrites': True, 'quiet': True})
    ydl.to_console_title = lambda s : print('to_console_title was called with s=%s' % s)
    ydl.process_info = lambda i: None
    try:
        ydl.download(['http://example.com/'])
    except DownloadError:
        pass

    if 'title' in os.environ:
        print('The title of the console has been changed to %s' % os.environ['title'])
        assert(os.environ['title'] == 'youtube-dl youtube-dl test title')

    # No assertions - we don't have access to sys.stdout in the test,
    # and we cannot mock sys.stdout to assert that the title was updated



# Generated at 2022-06-22 06:42:38.882406
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    f = FileDownloader()
    f.report_error('Foo bar is broken')

# Generated at 2022-06-22 06:42:46.839408
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def _fmt_secs(secs, expected_output):
        assert(FileDownloader.format_seconds(secs) == expected_output)

    _fmt_secs(0, '0:00')
    _fmt_secs(0.01, '0:00')
    _fmt_secs(1, '0:01')
    _fmt_secs(10, '0:10')
    _fmt_secs(59, '0:59')
    _fmt_secs(60, '1:00')
    _fmt_secs(61, '1:01')
    _fmt_secs(33900, '9:15')
    _fmt_secs(35999, '9:59')

# Generated at 2022-06-22 06:42:58.581605
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(60) == '00:01'
    assert FileDownloader.format_eta(61) == '00:01'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(7261) == '02:01:01'
    assert FileDownloader.format_eta(3601.95) == '01:00:02'
    assert FileDownloader.format_eta(86401.1) == '24:00:01'
    assert FileDownloader.format_eta(90123.45) == '25:02:03'


# Unit test

# Generated at 2022-06-22 06:43:09.078591
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """
    Makes use of FileDownloader.real_download() to download any file
    """
    if len(sys.argv) != 4:
        print("Usage: %s <url> <filename> <downloaded_file_size>" % sys.argv[0])
        sys.exit(1)

    url = sys.argv[1]
    filename = sys.argv[2]
    downloaded_file_size = int(sys.argv[3])
    print("Testing FileDownloader.real_download method with URL %s" % url)
    print("\t(downloaded_file_size = %d bytes)" % downloaded_file_size)
    print("\t(filename = %s)" % filename)
    fd = FileDownloader({"test": True}, {}, {}, {}, {}, {})
   

# Generated at 2022-06-22 06:43:27.520742
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    # Create a file downloader
    obj = FileDownloader('', {})
    # Assert that the method returns None
    assert obj.report_error() is None, 'The method report_error of class FileDownloader should return None'


# Generated at 2022-06-22 06:43:38.608332
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    downloader = FileDownloader(params)

    # test for zero values
    assert downloader.calc_percent(0,0) is None

    # test for one value equal zero
    assert downloader.calc_percent(1,0) is None
    assert downloader.calc_percent(0,1) is None

    # test for positive values
    assert downloader.calc_percent(0,50) == 0
    assert downloader.calc_percent(1,50) == 2
    assert downloader.calc_percent(25,50) == 50
    assert downloader.calc_percent(50,50) == 100
    assert downloader.calc_percent(75,50) == 150
    assert downloader.calc_percent(99,50) == 198

    # test for negative values

# Generated at 2022-06-22 06:43:44.384808
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    out, err = StringIO(), StringIO()
    # success
    fd = FileDownloader(out=out, err=err)
    fd.report_unable_to_resume()
    assert out.getvalue() == '[download] Unable to resume\n'
    out.truncate(0)
test_FileDownloader_report_unable_to_resume()


# Generated at 2022-06-22 06:43:57.250063
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.version import __version__
    from io import StringIO
    from sys import stderr

    out = StringIO()
    err = StringIO()
    ydl = YoutubeDL({'verbose': True, 'outtmpl': '%(id)s%(ext)s', 'noprogress':True})
    fd = FileDownloader(ydl, {'noprogress':True, 'outtmpl': '%(id)s%(ext)s'})

    # Test default format
    fd.report_error('ERROR', 'DEBUG MESSAGE')
    assert err.getvalue() == 'ERROR: DEBUG MESSAGE\n'

    # Test plain format
    ydl

# Generated at 2022-06-22 06:44:07.894631
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    test_cases = []

    # First, the cases from FileDownloader.calc_speed
    test_cases.append(
        {'current': 0, 'start': 0, 'now': 10, 'total': 0, 'expected': None})
    test_cases.append(
        {'current': 0, 'start': 0, 'now': 1, 'total': 0, 'expected': None})
    test_cases.append(
        {'current': 0, 'start': 0, 'now': 0.001, 'total': 0, 'expected': None})
    test_cases.append(
        {'current': 1, 'start': 0, 'now': 1, 'total': 1, 'expected': 1.0})

    # The other test cases

# Generated at 2022-06-22 06:44:17.522713
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # Test with a normal string
    fd = FileDownloader(None)
    assert fd.to_console_title('thisIsAString') is None
    # Test with a string containing an escaped char
    fd = FileDownloader(None)
    assert fd.to_console_title('Escaped\bChar') is None
    # Test with exception from encode error
    fd = FileDownloader(None)
    assert fd.to_console_title('StringWithUnicodeErroŔ') is None
    # Test with a unicode string containing an escaped char
    fd = FileDownloader(None)
    assert fd.to_console_title('UnicodeEscaped\bChar') is None


# Generated at 2022-06-22 06:44:18.271302
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """

    """
    pass



# Generated at 2022-06-22 06:44:30.602723
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Call function with valid arguments
    assert FileDownloader.calc_speed(1446860288.57, 1446860291.57, 100) == 33.333333333333326
    assert FileDownloader.calc_speed(1446284673.49, 1446284678.49, 1000) == 100.0
    assert FileDownloader.calc_speed(1444520462.84, 1444520464.84, 1000) == 500.0
    assert FileDownloader.calc_speed(1445285830.3, 1445285832.3, 10000) == 4000.0
    assert FileDownloader.calc_speed(1445353272.8, 1445353274.8, 10000) == 4000.0

# Generated at 2022-06-22 06:44:40.785366
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    class Dummy_FileDownloader(FileDownloader):
        def __init__(self, *args, **kargs):
            pass

        def to_screen(self, message):
            return message

    # Check destination filename of a single file
    d = Dummy_FileDownloader(params={})
    assert(d.report_destination('file.mp4') == '[download] Destination: file.mp4')

    # Check destination filename for a single file with a percent sign
    assert(d.report_destination('Z%C3%BCrich.ogg') == '[download] Destination: Z%C3%BCrich.ogg')

    # Check destination filename for a playlist
    assert(d.report_destination('file.mp4', playlist=True) == '[download] Destination: file.mp4')

    # Check destination filename for a playlist


# Generated at 2022-06-22 06:44:53.034621
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(datetime.timedelta(seconds=0), 0, 1000) == 1000
    assert fd.calc_eta(datetime.timedelta(seconds=1000), 0, 1000) == 1000
    assert fd.calc_eta(datetime.timedelta(seconds=0), 0, 0) == 0
    assert fd.calc_eta(datetime.timedelta(seconds=1000), 1000, 0) == 0
    assert fd.calc_eta(datetime.timedelta(seconds=1000), 1000, 1000) == 0
    assert fd.calc_eta(datetime.timedelta(seconds=1000), 100, 1000) == 900

# Generated at 2022-06-22 06:45:25.512517
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    pass
    

# Generated at 2022-06-22 06:45:30.805847
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '  0%'
    assert FileDownloader.format_percent(0.01) == '  1%'
    assert FileDownloader.format_percent(0.995) == ' 99%'
    assert FileDownloader.format_percent(1.0) == '100%'



# Generated at 2022-06-22 06:45:40.178041
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(params = {'cachedir': False}, ydl = False)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_resuming_byte('10') == 'Resuming download at byte 10'
    assert fd.report_resuming_byte('0') == 'Resuming download at byte 0'
    with pytest.raises(TypeError):
        fd.report_resuming_byte(10)
    with pytest.raises(TypeError):
        fd.report_resuming_byte(-10)
    with pytest.raises(TypeError):
        fd.report_resuming_byte(None)
    with pytest.raises(TypeError):
        fd.report_resuming_byte('a')

# Generated at 2022-06-22 06:45:45.097098
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    temp_filename = os.path.join(tempfile.gettempdir(), 'youtube-dl-test-utime')
    fd = open(encodeFilename(temp_filename), 'wb')
    fd.write(b'hello')
    fd.close()
    fd = None

    fd = FileDownloader({'outtmpl': temp_filename})
    fd._total_downloaded = 5
    assert fd.try_utime(temp_filename, '@0') is None

    fd._total_downloaded = 0
    assert fd.try_utime(temp_filename, '@0') is not None
    assert fd.try_utime(temp_filename, '1970-01-01 00:00:00') is not None

# Generated at 2022-06-22 06:45:57.822527
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Tests if FileDownloader.slow_down() works properly
    assert FileDownloader.slow_down(0, 0, 0, 0) == time.time() + 0.5
    assert FileDownloader.slow_down(0, 0, 0, 1) == time.time() + 0.5
    assert FileDownloader.slow_down(0, 0, 1, 0) == time.time() + 0.5
    assert FileDownloader.slow_down(0, 0, 1, 1) == time.time() + 1.0
    assert FileDownloader.slow_down(0, 0.1, 1, 1) == time.time() + 0.4
    assert FileDownloader.slow_down(0, 1, 0, 0) == time.time() + 0.5

# Generated at 2022-06-22 06:46:06.490959
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import sys
    import tempfile
    import shutil
    from .compat import byte_str
    from .utils import prepend_extension
    from .extractor import get_info_extractor
    from .YoutubeDL import YoutubeDL

    ratelimit = 1024

    class FileLike(object):
        def __init__(self):
            self.start = time.time()
            self.time = self.start
            self.bytes = 0
            self.limit = 10
            self.buf = b''

        def write(self, s):
            now = time.time()
            if self.bytes >= self.limit:
                # Buffer full
                return
            self.buf += s
            self.bytes = len(self.buf)
            self.time = now

# Generated at 2022-06-22 06:46:10.736001
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(YoutubeDL({}), {'elapsed_time': 4, 'elapsed_bytes': 1024 * 100}, None)
    assert fd.best_block_size(4, 1024 * 100) == 1024 * 32
    assert fd.best_block_size(4, 1024 * 10) == 1024 * 1


# Generated at 2022-06-22 06:46:22.893412
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from unittest.mock import patch

    ydl = YoutubeDL({})
    downloader = HttpFD(ydl, {}, {})

    # Standard test
    filename = 'test.mp4'
    downloader.report_file_already_downloaded(filename)
    assert ydl._screen_file_num == 1
    assert ydl._screen_file_list[0][1] == 'The file has already been downloaded'

    # Unicode test
    filename = '测试.mp4'
    downloader.report_file_already_downloaded(filename)
    assert ydl._screen_file_num == 2

# Generated at 2022-06-22 06:46:30.140994
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import tempfile

    def t(str, result):
        # Mock time.time()
        time_counter = [1200000000]
        def time_fx():
            time_counter[0] += 1
            return time_counter[0]
        time.time = time_fx

        # Create mock file
        tf = tempfile.NamedTemporaryFile()
        tf.write(b'x' * 100)
        tf.flush()

        # Run method
        fd = FileDownloader({}, FakeYDL())
        fd.to_screen = lambda *x: x
        fd.report_error = lambda *x: x
        assert result == fd.try_utime(tf.name, str)

        # Restore time
        time.time = time.time

        # Remove mock file
        tf.close

# Generated at 2022-06-22 06:46:38.465288
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    half = FileDownloader.format_percent(0.5)
    assert half == '50%'
    quarter = FileDownloader.format_percent(0.25)
    assert quarter == '25%'
    round_half = FileDownloader.format_percent(0.5555)
    assert round_half == '55%'
    round_quarter = FileDownloader.format_percent(0.5655)
    assert round_quarter == '57%'
    round_quarter_5 = FileDownloader.format_percent(0.555555)
    assert round_quarter_5 == '56%'

# Generated at 2022-06-22 06:48:00.091348
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class TestFileDownloader(FileDownloader):
        def __init__(self, ydl, filename, info_dict):
            FileDownloader.__init__(self, ydl, filename, info_dict)
            self.screen_outputs = []
        def to_screen(self, msg):
            self.screen_outputs.append(msg)
    test_filename = 'abcdefg'
    test_info_dict = {'title': 'hello'}
    test_ydl = object()
    # Test when file doesn't exist
    fd = TestFileDownloader(test_ydl, test_filename, test_info_dict)
    fd.report_file_already_downloaded(test_filename)
    assert len(fd.screen_outputs) == 0
    # Test when file exists

# Generated at 2022-06-22 06:48:11.871449
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    fd = FileDownloader(params={})
    print(
        'Testing calc_percent(total=1000, downloaded=150)...\nExpected result: 15.0\nReal result:  %s'
        % fd.calc_percent(total=1000, downloaded=150)
    )
    print(
        'Testing calc_percent(total=150, downloaded=150)...\nExpected result: 100.0\nReal result:  %s'
        % fd.calc_percent(total=150, downloaded=150)
    )
    print(
        'Testing calc_percent(total=-1, downloaded=0)...\nExpected result: None\nReal result:  %s'
        % fd.calc_percent(total=-1, downloaded=0)
    )

# Generated at 2022-06-22 06:48:23.724182
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    #checking the output of report_retry method
    ydl_opts = {'logger': MockLogger(), 'verbose': True}
    video_url = "http://www.youtube.com/watch?v=GQdRhK9Yvkc"
    url_data = {
        'id': 'GQdRhK9Yvkc',
        'url': video_url,
        'title': 'Video for Unit testing',
        'description': 'description for Unit testing',
        'duration': 123.4567,
    }
    fd = FileDownloader(ydl_opts,url_data )
    err = HTTPError('http://www.youtube.com/watch?v=GQdRhK9Yvkc', 500, 'test error message', None, None)
    count = 1
   

# Generated at 2022-06-22 06:48:27.302673
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    downloader = FileDownloader({})
    downloader.to_screen = lambda x: x
    downloader.report_retry(2, 3, 4)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 06:48:32.583046
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('-') == '-'
    assert fd.temp_name('file') == 'file.part'
    assert fd.temp_name('file.part') == 'file.part'



# Generated at 2022-06-22 06:48:41.847417
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(121) == '02:01'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(3661) == '01:01:01'
    assert FileDownloader.format_eta(None) == '--:--'



# Generated at 2022-06-22 06:48:50.268216
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None)
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 1000, 1000) is None
    assert fd.calc_eta(0, 1000, 0) is None
    assert fd.calc_eta(1000, 0, 1000) is None
    assert fd.calc_eta(1000, 2000, 1000) is None
    assert fd.calc_eta(1000, 2000, 0) is None

# Generated at 2022-06-22 06:48:59.374828
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    f = FileDownloader(params={})
    assert f.format_percent(1) == '  1%'
    assert f.format_percent(9) == '  9%'
    assert f.format_percent(10) == ' 10%'
    assert f.format_percent(99) == ' 99%'
    assert f.format_percent(99.9) == ' 99%'
    assert f.format_percent(100) == '100%'
    assert f.format_percent(1000) == '***%'
    assert f.format_percent(-1) == '***%'
    assert f.format_percent(None) == '***%'


# Generated at 2022-06-22 06:49:10.632412
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from io import BytesIO

    class TmpFileDownloader(FileDownloader):
        def __init__(self, params, filename, info_dict):
            FileDownloader.__init__(self, params, filename, info_dict)
            self._params = params

        def real_download(self, filename, info_dict):
            pass

    # Test normal case
    tmp_fd = TmpFileDownloader('test', '/tmp/does_not_exist', None)
    test_filename = u'\u0420\u0443\u0441\u0441\u043a\u0438\u0439.txt'
    f = BytesIO()
    f.name = test_filename
    f.write(b'blah')
    f.seek(0)


# Generated at 2022-06-22 06:49:21.181485
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():

    def test(resume_len):
        fd = FileDownloader({}, {})

        class OutStream:
            def __init__(self):
                self.out = ''

            def write(self, s):
                self.out += s

            def close(self):
                pass

        fd.to_screen = lambda *args, **kwargs: None
        fd.to_screen = OutStream()
        fd.report_resuming_byte(resume_len)
        assert fd.to_screen.out == '[download] Resuming download at byte %s\n' % resume_len

    test(1)
    test(100)


# Unit tests for method format_seconds of class FileDownloader