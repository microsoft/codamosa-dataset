

# Generated at 2022-06-22 06:40:10.455229
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    file_downloader = FileDownloader(
        youtube_dl=FakeYoutubeDL(),
        params=dict(),
        info_dict=dict(_type='url', url="http://example.com"),
        filename="file.mp4")
    assert file_downloader.ytdl_filename("file.mp4") == "file.mp4.ytdl"

# Generated at 2022-06-22 06:40:23.426759
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00:00'
    assert FileDownloader.format_seconds(0.3) == '0:00:00'
    assert FileDownloader.format_seconds(1) == '0:00:01'
    assert FileDownloader.format_seconds(1.1) == '0:00:01'
    assert FileDownloader.format_seconds(59) == '0:00:59'
    assert FileDownloader.format_seconds(59.9) == '0:00:59'
    assert FileDownloader.format_seconds(60) == '0:01:00'
    assert FileDownloader.format_seconds(119.5) == '0:01:59'
    assert FileDownloader.format_seconds(3600 - 1) == '0:59:59'

# Generated at 2022-06-22 06:40:33.913344
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader(None, None)

    assert fd.format_speed(0) == "   0.00b/s"
    assert fd.format_speed(100) == " 100.00b/s"
    assert fd.format_speed(1000) == "   1.00Kb/s"
    assert fd.format_speed(1024) == "   1.00Kb/s"
    assert fd.format_speed(1025) == "   1.00Kb/s"
    assert fd.format_speed(1024**2) == "   1.00Mb/s"
    assert fd.format_speed(1024**3) == "   1.00Gb/s"
    assert fd.format_speed(1024**4) == "   1.00Tb/s"

# Generated at 2022-06-22 06:40:39.639485
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.part') == 'foo.part'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'


# Generated at 2022-06-22 06:40:52.036777
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader({})

# Generated at 2022-06-22 06:41:02.017483
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def _mock_utime(fn, times):
        """Utility function mocking os.utime."""
        if not hasattr(_mock_utime, "utime_called"):
            setattr(_mock_utime, "utime_called", dict())
        _mock_utime.utime_called[fn] = times

    patcher = patch("os.utime", side_effect=_mock_utime)

    with patcher, patch("os.path.exists", return_value = True), \
            patch("os.path.isfile", return_value = True):
        fd = FileDownloader(FileDownloaderParams())
        last_modified_hdr = "Fri, 09 Aug 2013 23:54:35 GMT"

# Generated at 2022-06-22 06:41:05.131308
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader(None, None)
    assert fd.ytdl_filename('dummy.part') == 'dummy.part.ytdl'
    assert fd.ytdl_filename('dummy.txt') == 'dummy.txt.ytdl'


# Generated at 2022-06-22 06:41:08.483759
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    FileDownloader.format_retries(2.4) == '2'
# Full unit test for FileDownloader on HTTP download
# Uses external resources (web server)

# Generated at 2022-06-22 06:41:16.195579
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    d = FileDownloader(params={'logger': FakeLogger()})
    assert d.calc_percent(100, 100) == 100
    assert 0 <= d.calc_percent(50, 100) <= 100
    assert 0 <= d.calc_percent(0, 100) <= 100
    assert d.calc_percent(101, 100) is None
    assert d.calc_percent(-1, 100) is None
    assert 0 <= d.calc_percent(50, -1) <= 100


# Generated at 2022-06-22 06:41:20.979420
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = youtube_dl.downloader.FileDownloader({}, youtube_dl.YoutubeDL({}))
    fd.to_screen = lambda msg: None
    fd.report_file_already_downloaded('foo')

# Unit tests for method format_bytes of class FileDownloader

# Generated at 2022-06-22 06:41:48.389659
# Unit test for constructor of class FileDownloader

# Generated at 2022-06-22 06:42:01.772834
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    assert FileDownloader.ytdl_filename('test') == 'test.ytdl','testFile'
    assert FileDownloader.ytdl_filename('.test') == '.test.ytdl','testFile'
    assert FileDownloader.ytdl_filename('.') == '.ytdl','testFile'
    assert FileDownloader.ytdl_filename('..') == '..ytdl','testFile'
    assert FileDownloader.ytdl_filename('/') == '.ytdl','testFile'
    assert FileDownloader.ytdl_filename('..test') == '..test.ytdl','testFile'
    assert FileDownloader.ytdl_filename('test..') == 'test..ytdl','testFile'

# Generated at 2022-06-22 06:42:13.869152
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assertEquals(FileDownloader.calc_eta(None, 1000, 0), None)
    assertEquals(
        FileDownloader.calc_eta(time.time(), 1000, 0), None)
    assertEquals(
        FileDownloader.calc_eta(time.time(), 1000, 1000), None)
    assertEquals(
        FileDownloader.calc_eta(time.time(), 1000, 500), None)
    assertEquals(
        FileDownloader.calc_eta(time.time(), 1000, 1500), None)
    assertEquals(
        FileDownloader.calc_eta(time.time() - 500, 1000, 0), None)
    assertEquals(FileDownloader.calc_eta(time.time() - 500, 1000, 100), 400)

# Generated at 2022-06-22 06:42:18.705348
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    class _fd(FileDownloader):
        def real_download(self, filename, info_dict):
            pass
    fd = _fd(None, None)
    assert fd.ytdl_filename("filename") == "filename.ytdl"

# Generated at 2022-06-22 06:42:28.379629
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader()
    fd.params['ratelimit'] = 1000000 # bytes/second
    fd.to_screen = lambda *x: None
    fd.to_console_title = lambda *x: None

    def test(expected_sleep_time, start, now, bytes):
        if now is None:
            now = start
        sleeptime = fd.slow_down(start, now, bytes)
        if sleeptime != expected_sleep_time:
            raise Exception('Expected sleep time %f, got %f' % (expected_sleep_time, sleeptime))
        print('Test OK: expected sleep time %f, got %f' % (expected_sleep_time, sleeptime))

    # Just verifying that when ratelimit isn't set, slow_down
    # returns None, so we don't

# Generated at 2022-06-22 06:42:35.985120
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    import sys
    import tempfile
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO
    ydl = YoutubeDL({
        'outtmpl': '%(id)s%(ext)s',
        'forcefilename': True,
        'verbose': True,
        'simulate': True,
        'ratelimit': 176400,
        'progress_with_newline': True,
        'test': True,
        'logger': YoutubeDlLogger(),
    })

    def _make_fd(**fd_kwargs):
        return FileDownloader(ydl, **fd_kwargs)

    # test methods of FileDownloader
    fd = _make_fd(params={})

# Generated at 2022-06-22 06:42:46.249876
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    if not verbose_tests:
        return True

    # Test for report_resuming_byte()
    _args = {}
    _args['ydl'].verbose = 1
    _args['ydl'].forceurl = 1
    _args['ydl'].nooverwrites = 1
    _args['ydl'].troubleshoot = 1
    _args['ydl'].continue_dl = 1

    _args['url'] = ''
    _args['outtmpl'] = '%(stitle)s-%(id)s.%(ext)s'
    _args['playlist'] = 'test'

    _args['ydl'].params = ['--verbose', '--force-url', '--nooverwrites', '--troubleshoot', '--continue']

    import youtube

# Generated at 2022-06-22 06:42:58.334073
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader(None, None)
    assert fd.format_seconds(0) == '0:00'
    assert fd.format_seconds(1) == '0:01'
    assert fd.format_seconds(59) == '0:59'
    assert fd.format_seconds(60) == '1:00'
    assert fd.format_seconds(61) == '1:01'
    assert fd.format_seconds(3599) == '59:59'
    assert fd.format_seconds(3600) == '1:00:00'
    assert fd.format_seconds(3601) == '1:00:01'
    assert fd.format_seconds(3661) == '1:01:01'

# Generated at 2022-06-22 06:43:05.990555
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import threading
    import time
    class MyFD(FileDownloader):
        def __init__(self):
            self.ydl = object()
            self.params = {'sleep_interval': 0, 'max_sleep_interval': 0}
            self._num_sleeps = 0
            self._lock = threading.Lock()

        @synchronized(Lock('num_sleeps'))
        def num_sleeps(self):
            return self._num_sleeps

        @synchronized(Lock('lock'))
        def slow_down(self, *args, **kargs):
            self._num_sleeps += 1
            return super(MyFD, self).slow_down(*args, **kargs)

    fd = MyFD()
    assert fd.num_sleeps() == 0

    # Test

# Generated at 2022-06-22 06:43:13.802213
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0.01) == '0:00:01'
    assert FileDownloader.format_seconds(0.1) == '0:00:01'
    assert FileDownloader.format_seconds(1) == '0:01:00'
    assert FileDownloader.format_seconds(60) == '1:00:00'
    assert FileDownloader.format_seconds(90) == '1:30:00'
    assert FileDownloader.format_seconds(3000) == '1:23:20'
    assert FileDownloader.format_seconds(3600) == '1:00:00'


# Generated at 2022-06-22 06:43:29.634297
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    f = FileDownloader({})
    assert f.undo_temp_name('abc.def.part') == 'abc.def'
    assert f.undo_temp_name('abc.part') == 'abc'
    assert f.undo_temp_name('.part') == ''
    assert f.undo_temp_name('abc.déf.part') == 'abc.déf'
    assert f.undo_temp_name('abc.def.part.part') == 'abc.def.part'
    assert f.undo_temp_name('abc.def.part.obiwan') == 'abc.def.part.obiwan'


# Generated at 2022-06-22 06:43:33.615879
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    class TestFD(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
    
    fd = TestFD({})
    assert fd.calc_speed(0.0, 10.0, 1024) == 1024.0 / 10.0
    assert fd.calc_speed(0.0, 0.0, 1024) is None
    assert fd.calc_speed(0.0, 10.0, 0) is None


# Generated at 2022-06-22 06:43:46.554696
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    class FakeYDL(object):
        class params(object):
            pass

        def to_screen(self, *args, **kargs):
            pass

        def to_console_title(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

    # Toy class to test inheritance of FileDownloader
    class TestFD(FileDownloader):
        def real_download(self, filename, info_dict):
            pass

    fd = TestFD(FakeYDL(), {})
    assert fd.params is fd.ydl.params



# Generated at 2022-06-22 06:43:57.625697
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test that the speed is controlled by ratelimit param
    params = {
        'ratelimit': 10,
        'noprogress': True,
    }
    fd = FileDownloader(params)
    fd._start_time = time.time()
    start_time = fd._start_time
    for i in range(100):
        fd.slow_down(fd._start_time, time.time(), 10)
        assert (fd._start_time == start_time)
        time.sleep(0.01)

    # Test that the speed is controlled by max_rate_limit param
    params = {
        'ratelimit': 10,
        'max_rate_limit': 1,
        'noprogress': True,
    }
    fd = FileDownloader(params)
    fd._start_

# Generated at 2022-06-22 06:44:08.183729
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    import sys
    if sys.version_info < (2, 7):
        return

    class FakeDownloader:
        params = {'noprogress': False}

    def assert_format_percent(num, expected):
        fd = FakeDownloader()
        assert fd.format_percent(num) == expected

    assert_format_percent(0.0, '0.0%')
    assert_format_percent(0.1, '0.1%')
    assert_format_percent(0.12, '0.1%')
    assert_format_percent(0.123, '0.1%')
    assert_format_percent(0.1234, '0.1%')
    assert_format_percent(0.12345, '0.1%')

# Generated at 2022-06-22 06:44:18.041609
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    # Arguments
    testargs = ['testprog', '--verbose', '--quiet']
    for t in ['http://www.youtube.com/watch?v=BaW_jenozKc',
              'http://youtu.be/BaW_jenozKc']:
        testargs.append(t)
    # Create FileDownloader
    fd = FileDownloader(testargs)
    assert fd.params['format'] is None
    assert fd.params['verbose'] is True
    assert fd.params['quiet'] is True
    assert fd.params['outtmpl'] == (
        '%(title)s-%(id)s-%(format)s.%(ext)s')
    assert fd.params['ignoreerrors'] is False
    assert fd.params['ratelimit'] is None

# Generated at 2022-06-22 06:44:23.005072
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    from .PostProcessor import PostProcessor
    from .YoutubeDL import YoutubeDL

    dl = YoutubeDL()
    postprocessor = PostProcessor(dl, 'videofilename')

    # Make a temporary filename to write to
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)

    downloader = FileDownloader({}, {}, dl, filename, {'id': '1234'})

    # If a downloader has no try_utime method, PostProcessor should fall
    # back on using utime()
    postprocessor._downloader = Downloader({}, {}, dl, filename, {'id': '1234'})
    postprocessor._downloader.try_utime = None

# Generated at 2022-06-22 06:44:34.820958
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def test(s):
        ydl = FakeYoutubeDl()
        fd = FileDownloader(ydl, {'nopart':False})
        output = fd.temp_name(s)
        print('{:>30} -> {!r}'.format(s, output))

    test('foo')
    test('foo.part')
    test('foo.bar')
    test('foo.bar.part')
    test('foo.bar.baz')
    test('foo.bar.baz.part')
    test('-')

    ydl = FakeYoutubeDl()
    fd = FileDownloader(ydl, {'nopart':True})
    assert fd.temp_name('foo') == 'foo'

# Generated at 2022-06-22 06:44:45.556411
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    import sys
    import six
    # init downloader
    fd = FileDownloader(default_params=None, params={'verbose': True},
                        to_screen=lambda *_, **__: None)
    fd.to_stderr = lambda *_, **__: None

    # init test
    retry_count = 5
    retries = 100
    for i in six.moves.range(0, retry_count):
        count = retries - (i + 1)
        # print the retry message
        fd.report_retry(
            None, count, retries)
        # get the output
        out = sys.stdout.getvalue()
        # print the current expected retry message

# Generated at 2022-06-22 06:44:48.447331
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    a = FileDownloader(params=None)
    for x in range(0, 100):
        a.to_screen('[download] Download completed')


# Generated at 2022-06-22 06:45:01.581384
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    downloader = FileDownloader(params=None, ydl=None)
    s = 'Test string'
    downloader.to_stderr(s)
    if platform.system() == 'Windows':
        assert sys.stderr.getvalue() == s + '\n'
    else:
        assert sys.stderr.getvalue() == s + '\n'


# Generated at 2022-06-22 06:45:12.492142
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    import unittest
    # check for valid percentage calculation
    class TestCalculatePercentage(unittest.TestCase):
        def runTest(self):
            fdl = FileDownloader(YoutubeDL(), {})
            self.assertEqual(fdl.calc_percent(100, 0), 0)
            self.assertEqual(fdl.calc_percent(4000, 1000), 25)
            self.assertEqual(fdl.calc_percent(4000, 10000), 0)
    # check for valid percentage calculation with invalid input
    class TestCalculatePercentageWithErr(unittest.TestCase):
        def runTest(self):
            fdl = FileDownloader(YoutubeDL(), {})
            self.assertEqual(fdl.calc_percent(0, 0), 0)

# Generated at 2022-06-22 06:45:16.319281
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd = FileDownloader(values={}, params={}, info_dict={})
    fd.to_screen = lambda x: x
    new_str = fd.report_unable_to_resume()
    assert(new_str == '[download] Unable to resume')

# Generated at 2022-06-22 06:45:26.668561
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.calc_eta(0, 1, 100) is None
    assert fd.calc_eta(0, 0, 100) is None
    assert fd.calc_eta(0, 100, 100) == 0
    assert fd.calc_eta(0, 200, 100) == -1
    assert fd.calc_eta(1, 100, 200) == 1
    assert fd.calc_eta(1, 100, 100) == 0
    assert fd.calc_eta(1, 200, 100) == 0
    assert fd.calc_eta(3, 400, 200) == 3



# Generated at 2022-06-22 06:45:29.225058
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    fd = FileDownloader(None, None)
    assert fd.to_console_title('test') is None


# Generated at 2022-06-22 06:45:39.333920
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print('Testing FileDownloader.report_progress')

    import tempfile
    import shutil
    import os
    import time

    tmpdir = tempfile.mkdtemp()

    def _test(speed, elapsed, eta, total_bytes, total_bytes_estimate, downloaded_bytes=None):
        s = {
            'status': 'downloading',
            'speed': speed,
            'eta': eta,
            'elapsed': elapsed,
            'total_bytes': total_bytes,
            'total_bytes_estimate': total_bytes_estimate,
        }

        if downloaded_bytes is None:
            downloaded_bytes = total_bytes

        s['downloaded_bytes'] = downloaded_bytes


# Generated at 2022-06-22 06:45:45.773548
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # No setup required
    # Test normal speed
    fd = FileDownloader({'ratelimit': 8192})
    start_time = 0.5
    now = 5.0
    bytes = 4096

    fd.slow_down(start_time, now, bytes)
    # Test to slow down
    fd.slow_down(start_time, now, bytes * 2)
    # Test to high speed
    fd.slow_down(start_time, now, bytes / 4)



# Generated at 2022-06-22 06:45:54.741352
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.mp4') == 'foo.mp4'
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.mp4') == 'foo.mp4'
    assert FileDownloader.undo_temp_name('foo.part.mp4.part') == 'foo.mp4'


# Generated at 2022-06-22 06:46:00.829844
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    to_screen_list = []
    to_screen_local = to_screen_list.append

    fd = FileDownloader({'noprogress': True}, None)
    fd.to_screen = to_screen_local
    fd.report_unable_to_resume()
    assert len(to_screen_list) == 1
    assert to_screen_list[0] == '[download] Unable to resume'


# Generated at 2022-06-22 06:46:10.485948
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(600) == '10:00'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3610) == '1:00:10'

# Generated at 2022-06-22 06:46:26.958325
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def FileDownloaderTest_real_download(self, filename, info_dict):
            return True
    FileDownloader.real_download = FileDownloaderTest_real_download
    
    def FileDownloaderTest_report_progress(self, s):
            pass
    FileDownloader.report_progress = FileDownloaderTest_report_progress
    
    def FileDownloaderTest_report_file_already_downloaded(self, filename):
        pass
    FileDownloader.report_file_already_downloaded = FileDownloaderTest_report_file_already_downloaded
    
    assert FileDownloader(YoutubeDL()).download('a', {}) == True

# Generated at 2022-06-22 06:46:38.244732
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    # Path is not exist
    assert FileDownloader.try_rename('abc', 'def') is None
    # Path is file
    with open('abc', 'w') as f:
        f.write('111')
    os.path.isfile('abc')
    FileDownloader.try_rename('abc', 'def')
    assert os.path.isfile('def')
    # Path is folder
    os.mkdir('folder')
    os.path.isdir('folder')
    FileDownloader.try_rename('folder', 'new_folder')
    assert os.path.isdir('new_folder')
    # Try to rename the same name
    FileDownloader.try_rename('folder', 'new_folder')
    assert os.path.isdir('new_folder')
    # Delete folder, file and new

# Generated at 2022-06-22 06:46:49.222917
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def check(rate_limit, downloaded_bytes, elapsed_time, expected_sleep_time):
        print('checking rate limit: %s, downloaded_bytes: %s, elapsed_time: %s' % (rate_limit, downloaded_bytes, elapsed_time))
        fd = FileDownloader({'ratelimit': rate_limit}, None)
        start_time = time.time() - elapsed_time
        fd.slow_down(start_time, None, downloaded_bytes)
        actual_sleep_time = time.time() - (start_time + elapsed_time)
        print('actual sleep time: %s' % actual_sleep_time)
        assert within_threshold(actual_sleep_time, expected_sleep_time, 2)

    check(4, 2, 1, 0)
    check(4, 2, 5, 2)

# Generated at 2022-06-22 06:46:55.388035
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    print('Testing method download of class FileDownloader', file=sys.stderr)
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['youtube_print_sig_code'] = True
    fd = FileDownloader(ydl, {}, {'id': 'Test video'}, '_')
    fd.download('-', {})


# Generated at 2022-06-22 06:47:06.130631
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert '%10s' % ('%s/s' % format_bytes(100)) == FileDownloader.format_speed(100)
    assert '%10s' % ('%s/s' % format_bytes(1000)) == FileDownloader.format_speed(1000)
    assert '%10s' % ('%s/s' % format_bytes(1024)) == FileDownloader.format_speed(1024)
    assert '%10s' % ('%s/s' % format_bytes(1048576)) == FileDownloader.format_speed(1048576)
    assert '%10s' % ('%s/s' % format_bytes(1073741824)) == FileDownloader.format_speed(1073741824)

# Generated at 2022-06-22 06:47:15.256536
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def _test(eta, ret):
        assert FileDownloader.format_eta(eta) == ret
    _test(None, '--:--')
    _test(0, '00:00')
    _test(1, '00:01')
    _test(60, '01:00')
    _test(65, '01:05')
    _test(3600, '1:00:00')
    _test(3665, '1:01:05')
    _test(3666, '1:01:06')
    _test(86665, '24:01:05')



# Generated at 2022-06-22 06:47:21.220409
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    from FileDownloader import FileDownloader

    fd = FileDownloader({})
    fd.to_screen('to_screen')
    fd.report_unable_to_resume()


if __name__ == '__main__':
    test_FileDownloader_report_unable_to_resume()

# Generated at 2022-06-22 06:47:33.245947
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def calc_eta_test(speed, total, current, start, now, expected_eta):
        class FakeFileDownloader:
            params = {'noprogress': True}
            def format_eta(self, seconds):
                return 'ETAdummy %s' % seconds
            def report_progress(self, s):
                pass
            def to_screen(self, *args, **kargs):
                pass

        fd = FakeFileDownloader()
        eta = fd.calc_eta(speed, total, current, start, now)
        assert eta == expected_eta, 'expected ETA: %s, got %s (speed=%s, total=%s, current=%s, start=%s, now=%s)' % (expected_eta, eta, speed, total, current, start, now)



# Generated at 2022-06-22 06:47:45.399008
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    ydl=YoutubeDL()

# Generated at 2022-06-22 06:47:46.538843
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
        assert(1)


# Generated at 2022-06-22 06:48:17.762589
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    assert FileDownloader.calc_percent(1, 100, 1) is None
    assert FileDownloader.calc_percent(0, 100, 0) is None
    assert FileDownloader.calc_percent(0, 100, 2) == 1
    assert FileDownloader.calc_percent(0, 100, 100) == 100
    assert FileDownloader.calc_percent(0, 100, 50) == 50
    #
    assert FileDownloader.calc_percent(2, 100, 1) == 50
    assert FileDownloader.calc_percent(0, 100, 1) == 1
    assert FileDownloader.calc_percent(2, 100, 50) == 75
    #
    assert FileDownloader.calc_percent(2, 100, -1) is None

# Generated at 2022-06-22 06:48:28.040909
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    # Test for string
    test_stderr_string = '[youtube] Setting language'
    assert_equals(FileDownloader.to_stderr(test_stderr_string), test_stderr_string)
    assert_equals(FileDownloader.to_stderr(test_stderr_string), test_stderr_string)
    assert_equals(FileDownloader.to_stderr(test_stderr_string), test_stderr_string)
    # Test for bytes
    test_stderr_bts1 = b"[youtube] Setting language"
    test_stderr_bts2 = b"\x8A[youtube] Setting language"

# Generated at 2022-06-22 06:48:36.382102
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None)
    assert fd.undo_temp_name('/tmp/abcd.part') == '/tmp/abcd'
    assert fd.undo_temp_name('/tmp/abcd') == '/tmp/abcd'
    assert fd.undo_temp_name('/tmp/abcd.part.part') == '/tmp/abcd.part'
    assert fd.undo_temp_name('/tmp/abcd.part.part.part') == '/tmp/abcd.part.part'


# Generated at 2022-06-22 06:48:43.832969
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # convert_seconds is tested in test_convert_seconds
    try_sleep = lambda : None

    def func(**s):
        if len(s) == 1 and 'status' in s:
            status = s['status']
            if status == 'finished':
                return
            else:
                raise AssertionError('bad status: %r' % status)
        if 'eta' in s:
            eta = s['eta']
            if eta == 'Unknown ETA':
                return
            if isinstance(eta, int):
                if eta >= 0:
                    return
                raise AssertionError('bad eta: %r' % eta)
            raise AssertionError('bad eta: %r' % eta)
        if 'elapsed' in s:
            elapsed = s['elapsed']
           

# Generated at 2022-06-22 06:48:52.644336
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import CookieJar
    from youtube_dl.utils import DownloadError
    from http.cookiejar import Cookie
    from http.cookiejar import CookiePolicy
    from http.cookies import SimpleCookie
    ydl = YoutubeDL()
    ydl.cookies = CookieJar()
    ydl.debug = True
    # Add a dummy cookie to show it will be output in case of verbose

# Generated at 2022-06-22 06:48:57.244953
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    files = os.listdir()

    fd = FileDownloader(FileDownloaderParams())
    fd.report_retry(Exception(), 1, 2)
    fd.report_retry(Exception(), 2, 2)
    assert len(files) == len(os.listdir())


# Generated at 2022-06-22 06:49:08.846926
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})

# Generated at 2022-06-22 06:49:14.648068
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None, None)
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('1m') == 1024 * 1024
    assert fd.parse_bytes('1M') == 1024 * 1024
    assert fd.parse_bytes('1g') == 1024 * 1024 * 1024
    assert fd.parse_bytes('1G') == 1024 * 1024 * 1024
    assert fd.parse_bytes('1x') is None
    assert fd.parse_bytes('1a') is None
    assert fd.parse_bytes('1ac') is None
    assert fd.parse_bytes('1kx') is None

# Generated at 2022-06-22 06:49:17.104846
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader({})
    fd.ydl_filename("abcd") == "abcd.ytdl"



# Generated at 2022-06-22 06:49:25.796936
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    for (seconds, eta) in [
        (60, '1:00'),
        (0, '0:00'),
        (1, '0:01'),
        (61, '1:01'),
        (3601, '1:00:01'),
        (3599, '59:59'),
        (3661, '1:01:01'),
        (5401, '1:30:01'),
        (86401, '1:00:00:01'),
        (90061, '1:01:01:01'),
    ]:
        assert eta == FileDownloader.format_eta(seconds)