

# Generated at 2022-06-22 06:40:12.764985
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def calc_eta(start, now, current, total):
        fd = FileDownloader(params={})
        return fd._calc_eta(start, now, current, total)

    assert calc_eta(0, 10, 0, 10) == 10
    assert calc_eta(0, 10, 1, 10) is None
    assert calc_eta(0, 10, 9, 10) is None
    assert calc_eta(0, 10, 10, 10) == 0
    assert calc_eta(0, 10, 11, 10) == -1
    assert calc_eta(0, 10, 0, None) is None
    assert calc_eta(0, 10, 10, None) == 0
    assert calc_eta(0, 10, 0, 0) == 0

# Generated at 2022-06-22 06:40:13.537211
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    pass

# Generated at 2022-06-22 06:40:18.660890
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    from io import BytesIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_urllib_error

    # Dummy extractor for testing
    class DummyIE(InfoExtractor):
        def __init__(self, downloader=None, temp_name='test'):
            InfoExtractor.__init__(self, downloader)
            self.temp_name = temp_name

        def _real_initialize(self):
            return

        def _real_extract(self, url):
            return {'id': url.split('/')[-1]}

    # Dummy downloader for testing

# Generated at 2022-06-22 06:40:23.251340
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(FakeYDL(), {'nopart': True})
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('bar') == 'bar'
    assert fd.undo_temp_name('bar.part') == 'bar'
    assert fd.undo_temp_name('baz') == 'baz'
    fd = FileDownloader(FakeYDL(), {'nopart': False})
    assert fd.undo_temp_name('foo') == 'foo'
    assert fd.undo_temp_name('foo.part') == 'foo'
    assert fd.undo_temp_name('bar') == 'bar'

# Generated at 2022-06-22 06:40:27.823022
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Clear progress_hooks
    fd = FileDownloader({})
    fd._progress_hooks = []
    fd.add_progress_hook(lambda a: a)
    assert fd._progress_hooks == [lambda a: a]
    fd.add_progress_hook(lambda a: a)
    assert len(fd._progress_hooks) == 2

# Generated at 2022-06-22 06:40:29.253979
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    fd=FileDownloader()
    fd.report_unable_to_resume()
    #assert True
    #pass  # TODO implement your test here


# Generated at 2022-06-22 06:40:33.738001
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader({})

    filename = 'test.mp4'
    assert downloader.temp_name(filename) == filename + '.part'

    filename = 'test'
    assert downloader.temp_name(filename) == filename + '.part'

    filename = 'test.mp4.part'
    assert downloader.temp_name(filename) == filename

    filename = '-'
    assert downloader.temp_name(filename) == filename

    filename = '-o'
    assert downloader.temp_name(filename) == filename

# Generated at 2022-06-22 06:40:46.047981
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import random
    import shutil
    import tempfile
    import unittest

    from youtube_dl.YoutubeDL import YoutubeDL

    test_id = 'test_id'
    test_filename = 'test_filename'
    test_params = {
        'ratelimit': 42,
        'sleep_interval': 0.0,
        'max_sleep_interval': 0.0,
        'continuedl': True,
        'nooverwrites': True,
        'noprogress': True,
    }

    class FileDownloaderMock(FileDownloader):
        def real_download(self, filename, info_dict):
            self._real_download_called = True
            self._real_download_filename = filename
            self._real_download_info_dict = info_dict
           

# Generated at 2022-06-22 06:40:56.957760
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFD(FileDownloader):
        def __init__(self):
            self.overwrites = 0
            self.resumes = 0
            super(TestFD, self).__init__(None)

        def trouble(self, *args, **kwargs):
            pass

        def report_error(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kwargs):
            pass

        def to_console_title(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

        def real_download(self, *args, **kwards):
            return True

    fd = TestFD()

    # no overwrite, no resume
    report = fd.report_progress

# Generated at 2022-06-22 06:41:04.594991
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    """This test is not meant to be run as shell script, but just used as
    support for the unit test of FileDownloader.real_download()
    """
    import tempfile
    import shutil
    import os
    import os.path

    temp_dir = tempfile.mkdtemp(prefix='test_youtube-dl_FileDownloader')

# Generated at 2022-06-22 06:41:26.785325
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    tests = [
        ('test.txt', 'test.txt'),
        ('test.txt.part', 'test.txt'),
        ('test.txt.partaaa', 'test.txt'),
        ('test.txt.part.aaa', 'test.txt.part.aaa'),
    ]

    fd = FileDownloader({'continuedl': True})
    for test, ret in tests:
        assert fd.undo_temp_name(test) == ret


# Generated at 2022-06-22 06:41:32.407854
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # pylint: disable=C0111,W0201
    fd = FileDownloader({})
    assert fd.report_resuming_byte(0) is None
    assert fd.report_resuming_byte(1) is None
    assert fd.report_resuming_byte(129) is None


# Generated at 2022-06-22 06:41:44.383521
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    file_downloader = FileDownloader(
        params={},
        ydl=YoutubeDL(params={}),
        progress_hooks=[]
    )
    assert file_downloader.ytdl_filename('test') == 'test.ytdl'
    assert file_downloader.ytdl_filename('test.ytdl') == 'test.ytdl.ytdl'
    # No exceptions:
    file_downloader.ytdl_filename('')
    file_downloader.ytdl_filename('.')
    file_downloader.ytdl_filename('..')
    file_downloader.ytdl_filename('.ytdl')
    file_downloader.ytdl_filename('..ytdl')

# Generated at 2022-06-22 06:41:51.042957
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    msg = 'this failed'
    with pytest.raises(Exception) as e:
        with mock.patch('youtube_dl.downloader.FileDownloader.to_screen') as mocked_to_screen:
            mocked_to_screen.return_value = msg
            fd = FileDownloader('')
            fd.report_unable_to_resume()
    assert msg in str(e.value)


# Generated at 2022-06-22 06:42:02.967927
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    # Note: file downloader is not instantiated, but we use a
    # dummy class object instead.
    fd = FileDownloader(params={})
    assert(fd.format_eta(None) == '--:--')
    assert(fd.format_eta(1) == '0:01')
    assert(fd.format_eta(60) == '1:00')
    assert(fd.format_eta(3601) == '1:00:01')
    assert(fd.format_eta(36001) == '10:00:01')
    assert(fd.format_eta(None, True) == '--m --s')
    assert(fd.format_eta(1, True) == '0m 1s')
    assert(fd.format_eta(60, True) == '1m 0s')

# Generated at 2022-06-22 06:42:05.643950
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # Test case 4:
    global downloader
    downloader = FileDownloader(params={})
    downloader.report_resuming_byte(1)
    assert downloader.to_screen_list[-1] == '[download] Resuming download at byte 1'


# Generated at 2022-06-22 06:42:12.865042
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0)    == '0:00'
    assert FileDownloader.format_eta(1)    == '0:01'
    assert FileDownloader.format_eta(60)   == '1:00'
    assert FileDownloader.format_eta(61)   == '1:01'
    assert FileDownloader.format_eta(3600) == '1:00:00'


# Generated at 2022-06-22 06:42:24.047688
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # Test OS X:
    os.environ['TERM_PROGRAM'] = 'iTerm.app'
    fd = FileDownloader({'outtmpl':'-'}, {'url':'http://example.com'})
    # Test Windows 7:
    os.environ['TERM_PROGRAM'] = ''
    os.environ['PROCESSOR_ARCHITECTURE'] = 'AMD64'
    os.environ['PROCESSOR_ARCHITEW6432'] = 'AMD64'
    os.environ['NUMBER_OF_PROCESSORS'] = '8'
    fd.to_console_title('foo')
    # Test Windows XP:
    os.environ['PROCESSOR_ARCHITECTURE'] = 'x86'

# Generated at 2022-06-22 06:42:33.697988
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    ydl = YoutubeDL()
    ydl.report_warning = Mock()
    ydl.params = {}
    ydl.params['verbose'] = True
    ydl.add_progress_hook = Mock()

    fd = FileDownloader(ydl, {})
    fd.report_warning('Warning')
    ydl.report_warning.assert_called_with('Warning')

    del ydl.params['verbose']
    fd.report_warning('Warning')
    ydl.report_warning.assert_called_with(
        'Non-fatal warning encountered: Warning')

# Generated at 2022-06-22 06:42:43.842973
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    from io import StringIO
    from sys import stdout
    from time import sleep
    from .compat import str, sys, compat_str, compat_urllib_error, compat_urllib_request, compat_urllib_response, \
        compat_urlparse, compat_urlerr, stdout_encoding, getproxies

    ydl = object.__new__(YoutubeDL)
    ydl.params = {
        'verbose': True,
        'simulate': True,
    }
    ydl.downloaded_bytes = {
        None: 613
    }
    ydl.to_screen = lambda *args, **kargs: None
    ydl.to_stdout = lambda line: None
    ydl.report_warning = lambda *args, **kargs: None

# Generated at 2022-06-22 06:43:34.363520
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    # Test a normal run
    fd = FileDownloader(param={'quiet': True})
    assert fd.params['quiet']
    fd.params = {}
    # Test to see if FileDownloader raises an exception for unknown parameters
    pytest.raises(KeyError, FileDownloader, {'parameters': {'unknown': 4}})



# Generated at 2022-06-22 06:43:40.560298
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    class FakeYDL(object):
        params = {'outtmpl': '%(title)s'}
    ydl = FakeYDL()
    dl = FileDownloader(ydl)
    assert dl.ytdl_filename('foo-title') == 'foo-title.ytdl'



# Generated at 2022-06-22 06:43:51.183509
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    import random
    import nose.tools

    best_block_size = FileDownloader.best_block_size
    BLOCK_SIZE_STEP = 1024 * 512  # 0.5 MiB
    RANDOM_SAMPLES = 16

    def random_test_range(Min, Max, step=1.0, samples=RANDOM_SAMPLES):
        for i in range(samples):
            yield random.uniform(Min, Max)

    # Test block sizes up to 1 MiB
    for size in range(0, 1024 * 1024 + 1, BLOCK_SIZE_STEP):
        for elapsed in random_test_range(0.001, 1.0):
            assert best_block_size(elapsed, size) == size

    # Test block sizes up to 4 MiB

# Generated at 2022-06-22 06:44:03.195134
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params={})
    fd.to_screen = lambda *x:x
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 10,
        'downloaded_bytes': 10,
        'elapsed': 1,
    })
    assert fd.to_screen.called
    assert fd.to_screen.call_args[0][0].startswith('[download] 100% of 10 bytes in ')
    fd.to_screen.reset_mock()

    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
        'elapsed': None,
    })
    assert fd.to_screen.called

# Generated at 2022-06-22 06:44:14.953274
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from .YoutubeDL import YoutubeDL
    from .utils import DateRange
    from .extractor import gen_extractors

    ydl = YoutubeDL({
        'forcejson': True,
        'simulate': True,
    })

    url = 'http://example.org/'
    ie = gen_extractors(ydl)[0](ydl, {'url': url})
    ie.set_downloader(FileDownloader(ydl, {'ratelimit': '2'}))
    ie._prepare_and_start_download(
        {
            'id': 'testvideoid',
            'is_live': False,
            'formats': [
                {'url': url, 'ext': 'mp4'},
            ],
        },
        DateRange(),
    )



# Generated at 2022-06-22 06:44:23.360640
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    f = FileDownloader({})
    assert f.calc_speed(0, 1, 1) == 1 # One byte per second
    assert f.calc_speed(0, 10, 1) == 0.1 # One byte per ten seconds
    assert f.calc_speed(0, 1, 1024) == 1024 # 1024 byte per second
    assert f.calc_speed(0, 10, 1024) == 102.4 # 1024 byte per ten seconds
    assert f.calc_speed(0, 1, 1024**2) == (1024**2) # 1024 byte per second
    assert f.calc_speed(0, 1, 1024**2+512**2) == (1024**2+512**2) # 1024 byte per second

# Generated at 2022-06-22 06:44:31.521333
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # Call report_destination with the following parameters
    filename = "toto.mp3"
    fd = FileDownloader()
    # mock the output of report_destination
    fd.to_screen = Mock()
    fd.report_destination(filename)
    assert fd.to_screen.call_count == 1
    fd.to_screen.assert_called_with("[download] Destination: toto.mp3")

test_FileDownloader_report_destination()


# Generated at 2022-06-22 06:44:39.045134
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    # Test that an error is correctly reported
    fd = FileDownloader({'logger': MockLogger()})
    error = Exception('Some error message')
    fd.report_error('youtube-dl', error)
    # The logger should have been called with the error message
    assert fd._logger.my_method.called
    args, kwargs = fd._logger.my_method.call_args
    assert 'ERROR: youtube-dl: Some error message' in args
    # Test that the traceback is not present
    assert 'Traceback' not in args    
    

# Generated at 2022-06-22 06:44:40.355293
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    #TODO
    return

# Generated at 2022-06-22 06:44:52.477347
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # Test with a string
    assert FileDownloader.format_seconds('test') == 'test'

    # Test with a float
    assert FileDownloader.format_seconds(2.5) == '2.5'

    # Test with 0
    assert FileDownloader.format_seconds(0) == '0:00'

    # Test with an integer of multiple seconds
    assert FileDownloader.format_seconds(5) == '0:05'

    # Test with a float of multiple seconds
    assert FileDownloader.format_seconds(5.1) == '0:05'

    # Test with an integer of multiple minutes
    assert FileDownloader.format_seconds(60) == '1:00'

    # Test with a float of multiple minutes
    assert FileDownloader.format_seconds(61.3) == '1:01'

    #

# Generated at 2022-06-22 06:46:25.361854
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def _test(s, expected):
        _got = FileDownloader.parse_bytes(s)
        assert _got == expected
    yield _test, '1', 1
    yield _test, '1.1', 1
    yield _test, '1b', 1
    yield _test, '  1.1b  ', 1
    yield _test, '1.1kb', 1.1 * 1024
    yield _test, '1.1KiB', 1.1 * 1024
    yield _test, '1.1m', 1.1 * 1024 * 1024
    yield _test, '1.1mb', 1.1 * 1024 * 1024
    yield _test, '1.1 MiB', 1.1 * 1024 * 1024
    yield _test, '1.1GB', 1.1 * 1024 * 1024 * 1024
    yield _test

# Generated at 2022-06-22 06:46:31.671994
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # An instance of class FileDownloader
    f = FileDownloader(params = {}, ydl = mock.MagicMock())

    now = time.time()
    # Testing valid inputs
    tests = [
        # (current, start, bytes, expected)
        (0, None, 0, None),
        (10, 0, 10, 1),
        (20, 0, 10, 2),
        (40, 0, 10, 4),
        (5, 0, 10, 2.5),
        (10, 0, 5, 2),
        (10, 0, 15, 1.5),
        (10, now - 10, 5, 0.5),
        (10, now - 5, 5, 1),
        (10, now - 10, 10, 1),
        (10, now - 5, 10, 2)
    ]

# Generated at 2022-06-22 06:46:42.072970
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # Placeholder for a class to hold stubs for FileDownloader
    class TestDownloader(FileDownloader):
        pass

    # Initialise the stub object
    test_downloader = TestDownloader(youtube_dl.YoutubeDL({}))

    # Placeholder for a class to hold stubs for os
    class TestOS(object):
        pass

    # Initialise the stub object
    test_os = TestOS()

    # Replace the original os with the stub
    test_downloader.os = test_os
    filename = 'dummy_filename'

    # We shouldn't get a ZeroDivisionError if somehow the st_mtime
    # of the file isn't set

# Generated at 2022-06-22 06:46:47.194349
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("foo.part") == "foo"
    assert FileDownloader.undo_temp_name("foo.bar.part") == "foo.bar"
    assert FileDownloader.undo_temp_name("foo.part.part") == "foo.part"
    assert FileDownloader.undo_temp_name("foo") == "foo"

# Generated at 2022-06-22 06:46:56.525366
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(None) == '%10s' % '---b/s'
    assert FileDownloader.format_speed(0) == '%10s' % '0b/s'
    assert FileDownloader.format_speed(1) == '%10s' % '1b/s'
    assert FileDownloader.format_speed(1025) == '%10s' % '1025b/s'
    assert FileDownloader.format_speed(2048) == '%10s' % '2.00Kb/s'
    assert FileDownloader.format_speed(2049) == '%10s' % '2.00Kb/s'
    assert FileDownloader.format_speed(1024*1024) == '%10s' % '1.00Mb/s'

# Generated at 2022-06-22 06:47:05.922291
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    f = FileDownloader(FakeInfoExtractor(), {})
    # Write a file to the disk
    with open("test_FileDownloader_try_rename.txt", "w") as fd:
        fd.write("Hello World!")
    # Try to move it to another name
    f.try_rename("test_FileDownloader_try_rename.txt", "new_name.txt")
    # Check that the file is moved
    assert(os.path.isfile("new_name.txt"))
    # Cleanup
    os.remove("new_name.txt")

if __name__ == '__main__':
    test_FileDownloader_try_rename()

# Generated at 2022-06-22 06:47:17.988336
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader({})
    assert fd.format_speed(0) == '%10s' % '---b/s'
    assert fd.format_speed(300) == '%10s' % '300b/s'
    assert fd.format_speed(1234) == '%10s' % '1.2Kb/s'
    assert fd.format_speed(123456) == '%10s' % '120Kb/s'
    assert fd.format_speed(1234567) == '%10s' % '1.2Mb/s'
    assert fd.format_speed(123456789) == '%10s' % '120Mb/s'

# Generated at 2022-06-22 06:47:22.206602
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(YoutubeDL(), {})
    fd.to_screen = lambda s: s
    assert('[download] Resuming download at byte 12345' ==
           fd.report_resuming_byte(12345))

# Generated at 2022-06-22 06:47:33.588519
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """
    Unit test for method try_utime of class FileDownloader
    """

# Generated at 2022-06-22 06:47:38.718499
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    #test case 1
    # test case for FileDownloader.report_resuming_byte(resume_len = None)
    downloader = FileDownloader(params={})
    downloader.report_resuming_byte(None)


# Generated at 2022-06-22 06:49:07.638107
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('123') == 123
    assert FileDownloader.parse_bytes('2k') == 2048
    assert FileDownloader.parse_bytes('2K') == 2048
    assert FileDownloader.parse_bytes('2kiB') == 2048
    assert FileDownloader.parse_bytes(' 2k ') == 2048
    assert FileDownloader.parse_bytes('2  k') == 2048
    assert FileDownloader.parse_bytes('2m') == 2097152
    assert FileDownloader.parse_bytes('2M') == 2097152
    assert FileDownloader.parse_bytes('2MiB') == 2097152
    assert FileDownloader.parse_bytes(' 2m ') == 2097152
    assert FileDownloader.parse_bytes('2  m') == 2097152
    assert FileDownloader.parse_

# Generated at 2022-06-22 06:49:10.936839
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({}, {})
    assert fd.undo_temp_name('test.txt') == 'test.txt'
    assert fd.undo_temp_name('test.txt.part') == 'test.txt'


# Generated at 2022-06-22 06:49:22.639688
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    import pytest


# Generated at 2022-06-22 06:49:32.447525
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # test setup
    file_name = 'test_download'
    fd = FileDownloader({'continuedl': True, 'noprogress': True, 'outtmpl': file_name})
    # create test file
    with open(file_name, 'w') as f:
        f.write('some content')
    orig_size = os.path.getsize(file_name)
    os.remove(file_name)

    mock_info_dict = {
        'url': 'http://localhost/test_file',
        'http_headers': {'Content-Length': orig_size},
    }

    # test
    fd.real_download(file_name, mock_info_dict)
    # verify
    assert os.path.isfile(file_name)