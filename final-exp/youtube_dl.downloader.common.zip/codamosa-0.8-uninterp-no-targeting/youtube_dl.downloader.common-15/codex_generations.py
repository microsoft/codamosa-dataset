

# Generated at 2022-06-22 06:40:14.945103
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    from io import BytesIO
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL

    fd = FileDownloader({})
    hook = lambda status: status['filename'] == '/dev/null'
    fd.add_progress_hook(hook)
    assert hook in fd._progress_hooks
    fd.params['outtmpl'] = '/dev/null'
    fd.params['logger'] = YoutubeDL()._setup_logger()
    fd.to_screen = lambda *args, **kargs: None
    fd.report_progress = lambda *args, **kargs: None
    fd.real_download = lambda *args, **kargs: None


# Generated at 2022-06-22 06:40:23.426799
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    assert FileDownloader.calc_percent(0, 0) is None
    assert FileDownloader.calc_percent(0, 1) == 0
    assert FileDownloader.calc_percent(0, 100) == 0
    assert FileDownloader.calc_percent(1, 1) == 100
    assert FileDownloader.calc_percent(1, 100) == 1
    assert FileDownloader.calc_percent(100, 100) == 100
    assert FileDownloader.calc_percent(100, 200) == 50


# Generated at 2022-06-22 06:40:30.936769
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader({}, {'nooverwrites': True}, None)
    fd.postproc = PostProcessor({'convert_subtitles': False}, {}, None)
    fd.real_download = mock.Mock()
    # We do not pass info_dict to mock.ANY because it will fail tests
    # if info_dict is not passed
    fd.download('test', {'test': 'test'})
    fd.real_download.assert_called_once_with('test', {'test': 'test'})



# Generated at 2022-06-22 06:40:42.501940
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():

    fd = FileDownloader({})	# initialise FileDownloader object fd
    # output = fd.format_eta(23)

    # assert output == '23s'

    # output = fd.format_eta(12300)

    # assert output == '3h 30m'

    # output = fd.format_eta(1234567890)

    # assert output == '14211h 56m'

    # assert fd.format_eta(0) == '0s'
    # assert fd.format_eta(1) == '1s'
    # assert fd.format_eta(30) == '30s'
    # assert fd.format_eta(90) == '1m 30s'
    # assert fd.format_eta(3600) == '1h'
    # assert fd

# Generated at 2022-06-22 06:40:54.525723
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)

    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(0, 10, 0) is None
    assert fd.calc_eta(10, 0, 10) is None

    assert fd.calc_eta(0, 10, 40) == 30
    assert fd.calc_eta(0, 10, 50) == 20
    assert fd.calc_eta(0, 10, 60) == 10

    assert fd.calc_eta(0, 10, 40, now=5) == 25
    assert fd.calc_eta(0, 10, 50, now=5) == 15
    assert fd.calc_eta(0, 10, 60, now=5) == 5

    assert f

# Generated at 2022-06-22 06:41:04.192328
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    # 1
    assert FileDownloader.calc_percent(None, 1, 1) == 100.0
    # 2
    assert FileDownloader.calc_percent(None, 1, 2) == 50.0
    # 3
    assert FileDownloader.calc_percent(None, 2, 1) == 200.0
    # 4
    assert FileDownloader.calc_percent(None, 0, 1) == 0.0
    # 5
    assert FileDownloader.calc_percent(None, 1, 0) == 0.0
    # 6
    assert FileDownloader.calc_percent(None, 0, 0) == 0.0
    # 7
    assert FileDownloader.calc_percent(0.0, 1, 1) == 100.0
    # 8

# Generated at 2022-06-22 06:41:11.839879
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    from tempfile import mkstemp

    dirpath = None
    oldfn, newfn = None, None


# Generated at 2022-06-22 06:41:17.486595
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd = FileDownloader({}, None)
    assert fd._progress_hooks == []
    fd.add_progress_hook(lambda x: None)
    assert len(fd._progress_hooks) == 1

# Generated at 2022-06-22 06:41:28.387247
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('abc.part') == 'abc'
    assert FileDownloader.undo_temp_name('abc.part.foo') == 'abc.part.foo'
    assert FileDownloader.undo_temp_name('abc') == 'abc'
    assert FileDownloader.undo_temp_name('abc.partx') == 'abc.partx'
    assert FileDownloader.undo_temp_name('.part') == '.part'

from .extractor.common import InfoExtractor
from .utils import (
    encodeFilename,
    error_to_compat_str,
    format_bytes,
    format_seconds,
    shell_quote
)

from sys import stderr as compat_stderr
from os import makedirs
from time import time as timeconvert
import time

# Generated at 2022-06-22 06:41:32.707353
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Input and expected output
    filename = 'Example filename.mp3'
    expected_output = '[download] Example filename.mp3 has already been downloaded'
    # Instantiate the class
    fd = FileDownloader({})
    # Call the method
    fd.report_file_already_downloaded(filename)
    # Get the output from unit test
    output = fd.ydl.convert_bytes_to_str(fd.ydl.last_line)
    # Compare output with expected output
    assert output == expected_output


# Generated at 2022-06-22 06:41:47.890245
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    print("\nTest #1: FileDownloader.calc_percent")

    # Test 1
    print("Test 1:")
    downloader = FileDownloader({}, False, False)
    print("Expected : 20")
    print("Actual   : " + str(downloader.calc_percent(100, 20)))
    print("Expected : 1")
    print("Actual   : " + str(downloader.calc_percent(100, 1)))
    print("Expected : 100")
    print("Actual   : " + str(downloader.calc_percent(100, 100)))
    print("Expected : 0")
    print("Actual   : " + str(downloader.calc_percent(0, 100)))
    print("Expected : 0")

# Generated at 2022-06-22 06:42:01.393880
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    # Testing on a small amount of data because it is slow otherwise (this
    #   test uses network and disk I/O).
    small_amount = 100
    downloader = FileDownloader({'quiet': True})

    # Establish percent for downloaded bytes
    downloaded_bytes = random.randint(0, small_amount)
    total_bytes = random.randint(downloaded_bytes, small_amount)
    percent = downloader.calc_percent(downloaded_bytes, total_bytes)

    assert percent in range(0, 100)

    # Test some known values
    assert downloader.calc_percent(1, 100) == 1
    assert downloader.calc_percent(0, 100) == 0
    assert downloader.calc_percent(50, 100) == 50

# Generated at 2022-06-22 06:42:13.461206
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    print('Testing FileDownloader.best_block_size')

    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {})

    def assert_block_sizes(block_size, elapsed, bytes):
        assert(
            fd.best_block_size(elapsed, bytes)
            == block_size * 1024 * 1024
        )

    assert_block_sizes(1, 0.1, 10 * 1024 * 1024)
    assert_block_sizes(2, 0.1, 20 * 1024 * 1024)
    assert_block_sizes(4, 0.1, 40 * 1024 * 1024)
    assert_block_sizes(1, 0.1, 9 * 1024 * 1024)

# Generated at 2022-06-22 06:42:24.534488
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from pytube import YouTube
    from pytube.streams import Stream
    from pytube.exceptions import SameFileError, RegexMatchError

    import tempfile
    import time
    import os
    import sys
    import shutil
    import random

    def download(streams):
        def download_unique_path(unique_path, stream):
            # Download the video at `unique_path`
            stream.download(output_path=unique_path)

        paths = [tempfile.mkdtemp() for i in range(len(streams))]
        # Ensure the directory is empty.
        # This will remove the directory.
        for p in paths:
            shutil.rmtree(p)
        # Re-create the empty directory.
        for p in paths:
            os.mkdir(p)

# Generated at 2022-06-22 06:42:34.306165
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
	output = []
	def to_screen(msg):
		output.append(msg)
		return

	filename = 'filename'
	file_downloaded = FileDownloader(YoutubeDL(dict()), filename, None)
	file_downloaded.to_screen = to_screen
	file_downloaded.report_file_already_downloaded(filename)
	expected = '\n[download] {} has already been downloaded'.format(filename)
	assert(output[0] == expected)

if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-22 06:42:44.448398
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-22 06:42:51.722047
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, params={'verbose': True, 'verbose_sleep': True})
    fd.params['ratelimit'] = 10
    time.sleep(0.01)
    byte_counter = 10000
    start_time = time.time()
    fd.slow_down(start_time, None, byte_counter)
    elapsed = time.time() - start_time
    speed = byte_counter / elapsed
    assert (speed <= 10)


# Generated at 2022-06-22 06:43:02.154274
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FileDownloader({
        'nopart': True,
        'continuedl': True,
        'verbose': True,
    }, YoutubeDL({}))
    assert 'foo' == fd.temp_name('foo')
    assert 'foo.part' == fd.temp_name('foo.part')
    assert 'bar' == fd.temp_name('bar')
    fd.params['nopart'] = False
    assert 'bar.part' == fd.temp_name('bar')
    fd.params['nopart'] = True
    fd.params['continuedl'] = False
    assert 'bar' == fd.temp_name('bar')
    f = StringIO()

# Generated at 2022-06-22 06:43:12.874904
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(10 * 1024 * 1024) == ' 10.0MiB'
    assert FileDownloader.format_speed(10 * 1024 * 1024 / 8) == '  1.3MiB'
    assert FileDownloader.format_speed(500) == '500.0KiB'
    assert FileDownloader.format_speed(500.0 / 8) == '  62.5KiB'
    assert FileDownloader.format_speed(4 * 1024 * 1024) == '  4.0MiB'
    assert FileDownloader.format_speed(4 * 1024 * 1024 / 8) == ' 511.0KiB'
    assert FileDownloader.format_speed(1 * 1024 * 1024 * 1024) == '  1.0GiB'

# Generated at 2022-06-22 06:43:24.814330
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    import ytdl
    import os
    import pprint
    import tempfile
    import shutil
    
    assert ytdl.__file__

    # Test each subclass of FileDownloader
    for klass in sorted(ytdl.FileDownloader.__subclasses__(), key=lambda k: k.__name__):
        if not hasattr(klass, 'real_download') or not getattr(klass, 'real_download').__module__ == 'ytdl':
            continue
        if not hasattr(klass, 'test'):
            continue
        
        test = getattr(klass, 'test')
        if len(test) != 1:
            continue

        test_case = test[0]

        if isinstance(test_case, dict):
            # For backward compatibility
            test_case = test_

# Generated at 2022-06-22 06:43:44.683634
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader({})
    # percent is None
    assert fd.format_percent(None) == 'Unknown %'
    # percent is a float but its value is -1
    assert fd.format_percent(-1) == 'Unknown %'
    # percent is a float but its value is -1
    assert fd.format_percent(-1) == 'Unknown %'
    # percent is a float but its value is 101
    assert fd.format_percent(101) == 'Unknown %'
    # percent is a float but its value is 12.345
    assert fd.format_percent(12.345) == '12.3%'
    # percent is a float but its value is 12.344
    assert fd.format_percent(12.344) == '12.3%'
    # percent is an integer


# Generated at 2022-06-22 06:43:56.287085
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # Test values based on format_seconds of youtube-dl version 2014.03.25
    assert FileDownloader.format_seconds(0) == ' 0:00:00'
    assert FileDownloader.format_seconds(5) == ' 0:00:05'
    assert FileDownloader.format_seconds(8.87) == ' 0:00:08'
    assert FileDownloader.format_seconds(60) == ' 0:01:00'
    assert FileDownloader.format_seconds(62) == ' 0:01:02'
    assert FileDownloader.format_seconds(3600) == ' 1:00:00'
    assert FileDownloader.format_seconds(7200) == ' 2:00:00'
    assert FileDownloader.format_seconds(3662) == ' 1:01:02'

# Generated at 2022-06-22 06:44:03.005217
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from io import BytesIO
    from youtube_dl.extractor import get_info_extractor

    def _run_download(extractor, file_size=0, file_data=b'', expected_status='finished', expected_total_bytes=0):
        _, tmp = tempfile.mkstemp()

# Generated at 2022-06-22 06:44:14.801754
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(2) == '00:02'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(120) == '02:00'
    assert FileDownloader.format_eta(3600) == '01:00:00'
    assert FileDownloader.format_eta(7200) == '02:00:00'

if __name__ == '__main__':
    import doctest
    doctest.testmod(sys.modules[__name__])

    test_FileDownloader_format

# Generated at 2022-06-22 06:44:18.407500
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    fd = FileDownloader({})
    fd.add_progress_hook(lambda x: None)
    fd.add_progress_hook(lambda x: None)
    fd.add_progress_hook(lambda x: None)

# Generated at 2022-06-22 06:44:25.552252
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    cases = [
        ('inf', float('inf')),
        ('0', 0),
        ('12453', 12453),
        ('-12', None),
        ('asdf', None),
    ]
    fd = FileDownloader({})
    for expected, retries in cases:
        got = fd.format_retries(retries)
        assert expected == got, '%r != %r' % (expected, got)



# Generated at 2022-06-22 06:44:36.492410
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """Return True if the function download works properly."""
    # Create a test instance of FileDownloader
    fd = FileDownloader(params=dict())

    # Create a test info_dict
    info_dict = {
        'id': 'test video id',
        'ext': 'test extension',
        'url': 'test url',
        'title': 'test title',
        'requested_formats': [{
            'url': 'test url',
            'format_id': 'test format id',
            'ext': 'test extension',
        }],
    }

    # Test that the function download fails if the parameter filename
    # is not defined.
    is_download_ok = fd.download(None, info_dict)
    if is_download_ok is not False:
        return False

    # Test that the function

# Generated at 2022-06-22 06:44:41.251133
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    from collections import namedtuple
    from types import SimpleNamespace as Namespace
    opts = Namespace(noprogress=False)
    fd = FileDownloader(opts)
    assert fd.to_screen('test') == None


# Generated at 2022-06-22 06:44:53.588452
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # Test report_destination function
    # From https://github.com/ytdl-org/youtube-dl/blob/test/test_file.py

    # Create a FileDownloader
    params = {'logger': False}
    down = FileDownloader(params)

    # Download to: '-'
    down.report_destination('-')
    assert down.params.get('outtmpl') == '-'

    # Download to: 'test'
    down.report_destination('test')
    assert down.params.get('outtmpl') == 'test'

    # Download to: '-o test'
    down.report_destination('-o test')
    assert down.params.get('outtmpl') == 'test'

    # Download to: '-otest'
    down.report_destination

# Generated at 2022-06-22 06:45:05.420346
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from .YoutubeDL import YoutubeDL
    from .extractor import YoutubeIE
    from .utils import DateRange

    class DummyExtractor(YoutubeIE):
        pass

    extractor = DummyExtractor(YoutubeDL({'format': 'best'}))
    df = FileDownloader({'cachedir': False}, YoutubeDL({'format': 'best'}))
    fd = io.BytesIO()
    df.add_progress_hook(lambda s: fd.write(s.encode('utf-8')))

# Generated at 2022-06-22 06:45:34.757551
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
  # Test FileDownloader.real_download
  from .YoutubeDL import YoutubeDL
  from .utils import encodeFilename
  from .extractor import get_info_extractor
  from .compat import compat_urllib_request

  class MyFD(FileDownloader):
    def __init__(self, ydl, params, outtmpl, ie_key, test, verbose):
      super(MyFD, self).__init__(ydl, params, outtmpl, ie_key)
      self.test = test
      self.verbose = verbose


# Generated at 2022-06-22 06:45:42.357402
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    file_downloader = FileDownloader(None, params={})
    os.mkdir("test_folder/")
    with open("test_folder/test_file", "w") as test_file:
        test_file.write("test1\n")
    assert file_downloader.try_rename("test_folder/test_file", "test_folder/test_file") is None
    assert os.path.isfile("test_folder/test_file")
    with open("test_folder/test_file", "r") as test_file:
        assert test_file.read() == "test1\n"
    os.rename("test_folder/test_file", "test_folder/test_file2")

# Generated at 2022-06-22 06:45:44.480278
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(2000) == '2000'



# Generated at 2022-06-22 06:45:57.213947
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    h = FileDownloader(YoutubeDL())
    assert '1' == h.format_bytes(h.parse_bytes('1'))
    assert '1' == h.format_bytes(h.parse_bytes('1.0'))
    assert '1' == h.format_bytes(h.parse_bytes('1.00'))
    assert '1' == h.format_bytes(h.parse_bytes('1.0k'))
    assert '1024' == h.format_bytes(h.parse_bytes('1k'))
    assert '1024' == h.format_bytes(h.parse_bytes('1.k'))
    assert '1048576' == h.format_bytes(h.parse_bytes('1m'))

# Generated at 2022-06-22 06:46:01.050818
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Currently, this test is noop because calc_speed is only a
    # staticmethod, but this test can be used for future
    # refactorings.
    pass



# Generated at 2022-06-22 06:46:12.114973
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    # report_warning(self, *args, **kargs):
    fd = FileDownloader()

    class dummy_ydl():
        def __init__(self):
            self.warned = []
        def report_warning(self, msg):
            self.warned.append(msg)

    fd.ydl = dummy_ydl()

    # test 1
    fd.report_warning('test1a')
    assert fd.ydl.warned == ['test1a']
    # test 2
    fd.report_warning('test2a', 'test2b')
    assert fd.ydl.warned == ['test1a', 'test2a']
    # test 2
    fd.report_warning(warning_code='test3a')

# Generated at 2022-06-22 06:46:24.231961
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader(Param({}), None)
    fd.download = lambda filename, info_dict: (filename, info_dict)
    # Test all params

# Generated at 2022-06-22 06:46:34.473020
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'garbage')
        f.flush()

        # Write garbage to the file
        f.write(b'garbage')
        f.seek(0)

        assert f.read() == b'garbagegarbage'

        d = FileDownloader({}, {})
        assert d.try_utime(f.name, None) is None

        curr_time = time.time()
        d.try_utime(f.name, format_time(curr_time))
        assert os.path.getmtime(f.name) == curr_time

        assert d.try_utime(f.name, '2010') == 1262304000.0
        assert d.try_utime(f.name, 'coucou')

# Generated at 2022-06-22 06:46:40.566755
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # Input
    def FakeFileDownloader_real_download(filename, info_dict):
        return True

    # Output
    def FakeFileDownloader_real_download(filename, info_dict):
        return True

    # Unit test
    assert FileDownloader_real_download(filename, info_dict) == True


# Generated at 2022-06-22 06:46:51.593823
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    # Test First version
    # Set global variables for test
    global test_status, test_hook
    test_status = None
    test_hook = None

    # Define test status
    status = {'downloaded_bytes': 1000,
              'total_bytes': 2000,
              'filename': 'test.mp4',
              'status': 'downloading',
              'elapsed': 10.0,
              '_percent_str': '50%',
              'eta': 181,
              'speed': 100.0,
              '_total_bytes_str': '2.00M',
              '_speed_str': '100.0B/s'
              }

    # Mock up the hook function
    def hook(s):
        test_hook = s

    # Set up downloader
    downloader = FileDownloader({})



# Generated at 2022-06-22 06:47:51.252055
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    #from youtube_dl.downloader.FileDownloader import _calc_speed
    from youtube_dl.downloader.FileDownloader import FileDownloader

    fd = FileDownloader({})

    assert fd.calc_speed(1432515100.0, 1432515100.0, 0) is None
    assert fd.calc_speed(1432515100.0, 1432515100.0, 1) is None
    assert fd.calc_speed(1432515100.0, 1432515100.0, 1e11) is None

    assert fd.calc_speed(1432515100.0, 1432515100.1, 100) == 1000
    assert fd.calc_speed(1432515100.0, 1432515100.3, 200) == 1333
    assert fd

# Generated at 2022-06-22 06:48:01.768591
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.compat import compat_urllib_error
    from collections import namedtuple

    DownloadStatus = namedtuple('DownloadStatus', [
        'status', 'filename', 'total_bytes', 'downloaded_bytes', 'elapsed', 'speed', 'eta'])


# Generated at 2022-06-22 06:48:07.134351
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.part.bar') == 'foo.part.bar'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('') == ''

# Utility function for testing format_bytes

# Generated at 2022-06-22 06:48:14.033920
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader({}, FakeYDL())
    assert fd.ytdl_filename('foo.mp4') == 'foo.mp4.ytdl'
    assert fd.ytdl_filename('bar.flv.tmp') == 'bar.flv.tmp.ytdl'
    assert fd.ytdl_filename('baz.mp4.part') == 'baz.mp4.part.ytdl'


# Generated at 2022-06-22 06:48:24.114880
# Unit test for method add_progress_hook of class FileDownloader
def test_FileDownloader_add_progress_hook():
    downloader = FileDownloader({})

    class TestHook():
        def __init__(self):
            self.called = False

        def __call__(self, status):
            self.called = True

    hook = TestHook()
    downloader.add_progress_hook(hook)
    assert hook in downloader._progress_hooks, "Hook hasn't been added to the downloader"
    assert hook.called is False, 'hook has been called although no download has started yet'

    downloader._hook_progress({'status': 'downloading'})
    assert hook.called is True, 'hook has not been called'


test_FileDownloader_add_progress_hook()


# Generated at 2022-06-22 06:48:33.980807
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(1.0) == '0:00:01'
    assert FileDownloader.format_eta(10.0) == '0:00:10'
    assert FileDownloader.format_eta(60.0) == '0:01:00'
    assert FileDownloader.format_eta(60.0 + 1.0) == '0:01:01'
    assert FileDownloader.format_eta(60.0 * 60) == '1:00:00'
    assert FileDownloader.format_eta(60.0 * 60 + 1.0) == '1:00:01'
    assert FileDownloader.format_eta(60.0 * 60 * 24) == '24:00:00'
    assert FileDownloader.format_eta(60.0 * 60 * 24 + 1.0)

# Generated at 2022-06-22 06:48:46.211924
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)

    assert fd.temp_name('foo') == 'foo'
    assert fd.temp_name('foo.bar') == 'foo.part'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo.part.mp4') == 'foo.part.mp4'
    assert fd.temp_name('foo.part.abc.mp4') == 'foo.part.abc.mp4'
    assert fd.temp_name('foo.part.abc.part.mp4') == 'foo.part.abc.part.mp4'
    assert fd.temp_name('/foo/bar') == '/foo/bar'

# Generated at 2022-06-22 06:48:47.779816
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    FileDownloader.to_console_title("YouTubeDL")
    

# Generated at 2022-06-22 06:48:57.678697
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    import sys
    import shutil

    if not os.path.exists('./test/temp'):
        os.mkdir('./test/temp')
    shutil.copyfile('./test/test1.mp4', './test/temp/test1.mp4.part')

    downloader = FileDownloader(YoutubeDL({}), {})
    assert (downloader.undo_temp_name('./test/temp/test1.mp4.part') == './test/temp/test1.mp4')
    os.remove('./test/temp/test1.mp4.part')
    os.rmdir('./test/temp')


# Generated at 2022-06-22 06:49:09.312668
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    import sys
    import contextlib

    @contextlib.contextmanager
    def _s_w():
        orig_s = sys.stdout
        sys.stdout = sys.stderr
        try:
            yield
        finally:
            sys.stdout = orig_s

    with _s_w():
        sd = FileDownloader(params={
            'logger': MockLogger(),
            'forcefilename': True,
            'forcetitle': True,
            'forcedescription': True,
            'forceurl': True,
        })

        sd.to_screen('ascii')
        sd.to_screen(u'unicode')
        sd.to_screen(u'\u0421\u043c\u0435\u0441\u043b\u043e')
