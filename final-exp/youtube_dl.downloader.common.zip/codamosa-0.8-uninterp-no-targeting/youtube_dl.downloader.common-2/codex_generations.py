

# Generated at 2022-06-22 06:40:18.594098
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None, None)

    # Test duration 0
    assert fd.calc_speed(100, 200, 50) == None

    # Test duration > 0
    assert fd.calc_speed(100, 200, 100) == 100.0

    # Test duration < 0
    assert fd.calc_speed(200, 100, 100) == None


# Generated at 2022-06-22 06:40:26.270817
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # For the test, we use a mock class
    class TestFileDownloader(FileDownloader):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *x, **xx: None

    filename = 'test.mp4'
    params = {'outtmpl': '%(id)s.%(ext)s'}
    fd = TestFileDownloader(params)
    fd.report_destination(filename)


# Generated at 2022-06-22 06:40:32.969383
# Unit test for method to_console_title of class FileDownloader
def test_FileDownloader_to_console_title():
    # Given a FileDownloader object
    fd = FileDownloader(FakeYDL(), {})
    # when I call the method to_console_title
    fd.to_console_title("Test")
    # then I see the message "Test" in the console title
    assert sys.stdout.getvalue() == ''


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-22 06:40:44.747608
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name("test.flv") == "test.flv.part"
    assert fd.temp_name("test.flv.part") == "test.flv.part"
    assert fd.temp_name("test") == "test.part"
    assert fd.temp_name("test.nopart") == "test.nopart"
    fd = FileDownloader({'nopart': True})
    assert fd.temp_name("test.flv") == "test.flv"
    assert fd.temp_name("test.flv.part") == "test.flv.part"
    assert fd.temp_name("test") == "test"

# Generated at 2022-06-22 06:40:45.833509
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    pass

# Generated at 2022-06-22 06:40:54.160442
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    fd = FileDownloader(YoutubeDL(), params={})
    assert fd.ytdl_filename('/path/to/file-000000.part') == '/path/to/file-000000.part.ytdl'
    assert fd.ytdl_filename('/path/to/file-00000000.part') == '/path/to/file-00000000.part.ytdl'
    assert fd.ytdl_filename('/path/to/file-00000000.part.ytdl') == '/path/to/file-00000000.part.ytdl'



# Generated at 2022-06-22 06:40:58.259185
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    #assert FileDownloader().report_retry(
    #    "error_message", 1, 2) == 'error_message'
    assert FileDownloader().report_retry(
        "error_message", 1, 2) == '[download] Got server HTTP error: error_message. Retrying (attempt 1 of inf)...'



# Generated at 2022-06-22 06:41:06.244273
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
        # Test vimeo case (single URL)
        fd = FileDownloader(
            {
                'format': 'best',
                'nooverwrites': True,
                'outtmpl': '%(id)s',
                'quiet': True,
                'retries': 10,
                'skip_download': True,
                'noprogress': True
            },
            None)
        fd.report_destination = lambda *args: None
        fd.http_headers = lambda *args: {}
        fd.to_screen = lambda *args: None
        fd.to_console_title = lambda *args: None
        fd.post_process = lambda *args: True

# Generated at 2022-06-22 06:41:09.009799
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    downloader = FileDownloader(None, {})
    assert downloader.calc_percent(1, 2, 3) == 50



# Generated at 2022-06-22 06:41:20.570364
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    from urllib.parse import urlparse

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.reported = []

        def to_screen(self, msg):
            self.reported.append(msg)

        def to_console_title(self, msg):
            self.reported.append(msg)

    url = 'http://example.org/video.ext'
    fd = FileDownloader({'outtmpl': u'out%(ext)s'}, DummyYDL({}))
    fd.report_destination(fd.prepare_filename(url))

    url = 'http://example.org/video.ext'

# Generated at 2022-06-22 06:41:35.986505
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    fd = FileDownloader(FakeYoutubeDl(), None)
    fd.report_destination(None)
    fd.report_resuming_byte(12345)
    fd._hook_progress({'downloaded_bytes': 42, 'status': 'downloading', 'elapsed': 4242, 'total_bytes': 420000})
    fd.params['noprogress'] = True
    fd._hook_progress({'downloaded_bytes': 420000, 'status': 'finished', 'total_bytes': 420000})
    fd.params['progress_with_newline'] = True
    fd._hook_progress({'downloaded_bytes': 420000, 'status': 'finished', 'total_bytes': 420000})
    fd.to_stderr(None)


# Unit test

# Generated at 2022-06-22 06:41:47.521469
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader({'nopart': True})
    # Test output for common cases
    assert downloader.temp_name('foo') == 'foo'
    assert downloader.temp_name('foo.bar') == 'foo.part.bar'
    assert downloader.temp_name('foo.bar.baz') == 'foo.bar.part.baz'
    assert downloader.temp_name('.hidden-file') == '.hidden-file.part'
    assert downloader.temp_name('-.hidden-file') == '-.hidden-file.part'
    assert downloader.temp_name('foo/bar.baz') == 'foo/bar.part.baz'
    assert downloader.temp_name('foo/bar') == 'foo/bar'

# Generated at 2022-06-22 06:41:51.728466
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    ydl = YoutubeDL()
    ydl.params['verbose'] = True
    ydl.report_warning('test_warning')


# Generated at 2022-06-22 06:42:01.878757
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(object, object, object)
    assert fd.calc_speed(0, 0, 0) == None
    assert fd.calc_speed(0, 10, 0) == None
    assert fd.calc_speed(0, 10, 10) > 0
    assert fd.calc_speed(1, 10, 10) > 0
    assert fd.calc_speed(2, 10, 10) > 0
    assert fd.calc_speed(10, 100, 10) > 0
    assert fd.calc_speed(10, 100, 20) > fd.calc_speed(10, 100, 10)

# Generated at 2022-06-22 06:42:13.985296
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, None)
    assert fd.calc_eta(0, 0, 100) is None
    assert fd.calc_eta(100, 0, 100) is None
    assert fd.calc_eta(0, 100, 100) is None
    assert fd.calc_eta(0, 0, 0) is None
    assert fd.calc_eta(100, 100, 0) is None
    assert abs(fd.calc_eta(0, 0, 100, now=1000) - 1000) < 0.001
    assert abs(fd.calc_eta(100, 0, 100, now=1000) - 1000) < 0.001
    assert abs(fd.calc_eta(0, 100, 100, now=1000) - 1000) < 0.001
    assert fd

# Generated at 2022-06-22 06:42:24.861142
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    def _test(msg, expected_msg, expected_tb):
        fd = FileDownloader({})
        try:
            raise Exception(msg)
        except Exception as e:
            fd.trouble(e)
        assert fd.ydl.errmsg == expected_msg
        assert fd.ydl.traceback == expected_tb


# Generated at 2022-06-22 06:42:37.191693
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    global fd
    fd = FileDownloader({})
    assert fd.calc_percent(100, 100) == 1, "Downloaded a number of bytes which is not equal to total bytes should have a different percent."
    assert fd.calc_percent(99, 100) == 1, "Downloaded a number of bytes which is not equal to total bytes should have a different percent."
    assert fd.calc_percent(0, 100) == 1, "Downloaded a number of bytes which is not equal to total bytes should have a different percent."
    assert fd.calc_percent(0, 0) == 1, "Downloaded a number of bytes which is not equal to total bytes should have a different percent."

# Generated at 2022-06-22 06:42:46.860403
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {'outtmpl': '%(id)s.%(ext)s'})
    info = {
        'id': 'fakevideoid',
        'ext': 'mp4'
    }
    assert fd.temp_name('%(id)s.%(ext)s' % info) == 'fakevideoid.part.mp4'
    assert fd.temp_name('%(id)s.%(ext)s' % info) == fd.temp_name('%(id)s.%(ext)s' % info)
    assert fd.temp_name('%(id)s.%(ext)s' % info) == fd.ydl_filename('%(id)s.%(ext)s' % info)

# Generated at 2022-06-22 06:42:53.746346
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    #  test FileDownloader.to_screen(*, error=false)
    msg = 'hello, world!'
    ydl = FileDownloader({})
    with mock.patch.object(FileDownloader, 'to_stderr') as to_stderr:
        # print msg to stderr when error is False 
        ydl.to_screen(msg, error=False)
        to_stderr.assert_called_with(msg)

        # print msg to stderr when error is True
        ydl.to_screen(msg, error=True)
        # to_stderr.assert_called_with(msg)
        
        # print msg to stderr when error is None
        to_stderr.reset_mock()
        ydl.to_screen(msg, error=None)
        to

# Generated at 2022-06-22 06:43:03.727372
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def t(params, filename, expected):
        ydl = YoutubeDL(params)
        fd = FileDownloader(ydl, {'url': 'foo'}, {})
        assert fd.temp_name(filename) == expected
    t({'nopart': True}, 'foo', 'foo')
    t({'nopart': True}, 'foo.part', 'foo.part')
    t({'nopart': False}, 'foo', 'foo.part')
    t({'nopart': False}, 'foo.part', 'foo.part')
    t({'nopart': False}, 'foo.part', 'foo.part')
    t({'nopart': False}, 'bar/foo', 'bar/foo.part')

# Generated at 2022-06-22 06:43:17.060524
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.extractor import common
    import doctest
    from youtube_dl.utils import encode_compat_str, encode_data_uri
    FileDownloader.params = {}
    class FakeExtractor(object):
        """Test extractor"""
        IE_DESC = 'Fake Extractor'
        _VALID_URL = r'(?:https?://)?(?:\w+\.)?example\.com'
        def __init__(self, *args, **kwargs):
            pass
        def _real_initialize(self):
            pass
        @staticmethod
        def _match_id(url):
            return re.match(FakeExtractor._VALID_URL, url)
        def _real_extract(self, url):
            return {'id': 'fakeid'}

# Generated at 2022-06-22 06:43:28.734285
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    t = nocacheFileDownloader({'verbose': True, 'quiet': False}, None, None)
    t.to_screen = lambda x: x
    t.to_stderr = lambda x: x
    t.report_error = lambda x: x
    def _hook_progress(a): pass
    t.add_progress_hook(_hook_progress)
    t.report_progress = lambda a: a
    t.report_destination = lambda a: a
    t.report_file_already_downloaded = lambda a: a
    t.report_unable_to_resume = lambda a: a
    t.report_retry = lambda a, b, c: a
    t.report_resuming_byte = lambda a: a

    # 1. Original code:
    from .__main__ import main


# Generated at 2022-06-22 06:43:39.547257
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    _test_FileDownloader_format_percent(0, '')
    _test_FileDownloader_format_percent(0, ' ')
    _test_FileDownloader_format_percent(0, '.')
    _test_FileDownloader_format_percent(100, '')
    _test_FileDownloader_format_percent(100, ' ')
    _test_FileDownloader_format_percent(100, '.')
    _test_FileDownloader_format_percent(50, '')
    _test_FileDownloader_format_percent(50, ' ')
    _test_FileDownloader_format_percent(50, '.')
    _test_FileDownloader_format_percent(99, '')
    _test_FileDownloader_format_percent(99, ' ')
    _test_File

# Generated at 2022-06-22 06:43:44.898697
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    # given
    fd = FileDownloader(YoutubeDL({}))
    expected_message = b'\x00\x01\x02\x03'
    fd.to_screen = MagicMock()
    # when
    fd.to_stderr(expected_message)
    # then
    fd.to_screen.assert_called_once_with(expected_message)

# Generated at 2022-06-22 06:43:56.469689
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    downloader = FileDownloader({})

    def test(s, expected):
        downloader.report_progress(s)
        assert(downloader._report_progress_prev_line_length == expected)

    test({'status': 'finished'}, 0)
    test({'status': 'downloading'}, 0)
    test({'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes_estimate': 10**9, 'total_bytes': 10**9, 'elapsed': 10**9}, 35)
    test({'status': 'downloading', 'downloaded_bytes': 10**9, 'total_bytes_estimate': 10**9, 'total_bytes': 10**9, 'elapsed': 10**9}, 0)

# Generated at 2022-06-22 06:43:57.666400
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    fd = FileDownloader(FakeInfoExtractor())
    fd.report_error('test_message')



# Generated at 2022-06-22 06:44:01.587958
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    f = FileDownloader({}, None)
    f.to_screen = lambda x: x
    assert f.report_destination('filename') == '[download] Destination: filename'


# Generated at 2022-06-22 06:44:03.421699
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    assert(FileDownloader({}))
    assert(FileDownloader({}, {}))


# Generated at 2022-06-22 06:44:15.133802
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    # Test normal situations
    c = ConfigParser()
    c.add_section('youtube-dl')
    c.set('youtube-dl', 'restrictfilenames', 'True')
    c.set('youtube-dl', 'logtostderr', 'True')
    ydl = YoutubeDL(c)

    filename = 'foo.bar'
    fd = FileDownloader(ydl, {})
    fd.report_destination(filename)

    filename = '~/foo.bar'
    fd = FileDownloader(ydl, {})
    fd.report_destination(filename)

    path = os.getcwd()
    if path.startswith('/'):
        sep = '/'
    else:
        sep = '\\'
    filename = path + sep + 'foo.bar'


# Generated at 2022-06-22 06:44:23.471125
# Unit test for method format_retries of class FileDownloader

# Generated at 2022-06-22 06:44:33.870271
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader()
    filename = 'abc.txt'
    fd.report_file_already_downloaded(filename)
    encoded_filename = encodeFilename(filename)
    assert os.path.isfile(encoded_filename)
    dl = open(encoded_filename, 'r')
    content = dl.read()
    dl.close()
    assert content.startswith('[download] abc.txt has already been downloaded')
    assert os.path.exists(encoded_filename)
    os.remove(encoded_filename)
# Test for download function of FileDownloader class

# Generated at 2022-06-22 06:44:39.525940
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({'noprogress': True})
    fd.report_file_already_downloaded('aaa.bbb')
    message = 'aaa.bbb has already been downloaded'
    fd.to_screen.assert_called_once_with('[download] ' + message)
raise Exception("hohoho")

# Generated at 2022-06-22 06:44:51.053496
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader({})
    assert fd.format_percent(0) == '0.0%'
    assert fd.format_percent(0.5) == '0.5%'
    assert fd.format_percent(0.12345) == '0.1%'
    assert fd.format_percent(1) == '1.0%'
    assert fd.format_percent(1.2345) == '1.2%'
    assert fd.format_percent(99) == '99.0%'
    assert fd.format_percent(99.9) == '99.9%'
    assert fd.format_percent(99.99) == '100%'
    assert fd.format_percent(100) == '100%'

# Generated at 2022-06-22 06:45:03.552665
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(10) == '0:10'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(120) == '2:00'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(36000) == '10:00:00'
    assert FileDownloader.format_seconds(7200) == '2:00:00'

# Generated at 2022-06-22 06:45:13.793059
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from .YoutubeDL import YoutubeDL
    fd = FileDownloader(YoutubeDL({'verbose': True}))
    fd._progress_hooks.append(_create_hook_tester())

    # Test without data
    fd.report_progress({'status': 'downloading'})
    _assert_progress_hooks(None)

    # Test with speed and eta
    fd.report_progress({'status': 'downloading',
                        'total_bytes': 1024,
                        'downloaded_bytes': 512,
                        'elapsed': 123,
                        'speed': 64})
    _assert_progress_hooks(None)

    # Test with total_bytes_estimate

# Generated at 2022-06-22 06:45:24.042797
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    """ Test the method calc_percent of class FileDownloader """

    # Test correct return of None when total_bytes is 0
    assert None == FileDownloader.calc_percent(0, 0)
    assert None == FileDownloader.calc_percent(42, 0)

    # Test correct return of a float
    assert 42.42 == FileDownloader.calc_percent(42, 100)
    assert 0.0 == FileDownloader.calc_percent(0, 100)
    assert 99.99 == FileDownloader.calc_percent(999999, 1000000)
    assert 100.0 == FileDownloader.calc_percent(1, 1)
    assert 100.0 == FileDownloader.calc_percent(1000000, 1000000)



# Generated at 2022-06-22 06:45:35.415705
# Unit test for method to_screen of class FileDownloader

# Generated at 2022-06-22 06:45:42.778656
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader(None)
    assert fd.format_percent(0) == '0%'
    assert fd.format_percent(1) == '>100%'
    assert fd.format_percent(0.001) == '>100%'
    assert fd.format_percent(0.01) == '>100%'
    assert fd.format_percent(0.1) == '>100%'
    assert fd.format_percent(0.5) == '50%'
    assert fd.format_percent(0.99) == '99%'
    assert fd.format_percent(1.0) == '100%'
    assert fd.format_percent(1.1) == '>100%'

# Generated at 2022-06-22 06:45:47.633488
# Unit test for method download of class FileDownloader

# Generated at 2022-06-22 06:45:53.915054
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    # Initialization
    downloader = FileDownloader()
    # Expected output
    expected = '\r[download] Resuming download at byte {}'.format(5)
    # Actual output
    actual = downloader.report_resuming_byte(5)
    # Check if the function returned the expected value
    assert expected == actual

# Generated at 2022-06-22 06:46:13.779418
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    def _test(retries, expected):
        if FileDownloader.format_retries(retries) != expected:
            raise ValueError('Expected "%s" for retries=%s' % (expected, retries))

    _test(0, '0')
    _test(1, '1')
    _test(2, '2')
    _test(10, '10')
    _test(float('inf'), 'inf')
    _test(_Inf, 'inf')


# Generated at 2022-06-22 06:46:25.743115
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    def test_FileDownloader_calc_speed_template(expected, *args):
        assert FileDownloader.calc_speed(*args) == expected

    yield test_FileDownloader_calc_speed_template, None, 0, 0, 0
    yield test_FileDownloader_calc_speed_template, None, 0, 0, 1
    yield test_FileDownloader_calc_speed_template, None, 0, 1, 0
    yield test_FileDownloader_calc_speed_template, None, 0, 1, 2
    yield test_FileDownloader_calc_speed_template, 0, 0, 1, 1
    yield test_FileDownloader_calc_speed_template, 1, 1, 2, 1
    yield test_FileDownloader_calc_speed_template, 1, 1, 3, 0.5

# Generated at 2022-06-22 06:46:35.369603
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    dl = FileDownloader(object)
    import sys
    dl.real_download = lambda *a, **k: None
    dl.to_screen = lambda msg: sys.stdout.write(msg.encode('utf-8'))
    for retries in (-1, 0):
        dl.report_retry(retries, 1, retries)
    dl.to_screen = lambda msg: sys.stdout.write(msg.encode('utf-8'))
    for retries in (float('inf'), 1, 5):
        dl.report_retry(Exception, 1, retries)

if __name__ == '__main__':
    test_FileDownloader_report_retry()


# Generated at 2022-06-22 06:46:46.601550
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    fd = FileDownloader(DummyYoutubeDL())
    # Multiples of kilo- and mega-
    assert fd.format_speed(8) == '       8b/s'
    assert fd.format_speed(1024) == '    1.0Kb/s'
    assert fd.format_speed(2048) == '    2.0Kb/s'
    assert fd.format_speed(1536 * 1024) == '    1.5Mb/s'
    assert fd.format_speed(2.0 * 1024 * 1024) == '    2.0Mb/s'
    assert fd.format_speed(1.234567891 * 1024 * 1024) == '  1.23Mb/s'

# Generated at 2022-06-22 06:46:56.043303
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def test(seconds, expected):
        result = FileDownloader.format_seconds(seconds)
        if result != expected:
            raise ValueError('Expected %r but got %r' % (expected, result))
    # Test seconds
    test(15, '00:15')
    test(165, '02:45')
    test(3615, '1:00:15')
    test(86400, '24:00:00')
    # Test float seconds
    test(18.8, '00:18')
    test(165.9, '02:45')
    test(3615.9, '1:00:15')
    test(86400.9, '24:00:00')
    # Additional tests
    test(3601, '1:00:01')
    test(60, '01:00')

# Generated at 2022-06-22 06:47:00.810620
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    # Create a FileDownloader
    fd = FileDownloader(YoutubeDL(), {})
    # Call method report_retry
    fd.report_retry(HTTPError(None,None,None,None,None),1,3)
    

# Generated at 2022-06-22 06:47:07.160011
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    bad_sample = devnull()
    bad_sample.close()
    bad_sample_descriptor = bad_sample.fileno()
    fd = FileDownloader(FakeYDL(), {})
    fd.to_screen = lambda x: None
    fd.trouble(u'ERROR: foobar')
    fd.trouble(u'ERROR: bad sample: Unspecified sample error')
    fd.trouble(u'ERROR: bad sample2: sample error %d' % bad_sample_descriptor)



# Generated at 2022-06-22 06:47:12.937148
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    ydl = YoutubeDL({})
    fd = FileDownloader({'quiet': True}, ydl)
    fd.report_error('foo')
    fd.report_warning('bar')
    fd.report_error('%s', 'baz')
    fd.report_warning('%s', '1')


if __name__ == '__main__':
    test_FileDownloader_trouble()

# Generated at 2022-06-22 06:47:17.725940
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    
    # Create a new object downloader
    downloader = FileDownloader(None, {})

    # Test if the write of the warning is right
    downloader.report_warning('test') == 'WARNING: test\n'



# Generated at 2022-06-22 06:47:28.255934
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    class YDL:
        params = {}
        def to_screen(self, *args, **kargs):
            print(args, kargs)
        def to_console_title(self, *args, **kargs):
            pass
        def trouble(self, *args, **kargs):
            print(args, kargs)
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
    ydl = YDL()
    fd = FileDownloader(ydl, {'outtmpl': '%(id)s'})
    assert_equals(fd.ydl, ydl)

# Generated at 2022-06-22 06:47:53.391284
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    # A fake download process that sleeps before finishing.
    def real_download(filename, info_dict):
        time.sleep(1)
        return True

    # Create an instance of FileDownloader that uses `real_download` as
    # `real_download` method.
    fd = FileDownloader(object(), {}, {}, {})
    fd.real_download = real_download

    # Download to a file
    assert fd.download(os.path.join(os.path.dirname(__file__), '__test__'), {}) is True

    # Download to a file handle
    with io.open(os.path.join(os.path.dirname(__file__), '__test__'), 'wb') as fh:
        assert fd.download(fh, {}) is True

# Generated at 2022-06-22 06:47:54.107174
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    pass


# Generated at 2022-06-22 06:48:03.940518
# Unit test for method trouble of class FileDownloader
def test_FileDownloader_trouble():
    downloader = FileDownloader(FakeYDL())

# Generated at 2022-06-22 06:48:11.514904
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    ydl = YoutubeDL()
    ydl.params['retries'] = 10
    ydl.params['nooverwrites'] = False
    fd = FileDownloader(ydl, {}, None)
    fd.report_retry(socket.error(), 1, 10)
    fd.report_retry(socket.error(), 10, 10)
    fd.report_retry(socket.error(), 10, float('inf'))
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report_retry()
test_FileDownloader_report

# Generated at 2022-06-22 06:48:15.138759
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import doctest
    doctest.testmod(FileDownloader, verbose=True)

if __name__ == '__main__':
    test_FileDownloader_report_progress()

# Generated at 2022-06-22 06:48:20.129522
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # These values are taken from GNU Wget 1.17.1
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1m') == 1048576
    assert FileDownloader.parse_bytes('1M') == 1048576
    assert FileDownloader.parse_bytes('1g') == 1073741824
    assert FileDownloader.parse_bytes('1G') == 1073741824
    assert FileDownloader.parse_bytes('1x') is None
    assert FileDownloader.parse_bytes('1kx') is None
    assert FileDownloader.parse_bytes('1.2') == 1

# Generated at 2022-06-22 06:48:23.631370
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    fd = FileDownloader({'nooverwrites': False}, None)
    fd.to_screen('test_message')



# Generated at 2022-06-22 06:48:28.074119
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(0.1) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(3) == '3'


# Generated at 2022-06-22 06:48:39.119899
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader({}, ydl, {})

#class FragmentDownloader(FileDownloader):
#    """
#    A downloader that picks up fragments at the given times
#    """
#
#    def real_download(self, filename, info_dict):
#        """Download the video to a temporary file and then copy it
#        to filename if everything went alright"""
#        # Pick up all the fragments
#        fragment_filenames = []
#        for t in self.params['fragment_times']:
#            fragment_filename = self.temp_name(filename)
#            fragment_filenames.append(fragment_filename)
#            retval = self.download_fragment(t, fragment_

# Generated at 2022-06-22 06:48:43.349764
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    from ydl.downloader.common import FileDownloader
    # Create a FileDownloader instance
    fd = FileDownloader()
    # Testing of report_destination method
    fd.report_destination('file.mp4')
