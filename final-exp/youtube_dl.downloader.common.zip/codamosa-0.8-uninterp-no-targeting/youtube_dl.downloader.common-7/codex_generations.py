

# Generated at 2022-06-22 06:40:09.421580
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    """format_seconds test"""

    fd = FileDownloader(None, None)

    def _test_fc(seconds, expected):
        assert fd.format_seconds(seconds) == expected

    # Examples taken from http://en.wikipedia.org/wiki/ISO_8601#Durations
    _test_fc(0, '0:00:00')
    _test_fc(3, '0:00:03')
    _test_fc(61, '0:01:01')
    _test_fc(60*60, '1:00:00')
    _test_fc(60*61, '1:01:00')
    _test_fc(60*60*24 + 3, '24:00:03')
    _test_fc(60*60*25 + 3, '1d 1:00:03')

# Generated at 2022-06-22 06:40:16.027067
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time

    fd = FileDownloader({'ratelimit': 44032})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 1)
    time.sleep(1)
    fd.slow_down(start_time, start_time + 1, 2)
    time.sleep(1)
    fd.slow_down(start_time, time.time() + 2, 4)
    time.sleep(1)
    fd.slow_down(start_time, time.time() + 3, 8)
    time.sleep(1)
    fd.slow_down(start_time, time.time() + 4, 16)
    time.sleep(1)
    fd.slow_down(start_time, time.time() + 5, 32)
   

# Generated at 2022-06-22 06:40:27.330014
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test cases are tuples of (value, current, total, start, now, expected)
    valid_test_cases = [
        (0, 100, 500, 1.0, 2.0, 200.0),
        (0.5, 100, 500, 1.0, 2.0, 400.0),
        (100, 100, 500, 1.0, 2.0, 0.0),
        (100, 200, 500, 1.0, 2.0, 100.0),
        (100, 500, 500, 1.0, 2.0, None),
        (100, 0, 500, 1.0, 2.0, None),
        (0, 100, 500, 1.0, 0.0, None)
    ]


# Generated at 2022-06-22 06:40:38.093184
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    import pytest
    for i in range(100):
        assert FileDownloader.format_percent(i) == '%3d%%' % i
    assert FileDownloader.format_percent(1.1) == '  1%'
    assert FileDownloader.format_percent(1.1, 0) == '  1%'
    assert FileDownloader.format_percent(1.1, 1) == '1.1%'
    assert FileDownloader.format_percent(1.123) == '  1%'
    assert FileDownloader.format_percent(1.123, 2) == '1.12%'
    with pytest.raises(ValueError):
        FileDownloader.format_percent(1.123, 3)

# Generated at 2022-06-22 06:40:50.816705
# Unit test for method report_warning of class FileDownloader
def test_FileDownloader_report_warning():
    import logging
    import unittest
    import unittest.mock

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_called = 0

        def to_screen(self, msg):
            self.to_screen_called += 1

    fd = FileDownloader({}, FakeYDL())
    fd.report_warning('msg1')
    fd.report_warning('msg2')

    # warning: no handler found for a logger
    if 'warning' not in logging.root.manager.loggerDict:
        return

    # check if warning logger was called
    called = 0
    for cd in logging.root.manager.loggerDict['warning']:
        if isinstance(cd, unittest.mock._Call):
            called += 1
    assert called

# Generated at 2022-06-22 06:40:54.886260
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    FD = FileDownloader(None)
    FD.params = {
        'retries': 5
    }
    assert(FD.format_retries(float('inf')) == 'inf')
    assert(FD.format_retries(1) == '1.0')



# Generated at 2022-06-22 06:40:56.548631
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    assert_raises(NotImplementedError, FileDownloader.report_unable_to_resume, '')


# Generated at 2022-06-22 06:41:07.219908
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    # Test error message to stderr
    from youtube_dl.YoutubeDL import YoutubeDL
    from io import StringIO
    import sys

    log_buffer = StringIO()
    # Redirect stderr to a string buffer
    sys.stderr = log_buffer
    # Generate an error message
    FileDownloader(YoutubeDL()).report_error("test error message")
    # Restore stderr
    sys.stderr = sys.__stderr__

    assert "ERROR: test error message" in log_buffer.getvalue(), \
        'error message not found in stderr'


if __name__ == '__main__':
    test_FileDownloader_report_error()
    print('FileDownloader tests succeeded!')

# Generated at 2022-06-22 06:41:14.424111
# Unit test for method real_download of class FileDownloader
def test_FileDownloader_real_download():
    fd = FileDownloader()
    fd.params = {}
    fd.report_progress = lambda *args, **kargs : None
    fd.to_screen = lambda *args, **kargs : None

    try:
        fd.real_download('/non/existing/path/if-you-are/lucky', {})
    except NotImplementedError:
        return
    assert False # real_download method of FileDownloader must raise an exception


# Generated at 2022-06-22 06:41:22.784685
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader(None)

    eq_(fd.format_seconds(0), '0:00')
    eq_(fd.format_seconds(1), '0:01')
    eq_(fd.format_seconds(60), '1:00')
    eq_(fd.format_seconds(61), '1:01')
    eq_(fd.format_seconds(3600), '1:00:00')
    eq_(fd.format_seconds(3601), '1:00:01')
    eq_(fd.format_seconds(3661), '1:01:01')



# Generated at 2022-06-22 06:41:47.000671
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    # Test try_rename method
    fd = FileDownloader({})
    fd.report_error = lambda *args, **kargs : None

    if not os.path.exists('test'):
        os.mkdir('test')
    else:
        # Remove garbage
        if os.path.exists('test/try_rename1'):
            os.remove('test/try_rename1')
        if os.path.exists('test/try_rename2'):
            os.remove('test/try_rename2')
        if os.path.exists('test/try_rename3'):
            os.remove('test/try_rename3')

# Generated at 2022-06-22 06:42:00.917821
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '00:00'
    assert FileDownloader.format_seconds(1.1) == '01:01'
    assert FileDownloader.format_seconds(1.11) == '01:01'
    assert FileDownloader.format_seconds(11.1) == '11:01'
    assert FileDownloader.format_seconds(61) == '01:01:01'
    assert FileDownloader.format_seconds(3661) == '01:01:01:01'
    assert FileDownloader.format_seconds(None) == '--:--'
    assert FileDownloader.format_seconds('abc') == '--:--'
    assert FileDownloader.format_seconds(['a', 'b']) == '--:--'

# Generated at 2022-06-22 06:42:13.225957
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # This test does not use assertTrue and assertEqual because nose will
    # report that the tests have no lines executed.
    fd = FileDownloader({'continuedl': True})
    info_dict = {'ext': 'mp4'}
    nf = fd.temp_name('a')
    assert nf == 'a.part'
    nf = fd.undo_temp_name('a.part')
    assert nf == 'a'
    nf = fd.temp_name('a')
    assert nf == 'a.part'
    nf = fd.undo_temp_name('a.part')
    assert nf == 'a'
    nf = fd.temp_name('a.part')
    assert nf == 'a.part'

    assert fd.format_seconds

# Generated at 2022-06-22 06:42:24.348946
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert '100.0%' == FileDownloader.format_percent(1.0)
    assert '100%' == FileDownloader.format_percent(1.0)
    assert '100%' == FileDownloader.format_percent(1)
    assert '0%' == FileDownloader.format_percent(0)
    assert '0.0%' == FileDownloader.format_percent(0.0)
    assert '0' == FileDownloader.format_percent(0)
    assert '0.00%' == FileDownloader.format_percent(0, 2)
    assert '0.12345' == FileDownloader.format_percent(0.12345)
    assert '0.12%' == FileDownloader.format_percent(0.12345, 2)
    assert '1.23%' == FileDownloader

# Generated at 2022-06-22 06:42:36.723622
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    from ytdl.extractor import _ALL_CLASSES
    for cls in _ALL_CLASSES():
        print(cls.IE_NAME)
        for downloader in cls._downloader_classes:
            d = downloader()
            assert d.format_percent(0) == '0%'
            assert d.format_percent(0.0) == '0%'
            assert d.format_percent(0.01) == '0%'
            assert d.format_percent(0.09999) == '1%'
            assert d.format_percent(0.1) == '1%'
            assert d.format_percent(0.1099) == '11%'
            assert d.format_percent(0.11) == '11%'

# Generated at 2022-06-22 06:42:44.722527
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(1) == '00:01'
    assert FileDownloader.format_eta(10) == '00:10'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(70) == '01:10'
    assert FileDownloader.format_eta(3603) == '01:00:03'
    assert FileDownloader.format_eta(3661) == '01:01:01'

# Generated at 2022-06-22 06:42:56.238225
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import os
    import shutil
    import tempfile
    from youtube_dl.utils import encodeFilename

    tmpdir = tempfile.mkdtemp()

    # Test temp_name with a file that doesn't exist
    fname = 'example.txt'
    fd = FileDownloader({'nopart': True, 'outtmpl': os.path.join(tmpdir, fname)})
    assert fd.temp_name(fname) == fname

    # Test temp_name with a file that exists
    fname = 'example.txt'
    fpath = os.path.join(tmpdir, fname)
    open(encodeFilename(fpath), 'a').close()
    fd = FileDownloader({'nopart': True, 'outtmpl': fpath})

# Generated at 2022-06-22 06:43:05.039843
# Unit test for method report_retry of class FileDownloader
def test_FileDownloader_report_retry():
    class FakeYdl:
        def __init__(self):
            self.errorToScreen=[]
            self.errorToStderr=[]
        
        def to_screen(self, msg):
            self.errorToScreen.append(msg)
        
        def to_stderr(self, msg):
            self.errorToStderr.append(msg)
            
    def test(err, count, retries):
        ydl = FakeYdl()
        fd = FileDownloader(ydl, {'verbose':True})
        t1 = (
            '[debug] HTTP Error 522: Origin Connection Time-out\n'
            '[download] Got server HTTP error: Origin Connection Time-out. Retrying (attempt 1 of inf)...\n')
        

# Generated at 2022-06-22 06:43:10.222001
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    with open('stderr.txt', 'w', encoding='utf8') as f:
        ydl = FakeYoutubeDL({})
        fd = FileDownloader(ydl, {'verbose': True})
        fd.to_stderr('hello')
        assert 'hello' in f.read()

# Generated at 2022-06-22 06:43:15.874274
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-22 06:43:35.045754
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time

    class MockTime(object):
        def __init__(self):
            self._i = 0

        def time(self):
            self._i += 1
            return self._i

    class MockRandom(object):
        def uniform(self, _min, _max):
            return 0.5

    time_mock = MockTime()
    random_mock = MockRandom()

    fd = FileDownloader(YoutubeDL())
    fd.ratelimit_tmp_bytes = None


# Generated at 2022-06-22 06:43:47.469049
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    # Test fill up integer
    assert FileDownloader.format_percent(1) == '   1%'
    assert FileDownloader.format_percent(10) == '  10%'
    assert FileDownloader.format_percent(100) == ' 100%'
    assert FileDownloader.format_percent(1000) == '1000%'
    # Test fill up float
    assert FileDownloader.format_percent(0.1) == '  0.1%'
    assert FileDownloader.format_percent(1.1) == '  1.1%'
    assert FileDownloader.format_percent(10.1) == ' 10.1%'
    assert FileDownloader.format_percent(100.1) == '100.1%'

# Generated at 2022-06-22 06:43:59.333129
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    result1 = FileDownloader.undo_temp_name('/tmp/file.tmp')
    expect1 = '/tmp/file'
    assert result1 == expect1, 'FileDownloader.undo_temp_name(%s) returns %s but %s expected' % (
        '/tmp/file.tmp', repr(result1), repr(expect1))

    result2 = FileDownloader.undo_temp_name('/tmp/file')
    expect2 = '/tmp/file'
    assert result2 == expect2, 'FileDownloader.undo_temp_name(%s) returns %s but %s expected' % (
        '/tmp/file.tmp', repr(result2), repr(expect2))

    result3 = FileDownloader.undo_temp_name('/tmp/file.part')
    expect3 = '/tmp/file'

# Generated at 2022-06-22 06:44:01.968823
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    fd = FileDownloader()
    percent = fd.format_percent(100)
    assert percent == "\033[1;32m100%\033[0m"


# Generated at 2022-06-22 06:44:12.164248
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFD(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kwargs):
            print(args)

    fd = TestFD()
    fd.params['noprogress'] = False
    fd.params['progress_with_newline'] = False
    fd.params['ratelimit'] = 123

    dl = FileDownloader(fd, {})

    dl.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })

    dl.report_progress({
        'status': 'finished',
        'total_bytes': 1,
        'elapsed': 12,
        'downloaded_bytes': 0,
    })


# Generated at 2022-06-22 06:44:23.525984
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader({})
    assert fd.format_seconds(0) == '0:00'
    assert fd.format_seconds(1) == '0:01'
    assert fd.format_seconds(9) == '0:09'
    assert fd.format_seconds(10) == '0:10'
    assert fd.format_seconds(59) == '0:59'
    assert fd.format_seconds(60) == '1:00'
    assert fd.format_seconds(61) == '1:01'
    assert fd.format_seconds(62) == '1:02'
    assert fd.format_seconds(3599) == '59:59'
    assert fd.format_seconds(3600) == '60:00'

    fd = FileDownloader

# Generated at 2022-06-22 06:44:26.832415
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    filename = tempfile.mkstemp()[1]
    try:
        s = FileDownloader({})
        last_modified_hdr = time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(os.path.getmtime(filename)))
        assert s.try_utime(filename, last_modified_hdr) == os.path.getmtime(filename)
    finally:
        os.remove(filename)

# Generated at 2022-06-22 06:44:30.758212
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    import tempfile
    fd = FileDownloader(FakeYoutubeDL({}))
    fd.to_screen = lambda *args, **kwargs: None
    fd.report_destination(tempfile.mktemp())


# Generated at 2022-06-22 06:44:32.984659
# Unit test for method to_screen of class FileDownloader
def test_FileDownloader_to_screen():
    ydl = fake_ydl()
    dl = FileDownloader(ydl, {})
    def to_screen(msg):
        assert msg == 'Test Message'
    dl.to_screen = to_screen
    dl.to_screen('Test Message')


# Generated at 2022-06-22 06:44:43.706614
# Unit test for method undo_temp_name of class FileDownloader

# Generated at 2022-06-22 06:45:29.317124
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    import unittest
    class MockYoutubeDL:
        def to_screen(self, msg):
            print(msg)
    # Wrapper class for youtube-dl
    class MockYoutubeDLWrapper:
        def __init__(self, ydl):
            self.ydl = ydl

# Generated at 2022-06-22 06:45:35.556093
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Various tests to check the good behavior of method best_block_size of
    # class FileDownloader
    fd = FileDownloader(None, params={})
    assert fd.best_block_size(1000, 500*1024) == 262144
    assert fd.best_block_size(1000, 1024) == 512
    assert fd.best_block_size(1000, 1025) == 512
    assert fd.best_block_size(1000, 1023) == 512



# Generated at 2022-06-22 06:45:42.369186
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    print('Calculating % progress based on filesize')
    print('========================================')
    for size in (10, 100, 1000, 10000, 100000, 1000000, 10000000):
        for bytes in (0, 5, 10, size//2, size-1, size, size+1, 2*size, 2**32-1, 2**32):
            print('%8d of %8d bytes => %d%%' % (bytes, size, FileDownloader.calc_percent(bytes, size)))

# Generated at 2022-06-22 06:45:47.293803
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import unittest
    from collections import namedtuple

    Fdl = namedtuple('Fdl', ['params'])
    fdl = Fdl({'ratelimit': 512})

    class FakeTime(object):
        def __init__(self):
            self._calls = 0

        def time(self):
            self._calls += 1
            return self._calls

    ft = FakeTime()

    def time_sleep_mock(t):
        ft.time()  # Call time() to update the mock time
        assert t == 0.003  # The sleep time should be 3ms

    class FakeThread(object):
        @staticmethod
        def name():
            return 'test_thread'

    # We mock time.sleep and threading.currentThread() to avoid sleeping
    # during the test
    old_ts = time

# Generated at 2022-06-22 06:45:55.737023
# Unit test for constructor of class FileDownloader
def test_FileDownloader():
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.params['continuedl'] = True
    ydl.params['noprogress'] = True

    fd = FileDownloader(ydl, {'id': 'test'}, {})

    assert fd.params['noprogress'] == True

    assert fd.reporthook.__name__ == 'reporthook'
    assert fd.reporthook.__self__ == fd

    assert fd.to_screen == fd.ydl.to_screen
    assert fd.to_stderr == fd.ydl.to_stderr
    assert fd.to_console_title == fd.ydl.to_console_title

# Generated at 2022-06-22 06:46:06.238976
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader('http://example.com')
    fd.params.update({
        'noprogress': True,
        'retries': 0,
    })

    def urlopen(*args, **kwargs):
        return io.BytesIO(b'\x00\x00\x00\x00\x00')

    fd.ydl._get_best_url_handle = urlopen

    retry = 2
    for d in range(1, 4):
        start_time = time.time()

# Generated at 2022-06-22 06:46:08.155161
# Unit test for method report_resuming_byte of class FileDownloader
def test_FileDownloader_report_resuming_byte():
    a = FileDownloader()
    a.to_screen = lambda x : None
    a.report_resuming_byte('')


# Generated at 2022-06-22 06:46:20.029973
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: Test with byte_counter == 0
    fd = FileDownloader(None, {})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    assert time.time() - start_time < 0.1

    # Test 2: Test with byte_counter != 0 and elapsed < 1 millisecond
    fd = FileDownloader(None, {})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 5)
    assert time.time() - start_time < 0.1

    # Test 3: Test with byte_counter != 0, elapsed > 1 millisecond,
    #         rate < low rate limit, increase sleep_time
    fd = FileDownloader(None, {'ratelimit': 10})
   

# Generated at 2022-06-22 06:46:31.103932
# Unit test for method report_destination of class FileDownloader
def test_FileDownloader_report_destination():
    """
    A whitelist test for method report_destination of FileDownloader class
    Input here is the desired output, and the function is expected to pass the test if
    output is the same as the input.
    """
    fd = FileDownloader()
    out = fd.report_destination('/home/mememaster/viacom.mp4')
    assert(out == '[download] Destination: /home/mememaster/viacom.mp4')
    out = fd.report_destination('trump.mp4')
    assert(out == '[download] Destination: trump.mp4')
    out = fd.report_destination('/home/mememaster/trump.mp4')
    assert(out == '[download] Destination: /home/mememaster/trump.mp4')
    out = fd.report

# Generated at 2022-06-22 06:46:36.108761
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    ydl=YoutubeDL()
    param={'logger': ydl}
    fd=FileDownloader(param)
    fd.to_stderr("success")
    print("test_FileDownloader_to_stderr test is pass")
    

# Generated at 2022-06-22 06:47:11.831154
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1.5) == '2'



# Generated at 2022-06-22 06:47:15.364005
# Unit test for method ytdl_filename of class FileDownloader
def test_FileDownloader_ytdl_filename():
    filename = 'def.mp4'
    assert FileDownloader(FakeYDL()).ytdl_filename(filename) == filename + '.ytdl'
import os


# Generated at 2022-06-22 06:47:26.730455
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def my_hook(status):
        assert status['status'] == 'finished'
        assert status['total_bytes'] == os.path.getsize(filename)

    filename = 'test_file.tmp'
    info_dict = {
        'id': 'video_id',
    }

    # In case of errors the temporary file should be cleaned
    def remove_temp_file(exception):
        if os.path.isfile(filename):
            os.remove(filename)

    request.addfinalizer(remove_temp_file)

    file_data = os.urandom(10)
    with open(filename, 'wb') as stream:
        stream.write(file_data)

    fd = FileDownloader('test_url', None, None)
    fd.add_progress_hook(my_hook)


# Generated at 2022-06-22 06:47:36.014144
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def test(msg, expected):
        fd._report_progress_status(msg)
        assert os.linesep.join(fd.ydl.msgs) == expected
        fd.ydl.msgs = []

    fd = FileDownloader(
        params={'noprogress': False, 'ratelimit': None, 'nopart': False})
    # Test progress with newline
    fd.params['progress_with_newline'] = True
    test(msg='[download] blah blah blah',
         expected='[download] blah blah blah')
    test(msg='[download] blah blah blah\r',
         expected='')

# Generated at 2022-06-22 06:47:41.065896
# Unit test for method report_error of class FileDownloader
def test_FileDownloader_report_error():
    f = FileDownloader(YoutubeDL(), {})
    # Test in quiet mode
    f.params['quiet'] = True
    # Test with error message
    f.report_error('an error message')
    # Test with exception
    try:
        raise Exception('something went wrong')
    except Exception as exception:
        f.report_error(exception)

# Generated at 2022-06-22 06:47:50.395816
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('42') == 42
    assert FileDownloader.parse_bytes('42b') == 42
    assert FileDownloader.parse_bytes('42k') == 43008
    assert FileDownloader.parse_bytes('42K') == 43008
    assert FileDownloader.parse_bytes('42m') == 44040192
    assert FileDownloader.parse_bytes('42M') == 44040192
    assert FileDownloader.parse_bytes('42g') == 452984832
    assert FileDownloader.parse_bytes('42G') == 452984832

    assert FileDownloader.parse_bytes('1t') == 1099511627776
    assert FileDownloader.parse_bytes('1T') == 1099511627776
    assert FileDownloader.parse_bytes('1p') == 11258999068426

# Generated at 2022-06-22 06:47:53.882249
# Unit test for method to_stderr of class FileDownloader
def test_FileDownloader_to_stderr():
    fd = FileDownloader()
    fd.params['verbose'] = True
    fd.to_stderr('test string')

# Generated at 2022-06-22 06:48:03.177958
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None)

    assert fd.parse_bytes('10') == 10
    assert fd.parse_bytes('10.5') == 10
    assert fd.parse_bytes('10.5k') == 10 * 1024 + 512
    assert fd.parse_bytes('10.9k') == 10 * 1024 + 1024 * 0.9
    assert fd.parse_bytes('10.5M') == 10 * 1024 * 1024 + 512 * 1024
    assert fd.parse_bytes('10.5G') == 10 * 1024 * 1024 * 1024 + 512 * 1024 * 1024
    assert fd.parse_bytes('1T') == 1024 * 1024 * 1024 * 1024

    assert fd.parse_bytes('10a') is None



# Generated at 2022-06-22 06:48:06.642733
# Unit test for method report_unable_to_resume of class FileDownloader
def test_FileDownloader_report_unable_to_resume():
    downloader = FileDownloader(FakeYDL())
    downloader.report_unable_to_resume()
    assert downloader.ydl.msgs[-1] == '[download] Unable to resume'


# Generated at 2022-06-22 06:48:18.043495
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(0) == '0:00'
    assert FileDownloader.format_eta(1) == '0:01'
    assert FileDownloader.format_eta(59) == '0:59'
    assert FileDownloader.format_eta(60) == '1:00'
    assert FileDownloader.format_eta(61) == '1:01'
    assert FileDownloader.format_eta(3599) == '59:59'
    assert FileDownloader.format_eta(3600) == '1:00:00'
    assert FileDownloader.format_eta(3601) == '1:00:01'
    assert FileDownloader.format_eta(36000) == '10:00:00'

