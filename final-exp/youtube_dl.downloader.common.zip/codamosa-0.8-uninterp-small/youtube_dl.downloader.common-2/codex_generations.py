

# Generated at 2022-06-26 11:03:26.588157
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    str_0 = '*_$yjY>%V`f`#1-7'
    str_1 = '#)5 |9&O7'
    str_2 = '%Mw+g;uG7'
    tuple_0 = (str_0, )
    tuple_1 = (str_1, )
    tuple_2 = (str_2, str_2)
    fd = FileDownloader(tuple_0, tuple_1)
    fd.try_rename(tuple_2[0], tuple_2[1])
    print(tuple_2[0])
    print(tuple_2[1])


# Generated at 2022-06-26 11:03:29.944381
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    data = 'test1'
    expected = 'test1.part'
    actual = FileDownloader.temp_name(data)
    if actual != expected:
        raise AssertionError(actual)


# Generated at 2022-06-26 11:03:34.770779
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time

    # Test with 3 extensions
    time.sleep(0.05)
    time.sleep(0.05)
    time.sleep(0.05)


# Generated at 2022-06-26 11:03:41.765856
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    str_0 = ';,dW.{>B!q;f/07'
    tuple_0 = (str_0,)
    file_downloader_0 = FileDownloader(tuple_0, tuple_0)
    long_0 = 0
    long_1 = file_downloader_0.best_block_size(long_0, long_0)
    assert long_1 == 1


# Generated at 2022-06-26 11:03:47.089704
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = ';,dW.{>B!q;f/07'
    tuple_0 = (str_0,)
    file_downloader_0 = FileDownloader(tuple_0, tuple_0)
    str_1 = 'Thu, 07 Jul 2016 15:18:01 GMT'
    file_downloader_0.try_utime('filename', str_1)


# Generated at 2022-06-26 11:03:53.105343
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = 'D~P[5M_y'
    tuple_0 = (str_0,)
    file_downloader_0 = FileDownloader(tuple_0, tuple_0)
    file_name_0 = ','
    must_be_0 = ','
    real_0 = file_downloader_0.temp_name(file_name_0)
    assert must_be_0 == real_0


# Generated at 2022-06-26 11:04:07.009656
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import StringIO
    from collections import namedtuple

    s = namedtuple('s', 'status filename eta total_bytes downloaded_bytes speed')('downloading', 'file', None, None, None, None)
    file_downloader_0 = FileDownloader('/', '/')
    file_downloader_0._report_progress_status = lambda x: None
    file_downloader_0.to_screen = lambda x: None
    file_downloader_0._report_progress(s)

    s = namedtuple('s', 'status filename eta total_bytes downloaded_bytes speed')('downloading', 'file', None, None, 0, None)
    file_downloader_0 = FileDownloader('/', '/')
    file_downloader_0._report_progress_status = lambda x: None
    file_downloader_

# Generated at 2022-06-26 11:04:18.467935
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test with the mock value of -1
    file_downloader_0 = FileDownloader({}, {'nopart': -1})
    str_0 = 'test_value'
    assert file_downloader_0.undo_temp_name(str_0) == str_0

    # Test with the mock value of 0
    file_downloader_1 = FileDownloader({}, {'nopart': 0})
    str_0 = 'test_value'
    assert file_downloader_1.undo_temp_name(str_0) == str_0

    # Test with the mock value of 1
    file_downloader_2 = FileDownloader({}, {'nopart': 1})
    str_0 = 'test_value'

# Generated at 2022-06-26 11:04:25.574518
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    result = ydl.extract_info(url, download=False)
    ydl.process_info(result)

    urlhandle = urlopen(url)
    url_content = urlhandle.read()

    if hasattr(url_content, 'decode'):
        url_content_decoded = url_content.decode('utf-8')
        test_case_0()
    else:
        print('test_case_0()')

test_FileDownloader_download()

# Generated at 2022-06-26 11:04:31.410466
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = '{`:Z`VoI'
    str_1 = 'Q{[j '
    tuple_0 = (str_0, str_1)
    tuple_1 = (tuple_0,)
    file_downloader_0 = FileDownloader(tuple_1, tuple_1)
    file_downloader_0.report_file_already_downloaded(str_1)


# Generated at 2022-06-26 11:04:54.602193
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    float_0 = 0.05
    float_1 = 0.49
    float_2 = 0.4
    float_3 = 0.99
    float_4 = 0.8
    float_5 = 0.01
    int_0 = 4194304
    int_1 = 1
    int_2 = 1
    float_6 = 0.91
    int_3 = 1024
    float_7 = 0.6
    int_4 = 1024
    float_8 = 0.3
    int_5 = 1024
    float_9 = 0.5
    int_6 = 1024
    float_10 = 0.2
    int_7 = 1024
    float_11 = 0.1
    int_8 = 1024
    float_12 = 0.0
    int_9 = 1024


# Generated at 2022-06-26 11:04:57.853612
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    # Test 0
    test_FileDownloader_report_progress_0(FileDownloader())

# Based on the test case: 0

# Generated at 2022-06-26 11:05:04.770699
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()
    float_24 = float()

# Generated at 2022-06-26 11:05:09.490232
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader()
    file_downloader_0.try_utime(str(float_0 * 0.15), str('mid') + str(float_0 * 0.15) + str('2007'))


# Generated at 2022-06-26 11:05:14.126492
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    file_downloader_0 = FileDownloader(None, None)
    assert file_downloader_0.undo_temp_name("h.part") == "h"



# Generated at 2022-06-26 11:05:21.098820
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    file_downloader_0 = FileDownloader(5.5, '/home/agroce/workspace/youtube-dl/youtube_dl/ytdl.py')
    file_downloader_0.best_block_size(test_case_0(), 2.0);

if __name__ == '__main__':
    test_FileDownloader_best_block_size()

# Generated at 2022-06-26 11:05:25.300888
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # test case 0
    fd = FileDownloader()
    assert fd.format_seconds(0.05) == '0.1'



# Generated at 2022-06-26 11:05:29.655343
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = None
    input, output = StringIO(), StringIO()

    # Case 0
    test_case_0()

    return ydl



# Generated at 2022-06-26 11:05:35.635135
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    s = {}
    s['status'] = 'finished'
    FileDownloader.report_progress(s)

    s['status'] = 'downloading'

    s['eta'] = 5
    s['total_bytes'] = 10
    FileDownloader.report_progress(s)


# Generated at 2022-06-26 11:05:41.007869
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader("", {}, 0)
    test_elapsed_time = float_0
    test_bytes = int_0
    fd.best_block_size(test_elapsed_time, test_bytes)


# Generated at 2022-06-26 11:05:54.586498
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert 'filename.part' == FileDownloader.temp_name('filename')
    assert 'filename' == FileDownloader.temp_name('filename.part')
    assert '-' == FileDownloader.temp_name('-')
    assert '--' == FileDownloader.temp_name('--')
    assert '-' == FileDownloader.temp_name('-', False)


# Generated at 2022-06-26 11:05:57.882722
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader()
    fd.slow_down( float_0, float_0, float_0)


# Generated at 2022-06-26 11:06:08.647620
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    out = []
    def my_hook(d):
        out.append(d)
    test_factory = YoutubeDL(params={'verbose': True, 'forcejson': True})
    test_factory.add_progress_hook(my_hook)
    test_downloader = FileDownloader(test_factory, params={'noprogress': False})
    test_filename = None
    test_info_dict = {
        'id': '123456789',
        'title': 'Foo Bar',
        'ext': 'mp4',
        'url': 'http://example.com/foo.bar',
        'thumbnail': 'http://example.com/foo.bar.jpg',
    }

# Generated at 2022-06-26 11:06:11.558271
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    FileDownloader.try_utime(float_0, float_0)


# Generated at 2022-06-26 11:06:16.874725
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test for float_0 = 0.05
    res_FileDownloader, rate_limit_FileDownloader, sleep_time_FileDownloader = FileDownloader.slow_down(1568627462642, 1568627462642, 5)

# Generated at 2022-06-26 11:06:30.752607
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    float_0 = 0.02
    float_1 = 0.01
    float_2 = 0.04
    float_3 = 0.03
    float_4 = 0.06
    float_5 = 0.07
    float_6 = 5.0
    float_7 = 0.001
    float_8 = 0.005
    float_9 = 0.009
    float_10 = 0.008
    float_11 = 0.006
    string_0 = str(float_0)
    string_1 = str(float_1)
    string_2 = str(float_2)
    string_3 = str(float_3)
    string_4 = str(float_4)
    string_5 = str(float_5)
    string_6 = str(float_6)

# Generated at 2022-06-26 11:06:39.366992
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    curl = Curl()
    data = io.BytesIO(b'abcdef')
    dl = FileDownloader(curl, {}, {'outtmpl': '%(id)s', 'continuedl': True}, False, {})
    dl.report_destination('abcdef')
    try:
        dl.try_utime('abcdef', float_0)
    except:
        pass


# Generated at 2022-06-26 11:06:47.188494
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    global s
    global seconds
    global minutes
    global hours
    global days
    global weeks
    global years
    global remainder
    global years_str
    global weeks_str
    global days_str
    global hours_str
    global minutes_str
    global seconds_str
    global s_str
    global y_str
    global w_str
    global d_str
    global h_str

    s = float_0
    # build the expected output
    years = s / float(31536000)
    remainder = s % float(31536000)
    weeks = remainder / float(604800)
    remainder = s % float(604800)
    days = remainder / float(86400)
    remainder = s % float(86400)
    hours = remainder / float(3600)
    remainder = s % float

# Generated at 2022-06-26 11:06:51.986792
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    if should_throw_error:
        return

    downloader = FileDownloader()
    downloader.params = downloader.params
    downloader.to_screen = test_to_screen
    downloader.report_progress({
        'msg': '',
        'eta': '',
        'percent': 0.05,
        'speed': '',
        'size': '',
        'status': '',
        'name': ''
    })

# Generated at 2022-06-26 11:06:54.720345
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Set up test environment
    FileDownloader.slow_down(float_0, float_0, int_0)


# Generated at 2022-06-26 11:07:10.142971
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    print("Testing temp_name.")
    filename = "filename"
    file_downloader = FileDownloader(None, None, None)
    
    #This test case covers the following variables in the class:
    #params['nopart'] = False
    #params['noprogress'] = False
    #params['continue'] = False
    file_downloader.params['nopart'] = False
    file_downloader.params['noprogress'] = False
    file_downloader.params['continue'] = False
    #This test case checks for a case where the file name is a directory.
    if os.path.exists(encodeFilename(filename)) and not os.path.isfile(encodeFilename(filename)):
        assert file_downloader.temp_name(filename) == filename #Check if the temp name method returns the

# Generated at 2022-06-26 11:07:22.694896
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    global FileDownloader

    string_0 = "filename"
    FileDownloader.parameters.update({"nopart": False, "verbose": False})
    if (FileDownloader.temp_name(string_0) != string_0 + ".part"):
        raise RuntimeError("Return value of FileDownloader.temp_name(filename) is incorrect: expected: %s, actual: %s" % (string_0,  FileDownloader.temp_name(string_0)))
    FileDownloader.parameters.update({"nopart": True})

# Generated at 2022-06-26 11:07:28.893654
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    filename = '__test_case_0.test'
    params = {'nopart':False}
    test_downloader = FileDownloader({'test':'case'}, params, False)
    # call the temp_name method
    temp_name_return_value = test_downloader.temp_name(filename)

    assert_equals(temp_name_return_value, filename)
    
    

# Generated at 2022-06-26 11:07:30.974960
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()


# Generated at 2022-06-26 11:07:35.505963
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    dict_0 = {}
    dict_1 = {}
    file_downloader = FileDownloader(dict_0)
    file_downloader.real_download = test_case_0
    file_downloader.download('filename', dict_1)
    file_downloader.add_progress_hook(test_case_0)
test_FileDownloader_download()

# Generated at 2022-06-26 11:07:40.567948
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    print('Testing method try_utime of class FileDownloader')

    fileDownloader_0 = FileDownloader(MockYoutubeDL({}), {}, {'format':'256'})
    last_modified_hdr = 'Wed, 21 Oct 2015 07:28:00 GMT'
    filename = 'f4pIa.dll'
    fileDownloader_0.try_utime(filename, last_modified_hdr)


# Generated at 2022-06-26 11:07:51.944481
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    extensions = {'.mp4': 'video/mp4', '.webm': 'video/webm'}
    formats = {
        'mp4': {
            'format_id': 'mp4',
            'ext': 'mp4',
            'acodec': 'none'
        },
        'webm': {
            'format_id': 'webm',
            'ext': 'webm',
            'acodec': 'none'
        },
    }

    # Testing FileDownloader._available_formats
    ydl_0 = FileDownloader({})
    ydl_0.formats = formats
    res_0 = ydl_0._available_formats()

    # Testing FileDownloader._calc_expected_size
    total_size_0 = 0
    for it in res_0:
        total

# Generated at 2022-06-26 11:08:03.399831
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from builtins import range

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(0)

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(1)

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(2)

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(3)

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(4)

    # Call tested method with parameters
    fd = FileDownloader()
    fd.slow_down(5)


# Generated at 2022-06-26 11:08:06.240680
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    dl = FileDownloader({})
    dl.report_file_already_downloaded('filename')


if __name__ == '__main__':
    dl = FileDownloader({})
    test_FileDownloader_report_file_already_downloaded()
    test_FileDownloader()
    test_case_0()

# Generated at 2022-06-26 11:08:22.192025
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        pass
    f.close()
    try:
        temp_filename = f.name
    except AttributeError:
        temp_filename = f
    
    # Call the function to be tested
    last_modified_hdr = 'Thu, 22 Feb 2018 14:04:01 GMT'
    fd = FileDownloader({
        'outtmpl': temp_filename,
        'ratelimit': 20480,
    })
    fd.try_utime(temp_filename, last_modified_hdr)
    
    # Verify the result

# Generated at 2022-06-26 11:08:36.167014
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 0.05
    fd = FileDownloader(None,0)
    fd.slow_down(None, None, None)
    fd.slow_down(None, None, float_0)
    fd.slow_down(None, None, 0)
    fd.slow_down(None, None, -1)
    fd.slow_down(None, None, 1)
    fd.slow_down(None, None, -1 * float_0)
    fd.slow_down(None, None, 1 * float_0)


# Generated at 2022-06-26 11:08:42.503800
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = int(time.time())
    now = start_time + 1
    byte_counter = 1000
    rate_limit = 500
    expected = 0.5
    sleep_time = expected
    time.sleep(sleep_time)
    assert sleep_time == expected


# Generated at 2022-06-26 11:08:53.694789
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    print('Testing try_utime of FileDownloader')
    filename = 'FileDownloader.py'
    assert FileDownloader.try_utime(filename, None) == None
    assert FileDownloader.try_utime(filename, 1) == None
    assert FileDownloader.try_utime(filename, 'test_string') == None
    try:
        assert os.utime(filename, (time.time(), time.time())) == None
    except Exception:
        assert False
    print('Test successful')

# Generated at 2022-06-26 11:09:01.979552
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # A simple test case of code of method temp_name of class FileDownloader
    down_0 = FileDownloader()
    filename_0 = "The file name"
    filename_1 = down_0.temp_name(filename_0)
    filename_2 = down_0.temp_name(filename_0)
    if filename_1 != filename_2:
        return 1
    return 0


# Generated at 2022-06-26 11:09:04.495219
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
  # Test case 0
  print("Testing case 0...")
  d = FileDownloader("test input", None)
  test_case_0()


# Generated at 2022-06-26 11:09:14.192607
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # test number 0
    # case is_part=False
    # case filename='-'
    # case is_file='True'
    filename = '-'
    is_part = False

    # Create a new instance of FileDownloader
    fd = FileDownloader()

    # Call method temp_name with parameter filename
    result = fd.temp_name(filename)

    # Check returned value and compare it with expected result
    assert result == '-', "Returned value mismatch"


# Generated at 2022-06-26 11:09:19.081452
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    filename = None
    obj = FileDownloader(None)
    obj.report_file_already_downloaded(filename)
    del obj
    del filename


# Generated at 2022-06-26 11:09:24.532323
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    float_0 = 0.06
    string_0 = "Expected inf for infinite retries, but received inf"
    assert FileDownloader.format_retries(float_0) == "inf", string_0


# Generated at 2022-06-26 11:09:29.748011
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # float_0 = float('float')
    float_0 = float(0.05)
    float_1 = float(0.75)
    float_2 = float(0.9)

    # Test data used in a test case
    float_3 = float(0.25)
    float_4 = float(0.55)
    float_5 = float(0.85)
    float_6 = float(0.95)

    # Test data used in a test case
    float_7 = float(0.32)
    float_8 = float(0.67)

    # Test data used in a test case
    float_9 = float(0.41)
    float_10 = float(0.58)

    # Test data used in a test case
    float_11 = float(0.48)
    float_12

# Generated at 2022-06-26 11:09:39.634856
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # float 0.05 as input, expected '%.0f' % float 0.05
    float_0 = 0.05
    # float 0.04 as input, expected '%.0f' % float 0.04
    float_1 = 0.04
    # float 'inf' as input, expected 'inf'
    float_2 = 'inf'
    # float 'inf' as input, expected 'inf'
    float_3 = 'inf'
    # float 'inf' as input, expected 'inf'
    float_4 = 'inf'
    #float 0.04 as input, expected '%.0f' % float 0.04
    float_5 = 0.04
    #float 0.05 as input, expected '%.0f' % float 0.05
    float_6 = 0.05
    #float 0.06 as input, expected

# Generated at 2022-06-26 11:09:59.479286
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # initializing argument filename with value ''
    # initializing argument self with value <youtube_dl.FileDownloader object at 0x7fb6deee7dd8>
    filename = ''
    self = FileDownloader()
    # calling report_file_already_downloaded with arguments filename, self
    test_case_0()

# End of test for method report_file_already_downloaded of class FileDownloader


# Generated at 2022-06-26 11:10:10.923484
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_FileDownloader = FileDownloader()
    filename = 'file'
    test_FileDownloader.params['nopart'] = False
    test_FileDownloader.params['nooverwrites'] = False
    test_FileDownloader.params['continuedl'] = True
    test_FileDownloader.params['noprogress'] = False
    expected_out = filename + '.part'
    test_result_out = test_FileDownloader.temp_name(filename)
    assert test_result_out == expected_out, 'Expected: %s, Test Result: %s' % (expected_out, test_result_out)


# Generated at 2022-06-26 11:10:16.144981
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    elapsed_time = float_0
    bytes = [1,2,3,4,5,6,7,8,9,10]
    float_1 = 0.05
    float_2 = 0.05
    float_3 = 0.05
    float_4 = 0.05
    float_5 = 0.05
    float_6 = 0.05
    float_7 = 0.05
    float_8 = 0.05
    float_9 = 0.05
    float_10 = 0.05
    for i in range(10):
        assert FileDownloader.best_block_size(i, bytes[i]) == float_i

# Generated at 2022-06-26 11:10:20.219684
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Asserts for FileDownloader.report_progress method
    FileDownloader = FileDownloader()
    assert FileDownloader.report_progress("") == None


# Generated at 2022-06-26 11:10:35.403655
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('/') == '/'
    assert FileDownloader.temp_name('/home/') == '/home/'
    assert FileDownloader.temp_name('/home/abc') == '/home/abc'
    assert FileDownloader.temp_name('/home/abc.mp4') == '/home/abc.mp4'
    assert FileDownloader.temp_name('') == ''
    assert FileDownloader.temp_name('/home/abc.mp4.part') == '/home/abc.mp4'
    assert FileDownloader.temp_name('C:\\Users\\mkyong') == 'C:\\Users\\mkyong'

# Generated at 2022-06-26 11:10:37.716915
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.slow_down(float_0, float_0, int_0)


# Generated at 2022-06-26 11:10:47.034844
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Creation of objects needed to call download method
    file_downloader_0 = FileDownloader(None, {}, {}, False)
    info_dict_0 = {}
    filename_0 = 'p6Fmj6mfwU8'
    file_downloader_0._progress_hooks = [None]
    file_downloader_0.report_progress = object()
    file_downloader_0.to_screen = object()
    # Call method
    file_downloader_0.download(filename_0, info_dict_0)


# Generated at 2022-06-26 11:10:59.558792
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    if __name__ == '__main__':
        float_0 = 0.05
        # Creation of the class FileDownloader
        # Assigning to the class' attribute '_downloader' an instance of class MockYoutubeDl
        self.FileDownloader._downloader = MockYoutubeDl(format_note='')
        # Call to method FileDownloader.__init__
        # Creation of an instance of class FileDownloader
        FileDownloader.__init__(self, MockYoutubeDl(format_note=''), {}, {})
        test_case_name = 'Test FileDownloader'
        with open('test_results.txt','a') as wf:
            wf.write(test_case_name + '\n')

# Generated at 2022-06-26 11:11:05.215335
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Create FileDownloader instance
    fd = FileDownloader({"nooverwrites" : True}, None)

    # Create local variables
    file_name = "file_name"

    # Call method with valid arguments
    fd.report_file_already_downloaded(file_name)

    # Check for expected results
    assert fd.to_screen_called == 1
    assert fd.to_screen_args_list[0] == "[download] file_name has already been downloaded"

    # Cleanup
    del fd


# Generated at 2022-06-26 11:11:15.730340
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test Case 0:
    print("Testing Case 0...")
    float_0 = float('inf')
    float_1 = float('inf')
    float_2 = float('inf')
    float_3 = float('inf')
    float_4 = float('inf')
    float_5 = float('inf')
    float_6 = float('inf')
    float_7 = float('inf')
    float_8 = float('inf')
    float_9 = float('inf')
    float_10 = float('inf')
    float_11 = float('inf')
    float_12 = float('inf')
    float_13 = float('inf')
    float_14 = float('inf')
    float_15 = float('inf')
    float_16 = float('inf')
    float_17 = float('inf')
    float_

# Generated at 2022-06-26 11:11:52.203196
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    url = 'https://www.youtube.com/watch?v=6IyA8hNl_Nc&list=PLrEnWoR732-BHrPp_Pm8_VleD68f9s14-'

    ydl_opts = {}
    fd = FileDownloader(ydl_opts)
    result = fd.real_download('test_video',{'url':url})

    print(result)

# test_FileDownloader_download()


# Generated at 2022-06-26 11:11:54.009805
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    float_0 = 0.05
    assert_equal(float_0, 1.0)


# Generated at 2022-06-26 11:11:56.585684
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()

test_FileDownloader_download()

 

# Generated at 2022-06-26 11:11:57.499336
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    assert True


# Generated at 2022-06-26 11:12:06.226782
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader(params={})
    fd.real_download('filename', {'status': 'finished', 'urlhandle': ''})
    fd.real_download('filename', {'status': 'finished', 'urlhandle': '', 'elapsed': 0.01})
    fd.real_download('filename', {'status': 'finished', 'urlhandle': '', 'elapsed': 0.01, 'total_bytes': 1, 'downloaded_bytes': 0})
    fd.real_download('filename', {'status': 'finished', 'urlhandle': '', 'elapsed': 0.01, 'total_bytes': 1, 'downloaded_bytes': 1})


# Generated at 2022-06-26 11:12:10.193581
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fileDownloader_0 = FileDownloader()
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 11:12:11.681120
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()


# Generated at 2022-06-26 11:12:18.213539
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = time.time()
    time.sleep(1)
    now = time.time()
    filename = '-'
    eta = None
    retries = 10
    params = {'sleep_interval': float_0}
    ydl = YoutubeDL({'forcefilename': filename, 'nooverwrites': True, 'continuedl': True, 'nooverwrites': True, 'restrictfilenames': True})
    dl = FileDownloader(ydl, {})
    dl.download({'id': 'A', 'url': 'https://example.com'})
    assert len(params) > 0
    assert a >= b


# Generated at 2022-06-26 11:12:28.376493
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    float_pot = float_0
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot)
    # [float_0, float_0]
    # (float_pot, float_pot

# Generated at 2022-06-26 11:12:31.371100
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()

test_FileDownloader_report_progress()
