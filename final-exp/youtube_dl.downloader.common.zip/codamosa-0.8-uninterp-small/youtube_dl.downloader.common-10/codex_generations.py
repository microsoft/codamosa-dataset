

# Generated at 2022-06-26 11:03:22.057859
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    dict_0 = dict()
    dict_0 = {}
    dict_0['jsonrpc'] = '2.0'
    dict_0['id'] = 1
    dict_0['result'] = None
    dict_0['method'] = 'paused'
    file_downloader_0 = FileDownloader(dict_0, dict_0)
    dict_0 = dict()
    dict_0 = {}
    dict_0['jsonrpc'] = '2.0'
    dict_0['id'] = 1
    dict_0['result'] = None
    dict_0['method'] = 'paused'
    dict_0 = dict()
    dict_0 = {}
    dict_0['jsonrpc'] = '2.0'
    dict_0['id'] = 1
    dict_0['result'] = None

# Generated at 2022-06-26 11:03:32.640041
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = 'a\x01\x0e\x1c\xdb\xb8\xe6\x1dE\xd9o\x13\xde\xb8\x00\xf1\x00\x11\x85\x01\xb9'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\xcc\xc9\xe6Ky\xaar\x07\xa4\xadV\x1c\xa4\xf4\xcbI'
    file_downloader_0 = FileDownloader(dict_0, bytes_0)

# Generated at 2022-06-26 11:03:44.217222
# Unit test for method undo_temp_name of class FileDownloader

# Generated at 2022-06-26 11:03:56.690547
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    str_0 = '(wry }\\9TNN}l[Bg'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\xcc\xc9\xe6Ky\xaar\x07\xa4\xadV\x1c\xa4\xf4\xcbI'
    file_downloader_0 = FileDownloader(dict_0, bytes_0)

# Generated at 2022-06-26 11:04:05.364996
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = 'XXMROz'
    str_1 = '\x06\xc4\x0c\x99\x87\xf4\x0c\x11\x1a'
    int_0 = 2
    file_downloader_0 = FileDownloader(str_0, str_1)
    file_downloader_0.try_utime(str_0, int_0)


# Generated at 2022-06-26 11:04:19.353294
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-26 11:04:26.814577
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = '(wry }\\9TNN}l[Bg'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\xcc\xc9\xe6Ky\xaar\x07\xa4\xadV\x1c\xa4\xf4\xcbI'
    file_downloader_0 = FileDownloader(dict_0, bytes_0)
    str_0 = '(wry }\\9TNN}l[Bg'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-26 11:04:28.429548
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('-') == '-'


# Generated at 2022-06-26 11:04:35.532230
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = '+rghE'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\xcc\xc9\xe6Ky\xaar\x07\xa4\xadV\x1c\xa4\xf4\xcbI'
    file_downloader_0 = FileDownloader(dict_0, bytes_0)
    file_downloader_0.slow_down(dict_0, dict_1, dict_1)


# Generated at 2022-06-26 11:04:48.194931
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = ':W\x82\x81\x85\x1c\x86\x18\x87\x01\x81\x18\x83\x01\x1c\x0e\x99\xac\x1f\xd3\x02\xe9\x89'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\x08\x07\x07\x08\x08\x08\x07\x08\x08\x07\x07\x08\x08\x08\x07\x07\x07\x08\x08\x07\x08'
    file_downloader_0 = FileDownloader

# Generated at 2022-06-26 11:05:23.102095
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test 0: Non-existed File
    str_0 = '-'
    str_1 = '-'
    Int_0 = 0
    Int_1 = 0
    non_existed_File_Buffer_Size = FileDownloader.calc_speed(str_0, str_1, Int_0, Int_1)
    print(non_existed_File_Buffer_Size)



# Generated at 2022-06-26 11:05:28.246833
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    o = FileDownloader()
    str_0 = '-'
    try:
        FileDownloader.temp_name(o, str_0)
    except Exception:
        assert False
    return None


# Generated at 2022-06-26 11:05:36.599871
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader()
    float_0 = float('inf')
    float_1 = float('inf')
    float_2 = float('inf')
    float_3 = float('inf')
    float_4 = float('inf')
    float_5 = float('inf')
    float_6 = float('inf')
    float_7 = float('inf')
    float_8 = float('inf')
    float_9 = float('inf')
    float_10 = float('inf')
    float_11 = float('inf')
    float_12 = float('inf')
    float_13 = float('inf')
    float_14 = float('inf')
    float_15 = float('inf')
    float_16 = float('inf')
    float_17 = float('inf')
    float_18 = float('inf')


# Generated at 2022-06-26 11:05:38.696955
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    pytest.skip('Test method is not implemented')


# Generated at 2022-06-26 11:05:46.769898
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = '-'
    str_1 = '-'
    str_2 = '-'
    str_3 = '-'
    str_4 = '-'
    str_5 = '-'
    str_6 = '-'
    str_7 = '-'
    str_8 = '-'
    str_9 = '-'
    str_10 = '-'
    str_11 = '-'
    str_12 = '-'
    str_13 = '-'
    str_14 = '-'
    str_15 = '-'
    str_16 = '-'
    str_17 = '-'
    str_18 = '-'
    str_19 = '-'
    str_20 = '-'
    str_21 = '-'
    str_22 = '-'
    str_23 = '-'
    str_24 = '-'

# Generated at 2022-06-26 11:05:47.829227
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})

    assert fd.temp_name(str_0) == str_0


# Generated at 2022-06-26 11:05:54.948059
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    global str_0
    # Zero arguments constructor.
    fd_0 = FileDownloader(None, None, {}, {}, None, None)
    # Input arguments:
    bytestr = str_0
    # Call method:
    fd_0.parse_bytes(bytestr)
    guard_0 = len(bytestr)
    guard_1 = len(bytestr)
    # Assertion: the length of the given value is invariant.
    assert guard_0 == guard_1

# Generated at 2022-06-26 11:05:57.435107
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    obj = FileDownloader(None, None)
    obj.report_progress(s = 's')


# Generated at 2022-06-26 11:06:08.405059
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    global str_0
    str_0 = '-'
    assert FileDownloader.calc_speed(
        float('nan'), float('inf'), float('inf')) == float('inf')
    assert FileDownloader.calc_speed(float('nan'), float('nan'), float('nan')) == float('nan')
    assert FileDownloader.calc_speed(-float('inf'), float('inf'), float('inf')) == float('nan')
    assert FileDownloader.calc_speed(float('nan'), -float('inf'), -float('inf')) == float('nan')
    assert FileDownloader.calc_speed(
        float('inf'), -float('inf'), -float('inf')) == float('-inf')
    assert FileDownloader.calc_speed(1, 1, 1) == 1

# Generated at 2022-06-26 11:06:11.944847
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    ydl = YouTubeDL()
    ydl.add_progress_hook(lambda status: print(status))
    test_case_0()



# Generated at 2022-06-26 11:06:28.680395
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    filename = str_0
    info_dict = dict()

    fd = FileDownloader(info_dict)
    fd.download(filename, info_dict)



# Generated at 2022-06-26 11:06:32.886931
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    obj_FileDownloader = FileDownloader()
    obj_FileDownloader.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:06:36.523172
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    print('Testing FileDownloader.format_retries')
    str_0 = '-'
    assert not True


# Generated at 2022-06-26 11:06:39.912964
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    dl_0 = FileDownloader({})
    assert(dl_0.temp_name('-') == '-')


# Generated at 2022-06-26 11:06:43.756184
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None)
    fd.report_progress(None)


# Generated at 2022-06-26 11:06:51.117678
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = '-'
    fd_0 = FileDownloader({'nopart': True})
    result = fd_0.temp_name(str_0)
    assert (result) == str_0, "Assertion failed:  %s" % result


# Generated at 2022-06-26 11:06:56.384883
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    downloader = FileDownloader({})
    str_0 = 'file-0'
    str_1 = 'file-1'
    downloader.try_utime(str_0, str_1)
    str_2 = 'file-2'
    str_3 = 'file-3'
    downloader.try_utime(str_2, str_3)


# Generated at 2022-06-26 11:07:08.681413
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    ydl = YouTubeDL()
    ydl.params['outtmpl'] = '%(title)s_%(id)s_%(resolution)s_%(format)s.%(ext)s'
    ydl.params['continuedl'] = True
    dl = FileDownloader(ydl, {})
    dl.prepend_extension = False
    assert len(dl.format_resolution('720p')) == 0
    assert dl.format_resolution('720p') == ''
    assert len(dl.format_resolution('720')) == 3
    assert dl.format_resolution('720p') == ''

# Generated at 2022-06-26 11:07:19.968867
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    mo = hashlib.sha1(b'').hexdigest()
    str_0 = '-'
    str_1 = '-'

# Generated at 2022-06-26 11:07:31.331732
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = '-'

    # Setup
    class MockYoutubeDL(object):
        params = {}
        _progress_hooks = []
        _screen_file = sys.stderr
        player = None
        def to_screen(self, *args):
            pass
        def to_console_title(self, *args, **kwargs):
            pass
        def trouble(self, *args):
            pass
        def report_warning(self, *args):
            pass
        def report_error(self, *args):
            pass

    ydl = MockYoutubeDL()

# Generated at 2022-06-26 11:07:51.048877
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    
    #
    # test case 0
    #
    
    # test case 0 test 0
    str_0 = '-'
    str_1 = '-'
    str_2 = '-'
    str_3 = '-'
    str_4 = '-'
    var_0 = FileDownloader.calc_speed(str_0, str_1, str_2, str_3, str_4)
    
    # test case 0 test 1
    str_0 = '-'
    str_1 = '-'
    str_2 = '-'
    str_3 = '-'
    str_4 = '-'
    var_1 = FileDownloader.calc_speed(str_0, str_1, str_2, str_3, str_4)
    
    # test case 0 test 2

# Generated at 2022-06-26 11:07:57.907250
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert_equals(FileDownloader.try_utime('filename', 'last_modified_hdr'), None)
    assert_equals(FileDownloader.try_utime('-', '-'), None)


# Generated at 2022-06-26 11:08:00.133714
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    o = FileDownloader()
    print('s: ', s)
    o.report_progress(s)


# Generated at 2022-06-26 11:08:05.180468
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    unitTest_FileDownloader = FileDownloader()
    str_0 = '-'
    assert unitTest_FileDownloader.parse_bytes(str_0) == None


# Generated at 2022-06-26 11:08:09.499395
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader()
    file_downloader_0.slow_down(time.time(), time.time(), 0)


# Generated at 2022-06-26 11:08:22.223351
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    def __assert(file_name):
        downloader = FileDownloader(None, {})
        assert downloader.report_file_already_downloaded(file_name) == None
        assert downloader.to_screen('[download] %s has already been downloaded' % file_name) == None
        assert downloader._hook_progress({'filename': file_name, 'status': 'finished', 'total_bytes': os.path.getsize(encodeFilename(file_name))}) == None
    test_case_0()
    __assert('-')
    __assert('qwerty')

if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-26 11:08:24.158864
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = '-'



# Generated at 2022-06-26 11:08:34.089127
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    try:
        s_0 = {}
        str_0 = '-'

        test_FileDownloader_report_progress_0.params['progress_hooks'] = [test_FileDownloader_report_progress_0.to_screen]
        test_FileDownloader_report_progress_0.params['outtmpl'] = str_0
        test_FileDownloader_report_progress_0.params['noprogress'] = True

        test_FileDownloader_report_progress_0.report_progress(s_0)

    except Exception as err0:
        print(err0)



# Generated at 2022-06-26 11:08:39.678815
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, None)
    # TEST CASE BEGIN
    fd.slow_down(0.0, 0.0, 0)
    # TEST CASE END


# Generated at 2022-06-26 11:08:44.470244
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # global str_0
    start_time_0 = 0.0
    byte_counter_0 = 0
    rate_limit_0 = 0
    FileDownloader_0 = FileDownloader({})
    FileDownloader_0.slow_down(start_time_0, start_time_0, byte_counter_0, rate_limit_0)


# Generated at 2022-06-26 11:08:58.122922
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():

    fn = FileDownloader(None)

    filename = 'foo.bar.part'
    result = fn.undo_temp_name(filename)
    assert result == 'foo.bar'

    filename = 'foo.part'
    result = fn.undo_temp_name(filename)
    assert result == 'foo'

    filename = 'foo'
    result = fn.undo_temp_name(filename)
    assert result == 'foo'

    filename = 'foo.txt'
    result = fn.undo_temp_name(filename)
    assert result == 'foo.txt'



# Generated at 2022-06-26 11:09:00.826197
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = '-'
    FileDownloader_0 = FileDownloader(YoutubeDL_0, youtube_dl_0.default_params, options_0)
    FileDownloader_0.undo_temp_name(str_0)


# Generated at 2022-06-26 11:09:02.185035
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    ftp = FileDownloader.try_utime(str_0, '8J')


# Generated at 2022-06-26 11:09:15.505246
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    def test_FileDownloader_report_progress_0():
        url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
        filename = 'unavailable.mp4'
        ydl_opts = {'outtmpl': '%(id)s.%(ext)s'}
        fd = FileDownloader({'format': 'best'}, ydl_opts)

        status = twc.get_last_status()
        assert status['status'] == 'finished'
        assert status['elapsed'] == -1
        assert status['eta'] == -1
        assert status['speed'] == -1
        assert status['total_bytes'] == -1
        assert status['total_bytes_estimate'] == -1
        assert status['downloaded_bytes'] == -1
        assert status

# Generated at 2022-06-26 11:09:25.570955
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test case '-'. Evaluate and print useful information
    print('Test case: ' + test_case_0.__doc__)
    print('Execution: ' + str(test_case_0.__name__))
    print('Expected:  ' + str(test_case_0.__code__))
    test_case_0()
    print('Finished:  ' + str(test_case_0.__code__))
    print('\n\n')


# Generated at 2022-06-26 11:09:38.579143
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Status of download.
    str_0 = 'error'
    str_1 = 'downloading'
    str_2 = 'finished'
    str_3 = 'downloading'
    str_4 = 'finished'
    str_5 = 'downloading'
    str_6 = 'finished'
    str_7 = 'downloading'
    str_8 = 'finished'
    str_9 = 'downloading'
    str_10 = 'finished'
    str_11 = 'downloading'
    str_12 = 'finished'
    str_13 = 'downloading'
    str_14 = 'finished'
    str_15 = 'downloading'
    str_16 = 'finished'
    str_17 = 'downloading'
    str_18 = 'finished'
    str_19 = 'downloading'
    str

# Generated at 2022-06-26 11:09:41.427399
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start = 1497605194.9297054
    now = 1497605194.9297054
    bytes = 0
    expected = None
    FileDownloader.calc_speed(start, now, bytes)
    if (FileDownloader.calc_speed(start, now, bytes) != expected):
        raise Exception("Failed on call to calc_speed of class FileDownloader")


# Generated at 2022-06-26 11:09:44.131423
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    # Call method
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 11:09:48.477488
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader_0 = FileDownloader()

    #Test 1
    assert file_downloader_0.parse_bytes(test_case_0()) == 0

# Generated at 2022-06-26 11:09:54.619061
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # test call
    args = {'status': 'finished', 'total_bytes': 'total_bytes_0'}
    obj = FileDownloader()
    FileDownloader.report_progress(obj, args)


# Generated at 2022-06-26 11:10:09.685510
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test case with 0 arguments
    try:
        assert FileDownloader.undo_temp_name(
            '-') == '-'
    except:
        print('Failed test for method undo_temp_name of class FileDownloader')
        return

    print('Passed tests for method undo_temp_name of class FileDownloader')


# Generated at 2022-06-26 11:10:24.506502
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Setup
    str_0 = '-'
    argv_0 = ['youtubedl', '-i', '--print-traffic', '--write-info-json', '-v', 'https://www.youtube.com/watch?v=8tPnX7OPo0Q']
    filename_0 = str_0
    params_0 = {  }
    ydl_0 = YoutubeDL(argv_0, params_0)
    file_downloader_0 = FileDownloader(ydl_0, filename_0, params_0)

    # Procedure call
    file_downloader_0.slow_down(0.0, 0.0, 0)

    # Teardown
    return


# Generated at 2022-06-26 11:10:32.375969
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-26 11:10:40.308883
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Unit test for method report_file_already_downloaded of class FileDownloader

    # Call method report_file_already_downloaded of class FileDownloader with argument filename
    FileDownloader.report_file_already_downloaded(str_0)

# Generated at 2022-06-26 11:10:50.317498
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = '-'
    str_1 = 'shadow'
    str_2 = './shadow/'
    str_3 = 'self.temp_name(filename)'
    str_4 = 'downloader/youtube.py'
    str_5 = 'se'
    str_6 = 'test_case_0'
    str_7 = '<'
    str_8 = 'test_FileDownloader_undo_temp_name'
    str_9 = ' '
    str_10 = 'temp_file'
    str_11 = '&'
    str_12 = '.8'
    str_13 = '-'
    str_14 = 'shadow'
    str_15 = './shadow/'
    str_16 = 'self.temp_name(filename)'

# Generated at 2022-06-26 11:10:51.305520
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('-').__eq__('-')


# Generated at 2022-06-26 11:11:00.018682
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    args_0 = {'noprogress': False, 'continuedl': True, 'ratelimit': None, 'sleep_interval': None}
    fd_0 = FileDownloader(args_0, None)
    args_1 = {'noprogress': False, 'continuedl': True, 'ratelimit': None, 'sleep_interval': None}
    fd_1 = FileDownloader(args_1, None)
    args_2 = {'noprogress': False, 'continuedl': True, 'ratelimit': None, 'sleep_interval': None}
    fd_2 = FileDownloader(args_2, None)
    args_3 = {'noprogress': False, 'continuedl': False, 'ratelimit': None, 'sleep_interval': 2}
    fd_

# Generated at 2022-06-26 11:11:05.030382
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = '-'
    str_1 = '-'
    file_downloader_0 = FileDownloader()
    str_2 = file_downloader_0.temp_name(str_0)
    assert str_1 == str_2


# Generated at 2022-06-26 11:11:10.303045
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = 'inf'
    assert FileDownloader.format_retries('inf') == str_0


# Generated at 2022-06-26 11:11:11.821195
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = '-'


# Generated at 2022-06-26 11:11:24.589859
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    filename = None
    # Case 0
    try:
        str_0 = '-'
        ret_0 = FileDownloader.temp_name(filename)
        print("test case 0: ", end = '')
        if ret_0 == str_0:
            print("True")
        else:
            print("False")
    except Exception as e:
        print(e)

# Generated at 2022-06-26 11:11:27.310808
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    assert FileDownloader('host', 'port', 'path') is not None


# Generated at 2022-06-26 11:11:32.271763
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(dict())
    # Failed with a wrong date
    start_time = None
    now = None
    byte_counter = None
    try:
        fd.slow_down(start_time, now, byte_counter)
    except:
        pass
    # Failed with a wrong date
    start_time = None
    now = None
    byte_counter = None
    try:
        fd.slow_down(start_time, now, byte_counter)
    except:
        pass


# Generated at 2022-06-26 11:11:33.591327
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert str_0 == FileDownloader.parse_bytes('-'), 'Failed to parse_bytes(str)'

# test to ensure it runs properly

# Generated at 2022-06-26 11:11:36.121715
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd_0 = FileDownloader(str_0)
    fd_0.download('-', None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:11:40.132316
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-26 11:11:43.076118
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-26 11:11:49.167853
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    from random import random
    import time
    print('Testing FileDownloader.calc_speed()')
    start = time.time()
    now = start + random()
    bytes = int(random() * 1000)
    print('Calling FileDownloader.calc_speed() with '
          + 'start = {}, now = {}, bytes = {}'.format(start, now, bytes))
    result = FileDownloader.calc_speed(start, now, bytes)
    correct = int(bytes / (now - start))
    print('Expected {}, got {}'.format(correct, result))
    assert result == correct


# Generated at 2022-06-26 11:11:57.962644
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    try_utime = FileDownloader.try_utime
    fd = FileDownloader(YoutubeDL())
    file_name = '.'
    filename = './'
    last_modified_hdr = 'Thu, 19 Nov 2015 23:36:46 GMT'
    out = try_utime(fd, file_name, last_modified_hdr)
    assert out == 1447971406.0
    last_modified_hdr = None
    out = try_utime(fd, filename, last_modified_hdr)
    assert out == None
    file_name = '123.txt'
    filename = '123.txt'
    last_modified_hdr = 'Thu, 19 Nov 2015 23:36:46 GMT'
    out = try_utime(fd, file_name, last_modified_hdr)


# Generated at 2022-06-26 11:12:02.440303
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    print("Test FileDownloader")
    start = (1, 2, 3)
    now = 1
    bytes = 2
    assert FileDownloader.calc_speed(start, now, bytes) is None


# Generated at 2022-06-26 11:12:35.274083
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    noprogress = False
    # Call method report_progress with parameters s and noprogress
    FileDownloader.report_progress(s, noprogress)


# Generated at 2022-06-26 11:12:37.066144
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(None)

    fd.try_utime(str_0, str_0)


# Generated at 2022-06-26 11:12:49.960027
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = '-'
    file_path_str_0 = '-'
    str_1 = '-'
    file_path_str_1 = '/tmp/'
    str_2 = '/tmp'
    file_path_str_2 = '/tmp'
    str_3 = '.'
    file_path_str_3 = '.'
    str_4 = './'
    file_path_str_4 = './'
    str_5 = '/tmp/'
    file_path_str_5 = '/tmp/'
    str_6 = '.'
    file_path_str_6 = '.'
    str_7 = '-'
    file_path_str_7 = '-'
    str_8 = '.'
    file_path_str_8 = '.'
    str_9 = '.'
   