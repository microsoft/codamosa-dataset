

# Generated at 2022-06-26 11:03:16.075475
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Input parameters
    filename = ''
    last_modified_hdr = '~?BNZ|5f5m'

    file_downloader_0 = FileDownloader(None, None)

    filetime = file_downloader_0.try_utime(filename, last_modified_hdr)

# Generated at 2022-06-26 11:03:23.651260
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 4296
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    str_0 = 'DmLEyXsm#m^Bmvvd6pZU$&ZU8e'
    float_0 = -3690.988
    file_downloader_0.try_utime(str_0, float_0)


# Generated at 2022-06-26 11:03:26.636911
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    file_downloader_0 = FileDownloader(list(), list())
    file_downloader_0.undo_temp_name('foo.part')


# Generated at 2022-06-26 11:03:35.337714
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes(None) == None
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('10240') == 10240
    assert FileDownloader.parse_bytes('10 KiB') == 10240
    assert FileDownloader.parse_bytes('10kb') == 10240
    assert FileDownloader.parse_bytes('1 MiB') == 1048576
    assert FileDownloader.parse_bytes('1mb') == 1048576
    assert FileDownloader.parse_bytes('1 GiB') == 1073741824
    assert FileDownloader.parse_bytes('1gb') == 1073741824

# Generated at 2022-06-26 11:03:38.849280
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("abc") == "abc"
    assert FileDownloader.undo_temp_name("abc.part") == "abc"



# Generated at 2022-06-26 11:03:44.413266
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    start_time = 0.0
    byte_counter = 0
    now = 0.0
    file_downloader_0.slow_down(start_time, now, byte_counter);


# Generated at 2022-06-26 11:03:48.565508
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    filename = '1234'
    file_downloader_0.try_utime(filename, '1234')



# Generated at 2022-06-26 11:03:55.941882
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    list_0 = [get_random_int(), get_random_int(), get_random_int(), get_random_int()]
    file_downloader_0.slow_down(list_0[0], list_0[1], list_0[2], list_0[3])


# Generated at 2022-06-26 11:04:05.460881
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)

    retries_0 = 0.0
    result_0 = file_downloader_0.format_retries(retries_0)

    retries_1 = 0
    result_1 = file_downloader_0.format_retries(retries_1)



# Generated at 2022-06-26 11:04:19.443752
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class FileDownloader_try_utime_0(FileDownloader):
        def __init__(self):
            self.FILE_UTIME_FAILED = None
            self.a = None
            self.b = None
            self.c = None
            self.d = None
            self.e = None
            self.f = None
            self.g = None
            self.h = None

        def try_utime_0(self, arg_0):
            self.a = 0

        def try_utime_1(self, arg_0):
            self.b = 0

        def try_utime_2(self, arg_0):
            self.c = 0

        def try_utime_3(self, arg_0):
            self.d = 0


# Generated at 2022-06-26 11:04:38.221915
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('12345') == 12345
    assert FileDownloader.parse_bytes('12B') == 12
    assert FileDownloader.parse_bytes('12b') == 12
    assert FileDownloader.parse_bytes('12.3k') == 12.3 * 1024
    assert FileDownloader.parse_bytes('12.0k') == 12 * 1024
    assert FileDownloader.parse_bytes('12.3K') == 12.3 * 1024
    assert FileDownloader.parse_bytes('12.0K') == 12 * 1024
    assert FileDownloader.parse_bytes('1.23e+5') == 1.23 * 10 ** 5
    assert FileDownloader.parse_bytes('1.23e5') == 1.23 * 10 ** 5

# Generated at 2022-06-26 11:04:51.650717
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assert FileDownloader.calc_eta(0, 0, 0) == None
    assert FileDownloader.calc_eta(0, 0, 3) == None
    assert FileDownloader.calc_eta(1.7881393432617188e+308, 1.7881393432617188e+308, 100) == 1.7881393432617188e+308
    assert FileDownloader.calc_eta(0.001, 0.001, 0) == None
    assert FileDownloader.calc_eta(0, 0, 1) == None
    assert FileDownloader.calc_eta(0, 0, 0) == None
    assert FileDownloader.calc_eta(0, 0, 3) == None

# Generated at 2022-06-26 11:04:59.020971
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader(downloader_options, [])
    start_time_0 = 'Start time'
    now_0 = 'Now'
    byte_counter_0 = -10
    file_downloader_0.slow_down(start_time_0, now_0, byte_counter_0)


# Generated at 2022-06-26 11:05:12.085034
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert FileDownloader(None, None).try_utime("test_filename", "Oct 29, 2019") == 1572320000
    assert FileDownloader(None, None).try_utime("test_filename", "Oct 29, 2019") != 1572329999
    assert FileDownloader(None, None).try_utime("test_filename", "Oct 29, 2019") != 1572330001
    assert FileDownloader(None, None).try_utime("test_filename", "Nov 29, 2019") == 1574880000
    assert FileDownloader(None, None).try_utime("test_filename", 1990) == 631152000
    assert FileDownloader(None, None).try_utime("test_filename", "1990") == 631152000

# Generated at 2022-06-26 11:05:24.030220
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    float_0 = 1.874885e-07
    float_1 = 7.854545e-08
    float_2 = 1.15e-07
    double_0 = 3.8295e-08
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    float_3 = file_downloader_0.calc_speed(float_0, float_1, float_2)
    float_4 = file_downloader_0.calc_speed(float_0, float_2, float_1)
    float_5 = file_downloader_0.calc_speed(float_0, float_2, float_2)

# Generated at 2022-06-26 11:05:29.655768
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    int_0 = 6337
    u, v = divmod(int_0, 100)
    str_0 = '63%'
    assert(FileDownloader.format_percent(int_0) == str_0)


# Generated at 2022-06-26 11:05:33.327450
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    list_0 = [0, 32, 0, 0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    str_0 = file_downloader_0.format_retries(list_0[1])
    assert str_0 == '32'


# Generated at 2022-06-26 11:05:43.565901
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    print('Running unit test for FileDownloader.format_percent()...')
    assert FileDownloader.format_percent(0.77) == '77%'
    assert FileDownloader.format_percent(77.) == '77%'
    assert FileDownloader.format_percent(7.7) == '7.7%'
    assert FileDownloader.format_percent(0.0) == '0%'
    assert FileDownloader.format_percent(.777) == '77.7%'
    assert FileDownloader.format_percent(.077) == '7.7%'
    print('Unit test successful!')


# Generated at 2022-06-26 11:05:51.544376
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # File downloader should fail without an arguments
    #assert FileDownloader.try_utime() == NotImplemented
    # File downloader should fail with valid arguments
    assert FileDownloader.try_utime(list_0, list_0) == NotImplemented

# Unit test of method best_block_size of class FileDownloader

# Generated at 2022-06-26 11:05:58.810766
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    var_1 = 'filename'
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    file_downloader_0.report_file_already_downloaded(var_1)



# Generated at 2022-06-26 11:06:43.692888
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    x = FileDownloader([],[])
    assert x.format_seconds(5.5) == '5.5s'
    assert x.format_seconds(5.0) == '5s'
    assert x.format_seconds(5.05) == '5.1s'
    assert x.format_seconds(60.5) == '1m1s'
    assert x.format_seconds(3601.0) == '1h0m1s'
    assert x.format_seconds(3601.5) == '1h0m1s'
    assert x.format_seconds(3605.5) == '1h0m5s'
    assert x.format_seconds(3660.5) == '1h1m0s'

# Generated at 2022-06-26 11:06:46.410681
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_case_0()


# Generated at 2022-06-26 11:06:51.464784
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    file_downloader_0 = FileDownloader([0], [0])
    assert (11001 == file_downloader_0.format_retries(11000))
    assert (11 == file_downloader_0.format_retries(11))
    assert ("inf" == file_downloader_0.format_retries(float('inf')))


# Generated at 2022-06-26 11:07:02.676087
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    x = FileDownloader([], [])
    assert(x.format_retries(-1) == 'inf')
    assert(x.format_retries(0) == '0')
    assert(x.format_retries(1) == '1')
    assert(x.format_retries(123) == '123')
    assert(x.format_retries(9999) == '9999')
    assert(x.format_retries(10000) == '10000')
    assert(x.format_retries(float('inf')) == 'inf')
    assert(x.format_retries(float('NaN')) == 'inf')


# Generated at 2022-06-26 11:07:10.955619
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    if not FileDownloader.parse_bytes('1 Kb') == 1024:
        raise Exception('Test failed for parse_bytes')
    if not FileDownloader.parse_bytes('1mb') == 1048576:
        raise Exception('Test failed for parse_bytes')
    if not FileDownloader.parse_bytes('3.14g') == 3.14 * 1024 ** 3:
        raise Exception('Test failed for parse_bytes')


# Generated at 2022-06-26 11:07:23.200795
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def assert_report_progress(status: dict, expected: str):
        output = io.StringIO()
        FileDownloader([], {'logger': logging.Logger('test', level=logging.DEBUG), 'outtmpl': '-'}).to_screen = lambda msg, **kwargs: output.write(msg + '\n')
        file_downloader_0 = FileDownloader([], {})
        with mock.patch.object(file_downloader_0, '_report_progress_status') as mock_report_progres_status:
            file_downloader_0.report_progress(status)
            mock_report_progres_status.assert_called_once_with(expected, is_last_line=False)


# Generated at 2022-06-26 11:07:31.949285
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 1
    int_1 = 1
    int_2 = 1
    int_3 = 1
    int_4 = 1
    int_5 = 1
    int_6 = 1
    int_7 = 1
    int_8 = 1
    int_9 = 1
    int_10 = 1
    str_0 = '35ci39h1y872q3l3vzrmmn0rko6f8gk1'
    str_1 = 'wwjy2ol8z0g7rhw5j6b5o6p9x80'
    str_2 = '6i5um6g838f7441k6bt5b6h5p'

# Generated at 2022-06-26 11:07:37.301141
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    file_downloader_0 = FileDownloader(2, 3)
    assert file_downloader_0.report_file_already_downloaded(
        'youtube-dl_2018.06.27_[11.06]') == None


# Generated at 2022-06-26 11:07:46.247706
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    dict_0 = dict()
    file_downloader_0.report_progress(dict_0)
'''
test_case_0()
test_FileDownloader_report_progress()
'''

# Generated at 2022-06-26 11:07:50.199612
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    FileDownloader.report_progress(['status'])

    start_time = time.time()
    sleep_time = 100
    time.sleep(sleep_time)
    FileDownloader.report_progress({'status': 'downloading', 'elapsed': time.time() - start_time, 'speed': float(sleep_time) / (time.time() - start_time)})


# Generated at 2022-06-26 11:08:22.324129
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = '"LkinuZ%J8j.B'
    file_downloader_0 = FileDownloader(None, None)
    int_1 = 0
    list_0 = [int_1]
    int_0 = file_downloader_0.try_utime(str_0, list_0)
    assert int_0 == 0


# Generated at 2022-06-26 11:08:35.217700
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Test single byte units
    assert FileDownloader.parse_bytes('0b') == 0
    assert FileDownloader.parse_bytes('1b') == 1
    assert FileDownloader.parse_bytes('1023b') == 1023
    assert FileDownloader.parse_bytes('1024b') == 1024
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1023k') == 1048575
    assert FileDownloader.parse_bytes('1m') == 1048576
    assert FileDownloader.parse_bytes('1023m') == 1073741823
    assert FileDownloader.parse_bytes('1g') == 1073741824
    assert FileDownloader.parse_bytes('1023g') == 1073741824 * 1023

# Generated at 2022-06-26 11:08:45.274753
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 1199
    list_0 = [int_0, 1, int_0, int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    int_1 = 0
    int_2 = 0
    str_0 = 'Unknown'
    str_1 = 'Unknown ETA'
    str_2 = 'Unknown %'
    str_3 = 'Unknown speed'
    str_4 = 'Unknown'
    str_5 = 'Unknown ETA'
    s_0 = {'speed': int_1, 'status': str_0, 'total_bytes': int_2, 'eta': int_1, 'downloaded_bytes': int_2}
    file_downloader_0.report_progress(s_0)

# Generated at 2022-06-26 11:08:52.758984
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 3165
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    file_downloader_0.slow_down(4.0, 4.0, 4)


# Generated at 2022-06-26 11:08:55.365408
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    assert True # TODO: implement your test here

# Generated at 2022-06-26 11:08:56.262291
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    FileDownloader.parse_bytes('1024')


# Generated at 2022-06-26 11:08:59.124425
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start = time.time()
    time.sleep(0.05)
    now = time.time()
    assert FileDownloader.calc_speed(start, now, 1024) == 1024 / (now - start)


# Generated at 2022-06-26 11:09:03.605567
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(None, None)

    # Test a positive case
    assert file_downloader_0.try_utime('file_downloader_0', '1776-06-04') == -45113600.0

    # Test a negative case
    file_downloader_0.try_utime(None, None)


# Generated at 2022-06-26 11:09:09.129411
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Set up parameters
    bytestr = '4,096'

    # Invoke method
    result = FileDownloader.parse_bytes(bytestr)

    # Check for expected values
    assert result == 4096



# Generated at 2022-06-26 11:09:10.629302
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    test_case_0()



# Generated at 2022-06-26 11:09:47.545796
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    file_downloader_0 = FileDownloader(list_0, list_0)
    s = {}
    # Output: [download] Unknown % of Unknown speed ETA Unknown ETA
    file_downloader_0.report_progress(s)

# main function

if __name__ == '__main__':
    print('Testing FileDownloader ...')
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:09:58.110054
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    int_3 = 678
    list_3 = [int_3, int_3, int_3, int_3]
    file_downloader_0 = FileDownloader(list_3, list_3)
    str_0 = "test_case_1"
    str_0 = file_downloader_0.temp_name(str_0)
    if (str_0 != "test_case_1.part"):
        raise RuntimeError("File downloader temp_name")


# Generated at 2022-06-26 11:10:07.927093
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = 1.6221327e9
    now = 1.6221328e9
    byte_counter = 1.23456789123456789e9
    file_downloader_0 = FileDownloader(None, None)
    try:
        file_downloader_0.slow_down(start_time, now, byte_counter)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 11:10:12.866512
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    assert FileDownloader.best_block_size(0.0, 32) == int_0
    assert FileDownloader.best_block_size(0.014, 2743) == int_0
    assert file_downloader_0.best_block_size(32, 0.014) == int_0


# Generated at 2022-06-26 11:10:24.066404
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)
    str_0 = '=vci8j'
    str_1 = '9'
    str_2 = 'Yic6u'
    str_3 = 'j8V'
    # assert slow_down(file_downloader_0, str_0, str_1, str_2) == str_3
    raise NameError('Could not find suitable test case')


# Generated at 2022-06-26 11:10:36.240446
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 1242
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)

# Generated at 2022-06-26 11:10:48.613867
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    filename = 'dl/filename.mp4'

# Generated at 2022-06-26 11:10:57.018591
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 3072
    list_0 = [int_0, int_0, int_0, int_0]
    file_downloader_0 = FileDownloader(list_0, list_0)

    byte_counter = 1024
    rate_limit = 512
    start_time = time.time()
    file_downloader_0.slow_down(start_time, None, byte_counter)

# Generated at 2022-06-26 11:11:00.723851
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Stub: return 'I am a stub'
    return 'I am a stub'



# Generated at 2022-06-26 11:11:08.523507
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 2743
    list_0 = [int_0, int_0, int_0, int_0]
    int_1 = 0
    int_2 = 0
    file_downloader_0 = FileDownloader(list_0, list_0)
    str_dict_0 = {'downloaded_bytes': int_1, 'total_bytes': int_2, 'status': 'finished', 'speed': 4.02230935178059e-06, 'elapsed': 7.320670313835144}
    #file_downloader_0.report_progress(str_dict_0)
