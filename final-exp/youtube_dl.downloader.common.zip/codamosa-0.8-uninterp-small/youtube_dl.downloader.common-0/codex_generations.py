

# Generated at 2022-06-26 11:03:23.373872
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Test with the following configuration:
    #     noplaylist = False
    #     nocheckcertificate = False
    args = []
    args.append('--noplaylist')
    args.append('--nocheckcertificate')
    ydl_opts = {}
    FileDownloader.report_file_already_downloaded(args[0], ydl_opts)


# Generated at 2022-06-26 11:03:31.350650
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = 0.0
    file_downloader_0 = FileDownloader()
    now = 0.5
    file_downloader_0.params['ratelimit'] = 128
    byte_counter = 128
    file_downloader_0.slow_down(start_time, now, byte_counter)
    # now > start_time
    # sleep_time > 0
    # Unverified Assertion

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()

# Generated at 2022-06-26 11:03:33.912172
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.calc_eta('', '', '', '')



# Generated at 2022-06-26 11:03:39.219380
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = time.time()
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.slow_down(start_time, time.time(), 10485760)


# Generated at 2022-06-26 11:03:48.828122
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from batchmp3downloader.filedownloader import time
    from batchmp3downloader.filedownloader import sleep
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)

    # Testcase 1
    start_time_0 = 0
    now_0 = 0
    byte_counter_0 = 0
    FileDownloader.slow_down(file_downloader_0, start_time_0, now_0, byte_counter_0)
    # Testcase 2
    start_time_0 = 0
    now_0 = 0
    byte_counter_0 = 0
    file_downloader_0.params['ratelimit'] = 0

# Generated at 2022-06-26 11:03:53.250737
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    start = 0
    now = 1
    bytes = 0
    file_downloader_0.calc_speed(start, now, bytes)


# Generated at 2022-06-26 11:03:56.537778
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("foo.part") == "foo"
    assert FileDownloader.undo_temp_name("foo") == "foo"


# Generated at 2022-06-26 11:04:05.600257
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert FileDownloader.try_utime("FileDownloader_try_utime", "FileDownloader_try_utime") == None
    assert FileDownloader.try_utime("FileDownloader_try_utime", None) == None
    assert FileDownloader.try_utime("FileDownloader_try_utime", "n/a") == None
    # assert FileDownloader.try_utime("FileDownloader_try_utime", "n") == None



# Generated at 2022-06-26 11:04:09.322126
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.download('', None)


# Generated at 2022-06-26 11:04:21.584818
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.params['continuedl'] = True
    file_downloader_0.params['nopart'] = True
    file_downloader_0.download('-', None)
    if file_downloader_0.params['skip_download']:
        return

    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.params['continuedl'] = True
    file_downloader_0.params['nopart'] = True
    file_downloader_0.download('-', None)
    if file_downloader_0.params['skip_download']:
        return

    file_downloader

# Generated at 2022-06-26 11:04:32.164403
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    FileDownloader.calc_eta(0, 0, 0)


# Generated at 2022-06-26 11:04:33.255136
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    str_0 = 'foo.part'
    str_1 = 'foo'


# Generated at 2022-06-26 11:04:34.825601
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    file_downloader = FileDownloader(None, {}, None)
    file_downloader.format_seconds(123.456789)


# Generated at 2022-06-26 11:04:35.958801
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Note: See the comment in method report_progress of class FileDownloader
    print('Testing report_progress')
    test_case_0()


# Generated at 2022-06-26 11:04:49.135064
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_0 = FileDownloader(None, {})
    file_downloader_0.to_screen(' ')
    file_downloader_0.to_screen('[download] Destination: foo.part')
    file_downloader_0.to_screen('\r[download] Unknown % of Unknown size at Unknown speed ETA Unknown ETA')
    file_downloader_0.to_screen('\r\x1b[K[download] Unknown % of Unknown size at Unknown speed ETA Unknown ETA')
    file_downloader_0.to_screen('\r[download] 0.0% of Unknown size at Unknown speed ETA Unknown ETA')

# Generated at 2022-06-26 11:04:59.378951
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    obj = FileDownloader()
    obj.to_screen = lambda *x: None
    obj.to_console_title = lambda *x: None
    arg_0 = {}
    # Test case 1
    arg_0 = {u'total_bytes': None, u'downloaded_bytes': None, u'total_bytes_estimate': None, u'elapsed': 1.564093828201294, u'speed': None}
    obj.report_progress(arg_0)


# Generated at 2022-06-26 11:05:02.078022
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 11:05:09.626526
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # tests download speed
    # check that the download time is larger than 0.1 secs
    print("test_FileDownloader_slow_down")
    if __name__ == '__main__':
        test_case_0()
        sys.exit(0)
    else:
        assert(test_case_0())

test_FileDownloader_slow_down()

# Generated at 2022-06-26 11:05:19.900827
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    str_0 = 'foo.part'
    str_1 = 'foo'
    str_2 = 'foo.part'
    str_3 = 'foo'
    str_4 = 'foo.part'
    str_5 = 'foo'
    FileDownloader.best_block_size(0, 0)
    FileDownloader.best_block_size(0, 0)
    FileDownloader.best_block_size(0, 0)


# Generated at 2022-06-26 11:05:32.431296
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    fd = FileDownloader('', {}, True)
    assert fd.format_seconds(1) == '1.00s'
    assert fd.format_seconds(.1) == '0.10s'
    assert fd.format_seconds(.01) == '0.01s'
    assert fd.format_seconds(0) == '0.00s'
    assert fd.format_seconds(10) == '10.0s'
    assert fd.format_seconds(100) == '100s'
    assert fd.format_seconds(1000) == '16m40s'
    assert fd.format_seconds(10000) == '2h46m40s'


# Generated at 2022-06-26 11:05:57.175446
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Assigning argument 'filename' (line 884)
    # Getting the type of 'filename' (line 884)
    filename_45410 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 884, 18), 'filename')
    # Testing if the type of an if condition is none (line 884)

    if evaluates_to_none(stypy.reporting.localization.Localization(__file__, 884, 4), filename_45410):
        pass
    else:
        
        # Testing the type of an if condition (line 884)
        if_condition_45411 = is_suitable_condition(stypy.reporting.localization.Localization(__file__, 884, 4), filename_45410)
        # Assigning a type to the

# Generated at 2022-06-26 11:06:00.981788
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    elapsed_time = 0
    bytes = 0
    class_0 = FileDownloader()
    new_block_size = class_0.best_block_size(elapsed_time, bytes)


# Generated at 2022-06-26 11:06:10.052743
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    elasped_time = 0.0
    bytes = 0
    fd = FileDownloader({"batch_file":None})
    if (fd.best_block_size(elasped_time, bytes) != 0):
        print("Error! when elasped_time = %s, bytes = %s, best_block_size should be 0, but get %s" % (elasped_time, bytes, fd.best_block_size(elasped_time, bytes)))
        test_case_0()
    elasped_time = -1.0
    bytes = 0

# Generated at 2022-06-26 11:06:11.780025
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    test_case_0()

# Generated at 2022-06-26 11:06:23.669302
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    # Negative test case 0
    # Test type: normal
    # (int_0 >= 0.001) is False, [05.01, 13.01] is False
    int_0 = float(random.randint(0, 0)) / float(random.randint(1, 1000))
    int_1 = random.randint(1, 100)
    int_1 = int(int_1)
    if int_0 >= 0.001 and int_1 <= 4194304:
        assert FileDownloader.best_block_size(int_0, int_1) is not None, 'Assertion error for line number: ' + str(get_line_number()) + ' in method ' + str(get_method_name())
    else:
        assert FileDownloader.best_block_size(int_0, int_1) is None

# Generated at 2022-06-26 11:06:36.041543
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """Report download progress."""
    import StringIO
    progress_stream = StringIO.StringIO()
    fd = FileDownloader({}, {}, progress_stream)
    fd.report_progress({'total_bytes': 100, 'downloaded_bytes': 90, 'speed': 10})
    assert progress_stream.getvalue() == "", "Report progress failed"
    progress_stream = StringIO.StringIO()
    fd.report_progress({'total_bytes': 100, 'downloaded_bytes': 90, 'speed': 10})
    assert progress_stream.getvalue() == "", "Report progress failed"
    progress_stream = StringIO.StringIO()
    fd.report_progress({'total_bytes': 100, 'downloaded_bytes': 90, 'speed': 10})

# Generated at 2022-06-26 11:06:42.724925
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Parameters
    start_time = 0.0
    now = 0.0
    byte_counter = 0

    # Return value
    # Return value type:  -
    # Return value description:  -
    retVal = FileDownloader.slow_down(start_time, now, byte_counter)

    return retVal


# Generated at 2022-06-26 11:06:47.645497
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    try_0 = FileDownloader()
    # Should not throw an exception
    try_0.try_utime('file', 'file')

# Generated at 2022-06-26 11:06:50.313739
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    global int_0
    FileDownloader.report_progress(int_0)


# Generated at 2022-06-26 11:06:55.093947
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd0 = FileDownloader(None)
    try:
        fd0.try_rename(u'downloads/download.ts', u'downloads/2.ts_converted')
    except AttributeError:
        assert False


# Generated at 2022-06-26 11:07:10.453766
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_FileDownloader = FileDownloader()

    # Test properties and methods of library pytube
    # Test properties and methods of library pytube.exceptions
    # Test properties and methods of library pytube.compat
    # Test properties and methods of library pytube.helpers
    # Test properties and methods of library pytube.streams
    # Test properties and methods of library pytube.contrib
    # Test properties and methods of library pytube.extract
    # Test properties and methods of library pytube.__main__
    # Test properties and methods of library pytube.cipher
    # Test properties and methods of library pytube.cache
    # Test properties and methods of library pytube.cli
    # Test properties and methods of library pytube.query

    # Test code
    # Test if first argument of function is callable

# Generated at 2022-06-26 11:07:16.513353
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Create and initialize object
    downloader = FileDownloader({}, YoutubeDL(params={}))
    filename = "moo"

    # Check that report file already downloaded already exists is printed
    downloader.report_file_already_downloaded(filename)



# Generated at 2022-06-26 11:07:20.017916
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    int_0 = 0
    obj_0 = FileDownloader()
    obj_0.download("abc", int_0)


# Generated at 2022-06-26 11:07:31.330958
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    #Test case 0
    int_0 = FileDownloader.calc_speed(1.0, 1.0, 1)
    if (int_0 != None):
        print("test case 0 failed")
    #Test case 1
    int_0 = FileDownloader.calc_speed(0.0, 1.0, 1)
    if (int_0 != None):
        print("test case 1 failed")
    #Test case 2
    int_0 = FileDownloader.calc_speed(1.0, 0.0, 1)
    if (int_0 != None):
        print("test case 2 failed")
    #Test case 3
    int_0 = FileDownloader.calc_speed(1.0, 1.0, 0)
    if (int_0 != None):
        print("test case 3 failed")

# Generated at 2022-06-26 11:07:33.861208
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    file_downloader_0 = FileDownloader()
    str_0 = file_downloader_0.format_retries(int_0)
    assert str_0 != None


# Generated at 2022-06-26 11:07:37.301927
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader()
    fd.slow_down(0, 0, 0)
    pass



# Generated at 2022-06-26 11:07:42.701141
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    params = { "noprogress" : False, "continuedl" : True, "nopart" : False, "max_sleep_interval" : 1.0, "sleep_interval" : 1.0 }
    ydl = YoutubeDL(params)
    fd = FileDownloader(ydl, params)
    # test case 0
    s = { "downloaded_bytes" : 0, "eta" : None, "total_bytes_estimate" : None, "total_bytes" : None, "elapsed" : 0, "speed" : None, "status" : "downloading" }
    test_case_0()



# Generated at 2022-06-26 11:07:51.889629
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    try_utime_0_FileDownloader = FileDownloader(JsonParams(None, None, None, None, None, None, None, None, None))
    try_utime_0_FileDownloader.params = JsonParams(None, None, None, None, None, None, None, None, None)
    try_utime_0_filename = ""
    try_utime_0_last_modified_hdr = None
    # Call method
    try_utime_0_FileDownloader.try_utime(try_utime_0_filename, try_utime_0_last_modified_hdr)
    return


# Generated at 2022-06-26 11:07:59.308019
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    obj_0 = FileDownloader(None, None)
    int_0 = 100000000
    str_0 = obj_0.format_retries(int_0)

    assert int_0 == 100000000
    assert str_0 == 'inf'


# Generated at 2022-06-26 11:08:03.140735
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    FileDownloader.parse_bytes('1b')
    # test_case_0()


# Generated at 2022-06-26 11:08:15.539721
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = 0.0
    now = 0.0
    byte_counter = 0
    f_d = FileDownloader()
    f_d.slow_down(start_time,now,byte_counter)


# Generated at 2022-06-26 11:08:19.969764
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    ydl = FileDownloader(object())
    if ydl.best_block_size(0, 0) != 1:
        assert True
    if ydl.best_block_size(0, 1) != 1:
        assert True
    if ydl.best_block_size(3, 1) != 0:
        assert True
    if ydl.best_block_size(0, 1024) != 1:
        assert True
    if ydl.best_block_size(0, 1025) != 2:
        assert True
    if ydl.best_block_size(0, 10240) != 4:
        assert True
    if ydl.best_block_size(1, 10240) != 10240:
        assert True

# Generated at 2022-06-26 11:08:27.741189
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader()

# Generated at 2022-06-26 11:08:35.508397
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    params = {'param1': 3, 'param2': 2, 'param3': 1, 'key': 'value'}
    params['nopart'] = False
    ydl = FileDownloader(params)

    instance_of_FileDownloader = ydl

    expected_value = 'filename'

    if not isinstance(test_case_0(), object):
        print('test_case_0() returns a non-object')
        return

    actual_value = instance_of_FileDownloader.temp_name('filename')
    assert actual_value == expected_value

# Generated at 2022-06-26 11:08:43.664831
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    s = {'status': 'finished', 'total_bytes': 1337, 'elapsed': 42}
    fd.report_progress(s)
    s = {'status': 'downloading', 'elapsed': 1000001}
    fd.report_progress(s)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:08:51.848959
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = random.uniform(0, 10000)
    now = random.uniform(0, 10000)
    byte_counter = random.uniform(0, 10000)

    downloader = FileDownloader(YoutubeDL({}))
    downloader.slow_down(start_time, now, byte_counter)


# Generated at 2022-06-26 11:08:55.600439
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Instantiate the class to be tested
    test_obj = FileDownloader(add_default_args(None))

    # Set inputs
    s = {'status': 'Downloaded'}

    # Invoke method
    test_obj.report_progress(s)


# Generated at 2022-06-26 11:09:00.157442
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_FileDownloader = FileDownloader()
    test_FileDownloader._progress_hooks = []
    test_FileDownloader._report_progress_status = test_case_0
    str_0 = 'Status'
    test_FileDownloader_report_progress_0_0 = test_FileDownloader.report_progress(str_0)
    return test_FileDownloader_report_progress_0_0


# Generated at 2022-06-26 11:09:03.709655
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    obj_0 = FileDownloader()
    # report_progress is not implemented in parent class InfoExtractor
    # test_case_0 is not implemented
    # see 'todo' section at the top of this file
test_case_0()

test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:09:14.096007
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    print(' '*5 +'**Running test_FileDownloader_try_utime...')
    print(' '*10 +'Test Case 0...')
    test_case_0()
    print(' '*10 +'Test Case 1...')
    test_case_1()
    print(' '*10 +'Test Case 2...')
    test_case_2()
    print(' '*10 +'Test Case 3...')
    test_case_3()
    print(' '*10 +'Test Case 4...')
    test_case_4()

# Generated at 2022-06-26 11:09:28.508820
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from os.path import abspath, basename, dirname
    from tempfile import NamedTemporaryFile
    from youtube_dl import YoutubeDL
    from youtube_dl.InfoExtractors import YoutubeIE
    # Test for argument `filename`
    # Call FileDownloader.download without a downloader
    # Call FileDownloader.download with a missing InfoExtractor
    # Call FileDownloader.download with a missing InfoExtractor
    video_url = 'https://www.youtube.com/watch?v=BaW_jenozKc#t=3m27'
    ydl = YoutubeDL({'format': '1', 'continuedl': True, 'sleep_interval': 0, 'quiet': True, 'noprogress': True})
    ydl.add_default_info_extractors()
    ydl.add_info_ext

# Generated at 2022-06-26 11:09:30.378020
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(params=None, ydl=None)
    filename = 'filename'
    info_dict = {}
    file_downloader_0.download(filename, info_dict)


# Generated at 2022-06-26 11:09:33.070290
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    file_downloader = FileDownloader()
    test_case_0()


# Generated at 2022-06-26 11:09:40.802334
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    if FileDownloader.parse_bytes("20g"):
        pass
    elif not FileDownloader.parse_bytes("200"):
        pass
    elif not FileDownloader.parse_bytes("200%"):
        pass
    elif not FileDownloader.parse_bytes("-10"):
        pass
    elif not FileDownloader.parse_bytes("%10"):
        pass
    elif not FileDownloader.parse_bytes("100k45"):
        pass
    elif not FileDownloader.parse_bytes("100k45%"):
        pass
    elif not FileDownloader.parse_bytes("100k45asd"):
        pass
    elif not FileDownloader.parse_bytes("100"):
        pass
    elif not FileDownloader.parse_bytes("100%"):
        pass


# Generated at 2022-06-26 11:09:44.697260
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Instantiating object
    fd = FileDownloader('url', {})

    assert fd.try_utime('filename', 'timestr') is None


# Generated at 2022-06-26 11:09:53.844213
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_1 = 1
    #test case 0
    int_2 = 2
    #test case 1
    int_3 = 3
    #test case 2
    int_4 = 4
    #test case 3
    int_5 = 5
    #test case 4
    int_6 = 6
    #test case 5
    int_7 = 7
    #test case 6
    int_8 = 8
    #test case 7
    int_9 = 9
    #test case 8
    int_10 = 10
    #test case 9
    int_11 = 11
    #test case 10
    int_12 = 12
    #test case 11


# Generated at 2022-06-26 11:10:00.022654
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()


# Generated at 2022-06-26 11:10:04.965707
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Add test code here
    fileDown = FileDownloader()
    name = fileDown.temp_name("1")
    assert name == "1.part"


# Generated at 2022-06-26 11:10:09.309566
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader()
    fd.try_utime('test_file', '20150101')
    assert fd.try_utime('test_file', '20150101') is not None


# Generated at 2022-06-26 11:10:16.324239
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():

    int_0 = 0
    int_0 = 0

    # TEST CASE:
    print("test_case_0")
    test_case_0()


if __name__ == '__main__':
    test_FileDownloader_calc_eta()

# Generated at 2022-06-26 11:10:33.168430
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    a = 100.0
    b = 1.0
    c = 1.0
    actual = FileDownloader.best_block_size(a, b)
    expected = c
    if c != actual:
        print("Test Failed on Line " + str(inspect.stack()[0][2]))
        print("\tExpected: "+str(expected))
        print("\tActual: "+str(actual))


# Generated at 2022-06-26 11:10:39.908908
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.b = 0
    file_downloader_0.best_block_size(1)
    file_downloader_0.best_block_size(0.5)
    file_downloader_0.best_block_size(2)
    file_downloader_0.best_block_size(1)
    file_downloader_0.best_block_size(0)
    file_downloader_0.best_block_size(0.5)
    file_downloader_0.best_block_size(2)


# Generated at 2022-06-26 11:10:42.316755
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 11:10:50.980129
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    """Function test_parse_bytes of FileDownloader class."""
    assert FileDownloader.parse_bytes("1") == 1
    assert FileDownloader.parse_bytes("1k") == 1000
    assert FileDownloader.parse_bytes("1m") == 1000000
    assert FileDownloader.parse_bytes("1g") == 1000000000
    assert FileDownloader.parse_bytes("1t") == 1000000000000
    assert FileDownloader.parse_bytes("1p") == 1000000000000000
    assert FileDownloader.parse_bytes("1e") == 1000000000000000000
    assert FileDownloader.parse_bytes("1z") == 1000000000000000000000
    assert FileDownloader.parse_bytes("1y") == 1000000000000000000000000
    assert FileDownloader.parse_bytes("1.1") == 1

# Generated at 2022-06-26 11:10:59.686925
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)

# Generated at 2022-06-26 11:11:09.092164
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    assert file_downloader_0.report_progress(s={'status': 'finished'}) == None, 'Failed at line 62'
    assert file_downloader_0.report_progress(s={'status': 'downloading'}) == None, 'Failed at line 63'
    assert file_downloader_0.report_progress(s={'status': 'downloading', 'elapsed': 0.0, 'speed': 0.0, 'downloaded_bytes': 0, 'eta': 0}) == None, 'Failed at line 64'
    assert file_downloader_0.report_progress(s={'status': 'downloading', 'percent': 10.0, 'speed': 10.0})

# Generated at 2022-06-26 11:11:15.799361
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.slow_down(2.0, 3.0, 1)  # This method is not really tested here, because there is no reliable way to test that it actually slows down.


# Generated at 2022-06-26 11:11:26.185116
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    list_1 = []
    tuple_1 = ()
    file_downloader_1 = FileDownloader(list_1, tuple_1)
    try:
        assert isinstance(file_downloader_1.temp_name(None), str)
    except AssertionError:
        raise AssertionError(
            'Test FileDownloader.temp_name is failed. Unexpected input.')

    try:
        assert file_downloader_1.temp_name('test_FileDownloader_temp_name.tmp') \
            == 'test_FileDownloader_temp_name.tmp.part'
    except AssertionError:
        raise AssertionError(
            'Test FileDownloader.temp_name is failed. Unexpected output.')


# Generated at 2022-06-26 11:11:28.608214
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    """Unit test for method FileDownloader.try_rename"""


# Generated at 2022-06-26 11:11:35.158779
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.slow_down(1435273140, 1435273141, 0)
    file_downloader_0.slow_down(1435273141, 1435273141, 0)


# Generated at 2022-06-26 11:11:49.638423
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    assert file_downloader_0.format_retries(1.0) == 1.0


# Generated at 2022-06-26 11:11:54.286276
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = [' ']
    tuple_0 = (1,)
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    int_0 = file_downloader_0.calc_speed(0, 0, 0)
    assert int_0 is None


# Generated at 2022-06-26 11:11:57.739661
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Create a FileDownloader instance
    file_downloader_0 = FileDownloader(['--no-part'], {'nopart': True, 'ratelimit': 0.0})
    # Invoke method slow_down of FileDownloader instance file_downloader_0
    file_downloader_0.slow_down(0.0, 0.0, 0)



# Generated at 2022-06-26 11:12:03.961035
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    time_0 = time.time()
    time_0 = time.time()
    file_downloader_0.slow_down(time_0, time_0, 1)


# Generated at 2022-06-26 11:12:09.441134
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    file_downloader_0.try_rename('-', '-')


# Generated at 2022-06-26 11:12:16.231758
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_0  = tempfile.NamedTemporaryFile(delete=False)
    file_0.close()
    filename = file_0.name

    downloader_0 = FileDownloader(None, None)
    file_time = downloader_0.try_utime(filename, None)
    assert file_time is None, "The return value of the function try_utime is " \
                              "None, but it should be %s." % file_time
    os.remove(filename)


# Generated at 2022-06-26 11:12:27.926370
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('10k') == 10240
    assert FileDownloader.parse_bytes('10') == 10
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('1.0M') == 1048576
    assert FileDownloader.parse_bytes('1.0MB') == 1048576
    assert FileDownloader.parse_bytes('1.0G') == 1073741824
    assert FileDownloader.parse_bytes('1.0GB') == 1073741824
    assert FileDownloader.parse_bytes('1.0Ki') == 1024
    assert FileDownloader.parse_bytes('1.0K') == 1024
    assert FileDownloader.parse_bytes('1.0KiB') == 1024

# Generated at 2022-06-26 11:12:33.744759
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_1 = []
    tuple_1 = ()
    file_downloader_1 = FileDownloader(list_1, tuple_1)
    file_downloader_1.download("filename", "info_dict")


# Generated at 2022-06-26 11:12:40.883214
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    from difflib import Differ
    from io import StringIO

    list_0 = []
    tuple_0 = ()
    file_downloader_0 = FileDownloader(list_0, tuple_0)
    best_block_size_0 = file_downloader_0.best_block_size(1, 1)
    diff = Differ().compare(str(best_block_size_0), "1024")
    print(list(diff))

    best_block_size_0 = file_downloader_0.best_block_size(1, 2)
    diff = Differ().compare(str(best_block_size_0), "2048")
    print(list(diff))

    best_block_size_0 = file_downloader_0.best_block_size(4, 10)
    diff = Differ

# Generated at 2022-06-26 11:12:51.311832
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    args = ["--ignore-errors", "-o", "/tmp/a4pb0fhwqc.flv", "--no-part", "--write-description", "--write-info-json", "--write-thumbnail", "--max-filesize", "2.5GB", "https://www.youtube.com/watch?v=5ylwf5zEjK8"]
    ydl_opts = {}
    dl = FileDownloader(args, ydl_opts)