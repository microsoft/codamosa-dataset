

# Generated at 2022-06-26 11:03:44.647742
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = ['--dl-num-retries=4']
    str_0 = 's0(9Y,E{Np'
    file_downloader_0 = FileDownloader(list_0, str_0)
    info_dict_0 = {'age_limit': 4, 'playlist_end': 'U6PxUc%[5H"|9YMg', 'resolution': 'C(.H=)'}
    str_1 = 'BZ.25{j'
    file_downloader_0.download(str_1, info_dict_0)


# Generated at 2022-06-26 11:03:56.745628
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    str_0 = '^e  A6U)A6U)A6U)A6U)A6U)A6U)A6U)A6U)A6U)A6U)ER'
    file_downloader_0 = FileDownloader(list_0, str_0)
    float_1 = float('nan')
    float_2 = float('-inf')
    float_3 = float('nan')
    float_4 = float('inf')
    float_5 = float('inf')
    file_downloader_0.slow_down(float_4, float_3, float_5)
    file_downloader_0.slow_down(float_1, float_2, float_0)
    float_6 = float('inf')

# Generated at 2022-06-26 11:04:00.512619
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """
    Test if the method returns the expected result
    """
    list_0 = []
    str_0 = 'dW_P}[fJG'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_1 = 'p1]9XH<J!'
    result = file_downloader_0.try_utime(str_1, None)
    assert(result == None)


# Generated at 2022-06-26 11:04:05.414886
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    list_0 = []
    str_0 = '\u00123'
    FileDownloader_0 = FileDownloader(list_0, str_0)
    str_0 = '\\'
    FileDownloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:04:19.397882
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_1 = 'f[7Vuw'

# Generated at 2022-06-26 11:04:30.029790
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)

    dict_0 = dict()
    dict_0['status'] = 'finished'
    dict_0['elapsed'] = 5.0
    dict_0['total_bytes'] = 15.0
    dict_0['downloaded_bytes'] = 15.0

    file_downloader_0.report_progress(dict_0)

    dict_1 = dict()
    dict_1['status'] = 'finished'
    dict_1['elapsed'] = 6.0
    dict_1['total_bytes'] = 16.0
    dict_1['downloaded_bytes'] = 16.0

    file_downloader_0.report_progress(dict_1)



# Generated at 2022-06-26 11:04:33.479194
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = 'sdc'
    dict_0 = {}
    file_downloader_0.download(str_0, dict_0)


# Generated at 2022-06-26 11:04:37.055388
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    str_2 = ']'
    str_3 = '#Ki'
    file_downloader_0 = FileDownloader(list_0, str_2)
    assert_raises_regexp(NotImplementedError, 'This method must be implemented by subclasses', file_downloader_0.download, str_3, str_0, str_1)


# Generated at 2022-06-26 11:04:46.551380
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    dl = FileDownloader([], '')
    assert(dl.best_block_size(1, 10) == 10)
    assert(dl.best_block_size(0, 10) <= 4194304)
    assert(dl.best_block_size(1, 0) == 1)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_best_block_size()

# Generated at 2022-06-26 11:04:53.930428
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    str_0 = ' :G'
    file_downloader_0 = FileDownloader(list_0, str_0)
    float_0 = file_downloader_0.calc_speed(0.0, 0.0, 0)
    assert_equals(float_0, None)
    # Unreachable
    # float_0 = file_downloader_0.calc_speed(0.0, 0.0, 0)
    # assert_equals(float_0, None)
    float_3 = file_downloader_0.calc_speed(0.0, 0.0, 0)
    assert_equals(float_3, None)


# Generated at 2022-06-26 11:05:16.251767
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    os.system('clear')

    test_list = ['youtube-dl', '--no-warnings']
    test_str = 'https://www.youtube.com/watch?v=J---aiyznGQ'
    test_downloader = FileDownloader(test_list, test_str)

    print("Testing report_progress()")
    # Status downloading

# Generated at 2022-06-26 11:05:24.691515
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    str_0 = ';#{t'
    file_downloader_0 = FileDownloader(list_0, str_0)
    int_0 = random.randint(0, 999999)
    int_1 = random.randint(0, 999999)
    int_2 = random.randint(0, 999999)
    int_3 = random.randint(0, 999999)
    file_downloader_0.slow_down(int_0, int_1, int_2)
    file_downloader_0.slow_down(int_0, int_1, int_3)
    test_FileDownloader_report_progress_0()


# Generated at 2022-06-26 11:05:28.402877
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    assert FileDownloader(list_0, str_0).slow_down(start_time, now, byte_counter) == None


# Generated at 2022-06-26 11:05:36.655206
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('13') == 13
    assert FileDownloader.parse_bytes('13.7') == 13.7
    assert FileDownloader.parse_bytes('13.7k') == 14047.2
    assert FileDownloader.parse_bytes('13.7K') == 14047.2
    assert FileDownloader.parse_bytes('13.7kb') == 14047.2
    assert FileDownloader.parse_bytes('13.7KB') == 14047.2
    assert FileDownloader.parse_bytes('13.7Gi') == 147251205120.0
    assert FileDownloader.parse_bytes('13.7ki') == 14043.392
    assert FileDownloader.parse_bytes('13.7m') == 14400000.0

# Generated at 2022-06-26 11:05:46.033116
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    str_0 = 'zg#f|'
    file_downloader_0 = FileDownloader(list_0, str_0)
    file_downloader_0.params['ratelimit'] = 0.0
    assert_equals(file_downloader_0.params['ratelimit'], 0.0)
    assert_equals(file_downloader_0.params.get('ratelimit'), 0.0)
    file_downloader_0.params['ratelimit'] = -1.0
    assert_equals(file_downloader_0.params['ratelimit'], -1.0)
    assert_equals(file_downloader_0.params.get('ratelimit'), -1.0)

# Generated at 2022-06-26 11:05:48.288279
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # TODO
    pass


# Generated at 2022-06-26 11:05:53.440250
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    arg_0 = None
    arg_1 = None
    file_downloader_0 = FileDownloader(arg_0, arg_1)
    outfile_0 = None
    timestamp = file_downloader_0.try_utime(arg_1, arg_0)


# Generated at 2022-06-26 11:05:59.655482
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    cmd_args = ['--skip-download', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    ydl_opts = {}
    fd = FileDownloader(cmd_args, ydl_opts)
    fd.download(1, 1)


# Generated at 2022-06-26 11:06:07.664256
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    str_0 = 'W8Xe&gh=.h'
    file_downloader_0 = FileDownloader(list_0, str_0)
    time_0 = time.time()
    time_0 *= 1000
    time_0 += -1970
    time_1 = time.time()
    time_1 *= 1000
    time_1 += -1970
    int_0 = file_downloader_0.calc_speed(time_0, time_1, -345)
    assert int_0 is None


# Generated at 2022-06-26 11:06:14.839349
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    str_0 = ' )2'
    file_downloader_0 = FileDownloader(list_0, str_0)

    float_0 = float(0.0)
    float_1 = float(0.0)
    float_2 = float(0.0)
    file_downloader_0.slow_down(float_0, float_1, float_2)


# Generated at 2022-06-26 11:06:39.214101
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = 'dspj.\\'
    file_downloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:06:47.147874
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    # Test with parameters:
    #  - elapsed_time=1.1
    #  - bytes=450
    # Should output:
    #  - return_value=450
    #  - stdout=''
    #  - stderr=''

    current_time = time.time()
    elapsed_time = 1.1
    bytes = 450

    return_value = FileDownloader.best_block_size(elapsed_time, bytes)
    stdout_value = sys.stdout.getvalue()
    stderr_value = sys.stderr.getvalue()
    sys.stdout.seek(0)
    sys.stdout.truncate()
    sys.stderr.seek(0)
    sys.stderr.truncate()

    # Check that the return value is as expected
   

# Generated at 2022-06-26 11:06:50.070927
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test the case where the following statement returns None
    result = FileDownloader.try_utime(str(0), str(0))
    assert result is None


# Generated at 2022-06-26 11:06:53.444671
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    FileDownloader_0 = FileDownloader([], ';')
    FileDownloader_0.parse_bytes('')


# Generated at 2022-06-26 11:06:57.547327
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    list_0 = []
    str_0 = 'https://youtube.com/watch?v=YE7VzlLtp-4'
    file_downloader_0 = FileDownloader(list_0, str_0)
    string_0 = '27.7k'
    long_0 = file_downloader_0.parse_bytes(string_0)
    assert long_0 > 0


# Generated at 2022-06-26 11:07:09.132420
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-26 11:07:19.471357
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = ['N', 300, 'J']
    str_0 = 'L$d9'
    file_downloader_0 = FileDownloader(list_0, str_0)
    map_0 = {'F': 'v', 'W': 'F', 'Q': 'N', 'P': 300}
    file_downloader_0.report_progress(map_0)
    map_0 = {'C': 'w', 'S': '#', 'L': 'e', 'B': '0', 'M': '+', 'H': '|', 'Z': 'J', 'A': 'l'}
    file_downloader_0.report_progress(map_0)


# Generated at 2022-06-26 11:07:31.153786
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    list_0 = []
    str_0 = ' ;#{rwk'
    str_1 = ' )i'
    filename = 'test.txt'
    file_downloader_0 = FileDownloader(list_0, str_0)
    filename = file_downloader_0.temp_name(filename)
    assert(file_downloader_0.undo_temp_name(filename) == 'test.txt')
    file_downloader_0.to_screen('test.txt')
    str_2 = 'u_f{r'
    file_downloader_0.report_warning(str_2)
    str_2 = '+?wwrh{'
    file_downloader_0.report_error(str_2)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 11:07:33.942844
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = ['d']
    str_0 = '=^K'
    FileDownloader.report_progress(list_0, str_0)

if __name__ == '__main__':
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:07:46.428830
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = [None, None]
    float_0 = float(1.045)
    float_1 = float(25.0)
    float_2 = float(26.0)
    float_3 = float(27.0)
    float_4 = float(15.0)
    float_5 = float(16.0)
    float_6 = float(17.0)
    float_7 = float(18.0)
    float_8 = float(19.0)
    float_9 = float(20.0)
    float_10 = float(21.0)
    float_11 = float(22.0)
    float_12 = float(23.0)
    float_13 = float(24.0)
    float_14 = float(25.0)

# Generated at 2022-06-26 11:08:04.069238
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = [
        {
            'file': 'file0.avi',
            'format': '720p'
        },
        {
            'file': 'file1.avi',
            'format': '1080p'
        }
    ]
    str_0 = ';#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    file_downloader_0.report_destination = MagicMock(return_value=None)
    file_downloader_0.download({'file': 'file0.avi'}, list_0[0])


# Generated at 2022-06-26 11:08:11.575845
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    list_0 = []
    str_0 = ''
    file_downloader_0 = FileDownloader(list_0, str_0)
    filename_0 = '\n'
    file_downloader_0.temp_name(filename_0)
    filename_0 = 'Z*e&t\x16\xef\x1b\x0c'
    file_downloader_0.temp_name(filename_0)


# Generated at 2022-06-26 11:08:15.469553
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader([], '*')
    file_downloader_0.download('', {})


# Generated at 2022-06-26 11:08:25.794442
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    new_filename = '06Z5IYw1qmo'
    old_filename = 'SH1CfRgtdV8'
    file_downloader_0 = FileDownloader(list(), str())
    file_downloader_0.to_screen = mock.MagicMock()
    file_downloader_0.report_error = mock.MagicMock()
    file_downloader_0.try_rename(new_filename, old_filename)
    assert file_downloader_0.to_screen.call_args_list[0] == mock.call(
        '[download] Destination: 06Z5IYw1qmo'
    )

# Generated at 2022-06-26 11:08:36.511751
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test for function FileDownloader.try_utime
    # A utime is attempted with an invalid time
    filename_0 = "test_downloader.py"
    filename_1 = "test_downloader.py"
    file_downloader_0 = FileDownloader(None, None)
    filetime_0 = file_downloader_0.try_utime(filename_0, "test_downloader.py")
    assert filetime_0 is None

    # A utime is attempted with a valid time
    filename_2 = "test_downloader.py"
    filename_3 = "test_downloader.py"
    file_downloader_1 = FileDownloader(None, None)
    filetime_1 = file_downloader_1.try_utime(filename_2, "test_downloader.py")


# Generated at 2022-06-26 11:08:45.561355
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name(''.part) == '.'
    assert FileDownloader.undo_temp_name('..') == '..'
    assert FileDownloader.undo_temp_name('..part') == '..'
    assert FileDownloader.undo_temp_name('123456.part') == '123456.'
    assert FileDownloader.undo_temp_name('1234567.part') == '1234567.'
    assert FileDownloader.undo_temp_name('12345678.part') == '12345678.'

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_undo_temp_name()

# Generated at 2022-06-26 11:08:52.438999
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = None
    file_downloader_0.try_utime(str_0, str_0)


# Generated at 2022-06-26 11:09:01.019191
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    params = {'verbose': True, 'noprogress': False, 'sleep_interval': 2, 'max_sleep_interval': 3.5}
    fd = FileDownloader({}, None)
    fd.params = params

    status = {'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None, 'speed': None, 'eta': None}
    fd.report_progress(status)
    status = {'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None, 'speed': 1.0, 'eta': None}
    fd.report_progress(status)
    status = {'status': 'downloading', 'downloaded_bytes': 500, 'total_bytes': 30000, 'speed': 2.0, 'eta': 10}
    f

# Generated at 2022-06-26 11:09:04.217562
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Positive test
    test_value_0 = '2K'
    result_parse_bytes = FileDownloader.parse_bytes(test_value_0)
    assert result_parse_bytes == 2048


# Generated at 2022-06-26 11:09:16.191714
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = '<sO'
    assert_equal(file_downloader_0.temp_name(str_0), '<sO.part')
    list_0 = ['-o', '9q7+uI.bE', '--verbose']
    str_0 = 'v<A+'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = '#m~^'
    assert_equal(file_downloader_0.temp_name(str_0), '#m~^.part')
    list_0.append('--no-check-certificate')
    list_

# Generated at 2022-06-26 11:09:38.634166
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    s = {}
    s['status'] = 'finished'

    file_downloader_0.report_progress(s)


if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:09:49.179409
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    list_0 = ['a', 'v']
    str_0 = 'a'
    file_downloader_0 = FileDownloader(list_0, str_0)
    file_downloader_0.params['noprogress'] = True
    file_downloader_0.params['ratelimit'] = None
    file_downloader_0.params['min_filesize'] = None
    file_downloader_0.params['max_filesize'] = None
    file_downloader_0.params['test'] = True
    file_downloader_0.params['ignoreerrors'] = False
    file_downloader_0.params['continuedl'] = True
    file_downloader_0.params['nopart'] = False
    file_downloader_0.params['updatetime'] = True
    file_downloader

# Generated at 2022-06-26 11:10:00.665370
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)
    list_1 = []
    str_1 = '2V7%c$=f&'
    float_0 = float(str_1)
    float_1 = float_0
    str_2 = 'h\x7fA@'
    float_2 = float(str_2)
    float_3 = float_2
    s_0 = {'status': 'downloading', 'total_bytes_estimate': float_1, 'downloaded_bytes': float_3, 'elapsed': float_3, 'speed': float_3, 'eta': float_3, 'total_bytes': float_3}
    file_downloader_0.report_

# Generated at 2022-06-26 11:10:08.072244
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    start_0 = 2.0
    now_0 = 2.0
    bytes_0 = random.randrange(1, 13)

    # Function call of calc_speed
    assert FileDownloader.calc_speed(start_0, now_0, bytes_0) == 0.0


# Generated at 2022-06-26 11:10:15.012370
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    list_0 = []
    str_0 = ' ,%^-#kA'
    file_downloader_0 = FileDownloader(list_0, str_0)
    tuple_0 = (bytes([116, 101, 115, 116, 45, 98, 105, 110]), int(0))
    # The desired return value of try_utime must be populated in the expected
    # variables.
    expected_var_1 = int(0)
    # Invoke try_utime
    actual_var_1 = file_downloader_0.try_utime(*tuple_0)

    assert expected_var_1 == actual_var_1


# Generated at 2022-06-26 11:10:21.371395
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-26 11:10:28.133551
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test with invalid parameter
    str_0 = 'site.com/video.mp4'
    info_dict_0 = 'info_dict_0'
    FileDownloader.download(str_0, info_dict_0)


# Generated at 2022-06-26 11:10:29.097201
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    pass


# Generated at 2022-06-26 11:10:34.207609
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    list_0 = []
    str_0 = '.'
    file_downloader_0 = FileDownloader(list_0, str_0)
    filename = '3jb5f6L5x6'
    file_downloader_0.report_file_already_downloaded(filename)


# Generated at 2022-06-26 11:10:40.888636
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    str_0 = 'y'
    file_downloader_0 = FileDownloader(list_0, str_0)
    float_0 = float('inf')
    float_1 = float('-inf')
    float_2 = float('nan')
    float_3 = float('2.0')
    float_4 = float('-6.0')
    float_5 = float('6.0')
    float_6 = float('1.0')
    float_7 = float('-5.0')
    float_8 = float('5.0')
    float_9 = float('0.0')
    float_10 = float('-4.0')
    float_11 = float('4.0')
    float_12 = float('-3.0')

# Generated at 2022-06-26 11:11:19.432013
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    str_0 = '#{d/X/'
    str_1 = '/tmp/'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_2 = file_downloader_0.download(str_1, list_0)
    assert str_2 == True


# Generated at 2022-06-26 11:11:28.198626
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    str_0 = '+^yb*h'
    file_downloader_0 = FileDownloader(list_0, str_0)
    a = {'downloaded_bytes': '4', 'elapsed': '4', 'total_bytes': '4', 'total_bytes_estimate': '4', 'downloaded_bytes_str': '4', 'total_bytes_str': '4', 'total_bytes_estimate_str': '4', '_speed_str': '4', '_percent_str': '4', '_eta_str': '4'}
    file_downloader_0.report_progress(a)
    a['_percent_str'] = '0'
    file_downloader_0.report_progress(a)

# Generated at 2022-06-26 11:11:38.124672
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    list_1 = []
    str_1 = ' '
    file_downloader_1 = FileDownloader(list_1, str_1)
    list_1 = []
    str_1 = ' '
    file_downloader_1 = FileDownloader(list_1, str_1)
    float_0 = float('inf')
    float_1 = float('inf')
    float_2 = float('inf')
    float_3 = float('inf')
    float_4 = float('inf')
    float_5 = float('inf')
    float_6 = float('inf')
    float_7 = float('inf')
    float_8 = float('inf')
    float_9 = float('inf')
    float_10 = float('inf')
    float_11 = float('inf')

# Generated at 2022-06-26 11:11:44.637482
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    list_0 = []
    str_0 = ' ;#{rwk'
    file_downloader_0 = FileDownloader(list_0, str_0)

    list_1 = []
    str_1 = ' ;#{rwk'
    file_downloader_1 = FileDownloader(list_1, str_1)

    file_downloader_1.try_utime(str_0, str_1)
    pass


# Generated at 2022-06-26 11:11:51.538682
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # UnitTest
    assert FileDownloader.undo_temp_name('list_0') == 'list_0'
    assert FileDownloader.undo_temp_name('list_0.part') == 'list_0'

if __name__ == '__main__':
    test_FileDownloader_undo_temp_name()

# Generated at 2022-06-26 11:12:04.620960
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Constructor tests
    if __package__ is None:
        import sys
        from os import path
        sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
        from FileDownloader import FileDownloader
    else:
        from .FileDownloader import FileDownloader

    float_0 = float()
    float_1 = float()
    int_1 = int()
    float_2 = float()
    int_3 = int()
    float_4 = float()
    int_5 = int()
    float_6 = float()
    int_7 = int()
    float_8 = float()
    int_9 = int()
    float_10 = float()
    int_11 = int()
    float_12 = float()
    int_13 = int()
   

# Generated at 2022-06-26 11:12:10.942299
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = ''
    str_1 = ''
    file_downloader_0 = FileDownloader({}) # file_downloader_0 is class FileDownloader
    file_downloader_0.try_utime(str_0, str_1)


# Generated at 2022-06-26 11:12:16.845732
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    str_0 = ' |%^ }'
    file_downloader_0 = FileDownloader(list_0, str_0)
    float_0 = float('inf')
    float_1 = float('inf')
    float_0 = float('inf')
    float_1 = float('inf')
    float_0 = float('inf')
    float_1 = float('inf')
    float_0 = float('inf')
    float_1 = float('inf')


# Generated at 2022-06-26 11:12:26.362487
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_1 = []
    str_1 = 'o/x!oL'
    file_downloader_1 = FileDownloader(list_1, str_1)
    assert(file_downloader_1.params['noprogress'] == False)
    map_1 = {'total_bytes': 50, 'eta': 30, 'speed': 40, 'status': 'downloading', 'downloaded_bytes': 40}
    file_downloader_1.report_progress(map_1)
    assert(map_1['downloaded_bytes'] == 40)


# Generated at 2022-06-26 11:12:35.078083
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    list_0 = [0]
    str_0 = 'a;$IRW+dI_g'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_1 = '4by3'
    tuple_0 = (1, 17)
    file_downloader_0.try_utime(str_1, tuple_0)

