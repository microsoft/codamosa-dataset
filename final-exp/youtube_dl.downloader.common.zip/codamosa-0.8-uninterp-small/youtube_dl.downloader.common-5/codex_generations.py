

# Generated at 2022-06-26 11:03:27.849637
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = '7Rs'
    dict_0 = {str_0: str_0}
    file_downloader_0 = FileDownloader(str_0, dict_0)
    file_downloader_0.download(str_0, dict_0)


# Generated at 2022-06-26 11:03:31.272201
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    start = time.time()
    time.sleep(0.1)
    elapsed = time.time() - start
    block_size = FileDownloader.best_block_size(elapsed, 0)
    assert block_size == 0


# Generated at 2022-06-26 11:03:38.850582
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = '5E!4|>'
    dict_0 = {str_0: str_0}
    file_downloader_0 = FileDownloader(str_0, dict_0)
    str_1 = 'O9h0QA;'
    str_2 = file_downloader_0.undo_temp_name(str_1)
    return str_2


# Generated at 2022-06-26 11:03:48.626768
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_10 = 'f4,7nI'
    dict_10 = {str_10: str_10}
    file_downloader_0 = FileDownloader(str_10, dict_10)
    str_0 = 'f4,7nI'
    dict_0 = {str_0: str_0}
    file_downloader_0 = FileDownloader(str_0, dict_0)
    str_3 = 'f4,7nI'
    dict_3 = {str_3: str_3}
    file_downloader_3 = FileDownloader(str_3, dict_3)
    str_1 = 'f4,7nI'
    dict_1 = {str_1: str_1}
    file_downloader_1 = FileDownloader(str_1, dict_1)

# Generated at 2022-06-26 11:03:53.855516
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = 'fc`@+'
    dict_0 = {str_0: str_0}
    file_downloader_0 = FileDownloader(str_0, dict_0)
    fd_format_retries = file_downloader_0.format_retries(float('inf'))
    assert fd_format_retries == 'inf'


# Generated at 2022-06-26 11:03:59.521667
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
  print('Testing method best_block_size')
  assert FileDownloader.best_block_size(0, 0) == 1, 'Error in FileDownloader.best_block_size'



# Generated at 2022-06-26 11:04:06.137767
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import codecs
    codecs.register(lambda name: codecs.lookup('utf-8') if name == 'cp65001' else None)
    fd = FileDownloader('', {})
    fd.params['continuedl'] = True
    fd.report_file_already_downloaded(u'\u4e0a\u5929\uff0c\u4e0b\u539f')



# Generated at 2022-06-26 11:04:20.071864
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'D'
    dict_0 = {}
    for i in range(7):
        dict_0['_Q8A'] = str_0 * i * i * i * i * i * i * i * i * i * i
    file_downloader_0 = FileDownloader(str_0, dict_0)
    for i in range(7):
        dict_0['G7VuP'] = str_0 * i * i * i * i * i * i * i * i * i * i

# Generated at 2022-06-26 11:04:22.924205
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    file_downloader_1 = FileDownloader('qpU,c*')
    file_downloader_1.report_file_already_downloaded('aLBa')


# Generated at 2022-06-26 11:04:32.754947
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    try:
        # setup
        dummy_ydl = youtube_dl.YoutubeDL({})
        fd = FileDownloader(dummy_ydl, {'format': 'best'})
        fd.to_screen = lambda s: None

        fd.report_progress({'status': 'downloading', 'downloaded_bytes': 10,
                            'total_bytes': 100, 'elapsed': 5})
        assert file_downloader_0.last_reported_progress == 10

        fd.report_progress({'status': 'finished', 'total_bytes': 100,
                            'elapsed': 5})
    except SystemExit as exc:
        if exc.code != 0:
            raise
        pass

if __name__ == '__main__':
    test_FileDownloader_report_progress()

    # Run all

# Generated at 2022-06-26 11:05:01.623155
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    conf = YoutubeDL().params
    fd = FileDownloader(conf, None)
    # test_0
    # assert_true
    # assert_equal
    # assert_false
    assert_true(fd.best_block_size(2.0, 2.0) == 4.0)
    # test_1
    # assert_true
    # assert_equal
    # assert_false
    assert_true(fd.best_block_size(1.0, 1.0) == 2.0)
    # test_2
    # assert_true
    # assert_equal
    # assert_false
    assert_true(fd.best_block_size(4.0, 8.0) == 8.0)


# Generated at 2022-06-26 11:05:04.391678
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:05:07.073452
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    test_case_0()
    # TODO: Add your own implementation of the test case
    pass


# Generated at 2022-06-26 11:05:08.660613
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    test_case_0()


# Generated at 2022-06-26 11:05:14.342963
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    float_0 = 0.1
    assert FileDownloader.calc_eta(float_0, 0, 0) is None
    assert FileDownloader.calc_eta(float_0, 0, 1) is None
    assert FileDownloader.calc_eta(float_0, 1, 1) is None
    #assert FileDownloader.calc_eta(float_0, 1, 2) == 1
    #assert FileDownloader.calc_eta(float_0, 2, 4) == 2


# Generated at 2022-06-26 11:05:19.749630
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Test case test_case_0
    float_0 = 0.1
    int_0 = 0
    assert FileDownloader.best_block_size(float_0, int_0) == 1, 'Test case test_case_0 failed'

# Generated at 2022-06-26 11:05:33.257742
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    global FileDownloader
    # Declare variables used for test
    # Create instance of class 'FileDownloader' with argument 'params'

# Generated at 2022-06-26 11:05:41.176486
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    # Instantiate object
    fd = FileDownloader()
    # Invoke method
    result = fd.calc_eta(float_0, float_0, int_0)  # float, float, int -> float
    # Test result
    assert fd.calc_eta(float_0, float_0, int_0) == float_0


# Generated at 2022-06-26 11:05:50.914516
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None, None, None)
    s = {}
    s['status'] = 'finished'
    fd.report_progress(s)

    fd.params['noprogress'] = False
    s['total_bytes_estimate'] = 0
    s['downloaded_bytes'] = 0
    s['status'] = 'downloading'
    fd.report_progress(s)


# Generated at 2022-06-26 11:05:53.807380
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Setup
    s = {'status': 'Downloading'}
    fd = FileDownloader(None, None)

    # Test
    fd.report_progress(s)


# Generated at 2022-06-26 11:06:15.116325
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = {}
    str_1 = {}
    file_downloader_0 = FileDownloader(str_0, str_1)
    str_0 = None
    file_downloader_0.try_utime(str_0, str_1)


# Generated at 2022-06-26 11:06:25.193625
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = 'HTTP Error 429: Too Many Requests'
    str_2 = 'Unable to download webpage: <urlopen error [Errno 110] Connection timed out> (caused by HTTPError(429, \'Too Many Requests\'))'
    file_downloader_0.trouble(str_1, str_2)
    file_downloader_0.report_warning(str_2)
    file_downloader_0.report_error(str_2)
    str_3 = 'The file has already been downloaded'
    file_downloader_0.report_file_already_downloaded(str_3)

# Generated at 2022-06-26 11:06:33.680197
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = {}
    str_1 = ''
    to_screen_0 = FileDownloader(str_0, str_0).to_screen
    time_time_0 = time.time()
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.ydl.to_screen = to_screen_0
    file_downloader_0.try_utime(str_1, time_time_0)


# Generated at 2022-06-26 11:06:45.400502
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = {}
    str_1 = 'Unknown speed'
    str_2 = 'Test passed'
    str_3 = 'Unknown %'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_4 = {}
    str_4['speed'] = None
    str_4['downloaded_bytes'] = None
    str_4['_speed_str'] = str_1
    str_4['total_bytes'] = None
    str_4['_percent_str'] = str_3
    str_4['eta'] = None
    str_4['_eta_str'] = str_2
    #FileDownloader._report_progress_status(file_downloader_0, str_4)
    #assert str_4['_speed_str'] == get_output_string()


# Generated at 2022-06-26 11:06:50.166429
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = 'SLO'
    file_downloader_0 = FileDownloader(str_0, str_0)
    int_4 = random.randint(1, 10**9)
    s_0 = {'status': 'finished', 'total_bytes': int_4}
    file_downloader_0.report_progress(s_0)
    str_1 = 'RZJ'
    file_downloader_1 = FileDownloader(str_0, str_1)
    int_5 = random.randint(1, 10**9)
    s_1 = {'status': 'finished', 'total_bytes': int_5}
    file_downloader_1.report_progress(s_1)
    str_2 = 'UXU'

# Generated at 2022-06-26 11:07:02.369261
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_case_0()
    str_0 = 'get-video.py'
    str_1 = '/u/14/d/14daf4/v/12.34/get-video.py'
    file_downloader_0 = FileDownloader({'nopart': True}, str_0)
    file_downloader_0 = FileDownloader({'nopart': False}, str_1)
    file_downloader_0 = FileDownloader({'verbose': False}, str_1)
    file_downloader_0 = FileDownloader({'verbose': True}, str_1)
    file_downloader_0 = FileDownloader({'ignoreerrors': False}, str_1)
    file_downloader_0 = FileDownloader({'ignoreerrors': True}, str_1)

# Generated at 2022-06-26 11:07:13.398525
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_progress({
        'status': 'downloading',
        'speed': 14077.76,
        'downloaded_bytes': 181216,
        'total_bytes': 7240854,
        'eta': 8
    })
    file_downloader_0.report_progress({
        'status': 'finished',
        'elapsed': 1,
        'downloaded_bytes': 161216,
        'total_bytes': 15220908
    })

# Generated at 2022-06-26 11:07:18.281600
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    if file_downloader_0.format_retries(10) != 10:
        raise RuntimeError
    return '{0}'.format(file_downloader_0.format_retries(float('inf')))


# Generated at 2022-06-26 11:07:30.644759
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import time
    str_0 = {}
    str_0['total_bytes'] = 1
    str_0['downloaded_bytes'] = 1
    str_0['speed'] = 2
    str_0['eta'] = 3
    str_0['status'] = 'downloading'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.to_screen = lambda x: print(x)
    file_downloader_0.to_console_title = lambda x: print(x)
    file_downloader_0.report_progress(str_0)
    str_0['status'] = 'finished'
    file_downloader_0.report_progress(str_0)
    str_0['total_bytes'] = None

# Generated at 2022-06-26 11:07:33.617717
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    # The following line raises an exception as the function has no arguments
    # file_downloader_0.slow_down()


# Generated at 2022-06-26 11:07:50.325358
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Arrange
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    elapsed_time = 35.0
    bytes = 4.0

    # Act
    actual = file_downloader_0.best_block_size(elapsed_time, bytes)

    # Assert
    assert 175 == actual


# Generated at 2022-06-26 11:08:03.241036
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = {}
    str_1 = {'speed': '%(speed)s %(eta)s', 'speed': '%(speed)s'}
    str_1 = {}
    str_1 = {'status': 'finished', 'total_bytes': '%(total_bytes)s %(elapsed)s'}
    str_1 = {}
    str_1 = {'filename': '%(filename)s %(elapsed)s', 'status': 'finished'}
    str_1 = {'status': 'downloading'}
    str_1 = {'status': 'downloading', 'elapsed': '%(elapsed)s'}

# Generated at 2022-06-26 11:08:10.353561
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    str_0 = {}
    # last_time = 0, num = 0, block_size = 0, sleep_time = 0
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.calc_speed(0, 0, 0) is None


# Generated at 2022-06-26 11:08:21.232677
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.calc_eta(1, 1, 1, 1) is None
    assert file_downloader_0.calc_eta(1, 1, 1, 1) is None
    assert file_downloader_0.calc_eta(1, 1, 1, 1) is None
    assert file_downloader_0.calc_eta(1, 1, 1, 1) is None


# Generated at 2022-06-26 11:08:34.590174
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)

    filename_arg_0 = ""
    filename_res_0 = "."

    assert filename_res_0 == file_downloader_0.temp_name(filename_arg_0)

    filename_arg_0 = ""
    filename_res_0 = "."
    file_downloader_0._params = {}

    assert filename_res_0 == file_downloader_0.temp_name(filename_arg_0)

    filename_arg_0 = "-"
    filename_res_0 = "-"
    file_downloader_0._params = {"nopart": True}

    assert filename_res_0 == file_downloader_0.temp_name(filename_arg_0)


# Generated at 2022-06-26 11:08:39.004157
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:08:40.199242
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_download()

# Generated at 2022-06-26 11:08:44.440570
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = {}
    str_1 = 'YjPd5O-Jk-U'
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.temp_name(str_1) == 'YjPd5O-Jk-U.part'


# Generated at 2022-06-26 11:08:47.468810
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assert FileDownloader.calc_eta((lambda: None)()) is None


# Generated at 2022-06-26 11:08:57.382191
# Unit test for method calc_eta of class FileDownloader

# Generated at 2022-06-26 11:09:10.927595
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Create a new object of class FileDownloader
    file_downloader_0 = FileDownloader('str_0', {}, 'str_1')

    # Create a local variable res_c of type int
    res_c = file_downloader_0.format_retries(float('inf'))

    # Check the value of res_c
    assert res_c == 'inf'


# Generated at 2022-06-26 11:09:15.423932
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    string_0 = ''
    string_1 = ''
    string_1 = file_downloader_0.try_utime(string_0, string_0)
    assert(string_1 is None)


# Generated at 2022-06-26 11:09:25.790952
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    # We only test the functionality of the method but not the correctness
    # of the eta calculations.
    t0 = time.time()
    time.sleep(0.4)
    assert (FileDownloader.calc_eta(t0, time.time(), 4000, 5000) > 30 and
            FileDownloader.calc_eta(t0, time.time(), 4000, 5000) < 80)
    time.sleep(0.6)
    assert FileDownloader.calc_eta(t0, time.time(), 4000, 5000) < 20



# Generated at 2022-06-26 11:09:33.429160
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # Assign parameter values to method
    start = 0.0
    now = 0.0
    bytes = 0

    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.calc_speed(start, now, bytes) is None


# Generated at 2022-06-26 11:09:35.035986
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()


# Generated at 2022-06-26 11:09:38.510196
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test case 0
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.download("a", str_0)
    file = open("output.txt", "r")
    print("Test case 0")
    print("Input: ")
    print("Output: " + file.read())


# Generated at 2022-06-26 11:09:42.564711
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    file_downloader_0 = FileDownloader(str, str)
    file_downloader_0.best_block_size(float, float)


# Generated at 2022-06-26 11:09:48.956129
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = {}
    file_downloader_0.report_progress(str_1)


# Generated at 2022-06-26 11:10:00.599071
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def test_FileDownloader_download_hook(status_dict):
        return None
    d = FileDownloader({"download_archive": "garbage"}, None)
    d.add_progress_hook(test_FileDownloader_download_hook)
    d.report_destination = test_FileDownloader_report_destination
    d.report_progress = test_FileDownloader_report_progress
    d.report_unable_to_resume = test_FileDownloader_report_unable_to_resume
    d.real_download = test_FileDownloader_real_download
    d.to_screen = test_FileDownloader_to_screen
    d.trouble = test_FileDownloader_trouble
    arg0 = "garbage"

# Generated at 2022-06-26 11:10:11.923554
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    while True:
        try:
            file_downloader_0 = FileDownloader(str_0, str_0)
            file_downloader_0.slow_down(float_0, float_0, int_0)
            file_downloader_0.slow_down(float_0, float_0, int_0)
            file_downloader_0.slow_down(float_0, float_0, int_0)
            file_downloader_0.slow_down(float_0, float_0, int_0)
            file_downloader_0.slow_down(float_0, float_0, int_0)
        except type_error:
            assert False
            break
        else:
            break


# Generated at 2022-06-26 11:10:19.752892
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = FileDownloader.try_utime((FileDownloader(str(), str())), str())


# Generated at 2022-06-26 11:10:26.183916
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Create an object of the tested class
    file_downloader_0 = FileDownloader({}, {})

    # Test1: Test function when filetime is None
    try:
        return_value_1 = file_downloader_0.try_utime('A', None)

        # Check return value
        if return_value_1 is None:
            print('Passed')
        else:
            print('Failed')

    except Exception:
        print('Unhandled Exception')


# Generated at 2022-06-26 11:10:36.890122
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(1.0, 1024) == 512
    assert FileDownloader.best_block_size(1.0, 0) == 1
    assert FileDownloader.best_block_size(1.0, 4194304) == 4194304
    assert FileDownloader.best_block_size(0.0, 1024) == 1048576
    assert FileDownloader.best_block_size(1.0, 1048576) == 524288
    assert FileDownloader.best_block_size(1.0, 10485760) == 4194304
    assert FileDownloader.best_block_size(1.0, 104857600) == 4194304
    assert FileDownloader.best_block_size(1.0, 1048576000) == 4194304

# Generated at 2022-06-26 11:10:43.068377
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.temp_name('/a')
    file_downloader_0.temp_name('/a/b/c.txt')


# Generated at 2022-06-26 11:10:46.472681
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assertEqual(FileDownloader.undo_temp_name('filename'), 'filename')
    assertEqual(FileDownloader.undo_temp_name('filename.part'), 'filename')


# Generated at 2022-06-26 11:10:52.660202
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = {}
    file_downloader_0.report_progress(str_1)


# Generated at 2022-06-26 11:10:57.903993
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = "abcd"
    file_downloader_0 = FileDownloader({}, {})
    assert file_downloader_0.undo_temp_name(str_0) == "abcd"
    str_0 = "abcd.part"
    assert file_downloader_0.undo_temp_name(str_0) == "abcd"


# Generated at 2022-06-26 11:11:08.281196
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Creating an instance of the class
    fd = FileDownloader({})

    # Creation of the file
    filename = 'test_try_utime'
    f = open(filename,'w')
    f.close()
    # Calling the function with the following header
    last_modified_hdr = 'Sat, 08 Aug 2015 17:18:51 GMT'
    filetime = fd.try_utime(filename, last_modified_hdr)
    f = open(filename, 'r')
    # Comparing the result with the expected value
    assert filetime == os.fstat(f.fileno()).st_mtime
    # Removing the file
    f.close()
    os.remove(filename)


# Generated at 2022-06-26 11:11:15.944416
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader({'verbose': False}, {})
    assert file_downloader_0 == file_downloader_0
    assert file_downloader_0 != None
    assert file_downloader_0 == None
    assert repr(file_downloader_0) == repr(file_downloader_0)
    assert repr(file_downloader_0) == repr(None)
    assert repr(file_downloader_0) != repr(None)
    assert str(file_downloader_0) == str(None)
    assert str(file_downloader_0) != str(None)
    assert str(file_downloader_0) == str(file_downloader_0)
    assert file_downloader_0 != ''
    assert file_downloader_0 == ''
    file_downloader_

# Generated at 2022-06-26 11:11:19.810131
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.try_utime('-', '-') == None


# Generated at 2022-06-26 11:11:30.815182
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start_0 = 14.3
    now_0 = 10
    bytes_0 = 8
    s_0 = file_downloader_0.calc_speed(start_0, now_0, bytes_0)
    assert(s_0 == 0.8)

    start_0 = 17.8
    now_0 = 5
    bytes_0 = 2
    s_0 = file_downloader_0.calc_speed(start_0, now_0, bytes_0)
    assert(s_0 == 0.4)


# Generated at 2022-06-26 11:11:38.876502
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    ydl = YoutubeDL()
    ydl.params['verbose'] = True
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    try:
        file_moddate = os.path.getmtime("test.mp4")
    except :
        file_moddate = None
    if file_moddate:
        assert(datetime.datetime.fromtimestamp(file_moddate) ==
               datetime.datetime.strptime('2013-11-11 14:46:32', '%Y-%m-%d %H:%M:%S'))
    else:
        print("File not found")

# Code for enabling code coverage (see #408)
import atexit
import signal


# Generated at 2022-06-26 11:11:45.517423
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test case
    str_0 = rfc822.formatdate(os.path.getmtime(encodeFilename('test.mp4'))).encode('ascii')
    str_1 = 'test.mp4'
    # Call function try_utime
    file_downloader_0 = FileDownloader({}, {})
    file_downloader_0.try_utime(str_1, str_0)


# Generated at 2022-06-26 11:11:48.466708
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    start = 0
    current = 0
    total = 0

    file_downloader_0 = FileDownloader()
    assert(file_downloader_0.calc_eta(start, current, total) == None)



# Generated at 2022-06-26 11:11:55.001442
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader({}, {})
    ydl_0 = YoutubeDL({})
    ydl_0.ydl_opts = None
    file_downloader_0.ydl = ydl_0
    str_0 = 'filename'
    str_1 = 'info_dict'
    bool_0 = file_downloader_0.download(str_0, str_1)
    assert bool_0


# Generated at 2022-06-26 11:11:55.760542
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # TODO implement test
    return


# Generated at 2022-06-26 11:12:01.386938
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.downloader.http import HttpFD
    params = {
        'continuedl': True,
        'ratelimit': 1,
        'sleep_interval': 0,
        'noprogress': True,
        'verbose': True,
        'nocheckcertificate': True,
        'retries': 5,
        'test': True,
    }
    temp_ydl = YoutubeDL(params)
    temp_ydl.add_progress_hook = lambda *args, **kargs: None
    fd = FileDownloader(params, temp_ydl)

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'test')

# Generated at 2022-06-26 11:12:03.995001
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    test_case_0()


if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-26 11:12:16.424189
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)

    test_cases = [
        float('inf'),
        float('nan'),
        float('-inf'),
        0.0,
        5.0,
        1.0,
        1.1,
        1.9,
        2.0,
        9.0,
        10.0,
        159.0,
        160.0,
        161.0,
        999.0,
        1000.0,
        1001.0,
    ]


# Generated at 2022-06-26 11:12:24.863803
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    filename_0 = 'filename'
    try:
        file_downloader_0.report_file_already_downloaded(filename_0)
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('UnicodeEncodeError not raised')


# Generated at 2022-06-26 11:12:42.318007
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = {}
    str_1 = {}
    int_0 = 0
    file_downloader_0 = FileDownloader(str_0, str_1)
    file_downloader_0.format_retries(int_0)


# Generated at 2022-06-26 11:12:51.643224
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader({'sleep_interval': float('inf')}, {'continuedl': True, 'nopart': False, 'verbose': False})
    assert file_downloader_0 is not None
    assert file_downloader_0.params == {'sleep_interval': float('inf')}
    assert file_downloader_0.ydl is not None
    assert file_downloader_0._progress_hooks == []
    assert file_downloader_0.sleep_interval == float('inf')
    assert file_downloader_0.params == {'sleep_interval': float('inf')}
    assert file_downloader_0.ydl is not None
    assert file_downloader_0._progress_hooks == []