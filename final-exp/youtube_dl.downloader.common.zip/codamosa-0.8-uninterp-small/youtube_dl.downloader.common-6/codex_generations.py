

# Generated at 2022-06-26 11:03:15.411038
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    int_0 = float_0.to_string()
    float_1 = 1387.733
    float_2 = 1387.733
    file_downloader_0.slow_down(int_0, float_1, float_2)


# Generated at 2022-06-26 11:03:20.819705
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start_0 = 1387.733
    now_0 = 1387.733
    bytes_0 = 1387.733
    assert FileDownloader.calc_speed(start_0, now_0, bytes_0) == float('inf')


# Generated at 2022-06-26 11:03:26.439447
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # Initializing floating point variable with value: 1387.733
    float_0 = 1387.733
    # Initializing File Downloader object with arguments: float_0 and float_0
    file_downloader_0 = FileDownloader(float_0, float_0)
    # Calling report_file_already_downloaded function with argument: file_downloader_0
    test_case_0()


# Generated at 2022-06-26 11:03:32.010521
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 0.0
    file_downloader_0 = FileDownloader(float_0, float_0)
    int_0 = file_downloader_0.block_size
    int_1 = file_downloader_0.block_size
    float_1 = 0.0
    file_downloader_0.slow_down = float_1
    assert int_0  == int_1


# Generated at 2022-06-26 11:03:37.995721
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    float_0 = 509.6
    file_downloader_0 = FileDownloader(float_0, float_0)
    float_0 = 1177.9
    float_1 = 1089.528
    float_2 = float_1 / float_0
    assert float_2 == float_1 / float_0


# Generated at 2022-06-26 11:03:47.324369
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    report_error = FileDownloader.report_error
    with file(__file__, 'rb') as f:
        str_0 = f.read()
    with file(__file__, 'wb') as f:
        f.write(str_0)
    assert len(str_0) == os.path.getsize(__file__)
    fd = FileDownloader({'ratelimit': 1e+1}, None)
    with LockFile(__file__) as lockfile:
        start_time = time.time()
        fd.slow_down(start_time, None, len(str_0))
        time.sleep(1)
    os.unlink(__file__)


# Generated at 2022-06-26 11:03:52.409775
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    var_1 = file_downloader_0.to_screen()
    int_0 = 0
    int_1 = 0
    file_downloader_0.slow_down(int_0, int_1, int_1)


# Generated at 2022-06-26 11:03:53.584796
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    pass


# Generated at 2022-06-26 11:03:59.701874
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_0 = FileDownloader()
    try:
        raise TypeError
    except TypeError:
        a = traceback.format_exc()
        file_downloader_0.to_screen(a)

# Generated at 2022-06-26 11:04:08.750749
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    var_0 = file_downloader_0.to_screen()
    float_0 = float_0
    float_1 = float_0
    file_downloader_0.slow_down(float_0, float_1, float_0)


# Generated at 2022-06-26 11:04:34.110044
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    download_0 = FileDownloader.download('test_data/test_video.mp4', None)
    return download_0


# Generated at 2022-06-26 11:04:36.429852
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    map_0 = {}
    file_downloader_0.report_progress(map_0)


# Generated at 2022-06-26 11:04:38.269999
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    arg_0 = 'foo'
    arg_1 = 'bar'
    result = FileDownloader.try_utime(arg_0, arg_1)
    assert result == None
    assert True



# Generated at 2022-06-26 11:04:46.713945
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    float_0 = 674.092
    # Create instance FileDownloader with arguments float_0 and float_0
    file_downloader_0 = FileDownloader(float_0, float_0)
    # Test case with arguments float_0 and float_0
    assert file_downloader_0.calc_speed(float_0, float_0, float_0) is None


# Generated at 2022-06-26 11:04:54.625280
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    str_0 = 'Unknown speed'
    str_1 = 'Unknown ETA'
    str_2 = 'Unknown %'
    str_3 = 'Unknown speed'
    str_4 = 'Unknown ETA'
    str_5 = 'Unknown %'
    str_6 = 'Unknown speed'
    str_7 = 'Unknown ETA'
    str_8 = 'Unknown %'
    str_9 = 'Unknown speed'
    str_10 = 'Unknown ETA'
    str_11 = 'Unknown %'
    str_12 = 'Unknown speed'
    str_13 = 'Unknown ETA'
    str_14 = 'Unknown %'
    str_15 = 'Unknown speed'
    str_

# Generated at 2022-06-26 11:05:03.784984
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    float_0 = 299.7
    file_downloader_0 = FileDownloader(float_0, float_0)
    var_0 = file_downloader_0.try_utime('tests/test_data/test_video/test.mp4', 'Thu, 31 Jan 2013 22:35:26 GMT')
    var_1 = file_downloader_0.try_utime(var_0, 'Tue, 16 Oct 2018 03:04:23 GMT')
    var_2 = file_downloader_0.try_utime('tests/test_data/test_video/test.mp4', 'Wed, 18 Jul 2018 07:52:56 GMT')

# Generated at 2022-06-26 11:05:05.365376
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    pass



# Generated at 2022-06-26 11:05:07.541318
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:05:10.418582
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    filename = 'filename.part'
    fd = FileDownloader(None, None)
    assert fd.undo_temp_name(filename) == 'filename'

# Generated at 2022-06-26 11:05:23.600606
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    downloader = FileDownloader("testid", "testname")

    assert downloader._parse_bytes("1") == 1
    assert downloader._parse_bytes("200") == 200
    assert downloader._parse_bytes("1k") == 1024
    assert downloader._parse_bytes("1K") == 1024
    assert downloader._parse_bytes("1000k") == 1024000
    assert downloader._parse_bytes("1.24M") == 1310720
    assert downloader._parse_bytes("1,24M") == 1310720
    assert downloader._parse_bytes("1.24 G") == 134217728
    assert downloader._parse_bytes("1,24 G") == 134217728
    assert downloader._parse_bytes("1.24 T") == 137438953472

# Generated at 2022-06-26 11:05:50.982192
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 6688
    dbl_0 = 0.0691543488
    float_0 = 4241.7577
    file_downloader_0 = FileDownloader(int_0, float_0)
    file_downloader_0.slow_down(dbl_0, float_0, float_0)



# Generated at 2022-06-26 11:05:58.335501
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Constants to be used by test case.
    const_float_0 = 926.1081
    const_int_0 = -7605
    const_float_1 = -6.94871
    const_int_1 = -8255
    const_str_0 = '\x1f\x1d\x1f\x1f\x19\x0b'
    const_str_1 = '\x1d\x1d\x1c\x1d\x1f\x0b'
    const_str_2 = '<\x03S.\x1d\x12'
    const_str_3 = '\x0c\x0b\x06\x0c\x0b\x0c'
    const_int_2 = 3390
    const_int_

# Generated at 2022-06-26 11:06:08.861793
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Initiate FileDownloader object with input parameters
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    # Test with filename = '-'
    filename = '-'
    ref = '-'
    var = file_downloader_0.temp_name(filename)
    assert var == ref, "When filename = '-', temp_name should return '-' instead of {}".format(var)

    # Test with filename = 'Romeo+Juliet.1996.720p.bluray.x264.yify.mp4'
    filename = 'Romeo+Juliet.1996.720p.bluray.x264.yify.mp4'

# Generated at 2022-06-26 11:06:17.641944
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fileDownloader = FileDownloader(1, 1)
    fileDownloader.reserved_filename = False
    fileDownloader.params = {}
    fileDownloader.report_resuming_byte = Mock()
    fileDownloader.report_destination = Mock()
    fileDownloader.report_progress = Mock()
    fileDownloader.to_screen = Mock()
    fileDownloader.report_error = Mock()
    fileDownloader.report_file_already_downloaded = Mock()
    fileDownloader.to_console_title = Mock()
    fileDownloader.temp_name = Mock()
    fileDownloader.ydl_filename = Mock()
    fileDownloader.try_rename = Mock()
    fileDownloader.trouble = Mock()
    fileDownloader.slow_down = Mock()
    fileDownloader.report

# Generated at 2022-06-26 11:06:20.885310
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_0 = FileDownloader(None, None)
    s = {'total_bytes_estimate': None, 'eta': None}
    file_downloader_0.report_progress(s)

# Generated at 2022-06-26 11:06:34.135228
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    file_downloader_0.report_progress({})
    file_downloader_0.to_screen('v')
    file_downloader_0.to_screen({})
    file_downloader_0.to_console_title('v')
    file_downloader_0.to_console_title({})
    file_downloader_0.trouble('v')
    file_downloader_0.trouble({})
    file_downloader_0.report_warning('v')
    file_downloader_0.report_warning({})
    file_downloader_0.report_error('v')
    file_downloader_0.report_error({})

# Generated at 2022-06-26 11:06:38.995597
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader(None, None).temp_name("input.mp4") == "input.mp4.part"
    assert FileDownloader(None, None).temp_name("-") == "-"


# Generated at 2022-06-26 11:06:47.081921
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('123k') == 123 * 1024
    assert FileDownloader.parse_bytes('1.5m') == 1536 * 1024
    assert FileDownloader.parse_bytes('123M') == 123 * 1024 * 1024
    assert FileDownloader.parse_bytes('1.5g') == 1536 * 1024 * 1024
    assert FileDownloader.parse_bytes('123G') == 123 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1.5t') == 1536 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('123T') == 123 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1.5p') == 1536 * 1024 * 1024 * 1024 * 1024


# Generated at 2022-06-26 11:06:53.972250
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Template for test case

    class_0 = FileDownloader()

    # Assert on the expected result
    assert class_0.format_retries(2.0) == '2'

    # Assert on the expected result
    assert class_0.format_retries(float('inf')) == 'inf'


# Generated at 2022-06-26 11:07:07.663318
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    rnd_number = random.randint(0, 1e5)
    # Create a random file to be dowloaded
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
        f.write(str(rnd_number).encode())
    # Download the file
    ydl_opts = {
        'quiet': True,
        'format': 'best',
        'nooverwrites': True
    }
    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        ydl.add_default_info_extractors()
        # Mock the download function
        def mock_download(self, filename, info_dict):
            # Check whether the file has been downloaded properly
            with open(filename, 'r') as f:
                assert int

# Generated at 2022-06-26 11:07:40.878021
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_0 = FileDownloader(int(1387.733), int(1387.733))

# Generated at 2022-06-26 11:07:46.242438
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Create an instance for the FileDownloader class
    file_downloader_0 = FileDownloader(None, None)

    # Create a variable file_name_0 with the value: 'test_name'
    file_name_0 = 'test_name'

    # Call method temp_name of file_downloader_0
    file_downloader_0.temp_name(file_name_0)


# Generated at 2022-06-26 11:07:51.621544
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Positive test case
    var_0 = FileDownloader.format_retries(0)
    assert (var_0 == '0')

    # Positive test case
    var_0 = FileDownloader.format_retries(1)
    assert (var_0 == '1')

    # Positive test case
    var_0 = FileDownloader.format_retries(float('inf'))
    assert (var_0 == 'inf')


# Generated at 2022-06-26 11:08:04.005305
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes("42") == 42
    assert FileDownloader.parse_bytes("42.5") == 42
    assert FileDownloader.parse_bytes("42.0") == 42
    assert FileDownloader.parse_bytes("42b") == 42
    assert FileDownloader.parse_bytes("42k") == 42 * 1024
    assert FileDownloader.parse_bytes("42m") == 42 * 1024 * 1024
    assert FileDownloader.parse_bytes("42g") == 42 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes("  42G ") == 42 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes("  42.5G 42m 42k 42 ") == 452918228042

# Generated at 2022-06-26 11:08:10.682788
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    s_0 = {}
    s_0['status'] = 'finished'
    s_0['total_bytes'] = '78364'
    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:08:12.844633
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    params = Params()
    params.addDict({
        'ratelimit': '1',
    })
    info_dict = {
        'id': 'video_id',
    }

# Generated at 2022-06-26 11:08:25.036299
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Create instance of class: file_downloader_0
    file_downloader_0 = FileDownloader(1387.733, 1387.733)

    # Test method: best_block_size
    assert file_downloader_0.best_block_size(0.0, 0) == 1
    assert file_downloader_0.best_block_size(0.0, 1) == 1
    assert file_downloader_0.best_block_size(0.0, 2) == 2
    assert file_downloader_0.best_block_size(0.0, 3) == 4
    assert file_downloader_0.best_block_size(0.0, 4) == 8
    assert file_downloader_0.best_block_size(0.0, 5) == 8
    assert file_downloader_

# Generated at 2022-06-26 11:08:30.970342
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    float_0 = 1258.5
    file_downloader_0 = FileDownloader(float_0, float_0)
    var_0 = file_downloader_0.format_retries(float_0)
    assert var_0 == '1258'


# Generated at 2022-06-26 11:08:33.111271
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_temp_name()

# Generated at 2022-06-26 11:08:35.141722
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    test_case_0()

# Generated at 2022-06-26 11:09:19.077547
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    filename = 'file-to-change-time'
    dir_name = 'dir-to-change-time'
    open(filename, 'w').close()
    open(dir_name, 'w').close()
    dl = FileDownloader(None, None)

    # Test for file
    os.utime(filename, (1, 2))
    assert os.path.getmtime(filename) == 2
    dl.try_utime(filename, '1')

    # Test for dir
    os.utime(dir_name, (1, 2))
    assert os.path.getmtime(dir_name) == 2
    dl.try_utime(dir_name, '1')

    # Test for non-existing file

# Generated at 2022-06-26 11:09:27.372901
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 100.0
    float_1 = 1387.733
    float_2 = 5.625
    float_3 = 5.625
    float_4 = 5.625
    float_5 = 5.625
    float_6 = 5.625
    file_downloader_0 = FileDownloader(float_4, float_5)
    file_downloader_0.slow_down(float_6, float_0, float_2)
    file_downloader_0.slow_down(float_1, float_3, 5.625)


# Generated at 2022-06-26 11:09:39.073390
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # create an FileDownloader object
    file_downloader_0 = FileDownloader()

    # Run method try_utime of class FileDownloader
    file_downloader_0.try_utime('file.txt', 'None')
    file_downloader_0.try_utime('file.txt', '07/02/2018')
    file_downloader_0.try_utime('file.txt', '01/08/2016')
    file_downloader_0.try_utime('file.txt', '04/11/2018')
    file_downloader_0.try_utime('file.txt', '07/05/2017')
    file_downloader_0.try_utime('file.txt', '12/15/2015')

# Generated at 2022-06-26 11:09:47.634618
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Preparing input arguments
    filename = 'string_0'
    info_dict = {'string_0': 'string_0', 'string_1': 'string_1', 'string_2': 'string_2', 'string_3': 'string_3', 'string_4': 'string_4', 'string_5': 'string_5', 'string_6': 'string_6', 'string_7': 'string_7'}

    # Invoking the tested method
    FileDownloader.download(filename, info_dict)


# Generated at 2022-06-26 11:10:00.243456
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    test_0_filename = "test_0_filename"
    test_0_info_dict = {}
    test_0_info_dict['status'] = 'finished'
    test_0_info_dict['filename'] = test_0_filename
    test_0_info_dict['total_bytes'] = 1000

    test_1_filename = "test_1_filename"
    test_1_info_dict = {}
    test_1_info_dict['status'] = 'downloading'
    test_1_info_dict['eta'] = 10
    test_1_info_dict['elapsed'] = 0
    test_1_info_dict['total_bytes'] = 1000
    test_1_info_dict['total_bytes_estimate'] = 100
    test_1_info_dict['downloaded_bytes'] = 0

# Generated at 2022-06-26 11:10:07.852818
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # test case 1
    filename = 'filename'
    last_modified_hdr = 'last_modified_hdr'
    fd = FileDownloader(last_modified_hdr, last_modified_hdr)
    fd.try_utime(filename, last_modified_hdr)


# Generated at 2022-06-26 11:10:15.759748
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('somemovie.mp4') == 'somemovie.mp4.part'
    assert fd.temp_name('-') == '-'
    assert fd.temp_name('somemovie.mp4.part') == 'somemovie.mp4.part'
    assert fd.temp_name('somemovie.mp4') == 'somemovie.mp4.part'
    assert fd.temp_name('somemovie.mp4') == 'somemovie.mp4.part'
    assert fd.temp_name('.part') == '.part'
    assert fd.temp_name('somemovie.mp4.part') == 'somemovie.mp4.part'
    assert f

# Generated at 2022-06-26 11:10:26.506603
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    filepath = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(filepath, '..'))
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.params['noprogress'] = False
    file_downloader_0.params['ratelimit'] = None
    s = {}
    s['status'] = 'downloading'
    s['total_bytes'] = 123456
    s['downloaded_bytes'] = 121212
    s['speed'] = 1212.12
    s['eta'] = 12121212
    file_downloader_0.report_progress(s)
    s['status'] = 'finished'
    f

# Generated at 2022-06-26 11:10:36.987598
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    float_0 = 1387.733
    file_downloader_0 = FileDownloader(float_0, float_0)
    assertFalse(file_downloader_0.report_progress({ }))
    assertTrue(file_downloader_0.report_progress({ 'status': 'finished' }))
    assertFalse(file_downloader_0.report_progress({ 'status': 'downloading' }))
    assertFalse(file_downloader_0.report_progress({ 'status': 'downloading', 'eta': 'speed' }))

    assertFalse(file_downloader_0.report_progress({ 'status': 'downloading', 'downloaded_bytes': 10 }))
    assertFalse(file_downloader_0.report_progress({ 'status': 'downloading', 'downloaded_bytes': 10, 'elapsed': 10 }))


# Generated at 2022-06-26 11:10:48.979098
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = 597.41
    float_1 = float_0
    file_downloader_0 = FileDownloader(float_1, float_0)
    int_0 = 138
    int_1 = 100
    float_2 = time.time()
    float_3 = float_2
    float_4 = float_2
    int_2 = 1
    float_5 = float_4
    int_3 = int_0
    float_6 = float_5
    var_0 = file_downloader_0._slow_down(float_3, float_6, int_3)
    float_7 = float_2
    float_8 = float_7
    float_9 = float_7
    int_4 = 1
    float_10 = float_9
    int_5 = int_1
    float