

# Generated at 2022-06-26 11:03:31.427853
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    set_0 = None
    int_0 = 782670440
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.try_rename("M", "t")

test_case_0()
test_FileDownloader_try_rename()

# Generated at 2022-06-26 11:03:35.961770
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('3.5K') == 3584
    assert FileDownloader.parse_bytes('3.5k') == 3584
    assert FileDownloader.parse_bytes('3.5M') == 3.5 * 1024 * 1024
    assert FileDownloader.parse_bytes('23.45') == 23.45
    assert FileDownloader.parse_bytes('23.45e2') == 2345
    assert FileDownloader.parse_bytes('3.5foo') is None


# Generated at 2022-06-26 11:03:41.483990
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed(): 

    # Test.
    start_time = 9
    now = 20
    bytes = 30

    # Object to invoke method on
    obj = None

    # Invoke target method.
    val = obj._FileDownloader__calc_speed(start_time, now, bytes)

    # Test for something?


# Generated at 2022-06-26 11:03:46.873888
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    string_0 = 'test_file_name'
    # Testing a not supported value
    try:
        file_downloader_0.report_file_already_downloaded(string_0)
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-26 11:03:51.945955
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    int_0 = -1535
    set_0 = None
    int_1 = -1732
    file_downloader_0 = FileDownloader(set_0, int_1)
    int_2 = 0

    with pytest.raises(TypeError):
        file_downloader_0.calc_speed(int_0, None, int_2)


# Generated at 2022-06-26 11:03:59.404107
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    str_0 = "6UToFVU19x6uN"
    dict_0 = {}
    file_downloader_0.download(str_0, dict_0)


# Generated at 2022-06-26 11:04:12.105533
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    #  Test (1):
    #   set['status'] != 'downloading'
    #   params['noprogress'] is True
    set_1 = {'status': 'finished'}
    int_1 = 6
    file_downloader_1 = FileDownloader(set_1, int_1)
    file_downloader_1.params['noprogress'] = True
    assert file_downloader_1.params['noprogress'] is True
    file_downloader_1.report_progress(set_1)
    assert file_downloader_1.params['noprogress'] is True
    #  Test (2):
    #   set['status'] == 'downloading'
    #   set['eta'] is not None
    #   set['total_bytes'] is not None
    #   set['

# Generated at 2022-06-26 11:04:19.451735
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.params['nopart'] = True
    file_downloader_0.params['nooverwrites'] = False
    file_downloader_0.params['verbose'] = True
    file_downloader_0.params['continuedl'] = True
    file_downloader_0.params['noprogress'] = True
    file_downloader_0.params['sleep_interval'] = 5
    file_downloader_0.params['max_sleep_interval'] = 5
    file_downloader_0.params['quiet'] = True
    file_downloader_0.params['restrictfilenames'] = True
    file_

# Generated at 2022-06-26 11:04:21.138711
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 11:04:27.838559
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import os.path
    import time
    import tempfile
    from socket import socket, AF_INET, SOCK_DGRAM
    import re
    import shutil
    import traceback
    import sys
    from .utils import (
        encodeFilename,
    )
    from .compat import (
        compat_urllib_request,
        compat_str,
        compat_kwargs,
        compat_etree_fromstring,
        compat_urllib_error,
        compat_urlparse,
        compat_urllib_parse,
        compat_HTTPError,
        compat_shlex_split,
        compat_socket_create_connection,
    )
    from .postprocessor import (
        PostProcessor
    )

# Generated at 2022-06-26 11:04:51.688479
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    assert FileDownloader.calc_speed(0, 0, 0) == None
    assert FileDownloader.calc_speed(10, 0, 0) == None
    assert FileDownloader.calc_speed(0, 10, 0) == None
    assert FileDownloader.calc_speed(10, 10, 0) == 0
    assert FileDownloader.calc_speed(10, 11, 10) == 10
    assert FileDownloader.calc_speed(10, 20, 10) == 5
    assert FileDownloader.calc_speed(10, 5, 10) == 0
    assert FileDownloader.calc_speed(0, 0, 0.001) == None
    assert FileDownloader.calc_speed(10, 10, 0.001) == 1000

# Generated at 2022-06-26 11:04:53.563190
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    # Default case
    set_0 = None
    int_0 = 1736
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.temp_name("iOuM")



# Generated at 2022-06-26 11:05:03.421313
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    set_0 = None
    int_0 = -1596
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_name = None

# Generated at 2022-06-26 11:05:14.404167
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-26 11:05:21.272796
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    float_0 = 0.0
    float_1 = 0.0
    int_0 = 0
    file_downloader_0.slow_down(float_0, float_1, int_0)


# Generated at 2022-06-26 11:05:28.951000
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    int_0 = None
    int_1 = 3
    file_downloader_0.slow_down(int_1, int_0, int_0)


# Generated at 2022-06-26 11:05:36.828844
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    str_0 = 'u,7[h' # assume the string is a filename
    str_1 = '_d^' # assume the string is a value of last-modified header
    # assume that last_modified_hdr is a header value for last-modified
    last_modified_hdr = '_d^' 
    filetime = file_downloader_0.try_utime(str_0, last_modified_hdr)
    if (last_modified_hdr is None):
        return
    if (not os.path.isfile(str_0)):
        return
    if (str_1 is None):
        # assert filetime is None
        assert file

# Generated at 2022-06-26 11:05:38.321467
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    pass


# Generated at 2022-06-26 11:05:46.637828
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = float('NaN')
    float_1 = float('inf')
    float_2 = float('-inf')
    float_3 = float('nan')
    float_4 = float('1e308')

    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)

    float_5 = float_1 / (float_0 * float_0)
    float_6 = float_3 - float_1
    float_7 = float_0 + float_1
    float_8 = float_2 + float_0
    float_9 = float_1 / float_3
    float_10 = float_2 ** float_2
    float_11 = float_2 * float_0
    float_12 = float_5 / float_

# Generated at 2022-06-26 11:05:56.968762
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)

    str_0 = None
    dict_0 = {
        'a': 'http://www.youtube.com/',
        'g': True,
        'f': True,
        'c': True,
        'd': True,
        'b': 'http://www.youtube.com/',
        'e': True
    }

    bool_0 = file_downloader_0.download(str_0, dict_0)

# Generated at 2022-06-26 11:06:19.757476
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    set_0 = None
    int_0 = 1399
    str_0 = "Different"
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.temp_name(str_0)


# Generated at 2022-06-26 11:06:23.559484
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.report_file_already_downloaded("")


# Generated at 2022-06-26 11:06:30.097237
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    str_0 = 'château'
    file_downloader_0.try_utime(str_0, str_0)

# Generated at 2022-06-26 11:06:39.290434
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # set_0 is an object of class dict
    set_0 = None
    int_0 = -1581
    file_downloader_0 = FileDownloader(set_0, int_0)
    # str_0 is an object of class str
    str_0 = "S1U@"
    # num_0 is an object of class int
    num_0 = -1581
    file_downloader_0.try_utime(str_0, num_0)


# Generated at 2022-06-26 11:06:42.153719
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    float_0 = file_downloader_0.best_block_size(0, -1360)
    assert float_0 == 1024


# Generated at 2022-06-26 11:06:44.684555
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fn = 'file.part'
    res = FileDownloader.undo_temp_name(fn)
    return res == 'file'


# Generated at 2022-06-26 11:06:52.350193
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    string_0 = '4,a,'
    file_downloader_0.try_utime(string_0, string_0)


# Generated at 2022-06-26 11:06:56.384860
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    set_0 = None
    int_0 = -1601
    fd_0 = FileDownloader(set_0, int_0)
    fd_1 = FileDownloader(set_0, int_0)
    fd_2 = FileDownloader(set_0, int_0)


# Generated at 2022-06-26 11:07:06.170822
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    dict_0 = {'status': 'finished', 'elapsed': 0.85909, '_speed_str': '    Unknown speed', 'downloaded_bytes': 271476, 'total_bytes': 271476, 'speed': 0}
    assert file_downloader_0.report_progress(dict_0) is None


# Generated at 2022-06-26 11:07:13.573964
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)

    str_0 = "-"
    # Test argument str_0
    file_downloader_0.undo_temp_name(str_0)
    str_0 = "b7a2e075c3e7f3370cbebd15e46fc45b"
    # Test argument str_0
    file_downloader_0.undo_temp_name(str_0)
    str_0 = "7.3jT6eI/sd"
    # Test argument str_0
    file_downloader_0.undo_temp_name(str_0)
    str_0 = "p<:y#'ts4X4l2"
    # Test argument str

# Generated at 2022-06-26 11:07:31.060102
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    set_0 = None
    int_0 = 1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    # Set the attribute "params" to a fake object
    file_downloader_0.params = type('', (), {})()
    setattr(file_downloader_0.params, 'noprogress', False)

    d = {}
    d['downloaded_bytes'] = 0
    d['total_bytes'] = 23

    ret = file_downloader_0._report_progress_status(
        '%(percent_str)s of %(total_bytes_str)s', is_last_line=True)
    # Expecting "0% of 23" as a result
    assert ret == '100% of 23'


# Generated at 2022-06-26 11:07:35.298074
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()

# From http://stackoverflow.com/questions/4289331/python-extracting-numbers-from-a-string

# Generated at 2022-06-26 11:07:37.348872
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # TODO: Implement this unit test
    pass


# Generated at 2022-06-26 11:07:43.691257
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(5) == '00:05'
    assert FileDownloader.format_seconds(59) == '00:59'
    assert FileDownloader.format_seconds(60) == '01:00'
    assert FileDownloader.format_seconds(61) == '01:01'
    assert FileDownloader.format_seconds(3599) == '59:59'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3660) == '1:01:00'
    assert FileDownloader.format_seconds(3661) == '1:01:01'

# Generated at 2022-06-26 11:07:45.955042
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:07:49.718429
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert FileDownloader.try_utime(None, None) == None

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:08:00.134075
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    url_0 = "http://www.youtube.com/watch?v=baW_jenozKc"
    str_0 = "C:/fakepath"

    # Create a new object for class FileDownloader
    file_downloader_0 = FileDownloader({"nooverwrites": False})
    # Test that no exception is thrown by method download
    file_downloader_0.download(str_0, url_0)
    assert True == True


# Generated at 2022-06-26 11:08:09.736698
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    str_0 = "MBo5O5"
    str_1 = file_downloader_0.temp_name(str_0)
    if not (str_1 == "MBo5O5"):
        raise RuntimeError("Unexpected behavior")


# Generated at 2022-06-26 11:08:18.379824
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)

    # Set values for testing report_progress
    s_0 = { 'status': 'finished', 'total_bytes': 14, '_total_bytes_str': '14B' }

    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:08:32.892832
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    set_0 = {
        'sleep_interval': 7.249833714689169,
        'max_sleep_interval': 2.4013305285596176,
        'noprogress': True,
        'verbose': True,
        'nooverwrites': True,
        'continuedl': True,
        'ratelimit': 3.435570166127856,
    }
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    float_0 = -0.9780223423905835
    float_1 = 21.188362012734887
    int_1 = -671520600
    file_downloader_0.slow_down(float_0, float_1, int_1)



# Generated at 2022-06-26 11:09:05.732673
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    arg_0 = {'status': 'downloading',
                    'elapsed': 68.0,
                    'eta': 68,
                    'downloaded_bytes': 68,
                    'total_bytes': 68,
                    'total_bytes_estimate': 68,
                    'speed': 68}
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.report_progress(arg_0)
    arg_0 = {'status': 'downloading',
                    'elapsed': 68.0,
                    'eta': 68,
                    'downloaded_bytes': 68,
                    'speed': 68}
    set_0 = None
    int_0 = -1601

# Generated at 2022-06-26 11:09:13.864228
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    filename_0 = 'bPaRiRcYIT'
    info_dict_0 = None
    try:
        file_downloader_0.download(filename_0, info_dict_0)
    except Exception:
        pass


# Generated at 2022-06-26 11:09:25.493934
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({}, {})
    assert fd.temp_name('test') == 'test'
    set_0 = {'nopart': True}
    int_0 = -1809
    file_downloader_0 = FileDownloader(set_0, int_0)
    assert file_downloader_0.temp_name('test') == 'test'
    assert file_downloader_0.temp_name('test.test') == 'test.test'
    assert file_downloader_0.temp_name('') == ''



# Generated at 2022-06-26 11:09:35.593604
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    set_1 = None
    int_1 = -1235
    file_downloader_1 = FileDownloader(set_1, int_1)
    float_1 = 0
    float_2 = 0
    file_downloader_1.slow_down(float_1, float_2)
    # Test for exit 0, due to unimplemented functionality

if __name__ == '__main__':
    test_FileDownloader_slow_down()

# Generated at 2022-06-26 11:09:47.220596
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.trouble = _print_trouble
    file_downloader_0.to_screen = _print_to_screen
    path_0 = '/Users/lucaskamo/Documents/GitHub/youtube-dl-Tests/youtube_dl/extractor/test/test_00.webm'
    string_0 = None
    file_downloader_0.try_utime(path_0, string_0)


# Generated at 2022-06-26 11:09:58.360178
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    set_literal_0 = {'simulate': False}
    int_literal_0 = 1
    file_downloader_0 = FileDownloader(set_literal_0, int_literal_0)
    dict_literal_0 = {'status': 'downloading'}
    file_downloader_0.report_progress(dict_literal_0)
    dict_literal_1 = {'status': 'finished'}
    file_downloader_0.report_progress(dict_literal_1)


# Generated at 2022-06-26 11:10:08.219253
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    set_3 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_3, int_0)
    file_downloader_0.add_progress_hook(test_FileDownloader_download)
    str_0 = 'This is a test'
    dict_0 = {'test': 'key'}
    file_downloader_0.download(str_0, dict_0)


# Generated at 2022-06-26 11:10:14.527164
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)

    # This should not raise an Exception:
    file_downloader_0.report_progress({
        'status': 'downloading',
        'eta': 423,
        'speed': 1234,
        'total_bytes': 1723,
        'downloaded_bytes': 471
    })

    # This should not raise an Exception:
    file_downloader_0.report_progress({
        'status': 'downloading',
        'total_bytes': 0,
        'speed': 1234,
        'downloaded_bytes': 0
    })

    # This should not raise an Exception:

# Generated at 2022-06-26 11:10:15.454114
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    pass


# Generated at 2022-06-26 11:10:26.597639
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    set_0 = None
    set_1 = None
    for i in range(0, 200):
        pass
    int_0 = -1167
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.slow_down(float(0), float(0), float(0))
    assert_true(file_downloader_0.slower_than_expected)
    file_downloader_0.slow_down(float(0), float(0), float(0))
    assert_true(file_downloader_0.slower_than_expected)
    file_downloader_0.slow_down(float(0), float(0), float(0))
    assert_true(file_downloader_0.slower_than_expected)
    file_downloader_

# Generated at 2022-06-26 11:10:59.147377
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    file_downloader_0 = FileDownloader({'noprogress': True, 'outtmpl': '%(id)s%(ext)s', 'format': 'bestvideo+bestaudio/best'}, 0)
    float_0 = 1.03
    int_0 = 1187
    assert file_downloader_0.best_block_size(float_0, int_0) == 1187

# Generated at 2022-06-26 11:11:00.749965
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test for case 0
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_temp_name()

# Generated at 2022-06-26 11:11:09.086413
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('filename') == 'filename.part'
    assert FileDownloader.temp_name('-') == '-'
    assert FileDownloader.temp_name('/dev/null') == '/dev/null'
    assert FileDownloader.temp_name('/dev/null.part') == '/dev/null.part'
    return

if __name__ == '__main__':
    test_FileDownloader_temp_name()
    print('All test passed!')

# Generated at 2022-06-26 11:11:16.503245
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-26 11:11:26.969308
# Unit test for method temp_name of class FileDownloader

# Generated at 2022-06-26 11:11:37.647756
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-26 11:11:42.031426
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    set_0 = None
    int_0 = -1601
    file_downloader_0 = FileDownloader(set_0, int_0)
    # assert_equal(expected, temp_name(filename))
    raise NotImplementedError()


# Generated at 2022-06-26 11:11:42.815502
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()


# Generated at 2022-06-26 11:11:50.234126
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    print("Testing FileDownloader.try_utime()...", end="", flush=True)

    fmt_str = "%a, %d %b %Y %H:%M:%S %Z"
    formats = ["%s GMT", "%s (GMT)", "%s",
               "%s UT", "%s (UT)",
               "%s CST", "%s (CST)",
               fmt_str + " GMT", fmt_str + " (GMT)", fmt_str]

    localnow = time.localtime()
    utcnow = time.gmtime()
    now = time.time()
    # We need to compensate for timezone and summer time, which might
    # have an effect in a time range of 1 hour around midnight
    # (depending on the local timezone definitions)
    # The timezone difference was calculated using timedelta.total_seconds(),


# Generated at 2022-06-26 11:11:54.631042
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    time_0 = time.time()
    time_1 = time.time()
    int_0 = 0
    file_downloader_0 = None
    file_downloader_0 = FileDownloader(set_0, int_0)
    file_downloader_0.slow_down(time_0, time_1, int_0)

