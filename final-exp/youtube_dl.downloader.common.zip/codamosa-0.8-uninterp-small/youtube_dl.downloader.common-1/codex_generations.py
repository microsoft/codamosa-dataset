

# Generated at 2022-06-26 11:03:29.887209
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    file_downloader_0.try_rename('OZ ', '18q3H8WHAh')


# Generated at 2022-06-26 11:03:33.354974
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    old_filename = str()
    new_filename = str()
    file_downloader_0.try_rename(old_filename, new_filename)


# Generated at 2022-06-26 11:03:40.756220
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    s_dict = dict()
    s_dict['status'] = 'finished'
    file_downloader_0.report_progress(s_dict)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:03:56.486550
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from time import sleep
    from time import time
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.to_screen = lambda x: None
    file_downloader_0.params = {'ratelimit': 10}
    start_time = time()
    # First, sleep a little bit and make sure that no slowdown is applied
    sleep(1)
    file_downloader_0.slow_down(start_time, time(), 10)
    # Then, download ten bytes and check if slowdown is applied
    sleep(0.5)
    file_downloader_0.slow_down(start_time, time(), 10)
    # Then, download one byte and check if slowdown is applied
    sleep(0.5)

# Generated at 2022-06-26 11:04:02.028793
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    file_downloader_0.download("", "")


# Generated at 2022-06-26 11:04:10.172193
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(None, None)
    arg_0 = timeconvert(None)
    arg_1 = timeconvert(None)
    file_downloader_0.try_utime(arg_0, arg_1)
    assert_equals(arg_0, None)
    assert_equals(arg_1, None)
    assert_equals(file_downloader_0, FileDownloader(None, None))


# Generated at 2022-06-26 11:04:18.553074
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    list_0 = []
    list_1 = []
    file_downloader_1 = FileDownloader(list_0, list_1)
    file_downloader_0.params = file_downloader_1.params = {'noprogress': True}
    file_downloader_2 = FileDownloader(list_0, list_1)
    file_downloader_0.params = file_downloader_2.params = {'noprogress': True}
    file_downloader_3 = FileDownloader(list_0, list_1)
    file_downloader_0.params = file_downloader_3.params = {'noprogress': True}



# Generated at 2022-06-26 11:04:24.983882
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    filename_0 = "C:\\Users\\pankaj\\AppData\\Local\\Temp\\tmpf1vbkahr"
    filename_1 = "C:\\Users\\pankaj\\AppData\\Local\\Temp\\tmpqze16y2h"
    assert file_downloader_0.try_rename(filename_0, filename_1) == None


# Generated at 2022-06-26 11:04:29.341869
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    list_0 = []
    list_1 = []
    file_downloader_0 = FileDownloader(list_0, list_1)
    file_downloader_0.report_file_already_downloaded('m0GSoEwZ')


# Generated at 2022-06-26 11:04:30.795594
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test case for method download of class FileDownloader
    test_case_0()


# Generated at 2022-06-26 11:04:53.363408
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.report_progress({'_eta_str': '0:00:00', '_speed_str': 'Unknown speed', '_total_bytes_estimate_str': '1.3KiB', '_percent_str': 'Unknown %', '_total_bytes_str': '2.1KiB', '_downloaded_bytes_str': '1.3KiB', '_elapsed_str': '0:00:00'})

# Generated at 2022-06-26 11:04:59.277162
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    var_1 = []
    file_downloader_1 = FileDownloader(var_1, var_1)
    var_2 = '-'
    var_3 = file_downloader_1.temp_name(var_2)
    print(var_3)


# Generated at 2022-06-26 11:05:12.563060
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('0b') == 0
    assert FileDownloader.parse_bytes('5b') == 5
    assert FileDownloader.parse_bytes('5k') == 5 * 1024
    assert FileDownloader.parse_bytes('5K') == 5 * 1024
    assert FileDownloader.parse_bytes('5m') == 5 * 1024 * 1024
    assert FileDownloader.parse_bytes('5M') == 5 * 1024 * 1024
    assert FileDownloader.parse_bytes('5g') == 5 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('5G') == 5 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('5t') == 5 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_

# Generated at 2022-06-26 11:05:24.138551
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def test_case_template(progress_with_newline, noprogress, sleep_interval):
        var_0 = {'noprogress': noprogress, 'progress_with_newline': progress_with_newline, 'sleep_interval': sleep_interval}
        file_downloader_0 = FileDownloader(var_0, var_0)
        if sleep_interval:
            if noprogress:
                file_downloader_0.to_screen.assert_any_call(
                    '[download] Sleeping %s seconds...' % (sleep_interval if sleep_interval.is_integer() else '%.2f' % sleep_interval))
            else:
                file_downloader_0.to_screen.assert_not_called()
        else:
            file_downloader_0

# Generated at 2022-06-26 11:05:25.680068
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    pass


# Generated at 2022-06-26 11:05:31.813057
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    var_0 = [None, None, None]
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_0 = None
    var_1 = None
    var_2 = None
    file_downloader_0.calc_speed(var_0, var_1, var_2)


# Generated at 2022-06-26 11:05:44.302399
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = {'elapsed': 2.0, 'downloaded_bytes': 5242880.0, 'speed': 2.621507052421542, 'total_bytes_estimate': 0.0, 'total_bytes': None, '_speed_str': '  2.6MiB/s', 'downloaded_bytes_str': '5.0MiB', '_percent_str': 'Unknown %', '_eta_str': 'Unknown ETA', '_total_bytes_estimate_str': 'Unknown', '_total_bytes_str': 'Unknown', '_elapsed_str': '02:00.00'}
    file_downloader_0.report_progress(var_1)

#

# Generated at 2022-06-26 11:05:55.571117
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    var_1 = {}

    # Test for FileDownloader.report_progress(dict)
    file_downloader_0 = FileDownloader(var_0, var_0)
    ret = file_downloader_0.report_progress(var_1)

    # Test for FileDownloader.report_progress(dict)
    file_downloader_0 = FileDownloader(var_0, var_0)
    ret = file_downloader_0.report_progress(var_1)

    # Test for FileDownloader.report_progress(dict)
    file_downloader_0 = FileDownloader(var_0, var_0)
    ret = file_downloader_0.report_progress(var_1)


# Generated at 2022-06-26 11:06:01.957632
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    var_0 = []
    var_1 = []
    file_downloader_0 = FileDownloader(var_0, var_1)
    var_2 = file_downloader_0.temp_name('hello.py')
    var_3 = file_downloader_0.temp_name('hello.py')
    assert var_3 == 'hello.py.part'


# Generated at 2022-06-26 11:06:09.818461
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    var_0 = FileDownloader('', [])
    try:
        file_downloader_0.report_file_already_downloaded('/tmp/youtube-dl/0')
    except UnicodeEncodeError:
        file_downloader_0.report_file_already_downloaded('The file has already been downloaded')

# Generated at 2022-06-26 11:06:18.356119
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    test_case_0()


# Generated at 2022-06-26 11:06:32.219100
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    file_downloader_0 = FileDownloader()
    filename_0 = ''
    last_modified_hdr_0 = ''
    var_0 = file_downloader_0.try_utime(filename_0, last_modified_hdr_0)
    assert var_0 == None

    file_downloader_1 = FileDownloader()
    filename_1 = 'test_FileDownloader_try_utime.test_case_0'
    last_modified_hdr_1 = ''
    var_1 = file_downloader_1.try_utime(filename_1, last_modified_hdr_1)
    assert var_1 == None

    file_downloader_2 = FileDownloader()
    filename_2 = 'test_FileDownloader_try_utime.test_case_1'
    last_

# Generated at 2022-06-26 11:06:38.622988
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test case 0
    file_downloader_0 = FileDownloader({}, {})
    string_0 = 'test_case_0.part'
    string_1 = file_downloader_0.undo_temp_name(string_0)
    assert string_1 == 'test_case_0'


# Generated at 2022-06-26 11:06:40.711440
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:06:45.321954
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    var_1 = "already_downloaded.txt"
    file_downloader_0.report_file_already_downloaded(var_1)



# Generated at 2022-06-26 11:06:52.639399
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    param_0 = 2
    param_1 = 1
    param_2 = str()
    file_downloader_0 = FileDownloader.calc_speed(param_0, param_1, param_2)
    assert_equal(file_downloader_0, float())


# Generated at 2022-06-26 11:06:55.949752
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    assert FileDownloader({}, {}).calc_eta(0.0, 0.0, 10, 1) == 9
    assert FileDownloader({}, {}).calc_eta(0, 0, 10, 1) == 9



# Generated at 2022-06-26 11:06:57.602155
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()



# Generated at 2022-06-26 11:06:59.684194
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.calc_speed(var_0, var_0, var_0)


# Generated at 2022-06-26 11:07:06.821944
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = {}
    var_0 = {}
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    var_2 = file_downloader_0.try_utime(var_1, var_1)
    test_case_assert('assertEqual', 'var_2', None, var_2)


# Generated at 2022-06-26 11:07:24.159895
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    # test 1

# Generated at 2022-06-26 11:07:28.454529
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = file_downloader_0.calc_eta(2.0, 6.0, 10.0)
    print(var_1)


# Generated at 2022-06-26 11:07:40.879357
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    status = {'status':'downloading','downloaded_bytes':4096,'total_bytes':8192,'speed':4096,'eta':4}

    # Calling the method
    test_result = file_downloader_0.report_progress(status)

    # Verifying the method's result
    assert test_result == None

    # Verifying method call count, call parameters and return value
    assert file_downloader_0._report_progress_status.call_count == 1
    assert file_downloader_0._report_progress_status.call_args_list == [call('50% of 8192 at 4096/s ETA 4')]

# Generated at 2022-06-26 11:07:47.583778
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Case - 0
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    assert_equal(file_downloader_0.report_progress({'eta':'vamsi','total_bytes_estimate':'sai','status':'sai','elapsed':'sai','downloaded_bytes':'sai','speed':'sai','total_bytes':'sai'}),var_0)

test_case_0()
test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:07:51.510756
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    # tested function's behavior
    float_0 = float()
    float_1 = float()
    float_2 = float()
    file_downloader_0.slow_down(float_0, float_1, float_2)



# Generated at 2022-06-26 11:07:59.579313
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = FileDownloader(None, None)
    var_1 = None
    var_2 = 'Sat, 13 Feb 2010 23:31:30 GMT'
    # assertIntermediate(var_0.try_utime(var_1, var_2), 1265787890.0)


# Generated at 2022-06-26 11:08:12.721520
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('101') == 101
    assert FileDownloader.parse_bytes('  1  ') == 1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1.0k') == 1024
    assert FileDownloader.parse_bytes('.5k') == 512
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1.1k') == 1152
    assert FileDownloader.parse_bytes(' 1024 ') == 1024
    assert FileDownloader.parse_bytes('300b') == 300


# Generated at 2022-06-26 11:08:23.389553
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # var_0 contains the time of the test in seconds since the Epoch
    var_0 = time.time()
    # var_1 contains a tuple of arguments passed to function slow_down
    # of class FileDownloader
    var_1 = (0, 0, var_0, 0)
    # create a FileDownloader instance
    file_downloader_0 = FileDownloader({}, {})
    # call the method slow_down
    file_downloader_0.slow_down(var_1[0], var_1[1], var_1[2], var_1[3])


# Generated at 2022-06-26 11:08:35.508626
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = []
    var_1.append({'elapsed': 1.09233796, 'status': 'finished', 'speed': 14.662624, 'total_bytes': 5732077, 'downloaded_bytes': 5732077})
    file_downloader_0.report_progress(var_1[0])

# Generated at 2022-06-26 11:08:46.158981
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    for test in [
        ["file", "last-modified", "2017-01-01T00:00:00+01:00", None],
        ["file", "last-modified", "invalid_date", None],  # should not raise an exception
        ["file", "last-modified", "Wed, 08 Feb 2017 10:35:49 GMT", 1486607749]
    ]:
        file_name, hdr_key, hdr_val, expected = test
        fd = FileDownloader({'test': True})
        fd.report_destination(file_name)
        with open(encodeFilename(file_name), 'w') as f:
            f.write('test')
            f.close()
        hdr_dict = {hdr_key: hdr_val}
        result = fd.try_

# Generated at 2022-06-26 11:08:59.013547
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from datetime import datetime
    from random import seed
    seed(datetime.now())
    for _ in range(0, 100):
        var_1 = FileDownloader(None, None)
        var_current_time = random.randint(0, 9223372036854775807)
        var_byte_counter = random.randint(0, 9223372036854775807)
        var_2 = var_current_time
        var_1.slow_down(var_2, var_current_time, var_byte_counter)


# Generated at 2022-06-26 11:09:04.432363
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = {'status': 'finished', 'total_bytes': 133463775}
    args = [var_0, var_1]
    file_downloader_0.report_progress(*args)


# Generated at 2022-06-26 11:09:11.716075
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    var_0 = []
    var_1 = []
    var_2 = FileDownloader(var_0, var_1)
    var_3 = '-'
    file_downloader_0 = var_2.temp_name(var_3)
    assert(file_downloader_0 == '-')


# Generated at 2022-06-26 11:09:15.058294
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Case 0
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.slow_down(1, 2, 3)


# Generated at 2022-06-26 11:09:18.088404
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader([], {})


# Generated at 2022-06-26 11:09:28.492796
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    status = {'filename': '/foo/bar.mp3', 'status': 'downloading', 'downloaded_bytes': 0, 'total_bytes': None, 'total_bytes_estimate': None, 'elapsed': 0, 'eta': 0, 'speed': 0}
    fo = open('file_downloader_report_progress.txt', 'w+')
    var_5 = ['-o', 'bar-%(title)s.%(ext)s', '--newline', '--no-progress', '--no-part', '--verbose', '--quiet', '--no-warnings', '--max-sleep-interval', '1.0']
    file_downloader_0 = FileDownloader(var_5, var_5)
    file_downloader_0.to_screen = fo.write
    file_downloader

# Generated at 2022-06-26 11:09:39.358973
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-26 11:09:46.146928
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_1 = FileDownloader({}, {})
    # file_downloader_1.slow_down(None,None,0)
    # file_downloader_1.slow_down(None,None,1)
    # file_downloader_1.slow_down(None,None,2)



# Generated at 2022-06-26 11:09:48.955971
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    assert FileDownloader.calc_speed(time.time(), time.time(), 0) is None
    assert FileDownloader.calc_speed(0, 1, 10) == 10


# Generated at 2022-06-26 11:09:55.233030
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    var_0 = []
    var_1 = FileDownloader(var_0, var_0)
    var_2 = 'test_Value'
    var_1.report_file_already_downloaded(var_2)


# Generated at 2022-06-26 11:10:09.898680
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys

    dl = downloader.FileDownloader({})
    if sys.version_info < (3, 0):
        import mock
        with mock.patch('__builtin__.open', new=lambda *args: args[1]):
            dl.download(b'\xc3\xb1', {'id': 'abc', 'title': 'video.mp4'}) == b'\xc3\xb1'
    else:
        dl.download('ø', {'id': 'abc', 'title': 'video.mp4'}) == 'ø'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:10:23.564867
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    # Case 1:
    # rate_limit_0 = None
    # byte_counter_0 = 0
    # start_time_0 = 0
    # now_0 = 0

    # Expected output:
    # None

    rate_limit_0 = None
    byte_counter_0 = 0
    start_time_0 = 0
    now_0 = 0
    assert file_downloader_0.slow_down(start_time_0, now_0, byte_counter_0) == None



# Generated at 2022-06-26 11:10:34.087204
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    var_1 = []
    file_downloader_1 = FileDownloader(var_1, var_1)
    var_1_a = b'~\x8a@\x86\xac\x1d\x9f\x1d\x01\x91\r\x04\x99'
    var_1_b = file_downloader_1.report_file_already_downloaded(var_1_a)
    assert(var_1_b == True)
    assert(not (var_1_b == False))


# Generated at 2022-06-26 11:10:38.700106
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    downloaded = False

    class TestFD(FileDownloader):
        def real_download(self, filename, info_dict):
            nonlocal downloaded
            downloaded = True

    tfd = TestFD(dict(), dict())
    tfd.download("test_filename", {})
    return downloaded


# Test cases for the whole file
test_cases = [test_case_0,
              test_FileDownloader_download]


# Test class

# Generated at 2022-06-26 11:10:43.518482
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.slow_down(0, 0, 0)



# Generated at 2022-06-26 11:10:50.225687
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Creating objects of class FileDownloader
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    # Calling methods of the class
    file_downloader_0.try_utime("test1.txt", "Thu, 1 Jan 1970 00:00:00 GMT")
    file_downloader_0.try_utime("test2.txt", None)
    file_downloader_0.try_utime("test1.txt", "")
    file_downloader_0.try_utime("test2.txt", "Thu, 1 Jan 1970 00:00:00 GMT")


# Generated at 2022-06-26 11:10:57.375348
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print('Testing FileDownloader.report_progress')
    var_1 = []
    file_downloader_1 = FileDownloader(var_1, var_1)
    str_1 = '100% of %(_total_bytes_str)s in %(_elapsed_str)s'
    file_downloader_1.report_progress(str_1)


# Generated at 2022-06-26 11:11:07.195098
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    # Test file is in tests/pytest/test_test_test.py
    file_name = 'test_test_test.py'
    last_modified_hdr = file_downloader_0.try_utime(file_name,
            last_modified_hdr=time.ctime(os.path.getmtime(file_name)))
    assert last_modified_hdr == os.path.getmtime(file_name)


# Generated at 2022-06-26 11:11:21.291890
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)

    status_0 = {
        'total_bytes_estimate': None,
        '_speed_str': 'Unknown speed',
        'elapsed': 0,
        'status': 'downloading',
        'downloaded_bytes': None,
        '_eta_str': 'Unknown ETA',
        'speed': None,
        '_percent_str': 'Unknown %',
        'eta': None,
        'total_bytes': None,
        '_total_bytes_estimate_str': None,
        '_elapsed_str': None,
        '_total_bytes_str': None,
        '_downloaded_bytes_str': None
    }

# Generated at 2022-06-26 11:11:28.927585
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    if not os.path.exists(temp_file):
        subprocess.run(['touch', temp_file])
    file_downloader_0 = FileDownloader(["-r","1M","https://httpbin.org/bytes/9999999"], None)
    file_downloader_0.temp_name = lambda s: temp_file
    start = time.time()
    file_downloader_0.slow_down(start, None, 1000)
    while(os.path.getsize(temp_file) < 8388608) :
        file_downloader_0.slow_down(start, time.time(), os.path.getsize(temp_file))
    os.remove(temp_file);
    test_result = os.path.getsize(temp_file) < 8388608

# Generated at 2022-06-26 11:11:47.184941
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Test with empty input
    assert FileDownloader.parse_bytes('') is None

    # Test with input with no letters in it
    assert FileDownloader.parse_bytes('8') == 8
    assert FileDownloader.parse_bytes('8.2') == 8
    assert FileDownloader.parse_bytes('8.8') == 8

    # Test with input with letters in it
    assert FileDownloader.parse_bytes('42.5M') == 439804651110
    assert FileDownloader.parse_bytes('8.2K') == 8192
    assert FileDownloader.parse_bytes('42.5P') == 46837515716799
    assert FileDownloader.parse_bytes('8.8T') == 93615548046520
    assert FileDownloader.parse_bytes('8.8Z') == 936

# Generated at 2022-06-26 11:11:55.205848
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    from random import uniform
    from time import sleep
    from math import fabs
    from hyphen import Hyphenator

    # This class is used to test if the method calc_speed does not fail when it
    # is used with a hyphenator. Hyphenator is not available with Python 2.4.
    class FileDownloader(BaseFileDownloader):
        def __init__(self, params, info_dict):
            BaseFileDownloader.__init__(self, params, info_dict)
            self.speed_tester = Hyphenator()

        def real_download(self, filename, info_dict):
            try:
                self.speed_tester.hyphenate('some text')
                self.speed_tester.hyphenate('some text')
            except:
                pass
            return True

    min_speed = 512.

# Generated at 2022-06-26 11:12:00.951560
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test initial status
    var_0 = {}
    var_0['status'] = 'downloading'
    file_downloader_0 = FileDownloader({}, {})
    assert file_downloader_0.params.get('noprogress') == False
    file_downloader_0.report_progress(var_0)

    # Test when speed is known
    var_0['status'] = 'downloading'
    var_0['total_bytes'] = 1
    var_0['downloaded_bytes'] = 1
    var_0['eta'] = None
    var_0['speed'] = 1
    file_downloader_0 = FileDownloader({}, {})
    assert file_downloader_0.params.get('noprogress') == False
    file_downloader_0.report_progress(var_0)

# Generated at 2022-06-26 11:12:04.843410
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    assert FileDownloader.calc_speed(9999, 10001, 1000) == 200.0, 'Calc speed should be 200.0'
    assert FileDownloader.calc_speed(0, 0, 0) == None, 'Calc speed should be None'


# Generated at 2022-06-26 11:12:13.875955
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    # Try with a float
    var_1 = time.time()
    # Try with a float
    var_2 = time.time()
    # Try with an int
    var_3 = 0
    file_downloader_0.slow_down(var_1, var_2, var_3)


# Generated at 2022-06-26 11:12:20.238786
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = []
    file_downloader_0 = FileDownloader(var_0, var_0)
    string_0 = "January 1, 1970"
    file_downloader_0.try_utime(string_0, string_0)


# Generated at 2022-06-26 11:12:24.486952
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = {}
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.report_progress(var_0)


# Generated at 2022-06-26 11:12:30.224424
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start_0 = time.time()
    now_0 = time.time()
    bytes_0 = 100
    var_0 = FileDownloader.calc_speed(start_0, now_0, bytes_0)



# Generated at 2022-06-26 11:12:39.908318
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = []
    var_1 = []
    file_downloader_0 = FileDownloader(var_0, var_1)
    file_downloader_0.params = {'nooverwrites': False, 'simulate': True, 'continuedl': True, 'nopart': False}
    var_2 = handle_mock('success')
    var_3 = {'mocked': 'success'}
    actual_value = file_downloader_0.download(var_2, var_3)
    expected_value = True
    assert actual_value == expected_value
    file_downloader_0.params = {'nooverwrites': True, 'simulate': True, 'continuedl': True, 'nopart': False}
    var_4 = handle_mock('success')
   