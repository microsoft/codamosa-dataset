

# Generated at 2022-06-26 11:03:22.980172
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = None
    str_0 = 'daMzij4p@f*w'
    file_downloader_0 = FileDownloader(int_0, int_0)
    exists_0 = os.path.exists('/tmp')
    if exists_0:
        file_downloader_0.try_utime('/tmp', str_0)
    else:
        file_downloader_0.try_utime('/tmp', str_0)


# Generated at 2022-06-26 11:03:33.424163
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Test for float('inf')
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    # Test for float('inf') - 1
    assert FileDownloader.format_retries(float('inf') - 1) == 'inf'
    # Test for float('-inf')
    assert FileDownloader.format_retries(float('-inf')) == '0'
    # Test for float('-inf') + 1
    assert FileDownloader.format_retries(float('-inf') + 1) == '0'
    # Test for float('inf') * 2
    assert FileDownloader.format_retries(float('inf') * 2) == 'inf'
    # Test for float('inf') * -1

# Generated at 2022-06-26 11:03:40.113639
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = None
    str_0 = 'daMzij4p@f*w'
    file_downloader_0 = FileDownloader(int_0, int_0)
    # AssertionError: AttributeError: 'FileDownloader' object has no attribute 'params'
    file_downloader_0.slow_down(int_0, int_0, int_0)


# Generated at 2022-06-26 11:03:49.255932
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    global file_downloader_0
    global int_0
    global int_1
    global int_2
    global str_0
    global str_1
    global str_2
    global str_3

    int_0 = 1
    str_0 = 'tls'
    str_1 = 'cLp48;|'

    # Only relevant with resumed partial downloads
    int_1 = 1
    int_2 = 1
    str_2 = '*wN<`|G'

    # For verbose mode
    str_3 = 'd'

    # Random but necessary test argument
    file_downloader_0 = FileDownloader(int_0, int_0)

    # Assert the test arguments were valid
    file_downloader_0.report_progress(str_0)
    file_downloader_0

# Generated at 2022-06-26 11:04:02.827815
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = None
    str_0 = 'daMzij4p@f*w'
    file_downloader_0 = FileDownloader(int_0, int_0)
    status_0 = OrderedDict((('downloaded_bytes', 0), ('_speed_str', 'Unknown speed'), ('_eta_str', 'Unknown ETA'), ('_downloaded_bytes_str', format_bytes(0)), ('_percent_str', 'Unknown %'), ('elapsed', 1.25385522842), ('total_bytes', None), ('_elapsed_str', file_downloader_0.format_seconds(1.25385522842)), ('speed', None)))
    status_0['status'] = 'downloading'
    file_downloader_0.report_progress(status_0)


# Generated at 2022-06-26 11:04:10.742541
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = None
    str_0 = 'iD[nS_oL-n)a~E'
    time_0 = timeconvert(None)
    file_downloader_0 = FileDownloader(int_0, int_0)
    file_downloader_0.try_utime(str_0, time_0)

    file_downloader_0.format_percent(time_0)

#

# Generated at 2022-06-26 11:04:15.525876
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    timeconvert_0 = None
    file_downloader_0 = FileDownloader(timeconvert_0, timeconvert_0)
    filename_0 = 'KjSl$L-YO1z$'
    last_modified_hdr_0 = None
    filetime_0 = file_downloader_0.try_utime(filename_0, last_modified_hdr_0)
    print(filetime_0)


# Generated at 2022-06-26 11:04:22.816884
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    int_0 = None
    str_0 = 'daMzij4p@f*w'
    file_downloader_0 = FileDownloader(int_0, int_0)
    elapsed_time_1 = 0.043787
    bytes_1 = 0
    int_0 = None
    int_2 = None
    bytes_2 = 0
    file_downloader_0.best_block_size(elapsed_time_1, bytes_1, int_0, int_2, bytes_2)


# Generated at 2022-06-26 11:04:32.754274
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    dict_0 = {}
    int_0 = (1 << 31) - 1
    dict_0['eta'] = int_0
    float_0 = float(random.randint(-2147483648, 2147483647))
    # float_0 = float(random.uniform(-1.0, 1.0))
    dict_0['elapsed'] = float_0
    int_1 = (1 << 31) - 1
    dict_0['downloaded_bytes'] = int_1
    int_2 = (1 << 31) - 1
    dict_0['total_bytes'] = int_2
    int_3 = (1 << 31) - 1
    dict_0['total_bytes_estimate'] = int_3
    dict_0['status'] = 'finished'
    dict_0['speed'] = float_

# Generated at 2022-06-26 11:04:37.148092
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    info_dict_0 = {'url': 'https://www.youtube.com/watch?v=1r8zWLEj5BY'}
    filename_0 = 'https://www.youtube.com/watch?v=1r8zWLEj5BY'
    #file_downloader_0 = None
    #file_downloader_0 = FileDownloader(info_dict_0, filename_0)
    #file_downloader_0.download(filename_0, info_dict_0)


# Generated at 2022-06-26 11:04:46.013995
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # test case #1
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = "Tue, 18 Oct 2016 11:58:00 GMT"
    var_2 = file_downloader_0.try_utime(filename_0, var_1)


# Generated at 2022-06-26 11:04:52.565630
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = None
    var_1 = {'_eta_str': 'Unknown ETA',
             '_percent_str': 'Unknown %',
             '_speed_str': 'Unknown speed',
             'downloaded_bytes': None,
             'elapsed': None,
             'eta': None,
             'speed': None,
             'status': 'downloading'}

    file_downloader_0 = FileDownloader(var_0, var_0)

    file_downloader_0.report_progress(var_1)


# Generated at 2022-06-26 11:04:58.477176
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    var_2 = None
    file_downloader_0.download(var_1, var_2)


# Generated at 2022-06-26 11:05:02.432900
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    var_2 = FileDownloader(None, None)
    var_3 = None
    return var_2.temp_name(var_3)


# Generated at 2022-06-26 11:05:09.445008
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = int()
    var_0 = 3.14
    var_1 = int()
    var_1 = 0
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.slow_down(var_0, var_0, var_1)


# Generated at 2022-06-26 11:05:15.917525
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_1 = None
    file_downloader_0 = FileDownloader(var_1, var_1)
    var_2 = None
    var_3 = None
    file_downloader_0.download(var_3, var_2)


# Generated at 2022-06-26 11:05:17.019234
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    pass


# Generated at 2022-06-26 11:05:21.645796
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader(var_0, var_0)
    # TODO: get this to pass
    # assert file_downloader_0.slow_down(var_0, var_0, var_0) == None


# Generated at 2022-06-26 11:05:26.614702
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    file_downloader_0.report_progress(var_1)


# Generated at 2022-06-26 11:05:32.272004
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = None
    var_1 = 'tests/youtube/__main__.py'
    var_2 = 'tests/youtube/__main__.py'
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.download(var_1, var_2)


# Generated at 2022-06-26 11:05:48.028035
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    assert FileDownloader.download('test_FileDownloader_download', 'test_FileDownloader_download').actual_retval == Exception

# Generated at 2022-06-26 11:05:53.643579
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = None
    var_1 = None
    file_downloader_0 = FileDownloader(var_0, var_1)
    file_downloader_0.to_screen ('[download] %s has already been downloaded' % var_1)


if __name__ == '__main__':
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:06:01.881915
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    inf_retries = float('inf')
    assert FileDownloader.format_retries(inf_retries) == 'inf'

    zero_retries = 0
    assert FileDownloader.format_retries(zero_retries) == '0'

    nan_retries = float('nan')
    try:
        FileDownloader.format_retries(nan_retries)
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-26 11:06:03.339891
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # TODO: Implement
    pass


# Generated at 2022-06-26 11:06:15.733246
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_1 = None
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.report_destination("KI")
    file_downloader_0.report_progress("xS")
    file_downloader_0.report_resuming_byte("4")
    file_downloader_0.report_retry("V", "u", "D")
    file_downloader_0.report_file_already_downloaded("M")
    file_downloader_0.report_unable_to_resume("V")
    file_downloader_0.download("J", "7")


# Generated at 2022-06-26 11:06:21.001254
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = None
    var_1 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    assert file_downloader_0.try_utime(var_0, var_1) == None


# Generated at 2022-06-26 11:06:30.391429
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    var_2 = None
    file_downloader_0.slow_down(var_1, var_2, 0)
    
if __name__ == '__main__':
    from minitest import *

    with test("FileDownloader"):
        test_case_0()
        test_FileDownloader_slow_down()

# Generated at 2022-06-26 11:06:35.756845
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert file_downloader_0.try_utime('/home/matt/p5-video-downloader/data/youtube-dl/temp/data/tweets/tweets.txt', 'Wed, 30 Nov 2016 20:18:26 GMT') != None


# Generated at 2022-06-26 11:06:46.074550
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Scenario 1
    # Parameters:
    filename = 'file1.txt'
    last_modified_hdr = 'Thu, 01 Jan 1970 00:00:00 GMT'
    try:
        os.makedirs('download')
    except FileExistsError:
        pass
    with open(os.path.join('download', filename), 'w') as f:
        f.write('Test file')
    file_downloader = FileDownloader(None, None)
    result = file_downloader.try_utime(filename, last_modified_hdr)
    print('Unit test for "try_utime"')
    print('Scenario 1:')
    try:
        assert result == 0
    except AssertionError:
        print('Expected: 0')
        print('Actual:', result)

# Generated at 2022-06-26 11:06:49.067475
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Test 1
    test_case_0()


# Generated at 2022-06-26 11:07:16.556524
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = {
        'speed': None,
        'total_bytes': None,
        'downloaded_bytes': None,
        'elapsed': None,
        'eta': None,
        'status': None,
    }
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    file_downloader_0.report_progress(var_1)


# Generated at 2022-06-26 11:07:29.252108
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    global start_time, now, byte_counter
    
    global rate_limit, sleep_time
    
    start_time = time.time()
    rate_limit = 10
    byte_counter = 100
    now = time.time()
    elapsed = now - start_time
    assert elapsed > 0
    speed = float(byte_counter) / elapsed
    assert speed > rate_limit
    sleep_time = float(byte_counter) / rate_limit - elapsed
    assert sleep_time > 0
    time.sleep(sleep_time)

test_case_0()
start_time = time.time()
byte_counter = 100
rate_limit = 10
test_FileDownloader_slow_down()

# Generated at 2022-06-26 11:07:36.476550
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(var_0, var_0)
    filename_0 = None
    info_dict_0 = None
    var_1 = file_downloader_0.download(filename_0, info_dict_0)
    assert var_1 == False


# Generated at 2022-06-26 11:07:45.043751
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    str_1 = file_downloader_0.format_seconds(var_1)
    print("str_1 = " + str_1)


# Generated at 2022-06-26 11:07:48.582172
# Unit test for method download of class FileDownloader

# Generated at 2022-06-26 11:07:51.507297
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:07:58.442598
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_1 = None
    file_downloader_0.report_progress(var_1)


# Generated at 2022-06-26 11:08:05.970058
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    var_0 = 0.0
    var_1 = 0.0
    var_2 = 0
    var_3 = FileDownloader.best_block_size(var_1, var_2)
    assert type(var_3) == int

    var_0 = 0.0
    var_1 = 0.0
    var_2 = 1
    var_3 = FileDownloader.best_block_size(var_1, var_2)
    assert type(var_3) == int

    var_0 = 0.0
    var_1 = 0.0
    var_2 = 2
    var_3 = FileDownloader.best_block_size(var_1, var_2)
    assert type(var_3) == int

    var_0 = 0.0
    var_1 = 0.0
   

# Generated at 2022-06-26 11:08:14.773858
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    var_0 = None
    var_1 = None
    var_2 = None
    file_downloader_0 = FileDownloader(var_0, var_1)
    var_3 = file_downloader_0.calc_speed(var_0, var_1, var_2)
    assert var_3 == None


# Generated at 2022-06-26 11:08:25.641155
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    var_0 = {'status': 'downloading', 'speed': '10.0', '_eta_str': 'Unknown ETA', '_total_bytes_str': '1.0%', 'downloaded_bytes': '10', 'total_bytes': '100', '_percent_str': '10.0%', '_speed_str': '10.0b/s'}
    var_1 = {'status': 'downloading', 'speed': '10.0', '_eta_str': 'Unknown ETA', '_total_bytes_estimate_str': '1.0%', 'downloaded_bytes': '10', 'total_bytes_estimate': '100', '_percent_str': '10.0%', '_speed_str': '10.0b/s'}
    file_downloader_0 = FileDownloader

# Generated at 2022-06-26 11:08:41.658543
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    var_0 = 0.1
    var_1 = 0.2
    var_2 = FileDownloader.best_block_size(var_1, var_0)


# Generated at 2022-06-26 11:08:47.922760
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    var_0 = None
    file_downloader_1 = FileDownloader(var_0, var_0)
    retries = (0, float('inf'), 20)
    for r in retries:
        formated = file_downloader_1.format_retries(r)
        print('%f -> %s' % (r, formated))


# Generated at 2022-06-26 11:08:56.124758
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    var_1 = None
    var_2 = float('inf')
    file_downloader_0 = FileDownloader(var_1, var_1)
    assert(file_downloader_0.format_retries(var_2) == 'inf')
    var_2 = 0
    assert(file_downloader_0.format_retries(var_2) == '0')
    var_2 = 1
    assert(file_downloader_0.format_retries(var_2) == '1')


# Generated at 2022-06-26 11:08:57.507380
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    pass


# Generated at 2022-06-26 11:09:03.504402
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = None
    var_1 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    val_0 = file_downloader_0.try_utime(var_1, var_1)
    assert val_0 == None


# Generated at 2022-06-26 11:09:15.901697
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'noprogress': False})
    fd = FileDownloader(ydl, {})

    e = {'status': 'downloading',
         'total_bytes_estimate': 5000,
         'downloaded_bytes': 0,
         'speed': 500}
    fd.report_progress(e)
    assert '>' in read_all_stdout()
    e = {'status': 'downloading',
         'total_bytes_estimate': 5000,
         'downloaded_bytes': 4567,
         'speed': 500,
         'eta': 999}
    fd.report_progress(e)
    assert '>' in read_all_stdout()

# Generated at 2022-06-26 11:09:27.884555
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def x_gen_func(_):
        return True

    var_0 = {'x_gen_func': x_gen_func}
    var_0.update({'test_case': test_case_0})
    file_downloader_0 = FileDownloader(var_0, var_0)
    file_downloader_0.temp_name('test')
    file_downloader_0.undo_temp_name('test')
    file_downloader_0.ytdl_filename('test')
    assert not file_downloader_0.try_rename('test', 'test1')
    assert not file_downloader_0.try_utime('test', 'test1')
    assert file_downloader_0.report_destination('test')
    s = {'status': 'finished'}
    file_

# Generated at 2022-06-26 11:09:39.174076
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    print('Testing best_block_size')
    fd = FileDownloader('', None)
    assert fd.best_block_size(0, 0) == 1
    orig_min, orig_max = fd._MIN_BLOCK_SIZE, fd._MAX_BLOCK_SIZE
    fd._MIN_BLOCK_SIZE, fd._MAX_BLOCK_SIZE = 1, 4194304
    assert fd.best_block_size(1, 1) == 1
    assert fd.best_block_size(0.5, 1) == 2
    assert fd.best_block_size(0.5, 2) == 1
    assert fd.best_block_size(2, 2) == 1
    assert fd.best_block_size(0.5, 4194304) == 2097152

# Generated at 2022-06-26 11:09:46.006210
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_1 = None
    file_downloader_1 = FileDownloader(var_1, var_1)
    var_1 = u'filename'
    var_2 = None
    res_1 = file_downloader_1.download(var_1, var_2)
    assert res_1 is True


# Generated at 2022-06-26 11:09:50.286833
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    filename_0 = ""
    info_dict_0 = {'fragments': [], 'title': '', 'webpage_url': ''}
    try:
        if file_downloader_0.download(filename_0, info_dict_0):
            pass
    except:
        pass


# Generated at 2022-06-26 11:10:42.099520
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_3 = '/tmp/youtube-dl/test/youtube-dl/test/test/ts'
    var_4 = 'Tue, 15 Nov 1994 12:45:26 GMT'
    var_5 = FileDownloader._FileDownloader__try_utime(var_4, var_3)
    return var_5


# Generated at 2022-06-26 11:10:43.087164
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    return


# Generated at 2022-06-26 11:10:47.109257
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    var_0 = None
    var_1 = file_downloader_0.try_utime(var_0, var_0)


# Generated at 2022-06-26 11:10:53.848305
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    dl_0 = {
        '_eta_str': '0:00:02',
        'status': 'downloading',
        '_percent_str': 'Unknown %',
        '_downloaded_bytes_str': '   1.7KiB',
        '_elapsed_str': '0:00:00',
        'downloaded_bytes': 1722,
        'elapsed': 1.971573829650879,
        '_speed_str': 'Unknown speed'
    }

    test_FileDownloader = FileDownloader(var_0, var_0)
    test_FileDownloader.params = {'noprogress': False}
    test_FileDownloader.report_progress(dl_0)


# Generated at 2022-06-26 11:10:57.307715
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test case 0
    test_case_0()
    # Report that test is completed
    print('test_FileDownloader_report_progress success')


# Generated at 2022-06-26 11:11:03.490987
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Arrange and act
    file_downloader_0 = FileDownloader(None, None)
    actual_result = file_downloader_0.format_retries(10)
    # Assert
    assert actual_result == '10'


# Generated at 2022-06-26 11:11:09.495821
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
  fd = FileDownloader(params={'ratelimit': '63688000.0'}, ydl=None)
  fd.slow_down(start_time=0, now=0, byte_counter=0)


# Generated at 2022-06-26 11:11:13.130260
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    var_0 = None
    var_1 = time.time()
    var_2 = time.time()
    var_3 = int()
    file_downloader_1 = FileDownloader(var_0, var_0)
    file_downloader_1.slow_down(var_1, var_2, var_3)


# Generated at 2022-06-26 11:11:24.935666
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader(
        {},
        {})
#     file_downloader_0.slow_down(
#         var_0,
#         var_0,
#         var_0)
#
# # Unit test for method to_screen of class FileDownloader
# def test_FileDownloader_to_screen():
#     file_downloader_0 = FileDownloader(
#         {},
#         {})
#     file_downloader_0.to_screen()
#
# # Unit test for method trouble of class FileDownloader
# def test_FileDownloader_trouble():
#     file_downloader_0 = FileDownloader(
#         {},
#         {})
#     file_downloader_0.trouble()
#
# # Unit test for method report

# Generated at 2022-06-26 11:11:34.058475
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)
    start_0 = 0
    now_0 = 0
    current_0 = 0
    total_0 = 0
    var_4 = file_downloader_0.calc_eta(start_0, now_0, current_0, total_0)
    var_5 = assert_var(var_4, None)


# Generated at 2022-06-26 11:12:38.206037
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    def progress_hook(status):
        print(status)

    ydl_opts = {
        'ratelimit': 1.0,
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s.%(ext)s',
    }
    ydl = YoutubeDL(ydl_opts)

# Generated at 2022-06-26 11:12:44.548872
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = None
    file_downloader_0 = FileDownloader(var_0, var_0)

    filename_0 = None
    info_dict_0 = {}
    file_downloader_0.download(filename_0, info_dict_0)
