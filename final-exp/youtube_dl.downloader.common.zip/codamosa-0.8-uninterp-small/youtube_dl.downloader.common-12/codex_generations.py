

# Generated at 2022-06-26 11:03:19.173576
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes("10k") == 10240
    assert FileDownloader.parse_bytes("10K") == 10240
    assert FileDownloader.parse_bytes("1M") == 1048576
    assert FileDownloader.parse_bytes("4">"") == 67108864
    assert FileDownloa

# Generated at 2022-06-26 11:03:24.121853
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    time_0 = time.time()
    time_1 = time.time()
    int_0 = 0
    file_downloader_0.slow_down(time_0, time_1, int_0)


# Generated at 2022-06-26 11:03:26.740146
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader_0 = FileDownloader(None)
    assert file_downloader_0.parse_bytes('123') == 123


# Generated at 2022-06-26 11:03:30.307937
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    file_downloader_0.slow_down(float(), float(), int())
    

# Generated at 2022-06-26 11:03:43.851742
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_1 = {}
    dict_1['id'] = 'wCJiSfyA1D4'
    dict_1['title'] = 'Beautiful Relaxing Music - Sleep Music, Study Music, Calm Music, Meditation Music'
    dict_1['ext'] = 'mp3'
    dict_1['url'] = 'https://www.youtube.com/watch?v=wCJiSfyA1D4'
    dict_1['extractor'] = 'youtube'
    dict_1['format'] = '251'
    dict_1['format_id'] = '251'
    dict_1['filesize'] = None

# Generated at 2022-06-26 11:03:50.143540
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    
    status = {'status': 'finished', 'total_bytes': None, 'total_bytes_estimate': None,\
        'total_bytes_filtered': None, 'downloaded_bytes': None, 'downloaded_bytes_filtered': None,\
        'tmpfilename': 'tmpfilename', 'filename': 'filename', 'eta': None, 'elapsed': None, 'speed': None}
    
    file_downloader_0.report_progress(status)

    assert True


# Generated at 2022-06-26 11:03:55.033645
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    file_downloader_0 = FileDownloader([], [])
    elapsed_time_0 = random.random()
    bytes_0 = random.randint(1, 1000)
    assert file_downloader_0.best_block_size(elapsed_time_0, bytes_0)


# Generated at 2022-06-26 11:04:09.762260
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('10K') == 10240
    assert FileDownloader.parse_bytes('10k') == 10240
    assert FileDownloader.parse_bytes('10KiB') == 10240
    assert FileDownloader.parse_bytes('10Ki') == 10240
    assert FileDownloader.parse_bytes('10kb') == 10240
    assert FileDownloader.parse_bytes('10kib') == 10240
    assert FileDownloader.parse_bytes('10KIB') == 10240
    assert FileDownloader.parse_bytes('10Ki') == 10240
    assert FileDownloader.parse_bytes('10ki') == 10240
    assert FileDownloader.parse_bytes('2000') == 2000

# Generated at 2022-06-26 11:04:13.919118
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    args_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    s_0 = {}

    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:04:23.924386
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    speed_0 = None
    speed_1 = float(0)
    float_0 = float(speed_1)
    float_1 = float(0)
    float_2 = float(35)
    date_0 = datetime.date(2000, 1, 1)
    date_time_0 = datetime.datetime(2000, 1, 1)
    time_0 = datetime.time(15, 30)
    bool_0 = bool(35)
    int_0 = int(speed_1)
    int_1 = int(314159)
    int_2 = int(speed_1)
    str_0 = str(int_2)
    str_1 = str(bool_0)

    # Call method

# Generated at 2022-06-26 11:04:44.103739
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_obj_0 = FileDownloader()
    file_downloader_obj_1 = FileDownloader()
    tup_0 = {}
    tup_1 = {}
    file_downloader_obj_1.report_progress(tup_0)


# Generated at 2022-06-26 11:04:47.613103
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    FileDownloader.try_utime(test_case_0(), test_case_0(), test_case_0())


# Generated at 2022-06-26 11:04:49.506105
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    test_case_0()


# Generated at 2022-06-26 11:04:52.047377
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    var_0 = {}
    var_1 = {}


# Generated at 2022-06-26 11:04:59.378154
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from youtube_dl.FileDownloader import FileDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl=ydl, params=var_0, info_dict=var_1)
    fd.report_file_already_downloaded(filename='test_file')


# Generated at 2022-06-26 11:05:04.531336
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    print("\n[test_FileDownloader_parse_bytes]")
    fd = FileDownloader(var_0, var_1)
    fd.parse_bytes("")


# Generated at 2022-06-26 11:05:10.378228
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    print('Testing FileDownloader.calc_speed')

    var_0 = FileDownloader()
    var_1 = time.time()
    var_2 = time.time()
    var_3 = 0
    var_4 = var_0.calc_speed(var_1, var_2, var_3)



# Generated at 2022-06-26 11:05:20.826115
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    var_0 = 'wonderful'
    var_1 = FileDownloader
    var_1.undo_temp_name(var_0)
    var_0 = 'wonderful.part'
    var_1.undo_temp_name(var_0)
    var_0 = 'wonderfulpart'
    var_1.undo_temp_name(var_0)
    var_0 = 0
    var_1.undo_temp_name(var_0)


# Generated at 2022-06-26 11:05:26.304856
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    var_0 = {'outtmpl': '%(id)s%(ext)s'}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = object()


# Generated at 2022-06-26 11:05:31.426113
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_0 = FileDownloader()
    var_1 = {}
    var_1 = u'test'
    var_2 = {}
    var_2 = {}
    var_2 = var_0.download(var_1, var_2)

# Generated at 2022-06-26 11:05:48.706680
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(YoutubeDL(YoutubeDLOptions()),'https://www.youtube.com/watch?v=gZfuD0ZBuzI', {})
    assert fd.slow_down(0,0,0) == None
    assert fd.slow_down(0,0,10) == None

# Generated at 2022-06-26 11:05:50.072665
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    arg_0 = 'test_file'
    obj_0 = FileDownloader()
    assert(obj_0.undo_temp_name(arg_0) == 'test_file')


# Generated at 2022-06-26 11:05:57.236362
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    str_0 = 'test_file'
    str_1 = 'test_file'
    str_2 = 'test_file'
    test_FileDownloader_calc_speed_var_0 = FileDownloader(str_0, str_1)

    test_FileDownloader_calc_speed_var_1 = test_FileDownloader_calc_speed_var_0.calc_speed(str_2)
    return test_FileDownloader_calc_speed_var_1


# Generated at 2022-06-26 11:05:59.178310
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = 'test_file'
    obj_FileDownloader_0 = FileDownloader(None, None)
    obj_FileDownloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:06:06.596256
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Testing str_0
    str_0 = 'test_file'
    str_return_0 = FileDownloader.undo_temp_name(str_0)
    assert_equal(str_return_0, 'test_file')
    # Testing str_1
    str_1 = 'test_file.part'
    str_return_1 = FileDownloader.undo_temp_name(str_1)
    assert_equal(str_return_1, 'test_file')


# Generated at 2022-06-26 11:06:16.916158
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert_equals(1, FileDownloader.best_block_size(0, 1))
    assert_equals(1, FileDownloader.best_block_size(0, 2))
    assert_equals(1, FileDownloader.best_block_size(0, 3))
    assert_equals(1, FileDownloader.best_block_size(0, 4))
    assert_equals(2, FileDownloader.best_block_size(0, 5))
    assert_equals(2, FileDownloader.best_block_size(0, 6))
    assert_equals(2, FileDownloader.best_block_size(0, 7))
    assert_equals(2, FileDownloader.best_block_size(0, 8))

# Generated at 2022-06-26 11:06:30.750772
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # raise NotImplementedError
    test_case_0()
    test_FileDownloader_add_progress_hook()
    test_FileDownloader__debug_cmd()
    test_FileDownloader_add_progress_hook()
    test_FileDownloader_report_retry()
    test_FileDownloader_report_progress()
    test_FileDownloader_real_download()
    test_FileDownloader_report_file_already_downloaded()
    test_FileDownloader_report_resuming_byte()
    test_FileDownloader_temp_name()
    test_FileDownloader_undo_temp_name()
    test_FileDownloader_trouble()
    test_FileDownloader_try_utime()
    test_FileDownloader_calc_eta()
    test_FileDownloader_format

# Generated at 2022-06-26 11:06:36.293986
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test case 0
    str_0 = 'test_file'
    fd = FileDownloader(YoutubeDL())
    fd.params['nopart'] = False
    fd.try_utime(str_0, None)


# Generated at 2022-06-26 11:06:46.231666
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Define a dict for choosing the options for method download
    options = {
        'filename': 'output',
        'outtmpl': '%(title)s.f4v',
        'format': 'best',
        'outtmpl': '%(id)s.%(ext)s',
        'noprogress': True,
        'quiet': True,
    }
    # Call the method to initialize the FileDownloader
    file_d = FileDownloader('http://127.0.0.1:8080', options)
    # Call the method to download the file
    file_d.download()
    # Call the method to test the method
    file_d.clean_fmt_options()


# Generated at 2022-06-26 11:06:49.989139
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader_0 = FileDownloader()

    
    assert file_downloader_0.parse_bytes(str_0) == None


# Generated at 2022-06-26 11:07:07.901619
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'test_file'
    fd_0 = FileDownloader
    time_0 = time
    float_0 = float
    dict_0 = dict()
    dict_0['rate_limit'] = float_0
    fd_0.params = dict_0
    fd_0.slow_down(float_0, float_0, float_0)
    fd_0.slow_down(float_0, float_0, float_0)
    dict_0['rate_limit'] = float_0
    fd_0.slow_down(float_0, float_0, float_0)


# Generated at 2022-06-26 11:07:11.644688
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    test_case_0()
    FileDownloader.slow_down(test_case_0, test_case_0, test_case_0)


# Generated at 2022-06-26 11:07:13.136454
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    return


# Generated at 2022-06-26 11:07:16.338707
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    test_case_0()

if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-26 11:07:22.383500
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    tmp_file = 'test_file.part'
    obj = FileDownloader(None)
    assert obj.undo_temp_name(tmp_file) == 'test_file'


# Generated at 2022-06-26 11:07:26.450642
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(str_0, None, None)

    assert fd.temp_name(str_0) == 'test_file.part'


# Generated at 2022-06-26 11:07:31.591091
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'test_file'
    fd = FileDownloader({'ratelimit':10^10}, None)
    fd.slow_down(0,5,10)



# Generated at 2022-06-26 11:07:36.015879
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import datetime
    timestamp = datetime.datetime.utcnow().timestamp()
    print(timestamp)
    time.sleep(2)

    file_downloader = FileDownloader({})

    timestamp = datetime.datetime.utcnow().timestamp()
    print(timestamp)
    file_downloader.try_utime(str_0, timestamp)


# Generated at 2022-06-26 11:07:42.049771
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    """
    report_file_already_downloaded(self, file_name)
    """

    #
    # Test case 0
    #
    str_0 = 'test_file'

# Generated at 2022-06-26 11:07:50.155089
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader({}, {})
    filename_0 = 'test_file'
    info_dict_0 = {}
    exception_0 = False
    try:
        fd.download(filename_0, info_dict_0)
    except NotImplementedError as e:
        exception_0 = True
    print(exception_0)
    assert exception_0

if __name__ == '__main__':
    test_FileDownloader_download()

# Generated at 2022-06-26 11:08:05.701762
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bool_0 = True
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_0 = {}
    dict_0['status'] = 'finished'
    file_downloader_0._report_progress_status('%(_total_bytes_str)s in %(_elapsed_str)s', True)
    file_downloader_0.report_progress(dict_0)
    dict_0['elapsed'] = 1
    file_downloader_0.report_progress(dict_0)
    dict_0['status'] = 'downloading'
    dict_0['total_bytes'] = 1
    dict_0['downloaded_bytes'] = 1
    file_downloader_0.report_progress(dict_0)

# Generated at 2022-06-26 11:08:12.895549
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    start_0 = 12
    now_0 = 9
    current_0 = 8
    total_0 = 11
    test_FileDownloader_calc_eta_0 = file_downloader_0.calc_eta(start_0, now_0, current_0, total_0)
    print('test_FileDownloader_calc_eta_0: ' + str(test_FileDownloader_calc_eta_0))


# Generated at 2022-06-26 11:08:20.952287
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    bool_0 = True
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    filename = "test"
    last_modified_hdr = None
    filetime = file_downloader_0.try_utime(filename, last_modified_hdr)
    assert filetime is None


# Generated at 2022-06-26 11:08:32.057247
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():

    s = FileDownloader(False, {})

    # Test case 0
    assert (s.format_seconds(3) == '00:03')

    # Test case 1
    assert (s.format_seconds(61) == '01:01')

    # Test case 2
    assert (s.format_seconds(3661) == '01:01:01')

    # Test case 3
    assert (s.format_seconds(None) == '--:--')

    # Test case 4
    assert (s.format_seconds(0) == '00:00')


# Generated at 2022-06-26 11:08:43.191879
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    print("Test for method report_file_already_downloaded of class FileDownloader")
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    str_0 = "���<�f�Z�n�����P�H��(�B���O�̃t�H�[��)�w�b�_"
    file_downloader_0.report_file_already_downloaded(str_0)



# Generated at 2022-06-26 11:08:56.961234
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    print('Testing FileDownloader.parse_bytes')
    file_downloader_0 = FileDownloader(False, {})
    file_downloader_0.ydl = YoutubeDL({'quiet': True})

    assert file_downloader_0.parse_bytes('3') == 3
    assert file_downloader_0.parse_bytes(' 3') == 3
    assert file_downloader_0.parse_bytes('3 ') == 3
    assert file_downloader_0.parse_bytes(' 3 ') == 3
    assert file_downloader_0.parse_bytes('3.4') == 3
    assert file_downloader_0.parse_bytes('3.4k') == 3.4 * 1024
    assert file_downloader_0.parse_bytes('3.5Ki') == 3.5 * 1024
    assert file_

# Generated at 2022-06-26 11:08:59.504139
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    filename = 'test.mp4'
    res = file_downloader_0.temp_name(filename)

# Generated at 2022-06-26 11:09:12.160731
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    test_case_signature = "FileDownloader_parse_bytes"

# Generated at 2022-06-26 11:09:15.479232
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    file_downloader_0 = FileDownloader(None, None)
    time_0 = time.time()
    result = file_downloader_0.calc_speed(time_0, time_0, 0)
    assert(result is None)
    # TODO: check result with expected value


# Generated at 2022-06-26 11:09:27.832434
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    file_downloader_0.ydl = ytdl_0 = YoutubeDL()
    str_0 = '-oc-vb'
    try:
        file_downloader_0.temp_name(str_0)
    except Exception:
        file_downloader_0.report_error('unable to rename file: %s' % error_to_compat_str(Exception))

# Generated at 2022-06-26 11:09:48.783241
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(None, None)
    filename = random.choice(string.ascii_letters)
    last_modified_hdr = random.choice(string.ascii_letters)
    ret_val = file_downloader_0.try_utime(filename, last_modified_hdr)
    print('ret_val: ' + str(ret_val))

if __name__ == '__main__':
    # Generate a random string
    filename = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    last_modified_hdr = int(time.time())

    # Create a random file
    file = open(filename, 'w')

# Generated at 2022-06-26 11:09:56.187603
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = 'test_name'
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    file_downloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:10:00.889681
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    '''
    Test function for the report_progress function.
    '''

    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)

    s_0 = {}

    try:
        file_downloader_0.report_progress(s_0)
    except:
        return False

    return True


# Generated at 2022-06-26 11:10:12.414675
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test case 0 (test_case_0)
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)

    # Test case 1 (test_case_1)
    bool_0 = True
    dict_0 = ''
    file_downloader_0 = FileDownloader(bool_0, dict_0)

    # Test case 2 (test_case_2)
    bool_0 = True
    dict_0 = 'Pwc8tJ_Kz'
    file_downloader_0 = FileDownloader(bool_0, dict_0)

    # Test case 3 (test_case_3)
    bool_0 = True
    dict_0 = 'eUDl7I'

# Generated at 2022-06-26 11:10:24.150207
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    file_downloader_0.to_stderr = MagicMock()
    file_downloader_0.to_stderr.side_effect = my_side_effect

    # Call the method
    result = file_downloader_0.try_utime("file_name_0", "last_modified_hdr_0")

    # Check the results
    assert result == None
    assert file_downloader_0.to_stderr.call_count == 0



# Generated at 2022-06-26 11:10:36.269116
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bool_0 = True
    dict_0 = {'noprogress': True, 'format': 'bestvideo+bestaudio/best'}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_1 = {'elapsed': 5.028, 'total_bytes_estimate': None, 'speed': 'Unknown speed', '_eta_str': 'Unknown ETA', 'status': 'finished', '_total_bytes_estimate_str': 'Unknown %', 'filename': '-', 'total_bytes': None, '_elapsed_str': '00:00:05', '_downloaded_bytes_str': 'Unknown speed', '_speed_str': 'Unknown speed', '_percent_str': '100%%', '_total_bytes_str': 'Unknown %'}
    file_downloader_

# Generated at 2022-06-26 11:10:47.513371
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    dict_0 = dict()
    dict_0['ratelimit'] = (1048576 // 4)
    filename = 'C:\\Users\\Admin\\Desktop\\python\\youtube-dl\\youtube_dl\\downloader\\f4e8501c54.py'
    file_downloader_0 = FileDownloader(dict_0, dict_0)
    filetime = file_downloader_0.try_utime(filename, '2013-08-26T10:54:27.000Z')
    return filetime

if __name__ == '__main__':
    # test_FileDownloader_try_utime()
    test_case_0()

# Generated at 2022-06-26 11:10:49.439420
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    s = {}
    file_downloader_0 = FileDownloader(True, {})
    file_downloader_0.report_progress(s)


# Generated at 2022-06-26 11:10:57.165017
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    _filename_0 = FileDownloader.undo_temp_name('./test/test.part')
    assert (_filename_0 == './test/test')
    _filename_1 = FileDownloader.undo_temp_name('./test/test_0.part')
    assert (_filename_1 == './test/test_0')

    test_case_0()

# Generated at 2022-06-26 11:10:59.455324
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    pass


# Generated at 2022-06-26 11:11:34.131716
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(False, {})
    filename_0 = "set-videos"
    the_url = "http://www.youtube.com/watch?v=RnI6Zbq54G8"
    r = requests.get(the_url, params={'format':'best'})
    html = r.text

# Generated at 2022-06-26 11:11:38.169261
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Create a new instance of FileDownloader
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)

    # Call method 'temp_name' of class FileDownloader
    out_str = 'temp_name_output'
    result = file_downloader_0.temp_name(out_str)

    # Test the output
    assert result == 'temp_name_output'


# Generated at 2022-06-26 11:11:42.367147
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test variables
    filename = ''

    file_downloader_0 = FileDownloader(False, {})
    temp_name_0 = file_downloader_0.temp_name(filename)
    check('filename.part', temp_name_0)


# Generated at 2022-06-26 11:11:45.811436
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    dict_0 = {}
    file_downloader_0 = FileDownloader(True, dict_0)
    assert file_downloader_0.slow_down(datetime.datetime(1,1,1,1,1,1), str(5), str(5)) == None


# Generated at 2022-06-26 11:11:53.469563
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_1 = {'elapsed': 0, 'eta': 216.0159912109375, 'speed': 17.868858729382283, 'downloaded_bytes': 0, 'total_bytes': None, 'total_bytes_estimate': None}
    file_downloader_0.report_progress(dict_1)
    dict_2 = {'elapsed': 0, 'eta': 216.0159912109375, 'speed': 17.868858729382283, 'downloaded_bytes': 0, 'total_bytes': None, 'total_bytes_estimate': None}
    file_downloader_0.report_progress(dict_2)
    dict_3

# Generated at 2022-06-26 11:11:56.375781
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # TODO: Add tests for FileDownloader.try_utime
    pass


# Generated at 2022-06-26 11:12:05.805708
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    bool_0 =  False
    dict_0 =  {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    file_downloader_0.to_screen = mock_func(return_value=None)
    file_downloader_0.report_error = mock_func(return_value=None)
    file_downloader_0.report_warning = mock_func(return_value=None)
    file_downloader_0.trouble = mock_func(return_value=None)
    str_0 = "t"
    file_downloader_0.try_utime('t', str_0)



# Generated at 2022-06-26 11:12:07.211578
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()


# Generated at 2022-06-26 11:12:09.225076
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()


# Generated at 2022-06-26 11:12:18.267968
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert '0:00:00' == FileDownloader.format_seconds(0)
    assert '0:00:59' == FileDownloader.format_seconds(59)
    assert '0:01:00' == FileDownloader.format_seconds(60)
    assert '0:01:01' == FileDownloader.format_seconds(61)
    assert '0:59:59' == FileDownloader.format_seconds(3599)
    assert '1:00:00' == FileDownloader.format_seconds(3600)
    assert '1:00:01' == FileDownloader.format_seconds(3601)
    assert '1:01:01' == FileDownloader.format_seconds(3661)
    assert '23:59:59' == FileDownloader.format_seconds(86399)

# Generated at 2022-06-26 11:12:38.239939
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile

    fp = tempfile.NamedTemporaryFile(prefix='youtube-dl-test_', delete=False)
    fp.write(b'foobar')
    fp.close()

    ydl_opts = {
        'simulate': True,
        'quiet': True,
    }

    fd = FileDownloader(ydl_opts, {})

    fd.real_download = lambda filename, info: None

    assert fd.download(fp.name, {'id': '123', 'title': 'abc'})
    assert fd.download('-', {'id': '123', 'title': 'abc'})
    assert not fd.download(fp.name, {'id': '123', 'title': 'abc'})

# Generated at 2022-06-26 11:12:43.823114
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '00:00';

    assert FileDownloader.format_seconds(5) == '00:05';
    assert FileDownloader.format_seconds(59) == '00:59';
    assert FileDownloader.format_seconds(60) == '01:00';
    assert FileDownloader.format_seconds(61) == '01:01';
    assert FileDownloader.format_seconds(70) == '01:10';
    assert FileDownloader.format_seconds(69) == '01:09';

    assert FileDownloader.format_seconds(3599) == '59:59';
    assert FileDownloader.format_seconds(3600) == '1:00:00';
    assert FileDownloader.format_seconds(3700) == '1:01:40';

# Generated at 2022-06-26 11:12:49.988710
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bool_0 = False
    dict_0 = {}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_0 = {'downloaded_bytes': ten, 'total_bytes_estimate': gen_0, 'status': 'downloading', 'speed': gen_0, 'total_bytes': gen_0, 'elapsed': gen_0}
    file_downloader_0.report_progress(dict_0)
