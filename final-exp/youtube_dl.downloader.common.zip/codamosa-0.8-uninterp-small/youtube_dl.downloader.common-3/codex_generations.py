

# Generated at 2022-06-26 11:03:48.469256
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 9094
    str_0 = '+#Jk'
    file_downloader_0 = FileDownloader(int_0, str_0)
    var_0 = { }
    return file_downloader_0.report_progress(var_0)


# Generated at 2022-06-26 11:03:53.244893
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_1 = 'N'
    int_1 = file_downloader_0.temp_name(str_1)
    temp_name_assert(int_1, str_1)


# Generated at 2022-06-26 11:04:07.103402
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    time_0 = time.time()
    time_1 = time_0 + 1
    file_downloader_0 = FileDownloader(0, (0))
    assert isinstance(file_downloader_0._last_modified, float)
    assert isinstance(file_downloader_0._last_modified_epoch, float)
    assert isinstance(file_downloader_0._info_dict, dict)
    assert isinstance(file_downloader_0._last_activity, float)
    assert isinstance(file_downloader_0._outtmpl, str)
    assert isinstance(file_downloader_0._download_retcode, int)
    assert isinstance(file_downloader_0._total_bytes_estimate, int)

# Generated at 2022-06-26 11:04:14.693653
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Arrange
    file_downloader_0 = FileDownloader(2, '1R)+B')

    # Act
    file_downloader_0.report_progress(status='downloading',
                                      downloaded_bytes=98)

    # Assert

if __name__ == '__main__':
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:04:24.544891
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    int_0 = 3488
    str_0 = 'q3c%0h4Zl'
    file_downloader_0 = FileDownloader(int_0, str_0)
    float_0 = float(2)
    float_1 = float(3)
    float_2 = float(0)
    float_3 = float(0)
    float_4 = float(0)
    float_5 = float(0)
    float_6 = float(0)
    float_7 = float(0)
    float_8 = float(0)
    float_9 = float(0)
    float_10 = float(0)
    float_11 = float(0)
    float_12 = float(0)
    float_13 = float(0)
    float_14 = float(0)
    float_

# Generated at 2022-06-26 11:04:31.239657
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    var_22 = str('LZ')
    var_23 = dict({
        'B': '{',
        'C': 'P',
        'E': '+',
        'F': '@',
        'A': 'D',
        'D': 'p',
    })
    var_24 = FileDownloader(var_22, var_23)
    var_25 = var_24.real_download()
    var_26 = var_24.to_screen()


# Generated at 2022-06-26 11:04:33.514837
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(2227, '1R)+B')
    assert_equals(file_downloader_0.try_utime('',None), None)


# Generated at 2022-06-26 11:04:35.331547
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader('', '').temp_name('-') == '-' and FileDownloader('', '').temp_name('a') == 'a.part'


# Generated at 2022-06-26 11:04:40.681818
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # 1st test case
    int_0 = 2227
    str_0 = '1R)+B'
    file_downloader_0 = FileDownloader(int_0, str_0)
    dict_0 = {
        'elapsed': None,
        'eta': None,
        'speed': None,
        'downloaded_bytes': None,
        'total_bytes': None,
        'total_bytes_estimate': None,
        'status': 'downloading'
    }
    var_0 = file_downloader_0.report_progress(dict_0) # void method

    # 2nd test case
    int_0 = 2227
    str_0 = '1R)+B'
    file_downloader_0 = FileDownloader(int_0, str_0)

# Generated at 2022-06-26 11:04:52.691010
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    int_0 = 2227
    str_0 = '1R)+B'
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_1 = 'm3u8'
    str_2 = 'Rf]g(%?_&'
    var_0 = file_downloader_0.download(str_1, str_2)
    #   assert var_0 == None
    #   assert file_downloader_0.to_screen() == None
    #   assert file_downloader_0.report_progress() == None
    #   assert file_downloader_0.real_download() == None
    #   assert file_downloader_0.report_progress() == None
    #   assert file_downloader_0._hook_progress() == None
    #   assert file_

# Generated at 2022-06-26 11:05:05.423155
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test case 0
    file_downloader_0 = FileDownloader(0, '')
    param_0 = 'video.part'
    returned_0 = file_downloader_0.undo_temp_name(param_0)
    assert returned_0 == 'video'


# Generated at 2022-06-26 11:05:13.579743
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    a_dict = {
        'status': '',
        'total_bytes': None,
        'downloaded_bytes': None,
        'total_bitrate': None,
        'downloaded_bitrate': None,
        '_percent_str': None,
        '_total_bytes_str': None,
        '_elapsed_str': None,
        '_eta_str': None,
        '_speed_str': None,
        '_bitrate_str': None,
    }
    file_downloader_0.report_progress(a_dict)


# Generated at 2022-06-26 11:05:19.027717
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    dld = FileDownloader(0, {})
    int_0 = 0
    str_0 = ''
    result = dld.try_utime(str(int_0), str_0)
    assert result == None


# Generated at 2022-06-26 11:05:22.585447
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_1 = ''
    file_downloader_0.try_utime(str_1, str_1)


# Generated at 2022-06-26 11:05:32.230546
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    logger.info('Testing FileDownloader.report_progress')
    # Test case 1
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    s = {
        'status': 'downloading',
        'downloaded_bytes': 99,
        'total_bytes_estimate': 44,
        'speed': 7.96,
        'eta': 2
    }
    file_downloader_0.report_progress(s)


# Generated at 2022-06-26 11:05:41.220840
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-26 11:05:46.691188
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    dict_0 = dict()
    dict_0['total_bytes'] = '1.50KiB'
    dict_0['downloaded_bytes'] = '2KiB'
    dict_0['speed'] = '1.50KiB/s'
    dict_0['eta'] = '1s'
    dict_0['status'] = 'finished'
    file_downloader_0 = FileDownloader(0, '')
    file_downloader_0.report_progress(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:05:47.385997
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    pass


# Generated at 2022-06-26 11:05:57.117099
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)

    # Test 1
    # Size of argument is 0
    s_0 = {} 
    result_1 = file_downloader_0.report_progress(s_0)
    assert result_1 == None   

    # Test 2
    # Size of argument is not 0 and noprogress is true
    s_0 = {
        'status' : 'finished',
        'total_bytes' : 12345
    }
    result_2 = file_downloader_0.report_progress(s_0)
    assert result_2 == None

    # Test 3
    # Size of argument is not 0 and status is downloading

# Generated at 2022-06-26 11:06:00.426456
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(0, '')
    assert file_downloader_0.download('test_file', {}) == True, ''


# Generated at 2022-06-26 11:06:13.695514
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader_0 = FileDownloader(0, '')
    time_0 = time.time()
    time_1 = time.time()
    int_0 = 0
    file_downloader_0.slow_down(time_0, time_1, int_0)


# Generated at 2022-06-26 11:06:22.644041
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_2 = 'Fri, 13 Feb 2009 23:31:30 GMT'
    int_2 = 1234
    file_downloader_0.try_utime(str_1, str_2)
    file_downloader_0.try_utime(str_1, int_2)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_try_utime()
# End of test cases

# Generated at 2022-06-26 11:06:29.214584
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    tmp = os.tmpnam()
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    ExpectEq(True, file_downloader_0.download(tmp, str_0))


# Generated at 2022-06-26 11:06:36.920097
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Create a test object of class FileDownloader
    # with parameters:
    #   1. int = 0
    #   2. str = ''
    test_object = FileDownloader(0, '')

    # set variable s to be a test object
    variable_s = test_object

    # set variable msg_template to be an empty string
    variable_msg_template = ''

    # call method report_progress of class FileDownloader on variable s
    # with parameter msg_template
    test_object.report_progress(msg_template)

if __name__ == '__main__':
    # test method report_progress of class FileDownloader
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:06:40.332856
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 236
    str_0 = 'G\\/q<!EiF'
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_downloader_0.slow_down(float_0, float_1, float_2)


# Generated at 2022-06-26 11:06:47.113928
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import random
    import math
    int_0 = random.randint(0, 100)
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    file_downloader_0 = FileDownloader(int_0, str_0)
    dict_0 = collections.defaultdict(lambda: math.pi)
    dict_0['entropy'] = 71
    file_downloader_0.report_progress(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:06:51.521771
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    time_0 = time.time()
    int_1 = 0
    int_2 = 0
    file_downloader_0.slow_down(time_0, int_1, int_2)


# Generated at 2022-06-26 11:06:58.489830
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    file_downloader_0.slow_down(int_0, int_1, int_2, int_3)


# Generated at 2022-06-26 11:07:03.906279
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    assert file_downloader_0.format_retries(1) == '1'


# Generated at 2022-06-26 11:07:07.833547
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    s_0 = {}
    file_downloader_0.report_progress(s_0)
test_FileDownloader_report_progress()


# Generated at 2022-06-26 11:07:29.385907
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_downloader_0.calc_speed(int_0, int_0, int_0)


# Generated at 2022-06-26 11:07:37.529765
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_2 = 'test_video.f4v'
    str_1 = file_downloader_0.temp_name(str_2)

    assert str_1 == 'test_video.f4v'


# Generated at 2022-06-26 11:07:42.859042
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader(0, "p_FileDownloader_0")
    file_downloader_0.try_utime("p_FileDownloader_try_utime_filename_0", 'p_FileDownloader_try_utime_last_modified_hdr_1')
    # Testing if an exception is raised when a wrong path is given
    try:
        file_downloader_0.try_utime("p_FileDownloader_try_utime_filename_2", 'p_FileDownloader_try_utime_last_modified_hdr_3')
    except Exception as e:
        pass


# Generated at 2022-06-26 11:07:49.719682
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    dict_0 = {
        'status': 'finished',
        'total_bytes': 0.6958444391550582,
    }
    file_downloader_0.report_progress(dict_0)



# Generated at 2022-06-26 11:08:00.439316
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader = FileDownloader(0, '')
    # Check whether filename satisfy the equation: nooverwrites_and_exists. 
    # If so, it should return True
    # Otherwise, it'll be False
    filename = True
    info_dict = 0
    # In this case, filename is True, so it'll return True
    ret = file_downloader.download(filename, info_dict)
    # If the method run correctly, then the ret should be True
    assert ret


# Generated at 2022-06-26 11:08:12.985563
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    dict_0 = {
    }
    try:
        file_downloader_0.report_progress(dict_0)
        assert False
    except TypeError as e:
        assert True
    dict_1 = {
        'status': '',
    }
    file_downloader_0.report_progress(dict_1)
    dict_1 = {
        'status': '',
        'elapsed': 0,
    }
    file_downloader_0.report_progress(dict_1)
    dict_1 = {
        'status': '',
        'elapsed': 0,
        'total_bytes': 0,
    }
    file_downloader_0

# Generated at 2022-06-26 11:08:25.094551
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL

    run_test_params = {
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s'
    }

    run_test_urls = [
        'https://www.youtube.com/watch?v=yU-b6rqr3UQ',
        'https://www.youtube.com/watch?v=pT8m7YusuzA',
        'https://www.youtube.com/watch?v=cBtSmZ9t9X8',
        'https://www.youtube.com/watch?v=VT1-sitWRtY'
    ]

    test_ydl = YoutubeDL(run_test_params)
    test_ydl.add_default_info_extractors()
    test

# Generated at 2022-06-26 11:08:36.240849
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    float_0 = float('inf')
    FileDownloader.format_retries(float_0)
    FileDownloader.calc_eta(int_0, int_0, int_0, int_0)
    FileDownloader.calc_speed(int_0, int_0, int_0)
    FileDownloader.calc_percent(int_0, int_0, int_0)
    FileDownloader.calc_eta(int_0, int_0, int_0, int_0)
    FileDownloader.calc_speed(int_0, int_0, int_0)
    FileDownloader.best_block_size(int_0, int_0)
    FileDownloader.format_eta(int_0)
    FileDownloader.format_eta(int_0)
    FileDownload

# Generated at 2022-06-26 11:08:38.930971
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_0 = ''
    dict_0 = {
    }
    file_downloader_0.download(str_0, dict_0)


# Generated at 2022-06-26 11:08:46.847736
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_localfolderpath = 'D:\\Temp\\YoutubeDLTest'
    test_filename = 'test_file'
    test_ext = 'py'
    test_fullname = test_filename + '.' + test_ext
    test_fullpath = os.path.join(test_localfolderpath, test_fullname)
    test_localfile = open(test_fullpath, 'w')
    test_string = 'test string'
    test_localfile.write(test_string)
    test_localfile.close()
    test_ytdl_fullpath = FileDownloader.ytdl_filename(test_fullpath)
    test_ytdl_file = open(test_ytdl_fullpath, 'w')
    test_string = 'test string'
    test_ytd

# Generated at 2022-06-26 11:09:01.695681
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    assert_raises(NotImplementedError, test_case_0)

if __name__ == '__main__':
    from testing import run_tests
    run_tests(globals())

# Generated at 2022-06-26 11:09:05.115185
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_downloader_0.temp_name(str_0)
    print("Unit tests for FileDownloader.temp_name() passed!")

# Tests for the module FileDownloader

# Generated at 2022-06-26 11:09:16.508105
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    s = {}
    file_downloader_0.report_progress(s)
    assert_equals(s['_speed_str'], 'Unknown speed')
    s['_speed_str'] = 'Unknown speed'
    assert_equals(s['_total_bytes_str'], '')
    s['_total_bytes_str'] = ''
    assert_equals(s['_elapsed_str'], '')
    s['_elapsed_str'] = ''
    assert_equals(s['_percent_str'], 'Unknown %')
    s['_percent_str'] = 'Unknown %'

# Generated at 2022-06-26 11:09:24.147125
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    float_0 = float()
    float_1 = float()
    float_2 = float()
    file_downloader_0.slow_down(float_0, float_1, float_2)


# Generated at 2022-06-26 11:09:25.533504
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert True


test_case_1()
test_case_0()

# Generated at 2022-06-26 11:09:32.630728
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    assert 'inf' == file_downloader_0.format_retries(float('inf'))


# Generated at 2022-06-26 11:09:35.625320
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    assert (FileDownloader(0, '').slow_down(0, 0, 0) is None)


# Generated at 2022-06-26 11:09:44.277344
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    # FIXME: We need a proper simulation of time.time() in order to test this function properly
    #   file_downloader_0.slow_down(int_0, int_0, int_0);


# Generated at 2022-06-26 11:09:50.046224
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_1 = '#'
    dict_0 = {
        '#': '#',
    }
    assert file_downloader_0.download(str_1, dict_0) == True

# Function test_FileDownloader_add_progress_hook

# Generated at 2022-06-26 11:09:53.920962
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    FileDownloader.report_progress(test_case_0, 's')
    return None


# Generated at 2022-06-26 11:10:10.167935
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    float_0 = 0.0
    float_1 = 0.0
    int_1 = 0
    file_downloader_0.slow_down(float_0, float_1, int_1)


# Generated at 2022-06-26 11:10:18.894950
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_down_0 = file_downloader_0.slow_down(int_0, float_0, float_0)
    print(file_down_0)


# Generated at 2022-06-26 11:10:21.301148
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    dict_0 = dict()
    file_downloader_0.report_progress(dict_0)


# Generated at 2022-06-26 11:10:35.636668
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-26 11:10:41.569795
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Setup
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    int_1 = 0
    int_0 = 0
    file_downloader_0.params = {
        'ratelimit': int_1,
    }
    int_0 = 0
    int_1 = 0
    file_downloader_0.report_progress({
        'speed': int_0,
        'downloaded_bytes': int_1,
    })
    int_0 = 0
    int_1 = 0
    file_downloader_0.report_progress({
        'speed': int_0,
        'total_bytes': int_1,
        'downloaded_bytes': int_1,
    })
    int_0 = 0
   

# Generated at 2022-06-26 11:10:50.667575
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_downloader_0.params = {'ratelimit': 5.8}
    file_downloader_0.params = {'nooverwrites': False}
    file_downloader_0.params = {'continuedl': False}
    file_downloader_0.params = {'nopart': False}
    file_downloader_0.params = {'retries': 5.6}
    file_downloader_0.params = {'sleep_interval': 4.3}
    file_downloader_0.params = {'max_sleep_interval': 5.0}
    file_downloader_0.params = {'verbose': False}
   

# Generated at 2022-06-26 11:10:59.131810
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # FIXME: This test is not valid for Python 3
    if sys.version_info.major == 3:
        return
    dir_0 = tempfile.mkdtemp('')
    f_0 = open(dir_0 + '/file_downloader.txt', 'wb')
    f_0.write('test')
    f_0.close()
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    assert len(dir_0 + '/file_downloader.txt') > 0
    file_downloader_0.report_file_already_downloaded(dir_0 + '/file_downloader.txt')
    os.rmdir(dir_0)


# Generated at 2022-06-26 11:11:04.908660
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = 'Zero'
    file_downloader_0 = FileDownloader(int_0, str_0)
    float_0 = 2.0
    int_1 = 1
    file_downloader_0.slow_down(float_0, int_1)


# Generated at 2022-06-26 11:11:11.992841
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    file_downloader_0.report_file_already_downloaded('/home/dimitris/.local/share/Trash/files/f.mp3')


# Generated at 2022-06-26 11:11:19.189303
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    flt_0 = 0.0
    file_downloader_0.slow_down(flt_0, flt_0, int_0)


# Generated at 2022-06-26 11:11:36.338715
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    str_0 = ''
    int_0 = file_downloader_0.try_utime(str_0, int_0)

    assert False # TODO: implement your test here


# Generated at 2022-06-26 11:11:44.571699
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """
    report_progress()
    """
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0);

    s = {}
    #s['status'] = 'finished'
    #s['downloaded_bytes'] = 0
    #s['speed'] = 0
    #file_downloader_0.report_progress(s);
    return

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:11:52.009701
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # create an instance
    file_downloader_0 = FileDownloader(None, None)
    # test method
    file_downloader_0.report_file_already_downloaded('C:\\Users\\Public\\Libraries\\example.mp4')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:12:05.078793
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    assert(file_downloader_0.try_utime('/home/benoit/ppa_tests/ppa-tests/ppa-tests/ppa_tests/', 'Thu, 04 Dec 2014 16:10:21 GMT') == 1417697421)
    assert(file_downloader_0.try_utime('/home/benoit/ppa_tests/ppa-tests/ppa-tests/ppa_tests/', 'Wed, 1 Jan 2014 16:10:21 GMT') == 1388586221)

# Generated at 2022-06-26 11:12:06.519176
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    assert False


# Generated at 2022-06-26 11:12:12.939054
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    # s = dict
    s = {}
    file_downloader_0.report_progress(s)


# Generated at 2022-06-26 11:12:20.453722
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    
    ## Instantiate object of class FileDownloader
    file_downloader_obj = FileDownloader(0, '')

    ## Dummy test
    assert file_downloader_obj is not None, "Constructor of class FileDownloader is incorrect"

if __name__ == '__main__':

    ## Perform unit tests
    test_FileDownloader_try_utime()
    print("====== All test cases passed successfully ======")

# Generated at 2022-06-26 11:12:25.165420
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = 0
    str_0 = 'a'
    file_downloader_0 = FileDownloader(int_0, str_0)

    file_downloader_0.slow_down(1.0, 2.0, 3.0)


# Generated at 2022-06-26 11:12:35.911155
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    elapsed_time = 0.0
    bytes = 0.0
    assert file_downloader_0.best_block_size(elapsed_time, bytes) == int(0)
    elapsed_time = 0.0
    bytes = 0.0
    assert file_downloader_0.best_block_size(elapsed_time, bytes) == int(0)


# Generated at 2022-06-26 11:12:44.678461
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert(True) == True
    int_0 = 0
    str_0 = ''
    file_downloader_0 = FileDownloader(int_0, str_0)
    filename = ''
    last_modified = ''
    filetime = 0
    assert(file_downloader_0.try_utime(filename, last_modified, filetime) == 0)
