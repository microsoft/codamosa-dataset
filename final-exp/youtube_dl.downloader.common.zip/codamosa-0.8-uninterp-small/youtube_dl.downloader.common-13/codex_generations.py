

# Generated at 2022-06-26 11:03:40.966551
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = []
    set_0 = set()
    file_downloader_0 = FileDownloader(list_0, set_0)
    params_0 = {}
    file_downloader_0.params = params_0
    start_time = 0
    now = -1174690368
    byte_counter = -1174690368
    file_downloader_0.slow_down(start_time, now, byte_counter)


# Generated at 2022-06-26 11:03:50.078981
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader([], set())
    try:
        file_downloader_0.try_utime(sys.argv[1], sys.argv[2])
    except IndexError:
        file_downloader_0.try_utime(sys.argv[1], None)


# Generated at 2022-06-26 11:04:02.778132
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    class FileDownloaderStub(FileDownloader):
        pass

    fd = FileDownloaderStub(None, None)
    file_name = "test.txt"

    try:
        os.remove(file_name)
    except OSError:
        pass

    open(file_name, 'a').close()
    fd.try_utime(file_name, None)
    fd.try_utime(file_name, "Invalid Value")
    fd.try_utime(file_name, "1365814867")
    os.remove(file_name)


if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:04:07.149393
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    list_0 = []
    set_0 = set()
    file_downloader_0 = FileDownloader(list_0, set_0)
    s_0 = {}
    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:04:17.119295
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    list_0 = []
    set_0 = set()
    file_downloader_0 = FileDownloader(list_0, set_0)

    # Test with the first argument equal to ''
    str_temp_name_0 = file_downloader_0.temp_name('')
    assert str_temp_name_0 == ''

    # Test with the second argument equal to '-'
    str_temp_name_1 = file_downloader_0.temp_name('-')
    assert str_temp_name_1 == '-'


# Generated at 2022-06-26 11:04:24.738431
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    list_0 = []
    set_0 = set()
    file_downloader_0 = FileDownloader(list_0, set_0)

    # Asserts
    assert file_downloader_0.calc_speed(0, 0, 0) == None
    assert file_downloader_0.calc_speed(1.2766144963532213, 1532170173.350029, 27517649) == 0.27845361075782767
    assert file_downloader_0.calc_speed(0, 0.001, 1048576) == 10485760.0


# Generated at 2022-06-26 11:04:27.487423
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    status_0 = FileDownloader_try_utime()
    print(status_0)


# Generated at 2022-06-26 11:04:32.093257
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    assert FileDownloader.format_eta_str(0) == '0s'
    assert FileDownloader.format_eta_str(1) == '1s'
    assert FileDownloader.format_eta_str(0.123) == '0s'
    assert FileDownloader.format_eta_str(1.123) == '1s'
    assert FileDownloader.format_eta_str(0.5) == '0s'


# Generated at 2022-06-26 11:04:37.928830
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    path = './test.txt'
    with open(path, 'w') as fd:
        fd.write('test')

    t = time.time()
    t_str = time.strftime(time_format, time.localtime(t))
    file_downloader = FileDownloader([], {})
    ret = file_downloader.try_utime(path, t_str)
    assert ret == t, 'test_FileDownloader_try_utime failed'

    ret = file_downloader.try_utime(path, 'wrong')
    assert ret is None, 'test_FileDownloader_try_utime failed'

    # TODO: error case


# Generated at 2022-06-26 11:04:51.508857
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    filename_0 = 'JbjCz9Xq3dQ'
    list_0 = []
    set_0 = set()
    file_downloader_0 = FileDownloader(list_0, set_0)

# Generated at 2022-06-26 11:05:02.639769
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    str_0 = './test.txt'
    float_0 = float('inf')
    float_1 = float('nan')
    float_2 = float('-inf')
    float_3 = float('-inf')
    float_4 = float('nan')
    float_5 = float('inf')
    float_6 = float('inf')
    float_7 = float('nan')
    float_8 = float('-inf')
    file_downloader_0 = FileDownloader(str_0, str_0)
    #print(file_downloader_0.format_seconds(float_0))
    #print(file_downloader_0.format_seconds(float_1))
    #print(file_downloader_0.format_seconds(float_2))
    #print(file_downloader_0.format_

# Generated at 2022-06-26 11:05:06.024835
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Initialization
    str_1 = './test.txt'
    str_2 = './test_2.txt'
    file_downloader_1 = FileDownloader(str_1, str_2)
    elapsed_time_0 = 1
    byte_counter_0 = 1
    # Call function
    result = file_downloader_1.best_block_size(elapsed_time_0, byte_counter_0)
    # Return to caller
    return result


# Generated at 2022-06-26 11:05:10.213282
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.slow_down(0, 0, 0)


# Generated at 2022-06-26 11:05:15.078364
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.download(None, None)

################################################################################


# Generated at 2022-06-26 11:05:24.904745
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)

    dict_0 = {'status': 'finished', 'total_bytes': 10}
    file_downloader_0.report_progress(dict_0)
    dict_0['status'] = 'downloading'
    dict_0['eta'] = 'eta'
    dict_0['total_bytes'] = 1
    dict_0['downloaded_bytes'] = 1
    dict_0['total_bytes_estimate'] = 1
    dict_0['speed'] = 1
    file_downloader_0.report_progress(dict_0)
    dict_0['status'] = 'finished'
    dict_0['total_bytes'] = 100

# Generated at 2022-06-26 11:05:35.274024
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-26 11:05:36.850936
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()


# Generated at 2022-06-26 11:05:44.701061
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # input
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)

    # Expected value
    expected_value = '100% of - at - ETA -'

    # test
    file_downloader_0.report_progress('finished')
    actual_value = getattr(file_downloader_0, '_last_line')

    # Assertion
    assert expected_value == actual_value, "Expected: " + str(expected_value) + ". Actual: " + str(actual_value)


# Generated at 2022-06-26 11:05:47.214507
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_case_0()
    test_FileDownloader_temp_name()


# Generated at 2022-06-26 11:05:53.632176
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start = 0
    current = 0
    bytes = 0
    file_downloader_0 = FileDownloader('qeHl_dIxvV8','qeHl_dIxvV8')

    # Testing: no return value
    assert file_downloader_0.calc_speed(start, current, bytes) == None



# Generated at 2022-06-26 11:06:07.271521
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    sec_0 = 0
    assert FileDownloader.format_seconds(sec_0) == '00:00:00'
    sec_1 = 60
    assert FileDownloader.format_seconds(sec_1) == '00:01:00'
    sec_2 = 3600
    assert FileDownloader.format_seconds(sec_2) == '01:00:00'
    sec_3 = 3600 * 24
    assert FileDownloader.format_seconds(sec_3) == '24:00:00'



# Generated at 2022-06-26 11:06:13.590052
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    with pytest.raises(NotImplementedError):
        file_downloader_0.download(str_0, str_0)


# Generated at 2022-06-26 11:06:24.749435
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader('http://www.youtube.com/watch?v=BaW_jenozKc', 'test.mp4')
    str_0 = file_downloader_0.temp_name('test.mp4')
    assert str_0 == 'test.mp4.part'

    file_downloader_1 = FileDownloader('http://www.youtube.com/watch?v=BaW_jenozKc', 'test.mp4')
    file_downloader_1.params['nopart'] = True
    str_1 = file_downloader_1.temp_name('test.mp4')
    assert str_1 == 'test.mp4'


# Generated at 2022-06-26 11:06:26.699099
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()


# Generated at 2022-06-26 11:06:43.082298
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-26 11:06:50.384996
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_filename = './test.txt'
    str_info_dict = './test.txt'
    fd_0 = FileDownloader(str_filename, str_info_dict)
    fd_0.download(str_filename, str_info_dict)


# Generated at 2022-06-26 11:06:58.999327
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from ytdl_format import YtdlFileDownloader

# Generated at 2022-06-26 11:07:06.159286
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_file_already_downloaded('test.txt')

if __name__ == '__main__':
    # test_FileDownloader_report_file_already_downloaded()
    print('Done')

# Generated at 2022-06-26 11:07:13.581659
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0) # *
    dict_0 = {} # *
    dict_0['status'] = 'finished'
    dict_0['elapsed'] = 0.0
    dict_0['downloaded_bytes'] = 0.0
    dict_0['total_bytes'] = 0.0
    dict_0['speed'] = 0.0
    dict_0['eta'] = 0.0
    dict_1 = dict_0 # *
    dict_1['status'] = 'error'
    dict_1['elapsed'] = 0.0
    dict_1['downloaded_bytes'] = 0.0
    dict_1['total_bytes'] = 0.0
    dict_1['speed'] = 0.0


# Generated at 2022-06-26 11:07:22.475402
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('8.0K') == 8192
    assert FileDownloader.parse_bytes('1.2M') == 1258291
    assert FileDownloader.parse_bytes('1.58Mi') == 1649537
    assert FileDownloader.parse_bytes('3.99G') == 4294967296
    assert FileDownloader.parse_bytes('0.99T') == 1099511627776
    assert FileDownloader.parse_bytes('1.0P') == 1125899906842624


# Generated at 2022-06-26 11:07:34.701506
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.report_file_already_downloaded(str_0) == True
    
    

# Generated at 2022-06-26 11:07:40.213006
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test data:
    filename = './test.txt'
    last_modified_hdr = '10/10/2018'
    # Test:
    file_downloader_0 = FileDownloader(filename, filename)
    file_downloader_0.try_utime(filename, last_modified_hdr)
    pass

if __name__ == "__main__":
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:07:41.811153
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()


# Generated at 2022-06-26 11:07:50.582284
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    test_cases = [
        (
            0,
        ),
        (
            float('inf'),
        ),
        (
            None,
        ),
        (
            -1,
        ),
        (
            'hello world',
        ),
        (
            1,
        ),
        (
            1.9,
        ),
    ]

    for test_case in test_cases:
        if test_case is None:
            continue
        r = FileDownloader.format_retries(test_case[0])


# Generated at 2022-06-26 11:08:01.499471
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    dict_1 = {}
    dict_1['_speed_str'] = 'Unknown speed'
    dict_1['_eta_str'] = 'Unknown ETA'
    dict_1['status'] = 'finished'
    dict_1['elapsed'] = int_0 = 0
    dict_1['total_bytes'] = int_0
    file_downloader_0.report_progress(dict_1)


# Generated at 2022-06-26 11:08:06.648412
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    file_downloader = FileDownloader('1', '2')
    assert not file_downloader.slow_down(0, 0, 0)


# Generated at 2022-06-26 11:08:22.188554
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # test 1: sleep time is zero
    # inputs
    start_time_0 = 0
    now_0 = 2
    byte_counter_0 = 2
    params_0 = {'ratelimit': 100}

    time.sleep = mock_sleep()
    time.time = mock_time(start_time_0, now_0 + 1)
    file_downloader_0 = FileDownloader('', params_0)
    file_downloader_0.slow_down(start_time_0, now_0, byte_counter_0)
    assert time.sleep.times_called == 0 

    # test 2: sleep time is greater than zero
    # inputs
    start_time_1 = 0
    now_1 = 2
    byte_counter_1 = 2
    params_1 = {'ratelimit': 1}

   

# Generated at 2022-06-26 11:08:25.331145
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()

# Test FileDownloader
test_FileDownloader_download()

# Generated at 2022-06-26 11:08:34.398954
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    FileDownloader_download_str1_str1 = './test.txt'
    FileDownloader_download_str1_str1 = './test.txt'
    FileDownloader_download_file_downloader_1 = FileDownloader(FileDownloader_download_str1_str1, FileDownloader_download_str1_str1)
    FileDownloader_download_retval = FileDownloader_download_file_downloader_1.download(FileDownloader_download_str1_str1, FileDownloader_download_str1_str1)


# Generated at 2022-06-26 11:08:45.183556
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Get the class FileDownloader
    class_FileDownloader = get_class_from_module(
        "youtube_dl.downloader.common.FileDownloader",
        "youtube_dl.downloader.common",
        "FileDownloader")
    # Get the test cases
    test_cases = get_args_from_signature(class_FileDownloader.undo_temp_name, [str])

    # Add the test case
    test_case_0()
    test_cases.append(test_case_0)
    # Run tests
    run_tests(class_FileDownloader.undo_temp_name, test_cases,
              list_of_arguments=True)


# Generated at 2022-06-26 11:09:16.267730
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    file_downloader_0 = FileDownloader('', '')
    # Assert:
    assert file_downloader_0.undo_temp_name('test.txt') == 'test.txt'
    assert file_downloader_0.undo_temp_name('test.txt.part') == 'test.txt'
    assert file_downloader_0.undo_temp_name('test.txt.part.part') != 'test.txt.part'


# Generated at 2022-06-26 11:09:27.912200
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = './test.txt'
    file_downloader_0.params = {
        'nopart': False,
    }
    str_2 = file_downloader_0.temp_name(str_1)
    assert(str_2 == str_1 + '.part')

    file_downloader_1 = FileDownloader(str_0, str_0)
    str_3 = './test.txt'
    file_downloader_1.params = {
        'nopart': True,
    }
    str_4 = file_downloader_1.temp_name(str_3)
    assert(str_4 == str_3)

    file_download

# Generated at 2022-06-26 11:09:36.666780
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    test_labels = {}
    test_labels["status"] = "finished"
    test_labels["total_bytes"] = 7
    test_labels["elapsed"] = 1
    file_downloader_0.report_progress(test_labels)

test_FileDownloader_report_progress()

test_case_0()

# Generated at 2022-06-26 11:09:44.696206
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = 'abc'
    ret_val_0 = file_downloader_0.try_utime(str_0, str_1)

test_case_0()
test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:09:48.219136
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = './test.txt'
    dict_0 = {'status': 'Downloading'}
    file_downloader_0 = FileDownloader(str_0, str_0)
    #assert file_downloader_0.download(str_0, dict_0) == True


# Generated at 2022-06-26 11:09:59.221096
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_1 = './test.txt'
    file_downloader_1 = FileDownloader(str_1, str_1)

    file_downloader_0 = FileDownloader('', '')
    str_0 = 'Tue, 09 Aug 2016 23:50:46 GMT'
    float_0 = float(0)
    float_1 = float(0)

    float_1 = file_downloader_0.try_utime(str_1, str_0)

    assert file_downloader_0.try_utime(str_1, str_0) == float_1
    assert float_1 == float_0


# Generated at 2022-06-26 11:10:11.863275
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = 'abc'
    str_2 = 'abc'
    dict_0 = dict(eta='a', downloaded_bytes='a')
    dict_1 = dict(eta='a', downloaded_bytes='a')
    dict_2 = dict(eta='a', downloaded_bytes='a')
    dict_3 = dict(eta='a', downloaded_bytes='a')
    dict_4 = dict(eta='a', downloaded_bytes='a')
    dict_5 = dict(eta='a', downloaded_bytes='a')
    dict_6 = dict(eta='a', downloaded_bytes='a')
    dict_7 = dict(eta='a', downloaded_bytes='a')
    dict_8

# Generated at 2022-06-26 11:10:14.626836
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    assert FileDownloader.calc_speed(0, 0, 0) == None


# Generated at 2022-06-26 11:10:20.664425
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # file_downloader_0 = FileDownloader(str_0, str_0)
    str_0 = False
    str_1 = '-nopart'
    int_0 = file_downloader_0.temp_name(str_1)
    print(int_0)


# Generated at 2022-06-26 11:10:31.275440
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader('test.txt', 'test.txt')
    assert file_downloader_0.temp_name('test.txt') == 'test.txt.part'
    assert file_downloader_0.temp_name('out.txt') == 'out.txt.part'
    assert file_downloader_0.temp_name('out') == 'out'


# Generated at 2022-06-26 11:10:44.327192
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    try_utime_0 = FileDownloader(str_0, str_0)
    try_utime_1 = None
    try_utime_2 = '/home/hugo/test.txt'
    try_utime_0.try_utime(try_utime_2, try_utime_1)


# Generated at 2022-06-26 11:10:50.520656
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = 'Unknown %'
    str_2 = 'Unknown speed'
    str_3 = 'Unknown ETA'
    file_downloader_0.report_progress({'speed': None, 'downloaded_bytes': None, 'eta': None, 'status': 'downloading', 'percent': None, '_speed_str': str_2, '_eta_str': str_3, '_percent_str': str_1})

test_case_0()
test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:10:57.129754
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    str_0 = './test.txt'
    str_1 = './test.txt.part'
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.temp_name(str_0) == str_1
    file_downloader_1 = FileDownloader(None, None)
    assert file_downloader_1.temp_name(str_0) == str_0
    str_2 = '-'
    assert file_downloader_0.temp_name(str_1) == str_1


# Generated at 2022-06-26 11:11:00.163448
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    # Attempt to set the last-modified time of the file
    file_downloader_0.try_utime('./test.txt', None)


# Generated at 2022-06-26 11:11:02.201107
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_progress({'status': 'finished'})

# Generated at 2022-06-26 11:11:12.984014
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    FileDownloader.report_progress(
        {'elapsed': 1.25, 'total_bytes_estimate': 1.25, 'status': 'finished', '_total_bytes_estimate_str': '1.25', 'downloaded_bytes': 2.5, '_downloaded_bytes_str': '2.5', 'total_bytes': 2.5, 'total_time': 2.5, '_elapsed_str': '1.25', 'eta': 0.0, '_eta_str': '0:00', '_percent_str': '100%', 'speed': 2.0, '_speed_str': '2.00B/s'})



# Generated at 2022-06-26 11:11:20.750454
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    # Test executing function FileDownloader.report_file_already_downloaded
    # with filename equals null
    try:
        file_downloader_0.report_file_already_downloaded(None)
    except:
        pass


# Generated at 2022-06-26 11:11:23.835330
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert(file_downloader_0.slow_down(0, 0, 8) == None)


# Generated at 2022-06-26 11:11:32.287136
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    float_0 = 1.0
    float_1 = 2.0
    file_downloader_0.slow_down(float_0, float_1, int_0)
    print('Unit test for method slow_down of class FileDownloader')
    print('\n>>> Done')


# Generated at 2022-06-26 11:11:36.054319
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_1 = FileDownloader(str_0, str_0)
    file_downloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:11:58.127032
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-26 11:12:07.224222
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    print('Testing function format_retries')
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_0 = file_downloader_0.format_retries(0)
    print('str_0: ' + str_0)
    str_0 = file_downloader_0.format_retries(1)
    print('str_0: ' + str_0)
    str_0 = file_downloader_0.format_retries(2)
    print('str_0: ' + str_0)
    str_0 = file_downloader_0.format_retries(3)
    print('str_0: ' + str_0)


test_case_0()
test_FileDownloader_format_retries()

# Generated at 2022-06-26 11:12:17.754563
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    str_0 = '100'
    str_1 = '100k'
    str_2 = '100M'
    str_3 = '100G'
    str_4 = '100T'
    str_5 = '100P'
    str_6 = '100E'
    str_7 = '100Z'
    str_8 = '100Y'
    str_9 = '100.25k'
    str_10 = '100.25.0M'
    str_11 = '0.25k'
    str_12 = '0.25M'
    str_13 = '0.0k'
    str_14 = '0.0M'
    str_15 = '100x'
    str_16 = '100kx'
    str_17 = '100.25kx'
    str

# Generated at 2022-06-26 11:12:23.219708
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_file_already_downloaded(str_0)


# Generated at 2022-06-26 11:12:29.796234
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    # FileDownloader(str, str)
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)

    # calc_speed(int, int, int)
    import time
    int_0 = int(time.time())
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_0 * int_0 * int_0
    int_0 = int_

# Generated at 2022-06-26 11:12:39.721358
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    params = {
        'verbose': False,
        'quiet': False,
        'noprogress': False,
    }
    ydl = YoutubeDL(params)
    str_0 = './test.txt'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.ydl = ydl
    s = {
        'status': 'finished',
        'total_bytes': None,
    }
    file_downloader_0.report_progress(s)
    file_downloader_0.params = {
        'verbose': True,
        'quiet': False,
        'noprogress': True,
    }
    file_downloader_0.report_progress(s)

# Generated at 2022-06-26 11:12:41.154992
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()
