

# Generated at 2022-06-26 11:03:21.208915
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    test_case_0()
    list_1 = []
    str_1 = 'OvPmg,z'
    int_0 = 3
    file_downloader_1 = FileDownloader(list_1, str_1)
    file_downloader_1.slow_down(0.0, 0.0, int_0)


# Generated at 2022-06-26 11:03:28.845709
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    list_0 = []
    str_0 = '+4bQ6U\n6Pl(3'
    file_downloader_0 = FileDownloader(list_0, str_0)
    list_1 = []
    str_1 = 'oKv)x0'
    file_downloader_1 = FileDownloader(list_1, str_1)
    assert file_downloader_1.parse_bytes(str_1) == file_downloader_0.parse_bytes(str_0)


# Generated at 2022-06-26 11:03:36.385682
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print('Testing test_FileDownloader_report_progress')
    # Test case 0
    list_0 = []
    str_0 = 'cmG4G\nvi=Gyq,rj4Pz'
    file_downloader_0 = FileDownloader(list_0, str_0)
    dict_0 = {}
    # 1)
    dict_0['status'] = 'downloading'
    # 2)
    dict_0['total_bytes'] = 0
    # 3)
    dict_0['downloaded_bytes'] = 0
    file_downloader_0.report_progress(dict_0)
    # 4)
    bool_0 = bool()
    bool_0 = bool()
    bool_0 = bool_0
    if bool_0:
        bool_0 = bool()
    bool_0

# Generated at 2022-06-26 11:03:47.390976
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    list_0 = []
    str_0 = "r2r/t!H3Z2\nZ\"jmTmTfT$(YyXX\nk/"
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_0 = "zv,xW"

# Generated at 2022-06-26 11:03:53.290582
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    list_0 = ['U3Ci3A5.O']
    str_0 = 'F(#_c%!bM'
    file_downloader_0 = FileDownloader(list_0, str_0)
    float_0 = 4.242801229599292
    str_1 = 'wb'
    int_0 = test_case_0.download(list_0, float_0, str_1)


# Generated at 2022-06-26 11:03:54.575114
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    test_case_0()


# Generated at 2022-06-26 11:04:02.362191
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    list_0 = []
    str_0 = 'u4\x1a2w4'
    file_downloader_0 = FileDownloader(list_0, str_0)
    str_1 = 'wL0Z'
    filename_1 = file_downloader_0.temp_name(str_1)
    assert filename_1 == str_1


# Generated at 2022-06-26 11:04:15.958091
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader_0 = FileDownloader([], 'nZ/\nNf*&t|')
    assert file_downloader_0.parse_bytes('1.0MB') == 1048576
    assert file_downloader_0.parse_bytes('1.5MB') == 1572864
    assert file_downloader_0.parse_bytes('0b') == 0
    assert file_downloader_0.parse_bytes('1KB') == 1024
    assert file_downloader_0.parse_bytes('1.2K') == 1228
    assert file_downloader_0.parse_bytes('1.1m') == 1153433
    assert file_downloader_0.parse_bytes('1.1G') == 11805916207173

# Test for method format_eta of class FileDownloader

# Generated at 2022-06-26 11:04:24.388228
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1234') == 1234
    assert FileDownloader.parse_bytes('1234k') == 1234000
    assert FileDownloader.parse_bytes('1234M') == 1234000000
    assert FileDownloader.parse_bytes('1234G') == 1234000000000
    assert FileDownloader.parse_bytes('1234T') == 1234000000000000
    assert FileDownloader.parse_bytes('1234P') == 1234000000000000000
    assert FileDownloader.parse_bytes('1234E') == 1234000000000000000000
    assert FileDownloader.parse_bytes('1234Z') == 1234000000000000000000000
    assert FileDownloader.parse_bytes('1234Y') == 1234000000000000000000000000

    assert FileDownloader.parse_bytes('1.2k') == 1200

# Generated at 2022-06-26 11:04:31.850253
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    list_1 = []
    str_1 = '7b;C,{'
    file_downloader_1 = FileDownloader(list_1, str_1)
    str_2 = 'qG3,:z0X5A5?5g5%5;5=5+5,5\5&5*5"5\'5|5!5)5556545352515/505?5.5p5:5|5`5-5'
    file_downloader_1.report_file_already_downloaded(str_2)


# Generated at 2022-06-26 11:04:52.271617
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'\xd4\x16\xcb\x08\xc7\x97~\xdc\x0b\x9a\x12\xc6\x91'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    start_time = 0.155967374377
    now = 0.365430049979
    byte_counter = 0.321787688591
    file_downloader_0.slow_down(start_time, now, byte_counter)


# Generated at 2022-06-26 11:04:58.772982
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    error_count = 0
    for i in xrange(1):
        try:
            test_case_0()
        except:
            error_count += 1
    assert error_count == 0

if __name__ == '__main__':
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:05:11.932180
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    if not os.path.isdir('test_dir'):
        os.mkdir('test_dir')
    fd = open(os.path.join('test_dir', 'test_file'), 'w')
    fd.write('Some file contents.')
    fd.close()
    info_dict = {
        'id': 'video id',
        'ext': 'mp3',
    }
    file_downloader = FileDownloader({'noprogress': True}, {'sleep_interval': 2})
    file_downloader.to_screen = lambda x: None
    assert file_downloader.download('test_dir/test_file', info_dict)
    assert os.path.isfile(os.path.join('test_dir', 'test_file'))
    file_downloader = FileDownloader

# Generated at 2022-06-26 11:05:24.000257
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'q\xeb\x8b\x9c\xbf\xd7\x04d\x02\x94\xfa\x80\x8c%0\xa9\x9d\x06\x8c\xbc\x89\xbc\xaf\xa8\x02Q\x18A'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    bytes_0 = b'\x06\xba\x1a\xf9\x9f\xb9Y\xa2\x8f\x91\x85\xbe\x84\xa8\x99g\x05\x82\xac\xb8\xa5\xaa\x07'
    file_downloader_0.params = bytes_0
   

# Generated at 2022-06-26 11:05:25.602120
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    pass # TODO


# Generated at 2022-06-26 11:05:35.522983
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(0.0, 0.0) == 0
    assert FileDownloader.best_block_size(0.0, 1.0) == 1
    assert FileDownloader.best_block_size(0.0, 2.0) == 2
    assert FileDownloader.best_block_size(0.0, 3.0) == 2
    assert FileDownloader.best_block_size(0.5, 0.5) == 1
    assert FileDownloader.best_block_size(0.5, 1.5) == 3
    assert FileDownloader.best_block_size(0.5, 2.5) == 5
    assert FileDownloader.best_block_size(0.5, 3.5) == 4

# Generated at 2022-06-26 11:05:44.913834
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ytdl_0 = YoutubeDL({'download_archive': ['https://www.youtube.com/watch?v=x'], 'format': 'best', 'quiet': True, 'simulate': True, 'writethumbnail': True})
    file_downloader_0 = FileDownloader(ytdl_0)
    file_downloader_0._report_progress_prev_line_length = None
    s = {'elapsed': 0.0, 'speed': 0.0, 'total_bytes_estimate': None, 'total_bytes': None, 'downloaded_bytes': None, 'status': 'downloading', 'filename': 'x'}
    file_downloader_0.report_progress(s)


# Generated at 2022-06-26 11:05:52.067040
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():

    # Test when the value of string is invalid
    with pytest.raises(ValueError):
        FileDownloader.parse_bytes("5TB")

    # Test when the value of string is valid
    value = FileDownloader.parse_bytes("5gB")
    assert value == 5368709120


# Generated at 2022-06-26 11:05:57.445696
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_1 = FileDownloader('O1i\xf7', 'O1i\xf7')
    assert file_downloader_1.report_progress(file_downloader_1) == None



# Generated at 2022-06-26 11:06:02.682320
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bytes_0 = b"$\xdf\xf8+\xea\xfa\x1b"
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    bytes_0 = b"`\xb1\x05)\x0fi\x9f\xd0"
    dic = dict()
    dic["status"] = "downloading"
    dic["speed"] = 1129
    dic["downloaded_bytes"] = 84
    dic["eta"] = 6.5463969e-06
    dic["total_bytes"] = 185
    dic["total_bytes_estimate"] = None
    dic["elapsed"] = None
    file_downloader_0.report_progress(dic)




# Generated at 2022-06-26 11:06:18.041885
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_2 = FileDownloader(
        b'\x03\xfaV\xe6\x89nT\xa6\x10\x8c\xb2\xb2\xf6\x90\xabj<\xe1\x9f\xcd\xcc\xae\x1a',
        b'\xb7\x8a\xa4\xfd\x98\xe7\x1e\xaf\x1b\xae\xda\x85\x0a!\x9bF&\x8cW\xb3\xe3\x04'
    )

# Generated at 2022-06-26 11:06:20.843602
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader('', {})
    assert file_downloader_0.temp_name('') is not None


# Generated at 2022-06-26 11:06:29.516975
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    temp_name_0 = FileDownloader.temp_name('5.xmp.bz2')
    temp_name_1 = FileDownloader.temp_name('5.xmp.bz2')
    assert temp_name_1 != temp_name_0
    temp_name_2 = FileDownloader.temp_name('5.xmp.bz2')
    assert temp_name_2 == temp_name_1


# Generated at 2022-06-26 11:06:37.915379
# Unit test for method undo_temp_name of class FileDownloader

# Generated at 2022-06-26 11:06:46.752559
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-26 11:06:50.590420
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    bytes_range_0 = range(0, 3)
    for i in bytes_range_0:
        assert True
        test_case_0()

if __name__ == '__main__':
    test_FileDownloader_try_utime()

# Generated at 2022-06-26 11:06:53.199457
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    filename = ''
    last_modified_hdr = ''
    return_value = FileDownloader.try_utime(filename, last_modified_hdr)
    print(return_value)


# Generated at 2022-06-26 11:06:59.875609
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    filename = 'main.py'
    downloader = FileDownloader(None, None)

    # Invalid file name
    assert downloader.try_utime(None, None) is None

    # Empty file name
    assert downloader.try_utime('', None) is None
    assert downloader.try_utime('   ', None) is None

    # File does not exist
    assert downloader.try_utime(filename, None) is None

    # Time stamp is None
    assert downloader.try_utime(filename, None) is None

    # Time stamp is too old
    assert downloader.try_utime(filename, 'Thu Jan  1 00:00:00 1970') is None

    # Time stamp is valid

# Generated at 2022-06-26 11:07:07.205759
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Define a few input arguments to pass to slow_down
    start_time_0 = time.time()
    now_0 = time.time()
    byte_counter_0 = random.randint(50, 100)
    file_downloader_0 = FileDownloader(b'a', b'b')
    file_downloader_0.slow_down(start_time_0, now_0, byte_counter_0)


# Generated at 2022-06-26 11:07:14.074760
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    s_0 = {'status': '100%'}
    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:07:34.849361
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    
    assert file_downloader_0.slow_down(0.0, 0.0, 0) == None


# Generated at 2022-06-26 11:07:42.792706
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    bytes_0 = b'\xce\xde\x01\x0f\xb7\x10\xc8\x86'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)

    # Test with arguments:
    #   filename='\x1e\xdc\x8a\xda\x82\xd6\xda\x8a\xc2\xfb\x9d\x82\x8c'
    result = file_downloader_0.temp_name('\x1e\xdc\x8a\xda\x82\xd6\xda\x8a\xc2\xfb\x9d\x82\x8c')
    assert result is not None
    assert isinstance(result, str)

    # Test with arguments:
    #

# Generated at 2022-06-26 11:07:49.363817
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    # block_size = file_downloader_0.best_block_size(float_0, int_0)
    # assert_equals(block_size, int_0)


# Generated at 2022-06-26 11:07:54.500142
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader(b'', b'')
    file_downloader_0.download(b'', b'')


# Generated at 2022-06-26 11:08:04.577807
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Tests the case where FileDownloader.undo_temp_name() is called with a
    # non-string argument (list object list_0)
    list_0 = ['sT\x98\x0c', 'F\x87\x16\xf4', '\xdf\n\xbc']
    file_downloader_0 = FileDownloader(list_0, list_0)
    file_downloader_0.undo_temp_name(list_0)

    # Tests the case where FileDownloader.undo_temp_name() is called with a
    # string argument (string object str_0) containing the character '\x7f'
    str_0 = '\x7f\xe6\x8e\x0c'
    file_downloader_0.undo_temp_name(str_0)

   

# Generated at 2022-06-26 11:08:10.651076
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.report_destination('tmp')
    # @TODO: Add tests for method download of class FileDownloader


# Generated at 2022-06-26 11:08:24.196317
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    # Test with good arguments
    assert file_downloader_0.parse_bytes('1') == 1
    assert file_downloader_0.parse_bytes('1B') == 1
    assert file_downloader_0.parse_bytes('1.5B') == 1.5
    assert file_downloader_0.parse_bytes('1.0B') == 1
    assert file_downloader_0.parse_bytes('1.5k') == 1536
    assert file_downloader_0.parse_bytes('1.5m') == 1572864
    assert file_downloader_0.parse_bytes('1.5g') == 1610612736
    assert file_downloader

# Generated at 2022-06-26 11:08:35.870075
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bytes_0 = b'%\xad'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)

    bytes_1 = b'\xbfe9\xd3'
    bytes_2 = b'\xe7\xda\xab\xbb\xe2\xde\xa9\x14\x06\x19\xee\xf0\xc5\x92'
    bytes_3 = b'\xe2\xe1\x88\x02\x97\x80\xef\x9a\x0c\xbd\xdb\x8d\xdd\xa0\xec'
    bytes_4 = b'\xc4\x7f\x03\xe8\xd4\xbc\xa7\xb4\x01'
    bytes_5

# Generated at 2022-06-26 11:08:43.055966
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'#\x1b'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.slow_down(3.0, 5.0, 4.0)
    assert file_downloader_0.file_downloader_slow_down_time is None


# Generated at 2022-06-26 11:08:45.798199
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Insert your test code here
    assert(True)


# Generated at 2022-06-26 11:09:03.749241
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    bytes_0 = b''
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.report_progress(0)


# Generated at 2022-06-26 11:09:16.036853
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-26 11:09:27.225592
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Test with invalid parameters
    if FileDownloader.parse_bytes('K') is not None:
        return 'Failed'
    if FileDownloader.parse_bytes('2.5K') != 2560:
        return 'Failed'
    if FileDownloader.parse_bytes('2.5M') != 2621440:
        return 'Failed'
    if FileDownloader.parse_bytes('2.5G') != 274877906944:
        return 'Failed'

    # force use and coverage of fallback param
    if FileDownloader.parse_bytes('2.5K', fallback=None) is not None:
        return 'Failed'
    return 'Success'


# Generated at 2022-06-26 11:09:36.244417
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    temp_0 = FileDownloader.temp_name(b'\xd1\xad')
    temp_1 = FileDownloader.undo_temp_name(temp_0)
    if temp_0 != temp_1:
        raise Exception(b"AssertionError: 'temp_0 != temp_1'")

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_undo_temp_name()

# Generated at 2022-06-26 11:09:48.694385
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)

# Generated at 2022-06-26 11:09:57.724959
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Arrange
    s_0 = [{}]

    # Act
    fd = FileDownloader
    fd._report_progress_status = MagicMock()
    fd.report_progress(s_0)

    # Assert
    assert fd._report_progress_status.called_with(
        '100%',
        is_last_line=True
    )


# Generated at 2022-06-26 11:10:07.411398
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    file_downloader_0 = FileDownloader({'external_downloader_args': [b'youtube-dl'], 'noprogress': True, 'quiet': True}, {'external_downloader_args': [b'youtube-dl'], 'noprogress': True, 'quiet': True})
    s_0 = {'status': 'finished'}
    file_downloader_0.report_progress(s_0)


# Generated at 2022-06-26 11:10:15.759108
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test with 0:
    str_0 = "o.d"
    file_downloader_0 = FileDownloader(str_0, str_0)
    result = file_downloader_0._FileDownloader__undo_temp_name(str_0)
    assert result == "o.d"
# Test with 1:
    str_0 = ".d"
    file_downloader_0 = FileDownloader(str_0, str_0)
    result = file_downloader_0._FileDownloader__undo_temp_name(str_0)
    assert result == ".d"
# Test with 2:
    str_0 = "d"
    file_downloader_0 = FileDownloader(str_0, str_0)

# Generated at 2022-06-26 11:10:18.738414
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes("1.1K") == 1126
    assert FileDownloader.parse_bytes("20M") == 20971520

if __name__ == "__main__":
    test_case_0()
    test_FileDownloader_parse_bytes()

# Generated at 2022-06-26 11:10:22.205764
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    filename = 'test.txt'
    file = open(filename, 'w')
    file.close()
    fd = FileDownloader({}, {})
    fd.try_utime(filename, '2019-04-01T16:34:58.000Z')
    utime = os.path.getmtime(filename)
    os.remove(filename)
    assert utime == 1554137298


# Generated at 2022-06-26 11:10:34.554717
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'O1i\xf7'
    ctime_0 = time.ctime()
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.slow_down(ctime_0, ctime_0, 0)


# Generated at 2022-06-26 11:10:45.594180
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    bytes_0 = b'\xf4\xc6\xae\x1e\xe3\xab!\x97\xaa\xe8\x7f\xdc\xb5\x89\x8d\x08'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    str_0 = file_downloader_0.temp_name(bytes_0)
    assert re.search(r'^\d{1,}[.]\d{1,}$', str_0) != None


# Generated at 2022-06-26 11:10:59.147235
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('2M') == 2 * 1024 * 1024
    assert FileDownloader.parse_bytes('2K') == 2 * 1024
    assert FileDownloader.parse_bytes('2G') == 2 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('2P') == 2 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('2T') == 2 * 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('2E') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('2Z') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('2Y') == 2 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-26 11:11:01.499862
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    #file_downloader_0.test()

test_case_0()

# Generated at 2022-06-26 11:11:06.925384
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    bytes_0 = b'zP'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    integer_0 = 4
    value_of_my_var = file_downloader_0.format_retries(integer_0)
    assert (value_of_my_var == '4')


# Generated at 2022-06-26 11:11:15.894793
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import datetime

# Generated at 2022-06-26 11:11:20.266868
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    file_downloader_0 = FileDownloader(b'O1i\xf7', b'O1i\xf7')
    assert file_downloader_0.best_block_size(0.0, 0) == 0


# Generated at 2022-06-26 11:11:27.219171
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from datetime import timedelta
    start_time_0 = time.strptime('Sun Jun 18 12:41:21 2017', '%a %b %d %H:%M:%S %Y')
    now_0 = time.strptime('Tue Nov 14 14:20:15 2017', '%a %b %d %H:%M:%S %Y')
    byte_counter_0 = timedelta(seconds=5, microseconds=847114)
    ret_1 = FileDownloader.slow_down(start_time_0, now_0, byte_counter_0)


# Generated at 2022-06-26 11:11:34.468429
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    filename_0 = file_downloader_0.download(filename_0, info_dict_0)

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_download()

# Generated at 2022-06-26 11:11:40.528955
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.slow_down(13.68510887667537, 8.0, 499)


# Generated at 2022-06-26 11:11:54.910070
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    p_0 = 'x_'
    p_1 = file_downloader_0.undo_temp_name(p_0)
    assert p_1 == 'x_'


# Generated at 2022-06-26 11:11:59.770468
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader()
    str_0 = '07/08/1949'
    file_downloader_0.try_utime('h8n&b)N', str_0)



# Generated at 2022-06-26 11:12:05.587914
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'\x1f\xe4\xb3\xaa\xc2\x9a\x0b'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)

    start_time = 0.0
    now = 0.0
    byte_counter = 0
    file_downloader_0.slow_down(start_time, now, byte_counter)


# Generated at 2022-06-26 11:12:15.067125
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader(None, 'http://www.youtube.com/watch?v=IrYQA5X9fWs')
    file_downloader_0.temp_name('IrYQA5X9fWs')
    file_downloader_0.temp_name('IrYQA5X9fWs')
    file_downloader_0.temp_name('IrYQA5X9fWs')
    file_downloader_0.temp_name('IrYQA5X9fWs')


# Generated at 2022-06-26 11:12:27.196184
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    urlopen_side_effect = [
        {'status': 'downloading', 'total_bytes': None, 'speed': 50, 'downloaded_bytes': 100},
        {'status': 'finished'},
    ]
    bytes_0 = b'O1i\xf7'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)
    file_downloader_0.params['ratelimit'] = 100
    ret_val_0 = file_downloader_0.slow_down(100, 200, 100)
    ret_val_1 = file_downloader_0.slow_down(100, 200, 50)
    ret_val_2 = file_downloader_0.slow_down(100, 200, 100)


# Generated at 2022-06-26 11:12:30.573284
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    time_float = time.time()  # This call is undeterministic
    time_str = time.ctime(time_float)


# Generated at 2022-06-26 11:12:35.585226
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    bytes_0 = b'%p\x92\x17\x02\xa3\xec\xd3\x0c'
    file_downloader_0 = FileDownloader(bytes_0, bytes_0)


# Generated at 2022-06-26 11:12:44.369611
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    file_name = b'\xce' * 4
    fd = FileDownloader(file_name, bytes())
    fd.report_file_already_downloaded(file_name.decode())

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_report_file_already_downloaded()