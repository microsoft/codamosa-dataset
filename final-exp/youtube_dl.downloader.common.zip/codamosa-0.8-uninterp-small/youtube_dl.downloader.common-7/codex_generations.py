

# Generated at 2022-06-26 11:03:31.110219
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    float_0 = float(0) 
    float_1 = float(0) 
    float_2 = float(0) 
    assert file_downloader_0.best_block_size(float_0, float_1, float_2) == 0


# Generated at 2022-06-26 11:03:33.341770
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    assert(0)


# Generated at 2022-06-26 11:03:43.433962
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    tmp_argv = sys.argv
    sys.argv = ['youtube-dl']
    try:
        str_0 = 'qh@3'
        file_downloader_0 = FileDownloader(str_0, str_0)
        str_0 = 'M0p@ng'
        str_1 = '123'
        bool_0 = file_downloader_0.download(str_0, str_1)
        return bool_0
    finally:
        sys.argv = tmp_argv


# Generated at 2022-06-26 11:03:49.335930
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print("Test for method report_progress of class FileDownloader")
    # Test for case 0
    print("[+] Test for case 0")
    test_case_0()

if __name__ == "__main__":
    test_FileDownloader_report_progress()

# Generated at 2022-06-26 11:03:53.405045
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    arg_0 = 20
    arg_1 = 9
    file_downloader_0 = FileDownloader()
    return_value_0 = file_downloader_0.best_block_size(arg_0, arg_1)
    assert return_value_0 == 10


# Generated at 2022-06-26 11:03:58.864602
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    start = time.time()
    time.sleep(1)
    result = FileDownloader.calc_eta(start, time.time(), 1)
    assert(result == 0)


# Generated at 2022-06-26 11:04:01.059189
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:04:05.508461
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_1 = 'G}#I'
    int_0 = 1
    file_downloader_1 = FileDownloader(str_1, str_1)
    file_downloader_1.report_file_already_downloaded(int_0)


# Generated at 2022-06-26 11:04:19.498151
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = '4@$&'
    str_1 = 'd8=v'
    int_0 = random.randint(1, 1000)
    str_2 = 'Nqg6'
    int_1 = random.randint(0, 1000)
    int_2 = random.randint(0, 1000)
    int_3 = random.randint(0, 1000)
    int_4 = random.randint(0, 1000)
    str_3 = 'C1S@'
    str_4 = 'Lgdj'
    str_5 = 'Mr&^{'
    int_5 = random.randint(0, 1000)
    str_6 = '@!3J'
    int_6 = random.randint(0, 1000)

# Generated at 2022-06-26 11:04:23.777752
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    str_0 = 'f'
    file_downloader_0 = FileDownloader(str_0, str_0)
    num_0 = 5.0
    num_1 = 5.0
    num_2 = 5.0
    assert_equals(file_downloader_0.calc_eta(num_0, num_1, num_2), None)


# Generated at 2022-06-26 11:04:53.507787
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = 'nD.|'
    try:
        file_downloader_0 = FileDownloader(str_0, str_0)
    except Exception as failed_download_0:
        file_downloader_0 = FileDownloader(str_0, str_0)
    str_2 = 'm;#s'
    str_4 = '4'
    str_6 = 'v:l'
    str_1 = '?'
    video = file_downloader_0.download(str_1, {str_0: int(str_2), str_4: str_6})
    assert not video
    assert str_0 == file_downloader_0._FileDownloader__ydl._ydl_opts['default_search']
    assert str_1 == file_downloader_0._FileDownloader__yd

# Generated at 2022-06-26 11:05:03.167241
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    file_downloader_0 = FileDownloader('', '')
    assert file_downloader_0.parse_bytes('10k') == 10240
    assert file_downloader_0.parse_bytes('10K') == 10240
    assert file_downloader_0.parse_bytes('10m') == 10485760
    assert file_downloader_0.parse_bytes('10M') == 10485760
    assert file_downloader_0.parse_bytes('10g') == 10737418240
    assert file_downloader_0.parse_bytes('10G') == 10737418240
    assert file_downloader_0.parse_bytes('10') == 10
    assert file_downloader_0.parse_bytes('1') == 1


# Generated at 2022-06-26 11:05:14.314102
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    filename = 'test_FileDownloader_report_progress.py'
    params = {'format': 'bestvideo+bestaudio'}

    ydl = YoutubeDL(params)
    fd = FileDownloader(ydl, {'id': 'aaaaaaaaaaaaaaaaaaa'}, params)
    fd._report_progress_status = lambda status, _: None

    with open(filename, 'w') as f:
        f.close()


# Generated at 2022-06-26 11:05:22.160510
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader_0 = FileDownloader('YoutubeDL', {})
    str_0 = 'youtube-dl'
    str_1 = 'youtube-dl'
    str_2 = 'youtube-dl'
    str_3 = 'youtube-dl'
    assert file_downloader_0.temp_name(str_0) == str_1
    assert file_downloader_0.temp_name(str_2) == str_3


# Generated at 2022-06-26 11:05:23.821243
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    test_case_0()



# Generated at 2022-06-26 11:05:28.804125
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    file_downloader_0 = FileDownloader('qh@3', 'qh@3')
    file_downloader_0.download('qh@3', 'qh@3')


# Generated at 2022-06-26 11:05:40.964602
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('20K') == 20480
    assert FileDownloader.parse_bytes('2.5M') == 262144 * 2.5
    assert FileDownloader.parse_bytes('10G') == 1024 ** 3 * 10
    assert FileDownloader.parse_bytes(None) is None
    assert FileDownloader.parse_bytes('some string') is None
    assert FileDownloader.parse_bytes('20 Y') is None
    assert FileDownloader.parse_bytes('20Y') is None

if __name__ == '__main__':
    test_case_0()
    test_FileDownloader_parse_bytes()

# Generated at 2022-06-26 11:05:54.755124
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    file_downloader_0 = FileDownloader('http://www.youtube.com/watch?v=BaW_jenozKc', 'https://www.youtube.com/watch?v=Xta_hRsYaHY')
    file_downloader_0.report_file_already_downloaded('%(uploader)s/%(uploader_id)s - %(title)s.%(ext)s')
    file_downloader_0.report_file_already_downloaded('%(uploader)s/%(uploader_id)s - %(title)s.%(ext)s')
    file_downloader_0.report_file_already_downloaded('%(uploader)s/%(uploader_id)s - %(title)s.%(ext)s')

# Unit

# Generated at 2022-06-26 11:05:57.967185
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from datetime import datetime
    import time
    dt = datetime.now()
    file_downloader_0 = FileDownloader('http://examples.com/', 'test')
    file_downloader_0.slow_down(dt.timestamp(),dt.timestamp(),100)

test_case_0()
test_FileDownloader_slow_down()

# Generated at 2022-06-26 11:06:06.781468
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    str_0 = 'h'
    file_downloader_0 = FileDownloader(str_0, str_0)
    num_0 = 3.2
    num_1 = 0.001
    num_2 = 0.4
    num_3 = 2.72
    num_4 = file_downloader_0.best_block_size(num_0, num_1)
    assert num_4 == num_2
    num_5 = file_downloader_0.best_block_size(num_3, num_1)
    assert num_5 == num_2


# Generated at 2022-06-26 11:06:27.680861
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, {'nooverwrites': True, 'nopart': False, 'verbose': True, 'sleep_interval': None, 'continuedl': True})
    fd.slow_down(1, 1, 1)


# Generated at 2022-06-26 11:06:36.675108
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = None
    try:
        fd = FileDownloader(None, None)
    except Exception as e:
        print(e)
    try:
        fd.download('', {})
    except Exception as e:
        print(e)
    

if __name__ == '__main__':
    test_FileDownloader_download()

# Generated at 2022-06-26 11:06:42.729091
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    params = {
        'noprogress': True,
        'ratelimit': 10240,
    }
    fd = FileDownloader(params, '')
    start = time.time()
    fd.slow_down(start, start, 10 * 1024 * 1024)


# Generated at 2022-06-26 11:06:56.830757
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = 'qh@3'
    str_1 = 'vw'
    file_downloader_0 = FileDownloader(str_0, str_0)
    if (sys.hexversion < 0x03000000) and hasattr(sys.stdout, 'encoding') and sys.stdout.encoding:
        ucode_stdout = True
    else:
        ucode_stdout = False
    if (sys.hexversion < 0x03000000) and hasattr(sys.stderr, 'encoding') and sys.stderr.encoding:
        ucode_stderr = True
    else:
        ucode_stderr = False

# Generated at 2022-06-26 11:07:08.867387
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    param_0 = {'nopart': False,
               'nocheckcertificate': False,
               'no_color': False,
               'no_warnings': False,
               'format': None}
    str_0 = 'http://localhost:9999/'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.params = param_0

# Generated at 2022-06-26 11:07:13.270723
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    time_0 = 0
    bytes_0 = 0
    assert FileDownloader.best_block_size(time_0, bytes_0) == 1


# Generated at 2022-06-26 11:07:18.520244
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    str_0 = 'a'
    str_1 = 'b'

    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.try_rename(str_0, str_1)

if __name__ == '__main__':

    test_case_0()
    test_FileDownloader_try_rename()

# Generated at 2022-06-26 11:07:30.460470
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    str_0 = 'qh@3'
    str_1 = 'X'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.try_utime('Sx')
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.try_utime('Sx', str_1)
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.try_utime('Sx', None)
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.try_utime('Sx', str_1)


# Generated at 2022-06-26 11:07:37.181905
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'qh@3'
    str_1 = 'c%'
    file_downloader_0 = FileDownloader(str_0, str_1)
    file_downloader_0.slow_down('llq_h', 'n|y', 'bpx#')


# Generated at 2022-06-26 11:07:46.028967
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    from youtube_dl.utils import encodeFilename

    assert FileDownloader.try_utime(encodeFilename(__file__), None) == int(os.path.getmtime(__file__))
    assert FileDownloader.try_utime(encodeFilename(__file__), 'Sat, 12 May 2018 15:10:51 GMT') == int(os.path.getmtime(__file__))


# Generated at 2022-06-26 11:07:59.885777
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time_0 = object()
    now_0 = object()
    byte_counter_0 = object()
    file_downloader_0 = FileDownloader(None, None)
    file_downloader_0.slow_down(start_time_0, now_0, byte_counter_0)


# Generated at 2022-06-26 11:08:06.723149
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    retries = 1.0
    file_downloader_0 = FileDownloader(retries, retries)
    str_0 = file_downloader_0.format_retries(retries)
    assert str_0 == '1'


# Generated at 2022-06-26 11:08:16.363996
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = 'Y89+G?j'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = file_downloader_0.undo_temp_name(str_0)
    # Check if str_1 equals to str_0
    if str_1 != 'Y89+G?j':
        print('Test failed')


# Generated at 2022-06-26 11:08:18.529800
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = 'qh@3'
    dict_0 = {}
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_1 = file_downloader_0.download(str_0, dict_0)
    assert file_downloader_1 == True


# Generated at 2022-06-26 11:08:28.660742
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    filename_0 = "D:\\python-youtube-dl/youtube_dl/1.py"
    expected_0 = """[download] D:\python-youtube-dl/youtube_dl/1.py has already been downloaded"""
    assert file_downloader_0.report_file_already_downloaded(filename_0) == expected_0


# Generated at 2022-06-26 11:08:37.514759
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    code = 'Qh@3'
    code = 'https://i.ytimg.com/vi/4vt9HsMEE_k/mqdefault.jpg'

# Generated at 2022-06-26 11:08:46.822337
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_5 = 'me@2'
    str_6 = 'f&'
    float_0 = float('inf')
    float_1 = float('inf')
    float_1 = float_0 / float_0
    float_2 = float('inf')
    float_2 = float_1 / float_1
    float_2 = float_2 / float_1
    float_3 = float('inf')
    float_3 = float_3 / float_3
    float_3 = float_3 / float_1
    float_3 = float_3 / float_2
    float_2 = float_2 / float_1
    float_1 = float_1 / float_0
   

# Generated at 2022-06-26 11:08:58.443121
# Unit test for method download of class FileDownloader

# Generated at 2022-06-26 11:09:10.262152
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-26 11:09:15.310493
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Declare some unit test parameters
    test_FileDownloader_slow_down_rate_limit = None
    # Initialize the unit test context
    file_downloader_0 = FileDownloader('', '')
    # Execute the unit test
    file_downloader_0.slow_down(test_FileDownloader_slow_down_rate_limit, 0.0, 0.0)


# Generated at 2022-06-26 11:09:29.465690
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import random
    import time
    import os
    import tempfile
    import shutil
    from .utils import encodeFilename

    def _random_sleep():
        time.sleep(random.random() * 0.1)

    def _read_and_discard(f, numbytes):
        f.seek(-numbytes, os.SEEK_END)
        f.read()

    def _write_into_file(f, numbytes, offset=0):
        if offset > 0:
            f.seek(offset, os.SEEK_SET)
        data = os.urandom(numbytes)
        f.write(data)

    def _download_hook(status):
        if status['status'] != 'downloading':
            return

# Generated at 2022-06-26 11:09:36.824573
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_0 = 'qh@3'
    dict_0 = {'_speed_str': 'Unknown speed', '_eta_str': 'Unknown ETA', '_percent_str': 'Unknown %'}
    file_downloader_0.report_progress(dict_0)


# Generated at 2022-06-26 11:09:42.408510
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Should return 1048576
    assert FileDownloader.parse_bytes('1m') == 1048576

    # Should return 3145728
    assert FileDownloader.parse_bytes('3M') == 3145728


# Generated at 2022-06-26 11:09:49.998791
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    start_0 = 13236.5053925
    now_0 = 8.2528613793
    bytes_0 = 0.0150258088483
    file_downloader_0.calc_speed(start_0, now_0, bytes_0)


# Generated at 2022-06-26 11:09:56.755402
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = 'k'
    str_1 = 'w| d'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.download(str_1, str_0)


# Generated at 2022-06-26 11:10:06.153846
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)

    try:
        file_downloader_0.slow_down(float('nan'), 1.0, 1)
    except Exception as e:
        print(e)

    # Test method with arguments: (float, float, int), (float, float, float)
    try:
        file_downloader_0.slow_down(0.0, 1.0, 1)
    except Exception as e:
        print(e)

    # Test method with arguments: (float, float, int), (float, float, float)
    try:
        file_downloader_0.slow_down(0.0, 1.0, 1)
    except Exception as e:
        print(e)

    #

# Generated at 2022-06-26 11:10:09.908437
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.download(str_0, str_0)


# Generated at 2022-06-26 11:10:24.273004
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    assert file_downloader_0.parse_bytes('100') == 100
    assert file_downloader_0.parse_bytes('100b') == 100
    assert file_downloader_0.parse_bytes('100k') == 100 * 1024
    assert file_downloader_0.parse_bytes('100m') == 100 * 1024 * 1024
    assert file_downloader_0.parse_bytes('100g') == 100 * 1024 * 1024 * 1024
    assert file_downloader_0.parse_bytes('100t') == 100 * 1024 * 1024 * 1024 * 1024


# Generated at 2022-06-26 11:10:36.323688
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # First test case
    str_0 = 'YC#'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = 'G8f'
    str_2 = 'wN\x18'
    str_3 = '\x7f'
    num_0 = file_downloader_0.slow_down(str_0, str_2, str_3)
    assert num_0 == None

    # Second test case
    str_0 = 'sn%'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_1 = '\x1a'
    str_2 = '\\@\x05'
    str_3 = 'x|\x1a'
    num_0 = file_downloader_0.slow

# Generated at 2022-06-26 11:10:37.168856
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    test_case_0()


# Generated at 2022-06-26 11:10:47.758534
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    file_downloader = FileDownloader("http://www.youtube.com/watch?v=Ik-RsDGPI5Y", None)
    assert "funny-cat-videos-compilation-2014.flv.part" == file_downloader.temp_name("funny-cat-videos-compilation-2014.flv")


# Generated at 2022-06-26 11:10:56.688335
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # expected: None
    int_0 = 5
    str_0 = 'yBVOm@JjFzwM8.QeTZ?-L3qJXW($_T)N'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.slow_down(5, 5, int_0)


# Generated at 2022-06-26 11:11:00.523836
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    str_0 = 'x`7c'
    assert(FileDownloader.parse_bytes(str_0) == 750000000)
    str_0 = 'hUc%'
    assert(FileDownloader.parse_bytes(str_0) == None)
    str_0 = 'qZq^'
    assert(FileDownloader.parse_bytes(str_0) == None)


# Generated at 2022-06-26 11:11:09.311889
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    int_0 = random.randint(0, 9)
    float_0 = random.uniform(0.0, 0.0)
    int_1 = random.randint(0, 9)
    int_2 = random.randint(0, 9)
    int_3 = random.randint(0, 9)
    int_4 = random.randint(0, 9)
    str_0 = '{}'.format('8a06 ys'[int_2:int_3 + 1])
    str_1 = '{}'.format('!p;8'[int_3:int_0 + 1])
    float_1 = random.uniform(0.0, 0.0)
    float_2 = random.uniform(0.0, 0.0)

# Generated at 2022-06-26 11:11:14.562430
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('qh') == 'qh'
    assert FileDownloader.undo_temp_name('qh.part') == 'qh'

if __name__ == '__main__':
    import sys
    import pytest_helper
    pytest_helper.script_run(test_case_0, [sys.argv[0]])
    pytest_helper.script_run(test_FileDownloader_undo_temp_name, [sys.argv[0]])

# Generated at 2022-06-26 11:11:16.098181
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:11:20.551238
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    file_downloader_0 = FileDownloader('http://google.com/', 'google.com')
    file_downloader_0.try_utime('google.com', 'Tue, 25 Jun 2013 18:45:27 GMT')


# Generated at 2022-06-26 11:11:21.438828
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    test_case_0()


# Generated at 2022-06-26 11:11:33.011158
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = 'fcr'
    str_1 = 'e'
    str_2 = 'z'
    str_3 = '1'
    str_4 = '9'
    str_5 = 'o8'
    file_downloader_0 = FileDownloader(str_5, str_5)
    # assert file_downloader_0.undo_temp_name(str_0) == (str_1)
    # assert file_downloader_0.undo_temp_name(str_2) == (str_3)
    # assert file_downloader_0.undo_temp_name(str_4) == (str_1)
    print('Pass')


# Generated at 2022-06-26 11:11:44.766809
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('1024k') == 1048576
    assert FileDownloader.parse_bytes('1.5M') == 1572864
    assert FileDownloader.parse_bytes('0') == 0
    assert FileDownloader.parse_bytes('3.14M') == 3294824
    assert FileDownloader.parse_bytes('3.14MB') == 3294824
    assert FileDownloader.parse_bytes('3.14') == 3
    assert FileDownloader.parse_bytes('+3.14') is None
    assert FileDownloader.parse_bytes('-3.14') is None
    assert FileDownloader.parse_bytes('3.14MBB') is None
    assert FileDownloader.parse_bytes('3.14B') is None
   

# Generated at 2022-06-26 11:11:56.182678
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    d_0 = OrderedDict()
    d_0['status'] = 'finished'
    file_downloader_0.report_progress(d_0)
    file_downloader_0.report_progress(d_0)


# Generated at 2022-06-26 11:11:58.894477
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'O'
    int_0 = 3
    float_0 = 3
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.slow_down(int_0, int_0, float_0)


# Generated at 2022-06-26 11:12:07.487126
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    str_0 = 'bts'
    str_1 = 'btz'
    str_2 = 'thumb'
    v_0 = FileDownloader(str_1, str_2)
    v_0.params = {'quiet': False}
    v_0.to_screen = lambda *a, **ka: None
    v_0.report_destination = lambda *a, **ka: None
    v_0.report_progress = lambda *a, **ka: None
    v_0.to_stderr = lambda *a, **ka: None

# Generated at 2022-06-26 11:12:13.288592
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    str_0 = 'ED$'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_file_already_downloaded('cw-~')


# Generated at 2022-06-26 11:12:19.148077
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    int_0 = 49
    int_1 = 50
    file_downloader_0.slow_down(int_0, int_1, int_0)


# Generated at 2022-06-26 11:12:28.613411
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    str_0 = 'qh@3'
    file_downloader_0 = FileDownloader(str_0, str_0)
    file_downloader_0.report_destination(str_0)
    file_downloader_0.report_progress({'status': 'downloading', 'eta': '59:43', 'total_bytes': '2187922', 'elapsed': '0:09', 'speed': '213452'})
    file_downloader_0.trouble('e4#')
    file_downloader_0.report_download_webpage(str_0)
    file_downloader_0.report_retry(str_0, 5, 2)
    file_downloader_0.report_unable_to_resume()

# Generated at 2022-06-26 11:12:39.253667
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    time_0 = time.time()
    timeconvert_str_0 = timeconvert(time_0)
    assert timeconvert_str_0 is not None
    file_downloader_0 = FileDownloader('https://www.youtube.com/watch?v=W0LHTWG-UmQ', 'test_FileDownloader_slow_down')
    file_downloader_0.params.update({
        'verbose': True,
        'format': 'best',
        'outtmpl': '%(id)s%(ext)s'
    })
    assert isinstance(file_downloader_0.filename, str)
    assert file_downloader_0.ydl is not None
    assert file_downloader_0.params is not None
    assert file_downloader_0.info is None

# Generated at 2022-06-26 11:12:46.848280
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    str_0 = 'w'
    file_downloader_0 = FileDownloader(str_0, str_0)
    str_0 = 'h'
    str_1 = 'v'
    assert file_downloader_0.undo_temp_name(str_0) == 'h'

