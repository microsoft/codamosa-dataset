

# Generated at 2022-06-12 16:23:57.404056
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    
    fd = FileDownloader(ydl, {
        'id': 'test',
        'url': 'http://www.test.com/test.file',
        'title': 'test',
        'ext': 'test'
    })

    fd.params['ratelimit'] = 2048
    fd._start_time = time.time()


    fd.slow_down(fd._start_time, None, 50)
    assert fd._start_time == time.time()


# Generated at 2022-06-12 16:24:09.578063
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({}, None)
    fd.to_screen = MagicMock()
    fd.report_file_already_downloaded('filename')
    fd.to_screen.assert_called_once_with(u'[download] filename has already been downloaded')
    fd.to_screen.reset_mock()
    fd.report_file_already_downloaded('file/name')
    fd.to_screen.assert_called_once_with(u'[download] The file has already been downloaded')
    fd.to_screen.reset_mock()
    fd.report_file_already_downloaded('file/name/file/name')
    fd.to_screen.assert_called_once_with(u'[download] The file has already been downloaded')
   

# Generated at 2022-06-12 16:24:12.144307
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    d = FileDownloader(None, None)
    assert d.temp_name('test') == 'test.part'



# Generated at 2022-06-12 16:24:20.696477
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})

    fd.params['nopart'] = True
    assert fd.temp_name('abc') == 'abc'

    fd.params['nopart'] = False
    fd.params['continuedl'] = True
    assert fd.temp_name('abc') == 'abc.part'

    fd.params['nopart'] = True
    assert fd.temp_name('abc') == 'abc'

    fd.params['nopart'] = False
    assert fd.temp_name('abc') == 'abc.part'

    fd.params['nopart'] = True
    assert fd.temp_name('abc') == 'abc'

    fd.params['nopart'] = False

# Generated at 2022-06-12 16:24:26.570608
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    print('test_FileDownloader_undo_temp_name')
    temp_name = FileDownloader.temp_name('test')
    assert temp_name == 'test.part'
    assert FileDownloader.undo_temp_name(temp_name) == 'test'


# Generated at 2022-06-12 16:24:32.786533
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    # Test with speed==0
    assert fd.calc_speed(0, 0.5, 0) is None

    # Test with dif==0
    assert fd.calc_speed(1, 1, 10) is None

    # Test with dif and speed > 0
    assert fd.calc_speed(1, 2, 10) == 5

# Generated at 2022-06-12 16:24:42.869428
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Mock up FileDownloader class
    class MockFileDownloader(FileDownloader):
        pass

    class Instance:
        ydl = MockFileDownloader(Instance())
        params = {
            'noprogress': False,
            'verbose': False,
            'nopart': False,
            'continuedl': True,
            'nooverwrites': False,
        }
    # Mock a callback function
    def ph(status):
        assert 'status' in status
        assert 'filename' in status
        assert 'eta' in status

    # Initialize the instance
    instance = Instance()
    # Initialize the report_progress method
    report_progress = MockFileDownloader.report_progress

    # Test the 'finished' status
    report_progress(instance, {})

    # Test the 'downloading

# Generated at 2022-06-12 16:24:50.584243
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def test_calc_eta():
        assert FileDownloader.calc_eta(0, 0, 0) is None
        assert FileDownloader.calc_eta(0, 1, 0) is None
        assert FileDownloader.calc_eta(0, 0, 1) == 0.0
        assert FileDownloader.calc_eta(0, 2, 1) == 0.5

    test_calc_eta()



# Generated at 2022-06-12 16:25:03.059479
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    ydl = FakeYDL()
    fd = FileDownloader(ydl, {'sleep_interval': 0, 'progress_with_newline': True})

# Generated at 2022-06-12 16:25:11.730676
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({}, {})
    fd.undo_temp_name('abc.part') == 'abc'
    fd.undo_temp_name('abc') == 'abc'
    fd.undo_temp_name('abc.tar.part') == 'abc.tar'
    fd.undo_temp_name('abc.tar') == 'abc.tar'
    fd.undo_temp_name('abc.tar.gz.part') == 'abc.tar.gz'
    fd.undo_temp_name('abc.tar.gz') == 'abc.tar.gz'
    fd.undo_temp_name('abc.part.part') == 'abc.part'
    fd.undo_temp_name('abc.part.tar.part') == 'abc.part.tar'
    fd.undo

# Generated at 2022-06-12 16:25:38.533122
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """ Test FileDownloader.report_progress
    """
    ydl = FileDownloader({'noprogress': True})
    status = {}

    def _test(s, exp):
        ydl.report_progress(s)
        assert s == status
        assert exp == ydl._last_line

    status = {'status': 'finished', 'speed': 'Unknown speed', 'eta': 'Unknown ETA', 'downloaded_bytes': 12345, 'elapsed': 2.5}
    _test(status, '[download] 12345 at Unknown speed (00:00)')

    status = {'status': 'finished', 'speed': 'Unknown speed', 'eta': 'Unknown ETA', 'downloaded_bytes': 12345, 'elapsed': 0.5}

# Generated at 2022-06-12 16:25:50.235731
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import pytest

    # Setup FileDownloader instance
    fd = FileDownloader(None)

    # Setup status dictionary
    status = {}

    # Check for exception when status is empty
    with pytest.raises(Exception):
        fd.report_progress(status)

    # Check for exception when status is wrong
    status = {'wrong': 'status'}
    with pytest.raises(Exception):
        fd.report_progress(status)

    # Status 'status' is not handled by FileDownloader
    status = {'status': 'status'}
    fd.report_progress(status)

    # Status 'finished' is not handled by FileDownloader
    status = {'status': 'finished'}
    fd.report_progress(status)

    # Status 'downloading'

# Generated at 2022-06-12 16:26:02.824524
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.utils import encode_compat_str

    def _test(status, expected_output):
        fd = FileDownloader(None)
        fd.params = {}
        fd.to_screen = lambda s: s

        res = fd.report_progress({'status': status})
        if res is not None:
            res = encode_compat_str(res)
        assert res == expected_output

    _test('downloading', None)
    _test('finished', '100% of Unknown size in Unknown time ETA Unknown ETA')

    _test('downloading', None)
    _test('finished', '100% of Unknown size in Unknown time ETA Unknown ETA')
    _test('downloading', None)
    _test('finished', '100% of Unknown size in Unknown time ETA Unknown ETA')

# Generated at 2022-06-12 16:26:15.044274
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from argparse import _VersionAction
    from mock import Mock
    from ytdl.FileDownloader import FileDownloader

    fd = FileDownloader({ 'ratelimit' : '10240' })

    # Case:
    #   - ratelimit > max(bytes, 2) / seconds
    #   - ratelimit < min(bytes / 2, 1)
    fd.slow_down(time.time(), time.time() + 1, 100)

    # Case:
    #   - ratelimit < max(bytes, 2) / seconds
    #   - ratelimit >= min(bytes / 2, 1)
    fd.slow_down(time.time(), time.time() + 1, 12288)

test_FileDownloader_slow_down()

# Test suite for unit-test of class GenericInfoExtractor

# Generated at 2022-06-12 16:26:27.782979
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    downloader = FileDownloader({})
    def test(s, r):
        if downloader.parse_bytes(s) != r:
            print('Invalid result for %s: %s (expected: %s)' % (s, downloader.parse_bytes(s), r))
    test('0b', 0)
    test('0k', 0)
    test('0m', 0)
    test('0', 0)
    test('1b', 1)
    test('1k', 1000)
    test('1m', 1000000)
    test('1.0b', 1)
    test('1.1b', 1)
    test('1.0k', 1000)
    test('1.1k', 1100)
    test('0.8m', 800000)
    test('1.0m', 1000000)
   

# Generated at 2022-06-12 16:26:40.016187
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    progress_hooks = []
    fd = FileDownloader({'progress_with_newline': False}, None)

    fd.add_progress_hook(lambda s: progress_hooks.append(s))

    fd.report_progress({'downloaded_bytes': 0,
                        'total_bytes': 100,
                        'elapsed': 1,
                        'status': 'downloading'})

# Generated at 2022-06-12 16:26:53.040457
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    # Set up a FileDownloader instance
    ######################################

    params = {
        'simulate': True,
        'outtmpl': '%(id)s',
        'quiet': True,
    }

    ydl = Ydl(params)

    fd = FileDownloader(ydl, {})
    fd.add_progress_hook(lambda status: None)

    # Test normal downloading
    ######################################

    assert fd.download('youtube-dl_test', {}) is True

    # Test that downloading twice to the same file fails
    ######################################

    assert fd.download('youtube-dl_test', {}) is False

    # Test downloading to stdout
    ######################################

    assert fd.download('-', {}) is True

    # Test that downloading twice to the same stdout fails

# Generated at 2022-06-12 16:27:04.739496
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    import sys
    import json

    # Create a test FileDownloader object
    f = FileDownloader({'format': 'best', 'outtmpl': '-'})

    # Test: Format is None, info_dict is None
    args = f.download(None, None)
    assert(args == (False, returncode_none, None, None))

    # Test: Format is None, info_dict is specified
    args = f.download(None, {'start_time': 0})
    assert(args == (False, returncode_none, None, None))

    # Test: Format is None, info_dict is specified
    args = f.download(None, {'start_time': 0})
    assert(args == (False, returncode_none, None, None))

    # Test: Format is specified, info_dict is None
   

# Generated at 2022-06-12 16:27:10.833825
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, None)
    fd.params = {'nopart': False}

    # Test without '.part'
    assert fd.temp_name('test.tmp') == 'test.tmp.part'
    # Test with '.part'
    assert fd.temp_name('test.tmp.part') == 'test.tmp.part.part'

    # Test with '-' (stdout)
    assert fd.temp_name('-') == '-'

    # Test with dir
    assert fd.temp_name('test') == 'test'

    # Test with nopart
    fd.params = {'nopart': True}
    assert fd.temp_name('test.tmp') == 'test.tmp'



# Generated at 2022-06-12 16:27:15.550859
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    downloader = FileDownloader({})
    assert downloader.download(
        filename='test', info_dict={'file': 'test'})



# Generated at 2022-06-12 16:27:26.423163
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """
    Test report_progress method of FileDownloader
    """
    # Test with use_proxy, proxy and proxy_username parameters
    params = {
        "proxy": "proxy",
        "proxy_username": "proxy_username"
    }
    ydl = YoutubeDL(params)
    fd = FileDownloader({}, None, ydl)
    fd.report_progress({
        'total_bytes_estimate': 20,
    })


# Generated at 2022-06-12 16:27:38.145916
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    class FileDownloader_download_FakeInfoDict:
        def __init__(self):
            self.title = ''
            self.formats = []

# Generated at 2022-06-12 16:27:49.793503
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    outdir = os.path.abspath(os.path.join(os.getcwd(), 'FileDownloader_test_output'))
    os.mkdir(outdir)
    class MockYDL(YoutubeDL):
        """
        A mock YoutubeDL class to override get_suitable_downloader.
        """

        def __init__(self, *args, **kwargs):
            self.downloader = FileDownloader(*args, **kwargs)

        def to_screen(self, msg, skip_eol=False):
            pass

        def to_console_title(self, msg):
            pass

# Generated at 2022-06-12 16:27:58.935594
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from .utils import DateRange
    from .extractor.common import InfoExtractor

    class MyInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            self._downloader = FileDownloader(
                params=dict(nopart=True),
                info_dict=dict(name='test'))

        def _real_extract(self, url):
            return url

    ie = MyInfoExtractor()
    d = ie._downloader

    # No speed limit
    d._start_time = 0
    d._total_bytes = 2
    d._downloaded_bytes = 1
    d.slow_down(0, 1000, 1)
    assert d._downloaded_bytes == 1

    # No speed limit
    d._start_time = 0
    d._total_bytes = 2
    d._

# Generated at 2022-06-12 16:28:11.903417
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    t = FileDownloader({'outtmpl': '%(id)s%(ext)s', 'sleep_interval': 0})
    t._debug_cmd = lambda x: None
    t.report_error = lambda msg: None
    t.real_download = lambda x, y: True
    t.ydl = YoutubeDL({'cachedir': False})
    info = {
        'id': 'test',
        'ext': '.test'
    }
    ret = t.download('%(id)s%(ext)s', info)
    assert ret

    t.params['sleep_interval'] = 0.5
    ret = t.download('%(id)s%(ext)s', info)
    assert ret

    t.params['continuedl']

# Generated at 2022-06-12 16:28:19.245260
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def return_1000(unused):
        return 1000.0
    def return_minus_2(unused):
        return -2.0
    fd = FileDownloader({}, None)
    fd.time = return_1000
    fd.calc_eta = return_minus_2
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(0, 0, 1000) == 1000.0
    assert fd.calc_speed(0, 1, 1000) == 1000.0
    assert fd.calc_speed(0, 0, 1024) is None
    assert fd.calc_speed(0, 1, 1024) == 1024.0



# Generated at 2022-06-12 16:28:25.568271
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """Unit test for FileDownloader.try_utime."""
    fd = FileDownloader({})
    assert fd.try_utime('/tmp/test_filename', 'Tue, 07 Feb 2012 12:45:26 GMT') is not None
    assert fd.try_utime('/tmp/test_filename', 'i am not a valid timestamp') is None

# Generated at 2022-06-12 16:28:38.095489
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    ydl = FileDownloader(FakeYoutubeDL(), params={})
    ydl.params['nooverwrites'] = True

    def hook(status):
        time.sleep(0.05)
        if status['status'] == 'finished':
            raise ValueError

    ydl.add_progress_hook(hook)

    fd = FakeFD()
    ydl.report_destination(fd.name)

    start = time.time()
    ydl.slow_down(start, start + 1.0, 1024)
    assert (time.time() - start) < 0.01

    ydl.params['ratelimit'] = 64
    ydl.slow_down(start, start + 1.0, 512)
    assert (time.time() - start) >= 0.25

# Generated at 2022-06-12 16:28:49.645152
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # Some examples:
    # 0:00:00.000
    # 0:00:09.001
    # 0:01:00.011
    # 0:45:23.123
    # 1:30:42.435
    # 123:45:07.654
    # 3600:00:00.001
    assert FileDownloader.format_seconds(0) == '0:00:00'
    assert FileDownloader.format_seconds(9.001) == '0:00:09'
    assert FileDownloader.format_seconds(60.011) == '0:01:00'
    assert FileDownloader.format_seconds(2723.123) == '0:45:23'
    assert FileDownloader.format_seconds(5442.435) == '1:30:42'
    assert FileDownloader.format

# Generated at 2022-06-12 16:29:01.564742
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def calc(current, total, start, now):
        fd = object.__new__(FileDownloader)
        fd.params = {}
        return fd.calc_speed(start, now, current, total)
    # Test that the speed is not calculated if the download time is less than a millisecond
    assert calc(0, 1, time.time(), time.time()) is None
    assert calc(0, 1, time.time(), time.time() + 0.0005) is None
    assert calc(0, 1, time.time(), time.time() + 1) is not None
    # Test that the speed is not calculated if current or total is zero or negative
    assert calc(0, 0, time.time(), time.time() + 1) is None

# Generated at 2022-06-12 16:29:25.575454
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fileNames = ['test_2015_03_02', 'test_2015_03_02.ytdl', 'test_2015_03_02.part']
    for fileName in fileNames:
        downloader = FileDownloader(YoutubeDL(), {})
        fh = open(fileName, 'w')
        fh.close()
        downloader.try_utime(fileName, "Sat, 02 Mar 2015 14:14:22 +0000")
        data = os.stat(fileName)
        atime = data.st_atime
        if atime != 1425278062.0:
            raise Exception('Failed to set timestamp for file ' + fileName)
        os.remove(fileName)

# Generated at 2022-06-12 16:29:33.727037
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    if sys.version_info < (2, 7):
        return  # no float('inf') support
    fd = FileDownloader({})
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(float('inf')) == 'inf'


test_FileDownloader_format_retries()

# Generated at 2022-06-12 16:29:44.140071
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    def test_report_downloaded(file_name, msg):
        fd = FileDownloader(None, None)
        try:
            fd.report_file_already_downloaded(file_name)
        except UnicodeEncodeError:
            assert msg == 'download] The file has already been downloaded'
        else:
            assert msg == 'download] %s has already been downloaded' % file_name

    test_report_downloaded('test1', 'download] test1 has already been downloaded')
    test_report_downloaded('test2\u03b1', 'download] test2α has already been downloaded')
    test_report_downloaded('test2\u0391', 'download] test2Α has already been downloaded')

# Generated at 2022-06-12 16:29:56.914890
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True
    # Test setup
    fd = TestFileDownloader({'noprogress': True})
    # Test report_progress with no additional parameters
    fd.report_progress({})
    # Test report_progress with sleep_interval set
    fd = TestFileDownloader({'noprogress': True, 'sleep_interval': '0.1'})
    fd.report_progress({})
    # Test report_progress with max_sleep_interval set
    fd = TestFileDownloader({'noprogress': True, 'sleep_interval': '0.1', 'max_sleep_interval': '0.2'})
    fd.report_progress({})
    # Test

# Generated at 2022-06-12 16:30:07.990698
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class TestFileDownloader(FileDownloader):
        def report_error(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def slow_down(self, *args, **kargs):
            pass

    fd = TestFileDownloader(None, {'outtmpl': '%(title)s'})
    filename = 'test.mp4'
    open(filename, 'w').close()
    assert not fd.try_utime(filename, None) is None
    assert not fd.try_utime(filename, 'X') is None
    assert not fd.try_utime(filename, '1970') is None
    assert not fd.try_utime(filename, '1970.00') is None

# Generated at 2022-06-12 16:30:20.218382
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
	import datetime

	# utime does not work on Windows XP; TODO: find a way to test it on XP
	if sys.platform == 'win32' and sys.getwindowsversion()[0] < 6:
		return

	class FakeInfo(object):
		def __init__(self, timestamp):
			self.timestamp = timestamp

	class FakeYdl(object):
		pass

	fd = FileDownloader({'outtmpl': '%(id)s.%(ext)s'}, FakeYdl())
	testfile = os.path.join(os.path.dirname(__file__), 'testfile')

	# Using a temporary file makes sure the test doesn't
	# modify the user's file timestamp
	fd.try_utime(testfile, None)

# Generated at 2022-06-12 16:30:25.973363
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(params={'noprogress': True, 'nopart': True},
                                progress_hooks=[])
    assert downloader.temp_name('abc.mp4') == 'abc.mp4'
    assert downloader.temp_name('123/abc.mp4') == '123/abc.mp4'
    assert downloader.temp_name('abc.mp4') == 'abc.mp4'
    assert downloader.temp_name('abc') == 'abc'
    assert downloader.temp_name('-') == '-'



# Generated at 2022-06-12 16:30:37.654910
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def dict_equal(d1, d2):
        for key, value in d1.items():
            if key == 'elapsed':
                continue
            if key not in d2:
                return False
            if value != d2[key]:
                return False
        return True


# Generated at 2022-06-12 16:30:49.837364
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    import sys
    _FileDownloader = FileDownloader(params={}, ydl=None)
    def chk(blk, exp):
        res = _FileDownloader.parse_bytes(blk)
        print(res, res == exp)
        assert res == exp
    chk("1", 1)
    chk("1k", 1024)
    chk("1m", 1048576)
    chk("1g", 1073741824)
    chk("0.5k", 512)
    chk("2.5k", 2560)
    chk("1.4M", 1474560)
    chk("1.4m", 1474560)
    chk("0", 0)
    # Float values

# Generated at 2022-06-12 16:30:51.158166
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # TODO
    pass

# Generated at 2022-06-12 16:31:03.077750
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    import time
    t0 = time.time()

# Generated at 2022-06-12 16:31:07.888673
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader()
    fd.params = {'ratelimit': 2000}
    now = time.time()
    start = now - 100.0
    byte_counter = 10 * 1024 *1024
    fd.slow_down(start, now, byte_counter)
    assert True


# Generated at 2022-06-12 16:31:19.581243
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def recorder(s, buf):
        s['slept'] = buf == 'time.sleep(3.1415)\n'
        s['sleep_time'] = 3.1415
    fd = FileDownloader(None, None)
    fd.sleep = recorder
    s = {'slept': False, 'speed': 10, 'downloaded_bytes': 31415}
    fd.slow_down(0, 10, 31415)
    assert s['slept']

    s = {'slept': False, 'speed': 5, 'downloaded_bytes': 31415}
    fd.slow_down(0, 10, 31415)
    assert s['slept']

    s = {'slept': False, 'speed': 5, 'downloaded_bytes': 31415}

# Generated at 2022-06-12 16:31:31.355348
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class MockLogger(object):
        def __init__(self):
            self.messages = []

        def debug(self, msg):
            self.messages.append(msg)
    logger = MockLogger()

    fd = FileDownloader(params={'noprogress': True})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 2000,
    })
    assert len(logger.messages) == 1
    assert logger.messages[0] == '[download] Download completed'

    logger.messages = []
    fd = FileDownloader(params={'noprogress': False})
    fd.to_screen = logger.debug
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 2000,
    })

# Generated at 2022-06-12 16:31:44.561333
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """test_FileDownloader_report_progress

    Test report_progress function of FileDownloader
    """
    import sys
    import io
    import unittest

    class TestFileDownloader(FileDownloader):
        def __init__(self, params):
            super().__init__(params)

    if 'win32' in compat_sys_platform:
        unittest.TestCase.skipTest(
            'skipped on win32 platform '
            '(https://github.com/rg3/youtube-dl/issues/8233)')

    class TestFileDownloader_report_progress(unittest.TestCase):
        def setUp(self):
            with self.assertRaises(AttributeError):
                sys.stdout.encoding
            self.true_encoding = sys.stdout.encoding
            self.params

# Generated at 2022-06-12 16:31:55.015209
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # TODO: Improve this unit test
    fdclass = FileDownloader(None, {'noprogress': False})
    speed_str = ' ' * 8
    eta_str = ' ' * 4

    status = {
        'status': 'downloading',
        'downloaded_bytes': 1234,
        'speed': int(3.45 * 1024)
    }
    fdclass.report_progress(status)

    assert fdclass._report_progress_prev_line_length == 0
    assert sys.stderr.getvalue() == '\r[download]   0.3KiB at 3.4KiB/s%sETA%s' % (speed_str, eta_str)

    sys.stderr.seek(0)
    sys.stderr.truncate()



# Generated at 2022-06-12 16:32:05.391375
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert type(fd.best_block_size(1, 1)) is int
    assert type(fd.best_block_size(2, 1)) is int
    assert fd.best_block_size(1, 1) == 1
    assert fd.best_block_size(1, 2) == 1
    assert fd.best_block_size(1, 3) == 1
    assert fd.best_block_size(1, 4) == 1
    assert fd.best_block_size(1, 5) == 2
    assert fd.best_block_size(1, 6) == 2
    assert fd.best_block_size(1, 7) == 4
    assert fd.best_block_size(1, 8) == 4
    assert fd.best_

# Generated at 2022-06-12 16:32:15.880780
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import tempfile
    import shutil
    import os
    import os.path
    import re
    import filecmp
    import httplib
    from io import BytesIO
    from io import BufferedReader
    from io import BufferedWriter
    from io import BufferedIOBase
    from socket import error as SocketError
    from socket import timeout as SocketTimeout
    import ssl
    from subprocess import Popen
    from sys import version_info
    from threading import Thread
    from time import sleep
    from unittest.case import SkipTest
    from unittest.case import TestCase
    from unittest.case import skipIf
    from unittest.case import skipUnless
    from urllib2 import URLError
    from youtube_dl.FileDownloader import FileDownloader
    # On Python 2.6, we

# Generated at 2022-06-12 16:32:22.481376
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(params={'nopart': False})
    downloader.to_screen = lambda *args, **kargs: None
    downloader.verbose = False
    # Test noop
    assert downloader.temp_name('foo') == 'foo'
    # Test .part extension
    assert downloader.temp_name('foo') == 'foo.part'
    # Test undo of .part extension
    assert downloader.undo_temp_name('foo.part') == 'foo'
    assert downloader.undo_temp_name('foo') == 'foo'
    # Test .part extension of .part
    assert downloader.temp_name('foo.part') == 'foo.part.part'

# Generated at 2022-06-12 16:32:31.464846
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Create a YouTube video info dict
    info_dict = {'id': 'http://www.youtube.com/watch?v=BaW_jenozKc'}

    # Create the FileDownloader
    fd = FileDownloader(None, params={})

    # Test the download method
    assert fd.download(None, info_dict) is None

# Test run
if __name__ == '__main__':
    # Test the test_FileDownloader_download function
    test_FileDownloader_download()

 

# Generated at 2022-06-12 16:32:56.692239
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    """
    Test if the function works as expected in all cases
    """
    fd = FileDownloader({'ratelimit': None})
    start = time.time()
    fd.slow_down(start, start + 1, 1024)  # No rate limit, no sleep

    rate_limits = [1024, 1024 * 1024, 1024 * 1024 * 1024]
    for rate_limit in rate_limits:
        fd = FileDownloader({'ratelimit': rate_limit})
        start = time.time()
        elapsed = float(1024 * 1024) / rate_limit
        fd.slow_down(start, start + elapsed, 1024 * 1024)  # Rate limit respected, no sleep
        fd.slow_down(start, start + elapsed + 0.1, 1024 * 1024)  # Rate limit not respected, sleep
        fd.slow_

# Generated at 2022-06-12 16:33:07.251320
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import sys
    import time
    import shutil
    import tempfile

    def touch(filename):
        with open(filename, 'a'):
            os.utime(filename, None)

    def read_sys_timezone():
        if sys.platform == 'win32':
            return time.altzone
        return time.timezone

    filename = os.path.join(tempfile.gettempdir(), 'filename')
    timezone = read_sys_timezone()


# Generated at 2022-06-12 16:33:19.096355
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # file name
    filename = os.path.join(os.getcwd(),'FileDownloader.py')
    # reset FileDownloader class
    fd = FileDownloader(
        params={'noprogress':True},
        ydl=YoutubeDL(params={})
    )
    # create fake info_dict
    info_dict = {'url':'https://www.youtube.com/watch?v=9bZkp7q19f0'}
    # get the redirection url
    info_dict['url'] = fd._do_redirect(info_dict['url'])
    # get file size
    info_dict['total_bytes'] = fd._get_total_bytes(info_dict['url'])
    # call to _hook_progress