

# Generated at 2022-06-12 16:24:16.231170
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert (FileDownloader().temp_name('abc.def') == 'abc.def.part')
    assert (FileDownloader().temp_name('.abc') == '.abc.part')
    assert (FileDownloader().temp_name('abc') == 'abc.part')
    assert (FileDownloader().temp_name('abc.def.ghi') == 'abc.def.ghi.part')
    assert (FileDownloader().temp_name('-') == '-')
    assert (FileDownloader().temp_name('abc', nopart=True) == 'abc')
    assert (FileDownloader().temp_name('abc.def', nopart=True) == 'abc.def')
    assert (FileDownloader().temp_name('abc.def', nopart=True) == 'abc.def')

# Generated at 2022-06-12 16:24:28.543122
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    ydl = YoutubeDL()
    assert ydl.fd.temp_name('-') == '-'
    assert ydl.fd.temp_name('/tmp/abc') == '/tmp/abc.part'
    assert (ydl.fd.temp_name('/tmp/abc.part') ==
            '/tmp/abc.part.part')
    assert (ydl.fd.temp_name('/tmp/abc.part.part') ==
            '/tmp/abc.part.part.part')
    assert ydl.fd.temp_name('/tmp/abc.tmp') == '/tmp/abc.tmp.part'
    assert ydl.fd.temp_name('abc.flv') == 'abc.flv.part'

    ydl = YoutubeDL({'nopart': True})

# Generated at 2022-06-12 16:24:39.528340
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def make_test_file(filename, timestamp=1386973053.204584):
        with open(encodeFilename(filename), 'wb') as f:
            f.write(b'blah')
        os.utime(encodeFilename(filename), (timestamp, timestamp))

    def assert_utime_within_one_second(filename, reference):
        last_modified_hdr = time.strftime(
            '%Y%m%d%H%M%S', time.gmtime(reference)) + '.000Z'
        # Check that FileDownloader.try_utime works as needed
        assert fd.try_utime(encodeFilename(filename), last_modified_hdr) == reference

        # Check that there is 'within one second' accuracy in utime
        # Try setting a timestamp that is one day earlier


# Generated at 2022-06-12 16:24:51.695576
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeInfoObject(object):
        def __init__(self, tb):
            self.total_bytes = tb

    tb = 1024*10
    info = FakeInfoObject(tb)
    fd = FileDownloader(
        params={},
        ydl=FakeYoutubeDL(stdout=io.BytesIO()),
    )

    # 1. noprogress: no output
    fd.report_progress({'status': 'finished'})
    fd.params['noprogress'] = True
    fd.report_progress({'status': 'downloading', 'total_bytes': tb, 'downloaded_bytes': (tb/10)})
    fd.params['noprogress'] = False
    fd.report_progress({'status': 'finished'})

    # 2.

# Generated at 2022-06-12 16:25:03.974765
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def run_try_utime(last_modified_hdr, expected_result):
        assert FileDownloader.try_utime(
            'test', last_modified_hdr) == expected_result

    from datetime import datetime, timedelta
    EPOCH = datetime(1970, 1, 1)

    # We use a fixed timestamp for the test
    test_timestamp = EPOCH + timedelta(days=1)

    run_try_utime(None, None)
    run_try_utime('', None)
    run_try_utime('0', None)
    run_try_utime('a', None)
    run_try_utime('1970-01-02T00:00:00.0Z', (test_timestamp - EPOCH).total_seconds())
    run_try_ut

# Generated at 2022-06-12 16:25:13.525382
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Make sure test files are not created in the system
    fd = FileDownloader(None, params={'outtmpl': 'test/test_%(epoch)s'})

# Generated at 2022-06-12 16:25:19.017243
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    """Test method undo_temp_name of class FileDownloader"""
    fd = FileDownloader(params={})
    assert fd.undo_temp_name('file.part') == 'file'
    assert fd.undo_temp_name('file.part.part') == 'file.part'
    assert fd.undo_temp_name('file') == 'file'

# Generated at 2022-06-12 16:25:28.689221
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """Testing method download of class FileDownloader"""

    from .extractor.common import InfoExtractor
    from .compat import parse_qs, compat_urlparse, compat_urllib_parse

    class InfoExtractorMock(InfoExtractor):
        def __init__(self):
            self._info_dict = {'id': 'ytdl-test-id'}

    class DownloaderMock:
        def __init__(self):
            self.extractor = InfoExtractorMock()
            self.ydl = Ydl()

        def ytdl_filename(self, filename):
            return filename + '.ytdl'

    class Ydl:
        def __init__(self):
            self.params = {}
            self.to_screen = mock.Mock()


# Generated at 2022-06-12 16:25:40.715313
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # Save current time
    now = time.time()

    # Create a temporary file
    test_filename = 'test_FileDownloader_try_utime.tmp'
    with open(test_filename,'w') as f:
        f.write('test')
    filetime = None

    # Test with a last_modified_hdr value which can't be converted to a valid time
    last_modified_hdr = 'test'
    filetime = FileDownloader.try_utime(test_filename, last_modified_hdr)
    assert filetime is None

    # Test with a last_modified_hdr value which can be converted to a valid time
    last_modified_hdr = 'Tue, 15 Nov 1994 12:45:26 GMT'

# Generated at 2022-06-12 16:25:51.885897
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    filename = 'test'
    os.utime(filename, None)
    file = open(filename, 'w+')
    fd = FileDownloader(None, None)
    file.close()
    assert fd.try_utime(filename, None) == 0
    assert fd.try_utime(filename, '123') == 0
    assert fd.try_utime(filename, '1234567890') == 1234567890
    assert fd.try_utime(filename, '0') == 0
    assert fd.try_utime(filename, '123456789012345678') == 1234567890
    fd.try_utime(filename, '1') == 1
    os.remove(filename)


test_FileDownloader_try_utime()


# Generated at 2022-06-12 16:26:19.235960
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(DummyYoutubeDl())
    FilenameAssertion('abc.part', fd.undo_temp_name('abc.part'))
    FilenameAssertion('abc.flv', fd.undo_temp_name('abc.flv'))
    FilenameAssertion('abc.', fd.undo_temp_name('abc.'))
    FilenameAssertion('', fd.undo_temp_name(''))
    FilenameAssertion('abc.part.bak', fd.undo_temp_name('abc.part.bak'))



# Generated at 2022-06-12 16:26:32.236584
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import os
    import time
    import shutil
    from tempfile import mkdtemp
    from .postprocessor import _sleep, _read, _write, _remove

    # Formatting function seems to show only milliseconds so it has to be
    # tested like this.
    def assertAlmostEqual(value, expected, max_delta):
        assert abs(value - expected) < max_delta

    # Mock the time.sleep() function
    sleep_orig = time.sleep
    slept = []
    def mock_sleep(dur):
        slept.append(dur)
        sleep_orig(dur)


# Generated at 2022-06-12 16:26:43.284076
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test Case 1: The parameter s has no key 'elapsed'
    # Expected Result: The downloaded_bytes is added to progress message
    fd = FileDownloader({})
    s = {'status': 'downloading'}
    s['speed'] = 100
    s['eta'] = 123
    s['total_bytes'] = 20000
    s['downloaded_bytes'] = 1000
    s['_percent_str'] = '50%'
    fd.report_progress(s)
    # Test Case 2: The parameter s has key 'elapsed'
    # Expected Result: The downloaded_bytes is added to progress message
    fd = FileDownloader({})
    s = {'status': 'downloading'}
    s['speed'] = 100
    s['eta'] = 123
    s['total_bytes'] = 200

# Generated at 2022-06-12 16:26:57.233137
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    _, tmp_filename = tempfile.mkstemp(prefix='youtube-dl-test-filedownloader-')
    class FakeYDL:
        params = {}
        def to_screen(self, *args, **kargs):
            pass
    fd = FileDownloader(FakeYDL(), None)

# Generated at 2022-06-12 16:27:07.447549
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """
    Test the report_progress method of FileDownloader
    """
    print('test_FileDownloader_report_progress ..')

    class TestFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            FileDownloader.__init__(self, *args, **kwargs)
            self.msgs = []

        def to_screen(self, msg, skip_eol=False):
            self.msgs.append(msg)

    fd = TestFileDownloader({})

    # first the simple case: no total_bytes and no downloaded_bytes

# Generated at 2022-06-12 16:27:20.000208
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # step 1
    print('step 1')
    d = FileDownloader({'ratelimit': 2.0})
    start = time.time()
    end = start + 100.0
    # step 2
    print('step 2')
    d.slow_down(start, end, 2000)
    # step 3
    print('step 3')
    d.slow_down(start, end, 2000)
    assert abs(time.time() - start - 2.0) < 0.1

    # step 4
    print('step 4')
    d = FileDownloader({'ratelimit': 2.0})
    start = time.time()
    end = start + 0.001
    # step 5
    print('step 5')
    d.slow_down(start, end, 2000)
    # step 6
    print('step 6')

# Generated at 2022-06-12 16:27:27.508761
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def try_utime(fname, last_modified_hdr):
        return FileDownloader.try_utime(fname, last_modified_hdr)

    class Info_dict(object):
        def __init__(self, headers):
            self.http_headers = headers

    # Test ISO 8601
    fname = 'foobar'
    last_modified_hdr = 'Thu, 29 Nov 2012 01:59:41 GMT'
    utime = try_utime(fname, last_modified_hdr)
    assert str(utime) == '1354287181.0'

    # Test RFC 1123
    last_modified_hdr = 'Thu, 29 Nov 2012 01:59:41 GMT'
    utime = try_utime(fname, last_modified_hdr)

# Generated at 2022-06-12 16:27:39.796994
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    print('Testing function slow_down...', end='')
    from .YoutubeDL.utils import encode_compat_str
    ydl = FakeYoutubeDL()
    dl = FileDownloader(ydl, {})
    dl.speed = lambda: 10
    dl.start = time.time()
    dl.temp_name('a')
    dl.slow_down(dl.start, None, 100)
    assert 100 == dl.ratelimit
    dl.slow_down(dl.start, None, 100000)
    assert 1000 == dl.ratelimit
    dl.slow_down(dl.start, None, 10)
    assert 100 == dl.ratelimit
    dl.ratelimit = None
    dl.slow_down(dl.start, None, 10)

# Generated at 2022-06-12 16:27:45.465823
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert(FileDownloader("YoutubeDL").undo_temp_name("test.part") == "test")
    assert(FileDownloader("YoutubeDL").undo_temp_name("test.ytdl") == "test")
    assert(FileDownloader("YoutubeDL").undo_temp_name("test") == "test")


# Generated at 2022-06-12 16:27:53.842044
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Test that try_utime parses correctly dates
    for last_modified_hdr in ['Sat, 15 Jul 2017 17:27:49 GMT',
                              'Fri, 26 May 2017 13:51:41 GMT']:
        filetime = FileDownloader.try_utime('filename', last_modified_hdr)
        assert filetime is not None
        assert type(filetime) == float

    # Tests that try_utime returns None when given a malformed date
    malformed_date = 'this is not a date'
    filetime = FileDownloader.try_utime('filename', malformed_date)
    assert filetime is None


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 16:28:19.194886
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def assert_utime(last_modified_hdr, expected_mtime, expected_result=True,
                     filename='dummy.txt'):
        fd = FileDownloader(
            {})
        result = fd.try_utime(filename, last_modified_hdr)
        if expected_mtime is None:
            assert result is expected_mtime
        else:
            # In python 3.2, utime uses microseconds
            # while time.time returns seconds
            # so we need to use assertAlmostEqual
            assertAlmostEqual(result, expected_mtime)
        if expected_result:
            assert os.path.getmtime(encodeFilename(filename)) == pytest.approx(result)

# Generated at 2022-06-12 16:28:22.649450
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    FileDownloader('', {}).report_file_already_downloaded('test')

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 16:28:35.742468
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import shutil
    import tempfile
    import datetime

    td = tempfile.mkdtemp()
    file_path = os.path.join(td, 'file1')

    # Create test file
    with open(file_path, 'w') as f:
        f.write('abcd')

    origin_utime = os.stat(file_path).st_mtime

    # Set new timestamp
    custom_utime = datetime.datetime(2000, 1, 1)
    fd = FileDownloader({'progress_hooks': []})
    fd.try_utime(file_path, custom_utime)

    # Check that the file timestamp was changed
    new_utime = os.stat(file_path).st_mtime
    assert new_utime != origin_utime


# Generated at 2022-06-12 16:28:41.993159
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def format_seconds(secs):
        return '00:00:%(seconds)02.f' % {
            'seconds': float(secs)}

    def format_eta(eta):
        return format_seconds(eta)

    def format_speed(speed):
        return '%(speed)10s' % {
            'speed': format_bytes(speed)}

    downloader = FileDownloader({
        'format': 'best', 'verbose': False,
        'simulate': True, 'quiet': True,
        'format_seconds': format_seconds,
        'format_eta': format_eta,
        'format_speed': format_speed,
    })


# Generated at 2022-06-12 16:28:54.651270
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """FileDownloader.download raises an error when not overwriting an existing file
    
    This test covers the following use case:
    - a file exists
    - we do not want to overwrite it
    - we are told to keep the file on disk
    """
    file_downloader = FileDownloader({ 'nooverwrites': True, 'keep_fragments': True })
    file_downloader.ydl = MockYoutubeDl()
    file_exists = os.path.exists
    os.path.exists = lambda path: True
    try:
        with pytest.raises(FileExistsError):
            file_downloader.download('file-does-not-matter', { 'id': 'id-does-not-matter' })
    finally:
        os.path.exists = file_exists


# Generated at 2022-06-12 16:29:05.581831
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # See [1] for details about the tests
    # [1] http://stackoverflow.com/questions/273192/python-unittest-testcase-execution-order-dependency/6928672#6928672
    fd = FileDownloader({})
    assert (fd.temp_name('example') == 'example.part')
    assert (fd.temp_name('example.mp4') == 'example.mp4.part')
    assert (fd.temp_name('example.en.srt') == 'example.en.srt.part')
    assert (fd.temp_name('example.part') == 'example.part')
    assert (fd.temp_name('example.part.mp4') == 'example.part.mp4.part')

# Generated at 2022-06-12 16:29:18.001409
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # [1] Test download with existing filename and nooverwrites = False
    #     Should return True
    params = {
        'outtmpl': os.path.join(os.path.dirname(__file__), 'test_FileDownloader', '%(id)s.%(ext)s'),
        'nooverwrites': False,
        'continuedl': False,
        'nopart': True,
        'ratelimit': None,
        'noprogress': False,
        'retries': 10,
        'buffersize': 1024,
        'noresizebuffer': False,
    }

    info_dict = {
        'id': 'test_video_id',
        'ext': 'mp4',
        'title': 'test_video_title',
    }


# Generated at 2022-06-12 16:29:30.784276
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import namedtuple
    from io import StringIO

    Status = namedtuple('Status', ['status', 'downloaded_bytes', 'total_bytes', 'total_bytes_estimate', 'eta', 'elapsed', 'speed'])
    buf = StringIO()
    fd = FileDownloader({'noprogress': True, 'outtmpl': '-'}, {'id': 'a'}, buf)

    def test(status):
        fd.report_progress(status._asdict())
        return buf.getvalue()

    def progress_len(status):
        return len(test(status))

    # Speed only
    assert progress_len(Status('downloading', None, None, None, None, None, 1)) == len('Unknown speed')

    # Speed and ETA

# Generated at 2022-06-12 16:29:37.262768
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    params = {'nopart': True}
    assert FileDownloader({}).temp_name('b') == 'b'
    assert FileDownloader(params).temp_name('b') == 'b'
    params['nopart'] = False
    assert FileDownloader(params).temp_name('a') == 'a.part'
    assert FileDownloader(params).temp_name('b') == 'b.part'



# Generated at 2022-06-12 16:29:46.615792
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def fd_try_utime_tester(input_string, expected_result):
        fd = FileDownloader(DummyYDL(), FakeDict())
        result = fd.try_utime(None, input_string)
        assert result == expected_result, 'Expected %r, got %r' % (expected_result, result)
    # File's last-modified time matches the last-modified header
    from datetime import datetime
    from email.utils import mktime_tz
    dt = datetime(2014, 8, 15, 12, 2, 48, tzinfo=FixedOffset(-120))
    t = int(mktime_tz(dt.timetuple()))
    fd_try_utime_tester(formatdate(t), t)
    # No last-modified header
    fd_try

# Generated at 2022-06-12 16:30:01.242001
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    ''' Mimic the context of unit test test_FileDownloader_report_file_already_downloaded from
        youtube_dl/YoutubeDL.py, as if it had been called.
    '''

    class MockYdl(object):
        def __init__(self):
            self.params = {}
            self.to_screen = self.to_screen_mock

        def to_screen_mock(self, msg):
            print(msg)

        def set_option(self, key, value):
            self.params[key] = value

    # Test that to_screen is called
    ydl = MockYdl()
    fd = FileDownloader(ydl)
    fd.report_file_already_downloaded('filename')


# Generated at 2022-06-12 16:30:06.265510
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # given
    fd = FileDownloader(DummyYDL(), {})
    given_filename = 'file.mp4'
    # when
    result = fd.temp_name(given_filename)
    # then
    expect_result = given_filename + '.part'
    assert expect_result == result
    


# Generated at 2022-06-12 16:30:16.817818
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader('ytdl', {}).temp_name('foo') == 'foo'
    assert FileDownloader('ytdl', {}).temp_name('foo.bar') == 'foo.part.bar'
    assert FileDownloader('ytdl', {}).temp_name('foo.bar') == 'foo.part.bar'
    assert FileDownloader('ytdl', {}).temp_name('foo.bar') == 'foo.part.bar'
    assert FileDownloader('ytdl', {'nopart': True}).temp_name('foo') == 'foo'
    assert FileDownloader('ytdl', {'nopart': True}).temp_name('foo.bar') == 'foo.bar'
    assert FileDownloader('ytdl', {}).temp_name('-') == '-'
    assert File

# Generated at 2022-06-12 16:30:26.485202
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class DummyFileDownloader:
        def __init__(self):
            self.params = {}

        def trouble(self, message):
            raise AssertionError('trouble: ' + message)

        def report_error(self, message):
            raise AssertionError('report_error: ' + message)

    # we ignore timezones
    TIMEZONE_OFFSET = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone

    class _TakenFrom(object):
        pass

    class TakenFrom(_TakenFrom):
        pass

    ff = FileDownloader(DummyFileDownloader())

    def _test(filename, last_modified_hdr, expected_time):
        _TakenFrom.last_modified_hdr = last_modified_hdr

# Generated at 2022-06-12 16:30:28.967844
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    assert FileDownloader(params=None, youtube_dl=None).report_file_already_downloaded("testfile")==None,"Unit test for method report_file_already_downloaded of class FileDownloader failed"


# Generated at 2022-06-12 16:30:32.038757
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """Unit test for method try_utime of class FileDownloader."""
    _test_FileDownloader_try_utime()



# Generated at 2022-06-12 16:30:45.194284
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import tempfile
    tmp = tempfile.NamedTemporaryFile()
    tmp_name = tmp.name
    tmp.close()
    fd = FileDownloader(FileDownloader.params)
    fd.params['nooverwrites'] = True
    d = fd.download(tmp_name, {'url': 'http://127.0.0.1/10M'})
    assert d == True
    d = fd.download(tmp_name, {'url': 'http://127.0.0.1/10M'})
    assert d == True
    fd.params['nooverwrites'] = False
    d = fd.download(tmp_name, {'url': 'http://127.0.0.1/10M'})
    assert d == True

# Generated at 2022-06-12 16:30:49.740828
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert 'Unknown' == FileDownloader.format_retries(float('inf'))
    assert '0' == FileDownloader.format_retries(0)
    assert '1' == FileDownloader.format_retries(1)
    assert '2' == FileDownloader.format_retries(2)

# Generated at 2022-06-12 16:30:57.570427
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class FD(FileDownloader):
        def real_download(self, filename, info):
            pass

    fd = FileDownloader({})
    fd.report_destination = types.MethodType(lambda self, filename: None, fd)

    # Test for None
    fd.to_screen = lambda *args: None
    fd.try_utime(filename='dummy', last_modified_hdr=None)
    fd.to_screen = lambda *args: args[0]
    assert fd.try_utime(filename='dummy', last_modified_hdr=None) is None

    # Test for some random date
    fd.to_screen = lambda *args: None

# Generated at 2022-06-12 16:31:09.380330
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import ctypes
    ctypes.windll.kernel32.SetConsoleOutputCP(65001)

# Generated at 2022-06-12 16:31:29.604157
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(None) == 'inf'
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    assert FileDownloader.format_retries(-1) == 'inf'
    assert FileDownloader.format_retries(float('NaN')) == 'inf'
    assert FileDownloader.format_retries(0.0) == '0'
    assert FileDownloader.format_retries(0.5) == '0'
    assert FileDownloader.format_retries(1.0) == '1'
    assert FileDownloader.format_retries(1.5) == '1'
    assert FileDownloader.format_retries(2.0) == '2'
    assert FileDownloader.format_retries(2.5) == '2'


# Generated at 2022-06-12 16:31:40.959388
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def _run(dl_speed, rate_limit, sleep_time, max_sleep_time, available_bytes, byte_counter, retries):
        fd = FileDownloader({'ratelimit': rate_limit, 'retries': retries})
        fd.slow_down = lambda *a, **ka: (a, ka)
        fd.retry = lambda *a, **ka: (a, ka)
        return fd.test_slow_down(dl_speed, sleep_time, max_sleep_time, available_bytes, byte_counter)

    def _test(expected, *args):
        assert expected == _run(*args)

    _test(((2.0,), {'byte_counter': 0}), 0, 1024, 0.0, 5.0, 1, 0)

# Generated at 2022-06-12 16:31:52.437337
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import io
    import time
    import unittest
    from .utils import make_fake_file_downloader
    from .extractor.youtube import YoutubeIE

    got_data = False

    def get_data(downloader, url):
        nonlocal got_data
        got_data = True
        return io.BytesIO(b'foobar')

    def make_fake_downloader():
        fd = make_fake_file_downloader(YoutubeIE(), {})
        fd.get_url = get_data
        fd.is_test = True
        fd.ydl.params['ratelimit'] = 3
        return fd

    def teardown():
        if got_data:
            raise Exception('FileDownloader.slow_down() was not called')

    fd = make_fake_downloader()

# Generated at 2022-06-12 16:31:57.840193
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test temp_name method
    assert FileDownloader.undo_temp_name('test.part') == 'test'
    assert FileDownloader.undo_temp_name('test') == 'test'
    assert FileDownloader.undo_temp_name('test.part.part') == 'test.part'

FileDownloader.test_Download = Download
FileDownloader.test_DownloadContextManager = DownloadContextManager
FileDownloader.test_DownloadRetry = DownloadRetry


# Generated at 2022-06-12 16:32:10.122931
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class TestFD(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_screen_calls = []
        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)
    params = {}
    fd = TestFD(params)
    fd.report_file_already_downloaded(u'abc')
    assert fd.to_screen_calls == [u'[download] abc has already been downloaded']
    # Now unicode
    fd.to_screen_calls = []
    fd.report_file_already_downloaded(u'\u2665')

# Generated at 2022-06-12 16:32:18.377578
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """
    Returns:
        str: The unit test result.
    """
    import unittest
    test = unittest.TestCase()
    logfile = StringIO()
    test_obj = FileDownloader(params={'noprogress':True},
                              outtmpl='/dev/null',
                              log_template='%(asctime)s %(message)s')
    test_obj.to_screen = logfile.write

    test_obj.report_progress({'status':'finished',
                              'total_bytes': '1048576',
                              'elapsed':'8.042638'})
    test.assertEqual(logfile.getvalue().strip(),
                     '[download] 100% of 1.00 MiB in 8.042638 seconds')


# Generated at 2022-06-12 16:32:30.755001
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # We cannot use FileDownloader.slow_down() here directly because
    # we need to mock os.urandom() and time.time(). With the
    # unittest.mock.patch() decorator they become unavailable, so we
    # need to use the FileDownloader.slow_down() method from a subclass.
    class Downloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(Downloader, self).__init__(*args, **kwargs)
            self.sleep_count = 0
            self.speed_sleep_time = 0.0

        def sleep(self, t):
            self.sleep_count += 1
            self.speed_sleep_time += t

    downloader = Downloader(params={'ratelimit': 1000000})

    # Test 1: Downloads too fast: should

# Generated at 2022-06-12 16:32:41.372979
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockTime(object):
        def __init__(self):
            self.time_returns = []
            self.sleep_called = 0

        def time(self):
            return self.time_returns.pop(0)

        def sleep(self, t):
            assert t > 0, t
            self.sleep_called += 1

    mtime = MockTime()
    downloader = FileDownloader({'ratelimit': 2097152})
    downloader.to_screen = lambda *args, **kargs: None
    downloader.to_stderr = lambda *args, **kargs: None

    def _record_call(name):
        def _recorder(*args, **kargs):
            setattr(mtime, name + '_called', True)
        return _recorder


# Generated at 2022-06-12 16:32:52.821156
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    ydl = YoutubeDL()
    d = FileDownloader(ydl, {})
    eq_(d.undo_temp_name(d.temp_name('aaa.txt')), 'aaa.txt')
    eq_(d.undo_temp_name('aaa.txt'), 'aaa.txt')
    eq_(d.undo_temp_name(d.temp_name('aaa')), 'aaa')
    eq_(d.undo_temp_name('aaa'), 'aaa')
    eq_(d.undo_temp_name('aaa.part'), 'aaa.part')
    eq_(d.undo_temp_name('aaa.part.part'), 'aaa.part.part')
    eq_(d.undo_temp_name('aaa.partpart'), 'aaa.partpart')
    # test with paths

# Generated at 2022-06-12 16:33:05.134945
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class FakeFD:
        def __init__(self, bytes):
            self.bytes = bytes
            self.downloaded_bytes = 0
            self.params = {
                'ratelimit': '1k',
                'retries': float('inf'),
                'nooverwrites': False,
                'continuedl': True,
                'noprogress': False,
                'verbose': False,
                'nooverwrites_ignore': None,
                'sleep_interval': None,
                'max_sleep_interval': None,
            }

        def to_screen(self, msg):
            print(msg)

        def trouble(self, msg):
            print('ERROR ' + msg)

        def report_warning(self, msg):
            print('WARNING ' + msg)
