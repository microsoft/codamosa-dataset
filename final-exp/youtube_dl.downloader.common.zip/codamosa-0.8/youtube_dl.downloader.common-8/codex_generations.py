

# Generated at 2022-06-12 16:24:21.243942
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class FileDownloaderTest(FileDownloader):
        def __init__(self, param):
            FileDownloader.__init__(self, param)
#             self.trouble = lambda *args, **kargs: FileDownloader.trouble(self, *args, **kargs)
        def real_download(self, filename, info_dict):
            self.report_destination(filename)
            return False
        def report_error(self, msg):
            print('ERROR: ' + msg)
        
        def trouble(self, msg):
            print('Trouble: ' + msg)
        
    def _hook_progress(status):
        return
        print ('hook', status)
    fd = FileDownloaderTest({})
    fd.add_progress_hook(_hook_progress)
    fd.download

# Generated at 2022-06-12 16:24:30.445395
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    """Unit test for report_file_already_downloaded function of FileDownloader class"""
    ydl = YoutubeDL(params={'verbose':False})
    ydl.to_screen('[download] %s has already been downloaded' % 'filename')
    ydl.to_screen('[download] %s has already been downloaded' %
                  unicode_to_printable('\u1234'))
    ydl.to_screen('[download] %s has already been downloaded' % '\xe9')

# Generated at 2022-06-12 16:24:41.111590
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    with tempfile.TemporaryDirectory() as tmpdir:
        ydl = YoutubeDl(common_args(tmpdir))

        fd = FileDownloader(ydl, {
            'nooverwrites': True,
            'noprogress': True,
        })

        fd.report_progress({
            'status': 'finished',
            'total_bytes': 5678,
        })
        assert '[download] 100% of 5.37KiB' in ydl.msgs

        fd.report_progress({
            'status': 'finished',
            'total_bytes': 12345678,
            'elapsed': 12.345,
        })
        assert '12.35 seconds' in ydl.msgs


# Generated at 2022-06-12 16:24:53.251288
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    ## Arrange ##
    fd = FileDownloader({})
    fd.report_destination = Mock()
    fd.report_progress = Mock()
    fd.download = Mock(return_value=True)

    filename = Mock()
    info_dict = Mock()

    ## Act ##
    result = fd.download(filename, info_dict)

    ## Assert ##
    fd.report_destination.assert_called_with(filename)
    fd.report_progress.assert_called_with(info_dict)
    fd.download.assert_called_with(filename, info_dict)
    assert result == True
## Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-12 16:24:59.644433
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    '''Unit test for method report_progress of class FileDownloader'''
    # Create object
    ydl = YoutubeDL()
    d = FileDownloader(ydl, {})

    # To screen
    d._report_progress_prev_line_length = None
    d.report_progress({
        'status': 'finished',
    })
    d.report_progress({
        'status': 'downloading',
        'total_bytes': 1,
        'downloaded_bytes': 0,
        'speed': 0.1,
        'eta': 120.0,
        'elapsed': 0.0,
    })

    # To console title
    d.report_progress({
        'status': 'finished',
    })

# Generated at 2022-06-12 16:25:05.967992
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    """Test the logic for determining a suitable default filename"""
    test_cases = [
        # Retries, Expected output
        [1, '1'],
        [2.0, '2'],
        [float('inf'), 'inf'],
        [-1, 'inf'],
    ]
    for retries, expected in test_cases:
        assert FileDownloader.format_retries(retries) == expected



# Generated at 2022-06-12 16:25:12.303303
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import os
    import shutil
    import time

    fd, temp_filename = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.write(b'\x00\x10\x83')
    f.close()
    # File should be 3 bytes big
    assert os.stat(encodeFilename(temp_filename)).st_size == 3
    # Create a FileDownloader instance and call try_utime function
    downloader = FileDownloader({})
    filetime = downloader.try_utime(temp_filename, 'Thu, 19 Jun 2014 09:53:53 GMT')
    assert time.gmtime(filetime) == time.gmtime(1403219233)
    # Remove temp file
    os.unlink(encodeFilename(temp_filename))

# Generated at 2022-06-12 16:25:22.484866
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    """Works only with Python 3"""
    fd = FileDownloader({})
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1.1) == '1'
    assert fd.format_retries(2.9) == '2'
    assert fd.format_retries(float('inf')) == 'inf'

    fd = FileDownloader({'retries': 5})
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(6.2) == '5'
    assert fd.format_retries(3.7) == '3'



# Generated at 2022-06-12 16:25:30.535455
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def status_dict_to_str(status):
        if status.get('status') == 'downloading':
            if status.get('total_bytes') is not None:
                return '%(downloaded_bytes)s of %(total_bytes)s at %(speed)s' % status
            elif status.get('total_bytes_estimate') is not None:
                return '%(downloaded_bytes)s of ~%(total_bytes_estimate)s at %(speed)s' % status
            else:
                return '%(downloaded_bytes)s at %(speed)s' % status
        elif status.get('status') == 'finished':
            if status.get('total_bytes') is not None:
                return '%(total_bytes)s in %(elapsed)s seconds' % status


# Generated at 2022-06-12 16:25:43.278794
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test 1: normal behavior
    fd = FileDownloader(FakeYoutubeDL(), params={'ratelimit': 25.0})
    start = time.time()
    for i in range(4):
        fd.slow_down(start, start + 0.1 * i, 4 * i)
        assert time.time() - start <= (0.1 * i + 0.1)
    # Test 2: ratelimit == 0
    fd = FileDownloader(FakeYoutubeDL(), params={'ratelimit': 0})
    start = time.time()
    for i in range(4):
        fd.slow_down(start, start + 0.1 * i, 4 * i)
        assert time.time() - start <= (0.1 * i)
    # Test 3: ratelimit == None
    fd = FileDownloader

# Generated at 2022-06-12 16:25:59.493248
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    pass
# End of unit test for FileDownloader.slow_down



# Generated at 2022-06-12 16:26:12.051006
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    # best_block_size is a static method, we need to define class with staticmethod
    class TestClass:

        @staticmethod
        def best_block_size(elapsed_time, bytes):
            """Calculate the best block size for download."""
            new_min = max(bytes / 2.0, 1.0)
            new_max = min(max(bytes * 2.0, 1.0), 4194304)  # Do not surpass 4 MB
            if elapsed_time < 0.001:
                return int(new_max)
            rate = bytes / elapsed_time
            if rate > new_max:
                return int(new_max)
            if rate < new_min:
                return int(new_min)
            return int(rate)

    # Check of the block size being in the range of [1, 4

# Generated at 2022-06-12 16:26:17.763161
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(None, {'continuedl': False})

    assert fd.calc_eta(0, 0, 0, None) is None
    assert fd.calc_eta(5, 5, 0, None) is None
    assert fd.calc_eta(0, 0, 5, None) is None
    assert fd.calc_eta(10, 0, 0, None) is None



# Generated at 2022-06-12 16:26:31.458062
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import re

    fd = FileDownloader({})

    filetime = None
    filetime = fd.try_utime('a', "Mon, 07 Apr 2008 16:00:00 GMT")
    assert filetime == 1207645600.0

    filetime = None
    filetime = fd.try_utime('a', "Mon, 07 Apr 2008 16:00:00 GMT+1000")
    assert filetime == 1207645600.0

    filetime = None
    filetime = fd.try_utime('a', "Mon, 07 Apr 2008 16:00:00 GMT-1000")
    assert filetime == 1207645600.0

    filetime = None
    filetime = fd.try_utime('a', "Mon, 7 Apr 2008 16:00:00 GMT+1000")
    assert filetime == 1207

# Generated at 2022-06-12 16:26:42.709338
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Tests the try_utime method in
    # FileDownloader
    # These tests are not in test_FileDownloader since
    # it calls os.utime
    # TODO New class for testing here?
    # Note: Using os.environ.pop('TZ', None) does not
    # work with Python 3
    old_tz = None

# Generated at 2022-06-12 16:26:56.313023
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from io import StringIO

    def _report_progress(s):
        for_human = s.get('_for_human', False)
        if for_human:
            out = s['_out_human']
            expected = s['_expected_human']
        else:
            out = s['_out']
            expected = s['_expected']
        assert out == expected, '\n%r\n!=\n%r' % (out, expected)
        if not for_human:
            # Test that the output is human-friendly too
            s['_out_human'] = out
            s['_for_human'] = True
            s['_expected_human'] = s['_expected_human']
            _report_progress(s)

    params = {'noprogress': False}

    fd = FileDownload

# Generated at 2022-06-12 16:27:02.751838
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(Param({}))
    assert downloader.temp_name('foobar') == 'foobar.part'
    assert downloader.temp_name('c:\\foo\\bar') == 'c:\\foo\\bar.part'
    assert downloader.temp_name('-') == '-'
    assert downloader.temp_name(10) == '10'



# Generated at 2022-06-12 16:27:07.505406
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    d = FileDownloader()
    tests = [
        (0, '0'),
        (10, '10'),
        (10240, '10240'),
        (10240, '10K'),
        (10485760, '10M'),
        (1073741824, '10G'),
        (1099511627776, '10T'),
        (1125899906842624, '10P'),
        (1152921504606846976, '10E'),
        (1180591620717411303424, '10Z'),
        (1208925819614629174706176, '10Y'),
        (0.1, '100m'),
        (0.01, '10m'),
        (0.0001, '100u'),
    ]

# Generated at 2022-06-12 16:27:15.906880
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test a normal case
    fd = FileDownloader({})
    assert fd.undo_temp_name('test.part') == 'test'
    # Test a case that should not happen
    fd = FileDownloader({})
    assert fd.undo_temp_name('test') == 'test'
    # Test a case that should not happen
    fd = FileDownloader({})
    assert fd.undo_temp_name('test.part2') == 'test.part2'


# Generated at 2022-06-12 16:27:25.475100
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    ydl = YoutubeDL()
    ydl.params['nopart'] = True
    fd = FileDownloader(ydl, {
        'id': 'test',
        'url': 'http://localhost/file'
    })
    assert fd.temp_name('test.txt') == 'test.txt'
    assert fd.temp_name('test.txt.part') == 'test.txt.part'
    assert fd.temp_name(os.path.join('test', 'test.txt')) == os.path.join('test', 'test.txt')
    ydl.params['nopart'] = False
    assert fd.temp_name('test.txt') == 'test.txt.part'
    assert fd.temp_name('test.txt.part') == 'test.txt.part'
   

# Generated at 2022-06-12 16:27:45.840888
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    # TO DO:
    return True

# Generated at 2022-06-12 16:27:55.012939
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class TestFD(FileDownloader):
        def __init__(self, params):
            self._sleep_time = None
            self._sleep_args = None
            FileDownloader.__init__(self, params)

        def report_error(self, *args, **kargs):
            assert False

        def to_screen(self, *args, **kargs):
            pass

        def to_console_title(self, *args, **kargs):
            pass

        def sleep(self, time):
            self._sleep_time = time

        def _debug_cmd(self, args, exe=None):
            pass

    dw = TestFD({
        'sleep_interval': 10.0,
        'max_sleep_interval': 15.0,
    })

# Generated at 2022-06-12 16:28:06.977210
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import datetime
    import time
    import email.utils
    import tempfile
    import os
    fd = FileDownloader(None, params = {})
    f = tempfile.NamedTemporaryFile(delete = False)
    f.write(b'abc')
    f.close()

    def tst(date_str, exp_timestamp):
        date_str2 = email.utils.formatdate(
            time.mktime(time.strptime(date_str, "%Y-%m-%d %H:%M:%S")),
            usegmt=True)
        assert date_str2.endswith(date_str[-5:])
        fd.try_utime(f.name, date_str2)
        assert os.path.getmtime(f.name) == exp

# Generated at 2022-06-12 16:28:17.561149
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import defaultdict
    from io import BytesIO
    from io import StringIO

    # Set up a fake sys.stderr for controlling what is written to it
    sys.modules['sys'].stderr = StringIO()
    sys.modules['os'].linesep = '\n'

    # Set up fake time module
    class fake_time(object):
        def __init__(self):
            self.counter = 0
        def time(self):
            self.counter += 1
            return self.counter

    sys.modules['time'] = fake_time()

    # Set up a fake sys.stdout for controlling what is written to it
    sys.modules['sys'].stdout = BytesIO()

    # Set up a fake params dictionary
    class fake_params(object):
        """Fake params object"""
       

# Generated at 2022-06-12 16:28:30.562248
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    ydl = YoutubeDL()
    fd = FileDownloader(ydl, 'info', params={})
    assert fd.temp_name("filename.ext") == "filename.part"
    assert fd.temp_name("filename") == "filename.part"
    assert fd.temp_name("filename.part") == "filename.part"
    assert fd.temp_name("filename.mp3") == "filename.part.mp3"
    assert fd.temp_name("filename.mp4.wav") == "filename.part.mp4.wav"
    assert fd.temp_name("filename.ext") == "filename.part"
    assert fd.temp_name("/path/filename.ext") == "/path/filename.part"

# Generated at 2022-06-12 16:28:41.216754
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    class MockFileDownloader(FileDownloader):
        def __init__(self):
            self.file_descriptor = [None]
            self.bytecounter = [0]

        def real_download(self, filename, info_dict):
            self.file_descriptor[0] = open(filename, 'wb')

        def slow_down(self, start_time, now, byte_counter):
            self.bytecounter[0] = byte_counter
            FileDownloader.slow_down(self, start_time, now, byte_counter)

    # Create mock
    fd = MockFileDownloader()
    fd.params = {'ratelimit': 1024}  # 1 KiB/s
    info_dict = {}
    filename = 'some_file.flv'

    # Download

# Generated at 2022-06-12 16:28:50.523867
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    do = FileDownloader(params={})
    def assertEqual(a, b):
        assert a == b, 'Expected %s but got %s' % (a, b)
    assertEqual(do.format_retries(float('inf')), 'inf')
    assertEqual(do.format_retries(1.5), '2')
    assertEqual(do.format_retries(1), '1')
    assertEqual(do.format_retries(0), '0')
test_FileDownloader_format_retries()


# Generated at 2022-06-12 16:28:59.689549
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    """
    Test the method format_retries of the class FileDownloader.
    """

    fd = FileDownloader(YoutubeDL({}))

    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(10) == '10'
    assert fd.format_retries(float('inf')) == 'inf'
    try:
        fd.format_retries('fail')
    except AssertionError:
        pass
    else:
        raise Exception('Must fail')



# Generated at 2022-06-12 16:29:06.298623
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """ Simple test for method download of class FileDownloader.
        Creates a FileDownloader object, downloads a YouTube video
        (http://youtu.be/pJk0p-98Xzc), and counts the number of its lines.
    """
    # Create a FileDownloader object
    class MyFileDowloader(FileDownloader):
        pass
    fd = MyFileDowloader({})
    # Set the video URL
    video_url = 'http://youtu.be/pJk0p-98Xzc'
    # Get the filename from the FileDownloader object
    video_filename = fd.prepare_filename(video_url)
    # Test the download
    assert(fd.download(video_filename, video_url))
    # Count the number of lines
    f = open(video_filename, 'r')

# Generated at 2022-06-12 16:29:18.804480
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-12 16:31:19.897552
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import pytest
    fd = FileDownloader(DummyYDL())
    fd.params['ratelimit'] = 576000
    fd.params['retries'] = 1
    fd.report_retry = DummyReportRetry()
    fd.trouble = DummyTrouble()
    fd.to_screen = DummyToScreen()
    fd.report_warning = DummyReportWarning()
    with open(os.path.join(sys.path[0], 'testid.txt')) as file:
        data = file.read()
    stream = json.loads(data)
    (stream_url, stream_size) = pick_video_format(stream['formats'],
                                                  fd.params['format'])
    stream_url += '&byte='
    start_time

# Generated at 2022-06-12 16:31:30.196678
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Check that try_utime works and that it sets the modification time (mtime)
    # of the file to a specified date (1990-01-01)
    dl = FileDownloader({})
    dl.params['noprogress'] = True
    tmpfilename = mktemp()
    open(tmpfilename, 'wb').write(b'foo')
    dl.try_utime(tmpfilename, 'Mon, 01 Jan 1990 00:00:00 +0000')
    assert time.gmtime(os.stat(tmpfilename).st_mtime)[:6] == (1990, 1, 1, 0, 0, 0)
    os.unlink(tmpfilename)


# Generated at 2022-06-12 16:31:31.607917
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader({})
    fd.report_file_already_downloaded('filename')

# Generated at 2022-06-12 16:31:40.199844
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None)
    assert fd.undo_temp_name('a') == 'a'
    assert fd.undo_temp_name('b.part') == 'b'
    assert fd.undo_temp_name('c.part.part') == 'c.part'
    assert fd.undo_temp_name('d.part.abc') == 'd.part.abc'
    assert fd.undo_temp_name('e.partx') == 'e.partx'



# Generated at 2022-06-12 16:31:43.281582
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader(FakeYDL())
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(1) == '1.0'
    assert fd.format_retries(1.1) == '1.1'
    assert fd.format_retries(0.1) == '0.1'
    assert fd.format_retries(0) == '0.0'
    assert fd.format_retries(-1) == '-1.0'



# Generated at 2022-06-12 16:31:54.461243
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    def test_block_sizes(block_size, elapsed_time, bytes, expected):
        fd = FileDownloader(None, params={})
        actual = fd.best_block_size(elapsed_time, bytes)
        assert expected == actual, 'Error in best_block_size' \
                                            '(%s, %s, %s): expected %s, got %s' % \
                                            (block_size, elapsed_time, bytes,
                                            expected, actual)

    test_block_sizes('1k', 0.04, 43981, 8)
    test_block_sizes('1k', 0.3, 43981, 10)
    test_block_sizes('1k', 0.04, 43981, 8)

# Generated at 2022-06-12 16:32:01.217590
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    ydl = FakeYdl({'nooverwrites': True, 'verbose': True})
    fd = FileDownloader(ydl, {})
    fd.report_file_already_downloaded('hi')
    assert ydl.msgs[-1] == '[download] %s has already been downloaded' % 'hi'

# How to run unit test by pytest
# 1. Open Anaconda command prompt in your virtual environment
# 2. pip uninstall pytest-cov
# 3. pip install pytest
# 4. pytest --cov youtube_dl/extractor/test_FileDownloader.py
# 5. pytest --cov youtube_dl/extractor/test_FileDownloader.py --cov-report term-missing
# 6. pytest --cov youtube_dl/extractor/test_FileDownload

# Generated at 2022-06-12 16:32:12.469849
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import datetime
    from collections import OrderedDict

    class FakeYDL:
        def to_screen(self, *args, **kargs):
            self._screen_str = args[0]

        def to_console_title(self, *args, **kargs):
            self._title_str = args[0]

    fd = FileDownloader(FakeYDL())

    # Test the diffent statuses
    status_msgs = OrderedDict([
        ('downloading', '100% of 100 at 10 ETA 01:00'),
        ('finished', '100% of 100 in 01:00'),
        ('error', 'ERROR'),
    ])

# Generated at 2022-06-12 16:32:18.795792
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Simple test: no speed, no eta, no total bytes
    s = {
        'status': 'downloading',
        'filename': 'some_video.mp4',
        'downloaded_bytes': 600,
        'elapsed': 2.1
    }
    output = FileDownloader.format_percent(s['downloaded_bytes'], s['elapsed'])
    assert output == '23.1%'

    # With eta and speed
    s['speed'] = 25.5
    s['eta'] = 15
    output = FileDownloader.format_percent(s['downloaded_bytes'], s['elapsed'], s['eta'], s['speed'])
    assert output == '23.1% of ~523 at 25.5/s ETA 13s'

    # With total_bytes

# Generated at 2022-06-12 16:32:26.682378
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fields = {"date": "Sun, 23 Aug 2015 15:07:06 GMT", "elapsed": 0.0,
              "eta": None, "speed": 0.0, "status": "finished",
              "total_bytes": None, "filename": "test.txt",
              "downloaded_bytes": 0}
    fd = FileDownloader()
    fd.to_screen = print
    fd.try_utime('test.txt', fields['date'])
