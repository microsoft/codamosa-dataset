

# Generated at 2022-06-12 16:23:56.437014
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def test_format(fmt):
        return time.strptime('8 '+fmt, '%d '+fmt)[8]
    assert test_format('%Y') == 0
    assert test_format('%m') == 8
    assert test_format('%d') == 8
    assert test_format('%H') == 0
    assert test_format('%M') == 0
    assert test_format('%S') == 0
    assert test_format('%Y-%m-%dT%H:%M:%S.%fZ') == 0
    assert test_format('%Y%m%d%H%M%S') == 0
    assert test_format('%Y%m%d%H%M%S.%f') == 0


# Generated at 2022-06-12 16:24:08.591875
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader(FakeYDL(), {'sleep-interval': 0})
    assert(fd.calc_eta(0, 1, 0) == None)
    assert(fd.calc_eta(0, 1, 1) == None)
    assert(fd.calc_eta(0, 1, 10) == 0)
    assert(fd.calc_eta(0, 10, 100) == 9)
    assert(fd.calc_eta(0, 10, 110) == 9)
    assert(fd.calc_eta(0, 10, 121) == 8)
    assert(fd.calc_eta(0, 10, 120) == 9)
    assert(fd.calc_eta(0, 1, 10) == 0)

# Generated at 2022-06-12 16:24:18.555513
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    d = FileDownloader(YoutubeDL({}), None)
    assert d.parse_bytes('') is None
    assert d.parse_bytes('a') is None
    assert d.parse_bytes('3') == 3
    assert d.parse_bytes('a5') is None
    assert d.parse_bytes('5a') is None
    assert d.parse_bytes('.') is None
    assert d.parse_bytes('5.') == 5
    assert d.parse_bytes('.5') == 0
    assert d.parse_bytes('3.5') == 3
    assert d.parse_bytes('3.5a') is None
    assert d.parse_bytes('3.5.4') is None
    assert d.parse_bytes('4.3.5.4') is None

# Generated at 2022-06-12 16:24:31.893545
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import shutil, tempfile

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:24:42.324475
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockProgress(object):
        def __init__(self, start, now, bytes):
            self.start = start
            self.now = now
            self.bytes = bytes

        def get(self, name, default=None):
            if name == 'start_time':
                return self.start
            if name == 'now':
                return self.now
            if name == 'downloaded_bytes':
                return self.bytes
            return default

    class DummyYDL(object):
        def __init__(self, params=None):
            self.params = params or {}

        def to_screen(self, msg):
            pass

    def check(expected_sleep_time, params=None, start=None, now=None, bytes=None):
        fd = FileDownloader(DummyYDL(params), params)


# Generated at 2022-06-12 16:24:54.844123
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Here we need to create a FileDownloader object that has a download method
    # since the real download method will have been replaced with a _do_download_test
    # method

    # So we create a FileDownloader object, and we create a method "download"
    # on it since there is not one
    fd = FileDownloader({})
    def download(self, filename, info_dict):
        # By default we do nothing
        pass
    fd.download = types.MethodType(download, fd)

    # Now we create the _do_download_test method
    def _do_download_test(self, filename, info_dict):
        # Here we just call the download method
        self.download(filename, info_dict)
        # And we return True because the test is successful
        return True
    fd._do_

# Generated at 2022-06-12 16:24:59.600180
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """Test FileDownloader.try_utime()."""
    import doctest
    doctest.testmod(sys.modules[__name__])

if __name__ == '__main__':
    test_FileDownloader_try_utime()

# Generated at 2022-06-12 16:25:09.166433
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    global _FAKE_TIME
    _FAKE_TIME = 0
    fd = FileDownloader(params={
        'max_sleep_interval': 2,
        'min_sleep_interval': 1,
    })
    # Speed above rate limit
    fd.slow_down(1, 3, 1000, 1001)
    assert _FAKE_TIME == 1
    # Speed below rate limit
    _FAKE_TIME = 0
    fd.slow_down(1, 3, 1000, 1000)
    assert _FAKE_TIME == 0
    # Download speed not known, should not sleep
    _FAKE_TIME = 0
    fd.slow_down(1, 3, 0, 512)
    assert _FAKE_TIME == 0
    # Rate limit not set, should not sleep

# Generated at 2022-06-12 16:25:20.916636
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import datetime
    import time as timemodule
    # Mock os.utime and datetime.datetime.strptime
    orig_utime = FileDownloader.try_utime.func_globals['os'].utime

# Generated at 2022-06-12 16:25:27.417566
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Prepare a FileDownloader instance
    fd = FileDownloader(params={
        'ratelimit': 1234,
    })
    now = time.time()
    # Test when download speed is too fast (must sleep)
    sleep_time = fd.slow_down(now - 2, now, 2 * 1024 * 1024)
    assert sleep_time > 0
    # Test when download speed is faster than ratelimit, but less than 2x ratelimit (must not sleep)
    sleep_time = fd.slow_down(now - 2, now, 1.5 * 1024 * 1024)
    assert sleep_time == 0
    # Test when download speed is slower than ratelimit (must not sleep)
    sleep_time = fd.slow_down(now - 2, now, 512 * 1024)
    assert sleep_time == 0
    # Test when

# Generated at 2022-06-12 16:25:47.862567
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import unittest

    class MockTime:
        def __init__(self):
            self.time = time.time()

        def __call__(self):
            return self.time

        def step(self):
            self.time += 1

    class MockFileDownloader(FileDownloader):
        def __init__(self, params):
            self.ydl = object()
            self.params = params
            self._sleep_count = 0

        def sleep(self, secs):
            self._sleep_count += 1

    class TestFileDownloaderSlowDown(unittest.TestCase):
        def setUp(self):
            self.time = MockTime()

        def test_no_rate_limit(self):
            fd = MockFileDownloader({'ratelimit': None})

# Generated at 2022-06-12 16:25:53.679336
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():

    f = FileDownloader(FakeYDL())
    assert f.undo_temp_name('foo.part') == 'foo'
    assert f.undo_temp_name('foo.part.part') == 'foo.part'
    assert f.undo_temp_name('foo') == 'foo'
    assert f.undo_temp_name('foo.bar') == 'foo.bar'
    assert f.undo_temp_name('foo.bar.part') == 'foo.bar'



# Generated at 2022-06-12 16:26:06.264240
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Create an instance of class FileDownloader
    fd = FileDownloader(params={})

    # A dictionary containing information of the download
    s = {
        'status': 'finished',
        'total_bytes': 100,
        'downloaded_bytes': 50,
        'speed': 3,
    }

    # Adding of progress_hook which will run on progress reports
    calls = []
    def progress_hook(status):
        called.append(status)

    fd.add_progress_hook(progress_hook)

    # Testing report_progress with the given information
    fd.report_progress(s)
    # Test if calls is not empty
    assert calls is not None
    # Test if calls is a dictionary
    assert isinstance(calls[0], dict)
    # Test if calls is the same information as s
   

# Generated at 2022-06-12 16:26:17.258158
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from io import BytesIO
    from tempfile import mkstemp
    from datetime import datetime
    from time import mktime
    from youtube_dl.downloader.FileDownloader import FileDownloader

    def try_utime(a, b):
        fd = FileDownloader(None)
        return fd.try_utime(a, b)

    fd, filename = mkstemp(prefix='test_utime')
    os.close(fd)

    os.utime(filename, (1, 2))
    assert os.stat(filename).st_mtime in (1, 2)

    assert try_utime(filename, None) is None
    assert os.stat(filename).st_mtime in (1, 2)

    assert try_utime(filename, '0') == 0
    assert os.stat

# Generated at 2022-06-12 16:26:30.810521
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1.5') == 1
    assert FileDownloader.parse_bytes('-1.5') == -1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('16K') == 16*1024
    assert FileDownloader.parse_bytes('1M') == 1024*1024
    assert FileDownloader.parse_bytes('1Gi') == 1024**3
    assert FileDownloader.parse_bytes('1GiB') == 1024**3
    assert FileDownloader.parse_bytes('1Ti') == 1024**4
    assert FileDownloader.parse_bytes('1TiB') == 1024**4
    assert FileDownloader.parse

# Generated at 2022-06-12 16:26:42.240085
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    args = [
        {'start': 1, 'now': 1, 'current': 0, 'total': 10},
        {'start': 1, 'now': 1, 'current': 10, 'total': 10},
        {'start': 1, 'now': 1, 'current': 0, 'total': 0},
        {'start': 1, 'now': 1, 'current': 1, 'total': 0},

    ]
    if sys.platform.startswith('win'):
        return
    else:
        expecteds = [
            None,
            1,
            None,
            None,

        ]
    assert len(args)==len(expecteds)
    assert len(args)==len(expecteds)
    for arg , expected in zip(args, expecteds):
        result = FileDownloader.calc_speed

# Generated at 2022-06-12 16:26:55.580956
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def _check_temp_name(params, expect):
        fd = FileDownloader(params)
        if expect == '-':
            if fd.temp_name('-') != expect:
                raise AssertionError('Temp name of - should be -, not %r' % fd.temp_name('-'))
        else:
            if fd.temp_name(expect) != expect + '.part':
                raise AssertionError('Temp name of %r should be %r, not %r' % (expect, expect + '.part', fd.temp_name(expect)))
    for flag in [True, False]:
        _check_temp_name({'continuedl': flag, 'nopart': True}, '-')

# Generated at 2022-06-12 16:27:06.587627
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(0, 0) == 1
    assert fd.best_block_size(0, 1) == 1
    assert fd.best_block_size(1, 2) == 2
    assert fd.best_block_size(2.0, 4.0) == 4
    assert fd.best_block_size(3.0, 4.0) == 4
    assert fd.best_block_size(0.8, 1.6) == 1
    assert fd.best_block_size(5.0, 10.0) == 8
    assert fd.best_block_size(15.0, 30.0) == 16
    assert fd.best_block_size(9.0, 18.0) == 16
    assert f

# Generated at 2022-06-12 16:27:18.031677
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    t = TestDownloader()
    dl = FileDownloader(t.params)

# Generated at 2022-06-12 16:27:22.011788
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(1.0) == '1'
    assert FileDownloader.format_retries(0.0) == 'inf'
    assert FileDownloader.format_retries(float('inf')) == 'inf'



# Generated at 2022-06-12 16:27:56.182974
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-12 16:28:08.513685
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(FakeInfoExtractor(), {'format': 'best'}, None)
    fd.report_progress(dict(filename='test1.mp4', status='finished', total_bytes=1024, elapsed=10))
    fd.report_progress(dict(filename='test2.mp4', status='downloading', total_bytes=1024, downloaded_bytes=512, speed=512, eta=10))
    fd.report_progress(dict(filename='test3.mp4', status='downloading', downloaded_bytes=512, speed=512, eta=10))
    fd.report_progress(dict(filename='test4.mp4', status='downloading', total_bytes_estimate=1024, downloaded_bytes=512, speed=512, eta=10))

# Generated at 2022-06-12 16:28:18.349853
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def _p(s, e):
        r = FileDownloader.parse_bytes(s)
        assert r == e, (s, r, e)

    _p('', None)
    _p('a', None)
    _p('2', None)
    _p('1.', None)
    _p('.1', None)
    _p(' 1', None)
    _p('1 ', None)
    _p('1 1', None)
    _p('a1', None)
    _p('1a', None)
    _p('1.1', None)
    _p('1.a', None)
    _p('1,1', None)
    _p('1,a', None)
    _p('1/1', None)
    _p('1/a', None)
   

# Generated at 2022-06-12 16:28:31.731267
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import time

    # Create a temp file
    f = tempfile.NamedTemporaryFile('w')
    f.close()
    filename = f.name
    # Variables for test
    timestr = 'Sat Jan 5 19:33:16 EEST 2013'
    filetime = timeconvert(timestr)
    # Set the modification time using a normal 'touch' command
    os.system('touch -m -t %s %s' % (filetime, filename))
    # Check the last modified time
    date_last_modified = os.path.getmtime(filename)
    # Downloader instance
    downloader = FileDownloader({})
    # Try to set utime
    downloader.try_utime(filename, timestr)
    # Check the last modified time again

# Generated at 2022-06-12 16:28:41.855823
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import platform
    from .YoutubeDL import YoutubeDL

    ydl = YoutubeDL({
        'nooverwrites': False,
        'noprogress': True,
        'logger': YoutubeDL.null_logger(),
    })

    # implementation
    def _test_download(params):
        fd = FileDownloader(ydl, params)

        # video file
        fd.download('file', {
            'id': '123',
            'title': 'example',
            'url': 'http://example.org',
            'ext': 'mp4',
            'urlhandle': compat_urllib_request.urlopen('http://example.org'),
            'duration': 4,
            'filesize': 1000,
        })

        # audio file

# Generated at 2022-06-12 16:28:49.538555
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert format_bytes(1024*1024) == '1.0 MiB'
    assert format_bytes(15*1024*1024) == '15.0 MiB'
    assert format_bytes(333) == '333.0 B'
    assert format_bytes(2**31) == '2.0 GiB'
    assert format_bytes(2**1024) == '1208925819614629174706176.0 YiB'
 


# Generated at 2022-06-12 16:29:01.460702
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    start = time.time()
    time.sleep(1)
    assert FileDownloader.calc_speed(start, time.time(), 1024 * 1024) == 1024 * 1024
    time.sleep(1)
    assert FileDownloader.calc_speed(start, time.time(), 1024 * 1024 * 2) == 1024 * 1024

    start = time.time()
    time.sleep(1)
    assert FileDownloader.calc_speed(start, None, 1024 * 1024) == None
    assert FileDownloader.calc_speed(None, time.time(), 1024 * 1024) == None
    assert FileDownloader.calc_speed(None, None, 1024 * 1024) == None
    assert FileDownloader.calc_speed(start, start, 1024 * 1024) == None

# Generated at 2022-06-12 16:29:09.420096
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    s = {
        'status': 'downloading',
        '_percent_str': '4.31%',
        'downloaded_bytes': 81920,
        'total_bytes': 1916032,
        '_speed_str': '12.01KiB/s',
        '_eta_str': '2:13:45',
    }
    class FakeYDL(object):
        def __init__(self):
            self.verbose = True
            self.params = {'noprogress': False}
        def to_screen(self, msg):
            assert msg == '\r[download] 4.31% of 1.80MiB at 12.01KiB/s ETA 2:13:45'
    fd = FileDownloader({}, FakeYDL())

# Generated at 2022-06-12 16:29:22.347408
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL
    from .extractor import gen_extractors
    gen_extractors()
    ydl = YoutubeDL({
        'format': 'm4a',
        'logger': YoutubeDL.default_logger,
    })
    fd = FileDownloader({
        'format': 'm4a',
        'consoletitle': True,
        'logger': YoutubeDL.default_logger,
    }, ydl)

# Generated at 2022-06-12 16:29:30.672470
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    FileDownloader.undone = False
    
    def test_undo(filename):
        FileDownloader.undone = True
        return 'original ' + filename
    
    FileDownloader.undo_temp_name = test_undo
    
    fd = FileDownloader({})
    
    res = fd.undo_temp_name('filename.part')
    
    assert FileDownloader.undone
    assert res == 'original filename.part'



# Generated at 2022-06-12 16:30:10.674164
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys, io
    import datetime

    class FakeParams(object):
        progress_with_newline = False
        no_progress = False
        noprogress = False

    class FakeYdl(object):
        def __init__(self):
            self.params = FakeParams()
            self.to_screen_calls = []
            self.to_console_title_calls = []

        def to_screen(self, msg, skip_eol=False):
            if sys.stderr.isatty() and not skip_eol:
                msg += '\n'
            self.to_screen_calls.append(msg)

        def to_console_title(self, msg):
            self.to_console_title_calls.append(msg)


# Generated at 2022-06-12 16:30:19.027821
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    downloader = FileDownloader({'verbose': False})
    downloader.real_download = lambda filename, info: True
    downloader.max_download_size = lambda: None
    downloader.report_destination = lambda filename: print('[download] Destination: ' + filename)

    for i in range(100):
        downloader.report_progress({"eta":i, "speed":i, "downloaded_bytes":i, "elapsed":i, "status":"downloading", "filename":"x"})
        time.sleep(1)



# Generated at 2022-06-12 16:30:26.776218
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """
    >>> print "Testing FileDownloader.download()..."
    >>> fd = FileDownloader(None, None)
    >>> ret = fd.download("foo.bar", None)
    Traceback (most recent call last):
    ...
    NotImplementedError: This method must be implemented by subclasses
    >>> fd.real_download = lambda filename, info_dict: filename
    >>> assert fd.download("foo.bar", None) == "foo.bar"
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# vim: expandtab:sw=4:ts=4

# Generated at 2022-06-12 16:30:38.831637
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def progress_hook(status):
        hook_status.append(status)

    hook_status = []
    downloader = FileDownloader({'noprogress': False, 'sleep_interval': 0, 'progress_with_newline': False})
    downloader.add_progress_hook(progress_hook)
    test_status = {'downloaded_bytes': 0, 'elapsed': 0, 'speed': 0, 'eta': 0,
                   'total_bytes': 0, 'status': 'downloading', '_percent_str': 'Unknown %',
                   '_speed_str': 'Unknown speed', '_total_bytes_str': 'Unknown size'}
    test_status_without_elapsed = test_status.copy()
    test_status_without_elapsed.pop('elapsed', None)

    # Test the beginning of

# Generated at 2022-06-12 16:30:50.808038
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(float('nan')) == 'nan'
    assert fd.format_retries(float('-inf')) == 'inf'
    assert fd.format_retries(float('0')) == '0'
    assert fd.format_retries(float('-1')) == '0'
    assert fd.format_retries(float('1')) == '1'
    assert fd.format_retries(float('2')) == '2'
    assert fd.format_retries(float('3')) == '3'
    assert fd.format_retries(float('4.2')) == '4.2'
    assert f

# Generated at 2022-06-12 16:31:02.795778
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    class FakeInfo(object):
        def __init__(self, filename, last_modified_hdr):
            self.filename = filename
            self.last_modified_hdr = last_modified_hdr

    class FakeYdl(object):
        def to_screen(self, msg):
            pass

        def trouble(self, msg):
            pass

    fd = FileDownloader({}, FakeYdl())

    fd.to_screen = lambda *args, **kargs: True
    fd.trouble = lambda *args, **kargs: True

    def test_case(filename, last_modified_hdr, expected_result):
        info = FakeInfo(filename, last_modified_hdr)
        test_result = fd.try_utime(info)
        assert test_result == expected_result

    test

# Generated at 2022-06-12 16:31:14.587134
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    filename = 'test'
    downloader = FileDownloader(None)
    downloader.params = {}
    temp_file = downloader.temp_name(filename)
    if temp_file != filename:
        raise ValueError('Test 1 failed')
    downloader.params['nopart'] = True
    temp_file = downloader.temp_name(filename)
    if temp_file != filename:
        raise ValueError('Test 2 failed')
    downloader.params = {}
    os.mkdir(encodeFilename(filename))
    temp_file = downloader.temp_name(filename)
    if temp_file != filename:
        raise ValueError('Test 3 failed')
    os.rmdir(encodeFilename(filename))

# Generated at 2022-06-12 16:31:27.233395
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_calls.append((msg, skip_eol))

        def to_console_title(self, msg):
            pass

    fd = FileDownloader({}, FakeYDL())
    fd.to_screen = fd.report_progress = lambda *args, **kwargs: None

    # Call once with some values

# Generated at 2022-06-12 16:31:35.265378
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    # TODO: test unicode handling
    def _test_one_try_rename(d, old_filename, new_filename, expect_success):
        if expect_success:
            result = d.try_rename(old_filename, new_filename)
            assert result is None, '%s -> %s should succeed, failed with: %s' % (
                old_filename, new_filename, result)
            assert os.path.exists(encodeFilename(new_filename)) and \
                   not os.path.exists(encodeFilename(old_filename))
        else:
            result = d.try_rename(old_filename, new_filename)
            assert result is not None, '%s -> %s should fail, but succeeded' % (
                old_filename, new_filename)
            assert os.path.ex

# Generated at 2022-06-12 16:31:36.338281
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    assert 1

# Generated at 2022-06-12 16:32:36.099437
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    l = [
        # status, elapsed, eta, downloaded_bytes, total_bytes, total_bytes_estimate, speed,
        ('downloading', 5, 10, 1000, 2000, None, 200),
        ('downloading', 15, 10, 1000, None, None, 200),
        ('downloading', 15, 10, 1000, None, 2000, 200),
        ('downloading', 15, 10, None, None, None, None),
        ('downloading', 15, None, 1000, None, 2000, 200),
        ('finished', 15, None, 1000, 2000, None, 200),
        ('finished', 15, None, 1000, 2000, None, None),
    ]

    def hook(status):
        if status['status'] == 'finished':
            hook.last = hook.last[:-1]
        hook.last.append(status)

# Generated at 2022-06-12 16:32:44.709564
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import os
    import shutil
    import tempfile
    import mock

    # Ensure that:
    # * sleep is called with the correct parameter
    # * speed returned by calc_speed is correct

    # create a temporary directory:
    tmpdir = tempfile.mkdtemp()
    # create a temporary file in this directory:
    tmpf = open(os.path.join(tmpdir, 'tmpfile'), 'wb')
    # write some bytes in this temporary file:
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    tmpf.write(b'blah')
    # seek

# Generated at 2022-06-12 16:32:57.163019
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def calc_speed(current, start, now):
        fd = FileDownloader({})
        return fd.calc_speed(start, now, current)

    assert calc_speed(10, 5, 20) == 0.5
    assert calc_speed(10, 5.1, 20) == 0.4901960784313726
    assert calc_speed(10, 5, 21) == 0.47619047619047616
    assert calc_speed(0, 5, 20) is None
    assert calc_speed(5, 5.5, 20) == 0.9000000000000001  # because of precision

    # Test floating precision
    assert calc_speed(100000, 0, 1000000000000.0) == 100
    assert calc_speed(100000, 0, 1000000000001.0) == 100.00000000000006
    assert calc

# Generated at 2022-06-12 16:33:04.682601
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None)
    # Set download speed
    fd.params['ratelimit'] = 100000
    # Download size in bytes
    size = fd.params['ratelimit'] * 1000
    # Set start time
    start_time = time.time()
    # Call slow_down method
    fd.slow_down(start_time, start_time, size)
    # Get end time
    end_time = time.time()
    # Compare results
    assert end_time - start_time >= 1
    # Set download speed
    fd.params['ratelimit'] = None
    # Set start time
    start_time = time.time()
    # Call slow_down method
    fd.slow_down(start_time, start_time, size)
    # Get end time

# Generated at 2022-06-12 16:33:16.926360
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import io
    from io import StringIO
    from time import time
    _progress_hook_instance = None

    class TestFD(FileDownloader):
        def __init__(self, out):
            self._test_out = out
            self._progress_hooks = []

        def to_screen(self, message, skip_eol=False):
            self._test_out.write(message)
            if not skip_eol:
                self._test_out.write('\n')

        def add_progress_hook(self, ph):
            self._progress_hooks.append(ph)

        def _hook_progress(self, status):
            global _progress_hook_instance
            _progress_hook_instance = self
            for ph in self._progress_hooks:
                ph(status)
