

# Generated at 2022-06-12 16:23:48.145312
# Unit test for method format_percent of class FileDownloader
def test_FileDownloader_format_percent():
    assert FileDownloader.format_percent(0) == '0%'
    assert FileDownloader.format_percent(0.0) == '0%'
    assert FileDownloader.format_percent(1) == '1%'
    assert FileDownloader.format_percent(0.123) == '0%'
    assert FileDownloader.format_percent(0.5) == '1%'
    assert FileDownloader.format_percent(0.505) == '1%'
    assert FileDownloader.format_percent(1.23) == '1%'
    assert FileDownloader.format_percent(1.235) == '1%'
    assert FileDownloader.format_percent(1.236) == '1%'
    assert FileDownloader.format_percent(9.995) == '10%'
    assert File

# Generated at 2022-06-12 16:23:52.960772
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    assert FileDownloader.try_utime('test', None) == None
    assert FileDownloader.try_utime('test', '123') == 123
    assert FileDownloader.try_utime('test', 'Invalid') == None
    assert FileDownloader.try_utime('test', '200') == 200
    assert FileDownloader.try_utime('test', '0') == 0


# Generated at 2022-06-12 16:24:00.061030
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from youtube_dl.__main__ import FileDownloader
    fd = FileDownloader({})
    fd.to_screen = Mock()
    fd.report_file_already_downloaded('/foo/bar/baz')
    fd.to_screen.assert_has_calls([call('[download] The file has already been downloaded')])
    fd.report_file_already_downloaded('/foo/bar/baz/')
    fd.to_screen.assert_has_calls([call('[download] The file has already been downloaded')])
    fd.report_file_already_downloaded('/foo/bar/baz.part')
    fd.to_screen.assert_has_calls([call('[download] The file has already been downloaded')])
    fd.report

# Generated at 2022-06-12 16:24:11.686203
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # Test a few normal cases
    assert(FileDownloader.parse_bytes('42') == 42)
    assert(FileDownloader.parse_bytes('42b') == 42)
    assert(FileDownloader.parse_bytes('42k') == 42 * 1024)
    assert(FileDownloader.parse_bytes('42KB') == 42 * 1024)
    assert(FileDownloader.parse_bytes('42kib') == 42 * 1024)
    assert(FileDownloader.parse_bytes('42KiB') == 42 * 1024)
    assert(FileDownloader.parse_bytes('42m') == 42 * 1024 * 1024)
    assert(FileDownloader.parse_bytes('42MB') == 42 * 1024 * 1024)
    assert(FileDownloader.parse_bytes('42mib') == 42 * 1024 * 1024)

# Generated at 2022-06-12 16:24:18.294396
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    for current, total, t1, t2, expected in [
            (32, 100, 1.0, 3.0, 2.6),
            (32, 100, 3.0, 1.0, 0.0),
            (32, 100, 1.0, 1.0, None),
            (32, 100, 1.0, 0.0, None),
            (32, 0, 1.0, 3.0, None)]:
        assert FileDownloader.calc_eta(current, total, t1, t2) == expected



# Generated at 2022-06-12 16:24:31.607744
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    if sys.version_info >= (3, 0):
        tests = [
            ['12', 12],
            ['12b', 12],
            ['12.2', 12],
            ['12.2b', 12],
            ['12.3k', 12 * 1024],
            ['12.3kb', 12 * 1024],
            ['12.3m', 12 * 1024 * 1024],
            ['12.3mb', 12 * 1024 * 1024],
            ['12.4g', 12 * 1024 * 1024 * 1024],
            ['12.4gb', 12 * 1024 * 1024 * 1024],
        ]

# Generated at 2022-06-12 16:24:41.471139
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import tempfile
    fd = FileDownloader(params = None)
    assert(fd.temp_name('abc') == 'abc.part')
    assert(fd.temp_name('ab.cd') == 'ab.cd.part')
    assert(fd.temp_name('a') == 'a.part')
    assert(fd.temp_name('') == '.part')

    fd.params = {}
    fd.params['nopart'] = True
    assert(fd.temp_name('abc') == 'abc')
    assert(fd.temp_name('ab.cd') == 'ab.cd')
    assert(fd.temp_name('a') == 'a')
    assert(fd.temp_name('') == '')



# Generated at 2022-06-12 16:24:54.713767
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class Params:
        def __init__(self, **kwargs):
            self.dict = kwargs

        def get(self, key, fallback=None):
            return self.dict.get(key, fallback)

    class FakeYDL:
        def __init__(self):
            self.to_screen_calls = []
            self.to_console_title_calls = []

        def to_screen(self, *args, **kwargs):
            self.to_screen_calls.append((args, kwargs))

        def to_console_title(self, *args, **kwargs):
            self.to_console_title_calls.append((args, kwargs))


# Generated at 2022-06-12 16:25:06.630974
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    if not hasattr(time, 'perf_counter'):
        time.perf_counter = time.time
    fd = FD()
    fd.params = {'ratelimit': 0.2}
    # speed = 1.0
    fd.slow_down(time.perf_counter(), time.perf_counter(), 1.0)
    # speed = 2.0
    fd.slow_down(time.perf_counter(), time.perf_counter(), 2.0)
    # speed = 0
    fd.slow_down(time.perf_counter(), time.perf_counter(), 0.0)
    # speed = 5.0
    fd.slow_down(time.perf_counter(), time.perf_counter(), 5.0)
    # ratelimit = None
    fd

# Generated at 2022-06-12 16:25:13.847528
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    s = fd.try_utime(filename = 'file', last_modified_hdr=None)
    assert s == None
    s = fd.try_utime(filename = 'file', last_modified_hdr=timeconvert('20151101'))
    assert s == 1446371200
    s = fd.try_utime(filename = 'file', last_modified_hdr=timeconvert('2015'))
    assert s == None


# Generated at 2022-06-12 16:25:43.226394
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    from .extractor import YoutubeIE
    from .utils import encode_data_uri

    def time_in_range(start, end, x):
        return start < x < end

    data_uri = encode_data_uri(
        b'', mime_type='application/octet-stream', extension='mp4')
    ie = YoutubeIE()
    info = ie._extract_info(
        'youtube.com/watch?v=-gA_wB7YIY0',
        downloader=None, ie_key='Youtube')

    fd = FileDownloader(None, params={'ratelimit': 300000, 'nooverwrites': True})
    fd.prepare_filename('-', info)
    fd.report_destination('-')

# Generated at 2022-06-12 16:25:53.381122
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # When using the progresshooks that update progress in the same
    # line, the ETA must not be displayed
    d = FileDownloader({'progress_with_newline': False})
    d.report_progress({
        'total_bytes_estimate': 10000,
        'downloaded_bytes': 1000,
        'eta': 5,
        'speed': 1000,
        'elapsed': 1,
    })
    assert d._screen_file.getvalue() == '\r[download]   10% of ~10.00KiB at 976.56KiB/s (1.0s)    '

    # When using the progresshooks that update progress in the same
    # line, the total size must not be displayed
    d = FileDownloader({'progress_with_newline': False})
    d.report_progress

# Generated at 2022-06-12 16:26:06.219341
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader(YoutubeDL()).temp_name('abc') == 'abc.part'
    assert FileDownloader(YoutubeDL({'nopart': True})).temp_name('abc') == 'abc'
    assert FileDownloader(YoutubeDL({'nopart': True})).temp_name('/a/b/c') == '/a/b/c'
    assert FileDownloader(YoutubeDL({'nopart': True})).temp_name('/a/b/c/') == '/a/b/c/'
    assert FileDownloader(YoutubeDL()).temp_name('/a/b/c/') == '/a/b/c/.part'
    assert FileDownloader(YoutubeDL()).temp_name('-') == '-'
    assert FileDownloader(YoutubeDL()).temp_

# Generated at 2022-06-12 16:26:09.589480
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import doctest
    doctest.testmod(sys.modules["__main__"])

if __name__ == "__main__":
    sys.exit(test_FileDownloader_try_utime())

# Generated at 2022-06-12 16:26:19.235478
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test that the method slow_down will sleep the number of seconds
    # corresponding to the rate difference

    # Rate limit of 100 bytes/second
    rate_limit = 100

    # Amount of downloaded bytes
    downloaded_bytes = 1000

    # Start and end of the timer
    start = time.time()
    end = time.time()

    # Seconds elapsed during the download
    elapsed = end - start

    # Time that should have taken to download 1000 bytes
    expected_time = float(downloaded_bytes) / float(rate_limit)

    # Actual rate
    actual_rate = float(downloaded_bytes) / elapsed

    # Difference between rate and rate limit
    rate_diff = actual_rate - rate_limit

    # If a rate limit is set and it is lower than the actual rate, the
    # slow_down method should sleep for the correct

# Generated at 2022-06-12 16:26:32.179670
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class FakeFD:
        params = {}

        def __init__(self):
            self.sleep_count = 0

        def slow_down(self, start, now, bytes):
            self.sleep_count += 1
            self.start = start
            self.now = now
            self.bytes = bytes

    fd = FakeFD()
    fd.params['ratelimit'] = None # Disable rate limiting
    fd.slow_down(1, 2, 3)
    assert fd.sleep_count == 0
    assert fd.start == 1
    assert fd.now == 2
    assert fd.bytes == 3

    fd = FakeFD()
    fd.params['ratelimit'] = 240
    fd.slow_down(0, 0, 0)
    assert fd.sleep_count == 0
    f

# Generated at 2022-06-12 16:26:43.211946
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # instantiate FileDownloader object
    class DummyYDL(object):
        params = {
            'noprogress': False
        }

        def __init__(self):
            self.to_screen = lambda *args: None
            self.to_console_title = lambda *args: None
            self.progress_hooks = []

        def add_progress_hook(self, f):
            self.progress_hooks.append(f)

    ydl_obj = DummyYDL()
    fd_obj = FileDownloader(ydl_obj, {})
    # call method

# Generated at 2022-06-12 16:26:56.970113
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import requests
    import tempfile

    # We don't want to depend on network to run tests
    # So we use responses to mock requests.get
    import responses

    import youtube_dl
    from youtube_dl.utils import DateRange

    fd = FileDownloader(
        params={
            'noprogress': False,
            'ratelimit': 4194304,  # 4 MB
        })
    fd.report_progress = lambda s: None
    fd.to_screen = lambda *args, **kargs: None


# Generated at 2022-06-12 16:27:02.190100
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader()
    with patch('youtube_dl.downloader.FileDownloader.to_screen') as mock_to_screen:
        fd.report_file_already_downloaded('Foo.flv')
        mock_to_screen.assert_called_once_with(
            '[download] Foo.flv has already been downloaded')
    with patch('youtube_dl.downloader.FileDownloader.to_screen') as mock_to_screen:
        fd.report_file_already_downloaded(b'Foo.flv\xf8'.decode('utf-8', 'ignore'))
        mock_to_screen.assert_called_once_with(
            '[download] The file has already been downloaded')

# Generated at 2022-06-12 16:27:10.171012
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # test empty string
    print(FileDownloader.try_utime('', ''))
    # test wrong input
    print(FileDownloader.try_utime("abc", "abc"))
    # test input with space
    print(FileDownloader.try_utime("abc def", "abc def"))
    # test correct input
    print(FileDownloader.try_utime("Thu, 01 Jan 1970 00:00:00 GMT", ""))
    # test correct input with space
    print(FileDownloader.try_utime("Thu, 01 Jan 1970 00:00:00 GMT ", ""))
    # test correct input with more space
    print(FileDownloader.try_utime("Thu, 01 Jan 1970 00:00:00 GMT  ", ""))
    # test correct input with many space

# Generated at 2022-06-12 16:27:40.930121
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fake_info_dict = {
        'ext': 'mkv'
    }

    class TestFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return 'success'

        def temp_name(self, filename):
            return filename + 'temporary'

        def ytdl_filename(self, filename):
            return filename + 'ytdl'

        def report_destination(self, filename):
            return 'destination:' + filename

    fd = TestFileDownloader({'outtmpl': '%(id)s'}, None, None)

    # file already downloaded
    assert fd.download('a', fake_info_dict)


# Generated at 2022-06-12 16:27:51.888731
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, None)
    assert fd.format_percent(0) == '0%'
    assert fd.format_percent(0.012) == '1%'
    assert fd.format_percent(0.1234) == '12%'
    assert fd.format_percent(1.2345) == '123%'
    assert fd.format_percent(12.345) == '1235%'
    assert fd.format_percent(123.45)
    assert fd.format_percent(1234.5)
    assert fd.format_percent(12345)

    assert fd.format_eta(0) == '0:00:00'
    assert fd.format_eta(2) == '0:00:02'
    assert fd.format_eta

# Generated at 2022-06-12 16:27:58.250195
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    print('test_FileDownloader_format_retries')
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2.333) == '2'
    assert fd.format_retries(2.501) == '3'
 

# Generated at 2022-06-12 16:28:11.370763
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import datetime
    from collections import namedtuple
    from unittest import mock
    from . import FakeYDL

    fd = FileDownloader(FakeYDL(), {'ratelimit': 0})
    fd.to_screen = mock.Mock()
    fd.to_console_title = mock.Mock()

    Status = namedtuple('Status', ['status', 'eta', 'total_bytes', 'downloaded_bytes', 'speed', 'total_bytes_estimate', 'elapsed'])

    fd.report_progress(Status(status='finished', downloaded_bytes=42, total_bytes=42, elapsed=datetime.timedelta(seconds=42)))
    fd.to_screen.assert_called_with('\r[download] 100% of 42 bytes in 42s', skip_eol=True)
   

# Generated at 2022-06-12 16:28:18.437788
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    assert FileDownloader.format_seconds(1.0) == '1.00s'
    assert FileDownloader.format_seconds(10.0) == '10.0s'
    assert FileDownloader.format_seconds(100.0) == '1.67m'
    assert FileDownloader.format_seconds(3600.0) == '1.00h'
    assert FileDownloader.format_seconds(7200.0) == '2.00h'
    assert FileDownloader.format_seconds(7261.0) == '2.01h'

    assert FileDownloader.format_bytes(0) == '0'
    assert FileDownloader.format_bytes(1) == '1'
    assert FileDownloader.format_bytes(1023) == '1023'

# Generated at 2022-06-12 16:28:31.839117
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({
        'noprogress': True,
        'logger': MockLogger(),
    })
    assert fd.temp_name('foo') == 'foo'
    assert fd.temp_name('foo.part') == 'foo.part'
    assert fd.temp_name('foo/bar.baz') == 'foo/bar.baz'
    assert fd.temp_name('foo\\bar.baz') == 'foo\\bar.baz'
    assert fd.temp_name('foo/') == 'foo/'

    fd.params['nopart'] = True
    assert fd.temp_name('foo') == 'foo'
    assert fd.temp_name('foo.part') == 'foo.part'

# Generated at 2022-06-12 16:28:41.331343
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    expected_results = {
        0: '0:00', 1: '0:01', 59: '0:59',
        60: '1:00', 61: '1:01', 3599: '59:59',
        3600: '1:00:00', 3601: '1:00:01',
        36000: '10:00:00', 86399: '23:59:59',
        86400: '1 day, 0:00:00', 86401: '1 day, 0:00:01',
        864000: '10 days, 0:00:00',
    }
    for key, value in expected_results.items():
        assert value == FileDownloader.format_seconds(key)



# Generated at 2022-06-12 16:28:53.951131
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    assert fd.try_utime('', None) is None
    assert fd.try_utime('', 'asdfasdf') is None
    assert fd.try_utime('', '1995-10-10 20:40:40') == 820444440.0
    assert fd.try_utime('', '1995-10-10 20:40:40+01:00') == 820444440.0
    assert fd.try_utime('', '1995-10-10 20:40:40+01:00') == 820444440.0
    assert fd.try_utime('', '1995-10-10T20:40:40.001Z') == 820444440.0

# Generated at 2022-06-12 16:29:05.087818
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({}, YoutubeDL({}))
    #Only '.part' in the end
    assert fd.undo_temp_name('test.part') == 'test'
    #Only '.part' in the middle
    assert fd.undo_temp_name('test.part.txt') == 'test.txt'
    #Multiple '.part'
    assert fd.undo_temp_name('test.part.part') == 'test.part'
    #No '.part'
    assert fd.undo_temp_name('test') == 'test'
    #Only '.part'
    assert fd.undo_temp_name('.part') == ''
    #Empty string
    assert fd.undo_temp_name('') == ''
    #None
    assert fd.undo_temp_name(None) == None

# Generated at 2022-06-12 16:29:17.762667
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import pytest
    from youtube_dl.downloader.FileDownloader import FileDownloader
    fd = FileDownloader(None, None)
    fd.to_screen = lambda x: pytest.fail(x)
    fd.to_console_title = lambda x: pytest.fail(x)
    fd.report_progress(dict(status='finished',
                            total_bytes=10,
                            downloaded_bytes=10,
                            elapsed=1))
    fd.report_progress(dict(status='downloading',
                            # total_bytes=10,
                            downloaded_bytes=10,
                            speed=1,
                            elapsed=1))

# Generated at 2022-06-12 16:29:48.058242
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    d = FileDownloader({'retries': 3})
    assert d.format_retries(3) == '3'


# Generated at 2022-06-12 16:30:00.904903
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import io
    import tempfile
    from urllib.request import pathname2url, urlopen
    from youtube_dl.utils import encode_data_uri
    ydl = YoutubeDL({})
    fd = FileDownloader(ydl, {'writedescription': True, 'writeinfojson': True, 'quiet': True})

    # Test a download from a file URL
    (fdl_in, file_url) = tempfile.mkstemp()

# Generated at 2022-06-12 16:30:10.638248
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import datetime
    import os
    import shutil
    import tempfile
    from subprocess import Popen, PIPE
    import pytz
    import time
    import unittest

    def set_file_mtime(filename, unix_timestamp):
        assert isinstance(filename, str)
        assert isinstance(unix_timestamp, int)
        subprocess = Popen(["touch", '-d', (datetime.datetime.utcfromtimestamp(unix_timestamp)).strftime("%Y-%m-%d %H:%M:%S UTC"), filename], stdout=PIPE, stderr=PIPE)
        stdoutdata, stderrdata = subprocess.communicate()
        assert subprocess.returncode == 0
        assert stderrdata == b''


# Generated at 2022-06-12 16:30:22.522070
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = YDL()
    ydl.params['noprogress'] = False
    fd = FileDownloader(ydl, {'url': 'http://www.example.com/', 'id': 'example'})

    s = {}
    fd.report_progress(s)
    assert not ydl.msgs

    s = {'status': 'downloading', 'elapsed': 2, 'eta': 3, 'total_bytes': 4, 'downloaded_bytes': 5}
    fd.report_progress(s)
    assert ydl.msgs[-1].startswith('[download]   0.0% of 4 at')

    s = {'status': 'finished', 'elapsed': 2, 'eta': 3, 'total_bytes': 4, 'downloaded_bytes': 4}
    fd.report

# Generated at 2022-06-12 16:30:29.986084
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(None)
    for name in ['foobar', 'foobar.part', 'foobar.part-xxx']:
        assert fd.undo_temp_name(name) == name

    for name in ['foobar.part.part', 'foobar.part-xxx.part', 'foobar.part.part-xxx']:
        assert fd.undo_temp_name(name) == 'foobar'

    for name in ['foobar.part.part-xxx', 'foobar.part-xxx.part-xxx']:
        assert fd.undo_temp_name(name) == 'foobar.part'


# Generated at 2022-06-12 16:30:42.806889
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import types
    def run_test(total_bytes, downloaded_bytes, elapsed, filename=None,
                 expected_msg=None, sleep_time=0.0, elapsed_expected=None):
        fd = FileDownloader(dict(format='bestaudio/best', noprogress=False), {})
        fd._report_progress_status = types.MethodType(
            lambda self, *args, **kargs: setattr(self, 'progress_status', args[0]), fd)
        def get_status():
            status = {
                'downloaded_bytes': downloaded_bytes, 'elapsed': elapsed,
                'total_bytes': total_bytes, 'total_bytes_estimate': None}
            if filename:
                status['filename'] = filename
            return status
        fd.report_progress(get_status())

# Generated at 2022-06-12 16:30:53.634789
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(None, {'noprogress': True, 'continuedl': False})
    assert fd.temp_name('abc.mp4') == 'abc.mp4.part'
    assert fd.temp_name('abc.mp4.part') == 'abc.mp4.part'
    assert fd.temp_name('/abc.mp4') == '/abc.mp4.part'
    assert fd.temp_name('/abc.mp4.part') == '/abc.mp4.part'
    assert fd.temp_name('/file with spaces/abc.mp4') == '/file with spaces/abc.mp4.part'
    assert fd.temp_name('/file with spaces/abc.mp4.part') == '/file with spaces/abc.mp4.part'

# Generated at 2022-06-12 16:31:06.174853
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from .utils import DateRange
    from .extractor.common import InfoExtractor

    date_range = DateRange()

    def assert_date(date_text, expected):
        info = {'upload_date': date_text}
        DateRange.inject_date_range(info)
        if expected is not True:
            info['upload_date'] = date_range(info['upload_date'])
        info['uploader_id'] = 'a'


# Generated at 2022-06-12 16:31:17.700666
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import platform
    import tempfile

    tmpfn = tempfile.NamedTemporaryFile(delete=False)
    tmpfn.close()

    fd = FileDownloader({})
    fd.to_screen = lambda *x: x
    fd.report_warning = lambda *x: x

    if platform.system() != 'Windows':
        # Windows doesn't handle well utime/time.sleep
        # See https://bugs.python.org/issue16308
        # and https://msdn.microsoft.com/en-us/library/windows/desktop/ms724928%28v=vs.85%29.aspx
        t = time.time()
        fd.try_utime(tmpfn.name, str(int(t)))
        assert abs(os.path.getmtime(tmpfn.name) - t)

# Generated at 2022-06-12 16:31:30.016811
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    dummy_params = {
        'continuedl': True,
        'sleep_interval': 'min',
    }
    dummy_info_dict = {
        'id': 'test_id',
        'ext': 'test_ext',
        'title': 'test_title',
        'url': 'test_url',
        'url_basename': 'test_url_basename',
        'format': 'test_format',
    }
    dummy_downloader = FileDownloader(dummy_params)

    # file existence check
    dummy_downloader.report_file_already_downloaded = mock.MagicMock()
    # hook progress
    dummy_downloader._hook_progress = mock.MagicMock()
    # real download
    dummy_downloader.real_download = mock.MagicMock()

    #

# Generated at 2022-06-12 16:32:15.880649
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    from datetime import timedelta
    from time import time
    def assertEqual(a,b):
        if a == b:
            return
        raise AssertionError('%r != %r' % (a, b))
    def assertAlmostEqual(a,b):
        if abs(a-b) < 1:
            return
        raise AssertionError('%r != %r' % (a, b))
    def get_timestamp(s):
        return s['timestamp']
    def get_timedelta(s):
        return s['timedelta']
    def get_timestamp_and_timedelta(s):
        return (s['timestamp'], s['timedelta'])
    def get_dummy(s):
        return 'dummy'


# Generated at 2022-06-12 16:32:21.092315
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader("http://foo.bar", None)
    def test_format_retries(retries, expected):
        fd.retries = retries
        assert fd.format_retries(fd.retries) == expected
    test_format_retries(float("inf"), "inf")
    test_format_retries(0, "0")
    test_format_retries(1, "1")
    test_format_retries(10, "10")



# Generated at 2022-06-12 16:32:34.108803
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    fd = FileDownloader(params={})

    class ReturnValue:
        def __init__(self):
            self.lines = []
        def write(self, line):
            self.lines.append(line)

    status = {'downloaded_bytes': 0, 'elapsed': 0, 'eta': None, 'total_bytes': None, 'speed': None, 'status': 'downloading'}
    fd.to_stderr = ReturnValue()

    fd.report_progress(status)
    assert fd.to_stderr.lines == ['']
    assert fd.to_stderr._report_progress_prev_line_length == 0

    status['downloaded_bytes'] = 50
    fd.report_progress(status)

# Generated at 2022-06-12 16:32:38.485836
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeYdl:
        def __init__(self):
            self.screen_output = ''
            self.title_output = ''

        def to_screen(self, message, skip_eol=False):
            self.screen_output += message
            if not skip_eol:
                self.screen_output += '\n'

        def to_console_title(self, message):
            self.title_output += message + '\n'

    info_dict = {
        'status': 'downloading',
        'downloaded_bytes': 12345,
        'total_bytes': 987654,
        'eta': 321,
        'speed': 456789,
    }

    ydl = FakeYdl()

# Generated at 2022-06-12 16:32:44.947533
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    def calc_speed_helper(fd, a, b, c, d):
        fd.calc_speed(a, b, c)
        return fd._calc_speed(a, b, c, d)
    fd = FileDownloader({})
    assert fd._calc_speed(0, 0, 0, 0) is None
    assert fd._calc_speed(0, 0, 1, 1) is None
    assert calc_speed_helper(fd, 0, 1, 0, 0) == 1
    assert calc_speed_helper(fd, 0, 2, 3, 0) == 3



# Generated at 2022-06-12 16:32:57.660842
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader(params={})
    # Test whether try_utime returns None if filename doesn't exist
    assert fd.try_utime(None, None) is None

    # Test whether try_utime returns None if last_modified_hdr is None
    testfile = tempfile.NamedTemporaryFile(delete=False)
    testfile.close()
    assert fd.try_utime(testfile.name, None) is None
    os.remove(testfile.name)

    # Test whether try_utime returns None if timeconvert returns None
    testfile = tempfile.NamedTemporaryFile(delete=False)
    testfile.close()
    assert fd.try_utime(testfile.name, 'x') is None
    os.remove(testfile.name)

    # Test whether

# Generated at 2022-06-12 16:33:07.657706
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None)
    fd.to_screen = lambda *args, **kargs: None
    fd.params = {'noprogress': False, 'verbose': False}

    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 99999,
        'downloaded_bytes': 1,
        'elapsed': 0.001,
        'eta': None,
        'speed': 0,
    })

    fd.report_progress({
        'status': 'downloading',
        'total_bytes': 99999,
        'downloaded_bytes': 1,
        'elapsed': 0.001,
        'eta': None,
        'speed': 1024,
    })
