

# Generated at 2022-06-12 16:23:53.761199
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert FileDownloader.format_retries(1) == '1'
    assert FileDownloader.format_retries(2) == '2'
    assert FileDownloader.format_retries(3) == '3'
    assert FileDownloader.format_retries(float('inf')) == 'inf'
    #fails
    #assert FileDownloader.format_retries(-1) == '-1'

# Generated at 2022-06-12 16:24:00.420542
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(2 ** 10) == '%10s' % '1.0KiB/s'
    assert FileDownloader.format_speed(2 ** 20) == '%10s' % '1.0MiB/s'
    assert FileDownloader.format_speed(2 ** 30) == '%10s' % '1.0GiB/s'
    assert FileDownloader.format_speed(2 ** 40) == '%10s' % '1.0TiB/s'
    assert FileDownloader.format_speed(2 ** 50) == '%10s' % '1.0PiB/s'
    assert FileDownloader.format_speed(2 ** 60) == '%10s' % '1.0EiB/s'

# Generated at 2022-06-12 16:24:11.859475
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # See issue #1018
    fd = FileDownloader({'nopart': True})
    assert fd.temp_name('Foo') == 'Foo'
    assert fd.temp_name('Foo.1.mp4') == 'Foo.1.mp4'
    assert fd.temp_name('FooBar') == 'FooBar'
    assert fd.temp_name('FooBar.mp4') == 'FooBar.mp4'
    assert fd.temp_name('Foo/Bar') == 'Foo/Bar'
    assert fd.temp_name('Foo/Bar.mp4') == 'Foo/Bar.mp4'
    assert fd.temp_name('Foo/Bar\\') == 'Foo/Bar\\'

# Generated at 2022-06-12 16:24:20.539467
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    """ FileDownloader. report_file_already_downloaded. """
    
    class FakeYDL():
        def to_screen(self, message):
            print(message)
    
    class FakeParams():
        def get(self, param, default = None):
            if param == 'nooverwrites':
                return True
            if param == 'continuedl':
                return True
            if param == 'nopart':
                return False
            return default
    
    ydl_fake = FakeYDL()
    params_fake = FakeParams()
    
    file_name_ok = 'file_name_ok'
    file_name_ko = 'file_name_ko'
    
    fd = FileDownloader(ydl_fake, params_fake)
    

# Generated at 2022-06-12 16:24:33.590612
# Unit test for method download of class FileDownloader

# Generated at 2022-06-12 16:24:43.522994
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    fd = FileDownloader({})
    assert fd._max_speed == float('inf')

    fd.params['ratelimit'] = 10
    fd.start_time = 0.0
    fd.downloaded_bytes = 0

    # No delay on startup
    fd.slow_down(fd.start_time, 0.0, fd.downloaded_bytes)

    fd.start_time = 0.0
    fd.downloaded_bytes = 100
    t0 = time.time()
    fd.slow_down(fd.start_time, t0, fd.downloaded_bytes)

    fd.start_time = 0.0
    fd.downloaded_bytes = 100
    t0 = time.time()

# Generated at 2022-06-12 16:24:55.667438
# Unit test for method calc_percent of class FileDownloader
def test_FileDownloader_calc_percent():
    normalized_url = 'Normalized URL'
    test_downloader = FileDownloader(None)
    test_downloader.info_dict = {
        '_downloaded_bytes': 0,
        '_total_bytes_estimate': 0,
        '_downloader_cache': {normalized_url: {'total_bytes': None}}
    }
    test_downloader.total_bytes = 0

    assert test_downloader.calc_percent(normalized_url) == None
    assert test_downloader.info_dict['_total_bytes_estimate'] == 0

    test_downloader.info_dict['_downloader_cache'][normalized_url]['total_bytes'] = 10

    assert test_downloader.calc_percent(normalized_url) == 0
    assert test_downloader.info_

# Generated at 2022-06-12 16:25:07.373031
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    def test(total, downloaded, start, now, expected_eta):
        downloader = FileDownloader({'ratelimit': None})
        eta = downloader.calc_eta(total, downloaded, start, now)
        if eta != expected_eta:
            return '%s != %s' % (eta, expected_eta)

    # total = 100
    # downloaded = 0
    # now = 0
    # start = 0
    # rate = 100
    # eta = 100
    r = test(100, 0, 0, 0, 100)
    if r:
        return r

    # total = 100
    # downloaded = 0
    # now = 1
    # start = 0
    # rate = 100
    # eta = 99
    r = test(100, 0, 0, 1, 99)

# Generated at 2022-06-12 16:25:18.600511
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({'format': '22'})
    # These numbers were obtained after trial and error
    # The unit is bytes per second
    # The last two values are expected to be None

# Generated at 2022-06-12 16:25:28.432469
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('911') == 911
    assert FileDownloader.parse_bytes('42k') == 43008
    assert FileDownloader.parse_bytes('42KB') == 43008
    assert FileDownloader.parse_bytes('42 Kb') == 43008
    assert FileDownloader.parse_bytes('42 KB') == 43008
    assert FileDownloader.parse_bytes('42Kb') == 43008
    assert FileDownloader.parse_bytes('42m') == 443901696
    assert FileDownloader.parse_bytes('42MB') == 443901696
    assert FileDownloader.parse_bytes('42 Mb') == 443901696
    assert FileDownloader.parse_bytes('42 MB') == 443901696

# Generated at 2022-06-12 16:25:54.879322
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-12 16:26:07.200262
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-12 16:26:17.905621
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    dl = FileDownloader(None, None)
    assert dl.best_block_size(1.0, 100000) == 4194304
    assert dl.best_block_size(1.0, 1) == 4194304
    assert dl.best_block_size(1.0, 1048576) == 1048576
    assert dl.best_block_size(1.0, 1048577) == 2097152
    assert dl.best_block_size(1.0, 1048576) == 1048576
    assert dl.best_block_size(1.0, 2097152) == 2097152
    assert dl.best_block_size(1.0, 2097153) == 1048576
    assert dl.best_block_size(1.0, 4194304) == 4

# Generated at 2022-06-12 16:26:31.617992
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def test(l):
        for filename, expected in l:
            assert FileDownloader.temp_name(filename) == expected

    # Temp name of some existing files must be the same file with a '.part' suffix
    test([
        ('foo.flv', 'foo.flv.part'),
        ('foo.fvl.download', 'foo.fvl.download.part'),
        ('foo.fvl.download.part', 'foo.fvl.download.part.part'),
        (u'Новая папка', u'Новая папка.part'),
    ])

    # Temp name of some non-existent files must be the same file

# Generated at 2022-06-12 16:26:42.828431
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import tempfile

    ydl = YoutubeDL(params={'noprogress': False})
    fd = FileDownloader(ydl, {'total_bytes': 10})

    def test(expected_output, expected_elapsed):
        elapsed = time.time() - start_time
        if abs(elapsed - expected_elapsed) > 0.1:
            raise ValueError('Test time error')
        # sys.stderr.write(sys.version + '\n')
        if compat_os_name != 'nt':
            return
        # Windows terminal doesn't support ANSI-Codes, so we can't clear
        # the previous line and print the new one
        # (the extra blank is because we don't clear the previous line)

# Generated at 2022-06-12 16:26:53.102859
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(15) == '0:15'
    assert FileDownloader.format_seconds(3 * 60 + 15) == '3:15'
    assert FileDownloader.format_seconds(3 * 60 * 60 + 3 * 60 + 15) == '3:03:15'
    assert FileDownloader.format_seconds(3 * 60 * 60 * 24 + 3 * 60 * 60 + 3 * 60 + 15) == '3 days, 3:03:15'



# Generated at 2022-06-12 16:26:59.399885
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import time
    # FileDownloader.report_progress(s)
    fd = FileDownloader({})
    s = {
        'status' : 'downloading',
        'filename' : 'test.flv',
        'total_bytes' : 235713,
        'eta' : None,
        'elapsed' : 5.0,
        'speed' : 1000,
        'downloaded_bytes' : 135713,
    }
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd.to_console_title = lambda *args, **kargs: print(args[0])
    fd.report_progress(s)
    assert fd._report_progress_prev_line_length == 0
    # ETA is available
    s['eta'] = 4

# Generated at 2022-06-12 16:27:08.566860
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import utils

# Generated at 2022-06-12 16:27:21.925645
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    ydl = YoutubeDL()
    ydl.params['nopart'] = True
    fd = FileDownloader(ydl, {}, {'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'})
    assert fd.temp_name('BaW_jenozKc.flv') == 'BaW_jenozKc.flv'
    assert fd.temp_name('-.part.mp4') == '-.part.mp4'
    assert fd.temp_name('-') == '-'
    assert fd.temp_name('test.part.test') == 'test.part.test'
    assert fd.temp_name('/tmp/test.part') == '/tmp/test.part'

# Generated at 2022-06-12 16:27:23.922142
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("/tmp/foo.part") == "/tmp/foo"


# Generated at 2022-06-12 16:27:46.243360
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    res = []
    time_stamps = []
    time_stamps.append(datetime.datetime.now())
    
    def _debug_hook(status):
        time_stamps.append(datetime.datetime.now())
        res.append(status['status'])
    
    def _dummy_to_screen(msg):
        pass

    fd = FileDownloader({
        'sleep_interval': 2.0,
        'ratelimit': 1.0,
    }, _dummy_to_screen)
    fd.params['test'] = True
    fd.add_progress_hook(_debug_hook)
    fd.downloaded_bytes = 0
    fd.start = time.time() - 2
    fd.slow_down(fd.start, None, 1)
    f

# Generated at 2022-06-12 16:27:55.353189
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    """ Unit test for method temp_name in class FileDownloader """
    try:
        from .compat import unittest
    except ImportError:
        import unittest
    import os
    import tempfile
    from youtube_dl.downloader.FileDownloader import FileDownloader

# Generated at 2022-06-12 16:28:03.417850
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('filename.tmp') == 'filename'
    assert FileDownloader.undo_temp_name('filename') == 'filename'
    assert FileDownloader.undo_temp_name('.filename') == '.filename'
    assert FileDownloader.undo_temp_name('.') == '.'
    assert FileDownloader.undo_temp_name('..') == '..'
    assert FileDownloader.undo_temp_name('.') == '.'
    assert FileDownloader.undo_temp_name('.part') == ''

# Generated at 2022-06-12 16:28:15.427622
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1024') == 1024
    assert FileDownloader.parse_bytes('10240') == 10240
    assert FileDownloader.parse_bytes('10k') == 10240
    assert FileDownloader.parse_bytes('10K') == 10240
    assert FileDownloader.parse_bytes('10000000000') == 10000000000
    assert FileDownloader.parse_bytes('1gb') == 1073741824
    assert FileDownloader.parse_bytes('1GiB') == 1073741824
    assert FileDownloader.parse_bytes('1G') == 1073741824
    assert FileDownloader.parse_bytes('1 gb') == 1073741824
    assert FileDownloader.parse_bytes('1.5gb') == 1500000000
    assert File

# Generated at 2022-06-12 16:28:27.935381
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_ydl = YoutubeDL(None)
    test_fd = FileDownloader(test_ydl, {})
    test_fd.report_destination = lambda x: None
    test_fd.report_progress = lambda s: None
    test_fd.real_download = lambda x, y: None
    test_fd.to_screen = lambda *args, **kargs: None
    test_fd.download('foo', {'id': 1})
    test_fd.download('foo', {'id': 1, 'filesize': 1})
    test_fd.download('foo', {'id': 1, 'filesize': 1000000, 'tbr': 1000000})
    test_fd.download('foo', {'id': 1, 'filesize': 1000000, 'tbr': 0.5})

# Generated at 2022-06-12 16:28:38.325472
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None)
    assert fd.calc_speed(0, 0, 0) is None
    assert fd.calc_speed(1, 1, 0) is None
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 100) == 100
    assert fd.calc_speed(1, 2, 100) == 100
    assert fd.calc_speed(1, 21, 100) == 5
    assert fd.calc_speed(3, 21, 100) == 33
    assert fd.calc_speed(8, 69, 100) == 12


# Generated at 2022-06-12 16:28:40.652412
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    elapsed_time = 0.1
    bytes = 1000
    print(FileDownloader.best_block_size(elapsed_time, bytes))


# Generated at 2022-06-12 16:28:53.311675
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    params = {'nopart': False}
    fd = FileDownloader(params)
    assert fd.temp_name("test_file") == "test_file.part"
    assert fd.temp_name("test_file.part") == "test_file.part"
    assert fd.temp_name("/home/user/test_file") == "/home/user/test_file.part"
    assert fd.temp_name("/home/user/test_file.part") == "/home/user/test_file.part"

    params = {'nopart': True}
    fd = FileDownloader(params)
    assert fd.temp_name("test_file") == "test_file"
    assert fd.temp_name("test_file.part") == "test_file.part"

# Generated at 2022-06-12 16:29:04.516972
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(None, {})

    assert(downloader.temp_name('xyz.mp4') == 'xyz.mp4')
    assert(downloader.temp_name('xyz') == 'xyz')
    assert(downloader.temp_name('/tmp/xyz') == '/tmp/xyz')
    assert(downloader.temp_name('c:\\xyz') == 'c:\\xyz')

    downloader.params['nopart'] = True
    assert(downloader.temp_name('xyz.mp4') == 'xyz.mp4')
    assert(downloader.temp_name('xyz') == 'xyz')
    downloader.params['nopart'] = False

    os.mkdir(TEST_TMPDIR)

# Generated at 2022-06-12 16:29:17.503713
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # We check that the result is lower than the limit and
    # greater than the minimum. Moreover, we check that
    # the "elapsed time" argument has an impact.
    fd = FileDownloader({})
    bs = fd.best_block_size(2, 500)
    assert bs < 4194304 and bs > 1

    bs = fd.best_block_size(1, 500)
    assert bs < 4194304 and bs > 1

    bs = fd.best_block_size(0.5, 500)
    assert bs < 4194304 and bs > 1

    # We check that the file size argument has an impact.
    bs = fd.best_block_size(2, 500)
    bs2 = fd.best_block_size(2, 1000)

# Generated at 2022-06-12 16:29:36.788630
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # This test is independent of the current directory
    with make_temp_directory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, 'FLV8.flv')
        open(tmp_file, 'w').close()
        fd = FileDownloader(params={})
        assert fd.temp_name(tmp_file) == tmp_file + '.part'
        assert fd.temp_name(tmp_file + '.part') == tmp_file + '.part'
        assert fd.temp_name(tmp_file) == tmp_file + '.part'
        assert fd.temp_name('http://www.youtube.com/watch/') == 'http://www.youtube.com/watch/'

# Generated at 2022-06-12 16:29:41.047315
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():

    fd = FileDownloader(None, None)

    # Logs filename
    fd.report_file_already_downloaded('/tmp/file')

    # Logs an error message when filename is not a string
    fd.report_file_already_downloaded(100)

# Generated at 2022-06-12 16:29:48.722216
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():

    fd = FileDownloader()
    # Test for kibibyte (KiB)
    assert fd.parse_bytes("1K") == 1024
    assert fd.parse_bytes("10K") == 10 * 1024
    assert fd.parse_bytes("2.5K") == 2.5 * 1024
    assert fd.parse_bytes("1.0K") == 1024

    # Test for mebibyte (MiB)
    assert fd.parse_bytes("1M") == 1024 * 1024
    assert fd.parse_bytes("10M") == 10 * 1024 * 1024
    assert fd.parse_bytes("2.5M") == 2.5 * 1024 * 1024

    # Test for gibibyte (GiB)
    assert fd.parse_bytes("1G") == 1024 * 1024 * 1024


# Generated at 2022-06-12 16:30:01.392973
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import pytest

    def return_123(start, now, bytes):
        return 123

    def return_456(start, now, bytes):
        return 456

    def return_zero(start, now, bytes):
        return 0

    def return_none(start, now, bytes):
        return None

    start = time.time()
    now = time.time()

    # Unused variables
    # pylint: disable-msg=W0613
    # Invalid function name
    # pylint: disable-msg=C0103
    def _test(sleep_time, rate_limit, bytes, calc_speed,
              expected_sleep_time):
        ydl = FileDownloader({
            'ratelimit': rate_limit,
        })

        ydl.calc_speed = calc_speed
        ydl.slow_

# Generated at 2022-06-12 16:30:10.955271
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    fd.to_screen = lambda x: x
    assert fd.report_progress({
        'status': 'finished',
    }) is None
    assert fd.report_progress({
        'status': 'downloading',
        'eta': 3,
        'total_bytes': 4,
        'downloaded_bytes': 1
    }) is None
    assert fd.report_progress({
        'status': 'downloading',
    }) is None
    assert fd.report_progress({
        'status': 'downloading',
        'eta': None,
        'total_bytes': None,
        'downloaded_bytes': None,
        'speed': None,
    }) is None

# Generated at 2022-06-12 16:30:22.854168
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    downloader = FileDownloader(params={'ratelimit': 1000000})

    ret = downloader.best_block_size(0.01, 512)
    assert ret == 25600
    ret = downloader.best_block_size(0.01, 1024)
    assert ret == 51200
    ret = downloader.best_block_size(0.01, 5000)
    assert ret == 102400
    ret = downloader.best_block_size(0.01, 10000)
    assert ret == 102400
    ret = downloader.best_block_size(0.01, 20000)
    assert ret == 102400
    ret = downloader.best_block_size(0.01, 40000)
    assert ret == 204800
    ret = downloader.best_block_size(0.01, 80000)
    assert ret

# Generated at 2022-06-12 16:30:30.237157
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params={})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })

    fd = FileDownloader(params={})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })

    fd = FileDownloader(params={'noprogress': True})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': None,
    })

    fd = FileDownloader(params={})
    fd.report_progress({
        'status': 'finished',
        'total_bytes': 100,
        'downloaded_bytes': 100,
    })

    fd = FileDownloader(params={})
    fd.report_

# Generated at 2022-06-12 16:30:43.261476
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with ratelimit = None
    params = {
        'ratelimit': None
    }
    now = 0.0
    count = 0
    sleep_time = 3.2
    start_time = now

    slow_down(now, now, count, start_time, sleep_time, params)

    # Test with ratelimit = 10
    params = {
        'ratelimit': 10
    }
    now = 0.0
    count = 0
    start_time = time.time()
    while count < 10:
        count += 1
        time.sleep(0.1)
        now = time.time()
        slow_down(now, now, count, start_time, sleep_time, params)
    # Make sure that slow_down method works correctly

    # Test with ratelimit = 0

# Generated at 2022-06-12 16:30:53.834655
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    if os.name != 'nt':
        pytest.skip('Test is incompatible with non-Windows systems')
    from .compat import compat_os_name
    assert compat_os_name == 'nt'

    def report_progress(self, *args, **kwargs):
        return FileDownloader.report_progress(self, *args, **kwargs)

    fd = FileDownloader({'noprogress': False, 'ratelimit': None})
    fd._report_progress_prev_line_length = 0
    fd._report_progress_status = MagicMock()
    fd.to_screen = MagicMock()

    report_progress(fd, {'status': 'finished'})
    assert fd.to_screen.call_count == 1

# Generated at 2022-06-12 16:31:06.370909
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    if not hasattr(FileDownloader, 'parse_bytes'):
        return True
    tests = [
        ('0', 0),
        ('100', 100),
        ('1k', 1024),
        ('1K', 1024),
        ('1m', 1024 * 1024),
        ('1M', 1024 * 1024),
        ('1g', 1024 * 1024 * 1024),
        ('1G', 1024 * 1024 * 1024),
        ('1x', None),
        ('1', None),
        ('', None),
        ('1.0k', None),
        ('1.0K', None),
    ]
    for inp, outp in tests:
        res = FileDownloader.parse_bytes(inp)
        if res != outp:
            print('parse_bytes(%r)' % inp)

# Generated at 2022-06-12 16:31:29.002259
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import copy
    import os
    import shutil
    import tempfile
    _TEST_DATA_ROOT = os.path.join(os.path.split(__file__)[0], 'testdata')
    _TEST_FILE1 = os.path.join(_TEST_DATA_ROOT, 'test1.mp4')

    def _fetch(fd, tmpfilename, t):
        fd.slow_down(t, t + 1, os.path.getsize(_TEST_FILE1))

    fd = FileDownloader({
        'outtmpl': u'%(id)s%(ext)s',
        'verbose': True,
        'ratelimit': 2000,
        'nooverwrites': True,
    })

# Generated at 2022-06-12 16:31:36.218359
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    """Test FileDownloader.temp_name method"""
    assert (
        FileDownloader('.').temp_name(
            r'C:\Documents and Settings\Ricardo\Configurações locais\Temp\tmphsa0xr') ==
        r'C:\Documents and Settings\Ricardo\Configurações locais\Temp\tmphsa0xr.part')
    assert (
        FileDownloader('.').temp_name(
            r'C:\Documents and Settings\Ricardo\Configurações locais\Temp\youtube-dl test video \'\'') ==
        r'C:\Documents and Settings\Ricardo\Configurações locais\Temp\youtube-dl test video \'\'.part')

# Generated at 2022-06-12 16:31:47.927831
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import _common
    from ytdl.FileDownloader import FileDownloader
    info_dict = {
        'id': 'id',
        'ext': 'ext',
        'url': 'url',
        'player_url': 'player_url',
        'playlist': 'playlist',
        'playlist_index': 'playlist_index',
        'title': 'title',
        'http_headers': {},
        'http_headers_keys_to_rawlist': True,
        'urlhandle': 'urlhandle',
    }
    class StubUrlHandle:
        def __init__(self, url):
            assert url == 'url'
            self.url = 'url'

        def geturl(self):
            return 'url'


# Generated at 2022-06-12 16:31:55.014385
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    # Initialization
    fd = FileDownloader({})

    # Check format_seconds method
    assert fd.format_seconds(0) == '0:00'
    assert fd.format_seconds(5) == '0:05'
    assert fd.format_seconds(60) == '1:00'
    assert fd.format_seconds(60 * 60) == '1:00:00'
    assert fd.format_seconds(3600 + 60 + 5) == '1:01:05'



# Generated at 2022-06-12 16:32:05.494510
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(DummyYDL())

    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('12') == 12
    assert fd.parse_bytes('123') == 123

    assert fd.parse_bytes('1.5') == 1
    assert fd.parse_bytes('1.57') == 2
    assert fd.parse_bytes('1.75') == 2

    assert fd.parse_bytes('1 K') == 1024
    assert fd.parse_bytes('1.5K') == 1536
    assert fd.parse_bytes('1Ki') == 1024
    assert fd.parse_bytes('1.5ki') == 1536
    assert fd.parse_bytes('1KiB') == 1024

# Generated at 2022-06-12 16:32:15.917856
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    def slow_down_test_wrapper(calc_rate):
        params = {
            'ratelimit': 100
        }

        # speed: 0
        calc_rate_res = calc_rate(100, 5, 0)
        assert calc_rate_res is None
        fd = FileDownloader(FakeYDL(), params)
        fd.slow_down(100, 5, 0)

        # speed: 200
        calc_rate_res = calc_rate(100, 5, 200)
        assert calc_rate_res == 2
        fd = FileDownloader(FakeYDL(), params)
        fd.slow_down(100, 5, 200)

        # speed: 1
        calc_rate_res = calc_rate(100, 5, 1)
        assert calc_rate_res == 1
        fd = FileDownload

# Generated at 2022-06-12 16:32:23.121416
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-12 16:32:35.305685
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # now <= start, return None
    start_time = datetime.datetime.now()
    now = start_time
    byte_counter = 100
    rate_limit = 50

    fd = FileDownloader(params={})
    fd.slow_down(start_time, now, byte_counter)

    # now > start, return None
    now = start_time + datetime.timedelta(seconds=1)
    fd.slow_down(start_time, now, byte_counter)

    # now > start, rate < rate_limit
    byte_counter = 50
    fd.slow_down(start_time, now, byte_counter)

    # now > start, rate == rate_limit
    byte_counter = 100
    fd.slow_down(start_time, now, byte_counter)

   

# Generated at 2022-06-12 16:32:41.585099
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    from .compat import empty_fn
    fd = FileDownloader({})
    fd.to_screen = empty_fn
    fd.report_error = empty_fn
    fd.try_rename('abc', 'abc')
    # Test for different filename
    fd.try_rename('abc', 'def')
    # Test for different name and nonexistent target
    fd.try_rename('abc', 'def')


# Test for method format_bytes of class FileDownloader

# Generated at 2022-06-12 16:32:53.085484
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    class TestDownloader(FileDownloader):
        def __init__(self):
            pass

    from_seconds = TestDownloader.format_seconds

    assert from_seconds(0) == "00:00"
    assert from_seconds(1) == "00:01"
    assert from_seconds(2) == "00:02"
    assert from_seconds(60) == "01:00"
    assert from_seconds(61) == "01:01"
    assert from_seconds(120) == "02:00"
    assert from_seconds(121) == "02:01"
    assert from_seconds(3600) == "01:00:00"
    assert from_seconds(3601) == "01:00:01"
    assert from_seconds(7200) == "02:00:00"
    assert from_

# Generated at 2022-06-12 16:33:19.697075
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00:00'
    assert FileDownloader.format_seconds(0.5) == '0:00:00'
    assert FileDownloader.format_seconds(1) == '0:00:01'
    assert FileDownloader.format_seconds(59) == '0:00:59'
    assert FileDownloader.format_seconds(60) == '0:01:00'
    assert FileDownloader.format_seconds(2999) == '0:49:59'
    assert FileDownloader.format_seconds(3000) == '0:50:00'
    assert FileDownloader.format_seconds(5999) == '0:59:59'
    assert FileDownloader.format_seconds(6000) == '1:00:00'