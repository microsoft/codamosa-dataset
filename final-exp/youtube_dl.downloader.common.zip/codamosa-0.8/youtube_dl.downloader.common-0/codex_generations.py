

# Generated at 2022-06-12 16:23:55.751268
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None, None)
    fd.report_file_already_downloaded('a')
    fd.report_file_already_downloaded(u'ü')

if __name__ == '__main__':
    test_FileDownloader_report_file_already_downloaded()

# Generated at 2022-06-12 16:24:07.716971
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    class TestClass(FileDownloader):
        def __init__(self):
            pass
        def trouble(self, message):
            assert False, 'trouble() should not be called, but it was called'
    t = TestClass()
    # test_empty_filenames
    assert t.try_rename('', '') == None, 'Test of try_rename() with empty filenames failed'
    
    # test_non_existing_file_filenames
    assert t.try_rename('non_existing_file', 'non_existing_file') == None, 'Test of try_rename() with non_existing files failed'
    
    # test_dir_as_filename
    tmpdir = tempfile.gettempdir()

# Generated at 2022-06-12 16:24:13.725906
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1 * 1024
    assert FileDownloader.parse_bytes('1m') == 1 * 1024 * 1024
    assert FileDownloader.parse_bytes('1g') == 1 * 1024 * 1024 * 1024
    assert FileDownloader.parse_bytes('1f') == None
    assert FileDownloader.parse_bytes('foo') == None



# Generated at 2022-06-12 16:24:20.337318
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # set up FileDownloader class for testing purpose
    class DummyYDl(object):
        def __init__(self,ydl):
            self.params=ydl.params
            self.to_screen=ydl.to_screen
            self.to_console_title=ydl.to_console_title
            self.trouble=ydl.trouble
            self.report_error=ydl.report_error
            self.report_warning=ydl.report_warning
        def download(self, filename, info_dict):
            return True
    ydl=YoutubeDL('params')
    ydl.to_screen=lambda *args,**kargs: print(args)
    ydl.to_console_title=lambda *args,**kargs:print(args)

# Generated at 2022-06-12 16:24:33.361341
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader._undo_temp_name('filename') == 'filename'
    assert FileDownloader._undo_temp_name('filename.temp') == 'filename'
    assert FileDownloader._undo_temp_name('filename.tmp') == 'filename'
    assert FileDownloader._undo_temp_name('filename.part') == 'filename'
    assert FileDownloader._undo_temp_name('filename.ytdl') == 'filename'
    assert FileDownloader._undo_temp_name('filename.part') == 'filename'

    assert FileDownloader._undo_temp_name('filename.part.ytdl') == 'filename.part'
    assert FileDownloader._undo_temp_name('filename.part.tmp') == 'filename.part'

# Generated at 2022-06-12 16:24:43.339756
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    th = FileDownloader()

    cases = [('1', 1024 ** 0),
             ('1023', 1023 * 1024 ** 0),
             ('1k', 1024 ** 1),
             ('1K', 1024 ** 1),
             ('1m', 1024 ** 2),
             ('1M', 1024 ** 2),
             ('1g', 1024 ** 3),
             ('1G', 1024 ** 3),
             ('1t', 1024 ** 4),
             ('1T', 1024 ** 4),
             ('1p', 1024 ** 5),
             ('1P', 1024 ** 5),
             ('1e', 1024 ** 6),
             ('1E', 1024 ** 6),
             ('1z', 1024 ** 7),
             ('1Z', 1024 ** 7),
             ('1y', 1024 ** 8),
             ('1Y', 1024 ** 8),
             ]


# Generated at 2022-06-12 16:24:47.617306
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(YoutubeDL())
    assert fd.report_file_already_downloaded('foo') == None
    assert fd.report_file_already_downloaded(u'bar') == None

# Generated at 2022-06-12 16:24:59.915811
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """
    Unit test for method try_utime of class FileDownloader
    """
    _filename = 'file.txt'
    _last_modified_hdr = 'Thu, 01 Jan 1970 00:00:00 GMT'

    # test for method when file exists
    _fd = FileDownloader(None, None)
    _empty_filename = 'empty.txt'
    with open(_empty_filename, 'w+') as _file:
        _file.close()
    _inf = {'date': _last_modified_hdr, 'filename': _empty_filename}
    try:
        _fd.try_utime(_filename, _last_modified_hdr)
        assert True
    except:
        assert False

    # test for method when file does not exist

# Generated at 2022-06-12 16:25:09.333807
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Create a test object
    ydl_opts = {}
    fd = FileDownloader(ydl_opts)

    # Test for file already being downloaded
    fd.params['nooverwrites'] = True
    info_dict = {'id': 'foo'}
    res = fd.download('video.mp4', info_dict)
    assert(res == True)

    # Test for file not being downloaded
    fd.params['nooverwrites'] = False
    res = fd.download('video.mp4', info_dict)
    assert(res == False)

    # Test for file not going to be downloaded
    fd.params['continuedl'] = False
    fd.params['nopart'] = True
    res = fd.download('video.mp4', info_dict)

# Generated at 2022-06-12 16:25:18.687547
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    t = [
        ('1', 1),
        ('1k', 1024),
        ('1K', 1024),
        ('1m', 1024 * 1024),
        ('1M', 1024 * 1024),
        ('1g', 1024 * 1024 * 1024),
        ('1G', 1024 * 1024 * 1024),
    ]

    fd = FileDownloader({})
    for i, o in t:
        err = '%s != %s in FileDownloader._parse_bytes' % (
            fd._parse_bytes(i), o)
        assert fd._parse_bytes(i) == o, err
test_FileDownloader_parse_bytes()


# Generated at 2022-06-12 16:25:38.532999
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    dler = FileDownloader(None, params={})
    start_time = time.time()
    dler.slow_down(start_time, None, 10485760)
    time_diff = time.time() - start_time
    assert abs(time_diff) < 0.01, 'The time diff is too big'

if __name__ == '__main__':
    test_FileDownloader_slow_down()



# Generated at 2022-06-12 16:25:50.233191
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class SubFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(SubFileDownloader, self).__init__(ydl, params)

        def real_download(self, filename, info_dict):
            return

    params = {
        'outtmpl': '%(id)s-%(height)s-%(ext)s',
        'nooverwrites': True,
        'continuedl': True,
        'nopart': True,
        'ignoreerrors': True,
        'sleep_interval': 3,
        'max_sleep_interval': 5,
    }

    # test Base FileDownloader
    fd = FileDownloader(None, params)

    # test SubFileDownloader
    sfd = SubFileDownloader(None, params)

# Generated at 2022-06-12 16:25:51.181132
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # TODO
    pass


# Generated at 2022-06-12 16:26:03.770591
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = file_downloader.FileDownloader({})
    old_time = time.time()
    fd.slow_down(old_time, old_time+0.5, 100)
    assert time.time() - old_time < 0.5
    old_time = time.time()
    fd.slow_down(old_time, old_time, 100)
    assert time.time() - old_time < 0.5
    old_time = time.time()
    fd.slow_down(old_time, None, None)
    assert time.time() - old_time < 0.5
    old_time = time.time()
    fd.slow_down(old_time, old_time+0.5, 100)
    assert time.time() - old_time >= 0.5
    old

# Generated at 2022-06-12 16:26:15.696410
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    progress_hooks = []
    def progress_hook(status):
        progress_hooks.append(status)

    ydl = FileDownloader({})
    ydl.add_progress_hook(progress_hook)

    ydl.report_progress({
        'status': 'finished',
        'total_bytes': 1,
    })
    assert progress_hooks == [{
        'status': 'finished',
        'total_bytes': 1,
    }]
    progress_hooks.pop()

    ydl.report_progress({
        'status': 'downloading',
        'eta': 1,
        'total_bytes': 1,
        'speed': 1,
        'downloaded_bytes': 1,
    })

# Generated at 2022-06-12 16:26:24.819502
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader(params={})

    assert fd.undo_temp_name('hello.m4a.part') == 'hello.m4a'
    assert fd.undo_temp_name('hello.m4a') == 'hello.m4a'
    assert fd.undo_temp_name('/path/to/hello.m4a.part') == '/path/to/hello.m4a'
    assert fd.undo_temp_name('/path/to/hello.m4a') == '/path/to/hello.m4a'

# Generated at 2022-06-12 16:26:37.614377
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    d = FileDownloader({})
    d.to_screen = lambda x, y=False: x
    d.format_eta = FileDownloader.format_eta
    d.format_percent = FileDownloader.format_percent
    d.format_bytes = FileDownloader.format_bytes
    d.format_speed = lambda s: '%10s' % ('%s/s' % format_bytes(s))
    d.format_seconds = FileDownloader.format_seconds
    d.report_progress(dict(status='finished'))
    d.report_progress(dict(status='downloading',
        downloaded_bytes=0, total_bytes=None, eta='6.0'))

# Generated at 2022-06-12 16:26:39.748771
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd=FileDownloader(None, None, None, None)
    # TODO: implement test
    assert True

# Generated at 2022-06-12 16:26:43.502195
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('temptest.part') == 'temptest'
    assert fd.undo_temp_name('temptest') == 'temptest'
    assert fd.undo_temp_name('') == ''


# Generated at 2022-06-12 16:26:57.447230
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0.0) == '0:00'
    assert FileDownloader.format_seconds(1.0) == '0:01'
    assert FileDownloader.format_seconds(10.0) == '0:10'
    assert FileDownloader.format_seconds(59.0) == '0:59'
    assert FileDownloader.format_seconds(60.0) == '1:00'
    assert FileDownloader.format_seconds(61.0) == '1:01'
    assert FileDownloader.format_seconds(70.0) == '1:10'
    assert FileDownloader.format_seconds(639.0) == '10:39'
    assert FileDownloader.format_seconds(660.0) == '11:00'
    assert FileDownloader.format_seconds

# Generated at 2022-06-12 16:27:22.789935
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    import time

    TEST_LINK = 'https://test.test/test.test'
    FAKE_SIZE = 1024**2
    FAKE_BYTES = 0
    DEFAULT_RATE_LIMIT = 1024**3
    DEFAULT_SPEED = FAKE_SIZE / 10 # 0.1s download

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test_id'}

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params, *args, **kwargs):
            super(FakeYoutubeDL, self).__init__(*args, **kwargs)
            self.params = params

# Generated at 2022-06-12 16:27:32.530789
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    def _test_case(stamp, expected):
        # Based on the actual code tested
        fd = FileDownloader({})
        stamp = fd.try_utime('/tmp', stamp)
        if stamp is not None:
            stamp = time.localtime(stamp)
        assert stamp == expected

    _test_case('Tue, 28 Mar 2017 00:23:29 GMT', None)
    _test_case('28 Mar 2017 00:23:29 GMT', None)
    _test_case('Tue, 28 Mar 2017 00:23:29 +0000', None)
    _test_case('Tue, 28 Mar 2017 00:23:29', time.localtime(1490715409))


# Generated at 2022-06-12 16:27:44.686079
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes(1) == 1
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1m') == 1048576
    assert FileDownloader.parse_bytes('1g') == 1073741824
    assert FileDownloader.parse_bytes('1t') == 1099511627776
    assert FileDownloader.parse_bytes('1p') == 1125899906842624
    assert FileDownloader.parse_bytes('1e') == 1152921504606846976
    assert FileDownloader.parse_bytes('1z') == 1180591620717411303424
    assert FileDownloader.parse_bytes('1y') == 1208925819614629174706176

# Generated at 2022-06-12 16:27:54.348927
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    class FakeFD(object):
        def __init__(self, *args, **kwargs):
            pass
        def read(self, blocksize):
            return b' ' * blocksize
    import shutil
    from .YoutubeDL import FileDownloader
    from .utils import std_headers
    from .compat import urlopen
    from .extractor.common import InfoExtractor
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    ydl = FileDownloader({'format': 'best[protocol!=m3u8]'})
    ydl.add_info_extractor(InfoExtractor(ydl))
    ydl.add_post_processor(FFmpegPostProcessor(ydl))
    ydl.postprocessor.run_read_chunk_size = lambda: 10
    ydl.fd = FakeFD

# Generated at 2022-06-12 16:28:06.346456
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class TestClass(unittest.TestCase):
        def setUp(self):
            self.test_class = FileDownloader()

    test_class = TestClass()
    # create 2 files and run function test_file_already_downloaded
    test_file = open('test_file.txt', 'w')
    test_file.close()
    test_class.test_class.report_file_already_downloaded('test_file.txt')
    # create 1 file and run function test_file_already_downloaded
    test_file2 = open('test_file2.txt', 'w')
    test_file.close()
    test_class.test_class.report_file_already_downloaded('test_file2.txt')
    # delete files
    os.remove('test_file.txt')

# Generated at 2022-06-12 16:28:17.087576
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    dl = FileDownloader({})
    dl.to_screen = lambda *args, **kargs: None
    dl.to_console_title = lambda *args, **kargs: None
    assert dl.format_percent(0) == '0%'
    assert dl.format_percent(0.1234567) == '12%'
    assert dl.format_percent(0.12345678) == '12.3%'
    assert dl.format_percent(0.9999999) == '100%'
    assert dl.format_percent(1) == '100%'
    assert dl.format_percent(1.1) == '100%'
    assert dl.format_percent(None) == 'Unknown %'

    assert dl.format_eta(0) == '0:00'

# Generated at 2022-06-12 16:28:30.135594
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class MyFD(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.to_screen('\n')

    fd = MyFD(None, {'noprogress': False, 'verbose': False, 'ratelimit': None})

    # Check that reporting less than one hundred percent does not end with an
    # end of line
    fd.report_progress({'status': 'downloading', '_percent_str': '99.9%',
                        '_eta_str': '9.99 secs', 'speed': '999 B/s',
                        'elapsed': 9.99, '_speed_str': '999 B/s'})

# Generated at 2022-06-12 16:28:36.604463
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('abc.part') == 'abc'
    assert fd.undo_temp_name('abc') == 'abc'
    assert fd.undo_temp_name('abc.part.part') == 'abc.part'

if __name__ == '__main__':
    test_FileDownloader_undo_temp_name()

# Generated at 2022-06-12 16:28:44.459410
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from os import utime
    from time import time

    from youtube_dl import FileDownloader
    from youtube_dl.utils import DateRange, timeconvert

    fd = FileDownloader({})
    # Test DURATION
    date = timeconvert('2:33:44')
    orig_f = fd.try_utime = lambda *args: None  # Do not call os.utime
    fd.try_utime('filename', '2:33:44')
    assert fd.try_utime.called_with('filename', date)
    # Test BEGIN
    date = timeconvert('2016-04-05T02:33:44')
    fd.try_utime('filename', '2016-04-05T02:33:44')
    assert fd.try_utime.called_with

# Generated at 2022-06-12 16:28:54.552204
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class FileDownloader_test(FileDownloader):
        def __init__(self, params):
            pass

        def to_screen(self, message, skip_eol=False):
            assert(message == u'[download] test_FileDownloader_report_file_already_downloaded.py has already been downloaded')
            assert(skip_eol == True)

    params = {}
    fd = FileDownloader_test(params)
    fd.report_file_already_downloaded('test_FileDownloader_report_file_already_downloaded.py')

# Generated at 2022-06-12 16:29:35.065808
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = YoutubeDL()
    # Test speed >= 1
    fd = FileDownloader(ydl, {'format': 'bestaudio/best', 'outtmpl': '%(id)s'})
    fd.report_progress({'downloaded_bytes': 1, 'total_bytes': 9, 'total_bytes_estimate': 10, 'eta': 7, 'elapsed': 5, 'speed': 1.9})
    assert ydl.screen_output[-1] == '\x1b[K[download] 1.00% of 10.0MiB at 1.9MiB/s ETA 7 seconds'
    del fd, ydl
    # Test speed < 1
    ydl = YoutubeDL()

# Generated at 2022-06-12 16:29:42.407152
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    def dummy_slow_down(sd, start, now, byte_counter):
        sd._sleep_time = 'dummy_sleep'

    # test with rate limit being None
    fd = FileDownloader(params={'ratelimit': None})
    fd._sleep_time = None
    fd.slow_down = dummy_slow_down
    fd.slow_down(1,2,3)
    assert fd._sleep_time == None

    # test with rate limit being 1, and remaining time being 0
    fd = FileDownloader(params={'ratelimit': 1})
    fd._sleep_time = None
    fd.slow_down = dummy_slow_down
    fd.slow_down(2,2,5)
    assert fd._sleep_time == None

    # test with rate limit being 1

# Generated at 2022-06-12 16:29:54.208190
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    import os
    import time
    import sys

    # For python 2.x, convert unicode strings to bytes
    if sys.version_info < (3, 0):
        def encodeFilename(fn):
            return fn.encode(sys.getfilesystemencoding())
    else:
        def encodeFilename(fn):
            return fn

    dummy_filename = '/tmp/abc/dummy'
    dummy_filename = encodeFilename(dummy_filename)
    f = open(dummy_filename, 'wb')
    f.close()


# Generated at 2022-06-12 16:30:06.124617
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import math

    # This is a method of class FileDownloader.
    # We don't want to use configuration options defined in the config file,
    # so we override some of them.
    params = {
        'verbose': True,
        'nooverwrites': True,
        'noprogress': False,
        'continuedl': True,
        'nopart': False,
    }

    def report_destination(*args):
        pass

    def report_progress(status):
        if status['status'] == 'finished':
            assert os.path.exists(encodeFilename(os.path.join('test_fdd', 'test.mp4')))
            assert not os.path.exists(encodeFilename(os.path.join('test_fdd', 'test.mp4.part')))


# Generated at 2022-06-12 16:30:13.542655
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # Test completely empty dict
    assert FileDownloader.try_utime('dummy path', {}) is None

    # Test without 'modification_time' and 'creation_time'
    assert FileDownloader.try_utime('dummy path', {'abc': 'dummy'}) is None

    # Test without 'modification_time'
    assert FileDownloader.try_utime('dummy path', {'creation_time': 'dummy'}) is None

    # Test without 'creation_time'
    assert FileDownloader.try_utime('dummy path', {'modification_time': 'dummy'}) is None

    # Test invalid modification_time
    assert FileDownloader.try_utime('dummy path', {'modification_time': 'dummy',
                                                   'creation_time': 'dummy'})

# Generated at 2022-06-12 16:30:24.959530
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """Tests the method try_utime
    """

    import os
    import tempfile

    path = os.path.join(tempfile.gettempdir(), 'test_FileDownloader_try_utime.tmp')

    if os.path.isfile(path):
        os.remove(path)


# Generated at 2022-06-12 16:30:36.118386
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    downloader = FileDownloader(None, params={})
    d = {
        'status': 'finished',
        'elapsed': 3.2,
        'total_bytes': 6969,
        'filename': 'foo.mp4',
    }
    downloader.report_progress(d)

    d = {'status': 'downloading', 'filename': 'foo.mp4', 'downloaded_bytes': 1000}
    downloader.report_progress(d)
    d = {'status': 'downloading', 'filename': 'foo.mp4', 'speed': 100, 'eta': 42, 'downloaded_bytes': 1000}
    downloader.report_progress(d)

# Generated at 2022-06-12 16:30:48.666659
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def fake_info_dict():
        return {'ext': 'mkv', 'title': 'Test video'}
    fd = FileDownloader(None, params={'nooverwrites': True})
    # Test nopart
    info_dict = fake_info_dict()
    filename = fd.temp_name('test video.%(ext)s')
    assert filename == 'test video.mkv.part'
    assert fd.download(filename, info_dict)
    filename = fd.temp_name('test video.%(ext)s')
    assert filename == 'test video.mkv'
    assert fd.download(filename, info_dict)
    # Test normal cases
    info_dict = fake_info_dict()

# Generated at 2022-06-12 16:31:01.443962
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import os

    def _test_FileDownloader_report_progress_sub(self):
        url = 'http://example.com/video.mp4'
        filename = 'video.mp4'
        filename_display = os.path.basename(filename)

        # Test report_progress when download is finished
        self.ydl.params['noprogress'] = True
        self.report_progress({
            'status': 'finished',
        })
        self.assertEqual(self.ydl.msgs, [])

        self.ydl.params['noprogress'] = False
        self.report_progress({
            'status': 'finished',
        })

# Generated at 2022-06-12 16:31:13.264899
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    from tempfile import mkdtemp
    import shutil
    
    dname = mkdtemp(prefix='youtube-dl-test.')

# Generated at 2022-06-12 16:31:51.358762
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(FakeYoutubeDL(), params = {})
    test_times = [(0,0,0), (0,1,1), (10,0,0), (10,1,1), (1,1,1), (1,10,10), (10,10,10)]
    for start, now, byte_counter in test_times:
        fd.slow_down(start, now, byte_counter)

if __name__ == '__main__':
    test_FileDownloader_slow_down()

# Generated at 2022-06-12 16:31:59.780635
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    filetime = fd.try_utime('/tmp/foo.txt', None)
    assert filetime is None, 'File time for inexistent file is None'

    fd.to_screen('Creating file /tmp/foo.txt')
    foofile = open('/tmp/foo.txt', 'w')
    foofile.write('foobar')
    foofile.close()

    filetime = fd.try_utime('/tmp/foo.txt', None)
    assert filetime is None, 'File time for existent file without last modified is None'

    fd = FileDownloader({'dump_intermediate_pages': True})
    fd.to_screen('Creating file /tmp/foo.txt')

# Generated at 2022-06-12 16:32:11.717357
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-12 16:32:13.109777
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from types import FunctionType
    assert False, "Not implemented"

# Generated at 2022-06-12 16:32:21.202630
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test 1
    params = {'outtmpl': '%(id)s-%(title)s.%(ext)s',
              'id': 'hQVTdjn8nSY', 'ext': 'mp4',
              'title': 'YouTube - “My Classical Guitar Pt1 - Guy Buttery”',
              'nopart': True,
              'autonumber_size': '5',
              'autonumber': True}
    fd = FileDownloader(params)
    assert fd.params.get('nopart') == True
    assert fd.temp_name(fd.params['outtmpl']) == '%(id)s-%(title)s.%(ext)s'

test_FileDownloader_temp_name()

# Generated at 2022-06-12 16:32:32.463337
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '1024'})
    start = time.time()
    fd.slow_down(start, start + 0.5, 1024)
    print(round(time.time() - (start + 0.5), 2) == 0.0)
    fd.slow_down(start, start + 0.05, 1024)
    print(round(time.time() - (start + 0.05), 2) == 0.0)
    fd.slow_down(start, start + 0.5, 512)
    print(round(time.time() - (start + 0.5), 2) == 0.5)

# Generated at 2022-06-12 16:32:42.760727
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader({})
    assert fd.parse_bytes('') is None
    assert fd.parse_bytes('a') is None
    assert fd.parse_bytes('a0') is None
    assert fd.parse_bytes('0a') is None
    assert fd.parse_bytes('0') == 0
    assert fd.parse_bytes('1') == 1
    assert fd.parse_bytes('12') == 12
    assert fd.parse_bytes('123') == 123
    assert fd.parse_bytes('1234') == 1234
    assert fd.parse_bytes('1b') == 1
    assert fd.parse_bytes('1B') == 1
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024

# Generated at 2022-06-12 16:32:54.244060
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params={'noprogress': False})
    s = {
        'downloaded_bytes': 0,
        'total_bytes': 10,
    }
    fd.report_progress(s)

    s = {
        'downloaded_bytes': 3,
        'total_bytes': 10,
    }
    fd.report_progress(s)

    s = {
        'downloaded_bytes': 10,
        'total_bytes': 10,
        'elapsed': 10
    }
    fd.report_progress(s)

    fd = FileDownloader(params={'noprogress': True})
    s = {
        'downloaded_bytes': 0,
        'total_bytes': 10,
    }
    fd.report_progress(s)

    s

# Generated at 2022-06-12 16:33:04.236715
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    args = ['-r', '1', 'foo']
    # Test with ratelimit not set
    ydl = YoutubeDL(args)
    fd = FileDownloader({}, ydl)
    start = time.time()
    fd.slow_down(start, start + 0.5, 1)
    assert time.time() - start < 0.5
    # Test with ratelimit set
    fd.params['ratelimit'] = 0.5
    fd.slow_down(start, start + 0.5, 100)
    assert time.time() - start > 0.5


# Generated at 2022-06-12 16:33:16.455801
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('   1 ') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes(' 1 k ') == 1024
    assert FileDownloader.parse_bytes('1 m') == 1024 * 1024
    assert FileDownloader.parse_bytes('  1 m ') == 1024 * 1024
    assert FileDownloader.parse_bytes('1m1') == 1024 * 1024 + 1
    assert FileDownloader.parse_bytes('1m1k') == 1024 * 1024 + 1024
    assert FileDownloader.parse_bytes('1m1k1') == 1024 * 1024 + 1024 + 1
    assert FileDownloader.parse_bytes('1.1m1.1k1.1') == 1024 * 1024 + 1024