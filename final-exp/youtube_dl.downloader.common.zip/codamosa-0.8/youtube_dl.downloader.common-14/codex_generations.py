

# Generated at 2022-06-12 16:24:15.864694
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Check if slow_down respects max rate limit
    f = FileDownloader({'max_ratelimit': 1024}, None)
    start_time = time.time()
    f.slow_down(start_time, start_time + 0.5, 1024 * 1024 * 1024)
    end_time = time.time()
    assert end_time - start_time >= 0.5, 'Took too little time, maybe rate limit exceeded'
    assert end_time - start_time <= 0.6, 'Slept too long'

    # Check if it doesn't sleep when not needed
    f = FileDownloader({'max_ratelimit': 1024}, None)
    start_time = time.time()
    f.slow_down(start_time, start_time + 1, 512)
    end_time = time.time()
    assert end_

# Generated at 2022-06-12 16:24:25.666667
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Arrange
    fd = FileDownloader(param={'nopart': False})
    # Act
    name = fd.undo_temp_name('test.abc.part')
    # Assert
    assert name == 'test.abc', 'Should return name without .part'

    # Act
    name = fd.undo_temp_name('test.part')
    # Assert
    assert name == 'test', 'Should return name without .part'

    # Act
    name = fd.undo_temp_name('test.mp3')
    # Assert
    assert name == 'test.mp3', 'Should return name without .part'

# Generated at 2022-06-12 16:24:36.846469
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(params=dict(), progress_hooks=[])

    def format_bytes(bytes):
        if bytes is None:
            return 'N/A'
        if type(bytes) is str:
            bytes = float(bytes)
        if bytes == 0.0:
            exponent = 0
        else:
            exponent = int(math.log(bytes, 1024.0))
        suffix = 'bkMGTPEZY'[exponent]
        converted = float(bytes) / float(1024**exponent)
        return '%.2f%s' % (converted, suffix)

    def open_for_write_count_bytes(filename, mode='w', buffering=-1):
        filename = encodeFilename(filename)
        file_obj = open(filename, mode, buffering)
        file_obj.write

# Generated at 2022-06-12 16:24:45.476607
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    """Tests the FileDownloader.slow_down() method"""
    import tempfile
    import shutil
    import os
    import sys

    filesize = 1000
    ratelimit = 500

    orig_sleep = time.sleep


# Generated at 2022-06-12 16:24:50.077021
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    test_fd = FileDownloader(None, params = None)
    test_fd.to_screen = lambda *args : 0

# Generated at 2022-06-12 16:24:59.099968
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('myvideo.flv') == 'myvideo.flv.part'
    assert FileDownloader.temp_name('myvideo.flv.part') == 'myvideo.flv.part'
    assert FileDownloader.temp_name('http://fakeurl.com/video.flv') == 'video.flv.part'
    assert FileDownloader.temp_name('/tmp/video.flv') == '/tmp/video.flv.part'


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 16:25:08.902238
# Unit test for method calc_speed of class FileDownloader

# Generated at 2022-06-12 16:25:20.565351
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys
    # Create instance of FileDownloader
    fd = FileDownloader({})
    # Test exception is raised if real_download method is not present
    try:
        fd.download('test-filename', 'test-info_dict')
    except AssertionError:
        pass
    else:
        sys.exit('Test failed')
    # Create subclasses with real_download method (dummy method)
    class DummyFD(FileDownloader):
        def real_download(self, filename, info_dict):
            return True
    class DummyFD1(DummyFD):
        def real_download(self, filename, info_dict):
            return False
    # Create instances of subclasses
    fd1 = DummyFD({})
    fd2 = DummyFD1({})
    # Test if return value is

# Generated at 2022-06-12 16:25:29.530442
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from collections import defaultdict
    from types import SimpleNamespace

    # format_percent()
    assert FileDownloader.format_percent(0) == '  0%'
    assert FileDownloader.format_percent(0.5) == ' 50%'
    assert FileDownloader.format_percent(1.0) == '100%'

    # format_eta()
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(0) == '00:00'
    assert FileDownloader.format_eta(30) == '00:30'
    assert FileDownloader.format_eta(60) == '01:00'
    assert FileDownloader.format_eta(61) == '01:01'

# Generated at 2022-06-12 16:25:42.079885
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')

# Generated at 2022-06-12 16:26:01.104714
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-12 16:26:13.384320
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def slow_down(fd, start_time, now, byte_counter, rate_limit=None, sleep_time_expected=None):
        fd.slow_down(start_time, now, byte_counter, rate_limit)
        return time.time() - now

    fd = FileDownloader({})

    # No rate limit, no sleep should occur
    assert slow_down(fd, 0, 0, 0) == 0

    # Rate limit reached, no sleep should occur
    assert slow_down(fd, 0, 0, 1024, 1024) == 0

    # Rate limit not reached, sleep should occur
    now = time.time()
    assert slow_down(fd, now, now, 0, 1024) == 0.125
    assert slow_down(fd, now, now, 1, 1024) == 0.25

    # Rate limit not

# Generated at 2022-06-12 16:26:19.764756
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('video.mp4.part') == 'video.mp4'
    assert fd.undo_temp_name('video.mp4.html') == 'video.mp4.html'
    assert fd.undo_temp_name('video.mp4.part.html') == 'video.mp4.html'
    assert fd.undo_temp_name('video.mp4.part.unknown') == 'video.mp4.part.unknown'


# Generated at 2022-06-12 16:26:32.710797
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    """Make sure that FileDownloader.temp_name returns the same value for
    same input parameters (nopart, filename) independent of when it is called
    """
    # TODO Add some more tests with parameters

    fd = FileDownloader({'nopart': True}, None)
    assert fd.temp_name('blabla.flv') == 'blabla.flv'

    fd = FileDownloader({'nopart': False}, None)
    assert fd.temp_name('blabla.flv') == 'blabla.flv.part'
    assert fd.temp_name('/path/to/blabla.flv') == '/path/to/blabla.flv.part'

    fd = FileDownloader({'nopart': True}, None)
    assert fd

# Generated at 2022-06-12 16:26:43.618473
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(params={})

    time_started = time.time()
    fd.slow_down(time_started, time_started, 11)
    assert time.time() == pytest.approx(time_started)

    fd.params['ratelimit'] = 10
    fd.slow_down(time_started, time_started, 11)
    assert time.time() == pytest.approx(time_started + 1)

    fd.params['ratelimit'] = 10
    fd.slow_down(time_started, time_started + 1, 11)
    assert time.time() == pytest.approx(time_started + 2)

    fd.params['ratelimit'] = 20
    fd.slow_down(time_started, time_started + 1, 11)
    assert time

# Generated at 2022-06-12 16:26:49.911983
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(1, 11, 10) == 1
    assert fd.calc_speed(1, 10, 10) is None
    assert fd.calc_speed(2, 3, 1) == 0.5


# Generated at 2022-06-12 16:27:02.358302
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    class FakeYdl(FileDownloader):
        def __init__(self):
            self.ydl = self

        def to_screen(self, s, skip_eol=False):
            lines = s.splitlines()
            for line in lines[:-1]:
                print(line)
            if lines[-1] != '':
                print(lines[-1], end='')
            elif not skip_eol:
                print()

        def report_error(self, *args, **kargs):
            pass

        def to_console_title(self, title):
            pass

    fd = FakeYdl()
    fd.report_progress({'status': 'finished'})
    fd.report_progress({'status': 'finished', 'elapsed': 1.5})
    fd.report_progress

# Generated at 2022-06-12 16:27:10.281471
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockTime(object):
        def __init__(self):
            self.time = 0

        def sleep(self, t):
            self.time += t

        def time(self):
            return self.time
    mocktime = MockTime()
    download = FileDownloader({'ratelimit': 1, 'retries': 0})
    download.slow_down(mocktime.time(), mocktime.time(), 11)
    assert mocktime.time() == 10
    download.slow_down(mocktime.time(), mocktime.time(), -1)
    assert mocktime.time() == 10
    download.slow_down(mocktime.time(), mocktime.time(), 5)
    assert mocktime.time() == 10
    download.slow_down(mocktime.time(), mocktime.time(), 100)
    assert mock

# Generated at 2022-06-12 16:27:23.282841
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    def check(s, ret):
        assert s == FileDownloader.format_seconds(ret)
        assert ret == FileDownloader.parse_bytes(s)
        assert ret == FileDownloader.parse_bytes(ret)

    for i in range(7):
        check('%d:00' % i, i * 60)

    check('0:05', 5)
    check('0:05.3', 5.3)
    check('0:05.34', 5.34)
    check('0:05.345', 5.345)
    
    check('5.3', 5.3)
    check('5.34', 5.34)
    check('5.345', 5.345)
    check('5.3456', 5.3456)
    check('5.34567', 5.34567)
    check

# Generated at 2022-06-12 16:27:34.816846
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    test_cases = [
        # filename, nopart, result
        ('full', True, 'full'),
        ('full', False, 'full.part'),
        ('/tmp/full', True, '/tmp/full'),
        ('/tmp/full', False, '/tmp/full.part'),
        ('/tmp/full.mp4', True, '/tmp/full.mp4'),
        ('/tmp/full.mp4', False, '/tmp/full.mp4.part'),
        ('-', True, '-'),
        ('-', False, '-.part'),
        ('/dev/null', True, '/dev/null'),
        ('/dev/null', False, '/dev/null.part'),
    ]

# Generated at 2022-06-12 16:28:11.477968
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({'noprogress': False}, None)

    # Test without total_bytes
    fd.report_progress({
        'downloaded_bytes': 0,
        'status': 'downloading',
        'total_bytes': None,
        'speed': None,
        'eta': None
    })
    fd.report_progress({
        'downloaded_bytes': 100,
        'status': 'downloading',
        'total_bytes': None,
        'speed': 100,
        'eta': None
    })
    fd.report_progress({
        'downloaded_bytes': 0,
        'status': 'downloading',
        'total_bytes': None,
        'speed': None,
        'eta': 0
    })

# Generated at 2022-06-12 16:28:13.197077
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    dl = FileDownloader({})
    # Execute method
    assert dl.undo_temp_name('abc.part') == 'abc'
    assert dl.undo_temp_name('abc') == 'abc'


# Generated at 2022-06-12 16:28:18.343638
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # Number of retries
    retries = 5
    # Result of fd.format_retries()
    result = FileDownloader.format_retries(retries)
    # Verify result
    assert result == '5'
    # Number of retries
    retries = float('inf')
    # Result of fd.format_retries()
    result = FileDownloader.format_retries(retries)
    # Verify result
    assert result == 'inf'

# Generated at 2022-06-12 16:28:31.785545
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    downloader = FileDownloader({})

    with open(__file__, 'rb') as f:
        test_data = f.read()

    expected_result = True
    result = downloader.real_download(
        os.path.join(gettempdir(), 'test.out'),
        {'url': 'data:application/octet-stream;base64,' + base64.standard_b64encode(test_data).decode('ascii')},
    )
    assert result == expected_result
    assert os.path.exists(os.path.join(gettempdir(), 'test.out'))

    with open(os.path.join(gettempdir(), 'test.out'), 'rb') as f:
        result = f.read()
    expected_result = test_data
    assert result == expected_result

# Generated at 2022-06-12 16:28:37.857603
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    test_inst = FileDownloader({'ratelimit':1024})
    test_inst._sleep_time = 0
    test_inst.slow_down(time.time(), None, 512)
    assert test_inst._sleep_time == 0
    test_inst.slow_down(time.time(), None, 1024)
    assert test_inst._sleep_time != 0

#test_FileDownloader_slow_down()

# Generated at 2022-06-12 16:28:45.535125
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == u'0:00'
    assert FileDownloader.format_seconds(12) == u'0:12'
    assert FileDownloader.format_seconds(60) == u'1:00'
    assert FileDownloader.format_seconds(61) == u'1:01'
    assert FileDownloader.format_seconds(3600) == u'1:00:00'
    assert FileDownloader.format_seconds(3660) == u'1:01:00'
    assert FileDownloader.format_seconds(87262) == u'24:17:42'



# Generated at 2022-06-12 16:28:58.551427
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    def clear_FileDownloader_try_utime():
        FileDownloader.try_utime.__func__.func_defaults = None

    # Test for FileDownloader.try_utime(filename, last_modified_hdr)
    # Return True on success and False otherwise

    # Test for FileDownloader.try_utime(filename, last_modified_hdr)
    # filename = 'temp_date.txt'
    # last_modified_hdr = 'Fri, 10 Feb 2017 10:10:10 GMT'
    # Expected value: True(Success)
    clear_FileDownloader_try_utime()
    testing_file = open('test/test_date.txt', 'w')
    testing_file.close()

# Generated at 2022-06-12 16:29:07.885765
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .utils import FakeYDL
    from .YoutubeDL import YoutubeDL, DEFAULT_OUTTMPL
    fd = FileDownloader({}, YoutubeDL, FakeYDL())
    assert fd.download('foo', {'status': 'finished', 'total_bytes': '100'}) == True
    fd.params['noprogress'] = True
    assert fd.download('foo', {'status': 'finished', 'total_bytes': '100'}) == True
    assert fd.download('foo', {'status': 'downloading', 'total_bytes': '100', '_percent_str': '10.0%', '_eta_str': '100', '_speed_str': '100', '_total_bytes_str': '100'}) == True

# Generated at 2022-06-12 16:29:16.494819
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('13') == 13
    assert FileDownloader.parse_bytes('13k') == 13 * (1 << 10)
    assert FileDownloader.parse_bytes('13M') == 13 * (1 << 20)
    assert FileDownloader.parse_bytes('13G') == 13 * (1 << 30)

# Generated at 2022-06-12 16:29:28.094434
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader({})
    def t(input, output):
        """Test parse_bytes(input) == output"""
        result = fd.parse_bytes(input)
        if result != output:
            print('parse_bytes(%s) => %s != %s' % (input, result, output))
            return False
        else:
            return True

    assert t('12345', 12345)
    assert t('12k', 12 * 1024)
    assert t('12M', 12 * 1024 * 1024)
    assert t('12G', 12 * 1024 * 1024 * 1024)
    assert t('12.5k', 12 * 1024 + 512)
    assert t('12.5M', 12 * 1024 * 1024 + 512 * 1024)

# Generated at 2022-06-12 16:29:47.318637
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    params = {'logger': MockLogger()}

    fd = FileDownloader(params)

    host_speed_limit = 100.0 / 8
    params['ratelimit'] = host_speed_limit

    start_time = time.time()
    now = start_time
    byte_counter = itertools.count()

    fd.slow_down(start_time, now, next(byte_counter))

    remaining_bytes = (host_speed_limit * 4)
    while remaining_bytes > 0:
        now += 1
        fd.slow_down(start_time, now, next(byte_counter))
        remaining_bytes -= host_speed_limit

# Generated at 2022-06-12 16:29:59.597718
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Create an instance of class object Downloader to call its methods
    ydl = youtube_dl.YoutubeDL()  
    fd = youtube_dl.FileDownloader(ydl, {'noprogress':False,'nopart': False,'verbose': True})

    # Test progress status 'finished'

# Generated at 2022-06-12 16:30:09.966988
# Unit test for method format_seconds of class FileDownloader

# Generated at 2022-06-12 16:30:21.810898
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # This is a test for FileDownloader.report_progress()
    import unittest

    # We will use this function as a hook for report_progress. It simply
    # records all calls to the hook
    def hook(d):
        hook.last_downloaded_bytes = d['downloaded_bytes']
        hook.last_total_bytes = d['total_bytes']
        hook.last_status = d['status']
    hook.last_downloaded_bytes = None
    hook.last_total_bytes = None
    hook.last_status = None
    hook.res = None

    # Now we do some tests

# Generated at 2022-06-12 16:30:29.523157
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import time as time_module
    # None
    try_utime_call = FileDownloader().try_utime(
        'filename', None)
    assert try_utime_call is None
    # a big year
    try_utime_call = FileDownloader().try_utime(
        'filename', '19500101')
    assert try_utime_call is None
    # a bad year
    try_utime_call = FileDownloader().try_utime(
        'filename', '000000')
    assert try_utime_call is None
    # a good year
    try_utime_call = FileDownloader().try_utime(
        'filename', '20000101')
    assert try_utime_call == 946684800.0


# Unit tests for the speed calculation methods

# Generated at 2022-06-12 16:30:42.326614
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def _test_report_progress(ydl, noprogress_bool, progress_with_newline_bool):
        ydl._progress_hooks = []
        ydl.params['noprogress'] = noprogress_bool
        ydl.params['progress_with_newline'] = progress_with_newline_bool

        def _test(ydl, s):
            ydl.report_progress(s)
            if ydl.params.get('noprogress') or s['status'] != 'downloading' or not ydl._progress_hooks:
                return
            # We use ydl.params['noprogress'] instead of noprogress_bool
            # because FileDownloader may override them (for example
            # in FileDownloader.report_progress).

# Generated at 2022-06-12 16:30:53.297338
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    dl = FileDownloader({})
    eq = dl.temp_name('/foo/bar/baz')
    eq_('/foo/bar/baz.part', eq)
    eq = dl.temp_name('/foo/bar/baz.part')
    eq_('/foo/bar/baz.part', eq)
    eq = dl.temp_name('/foo/bar/baz/')
    eq_('/foo/bar/baz', eq)

    dl = FileDownloader({'nopart': True})
    eq = dl.temp_name('/foo/bar/baz')
    eq_('/foo/bar/baz', eq)
    eq = dl.temp_name('/foo/bar/baz.part')

# Generated at 2022-06-12 16:31:05.869777
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader({})
    assert fd.calc_speed(0,0,0) is None
    assert fd.calc_speed(0,10,0) is None
    assert fd.calc_speed(0,0,10) is None
    assert fd.calc_speed(0,10,10) is None
    assert fd.calc_speed(0,10,100) == 10
    assert fd.calc_speed(0,10,10000) == 1000
    assert fd.calc_speed(0,10,1000000) == 100000
    assert fd.calc_speed(10,20,10000) == 500
    assert fd.calc_speed(10,20,100000) == 5000

# Generated at 2022-06-12 16:31:17.388938
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    import sys
    import time
    from collections import namedtuple

    from .YoutubeDL import YoutubeDL

    if sys.platform.startswith('win'):
        return

    def fake_sleep(n):
        time.sleep(n)

    def fake_time():
        return time.time()

    def fake_write_string(s):
        sys.stderr.write(s)

    def fake_get_term_width():
        return 80

    def fake_format_bytes(n):
        return str(n)

    def fake_format_seconds(n):
        return '%d.00' % n

    def fake_format_eta(n):
        return '%d:00:00' % n

    def fake_format_percent(n):
        return '%02.0f%%' % n

# Generated at 2022-06-12 16:31:21.382225
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Since the implementation is quite simple, we mostly just test that it
    # doesn't throw exceptions
    fd = FileDownloader(None)
    fd.slow_down(None, None, 10)

# Generated at 2022-06-12 16:31:47.406694
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('myfile.size') == 'myfile.size.part'
    assert fd.temp_name('.size') == '.size.part'
    assert fd.temp_name('myfile.size.part') == 'myfile.size.part'
    assert fd.temp_name('myfile') == 'myfile.part'
    assert fd.temp_name('.myfile') == '.myfile.part'
    assert fd.temp_name('myfile.part') == 'myfile.part'
    assert fd.temp_name('/path/to/myfile.size') == '/path/to/myfile.size.part'

# Generated at 2022-06-12 16:31:57.487146
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'quiet': True})
    # simple test (start and end are in the same interval)
    fd.slow_down(3,4,100)
    assertTrue(fd.params['sleep_interval'] == 0)

    fd.params['sleep_interval'] = 1
    # test that we dont sleep if we are faster than the rate
    # interval 1: 0-100 bytes, interval 2: 100-200 bytes
    fd.slow_down(1,2,200)
    assertTrue(fd.params['sleep_interval'] == 0)

    # test that we sleep 'enough' if we are slower than the rate
    fd.slow_down(1,2,50)
    assertTrue(fd.params['sleep_interval'] == 0.25)

    # test a long interval (more

# Generated at 2022-06-12 16:32:08.136026
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader({})
    return (fd.parse_bytes('1') == 1 and
            fd.parse_bytes('1G') == 1073741824 and
            fd.parse_bytes('1g') == 1073741824 and
            fd.parse_bytes('1gb') == 1073741824 and
            fd.parse_bytes('1mb') == 1048576 and
            fd.parse_bytes('1kb') == 1024 and
            fd.parse_bytes('1024') == 1024 and
            fd.parse_bytes('1,024') == 1024 and
            fd.parse_bytes('1,024kb') == 1024)
assert test_FileDownloader_parse_bytes()


# Generated at 2022-06-12 16:32:17.421006
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import shutil
    from tempfile import mkdtemp
    from .extractor import get_info_extractor
    from .compat import cmd_read_binary

# Generated at 2022-06-12 16:32:24.146842
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def _test(fname, last_modified_hdr, ftime):
        with open(fname, 'wb') as f:
            f.write(b'a')
        fd = FileDownloader({'outtmpl': 'filename'})
        assert fd.try_utime(fname, last_modified_hdr) == ftime
    import shutil
    import tempfile


# Generated at 2022-06-12 16:32:36.215519
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    import tempfile
    import shutil
    import os


# Generated at 2022-06-12 16:32:43.753872
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import tempfile
    from .extractor.common import InfoExtractor

    info = {'url': 'http://example.com', 'playlist_title': 'Testing slow_down method',
            'playlist_id' : 'Test_playlist_id', 'playlist' : [],
            'title': 'Testing slow_down method', 'id' : 'Test_id', 'ext': 'mp3'}
    ie = InfoExtractor()
    ie._ents = [info]

    class MockFD(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.to_screen = lambda *args: None

        def download(self, filename, info):
            return True


# Generated at 2022-06-12 16:32:55.900665
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import youtube_dl.utils

    class FakeYDL(object):
        def __init__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr

        def to_screen(self, msg, skip_eol=True):
            print(msg)

    class FakeFD(FileDownloader):
        def __init__(self, params):
            self.ydl = FakeYDL()
            self.params = params
            self._progress_hooks = []


# Generated at 2022-06-12 16:33:02.616197
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})

    filename = fd.undo_temp_name('foo')
    assert filename == 'foo'

    filename = fd.undo_temp_name('foo.part')
    assert filename == 'foo'

    filename = fd.undo_temp_name('foo.part.bar')
    assert filename == 'foo.part.bar'

# Generated at 2022-06-12 16:33:15.116085
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, {'continuedl': True})

    def test_block_size():
        for size in [1, 2, 8, 16, 64, 128, 256, 512, 1024, 2048, 4096, 8192]:
            for elapsed in [0.1, 0.2, 0.4, 0.8, 1.6, 3.2]:
                # If the download speed is higher than the block size we
                # should increase the block size to speed up the download.
                if size / elapsed < 512:
                    assert fd.best_block_size(-1, -1) == 8192
                    assert fd.best_block_size(elapsed, size) < fd.best_block_size(-1, -1)

                # If the download speed is lower than the block size we should
                # decrease the block size