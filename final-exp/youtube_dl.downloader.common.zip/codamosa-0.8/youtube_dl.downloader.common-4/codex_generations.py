

# Generated at 2022-06-12 16:23:58.300076
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = FileDownloader(ydl)
    print(sys.modules.keys())
    assert('sys.modules' in sys.modules.keys())
    print(sys.modules['sys.modules'])
    assert(fd.format_percent(0) == '0.00%')
    assert(fd.format_percent(0.0001) == '0.00%')
    assert(fd.format_percent(0.001) == '0.01%')
    assert(fd.format_percent(0.009) == '0.09%')
    assert(fd.format_percent(0.01) == '0.10%')
    assert(fd.format_percent(0.1) == '10.00%')

# Generated at 2022-06-12 16:24:10.477802
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    ydl = YoutubeDL(params={})
    fd = FileDownloader(ydl, params={})
    s = {}


# Generated at 2022-06-12 16:24:19.871510
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-12 16:24:32.940234
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    class Calc_elapsed_time_mock():
        def __init__(self):
            self.time_mock = [0.5, 1, 2, 4]
        def __call__(self):
            return self.time_mock.pop(0)
    fd._calc_elapsed_time = Calc_elapsed_time_mock()
    class Sleep_mock():
        def __init__(self):
            self.sleep_time_mock = [1.5, 1.75, 1.25, 2.5]
        def __call__(self, time):
            if time == 2:
                assert self.sleep_time_mock == [1.25, 2.5]
            elif time == 1:
                assert self.sleep_time

# Generated at 2022-06-12 16:24:37.570570
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    assert FileDownloader.format_eta(None) == '--:--'
    assert FileDownloader.format_eta(60) == '00:01'
    assert FileDownloader.format_eta(65) == '00:01'
    assert FileDownloader.format_eta(3601) == '01:00:01'
    assert FileDownloader.format_eta(7261) == '02:01:01'


# Generated at 2022-06-12 16:24:40.336263
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(YoutubeDL(), {})
    fd.to_screen = Mock()
    fd.report_file_already_downloaded("foo")
    fd.to_screen.assert_called_with("[download] foo has already been downloaded")


# Generated at 2022-06-12 16:24:53.345072
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    start_time = time.time()
    fd = FileDownloader({'ratelimit': None})
    # One millisecond
    fd.slow_down(start_time, start_time, 1)
    assert (time.time() - start_time) <= 0.001
    # 128 bytes
    fd.slow_down(start_time, start_time, 128)
    assert (time.time() - start_time) <= 0.001
    # 512 bytes
    fd.slow_down(start_time, start_time, 512)
    assert (time.time() - start_time) <= 0.004
    # 1024 bytes (1 KB)
    fd.slow_down(start_time, start_time, 1024)
    assert (time.time() - start_time) <= 0.008
    # 16382 bytes

# Generated at 2022-06-12 16:24:58.572651
# Unit test for method format_eta of class FileDownloader
def test_FileDownloader_format_eta():
    fd = FileDownloader({})
    assert fd.format_eta(0) == '0:00'
    assert fd.format_eta(59) == '0:59'
    assert fd.format_eta(60) == '1:00'
    assert fd.format_eta(61) == '1:01'
    assert fd.format_eta(3599) == '59:59'
    assert fd.format_eta(3600) == '1:00:00'
    assert fd.format_eta(3661) == '1:01:01'
    assert fd.format_eta(None) == '--:--'

# Generated at 2022-06-12 16:25:01.375818
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    """Test cases for slow_down method in class FileDownloader"""
    fd = FileDownloader(params={})
    assert fd.slow_down(1514764800, 1514764800, 100) is None



# Generated at 2022-06-12 16:25:04.758213
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    parameter = "filename.part"
    expected_result = "filename"
    actual_result = FileDownloader.undo_temp_name(parameter)
    assert actual_result == expected_result


# Generated at 2022-06-12 16:25:14.713871
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('filename.part') == 'filename'
    assert fd.undo_temp_name('filename') == 'filename'
 

# Generated at 2022-06-12 16:25:19.081016
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(1000, 0) == 2
    assert fd.best_block_size(1000, 1000) == 1
    assert fd.best_block_size(0.1, 1000) == 2097152



# Generated at 2022-06-12 16:25:28.760179
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def test(raw_bytes, parsed_bytes):
        result = FileDownloader.parse_bytes(raw_bytes)
        assert result == parsed_bytes, 'Expected %s, but got %s' % (parsed_bytes, result)

    test('1b', 1)
    test('1k', 1024)
    test('1K', 1024)
    test('1m', 1024**2)
    test('1M', 1024**2)
    test('1GB', 1024**3)
    test('1 GiB', 1024**3)
    test('1 TB', 1024**4)
    test('1 TiB', 1024**4)
    test('1 PB', 1024**5)
    test('1 PiB', 1024**5)
    test('1 EB', 1024**6)

# Generated at 2022-06-12 16:25:31.511029
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():

    fd = FileDownloader({})
    print("test_FileDownloader_calc_speed: {}".format(fd.calc_speed(0,0,0)))



# Generated at 2022-06-12 16:25:44.034649
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test normal behavior: slow down if rate limit is exceeded
    d = FileDownloader({'ratelimit': 10, 'retries': 0})
    d.start = time.time()
    d.downloaded_bytes = 11
    d.slow_down(d.start, d.start + 1, 11)
    assert d.downloaded_bytes == 11
    time.sleep(1)
    d.downloaded_bytes = 12
    d.slow_down(d.start, time.time(), 12)
    assert d.downloaded_bytes == 12

    # Test rate limit = 0 (means no rate limit)
    d = FileDownloader({'ratelimit': 0, 'retries': 0})
    d.start = time.time()
    d.downloaded_bytes = 11
    time.sleep(1)
    d.slow

# Generated at 2022-06-12 16:25:53.344966
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    import unittest
    from .test_utils import FakeYDL
    f = FileDownloader({}, FakeYDL(), {})
    assert f.calc_speed(0, 0, 0) == None
    assert f.calc_speed(0, 0.001, 100) == 100000
    assert f.calc_speed(0, 0.001, 30) == 30000
    # Test with float division (depends on the Python version, can be
    # result is 499999.9999999999 or 500000.0
    assert f.calc_speed(0, 0.002, 500) in [499999.9999999999, 500000.0]
    assert f.calc_speed(0, 0.002, 300) == 150000


# Generated at 2022-06-12 16:26:06.217532
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(2) == '0:02'
    assert FileDownloader.format_seconds(59) == '0:59'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(61) == '1:01'
    assert FileDownloader.format_seconds(3599) == '59:59'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3601) == '1:00:01'
    assert FileDownloader.format_seconds(3661) == '1:01:01'

# Generated at 2022-06-12 16:26:17.219166
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFD(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    def report_progress_test(filename, reports):
        """
        Run unit test for FileDownloader.report_progress

        filename: the file to set in reports (only 'filename' is used)
        reports: a list of dictionaries of the form:
            {
             'status': ... (one of 'downloading', 'finished', 'error'),
             'elapsed': ...,
             'eta': ...,
             'total_bytes': ...,
             'downloaded_bytes': ...,
             'total_bytes_estimate': ...,
             'speed': ...,
            }
        """
        fd = TestFD({'noprogress': False})

        def test_report_progress(status):
            predicted

# Generated at 2022-06-12 16:26:24.818837
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader(None).undo_temp_name("abc.part.tmp") == "abc.part"
    assert FileDownloader(None).undo_temp_name("abc.part") == "abc.part"
    assert FileDownloader(None).undo_temp_name("abc.part.") == "abc.part."
    assert FileDownloader(None).undo_temp_name("abc.part") == "abc.part"

# Generated at 2022-06-12 16:26:37.614483
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Validate FileDownloader.download returns True on success
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'outtmpl': '%(id)s-%(ext)s'})
    fd = FileDownloader(ydl, {'continuedl': True})
    info_dict = {
        'format': '341',
        'ext': 'webm',
        '_filename': '1-341.webm',
        'http_headers': {'Content-Disposition': 'foo; filename="1-341.webm"'},
    }
    assert fd.download('1-341.webm', info_dict)
    os.remove('1-341.webm')
    os.remove('1-341.part')

    # Test file already downloaded
    info_dict

# Generated at 2022-06-12 16:27:01.990055
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    fd = FileDownloader({})
    b = fd.best_block_size(0.0, 1.0)
    assert (b == 1.0)
    b = fd.best_block_size(0.0, 10.0)
    assert (b == 1.0)
    b = fd.best_block_size(0.0, 100.0)
    assert (b == 1.0)
    b = fd.best_block_size(1.0, 1.0)
    assert (b == 1.0)
    b = fd.best_block_size(1.0, 2.0)
    assert (b == 1.0)
    b = fd.best_block_size(1.0, 5.0)
    assert (b == 1.0)

# Generated at 2022-06-12 16:27:10.059034
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    # (elapsed time, bytes) -> expected block size
    tests = [
        # Increase block size if we download fast
        (0.8, 0, 4194304),
        (0.8, 1024, 4194304),
        (0.8, 10240, 4194304),
        (0.8, 102400, 4194304),
        (0.8, 1048576, 4194304),
        # Decrease block size if we download slow
        (10, 0, 1),
        (10, 1024, 1),
        (10, 10240, 1),
        (10, 102400, 512),
        (10, 1048576, 8192),
    ]

# Generated at 2022-06-12 16:27:19.755334
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def fake_FileDownloader_slow_down(self, start_time, now, byte_counter):
        return byte_counter
    dl = FileDownloader({})
    dl.slow_down = fake_FileDownloader_slow_down
    dl.params['ratelimit'] = None
    assert dl.slow_down(0, 0, 0) == 0
    dl.params['ratelimit'] = 42
    assert dl.slow_down(0, 0, 42) == 0

# Generated at 2022-06-12 16:27:26.248949
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})
    assert fd.undo_temp_name('a') == 'a'
    assert fd.undo_temp_name('a.part') == 'a'
    assert fd.undo_temp_name('a.b.part') == 'a.b'
    assert fd.undo_temp_name('a.part.part') == 'a.part'
    assert fd.undo_temp_name('a.part.part.part') == 'a.part'
    assert fd.undo_temp_name('a.part.b.part') == 'a.part.b'



# Generated at 2022-06-12 16:27:37.957403
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-12 16:27:41.280716
# Unit test for method undo_temp_name of class FileDownloader

# Generated at 2022-06-12 16:27:51.975674
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, params={'noprogress': False})
    fd.report_progress({'_percent_str': '35.5%', '_total_bytes_str': '2.43MiB', '_speed_str': '1.68MiB/s', '_eta_str': '5s', 'status': 'downloading'})

    fd = FileDownloader(None, params={'noprogress': False})
    fd.report_progress({'_percent_str': u'\u221e%', '_total_bytes_str': '2.43MiB', '_speed_str': '1.68MiB/s', '_eta_str': '5s', 'status': 'downloading'})


# Generated at 2022-06-12 16:28:02.649602
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name("foo") == "foo.part"
    assert fd.temp_name("foo.part") == "foo.part"
    assert fd.temp_name("/path/to/foo") == "/path/to/foo.part"
    assert fd.temp_name("/path/to/foo.part") == "/path/to/foo.part"
    assert fd.temp_name("/path/to/foo.mp4") == "/path/to/foo.mp4.part"
    assert fd.temp_name("/path/to/foo.bar.mp4") == "/path/to/foo.bar.mp4.part"

# Generated at 2022-06-12 16:28:03.792216
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    #TODO: implement
    pass

# Generated at 2022-06-12 16:28:15.705700
# Unit test for method best_block_size of class FileDownloader

# Generated at 2022-06-12 16:28:32.569677
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    assert hasattr(FileDownloader(), "download")
    assert callable(getattr(FileDownloader(), "download"))

# Generated at 2022-06-12 16:28:42.371967
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class fake_FileDownloader(FileDownloader):
        def __init__(self, params=None):
            self.maxDiff = None
            if params is None:
                params = {
                    'noprogress': False,
                    'format': 'test',
                }
            self.params = params
        def to_screen(self, *args, **kargs):
            pass
        def to_console_title(self, *args, **kargs):
            pass
        def format_seconds(self, t):
            return str(t)
        def format_eta(self, t):
            return 'ETA ' + self.format_seconds(t)
        def format_percent(self, t):
            return str(t)
        def format_speed(self, t):
            return str(t)

# Generated at 2022-06-12 16:28:55.069904
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    if sys.version_info < (3,):
        raise unittest.SkipTest('Test does not work under Python 2')

    # Create a temporary folder for testing
    temp_dir_path = get_temp_dir(prefix='youtube-dl-test_')

    # Create an info_dict for testing

# Generated at 2022-06-12 16:29:04.154904
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Expected output from each test
    test_expect = {
        'test_1': 'test_1.part',
        'test_2.part': 'test_2.part',
        'test_3': 'test_3'
    }

    # Test case source
    test_case = ['test_1', 'test_2.part', 'test_3']

    # For each test case
    for x in test_case:
        fd = FileDownloader(FileDownloaderParams({'nopart': False}))
        assert fd.undo_temp_name(x) == test_expect[x]



# Generated at 2022-06-12 16:29:17.346036
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    import unittest

    class TempFileDownloader(FileDownloader):
        counter = 0

        def real_download(self, filename, info_dict):
            self.counter += 1
            return self.counter

    class Test(unittest.TestCase):
        def setUp(self):
            self.ydl = TempFileDownloader()

        def test_best_block_size(self):
            self.assertEqual(self.ydl.best_block_size(0, 0), 1)
            self.assertEqual(self.ydl.best_block_size(0, 1), 1)
            self.assertEqual(self.ydl.best_block_size(0, 2), 2)
            self.assertEqual(self.ydl.best_block_size(0, 3), 4)

# Generated at 2022-06-12 16:29:29.003781
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    d = FileDownloader({'ratelimit':None, 'retries':None})
    assert d.best_block_size(0.0, 0) == 1
    assert d.best_block_size(0.0, 1) == 1
    assert d.best_block_size(0.0, 2) == 2
    assert d.best_block_size(0.0, 3) == 4 # 2**2

    assert d.best_block_size(0.0, 8*1024*1024) == 4*1024*1024 # 2**22
    assert d.best_block_size(0.0, 8*1024*1024+1) == 4*1024*1024 # 2**22

    assert d.best_block_size(0.0, 10*1024*1024) == 8*1024*1024 # 2**23

# Generated at 2022-06-12 16:29:41.285334
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    def test_with_timezone(time_str, expected, tz_delta):
        expected_timestamp = time.time() - 86400 + expected
        fd = FileDownloader({})
        fd.add_progress_hook(lambda s: None)
        filename = '%s.file' % test_id
        open(filename, 'w').close()
        assert fd.try_utime(filename, time_str) == expected_timestamp
        assert os.path.getmtime(filename) == expected_timestamp
        os.unlink(filename)

    def test(time_str, expected):
        test_with_timezone(time_str, expected, -8 * 3600)  # PST
        test_with_timezone(time_str, expected, 8 * 3600)  # PST

    #

# Generated at 2022-06-12 16:29:52.778568
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MyFileDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.sleep_time = None
        def real_download(self, filename, info_dict):
            return True
        def sleep(self, seconds):
            self.sleep_time = seconds

    # Test 1: no rate limit -> no sleep
    fd = MyFileDownloader({})
    fd.slow_down(0, 0, 0)
    assert fd.sleep_time is None, 'No download -> no sleep'
    fd.slow_down(0, 10, 10240)
    assert fd.sleep_time is None, 'Unlimited rate -> no sleep'

    # Test 2: rate limit, download too fast -> sleep

# Generated at 2022-06-12 16:30:04.799903
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader('/')

# Generated at 2022-06-12 16:30:11.955290
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    _f = FileDownloader({'outtmpl': '%(id)s'}, None)

    if not os.path.exists('.temp_test'):
        os.mkdir('.temp_test')

    def _check_utime(filename, last_modified_hdr):
        # create a file
        f = io.open(
            os.path.join('.temp_test', filename), 'wb')
        f.close()

        # get this file's original time
        orig_time = os.path.getmtime(
            os.path.join('.temp_test', filename))

        # call method try_utime
        filetime = _f.try_utime(
            os.path.join('.temp_test', filename),
            last_modified_hdr)

        # check if filetime

# Generated at 2022-06-12 16:30:30.580418
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    now = time.time()
    modified_time1 = fd.try_utime('test', None)
    modified_time2 = fd.try_utime('test', timeconvert('Thu, 10 Oct 2013 13:13:13 GMT'))
    modified_time3 = fd.try_utime('test', timeconvert('Thu, 10 Oct 2013 13:13:13 EDT'))
    modified_time4 = fd.try_utime('test', now)
    assert modified_time1 is None
    assert modified_time2 == 1381422943.0
    assert modified_time3 == 1381422943.0
    assert abs(modified_time4 - now) < 0.000001



# Generated at 2022-06-12 16:30:43.531794
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    dl = FileDownloader({'noprogress': True, 'quiet': True})
    dl.to_screen = lambda msg, skip_eol=None: None
    dl.to_stderr = dl.to_screen
    dl.to_console_title = lambda msg: None

    format_percent = FileDownloader.format_percent
    format_eta = FileDownloader.format_eta
    format_speed = FileDownloader.format_speed
    format_bytes = FileDownloader.format_bytes

    ##############
    # status=error
    ##############
    dl.report_progress({'status': 'error', 'downloaded_bytes': 1000, 'total_bytes': 5000, 'speed': 100, 'eta': 1800, 'filename': 'foo.flv'})
    dl.report

# Generated at 2022-06-12 16:30:45.516048
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    slow_down(start_time, now, byte_counter)

# Generated at 2022-06-12 16:30:47.577073
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    downloader = FileDownloader(params={})
    downloader.report_file_already_downloaded("filename")

# Generated at 2022-06-12 16:30:50.988656
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    params = {}
    now = time.time()
    bytecounter = 0
    start = now
    fd = FileDownloader({'params': params})
    fd.slow_down(start, now, bytecounter)

# Generated at 2022-06-12 16:30:53.537203
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader()
    fd.report_progress({'status': 'finished'})
    #assert False # TODO: implement your test here


# Generated at 2022-06-12 16:31:03.255685
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    downloader = FileDownloader({})
    assert 'foo.bar' == downloader.undo_temp_name('foo.bar')
    assert 'foo' == downloader.undo_temp_name('foo.part')
    assert 'foo' == downloader.undo_temp_name('foo')
    assert '.bar' == downloader.undo_temp_name('.bar.part')
    assert 'foo.bar' == downloader.undo_temp_name('foo.bar.part')
    assert 'foo.bar' == downloader.undo_temp_name('foo.bar.part.part')


# Generated at 2022-06-12 16:31:15.050383
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from ydl.test.test_extractor import run_test_cases, MockYDL


# Generated at 2022-06-12 16:31:27.718658
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    class FakeYDL:
        def __init__(self, to_screen_messages):
            self.to_screen_messages = to_screen_messages

        def to_screen(self, *args, **kargs):
            self.to_screen_messages.append(args)

    for to_sreen_args in [
            [['filename1']],
            [['filename2']],
    ]:
        fd = FileDownloader(
            FakeYDL(
                to_sreen_args),
            {'continuedl': True, 'nooverwrites': False}, None)
        fd.report_file_already_downloaded('filename')


# Generated at 2022-06-12 16:31:35.562318
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import os
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'a')
    open(temp_file, 'w').close()

# Generated at 2022-06-12 16:31:58.477836
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import pytest
    import tempfile
    from utils import encodeFilename
    
    
    
    
    # Use a local database.
    databaseManager = DatabaseManager(local_database=True)
    
    # Create a temporary directory
    test_dir = tempfile.mkdtemp()
    
    # Define a configuration object
    params = {
        'cachedir': databaseManager.get_directory(),
        'format': 'best',
        'outtmpl': os.path.join(test_dir, '%(id)s'),
    }
    params = compat_kwargs(params)
    
    #
    test_video_0 = 'https://youtu.be/gvdf5n-zI14'
    
    
    
    
    
    # Test 0: We will test a single

# Generated at 2022-06-12 16:32:07.548200
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({}, {})
    retval = fd.try_utime('test', 'Sat, 11 Feb 2012 13:47:39 GMT')
    assert retval == 1329030059
    try:
        from time import timezone
        time.altzone = - timezone
        retval = fd.try_utime('test', 'Thu, 01 Jan 1970 00:00:00 GMT')
        assert retval == -time.altzone
    finally:
        if hasattr(time, 'altzone'):
            del time.altzone


# Generated at 2022-06-12 16:32:17.124850
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    if hasattr(os, 'utime'):
        assert fd.try_utime(None, None) is None
        assert fd.try_utime('abc', None) is None
        assert fd.try_utime(None, 'abc') is None
        assert fd.try_utime('abc', 'abc') is None
        assert fd.try_utime('abc', '1') == 1
        assert fd.try_utime('abc', '-1') is None
        assert fd.try_utime('abc', '@-1') is None
    else:
        assert fd.try_utime(None, None) is None
        assert fd.try_utime('abc', None) is None

# Generated at 2022-06-12 16:32:21.399538
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader()

    # I don't know how to provide a Mock object as a parameter of the function
    # real_download, so I created a temporary file
    # (inspired by https://github.com/rg3/youtube-dl/pull/17025)
    res = fd.real_download('%s' % tempfile.mkstemp()[1], {'url': 'unused'})
    assert res

# Generated at 2022-06-12 16:32:34.958257
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': '20k', 'verbose': True})
    fd.to_screen = lambda *a, **ka: None

    # First: Test with no rate limit
    fd.params['ratelimit'] = None
    time.sleep = lambda *a, **ka: None
    byte_counter = 10
    start = time.time()
    fd.slow_down(start, start + 1, byte_counter)
    assert byte_counter == 10

    # Second: Test with rate limit
    # Modify time.sleep for testing purpose
    time.sleep = lambda *a, **ka: \
        (AssertionError('time.sleep called') if a[0] == 0.5 else None)
    fd.params['ratelimit'] = '20k'
    byte_counter = 10


# Generated at 2022-06-12 16:32:44.091169
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from youtube_dl.compat import TemporaryFile
    fd = TemporaryFile(mode='w')
    fd.write('test')
    fd.close()
    filename = fd.name

# Generated at 2022-06-12 16:32:56.399635
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    video = {'id': 'test_id', 'ext': 'test_ext'}
    params = {}
    fd = FileDownloader({}, params)
    fd.params['outtmpl'] = 'file_%(id)s.%(ext)s'
    assert fd.params['outtmpl'] == 'file_%(id)s.%(ext)s'
    assert fd.temp_name(video) == 'file_test_id.test_ext.part'
    # Test already present file
    assert fd.temp_name('file_test_id.test_ext.part') == 'file_test_id.test_ext.part'
    assert fd.temp_name('file_test_id.test_ext') == 'file_test_id.test_ext'
    assert fd

# Generated at 2022-06-12 16:33:07.189093
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from tempfile import NamedTemporaryFile
    from ytdl.extractor.common import InfoExtractor
    from ytdl.extractor.youtube import YoutubeIE
    from ytdl.utils import DateRange
    if sys.version_info < (3, 3):
        raise pytest.skip('test requires python >= 3.3')

    class MockYtdl(YoutubeDL):
        def __init__(self, params):
            self._ies = [InfoExtractor(y) for y in YoutubeIE.ies]
            self._age_limit = None
            self._default_search_query = 'ytsearch'
            self._default_search_limit = 1
            super(MockYtdl, self).__init__(params)


# Generated at 2022-06-12 16:33:19.019917
# Unit test for method temp_name of class FileDownloader