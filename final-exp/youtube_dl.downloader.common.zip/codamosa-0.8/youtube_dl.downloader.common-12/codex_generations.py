

# Generated at 2022-06-12 16:23:55.389862
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Test case:
    #   temp_name(filename) if filename is absolute path
    fd = FileDownloader(None)
    assert fd.temp_name('/home/username/temp') == '/home/username/temp'
    # Test case:
    #   temp_name(filename) if filename is relative path
    assert fd.temp_name('temp') == 'temp'
    # Test case:
    #   temp_name(filename) if filename is just a file name
    assert fd.temp_name('temp.mp4') == 'temp.mp4'
    # Test case:
    #   temp_name(filename) if filename is a file name with extension
    assert fd.temp_name('temp.mp4.part') == 'temp.mp4'
    # Test case:
    #   temp_name

# Generated at 2022-06-12 16:24:07.073381
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    with no_stdout_stderr():
        from youtube_dl.downloader.http import HttpFD
        from youtube_dl.utils import DateRange
        fd1 = HttpFD(
            {'progress_hooks': []}, None, None,
            'http://www.example.com', None, None, None, None,
            {'test': 'unit', 'noprogress': False}, 'test',
            lambda: DateRange(0), lambda: DateRange(3))
        fd1.report_progress({'status': 'downloading'})
        fd1.report_progress({'status': 'finished'})


# Generated at 2022-06-12 16:24:17.254413
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    import random
    for i in range(1000):
        hours = random.randint(0, 1000000000)
        minutes = random.randint(0, 59)
        seconds = random.randint(0, 59)
        res = FileDownloader.format_seconds(3600*hours + 60*minutes + seconds)
        if i % 50 == 0:
            # Also test random floats
            seconds += random.random()
            res = FileDownloader.format_seconds(3600*hours + 60*minutes + seconds)
        if hours > 0:
            assert res.startswith('%d:' % hours)
            res = res[len('%d:' % hours):]
            assert res.count(':') == 1
        if minutes > 0:
            assert res.startswith('%02d:' % minutes)

# Generated at 2022-06-12 16:24:30.249179
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    """Unit test for method FileDownloader.report_progress."""

    # Instantiate downloader
    params = {
        'noprogress': False,
        'progress_with_newline': False,
        'simulate': True,
    }
    downloader = FileDownloader({}, params)

    # Test with a new download
    downloader.report_progress({
        'status': 'downloading',
        'eta': 2,
        'speed': 100,
        'downloaded_bytes': 0,
        'total_bytes': 100,
    })
    assert downloader._progress_status == '[download]   0% of 100 at 100 ETA 02:00'

    # Test with a download nearly complete

# Generated at 2022-06-12 16:24:34.548001
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class MockFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True
    fd = MockFileDownloader({})
    assert fd.download('test.mp4',{'some_key': 'some_value'})


# Generated at 2022-06-12 16:24:39.329951
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    r"""
    > download_video(
        url='https://www.youtube.com/watch?v=BaW_jenozKc',
        file_name='D:/video_1.flv',
        format_id='43',
    )
    """
    pass

# Function download_video

# Generated at 2022-06-12 16:24:46.658802
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class DummyFD(FileDownloader):
        def real_download(self, filename, info_dict):
            return True
    params = {'nooverwrites': True, 'continuedl': True}
    fd = DummyFD(params)
    assert fd.download('filename_not_exists', {}) == True
    assert fd.download('filename_exists', {}) == True
    params = {'nooverwrites': True, 'continuedl': False}
    fd = DummyFD(params)
    assert fd.download('filename_not_exists', {}) == True
    assert fd.download('filename_exists', {}) == True
    params = {'nooverwrites': False, 'continuedl': True}
    fd = DummyFD(params)
   

# Generated at 2022-06-12 16:24:58.564405
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    outfile = '94B9FFBF8F2C4EBA.mp4'
    fd.to_screen = lambda *args, **kargs: None
    test_cases = [
        ('Fri, 14 Jun 2013 14:39:57 GMT', 1371267898),
        ('Sun, 14 Jul 2013 14:39:57 GMT', 1373777898),
        ('Sun, 14 Jul 2013 19:39:57 GMT', 1373777898),
    ]
    for timestr, expected in test_cases:
        fd.try_utime(outfile, timestr)
        assert os.stat(outfile).st_mtime == expected



# Generated at 2022-06-12 16:25:04.082145
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    for data in [
        (10, 20, 30, 100 / 20),
        (10, 20, 0, 0),
        (10, 0, 30, 30 / 0.001),  # One millisecond
        (10, 20, 30, 100 / 20),
    ]:
        assert (FileDownloader.calc_speed(*data[0:3]) - data[3]) < 0.00001, (
            'Invalid value returned by calc_speed: %f != %f'
            % (FileDownloader.calc_speed(*data[0:3]), data[3]))



# Generated at 2022-06-12 16:25:05.632414
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name("a.part") == 'a'
    assert FileDownloader.undo_temp_name("a") == 'a'



# Generated at 2022-06-12 16:25:22.090044
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({}, 'youtube-dl')
    assert fd.undo_temp_name('a') == 'a'
    assert fd.undo_temp_name('a.part') == 'a'
    assert fd.undo_temp_name('a.part.b.part') == 'a.part.b'
    assert fd.undo_temp_name('a.part.b') == 'a.part.b'


# Generated at 2022-06-12 16:25:30.260229
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import os
    import sys
    import shutil
    import tempfile
    import re
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.FileDownloader import FileDownloader
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import encodeFilename
    from ytdl.compat import (
        _encodeFilename,
        text_type,
    )
    from ytdl.postprocessor import (
        FFmpegMetadataPP,
    )

    class MockYDL(YoutubeDL):
        def __init__(self, params):
            super(MockYDL, self).__init__(params)
            self.downloaded_info_dicts = []
            self.pp_expected_outputs = []
            self.pp_outputs = []

       

# Generated at 2022-06-12 16:25:38.427928
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(None, {})

    # case 1: speed < rate_limit (slow down)
    assert fd.calc_speed(0, 1, 50) < 1000

    # case 2: speed > rate_limit (do not slow down)
    assert fd.calc_speed(0, 1, 1200) > 1000

    # case 3: speed = rate_limit (do not slow down)
    assert fd.calc_speed(0, 1, 1000) == 1000

# Generated at 2022-06-12 16:25:46.694136
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    assert FileDownloader.format_speed(None) == '%10s' % ('Unknown speed')
    assert FileDownloader.format_speed(0) == '%10s' % ('%s/s' % format_bytes(0))
    assert FileDownloader.format_speed(10240) == '%10s' % ('%s/s' % format_bytes(10240))
    assert FileDownloader.format_speed(10240*1024) == '%10s' % ('%s/s' % format_bytes(10240*1024))

# Generated at 2022-06-12 16:25:55.251499
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(0, 0) == max(0 / 2.0, 1.0)
    assert FileDownloader.best_block_size(0.001, 0) == max(0 / 2.0, 1.0)
    assert FileDownloader.best_block_size(0, 1024) == max(1024 / 2.0, 1.0)
    assert FileDownloader.best_block_size(0.001, 1024) == max(1024 / 2.0, 1.0)
    assert FileDownloader.best_block_size(2, 1024) == max(1024 * 2.0, 1.0)
    assert FileDownloader.best_block_size(2, 1024) == min(max(1024 * 2.0, 1.0), 4194304)
    assert FileDownloader.best_block

# Generated at 2022-06-12 16:25:59.401917
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(None)
    fd.to_screen = lambda x : x
    ret = fd.report_file_already_downloaded('test')
    assert ret == None
    assert fd.format_filename('test') == 'test'

# Generated at 2022-06-12 16:26:11.945304
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    downloader = FileDownloader(None, False, params=None)
    start_time = time.time()
    byte_counter = 0
    byte_counter = downloader.slow_down(start_time, None, byte_counter)
    assert byte_counter == 0
    # time is negative
    byte_counter = downloader.slow_down(start_time + 5, None, byte_counter)
    assert byte_counter == 0
    # byte_counter is 0
    byte_counter = downloader.slow_down(start_time, start_time + 15, byte_counter)
    assert byte_counter == 0
    # slow down
    byte_counter = downloader.slow_down(start_time, start_time + 5, 2000)
    assert byte_counter == 0
    # no slow down
    byte_counter

# Generated at 2022-06-12 16:26:19.010601
# Unit test for method format_seconds of class FileDownloader
def test_FileDownloader_format_seconds():
    assert FileDownloader.format_seconds(0) == '0:00'
    assert FileDownloader.format_seconds(1) == '0:01'
    assert FileDownloader.format_seconds(12) == '0:12'
    assert FileDownloader.format_seconds(60) == '1:00'
    assert FileDownloader.format_seconds(70) == '1:10'
    assert FileDownloader.format_seconds(3600) == '1:00:00'
    assert FileDownloader.format_seconds(3622) == '1:00:22'



# Generated at 2022-06-12 16:26:25.317233
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    print('Testing format_retries')
    t = FileDownloader(params=None, downloader=None, progress_hooks=None)
    mp3 = t.format_retries(float('inf'))
    assert (mp3 == 'inf')
    mp4 = t.format_retries(10)
    assert (mp4 == '10')



# Generated at 2022-06-12 16:26:37.944409
# Unit test for method format_speed of class FileDownloader
def test_FileDownloader_format_speed():
    # Check corner cases
    assert(FileDownloader.format_speed(None) == '%10s' % '---b/s')
    
    # Check all possible scales (24 of them)
    scales = list(map(lambda x: x + 1, range(24))) # list from 1 to 24
    scale_max_values = [0] + list(map(lambda x: 128 ** x, scales))
    scale_max_values.insert(0, 0) # scale_max_values now contains lists [0, 0], [1, 128], [9, 274877906944] ... [24, ...]
    for i in range(1, len(scale_max_values)):
        scale = scales[i - 1]
        scale_max = scale_max_values[i]
        speed_str = FileDownloader.format_

# Generated at 2022-06-12 16:27:00.466476
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    downloader = FileDownloader()
    start_time = time.time()

    # Test with invalid KBps
    downloader.slow_down(start_time, time.time(), 10, 0)
    assert (time.time() == start_time)

    # Test with invalid KBps
    downloader.slow_down(start_time, time.time(), 10, -1)
    assert (time.time() == start_time)

    # Test with valid KBps but no sleep required
    downloader.slow_down(start_time, time.time(), 10, 100)
    assert (time.time() == start_time)

    # After this function call, the time should be greater than start time
    downloader.slow_down(start_time, time.time(), 10, 1)
    assert (time.time() > start_time)

# Generated at 2022-06-12 16:27:09.133720
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    d = FileDownloader(None, {'retries': 5, 'max_retries': 5})
    assert d.format_retries(float('inf')) == 'inf'
    assert d.format_retries(5) == '5'
    t = d.format_retries(4)
    assert t == '4'
    d.report_retry(None, 0, -1)
    assert d.format_retries(5) == '5' # (retries should not have been decremented)
    d.report_retry(Exception(), 0, 4)
    assert d.format_retries(4) == t # (retries should not have been decremented)
    d.report_retry(Exception('a'), 0, 3)
    assert d.format_retries(3) != t # (retries should

# Generated at 2022-06-12 16:27:16.777853
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('1M') == 1048576
    assert FileDownloader.parse_bytes('2K') == 2048
    assert FileDownloader.parse_bytes('3') == 3
    assert FileDownloader.parse_bytes('5b') == 5
    assert FileDownloader.parse_bytes('-1') is None

# Generated at 2022-06-12 16:27:25.949037
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    #Two tests cases
    # First: it is not a stream, regular file
    # Second: it is a stream, regular file
    filename = 'video.mp4'

# Generated at 2022-06-12 16:27:37.721546
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL

    downloader = FileDownloader(YoutubeDL(), {'noprogress': False, 'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'}, {})


# Generated at 2022-06-12 16:27:49.413517
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    from YoutubeDL import FileDownloader
    fd = FileDownloader({})
    assert fd.format_retries(float('inf')) == 'inf'
    assert fd.format_retries(float('nan')) == 'unknown'
    assert fd.format_retries(0) == '0'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(1.1) == '1.1'
    assert fd.format_retries(1.5) == '1.5'
    assert fd.format_retries(1.6) == '1.6'
    assert fd.format_retries(1.9) == '1.9'

# Generated at 2022-06-12 16:27:58.059892
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(params={})
    for dl, limit, expected in [
            (10, 10, None),
            (11, 10, 1),
            (9, 10, None),
            (20, 10, 10),
    ]:
        start_time = time.time()

        fd.slow_down(
            start_time, start_time + 0.1, int(dl * 1024 * 1024 / 8))
        rate = None if expected is None else (limit * 1024 * 1024 / 8)
        assert fd.calc_speed(start_time, time.time(), dl * 1024 * 1024) == rate

    # Test rate limit with resume
    fd.slow_down(
        start_time, start_time + 0.1, int(11 * 1024 * 1024 / 8))

# Generated at 2022-06-12 16:28:08.999155
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # test if this does not crash

    fd = FileDownloader({})
    fd.slow_down(10, 20, 100)

    # test against rate limits

    fd = FileDownloader({'ratelimit': 10})
    fd.slow_down(10, 20, 100)  # ok, speed: 10
    fd.slow_down(10, 20, 90)   # ok, speed: 9

    fd = FileDownloader({'ratelimit': 10})
    fd.slow_down(10, 20, 101)  # too high, sleep 1 s
    fd.slow_down(10, 30, 101)  # too high, sleep (10 - 20 / 101) s


# Generated at 2022-06-12 16:28:18.600876
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from .YoutubeDL import YoutubeDL
    from .utils import FakeYDL

    def test_func(filename):
        ydl = FakeYDL()
        fd = FileDownloader(ydl, {})
        fd.report_file_already_downloaded(filename)

    # test with file name only
    test_func('./foo/bar.mp4')

    # test with more details about the file name
    fp = './foo/bar.mp4'
    fm = 'mp4'
    fd = 'video file'

    test_func('[%s]%s' % (fm, fp))
    test_func('[%s]%s' % (fm, fd))
    test_func('[%s]%s[%s]' % (fm, fp, fd))

# Generated at 2022-06-12 16:28:31.893002
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class FakeInfoDict(object):
        pass
    class FakeYtdl(object):
        def to_screen(self, msg):
            print (msg)
        def to_console_title(self, msg):
            print (msg)
        def trouble(self, msg):
            print (msg)
        def report_warning(self, msg):
            print (msg)
        def report_error(self, msg):
            print (msg)

    ydl = FakeYtdl()
    fd = FileDownloader(ydl, {}, {})

    filename = 'test_filename'
    info_dict = FakeInfoDict()
    info_dict.exists = False
    assert fd.download(filename, info_dict) is None

    info_dict.exists = True

# Generated at 2022-06-12 16:29:01.781814
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    fd = FileDownloader({})
    old_name = "test.txt"
    new_name = "new.txt"

    open(old_name, 'a').close()
    open(new_name, 'a').close()

    fd.try_rename(old_name, new_name)
    fd.try_rename(old_name, None)
    fd.try_rename(None, None)
    # assume we can not rename a file to itself if we try
    fd.try_rename(old_name, old_name)
    fd.try_rename(new_name, old_name)

    fd.try_rename(new_name, "doesnt_exist")
    fd.try_rename(old_name, "doesnt_exist")
    


# Generated at 2022-06-12 16:29:06.286576
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    class FakeFD:
        def __init__(self, params):
            self.params = params
            self._progress_hooks = []

    fd = FakeFD({})
    assert fd.calc_speed(0, 10, 0) == None
    assert fd.calc_speed(0, 20, 1000) == 50.0



# Generated at 2022-06-12 16:29:18.804224
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    d = FileDownloader(None)
    assert d.try_utime("foo", None) is None
    assert d.try_utime("foo", "") is None

    d.try_utime("foo", "10:01:01")
    assert d.try_utime("foo", "10:01:01") == 3600 + 60 + 1
    # d.to_screen("%s" % timeconvert("10:01:01"))

    # only last two digits for year is needed
    assert d.try_utime("foo", "10:01:01 2001") == 1009860261
    assert d.try_utime("foo", "10:01:01 21") == 1009860261
    # d.to_screen("%s" % timeconvert("10:01:01 2001"))
    # d.to

# Generated at 2022-06-12 16:29:25.281761
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    filedownloader = FileDownloader(None, None)

    # Test with normal filename
    assert filedownloader.report_file_already_downloaded('test_file.txt') == None

    # Test with filename containing non-ascii characters
    assert filedownloader.report_file_already_downloaded('test_file_åÅäÄöÖ.txt') == None


# Generated at 2022-06-12 16:29:34.065234
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    data = [
        # [input, expected result]
        ['foo.1', 'foo.1.part'],
        ['foo.bar', 'foo.bar.part'],
        ['f00.7z', 'f00.7z.part'],
        ['f.1', 'f.1.part']
    ]

    fd = FileDownloader({})
    for d in data:
        assert fd.temp_name(d[0]) == d[1]

# Generated at 2022-06-12 16:29:44.338073
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # Create a dummy downloader
    ydl = YoutubeDL()
    ydl.params['sleep_interval'] = 0
    down = FileDownloader(ydl)

    try:
        os.remove('test_utime1')
    except OSError:
        pass
    except IOError:
        pass
    f = open('test_utime1', 'wb')
    f.write(b'hi')
    f.close()
    mod_time = os.path.getmtime('test_utime1')

    # First test: no utime
    down.try_utime('test_utime1', None)
    assert os.path.getmtime('test_utime1') == mod_time

    # Second test: we have a utime
    time.sleep(0.1)  # Otherwise the

# Generated at 2022-06-12 16:29:57.047802
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def debug_hook(status):
        print(repr(status))
        pass
    
    def download_hook(status):
        print(repr(status))
        pass
    
    ydl = FileDownloader()
    ydl.add_progress_hook(debug_hook)
    ydl.add_progress_hook(download_hook)
    ydl.download(
            dummy_filename,
            {
                'status': 'downloading',
                'eta': 103,
                'speed': 1878,
                'elapsed': 30,
                'downloaded_bytes': 28683471
            })
    ydl.download(
            dummy_filename,
            {
                'status': 'finished',
                'total_bytes': 28683471,
            })

# Generated at 2022-06-12 16:30:08.118475
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from .YoutubeDL import YoutubeDL
    from io import BytesIO

    from .utils import xpath_with_ns

    ydl = YoutubeDL({
        'ratelimit': 1,
        'writethumbnail': True,
    })

    fd = FileDownloader(ydl, {
        'usenetrc': False,
        'username': 'un',
        'password': 'pwd',
    })

    def test_hook(d):
        assert d['status'] == 'finished'
        assert d['filename'] == '1.jpg'
        assert 'elapsed' in d
        assert 'speed' in d
        assert '_total_bytes_str' in d
        assert d['_total_bytes_str'] == '1.00KiB'

    fd.add_progress_hook(test_hook)

# Generated at 2022-06-12 16:30:20.320349
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    import pytest
    fd = FileDownloader(pytest.tests.YDL(), {})

    # Test different types of filename
    fd.report_file_already_downloaded('a')
    fd.report_file_already_downloaded('abc')
    fd.report_file_already_downloaded('abcdef')
    fd.report_file_already_downloaded('abcdefgh')
    fd.report_file_already_downloaded('abcdefghi')
    fd.report_file_already_downloaded('abcdefghij')

    # Test unicode filename
    fd.report_file_already_downloaded('绝')
    fd.report_file_already_downloaded('绝句')
    fd.report_file_al

# Generated at 2022-06-12 16:30:28.267046
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import convivial_downloader
    convivial_downloader.use_adaptive_sleep = False

    # Create a FileDownloader object and set its params, so that
    # params['simulate'] == True
    fd = convivial_downloader.FileDownloader({
        'simulate': True
    })

    # To test if the sleep_time is calculated correctly, we use a mocked version
    # of time.time()
    class MockTime(object):
        def __init__(self, start_time=0):
            self._time = start_time

        def sleep(self, sleep_time):
            self._time += sleep_time

        def time(self):
            return self._time

    # Assert a speed of 5B/s has the correct sleep time (1sec)

# Generated at 2022-06-12 16:30:49.635037
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # TODO: implement
    pass


# Generated at 2022-06-12 16:30:57.493532
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test with 0 bytes downloaded
    fd = FileDownloader({'ratelimit': '100k'})
    start = time.time()
    fd.slow_down(start, start, 0)
    assert (start == time.time())
    # Test with low download speed
    fd = FileDownloader({'ratelimit': '100k'})
    start = time.time()
    fd.slow_down(start, start + 1, 1)
    assert (start == time.time())
    # Test with high download speed
    fd = FileDownloader({'ratelimit': '100k'})
    start = time.time()
    fd.slow_down(start, start + 1, 1000)
    assert (start + 1 == time.time())

# Test for method calc_eta of class FileDownloader

# Generated at 2022-06-12 16:31:09.329622
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from tempfile import mkstemp
    from shutil import move
    from os import access, R_OK, W_OK, remove
    from os.path import join, isfile, isdir
    from time import sleep
    from datetime import datetime, timedelta
    from locale import getdefaultlocale
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import parse_qs
    from threading import Thread
    from http.client import HTTPConnection
    from sys import version_info
    if version_info < (3, 4, 3):
        # Python 3 >= 3.4.3 handles empty header values, 3.6 and 3.7 support
        # the new type of header values
        return
    if version_info >= (3, 6):
        from http.cookies import SimpleCookie

# Generated at 2022-06-12 16:31:21.238561
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    tn = FileDownloader().temp_name

# Generated at 2022-06-12 16:31:31.196832
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    # Test for checkError() method
    def report_error(self, *args, **kargs):
        pass
    FileDownloader.report_error = report_error

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    f = FileDownloader(
        params={'format': 'best'},
        ydl=lambda *args, **kargs: None)
    f.add_info_extractor(YoutubeIE())
    f.add_progress_hook(lambda d: None)

    try:
        f.download(url)
    except:
        pass
    else:
        assert False, 'Expected error not raised'

# Generated at 2022-06-12 16:31:43.658833
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader(None, None)
    assert fd.best_block_size(1.0, 1) == 4194304
    assert fd.best_block_size(0.5, 0) == 1
    assert fd.best_block_size(0.5, 512) == 1024
    assert fd.best_block_size(0.5, 1024) == 2048
    assert fd.best_block_size(10.0, 50) == 1
    assert fd.best_block_size(10.0, 512) == 1
    assert fd.best_block_size(10.0, 1024) == 1
    assert fd.best_block_size(10.0, 4096) == 1
    assert fd.best_block_size(10.0, 4194304) == 1



# Generated at 2022-06-12 16:31:47.879461
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time

    # This is done deliberately

    class Downloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            self._sleep_time = 0.0
            FileDownloader.__init__(self, *args, **kwargs)

        # Redefine sleep() to store the time we would have slept in the
        # object
        def sleep(self, time):
            self._sleep_time = time

    params = {
        'ratelimit': None,
        'noprogress': True,
        'retries': 0,
        'verbose': False,
    }

    # The following tests are run with the following configurations:
    # - No ratelimit
    # - The ratelimit is double the download speed
    # - The ratelimit is half the download speed

    # The tests assert that

# Generated at 2022-06-12 16:31:57.560585
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    import unittest

    import random

    def _test_FileDownloader_best_block_size_do(self, start, now, bytes, exp_result):
        self.assertEqual(
            FileDownloader.best_block_size(start, now, bytes),
            exp_result)

    class TestFileDownloader(unittest.TestCase):
        def test_best_block_size(self):
            for i in range(100):
                start = random.random()
                now = random.random()
                bytes = random.randint(1, 1000000000)
                _test_FileDownloader_best_block_size_do(self, start, now, bytes, FileDownloader.best_block_size(start, now, bytes))

    unittest.main()


# Generated at 2022-06-12 16:32:09.794807
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    """$ python -m tests.test_FileDownloader test_FileDownloader_temp_name"""
    fd = FileDownloader(params={})
    fd.to_screen = lambda *args, **kargs: sys.stderr.write(str(args) + '\n')
    filename = 'foobar'
    # Test a simple filename
    assert fd.temp_name(filename) == 'foobar.part'
    # Test a filename with a path
    filename = 'bar/foobar'
    assert fd.temp_name(filename) == 'bar/foobar.part'
    # Test a filename with a path and some parameters
    filename = 'bar/foobar.baz?a=1&b=2'

# Generated at 2022-06-12 16:32:13.036532
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    assert '1' == FileDownloader.format_retries(1)
    assert 'inf' == FileDownloader.format_retries(float('inf'))
    assert '1.00000001' == FileDownloader.format_retries(1.000000000000001)



# Generated at 2022-06-12 16:32:50.963213
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-12 16:33:03.890029
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    downloader = FileDownloader({})
    assert downloader.format_seconds(1) == '0:01'
    assert downloader.format_seconds(10) == '0:10'
    assert downloader.format_seconds(60 * 60 * 4 + 60 * 5 + 6) == '4:05:06'
    assert downloader.format_percent(1.2) == '122%'
    assert downloader.format_percent(1.23) == '123%'
    assert downloader.format_percent(1.235) == '123%'
    assert downloader.format_percent(1.0) == '100%'
    assert downloader.format_percent(0.0) == '0%'
    assert downloader.format_percent(0.1234) == '12%'

    assert downloader.format_eta

# Generated at 2022-06-12 16:33:16.325910
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    fd = FileDownloader({})
    assert fd.download('test', {}) == False

test_FileDownloader_download()

# No unit tests for method report_progress since it doesn't contain any
# non-trivial logic.
# No unit tests for method report_destination since it doesn't contain any
# non-trivial logic.
# No unit tests for method report_resuming_byte since it doesn't contain any
# non-trivial logic.
# No unit tests for method report_retry since it doesn't contain any
# non-trivial logic.
# No unit tests for method report_file_already_downloaded since it doesn't contain any
# non-trivial logic.
# No unit tests for method report_unable_to_resume since it doesn't contain any
# non-trivial