

# Generated at 2022-06-12 16:24:18.065783
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    exe = os.path.basename(sys.executable)
    def assert_utime(filename, last_modified_hdr, filetime, max_diff=60):
        fd = FileDownloader(YoutubeDL())
        now = time.time()
        assert fd.try_utime(filename, last_modified_hdr) == filetime
        f_time = os.path.getmtime(filename)
        assert (now - f_time) < max_diff
        assert abs(f_time - filetime) < max_diff

    # Unix

# Generated at 2022-06-12 16:24:31.313017
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import sys
    import collections
    import io

    def _get_report_progress_output(fobj, *args, **kwargs):
        """Capture the output of FileDownloader.report_progress
        and return the captured output"""

        if isinstance(fobj, io.IOBase) and fobj.isatty():
            return None

        buffer = collections.defaultdict(list)

        def _save(x):
            buffer[x].append(None)

        def _write(text):
            buffer[text].append(None)

        original = {
            'save_ensure_newline': FileDownloader.save_ensure_newline,
            'write': FileDownloader.write,
        }


# Generated at 2022-06-12 16:24:41.843723
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def _test(status, total_bytes, downloaded_bytes, elapsed, expected_output):
        fd = FileDownloader({})
        fd.report_progress({
            'status': status,
            'total_bytes': total_bytes,
            'downloaded_bytes': downloaded_bytes,
            'elapsed': elapsed,
        })
        out, err = capsys.readouterr()
        assert out == expected_output

    # Test with no progress
    _test(
        status='downloading', total_bytes=None, downloaded_bytes=None,
        elapsed=None,
        expected_output='[download]   0.0% of Unknown size at Unknown speed ETA Unknown ETA'
    )

    # Test with no progress but total bytes known

# Generated at 2022-06-12 16:24:54.755250
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def test_slow_down(params, expected_sleep_time, expected_speed=None):
        fd = FileDownloader(params, {})
        start_time = 0
        byte_counter = 0
        now = 0
        while byte_counter < 10000000:
            if byte_counter > 0:
                now += 1
                byte_counter += 1000
            fd.slow_down(start_time, now, byte_counter)
        sleep_time = (now - 1) - start_time
        assert sleep_time == expected_sleep_time, sleep_time
        if expected_speed is not None:
            speed = float(byte_counter) / (now - 1)
            assert speed == expected_speed, speed
    for ratelimit in [None, 0, 1, 1000000]:
        params = {'ratelimit': ratelimit}

# Generated at 2022-06-12 16:24:58.734890
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    downloader = FileDownloader()
    filename = 'a'*4
    downloader.report_file_already_downloaded(filename)
    assert(True)


# Generated at 2022-06-12 16:25:03.677390
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockFD:
        def __init__(self):
            self.params = {
                'ratelimit': 100,
            }
    fd = MockFD()
    fd.slow_down(0, time.time(), 200)
    time.sleep(0.2)


# Generated at 2022-06-12 16:25:11.123431
# Unit test for method try_utime of class FileDownloader

# Generated at 2022-06-12 16:25:20.804922
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    # Test normal filename
    fd = FileDownloader({})
    assert fd.undo_temp_name('/TEMP/FILENAME') == '/TEMP/FILENAME'
    assert fd.undo_temp_name('/TEMP/FILENAME.part') == '/TEMP/FILENAME'

    # Test with Unicode file name
    fd = FileDownloader({})
    assert fd.undo_temp_name(u'/TEMP/FILENAME') == u'/TEMP/FILENAME'
    assert fd.undo_temp_name(u'/TEMP/FILENAME.part') == u'/TEMP/FILENAME'


# Generated at 2022-06-12 16:25:27.150796
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader()
    fd.params = {'ratelimit': 500}

    # We have to force time.time to return a value of 1.0 and then
    # increment it manually.
    def ttime():
        ttime.val += 1
        return ttime.val
    ttime.val = 1.0
    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(time, 'time', ttime)

    # Test with "downloaded_bytes" much greater than "ratelimit"
    # which should trigger the sleep.
    fd.slow_down(ttime.val, ttime.val, 50 * 1024)
    assert ttime.val == 1.0 + 1.0  # No sleep

    fd.slow_down(ttime.val, ttime.val, 512 * 1024)

# Generated at 2022-06-12 16:25:35.743048
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert(FileDownloader.undo_temp_name("part") == "part")
    assert(FileDownloader.undo_temp_name("part.part") == "part")
    assert(FileDownloader.undo_temp_name("part.part.part") == "part.part.part")
    assert(FileDownloader.undo_temp_name("test") == "test")
    assert(FileDownloader.undo_temp_name("test.part") == "test")
    assert(FileDownloader.undo_temp_name("test.part.part") == "test.part")

test_FileDownloader_undo_temp_name()

# Generated at 2022-06-12 16:25:48.447499
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    u"""This method is used as a unit test for method download of class FileDownloader."""

    p = lambda *args : None
    hook_progress_obj = lambda status : p(status)
    def hook_progress(status):
        hook_progress_obj(status)

    downloader = FileDownloader()
    downloader.add_progress_hook(hook_progress)

# Generated at 2022-06-12 16:25:56.160668
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(ydl=YoutubeDL(params=None))
    fd.report_progress({
        'downloaded_bytes': 0,
        'total_bytes': 1000,
        'speed': 2.5
    })
    assert u'Unknown ETA' in fd._report_progress_prev_line_length
    fd.report_progress({
        'downloaded_bytes': 0,
        'total_bytes': 1000,
        'speed': 2.5,
        'eta': 1245
    })
    assert u'Unknown ETA' not in fd._report_progress_prev_line_length

# Generated at 2022-06-12 16:25:59.929717
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():

    # Test simple download
    assert FileDownloader({}).download('test_FileDownloader_download_', {'id': 'test_id'}) == True


if __name__ == "__main__":
    test_FileDownloader_download()

# Generated at 2022-06-12 16:26:12.417934
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    from .compat import parse_qs
    from .update import YoutubeDLHandler
    from .YoutubeDL import YoutubeDL
    try:
        compat_urllib_request.install_opener(YoutubeDLHandler(YoutubeDL()))
    except TypeError:
        compat_urllib_request.install_opener(YoutubeDLHandler())
    # FIXME: the following test is not reliable
    ## assert(FileDownloader.parse_bytes('5.9 K') == 5900)
    assert FileDownloader.parse_bytes(b'5.9K') == 5900
    assert FileDownloader.parse_bytes(b'5.9kB') == 5900
    assert FileDownloader.parse_bytes(b'5.9 KB') == 5900

# Generated at 2022-06-12 16:26:20.580109
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import cStringIO
    downloader = FileDownloader({})
    buf = cStringIO.StringIO()
    downloader.to_stderr = lambda s: buf.write(s + '\n')
    downloader.slow_down(100, 110, 1000)
    assert 'Slow down' in buf.getvalue()
    # Too small dif
    buf.truncate(0)
    downloader.slow_down(100, 105, 1000)
    assert 'Too small dif' in buf.getvalue()
    # Too small rate
    buf.truncate(0)
    downloader.slow_down(100, 110, 0)
    assert 'Too small rate' in buf.getvalue()
    # Just right
    buf.truncate(0)

# Generated at 2022-06-12 16:26:24.054054
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    downloader = FileDownloader()
    filename = 'test.txt'
    downloader.report_file_already_downloaded(filename)


# Generated at 2022-06-12 16:26:26.052193
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    # TODO: implement unit test
    assert True


# Generated at 2022-06-12 16:26:34.617610
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader(params=None,ydl=None,progress_hooks=None)
    fn = "abc.txt"
    fd.report_file_already_downloaded(fn)

    #fn = "\u5f20\u6d77"
    #UnicodeEncodeError: 'ascii' codec can't encode characters in position 0-1: ordinal not in range(128)

    fn = "测试.txt"
    fd.report_file_already_downloaded(fn)


# Generated at 2022-06-12 16:26:35.350116
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    pass

# Generated at 2022-06-12 16:26:41.286556
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeYDL:
        def __init__(self):
            self.to_screen_calls = []
            self.to_console_title_calls = []
            self.params = {'noprogress': False}
        def to_screen(self, s, skip_eol=False):
            self.to_screen_calls.append((s, skip_eol))
        def to_console_title(self, s):
            self.to_console_title_calls.append(s)

    ydl = FakeYDL()
    fd = FileDownloader(ydl, {})

    s = {'status': 'unknown'}
    fd.report_progress(s)
    assertEqual(ydl.to_screen_calls, [])


# Generated at 2022-06-12 16:27:00.576682
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFD(FileDownloader):
        def to_screen(self, message, skip_eol=False):
            self.ts_messages.append(message)
            self.ts_skip_eol.append(skip_eol)

        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.ts_messages = []
            self.ts_skip_eol = []


# Generated at 2022-06-12 16:27:09.193074
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    assert FileDownloader.best_block_size(0.0, 0.0) == 1
    assert FileDownloader.best_block_size(1.0, 1024.0) == 1024
    assert FileDownloader.best_block_size(1.0, 1023.0) == 1023
    assert FileDownloader.best_block_size(1.0, 512.0) == 512
    assert FileDownloader.best_block_size(1.0, 511.0) == 511
    assert FileDownloader.best_block_size(1.0, 1.0) == 1
    assert FileDownloader.best_block_size(1.0, 0.1) == 1
    assert FileDownloader.best_block_size(0.0, 0.1) == 1
    assert FileDownloader.best_block_size

# Generated at 2022-06-12 16:27:22.534198
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class FakeTime:
        def __init__(self, now):
            self._now = now
        def time(self):
            return self._now
    fake_time = FakeTime(0)
    fd = FileDownloader(params={}, ydl=object(), timefunc=fake_time.time)
    assert fd.calc_speed(0, 1, 2) == 2e9
    fd.slow_down(0, 1, 2)
    fake_time._now = 0.5
    fd.slow_down(0, 1, 2)
    fake_time._now = 1.5
    fd.slow_down(0, 2, 2)
    fd.slow_down(0, 2, 4)
    fake_time._now = 2.5

# Generated at 2022-06-12 16:27:27.758170
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    downloader = FileDownloader({})
    elap = 4.1
    size = 42000000
    expect = int(size / 8)
    actual = downloader.best_block_size(elap, size)
    print('elap', elap)
    print('size', size)
    print('expect', expect)
    print('actual', actual)

test_FileDownloader_best_block_size()

# Generated at 2022-06-12 16:27:38.472378
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    downloader = FileDownloader(None, None, None)
    assert downloader.report_file_already_downloaded('test') is None

# from .jsinterp import JSInterpreter
# from .fragment import FragmentFD
# from .utils import (
#     format_bytes,
#     check_executable,
#     prepend_extension,
#     prepend_extension,
#     decode_compat_str,
#     encode_compat_str,
#     compat_str,
#     encodeFilename,
#     shell_quote,
#     timeconvert,
#     get_cachedir,
# )

NO_DEFAULT = object()



# Generated at 2022-06-12 16:27:44.480859
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    x = FileDownloader(params={})
    assert x.calc_eta(0, 0, 0) is None
    assert x.calc_eta(0, 0, 123) is None
    assert x.calc_eta(10, 20, 0) is None
    assert x.calc_eta(10, 20, 123) == 6.0


# Generated at 2022-06-12 16:27:51.975432
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = FileDownloader(None, None)
    file_size = 10341920
    # Set the status
    status = {
        'status': 'downloading',
        'eta': 900,
        'filename': 'video.mp4',
        'speed': 325.15,
        'elapsed': 17,
        'total_bytes': file_size,
        'downloaded_bytes': 179864,
        'total_bytes_estimate': file_size
    }
    # Call report_progress method
    ydl.report_progress(status)



# Generated at 2022-06-12 16:28:02.198390
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader(YTDLDummyYDL(), {})
    # No sleep for speed == rate_limit
    fd.slow_down(0, 0, 10, 10.0)
    # Sleep for 10s for speed > 2 * rate_limit
    fd.slow_down(0, 0, 10, 2.0)
    # Sleep for 5s for speed = 0.5 * rate_limit
    fd.slow_down(0, 0, 10, -0.5)
    # No sleep if elapsed time is 0
    fd.slow_down(0, 0, 0, -1.0)
    # Sleep for ~0s if elapsed time is 0
    fd.slow_down(0, 0.1, 1, -1.0)



# Generated at 2022-06-12 16:28:13.822538
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    x = FileDownloader({'retries': 2})
    assert x.format_retries(2) == '2'
    x = FileDownloader({'retries': 2, 'playliststart': 0})
    assert x.format_retries(2) == '2'
    x = FileDownloader({'retries': 2, 'playliststart': 1})
    assert x.format_retries(2) == 'inf'
    x = FileDownloader({'retries': 2, 'playlistend': 2})
    assert x.format_retries(2) == '2'
    x = FileDownloader({'retries': 2, 'playlistend': 1})
    assert x.format_retries(2) == 'inf'



# Generated at 2022-06-12 16:28:24.407529
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    from tests.test_utils import FakeYDL
    from youtube_dl.YoutubeDL import YoutubeDL

    def _test_slow_down(self, byte_counter, elapsed, ratelimit, expected_sleep):
        class FakeTime(object):
            def time(self):
                return elapsed

        self.ydl = FakeYDL()
        self.params = {
            'ratelimit': ratelimit,
        }
        self.ydl.params = self.params
        self.time = FakeTime()
        self.start = 1.0
        self.slow_down(self.start, None, byte_counter)
        self.assertAlmostEqual(self.time.time() - self.start, expected_sleep, delta=0.01)


# Generated at 2022-06-12 16:28:41.671976
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    from . import YoutubeDL
    fd = FileDownloader(YoutubeDL({}), {})
    assert fd.temp_name('.youtube-dl.mp4') == '.youtube-dl.part.mp4'
    assert fd.temp_name('.youtube-dl') == '.youtube-dl.part'
    assert fd.temp_name('abc.mp4') == 'abc.part.mp4'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('/home/xyz/abc.mp4') == '/home/xyz/abc.part.mp4'
    assert fd.temp_name('/home/xyz/abc') == '/home/xyz/abc.part'

# Generated at 2022-06-12 16:28:54.296423
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """Initialize a FileDownloader object and try to set the
    last-modified time of a file."""
    from .YoutubeDL import YoutubeDL # From __init__.py, to avoid circular dependency
    from .utils import encodeFilename
    _, tmpfilename = tempfile.mkstemp(prefix='youtubedl-test_FileDowloader-')
    fd = FileDownloader(
        YoutubeDL(),
        {'restrictfilenames': True, 'outtmpl': tmpfilename + '_%(epoch)s'},
        {'id': encodeFilename(tmpfilename)})

# Generated at 2022-06-12 16:29:05.337781
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    def test_sleep(FileDownloader):
        time.sleep(0.01)

    print('Testing FileDownloader.slow_down()')
    fd = FileDownloader({'nooverwrites': True,
                         'verbose': False,
                         'ratelimit': 8192})
    fd.to_screen = lambda msg: test_sleep(fd)
    fd.report_progress = lambda x: None
    blocksize = 8192
    fd._download_retry = lambda *x, **y: None
    # Check that if rate_limit is set to None the method exits immediately
    fd.params['ratelimit'] = None
    t1 = time.time()
    fd.slow_down(t1, t1, blocksize)
    dt = time.time() - t1

# Generated at 2022-06-12 16:29:17.907042
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'noprogress': True})
    curr_time = int(time.time())
    fd.slow_down(curr_time, curr_time, 100000)
    assert fd.params.get('sleep_interval') == 1.0
    fd.slow_down(curr_time, curr_time+1, 100000)
    assert fd.params.get('sleep_interval') == 0.9
    fd.slow_down(curr_time, curr_time, 10000000)
    assert fd.params.get('sleep_interval') == 0.8
    fd.slow_down(curr_time, curr_time+100, 10000000)
    assert fd.params.get('sleep_interval') == 0.7
   

# Generated at 2022-06-12 16:29:30.679368
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import sys
    import tempfile
    from youtube_dl.utils import *

    with tempfile.TemporaryDirectory() as tmpdir:
        if sys.version_info >= (3, 6):
            tempdir = Path(tmpdir)

        fd = FileDownloader(None, {'nopart': True})
        fname = os.path.join(tmpdir, 'tést.mp4')
        fd.to_screen('tést fname:' + fname)
        tn = fd.temp_name(fname)
        assert fname == tn
        open(fname, 'wb').close()

        fd = FileDownloader(None, {'nopart': False})
        fname = os.path.join(tmpdir, 'tést.mp4')
        tn = fd

# Generated at 2022-06-12 16:29:41.979184
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import zipfile

    from compat import TemporaryDirectory

    from youtube_dl.version import __version__

    with TemporaryDirectory(suffix='test_FileDownloader.test_try_utime') as td:
        input_file_path = os.path.join(td, 'input.zip')
        output_file_path = os.path.join(td, 'output')

        with zipfile.ZipFile(input_file_path, 'w') as zf:
            zf.writestr('input.txt', 'foo')

        with open(input_file_path, 'rb') as rf:
            with open(output_file_path, 'wb') as wf:
                wf.write(rf.read())

        with open(input_file_path, 'rb') as rf:
            last_modified_hdr

# Generated at 2022-06-12 16:29:53.585383
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-12 16:30:05.515786
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    fd = FileDownloader(None, None)
    assert fd.parse_bytes('1') is None
    assert fd.parse_bytes('1k') == 1024
    assert fd.parse_bytes('1K') == 1024
    assert fd.parse_bytes('1m') == 1024 ** 2
    assert fd.parse_bytes('1M') == 1024 ** 2
    assert fd.parse_bytes('1g') == 1024 ** 3
    assert fd.parse_bytes('1G') == 1024 ** 3
    assert fd.parse_bytes('1x') is None
    assert fd.parse_bytes('1b') == 1
    assert fd.parse_bytes('1B') == 1
    assert fd.parse_bytes('1024') == 1024
    assert fd.parse_bytes('3.14') is None

# Generated at 2022-06-12 16:30:13.244959
# Unit test for method report_progress of class FileDownloader

# Generated at 2022-06-12 16:30:24.718101
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    """test that download method return value is True or False.
    This test is not very good as it doesn't test the functionality of the real_download method.
    """
    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda d: None)
    ydl.params['nooverwrites'] = ydl.params['continuedl'] = True
    # test with nopart
    ydl.params['nopart'] = True
    # test for a file that has already been downloaded
    # test for nopart
    fd = FileDownloader(ydl, {'id': 'id'})
    fd.params['nopart'] = True
    path = os.path.join(os.path.expanduser('~'), 'test-youtube-dl')
    open(path, 'w').close()

# Generated at 2022-06-12 16:30:54.811039
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    fd = FileDownloader({})  # Just an empty dict
    # Test cases with expected results
    test_cases = [
        ('abc.part', 'abc'),
        ('abc.file.part', 'abc.file'),
        ('abc.mp3.part', 'abc.mp3'),
        ('abc', 'abc'),
        ('abc.part.part', 'abc.part'),
        ('x.y.z', 'x.y.z'),
    ]
    for (test_input, expected_result) in test_cases:
        result = fd.undo_temp_name(test_input)
        assert result == expected_result, 'got %s instead of %s with input %s' % (result, expected_result, test_input)
    # Generate random filenames
    # We now add 100 new test cases to

# Generated at 2022-06-12 16:31:07.206311
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl_opts = {
        'continuedl': True,
        'outtmpl': '%(autonumber)s-%(id)s-%(title)s.%(ext)s',
        'nooverwrites': True,
        'verbose': True,
        'logger': YoutubeDL().logger,
    }
    ydl = YoutubeDL(ydl_opts)
    fd = FileDownloader(ydl, {
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'title': 'Horses riding horses',
    })


# Generated at 2022-06-12 16:31:18.900961
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    class FakeTime(object):
        def __init__(self):
            self.time = time.time()
            self.step = 0

        def time(self):
            self.time += self.step
            return self.time

    fd = FileDownloader({})

    ft = FakeTime()
    ft.step = 1
    assert fd.calc_speed(ft.time(), ft.time(), 0) is None
    assert fd.calc_speed(ft.time(), ft.time(), 1) is None
    assert fd.calc_speed(ft.time(), ft.time(), 10) is None
    assert fd.calc_speed(ft.time(), ft.time(), 100) is None

    ft.step = 1
    assert fd.calc_speed(ft.time(), ft.time(), 1)

# Generated at 2022-06-12 16:31:30.860770
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    params = {
        'outtmpl': '%(title)s-%(id)s-%(autonumber)s-%(ext)s',
        'format': 'best',
    }
    ydl = YoutubeDL(params)
    fd = FileDownloader(ydl, params)
    assert fd.temp_name('test.mp4') == 'test.part.mp4'
    assert fd.temp_name('test-%(id)s-test.mp4') == 'test-%(id)s-test.part.mp4'

    params.update({
        'nopart': True,
    })
    fd = FileDownloader(ydl, params)
    assert fd.temp_name('test.mp4') == 'test.mp4'
    assert fd.temp_

# Generated at 2022-06-12 16:31:42.900358
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class TestFD(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.fp = open(self.temp_name('unittest'), 'wb')
        def real_download(self, filename, info_dict):
            return True
        def temp_name(self, filename):
            return filename
        def try_utime(self, filename, last_modified_hdr):
            return True
        def try_rename(self, old_filename, new_filename):
            return
        def report_progress(self, s):
            return
        def report_destination(self, filename):
            return

    ydl = DummyYDL()
    ydl.params = {'ratelimit': 10240} # 10KB/s
   

# Generated at 2022-06-12 16:31:54.324586
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Since the report_progress method uses the format_bytes
    # and format_percent functions, the tests are done in the same
    # file where the functions are defined
    # In this test we use the format_bytes function
    # format_bytes
    assert format_bytes(1023) == u'1023.0\xa0bytes'
    assert format_bytes(1023, '%3.1f\xa0%s') == u'1023.0\xa0bytes'
    assert format_bytes(1023, '%3.1f\xa0%s', '-') == u'1023-0\xa0bytes'
    assert format_bytes(123456789) == u'117.7\xa0MiB'
    assert format_bytes(123456789000) == u'1.1\xa0GiB'

# Generated at 2022-06-12 16:32:03.544252
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader({}).temp_name('example.webm') == 'example.webm.part'
    assert FileDownloader({}).temp_name('example.webm.part') == 'example.webm.part'
    assert FileDownloader({'nopart': True}).temp_name('example.webm') == 'example.webm'
    assert FileDownloader({'nopart': True}).temp_name('example.webm.part') == 'example.webm.part'
    assert FileDownloader({}).temp_name('-') == '-'
    assert FileDownloader({}).temp_name('/dev/null') == '/dev/null'
    assert FileDownloader({}).temp_name(u'abcü.webm') == u'abcü.webm.part'



# Generated at 2022-06-12 16:32:14.734250
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    def slow_down_stub(start, now, byte_counter, self_):
        FileDownloader.slow_down(self_, start, now, byte_counter)

    def slow_down_real(start, now, byte_counter):
        self_ = FileDownloader(params={'ratelimit': 100})
        slow_down_stub(start, now, byte_counter, self_)

    def assertRaisesRegex(exception, regex, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except exception as err:
            if regex is None or re.search(regex, str(err)) is not None:
                return
            raise AssertionError('"%s" does not match "%s"' % (regex, str(err)))
        else:
            raise Ass

# Generated at 2022-06-12 16:32:21.752303
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class TestProgress(object):
        def __init__(self):
            self.last_time = None

        def __call__(self, status):
            if self.last_time is not None:
                dif = float(status['downloaded_bytes']) - self.last_time[0]
                rate = dif / (status['elapsed'] - self.last_time[1])
                if rate > 200:
                    raise Exception('Too fast')
                if rate < 50 and self.last_time[1] != 0:
                    raise Exception('Too slow')
            self.last_time = (float(status['downloaded_bytes']), status['elapsed'])

    test_fd = FileDownloader({'ratelimit': 100})
    test_fd.add_progress_hook(TestProgress())
    test_fd.to_

# Generated at 2022-06-12 16:32:34.958026
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.utils import DateRange

    ydl = YoutubeDL({
        'keepvideo': True,
        'format': 'best',
        'nooverwrites': True,
        'forcetitle': True,
        'verbose': False,
    })

    # Generate a list of dates for testing
    daterange = DateRange(None)
    dates = []
    for i in daterange._generate_days(365):
        dates.append(i.strftime('%Y%m%d'))
