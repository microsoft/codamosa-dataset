

# Generated at 2022-06-12 16:23:59.582099
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert fd.best_block_size(1, 1) == 2
    assert fd.best_block_size(2, 1) == 0.5
    assert fd.best_block_size(2, 2) == 4
    assert fd.best_block_size(4, 2) == 1
    assert fd.best_block_size(5, 2) == 1
    assert fd.best_block_size(5, 3) == 2
    assert fd.best_block_size(10, 1) == 0.25
    assert fd.best_block_size(10, 2) == 5
    assert fd.best_block_size(10, 3) == 3.3
    assert fd.best_block_size(20, 2) == 2.5
   

# Generated at 2022-06-12 16:24:11.547789
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class TestFD(FileDownloader):
        def __init__(self, ydl, d):
            FileDownloader.__init__(self, ydl)
            self.downloaded_bytes = [0]
            self.params = d['params']
            self.to_screen = d['to_screen']
            self.total_bytes = d['total_bytes']
            self.total_bytes_estimate = d['total_bytes_estimate']
            self.use_test_msg = d['use_test_msg']
            self.test_msg = d['test_msg']

        def to_screen(self, *args, **kargs):
            self.to_screen(*args, **kargs)


# Generated at 2022-06-12 16:24:13.061978
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader({'retries': 3}, None)
    assert fd.format_retries(3) == '3'
    assert fd.format_retries(float('inf')) == 'inf'


# Generated at 2022-06-12 16:24:17.161894
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # TODO to be continued
    fd = FileDownloader()
    if fd.temp_name(None) == None:
        print('test_FileDownloader_temp_name: PASS')
    else:
        print('test_FileDownloader_temp_name: FAIL')

# Generated at 2022-06-12 16:24:30.095380
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    def best_block_size(byte_counter, elapsed):
        return int(round(FileDownloader(None).best_block_size(elapsed, byte_counter)))

    assert best_block_size(0, 0) == 1
    assert best_block_size(1, 0) == 1
    assert best_block_size(1000, 0) == 1
    assert best_block_size(1024, 0) == 1
    assert best_block_size(10000, 0) == 1
    assert best_block_size(100000, 0) == 1
    assert best_block_size(1000000, 0) == 1

    assert best_block_size(0, 1) == 1024 ** 2
    assert best_block_size(1, 1) == 1
    assert best_block_size(1000, 1) == 1000
    assert best_

# Generated at 2022-06-12 16:24:40.793907
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():

    # Test valid bytes expressions
    assert FileDownloader.parse_bytes('42') == 42
    assert FileDownloader.parse_bytes(' 42 ') == 42
    assert FileDownloader.parse_bytes('42B') == 42
    assert FileDownloader.parse_bytes(' 42b ') == 42
    assert FileDownloader.parse_bytes(' 42B ') == 42
    assert FileDownloader.parse_bytes('42.5B') == 42
    assert FileDownloader.parse_bytes('42.5k') == 43008
    assert FileDownloader.parse_bytes('42.4k') == 43000
    assert FileDownloader.parse_bytes('42.6k') == 43008
    assert FileDownloader.parse_bytes('42.6f') == 42
    assert FileDownloader.parse_bytes('42.6foobar') == 42

# Generated at 2022-06-12 16:24:53.943246
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    print('\n**** Testing FileDownloader.report_progress ****')

    def _run_test(
            downloaded_bytes=0, start_time=None, elapsed=None,
            speed=None, eta=None, total_bytes=None,
            total_bytes_estimate=None, status='downloading', is_noprogress=False):
        fd = FileDownloader({
            'noprogress': is_noprogress,
            'format': 'best',
        })
        orig_stderr = sys.stderr
        sys.stderr = io.StringIO()

# Generated at 2022-06-12 16:25:05.878423
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():

    def mock_sleep(n):
        nonlocal sleep_time
        sleep_time = n

    def mock_time():
        nonlocal time_count
        time_count += 1
        return time_count

    downloader = FileDownloader({'ratelimit': 1})
    downloader.real_download = lambda f, _: None
    time_count = 0
    sleep_time = -1
    downloader.slow_down = lambda s, n, b: downloader.ydl.sleep(sleep_time)
    downloader.ydl.sleep = lambda n: mock_sleep(n)
    downloader.ydl.time = mock_time

    speed = 5
    downloader.ydl.to_screen = lambda *args, **kargs: None  # Do nothing

# Generated at 2022-06-12 16:25:12.257710
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import sys
    import io

    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self['format'] = 'best'

    class MockYoutubeDL(object):
        def __init__(self):
            self.trouble = lambda *args, **kargs: None
            self.params = {
                'verbose': True,
                'nooverwrites': False,
                'continuedl': True,
                'nopart': False,
            }
            self.to_screen = lambda s: sys.stderr.write(s + '\n')

        def to_console_title(self, title):
            pass


# Generated at 2022-06-12 16:25:23.458720
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    downloader = FileDownloader()
    testdir = os.path.dirname(__file__)
    testdir = os.path.join(testdir, 'testdir')

    # Try renaming a file that does not exist
    try:
        downloader.try_rename('test1.txt', 'test2.txt')
    except OSError as e:
        pass
    except Exception as e:
        raise (e)
    else:
        raise ValueError('Unable to catch OSError')

    # Create a file that can be renamed
    try:
        with open(os.path.join(testdir, 'test1.txt'), 'w') as fp:
            fp.write('test1.txt')
    except IOError as e:
        raise (e)

    # Rename test1.

# Generated at 2022-06-12 16:25:50.651868
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes('') is None
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('12') == 12
    assert FileDownloader.parse_bytes('12.3') == 12
    assert FileDownloader.parse_bytes('12.34') == 12
    assert FileDownloader.parse_bytes('.3') == 0
    assert FileDownloader.parse_bytes('1.3') == 1
    assert FileDownloader.parse_bytes('1.3k') == 1300
    assert FileDownloader.parse_bytes('1.3K') == 1300
    assert FileDownloader.parse_bytes('2.3m') == 2300000
    assert FileDownloader.parse_bytes('1.3g') == 1300000000

# Generated at 2022-06-12 16:25:51.638486
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    FileDownloader()

 

# Generated at 2022-06-12 16:25:58.926921
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    print('\ntest_FileDownloader_report_file_already_downloaded')
    open('test_file.txt', 'a').close()
    
    fd = FileDownloader({})
    fd.to_screen = _tst_to_screen
    fd.report_file_already_downloaded('test_file.txt')
    
    #os.remove('test_file.txt')


# Generated at 2022-06-12 16:26:11.476935
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.downloader import get_suitable_downloader
    from youtube_dl.version import __version__
    from youtube_dl.extractor import gen_extractors

    fd = FileDownloader({}, None, None)

    ie = get_info_extractor(get_suitable_downloader('http://example.com'), None)
    ie.extractor = ie
    ie._WORKING = True


# Generated at 2022-06-12 16:26:20.100407
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    f = FileDownloader(YDL(), params={})
    f.to_screen = lambda *args, **kargs: None  # Don't print to screen
    s = dict((el, 0) for el in ['total_bytes', 'downloaded_bytes', 'elapsed', 'eta', 'speed', 'fragment_index', 'fragment_count', 'fragment_duration'])
    # Case 0: basic test
    s.update(status='downloading', downloaded_bytes=1, elapsed=1, eta=0, speed=2, total_bytes=5)
    f.report_progress(s)
    assert f._progress_prev_line_length == 44
    s['elapsed'] = 10
    s['eta'] = 0
    s['total_bytes'] = 25
    f.report_progress(s)


# Generated at 2022-06-12 16:26:33.019000
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Intialize downloader with empty args
    downloader = FileDownloader(params={})

    # Initialize status values
    status = {
        'status': 'downloading',
        'downloaded_bytes': 1760,
        'total_bytes': None,
        'total_bytes_estimate': None,
        'eta': None,
        'elapsed': None,
        'speed': None,
        'fragment_index': 2,
        'fragment_count': 3
    }

    # Test report_progress with no_progress mode enabled
    downloader.params['noprogress'] = True
    downloader.report_progress(status)

    # Test report_progress with no_progress mode disabled
    downloader.params['noprogress'] = False
    downloader.report_progress(status)




# Generated at 2022-06-12 16:26:43.776472
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class MockYtdl(object):
        def __init__(self, *args, **kargs):
            pass

        def to_screen(self, *args, **kargs):
            pass

        def to_console_title(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

    class MockYdl(object):
        def __init__(self, *args, **kargs):
            pass

        def to_screen(self, *args, **kargs):
            pass

        def to_console_title(self, *args, **kargs):
            pass


# Generated at 2022-06-12 16:26:48.698343
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():

    # Explicitly import the code
    from youtube_dl.downloader import FileDownloader
    # Create a downloader instance
    ydl = FileDownloader({})
    # Create a fake file
    f = io.BytesIO()
    f.write(b'Hello World\n')
    f.seek(0, 0)
    # Now we get the last modification time
    last_modified_hdr = time.strftime('%a, %d %b %Y %H:%M:%S %Z', time.gmtime())
    time_before = time.time()
    time_after = time.time() + 1
    # Now we try to set the mtime with FileDownloader's method
    ydl.try_utime(f, last_modified_hdr)
    # And we read the mtime
    mtime = os

# Generated at 2022-06-12 16:26:54.599547
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Replacement for os.utime
    class FakeUtimes:
        def __init__(self):
            self.filename = None
            self.times = None

        def __call__(self, filename, times):
            self.filename = filename
            self.times = times

    fu = FakeUtimes()

    dl = FileDownloader({
        'outtmpl': '%(epoch)s',
    })
    dl.report_destination = lambda x: None
    dl.to_screen = lambda x: None
    dl.try_utime = lambda x, y: None

    def test_time(d, t):
        fu.filename = None
        fu.times = None
        dl.try_utime(d, t)
        return (fu.filename, fu.times, d)

    os

# Generated at 2022-06-12 16:27:05.870694
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({'nooverwrites': True})
    assert fd.best_block_size(3.0, 1000) == 4000
    assert fd.best_block_size(0.1, 1000) == 1000
    assert fd.best_block_size(2.5, 4194304) == 4194304
    assert fd.best_block_size(0.1, 4194304) == 419430.4
    assert fd.best_block_size(5.5, 4194304) == 8388608
    assert fd.best_block_size(0.0, 4194304) == 4194304
    assert fd.best_block_size(0.0, 0) == 1
    assert fd.best_block_size(5.5, 0) == 1
    assert f

# Generated at 2022-06-12 16:27:42.305889
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # We don't need actually to create a FileDownloader class to test
    # the function slow_down

    # We will pretend the download started right now
    start = time.time()

    # We will pretend we have downloaded N bytes
    N = 1000000

    # The mean speed is 100 Kbytes/s
    speed = 100 * 1024

    # This means that we have to wait for 10 seconds to download
    # the rest of the file
    eta = 10

    # But we pretend we are going to sleep for 2 seconds
    # to test it was enough to be less than eta
    time.sleep(2)

    # So we download the rest with a speed of 50 Kbytes/s
    # (we use only half of the bandwidth)
    slow_down(start, time.time(), N / 2, eta)

    # Now the mean speed

# Generated at 2022-06-12 16:27:52.856722
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    def init(fd):
        # pylint: disable=attribute-defined-outside-init
        fd.to_screen_calls = []

    def to_screen(fd, msg, skip_eol=False):
        fd.to_screen_calls.append((msg, skip_eol))

    fd = FileDownloader({})
    init(fd)
    fd.to_screen = to_screen
    # To simulate a normal download
    fd.report_progress({'status': 'finished', 'total_bytes': 10101,
                        'downloaded_bytes': 10101})
    assert (fd.to_screen_calls == [('[download] 100% of 10.1KiB', True),
                                   ('[download] Download completed', False)])
    init(fd)
    fd.report

# Generated at 2022-06-12 16:28:03.972496
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    import nose.tools
    import random

    def _assert_min_max(elapsed_time, bytes, min_block, max_block):
        block = FileDownloader.best_block_size(elapsed_time, bytes)
        nose.tools.assert_greater_equal(block, min_block)
        nose.tools.assert_less_equal(block, max_block)


# Generated at 2022-06-12 16:28:13.821137
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Create an instance of class FileDownloader and set its rate_limit to 1MB/s
    fd = FileDownloader(params=dict(ratelimit='1M'))
    
    # Set the initial start time to 0
    start_time = 0
    
    # Set the current time to 1 second
    now = 1
    
    # Detect the time to sleep that is required to slow down
    t = fd.slow_down(start_time, now, pow(2,20))
    
    # If the time to slow down is not more than 0.5s, return true
    return t<0.5


# Generated at 2022-06-12 16:28:24.408498
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    fd = FileDownloader(
        YoutubeDL({'noprogress': True, 'nopart': True}),
        {'id': '6e9B6YyhV8E',
         'url': 'http://www.youtube.com/watch?v=6e9B6YyhV8E',
         'upload_date': '20110307',
         'title': 'Sintel trailer',
         'ext': 'webm'})

    assert fd.temp_name('/foo/bar.mp4') == '/foo/bar.mp4'
    assert fd.temp_name('/foo/bar') == '/foo/bar'
    assert fd.temp_name('bar.mp4') == 'bar.part'
    assert fd.temp_name('bar') == 'bar.part'

   

# Generated at 2022-06-12 16:28:37.322576
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    video_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    tmp_filename = 'BaW_jenozKc.mp4'
    ydl = YoutubeDL(params={
        'outtmpl': tmp_filename,
        'nooverwrites': True,
        'continuedl': False,
        'verbose': False,
        'nopart': False,
    })

    fd = FileDownloader(ydl, params={
        'quiet': True,
    })

    fd.report_file_already_downloaded(tmp_filename)

    fd._hook_progress({
        'filename': tmp_filename,
        'status': 'finished',
        'total_bytes': os.path.getsize(tmp_filename),
    })


# Generated at 2022-06-12 16:28:38.369882
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    return


# Generated at 2022-06-12 16:28:50.415045
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    def dummy_ydl(x):
        pass
    fd = FileDownloader(dummy_ydl, {})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.part1') == 'abc.part1'
    assert fd.temp_name('abc.part.1') == 'abc.part.1'
    assert fd.temp_name('abc.part.13') == 'abc.part.13'
    assert fd.temp_name('abc.part.a') == 'abc.part.a'
    assert fd.temp_name('abc.part.a6') == 'abc.part.a6'

# Generated at 2022-06-12 16:28:58.755436
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader().undo_temp_name('abc.mp3.part') == 'abc.mp3'
    assert FileDownloader().undo_temp_name('abc') == 'abc'
    assert FileDownloader().undo_temp_name('abc.mp3') == 'abc.mp3'
    assert FileDownloader().undo_temp_name('abc.mp3.part.part') == 'abc.mp3.part'
    assert FileDownloader().undo_temp_name('abc.part.part') == 'abc.part'

# Generated at 2022-06-12 16:29:07.970665
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc.part') == 'abc.part'
    assert fd.temp_name('abc.txt') == 'abc.txt.part'
    assert fd.temp_name('/home/user/abc.txt') == '/home/user/abc.txt.part'
    assert fd.temp_name('/home/user/abc') == '/home/user/abc.part'
    assert fd.temp_name('/home/user/') == '/home/user/.part'
    assert fd.temp_name('/home/user') == '/home/user.part'

# Generated at 2022-06-12 16:29:36.702417
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    def wrap_sleep(orig_func):
        def wrapped_sleep(self, s):
            self.sleep_count += s
        return wrapped_sleep
    class FakeFileDownloader(FileDownloader):
        def __init__(self, params):
            super(FakeFileDownloader, self).__init__(params)
            self.sleep_count = 0
        def real_download(self, filename, info_dict):
            self.sleep_count = 0
            self.sleep = wrap_sleep(self.sleep)

    fd = FakeFileDownloader({})
    assert fd.download('-', {'ext': 'mp4'}) is True
    assert fd.sleep_count == 0
    assert fd.download('foo', {'ext': 'mp4'}) is True
    assert fd.sleep_count == 0


# Generated at 2022-06-12 16:29:37.871025
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    return



# Generated at 2022-06-12 16:29:47.021434
# Unit test for method parse_bytes of class FileDownloader

# Generated at 2022-06-12 16:29:59.303905
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def _check_try_utime(f, mtime):
        assert f.try_utime(filename, mtime) == mtime
        assert int(os.stat(encodeFilename(filename)).st_mtime) == mtime

    f = FileDownloader(None)
    temp_filename = mktemp()
    filename = temp_filename + '.part'

# Generated at 2022-06-12 16:30:09.808594
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    url = 'http://example.com/video.mp4'
    info_dict = {
        'id': 'video',
    }
    with make_temp_dir() as tmpdir:
        filename = os.path.join(tmpdir, 'video.mp4')
        ydl = FileDownloader(params={})
        ydl.report_destination(filename)

        assert not os.path.exists(encodeFilename(filename))
        assert not ydl.download(filename, info_dict)
        assert not os.path.exists(encodeFilename(filename))

        with open(encodeFilename(filename), 'w') as f:
            f.write('example video')

        assert os.path.exists(encodeFilename(filename))

        ydl = FileDownloader(params={})

        assert ydl.real

# Generated at 2022-06-12 16:30:11.907661
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    fd = FileDownloader('_')
    fd.report_file_already_downloaded('f')


# Generated at 2022-06-12 16:30:23.666175
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeYdl(object):
        def __init__(self):
            self.to_screen = lambda msg: None
            self.to_console_title = lambda msg: None

    class FakeInfoDict(object):
        def __init__(self, file_size):
            self.file_size = file_size

    fd = FileDownloader(FakeYdl(), {})
    infodict = FakeInfoDict(1375)

    fd.report_progress({'total_bytes': 1375, 'downloaded_bytes': 1375, 'status': 'finished'})
    fd.report_progress({'downloaded_bytes': 1375, 'status': 'downloading'})
    # The next two tests check if fd.format_percent does not raise an exception
    # when one of its arguments is zero.
    #

# Generated at 2022-06-12 16:30:35.169566
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    downloader = FileDownloader(None, None)

# Generated at 2022-06-12 16:30:47.629388
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test 1:
    params = {
        'noprogress': True
    }
    fd = FileDownloader(params)
    status = {'status': 'finished'}
    fd.report_progress(status)
    # Test 2:
    params = {
        'noprogress': False
    }
    fd = FileDownloader(params)
    status = {'status': 'finished'}
    fd.report_progress(status)
    # Test 3:
    params = {
        'noprogress': False,
        'progress_with_newline': True
    }
    fd = FileDownloader(params)
    status = {'status': 'finished'}
    fd.report_progress(status)
    # Test 4:

# Generated at 2022-06-12 16:30:56.269290
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    import math

# Generated at 2022-06-12 16:32:35.067185
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # Create a file with the modified time at -1 second
    # Tests for issue #7051 (https://github.com/rg3/youtube-dl/issues/7051)
    fd, a_file = tempfile.mkstemp()
    os.close(fd)
    os.utime(a_file, (time.time() - 1, time.time() - 1))

    # Create the downloader and run the test
    params = {
        'format': 'best',
        'nooverwrites': True,
    }
    fd = FileDownloader({
        'outtmpl': a_file,
        'quiet': True,
        'continuedl': True,
        'noprogress': True,
        'nopart': True,
    }, params, FakeYDL())

    # Only run the

# Generated at 2022-06-12 16:32:44.122848
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Build a test object
    ydl = YoutubeDL()
    ydl.params['ratelimit'] = '10240'  # bytes/sec
    ydl.params['retries'] = 5
    ydl.params['buffersize'] = '1024'
    ydl.params['outtmpl'] = 'b'  # doesn't matter
    ydl.params['quiet'] = True
    # Make sure we don't pollute unit tests directory with test files
    with temp_name('test_FileDownloader_slow_down.tmp', False) as temp_file:
        ydl.params['outtmpl'] = temp_file + '.' + '%(ext)s'

        fd = FileDownloader(ydl, {})

        start_time = time.time()
        byte_counter = 2048  # some bytes

# Generated at 2022-06-12 16:32:56.399745
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import os
    import tempfile
    tmpfd, tmpfname = tempfile.mkstemp(prefix='ydl_test_')

    # Create a dummy file
    f = os.fdopen(tmpfd, 'wb')
    f.write(('a' * 1048576).encode('ascii'))
    f.close()

    # Calculate the expected sleep time
    fsize = os.path.getsize(tmpfname)
    start_time = 0
    now = start_time + 1
    ratelimit = 1024000  # bytes / second
    download_time = fsize / ratelimit
    sleep_time = download_time - (now - start_time)

    # Test without sleep interval
    ratelimit = 0
    slow_down(start_time, now, fsize, ratelimit)

    # Test with

# Generated at 2022-06-12 16:33:07.187296
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    t_start = time.time()
    ydl = YoutubeDL()
    ydl.params['ratelimit'] = None
    ydl.params['retries'] = 1
    ydl.params['fragment_retries'] = None
    ydl.params['test'] = True

    fd = FileDownloader({
        'url': 'http://127.0.0.1/256',
        'test': True,
        'player_url': 'http://127.0.0.1/256',
        'filename': 'test.mp4',
        'fragment_index': 0},
        ydl)

    fd.slow_down(t_start, time.time(), 256000)
    assert(time.time() - t_start < 0.1)
    t_start = time.time()
    f

# Generated at 2022-06-12 16:33:19.019735
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    from io import StringIO
    from datetime import datetime
    now = datetime.now()
    date = now.timetuple()
    rfc2616 = '%s, %02d %s %04d %02d:%02d:%02d GMT' % (
        '%s' % ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][date[6] - 1],
        date[2],
        '%s' % ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][date[1] - 1],
        date[0], date[3], date[4], date[5])
    out = StringIO()