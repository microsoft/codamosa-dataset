

# Generated at 2022-06-12 16:24:05.204630
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    values = [
        (1, '1'),
        (2, '2'),
        (10, '10'),
        (float("inf"), 'inf')
    ]

    for val, expected in values:
        if FileDownloader.format_retries(val) != expected:
            raise ValueError('Test %i failed. Expected %s got %s ' % (
                val, expected, FileDownloader.format_retries(val)))


# Generated at 2022-06-12 16:24:16.185385
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    """
    Test try_utime method of FileDownloader class
    """
    def test_case(filetime, strtimestamp, expect_result):
        """
        Testcase
        filetime: expect time in integer
        strtimestamp: string represent time to be parsed
        expect_result: expected result by this testcase
        """
        temp_folder = tempfile.mkdtemp()
        temp_filename = os.path.join(temp_folder, 'test')

# Generated at 2022-06-12 16:24:25.094311
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    obj = FileDownloader()
    obj.to_screen = mock.Mock()

    # Test with a str object
    filename = 'filename'
    obj.report_file_already_downloaded(filename)
    obj.to_screen.assert_called_with('[download] filename has already been downloaded')

    # Test with a bytes object
    filename = 'filename'.encode('utf-8')
    obj.report_file_already_downloaded(filename)
    obj.to_screen.assert_called_with('[download] The file has already been downloaded')


# Generated at 2022-06-12 16:24:36.335971
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    # Test parameters
    rate_limit = None
    start_time = None
    now = None
    byte_counter = 0
    fd = FileDownloader(YoutubeDL(), {})
    fd.slow_down(start_time, now, byte_counter)
    # Test rate limit
    rate_limit = 2
    start_time = time.time()
    now = None
    byte_counter = 0
    fd = FileDownloader(YoutubeDL(), {'ratelimit': rate_limit})
    fd.slow_down(start_time, now, byte_counter)
    # Test parameters still equal
    rate_limit = None
    start_time = time.time()
    now = None
    byte_counter = 0
    fd = FileDownloader(YoutubeDL(), {})
    fd.slow_down

# Generated at 2022-06-12 16:24:45.151757
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import time
    import tempfile

    fd, fpath = tempfile.mkstemp()
    os.close(fd)

    def touch(fpath):
        with open(fpath, 'a'):
            os.utime(fpath, None)

    def test_try_utime(fpath, last_modified_hdr):
        touch(fpath)
        time.sleep(0.1)
        last_modified = FileDownloader.try_utime(fpath, last_modified_hdr)
        time.sleep(0.1)
        assert last_modified is None or os.path.getmtime(fpath) == last_modified
        return last_modified


# Generated at 2022-06-12 16:24:49.148534
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    filename = '/tmp/temp_filename'
    info_dict = {'ext': 'mp4'}
    assert FileDownloader.download(filename, info_dict)

# Generated at 2022-06-12 16:24:55.417026
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': 10})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 11)
    assert time.time() - start_time > 0.001
    start_time = time.time()
    fd.slow_down(start_time, start_time, 10)
    assert time.time() - start_time < 0.001


# Generated at 2022-06-12 16:25:07.174565
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Different block sizes depending on the elapsed time
    assert FileDownloader.best_block_size(0.0, 0) == 1
    assert FileDownloader.best_block_size(0.0, 1) == 1
    assert FileDownloader.best_block_size(0.0, 100) == 1
    assert FileDownloader.best_block_size(0.5, 100) == 2
    assert FileDownloader.best_block_size(0.5, 1000) == 8
    assert FileDownloader.best_block_size(10.0, 1000) == 128
    assert FileDownloader.best_block_size(10.0, 10000) == 1024
    assert FileDownloader.best_block_size(60.0, 10000) == 4096

# Generated at 2022-06-12 16:25:08.944053
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    t = FileDownloader({}, {})
    assert t.undo_temp_name('test.part') == 'test'

# Generated at 2022-06-12 16:25:14.622233
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader.undo_temp_name('foo.part') == 'foo'
    assert FileDownloader.undo_temp_name('foo') == 'foo'
    assert FileDownloader.undo_temp_name('foo.bar') == 'foo.bar'

if __name__ == '__main__':
    test_FileDownloader_undo_temp_name()

# Generated at 2022-06-12 16:25:43.279294
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    downloader = FileDownloader({}, {})
    
    target_folder = 'Youtube_downloader_data'
    test_file = target_folder + '\\' + 'test.mp4'
    new_name = target_folder + '\\' + 'new_file_name.mp4'
    
    if not os.path.exists(target_folder):
        os.mkdir(target_folder)
        
    f = open(test_file, "w+")
    f.close()
    
    downloader.try_rename(test_file, new_name)
    assert os.path.exists(new_name)
    
    os.remove(new_name)
    os.rmdir(target_folder)
test_FileDownloader_try_rename()

# Generated at 2022-06-12 16:25:53.417916
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import unittest.mock as mock

    fd = YoutubeDL(dict())
    fd.params['retries'] = float('inf')
    fd.params['nooverwrites'] = False
    fd.params['continuedl'] = True
    fd.params['noprogress'] = False
    fd.params['ratelimit'] = 0
    fd.params['listformats'] = False
    fd.params['extractaudio'] = False
    fd.params['audioformat'] = 'best'
    fd.params['outtmpl'] = '%(id)s.%(ext)s'
    fd.params['usenetrc'] = False
    fd.params['verbose'] = False
    fd.params['quiet'] = False

# Generated at 2022-06-12 16:25:59.140910
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # This test simply verifies that it executes without error,
    # without testing the actual results.
    fd = FileDownloader(DummyYDL({'outtmpl': '%(id)s'}), {})
    fd.try_utime('video.mp4', None)
    fd.try_utime('video.mp4', 'Thu, 19 Nov 2015 18:47:39 GMT')
    fd.try_utime('video.mp4', 'Invalid')
    fd.try_utime('/non/existing/path', None)
    # The following may behave differently on different platforms
    fd.try_utime('video.mp4', '3013-11-30 12:34:56')
    # The following will return an error if the user running the tests
    # does not have permission to set the file

# Generated at 2022-06-12 16:26:02.450283
# Unit test for method try_rename of class FileDownloader
def test_FileDownloader_try_rename():
    assert FileDownloader.try_rename('test.test', 'temp.test') is None
test_FileDownloader_try_rename()


# Generated at 2022-06-12 16:26:14.711271
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os
    import time
    import tempfile

    if not hasattr(os, 'utime'):
        return

    fd, filename = tempfile.mkstemp()
    try:
        try:
            os.close(fd)
            now = time.time() - 100
            time.sleep(0.000001)

            FileDownloader({}).try_utime(filename, time.strftime('%Y%m%d%H%M%S', time.gmtime(now)))

            mtime = os.path.getmtime(filename)
            if mtime < now - 10 or mtime > now + 10:
                raise Exception('Setting mtime failed')
        finally:
            os.remove(filename)
    except:
        os.remove(filename)
        raise

test_FileDownloader_try_

# Generated at 2022-06-12 16:26:24.220734
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():

    ydl_opts = {}

    fd = FileDownloader(ydl_opts)

    # Test that a .part extension will be appended to filename
    # when the file doesn't exists
    filename = 'non-existing-file.mp4'
    res = fd.temp_name(filename)
    assert res == filename + '.part'

    # Test that a .part extension will be appended to filename
    # when the file exists and is a regular file
    filename = os.path.join('tests', 'test.mp4')
    res = fd.temp_name(filename)
    assert res == filename + '.part'



# Generated at 2022-06-12 16:26:37.007181
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({
        'ratelimit': 100 * 1000,  # 100KB/s
        'noprogress': True
    })

    def time():
        time.counter += 1
        return time.counter

    time.counter = 0

    assert fd.calc_speed(1, 5, 55) == 11.0
    assert fd.calc_eta(1, 5, 55, 99) == 9.0

    start = time()
    now = start
    byte_counter = 0
    while byte_counter < 99:
        now = time()
        byte_counter = min(99, byte_counter + fd.calc_speed(start, now, byte_counter))
        fd.slow_down(start, now, byte_counter)
    assert 10 <= now <= 14

    start = time()

# Generated at 2022-06-12 16:26:43.775577
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None)
    assert fd.calc_speed(0, 1, 0) is None
    assert fd.calc_speed(0, 1, 1) == 1
    assert fd.calc_speed(0, 1, 2) == 2
    assert fd.calc_speed(0, 2, 4) == 2
    assert fd.calc_speed(0, 2, 1) == 0.5
    assert fd.calc_speed(0, 1, 10) == 10



# Generated at 2022-06-12 16:26:49.313922
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    msg = FileDownloader.format_retries(float('inf'))
    assert msg == 'inf'

    msg = FileDownloader.format_retries(10.0)
    assert msg == '10'
    assert isinstance(msg, str)


# Generated at 2022-06-12 16:27:01.945008
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import os.path
    from tempfile import mkstemp
    from shutil import rmtree
    from urllib.parse import quote_plus
    from youtube_dl.utils import encodeFilename

    def norm_time(t):
        return int(round(t / 1000.0))

    def encodeFilename(s):
        return quote_plus(s)

    def timeconvert(timestr):
        import re
        t_struct = time.strptime(timestr, '%Y%m%d%H%M%S')
        return int(calendar.timegm(t_struct))

    def format_bytes(n):
        return '%6s' % '%d%s' % round_bytes(n)

    def assert_common(fdl):
        assert fdl.params is not None

# Generated at 2022-06-12 16:27:20.985267
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    fd = FileDownloader({})
    assert(fd.best_block_size(0, 0) == 1)
    assert(fd.best_block_size(1, 0) == 1)
    assert(fd.best_block_size(0, 1) == 1)
    assert(fd.best_block_size(1, 1) == 1)
    assert(fd.best_block_size(3, 1) == 1)
    assert(fd.best_block_size(-1, 1) == 1)
    assert(fd.best_block_size(1. / 0, 1) == 1)

    assert(fd.best_block_size(1, 10) == 10)
    assert(fd.best_block_size(1, 4194304) == 4194304)

# Generated at 2022-06-12 16:27:28.073348
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    d = FileDownloader(None, None)
    assert d.calc_speed(0, 0, 0) is None
    assert d.calc_speed(10, 0, 0) is None
    assert d.calc_speed(10, 10.1, 0) is None
    assert d.calc_speed(0, 0, 10) == 10
    assert d.calc_speed(10, 0, 10) == 1
    assert d.calc_speed(10, 10, 10) is None
    assert d.calc_speed(10, 10.1, 10) == 0.99
    assert d.calc_speed(10, 10.1, 100) == 9.9
    assert d.calc_speed(10, 10, 100) == 10

# Generated at 2022-06-12 16:27:40.405886
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # TODO make these tests more robust
    if compat_os_name == 'nt':
        raise SkipTest('file last modification time can not be set on Windows')

    # Create a temporary file
    f = tempfile.NamedTemporaryFile(delete=False)

    # Create FileDownloader object
    fd = FileDownloader({})

    # Set file last modification time to time() - 1h
    fd.try_utime(f.name, compat_str(int(time.time() - 3600)))

    # Check if file last modification time is correct
    if abs(os.stat(f.name).st_mtime - (time.time() - 3600)) > 1:
        raise AssertionError(
            'FileDownloader.try_utime() set invalid last modification time')

    # Cleanup
    f.close

# Generated at 2022-06-12 16:27:51.490871
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    # Get file size
    size = os.path.getsize('t/1_25MB.dat')
    # Download the file with default block size
    fd = FileDownloader({}, None, None)
    new_block_size = fd.best_block_size(0, size)
    assert new_block_size != 1024
    # Average speed between the two downloads
    avg_speed = (size / 1024) / (time.time() - start_time)
    # Minimum block size
    min_block_size = max(size / 2, 1)
    # Maximum block size
    max_block_size = min(max(size * 2, 1), 4194304)  # Do not surpass 4 MB
    # Expected block size

# Generated at 2022-06-12 16:28:01.779581
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from io import StringIO
    from tempfile import mkstemp, gettempdir
    from youtube_dl.utils import KEEP_VID_TS
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    import sys


# Generated at 2022-06-12 16:28:14.318274
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError
    class DummyFileDownloader(FileDownloader):

        def real_download(self, filename, info_dict):
            return True

    # Test 1: No errors
    class DummyExtractor1(InfoExtractor):
        def real_extract(self, url):
            return {'id': 'DummyVideoID1', 'url': 'DummyVideoURL1'}
    class DummyYoutubeDL1(YoutubeDL):
        def __init__(self, params):
            super(DummyYoutubeDL1, self).__init__(params)
            self._ies = [DummyExtractor1()]

# Generated at 2022-06-12 16:28:25.568688
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    tests_valid = [
        ('47', 47),
        ('1K', 1024),
        ('1k', 1024),
        ('1M', 1024 * 1024),
        ('1m', 1024 * 1024),
        ('1G', 1024 * 1024 * 1024),
        ('1g', 1024 * 1024 * 1024),
    ]
    for t in tests_valid:
        res = FileDownloader.parse_bytes(t[0])
        if res != t[1]:
            raise AssertionError('%s != %s' % (res, t[1]))
        res = FileDownloader.parse_bytes(t[1])
        if res != t[1]:
            raise AssertionError('%s != %s' % (res, t[1]))

# Generated at 2022-06-12 16:28:38.097390
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import unittest
    import shutil
    import tempfile
    import os
    import time

    class TestFileDownloader_try_utime(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            self.temp_dir = tempfile.mkdtemp()
            self.fpath_tmp = os.path.join(self.temp_dir, 'test_file')
            with open(self.fpath_tmp, 'w') as temp_fh:
                temp_fh.write('test')

            self.fd = FileDownloader({})

        @classmethod
        def tearDownClass(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-12 16:28:46.619028
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class TestFileDownloader(FileDownloader):

        def real_download(self, filename, info_dict):
            assert False

        def sleep(self, sleep_time):
            pass

    fd = TestFileDownloader()
    fd.params['ratelimit'] = 10
    start_time = time.time()
    fd.slow_down(start_time, start_time, 11)
    assert start_time + fd.params['retries'] < time.time()

    fd.slow_down(start_time, start_time, 9)
    assert start_time + fd.params['retries'] >= time.time()

# Generated at 2022-06-12 16:28:59.168512
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import _common
    downloader = _common.FileDownloader({
        'ratelimit': '100k',  # 100kbyte/sec
        'nooverwrites': True,
        'continuedl': True,
    })
    downloader.to_screen = lambda x: None
    downloader.to_stderr = lambda x: None
    start = time.time()
    downloader.slow_down(start, start, 0)  # speed=0
    time.sleep(1)
    downloaded = 2000  # 2Mbyte
    downloader.slow_down(start, time.time(), downloaded)
    assert time.time() - start <= downloaded / 100000 + 1  # +1sec for processing time
    downloaded = 2000  # 2Mbyte
    downloader.slow_down(start, time.time(), downloaded)


# Generated at 2022-06-12 16:29:23.362112
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    print('Testing FileDownloader.parse_bytes()')
    # Method should recognize SI suffixes
    assert FileDownloader.parse_bytes('10k') == 10 * 1024
    assert FileDownloader.parse_bytes('3M') == 3 * 1024 * 1024
    assert FileDownloader.parse_bytes('1G') == 1 * 1024 * 1024 * 1024
    # Method should recognize "," as a thousand separator
    assert FileDownloader.parse_bytes('1,000') == 1 * 1000
    # Method should accept float values
    assert FileDownloader.parse_bytes('1.5k') == 1.5 * 1024
    assert FileDownloader.parse_bytes('1,000.1') == 1 * 1000 + 100
    # Method should recognize JEDEC suffixes
    assert FileDownloader.parse_bytes('10Ki') == 10 * 1024
   

# Generated at 2022-06-12 16:29:36.209983
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:29:43.774299
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    class FakeYDL(object):
        def to_screen(self, *args, **_kargs):
            print(args[0])
        def to_console_title(self, *args, **_kargs):
            pass
    fd = FileDownloader({
        'progress_with_newline': False,
    }, FakeYDL())
    fd.report_progress({
        'status': 'finished',
        'downloaded_bytes': 1024,
        'total_bytes': 2048,
    })
    print('-' * 79)
    fd.report_progress({
        'status': 'finished',
        'downloaded_bytes': 1024,
        'total_bytes': 2048,
        'elapsed': 1,
    })
    print('-' * 79)

# Generated at 2022-06-12 16:29:56.228045
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():

    status_dict = {
        'status': 'downloading',
        'downloaded_bytes': 105000,
        'total_bytes': 200000,
        'speed': 5000,
        'eta': 10,
        'elapsed': 5,
    }

    status_dict_no_eta = {
        'status': 'downloading',
        'downloaded_bytes': 105000,
        'total_bytes': 200000,
        'speed': 5000,
        'eta': None,
        'elapsed': 5,
    }

    status_dict_total_bytes_estimate = {
        'status': 'downloading',
        'downloaded_bytes': 105000,
        'total_bytes_estimate': 200000,
        'speed': 5000,
        'eta': 10,
        'elapsed': 5,
    }

# Generated at 2022-06-12 16:30:07.637559
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    class FileDownloader2(FileDownloader):
        def __init__(self, params):
            self.params = params

    fd = FileDownloader2({})

    assert fd.parse_bytes(None) is None
    assert fd.parse_bytes('') is None

    eq_(fd.parse_bytes('b'), 1)
    eq_(fd.parse_bytes('kB'), 1 << 10)
    eq_(fd.parse_bytes('MB'), 1 << 20)
    eq_(fd.parse_bytes('GB'), 1 << 30)
    eq_(fd.parse_bytes('TB'), 1 << 40)
    eq_(fd.parse_bytes('PB'), 1 << 50)
    eq_(fd.parse_bytes('EB'), 1 << 60)
    eq_(fd.parse_bytes('ZB'), 1 << 70)

# Generated at 2022-06-12 16:30:16.093820
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class FakeYDL:
        params = {
            'retries': float('inf'),
            'nooverwrites': False,
            'continuedl': True,
            'noprogress': False,
            'ratelimit': None,
        }

    fd = FileDownloader(FakeYDL(), {'id': 'video_id'}, {})
    start_time = time.time()
    time.sleep(0.2)
    fd.slow_down(start_time, time.time(), 1000)
    assert time.time() - start_time > 0.2

# Generated at 2022-06-12 16:30:25.990097
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockDL:
        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []

        def to_screen(self, line):
            self.to_screen_calls.append(line)

    dl = MockDL({})
    fdl = FileDownloader(dl, None)

    fdl.slow_down(0, 0, 0)
    assert dl.to_screen_calls == []
    dl.to_screen_calls = []

    fdl.slow_down(0, 10, 0)
    assert dl.to_screen_calls == []
    dl.to_screen_calls = []

    fdl.slow_down(0, 10, 512)
    assert 'too fast' in dl.to_screen_calls

# Generated at 2022-06-12 16:30:37.655247
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    # Testcase:
    #   FileDownloader().temp_name(filename):
    #   - If filename == '-', returns '-'
    #   - If filename is not '-', returns filename + '.part'
    #   - If filename is not '-' and filename + '.part' exists,
    #   returns filename + '.part'
    #   - If filename is not '-' and filename + '.part' does not exist,
    #   returns filename + '.part'
    fd = FileDownloader()
    fd.params = {}

    assert fd.temp_name('-') == '-'

    with temp_name('test') as filename:
        with open(filename, 'wb'):
            pass

        assert fd.temp_name(filename) == filename + '.part'

        # Make sure temp_name can handle the case

# Generated at 2022-06-12 16:30:49.882780
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import unittest
    import sys


# Generated at 2022-06-12 16:30:57.640844
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    assert FileDownloader.parse_bytes(None) is None
    assert FileDownloader.parse_bytes('1') == 1
    assert FileDownloader.parse_bytes('1b') == 1
    assert FileDownloader.parse_bytes('1k') == 1024
    assert FileDownloader.parse_bytes('1kb') == 1024
    assert FileDownloader.parse_bytes('1.5k') == 1536
    assert FileDownloader.parse_bytes('1.5kb') == 1536
    assert FileDownloader.parse_bytes('1K') == 1024
    assert FileDownloader.parse_bytes('1KB') == 1024
    assert FileDownloader.parse_bytes('1m') == 1048576
    assert FileDownloader.parse_bytes('1mb') == 1048576
    assert FileDownloader.parse_bytes('1.5m')

# Generated at 2022-06-12 16:32:41.836089
# Unit test for method slow_down of class FileDownloader

# Generated at 2022-06-12 16:32:53.357660
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader(DummyYDL(), {})
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert fd.temp_name('abc') == 'abc.part'
    assert f

# Generated at 2022-06-12 16:33:05.502885
# Unit test for method report_file_already_downloaded of class FileDownloader
def test_FileDownloader_report_file_already_downloaded():
    from .YoutubeDL import YoutubeDL
    from .YoutubeDL import YoutubeDLHandler

    ydl = YoutubeDL({'continuedl': False, 'nooverwrites': False})
    ydl.add_handler(YoutubeDLHandler(ydl))
    d = FileDownloader(ydl, {'continuedl': True, 'nooverwrites': False}, {})
    # if we are in a unittest suite, d.to_screen will not print to stdout but to a buffer
    # we will flush this buffer with the below statement
    sys.stdout.flush()

    d.report_file_already_downloaded('test')
    assert "has already been downloaded" in sys.stdout.getvalue()
    sys.stdout.flush()

    d.report_file_already_downloaded(None)

# Generated at 2022-06-12 16:33:17.267106
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time

    # test with rate limit
    fd = FileDownloader({'ratelimit': 100 * 1024 * 1024 * 8})
    start_time = time.time()
    fd.slow_down(start_time, start_time, 0)
    fd.slow_down(start_time, start_time, 10)
    assert fd.slow_down(start_time, start_time + 0.1, 10) is None
    time.sleep(0.1)
    assert fd.slow_down(start_time, time.time(), 10000000000) <= 0.1

    # test without rate limit
    fd = FileDownloader({})
    assert fd.slow_down(start_time, start_time, 10000000000) is None