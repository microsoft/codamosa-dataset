

# Generated at 2022-06-12 16:24:07.486726
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    testcases = [
        ('Thu, 19 Feb 2015 17:51:30 GMT', 1424374290),
        ('Thu, 19 Feb 2015 17:51:30 GMT', 1424374290),
        ('Sun, 20 Feb 2011 13:51:30 GMT', 1298174290),
        ('Thu, 19 Feb 2015 17:51:30 +0000', 1424374290),
        ('Thu, 19 Feb 2015 17:51:30 -0000', 1424374290),
        ('Not a time', None),
        ('1298174290', 1298174290),
    ]

    for timestr, expected in testcases:
        assert FileDownloader.try_utime('/any/file/path/name', timestr) == expected


# Generated at 2022-06-12 16:24:17.630207
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    # 'k' in the end
    assert(FileDownloader.parse_bytes('100K') == 102400)
    assert(FileDownloader.parse_bytes('100Kb') == 102400)
    assert(FileDownloader.parse_bytes('100kb') == 102400)
    assert(FileDownloader.parse_bytes('100KB') == 102400)
    assert(FileDownloader.parse_bytes('100KiB') == 102400)
    assert(FileDownloader.parse_bytes('100K') == 102400)

    # 'm' in the end
    assert(FileDownloader.parse_bytes('100M') == 102400000)
    assert(FileDownloader.parse_bytes('100Mb') == 102400000)
    assert(FileDownloader.parse_bytes('100mb') == 102400000)

# Generated at 2022-06-12 16:24:30.756133
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['noprogress'] = False
    fd = FileDownloader(ydl, {'url': 'foo'})
    fd.report_progress(
        {'status': 'finished', 'total_bytes': 12345})
    fd.report_progress(
        {'status': 'downloading',
         'filename': '/a/b/c',
         'eta': timedelta(seconds=2),
         'elapsed': timedelta(seconds=1),
         'total_bytes': 100, 'downloaded_bytes': 50,
         'speed': 3.14159265359})

# Generated at 2022-06-12 16:24:37.262169
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class FD(FileDownloader):
        def __init__(self, params):
            super(FD, self).__init__(params)
            self.test_download_result = None

        def real_download(self, filename, info_dict):
            self.test_download_result = datetime.datetime.now().time()

    fd = FD({})
    fd.download(None, None)
    assert fd.test_download_result is not None

# Generated at 2022-06-12 16:24:44.284046
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    fd = FileDownloader({})
    assert fd.temp_name(None) is None
    assert fd.temp_name('') == ''
    assert fd.temp_name('a') == 'a.part'
    assert fd.temp_name('a.b') == 'a.b.part'
    fd = FileDownloader({'nopart': True})
    assert fd.temp_name('') == ''
    assert fd.temp_name('a') == 'a'
    assert fd.temp_name('a.b') == 'a.b'



# Generated at 2022-06-12 16:24:56.471846
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    class MockYoutubeDL:
        params = {'ratelimit': 524288}

    class MockTime:
        def time(self):
            return 0

    time = MockTime()
    ydl = MockYoutubeDL()
    fd = FileDownloader(ydl, {})
    fd.aggregate_stats = {'start_time': 0, 'bytes_downloaded': 262144}
    fd.slow_down(time, None, 1048576)
    assert time.sleep_time == 0

    time = MockTime()
    ydl = MockYoutubeDL()
    fd = FileDownloader(ydl, {})
    fd.aggregate_stats = {'start_time': 0, 'bytes_downloaded': 262144}
    fd.slow_down(time, None, 4194304)
   

# Generated at 2022-06-12 16:25:07.885796
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import time
    # For the following tests, the time.sleep function is
    # replaced by a mock function that simply records in a list
    # the sleep times requested.
    old_sleep = time.sleep
    recorder = []

    def mock_sleep(secs):
        recorder.append(secs)

    time.sleep = mock_sleep
    # Sets up parameters and a FileDownloader object
    params = {
        'sleep_interval': 0,
        'max_sleep_interval': 0,
        'max_downloads': 1,
        'verbose': True
    }
    dl = FileDownloader({}, params)
    params['sleep_interval'] = 1.5
    params['max_sleep_interval'] = 3.2

    # Test 1: Test a very fast download (9.5 MiB/sec

# Generated at 2022-06-12 16:25:19.078011
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    # Test for update of progress of downloading file
    downloader = FileDownloader(None)
    # Test case 1
    downloader._report_progress_status = Mock()
    downloader.report_progress({'status':'downloading','total_bytes':10,'downloaded_bytes':1,'speed':1,'eta':9})
    call_list = downloader._report_progress_status.call_args_list
    # Expected value of call_args_list
    expected_call_args_list = [call(u'\x1b[K\r[download]   1% of 10 at 1/s ETA 9', False)]
    #print "Test case 1"
    #print "Expected value:"
    #print expected_call_args_list
    #print "Received value:"
    #print call_list
    # Ass

# Generated at 2022-06-12 16:25:28.762207
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil
    import os.path

    test_file = __file__
    if test_file.endswith('.pyc'):
        test_file = test_file[:-1]

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'foo.tmp')


# Generated at 2022-06-12 16:25:40.815969
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # utime is not supported on Windows
    if compat_os_name == 'nt':
        return

    filepath = 'test_FileDownloader_try_utime'

# Generated at 2022-06-12 16:26:04.758821
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class MockYoutubeDL:
        to_screen = lambda *a, **k: None
        to_console_title = lambda *a, **k: None
        trouble = lambda *a, **k: None
        report_warning = lambda *a, **k: None
        report_error = lambda *a, **k: None

    class MockFD(FileDownloader):
        def real_download(self, filename, info_dict):
            return False

    ydl = MockYoutubeDL()
    ydl.params = {
        'noprogress': True,
        'nopart': True,
    }
    fd = MockFD(ydl)
    assert fd.download('test', {}) is False



# Generated at 2022-06-12 16:26:09.009357
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import datetime
    import unittest
    class test_FileDownloader_try_utime_Base(unittest.TestCase):
        def setUp(self):
            self._datetime = datetime.datetime
            self._datetime_strptime = datetime.datetime.strptime
        def tearDown(self):
            datetime.datetime.now = self._datetime.now
            datetime.datetime.strptime = self._datetime_strptime
    class test_FileDownloader_try_utime_UTC(test_FileDownloader_try_utime_Base):
        def setUp(self):
            test_FileDownloader_try_utime_Base.setUp(self)
            self._time_time = time.time
            def my_time_time():
                return 12750

# Generated at 2022-06-12 16:26:18.980007
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader(None, {'format': 'best'})
    assert fd.format_eta(0) == '0:00'
    assert fd.format_eta(60 - 0.01) == '0:00'
    assert fd.format_eta(60) == '0:01'
    assert fd.format_eta(60 * 60 - 0.01) == '0:59'
    assert fd.format_eta(60 * 60) == '1:00:00'
    assert fd.format_eta(60 * 60 * 24 - 0.01) == '23:59:59'
    assert fd.format_eta(60 * 60 * 24) == '1 day, 0:00:00'

# Generated at 2022-06-12 16:26:32.073277
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    fd = FileDownloader({})
    values = {}

# Generated at 2022-06-12 16:26:43.139506
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import tempfile
    import shutil

    base_dir = tempfile.mkdtemp()
    test_file = os.path.join(base_dir, 'test_file')

# Generated at 2022-06-12 16:26:56.966060
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = FileDownloader(None)
    ydl.to_screen = lambda msg: msg

    # (status, eta, speed, downloaded_bytes, total_bytes, total_bytes_estimate)
    def report(s):
        return ydl.report_progress({
            'status': s[0],
            'eta': s[1],
            'speed': s[2],
            'downloaded_bytes': s[3],
            'total_bytes': s[4],
            'total_bytes_estimate': s[5],
            'elapsed': None
        })

    assert report(('downloading', None, None, 0, 0, 0)) == '[download] Unknown % of Unknown ETA'

# Generated at 2022-06-12 16:27:07.300893
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    fd = FileDownloader({'ratelimit': 10})
    mock_time = [time.time()]  # Used as a mock of time.time()
    orig_time = time.time

    def side_effect():
        """Used as a side effect of the mock of time.time()"""
        mock_time[0] += 1
        return orig_time()

    time.time = orig_time

    def side_effect():
        """Used as a side effect of the mock of time.time()"""
        mock_time[0] += 1
        return orig_time()

    time.time = mock.Mock(side_effect=side_effect)
    fd.slow_down(0.0, 1.0, 2.0)
    time.time = orig_time

    # Now check that the correct sleep time was chosen


# Generated at 2022-06-12 16:27:17.775229
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    ydl = YoutubeDL({'progress_with_newline': False})
    fd = FileDownloader(ydl, {'continuedl': True})

    # Pass Through
    _ret = fd.report_progress(
        {
            'status': 'finished',
        },
    )
    assert _ret is None

    # Pass Through
    _ret = fd.report_progress(
        {
            'status': 'downloading',
        },
    )
    assert _ret is None

    # Pass Through
    _ret = fd.report_progress(
        {
            'status': 'error',
        },
    )
    assert _ret is None


# Generated at 2022-06-12 16:27:24.409799
# Unit test for method undo_temp_name of class FileDownloader
def test_FileDownloader_undo_temp_name():
    assert FileDownloader(None, None).undo_temp_name('abc.part') == 'abc'
    assert FileDownloader(None, None).undo_temp_name('abc.part.part') == 'abc.part'
    assert FileDownloader(None, None).undo_temp_name('a.bc') == 'a.bc'
    assert FileDownloader(None, None).undo_temp_name(' ') == ' '
    assert FileDownloader(None, None).undo_temp_name(None) is None

# Generated at 2022-06-12 16:27:36.114800
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import os
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='ydl-test-')
    fd = FileDownloader({'nopart': True, 'temp_dir': temp_dir}, None)
    try:
        assert fd.temp_name(os.path.join(temp_dir, 'foo')) == os.path.join(temp_dir, 'foo')
        assert fd.temp_name(os.path.join(temp_dir, 'bar')) == os.path.join(temp_dir, 'bar')
        assert fd.temp_name('foo') == 'foo'
        assert fd.temp_name('foo') == 'foo'
        assert fd.temp_name('foo.1') == 'foo.1'
    finally:
        os.rmdir

# Generated at 2022-06-12 16:28:09.605559
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    class FakeYDL:
        params = {}
        def __init__(self):
            self.to_screen = lambda *args, **kargs: None
            self.to_console_title = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.trouble = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
    ydl = FakeYDL()
    ydl.params['nopart'] = False
    fd = FileDownloader(ydl, {'filepath': 'asdf.txt'}, {'url': 'http://example.com'})
    assert fd.temp_name('asdf.txt')

# Generated at 2022-06-12 16:28:18.922311
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    from .YoutubeDL import YoutubeDL
    import tempfile
    import hashlib

    def check_md5(fname):
        with open(encodeFilename(fname), 'rb') as f:
            md5 = hashlib.md5(f.read()).hexdigest()
        return md5

    def check_noop(*args, **kargs):
        pass

    def check_noop_for_retries(*args, **kargs):
        return args[1] < 3


# Generated at 2022-06-12 16:28:24.094285
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd = FileDownloader(DummyYoutubeDl())

    # Test the case `inf`
    assert fd.format_retries(float('inf')) == 'inf'

    # Test the case standard numer
    assert fd.format_retries(10) == '10'


# Generated at 2022-06-12 16:28:37.037807
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():
    downloader = FileDownloader(None)

# Generated at 2022-06-12 16:28:43.123376
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    d = FileDownloader(None, None)
    speed = d.calc_speed(1, 5, 10000)
    assert(speed == 2000)
    speed = d.calc_speed(1, 2, 10000)
    assert(speed == None)
    speed = d.calc_speed(2, 3, 1000)
    assert(speed == 500)
    speed = d.calc_speed(2, 2, 1000)
    assert(speed == 0)

if __name__ == '__main__':
    test_FileDownloader_calc_speed()

# Generated at 2022-06-12 16:28:56.109562
# Unit test for method parse_bytes of class FileDownloader
def test_FileDownloader_parse_bytes():
    def assert_parse_bytes(value, expected):
        result = FileDownloader.parse_bytes(value)
        assert result == expected, 'parse_bytes(%r) should return %r but returned %r' % (value, expected, result)
    assert_parse_bytes('3', 3)
    assert_parse_bytes('3.14159', 3)
    assert_parse_bytes('3,14159', 3)
    assert_parse_bytes(' 3,14159 ', 3)
    assert_parse_bytes('0x10', 16)
    assert_parse_bytes('0X10', 16)
    assert_parse_bytes('010', 10)
    assert_parse_bytes('0b10', 2)
    assert_parse_bytes('0B10', 2)
    assert_parse_bytes('3K', 3 * 1024)


# Generated at 2022-06-12 16:29:06.472685
# Unit test for method download of class FileDownloader
def test_FileDownloader_download():
    class DummyInfoDict(object):
        def __init__(self):
            self.url = url
            self.num_retries = num_retries
            self.title = title
            self.ext = ext
            self.format = format

    class DummyYtdl(object):
        def __init__(self, ydl):
            self.params = ydl.params

        def to_screen(self, msg):
            if self.params.get('verbose', False):
                pass

    class DummyToScreen(object):
        def __call__(self, msg, skip_eol=False):
            pass

    # Setup
    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()
    url = 'http://example.com/test.mp4'
    num_

# Generated at 2022-06-12 16:29:19.003872
# Unit test for method report_progress of class FileDownloader
def test_FileDownloader_report_progress():
    import pytest
    downloader = FileDownloader({'noprogress': True})
    downloader.report_progress({
        'status': 'finished',
        'elapsed': 0,
        'total_bytes': 200,
        'downloaded_bytes': 200,
    })
    with pytest.raises(KeyError):
        downloader.report_progress({
            'status': 'finished',
            'elapsed': 0,
            'total_bytes': 200,
            'downloaded_bytes': 200,
        })

    # Test correct behavior for non-utf8-byte sequences
    downloader = FileDownloader({'noprogress': False})
    downloader._report_progress_status = lambda x: x

# Generated at 2022-06-12 16:29:31.864494
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    fd=FileDownloader({})
    #test normal cases
    assert fd.format_retries(0)=='0'
    assert fd.format_retries(1)=='1'
    assert fd.format_retries(2)=='2'
    assert fd.format_retries(9)=='9'
    assert fd.format_retries(10)=='10'
    #test special cases
    assert fd.format_retries(float('inf'))=='inf'
    assert fd.format_retries(-1)=='0'
    assert fd.format_retries(1.5)=='1'
    assert fd.format_retries(2.5)=='2'

# Generated at 2022-06-12 16:29:42.936553
# Unit test for method slow_down of class FileDownloader
def test_FileDownloader_slow_down():
    import random
    import time
    downloader = FileDownloader({'ratelimit': 8192})
    total_bytes = 1000000
    start = time.time()
    # A high enough constant seed will produce a constant series of
    # random numbers (increasing in size)
    random.seed(10000)
    # Simulate the download of 1 MB of data with a few (random)
    # pauses
    for byte_counter in range(total_bytes):
        if byte_counter % 20000 == 0:
            time.sleep(random.uniform(0.01,0.1))
        downloader.slow_down(start, time.time(), byte_counter)
    end = time.time()
    # The download should almost exactly take 1 second
    # (DTIME is the allowed margin of error)
    DTIME = 1.0

# Generated at 2022-06-12 16:30:22.522106
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    fd = FileDownloader(None)
    from datetime import timedelta
    from time import time
    start=time()
    current=0
    total=10

# Generated at 2022-06-12 16:30:32.721246
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    fd = FileDownloader({})
    # Test urlopen
    def urlopen(req, data=None):
        return compat_urllib_request.addinfourl(
            compat_StringIO("foo"),
            compat_httplib.HTTPMessage(compat_StringIO("""
            HTTP/1.0 200 Ok
            Last-modified: Sat, 20 Apr 2013 17:02:38 GMT

            """)),
            req.get_full_url())
    fd.urlopen = urlopen
    # Actual test
    fn = 'abcd'
    fd.try_utime(fn, None)
    fd.try_utime(fn, '0')
    fd.try_utime(fn, '1234')

# Generated at 2022-06-12 16:30:45.992803
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    # if unlink fails, we will have tc in a directory that does not exist
    # this test will fail then
    fd = FileDownloader({
        'outtmpl': '%(epoch)s.%(ext)s',
        'continuedl': False,
    })

    def mocked_to_screen(msg):
        assert 'unable to update utime' in msg

    fd.to_screen = mocked_to_screen

    tc = os.path.join(TEST_TMPDIR, 'test_FileDownloader_try_utime')

    dirname = os.path.dirname(tc)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    fd.try_utime(tc, 'Fri, 09 Aug 2013 23:54:35 GMT')

# Generated at 2022-06-12 16:30:55.377890
# Unit test for method calc_eta of class FileDownloader
def test_FileDownloader_calc_eta():
    fd = FileDownloader({})
    assert fd.format_eta(0) == '00:00'
    assert fd.format_eta(1) == '00:01'
    assert fd.format_eta(59) == '00:59'
    assert fd.format_eta(60) == '01:00'
    assert fd.format_eta(61) == '01:01'
    assert fd.format_eta(3599) == '59:59'
    assert fd.format_eta(3600) == '1:00:00'
    assert fd.format_eta(3601) == '1:00:01'
    assert fd.format_eta(3661) == '1:01:01'

# Generated at 2022-06-12 16:31:07.832097
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    import tempfile
    temp_dir = tempfile.gettempdir()
    fd = FileDownloader({'progress_hooks': [lambda d: None], 'nopart': True})
    assert fd.temp_name(os.path.join(temp_dir, 'a')) == os.path.join(temp_dir, 'a')
    assert fd.temp_name(os.path.join(temp_dir, 'a.part')) == os.path.join(temp_dir, 'a.part')
    assert fd.temp_name('a') == 'a.part'
    assert fd.temp_name('a.part') == 'a.part'
    assert fd.temp_name('http://a/b/c') == 'http___a_b_c.part'
    # Source not a

# Generated at 2022-06-12 16:31:12.736798
# Unit test for method format_retries of class FileDownloader
def test_FileDownloader_format_retries():
    dl = FileDownloader({})
    assert dl.format_retries(1) == '1'
    assert dl.format_retries(2) == '2'
    assert dl.format_retries(float('inf')) == 'inf'


# Generated at 2022-06-12 16:31:25.063426
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def try_utime(filename, last_modified_hdr):
        return FileDownloader({}).try_utime(filename, last_modified_hdr)

    # Test %a, %d and %b with English locale
    if not hasattr(locale, 'nl_langinfo'):
        def nl_langinfo(val):
            return 'abc'
        locale.nl_langinfo = nl_langinfo

    # Test HTTP header with RFC 850 date
    filetime = try_utime(None, 'Thu, 31-Dec-2037 23:59:59 GMT')
    assert filetime == 2208988799

    # Test HTTP header with RFC 1123 date
    filetime = try_utime(None, 'Thu, 31 Dec 2037 23:59:59 GMT')
    assert filetime == 2208988799

   

# Generated at 2022-06-12 16:31:34.091489
# Unit test for method best_block_size of class FileDownloader
def test_FileDownloader_best_block_size():

    def compare_with_expected(expected, *args):
        assert FileDownloader.best_block_size(*args) == expected, '%r != %r' % (
            FileDownloader.best_block_size(*args), expected)

    # best_block_size(elapsed_time, bytes)
    compare_with_expected(1, 0.001, 0)
    compare_with_expected(1, 0.001, 1)
    compare_with_expected(2, 0.001, 1.1)
    compare_with_expected(1, 0.001, 1.4)
    compare_with_expected(1, 0.001, 1.5)
    compare_with_expected(2, 0.001, 1.6)
    compare_with_expected(2, 0.001, 2)
    compare_with_expected

# Generated at 2022-06-12 16:31:46.444958
# Unit test for method calc_speed of class FileDownloader
def test_FileDownloader_calc_speed():
    from time import time

    # Test on normal case
    time_start = time()
    time_end = time_start + 2
    assert FileDownloader.calc_speed(time_start, time_end, 1024) == 512

    # Test when time_end is before time_start
    time_end = time_start - 3
    assert FileDownloader.calc_speed(time_start, time_end, 1024) is None

    # Test when time_end and time_start are equal
    time_end = time_start
    assert FileDownloader.calc_speed(time_start, time_end, 1024) is None

    # Test when bytes is 0
    time_start = time()
    time_end = time_start + 2
    assert FileDownloader.calc_speed(time_start, time_end, 0)

# Generated at 2022-06-12 16:31:47.096114
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    pass



# Generated at 2022-06-12 16:33:00.766886
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    def check_utime(filename, last_modified_hdr, expected_date):
        fd = FileDownloader({'nopart': True})
        fd.to_screen = lambda *args, **kargs: None
        fd.report_warning = lambda *args, **kargs: None
        fd.real_download = lambda *args, **kargs: None
        fd.report_error = lambda *args, **kargs: None
        fd.report_destination = lambda *args, **kargs: None
        fd.report_progress = lambda *args, **kargs: None
        fd.report_retry = lambda *args, **kargs: None
        fd.report_resuming_byte = lambda *args, **kargs: None
        fd.report_unable_to_resume

# Generated at 2022-06-12 16:33:08.561899
# Unit test for method temp_name of class FileDownloader
def test_FileDownloader_temp_name():
    assert FileDownloader.temp_name('/some/dir/file.ext') == '/some/dir/file.part'
    assert FileDownloader.temp_name('file.ext') == 'file.part'
    assert FileDownloader.temp_name('file') == 'file.part'
    assert FileDownloader.temp_name('/some/dir/file') == '/some/dir/file.part'
    assert FileDownloader.temp_name('/some/dir/file.') == '/some/dir/file..part'



# Generated at 2022-06-12 16:33:20.051808
# Unit test for method try_utime of class FileDownloader
def test_FileDownloader_try_utime():
    import time
    import os
    import errno
    import tempfile
    from time import time as time_func
    from datetime import timedelta
    from datetime import datetime

    def _test(file_time, system_time, reference_time, expected_ret_time, expected_file_time):
        assert file_time is not None
        assert system_time is not None
        assert reference_time is not None

        if isinstance(file_time, datetime):
            file_time = time.mktime(file_time.timetuple())
        if isinstance(system_time, datetime):
            system_time = time.mktime(system_time.timetuple())
        if isinstance(reference_time, datetime):
            reference_time = time.mktime(reference_time.timetuple())
