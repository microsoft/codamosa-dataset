

# Generated at 2022-06-26 09:20:13.714878
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    var_0 = logging_redirect_tqdm()
    assert isinstance(var_0, logging_redirect_tqdm)



# Generated at 2022-06-26 09:20:17.066241
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('console logging redirected to `tqdm.write()`')
    logging.info('logging restored')

# Generated at 2022-06-26 09:20:22.615373
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test for function logging_redirect_tqdm
    """
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm.trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    return




# Generated at 2022-06-26 09:20:26.272114
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    record = Record()
    tqdm_class = std_tqdm()
    tqdmlogginghandler = _TqdmLoggingHandler(tqdm_class)
    tqdmlogginghandler.emit(record)

# Generated at 2022-06-26 09:20:33.712989
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import contextlib
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:20:35.784337
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # pylint: disable=undefined-variable
    var_0 = tqdm_logging_redirect()

# Generated at 2022-06-26 09:20:42.682466
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:20:51.297945
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:20:57.192426
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        

# Generated at 2022-06-26 09:21:04.647051
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    #   for i in trange(9):
    #       if i == 4:
    #           logging.info("console logging redirected to `tqdm.write()`")
    #       # logging restored
    # logging.basicConfig(level=logging.INFO)
    # for i in trange(

# Generated at 2022-06-26 09:21:18.051826
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test for function tqdm_logging_redirect with positional arguments
    var_1 = tqdm_logging_redirect()
    # Test for function tqdm_logging_redirect with keyword arguments
    var_2 = tqdm_logging_redirect(loggers=None, tqdm_class=std_tqdm)
    # Test for function tqdm_logging_redirect with positional or keyword arguments
    var_3 = tqdm_logging_redirect(loggers=None, tqdm_class=std_tqdm)

# Generated at 2022-06-26 09:21:21.999414
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_class = _TqdmLoggingHandler()
    with logging_redirect_tqdm():
        stream = sys.stdout
        msg = 'Test message'
        tqdm_class.write(msg, file=stream)
        tqdm_class.flush()


# Generated at 2022-06-26 09:21:33.213864
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Initialize test environment
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    loggers = [LOG]
    tqdm_class = std_tqdm

    # Test statement
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        # Test branch #0
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    return None


# Generated at 2022-06-26 09:21:34.730794
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    lh = _TqdmLoggingHandler()
    lh.emit()



# Generated at 2022-06-26 09:21:41.189207
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:21:45.413223
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test case 0

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    """
    # Test case 0
    test_case_0()

    # Test case 1
    # Expected side effect: IndentationError



# Generated at 2022-06-26 09:21:46.621879
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test 1
    with tqdm_logging_redirect():
        pass

# Generated at 2022-06-26 09:21:52.097656
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.root]
    tqdm_class = std_tqdm 
    pbar = tqdm_class() 
    var_0 = tqdm_logging_redirect(loggers=loggers, tqdm_class=tqdm_class)

# Generated at 2022-06-26 09:21:54.453786
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with logging_redirect_tqdm() as var_0:
        assert isinstance(var_0, Iterator)



# Generated at 2022-06-26 09:22:01.757923
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    # -- with default parameters
    # the default argument is not needed
    with logging_redirect_tqdm():
        log.info("hello world!")

    # -- with custom parameter
    with logging_redirect_tqdm(loggers=[log]):
        log.info("hello world!")

    # -- with custom parameter
    with logging_redirect_tqdm(loggers=[log], tqdm_class=std_tqdm):
        log.info("hello world!")

    # -- raise TypeError
    # with logging_redirect_tqdm(loggers=[1, 2]):
    #     log.info("hello world!")
    # with logging_redirect_

# Generated at 2022-06-26 09:22:18.094341
# Unit test for function tqdm_logging_redirect

# Generated at 2022-06-26 09:22:20.960857
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10):
        pass
    with tqdm_logging_redirect(total=10,
                               loggers=[logging.getLogger(__name__)],
                               leave=False):
        pass

# Generated at 2022-06-26 09:22:26.406879
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        for i in range(1000):
            pbar.update(1)
            if i == 500:
                assert pbar.total == 1000
                pbar.write("Test: tqdm_logging_redirect")
    assert pbar.n == 1000
    assert pbar.total == 1000
    assert isinstance(pbar.n, int)

# Generated at 2022-06-26 09:22:34.266897
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test 1
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record_1 = logging.LogRecord('Test', logging.INFO, '/foo/bar.py', 42, 'foobar', (), None, 'foobar')
    tqdm_logging_handler_1.emit(record_1)


# Generated at 2022-06-26 09:22:38.909187
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:49.072965
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test that writing log statement logs to stdout when not in logging
    # redirect context
    from tqdm.auto import trange

    logging.basicConfig(level=logging.INFO)
    with open('test', 'w') as stream:
        for i in trange(4):
            if i == 2:
                logging.info("outside of logging_redirect_tqdm")
            if i == 3:
                stream.seek(0)
                stream.truncate()
                assert stream.read() == "outside of logging_redirect_tqdm\n"

    # Test that logging statements are redirected to tqdm.write()
    # when in logging redirect context
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-26 09:22:59.040954
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from .test_case_utils import (
            tqdm_class_mock, sys_stdout_mock,
            sys_stderr_mock, stdout_write_mock
        )
    except (ImportError, ValueError):
        return
    tqdm_logging_handler = _TqdmLoggingHandler(
        tqdm_class=tqdm_class_mock)
    tqdm_logging_handler.stream = sys_stdout_mock
    # Mock
    record = 'record'
    # Call
    tqdm_logging_handler.emit(record)
    # Assert
    tqdm_class_mock.write.assert_called_once_with(
        record, file=sys_stdout_mock)
    stdout_

# Generated at 2022-06-26 09:23:04.224787
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(file=sys.stderr, total=5) as pbar:
        pass


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:23:09.155582
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # type: ignore

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("test")
    assert "test" in sys.stderr.getvalue()



# Generated at 2022-06-26 09:23:22.115026
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # First create a raw logger and set the `logging` level to `INFO`
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    # Check that the logger is not already configured to use a `_TqdmLoggingHandler`
    root_logger_handlers = root_logger.handlers
    assert all([not isinstance(h, _TqdmLoggingHandler) for h in root_logger_handlers])
    # Check that we can enter and exit the context manager without errors
    with tqdm_logging_redirect():
        pass
    # Check that the logger is _still_ not configured to use a `_TqdmLoggingHandler`
    root_logger_handlers = root_logger.handlers

# Generated at 2022-06-26 09:23:37.637429
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit of class _TqdmLoggingHandler.
    """
    _TqdmLoggingHandler().emit(logging.LogRecord(
        'a', 1, 'path', 2, 'message', None, None))

# Generated at 2022-06-26 09:23:50.847587
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    logging.root.handlers = []

    for logger in [logging.root, logging.getLogger()]:
        assert logger.handlers == []
        tqdm.write("Message from tqdm")
        logging.info("Message from logging")
        assert logger.handlers == []

    def error_function():
        with tqdm_logging_redirect():
            raise Exception("An exception!")
    with pytest.raises(Exception):
        error_function()

    for logger in [logging.root, logging.getLogger()]:
        tqdm.write("Message from tqdm")
        logging.info("Message from logging")

    with tqdm_logging_redirect(total=1):
        pass

    logging.shutdown()

# Generated at 2022-06-26 09:23:58.440268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    assert LOG.handlers == []

    with logging_redirect_tqdm():
        for _ in trange(4):
            LOG.info('bar')

    assert LOG.handlers == []


# Generated at 2022-06-26 09:24:09.325301
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test logging redirection using `logging_redirect_tqdm()`.
    """
    LOG = logging.getLogger(__name__)

    try:
        from tqdm import trange
    except ImportError:
        from sys import exit
        exit('tqdm not installed.')

    with logging_redirect_tqdm():
        for i in trange(4):
            if i == 2:
                LOG.info('logging redirected to `tqdm.write()`')



# Generated at 2022-06-26 09:24:15.434079
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:24:22.048319
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange  # noqa
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:24:34.977137
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import StreamHandler, Formatter
    from .tqdm import tqdm


# Generated at 2022-06-26 09:24:39.585835
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import tqdm

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            desc='test_logging_redirect_tqdm',
            loggers=[logging.getLogger('test_logging_redirect_tqdm')]
    ) as pbar:
        logging.getLogger('test_logging_redirect_tqdm').info("test_logging_redirect_tqdm")
        pbar.update(1)



# Generated at 2022-06-26 09:24:45.834820
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test case: method emit of class _TqdmLoggingHandler without exception
    def test_case_1():
        tqdm_logging_handler = _TqdmLoggingHandler()
        msg = 'Test message'
        record = logging.LogRecord(msg, logging.WARNING, 'name', 42, msg, None, None)
        tqdm_logging_handler.emit(record)

    # Test case: method emit of class _TqdmLoggingHandler with exception
    def test_case_2():
        tqdm_logging_handler = _TqdmLoggingHandler()
        tqdm_logging_handler.handleError = lambda record: None
        msg = 'Test message'
        record = Exception(msg)
        tqdm_logging_handler.emit(record)



# Generated at 2022-06-26 09:24:54.370835
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log_1a = logging.getLogger('test_logging_redirect_tqdm_1a')
    log_1a.setLevel(logging.INFO)
    log_1b = logging.getLogger('test_logging_redirect_tqdm_1b')
    log_1b.setLevel(logging.DEBUG)
    log_2 = logging.getLogger('test_logging_redirect_tqdm_2')
    log_2.setLevel(logging.WARNING)

    log_1a.addHandler(logging.StreamHandler(sys.stdout))
    log_1b.addHandler(logging.StreamHandler(sys.stdout))
    log_2.addHandler(logging.FileHandler('test_logging_redirect_tqdm.log'))

   

# Generated at 2022-06-26 09:25:16.099396
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import root, Logger
    from random import random
    from time import sleep
    from tqdm import trange

    n = 10
    root.propagate = False

    with logging_redirect_tqdm():
        for i in trange(n):
            if random() < 0.3:
                root.critical("critical {0}".format(i))
            elif random() < 0.5:
                root.error("error {0}".format(i))
            elif random() < 0.7:
                root.warning("warning {0}".format(i))
            elif random() < 0.75:
                root.info("info {0}".format(i))
            sleep(0.1)


# Generated at 2022-06-26 09:25:26.670049
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from random import randint as ri
    from itertools import count
    from tqdm import tnrange

    str_n = lambda n, l=4: ''.join(chr(ri(ord('A'), ord('Z'))) for _ in range(l))

    def sleep(t):
        from time import sleep
        sleep(t / 1000)

    test_inputs = [
        ('l', 0.1, 'foo'),
        ('m', 0.1, 'bar'),
        ('h', 0.2, 'spam'),
    ]

    def log_loop(log_func, log_level):
        for size, t, msg in test_inputs:
            log_func(msg)
            sleep(t)


# Generated at 2022-06-26 09:25:32.079939
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record_1 = logging.getLogger(__name__).makeRecord(__name__, logging.DEBUG,
                                                      __file__, __name__,
                                                      "test message 1",
                                                      None, None, None)
    tqdm_logging_handler_1.emit(record_1)
    record_2 = logging.getLogger(__name__).makeRecord(__name__, logging.INFO,
                                                      __file__, __name__,
                                                      "test message 2",
                                                      None, None, None)
    tqdm_logging_handler_1.emit(record_2)

# Generated at 2022-06-26 09:25:39.221125
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys
    import time

    LOG = logging.getLogger(__name__)
    LOG.propagate = True

    if __name__ == '__main__':
        logging.basicConfig(stream=sys.stdout, level=logging.INFO)
        tqdm_class = std_tqdm
        tqdm_class.monitor_interval = 0
        with logging_redirect_tqdm():
            for i in tqdm_class(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(0.25)
        print('logging restored')
    os.remove('tqdm.log')



# Generated at 2022-06-26 09:25:46.893541
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def test():
        tqdm_logging_handler = _TqdmLoggingHandler()
        original_handlers = LOG.handlers
        try:
            LOG.handlers = [tqdm_logging_handler]
            trange(9)
            LOG.info("console logging redirected to `tqdm.write()`")
            trange(9)
        finally:
            LOG.handlers = original_handlers

    test()
    with logging_redirect_tqdm():
        test()


# Generated at 2022-06-26 09:25:53.147851
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('test_logging_redirect_tqdm')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())
    with logging_redirect_tqdm():
        logger.info('test')


# Generated at 2022-06-26 09:26:05.244870
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(desc='foo', unit='B', unit_scale=True,
                               unit_divisor=1024, total=100):
        assert int(tqdm_logging_redirect._pbar()) == 0
        logging.info("logging_redirect_tqdm")  # pylint: disable=logging-format-interpolation
    with tqdm_logging_redirect(loggers=[logging.getLogger('')], desc='foo', unit='B',
                               unit_scale=True, unit_divisor=1024, total=100):
        assert int(tqdm_logging_redirect._pbar()) == 0
        logging.info("logging_redirect_tqdm")  # pylint: disable=logging-

# Generated at 2022-06-26 09:26:11.590181
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: (...) -> None
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.contrib import asyncio as tqdm_asyncio
    from tqdm.contrib.concurrent import process_map
    import logging
    import asyncio

    try:
        import uvloop
    except ImportError:
        uvloop = None  # type: ignore

    class AioTask(object):
        def __init__(self, coro):
            # type: (...) -> None
            self.coro = coro
            self._loop = tqdm_asyncio.get_event_loop()

        def __call__(self):
            # type: (...) -> None
            return self._loop.run_until_complete(self.coro)



# Generated at 2022-06-26 09:26:17.274849
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('foo')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())

    with logging_redirect_tqdm():
        LOG = logging.getLogger('foo')
        LOG.info('Hello, World!')
    with tqdm_logging_redirect():
        LOG = logging.getLogger('foo')
        LOG.info('Hello, World!')


if __name__ == '__main__':
    from tqdm.contrib._test_decorator import _test_extras
    _test_extras()

# Generated at 2022-06-26 09:26:25.279057
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    root_logger = logging.getLogger()
    # Remove any existing logging handlers
    for handler in root_logger.handlers:
        root_logger.removeHandler(handler)

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(logging.getLogger()) as pbar:
        pbar.set_description("Logging redirected to `tqdm.write()`")
        for i in pbar:
            pbar.write("hi!")

# Generated at 2022-06-26 09:26:48.788071
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.handlers = [logging.StreamHandler()]
    with tqdm_logging_redirect():
        logger.info("test_stdout_redirect")


# Generated at 2022-06-26 09:26:57.874259
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm():
        logger = logging.getLogger('root')
        assert not logger.handlers
        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger('root')
        assert logger.handlers
        assert isinstance(logger.handlers[0], logging.StreamHandler)
        assert logger.handlers[0].stream in {sys.stdout, sys.stderr}
        assert not isinstance(logger.handlers[0], _TqdmLoggingHandler)

        for logging_method in [logger.debug, logger.info, logger.warning,
                               logger.error, logger.critical]:
            logging_method('test')

        logger = logging.getLogger(__name__)
        assert logger.handlers
        assert logger

# Generated at 2022-06-26 09:27:00.806875
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test if TqdmLoggingHandler.emit method works
    """
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    LOG_1 = logging.getLogger("Test")
    LOG_1.info("tqdm_logging_handler_1.emit works")


# Generated at 2022-06-26 09:27:13.570522
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import pytest
    from pytest import raises
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from tqdm._utils import _range
    
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    import sys
    tqdm_logging_handler_0.stream = sys.stderr
    
    # Calling method flush of class _TqdmLoggingHandler
    with raises(TypeError):
        tqdm_logging_handler_0.flush()
    
    # Calling method format of class _TqdmLoggingHandler
    log_format = tqdm_logging_handler_0.format(logging.INFO)
    assert log_format == 'INFO:'
    
    # Calling method emit of class _TqdmLoggingHandler
   

# Generated at 2022-06-26 09:27:23.899618
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger('logging_redirect_tqdm')
    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(3):
                LOG.info('Redirected to `tqdm.write()`')
    except:
        return False
    return True



# Generated at 2022-06-26 09:27:34.415469
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    logger = logging.getLogger()
    original_handlers = logger.handlers

    # Test no loggers provided
    for nested_logger in [logger, logging.getLogger()]:
        with tqdm_logging_redirect(total=9) as pbar:
            for i in trange(9):
                if i == 4:
                    nested_logger.info('console logging redirected to `tqdm.write()`')
    assert logger.handlers == original_handlers

    # Test new loggers provided

# Generated at 2022-06-26 09:27:45.449978
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    print("\nLine breaks around `with` statement are expected\n")

    for i in trange(10):
        if i == 4:
            with logging_redirect_tqdm():
                LOG.info("console logging redirected to `tqdm.write()`")
        print("Line {} from console".format(i))
    print("\nLine breaks around `with` statement are expected\n")

if __name__ == '__main__':
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:27:52.134609
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:28:03.972815
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.root]
    with tqdm_logging_redirect():
        for logger in loggers:
            tqdm_handler = _TqdmLoggingHandler()
            orig_handler = _get_first_found_console_logging_handler(logger.handlers)
            assert orig_handler is not None
            tqdm_handler.setFormatter(orig_handler.formatter)
            tqdm_handler.stream = orig_handler.stream
            logger.handlers = [
                handler for handler in logger.handlers
                if not _is_console_logging_handler(handler)] + [tqdm_handler]



# Generated at 2022-06-26 09:28:14.916209
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(unit='B', unit_scale=True, miniters=1,
                                   desc='Downloading'):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:29:03.923301
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record = "example"
    tqdm_logging_handler_1.emit(record)



# Generated at 2022-06-26 09:29:13.832355
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import trange
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in trange(10):
            logger.info('test_logging_redirect_tqdm')
        logger.info('test_logging_redirect_tqdm')


# Generated at 2022-06-26 09:29:26.411348
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    def _test_logging_redirect_tqdm():
        # with logging_redirect_tqdm():
        #     for i in trange(9):
        #         if i == 4:
        #             LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        with tqdm_logging_redirect(
            total=1,
            loggers=[LOG],  # type: Optional[List[logging.Logger]]
            unit='log',
            unit_scale=True,
            desc='logging redirection',
            dynamic_ncols=True,
        ) as pbar:
            pbar.update(1)

# Generated at 2022-06-26 09:29:35.175085
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logtest = logging.getLogger("logtest")
    logtest.setLevel(logging.DEBUG)

    try:
        from StringIO import StringIO  # Py2
    except ImportError:
        from io import StringIO  # Py3

    with tqdm_logging_redirect(loggers=[logtest]):
        logtest.debug("This is a debug message")
        logtest.info("This is an info message")



# Generated at 2022-06-26 09:29:44.624565
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger()
    original_handlers = logger.handlers
    log_msg = "This should be displayed on console without the timestamps"
    try:
        with logging_redirect_tqdm(loggers=[logger]):
            logger.warning(log_msg)
    except:  # noqa pylint: disable=bare-except
        pass
    finally:
        logger.handlers = original_handlers



# Generated at 2022-06-26 09:29:57.399064
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    trange(9)
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored
    trange(9)

    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm(loggers=[LOG]):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    trange(9)

# Unit test

# Generated at 2022-06-26 09:30:02.604682
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    with tqdm_logging_redirect(total=3) as log_progress:
        logging.info('info')
        logging.debug('debug')
        logging.error('error')
        logging.info('logging info')
        logging.debug('logging debug')
        logging.error('logging error')


# Generated at 2022-06-26 09:30:09.837286
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # set up logging
    loggers = [logging.getLogger()]  # type: List[logging.Logger]
    logging.basicConfig(level=logging.INFO,
                        format="[%(levelname)s] - %(message)s")
    original_handlers_list = [logger.handlers for logger in loggers]
    text = "the quick brown fox jumped over the lazy dog"

    # redirect logging to tqdm.write
    with logging_redirect_tqdm(loggers=loggers):
        # logging.info will go to tqdm.write
        logging.info(text)
        # logging.warning will go to tqdm.write
        logging.warning("warning")
        # logging.error will go to tqdm.write
        logging.error("error")
        # logging