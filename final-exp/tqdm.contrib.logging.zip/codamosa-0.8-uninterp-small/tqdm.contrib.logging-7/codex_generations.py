

# Generated at 2022-06-26 09:20:08.548634
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9, ncols=120):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:20:15.747339
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: (...) -> Iterator[None]
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:20:20.217989
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=3) as pbar:
        assert pbar.format_dict['total'] == 3
        for i in range(4):
            pbar.update(1)
        assert pbar.n == 3
        raise RuntimeError

# Generated at 2022-06-26 09:20:24.138988
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    log_record = logging.makeLogRecord({'name': 'foo', 'level': logging.DEBUG})
    tqdm_logging_handler_1.emit(log_record)

# Generated at 2022-06-26 09:20:28.431946
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect() as pbar:
        for _ in range(9):
            pbar.update()
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:20:40.284530
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib.logging import logging_redirect_tqdm

    loggers = [logging.getLogger('test')]
    try:
        # logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    loggers[0].info("console logging redirected to `tqdm.write()`")
        # logging restored

        with logging_redirect_tqdm(loggers):
            for i in range(9):
                if i == 4:
                    loggers[0].info("console logging redirected to `tqdm.write()`")
        # logging restored
    except:  # noqa
        pass



# Generated at 2022-06-26 09:20:43.233534
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Unit test for tqdm_logging_redirect ()
    with tqdm_logging_redirect(loggers=None):
        pass


# Generated at 2022-06-26 09:20:52.579485
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pbar.update(1)

    with tqdm_logging_redirect(range(10)) as pbar:
        for _ in pbar:
            pass

    with tqdm_logging_redirect(loggers=[logging.getLogger(__name__)]) as pbar:
        logging.getLogger(__name__).info("something")
        with tqdm_logging_redirect(loggers=[logging.getLogger(__name__)]) as pbar2:
            logging.getLogger(__name__).info("something else")



# Generated at 2022-06-26 09:21:00.817480
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from io import StringIO
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with StringIO() as buff, logging_redirect_tqdm(loggers=[LOG]):
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
    assert buff.getvalue().replace(
        '\r', '').replace('\n', '') == 'console logging redirected to `tqdm.write()`'

    buff.truncate(0)
    buff.seek(0)

# Generated at 2022-06-26 09:21:10.136411
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import mock
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    with mock.patch('sys.stderr', mock.MagicMock()) as patched_stderr:
        logging_record_0 = mock.MagicMock()
        tqdm_logging_handler_0.stream = mock.MagicMock()
        tqdm_logging_handler_0.handleError = mock.MagicMock()
        tqdm_logging_handler_0.emit(logging_record_0)
        tqdm_logging_handler_0.flush()


# Generated at 2022-06-26 09:21:22.224615
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # setup
    logger = logging.getLogger('logger')
    logger.propagate = False
    logger.addHandler(_TqdmLoggingHandler())
    logger.setLevel(logging.INFO)

    # test
    logger.info('info log message')
    logger.debug('debug log message')
    logger.warning('warning log message')
    logger.error('error log message')
    logger.critical('critical log message')
    logger.info('info log message')


# Generated at 2022-06-26 09:21:26.917045
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("logging_redirect_tqdm is working")

# Generated at 2022-06-26 09:21:35.892138
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.info("This is a test")
    logger.debug("This is a test")
    logger.error("This is an error")
    logger.info("This is a test")
    logger.warning("This is a warning")


# Generated at 2022-06-26 09:21:40.695265
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    logger.info("testing")
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("testing")
    logger.info("testing")



# Generated at 2022-06-26 09:21:45.761639
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # logging.getLogger(__name__).info("Hello.")
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.emit(logging.LogRecord('info', 28, 'test_emit', 29, 'info str', (), None, None))

# Generated at 2022-06-26 09:21:52.103130
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import TestCase

    class Test__TqdmLoggingHandler_emit(TestCase):
        @staticmethod
        def _emit(text, tqdm_class=std_tqdm):
            pbar = tqdm_class.tqdm()
            pbar.write("")
            try:
                handler = _TqdmLoggingHandler(tqdm_class=tqdm_class)
                handler.emit(logging.LogRecord("", logging.ERROR, "", "", text, "", None))
                assert pbar.last_print_n + 1 == len(text.splitlines())
            finally:
                pbar.close()

        def test_case_0(self):
            self._emit("Test")

        def test_case_1(self):
            self._em

# Generated at 2022-06-26 09:22:00.660641
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)
    LOG.setLevel(10)
    log_handler = logging.StreamHandler()
    log_format = logging.Formatter('%(name)s: %(message)s')
    log_handler.setFormatter(log_format)
    LOG.addHandler(log_handler)
    console_log = logging.getLogger('console_log')
    console_log.setLevel(10)
    console_log.addHandler(log_handler)
    with logging_redirect_tqdm(tqdm_class=tqdm) as pbar:
        for _ in pbar(range(2)):
            LOG.info('logging info')
            console_log.info('console_logging_info')

# Generated at 2022-06-26 09:22:05.443425
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def worker(bar):
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    with tqdm_logging_redirect(total=10) as bar:
        worker(bar)

# Generated at 2022-06-26 09:22:15.791509
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    test_logger = logging.getLogger('logging_redirect_tqdm')
    contents_before = "before"
    contents_during = "during"
    contents_after = "after"
    with logging_redirect_tqdm([test_logger]):
        test_logger.info(contents_during)
        for i in trange(5):
            pass
    test_logger.info(contents_before)
    test_logger.info(contents_after)

    log_output = logging.root.handlers[0].stream.getvalue().strip().split('\n')
    assert contents_before in log_output[0]
    assert contents_after in log_output[1]

# Generated at 2022-06-26 09:22:27.029602
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import tqdm
        from tqdm.contrib.logging import logging_redirect_tqdm
    except ImportError:
        return

    def raise_error():
        raise RuntimeError("error message")

    try:
        with logging_redirect_tqdm():
            raise_error()
    except RuntimeError:
        pass

    try:
        with logging_redirect_tqdm():
            try:
                raise_error()
            except:  # noqa
                logging.exception("exception message")
    except RuntimeError:
        pass

    with logging_redirect_tqdm():
        for _ in tqdm(range(3)):
            logging.info("info message")

# Generated at 2022-06-26 09:22:42.322469
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    with tqdm_logging_redirect(total=len(LOG.handlers)) as pbar:
        for i in range(len(LOG.handlers)):
            pbar.set_description("Testing tqdm_logging_redirect")
            LOG.info("tqdm_logging_redirect is working!")

# Generated at 2022-06-26 09:22:49.555369
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from ..tqdm import tqdm

    with tqdm_logging_redirect(
            total=100, iterable=range(100), smoothing=0.0,
            logger=logging.getLogger("test")) as pbar:
        for _ in pbar:
            logging.info("info msg")
            logging.warning("warning msg")
            logging.error("error msg")


if __name__ == "__main__":
    import platform
    print("Python v{}".format(platform.python_version()))
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:56.604946
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    old_stdout = sys.stdout
    sys.stdout = temp = sys.stdout.__class__()  # type: ignore
    try:
        tqdm_logging_handler_0 = _TqdmLoggingHandler()
        msg = "msg"
        tqdm_logging_handler_0.emit(msg)
        assert(temp.getvalue().strip() == "msg")
    finally:
        sys.stdout = old_stdout


# Generated at 2022-06-26 09:23:04.646200
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(5):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:23:11.238880
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """test the emit method of _TqdmLoggingHandler"""
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # Test tqdm.write method for record.msg
    record_0 = logging.LogRecord('name_0', 'DEBUG', 'pathname_0', 1,
                                 'msg_0', None, None, None)
    tqdm_logging_handler_0.emit(record_0)


# Generated at 2022-06-26 09:23:21.464143
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Use test case from `logging_redirect_tqdm()` docstring.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:23:29.490212
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:23:41.212574
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    import os
    import tempfile
    from contextlib import contextmanager
    loggers = [logging.getLogger("test")]
    @contextmanager
    def _check_output(kwargs, console_logging_content):
        # type: (Dict[str, str], List[str]) -> Iterator[None]
        with tempfile.TemporaryFile("r+") as f:
            with logging_redirect_tqdm(f, loggers=loggers, **kwargs):
                for line in console_logging_content:
                    logging.info(line)
            f.seek(0)
            lines = f.read().strip().split("\n")
            assert lines == console_logging_content

# Generated at 2022-06-26 09:23:50.361002
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    with tqdm_logging_redirect(total=2):
        log_me("Test")
        log_me("Test")

    with tqdm_logging_redirect(total=0):
        log_me("Test")

    with tqdm_logging_redirect(total=1):
        log_me("Test")

    with tqdm_logging_redirect(total=1):
        log_me("Test")

    with tqdm_logging_redirect(total=1):
        log_me("Test")


# Generated at 2022-06-26 09:23:57.669699
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        for i in range(10):
            logging.info('redirected to tqdm.write(...)')
            time.sleep(0.1)


# Generated at 2022-06-26 09:24:11.820737
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import closing
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with closing(open('/tmp/test_out.txt', 'w')) as f:
        with logging_redirect_tqdm(loggers=[LOG], tqdm_class=std_tqdm):
            LOG.handlers[0].stream = f
            for _ in trange(5):
                LOG.info('test')
                LOG.warning('test')
                LOG.error('test')


# Generated at 2022-06-26 09:24:21.714016
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    test_logger = logging.getLogger("TEST_LOGGER")
    with tqdm_logging_redirect(total=1, loggers=[test_logger],
                               tqdm_class=std_tqdm) as pbar:
        test_logger.info("A")
        test_logger.info("B")
        pbar.update()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:24:28.548072
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    ch = _TqdmLoggingHandler()
    msg = 'Fake message'
    rec = logging.LogRecord('Fake name', logging.INFO, 'Fake pathname',
                            10, msg, None, None)
    ch.emit(rec)


# Generated at 2022-06-26 09:24:36.804694
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import _tqdm
    from tqdm.contrib import logger
    # init logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    # make some console logging
    log.info("%d", 0)
    # redirect console logging to tqdm
    with logger.tqdm_logging_redirect():
        # make some console logging
        log.info("%d", 1)
        # make some tqdm
        with _tqdm(total=2) as pbar:
            # make some console logging
            log.info("%d", 2)
            pbar.update()
            # make some console logging
            log.info("%d", 3)
            pbar.update()
            # make some console

# Generated at 2022-06-26 09:24:45.162872
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    msg = "Test print logging"
    record = logging.LogRecord(
        name='test',
        level=logging.INFO,
        pathname='test_path',
        lineno=1,
        msg=msg,
        args=None,
        exc_info=False)

    try:
        tqdm_logging_handler_0.emit(record)
    except:
        pass

# Generated at 2022-06-26 09:24:54.142911
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.auto import tqdm as auto, trange as auto_trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    with tqdm_logging_redirect():
        with auto_trange(2) as pbar:
            logging.info('this message is redirected to the tqdm logger')
            pbar.set_description('another logging message')


if __name__ == '__main__':
    # Test
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s: %(levelname)s [%(name)s]: %(message)s"
    )
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:05.056508
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    #TODO: Testing
    #TODO: unit test fails due to format mismatch
    #TODO: fix tests
    #FIXME: need more coverage
    logging.getLogger().setLevel(logging.DEBUG)
    logging.warn('This is a test for logging_redirect_tqdm')
    with logging_redirect_tqdm():
        logging.warn('This should go to STDOUT')
        logging.warn('This should go to STDOUT')
        logging.warn('This should go to STDOUT')
    logging.warn('This is a test for logging_redirect_tqdm')
    with logging_redirect_tqdm(loggers=[logging.getLogger()]):
        logging.warn('This should go to STDOUT')
        logging.warn('This should go to STDOUT')
        logging

# Generated at 2022-06-26 09:25:16.193750
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    logger = logging.getLogger(__name__ + '.test_tqdm_logging_redirect')
    logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(logger=logger) as pbar:
        with logging_redirect_tqdm([logger], tqdm_class=std_tqdm):
            for i in range(10):
                logger.debug('debug {}'.format(i))
                logger.info('info {}'.format(i))
                logger.warning('warning {}'.format(i))
                logger.error('error {}'.format(i))
                logger.critical('critical {}'.format(i))
                time.sleep(0.1)

    assert isinstance(pbar, std_tqdm)
    assert p

# Generated at 2022-06-26 09:25:20.886039
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with logging_redirect_tqdm(loggers=[logging.root], tqdm_class=std_tqdm):
        logging.info("test_logging_redirect_tqdm")

# Generated at 2022-06-26 09:25:24.366796
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange

    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to tqdm")



# Generated at 2022-06-26 09:25:38.521787
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-26 09:25:47.638690
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    def example_logging_func():
        LOG = logging.getLogger(__name__)
        LOG.info("example")

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(example_logging_func,
                               tqdm_class=trange) as pbar:
        pbar.update()


if __name__ == '__main__':
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-26 09:25:51.955897
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=[logging.root],
                               tqdm_class=tqdm_logging_handler_0) as pbar:
        logging.info('test')

# Generated at 2022-06-26 09:26:00.921127
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:26:08.917179
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:26:12.534211
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm_notebook
    from tqdm.contrib import logging
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_notebook(total=10) as pbar:
        with logging.tqdm_logging_redirect(pbar=pbar) as pbar:
            logging.info('info log message')
            logging.warning('warning log message')
            logging.error('error log message')
            logging.critical('critical log message')



# Generated at 2022-06-26 09:26:25.523616
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=2):
        assert logging.getLogger('tqdm').handlers == []
        logging.info('foo')
    assert logging.getLogger('tqdm').handlers == [logging.getLogger().handlers[0]]

    with tqdm_logging_redirect(total=2, smoothing=0.7, loggers=[logging.getLogger('tqdm')]):
        assert logging.getLogger('tqdm').handlers != []
        logging.info('foo')
    assert logging.getLogger('tqdm').handlers == [logging.getLogger().handlers[0]]


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-26 09:26:35.653771
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    with logging_redirect_tqdm() as pbar:
        log.debug('this should appear in console and not in pbar')

        # pbar.write('this should appear in pbar')
        # pbar.write('this should appear in pbar')
        # pbar.write('this should appear in pbar')

    log.debug('this should appear in console and not in pbar')


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:26:43.955747
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger("test_logging_redirect_tqdm_logger")
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm([logger]):
        logger.info("redirected to `tqdm.write()`")

    print("Unmodified logging after with statement")
    logger.info("Unmodified")



# Generated at 2022-06-26 09:26:51.478188
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    import io
    import sys

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        buf = io.StringIO()
        fmt = logging.Formatter('%(message)s')
        hdlr = logging.StreamHandler(buf)
        hdlr.setFormatter(fmt)
        root = logging.getLogger()
        root.addHandler(hdlr)
        root.setLevel(logging.DEBUG)

        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:27:23.984729
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    log = logging.getLogger()
    log.addHandler(logging.StreamHandler())
    log.setLevel(logging.DEBUG)
    with tqdm_logging_redirect("TEST", total=10):
        log.debug("only visible in tqdm bar on console")
        log.error("also visible in tqdm bar on console")
    print("\n")
    log.debug("now visible on console")
    log.error("now visible on console")

if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:27:29.601886
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit("some log message")



if __name__ == '__main__':
    test_case_0()
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-26 09:27:36.526646
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log_msg = "Test logging message"

    # Test redirecting both console handlers to tqdm.write()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    with logging_redirect_tqdm():
        logging.info(log_msg)

    # Test redirecting only console handler to tqdm.write()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    some_logger = logging.getLogger(__name__)

# Generated at 2022-06-26 09:27:46.451591
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Logging without context manager; without 'logging_redirect_tqdm' context manager
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    try:
        for i in range(10):
            if i == 5:
                LOG.info("console logging NOT redirected to `tqdm.write()`")
    except:  # noqa pylint: disable=bare-except
        pass

    # Logging with context manager; without 'logging_redirect_tqdm' context manager
    try:
        for i in range(10):
            if i == 5:
                LOG.info("console logging NOT redirected to `tqdm.write()`")
    except:  # noqa pylint: disable=bare-except
        pass

    # Logging without

# Generated at 2022-06-26 09:27:48.362929
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10) as pbar:
        assert pbar.total == 10
        assert isinstance(pbar, std_tqdm)
        LOG = logging.getLogger(__name__)
        LOG.info('hello world')



# Generated at 2022-06-26 09:27:52.659813
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect() as pbar:
        pbar.set_description("Test: ")
        logging.info("Message 1")
        logging.info("Message 2")
        pbar.update()
        logging.info("Message 3")



# Generated at 2022-06-26 09:27:56.613383
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(unit_scale=True):
        logging.info("one")
        logging.info("two")



# Generated at 2022-06-26 09:28:02.514513
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    with tqdm_logging_redirect(desc="Tqdm logging redirection test case"):
        logger.info("Test Info")
        logger.warning("Test Warning")
        logger.error("Test Error")


# Generated at 2022-06-26 09:28:15.284645
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    LOG = logging.getLogger(__name__)
    LOG_MSG = 'console logging redirected to `tqdm.write()`'  # type: str

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info(LOG_MSG)


# Generated at 2022-06-26 09:28:23.481443
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100) as pbar:
        assert pbar.pos == 0
        assert pbar.total == 100
        pbar.update(10)
        assert pbar.pos == 10
        pbar.update(5)
        assert pbar.pos == 15


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:16.597533
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def _test(tqdm_class):
        with tqdm_logging_redirect(tqdm_class=tqdm_class, total=2):
            pass

    _test(lambda *args, **kwargs: std_tqdm(*args, **kwargs))

# Generated at 2022-06-26 09:29:17.873106
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with logging_redirect_tqdm():
        log = logging.getLogger()
        log.error('test function')


# Generated at 2022-06-26 09:29:22.638853
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        LOG.info("Hello World")


# Generated at 2022-06-26 09:29:27.142589
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(
            # loggers=[logging.root],
            total=2,
            file=sys.stderr):
        LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:29:35.908400
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(
            total=100,
            desc="TEST",
            ascii=True,
            bar_format=":ascii: :desc :bar :percent",
            # postfix={"percent": "", "rate": ""},
            loggers=[logging.root],
            tqdm_class=std_tqdm,
            file=sys.stdout,
            ):
        logging.info("Info")
        logging.warning("Warning")
        logging.error("Error")

# Generated at 2022-06-26 09:29:40.549221
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as _:
        pass


if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:49.041369
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, \
        tqdm_logging_handler_0

    with open("temp", 'w') as f:
        loggers = list()
        h = logging.StreamHandler(f)

        loggers.append(logging.getLogger(__name__))
        logging.root.handlers = list()
        logging.root.addHandler(h)

        logger = loggers[0]
        logger.setLevel(logging.INFO)

        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:29:59.204673
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # create logger
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.DEBUG)

    # create a console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)  # WARNING)

    # create a file handler
    fh = logging.FileHandler('test_logger.log')
    fh.setLevel(logging.INFO)

    # create formatter and add it to the handlers
    # formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    formatter = logging.Formatter('%(message)s')
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)

    # add the handlers to the logger
