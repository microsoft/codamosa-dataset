

# Generated at 2022-06-26 09:20:22.386456
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    original_logger = logging.root
    original_handlers = [h for h in original_logger.handlers]

    with logging_redirect_tqdm():
        # This should be printed by the TqdmLoggingHandler
        logging.info("test message")
        # This should not be printed by the TqdmLoggingHandler
        logging.info("test message to file", extra={"file": sys.stderr})
        # This should be printed by the TqdmLoggingHandler
        for i in trange(5):
            logging.info(i)

    assert original_logger.handlers == original_handlers

# Generated at 2022-06-26 09:20:32.782205
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # Create a logger for test case
    logger = logging.getLogger('Test_Logging_Redirect_Tqdm')
    logger.setLevel(logging.DEBUG)

    # Create a console output handler for test case
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    # Set the formatter and add the handler to the logger
    console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(console_handler)

    # Logging a message
    logger.debug("Printing simple message")

    # Redirect logging to tqdm
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info

# Generated at 2022-06-26 09:20:41.223182
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:20:51.830506
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

        #if __name__ == '__main__':
        #    pass
    except:
        raise
    finally:
        pass


# Generated at 2022-06-26 09:20:56.608432
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    log = logging.getLogger(__name__)
    message = 'abc'
    log.info(message)
    tqdm_logging_handler.emit(log.handlers[0].messages['message'])
    assert tqdm_logging_handler.messages['message'] == message


# Generated at 2022-06-26 09:21:01.010450
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger('tqdm_logging_redirect_test')
    original_handlers = logger.handlers

    try:
        with logging_redirect_tqdm():
            logger.info('was redirected')
            logger.debug('not redirected')
    finally:
        logger.handlers = original_handlers


# Generated at 2022-06-26 09:21:05.424661
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in range(3):
            LOG.info("logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:21:10.592276
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    record_0 = logging.LogRecord(None,None,None,None,None,None,None,None)
    tqdm_logging_handler_0.emit(record_0)


# Generated at 2022-06-26 09:21:21.475406
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Some fake loggers
    log_a = logging.getLogger('logger_1')
    log_b = logging.getLogger('logger_2')
    log_c = logging.getLogger('logger_3')

    # Register a console handler in each logger
    console_handler_a = logging.StreamHandler()
    console_handler_b = logging.StreamHandler()
    console_handler_c = logging.StreamHandler()
    log_a.addHandler(console_handler_a)
    log_b.addHandler(console_handler_b)
    log_c.addHandler(console_handler_c)

    # Some fake messages
    msg_a = "This is log message A"
    msg_b = "This is log message B"
    msg_c = "This is log message C"

    #

# Generated at 2022-06-26 09:21:32.730756
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm
    # Test if no arguments are specified
    # Test if tqdm is passed as an argument
    # Test if loggers is passed as an argument
    # Test if both loggers and tqdm are passed as arguments
    # Test if both loggers and tqdm are passed as arguments and tqdm_instance is also returned
    from tqdm import trange
    import logging

    @contextmanager
    def logging_redirect_tqdm_context_manager():
        logging_redirect_tqdm()
    LOG = logging.getLogger(__name__)
    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:21:42.288120
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    log_rec = logging.LogRecord('name', logging.ERROR, 'pathname', 42,
                                'message', [], None)
    tqdm_logging_handler_1.emit(log_rec)



# Generated at 2022-06-26 09:21:50.595248
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm import tqdm, trange
    from time import sleep
    import logging

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # 'Writes back to where log has been configured to output to'
        with tqdm_logging_redirect(desc='Demo loop') as pbar:  # pylint: disable=unused-variable
            # pbar is progress bar
            for i in trange(9):
                sleep(0.1)
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:21:59.033175
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.tests._utils import _range
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    for _ in _range(5):
        LOG.info('logging message')

    with logging_redirect_tqdm(loggers=[LOG]):
        for _ in _range(5):
            LOG.info('logging message redirected to `tqdm.write()`')

    with tqdm_logging_redirect(loggers=[LOG]):
        for _ in _range(5):
            LOG.info('logging message redirected to `tqdm.write()`')

# Generated at 2022-06-26 09:22:10.075549
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()

    # Test empty message
    # It is expected to display a line with just a single space
    tqdm_logging_handler_1.emit(logging.LogRecord(
        level=logging.INFO,
        pathname='',
        lineno=1,
        msg='',
        args=(),
        exc_info=None))

    # Test message containing newline
    # It is expected to display a line with just a single space
    tqdm_logging_handler_1.emit(logging.LogRecord(
        level=logging.INFO,
        pathname='',
        lineno=1,
        msg='\n',
        args=(),
        exc_info=None))

    # Test message containing tabs
   

# Generated at 2022-06-26 09:22:21.150017
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm_notebook

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
            total=9,
            loggers=[LOG],
            tqdm_class=tqdm_notebook,
            desc='Loading Data',
            dynamic_ncols=True,
        ) as t:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                t.update(1)


test_case_0()
test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:24.292406
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as test_tqdm:
        logging.warning("hello world")
        logging.warning("hi")
        assert "he" in test_tqdm.format_dict['desc']

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:24.978496
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        logging.info("message")

# Generated at 2022-06-26 09:22:30.671250
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    level = logging.INFO
    formatstring = '\n%(levelname)s: %(asctime)s: %(message)s'
    logging.basicConfig(format=formatstring, level=level)
    tqdm_logging_handler_0 = _TqdmLoggingHandler(tqdm)

    logging.info('before redirect')

    with tqdm_logging_redirect(loggers=[logging.root]):
        logging.info('during redirect')

    logging.info('after redirect')



# Generated at 2022-06-26 09:22:34.070969
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        logging.info('test message')



# Generated at 2022-06-26 09:22:38.376076
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm, trange
    import logging

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:22:58.337862
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import time
    import tqdm

    with tqdm.tqdm(range(10)) as pbar:
        with logging_redirect_tqdm() as lredirect:
            # Test that logging to console is redirected to `tqdm.write()`
            for i in range(10):
                logging.info(i)
                time.sleep(0.1)

            # Test that logging to file is not redirected
            LOG_FILENAME = 'test.log'
            file_logger = logging.getLogger(__name__)
            file_logger.setLevel(logging.INFO)
            file_logger.propagate = False
            file_handler = logging.FileHandler(LOG_FILENAME, mode='w')

# Generated at 2022-06-26 09:23:02.258663
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging

        with logging_redirect_tqdm():
            logging.info('Hello World')
    except KeyboardInterrupt:
        pass



# Generated at 2022-06-26 09:23:12.770124
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test writing a message to the logger
    with tqdm_logging_redirect(
            total=9, desc="test_logging_redirect_tqdm", leave=True, unit="it",
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
        logging.info("console logging redirected to `tqdm.write()`")
    # Test that tqdm_logging_redirect can be used as a with statement

# Generated at 2022-06-26 09:23:15.836341
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import test_tqdm_logging_redirect as tc0
    with tc0() as a:
        pass


# Generated at 2022-06-26 09:23:21.156753
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.handlers = []

    root_logger = logging.getLogger()
    test_handler = _TqdmLoggingHandler()
    root_logger.addHandler(test_handler)
    root_logger.setLevel(logging.INFO)
    root_logger.info('test')



# Generated at 2022-06-26 09:23:22.549234
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_case_0()

# Generated at 2022-06-26 09:23:30.865896
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect() as pbar:
        with logging_redirect_tqdm():
            for i in pbar(range(9)):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
    # tqdm restored


if __name__ == '__main__':
    import logging
    with tqdm_logging_redirect() as pbar:
        with logging_redirect_tqdm():
            for i in pbar(range(9)):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
    # tqdm restored

    # Unit tests of the redirect_tqdm.py
    test_case_

# Generated at 2022-06-26 09:23:41.375910
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    import sys
    try:
        sys.stdout = io.StringIO()
        logging.basicConfig(format="%(message)s", level=logging.INFO)
        with logging_redirect_tqdm():
            logging.info("info")
            logging.warning("warning")
            logging.error("error")
        stdout_lines = sys.stdout.getvalue().split('\n')
        assert stdout_lines[0] == 'info'
        assert stdout_lines[1] == 'warning'
        assert stdout_lines[2] == 'error'
    finally:
        sys.stdout = sys.__stdout__


if __name__ == '__main__':
    from tqdm._main import main
    main()

# Generated at 2022-06-26 09:23:44.890230
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as tqdm_bar:
        tqdm_bar.write('yo')
        logger = logging.getLogger('testing')
        logger.info('logging')
        tqdm_bar.write('yo')

# Generated at 2022-06-26 09:23:49.937388
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    total = 0
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            total += i
    assert total == 36


# Generated at 2022-06-26 09:24:04.976734
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info("info")
    with tqdm_logging_redirect():
        LOG.info("info")

# Generated at 2022-06-26 09:24:13.406590
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    import warnings
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Test whether the message is redirected to tqdm
    with logging_redirect_tqdm() as pbar:
        for _ in trange(3):
            time.sleep(0.1)
            pbar.set_description('pbar')
            LOG.info('console logging')
            LOG.error('redirected to tqdm.write()')
            LOG.warning('and works with multiple loggers')
    # logging restored

    # Test whether other loggers' outputs are not redirected to tqdm

# Generated at 2022-06-26 09:24:19.266049
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:24:26.226719
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Testing logging.root
    logger = logging.root
    orig_handlers = logger.handlers
    try:
        with logging_redirect_tqdm():
            raise ValueError()
    except ValueError:
        pass
    assert str(ValueError) in std_tqdm.get_write_set_str()
    assert orig_handlers == logger.handlers

    std_tqdm.clear()
    tqdm_handler = _TqdmLoggingHandler()
    orig_handler = _get_first_found_console_logging_handler(logger.handlers)
    assert isinstance(orig_handler, logging.StreamHandler)
    if orig_handler is not None:
        tqdm_handler.setFormatter(orig_handler.formatter)
        tqdm_handler.stream = orig_handler

# Generated at 2022-06-26 09:24:34.570866
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:24:44.466775
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.emit(logging.root)
    tqdm_logging_handler_0.emit(logging.WARNING)
    tqdm_logging_handler_0.emit(1)
    tqdm_logging_handler_0.emit('str')
    tqdm_logging_handler_0.emit(u'unicode')
    tqdm_logging_handler_0.emit(Exception())
    tqdm_logging_handler_0.emit(object)
    try:
        1 / 0  # trigger ZeroDivisionError
    except:  # noqa pylint: disable=bare-except
        tqdm_logging_handler_

# Generated at 2022-06-26 09:24:54.299964
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # -------------
    # - Assertions
    logging.getLogger().setLevel(logging.DEBUG)
    old_handler = logging.root.handlers[0]
    #print("old_handler: " + str(old_handler))
    with logging_redirect_tqdm():
        #print("handlers: " + str(logging.root.handlers))
        assert len(logging.root.handlers) == 1
        assert isinstance(logging.root.handlers[0], _TqdmLoggingHandler)
        assert logging.root.handlers[0].stream is sys.stderr
    #print("handlers: " + str(logging.root.handlers))
    assert len(logging.root.handlers) == 1
    assert logging.root.handlers[0] is old_

# Generated at 2022-06-26 09:25:01.085811
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    tqdm = std_tqdm

    LOG = logging.getLogger(__name__)
    assert LOG.name == __name__

    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    for i in tqdm(range(3)):
        if i == 2:
            LOG.info("Finished testing.")


if __name__ == "__main__":
    # pytest.main([__file__])
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:25:02.903474
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(desc="test", total=2) as pbar:
        pbar.update()
        pbar.update()

# Generated at 2022-06-26 09:25:11.632863
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:25:35.866241
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # loggers = [logging.getLogger('foo'), logging.getLogger('bar')]
    with tqdm_logging_redirect(total=100):
        for i in range(100):
            logging.info("test")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:42.149583
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        with logging_redirect_tqdm(loggers=[logging.root], tqdm_class=pbar.__class__):
            for _ in range(10):
                logging.info('hello world')


# Generated at 2022-06-26 09:25:49.339735
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        # pylint: disable=protected-access
        assert pbar._file == sys.stderr
        assert isinstance(pbar, std_tqdm)
        pbar.update(1)
        assert pbar._last_print_t is not None

        # test that updating pbar updates tqdm as well
        pbar.update(2)
        assert pbar.n == 3
        # test that logging updates tqdm as well
        logging.info("INFO")
        assert pbar._last_print_t is not None
        assert pbar.n == 4
        # test that updating tqdm updates pbar as well
        pbar.update(1)
        assert pbar.n == 5

        # test that updating pbar updates tqdm as

# Generated at 2022-06-26 09:25:52.265296
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(3):
                if i == 1:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:26:03.623621
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # Tested with a dummy logging.StreamHandler
    # that just prints the logged message.
    dummy_handler_0 = logging.StreamHandler()
    dummy_handler_0.emit = lambda record: print(
        tqdm_logging_handler_0.format(record))
    log_msg_0 = "testing..."
    logging_rec_0 = logging.LogRecord("name", logging.INFO, None, None,
                                      log_msg_0, None, None)
    tqdm_logging_handler_0.emit(logging_rec_0)


# Generated at 2022-06-26 09:26:12.783895
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # If a logging redirect to a stdout isn't performed,
    # the test will raise an AssertionError
    try:
        with tqdm_logging_redirect():                      # pragma: no cover
            logging.info("This is a logging test message")
    except AssertionError:                                 # pragma: no cover
        raise AssertionError("`tqdm.logging_redirect` is"
                             " not properly redirecting stdout")

# Generated at 2022-06-26 09:26:22.105345
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record_1 = logging.LogRecord("test_logger", logging.DEBUG, "test_path", 0, "test_msg", tuple(), None)
    # print(">> tqdm_logging_handler.emit({!r})".format(record_1))
    tqdm_logging_handler_1.emit(record_1)


# Generated at 2022-06-26 09:26:30.499276
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        # import tqdm
        import sys
        # from tqdm.contrib.logging import logging_redirect_tqdm
    except ImportError:
        return
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        assert sys.stdout.getvalue() == "console logging redirected to `tqdm.write()`\n"
    assert sys.stdout.getvalue() == ""



# Generated at 2022-06-26 09:26:40.299295
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._tqdm import trange
    import logging
    import io
    import os

    def test_logging_redirect_tqdm_helper(tqdm_class):
        with io.StringIO() as out:
            old_stdout = sys.stdout
            sys.stdout = out

# Generated at 2022-06-26 09:26:49.023420
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9):
        for _ in range(9):
            logging.info('console logging redirected to tqdm.write()')
    logging.info('console logging restored')
    with tqdm_logging_redirect(total=9, tqdm_class=tqdm):
        for _ in range(9):
            logging.info('console logging redirected to tqdm.write()')
    logging.info('console logging restored')

# Generated at 2022-06-26 09:27:35.440937
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Basic test cases
    import tempfile
    from contextlib import contextmanager
    from tqdm import tqdm, trange
    from tqdm.logging import TqdmTypeError, logging_redirect_tqdm, tqdm_logging_redirect
    from tqdm.utils import _term_move_up

    @contextmanager
    def redirect_io(target=None, to=None):
        from contextlib import contextmanager
        import sys
        from textwrap import dedent
        from tempfile import TemporaryFile

        @contextmanager
        def redirect(from_, to):
            fileno = to.fileno()
            try:
                from_.fileno()
            except AttributeError:
                fileno = open(to.name, 'r').fileno()
            sys.stdout.flush()
           

# Generated at 2022-06-26 09:27:46.207939
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests_tqdm import closing, StringIO
    import logging
    import sys
    tqdm_class = std_tqdm
    with closing(StringIO()) as our_file:
        handler = _TqdmLoggingHandler(tqdm_class)
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s '
                                               '%(message)s'))
        handler.stream = our_file
        record = logging.LogRecord(
            '__name__', logging.DEBUG,
            '__init__.py', 0, 'Test message', None, None)
        handler.emit(record)
        assert our_file.getvalue() == '1970-01-01 00:00:00,000 DEBUG ' \
                                      'Test message\n'


# Generated at 2022-06-26 09:27:52.431084
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    log.addHandler(console)
    with tqdm_logging_redirect() as pbar:
        log.info("hello world")
        pbar.update(50)
    log.removeHandler(console)
    return

# Generated at 2022-06-26 09:27:58.859005
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert isinstance(pbar, std_tqdm), "tqdm instance not created"
        assert isinstance(logging.root.handlers[0], _TqdmLoggingHandler), \
            "Logging handler not created"

# Generated at 2022-06-26 09:28:05.070504
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    logger.addHandler(logging.StreamHandler())

    logger.info("test before")
    with logging_redirect_tqdm([logger]):
        logger.debug("test inside")
        logger.info("test inside")
        logger.warning("test inside")
        logger.error("test inside")
    logger.info("test after")


# Generated at 2022-06-26 09:28:14.653856
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        log = logging.getLogger('test_logging_redirect_tqdm')
        log.setLevel(logging.DEBUG)
        log.addHandler(logging.StreamHandler())
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    log.info("console logging redirected to `tqdm.write()`")
    except:
        print("ImportError (required: logging, tqdm)")


# Generated at 2022-06-26 09:28:23.169435
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
    except ImportError:
        return

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with logging_redirect_tqdm():
        logger.debug("debug message")
        logger.info("info message")
        logger.warn("warn message")
        logger.error("error message")
        logger.critical("critical message")



# Generated at 2022-06-26 09:28:26.853941
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert pbar.__class__.__name__ == "tqdm"
        assert pbar.__enter__().__class__.__name__ == "tqdm"

# Generated at 2022-06-26 09:28:34.891066
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    # Set up console logging handler
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-26 09:28:42.446050
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from logging import basicConfig, getLogger, INFO, StreamHandler, StreamHandler
    except ImportError:
        return

    logger = getLogger(__name__)

    with logging_redirect_tqdm():
        logger.info("Test test_logging_redirect_tqdm")

