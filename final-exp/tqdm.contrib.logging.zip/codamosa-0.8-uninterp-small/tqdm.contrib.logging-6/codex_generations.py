

# Generated at 2022-06-26 09:20:11.115443
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    info_string = 'info string'

    # test with default loggers
    with logging_redirect_tqdm():
        LOG.info(info_string)

    # test with provided loggers
    loggers = [logging.getLogger('logger_1'), logging.getLogger('logger_2')]
    with logging_redirect_tqdm(loggers=loggers):
        for logger in loggers:
            logger.info(info_string)

    # restore loggers
    for logger in loggers:
        logger.handlers = []
    LOG.handlers = []



# Generated at 2022-06-26 09:20:19.695219
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect("console logging redirected to `tqdm.write()`"):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:20:29.021408
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager, suppress
    from copy import copy
    from logging import (
        ERROR,
        WARNING,
        INFO,
        basicConfig,
        getLogger,
        StreamHandler,
        )
    from shutil import rmtree
    from tempfile import mkdtemp
    from tqdm import tqdm
    from tqdm._tqdm_gui import tqdm_gui
    from tqdm._tqdm_notebook import tqdm_notebook
    from tqdm._utils import _term_move_up
    from tqdm.contrib import logger as tqdm_logger

# Generated at 2022-06-26 09:20:40.284159
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import with_bar, discretesleep
    logging_redirect_tqdm()
    discretesleep(0.01)
    logging.debug('This is a debug statement')
    discretesleep(0.01)
    logging.info('This is an informational statement')
    discretesleep(0.01)
    logging.warning('And this, a warning.')
    discretesleep(0.01)
    logging.error('Last but not least, the error message.')
    with with_bar() as bar:
        bar.write('This should not be tqdm, but stdout')
        logging.info('This should be tqdm')



# Generated at 2022-06-26 09:20:43.456738
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in tqdm(range(9)):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
        logger.warning("console logging restored to `print()`")
    logger.info("console logging redirected to `print()`")



# Generated at 2022-06-26 09:20:55.380278
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        "name", 1, "file", 2, "msg", (), None, None)

    # Test for invalid file
    with tqdm_logging_handler.tqdm_class.disable_stdout_redirection():
        tqdm_logging_handler.stream = sys.stderr
        with tqdm_logging_handler.tqdm_class.disable_stdout_redirection():
            tqdm_logging_handler.emit(record)

    # Test for valid file
    with tqdm_logging_handler.tqdm_class.disable_stdout_redirection():
        tqdm_logging_handler.stream = sys.stdout
        tqdm_logging_

# Generated at 2022-06-26 09:21:03.615144
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm as _tqdm
    from tqdm._tqdm_gui import tqdm as _tqdm_gui
    from tqdm._tqdm_pandas import tqdm as _tqdm_pandas
    from tqdm._tqdm_notebook import tqdm as _tqdm_notebook

    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    log.info('foobar')


# Generated at 2022-06-26 09:21:15.042086
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tempfile
    import logging

    log_file = tempfile.NamedTemporaryFile(delete=False).name
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)-8s - %(asctime)s - %(name)s - %(message)s",
        filename=log_file,
    )

    from tqdm import trange

    with tqdm_logging_redirect(desc="test") as pbar:
        for _ in trange(9):
            logging.info("console logging redirected to `tqdm.write()`")

    pbar.close()


# Generated at 2022-06-26 09:21:20.010435
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(
        tqdm_class=std_tqdm,
        total=1
    ) as pbar:
        assert pbar is not None


if __name__ == '__main__':
    # TODO: test_tqdm_logging_redirect()
    print("ok.")

# Generated at 2022-06-26 09:21:23.467343
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:21:33.286155
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    with tqdm_logging_redirect(total=3, unit='B'):
        logging.warning('test')
        logging.warning('test 2')

if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:21:37.567113
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOGGER = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOGGER]):
        LOGGER.info('Hello')


# Generated at 2022-06-26 09:21:46.102376
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger('')
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler())

    with logging_redirect_tqdm():
        pass

    with logging_redirect_tqdm():
        log.info("test logging_redirect_tqdm")


# Generated at 2022-06-26 09:21:55.464348
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    # loggers=None
    with tqdm.tqdm() as pbar:
        with tqdm_logging_redirect():
            logging.info('logged to pbar!')
            pbar.write('non logged to pbar!')

    # loggers=[logging.root]
    with tqdm.tqdm() as pbar:
        with tqdm_logging_redirect(loggers=[logging.root]):
            logging.info('logged to pbar!')
            pbar.write('non logged to pbar!')



# Generated at 2022-06-26 09:22:02.226332
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler('test.log')
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    with tqdm_logging_redirect(loggers=[logger]):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warn message')
        logger.error('error message')
        logger.critical('critical message')

    logger.info('Restoring original stdout logging handlers')
    logger.removeHandler(fh)

# Generated at 2022-06-26 09:22:13.661622
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import os
    import sys
    # create logger with 'tqdm_example'
    logger = logging.getLogger('tqdm_example')
    logger.setLevel(logging.DEBUG)
    # Set the log output file, and
    # define a Handler which writes the log messages to the log_file
    log_file = 'log_for_testing_emit_of_TqdmLoggingHandler.txt'
    try:
        os.remove(log_file)
    except OSError:
        pass
    file_handler = logging.FileHandler(log_file)
    logger.addHandler(file_handler)
    # create console handler with a higher log level

# Generated at 2022-06-26 09:22:25.594151
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = None  # type: Optional[List[logging.Logger]]
    tqdm_class = std_tqdm  # type: Type[std_tqdm]
    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-26 09:22:34.120176
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=1):
        pass
    with tqdm_logging_redirect(total=1, tqdm_class=std_tqdm) as pbar:
        assert pbar.__class__ is std_tqdm

if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:38.828818
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        with tqdm_logging_redirect() as pbar:
            pbar.write("hi")
    except Exception as e:
        assert False, "Error " + str(e)
    try:
        with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar:
            pbar.write("hi")
    except Exception as e:
        assert False, "Error " + str(e)

# Generated at 2022-06-26 09:22:49.036135
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test for function logging_redirect_tqdm
    """
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # test a default logger
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # test a specific logger
    with logging_redirect_tqdm(loggers=[LOG]):
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:23:11.241116
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from unittest.mock import Mock
    import logging
    import sys
    # Py3K
    if hasattr(sys.stdout, 'buffer'):
        sys.stdout = sys.stdout.buffer  # type: ignore

    mock_file = Mock()
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.stream = mock_file

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(tqdm_logging_handler_0)

    log = logging.getLogger()
    with logging_redirect_tqdm():
        log.info('test')
        assert "test\n" == mock_file.write.call

# Generated at 2022-06-26 09:23:14.882906
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    assert hasattr(logging_redirect_tqdm(), '__enter__')
    assert hasattr(logging_redirect_tqdm(), '__exit__')
    assert hasattr(tqdm_logging_redirect(), '__enter__')
    assert hasattr(tqdm_logging_redirect(), '__exit__')

# Generated at 2022-06-26 09:23:25.915733
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Unit test for tqdm_logging_redirect
    import logging
    import sys

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=0, desc="desc", leave=True) as pbar:
            pbar.set_description("pbar desc")
            pbar.update(0)
            pbar.write("Console logging redirected to stdout")
            sys.stdout.write("Console logging redirected to stdout")
            sys.stderr.write("Console logging redirected to stderr")
            LOG.info("Console logging redirected to pbar")
            LOG.debug("LOG.debug")
            LOG.info("LOG info")

# Generated at 2022-06-26 09:23:33.260849
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging, time
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        try:
            with logging_redirect_tqdm(tqdm_class=std_tqdm):
                for i in range(9):
                    time.sleep(0.1)
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
        except:  # noqa pylint: disable=bare-except
            pass
        logging.info('logging restored')


# Generated at 2022-06-26 09:23:41.147582
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up

    try:
        # pylint: disable=unused-variable
        from StringIO import StringIO  # noqa
    except ImportError:
        from io import StringIO  # noqa

    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    # with logging_redirect_tqdm([LOG]):
    with logging_redirect_tqdm():
        for _ in tqdm(range(1000)):
            LOG.info('Iteration done: %d', 1)



# Generated at 2022-06-26 09:23:42.555618
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.test import test_tqdm_logging_redirect
    test_tqdm_logging_redirect()



# Generated at 2022-06-26 09:23:52.800833
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                desc='case 0',
                logger=LOG,
                tqdm_class=tqdm
        ) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()


# Generated at 2022-06-26 09:23:59.861610
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    log_str = "Just a random string that should be logged"
    with tqdm_logging_redirect(bar_format="{l_bar}", loggers=[logging.getLogger()]) as pbar:
        logging.info(log_str)
    # Make sure the log string was written to the tqdm progressbar
    assert log_str in pbar.__str__()

# Generated at 2022-06-26 09:24:09.557423
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import redirect_stderr
    import io
    from logging import basicConfig, INFO, getLogger

    buffer = io.StringIO()
    with redirect_stderr(buffer):
        basicConfig(level=INFO)
        getLogger(__name__).info('info test_tqdm_logging_redirect')
        with tqdm_logging_redirect():
            pass
    assert 'info test_tqdm_logging_redirect' in buffer.getvalue()



# Generated at 2022-06-26 09:24:15.805517
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc=__name__, leave=True) as pbar:
        LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update()
        LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update()
        pbar.write("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:24:36.926767
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange

    with tqdm_logging_redirect(
            total=9,
    ) as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
                assert pbar.is_active

# Generated at 2022-06-26 09:24:49.689613
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:24:51.391064
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        assert True

# Generated at 2022-06-26 09:25:04.287010
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm.auto import tqdm as auto_tqdm  # type: ignore
    except ImportError:
        return

    from logging import getLogger
    from sys import stderr
    from io import StringIO

    log = getLogger()
    log.setLevel(10)
    # Must initialize `tqdm` first due to the issue in 3rd party `logging` library
    # that iterates through handlers in a very naive way
    # https://github.com/tqdm/tqdm/pull/1043#issuecomment-420180748
    for _ in tqdm_logging_redirect(loggers=[log], file=stderr,
                                   tqdm_class=auto_tqdm):
        log.info("Hello World!")

# Generated at 2022-06-26 09:25:13.700654
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)
    log_format = '[%(name)s][%(levelname)s] %(message)s'
    logging.basicConfig(level=logging.INFO, format=log_format)
    if __name__ == '__main__':
        with tqdm_logging_redirect(
                desc='Bar',
                loggers=[LOG],
                tqdm_class=std_tqdm):
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:25:23.668390
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:25:36.322026
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()
    tqdm_logging_handler = _TqdmLoggingHandler()

    with StringIO() as buf, logging_redirect_tqdm():
        logger.info("console logging redirected to `tqdm.write()`")
        assert "console logging redirected to `tqdm.write()`\n" == buf.getvalue()
    assert "console logging redirected to `tqdm.write()`\n" != buf.getvalue()
    logger.info("logging restored")

    with StringIO() as buf, logging_redirect_tqdm(loggers=[]):
        logger.info

# Generated at 2022-06-26 09:25:39.128109
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()


# Generated at 2022-06-26 09:25:45.741931
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    for i in range(10):
        log.info('test case %s' % i)
    log.info('test logging_redirect_tqdm')
    with tqdm_logging_redirect('test_logging_redirect_tqdm', desc='redirect'):
        for i in range(10):
            log.info('test case %s' % i)



# Generated at 2022-06-26 09:25:55.034574
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        assert True
    with tqdm_logging_redirect(loggers=[logging.root]):
        assert True
    with tqdm_logging_redirect(
            loggers=[logging.getLogger(__name__)],
            tqdm_class=std_tqdm,
            total=10,
            desc='logging_redirect_tqdm'):
        for i in range(10):
            logging.info('%d', i)



# Generated at 2022-06-26 09:26:41.043852
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for _ in range(3):
            logging.info('hello')
        assert len(pbar) == 3, 'Should print 3 lines of `hello`'

# Generated at 2022-06-26 09:26:53.850813
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from random import randrange
    from ..std import tqdm  # imported locally for testing purposes
    # Testing arguments of tqdm_logging_redirect
    # Testing `loggers`
    # Testing `loggers=None`
    some_logger = logging.getLogger('some_logger')
    original_handler = logging.StreamHandler()
    some_logger.addHandler(original_handler)

# Generated at 2022-06-26 09:26:59.211343
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # Example usage of method emit of class _TqdmLoggingHandler
    tqdm_logging_handler_0.emit()


# Generated at 2022-06-26 09:27:08.363538
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib import logging_redirect_tqdm
    # from tqdm.contrib import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-26 09:27:13.499544
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")
        logging.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:27:18.296552
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect(total=100):
        for i in range(100):
            logging.info(''.join(['a'] * 50))


# Generated at 2022-06-26 09:27:29.219799
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import sys
    import logging
    from tqdm import tqdm

    def test_case_1():
        
        def func():
            logging.info("Test")
        # Creating a file-like stream
        stream = StringIO()
        with tqdm_logging_redirect(file=stream):
            func()
        sys.stdout = sys.__stdout__

        stream.seek(0)
        s = stream.readline()
        assert("Test" in s)
    
    def test_case_2():
        def func():
            logging.info("Test")
        # Creating a file-like stream
        stream = StringIO()
        with tqdm_logging_redirect(file=stream, loggers=[logging.getLogger("test")]):
            func()

# Generated at 2022-06-26 09:27:36.156431
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import time
    import unittest
    class UselessTestCase(unittest.TestCase):
        def test_1(self):
            with tqdm_logging_redirect():
                logging.info("hello")
            with tqdm_logging_redirect(redirect_stdout=False):
                logging.info("hello")
            with tqdm_logging_redirect(file=sys.stderr):
                logging.info("hello")
            with tqdm_logging_redirect(level=logging.DEBUG):
                logging.info("hello")
            with tqdm_logging_redirect(level=logging.DEBUG,
                                       file=sys.stderr):
                logging.info("hello")

# Generated at 2022-06-26 09:27:46.359717
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import discretize, with_setup  # import dependency

    try:
        import logging
    except ImportError:
        return

    try:
        logging.captureWarnings(True)
    except AttributeError:
        pass

    # Example
    def example_0():
        with tqdm_logging_redirect(total=9):
            logging.warn("console logging redirected to `tqdm.write()`")

    # Examples
    @with_setup(setup=discretize)
    def example_1():
        # minitest
        logging.basicConfig(level=logging.INFO)
        from .tests_tqdm import tqdm_class


# Generated at 2022-06-26 09:27:55.156900
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test handling of SystemExit exception
    import logging
    import sys
    import tqdm

    class TestException(Exception):
        pass

    with tqdm.tests.mock_std_streams() as (std_out, std_err):
        logger = logging.Logger('test')
        tqdm_logging_handler = tqdm.contrib.logging._TqdmLoggingHandler()

        def _raise_exception():
            # type: () -> None
            raise TestException

        logger.exception(_raise_exception)

        # Test handling of TestException exception
        logger.addHandler(tqdm_logging_handler)
        assert len(logger.handlers) == 1
        try:
            logger.exception(_raise_exception)
        except TestException:
            pass

# Generated at 2022-06-26 09:29:27.402607
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import io
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = io.StringIO()  # type: ignore
    record = logging.LogRecord("test", logging.INFO, "foo.py", 42, "test", [], None)
    handler.emit(record)
    assert handler.stream.getvalue() == "test\n"



# Generated at 2022-06-26 09:29:34.657523
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    get testing_msg, create _TqdmLoggingHandler object,
    then call emit of _TqdmLoggingHandler
    """
    testing_msg = "This is a test message"
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_1.emit(testing_msg)



# Generated at 2022-06-26 09:29:42.280091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    for i in tqdm_logging_redirect(loggers=[logging.root],
                                   desc='basic test', file=None):
        logging.info("this is a test")
        assert True

if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-26 09:29:49.583066
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:29:59.414100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger('log')
    log.setLevel(logging.DEBUG)

    # Create TqdmLoggingHandler
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.setLevel(logging.DEBUG)
    log.addHandler(tqdm_logging_handler)

    # Check if logger is correctly handled
    log.debug("this is a debug message")
    log.info("this is an info message")


if __name__ == "__main__":
    import logging
    import tqdm
    log_error = logging.getLogger('signac.error')
    log_error.setLevel(logging.DEBUG)