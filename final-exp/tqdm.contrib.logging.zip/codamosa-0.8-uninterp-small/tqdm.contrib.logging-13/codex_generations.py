

# Generated at 2022-06-26 09:20:17.800068
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOGGER = logging.getLogger(__name__)
    TEST_STR = 'Something is happening...'
    with tqdm_logging_redirect():
        LOGGER.critical(TEST_STR)
    # TODO: add a unittest for logging_redirect_tqdm

# Generated at 2022-06-26 09:20:21.392425
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=100, desc="test", loggers=[logging.root]):
        logging.info("This should be redirected to tqdm.write()")

# Generated at 2022-06-26 09:20:31.464769
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange

    class TestLoggingHandler(logging.StreamHandler):
        def emit(self, record):
            text = self.format(record)
            self.stream.write(text)

    logging.basicConfig(format='%(levelname)s %(message)s', level=logging.DEBUG)
    LOG = logging.getLogger(__name__)
    LOG.addHandler(TestLoggingHandler())

    LOG.info('start')

    with logging_redirect_tqdm():

        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    tqdm.write('end')

    LOG.info('end')



# Generated at 2022-06-26 09:20:43.622426
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)

    with open('testlog.log', 'w') as f:  # Log file
        logging.basicConfig(level=logging.INFO, filename='testlog.log')
        logger = logging.getLogger()
        with logging_redirect_tqdm():
            logger.info('tqdm logging redirect')
        logger.info('tqdm logging no redirect')

    with open('testlog.log', 'r') as f:
        logs = f.read()
        assert 'tqdm logging no redirect' in logs
        assert 'tqdm logging redirect' not in logs

    ############################################################################
    # Unit test for function tqdm_logging_redirect
    ############################################################################
    # Test default value

# Generated at 2022-06-26 09:20:55.530984
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm._utils import _term_move_up
    with tqdm_logging_redirect():
        for _ in trange(10):
            print('tqdm_logging_redirect:', 'tqdm')
        for i in trange(10):
            logging.debug('tqdm_logging_redirect:', 'logging')
            logging.info('tqdm_logging_redirect:', 'logging')
            logging.warning('tqdm_logging_redirect:', 'logging')
            logging.error('tqdm_logging_redirect:', 'logging')
            logging.critical('tqdm_logging_redirect:', 'logging')

# Generated at 2022-06-26 09:21:03.716016
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Create loggers and set logging level to `DEBUG`
    loggers = [logging.getLogger("tqdm-logging-redirect-test"), logging.getLogger("test-with-stream")]
    for logger in loggers:
        logger.setLevel(logging.DEBUG)
    # Create console handler and set logging level to `DEBUG`
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    # Create tqdm console handler and set logging level to `DEBUG`
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.setLevel(logging.DEBUG)
    loggers[0].addHandler(console_handler)  # add console_handler to logger

# Generated at 2022-06-26 09:21:11.742135
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    _logger = logging.getLogger()
    _logger.handlers = []

    with tqdm_logging_redirect() as pbar:
        for _ in range(10):
            _logger.handlers = []
        pbar.update(10)


if __name__ == '__main__':
    try:
        test_tqdm_logging_redirect()
        print('Succeeded')
    except Exception as e:
        print('Failed: ' + str(e))

# Generated at 2022-06-26 09:21:19.308558
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:21:21.613151
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(range(3), leave=False) as pbar:
        assert pbar.n == 3

# Generated at 2022-06-26 09:21:32.854013
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # Set the logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # create console handler and set level to info
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    # create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    # add formatter to ch
    tqdm_handler.setFormatter(formatter)
    # Use tqdm_logging_redirect and then log.info will be passed to logger

# Generated at 2022-06-26 09:21:48.129016
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=1, desc="I am a test case",
                               bar_format='{l_bar}{bar}{r_bar}',
                               leave=False) as pbar:
        pbar.update()
        logging.info("test case")

    with tqdm_logging_redirect(total=1, desc="I am a test case",
                               bar_format='{l_bar}{bar}{r_bar}',
                               leave=False,
                               loggers=[logging.getLogger('test')]) as pbar:
        pbar.update()
        logging.info("test case")
        logging.getLogger('test').info("test case")


# Generated at 2022-06-26 09:21:59.139826
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()

    logging.basicConfig(level = logging.INFO)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    #logHandler = logging.StreamHandler()
    logger.addHandler(tqdm_logging_handler_1)
    logger.info("Here is a log")
    logger.info("Here is a log with a random function")

    # Now we use the redirect function
    logging.basicConfig(level = logging.INFO)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    #logHandler = logging.StreamHandler()
    logger.addHandler(tqdm_logging_handler_1)

# Generated at 2022-06-26 09:22:01.230977
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100) as pbar:
        assert pbar is not None
        return

# Generated at 2022-06-26 09:22:12.601685
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    from logging import LogRecord
    from tqdm.auto import tqdm

    buffer_ = io.StringIO()
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = buffer_
    # Create the log record
    log_record = LogRecord(
        name='test',
        level=10,
        pathname='/test',
        lineno=1,
        msg='test',
        args=None,
        exc_info=None)
    # Call the method
    tqdm_logging_handler.emit(log_record)
    assert buffer_.getvalue() == 'test\n'

    # Test with tqdm.tqdm
    buffer_ = io.StringIO()
    tqdm_logging_handler

# Generated at 2022-06-26 09:22:22.102549
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=5, desc="test_tqdm_logging_redirect") as pbar:
        LOGGER = logging.getLogger(__name__)
        LOGGER.info("Console logging redirected")
        pbar.update(2)


if __name__ == "__main__":

    with tqdm_logging_redirect(total=5, desc="test_tqdm_logging_redirect") as pbar:
        LOGGER = logging.getLogger(__name__)
        LOGGER.info("Console logging redirected")
        pbar.update(2)

# Generated at 2022-06-26 09:22:26.050064
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # init tqdm_logging_handler_0._TqdmLoggingHandler__lock
    tqdm_logging_handler_0.__lock



# Generated at 2022-06-26 09:22:30.376590
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=0) as pbar:
        assert pbar.n == 0
        assert pbar.total == 0
    assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-26 09:22:39.685229
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import logging.handlers
    from io import StringIO

    from tqdm import tqdm
    from tqdm._tqdm_gui import tqdm as tqdm_gui
    from tqdm.contrib.logging import _TqdmLoggingHandler

    for tqdm_class in (tqdm, tqdm_gui):

        with tqdm_class(
                desc="logging_test", disable=False, unit_scale=True) as pbar:
            tqdm_handler = _TqdmLoggingHandler(tqdm_class)
            tqdm_handler.setFormatter(logging.Formatter('%(levelname)s:%(message)s'))

            mem_handler = logging.handlers.MemoryHandler(capacity=100)
#             mem_handler

# Generated at 2022-06-26 09:22:41.129489
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.tests._test_tqdm_logging import (
        _test_tqdm_logging_redirect as f)
    f()


# Generated at 2022-06-26 09:22:46.952512
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    buf = StringIO()
    with tqdm_logging_redirect(file=buf, total=1) as pbar:
        pbar.n = 1
        pbar.refresh()
        assert buf.getvalue().splitlines()[-1] == '100%|██████████| 1/1 [00:00<00:00, ?it/s]'



# Generated at 2022-06-26 09:22:56.435893
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with logging_redirect_tqdm():
        flag = 0
        with tqdm_logging_redirect(total=3) as pbar:
            pbar.update(2)
            logging.info('test')
            flag = 1
        assert flag == 1

# Generated at 2022-06-26 09:23:03.716444
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler()
    log.addHandler(stream_handler)
    with logging_redirect_tqdm():
        log.warning('This is a warning!')
        log.info('This is an info!')


# Generated at 2022-06-26 09:23:13.399206
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import warnings
    from random import random
    from contextlib import redirect_stdout
    from io import StringIO

    from .tqdm_test_cases import range_test, two_iter_test, tqdm, trange

    # list of all available loggers
    loggers = [logging.root, logging.getLogger(__name__)]
    # list of all available tqdm classes
    tqdm_classes = [tqdm, trange]

    # list of available log levels
    log_levels = {
        'debug': 10,
        'info': 20,
        'warning': 30,
        'error': 40,
        'critical': 50,
    }

    # test string
    test_str = 'test'

    # log format

# Generated at 2022-06-26 09:23:24.739215
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

    with io.StringIO() as buf, redirect_stdout(buf):
        with tqdm_logging_redirect(total=1):
            logger.debug("debug")
            logger.info("info")
            logger.warning("warning")
            logger.error("error")
            logger.critical("critical")
        assert buf.getvalue() == "info\nwarning\nerror\ncritical\n"
        with logging_redirect_tqdm():
            logger.debug("debug")
            logger.info("info")

# Generated at 2022-06-26 09:23:34.789516
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import os
    from .tests_tqdm import closing, _range
    log = logging.getLogger('foo')
    log.setLevel(logging.DEBUG)
    with closing(
            tqdm_logging_redirect(_range(3),
                                  desc='Logging',
                                  bar_format='{l_bar}{bar}{r_bar}',
                                  ncols=100,
                                  loggers=[log],
                                  # tqdm_class=tqdm.notebook.tqdm
                                  )) as pbar:
        log.info("Logging with tqdm")
        for _ in pbar:
            pbar.set_description("Advance")
    sys.stderr.seek(0)
    err = sys.stderr.read()

# Generated at 2022-06-26 09:23:39.286099
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    global logger
    logger = logging.getLogger(__name__) # pylint: disable=undefined-variable
    logger.setLevel(logging.INFO)

    with tqdm_logging_redirect(desc='test'):
        logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:23:51.110656
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.auto import tqdm
    from tqdm import trange
    from tqdm.contrib import logging as tqdm_logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging.tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:23:54.795150
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    class FakeTqdm:
        """
        Fake class since tqdm can not be imported for test
        """
        pass

    class FakeLogging:
        """
        Fake class since logging can not be imported for test
        """
        pass

    with tqdm_logging_redirect(
            loggers=[FakeLogging()],
            tqdm_class=FakeTqdm
    ) as pbar:
        pass


# Generated at 2022-06-26 09:24:00.296436
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with logging_redirect_tqdm() as pbar:
        pbar.write("should be redirected to TqdmLoggingHandler")
        logging.info("and this should be redirected too")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:24:12.151546
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    import contextlib

    class MockTqdm():
        def __init__(self, *argv, **kwargs):
            self.called = False
            self.text = None

        def write(self, text):
            self.called = True
            self.text = text

        @contextlib.contextmanager
        def __call__(self, *args, **kwargs):
            yield self

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()

    tqdm_class = MockTqdm
    loggers = [logger]

    with tqdm_logging_redirect(tqdm_class=tqdm_class, loggers=loggers) as pbar:
        assert pbar.called == False
       

# Generated at 2022-06-26 09:24:32.198180
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # Disable all logging handlers by default.
    logging.basicConfig(level=logging.CRITICAL)

    minimal_logger = logging.getLogger(__name__)
    minimal_logger.setLevel(logging.DEBUG)
    minimal_logger.addHandler(logging.StreamHandler())

    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(10):
            minimal_logger.debug('i = {0}'.format(i))
            pbar.update()

# Generated at 2022-06-26 09:24:43.550535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_tqdm import with_test_main
    from .test_tqdm import with_test_out

    @with_test_main(argv=['logging-redirect'])
    @with_test_out
    def test_case(out_stream):
        tqdm_class = std_tqdm.tqdm
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        with logging_redirect_tqdm(loggers=[logger], tqdm_class=tqdm_class):
            tqdm_class.write("hello", file=out_stream)
            logger.error("world")
            tqdm_class.reset(file=out_stream)
            logger.info("!")

# Generated at 2022-06-26 09:24:52.130290
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Example from docs
    if __name__ == '__main__':
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored



# Generated at 2022-06-26 09:25:02.232896
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(ascii=True) as pbar:
            with pbar:
                for i in range(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:25:13.164213
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        time.sleep(0.01)
    LOG.info("logging restored")
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        time.sleep(0.01)
    print("please check the above output for `test_logging_redirect_tqdm`")


# Generated at 2022-06-26 09:25:16.616116
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10, unit="characters") as pbar:
        pbar.update(5)

# Generated at 2022-06-26 09:25:22.471487
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    with logging_redirect_tqdm():
        logger = logging.getLogger('tqdm_logging_redirect')
        logger.warning('This will be displayed in tqdm')
        time.sleep(0.1)


# Generated at 2022-06-26 09:25:35.999053
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    log.addHandler(ch)

    from tqdm import tqdm, trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
        log.info("This should show up")
        log.info("This should also show up")

# Generated at 2022-06-26 09:25:46.000026
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    class TqdmMock(object):
        def __init__(self, iterable=None, **kwargs):
            return

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            return False

        def __iter__(self):
            return self

        def __next__(self):
            raise StopIteration

    def raise_exception():
        raise Exception('Error')

    with tqdm_logging_redirect(tqdm_class=TqdmMock, loggers=[logging.root]) as pbar:
        raise_exception()
        pbar.close()

# Generated at 2022-06-26 09:25:50.051771
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm() as h:
        pass
    assert isinstance(h, _TqdmLoggingHandler)

# Generated at 2022-06-26 09:26:14.846055
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=[logging.getLogger()]) as pbar:
        print(pbar)


if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:26:23.644642
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('test_logging_redirect_tqdm')
    logger.handlers = []
    with logging_redirect_tqdm() as logger:
        logger.info("testing")
        with logging_redirect_tqdm([logger]) as logger:
            logger.info("testing")
            logger.info("testing")
            logger.info("testing")
        logger.info("testing")
    logger.info("testing")

# Generated at 2022-06-26 09:26:35.315765
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    with logging_redirect_tqdm() as tqdm_handler:
        log.info('Hello, world!')
        assert tqdm_handler.stream == sys.stderr
    log.info('Bye, world!')
    assert tqdm_handler.stream != sys.stderr  # check that handler is removed


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '--verbose', '-v', 'tests'],
                   exit=False)

# Generated at 2022-06-26 09:26:47.208301
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:26:53.310455
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.root]
    tqdm_class = std_tqdm
    original_handlers_list = [logger.handlers for logger in loggers]
    assert len(original_handlers_list[0]) > 0
    with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
        assert len(logging.root.handlers) == len(original_handlers_list[0]) + 1
    assert len(logging.root.handlers) == len(original_handlers_list[0])


# Test for function tqdm_logging_redirect

# Generated at 2022-06-26 09:27:04.456387
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.root.setLevel(logging.WARNING)

    with tqdm_logging_redirect(logging.WARNING):
        logging.warning('This is a warning')

    with tqdm_logging_redirect(total=10):
        logging.warning('This is a warning')

    with tqdm_logging_redirect(total=10, loggers=[logging.root]):
        logging.warning('This is a warning')

        with tqdm_logging_redirect(total=10, loggers=[logging.root]):
            logging.warning('This is a warning')

        logging.warning('This is a warning')

    logging.warning('This is a warning')

# Generated at 2022-06-26 09:27:14.306029
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)
        total_steps = 9

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(total_steps):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored
    except:
        return False
    return True

# Generated at 2022-06-26 09:27:24.416436
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:27:28.912107
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # logging.basicConfig(level=logging.DEBUG)
    for i in tqdm_logging_redirect(total=2):
        logging.info("test_tqdm_logging_redirect")

# Generated at 2022-06-26 09:27:33.112279
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    try:
        tqdm_logging_handler_0._emit(None)
    except (KeyboardInterrupt, SystemExit) as e:
        assert 1
    except:
        assert 0


# Generated at 2022-06-26 09:28:26.182613
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    from logging import basicConfig, getLogger, INFO, DEBUG, StreamHandler
    from contextlib import redirect_stdout
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    # Set up logging basics, including custom output stream
    stream = StringIO()
    stream_handler = StreamHandler(stream)
    basicConfig(level=INFO)
    root_logger = getLogger()
    root_logger.addHandler(stream_handler)
    stream_handler.setLevel(DEBUG)

    # Initialize the context manager

# Generated at 2022-06-26 09:28:36.475374
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    logger_name = LOG.name

    # test of logging_redirect_tqdm
    logging.basicConfig(level=logging.INFO)
    test_message = "console logging redirected to `tqdm.write()`"
    with tqdm_logging_redirect() as pbar:
        for i in trange(4):
            if i == 3:
                LOG.info(test_message)

# Generated at 2022-06-26 09:28:42.642838
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logging_test_record = logging.LogRecord("foo", 1, "bar", 10, 'baz', None, None)
    tqdm_logging_handler_1.emit(logging_test_record)


# Generated at 2022-06-26 09:28:51.114969
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from unittest import TestCase

    class TestLoggingRedirect(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_case_0(self):
            # Copy-paste an example from the docstrings, into test case
            import logging
            from tqdm import trange
            from tqdm.contrib.logging import logging_redirect_tqdm

            LOG = logging.getLogger(__name__)

            if __name__ == '__main__':
                logging.basicConfig(level=logging.INFO)
                with logging_redirect_tqdm():
                    for i in trange(9):
                        if i == 4:
                            LOG.info("console logging redirected to `tqdm.write()`")
                #

# Generated at 2022-06-26 09:28:54.655579
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.getLogger(__name__).info('This is a test message')
    with tqdm_logging_redirect():
        logging.getLogger(__name__).info('This is a test message')

# Generated at 2022-06-26 09:29:06.057419
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            pbar.set_description("description %i"%i)
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:14.777747
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    assert LOG.getEffectiveLevel() == 20
    assert LOG.handlers == [logging.StreamHandler(sys.stdout)]
    assert LOG.hasHandlers()
    with tqdm_logging_redirect():
        assert not LOG.hasHandlers()



# Generated at 2022-06-26 09:29:24.760183
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in tqdm.trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:37.102535
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Check if raising an exception in emit does not cause a recursive loop
    record = logging.LogRecord("name", "level", None, None, "msg", None, None)
    tqdm_logging_handler = _TqdmLoggingHandler()
    with tqdm_logging_handler.tqdm_class.stdout():
        try:
            tqdm_logging_handler.emit(record)
        except Exception as e:
            print("Raised an exception: %s" % str(e))
    # Check that a normal message is logged
    record = logging.LogRecord("name", "INFO", None, None, "msg", None, None)
    with tqdm_logging_handler.tqdm_class.stdout():
        tqdm_logging_handler.emit(record)


#

# Generated at 2022-06-26 09:29:40.133949
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(desc="Test Desc"):
        logging.info("info log")