

# Generated at 2022-06-26 09:20:06.352232
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(4):
            logger.debug(i)


# Generated at 2022-06-26 09:20:18.048077
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    now = 0
    logging_record = logging.make_log_record({
        'msg': 'Test message',
        'created': now,
        'levelname': 'INFO',
        'name': 'test_case_emit',
    })

    (tqdm_logging_handler_0, tqdm_logging_handler_1, tqdm_logging_handler_2
     ) = (_TqdmLoggingHandler(), _TqdmLoggingHandler(tqdm_class=None),
          _TqdmLoggingHandler(tqdm_class=True))
    # The output should be the same with or without tqdm_class

# Generated at 2022-06-26 09:20:23.169100
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        tqdm_logging_handler_1 = _TqdmLoggingHandler()
        tqdm_logging_handler_1.emit(logging.LogRecord("name", logging.INFO, "pathname", 1, "msg", None, None))
    except (Exception):
        raise AssertionError("Failed!")

# Generated at 2022-06-26 09:20:33.536963
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("Everything is fine now")

if __name__ == '__main__':
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in std_tqdm(range(10)):
            logging.info('%d', i)
    logging

# Generated at 2022-06-26 09:20:41.174292
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100) as pbar:
        pbar.update(5)
        with logging_redirect_tqdm(tqdm_class=pbar.__class__):
            logging.info("Hello World!")
        pbar.update(10)
    assert "Hello World!" in pbar.read(False)


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:20:46.603179
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    logrecord_0 = logging.LogRecord('__name__', 'DEBUG', '__file__', 100,
                                    "Message: %s", ['test_case'], None)
    # tqdm_logging_handler_0.emit(logrecord_0)


# Generated at 2022-06-26 09:20:58.309838
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    test_logger = logging.getLogger(__name__)
    test_logger.debug("test debug message before patch")
    test_logger.info("test info message before patch")
    assert(len(test_logger.handlers) == 1)
    assert(not isinstance(test_logger.handlers[0], _TqdmLoggingHandler))
    with tqdm_logging_redirect():
        test_logger.debug("test debug message after patch")
        test_logger.info("test info message after patch")
    test_logger.debug("test debug message before patch")
    test_logger.info("test info message before patch")
    assert(len(test_logger.handlers) == 1)

# Generated at 2022-06-26 09:21:03.146318
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        tqdm_logging_handler_0 = _TqdmLoggingHandler()
        record = logging.LogRecord(None, None, 'TqdmLoggingHandlerTests', None, 'This is the message', None, None)
        tqdm_logging_handler_0.emit(record)
    except:
        print("Test failed")
        raise


# Generated at 2022-06-26 09:21:10.800557
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm_notebook as tqdm
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm(tqdm_class=tqdm):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in trange(9):
        if i == 4:
            LOG.info("console logging restored")

# Generated at 2022-06-26 09:21:17.099254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                print(pbar.__dict__)


# Generated at 2022-06-26 09:21:29.857728
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    def _log_test():
        with logging_redirect_tqdm() as log_redirect:
            logging.warn('Test A')
            logging.error('Test B')
            logging.info('Test C')
            logging.debug('Test D')
        logging.warn('Test E')
        logging.error('Test F')
        logging.info('Test G')
        logging.debug('Test H')
    _log_test()



# Generated at 2022-06-26 09:21:39.419029
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def test_tqdm_logging_redirect_1():
        with tqdm_logging_redirect():
            pass

    def test_tqdm_logging_redirect_2():
        with tqdm_logging_redirect() as pbar:
            for i in range(3):
                pbar.update(1)

    def test_tqdm_logging_redirect_3():
        with tqdm_logging_redirect() as pbar:
            pbar.update()

    def test_tqdm_logging_redirect_4():
        with tqdm_logging_redirect():
            raise ValueError()

    test_tqdm_logging_redirect_1()
    test_tqdm_logging_redirect_2()
    test_tq

# Generated at 2022-06-26 09:21:43.446843
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for _ in trange(9):
            logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:21:51.018207
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # Check that a simple use case runs
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for _ in range(9):
            if _ == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    # Check that it works with multiple loggers
    def test_loggers(loggers):
        with tqdm_logging_redirect(*loggers):
            logging.info("hello from root logger")
            for l in loggers:
                l.info("hello from {}".format(l.name))

    # Check that it works for a specific logger
    test_loggers([logging.getLogger(__name__)])
    # Check that it works for all loggers
    test_loggers([logging.root])
    #

# Generated at 2022-06-26 09:21:57.855942
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Tests logging_redirect_tqdm function.

    """
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    assert True



# Generated at 2022-06-26 09:22:08.883168
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm_tests_common import with_bar_redirected_stdout, with_captured_stdout

    with logging_redirect_tqdm():
        logging.info("foo")
        logging.debug("DEBUG")

    with with_captured_stdout() as captured:
        with logging_redirect_tqdm():
            logging.error("ERROR")
        assert captured.getvalue().strip() == '[ERROR] ERROR'

    with with_bar_redirected_stdout() as (bar1, bar2):
        with logging_redirect_tqdm():
            logging.info("foobar")
            logging.debug("DEBUG")

    assert bar2.get_postfix().strip() == 'foobar DEBUG'

    import logging.config

# Generated at 2022-06-26 09:22:20.860003
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log_test = logging.getLogger(__name__)
    log_test.setLevel(logging.INFO)
    # Test logging.basicConfig()
    with logging_redirect_tqdm():
        log_test.info("TEST INFO")
    # Test with loggers
    log_test2 = logging.getLogger(__name__ + "2")
    log_test2.setLevel(logging.INFO)
    with logging_redirect_tqdm([log_test, log_test2]):
        log_test2.info("TEST INFO 2")
    # Test with a logger already setup
    log_test3 = logging.getLogger(__name__ + "3")
    log_test3.setLevel(logging.INFO)

# Generated at 2022-06-26 09:22:24.271254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from sys import stdout

    # logging_redirect_tqdm_0 = logging_redirect_tqdm()
    tqdm_logging_redirect_0 = tqdm_logging_redirect()

    with tqdm(total=10, file=stdout) as pbar:
        with tqdm_logging_redirect():
            pbar.update(5)

# Generated at 2022-06-26 09:22:26.743044
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_1.emit()



# Generated at 2022-06-26 09:22:37.413572
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        # test code
        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    except Exception:
        import traceback
        traceback.print_exc()
        raise Exception



# Generated at 2022-06-26 09:22:45.365115
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("hi")



# Generated at 2022-06-26 09:22:52.711693
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def redirectTest(n):
        with tqdm_logging_redirect(
                total=n,
                desc='Redirecting logging to tqdm',
                loggers=[logging.getLogger(__name__)],
                bar_format='{desc} {n_fmt}/{total_fmt}') as pbar:
            for i in range(n):
                logging.log(1, 'Redirecting logging to tqdm')
                pbar.set_description_str('Redirecting logging to tqdm')
                pbar.update(1)
            logging.log(2, 'This should not appear')
            pbar.set_description_str('This should not appear')


# Generated at 2022-06-26 09:23:01.249458
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import logging


# Generated at 2022-06-26 09:23:08.446254
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    # Redirect logging to tqdm in this context
    with logging_redirect_tqdm():
        # Loop with logging
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    LOG.info("logging restored")
    # Loop with logging
    for i in range(9):
        if i == 4:
            LOG.info("console logging not redirected")


# Generated at 2022-06-26 09:23:19.586767
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)  # in case `logging` package is not yet configured

    LOG = logging.getLogger(__name__)

    def log_test_msg():
        # Log to console
        LOG.info("console logging redirected to `tqdm.write()`")
        # Log to tqdm
        tqdm.write("tqdm logging redirected to `tqdm.write()`")

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                log_test_msg()

# Generated at 2022-06-26 09:23:22.228197
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        with tqdm_logging_redirect(loggers=[logging.root]):
            logging.info("This should be outputed to tqdm.")
    except AttributeError:
        pass

# Generated at 2022-06-26 09:23:30.238124
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logger = logging.getLogger('tqdm_logging_redirect')

    def str_gen():
        logger.info('foo')
        yield 'bar'
        logger.info('baz')
        raise StopIteration

    # tqdm is passing the iterator to the logging handler
    with tqdm_logging_redirect(iterable=str_gen(), miniters=1) as pbar:
        assert pbar.n == 0
        # calls the iterator, logging fails, tqdm can't detect the final position
        assert pbar.n == 0
        # calls the iterator again, logging still fails, tqdm can't detect the final position
        assert pbar.n == 0

# Generated at 2022-06-26 09:23:41.341774
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    def test_case_1():
        # pylint: disable=missing-docstring
        import logging

        from tqdm import trange

        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    test_case_1()

    def test_case_2():
        # pylint: disable=missing-docstring
        import logging

        from tqdm import tqdm


# Generated at 2022-06-26 09:23:52.171174
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    import logging

    # Basic setup
    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
    LOG.setLevel(logging.DEBUG)
    CONSOLE_HANDLER = logging.StreamHandler()  # pylint: disable=invalid-name
    CONSOLE_HANDLER.setFormatter(logging.Formatter('%(name)s - %(levelname)s - %(message)s'))
    LOG.addHandler(CONSOLE_HANDLER)

    # Warnings
    LOG.warning("This won't be printed, we are not in the context")
    with logging_redirect_tqdm():
        LOG.warning("This will be redirected to tqdm.write")

    # Info
    LOG

# Generated at 2022-06-26 09:23:54.495311
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc='test'):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:24:10.114536
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("logging redirected to `tqdm.write()`")
    sys.stderr.write('.')



# Generated at 2022-06-26 09:24:14.930656
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_kwargs = {'logging_on': True}
    loggers = None
    tqdm_class = std_tqdm
    with tqdm_class(**tqdm_kwargs) as pbar:
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            yield pbar

# Generated at 2022-06-26 09:24:20.927238
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[logging.root]):
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:24:31.127512
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=2) as pbar:
        logger = logging.getLogger()
        logger.info("logging redirected to `tqdm.write()`")
        for _ in trange(2):
            pass
    assert(pbar.n == 2)
    logger.info("logging restored")


# Generated at 2022-06-26 09:24:35.335110
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('test_logging_redirect_tqdm')



# Generated at 2022-06-26 09:24:44.742772
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # setup
    original_stream = sys.stderr
    mock_stream = open("mock_stream.txt", "w")
    sys.stderr = mock_stream
    # test
    with logging_redirect_tqdm():
        logging.error("test_logging_redirect_tqdm: test message.")
    # verify
    mock_stream.close()
    with open("mock_stream.txt", "r") as mock_stream:
        mock_content = mock_stream.read()
        if mock_content != "test_logging_redirect_tqdm: test message.\n":
            raise AssertionError("Test logging_redirect_tqdm: failed.")
    # teardown
    sys.stderr = original_stream


# Generated at 2022-06-26 09:24:51.732622
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(bar_format='{postfix[0][iter]}, {postfix[0][remaining]}'):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:25:04.386903
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm.std import tqdm

    # Test case 1
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-26 09:25:12.187148
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=5, unit='B', unit_scale=True,
                               miniters=1):
        logging.debug("debug")
        logging.info("info")
        logging.warning("warning")
        logging.error("error")
        logging.critical("critical")


# Generated at 2022-06-26 09:25:25.357849
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import tqdm

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    with tqdm_logging_redirect(loggers=[logger], total=2) as t:
        logger.info("My first message!")
        t.update(1)
        time.sleep(1)
        logger.info("My second message!")
        t.update(1)
    logger.info("My third message!")

# Generated at 2022-06-26 09:25:55.432197
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:26:05.366733
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    
    # create a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    
    # add the handlers to the logger
    logger.addHandler(handler)
    
    with tqdm_logging_redirect():
        for i in range(10):
            logger.info('hi')

# Generated at 2022-06-26 09:26:13.466079
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:26:22.904097
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:26:27.324478
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    rec = logging.makeLogRecord({'msg': 'test'})  # type: logging.LogRecord
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit(rec)
    assert tqdm_logging_handler.stream is sys.stderr



# Generated at 2022-06-26 09:26:35.351507
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function logging_redirect_tqdm
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect(ncols=50):
            tqdm.write('text')



# Generated at 2022-06-26 09:26:47.207489
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.auto import tqdm
    try:
        from tempfile import TemporaryDirectory  # pylint: disable=unused-import
    except ImportError:
        pass
    try:
        from unittest.mock import patch  # pylint: disable=unused-import
    except ImportError:
        from mock import patch  # type: ignore

    outfile = 'test_logging_redirect_tqdm.out'
    try:
        from tempfile import TemporaryDirectory  # pylint: disable=unused-import
    except ImportError:
        pass
    try:
        from unittest.mock import patch  # pylint: disable=unused-import
    except ImportError:
        from mock import patch  # type: ignore


# Generated at 2022-06-26 09:26:49.107185
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pass

# Generated at 2022-06-26 09:26:53.255359
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # tqdm_logging_redirect(loggers=[logging.getLogger('tqdm')])
    with tqdm_logging_redirect():
        print('hello world')

# Generated at 2022-06-26 09:26:57.427764
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm
    import logging
    from io import StringIO
    output = StringIO()

    with tqdm_logging_redirect(file=output,
                               loggers=[logging.getLogger()]) as pbar:
        logging.info('redirected to tqdm.write')
        pbar.write('also printed')

    assert output.getvalue().strip() == 'redirected to tqdm.write\nalso printed'



# Generated at 2022-06-26 09:27:54.596014
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tempfile

    fname = tempfile.mktemp()
    with open(fname, 'wt') as f:
        handler = logging.FileHandler(fname)
        hdlr_fmt = logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s - %(message)s")
        handler.setFormatter(hdlr_fmt)
        root_logger = logging.getLogger()
        root_logger.addHandler(handler)
        root_logger.setLevel(logging.INFO)
        logger = logging.getLogger(__name__)
        logger.info('Before context')
        with logging_redirect_tqdm():
            logger.info('Inside context')
        logger.info('After context')
    assert f.read

# Generated at 2022-06-26 09:28:05.403513
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import re
    import os
    import subprocess
    import threading
    import time
    import tqdm

    # Create a temporary test file
    with open('test_log', 'w') as f:
        pass

    # Save the original logging handler
    original_handlers_list = [logging.root.handlers]

    # Create a new logging handler
    logger = logging.getLogger(__name__)
    log_handler = logging.FileHandler('test_log')
    log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger.handlers = [log_handler]

    # Some test log messages
    log_info_message = 'Test info message'

# Generated at 2022-06-26 09:28:15.176375
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import logging as std_logging
    from ..std import tqdm as std_tqdm
    from .test_std import TestCase  # noqa

    class TestLoggingRedirectTqdm(TestCase):
        def test_logging_redirect_tqdm_default(self):
            LOG = std_logging.getLogger(__name__)

            with tqdm_logging_redirect():
                for i in std_tqdm(range(9)):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:28:26.086519
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    import logging
    import os
    import tempfile
    import sys
    if sys.version_info >= (3, 3):
        import unittest as ut
        import unittest.mock as mock
    else:
        import mock
        import unittest as ut
    mock_stdout = mock.Mock()
    mock_stdout.__iter__.return_value = [""].__iter__()
    mock_stdout.write.return_value = len("")
    mock_stdout.flush.return_value = None

    mock_stderr = mock.Mock()
    mock_stderr.__iter__.return_value = [""].__iter__()
    mock_stderr.write.return_value = len

# Generated at 2022-06-26 09:28:30.883402
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    with logging_redirect_tqdm():
        for i in range(1000):
            logging.info('Original Logging')
            time.sleep(0.001)



# Generated at 2022-06-26 09:28:35.553475
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:28:42.251396
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # First case:
    # No Loggers passed. The root Logger is used.
    with logging_redirect_tqdm(None):
        logging.info("TEST")

    with tqdm_logging_redirect():
        logging.info("TEST")


# Generated at 2022-06-26 09:28:45.510469
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # test_case_1
    try:
        with logging_redirect_tqdm():
            assert True
    except Exception as e:
        assert False, "Error in logging_redirect_tqdm: " + str(e)

# Generated at 2022-06-26 09:28:54.206811
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger('logging_redirect_tqdm_test')
    with logging_redirect_tqdm():
        log.error('Oooh, shiny')
        log.error('Oooh, shiny')
    with logging_redirect_tqdm():
        log.warning('Oooh, shiny')
        log.warning('Oooh, shiny')



# Generated at 2022-06-26 09:28:58.764343
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler())
    with logging_redirect_tqdm():
        logger.info("foo")
