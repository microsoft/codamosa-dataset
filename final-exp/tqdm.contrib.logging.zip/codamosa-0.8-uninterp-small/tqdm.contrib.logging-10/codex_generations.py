

# Generated at 2022-06-26 09:20:16.875602
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .utils import TestHandler
    logger = logging.getLogger()
    with TestHandler() as handler, \
            logging_redirect_tqdm([logger]) as pbar:
        logger.info("test message")
        assert handler.messages == {}
        pbar.write("tqdm message")
        assert handler.messages == {}


# Generated at 2022-06-26 09:20:27.496543
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    default_logging_msg = "default logging message"
    tqdm_logging_msg = "redirected logging message"

    # Test 1: with logging_redirect_tqdm
    with tqdm_logging_redirect(bar_format="{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]"):
        LOG.info(tqdm_logging_msg)
    LOG.info(default_logging_msg)

    # Test 2: with tqdm_logging_redirect

# Generated at 2022-06-26 09:20:33.157166
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    logging.basicConfig(level=logging.INFO)
    # Create logger
    logger = logging.getLogger()

    # Create handlers
    c_handler = logging.StreamHandler(sys.stdout)
    c_handler.setLevel(logging.INFO)

    # Create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    c_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(c_handler)

    logger.info('Hello Baby')


# Generated at 2022-06-26 09:20:45.211804
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from _tqdm_test_cases import pretest_posttest
    from tqdm.std import tqdm

    log = logging.getLogger()
    with logging_redirect_tqdm():
        for i in tqdm(range(7)):
            log.info("hello {}".format(i))

    with logging_redirect_tqdm(tqdm=tqdm):
        for i in tqdm(range(7)):
            log.info("hello {}".format(i))

    with pretest_posttest(sys.stderr):
        with logging_redirect_tqdm(loggers=[]):
            for i in tqdm(range(7)):
                log.info("hello {}".format(i))


# Generated at 2022-06-26 09:20:48.313979
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    with tqdm_logging_redirect(file=sys.stdout):
        print("foo")
    # assert sys.stdout.getvalue() == "foo\n"

# Generated at 2022-06-26 09:20:51.659612
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        for _ in pbar:
            pass

# Generated at 2022-06-26 09:21:00.131632
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import getLogger
    from .tqdm_test_cases import with_setup, pretest_posttest, _range

    @with_setup(pretest=pretest_posttest, posttest=pretest_posttest)
    def test_case_1():
        log = getLogger(__name__)
        log.info('stdout')
        log.info('stderr')

        with logging_redirect_tqdm():
            log.info('stdout')
            log.info('stderr')
            log = getLogger(__package__)
            log.info('stdout')
            log.info('stderr')

        log.info('stdout')
        log.info('stderr')


# Generated at 2022-06-26 09:21:05.425498
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import time
        logging.basicConfig()

        def test_func():
            for _ in trange(5):
                logging.info('Hello World')
                time.sleep(0.05)

        test_func()

        with logging_redirect_tqdm():
            test_func()
    except AttributeError:
        print('Failed test_logging_redirect_tqdm')

# Generated at 2022-06-26 09:21:09.500672
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('console logging redirected to `tqdm.write()`')


# Generated at 2022-06-26 09:21:20.094463
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Setup logger
    log_format = '%(asctime)s %(levelname)s %(message)s'
    logging.basicConfig(level=logging.INFO, format=log_format)
    loggers = [logging.root]  # type: List[logging.Logger]
    # Message for logger before, during, and after the logger
    before_msg = 'Console logging should be directed to tqdm.write before the logger'
    during_msg = 'Console logging should be directed to tqdm.write during the logger'
    after_msg = 'Console logging should be directed to stdout after the logger'
    # Print console logging before and during the tqdm_logging_redirect
    print(before_msg)

# Generated at 2022-06-26 09:21:26.629891
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    pass


# Generated at 2022-06-26 09:21:31.568637
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(redirect=True) as pbar:
        assert pbar.disable

    with tqdm_logging_redirect(redirect=True):
        pass

    with tqdm_logging_redirect(redirect=True, leave=True) as pbar:
        assert not pbar.disable

# Generated at 2022-06-26 09:21:38.196875
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:21:44.045235
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    rec = logging.LogRecord('o', logging.INFO, 'foo.py', 42, 'Hello World', (), None)  # noqa pylint: disable=too-many-function-args
    tqdm_logging_handler_0.emit(rec)



# Generated at 2022-06-26 09:21:50.239921
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(10, desc='logging_redirect_tqdm'):
            if i == 1:
                logging.debug(0)
            elif i == 5:
                logging.info(1)
            elif i == 6:
                logging.warn(2)
            elif i == 8:
                logging.error(3)
            elif i == 9:
                logging.critical(4)
            else:
                pass


# Generated at 2022-06-26 09:21:57.894273
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO, filename='test_tqdm_logging_redirect.log')
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, ascii=True, desc='console logging redirected to `tqdm.write()`') as pbar:
        for i in range(10):
            LOG.info("console logging redirected to tqdm.write()")
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:05.682339
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger()
    log.setLevel(logging.INFO)
    with tqdm_logging_redirect():
        log.info("test")

    with tqdm_logging_redirect(loggers=[log]):
        log.info("test")
        log.info("test")

    with tqdm_logging_redirect(loggers=[log], total=10):
        log.info("test")
        log.info("test")



# Generated at 2022-06-26 09:22:16.002340
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Set up variables
    logger = logging.getLogger('__main__')
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logging_handler_1)
    logger.debug("log test")

# Generated at 2022-06-26 09:22:23.980396
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:25.888300
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # the test case 0
    with tqdm_logging_redirect() as pbar:
        pass

# Generated at 2022-06-26 09:22:48.163764
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    def test_case_1():
        with logging.getLogger(__name__).getChild("test_case_1").getChild("1") as log:
            with logging_redirect_tqdm(loggers=[log]):
                log.info("testing")

    def test_case_2():
        log = logging.getLogger(__name__).getChild("test_case_2")
        with logging_redirect_tqdm(loggers=[log]):
            log.info("testing")

    def test_case_3():
        log = logging.getLogger(__name__).getChild("test_case_3")
        with logging_redirect_tqdm(tqdm_class=std_tqdm):
            log.info("testing")


# Generated at 2022-06-26 09:22:56.140598
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger('test_logging_redirect_tqdm')

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:23:09.133394
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm_logging import (
        logging_redirect_tqdm,
        _get_first_found_console_logging_handler,
        _is_console_logging_handler)

    loggers = [logging.getLogger("log")]
    logging.basicConfig(level=logging.INFO)
    orig_handlers = loggers[0].handlers
    with logging_redirect_tqdm(loggers=loggers):
        assert orig_handlers != loggers[0].handlers
        assert _is_console_logging_handler(_get_first_found_console_logging_handler(loggers[0].handlers))

# Generated at 2022-06-26 09:23:20.510718
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=2) as t:
        logging.warning("hello")
        t.update()
        logging.error("world")
        t.update()

    with tqdm_logging_redirect(total=2, file=sys.stderr) as t:
        logging.warning("hello")
        t.update()
        logging.error("world")
        t.update()

    with tqdm_logging_redirect(total=2, file=sys.stdout) as t:
        logging.warning("hello")
        t.update()
        logging.error("world")
        t.update()

# Generated at 2022-06-26 09:23:26.821074
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    with tqdm_logging_redirect(desc= 'Test_01', total=10) as pbar:
        for i in range(10):
            pbar.update(i+1)
            if i == 4:
                pbar.write('console logging redirected to tqdm_logging_redirect().')



# Generated at 2022-06-26 09:23:33.524542
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        # with logging_redirect_tqdm():
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:23:40.738665
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:23:47.803308
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        logger.info('1')  # redirected to tqdm.write
        logger.info('2')  # redirected to tqdm.write

    logger.info('3')  # not redirected



# Generated at 2022-06-26 09:23:57.668291
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm

    def main():
        with tqdm_logging_redirect(tqdm_class=tqdm.std.tqdm):
            for i in range(3):
                logging.info('TqdmLoggingRedirect works!')

    main()
    logging.info('Done.')


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:24:01.379400
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm as tqdm
    import logging

    with tqdm_logging_redirect(total=9, file=sys.stdout):
        for i in range(9):
            if i == 4:
                logging.info('console logging redirected to `tqdm.write()`')


# Generated at 2022-06-26 09:24:27.149464
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        with logging_redirect_tqdm():
            assert logging.getLogger().handlers == [_TqdmLoggingHandler()]
    finally:
        assert logging.getLogger().handlers == []



# Generated at 2022-06-26 09:24:32.086031
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # logger is not specified and tqdm_class is not specified.
    with tqdm_logging_redirect("test", dynamic_ncols=True) as pbar:
        assert isinstance(pbar, std_tqdm)



# Generated at 2022-06-26 09:24:42.743658
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # basic config
    logging.basicConfig(level=logging.INFO)

    # log with logger
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=10, desc='testing') as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


    # log with root logger
    with tqdm_logging_redirect(total=10, desc='testing') as pbar:
        for i in pbar:
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:24:52.380574
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange, tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        'test_tqdm_logging_redirect',
        tqdm=trange, loggers=[LOG],
    ):
        for i in trange(3):
            if i == 2:
                LOG.info('Console logging redirected to `tqdm.write()`')
        LOG.info('Console logging redirected to `tqdm.write()`')



# Generated at 2022-06-26 09:24:59.855371
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from .tests import setup_logging_test

    LOG = setup_logging_test(__name__)

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-26 09:25:03.740224
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test function logging_redirect_tqdm.

    Test Cases
    ----------
    - Test Case #0: import tqdm and test tqdm_logging_handler_0
    """
    logging_redirect_tqdm()
    assert tqdm_logging_handler_0

# Generated at 2022-06-26 09:25:14.104589
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-26 09:25:24.816710
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from .tqdm_static import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging restored")
    return False


# Generated at 2022-06-26 09:25:36.719432
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger()
    with tqdm_logging_redirect(
        loggers=[logger], total=10, desc='logger',
        tqdm_class=std_tqdm
    ) as pbar:
        pbar.update()
        logging.debug("debug")
        logging.info("info")
        logging.warning("warning")
        logging.error("error")
        logging.critical("critical")
        pbar.update()
        pbar.update()
        logging.debug("debug")
        logging.info("info")
        logging.warning("warning")
        logging.error("error")
        logging.critical("critical")
        pbar.update()


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:43.782273
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=2) as pbar:
        assert (pbar.n == 0)
        logging.info('foo')
        pbar.update()
        assert (pbar.n == 1)
        logging.info('bar')
        pbar.update()
        assert (pbar.n == 2)



# Generated at 2022-06-26 09:26:35.553796
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # TODO: Generate a parametrized unit test
    log_record = logging.LogRecord(
        name='name_014807578011896',
        level=logging.DEBUG,
        pathname='pathname_099796016',
        lineno='lineno_91469',
        msg='msg_753977357',
        args='args_643770494',
        exc_info=None,
    )
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit(log_record=log_record)



# Generated at 2022-06-26 09:26:40.379012
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=0, desc='foobar') as t:
        assert isinstance(t, std_tqdm)
        assert t.desc == 'foobar'


# Generated at 2022-06-26 09:26:45.868165
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        with tqdm_logging_redirect(total=1, mininterval=0, smoothing=0) as pbar:
            logging.info('Info message')
            pbar.update(1)
    except AttributeError:
        logging.exception('Error')
        raise
    except:  # noqa pylint: disable=bare-except
        logging.info('Info message')


# Generated at 2022-06-26 09:26:56.762786
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def _test_case(loggers, tqdm_class, tqdm_kwargs):
        """
        Test the correct running of tqdm_logging_redirect().
        """
        # assert loggers, 'No handlers in tqdm_logging_redirect'
        # assert tqdm_class, 'No tqdm_class in tqdm_logging_redirect'
        # assert tqdm_kwargs, 'No tqdm_kwargs in tqdm_logging_redirect'

        # Get the number of each of the handler types in the class
        old_console_logging_handlers = [
            handler for handler in loggers.handlers
            if _is_console_logging_handler(handler)]

# Generated at 2022-06-26 09:27:05.466582
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:27:10.595973
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    from io import StringIO
    from contextlib import redirect_stdout

    with StringIO() as buf, redirect_stdout(buf):
        with tqdm_logging_redirect():
            logger = logging.getLogger()
            h = logging.StreamHandler(sys.stdout)
            h.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
            logger.addHandler(h)
            logger.setLevel(logging.INFO)

            logger.info('Testing tqdm_logging_redirect')
            assert "Testing tqdm_logging_redirect" in buf.getvalue()

# Generated at 2022-06-26 09:27:14.747385
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log = logging.getLogger('test_logging_redirect_tqdm')

    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                log.info("test_logging_redirect_tqdm")


# Generated at 2022-06-26 09:27:22.706189
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging  # pylint: disable=redefined-outer-name
    from ..std import tqdm as stdtqdm
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for _ in stdtqdm(range(9)):
            logging.info("Hello world!")



# Generated at 2022-06-26 09:27:27.273075
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(loggers=[logging.getLogger('tqdm_logging_redirect_test')], file=sys.stdout, leave=False) as pbar:
        logging.getLogger('tqdm_logging_redirect_test').info("console logging redirected to `tqdm.write()`")
        pbar.write('hi')

# Generated at 2022-06-26 09:27:35.336829
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    # Log with root logger
    with logging_redirect_tqdm():
        for i in trange(2):
            logging.info("console logging redirected to `tqdm.write()`")

    # Log with a specific logger
    log = logging.getLogger("test_logger")
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm(loggers=[log]):
        for i in trange(2):
            logging.info("console logging redirected to `tqdm.write()`")
            log.info("console logging redirected to `tqdm.write()`")

    # Log with a specific logger and specific stream
    log = logging.getLogger("test_logger")
    log.setLevel(logging.INFO)

# Generated at 2022-06-26 09:29:06.018169
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Sanity test for function tqdm_logging_redirect
    """
    try:
        import logging
        LOG = logging.getLogger(__name__)
    except ImportError:
        pass
    else:
        with tqdm_logging_redirect():
            LOG.info("hello world")

# Generated at 2022-06-26 09:29:14.778463
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    fh = logging.FileHandler("tqdm.log")
    logger = logging.getLogger("tqdm")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(fh)
    logger.info("hello world")
    logger.debug("hello world")
    logger.warning("hello world")
    logger.error("hello world")
    logger.critical("hello world")


# Generated at 2022-06-26 09:29:26.840870
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    def log_tqdm():
        with logging_redirect_tqdm():
            for _ in tqdm(range(10)):
                logging.info("There is no spoon")

    def log_std():
        with logging_redirect_tqdm():
            for _ in range(10):
                logging.info("There is no spoon")

    def log_multi():
        with logging_redirect_tqdm([logging.root, logging.getLogger("log2")]):
            for _ in range(10):
                logging.info("There is no spoon")
                logging.getLogger("log2").info("There is no spoon")

    def log_nohandler():
        log = logging.getLogger("log")
        log.handlers

# Generated at 2022-06-26 09:29:38.055948
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=undefined-variable
    # pylint: disable=function-redefined
    # pylint: disable=redefined-outer-name
    import logging
    import sys
    from tqdm.auto import tqdm as tqdm_tqdm
    from tqdm.contrib import logging as tqdm_logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging.logging_redirect_tqdm():
            for i in tqdm_tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:29:48.126851
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    log_msg = "I'm a logger!"

    with open('test.log', 'w') as log_file:
        file_handler = logging.FileHandler(log_file)
        LOG.addHandler(file_handler)
        with logging_redirect_tqdm():
            for i in trange(5):
                if i == 4:
                    LOG.info(log_msg)

        file_handler.close()
        assert LOG.handlers == [], \
            'logging handlers not restored upon exit from logging_redirect_tqdm'
        with open('test.log') as log_file:
            log_file

# Generated at 2022-06-26 09:29:52.295012
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.info("Test message: logging_redirect_tqdm")



# Generated at 2022-06-26 09:29:58.829669
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(
        loggers=[LOG],
        tqdm_class=std_tqdm,
        desc="test_tqdm_logging_redirect",
        total=100
    ):
        for i in range(10):
            LOG.info("console logging redirected to `tqdm.write()`")
            if i == 4:
                print("this is unrelated to logging")
        print("end tqdm_logging_redirect")


# Generated at 2022-06-26 09:30:07.220994
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        with std_tqdm.std.WrappedStringIO() as io:
            with logging_redirect_tqdm(
                loggers=[logging.root],
                tqdm_class=std_tqdm.std.WrappedTqdm
            ):
                LOG = logging.getLogger(__name__)
                LOG.info('message')
            assert io.getvalue() == 'message\n'
    except:  # noqa pylint: disable=bare-except
        print('WARN: test__TqdmLoggingHandler_emit failed')

