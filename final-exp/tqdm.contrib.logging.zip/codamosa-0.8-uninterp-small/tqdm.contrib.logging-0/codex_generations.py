

# Generated at 2022-06-26 09:20:16.553480
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=1, desc='Progress:') as pbar:
        logging.info('Batch 1')
        pbar.update()
        logging.info('Batch 2')
        pbar.update()



# Generated at 2022-06-26 09:20:27.225591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tempfile import NamedTemporaryFile
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Sanity check
    try:
        from nose2 import tools
    except ImportError:
        from nose.tools import assert_equal, assert_in

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    with NamedTemporaryFile(mode='r+') as temp:
        temp_filename = temp.name
        with tqdm_logging_redirect(
                total=5, file=temp, desc='pbar',
                loggers=[logging.getLogger()],
                tqdm_class=std_tqdm):
            logging.info("info line")
            logging.error("error line")
            logging

# Generated at 2022-06-26 09:20:32.486531
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    log = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
        desc="Progress",
        total=9,
    ) as pbar:
        for i in pbar:
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:20:38.432564
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    with tqdm.tqdm(total=10) as pbar:
        with logging_redirect_tqdm(loggers=[logging.root], tqdm_class=tqdm.tqdm):
            logging.info('logging redirected to tqdm.write()')



# Generated at 2022-06-26 09:20:50.102570
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .common import closable_named_temporary_file
    from .tests_tqdm import _range
    from .tests_tqdm import pretest_posttest

    # Test for helper function _is_console_logging_handler
    def test_is_console_logging_handler():
        handler = logging.StreamHandler()
        assert _is_console_logging_handler(handler) is True
        handler = logging.FileHandler('test.log')
        assert _is_console_logging_handler(handler) is False

    test_is_console_logging_handler()

    # Test for helper function _get_first_found_console_logging_handler
    def test_get_first_found_console_logging_handler():
        handler = logging.StreamHandler()
        assert handler == _get_first_found_

# Generated at 2022-06-26 09:21:00.346837
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    logging.basicConfig(level=logging.INFO)
    log_file = 'test_tqdm_logging_redirect.log'
    file_handler = logging.FileHandler(log_file)
    logging.root.addHandler(file_handler)
    with tqdm_logging_redirect() as tqdm_pbar:
        logging.info('Console message redirected to tqdm.write()')
        tqdm_pbar.write('Direct tqdm.write()')

    # Check file
    with open(log_file, 'r') as f:
        log_file_content = f.read()
    assert log_file_content == \
        'Console message redirected to tqdm.write()\n'
    logging.root.removeHandler(file_handler)



# Generated at 2022-06-26 09:21:11.871107
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import re

    # Create logger and handler, but don't add handler
    # to logger yet.
    LOG = logging.getLogger(__name__)
    stream_handler = logging.StreamHandler()
    LOG.addHandler(stream_handler)

    # Enter context manager.
    with tqdm_logging_redirect(loggers=[LOG], total=4):
        # Create message with logging.
        for i in range(4):
            LOG.info('Test message ' + str(i))

    # Get message from stream_handler.
    stream_handler.flush()
    msg = stream_handler.stream.getvalue()

    # Check that the message has the correct format.
    regex = r'\[ {0,2}\d*/4\] Test message \d+\n'

# Generated at 2022-06-26 09:21:22.144791
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=5, file=sys.stdout, unit_scale=1, unit='epoch') as pbar:
        assert sys.stdout.buffer is not None
        LOG = logging.getLogger(__name__)
        LOG.info("Test with progressbar")
    loglines = pbar.write.buf.strip().splitlines()
    assert len(loglines) == 2
    # logging output for epoch 5 will be redirected to tqdm.write
    assert loglines[-1] == "INFO:__main__:Test with progressbar"
    #logging output for epoch 5 will be redirected to tqdm.write

# Generated at 2022-06-26 09:21:28.678946
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(format='%(asctime)s %(message)s', level=logging.INFO)
    logger = logging.getLogger("")
    logger.info("some message")
    logger.info("start")
    with tqdm_logging_redirect():
        logger.info("console logging redirected to `tqdm.write()`")
    logger.info("end")

# Generated at 2022-06-26 09:21:33.413045
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    log_record_1 = logging.getLogger().makeRecord('Name', 'INFO', 'Path', 1,
                                                  "Message-1", (), None, None)
    tqdm_logging_handler_1.emit(log_record_1)


# Generated at 2022-06-26 09:21:48.596091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm

    msg = 'console logging redirected to `tqdm.write()`'

    # setup logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    LOG.propagate = False
    logging_stream = tqdm.std.capture_output()

    # redirect logging
    with logging_redirect_tqdm():
        LOG.info(msg)

    # test output
    captured_stdout = logging_stream.getvalue()
    assert captured_stdout.strip() == msg

    # reset logging
    logging.disable(logging.NOTSET)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 09:21:55.509789
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    record = logging.LogRecord('name', 'level', 'pathname',
                               'lineno', 'msg', 'args', 'exc_info')
    try:
        tqdm_logging_handler_0.emit(record)
        tqdm_logging_handler_0.flush()
    except Exception:
        pass


# Generated at 2022-06-26 09:21:59.835488
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger('TestCase')
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)
    logger.info('Call emit')



# Generated at 2022-06-26 09:22:08.999966
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log_format = '%(name)s %(levelname)s %(message)s'
    logging.basicConfig(format=log_format, level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

    with logging_redirect_tqdm():
        for i in range(9):
            logger.debug('debug')
            logger.info('info')
            logger.warning('warning')
            logger.error('error')
            logger.critical('critical')


# Generated at 2022-06-26 09:22:14.386258
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm
    logging.root.handlers = [logging.StreamHandler()]
    with logging_redirect_tqdm():
        logging.info(u"unicode")
    # logging.info(u"unicode")
    # logging_redirect_tqdm()
    # logging.info(u"unicode")
    logging.handlers = []


# Generated at 2022-06-26 09:22:26.330184
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import logging
    from .tqdm import tqdm

    class SimpleTest(object):
        def __init__(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.INFO)

            # create console handler and set level to info
            handler = logging.StreamHandler()
            handler.setLevel(logging.INFO)
            formatter = logging.Formatter("%(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            logger.addHandler(handler)

            # create error file handler and set level to error
            handler = logging.FileHandler("test.log", "w", encoding=None, delay="true")
            handler.setLevel(logging.ERROR)

# Generated at 2022-06-26 09:22:36.161393
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def do_work():
        LOG.info("logging redirected to progress bar")

    with tqdm_logging_redirect(loggers=None, tqdm_class=std_tqdm, desc="test") as pbar:
        do_work()
        pbar.update()

    assert pbar.n == 1
    assert pbar.desc == "test"

# Generated at 2022-06-26 09:22:44.124061
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10,
                               unit='B', unit_scale=True,
                               desc='test') as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info('test')
        pbar.update(5)
        LOG.debug('debug')
    try:
        with tqdm_logging_redirect(total=10):
            raise ValueError
    except ValueError:
        pass

# Generated at 2022-06-26 09:22:52.025139
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tests_tqdm import with_setup, _range, pretest_posttest

    # logging.basicConfig(level=logging.INFO)  # Default

    pbar = tqdm_logging_redirect()  # type: ignore
    pbar = tqdm_logging_redirect(total=50)  # type: ignore
    pbar = tqdm_logging_redirect()  # type: ignore

    with pretest_posttest():
        with tqdm_logging_redirect(total=50):  # type: ignore
            for i in _range(9):
                assert getattr(pbar, 'rate', None) is None
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:22:58.484360
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in tqdm(range(9)):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:23:13.275303
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    log = io.StringIO()
    handler = logging.StreamHandler(log)

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    tqdm_logging_redirect(loggers=[logger])
    logger.info("This should go to tqdm.write")

    log.seek(0)
    assert "This should go to tqdm.write" == log.read()

    log_1 = io.StringIO()
    handler_1 = logging.StreamHandler(log_1)

    logger_1 = logging.getLogger()
    logger_1.setLevel(logging.INFO)


# Generated at 2022-06-26 09:23:20.667323
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect() as pbar, \
            logging_redirect_tqdm(tqdm_class=pbar.__class__):
        logging.info("Logging with pbar info")
        pbar.update()
        logging.debug("Logging with pbar debug")
        logging.info("Logging with pbar info")


# Generated at 2022-06-26 09:23:25.264027
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Logging with default settings
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logging_redirect_tqdm():
        logger.info("Hello World!")


# Generated at 2022-06-26 09:23:30.357295
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = sys.stdout
    tqdm_logging_handler.emit(logging.LogRecord(
        'tqdm', logging.INFO, None, 1, 'test message', (), None))
    # if tqdm_logging_handler.tqdm_class is std_tqdm:
    #     assert sys.stdout.getvalue() == 'test message\n'


# Generated at 2022-06-26 09:23:41.409103
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Only test if tqdm and logging is installed
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in pbar(range(9)):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
    with tqdm_logging_redirect() as pbar:
        for i in pbar(range(9)):
            if i == 2:
                logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:23:47.900179
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    test_case_0()

    from io import StringIO
    from unittest import TestCase, TestLoader, TextTestRunner

    class TestLoggingRedirectTqdm(TestCase):
        """
        Test class for function logging_redirect_tqdm
        """
        def test_example(self):
            """
            Test example `logging_redirect_tqdm : Examples`
            """
            import logging
            from tqdm import trange
            from tqdm.contrib.logging import logging_redirect_tqdm

            LOG = logging.getLogger(__name__)

            import sys
            if sys.version_info[0] == 2:
                from StringIO import StringIO  # noqa
            else:
                from io import StringIO

            with StringIO() as stream:
                redirect_

# Generated at 2022-06-26 09:23:53.134419
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with tqdm_logging_redirect(loggers=[logger]) as pbar:
        logger.info("test")

# Generated at 2022-06-26 09:24:00.895051
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_1.emit(logging.LogRecord(
        name=None,
        level=logging.INFO,
        pathname=None,
        lineno=0,
        msg=None,
        args=None,
        exc_info=None,
        func=None,
        sinfo=None))


# Generated at 2022-06-26 09:24:10.360118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            loggers=None,
            tqdm_class=std_tqdm,
            **{"bar_format": "%t/%s %e",
               "unit_scale": True,
               "leave": True,
               "desc": "Loading"}) as pbar:
        for i in pbar(range(100)):
            logging.info("Fuck you")
            logging.debug("%s", i)
            logging.error("%s", i)

# Generated at 2022-06-26 09:24:17.631005
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # run function logging_redirect_tqdm
    with logging_redirect_tqdm():
        logging.info("redirected logging to {}".format(sys.stdout))
    # run logging_redirect_tqdm with arguments
    # with logging_redirect_tqdm(loggers=[logging.root]):
        # logging.info("redirected logging to {}".format(sys.stdout))
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        logging.info("redirected logging to {}".format(sys.stdout))

# Generated at 2022-06-26 09:24:35.671674
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log_record = logging.LogRecord('name', logging.DEBUG, 'pathname', 1,
                                   'msg', None, None)
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    buf = sys.stdout
    tqdm_logging_handler_0.setStream(buf)
    tqdm_logging_handler_0.setFormatter(logging.Formatter('%(message)s'))
    tqdm_logging_handler_0.emit(log_record)
    assert buf.getvalue() == 'msg\n'


# Generated at 2022-06-26 09:24:42.090800
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .cases.stdout_redirect_logging_tqdm import test_case_0
    from .cases.stdout_redirect_logging_tqdm import test_case_1
    from .cases.stdout_redirect_logging_tqdm import test_case_2

    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-26 09:24:52.084960
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        print("OK")


if __name__ == "__main__":
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:24:56.638422
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.emit(None)



# Generated at 2022-06-26 09:25:01.694398
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        logging.info("a")
        assert False
    except AttributeError:
        pass  # logging.info not called outside of logger context
    with logging_redirect_tqdm():
        logging.info("b")


# Generated at 2022-06-26 09:25:07.906620
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_emit = _TqdmLoggingHandler()
    record_dict = {}
    record_dict['record_message'] = 'foo'
    tqdm_logging_handler_emit.emit(record_dict)


# Generated at 2022-06-26 09:25:16.995478
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .main import tqdm

    logging.basicConfig(
        level=logging.INFO,
        format='%(name)s %(levelname)s %(message)s')
    for i in tqdm_logging_redirect(range(9),
                                   loggers=[logging.getLogger(__name__)],
                                   desc='Test',
                                   ascii=True,
                                   leave=True,
                                   disable=False):
        if i == 4:
            assert any(isinstance(h, tqdm.tqdm)
                       for h in logging.getLogger().handlers)
            logging.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-26 09:25:26.924789
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect() as pbar:
        assert pbar.__class__ == std_tqdm

    with tqdm_logging_redirect(desc="Test case 0") as pbar:
        assert pbar.__class__ == std_tqdm

    with tqdm_logging_redirect(total=10) as pbar:
        assert pbar.__class__ == std_tqdm

    with tqdm_logging_redirect(desc="Test case 2", total=100) as pbar:
        assert pbar.__class__ == std_tqdm


# Generated at 2022-06-26 09:25:32.156892
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOGGER = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    # check that non-redirected loggy works
    LOGGER.info("Info: 1")
    assert True

    # Wrap logging.root Logger with console output redirection to tqdm.write()
    with logging_redirect_tqdm():
        # Set logging level of wrapped logger to DEBUG (instead of INFO by
        # default) to check redirection of DEBUG messages as well
        LOGGER.setLevel(logging.DEBUG)
        LOGGER.info("Info: 2")
        LOGGER.debug("Debug: 1")
    # check that restored loggy works
    LOGGER.info("Info: 3")
    assert True



# Generated at 2022-06-26 09:25:39.252193
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    from test_tqdm import closing

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig()
        pbar = closing(tqdm(total=9))
        with tqdm_logging_redirect(loggers=[LOG], tqdm_class=tqdm):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                else:
                    LOG.info("this is a log message")
                pbar.update()
        # logging restored