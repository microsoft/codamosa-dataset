

# Generated at 2022-06-26 09:20:16.261408
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import logging
    from ..std import sys
    from ..std import StringIO
    from .stdtrange import trange

    # Test case: as context manager
    # ---------------------------------------

# Generated at 2022-06-26 09:20:20.273724
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
        Unit test for function logging_redirect_tqdm
    """
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.FileHandler(__name__))

    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)

    # Note: using `with` as context manager
    with tqdm_logging_redirect(loggers=[logger]):
        logger.debug('Log debug message')
        logger.info('Log info message')
        logger.warning('Log warning message')
        logger.error('Log error message')
        logger.critical('Log critical message')

# Generated at 2022-06-26 09:20:30.062485
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # import logging
    # from tqdm import tqdm
    # from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    with tqdm_logging_redirect(
            file=sys.stdout, unit="B", unit_scale=True, miniters=1,
            loggers=[logging.getLogger()]):
        for i in range(1, 10):
            print(i)
        # with logging_redirect_tqdm():
        #     for i in tqdm(range(1, 10), file=sys.stdout):
        #         pass

if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:20:37.190420
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('tqdm.contrib.logging.logging_redirect_tqdm')
    logger.info('logging test')
    with logging_redirect_tqdm():
        logger.info('logging redirect test')
    logger.info('logging test')

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:20:45.992903
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOGGER = logging.getLogger('test_logger')
    LOGGER.setLevel(logging.INFO)
    LOGGER.addHandler(logging.StreamHandler(sys.stderr))

    with logging_redirect_tqdm():
        for i in range(5):
            LOGGER.info("This is a test")
    with logging_redirect_tqdm(loggers=[logging.getLogger('test_logger')]):
        for i in range(5):
            LOGGER.info("This is a test")
    LOGGER.info("This is a test")


# Generated at 2022-06-26 09:20:54.194014
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Check logging_redirect_tqdm import
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Check logging_redirect_tqdm context manager
    with logging_redirect_tqdm() as tqdm_logging_handler_1:
        pass

    # Check additional logger support
    with logging_redirect_tqdm([logging.getLogger('test_logging_redirect_tqdm')]) as tqdm_logging_handler_1:
        pass


# Generated at 2022-06-26 09:20:59.702149
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging, logging.handlers

    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    logging_listener_0 = logging.handlers.MemoryHandler(1024,
                                                        target=tqdm_logging_handler_0)
    logging_listener_0.push_application()
    logging.info('Give me some log messages.')


# Generated at 2022-06-26 09:21:10.592521
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.root.handlers = []  # type: List[logging.Handler]
    logger_0 = logging.getLogger(__name__ + 'logger_0')
    logger_1 = logging.getLogger(__name__ + 'logger_1')
    logger_0.level = logger_1.level = logging.DEBUG
    with tqdm_logging_redirect(loggers=[logger_0], miniters=1, mininterval=0.1):
        logger_0.info('message')
        logger_1.info('message')  # should still be streamed to stdout
        for i in range(10):
            logger_0.info('message ' + str(i))
        logger_0.warning('message')


if __name__ == '__main__':
    from .main import main


# Generated at 2022-06-26 09:21:18.758142
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # TODO: Add some test code
    import logging
    logger = logging.getLogger(__name__)
    msg = 'Test message'

    with tqdm_logging_redirect() as pbar:
        logger.info(msg)
        assert pbar.total_refresh_time == 0
        assert pbar.miniters == 1

    # tqdm_logger_redirect_class should be reset
    logger.info(msg)
    assert pbar.total_refresh_time > 0
    assert pbar.miniters is not None

# Generated at 2022-06-26 09:21:27.241286
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib import tenumerate

    with tqdm_logging_redirect(total=6, desc='Logging') as pbar:
        i = 0
        while i < 5:
            i += 1
            pbar.update(1)
            print('\rtic: '+ str(i))

    list(tenumerate(['a', 'b']*6, desc='Logging'))
    with tqdm_logging_redirect(total=6, desc='Logging') as pbar:
        list(tenumerate(['a', 'b']*6, desc='Logging'))

# Generated at 2022-06-26 09:21:42.731332
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm

    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    msg = "Test message"
    record = logging.LogRecord(name="record0", level=logging.INFO,
        pathname="path0", lineno=1, msg=msg,
        args=None, exc_info=None)
    # Called without stream
    tqdm_logging_handler_1.emit(record)
    # Called with stream
    tqdm_logging_handler_1.stream = sys.stderr
    tqdm_logging_handler_1.emit(record)
    tqdm_logging_handler_1.stream = sys.stdout
    tqdm_logging_handler_1.emit(record)

# Generated at 2022-06-26 09:21:44.865259
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc='TEST'):
        for _ in trange(2):
            LOG.info('TEST_LOG')



# Generated at 2022-06-26 09:21:48.850964
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                # noqa pylint: disable=logging-not-lazy
                logging.info('console logging redirected to `tqdm.write()`')


# Generated at 2022-06-26 09:21:53.247461
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger("TQDM")
    logger.setLevel(logging.INFO)
    orig_streams = sys.stdout, sys.stderr
    with tqdm_logging_redirect(loggers=logger, total=9) as pbar:
        for i in range(9):
            logger.info("logging redirected to tqdm.write")
    assert not pbar.n
    assert not pbar.last_print_n
    sys.stdout, sys.stderr = orig_streams

if __name__ == "__main__":
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:22:01.149844
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    loggers=[logging.root]
    tqdm_class=tqdm

    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-26 09:22:07.825689
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:22:11.585702
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with logging_redirect_tqdm(loggers=[logging.root]):
        logging.info("tqdm-logging")
        logging.info("tqdm-logging")



# Generated at 2022-06-26 09:22:13.946638
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        tqdm_logging_handler_0 = _TqdmLoggingHandler()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-26 09:22:25.888248
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test for tqdm_logging_redirect
    """
    from tqdm._utils import _term_move_up
    from tqdm.auto import tqdm
    from tqdm.utils import _range
    from .test_tqdm_notebook import test_tqdm
    logging.basicConfig(level=logging.INFO)
    loggers = [logger for logger in (logging.getLogger(__name__),)]

# Generated at 2022-06-26 09:22:38.118547
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("Nothing changes")
        assert sys.stdout.flush != std_tqdm.write

    res = []

    def my_flush():
        res.append(1)

    sys.stdout.flush = my_flush
    with logging_redirect_tqdm():
        logging.info("Everything changes")
        assert sys.stdout.flush == std_tqdm.write
    assert len(res) == 1

    res = []
    sys.stdout.flush = my_flush
    with logging_redirect_tqdm([logging.getLogger("test")]):
        logging.info("Nothing changes")
        assert sys.stdout.flush == my_

# Generated at 2022-06-26 09:23:01.340543
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    np, na = range, len

    with tqdm_logging_redirect(total=10):
        for i in np(20):
            logging.info(i)
            time.sleep(.1)
    with tqdm_logging_redirect(total=10, disable=True):
        for i in np(20):
            logging.info(i)
            time.sleep(.1)

    for total in np(5):
        with tqdm_logging_redirect(total=total) as pbar:
            pbar.reset()
            for i in np(total):
                time.sleep(.1)
                pbar.update(1)

    with tqdm_logging_redirect() as pbar:
        time.sleep(.1)
        p

# Generated at 2022-06-26 09:23:12.447667
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Disable the logger
    logging.disable(logging.CRITICAL)

    # Globals
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    custom_logger = logging.getLogger("logging_redirect_tqdm")
    custom_logger.handlers = [tqdm_logging_handler_0]
    with tqdm_logging_redirect(
        loggers=[custom_logger],
        tqdm_class=_TqdmLoggingHandler
    ) as tqdm_logging_handler_1:
        tqdm_logging_handler_1.write("tqdm_logging_handler_1 with custom logger says hello")
        tqdm_logging_handler_1.flush()


# Generated at 2022-06-26 09:23:24.085034
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm

    import logging
    logging.basicConfig(level=logging.INFO)

    # Test that logging something ends up in the terminal
    for i in range(3):
        logging.info("Testing logging in tqdm_logging_redirect")

    # Now redirect logging to tqdm
    with tqdm.tqdm_logging_redirect():
        # Test that logging something ends up in tqdm
        for i in range(3):
            logging.info("Testing logging in tqdm_logging_redirect")

    # Test that logging something ends up in the terminal
    for i in range(3):
        logging.info("Testing logging in tqdm_logging_redirect")


if __name__ == '__main__':

    test_tqdm_logging_red

# Generated at 2022-06-26 09:23:32.951100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # setup
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with logging_redirect_tqdm(loggers=loggers, tqdm_class=std_tqdm):
        tqdm_handler = _TqdmLoggingHandler()
        orig_handler = _get_first_found_console_logging_handler(logging.root.handlers)
        assert orig_handler is not None
        tqdm_handler.setFormatter(orig_handler.formatter)
        tqdm_handler.stream = orig_handler.stream
        assert len(logging.root.handlers) > 0

# Generated at 2022-06-26 09:23:42.471227
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    from tqdm import tqdm
    import logging, sys

    @contextmanager
    def redirect_tqdm_logging(loggers):
        old_handlers = [logger.handlers for logger in loggers]

# Generated at 2022-06-26 09:23:50.711941
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test logging_redirect_tqdm.
    """
    import logging
    logging.basicConfig(level=logging.INFO)
    for logger in [logging.getLogger(), logging.getLogger('foo')]:
        with logging_redirect_tqdm([logger]):
            logger.info('logging redirected to `tqdm.write()`')
            # logging.info('logging redirected to `tqdm.write()`')
        # logging restored
    logging.info('logging NOT redirected to `tqdm.write()`')



# Generated at 2022-06-26 09:23:58.770880
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0_emit_0 = tqdm_logging_handler_0.emit()
    tqdm_logging_handler_0_emit_1 = tqdm_logging_handler_0.emit()


# Generated at 2022-06-26 09:24:03.615970
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect(
            loggers=[LOG],
            # desc='logging_redirect_tqdm',
            # total=9
            ) as pbar:
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-26 09:24:13.080608
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # noqa
    # type: () -> None
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # `logging_redirect_tqdm()` successfully redirects console logging without tqdm
    try:
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                LOG.info("console logging redirected to `tqdm.write()`: {0}"
                         .format(i))
    except Exception as e:
        raise e

    # `logging_redirect_tqdm()` successfully redirects console logging with tqdm

# Generated at 2022-06-26 09:24:24.140531
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.tests import pretest_posttest_test, TestCase
    from tqdm.tqdm import tqdm as tqdm_tqdm
    import logging

    class LoggingRedirectTqdmTest(TestCase):
        """ Tests for `tqdm_logging_redirect` """

        def check_logging_redirect(self, log_level, expected_level_name):
            with tqdm_tqdm() as pbar:
                pbar.write('pre-logging test')

                with logging_redirect_tqdm(
                    loggers=[logging.getLogger()],
                    tqdm_class=tqdm_tqdm
                ):
                    logging.log(log_level, 'logging test')

                pbar.write('post-logging test')



# Generated at 2022-06-26 09:24:53.724868
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Configure logger
    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.INFO)

    # Instantiate logger
    logger_0 = logging.getLogger(__name__)

    # Init input args and kwargs
    input_args = [10]
    input_kwargs = {'bar_format': '{desc}{r_bar}'}
    input_kwargs['loggers'] = [logging.root]

    with tqdm_logging_redirect(*input_args, **input_kwargs) as pbar:
        for i in pbar:
            logger_0.info("console logging redirected to `tqdm.write()`")
            logger_0.info("number %d", i)

# Generated at 2022-06-26 09:24:58.872593
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def func():
        return None

    with tqdm_logging_redirect():
        func()


if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:05.053753
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.root.handlers.clear()

    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.setLevel(logging.DEBUG)

    tqdm_obj = std_tqdm()
    tqdm_logging_handler.stream = tqdm_obj
    tqdm_logging_handler.emit(logging.LogRecord('name', logging.DEBUG, 'pathname', 1, 'msg',
                                                [], None))



# Generated at 2022-06-26 09:25:16.185070
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    import time

    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3

    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # stdlib logging supports both streams and files (tqdm.write only supports
    # streams, so we need to test redirection for both)
    # Also, logging supports being redirected to stderr, so we need to test
    # that too.

# Generated at 2022-06-26 09:25:24.569842
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOGGER = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        desc='test_tqdm_logging_redirect',
        total=10,
        loggers=[LOGGER],
    ):
        LOGGER.info('test_tqdm_logging_redirect')
        trange(1, 10)

# Generated at 2022-06-26 09:25:28.794717
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    trange_kwargs = {"desc": "TEST:", "units": "units"}
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        for i in trange(9):
            if i == 4:
                with logging_redirect_tqdm():
                    for j in trange(9, **trange_kwargs):
                        if j == 4:
                            LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored
        # logging restored


# Generated at 2022-06-26 09:25:35.341489
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import std_tqdm
    std_tqdm.write("")
    with logging_redirect_tqdm():
        logging.info("logging loop...")
        for i in range(3):
            logging.info("%i", i)
            time.sleep(0.1)
    std_tqdm.write("\n")



# Generated at 2022-06-26 09:25:45.448362
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(
        total=100,
        loggers=[logging.getLogger(__name__)],
        desc=__name__ + ': ',
        unit='B',
        unit_scale=True) as pbar:
        for i in pbar:
            if i == 10:
                logging.info("hello")
            if i == 20:
                logging.debug("debug")
            if i == 30:
                logging.warning("warning")
            if i == 40:
                logging.error("error")
            if i == 50:
                logging.critical("critical")



# Generated at 2022-06-26 09:25:55.664338
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # check if logging_redirect_tqdm can handle logger
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.INFO)
    test_logger.addHandler(logging.StreamHandler())

    # check if logging_redirect_tqdm can handle a tqdm class
    class TqdmTestClass(std_tqdm):
        def write(self, string):
            pass

    with logging_redirect_tqdm([test_logger], tqdm_class=TqdmTestClass):
        test_logger.info("TESTING")



# Generated at 2022-06-26 09:26:07.104587
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import tqdm
    import logging
    try:
        import mock
    except ImportError:
        from unittest import mock
    from .test_tqdm import pretest_posttest, UnitRes


# Generated at 2022-06-26 09:26:52.000591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(10):
            pbar.update(1)

# Generated at 2022-06-26 09:26:55.405236
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
                pbar.write("console logging redirected to `pbar.write()`")
            logging.info("console logging not redirected yet")
            pbar.update()
    logging.info("logging restored")

# Generated at 2022-06-26 09:27:07.029317
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # First, test if the contextmanager works normally
    from io import StringIO
    import logging

    captured_output = StringIO()
    # Patch sys.stdout
    sys.stdout = captured_output

    log = logging.getLogger('test')
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler())

    with logging_redirect_tqdm():
        with tqdm_logging_redirect(total=2, desc="logging_redirect_tqdm"):
            log.info("this is some info log")
            log.warning("this is some warning log")

    sys.stdout = sys.__stdout__
    out = captured_output.getvalue()

# Generated at 2022-06-26 09:27:11.241541
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    #tqdm_logging_redirect(loggers=None, tqdm_class=std_tqdm)
    tqdm_logging_redirect(disable=False, loggers=[logging.root])

# Generated at 2022-06-26 09:27:17.962283
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm import tqdm as std_tqdm

    def _test():
        loggers = logging.getLogger('test'), logging.getLogger('test_asyncio')
        for logger in loggers:
            logger.propagate = False
            logger.setLevel(logging.INFO)
            logger.addHandler(logging.StreamHandler())

        with logging_redirect_tqdm(loggers=loggers, tqdm_class=std_tqdm):
            for logger in loggers:
                logger.warning('Redirected to tqdm')

    _test()



# Generated at 2022-06-26 09:27:26.841907
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    std_tqdm.write("Start")
    with tqdm_logging_redirect() as pbar:
        std_tqdm.write("in with tqdm_logging_redirect as pbar")
        logging.info("test logging_redirect_tqdm")
    std_tqdm.write("out with tqdm_logging_redirect as pbar")
    logging.info("test logging_redirect_tqdm")
    std_tqdm.write("End")

# Run test case
test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:27:32.175215
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            tqdm_class=std_tqdm,
            logger=logger,
            total=10) as pbar:
        for i in range(10):
            logger.info('Hello, world!')


# Unit tests for function logging_redirect_tqdm

# Generated at 2022-06-26 09:27:44.911209
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # GIVEN
    import logging
    import sys
    import contextlib as cl
    with cl.redirect_stdout(sys.stderr):
        logging.basicConfig()
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
    check_assert = True
    # WHEN
    with tqdm_logging_redirect(
            'Test',
            bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}'
            ' - {rate_noinv_fmt}{postfix}',
            loggers=[logger]
    ) as pbar:
        if not pbar.disable:
            check_assert = False
        logging.info('Test - 0')
        pbar.update(1)
        logging.info

# Generated at 2022-06-26 09:27:54.719254
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logging_record_1 = logging.LogRecord(
        name='name', level=1, pathname=__file__,
        lineno=1, msg='msg', args=(),
        exc_info=None, func=None)
    # Test for non-KeyboardInterrupt/SystemExit raise
    tqdm_logging_handler_1.emit(logging_record_1)
    tqdm_logging_handler_1.stream = None
    # Test for KeyboardInterrupt/SystemExit raise
    try:
        raise KeyboardInterrupt
    except KeyboardInterrupt:
        tqdm_logging_handler_1.emit(logging_record_1)

# Generated at 2022-06-26 09:28:05.436845
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    This is a unit test for `logging_redirect_tqdm`
    """
    loggers = [logging.getLogger('test_1')]
    original_handlers_list = [logger.handlers for logger in loggers]
    try:
        with logging_redirect_tqdm(loggers=loggers):
            for logger in loggers:
                for handler in logger.handlers:
                    assert isinstance(handler, _TqdmLoggingHandler), \
                        'logging_redirect_tqdm should work!'
            logging.getLogger('test_1').info("test_1_info")
    finally:
        for logger, original_handlers in zip(loggers, original_handlers_list):
            logger.handlers = original_hand

# Generated at 2022-06-26 09:29:48.152412
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.contrib.logging import _TqdmLoggingHandler
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    try:
        record = logging.LogRecord('name', logging.INFO, 'pathname', 1, 'msg',
                                   (), None, 'func')
        with open('/dev/null', 'w') as fh:
            tqdm_logging_handler_0.stream = fh
            tqdm_logging_handler_0.emit(record)
    except Exception:
        pass


# Generated at 2022-06-26 09:29:57.493649
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm import tqdm as _tqdm  # pylint: disable=unused-import
    except ImportError:
        pass
    else:
        import logging
        import inspect
        LOG = logging.getLogger(__name__)
        LOG.debug("test debug")
        LOG.info("test info")
        with logging_redirect_tqdm():
            LOG.debug("test debug")
            LOG.info("test info")
        with logging_redirect_tqdm(tqdm_class=_tqdm):
            LOG.debug("test debug")
            LOG.info("test info")



# Generated at 2022-06-26 09:30:03.196667
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import warnings

    with warnings.catch_warnings(record=True):
        import logging
        import sys
        from tqdm.contrib.logging import _TqdmLoggingHandler

        tqdm_logging_handler_0 = _TqdmLoggingHandler()
        record_0 = logging.LogRecord("%(name)s", "%(levelno)s", "", "", "", "", "", "", "%(msg)s")

        tqdm_logging_handler_0.emit(record_0)
