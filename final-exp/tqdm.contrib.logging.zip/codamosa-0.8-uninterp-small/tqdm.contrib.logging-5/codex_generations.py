

# Generated at 2022-06-26 09:20:11.119514
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    pass


# Generated at 2022-06-26 09:20:23.071951
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm, trange
    assert sys.stdout.encoding == 'UTF-8', "console output is not UTF-8"
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    with StringIO() as s:
        with tqdm(file=s) as pbar:
            with logging_redirect_tqdm():
                print("hello")
                print("world")
        assert "hello" in str(s.getvalue().replace("\r", ""))
    with StringIO() as s:
        with tqdm(file=s) as pbar:
            with logging_redirect_tqdm(tqdm_class=tqdm):
                print("hello")
                print("world")

# Generated at 2022-06-26 09:20:29.870497
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:20:38.675638
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:20:50.665660
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import six
    import sys
    import tempfile
    if six.PY2:
        from StringIO import StringIO
    else:
        from io import StringIO
    sys.stderr = StringIO()
    sys.stdout = StringIO()
    f = tempfile.NamedTemporaryFile(mode='w', delete=False)
    f.close()
    log_file_path = f.name
    with open(log_file_path, 'w') as log_file:
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        TEST_LOG_FILE_HANDLER = logging.FileHandler(log_file_path)
        TEST_LOG_FILE_HANDLER.setLevel(logging.INFO)
        TEST_LOG_FILE_

# Generated at 2022-06-26 09:20:57.997101
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:21:01.934818
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    with tqdm_logging_redirect(tqdm_class=tqdm) as pbar:
        for i in range(10):
            pass
    return pbar

if __name__ == "__main__":
    import pytest
    pytest.main(["-x", "--timeout=2"] + __file__)

# Generated at 2022-06-26 09:21:13.920650
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test case 1
    with tqdm_logging_redirect() as pbar:
        pbar.update(1)
    # Test case 2
    with tqdm_logging_redirect(
        desc='description'
    ) as pbar:
        pbar.update(1)
    # Test case 3
    with tqdm_logging_redirect(
        desc='description',
        ncols=1
    ) as pbar:
        pbar.update(1)
    # Test case 5
    with tqdm_logging_redirect(
        desc='description',
        mininterval=0.5,
        maxinterval=0.5
    ) as pbar:
        pbar.update(1)
    # Test case 6

# Generated at 2022-06-26 09:21:24.452768
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    debug_count = 0

    # test case for logging_redirect_tqdm
    for i in range(1,10):
        logging.info("test case {}".format(i))
        if i == 4:
            with logging_redirect_tqdm():
                for j in std_tqdm(range(1,10)):
                    logging.debug("console logging redirected to `tqdm.write()`")
                    debug_count += 1
    assert debug_count == 90

    # test case for logging_redirect_tqdm which will redirect logging to a specific logger.
    test_logger = logging.getLogger("test_logger")
    test_logger.setLevel(logging.DEBUG)
    debug_count = 0


# Generated at 2022-06-26 09:21:29.813449
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    n = 5
    with tqdm_logging_redirect(*range(n),
                               tqdm_class=lambda x: std_tqdm(x, leave=False),
                               loggers=[logging.root]) as pbar:
        for i in pbar:
            # do something
            pass

# Generated at 2022-06-26 09:21:40.789727
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create a logging record which yields an error 'Ascii conversion failed'
    # when logging.StreamHandler.emit is called
    import logging
    import sys
    record = logging.LogRecord(
        name='anything',
        level=logging.INFO,
        pathname='anything',
        lineno=0,
        msg='\u05d0',
        args=None,
        exc_info=None)
    # Create the handler and set stream to sys.stderr
    handler = _TqdmLoggingHandler()
    handler.stream = sys.stderr
    # Call emit
    handler.emit(record)

# Generated at 2022-06-26 09:21:48.756703
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:21:51.608694
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.std import tqdm
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:21:54.397376
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_1.emit('Write Hello')


# Generated at 2022-06-26 09:21:59.033161
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # arrange
    import logging
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO, handlers=[
        _TqdmLoggingHandler()])
    logger.info("message in start")
    try:
        # act
        raise ValueError(1)
    except ValueError as e:
        # assert
        logger.exception(e)

# Generated at 2022-06-26 09:22:04.559268
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(desc="test from tqdm.contrib.logging",
                               unit_scale=True, unit='B', unit_divisor=1024) as _:
        # import tqdm.contrib.logging
        tqdm_logging_handler_0 = _TqdmLoggingHandler()

# Generated at 2022-06-26 09:22:13.454412
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        logging_redirect_tqdm(loggers=[LOG])
        with tqdm_logging_redirect(desc="Testing logging redirection",
                                   loggers= [LOG]) as pbar:
            pbar.update(1)
            LOG.info("console logging redirected to `tqdm.write()`")
            LOG.error("error logging redirected to `tqdm.write()`")
            pbar.update(1)

# Generated at 2022-06-26 09:22:25.349048
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    tempLog = logging.getLogger(__name__)

    def testFunc():
        for j in range(3):
            tempLog.info("console logging redirected to `tqdm.write()`")
            for i in trange(9):
                if i == 4:
                    tempLog.info("console logging redirected to `tqdm.write()`")

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            testFunc()
        testFunc()

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:22:37.991694
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    from tqdm.contrib import logging_redirect_tqdm
    with tqdm_logging_redirect(tqdm=std_tqdm):
        logging.info("test")
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        logging.info("test")
    with tqdm_logging_redirect(tqdm=std_tqdm) as pbar:
        pbar.update(1)
        logging.info("pbar")
        pbar.update(1)
        logging.info("pbar")
    with tqdm_logging_redirect(tqdm=std_tqdm) as pbar:
        pbar.update(1)
        logging.info

# Generated at 2022-06-26 09:22:42.786805
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect():
        logging.warn('This is a warning.')

    with tqdm_logging_redirect(unit='batch'):
        logging.warn('This is another warning.')



# Generated at 2022-06-26 09:22:58.188573
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Setup Testing
    log_lines = []
    class FakeTqdm():
        @staticmethod
        def write(*args, **kwargs):
            log_lines.append(args[0])

    with tqdm_logging_redirect(tqdm_class=FakeTqdm):
        logging.info("test case 0")
    assert len(log_lines) == 1
    assert log_lines[0] == "test case 0"

# Generated at 2022-06-26 09:23:08.274431
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()

        # logging restored
        LOG.info("logging restored")

# Unit Test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:23:14.785008
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    record_0 = logging.getLoggerClass()().handle(logging.makeLogRecord({}))
    tqdm_logging_handler_0.emit(record_0)



# Generated at 2022-06-26 09:23:26.754907
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    tqdm_class = type(tqdm_logging_handler_0.tqdm_class)
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    tqdm_handler.setFormatter(logging.Formatter(logging.BASIC_FORMAT,
                                                datefmt='%Y-%m-%d %H:%M:%S,%f'))
    tqdm_handler.stream = sys.stdout
    tqdm_handler.emit(logging.LogRecord(
        name='logging', level=logging.INFO, pathname='/home/user/file.py',
        lineno=12, msg='test', args=(), exc_info=None, func=None))

# Unit test

# Generated at 2022-06-26 09:23:34.003433
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import unittest
    logger = logging.getLogger('tqdm_tests')
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    handler.setFormatter(logging.Formatter('%(message)s'))
    handler.stream = stream
    # test string
    test_string = "foo"
    # add test string to log
    logger.info(test_string)
    # compare this with output
    assert test_string == stream.getvalue().strip()
    # test error
    with unittest.TestCase(method="emit"):
        handler.emit(None)
    # test handling exception

# Generated at 2022-06-26 09:23:39.531112
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:23:47.801973
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:23:57.669576
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def dummy_func(bar):
        bar.update(1)

    # Set up logger
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=5, file=sys.stdout):
        for _ in range(5):
            dummy_func(LOG)
            LOG.info("This should appear in the tqdm bar")



# Generated at 2022-06-26 09:24:03.516423
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    loggers = [logging.root]
    with logging_redirect_tqdm(tqdm_class=trange) as (cb):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    for logger in loggers:
        for handler in logger.handlers:
            assert not _is_console_logging_handler(handler)


# Generated at 2022-06-26 09:24:09.896255
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        with logging_redirect_tqdm():
            for __ in range(4):
                pbar.update(1)
                __log__ = logging.getLogger()
                __log__.info("console logging redirected to `tqdm.write()`")
    # logging.shutdown()



# Generated at 2022-06-26 09:24:42.188591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import closing, StrangeWritesIO
    import logging
    with StrangeWritesIO() as s, closing(std_tqdm(
            bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining},"
            "{rate_fmt}{postfix}]")) as pbar, tqdm_logging_redirect(
                loggers=[logging.root], tqdm=std_tqdm, file=s) as pbar2:
        logging.info('info')
        logging.info('info')
        logging.info('info')
        logging.info('info')
        logging.info('info')
        logging.info('info')
        logging.info('info')
        logging.info('info')

# Generated at 2022-06-26 09:24:45.907703
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.level = loggin

# Generated at 2022-06-26 09:24:51.013726
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:25:02.029466
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:25:15.038264
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._tqdm_test_utils import StringIO, _collections_abc
    import logging
    import time

    # Test that a custom logger can be used with logging_redirect_tqdm
    try:
        tqdm_IO = StringIO()
        logger = logging.getLogger('tqdm_custom_logger')
        logger.setLevel(logging.INFO)

        # This is the simplest handler; it writes all messages
        # to tqdm_IO at the INFO level.
        logger.addHandler(logging.StreamHandler(tqdm_IO))

        with logging_redirect_tqdm(loggers=[logger]):
            logger.info('Test')

        assert tqdm_IO.getvalue().strip() == 'Test'
    finally:
        logger.handlers.clear

# Generated at 2022-06-26 09:25:26.374770
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # self.assertNotIn('tqdm', logging.Logger.manager.loggerDict.keys())
    # Patch the root logger to avoid logging of all tests
    logging.getLogger().handlers = []

    # assert loggers are empty
    assert logging.getLogger().handlers == [], 'Assert loggers are empty'
    with logging_redirect_tqdm():
        # assert that it redirected
        handler = _get_first_found_console_logging_handler(logging.getLogger().handlers)
        assert isinstance(handler, _TqdmLoggingHandler)

    # assert loggers are empty
    assert logging.getLogger().handlers == [], 'Assert loggers are empty'

# Generated at 2022-06-26 09:25:27.783322
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    pass


# Generated at 2022-06-26 09:25:36.264636
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm as std_tqdm
    with tqdm_logging_redirect(tqdm=std_tqdm) as pbar:
        pbar.update(1)

    with tqdm_logging_redirect(tqdm=std_tqdm, ncols=120) as pbar:
        pbar.update(1)

    with tqdm_logging_redirect(tqdm=std_tqdm, unit="B") as pbar:
        pbar.update(1)



# Generated at 2022-06-26 09:25:46.957872
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

# Generated at 2022-06-26 09:25:58.777054
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    import sys
    import tqdm

    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    with redirect_stdout(StringIO()) as redirected_output:
        # Test with optional `loggers` parameter
        with tqdm_logging_redirect(loggers=[logger]):
            logger.debug('hello')

        # Test with optional `tqdm_class` parameter
        with tqdm_logging_redirect(tqdm_class=tqdm.tqdm):
            logger.debug('hello')

        # Test with optional `tqdm_kwargs` parameter

# Generated at 2022-06-26 09:26:47.999321
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    with tqdm_logging_redirect(bar_format="|{bar}|"):
        logging.info("hi")
    with tqdm_logging_redirect(bar_format="{percentage:3.0f}%"):
        logging.info("hi")
    with tqdm_logging_redirect(bar_format="{elapsed}s"):
        logging.info("hi")
    with tqdm_logging_redirect(bar_format="{n_fmt}/{total_fmt} [{n}/{total}]"):
        logging.info("hi")
    with tqdm_logging_redirect(bar_format="{bar} {remaining}{postfix}"):
        logging.info("hi")

# Generated at 2022-06-26 09:26:54.942883
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm_pandas
    from tqdm import tqdm_notebook
    from tqdm import tqdm_gui
    import logging
    import pandas as pd

    # Setup logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    # Setup pandas dataframe
    df = pd.DataFrame({'a': [1, 2, 3, 4]})

    # Success
    with tqdm_logging_redirect():
        LOG.info('Redirecting logging to tqdm.write()')
    with tqdm_logging_redirect(df.a.apply, total=df.shape[0]):
        LOG.info('Redirecting logging to tqdm.write()')

# Generated at 2022-06-26 09:27:03.207540
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm() as pbar:
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        assert pbar is None


# Generated at 2022-06-26 09:27:11.789264
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tqdm
    log = logging.getLogger(__name__)
    tqdm_logging_handler_0 = _TqdmLoggingHandler(tqdm_class=tqdm)
    log.addHandler(tqdm_logging_handler_0)
    log.error("This is a logging error message")
    log.info("This is a logging info message")
    log.removeHandler(tqdm_logging_handler_0)


# Generated at 2022-06-26 09:27:18.604297
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import tqdm

    loggers = [logging.getLogger(__name__)]

    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect(loggers=loggers, smoothing=0.1):
        with tqdm(range(9)) as pbar:
            for i in pbar:
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")

    print("logging restored")
    for i in tqdm(range(9), smoothing=0.1):
        if i == 4:
            logging.info("console logging not redirected")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:27:29.970209
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import sys
    from random import randint
    from tqdm.auto import tqdm

    # loggers to use
    loggers = [logging.getLogger(str(i)) for i in range(2)]


# Generated at 2022-06-26 09:27:36.289798
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test :func:`tqdm.contrib.logging.logging_redirect_tqdm`"""
    from io import StringIO
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.std import tqdm_std as tqdm

    with StringIO() as f:
        with logging_redirect_tqdm():
            logging.info('info')
            tqdm.write('tqdm write')

            tqdm.write('tqdm write...', file=f)
            tqdm.write('tqdm write...', file=sys.stdout)
            tqdm.write('tqdm write...', file=sys.stderr)

            logging.info('info')

# Generated at 2022-06-26 09:27:46.412859
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Try redirecting console logging to `tqdm.write()`.
    """
    import logging

    # Default case
    with logging_redirect_tqdm():
        for i in std_tqdm(range(4)):
            logging.info("hello")

    # Custom loggers
    loggers = [logging.getLogger(__name__)]
    with logging_redirect_tqdm(loggers=loggers):
        for i in std_tqdm(range(4)):
            logging.getLogger(__name__).info("hello")
        for i in std_tqdm(range(4)):
            logging.info("world")

    # Switching logger
    my_logger = logging.getLogger('my-logger')

# Generated at 2022-06-26 09:27:53.525091
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test case for tqdm_logging_redirect
    """
    from tqdm import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        assert pbar.n == 9



# Generated at 2022-06-26 09:28:05.097674
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import random
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stderr'):
        with patch('tqdm.std.tqdm') as mocked_tqdm:
            LOG = logging.getLogger(__name__)
            with logging_redirect_tqdm():
                for _ in trange(10):
                    LOG.info('This is a test')
                    LOG.warn('This is a test')
                    LOG.error('This is a test')
                    LOG.debug('This is a test')
                    LOG.critical('This is a test')


# Generated at 2022-06-26 09:29:35.718519
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    log_record_0 = logging.LogRecord('a', 'INFO', None, None, 'Hello, World!', None, None)

    tqdm_logging_handler_0.emit(log_record_0)

# Generated at 2022-06-26 09:29:44.790317
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with logging.root.handlers:
        logging.root.handlers = [logging.StreamHandler()]
        s = ''.join(str(i) for i in range(10))
        logging.info(s)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                logging.info(i)


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:46.482569
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # test calling function
    logging_redirect_tqdm()


# Generated at 2022-06-26 09:29:54.732555
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('test')
    normalHandler = logging.StreamHandler(sys.stdout)
    logger.handlers = [normalHandler]
    logger.setLevel(logging.INFO)
    try:
        with logging_redirect_tqdm(loggers=[logger]):
            logger.info('test')
    except:
        raise


# Generated at 2022-06-26 09:29:56.754545
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        pass

# Generated at 2022-06-26 09:30:04.937700
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def log(LOG, msg):
        for i in range(3):
            LOG.info(msg)

    # Create sample logs
    LOG = logging.getLogger("test_tqdm")
    LOG.setLevel(logging.INFO)
    try:
        with logging_redirect_tqdm(tqdm_class=std_tqdm, loggers=[LOG]):
            log(LOG, "One")
    except (KeyboardInterrupt, SystemExit):
        pass

# Generated at 2022-06-26 09:30:09.555257
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Unit test for function logging_redirect_tqdm
    import logging
    LOGGER = logging.getLogger(__name__)
    LOGGER.info("test")
    with logging_redirect_tqdm():
        LOGGER.info("console logging redirected to `tqdm.write()`")
    LOGGER.info("test")
    with logging_redirect_tqdm(loggers=[logging.getLogger(__name__)]):
        LOGGER.info("console logging redirected to `tqdm.write()`")
