

# Generated at 2022-06-26 09:20:12.736826
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from mock import MagicMock, call
    from contextlib import contextmanager

    loggers = [(MagicMock(), MagicMock(), MagicMock(), MagicMock())]
    tqdm_class = MagicMock()
    tqdm_kwargs = {"test": 0}
    pbar = MagicMock()

    tqdm_class.return_value = pbar

    with tqdm_class as pbar:
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            pass

    tqdm_class.assert_called_with(**tqdm_kwargs)
    assert (tqdm_class.return_value is pbar)
    assert (pbar.__exit__.call_count == 1)

# Generated at 2022-06-26 09:20:16.206555
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-26 09:20:26.909101
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with open("/tmp/tqdm_contrib/test__TqdmLoggingHandler_emit") as f:
        # Ensure that file is empty
        f.truncate(0)
    var_1 = logging.getLogger("tqdm_contrib.test")
    var_2 = logging.StreamHandler(f)
    var_3 = _TqdmLoggingHandler(std_tqdm)
    var_4 = logging.Formatter("%(name)s: %(levelname)s: %(message)s")
    var_2.setFormatter(var_4)
    var_3.setFormatter(var_4)
    var_1.handlers = [var_2, var_3]

# Generated at 2022-06-26 09:20:28.926930
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    var_49 = _TqdmLoggingHandler()
    with var_49 as var_50:
        var_50.emit = lambda: None


# Generated at 2022-06-26 09:20:32.388199
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    assert callable(tqdm_logging_redirect)
    # assert Exception
    var_0 = tqdm_logging_redirect()



# Generated at 2022-06-26 09:20:34.288852
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pbar.update(1)

# Generated at 2022-06-26 09:20:40.582545
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # use logging API for stdout
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("before")
    with logging_redirect_tqdm():
        logger.info("during")
    logger.info("after")
    logger.info("success")



# Generated at 2022-06-26 09:20:48.037134
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:20:56.970180
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from inspect import getargspec
    import logging

    assert getargspec(logging_redirect_tqdm) == getargspec(test_case_0)
    assert logging_redirect_tqdm.__name__ == 'logging_redirect_tqdm'
    assert logging_redirect_tqdm.__module__ == 'tqdm.contrib.logging'
    assert logging_redirect_tqdm.__doc__ is not None
    assert logging_redirect_tqdm(loggers=[logging.root]).__enter__().__exit__() is None

# Generated at 2022-06-26 09:21:01.293735
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from unittest import TestCase, main
    import types

    class TestTqdmLoggingRedirectMethods(TestCase):
        def test_tqdm_logging_redirect_class(self):
            self.assertTrue(isinstance(tqdm_logging_redirect, types.FunctionType))

    main(module='test_tqdm_logging_redirect')

# Generated at 2022-06-26 09:21:18.306726
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    # Test case 0
    try:
        var_0 = _TqdmLoggingHandler()
        var_0.emit(var_0)
    except Exception as exc_0:
        logging.exception(str(exc_0))
        raise
    # Test case 1
    try:
        var_0 = _TqdmLoggingHandler()
        var_0.emit(var_0)
    except Exception as exc_0:
        logging.exception(str(exc_0))
        raise
    # Test case 2
    try:
        var_0 = _TqdmLoggingHandler()
        var_0.emit(var_0)
    except Exception as exc_0:
        logging.exception(str(exc_0))
        raise
    # Test case 3

# Generated at 2022-06-26 09:21:23.027624
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100) as pbar:
        pbar.update(20)
        assert pbar.n == 20
        assert pbar.total == 100
        assert pbar.n == 20
        assert pbar.n == 20
    var_0 = tqdm_logging_redirect()


# Generated at 2022-06-26 09:21:33.782701
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # basic test
    with tqdm_logging_redirect() as t:
        assert isinstance(t, std_tqdm)
    # test tqdm kwargs
    with tqdm_logging_redirect(total=10) as t:
        assert t.total == 10
    # test loggers
    loggers = [logging.getLogger()]
    with tqdm_logging_redirect(loggers=loggers) as t:
        assert logging.getLogger().handlers[0] is not sys.stdout
    assert logging.getLogger().handlers[0] is sys.stdout
    # test tqdm class
    class Tqdm(std_tqdm):
        pass

# Generated at 2022-06-26 09:21:39.051974
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib import logging

    from tqdm import tqdm
    loggers = [logging.root]
    tqdm_class = tqdm
    with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
        with tqdm(total=None) as pbar:
            # your loop
            pass

# Test suite

# Generated at 2022-06-26 09:21:49.107899
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Tests the `logging_redirect_tqdm` function.

    Notes
    -----
    This test is written in doctest format. You can run it with the
    command:
        python -m doctest ./docs/source/contrib/logging.py
    """
    import logging
    from tqdm import trange

    # Testing for root logger
    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                logging.info("console logging redirected to tqdm.write()")
    # logging restored

    # Testing for specific logger
    LOG = logging.getLogger(__name__)

# Generated at 2022-06-26 09:21:56.766370
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:02.711541
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # https://docs.python.org/3/howto/logging-cookbook.html#redirecting-a-single-logger
    root = logging.getLogger()  # Root logger.
    root.setLevel(logging.DEBUG)
    original_handlers = root.handlers

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    root.addHandler(handler)

    import time
    import tqdm
    with logging_redirect_tqdm():
        for i in range(3):
            time.sleep(0.1)

# Generated at 2022-06-26 09:22:05.360495
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    return logging_redirect_tqdm()


# Generated at 2022-06-26 09:22:13.143227
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Test case for function tqdm_logging_redirect

# Generated at 2022-06-26 09:22:17.000036
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Sample test for function tqdm_logging_redirect"""
    test_case_0()


if __name__ == '__main__':
    # Sample usage
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:30.087791
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc="foo", total=9) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(desc="foo", total=9, disable=True) as pbar:
        for i in range(9):
            print("DEBUG: pbar: %r" % pbar)
            print("DEBUG: pbar.disable: %r" % pbar.disable)

# Generated at 2022-06-26 09:22:33.928815
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    var_0 = _TqdmLoggingHandler()
    var_1 = var_0.emit()


# Generated at 2022-06-26 09:22:35.847692
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test for global arguments compatibility
    tqdm_logging_redirect()



# Generated at 2022-06-26 09:22:38.437051
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging_redirect_tqdm()


# Generated at 2022-06-26 09:22:45.183460
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:48.918004
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm.trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:22:53.547520
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    var_8 = _TqdmLoggingHandler()
    var_9 = None  # type: Any
    var_7 = logging.StreamHandler()
    var_10 = True
    var_9 = logging.StreamHandler.emit(var_7, var_10)


# Generated at 2022-06-26 09:22:59.619155
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:23:11.725902
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=unused-argument
    import logging
    import sys
    from contextlib import contextmanager

    try:
        from typing import Iterator, List, Optional, Type  # pylint: disable=unused-import
    except ImportError:
        pass

    from ..std import tqdm as std_tqdm


    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(
            self,
            tqdm_class=std_tqdm  # type: Type[tqdm]
        ):
            super(_TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class


# Generated at 2022-06-26 09:23:14.212461
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = var_0
    file = var_0
    var_0.emit(msg, file)

# Generated at 2022-06-26 09:23:29.165876
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.utils import _term_move_up as smove

    logger = logging.getLogger()
    tqdm_logging_handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    tqdm_logging_handler.setFormatter(formatter)
    logger.addHandler(tqdm_logging_handler)

    pbar_class = std_tqdm
    with tqdm_logging_redirect(
        loggers=[logger], tqdm_class=pbar_class
    ) as pbar:
        print('first')
        logging.info('second')
        logging.info('second')
        pbar.write('third')
        # pbar.refresh()

# Generated at 2022-06-26 09:23:41.050273
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .constants import unit_test_verbosity
    logger = logging.getLogger('logging_redirect_tqdm_test')
    logger.setLevel(logging.DEBUG)
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(log_handler)
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info('console logging redirected to `tqdm.write()`')
    logger.removeHandler(log_handler)

# Generated at 2022-06-26 09:23:47.674378
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ...tests.lock import acquire_locks
    from ...tests.serialisation import make_serialisation_checkpoint

    try:
        from ...tests import _test_logging_redirect_tqdm
    except ImportError:
        return

    def checkpoint_callback(lock, checkpoint_path):
        # type: (str, str) -> None
        with acquire_locks(lock):
            make_serialisation_checkpoint('tqdm_redirect_contextmanager',
                                          _test_logging_redirect_tqdm,
                                          checkpoint_path)

    _test_logging_redirect_tqdm.make_and_check_checkpoint(
        'tqdm_redirect_contextmanager',
        test_logging_redirect_tqdm,
        checkpoint_callback)



# Generated at 2022-06-26 09:23:54.170398
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging.handlers
    import io
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    log_output = io.StringIO()
    handler = logging.StreamHandler(log_output)
    logger.addHandler(handler)

    log_messages = ['message %d' % i for i in range(5)]

    with logging_redirect_tqdm():
        for i in range(5):
            logger.info(log_messages[i])

    # restore original stderr
    sys.stdout = sys.__stdout__

    assert log_output.getvalue() == '\n'.join(log_messages)

# Generated at 2022-06-26 09:24:00.546967
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm.trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:24:11.788997
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    with tqdm_logging_redirect(desc='Default tqdm class'):
        logger.debug('Test 1')
        logger.info('Test 2')

    with tqdm_logging_redirect(desc='Default tqdm class', loggers=[logger]):
        logger.debug('Test 3')
        logger.info('Test 4')

    # Check that default logging is restored afterwards
    logger.debug('Test 5')
    logger.info('Test 6')


if __name__ == '__main__':
    _test()

# Generated at 2022-06-26 09:24:20.797481
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import tqdm
    with logging_redirect_tqdm():
        for _ in trange(9):
            LOG.info('1')
        for _ in tqdm(range(9)):
            LOG.info('2')
    for _ in trange(9):
        LOG.info('3')
    for _ in tqdm(range(9)):
        LOG.info('4')



# Generated at 2022-06-26 09:24:30.574118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Define a temporary stdout
    import StringIO
    stdout = sys.stdout
    output = StringIO.StringIO()
    sys.stdout = output

    # Logging should be printed in the newly defined stdout
    with tqdm_logging_redirect():
        logging.info('Testing')
    assert('Testing\n' in output.getvalue())

    # Clean up
    sys.stdout = stdout



# Generated at 2022-06-26 09:24:32.199703
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    with logging_redirect_tqdm():
        assert True


# Generated at 2022-06-26 09:24:39.415856
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for _ in std_tqdm(range(9)):
            logging.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert 'INFO' in sys.stdout.getvalue()



# Generated at 2022-06-26 09:24:53.268383
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.debug("this is a debug log")
        logging.warning("this is a warning log")
        logging.info("this is an info log")
        logging.error("this is an error log")

# Generated at 2022-06-26 09:24:59.719369
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("test_case_0")
    with logging_redirect_tqdm():
        logging.info("test_case_1")

# Test that logger name param is optional

# Generated at 2022-06-26 09:25:04.218991
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info("Console logging should be going to stdout")
    with logging_redirect_tqdm():
        LOG.info("Console logging should be going to tqdm.write()")
    LOG.info("Console logging should be going to stdout")



# Generated at 2022-06-26 09:25:11.641878
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import tqdm
        with logging_redirect_tqdm():
            for i in tqdm(range(3)):
                logging.info('{}'.format(i))
    except:
        raise Exception("Unit test for function logging_redirect_tqdm failed")


# Generated at 2022-06-26 09:25:17.833635
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function logging_redirect_tqdm
    """
    class FakeLogger(object):
        def __init__(self, handler):
            self.handlers = [handler]
    class FakeHandler(object):
        def __init__(self, stream):
            self.stream = stream
            self.formatter = 'formatter'
    fake_std_out = 'fake_std_out'
    with logging_redirect_tqdm():
        logger = FakeLogger(FakeHandler(fake_std_out))
        assert len(logger.handlers) == 1
        assert logger.handlers[0].stream == fake_std_out
        assert logger.handlers[0].formatter == 'formatter'

# Generated at 2022-06-26 09:25:25.787936
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Test 1: base test
    def test_1():
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in range(10):
                    if i == 5:
                        LOG.info("console logging is redirected to `tqdm.write()`")

    import sys
    import io
    sys.stdout = io.StringIO()
    test_1()
    redirected_output = sys.stdout.getvalue()
    assert "console logging is redirected to `tqdm.write()`" in redirected_output

    # Test 2: test with custom tqdm_class

# Generated at 2022-06-26 09:25:37.050061
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_msg = "Test message"
    loggers = [logging.root]
    tqdm_class = std_tqdm

    # Set up logging
    logging.basicConfig(level=logging.INFO)
    root_logger = logging.getLogger()

    # Try to log a message into a tqdm and onto the console
    with tqdm_logging_redirect(
        desc='test_tqdm', loggers=loggers, tqdm_class=tqdm_class) as test_tqdm:
        root_logger.info("test_msg")
        assert test_msg in test_tqdm.get_lock_tqdm()._instances
        assert test_msg in test_tqdm.get_lock_tqdm().last_window

# Generated at 2022-06-26 09:25:39.834397
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    _TqdmLoggingHandler().emit(logging.makeLogRecord({}))


# Generated at 2022-06-26 09:25:45.805927
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig()
    assert (
        logging.root.handlers[0].stream in {sys.stdout, sys.stderr})
    with logging_redirect_tqdm():
        assert (
            logging.root.handlers[0].stream in {sys.stdout, sys.stderr})
    assert (
        logging.root.handlers[0].stream in {sys.stdout, sys.stderr})



# Generated at 2022-06-26 09:25:58.440328
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging_redirect_tqdm(loggers=[logging.getLogger('test_tqdm_logging_redirect')])
    with std_tqdm(0) as pbar:
        with tqdm_logging_redirect():
            pbar.write('test_tqdm_logging_redirect')
            pbar.write('test_tqdm_logging_redirect')
        pbar.write('test_tqdm_logging_redirect')
    with std_tqdm(0) as pbar:
        with tqdm_logging_redirect(loggers=[logging.getLogger('test_tqdm_logging_redirect_with_loggers')]):
            pbar.write('test_tqdm_logging_redirect_with_loggers')

# Generated at 2022-06-26 09:26:17.711507
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    only_str = 'string'
    only_int = 1
    only_float = 1.1
    str_int = 'string ' + str(only_int)
    str_float = 'string ' + str(only_float)
    str_int_float = 'string ' + str(only_int) + ' ' + str(only_float)
    int_float = str(only_int) + ' ' + str(only_float)

    rec_0 = logging.makeLogRecord({'msg': only_str})
    rec_1 = logging.makeLogRecord({'msg': only_int})
    rec_2 = logging.makeLogRecord({'msg': only_float})
    rec_3 = logging.makeLogRecord({'msg': str_int})

# Generated at 2022-06-26 09:26:26.792760
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test case to verify that the class handles 'tqdm.write()' error
    # and raises other exceptions
    record = logging.LogRecord(
        name='tqdm_logging_handler',
        level=20,
        pathname='',
        lineno=0,
        msg='test_msg',
        args=None,
        exc_info=None,
    )
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # Test case to verify that the class handles 'SystemExit' exception
    tqdm_logging_handler_0.emit(record)
    # Test case to verify that the class handles 'KeyboardInterrupt' exception
    tqdm_logging_handler_0.emit(record)
    # Test case to verify that the class handles other exceptions
    t

# Generated at 2022-06-26 09:26:39.036775
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.std import tqdm
    from test_tqdm import with_move_cursor
    with logging_redirect_tqdm():
        log = logging.getLogger(__name__)
        log.setLevel(logging.INFO)
        _ = tqdm(total=10)
        log.info("Test")
    with logging_redirect_tqdm([logging.getLogger(__name__)]):
        log = logging.getLogger(__name__)
        log.setLevel(logging.INFO)
        _ = tqdm(total=10)
        log.info("Test")
    with logging_redirect_tqdm([logging.getLogger('test')]):
        log = logging.getLogger(__name__)

# Generated at 2022-06-26 09:26:42.898676
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger()
    with logging_redirect_tqdm():
        logger.info('foo bar')  # -> stdout



# Generated at 2022-06-26 09:26:48.209748
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # The code below is just a mockup code to test
    # tqdm_logging_redirect function, but it should
    # work after "import logging" is added
    import logging  # noqa: F401

    logging.basicConfig(level=logging.INFO)

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:26:55.087958
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Example
    -------
    ```python
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
            total=10,
            desc="console logging redirected to `tqdm.write()`"):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    ```
    """
    import logging
    from tqdm import trange


# Generated at 2022-06-26 09:27:06.897951
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.propagate = False
    logger.setLevel(logging.NOTSET)

    try:
        from tqdm import tqdm as std_tqdm
    except ImportError:
        std_tqdm = logging_redirect_tqdm()._self.tqdm_class

    original_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(original_handler)


# Generated at 2022-06-26 09:27:13.007362
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    l = logging.getLogger()
    with tqdm_logging_redirect():
        if l.handlers[0].__class__.__name__ != '_TqdmLoggingHandler':
            raise AssertionError()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:27:26.379462
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging
    from tqdm._utils import _term_move_up
    from tqdm.contrib.logging import logging_redirect_tqdm
    pbar = trange(4, desc='outer-bar')
    for i in pbar:
        pbar.set_description('test case {}'.format(i + 1))
        LOG = logging.getLogger(__name__)
        if i == 0:
            print
            LOG.info("LOG.info prints normally")
        elif i == 1:
            print
            with logging_redirect_tqdm():
                for j in trange(8, desc='inner-bar'):
                    if j == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:27:33.250294
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    debug_logger = logging.getLogger(__name__)
    debug_logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    debug_logger.addHandler(handler)
    debug_logger.debug('Test: debug logger message')
    debug_logger.info('Test: info logger message')
    #logger.warning('Test: warning logger message')
    #logger.error('Test: error logger message')
    #logger.critical('Test: critical logger message')