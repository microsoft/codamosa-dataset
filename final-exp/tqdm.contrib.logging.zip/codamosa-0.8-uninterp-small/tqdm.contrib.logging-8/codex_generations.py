

# Generated at 2022-06-26 09:20:20.393294
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logger = logging.getLogger('test_tqdm_logging_redirect')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    with tqdm_logging_redirect(
        logger.debug, desc="Progress",
        total=100, loggers=[logger],
        unit='events', unit_scale=True
    ) as pbar:
        for ii in range(100):
            logger.debug(ii)
            pbar.update()



# Generated at 2022-06-26 09:20:27.837452
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    try:
        # Redirect console logging to tqdm (stdout and stderr).
        with tqdm_logging_redirect():
            # Now, `logging.info` will redirect to tqdm
            LOG.info("console logging redirected to `tqdm.write()`")
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        LOG.exception("uncaught exception")

# Generated at 2022-06-26 09:20:38.224252
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test that logging_redirect_tqdm does not mix up loggers
    log1 = logging.getLogger('log1')
    log2 = logging.getLogger('log2')
    log1.handlers = [logging.StreamHandler(sys.stdout)]
    log2.handlers = [logging.StreamHandler(sys.stdout)]

    log1.info('test1')
    log2.info('test2')

    with logging_redirect_tqdm([log1]):
        log1.info('tqdm1')
        log2.info('tqdm2')

    log1.info('test1')
    log2.info('test2')

# Generated at 2022-06-26 09:20:48.979288
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    test_logger = logging.getLogger("TestLogging")
    test_logger.setLevel(logging.DEBUG)
    with tqdm_logging_redirect(total=10, desc="testing", logging_level=logging.DEBUG):
        test_logger.debug("this is a test")
        test_logger.debug("this is also a test")
        test_logger.info("this is a test")
        test_logger.info("this is also a test")
        test_logger.warning("this is a test")
        test_logger.warning("this is also a test")
        test_logger.error("this is a test")
        test_logger.error("this is also a test")
        test_logger.critical("this is a test")
        test_

# Generated at 2022-06-26 09:21:00.162270
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # test logging_redirect_tqdm and tqdm_logging_redirect
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def test_case(test_tqdm_func, test_case_num):
        log_str = ''.join(['Test Case', str(test_case_num), '\n'])
        print(log_str)
        test_tqdm_func.write(log_str)


# Generated at 2022-06-26 09:21:11.659552
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create a tqdm logging handler and some logging message
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logging_msg = "This message will be printed on console by tqdm"
    logging_record = logging.Logger("Test").makeRecord("Test", logging.INFO, "/tmp/test.log", 3, logging_msg, None, None, None)

    # Redirect stdout to known file
    out_file = "/tmp/test.out"
    f = open(out_file, "w")
    out_orig = sys.stdout
    sys.stdout = f

    # Print the logging message using tqdm logging handler
    tqdm_logging_handler_1.emit(logging_record)

    # Close the output file and restore stdout
    f.close()

# Generated at 2022-06-26 09:21:14.835185
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    from tqdm.utils import _range
    with tqdm_logging_handler_1:
        _range(3)


# Generated at 2022-06-26 09:21:21.911073
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    loggers = [logging.root]
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:21:29.814342
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm

    with tqdm.tqdm_logging_redirect(tqdm_class=tqdm.std.tqdm):
        logger = logging.getLogger(__name__)
        logger.info('123')

    with tqdm.tqdm_logging_redirect(tqdm_class=tqdm.std.tqdm, loggers=logging.Logger.manager.loggerDict.values()):
        logging.info('123')

# Generated at 2022-06-26 09:21:37.388179
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.DEBUG)
    logger1 = logging.getLogger(__name__)
    logger2 = logging.getLogger(__name__)
    with logging_redirect_tqdm([logger1, logger2]):
        logger1.debug("debug")
        logger1.info("info")
        logger1.warning("warning")
        logger1.error("error")
        logger2.warning("warning")
        logger2.error("error")
        logger2.critical("critical")
        logger1.info("info")
    logger1.info("info")

# Generated at 2022-06-26 09:21:52.654302
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as test_logging_redirect_tqdm:
        for i in std_tqdm.trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:21:56.540390
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        print(repr(pbar))
        pbar.update()


if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:08.517885
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with logging_redirect_tqdm():
        for logger in loggers:
            tqdm_handler = _TqdmLoggingHandler()
            orig_handler = _get_first_found_console_logging_handler(logger.handlers)
            if orig_handler is not None:
                tqdm_handler.setFormatter(orig_handler.formatter)
                tqdm_handler.stream = orig_handler.stream

# Generated at 2022-06-26 09:22:10.816248
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert pbar.disable is True


# Generated at 2022-06-26 09:22:16.468757
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(unit='unit', desc='description') as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()
        # logging restored
        # Note: tqdm_logging_redirect is a context manager, so the following will
        # no longer be redirected to pbar:
        LOG.info('This will only be redirected if outside `tqdm.tqdm` call.')

# Generated at 2022-06-26 09:22:20.590698
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(
            tqdm_class=std_tqdm,
            loggers=None,
            tqdm_kwargs={}
        ):
        pass

# Generated at 2022-06-26 09:22:28.789768
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        tqdm_class = std_tqdm
        with tqdm_logging_redirect(
                tqdm_class=tqdm_class,
                loggers=[LOG]
        ) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)
        # logging restored
        LOG.info("console logging restored")

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:38.291865
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    # tqdm_logging_handler_1 = _TqdmLoggingHandler()
    # tqdm_logging_handler_2 = _TqdmLoggingHandler()

    # logging.root.handlers[0]
    # logging.root.handlers
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


test_case_0()
test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:22:41.104315
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    def foo():
        logging.info("test")
    with logging_redirect_tqdm():
        foo()


# Generated at 2022-06-26 09:22:45.984305
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    with tqdm_logging_redirect(level=logging.INFO) as pbar:
        for _ in pbar(range(10)):
            logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:23:06.504508
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to tqdm.write()")

# Generated at 2022-06-26 09:23:10.515691
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Synchronous testing
    logger = logging.getLogger('test_class_write')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())
    logger.addHandler(_TqdmLoggingHandler())
    logger.info('hello')



# Generated at 2022-06-26 09:23:22.933005
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging as _logging
    logger = _logging.getLogger()
    assert len(logger.handlers) == 0
    assert len(logger.handlers) == 0

    with tqdm_logging_redirect(loggers=[_logging.root]) as pbar:
        assert pbar.__class__ == std_tqdm
        assert len(logger.handlers) == 1
        assert len(pbar.format_dict) == 0
        assert len(logger.handlers[0].__class__.__mro__) == 2
        assert logger.handlers[0].__class__.__mro__[-2] is _TqdmLoggingHandler

        pbar.format_str = 'abc'
        assert len(pbar.format_dict) == 1

        pbar.bar

# Generated at 2022-06-26 09:23:29.498004
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.root
    logger.setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm([logger]):
        for i in range(10):
            if i == 5:
                logging.info('console logging redirected to tqdm.write()')
                logger.debug('this should be seen in the test_logging_redirect_tqdm output')
            else:
                logging.info('some info')
                logging.debug('some debug')

# Generated at 2022-06-26 09:23:35.428437
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        pbar.set_description("test case 0")
        logging.info("info log")
        logging.warning("warning log")
        logging.error("error log")

# Generated at 2022-06-26 09:23:41.082380
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger(), logging.getLogger('test')]
    # Test in case there is no handler attached
    with logging_redirect_tqdm(loggers):
        pass

    # Test in case there are some handlers attached
    loggers[0].addHandler(logging.StreamHandler())
    with logging_redirect_tqdm(loggers):
        loggers[0].info("test")
        loggers[1].info("test")

# Generated at 2022-06-26 09:23:47.517593
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys

    stream = io.StringIO()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(_TqdmLoggingHandler())

    # console logging redirected to `tqdm.write()`
    tqdm_logging_redirect(file=stream)
    logger.info("console logging redirected to `tqdm.write()`")

    # logging restored
    logger.info("logging restored")

    # "console logging redirected to `tqdm.write()`\nlogging restored\n"
    test = stream.getvalue()
    assert test == "console logging redirected to `tqdm.write()`\nlogging restored\n"


# Generated at 2022-06-26 09:23:51.534522
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm
    import os

# Tries to run test cases with this statement
    # with logging_redirect_tqdm():
    #     for i in tqdm.trange(9):
    #         if i == 4:
    #             LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-26 09:24:02.430401
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .pretest import FullTestCase, PretestTestCase
    with PretestTestCase():
        with FullTestCase(__file__, **{
            'tqdm_display': False, 'unit': True, 'check_stdout': False,
            'logging_redirect': True, 'interactive': False, 'color': False
        }) as self:
            with tqdm_logging_redirect(total=10, desc='tqdm_logging_redirect',
                                       unit='it'):
                logging.getLogger().info('tqdm_logging_redirect')
            self.assertTrue(self.out())


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:24:12.721480
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange

    LOG = logging.getLogger(__name__)

    def _test():
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
    assert logging.root.handlers

    # Test with logging.root
    with logging_redirect_tqdm():
        _test()
    with logging_redirect_tqdm(loggers=[logging.root]):
        _test()
    with tqdm_logging_redirect():
        _test()

    # Test with custom logger
    custom_logger = logging.getLogger('custom_logger')
    with logging_redirect_tqdm(loggers=[custom_logger]):
        custom

# Generated at 2022-06-26 09:24:41.458974
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_tqdm_copy = std_tqdm.tqdm.copy

    try:
        logging.basicConfig(level=logging.INFO)
        tqdm_instance = test_tqdm_copy(range(10))
        with tqdm_logging_redirect(tqdm_instance) as pbar:
            for i in range(10):
                if i == 4:
                    logging.info('Test message')
    finally:
        pbar.close()

# Generated at 2022-06-26 09:24:46.549369
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:24:54.579939
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tnrange

    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    LOG = logging.getLogger(__name__)

    assert LOG.handlers == []

    try:
        with logging_redirect_tqdm():
            assert LOG.handlers == [tqdm_logging_handler_0]
    except Exception as e:
        raise e

    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            assert LOG.handlers == [tqdm_logging_handler_0]
    except Exception as e:
        raise e


# Generated at 2022-06-26 09:24:59.012542
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = ""
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.emit(msg)


# Generated at 2022-06-26 09:25:06.556201
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:25:14.430652
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _term_move_up
    from tqdm.auto import trange
    log = logging.getLogger()
    log.setLevel(logging.INFO)
    with std_tqdm(leave=False) as pbar:
        log.addHandler(logging.StreamHandler(pbar.write))
        for i in trange(10):
            log.info('test')
    sys.stderr.write(_term_move_up())



# Generated at 2022-06-26 09:25:23.075607
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc='test_tqdm_logging_redirect', total=3) as test_pbar:
        logging.info('First log message')
        test_pbar.update(1)
        logging.info('Second log message')
        test_pbar.update(1)
        logging.info('Last log message')


# Generated at 2022-06-26 09:25:31.506679
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    class TestLogger(logging.Logger):
        pass
    logging.setLoggerClass(TestLogger)
    logger = logging.getLogger()
    with logging_redirect_tqdm(loggers=[logger]):
        assert isinstance(logger.handlers[0], _TqdmLoggingHandler)
    logging.setLoggerClass(logging.Logger)


# Generated at 2022-06-26 09:25:43.864768
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(format='%(message)s', level=logging.INFO)

    def d(logging_redirect_tqdm):
        streams = []
        save_stdout = sys.stdout
        save_stderr = sys.stderr

# Generated at 2022-06-26 09:25:56.450397
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def test_case(case):
        with logging_redirect_tqdm() as lrt:
            with Open(BytesIO()) as log_to:
                with lrt as logger:
                    logger.addHandler(logging.StreamHandler(log_to))
            log_to.seek(0)
            log_output = log_to.read().decode()
            assert log_output == case


# Generated at 2022-06-26 09:26:48.731340
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        assert logging.root.handlers[0].__class__.__name__ == \
            _TqdmLoggingHandler.__name__
    assert isinstance(logging.root.handlers[0], logging.StreamHandler)
    with tqdm_logging_redirect(loggers=[]):
        assert len(logging.root.handlers) == 1
    assert isinstance(logging.root.handlers[0], logging.StreamHandler)
    with tqdm_logging_redirect(loggers=None):
        assert len(logging.root.handlers) == 1
    assert isinstance(logging.root.handlers[0], logging.StreamHandler)

# Generated at 2022-06-26 09:26:53.849273
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        logging.info('logging redirected to `tqdm.write()`')
    assert pbar.n == 10
    assert pbar.n == pbar.total

# Generated at 2022-06-26 09:27:06.254473
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def get_stdout_output():
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        yield
        sys.stdout.seek(0)
        output = sys.stdout.read()
        sys.stdout = old_stdout
        return output

    # Disable debug loggers
    log_level = logging.getLogger().getEffectiveLevel()
    logging.disable(logging.DEBUG)


# Generated at 2022-06-26 09:27:14.139289
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging  # isort:skip
    from tqdm import trange  # isort:skip

    global TEST_RUN  # pylint:disable=global-statement
    TEST_RUN = True

    def run():
        for _ in trange(9):
            if _ == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        run()



# Generated at 2022-06-26 09:27:17.858527
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import __main__
    args = ['-h']
    with logging_redirect_tqdm():
        __main__.main(args)

# Generated at 2022-06-26 09:27:27.865827
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from tqdm import trange
    logger = logging.getLogger()
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert sys.stdout.getvalue() == '0%|          | 0/9 [00:00<?, ?it/s]\n'
    logger.info("console logging restored")
    assert sys.stdout.getvalue() == '0%|          | 0/9 [00:00<?, ?it/s]\nconsole logging restored\n'


# Generated at 2022-06-26 09:27:35.922610
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from pytest import raises
    from io import StringIO
    from .tqdm_test_cases import tqdm
    stdout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-26 09:27:46.337431
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    # all_logging_test_cases_0 = globals()['all_logging_test_cases']
    # all_logger_test_cases_0 = [logging.getLogger(name) for name in all_logging_test_cases_0.keys()]
    all_logger_test_cases_0 = [logging.root]
    for logger_test_case_0 in all_logger_test_cases_0:
        tqdm_logging_handler_1 = _TqdmLoggingHandler()
        logger_test_case_0.addHandler(tqdm_logging_handler_1)

# Generated at 2022-06-26 09:27:53.217748
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    # Test Case 1
    logging.basicConfig()
    logger = logging.getLogger('logger')

    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logging_handler_1)

    logger.info('This is an info message')
    logger.warning('This is a warning message')
    logger.error('This is an error message')
    logger.critical('This is a critical message')


# Generated at 2022-06-26 09:28:02.319305
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    with tqdm_logging_redirect(total=10) as pbar:
        log.debug('Hello world')
        log.info('Foo')
        log.warn('Bar')
        log.error('1/10')
        pbar.update()
        log.critical('2/10')
        pbar.update()


# Generated at 2022-06-26 09:29:44.053328
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)

    with tqdm_logging_redirect(loggers=[logger]):
        logger.info('test')


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:46.856715
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    try:
        with logging_redirect_tqdm():
            pass
    except KeyboardInterrupt:
        raise
    except:  # noqa pylint: disable=bare-except
        pass


# Generated at 2022-06-26 09:29:52.095077
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=[logging.root]) as pbar:
        assert pbar.__class__.__name__ == 'tqdm'


# Generated at 2022-06-26 09:30:03.262636
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    try:
        with logging_redirect_tqdm():
            logging.info('A message')

        logging.info('Another message (should not be tqdm-redirected)')

        assert sys.stderr.getvalue() == '\x1b[A\n', \
            '\n'.join(['##### test_logging_redirect_tqdm failed:',
                       'Expected:',
                       '    ' + repr('\x1b[A\n'[:-1]),
                       'Got:',
                       '    ' + repr(sys.stderr.getvalue()[:-1])])
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-26 09:30:10.057741
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_2 = _TqdmLoggingHandler()
    assert tqdm_logging_handler_1 == tqdm_logging_handler_2
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]