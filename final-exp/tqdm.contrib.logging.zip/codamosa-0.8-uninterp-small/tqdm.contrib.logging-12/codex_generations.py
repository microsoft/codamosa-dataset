

# Generated at 2022-06-26 09:20:13.672497
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    with tqdm_logging_redirect() as pbar:
        # loggers = [logging.root]
        for i in trange(9):
            if i == 4:
                logging.info("boo")
                # LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:20:24.646094
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # create sample logger
    LOG = logging.getLogger(__name__)
    # sample test message
    test_message = "sample logging message"
    # test with basicConfig
    with logging_redirect_tqdm():
        LOG.info(test_message)
    # test with other logger
    other_logger = logging.getLogger("other_logger")
    with logging_redirect_tqdm(loggers=[other_logger]):
        other_logger.info(test_message)
    # test with both of those
    with logging_redirect_tqdm(loggers=[LOG, other_logger]):
        LOG.info(test_message)
        other_logger.info(test_message)


# Generated at 2022-06-26 09:20:35.144452
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tests_tqdm.utils import closing, _range

    ##########################################################################
    # logging.info

    with closing(_range(5)) as pbar:
        assert (not pbar.enable)
        with logging_redirect_tqdm():
            logging.info("Hello")
        assert pbar.enable
    with closing(_range(5)) as pbar:
        assert (not pbar.enable)
        with logging_redirect_tqdm(loggers=[logging.getLogger()]):
            logging.info("Hello")
            logging.warning("Another logger")
        assert pbar.enable

    ##########################################################################
    # logging.warning

    with closing(_range(5)) as pbar:
        assert (not pbar.enable)

# Generated at 2022-06-26 09:20:42.019308
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.info("test_tqdm_logging_redirect")
    try:
        from tqdm import tqdm
    except ImportError:
        # if tqdm not found, skip the test
        return
    
    with tqdm_logging_redirect(desc="testing", tqdm_class=tqdm) as pbar:
        logging.info("logging redirected to tqdm")



# Generated at 2022-06-26 09:20:47.433995
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=10, leave=False) as pbar:
        for i in range(10):
            pbar.update(1)
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:20:56.024985
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:21:01.364950
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import tqdm

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    assert "console logging redirected to `tqdm.write()`" in sys.stderr.getvalue()



# Generated at 2022-06-26 09:21:09.671316
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_1.stream = sys.stdout

    class TestRecord(object):
        def __init__(self, msg):
            self.msg = msg
        def __str__(self):
            return self.msg

    tqdm_logging_handler_1.emit(TestRecord("record msg"))
    assert tqdm_logging_handler_1.stream.getvalue() == "record msg\n"


# Generated at 2022-06-26 09:21:13.861192
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        _TqdmLoggingHandler().emit(logging.LogRecord(None, None, None, None,
                                                     None, None, None))
    except:  # noqa pylint: disable=bare-except
        pass  # pass-through

# Generated at 2022-06-26 09:21:21.520708
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        tqdm_logging_handler_1 = _TqdmLoggingHandler()
    with logging_redirect_tqdm(loggers=[logger]):
        tqdm_logging_handler_2 = _TqdmLoggingHandler()
    logger.info('Message')


if __name__ == '__main__':
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:21:30.912268
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(1000) as pbar:
        for i in range(1000):
            logging.info('#%d', i)
            if not i % 10:
                pbar.update(10)
    assert pbar.n == 1000


# Generated at 2022-06-26 09:21:35.803066
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm as std_tqdm

    with logging_redirect_tqdm():
        for _ in std_tqdm(range(4)):
            pass

    with tqdm_logging_redirect(
            [logging.root],
            total=4,
    ) as pbar:
        for _ in pbar:
            pass



# Generated at 2022-06-26 09:21:37.429224
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for logging_redirect_tqdm"""

    exit()

# Generated at 2022-06-26 09:21:47.521592
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm

    log_list = ['test_log', 'test_log2']
    for log in log_list:
        test_log = logging.getLogger(log)
        test_log.addHandler(logging.StreamHandler())

    test_log.info('test')

    with logging_redirect_tqdm():
        tqdm.write('test')

    test_log.info('test')

    with logging_redirect_tqdm():
        tqdm.write('test')

    test_log.info('test again')

    with logging_redirect_tqdm(tqdm=tqdm):
        tqdm.write('test')

    test_log.info('test')



# Generated at 2022-06-26 09:21:56.807331
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info('test complete')


# Generated at 2022-06-26 09:22:07.866824
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import random
    import logging
    import tqdm.std as tqdm
    import sys

    # set up logging
    logger = logging.getLogger('main')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    with logging_redirect_tqdm():
        for i in tqdm.tqdm(range(10)):
            if random.random() < 0.5:
                logger.info(i)

# Generated at 2022-06-26 09:22:12.431925
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    with logging_redirect_tqdm([logger]):
        logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:22:24.033747
# Unit test for function tqdm_logging_redirect

# Generated at 2022-06-26 09:22:30.467243
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    assert LOG.handlers
    assert logging.root.handlers

    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert LOG.handlers
    assert logging.root.handlers


if __name__ == '__main__':
    test_case_0()
    test_logging_redirect_tqdm()
    print('\nSUCCESS: all tests passed.')

# Generated at 2022-06-26 09:22:38.118097
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:44.797166
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm():
        logging.info("Some information")

# Generated at 2022-06-26 09:22:47.062727
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert isinstance(pbar, std_tqdm)
        pbar.update(1)

# Generated at 2022-06-26 09:22:52.329843
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                        format="[%(asctime)s] %(levelname)s: %(message)s")
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect(desc="test", total=4):
            for i in range(3):
                LOG.info("console logging redirected to `tqdm.write()`")
            LOG.info("logging restored")



# Generated at 2022-06-26 09:22:59.005156
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(loggers=[LOG]) as pbar:
            pbar.set_description("Test Case")
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)
        # logging restored


# Generated at 2022-06-26 09:23:09.179598
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Unit test to assert that `tqdm_logging_redirect` sets up the correct
    # logging handler and does not crash on a KeyboardInterrupt.
    with tqdm_logging_redirect(range(10)) as bar:
        for i in range(5):
            logging.warning("Logging through `tqdm.write()`")
            # Next line should throw an exception when we raise KeyboardInterrupt
            # (and the exception should be caught by the `tqdm_logging_redirect`
            # context manager and not propagate to the outer context.
            bar.update()
        raise KeyboardInterrupt
    assert bar.n == 5, "Tqdm bar should not have progressed"
    assert bar.n == bar._last_print_n, "Tqdm bar should be in sync"
    assert bar.internal_len

# Generated at 2022-06-26 09:23:19.039316
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-26 09:23:29.653234
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    tqdm_logging_handler_2 = _TqdmLoggingHandler()
    tqdm_logging_handler_3 = _TqdmLoggingHandler(std_tqdm)

    # logger = tqdm_logging_handler_2.get_logger()

    show_tqdm = [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR]

# Generated at 2022-06-26 09:23:38.262141
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # Initialize logger
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[logging.root], tqdm_class=tqdm):
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:23:49.041920
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        with tqdm_logging_redirect(
            total=1000, tqdm_class=std_tqdm
        ) as pbar:  # type: std_tqdm
            pass
        assert pbar.n == 1000
        assert pbar.total == 1000
        assert pbar.n == pbar.total
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        raise AssertionError('tqdm_logging_redirect failed')



# Generated at 2022-06-26 09:24:01.734085
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test for no loggers
    with logging_redirect_tqdm():
        pass

    # Test for regular logger
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[logging.root]):
        if 1 > 0:
            logging.info('Test logging message')

    # Test for multiple loggers
    logging.basicConfig(level=logging.INFO)
    logger_1 = logging.getLogger(__name__ + '-1')
    logger_2 = logging.getLogger(__name__ + '-2')
    with logging_redirect_tqdm(loggers=[logger_1, logger_2]):
        if 1 > 0:
            logger_1.info('Test logging message')
            logger_2.info('Test logging message')

# Generated at 2022-06-26 09:24:18.026024
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Test with logging_redirect_tqdm context manager
    with logging_redirect_tqdm():
        for _ in trange(5):
            LOG.info("console logging redirected to `tqdm.write()`")

    # Test with logging_redirect_tqdm context manager
    def test_func():
        # type: () -> None
        """
        Test function to be used by `logging_redirect_tqdm()`.
        """

# Generated at 2022-06-26 09:24:25.607947
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    test_logging_level = 17

    set_flag = False
    # Check if logging is on root logger
    if logging.getLogger() == logging.root:
        set_flag = True

    logging.basicConfig(level=logging.INFO)  # To suppress warning
    logging.setLoggerClass(logging.Logger)  # To supress warning

    # Check if logger is root logger
    test_logger = logging.getLogger()
    if test_logger == logging.root:
        set_flag = True

    test_logger.setLevel(logging.DEBUG)
    test_logger.handlers = []  # Remove default handler

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    console_handler.stream = sys.stdout
    test

# Generated at 2022-06-26 09:24:35.148159
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        logging.info("Testing tqdm.contrib.logging.logging_redirect_tqdm")
        with logging_redirect_tqdm():
            logging.info("ASCII")
            with tqdm_logging_redirect(bar_format='{l_bar}{bar}|{n_fmt}/{total_fmt}'):
                logging.info('BAR')
            logging.info("ASCII")
    except Exception as e:
        sys.stderr.write(str(e))

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:24:42.613645
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # Ensure that the logger is not being sent to stderr
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    logger = logging.getLogger(__name__)
    LOG = logger
    LOG.info('Foo')
    with tqdm_logging_redirect():
        LOG.info('Bar')


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:24:48.271568
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    message = 'test'
    record = logging.LogRecord('name', 10, 'pathname', 10, message, None, None)
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.emit(record)


# Generated at 2022-06-26 09:24:50.679530
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        for _ in pbar:
            break

# Generated at 2022-06-26 09:24:58.235155
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Set up logging to a stream
    logger = logging.getLogger('test_logging_redirect_tqdm')

    with logging_redirect_tqdm():
        logger.info('test with %s', 'test_logging_redirect_tqdm')
    with logging_redirect_tqdm():
        logger.info('test with %s', 'test_logging_redirect_tqdm')
    try:
        with logging_redirect_tqdm():
            raise Exception('test Exception')
    except Exception:
        logger.error('test error with %s', 'test_logging_redirect_tqdm')

    logger.error('test error with %s', 'test_logging_redirect_tqdm')


# Generated at 2022-06-26 09:25:06.344642
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import inspect
    a_logger = logging.getLogger(__name__)
    a_logger.addHandler(logging.StreamHandler())
    a_logger.setLevel(logging.DEBUG)
    with logging_redirect_tqdm():
        a_logger.debug('test debug message')
        a_logger.info('test info message')
        a_logger.warning('test warning message')
        a_logger.error('test error message')
        a_logger.critical('test critical message')
        assert inspect.currentframe().f_locals['self'] == tqdm_logging_handler_0
    assert 'test debug message' in tqdm_logging_handler_0.tqdm_class.write.call_args_list
    assert 'test info message'

# Generated at 2022-06-26 09:25:12.544230
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    logging.info("console logging")
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")
    logging.info("restored logging")

# Generated at 2022-06-26 09:25:23.197989
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:25:43.902069
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())

    logger.warning('Not redirected.')
    with logging_redirect_tqdm():
        logger.warning('Redirected to tqdm.')
    logger.warning('Not redirected.')


if __name__ == '__main__':
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:25:49.493405
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(desc='In progress ...') as pbar:
        logging.info('In progress ...')
        pbar.update(1)
    logging.info('Done')



# Generated at 2022-06-26 09:25:58.402053
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    import logging
    import sys
    root_logger = logging.getLogger()
    ch = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    root_logger.addHandler(ch)
    root_logger.setLevel(logging.DEBUG)
    log_message = 'Hello from logging'
    root_logger.debug(log_message)


# Generated at 2022-06-26 09:26:07.777301
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # test default value:
    with tqdm_logging_redirect(desc="default_tqdm") as pbar:
        assert pbar.desc == "default_tqdm"
        assert type(pbar) == std_tqdm

    # test explicitly passing in tqdm
    import tqdm, logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(desc="tqdm_tqdm", tqdm_class=tqdm.tqdm) as pbar:
        assert type(pbar) == tqdm.tqdm
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:26:15.341124
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        print('This should be displayed in tqdm.')
    sys.stdout.write('This should be displayed in console.')
    sys.stdout.flush()
    with tqdm_logging_redirect(logging_redirect_tqdm):
        print('This should be displayed in tqdm.')
    sys.stdout.write('This should be displayed in console.')
    sys.stdout.flush()


# Generated at 2022-06-26 09:26:24.655927
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:26:34.775037
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import logging
        with tqdm_logging_redirect(total=9) as pbar:
            for i in range(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    except:       # noqa pylint: disable=bare-except
        assert False, "Logging redirect failed"
    else:
        assert True, "Logging redirect successful"


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:26:40.015529
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with tqdm_logging_redirect(disable=True) as pbar:
        assert not pbar.disable
        with logging_redirect_tqdm():
            assert pbar.disable
        assert not pbar.disable

# Generated at 2022-06-26 09:26:45.109048
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(total=5) as pbar:
        logger.debug("Test tqdm_logging_redirect")
        pbar.update()



# Generated at 2022-06-26 09:26:51.019603
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import closing
    with closing(std_tqdm(desc="test_case_0")) as pbar:
        with logging_redirect_tqdm(tqdm_class=pbar.__class__):
            logging.info("Message info")
            logging.warning("Message warning")



# Generated at 2022-06-26 09:27:13.426590
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as gen:
        pass
    assert len(list(gen)) == 0

# Generated at 2022-06-26 09:27:25.589975
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .logging_redirect_tqdm import tqdm_logging_redirect
    from .guineapig import guineapig
    with tqdm_logging_redirect(total=1, unit_scale=0, unit_divisor=0) as pbar:
        guineapig(0, 100)
        assert not pbar.disable
    with tqdm_logging_redirect(
        total=1, unit_scale=0, unit_divisor=0,
        loggers=[logging.getLogger(guineapig.__name__)]) as pbar:
        guineapig(0, 100)
        assert not pbar.disable

# Generated at 2022-06-26 09:27:34.878137
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # set up a logger
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    # create console handler and set level to error
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    log.addHandler(ch)

    # logging test
    with tqdm_logging_redirect(total=5):
        for i in range(5):
            log.debug(str(i))

# Generated at 2022-06-26 09:27:42.363684
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    message_0 = "This is a test"
    record_0 = logging.LogRecord(message_0, logging.ERROR,
        'example.py', 52, message_0, None, None)
    tqdm_logging_handler_0.emit(record_0)


# Generated at 2022-06-26 09:27:51.674908
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-26 09:28:03.067238
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # Test logger
    tqdm_logger = logging.getLogger('tqdm_logging_test')

    try:
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(*[], loggers=[tqdm_logger],
                                   desc="Test", miniters=2, mininterval=1e-10) as pbar:
            for ii in range(10):
                tqdm_logger.info('Test message number ' + str(ii))
                pbar.update()

    except KeyboardInterrupt:
        pass


# Generated at 2022-06-26 09:28:15.477132
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import time

    # Unit test for function logging_redirect_tqdm
    def test_case_1():
        with logging_redirect_tqdm():
            logging.info('logging into tqdm.')

    # Unit test for function tqdm_logging_redirect
    def test_case_2():
        with tqdm_logging_redirect():
            logging.info('logging into tqdm.')

    # Unit test for function tqdm_logging_redirect
    def test_case_3():
        with tqdm_logging_redirect(desc='Hello'):
            logging.info('logging into tqdm.')

    # Unit test for function tqdm_logging_redirect

# Generated at 2022-06-26 09:28:23.879956
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # tqdm.set_slower_interval()
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in std_tqdm(range(3)):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("logging restored")

# Generated at 2022-06-26 09:28:28.282342
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for _ in trange(9):
            logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:28:36.889109
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm(total=9, desc='Case #0') as pbar:
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()
    with tqdm(total=9, desc='Case #1') as pbar:
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()


# Generated at 2022-06-26 09:29:37.923239
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    lg = logging.getLogger("")  # initialize logging
    lg.setLevel("DEBUG")
    # remove all handlers from logger
    for h in lg.handlers:
        lg.removeHandler(h)

    # generate a log message
    lg.debug("test")

    # check : no handlers registered
    assert  len(lg.handlers) == 0

    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    lg.addHandler(tqdm_logging_handler_0)
    # generate a log message
    lg.debug("test")

    # check : 1 handler registered
    assert  len(lg.handlers) == 1

    # generate a log message
    lg.debug("test")

    # check : 1 handler registered
    assert  len

# Generated at 2022-06-26 09:29:48.074538
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import sys

    # Check if a file named "test_log.txt" already exists in the working directory
    try:
        test_log = open('test_log.txt', 'r')
    except IOError: # If not existing
        test_log = open('test_log.txt', 'w') # Create it
    test_log.close()

    logging.basicConfig(filename='test_log.txt', filemode='a', level=logging.DEBUG)

    LOG = logging.getLogger(__name__)

    for i in range(9):
        if i == 4:
            with tqdm_logging_redirect(loggers=[LOG]):
                LOG.info("console logging redirected to `tqdm.write()`")

    # Open log file, check that it contains the logging

# Generated at 2022-06-26 09:29:57.494020
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(4, desc='main loop'):
                if i == 1:
                    LOG.info('console logging redirected to `tqdm.write()`')
                if i == 2:
                    LOG.info('i = 2')
        # logging restored
    return True



# Generated at 2022-06-26 09:30:00.827691
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log1 = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        log1.info('running...')
        log1.info('done.')
    log1.info('this should not appear')


# Generated at 2022-06-26 09:30:02.656978
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert pbar

# Generated at 2022-06-26 09:30:05.045664
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert (pbar.__class__ == std_tqdm)