

# Generated at 2022-06-26 09:20:13.573840
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logs = []
    # Create a Logger
    log = logging.getLogger('main.log')
    log.setLevel(logging.INFO)
    # Create a handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    # Create a formatter
    formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
    # Add the handler to the logger
    handler.setFormatter(formatter)
    log.addHandler(handler)
    # Logger use case
    log.info('This is an info')
    logs.append('This is an info')
    # Logging redirection

# Generated at 2022-06-26 09:20:19.693744
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from contextlib import redirect_stdout

    with redirect_stdout(sys.stdout):
        LOG = logging.getLogger(__name__)
        with tqdm_logging_redirect():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        assert True

# Generated at 2022-06-26 09:20:24.343420
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()
    logger.info("before redirect")
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("redirected logging to tqdm")
    logger.info("after redirect")


# Generated at 2022-06-26 09:20:34.539867
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # Reference:
    # https://stackoverflow.com/questions/1383254/logging-streamhandler-and-standard-streams
    # https://docs.python.org/3/howto/logging-cookbook.html#redirecting-logging-output-to-a-stream
    # https://docs.python.org/3/howto/logging-cookbook.html#using-loggeradapters-to-impart-contextual-information
    # https://docs.python.org/3/howto/logging-cookbook.html#logging-to-multiple-destinations
    # https://docs.python.org/3/howto/logging-cookbook.html#logging-to-a-single-file-from-multiple-processes
    # https://docs.python.

# Generated at 2022-06-26 09:20:44.857690
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm

    import io
    import os
    import sys

    sys.stdout = io.StringIO()
    with tqdm_logging_redirect(total=5) as pbar:
        for i in range(5):
            pbar.update(i)
    sys.stdout = sys.__stdout__

    sys.stdout = io.StringIO()
    with tqdm_logging_redirect(miniters=3, total=5) as pbar:
        for i in range(5):
            pbar.update(i)
    sys.stdout = sys.__stdout__



# Generated at 2022-06-26 09:20:51.527062
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    log = logging.getLogger(__name__)

    def main():
        log.info("info message")

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        main()


if __name__ == "__main__":
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:20:55.322612
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(desc='test_tqdm') as pbar:
        assert isinstance(pbar, std_tqdm)
        logger = logging.getLogger(__name__)
        logger.info('This is a test')

# Generated at 2022-06-26 09:21:03.630137
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(unit='B', unit_scale=True, miniters=1,
                               desc='test_tqdm_logging_redirect') as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                assert pbar.n == 4

    LOG = logging.getLogger(__name__)
    LOG.info('This should still go to stderr')

# Generated at 2022-06-26 09:21:14.720928
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.INFO)

    # First test with default loggers
    logger.info("This is a test")
    assert True
    
    # Second test with custom loggers
    logger_1 = logging.getLogger('test_logger_1')
    logger_1.setLevel(logging.INFO)
    logger_2 = logging.getLogger('test_logger_2')
    logger_2.setLevel(logging.INFO)
    with logging_redirect_tqdm(loggers=[logger_1, logger_2]):
        logger_1.info("This is a test")
        logger_2.info("This is a test")
    assert True

# Generated at 2022-06-26 09:21:26.342886
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)
    try:
        with logging_redirect_tqdm():
            log.info("Test")
    except tqdm.std.TqdmSynchronisationWarning:
        pass  # expected
    try:
        with logging_redirect_tqdm(loggers=[log]):
            log.info("Test")
    except tqdm.std.TqdmSynchronisationWarning:
        pass  # expected


try:
    from tqdm.auto import tqdm
    from tqdm.auto._tqdm_gui import tqdm_gui
except (ImportError, AttributeError):
    pass

# Generated at 2022-06-26 09:21:33.572211
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        log.info('test_case_1')



# Generated at 2022-06-26 09:21:44.662934
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import tempfile
    import threading
    import time
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    PATH = os.path.join(tempfile.gettempdir(), 'tqdm.log')

    def delete_log():
        import os
        try:
            os.remove(PATH)
        except OSError:
            pass

    delete_log()

    with tqdm(total=10, desc="Concurrent timer", file=StringIO()) as pbar:
        LOG = logging.getLogger(__name__)

# Generated at 2022-06-26 09:21:46.700489
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10, ncols=10) as pbar:
        assert pbar.total == 10

# Generated at 2022-06-26 09:21:55.464704
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())

    with tqdm_logging_redirect(logger=logger) as pbar:
        for i in range(3):
            logger.info("console logging redirected to tqdm.write()")
            pbar.update()
    assert pbar.n == 3
    assert pbar.total == 3
    assert pbar.last_print_n == 3


# Generated at 2022-06-26 09:22:02.226997
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    log = logging.getLogger(__name__)

    # Test if tqdm.write works correctly
    with tqdm_logging_redirect(logging.getLogger(__name__)) as pbar:
        for i in pbar:
            log.info(i)
    assert pbar.n == pbar.total == 10

    # Test if original logger works correctly
    log.handlers.extend(logging.getLogger(__name__).handlers)
    with tqdm_logging_redirect(logging.getLogger("other"), total=10) as pbar:
        for i in pbar:
            pass
    assert pbar.n == pbar.total, "{} != {}".format(pbar.n, pbar.total)


# Generated at 2022-06-26 09:22:08.961920
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """ Tests that tqdm_logging_redirect is working."""
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info("Test logging")


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info("Test logging")

# Generated at 2022-06-26 09:22:18.613494
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging
    log = logging.getLogger(__name__)
    tqdm.write = sys.stdout.write
    with tqdm_logging_redirect(total=2, file=sys.stdout):
        log.info('test_tqdm_logging_redirect_test_message')
        tqdm.write('test_tqdm_logging_redirect_write_message')
    assert True


if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:22:26.886597
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()

    class _LoggingRecord(object):
        def __init__(
            self,
            level=None,  # type: Optional[int]
            message=None,  # type: Optional[str]
        ):
            self.level = level
            self.message = message

        def __repr__(self):
            return '_LoggingRecord(level={}, message={})'.format(self.level, self.message)

    tqdm_logging_handler_1.emit(
        _LoggingRecord(message='foobar'))



# Generated at 2022-06-26 09:22:33.684289
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    for i in std_tqdm(range(9)):
        if i == 4:
            logger.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:22:40.430190
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up
    import logging
    import sys

    class MockLoggingHandler(logging.StreamHandler):
        def __init__(self, stream=sys.stderr, level=logging.NOTSET):
            self.stream = stream
            super(logging.StreamHandler, self).__init__(stream=stream)
            self.setLevel(level)
            self.records = []

        def emit(self, record):
            self.stream.write(record.msg)
            self.stream.write('\n')
            self.records.append(record)

    logger = logging.getLogger()
    original_streaming_handler = logger.handlers[0]
    mock_handler = MockLoggingHandler(stream=sys.stderr)
    logger.handlers

# Generated at 2022-06-26 09:22:59.989803
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from io import StringIO
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    buf = StringIO()
    handler = logging.StreamHandler(buf)
    handler.setFormatter(logging.Formatter('{message}', '{'))
    LOG.handlers = [handler]

    with tqdm_logging_redirect():
        LOG.debug('debug')
    assert buf.getvalue() == 'debug\n'

    buf.seek(0)
    buf.truncate()

    with tqdm_logging_redirect(desc='test'):
        LOG.debug('debug')
    assert buf.getvalue() == 'debug\n'

# Generated at 2022-06-26 09:23:07.680657
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=7, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}') as t:
        LOG = logging.getLogger(__name__)
        LOG.info("test logging")
        LOG.info("test logging")
        LOG.info("test logging")
        LOG.info("test logging")
        LOG.info("test logging")
        LOG.info("test logging")
        LOG.info("test logging")
        print(t)

# Generated at 2022-06-26 09:23:13.576778
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from tqdm.auto import trange
    with logging_redirect_tqdm():
        for i in trange(10):
            logging.info('Test logging to tqdm')



# Generated at 2022-06-26 09:23:25.197720
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from ..std import StringIO
    from ..std import tqdm as std_tqdm

    try:
        import cStringIO as cStringIO_mod
    except ImportError:
        cStringIO_mod = StringIO

    try:
        from unittest import mock
    except ImportError:
        import mock  # type: ignore

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    LOG.propagate = False

    def _reset_logger(logger):
        logger.handlers = []
        logger.addHandler(logging.NullHandler())


# Generated at 2022-06-26 09:23:28.906043
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    logging_record_1 = logging.LogRecord("name", 0, None, 0, "msg", None, None)
    tqdm_logging_handler_1.emit(logging_record_1)



# Generated at 2022-06-26 09:23:35.356142
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    try:
        tqdm_logging_handler_0.emit("testcase")
    except Exception:
        pass
    else:
        raise AssertionError("AssertionError")


# Generated at 2022-06-26 09:23:38.661807
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with logging_redirect_tqdm():
        logging.info("bar")

if __name__ == "__main__":
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:23:51.078405
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)

    # logging to console is disabled by default
    logger = logging.getLogger(__name__)
    logger.error("console logging is disabled by default")
    logger.info("console logging is disabled by default")

    # Test with target filename
    with open('test_logging_redirect_tqdm.log', 'w') as logfile:
        hdlr = logging.FileHandler(logfile.name)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)
        logger.addHandler(hdlr)
        logger.setLevel(logging.INFO)

        # logging to file

# Generated at 2022-06-26 09:24:02.512649
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from .logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test_case_logging_redirect_tqdm_0():
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    def test_case_logging_redirect_tqdm_1():
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test_case_logging_redirect_tqdm_0()

# Generated at 2022-06-26 09:24:03.781696
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with tqdm_logging_redirect(file=open(os.devnull, 'w'), desc='Test'):
        logging.info("Info message")

# Generated at 2022-06-26 09:24:19.721635
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=[logging.root], tqdm_class=std_tqdm) as pbar:
        pbar.update()
        logging.root.info("test")

# Generated at 2022-06-26 09:24:29.526175
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()

    class mock_tqdm:
        public_members = ['write', 'flush']

        def write(self, msg, file=sys.stderr):
            pass

        def flush(self):
            pass

    # set logging handler's stream member to mock_tqdm
    tqdm_logging_handler.stream = mock_tqdm
    logging_record = logging.LogRecord('name', 'level', 'pathname', 'lineno',
                                       'msg', 'args', 'exc_info')

    # test when no error
    try:
        tqdm_logging_handler.emit(logging_record)
    except (KeyboardInterrupt, SystemExit):
        raise

# Generated at 2022-06-26 09:24:34.613973
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            time.sleep(0.1)
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-26 09:24:45.581590
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_tqdm import pretest_posttest_test

    @pretest_posttest_test
    def test(desc=None):
        if desc == 'test':
            assert "test" in std_tqdm.messages

    with logging_redirect_tqdm():
        LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(desc='test'):
        LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name

# Generated at 2022-06-26 09:24:54.297906
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import threading
    from tqdm import tqdm
    import time
    
    def main_func(num):
        for i in tqdm(range(num), desc='foo'):
            with tqdm_logging_redirect():
                logging.info(str(i))
            time.sleep(0.3)
    
    def main_func_1(num):
        for i in tqdm(range(num), desc='foo1'):
            with tqdm_logging_redirect():
                logging.info(str(i))
            time.sleep(0.3)

    t = threading.Thread(target=main_func, args=(5,))
    t1 = threading.Thread(target=main_func_1, args=(5,))
    t.start()

# Generated at 2022-06-26 09:25:05.109891
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test logging_redirect_tqdm functionality."""

    # import logging
    # from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm

    # LOG = logging.getLogger(__name__)
    test_file_path = 'test_logging_redirect_tqdm_file.txt'

    with open(test_file_path, 'w') as f:
        with logging_redirect_tqdm(tqdm_class=lambda x: f):
            # for i in trange(9):
            #     LOG.info('test')
            print('test', file=f)

    with open(test_file_path, 'r') as f:
        assert f.read() == 'test\n'

    # logging loggers =

# Generated at 2022-06-26 09:25:11.920830
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    def foo():
        for i in trange(10):  # pylint: disable=unused-variable
            pass
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        foo()



# Generated at 2022-06-26 09:25:25.230631
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.cli import tqdm

    tqdm_class = tqdm
    tqdm = tqdm_class()

    # pylint: disable=redefined-outer-name
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stderr))

    for _ in range(5):
        logger.info('hello')

    # redirect logging to tqdm
    with logging_redirect_tqdm(loggers=[logger], tqdm_class=tqdm_class):
        for _ in tqdm:
            logger.info('world')

    for _ in range(5):
        logger.info('hello')
    # pyl

# Generated at 2022-06-26 09:25:33.444590
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # TODO: check tqdm output
    import logging

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    with logging_redirect_tqdm():
        LOG.debug('debug')
        LOG.info('info')
        LOG.warning('warning')
        LOG.error('error')
        LOG.critical('critical')



# Generated at 2022-06-26 09:25:42.438165
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Setup
    log = logging.getLogger()
    original_handlers = log.handlers
    log.handlers = [logging.StreamHandler()]
    try:
        with logging_redirect_tqdm() as _:
            pass
        assert any([isinstance(h, logging.StreamHandler)
                    for h in log.handlers])
    finally:
        log.handlers = original_handlers



# Generated at 2022-06-26 09:26:15.224859
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import time
    import logging
    from tqdm import trange

    print("testing tqdm_logging_redirect context manager")
    logfile = os.path.join(os.path.dirname(__file__), 'test.log')

    try:
        logging.basicConfig(filename=logfile, level=logging.INFO)
        LOG = logging.getLogger("tqdmlog")
        with tqdm_logging_redirect():
            for _ in trange(9):
                LOG.info("test")
                time.sleep(0.1)
    finally:
        os.remove(logfile)

# Generated at 2022-06-26 09:26:22.397563
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    import tqdm
    with tqdm_logging_redirect():
        for i in tqdm.trange(5):
            logging.info(i)
            time.sleep(.01)


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:26:28.061684
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')



# Generated at 2022-06-26 09:26:30.844820
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=None) as pbar:
        pbar.write("Hello")

# Generated at 2022-06-26 09:26:35.278851
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect() as pbar:
        logging.info("test")
        pbar.update()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:26:47.175091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.utils import _term_move_up
    from .utils import _range

    from datetime import datetime
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger('test_logging_redirect_tqdm')

    def logTest(log, i, count):
        log.info("{}/{}".format(i, count))

    case = 'default redirect'
    log.info(case)
    log.info("Before {}".format(case))

    with logging_redirect_tqdm():
        _range(9, desc=case, leave=True).map(logTest, log, _range(9))

    log.info("After {}".format(case))

    case = 'custom tqdm'
   

# Generated at 2022-06-26 09:26:57.195435
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    import logging.handlers

    from .test_tqdm import pretest_posttest  # pylint: disable=unused-import

    from tqdm import tqdm_notebook

    logging.basicConfig(level=logging.INFO)
    # to test for notebook, just comment out the following line:
    logging.getLogger().handlers = [logging.StreamHandler()]

    # test for file logging
    filehandler = logging.FileHandler("test_file")
    filehandler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    filehandler.setFormatter(formatter)
    logging.getLogger().addHandler(filehandler)

    logger1

# Generated at 2022-06-26 09:27:07.638659
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # logger = logging.getLogger(__name__)

    # regular setup
    logging.basicConfig(level=logging.INFO)

    # log messages should be visible
    with logging_redirect_tqdm():
        logging.info('visible message')
        logging.warning('another visible message')
        logging.critical('critical visible message')
    assert logging.getLogger().handlers == [], \
        'handlers not restored properly'

    # custom loggers
    logger0 = logging.getLogger('logger0')
    logger1 = logging.getLogger('logger1')

    # log messages should be visible
    with logging_redirect_tqdm([logger0, logger1]):
        logger0.info('visible message')
        logger0.warning('another visible message')
        logger1

# Generated at 2022-06-26 09:27:16.046303
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    try:
        with tqdm_logging_redirect(
                loggers=[log, logging.root],
                desc="test_logging_redirect_tqdm",
                ncols=100):
            log.info("logging redirected to `tqdm.write()`")
            print("Original print statement")
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        sys.stderr.write("\nTest failed!\n")
        raise

# Generated at 2022-06-26 09:27:27.825751
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm._utils import _term_move_up
    import logging
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stdout', new=sys.stdout):
        with tqdm_logging_redirect():
            logging.info("message")

    with patch('sys.stdout', new=sys.stdout):
        with tqdm_logging_redirect(ascii=True):
            logging.info("message")

    log_formatter = logging.Formatter("[%(levelname)s] %(message)s")

# Generated at 2022-06-26 09:28:21.740113
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import tqdm
    except ImportError:
        tqdm = std_tqdm
    with tqdm_logging_redirect():
        logging.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-26 09:28:24.565151
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..tests import test_tqdm_logging_redirect
    test_tqdm_logging_redirect(
        tqdm_logging_redirect,
        tqdm_class=std_tqdm
    )



# Generated at 2022-06-26 09:28:35.891582
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    class TqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            self.lines = []
            super(TqdmLoggingHandler, self).__init__(
                tqdm_class=lambda x: self)

        def write(self, s):
            self.lines.append(s)

    tqdm_logging_handler = TqdmLoggingHandler()
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    with logging_redirect_tqdm(loggers=[log], tqdm_class=TqdmLoggingHandler):
        log.debug("123")
        log.info("456")
        log.warning("789")
        log.error("012")

    assert tqdm_log

# Generated at 2022-06-26 09:28:40.116563
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect():
        logging.info("info")
        logging.warning("warning")
        logging.error("error")

# Generated at 2022-06-26 09:28:47.963154
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test without loggers
    with tqdm_logging_redirect():
        pass

    # Test without loggers and without tqdm_class
    with tqdm_logging_redirect(tqdm_class=tqdm_logging_handler_0):
        pass


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:28:58.190944
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        # This with block should not be indented
        with tqdm_logging_redirect(total=9,
                                   file=sys.stdout,
                                   unit='B',
                                   unit_scale=True) as pbar:
            for i in trange(9, file=sys.stdout):
                pbar.update(1)
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
       

# Generated at 2022-06-26 09:29:02.239246
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect():
        logging.info("Console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:29:08.417422
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc="tqdm redirect") as progress_bar:
        progress_bar.set_description("foo bar")
        progress_bar.set_postfix({"postfix_key": "postfix_value"})
        progress_bar.update()
        print("tqdm logging redirect")
        LOG.debug("tqdm logging redirect")
        LOG.info("tqdm logging redirect")
        LOG.warning("tqdm logging redirect")
        LOG.error("tqdm logging redirect")
        LOG.critical("tqdm logging redirect")
        progress_bar.update()
    print("tqdm logging redirect restored")
    LOG.debug("tqdm logging redirect restored")

# Generated at 2022-06-26 09:29:18.041735
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test if logging_redirect_tqdm works as expected
    """
    def test_logging_redirect_tqdm_function(test_loggers):
        # set logging.getLogger().handlers to test_loggers
        for logger in [logging.getLogger()]:
            logger.handlers = test_loggers

        with logging_redirect_tqdm(loggers=[logging.getLogger()]):
            for logger in [logging.getLogger()]:
                assert len(logger.handlers) == 2
                assert isinstance(logger.handlers[1], logging.StreamHandler)
            logging.info('test')
            for logger in [logging.getLogger()]:
                assert len(logger.handlers) == 2

# Generated at 2022-06-26 09:29:22.462524
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.stream = sys.stderr
    tqdm_logging_handler_0.level = logging.INFO
    tqdm_logging_handler_0.emit(logging.LogRecord(
        "name", logging.INFO, __file__, 1,
        "msg", tuple(), None))
