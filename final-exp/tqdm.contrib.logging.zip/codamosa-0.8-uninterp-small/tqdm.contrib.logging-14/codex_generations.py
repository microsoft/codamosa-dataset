

# Generated at 2022-06-26 09:20:20.440772
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test that we can redirect logging to tqdm.write()
    """
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        LOG = logging.getLogger(__name__)
        LOG.info("this should print with tqdm")

    LOG = logging.getLogger(__name__)
    LOG.info("this should print without tqdm")

# A decorator to pause the test for a given timeout in seconds

# Generated at 2022-06-26 09:20:22.517776
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
        tqdm_logging_handler_0 = _TqdmLoggingHandler()
        tqdm_logging_handler_0.emit("Test")

# Generated at 2022-06-26 09:20:27.146819
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # base case, with tqdm_redirect
    with tqdm_logging_redirect('test', logging.getLogger()):
        pass

    # check with tqdm instance
    with tqdm_logging_redirect(std_tqdm(desc='test'), logging.getLogger()):
        pass

# Generated at 2022-06-26 09:20:32.962255
# Unit test for function tqdm_logging_redirect

# Generated at 2022-06-26 09:20:42.619308
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    loggers = [logging.getLogger(__name__)]
    # loggers=[logging.root]
    logging.basicConfig(level=logging.INFO)
    test_list = []
    with tqdm_logging_redirect(total=9, loggers=loggers, logger=loggers[0], level=logging.INFO):
        for i in trange(9):
            if i == 4:
                loggers[0].info("console logging redirected to `tqdm.write()`")
    assert len(test_list) == 9



# Generated at 2022-06-26 09:20:50.902790
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange

    def test_case_1():
        logging.basicConfig()
        logging.info("foo")

    for test_case in [test_case_1]:
        with logging_redirect_tqdm():
            test_case()
            with trange(10) as pbar:
                logging.info("bar")
                for _ in pbar:
                    pass
                logging.info("baz")
            logging.info("qux")



# Generated at 2022-06-26 09:20:58.943604
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # Redirects logging to tqdm
    with tqdm_logging_redirect():
        logging.info("test")

    # Redirects logging to tqdm with custom arguments
    with tqdm_logging_redirect(position=42, total=100, desc="test",
                               bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"):
        logging.info("test")

    # Redirects logging to tqdm with custom logger
    logger = logging.getLogger("test")
    with tqdm_logging_redirect(loggers=[logger]):
        logger.info("test")

# Generated at 2022-06-26 09:21:04.813308
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("before")
    with tqdm_logging_redirect() as pbar:
        with logging_redirect_tqdm() as _:
            with tqdm_logging_redirect(total=1):
                logger.info("inside")
        logger.info("between")
    logger.info("after")

# Generated at 2022-06-26 09:21:11.572335
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:21:20.893044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm._utils import _term_move_up

    with trange(9) as pbar:
        logging.basicConfig(level=logging.DEBUG, format="%(message)s")
        with logging_redirect_tqdm():
            for i in pbar:
                if i == 4:
                    LOG = logging.getLogger("test_logging_redirect_tqdm")
                    LOG.info("console logging redirected to `tqdm.write()`")
                    LOG.debug("also `logging.debug()`")
                    LOG.info("you can even use %s", _term_move_up())
                    LOG.info("in-place refresh")

# Generated at 2022-06-26 09:21:26.944283
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pbar.update()



# Generated at 2022-06-26 09:21:34.260256
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[log], desc='test') as pbar:
        msg = 'Message in TQDM'
        log.info('%s', msg)


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:21:41.065606
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        # total=10 should be passed to tqdm
        assert pbar.total == 10
        for _ in range(10):
            logging.info("test")
            pbar.update()
            # everything should be redirected
            # NB: stdout could be redirected multiple times
            # so we can't check if it was redirected exactly once
            assert not pbar.fp.isatty()



# Generated at 2022-06-26 09:21:49.730179
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger('logging_redirect_tqdm')
    LOG.addHandler(logging.NullHandler())

    LOG.info("Before redirect")
    if logging_redirect_tqdm() is not None:
        raise ValueError('logging_redirect_tqdm() should not return anything')
    # Context manager should redirect logging to tqdm.write()
    LOG.info('During redirect')
    with tqdm(total=1) as t:
        t.update(1)
    # Context manager should have restored logging to stdout
    LOG.info('After redirect')



# Generated at 2022-06-26 09:21:59.459369
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging

    LOGGER = logging.getLogger(__name__)
    LOGGER.setLevel(logging.DEBUG)
    LOGGER.propagate = False
    HANDLER = logging.StreamHandler()
    FORMATER = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s')
    HANDLER.setFormatter(FORMATER)
    LOGGER.addHandler(HANDLER)

    with tqdm_logging_redirect(total=5) as pbar:
        for i in range(5):
            LOGGER.debug("Debug message")
            LOGGER.info("Info message")
            LOGGER.warning("Warning message")
            LOGGER.error("Error message")
            LOGGER.critical("Critical message")
           

# Generated at 2022-06-26 09:22:10.816977
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger('test')

    assert logging.root.handlers == []
    assert logger.handlers == []

    logging.basicConfig(level=logging.INFO)

    # tqdm_logging_handler doesn't handle it
    try:
        with logging_redirect_tqdm():
            logger.info('test')
    except AttributeError:
        pass

    # non-streamhandler logging.root.handlers
    logging.root.handlers = [logging.StreamHandler()]
    try:
        with logging_redirect_tqdm():
            logger.info('test')
    except AttributeError:
        pass

    # logging.root.handlers without stream
    logging.root.handlers = []

# Generated at 2022-06-26 09:22:20.647263
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record = logging.LogRecord('name', logging.INFO, 'pathname', 1, 'msg',
                               None, None)
    tqdm_logging_handler_1.emit(record)
    record = logging.LogRecord('name', logging.INFO, 'pathname', 1, 'msg',
                               None, None)
    record.exc_info = KeyboardInterrupt()
    try:
        tqdm_logging_handler_1.emit(record)
        raise Exception("Exception KeyboardInterrupt was not raised")
    except KeyboardInterrupt:
        pass


# Generated at 2022-06-26 09:22:27.811704
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from io import StringIO
    from .utils import _range

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    with StringIO() as log_out:
        handler = logging.StreamHandler(log_out)
        log.addHandler(handler)

        with tqdm_logging_redirect(file=log_out):
            for _ in _range(10):
                log.info(_)
        log.removeHandler(handler)

        assert len(log_out.getvalue().split('\n')) == 12



# Generated at 2022-06-26 09:22:34.780858
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Note: This test is only to check if the function runs without error.
    """
    with tqdm_logging_redirect(total=9, bar_format='{l_bar}{bar}|'):
        logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-26 09:22:39.810252
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # capture stdout into variable
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    logger = logging.getLogger(__name__)
    tqdm_logging_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logging_handler)
    logger.addHandler(old_stdout)
    logger.error("some log message")
    assert isinstance(tqdm_logging_handler, _TqdmLoggingHandler)
    # check if stdout has been captured
    assert mystdout.getvalue()

# Generated at 2022-06-26 09:23:17.011469
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(bar_format='{l_bar}{bar}{r_bar}',
                            desc='tqdm_logging_redirect',
                            total=9) as pbar:
        LOG = logging.getLogger(__name__)
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:23:23.004659
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Tests that console logging is redirected to `tqdm.write()` inside the
    context manager, and restored after exiting it.
    """
    # redirect all logging to tqdm.write()
    with logging_redirect_tqdm():
        logging.info("info msg")
        logging.warning("warning msg")
    # logging restored
    logging.info("info msg")
    logging.warning("warning msg")



# Generated at 2022-06-26 09:23:26.017608
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import _test_logging_redirect_tqdm
    _test_logging_redirect_tqdm()



# Generated at 2022-06-26 09:23:31.453921
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logger = logging.getLogger()

        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")

        logger.warning("warning2")
        logger.error("error2")
        logger.critical("critical2")

        logging.basicConfig(level=logging.INFO)
        logger.warning("warning3")
        logger.error("error3")
        logger.critical("critical3")

        logging.getLogger().propagate = False
        logger.warning("warning4")
        logger.error("error4")
        logger.critical("critical4")

if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:23:41.374658
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()

    tqdm_logging_handler_0 = _TqdmLoggingHandler()
    tqdm_logging_handler_0.setLevel(logging.DEBUG)
    logger.addHandler(tqdm_logging_handler_0)
    logger.info("test-info")
    logger.debug("test-debug")
    logger.warning("test-warning")
    tqdm_logging_handler_0.emit(logging.INFO)
    tqdm_logging_handler_0.emit(logging.DEBUG)
    tqdm_logging_handler_0.emit(logging.WARNING)

# Generated at 2022-06-26 09:23:45.568825
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=1) as pbar:
        logging.getLogger().info('message1')
        pbar.update()
    assert pbar.n == 1

# Generated at 2022-06-26 09:23:54.037274
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.contrib import logging as tqdm_logging
    import logging

    logger = logging.getLogger(__name__)
    for i in tqdm(range(9), desc="test_logging_redirect_tqdm"):
        if i == 4:
            with tqdm_logging.logging_redirect_tqdm([logger]):
                logger.info("console logging redirected to `tqdm.write()`")
    logger.info("logging restored")


# Generated at 2022-06-26 09:23:57.667825
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert pbar.__class__ is std_tqdm

# Generated at 2022-06-26 09:24:03.282104
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=1000,
                               file=sys.stdout,
                               desc='TEST_CASE_0',
                               leave=True) as pbar:
        for i in range(1000):
            logging.info("Test Case {}".format(i))
            pbar.update()
    logging.info("OUT")

if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:24:12.975435
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect() as pbar:
        # The point is to let logging report to stdout
        # while keeping tqdm silent
        for i in range(10):
            LOG.info(i)
            pbar.update(1)

        # The point is to let logging report to stdout
        # while keeping tqdm silent
        for i in range(10):
            LOG.info(i)
            pbar.update(1)

        # The point is to let logging report to stdout
        # while keeping tqdm silent

# Generated at 2022-06-26 09:24:44.120002
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_1 = _TqdmLoggingHandler()
    record = logging.LogRecord(
        name='root',
        level=logging.INFO,
        pathname='/usr/local/lib/python3.7/logging/__init__.py',
        lineno=1306,
        msg='test_logging_redirect_tqdm',
        args=(),
        exc_info=None
    )
    tqdm_logging_handler_1.emit(record)

# Generated at 2022-06-26 09:24:52.170620
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-26 09:25:04.569553
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-26 09:25:14.430550
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler_0 = _TqdmLoggingHandler()

    def mocked_TqdmLoggingHandler_emit(*args, **kwargs):
        print(args, kwargs)

    tqdm_logging_handler_0_emit_method = tqdm_logging_handler_0.emit
    mocked_TqdmLoggingHandler_emit = mocked_TqdmLoggingHandler_emit
    tqdm_logging_handler_0.emit = mocked_TqdmLoggingHandler_emit
    tqdm_logging_handler_0.emit()

# Generated at 2022-06-26 09:25:26.160612
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    from tqdm.utils import _term_move_up
    with tqdm_logging_redirect():
        logging.info("1")
        with tqdm_logging_redirect(tqdm_class=logging.info):
            logging.info("1")
            time.sleep(0.11)
            logging.info("2")
    with tqdm_logging_redirect(total=1):
        logging.info("2")

    # this raises an error
    # with tqdm_logging_redirect() as logging_redirect:
    #     logging.info("1")
    #     logging_redirect.write("2")

    # these also raise errors
    # with tqdm_logging_redirect(bar_format='{l_bar}'

# Generated at 2022-06-26 09:25:31.230831
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_logging_redirect()


if __name__ == "__main__":
    """
    To test:
    python -m tqdm.contrib.logging
    """
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:35.935349
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.info("hello")
    with tqdm_logging_redirect(miniters=1, mininterval=0) as pbar:
        LOG.info("tqdm redirect")
        pbar.update()
    LOG.info("end")


# Generated at 2022-06-26 09:25:43.698717
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create an instance of the handler
    tqdm_logging_handler = _TqdmLoggingHandler()
    # Create a logger to use it
    logger = logging.getLogger("some_logger")
    logger.setLevel(logging.INFO)
    logger.addHandler(tqdm_logging_handler)
    # Create an instance of the logger with an emit
    logger.info("End")

# Generated at 2022-06-26 09:25:50.473761
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=5, ascii=True) as pbar:
        for i in range(5):
            pbar.set_description("%s" % i)
            logging.info("Info message %s" % i)
    assert pbar.n == 5

# Generated at 2022-06-26 09:25:55.499014
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar_0:
        pbar_0.update()
        with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar_1:
            pbar_1.update()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:26:49.337692
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = "log test message"
    record = logging.LogRecord(msg, logging.DEBUG, '', 0, msg, None, None)
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit(record)

# Generated at 2022-06-26 09:26:53.532373
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)  # pylint: disable=no-member
    with tqdm_logging_redirect() as pbar:
        logging.info('test')  # pylint: disable=no-member
        pbar.update(1)
        logging.info('test')  # pylint: disable=no-member
        pbar.update(1)

# Generated at 2022-06-26 09:26:56.441162
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm

    logging_redirect_tqdm()

    tqdm_redirect_with_tqdm = tqdm_logging_redirect()
    tqdm_redirect_with_tqdm = tqdm_logging_redirect("test")

# Generated at 2022-06-26 09:27:07.463480
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import numpy as np
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    log_format = '%(asctime)s %(funcName)s:%(lineno)d - %(message)s'
    logging_handler = logging.StreamHandler()
    formatter = logging.Formatter(log_format)
    logging_handler.setFormatter(formatter)
    logger.addHandler(logging_handler)

    logger.setLevel(logging.INFO)
    logging.info("Normal log with log level INFO")

# Generated at 2022-06-26 09:27:13.314901
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(total=10, desc='Example') as pbar:
        for i in range(10):
            pbar.update(1)
            logger.debug("logging message")

# Generated at 2022-06-26 09:27:20.615592
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:27:27.980557
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    logging.basicConfig(level=logging.INFO)
    LOGGER = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[LOGGER]) as pbar:
        LOGGER.info('0')
        LOGGER.info('1')
        LOGGER.info('2')
        pbar.update(1)
        LOGGER.info('3')


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:27:33.690919
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)
    old_handlers = logger.handlers
    with logging_redirect_tqdm():
        assert len(logger.handlers) == len(old_handlers) + 1
        assert isinstance(logger.handlers[-1], _TqdmLoggingHandler)
        assert logger.handlers[0:len(old_handlers)] == old_handlers



# Generated at 2022-06-26 09:27:39.854196
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100) as pbar:
        import logging
        LOG = logging.getLogger(__name__)
        for i in range(100):
            LOG.info(i)

    assert pbar.n == 100

# Generated at 2022-06-26 09:27:46.691462
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import trange
    logger = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO, stream=sys.stderr)
        assert logger.handlers
        orig_handlers = logger.handlers
        with logging_redirect_tqdm():
            for i in trange(4):
                logger.info('console logging redirected to `tqdm.write()`')
                time.sleep(0.1)
        assert orig_handlers == logger.handlers, 'logger handlers restored'
        # logging restored



# Generated at 2022-06-26 09:29:50.243968
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.DEBUG, format='%(message)s')
    LOG = logging.getLogger()

    with tqdm_logging_redirect() as pbar:
        LOG.debug('debug')  # not shown
        LOG.info('info')  # shown

    with logging.Logger(__name__) as log:
        log.setLevel(logging.DEBUG)
        with tqdm_logging_redirect(desc=__name__) as pbar:
            log.debug('debug')  # not shown
            log.info('info')  # shown

    with tqdm_logging_redirect(desc=__name__, total=1) as pbar:
        LOG.info('info')  # shown
        pbar.close()


# Generated at 2022-06-26 09:29:54.946945
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(range(10), describe=1, logging_level=logging.DEBUG) as tqdm_pbar:
        # assert tqdm_pbar == 1
        print('hello')


# Generated at 2022-06-26 09:29:59.239234
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(loggers=[logging.getLogger()],
                               tqdm_class=std_tqdm,
                               total=3):
        pass


# Generated at 2022-06-26 09:30:06.534973
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger()
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    logger.info("test")
    with tqdm_logging_redirect(
            "test",
            total=2,
            loggers=[logger],
            tqdm_class=std_tqdm) as pbar:
        logger.info("test")
        pbar.update()
        logger.info("test")
        pbar.update()
