

# Generated at 2022-06-26 09:20:19.890331
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:20:29.434152
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # Initialize some loggers
    print("Initializing loggers...")
    tqdm_logger = logging.getLogger("tqdm")
    tqdm_logger.setLevel(logging.INFO)
    test_logger = logging.getLogger("test")

    # Set logging level for console
    logging.basicConfig(level=logging.INFO)
    print("Logging level for console is set to:", logging.getLogger().level)

    # Setup logging_redirection to tqdm

# Generated at 2022-06-26 09:20:38.324239
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys

    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout
    logger = logging.Logger('tqdm')
    logger.addHandler(handler)
    logger.handlers[0].setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.info('This is a test')
    assert len(logger.handlers) == 0


# Generated at 2022-06-26 09:20:45.046390
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9, ascii=True):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-26 09:20:48.083072
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.info('important')
        LOG.debug('not important')


# Generated at 2022-06-26 09:20:53.182075
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    for i in range(9):
        with logging_redirect_tqdm([log]):
            log.info('Intermediate output: %s', str(i))
    # logging.root.handlers = original_handlers



# Generated at 2022-06-26 09:21:02.646382
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from collections import deque
    import logging
    import sys

    from .std import tqdm
    from .std import __name__ as tqdm_name

    try:
        from logging import NullHandler
    except ImportError:
        class NullHandler(logging.Handler):
            def emit(self, record):
                pass

    # Mock sys.stdout
    def mock_stdout_write(s):
        _mock_stdout_write.append(s)

    # Mock sys.stderr
    def mock_stderr_write(s):
        _mock_stderr_write.append(s)


# Generated at 2022-06-26 09:21:14.234555
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Only does basic testing for a variety of loggers and handlers
    """
    import logging
    from tqdm.auto import tqdm
    from .utils import TestBar, close_all

    with close_all():
        # Test all these combinations
        for loggers in [[logging.root],
                        logging.Logger.manager.loggerDict.values()]:
            for tqdm_class in [TestBar, tqdm]:
                LOG = logging.getLogger(__name__)

                # Loggers should start with no streams
                assert all(len(logger.handlers) == 0
                           for logger in loggers)
                # Loggers should still hold on to their stream
                # (not yet logged to, so should not show up)

# Generated at 2022-06-26 09:21:15.960817
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = 'msg'
    _TqdmLoggingHandler().emit(msg)


# Generated at 2022-06-26 09:21:24.001169
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    # Set up python logger
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.getLogger(), logging.getLogger()]
    # Redirect console logging to tqdm.write()
    with tqdm_logging_redirect(loggers=loggers,
                               tqdm_class=std_tqdm,
                               file=sys.stdout):
        # Log both to tqdm and console
        for logger in loggers:
            logger.info('This should log both to tqdm and console')

# Generated at 2022-06-26 09:21:34.344541
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)

        with logging_redirect_tqdm() as pbar:
            with logging_redirect_tqdm() as pbar:
                LOG.info("console logging redirected to `tqdm.write()`")
    finally:
        # restore logging
        logging.basicConfig(level=logging.INFO)


# Generated at 2022-06-26 09:21:45.638416
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import tnrange, trange, tqdm
    import logging

    try:
        with tqdm_logging_redirect(total=100) as pbar:
            for _ in trange(100):
                pbar.update()
            pbar.close()
    except AttributeError:
        # python 2.6 compatibility
        return

    try:
        with tqdm_logging_redirect(total=100, loggers=[logging.getLogger()]) as pbar:
            for _ in trange(100):
                pbar.update()
            pbar.close()
    except AttributeError:
        # python 2.6 compatibility
        return


# Generated at 2022-06-26 09:21:49.547425
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging_redirect_tqdm()
    logging_redirect_tqdm(loggers=[])
    logging_redirect_tqdm(loggers=[logging.root])
    logging_redirect_tqdm(tqdm_class=std_tqdm)
    logging_redirect_tqdm(loggers=[logging.root], tqdm_class=std_tqdm)


# Generated at 2022-06-26 09:21:52.098789
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logging.debug("This should appear on the console")



# Generated at 2022-06-26 09:21:58.638724
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:22:06.668024
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    LOG.info('This is a message before redirecting.')
    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info('This is a message during redirecting.')
    LOG.info('This is a message after redirecting.')

if __name__ == "__main__":
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:22:13.945551
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import std as tqdm_std
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging


    logging.basicConfig(level=logging.INFO)

    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.setLevel(logging.INFO)

    with logging_redirect_tqdm([logger], tqdm_class=tqdm_std):
        logger.info("tqdm should be here")



# Generated at 2022-06-26 09:22:22.927756
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with tqdm_logging_redirect() as pbar:
        # Python 3.2
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
        assert pbar.n == 9
    try:
        with tqdm_logging_redirect() as pbar:
            assert False
    except AssertionError:
        pass
    else:
        assert False


# Test for proper format

# Generated at 2022-06-26 09:22:30.572396
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tempfile
    with tempfile.TemporaryFile() as tf:
        tqdm_logging_handler_0 = _TqdmLoggingHandler()
        tqdm_logging_handler_0.stream = tf
        tqdm_logging_handler_0.emit(logging.LogRecord(None, None, None, None, None, None, None, None))
        tf.seek(0)
        tqdm_logging_handler_0.emit(logging.LogRecord(None, None, None, None, None, None, None, None))
        tf.seek(0)
        tqdm_logging_handler_0.emit(logging.LogRecord(None, None, None, None, None, None, None, None))


# Generated at 2022-06-26 09:22:37.412992
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert True



# Generated at 2022-06-26 09:22:53.658762
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, logging_redirected

    try:
        # Test outside of context manager (should not raise)
        assert not logging_redirected
    except AssertionError as _:
        # Python 2.6 - 3.3 compatibility: check string
        assert str(_) == 'Logging should not be redirected out of context manager'
    else:
        logging.info('Test: logging_redirect_tqdm outside of context manager')

    with logging_redirect_tqdm():
        assert logging_redirected

        # Test logging redirected
        logging.info('Test: logging_redirect_tqdm with default loggers')

        # Test with custom logger

# Generated at 2022-06-26 09:22:56.768980
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # If the function works properly, nothing will be printed
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-26 09:23:05.511592
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    # This test is expected to fail with an assertion error
    logger = logging.getLogger(__name__)
    # logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(loggers=[logger], total=100) as pbar:
        logger.info("console logging redirected to `tqdm.write()`")
        pbar.update(25)

# Generated at 2022-06-26 09:23:14.782747
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, _is_console_logging_handler, _get_first_found_console_logging_handler

    loggers = [logging.root, logging.getLogger("root"), logging.getLogger("root2")]
    for logger in loggers:
        logger.info("abc")
        logger.setLevel(logging.DEBUG)
        logger.debug("def")

    # Check function _is_console_logging_handler
    assert not _is_console_logging_handler(logging.StreamHandler(sys.stdout))
    assert not _is_console_logging_handler(logging.StreamHandler(sys.stderr))

# Generated at 2022-06-26 09:23:24.563557
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create logger object
    logger = logging.getLogger('mytest')

    # Create handler and assign it to logger
    tqdm_logging_handler = _TqdmLoggingHandler(logger)

    # Create log message
    log_msg = 'Test log message'

    # Create logging message with level set to 'INFO'
    log_record = logging.LogRecord(logger.name, logging.INFO, logger.pathname,
                                   logger.lineno, log_msg, None, None)

    # Write to stream
    tqdm_logging_handler.emit(log_record)


# Unit test to check whether redirecting logging to tqdm is
# done successfully or not

# Generated at 2022-06-26 09:23:29.072090
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    try:
        with tqdm_logging_redirect(total=9, desc="this is a test",
                                   unit="itn", leave=False):
            raise ValueError
    except ValueError:
        pass


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:23:41.018273
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import unittest

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.handlers[0].formatter.datefmt = '%H:%M:%S'  # hours, minutes and seconds

    @contextmanager
    def nop_context_manager():
        # type: () -> Iterator[None]
        """Does nothing"""
        yield

    class TestLoggingRedirectTqdm(unittest.TestCase):
        def test_logging_redirect_tqdm(self):
            # type: () -> None
            """Test logging_redirect_tqdm function"""

            import datetime  # hours, minutes and seconds


# Generated at 2022-06-26 09:23:44.745162
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    return



# Generated at 2022-06-26 09:23:53.713348
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    '''
    Basic test to ensure that the logging redirection works as expected.

    The test is run several times to ensure the cleanup, and to validate
    that the default logger is correctly redirected.
    '''
    import logging
    from io import StringIO
    log_buf = StringIO()
    trange_bar = None

# Generated at 2022-06-26 09:23:59.989691
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from random import randint
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    # Create logger
    logger = logging.getLogger('test_logging_redirect_tqdm')
    logger.setLevel(logging.DEBUG)

    # Create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Add formatter to ch
    ch.setFormatter(formatter)

    # Add ch to logger
    logger.addHandler(ch)

    # Setup end tag

# Generated at 2022-06-26 09:24:23.883159
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Unit test for function _TqdmLoggingHandler
    import logging
    from tqdm import trange, tqdm_pandas
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    # Unit test for function _TqdmLoggingHandler with custom tqdm_class

# Generated at 2022-06-26 09:24:29.821741
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)
    LOG.info('before redirection')
    with logging_redirect_tqdm():
        LOG.info('console logging redirected to `tqdm.write()`')
    LOG.info('after redirection')



# Generated at 2022-06-26 09:24:32.681781
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test case 0
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as tqdm_logging_redirect_0:
        assert True


# Generated at 2022-06-26 09:24:40.614640
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        logger.info('test1')


    with logging_redirect_tqdm([logger]):
        logger.info('test2')


    with logging_redirect_tqdm([logger]):
        logger.error('test3')



# Generated at 2022-06-26 09:24:47.081331
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    with logging_redirect_tqdm():
        logging.warning("hello")


# Generated at 2022-06-26 09:24:56.104771
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    starting_loggers = logging.Logger.manager.loggerDict.keys()

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored, but one logger remains
        assert all(logger in logging.Logger.manager.loggerDict.keys()
                   for logger in starting_loggers)


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:05.700030
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        assert pbar.total == 10
        assert pbar.n == 0
        with logging_redirect_tqdm():
            pbar.update()
            assert pbar.n == 1


if __name__ == "__main__":
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        test_case_0()
        test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:25:09.985800
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(unit_scale=True, bar_format='{l_bar}') as pbar:
        pbar.update(1)

# Generated at 2022-06-26 09:25:16.066866
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-26 09:25:22.516785
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange


    def foo():
        log = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for _ in trange(3):
                log.info('console logging redirected to `tqdm.write()`')

    foo()

# Generated at 2022-06-26 09:25:59.358449
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm import tqdm, tqdm_gui, tqdm_notebook

    def do_nothing(arg):
        LOG.info("do nothing")
        pass

    LOG = logging.getLogger(__name__)
    loggers = [logging.root]

    # test logging with tqdm.std.tqdm
    logging.basicConfig(level=logging.INFO)
    for logger in loggers:
        logger.handlers = []
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.error("console logging redirected to `tqdm.write()`")
    LOG.handlers = []

    # test logging with tqdm.tqdm
    logging

# Generated at 2022-06-26 09:26:04.807718
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        for i in range(1):
            pass
        assert pbar.total == 1, \
            'progress bar total {} != 1'.format(pbar.total)


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:26:14.048627
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_class = std_tqdm
    loggers = [logging.root]
    # Creation of logging_redirect_tqdm context manager
    context_manager = logging_redirect_tqdm(loggers, tqdm_class)
    # Entering context manager
    with logging_redirect_tqdm(logger, tqdm_class) as ctx_mngr:
        assert type(ctx_mngr) == _TqdmLoggingHandler



# Generated at 2022-06-26 09:26:18.664692
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-26 09:26:24.235558
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to pbar")
    assert pbar.n == 9

# Generated at 2022-06-26 09:26:35.520784
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # - python3 -m unittest -q tests.test_logging
    from io import StringIO
    import logging
    from tqdm import trange

    logger = logging.getLogger(__name__)
    console_out = StringIO()

    # Init logging
    logging.basicConfig(stream=console_out, level=logging.INFO)
    # Output current level
    logger.info('test')
    # Try tqdm_logging_redirect
    with tqdm_logging_redirect():
        # Output current level
        logger.info('test')

    # close
    console_out.close()



# Generated at 2022-06-26 09:26:45.687293
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange

        from .logging.logging_redirect_tqdm import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored
    except:
        pass

# Generated at 2022-06-26 09:26:56.709165
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # init logging
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    for logger in loggers:
        tqdm_handler = _TqdmLoggingHandler()
        orig_handler = _get_first_found_console_logging_handler(logger.handlers)
        if orig_handler is not None:
            tqdm_handler.setFormatter(orig_handler.formatter)
            tqdm_handler.stream = orig_handler.stream
        logger.handlers = [
            handler for handler in logger.handlers
            if not _is_console_logging_handler(handler)] + [tqdm_handler]

    # restore logging

# Generated at 2022-06-26 09:27:00.968441
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test inner function
    # Test function
    # Use logging_redirect_tqdm() context manager
    # Use tqdm_logging_redirect() context manager
    pass

# Generated at 2022-06-26 09:27:09.042059
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._utils import _term_move_up

    # create test logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # create file handler which logs even debug messages
    fh = logging.FileHandler('test.log')
    fh.setLevel(logging.DEBUG)
    # create console handler with INFO level
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    # add the handlers to the logger

# Generated at 2022-06-26 09:28:14.709934
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    from tqdm.contrib import logging_redirect_tqdm
    from tqdm.contrib import tqdm_logging_redirect
    from tqdm.tests import pretest_posttest

    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    log_text = 'logging redirected to tqdm'

    with StringIO() as str_io:
        stream = logging.StreamHandler(stream=str_io)

        with logging_redirect_tqdm(tqdm_class=std_tqdm) as pbar:
            std_tqdm.write("test")
            logger.error("Some message")
            # logging_redirect_tqdm(loggers=[logger])
           

# Generated at 2022-06-26 09:28:25.904627
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    log_msg = "bar"
    with tqdm_logging_redirect(total=5) as pbar:
        assert pbar.__class__ == tqdm
        assert pbar.total == 5
        with open('test_tqdm_logging_redirect.txt', 'w') as f:
            pbar.write(log_msg)
            pbar.update(1)
            assert pbar.n == 1
            assert pbar.pos == 1
            assert pbar.last_print_n == 0
            pbar.write(log_msg, f)
            pbar.update(1)
            assert pbar.n == 2
            assert pbar.pos == 2
            assert pbar.last_print_n == 0

# Generated at 2022-06-26 09:28:30.182951
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import INFO, basicConfig, getLogger
    from tqdm.contrib.logging import logging_redirect_tqdm

    getLogger(__name__).setLevel(INFO)
    basicConfig(level=INFO)

    for i in logging_redirect_tqdm():
        getLogger(__name__).info("test1")
        break
    getLogger(__name__).info("test2")



# Generated at 2022-06-26 09:28:35.308868
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    # Create a logger object
    LOG = logging.getLogger(__name__)
    try:
        with logging_redirect_tqdm():
            for i in range(5):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    except:
        pass



# Generated at 2022-06-26 09:28:45.754664
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # We need to import logging first, to redirect logging.
    import logging

    # We emulate the absence of `logging` module.
    # If exception 'No module named logging' occurs,
    # we import the library `logging`.
    try:
        logging
    except NameError:
        import logging

    # This function is used to test import functionality
    def logging_test():
        LOG = logging.getLogger(__name__)
        return LOG

    # We test that we can use the function without logging module imported
    with logging_redirect_tqdm():
        try:
            logging
        except NameError as e:
            if str(e) != "'logging' is not defined":
                raise RuntimeError("Error found: " + str(e))
        else:
            raise RuntimeError("logging is imported")

    #

# Generated at 2022-06-26 09:28:55.554542
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        pbar.set_description('test tqdm_logging_redirect')
        for i in range(4):
            LOG.info(i)
    print('test is finished')


if __name__ == '__main__':
    test_case_0()
    test_tqdm_logging_redirect()

# Generated at 2022-06-26 09:29:04.850851
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_case_0()
    test_logging_redirect_tqdm()

# Generated at 2022-06-26 09:29:08.656701
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        assert pbar is not None



# Generated at 2022-06-26 09:29:16.451320
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=redefined-outer-name
    loggers = [logging.getLogger(__name__),
              logging.getLogger('tqdm.contrib')]
    log_msg_1, log_msg_2 = 'test log message 1', 'test log message 2'
    with logging_redirect_tqdm(loggers=loggers):
        for logger in loggers:
            logger.info(log_msg_1)
            logger.info(log_msg_2)


# Generated at 2022-06-26 09:29:23.754033
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # logging.captureWarnings(True)
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[logger], total=9):
        logger.info("current: %d", 4)
        logger.info("change: +1")
        logger.info("current: %d", 5)

