

# Generated at 2022-06-24 09:48:58.097604
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm import tqdm

    handler = _TqdmLoggingHandler(tqdm)
    handler.setLevel(logging.INFO)

    formatter = logging.Formatter('{levelname:.1s}: {message}', style='{')
    handler.setFormatter(formatter)

    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    logger.info('Info')

    out = StringIO()
    tqdm.set_lock(tqdm.get_lock(), threading.RLock())  # type: ignore
    with tqdm.std.io.capture_output(out=out, disable=False):
        logger.info('Info')


# Generated at 2022-06-24 09:49:01.520327
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = None
    tqdm_class = std_tqdm
    with tqdm_logging_redirect(loggers=loggers, tqdm_class=tqdm_class) as pbar:
        pbar.write("bab")

# Generated at 2022-06-24 09:49:09.954675
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import os
    import sys
    from collections import namedtuple
    from unittest.case import TestCase

    from ..std import StringIO

    # Note: os.devnull is not defined on Python 2.6
    DEVNULL = getattr(os, 'devnull', '/dev/null')
    log_names = ['critical', 'error', 'warning', 'info', 'debug']

    class FakeRecord(object):
        pass

    class TestLogRecord(namedtuple('TestLogRecord', 'levelno,msg,args')):
        def __new__(cls, levelno, msg, args=(), exc_info=None):
            return super(TestLogRecord, cls).__new__(cls, levelno, msg, args)


# Generated at 2022-06-24 09:49:20.661427
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def assert_is_logging_redirect_tqdm(
            tqdm_class,  # type: Type[std_tqdm]
            loggers,  # type: List[logging.Logger]
            tqdm_kwargs,  # type: Dict[str, Any]
    ):
        # type: (...) -> None
        """
        Assert that `logging.root` and `log` from `test_log`
        are redirected to `tqdm_class` in `test_tqdm_logging_redirect`.
        """

# Generated at 2022-06-24 09:49:25.975999
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # setup
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    record = logging.makeLogRecord({})  # Making an empty record
    record.msg = "Hello World"
    record.levelno = logging.INFO

    # executing emit()
    handler.emit(record)

    # testing emit
    _TqdmLoggingHandler.emit(handler, record)
    assert True


# Generated at 2022-06-24 09:49:32.946675
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    list(tqdm_logging_redirect(
            range(100),
            loggers=[logging.root],
            logging_format='%(message)s',
            dynamic_ncols=True,
            postfix={
                'cr': 0,
            },
            # disable=False,
            leave=True,
        ))
    return 'Done testing tqdm_logging_redirect'



# Generated at 2022-06-24 09:49:37.716453
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    tqdm_ = tqdm(total=1000)
    with tqdm_logging_redirect(tqdm_class=tqdm, tqdm=tqdm_) as pbar:
        for i in range(10):
            pbar.update()
        assert isinstance(pbar, tqdm)

# Generated at 2022-06-24 09:49:41.203257
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(total=1, leave=False) as bar:
        e = _TqdmLoggingHandler(bar)
        e.emit("log message")
        assert bar.n == 1

# Generated at 2022-06-24 09:49:51.231988
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import random
    from .utils import _range, _environ

    old_stderr = sys.stderr
    old_environ = {}
    for key in _environ:
        old_environ[key] = _environ[key]

# Generated at 2022-06-24 09:49:54.284200
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info("test message")
    assert(True)

# Generated at 2022-06-24 09:50:02.087699
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    log_string = StringIO.StringIO()

    try:
        # using default tqdm
        handler = _TqdmLoggingHandler()
        handler.stream = log_string
        record = logging.LogRecord("logger", logging.DEBUG, "", 3, "update", ())
        handler.emit(record)
        assert "update" in log_string.getvalue()
    finally:
        log_string.close()


# Generated at 2022-06-24 09:50:12.141528
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    import sys
    import unittest
    import unittest.mock

    class TestTqdmLoggingRedirect(unittest.TestCase):
        def test_tqdm_logging_redirect(self):
            # type: () -> None
            """
            Tests the tqdm_logging_redirect context manager
            """
            # creates an in memory byte buffer
            buffer = io.BytesIO()
            # redirects stdout to the buffer
            sys.stdout = buffer
            logger = logging.getLogger(__name__)
            # basic config sets the default output to sys.stderr
            logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:50:22.558651
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    stream = io.StringIO()
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream=stream)
    logger.handlers = [handler]
    with tqdm_logging_redirect(
            total=9, smoothing=1, prefix='test',  # tqdm
            loggers=[logger], tqdm_class=std_tqdm):
        logger.debug('Test message')
        logger.info('Info message')
        logger.warning('Warn message')
        logger.error('Error message')
    assert handler.stream == stream
    assert stream.getvalue() == ''

# Generated at 2022-06-24 09:50:30.790674
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm_notebook
    from tqdm.contrib import logger

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            total=9,
            logger=LOG,
            unit_scale=True,
            desc='test',
            leave=True,
            bar_format='{percentage:3.0f}%|{bar}|',
            ncols=80,
            ascii=True,
            unit='bytes',
            dynamic_ncols=True,
            smoothing=0.0,
            tqdm_class=tqdm_notebook
    ) as pbar:
        for i in pbar:
            pbar.update(2)
            if i == 4:
                LOG.info

# Generated at 2022-06-24 09:50:37.024133
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    import logging
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm(loggers=[logger]):
        for _ in tqdm(range(3)):
            logger.info('Foo')

    assert sys.stdout.getvalue() == 'Foo\n' * 3, (
        'logging_redirect_tqdm redirects logging to tqdm.write')



# Generated at 2022-06-24 09:50:40.448098
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert(hasattr(_TqdmLoggingHandler, "emit"))
    assert(hasattr(_TqdmLoggingHandler, "__init__"))


# Generated at 2022-06-24 09:50:42.881631
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('test')



# Generated at 2022-06-24 09:50:50.822273
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: (...) -> None
    # pylint: disable=redefined-outer-name
    """
    Tests the logging_redirect_tqdm() function.
    """
    import logging

    LOG = logging.getLogger(__name__)
    logger = logging.Logger(__name__)
    logger.addHandler(logging.NullHandler())

    with logging_redirect_tqdm(loggers=[LOG, logger]) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:00.512842
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=unused-variable
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        with logging_redirect_tqdm():
            LOG.info("this is a test")
            LOG.warn("this is a test")
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    LOG.warn("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:51:08.750308
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MockTqdm():
        def __init__(self):
            self.file = None
            self.msg = None

        def write(self, msg, file=None):
            self.msg = msg
            self.file = file
    MockTqdm = MockTqdm()
    msg = "Hello"
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    hndlr = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    hndlr.setFormatter(logging.Formatter())
    logger.addHandler(hndlr)

# Generated at 2022-06-24 09:51:15.135022
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Test _TqdmLoggingHandler.emit method"""
    # type: () -> None
    from tqdm import std as tqdm_std  # pylint: disable=no-name-in-module
    from six.moves import StringIO
    handler = _TqdmLoggingHandler(tqdm_class=tqdm_std)
    handler.stream = StringIO()
    record = logging.makeLogRecord(
        dict(msg='This is a test', level=logging.DEBUG))
    handler.emit(record)
    handler.flush()
    assert 'This is a test' == handler.stream.getvalue()

# Generated at 2022-06-24 09:51:19.278572
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger()]
    try:
        with logging_redirect_tqdm(loggers=loggers):
            logging.info("console logging redirected to `tqdm.write()`")
            logging.info("still in redirected context manager")
        logging.info("out of redirected context manager")
    except (KeyboardInterrupt, SystemExit):
        pass

# Generated at 2022-06-24 09:51:25.402841
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    for _ in trange(1):
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:51:36.334297
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    For the function emit of class _TqdmLoggingHandler, test the following:
        1. It should return the message that was passed to it.
        2. It should return something if a record with no attribute 'msg' is passed to it.
    """

    # create a dummy record
    dummy_record = logging.LogRecord("name", "logLevel", "pathName", 42, "msg",
        None, None)
    # create an instance of _TqdmLoggingHandler
    handler = _TqdmLoggingHandler()
    # test case 1
    assert handler.emit(dummy_record) == "msg"
    # test case 2
    assert handler.emit(logging.LogRecord("name", "logLevel", "pathName", 42, None,
        None, None)) is not None

# Generated at 2022-06-24 09:51:43.767206
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tempfile
    from tqdm.contrib.logging import _TqdmLoggingHandler

    _, fpath = tempfile.mkstemp()
    with open(fpath, "w") as f:
        tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        tqdm_handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        tqdm_handler.stream = f

        console_handler = logging.StreamHandler()

        logger = logging.getLogger("test")
        logger.setLevel(logging.DEBUG)
        logger.addHandler(console_handler)
        logger.addHandler(tqdm_handler)


# Generated at 2022-06-24 09:51:48.401566
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # would raise exception
    try:
        tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        tqdm_logging_handler.emit("test")
    except TypeError:
        logging.error("test__TqdmLoggingHandler_emit failed.")

# Generated at 2022-06-24 09:51:58.564098
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import inspect
    import logging
    try:  # Python 2
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import unittest
    import warnings
    warnings.filterwarnings('ignore')  # TODO: remove this once migration to unittest2 is done

    tqdm_logger = logging.getLogger('tqdm')
    test_logger = logging.getLogger('test_logger')

    @contextmanager
    def capture_stdout(logger):
        capture = StringIO()
        original_stdout = sys.stdout
        sys.stdout = capture
        try:
            log_func = logger.info if hasattr(logger, 'info') else logger.warn
            yield capture, log_func
        finally:
            sys.stdout = original_

# Generated at 2022-06-24 09:51:59.501591
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler()
    assert isinstance(logging_handler, logging.StreamHandler)


# Generated at 2022-06-24 09:52:01.914647
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdmLoggingHandler = _TqdmLoggingHandler(std_tqdm)
    assert tqdmLoggingHandler.tqdm_class.__name__ == 'tqdm'

# Generated at 2022-06-24 09:52:03.878455
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-24 09:52:05.844835
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LO

# Generated at 2022-06-24 09:52:14.515678
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    from ..std import logging
    from ..std import tqdm as std_tqdm

    std = []
    with tqdm_logging_redirect(desc='some desc') as pbar:
        std.append(pbar)
        logging.info('test')
        pbar.update()

    assert (isinstance(std[0], std_tqdm))
    assert std[0]._desc == 'some desc:'

    std = []
    with tqdm_logging_redirect(desc='some desc', tqdm_class=std_tqdm) as pbar:
        std.append(pbar)
        logging.info('test')
        pbar.update()

    assert (isinstance(std[0], std_tqdm))
    assert std[0]._desc

# Generated at 2022-06-24 09:52:17.403187
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        logger.info('hello, world')

# Generated at 2022-06-24 09:52:24.295526
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logger = logging.getLogger("test")
    for i in trange(4):
        logger.info("Hello {}".format(i))

    with logging_redirect_tqdm(loggers=[logger]):
        for i in trange(4):
            logger.info("tqdm {}".format(i))
        for i in trange(4):
            logger.info("tqdm {}".format(i))


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:52:34.510237
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """ Unit testing function for method emit of class _TqdmLoggingHandler """
    class _MockTqdm(object):
        """ Mock class for tqdm """
        def __init__(self):
            self.written_lines = []  # type: List[str]
        def write(self, string):
            """ Mock method for tqdm.write """
            self.written_lines.append(string)
        @classmethod
        def write_wrapped(cls, string):
            """ Class method for tqdm.write """
            cls().write(string)

    mock_tqdm = _MockTqdm()
    log_handler = _TqdmLoggingHandler(mock_tqdm.write_wrapped)

# Generated at 2022-06-24 09:52:39.569699
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Unit test for method emit of class _TqdmLoggingHandler"""

# Generated at 2022-06-24 09:52:45.939038
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tnrange
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging
    logger = logging.getLogger("test")
    logger.setLevel(logging.INFO)
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)-15s: %(message)s")
    for _ in tnrange(2):
        print("\n", "=" * 10)
        with logging_redirect_tqdm(loggers=[logger]):
            for i in range(3):
                logger.info("Test logging redirection to tqdm ({})".format(i))


# Generated at 2022-06-24 09:52:47.043428
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-24 09:52:51.129562
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_string = "test string"
    try:
        with tqdm_logging_redirect(
            desc="Unit test",
            bar_format="{desc} {percentage:3.0f}%|{bar}| {n}/{total_fmt} [{elapsed}<{remaining}]"
        ) as pbar:
            logging.info("Unit test for function " + pbar.desc)
            for i in range(100):
                pbar.update(1)
    except:  # noqa pylint: disable=bare-except
        print("Unit test failed")

# Generated at 2022-06-24 09:52:56.625064
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm) != None


# Generated at 2022-06-24 09:53:06.230972
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Unit test for function tqdm_logging_redirect."""
    import logging
    from tqdm import tqdm
    from tqdm.contrib import logger

    # Prepare
    logging.basicConfig(level=logging.INFO)
    logging.getLogger().handlers = []
    loggers = [logging.getLogger()]

    # Test
    with tqdm_logging_redirect(loggers=loggers, tqdm=tqdm):
        tqdm.write('foo', file=sys.stdout)
        logging.info('bar')
        assert len(logging.getLogger().handlers) == 1
        assert isinstance(logging.getLogger().handlers[0],
                          logger._TqdmLoggingHandler)




# Generated at 2022-06-24 09:53:12.821889
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test if logging_redirect_tqdm() works
    """
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in std_tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:53:16.076910
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__file__)
    logger.addHandler(_TqdmLoggingHandler())

    logger.warning("hello")
    logger.error("world")

# Generated at 2022-06-24 09:53:23.471574
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(
        desc='Logging',
        bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]',
        initial=0,
    ) as pbar:
        for _ in trange(10):
            logger.info('info')
            logger.warning('warning')
            logger.error('error')
            pbar.update()

# Generated at 2022-06-24 09:53:33.913364
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import tqdm

    x = logging.getLogger("test_logger")
    x.handlers = []
    x.setLevel(logging.INFO)

    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    x.addHandler(handler)
    x.info("Hello World")

    handler2 = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler2.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    x.addHandler(handler2)
    x.info("Hello World 2")



# Generated at 2022-06-24 09:53:37.425816
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class MyTqdm:
        def write(self, msg, file=None):
            print(msg, file=file)
    _TqdmLoggingHandler(tqdm_class=MyTqdm)

# Generated at 2022-06-24 09:53:47.243820
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    with logging_redirect_tqdm(), \
            trange(2) as pbar, \
            open('test1', 'w') as f:
        log.warning('foo')
        log.info('bar')
        log.debug('foo')
        pbar.update()
        log.warning('foo')
        log.info('bar')
        log.debug('foo')
        print('Test', file=f)

    with logging_redirect_tqdm(tqdm_class=trange, loggers=[log],
                               desc="LOGGING TEST"):
        log.warning('foo')
        log.info('bar')
        log.debug

# Generated at 2022-06-24 09:53:52.954947
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import sys
    log = logging.getLogger("Test")
    new_log = StringIO()
    sys.stdout = new_log
    log_handler = _TqdmLoggingHandler()
    log.addHandler(log_handler)
    log.warning("test")
    sys.stdout = sys.__stdout__
    new_log.seek(0)
    assert new_log.read() == "test\n"

# Generated at 2022-06-24 09:54:03.712214
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import time
    from unittest import TestCase

    class CustomStream(object):
        '''
        Mock a stream
        '''
        def write(self, msg):
            pass

        def flush(self):
            pass

    tqdm_class = std_tqdm

    class TestHandler(TestCase):

        def setUp(self):
            self.stream = CustomStream()
            self.tqdm_logger_handler = _TqdmLoggingHandler(tqdm_class=tqdm_class)
            self.tqdm_logger_handler.stream = self.stream
            self.logger = logging.Logger(name="tqdm_logger")
            self.logger.addHandler(self.tqdm_logger_handler)


# Generated at 2022-06-24 09:54:10.009758
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:15.848831
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)
    if __name__ == "__main__":
        try:
            with logging_redirect_tqdm() as tqdm:
                tqdm.write("Write test")
        except KeyboardInterrupt:
            pass
        # Test if logging is restored
        logger.info("Logging restored")



# Generated at 2022-06-24 09:54:25.288964
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from unittest import TestCase


# Generated at 2022-06-24 09:54:32.221089
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib import logging as tqdm_logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging.logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:42.725337
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    class TestLogger(logging.Logger):
        def __init__(self):
            super(TestLogger, self).__init__("TestLogger", level=logging.INFO)
            self.is_redirected = False

        def handle(self, record):
            self.is_redirected = isinstance(
                record.msg, logging.LogRecord)
            return super(TestLogger, self).handle(record)

    std_tqdm._instances.clear()  # type: ignore

    with logging_redirect_tqdm([TestLogger()]):
        logging.info("hello world")

    assert std_tqdm._instances == [  # type: ignore
        std_tqdm.get_instances()[0]]  # type: ignore

    assert std_tqdm._dec

# Generated at 2022-06-24 09:54:49.105118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch(
        'tqdm.contrib.logging.logging_redirect_tqdm',
        return_value=None,
    ) as logging_redirect_tqdm_mock, patch(
        'tqdm.std.tqdm',
        return_value=None
    ) as tqdm_mock:
        with tqdm_logging_redirect():
            pass


# Generated at 2022-06-24 09:54:59.586374
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    logging.basicConfig(level=logging.INFO)

    def test_fn(x):
        time.sleep(0.1)
        return x

    logging.info('before tqdm_logging_redirect')
    with tqdm_logging_redirect(["test_logger"],
                               desc="test_desc", total=1) as pbar:
        logging.info('in tqdm_logging_redirect')
        for x in pbar(range(10)):
            pbar.update(1)
            test_fn(x)
    logging.info('after tqdm_logging_redirect')

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:55:03.974725
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import numpy as np
    except:
        raise
    # pylint: disable=unused-variable
    with tqdm_logging_redirect(
        loggers=None,
        range=np.arange(9)
    ) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:07.983236
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test standard use
    with tqdm_logging_redirect(total=5):
        pass
    # Test custom handler and logger
    with tqdm_logging_redirect(total=5, loggers=[logging.getLogger('test.logger')]):
        pass

# Generated at 2022-06-24 09:55:18.159639
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    try:
        import unittest
    except ImportError:
        return
    import logging

    class TqdmLoggingHandlerTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            # type: () -> None
            cls.LOG = logging.getLogger(__name__)
            cls.LOG.setLevel(logging.INFO)
            cls.LOG.handlers = []
            logging.basicConfig(level=logging.INFO)
            cls.test_list = [1, 2, 3, 4, 5]


# Generated at 2022-06-24 09:55:26.179462
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from unittest import TestCase
    from .test import _range

    from .std import tqdm as std_tqdm

    def _isPython3():
        return sys.version_info[0] == 3
    class _TestTqdmLoggingHandler(TestCase):

        def setUp(self):
            self.logging_stringio = StringIO()
            self.logger = logging.Logger("test")
            if _isPython3():
                handler = logging.StreamHandler(io.TextIOWrapper(self.logging_stringio))
            else:
                handler = logging.StreamHandler(self.logging_stringio)
            handler.setLevel(logging.INFO)
            formatter

# Generated at 2022-06-24 09:55:32.159246
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    import unittest
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    class TestTqdmLoggingRedirect(unittest.TestCase):
        def test_tqdm_logging_redirect_0(self):
            """Test that console logging is correctly redirected to
            tqdm.write()"""

            LOG = logging.getLogger(__name__)
            if __name__ == '__main__':
                logging.basicConfig(level=logging.INFO)
                with tqdm_logging_redirect() as pbar:
                    for i in range(5):
                        if i == 2:
                            LOG.info("Console logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:55:34.006487
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler()
    assert handler._name == "TqdmLoggingHandler"

# Generated at 2022-06-24 09:55:39.195592
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    from tqdm import trange

    def test_tqdm_logging_redirect_helper(loggers=None):
        loggers = loggers if loggers else [logging.root]
        original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-24 09:55:43.850455
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler.
    """
    logging.basicConfig(level=logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.tqdm_class == std_tqdm
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:55:47.403829
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Unit tests for _TqdmLoggingHandler"""
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert tqdm_logging_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:55:57.876660
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import tqdm
    import logging

    try:
        from unittest import mock  # type: ignore
    except ImportError:
        import mock  # type: ignore  # pylint: disable=import-error

    LOG = logging.getLogger(__name__)
    logger = LOG

    def test_tqdm_version(tqdm_class):
        with tqdm_class(total=10) as pbar:
            assert tqdm_class.__version__ in str(pbar)
            with logging_redirect_tqdm(loggers=[logger], tqdm_class=tqdm_class):
                LOG.info("console logging redirected to `tqdm.write()`")
                LOG.info("still redirecting to tqdm")
            assert pbar.n == 10

    test_

# Generated at 2022-06-24 09:56:03.231028
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm._utils import _term_move_up
    from tqdm.contrib.testing import ClearStreams

    sio = StringIO()
    with ClearStreams():
        handler = _TqdmLoggingHandler()
        handler.stream = sio
        handler.emit(logging.makeLogRecord(
            {'msg': 'logging redirected to tqdm'}))
    assert sio.getvalue() == _term_move_up() + 'logging redirected to tqdm'

# Generated at 2022-06-24 09:56:10.708118
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    >>> import logging

    >>> log = logging.getLogger(__name__)
    >>> log.setLevel(logging.INFO)

    # set up logging to console
    >>> ch = logging.StreamHandler()
    >>> ch.setLevel(logging.INFO)

    >>> # create formatter and add it to the handlers
    >>> formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    >>> ch.setFormatter(formatter)

    >>> # add the handlers to logger
    >>> log.addHandler(ch)

    >>> test_string = 'test'
    >>> log.info(test_string)
    2019-03-12 14:19:06,099 - __main__ - INFO - test
    """

# Generated at 2022-06-24 09:56:18.176427
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Test _TqdmLoggingHandler class emit method

    1. Capture stdout, stderr
    2. Call _TqdmLoggingHandler.emit with a log record
    3. Cleanup
    4. Validate that it wrote to tqdm
    """
    from io import StringIO
    from contextlib import contextmanager
    from logging import getLogger, CRITICAL
    from .tqdm import tqdm_class

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = std_tqdm.stdout, std_tqdm.stderr

# Generated at 2022-06-24 09:56:27.390321
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Run PYTHONPATH=. pytest tests/test_logging.py::test__TqdmLoggingHandler
    """
    from tqdm.std import sys
    import io
    import logging
    import pytest
    from tqdm.contrib import logging as tqdm_logging

    msg = u"test"  # type: str
    stream = io.StringIO()  # type: io.StringIO
    handler = tqdm_logging._TqdmLoggingHandler(stream=stream)  # type: tqdm_logging._TqdmLoggingHandler
    # Write msg using the handler
    handler.emit(logging.LogRecord('tqdm.contrib.logging',
                                   logging.INFO,
                                   '.', 0, msg, (), None))
    assert msg

# Generated at 2022-06-24 09:56:35.292107
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    from nose.tools import eq_
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info('should not be captured')
    with logging_redirect_tqdm():
        LOG.info('should be captured')
    LOG.info('should not be captured')
    eq_(LOG.handlers, [])
    # Now restore logging, because it is useful in development and
    # unittesting
    logging.basicConfig(level=logging.INFO)



# Generated at 2022-06-24 09:56:37.146504
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    std_tqdm.write = lambda x: x
    with tqdm_logging_redirect('test test test'):
        pass

# Generated at 2022-06-24 09:56:44.116430
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_output_list = []
    def mock_write(s):
        test_output_list.append(s)
    class MockTqdm(object):
        write = mock_write
    test_handler = _TqdmLoggingHandler(MockTqdm)
    assert(test_handler.stream == sys.stderr)
    test_handler.emit('test_msg')
    assert(test_output_list[0] == 'test_msg\n')


# Generated at 2022-06-24 09:56:53.417638
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests method emit of class _TqdmLoggingHandler.
    """
    import io
    import sys
    class _TqdmTestClass(object):
        def __init__(self, file=None):
            self.file = file
            self.message = None
            self.exc_info = None
        def write(self, message, file=None, exc_info=None, end='\n'):
            if file and file is not sys.stderr:
                if file is not self.file:
                    raise ValueError('One file stream per class instance')
            if self.exc_info is not None and exc_info is not None:
                raise TypeError('One exc_info per class instance')
            if message == '\n':
                return
            if self.message is None:
                self.message = message

# Generated at 2022-06-24 09:56:54.190957
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-24 09:57:05.886897
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..utils import _range
    import logging

    def test_redirect(loggers=None, tqdm_class=std_tqdm):
        with tqdm_logging_redirect(
                _range(9),
                loggers=loggers,
                tqdm_class=tqdm_class,
                leave=True
        ) as pbar:
            assert len(pbar.handlers) == 1
            assert pbar.handlers[0].tqdm_class is tqdm_class
            assert pbar.handlers[0].stream is sys.stderr
            assert pbar.logger is logging.root
            logging.info("test")

    test_redirect()
    test_redirect([logging.getLogger('test')])

# Generated at 2022-06-24 09:57:11.735200
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    from ..std import tqdm, logging
    from .logging import tqdm_logging_redirect

    # Ensure we catch all logs (for testing)
    logging.basicConfig(level=logging.NOTSET)

    LOG = logging.getLogger("foo")

    with tqdm_logging_redirect() as pbar:
        assert pbar
        LOG.debug("Log a foo 1")
        LOG.info("Log a foo 2")
        LOG.warning("Log a foo 3")
        LOG.error("Log a foo 4")

# Generated at 2022-06-24 09:57:14.190222
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()  # pylint: disable=assignment-from-none
    assert handler is not None

# Generated at 2022-06-24 09:57:22.379132
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    message = 'console logging redirected to `tqdm.write()`'
    from io import StringIO
    from unittest import TestCase

    class TqdmLoggingHandlerTest(TestCase):
        def test_emit(self):
            record = logging.Logger("TestLogger").makeRecord("TestLogger", logging.INFO, "name", 42, message, None, None)
            tqdm_logging_handler = _TqdmLoggingHandler()
            tqdm_logging_handler.stream = StringIO()
            tqdm_logging_handler.emit(record)
            self.assertEqual(tqdm_logging_handler.stream.getvalue(), message + "\n")

    TqdmLoggingHandlerTest().test_emit()


# Generated at 2022-06-24 09:57:31.058276
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # Logging is not configured by default
    # https://docs.python.org/3/howto/logging.html#configuring-logging-for-a-library
    # pylint: disable=logging-not-lazy
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(5):
            logger.info("hello %d", i)
        for i in range(5):
            logger.warning("world %d", i)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:57:39.397296
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    >>> class DummyTqdm(object):
    ...     def write(self, msg):
    ...         sys.stderr.write("dummy_tqdm: {}".format(msg))
    >>> handler = _TqdmLoggingHandler(DummyTqdm)
    >>> record = logging.LogRecord("logger", logging.INFO, "", 0, "log_msg", None, None)
    >>> handler.emit(record)
    dummy_tqdm: log_msg
    """
    pass

# Generated at 2022-06-24 09:57:49.428159
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    log_capture_string = io.StringIO()
    pbar_logging_handler = _TqdmLoggingHandler()
    pbar_logging_handler.stream = log_capture_string
    pbar_logging_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(pbar_logging_handler)
    import pprint
    pprint.pprint(logger.handlers, stream=log_capture_string)
    logger.info('hello world')

# Generated at 2022-06-24 09:57:55.925229
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from time import sleep
    from logging import getLogger

    logger = getLogger()

    # print to stderr
    with logging_redirect_tqdm(loggers=[logger]):
        for i in range(9):
            logger.error("Hello")
            sleep(0.01)

    # print to stdout
    with logging_redirect_tqdm(loggers=[logger]):
        for i in range(9):
            logger.info("World")
            sleep(0.01)

# Generated at 2022-06-24 09:58:01.647279
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    try:
        from tqdm import tqdm  # type: ignore
    except ImportError as e:
        # Probably no tqdm installed:
        # test may fail, but it's not a problem.
        return
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(unit_scale=True, ascii=True):
        for _ in trange(5):
            logging.info("test %d", 5)

# Generated at 2022-06-24 09:58:11.876855
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests._tqdm_test_cases import \
        _TestTqdmLogging, _TestTqdmLoggingException

    with _TestTqdmLogging() as orig_stdout:
        logger = logging.getLogger('_TqdmLoggingHandler')
        logger.setLevel(logging.DEBUG)
        handler = _TqdmLoggingHandler()
        logger.addHandler(handler)
        logger.info('INFO %d', 1)
        logger.info('INFO %d', 2)
        logger.error('ERROR %d', 1)
        try:
            raise _TestTqdmLoggingException('EXCEPTION')
        except _TestTqdmLoggingException:
            logger.error('ERROR %s', 'EXCEPTION', exc_info=True)

# Generated at 2022-06-24 09:58:22.218424
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from ..tqdm import tqdm
    from .tests_class import LoggerFake, RecordFake, _TestHandler
    logger = LoggerFake('name')
    assert len(logger.handlers) == 0

    # Level < CRITICAL
    for level in ['DEBUG', 'INFO', 'WARNING']:
        setattr(logger, level, lambda msg, *args, **kwargs: None)
        record = RecordFake(level)
        # with tqdm redirect
        with tqdm_logging_redirect():
            _TqdmLoggingHandler().emit(record)
        # without tqdm redirect
        _TqdmLoggingHandler().emit(record)

    # Level >= CRITICAL

# Generated at 2022-06-24 09:58:24.487282
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:58:32.805235
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib import logging as tqdm_logging

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging.tqdm_logging_redirect(
            ['console logging redirected to `tqdm.write()`'],
            total=9,
            loggers=[LOG]
        ) as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:58:45.619522
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import tempfile
    import logging

    # create a temp file to write the logger logs to
    # (needed because TqdmLoggerHandler redirects to stdout)
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        logger_file_name = f.name
    log_format = "%(levelname)s " + "hello"  # print "hello"

# Generated at 2022-06-24 09:58:47.763997
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log = logging.getLogger()
    handler = _TqdmLoggingHandler()
    log.addHandler(handler)

# Generated at 2022-06-24 09:58:49.710540
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler()
    assert handler != None