

# Generated at 2022-06-24 09:48:53.761051
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Test `logging_redirect_tqdm` function."""
    import inspect
    import logging
    import subprocess
    from tempfile import NamedTemporaryFile
    from tqdm.contrib import tqdm_logging  # @Reimport

    def test_log():  # Function to test logging functionality
        # type: () -> int
        try:
            for i in range(4):
                logging.info('Logging message {}'.format(i))
            logging.error('Error message')
            logging.critical('Critical message')
            return 0
        except Exception:
            return 1

    LOG_FILENAME = NamedTemporaryFile(prefix='tqdm_log_test_').name
    logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)

   

# Generated at 2022-06-24 09:49:00.638734
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.test_utils import StringIO
    try:
        from tqdm.auto import tqdm
    except ImportError:
        from tqdm import tqdm  # type: ignore

    test_msg = 'test msg'

    with tqdm_logging_redirect() as pbar:
        logging.info(test_msg)
        assert test_msg in pbar.desc

    with tqdm_logging_redirect(file=None) as pbar:
        logging.info(test_msg)
        assert test_msg in str(pbar)

    with tqdm_logging_redirect(file=StringIO()) as pbar:
        logging.info(test_msg)
        assert test_msg in pbar.desc


# Generated at 2022-06-24 09:49:09.262268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import logging
    from tqdm import tqdm
    import tqdm.contrib.logging

    log_handler = logging.StreamHandler()
    root_logger = logging.root
    root_logger.addHandler(log_handler)
    root_logger.setLevel(logging.DEBUG)

    tqdm_output = StringIO()
    tqdm_write = tqdm(file=tqdm_output, leave=False).write
    with tqdm.contrib.logging.logging_redirect_tqdm():
        logging.info("I'm here")
    assert "I'm here" in tqdm_output.getvalue()
    assert "I'm here" not in log_

# Generated at 2022-06-24 09:49:18.126449
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Check init of the class with parameters passed
    handler_obj = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler_obj.stream = sys.stdout
    assert hasattr(handler_obj, "stream")
    assert hasattr(handler_obj, "emit")

    # Check with exceptions
    try:
        handler_obj.emit(record="")  # noqa pylint: disable=no-value-for-parameter
        assert True
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        assert True


# Generated at 2022-06-24 09:49:25.187927
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.tests import _suppress_stderr
    from unittest import TestCase

    with _suppress_stderr():
        handler_class = _TqdmLoggingHandler
        handler = handler_class()
        logmsg = "tqdm logging handler test"
        record = logging.LogRecord(LOGNAME, logging.INFO, __file__, 0, logmsg,
                                   [], None)
        handler.emit(record)
        TestCase().assertEqual(std_tqdm.format_sizeof(logmsg) + "\n",
                               handler.stream.getvalue())



# Generated at 2022-06-24 09:49:33.642004
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        # Test that the constructor of _TqdmLoggingHandler generates usable instance
        TqdmLoggingHandler = _TqdmLoggingHandler()

        # Test that the _TqdmLoggingHandler instance has all the attributes required for stdout
        assert TqdmLoggingHandler.stream == sys.stdout
        assert TqdmLoggingHandler.tqdm_class

    except Exception as e:
        print('Failed to test the constructor and attributes of class _TqdmLoggingHandler')
        print(e)
        sys.exit(1)



# Generated at 2022-06-24 09:49:39.455280
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    logger = logging.Logger("test_tqdm_logging_handler")
    orig_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        handler = _TqdmLoggingHandler()
        handler.stream = sys.stderr
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.handlers = [handler]
        logger.warning("test")
        output = sys.stderr.getvalue()
        assert output == "test\n"
    finally:
        sys.stderr = orig_stderr



# Generated at 2022-06-24 09:49:49.166234
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from time import sleep
    import logging
    from .main import tqdm

    l = logging.getLogger()
    with logging_redirect_tqdm(loggers=[l]):
        l.info('info')
        l.warning('warn')
        l.error('error')
        l = logging.getLogger('test')
        l.info('info2')
        l.warning('warn2')
        l.error('error2')
        with tqdm(unit='B', unit_scale=True, miniters=1,
                  desc='Foo', leave=False) as t:
            for i in t:
                sleep(0.0001)
                pass
        sleep(0.1)
    assert t.n == 1

# Generated at 2022-06-24 09:49:50.833348
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    TqdmLoggingHandler = _TqdmLoggingHandler()
    assert (isinstance(TqdmLoggingHandler, logging.StreamHandler))

# Generated at 2022-06-24 09:49:54.210772
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger(__name__)
    log.setLevel('INFO')
    with logging_redirect_tqdm():
        log.info("test")



# Generated at 2022-06-24 09:50:02.029495
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import sys
    import tempfile
    from io import StringIO
    from operator import attrgetter
    import logging
    import pytest
    from tqdm.contrib.logging import tqdm_logging_redirect

    def _tqdm_logging_redirect_test(tqdm_class=None, leave=False):
        log_file = tempfile.NamedTemporaryFile()
        fname = log_file.name

        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)

        console_handler = logging.StreamHandler(StringIO())
        console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        console_handler.setLevel(logging.INFO)
        logger

# Generated at 2022-06-24 09:50:12.074471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import sys
    import logging
    from contextlib import contextmanager
    from logging import FileHandler, Logger, NOTSET
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.tests import common as tests_common
    from tqdm.tests.common import with_setup

    @contextmanager
    def redirected_indented_logging():
        """ Context manager for redirecting stderr to a string for unit testing """
        stderr = sys.stderr
        s = StringIO()
        sys.stderr = s
        yield s
        sys.stderr = stderr

    def get_log_name(log):
        return

# Generated at 2022-06-24 09:50:14.289885
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:50:18.275592
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    >>> logging_handler = _TqdmLoggingHandler()
    """
    logging_handler = _TqdmLoggingHandler()
    assert logging_handler

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:50:27.249102
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm

    try:
        import io
    except ImportError:
        import io
    output_handle = io.BytesIO()
    logging.basicConfig(level=logging.INFO)
    tqdm_handler = _TqdmLoggingHandler(tqdm)
    tqdm_handler.setFormatter(logging.Formatter('%(levelname)s - %(message)s'))
    tqdm_handler.stream = output_handle
    logger = logging.getLogger(__name__)
    logger.addHandler(tqdm_handler)
    logger.info('This message is a unit test')
    logger.removeHandler(tqdm_handler)
    output_handle.seek(0)

# Generated at 2022-06-24 09:50:37.789216
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    import io
    streamIO = io.StringIO()
    # loggingsystem is configured with a handler that outputs to streamIO
    logging.basicConfig(level=logging.INFO, stream=streamIO)

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.setFormatter(logging.Formatter('%(asctime)s: %(message)s', datefmt='%Y%m%d-%H:%M:%S'))
    handler.setLevel(logging.DEBUG)
    handler.stream = streamIO

    LOG.addHandler(handler)

    LOG.error('error message')
    LOG.info('info message')

# Generated at 2022-06-24 09:50:44.828542
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    console_stream = open('/tmp/stdout.txt', 'w+')
    logger = logging.getLogger()
    tqdm_logger = _TqdmLoggingHandler(std_tqdm)
    tqdm_logger.stream = console_stream
    logger.setLevel(logging.INFO)
    logger.addHandler(tqdm_logger)
    logger.info('Hello World')
    with open('/tmp/stdout.txt', 'r') as f:
        assert f.read() == 'Hello World\n'

# Generated at 2022-06-24 09:50:54.866266
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Unit test for function tqdm_logging_redirect
    try:
        import tqdm as test_tqdm
    except ImportError:
        # No tqdm installed, cannot run tests
        return
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.WARN)
        with tqdm_logging_redirect(desc='logging_redirect_tqdm', total=9):
            for _ in range(9):
                if _ == 4:
                    LOG.warning("console logging redirected to `tqdm.write()`")
                    test_tqdm.write("console logging redirected to `tqdm.write()`")
    # logging restored
test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:51:01.708193
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm._tqdm import tqdm

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())

    with tqdm_logging_redirect(desc="testing", unit="blocks", disable=False,
                               ncols=None, miniters=1) as pbar:
        logger.info("hello")
        pbar.update(10)
        logger.info("world")
        pbar.update(10)



# Generated at 2022-06-24 09:51:10.971975
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import unittest
    import logging as logging_stdlib
    from tqdm import _tqdm

    class MockStream:
        last_msg = None
        def write(self, msg):
            self.last_msg = msg

    class TqdmLoggingHandlerTestCase(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.logging_tqdm_handler = _TqdmLoggingHandler(_tqdm)

        def test_logging_handler_emit_is_called_with_tqdm(self):
            mock_stream = MockStream()
            self.logging_tqdm_handler.stream = mock_stream
            message = 'This is a logging_tqdm_handler emit test'

# Generated at 2022-06-24 09:51:13.738813
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    logger.info('test')

# Generated at 2022-06-24 09:51:16.999041
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    for cls in [std_tqdm, std_tqdm]:
        logger = logging.getLogger('Bar')
        handler = _TqdmLoggingHandler(cls)
        logger.addHandler(handler)
        logger.warning('Foo')
        handler.close()

# Generated at 2022-06-24 09:51:22.924845
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger('log1'), logging.getLogger('log2')]
    with logging_redirect_tqdm(loggers):
        loggers[0].info('message1')
        loggers[1].info('message2')
    assert loggers[0].handlers[0].stream == sys.stdout
    assert loggers[1].handlers[0].stream == sys.stdout

# Generated at 2022-06-24 09:51:25.888248
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    instance_of_TqdmLoggingHandler = _TqdmLoggingHandler()
    assert isinstance(instance_of_TqdmLoggingHandler, _TqdmLoggingHandler)



# Generated at 2022-06-24 09:51:30.677719
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def test_func():
        # type: () -> None
        with tqdm_logging_redirect():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test_func()



# Generated at 2022-06-24 09:51:38.938623
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test function tqdm_logging_redirect."""
    order = []  # type: List[str]

    LOG = logging.getLogger(__name__)
    with std_tqdm() as pbar:
        order.append('tqdm')
        with logging_redirect_tqdm():
            order.append('logging_redirect_tqdm')
            for i in std_tqdm(range(3)):
                LOG.info("hello %s!", i)  # prints to pbar

    assert order == ["tqdm", "logging_redirect_tqdm"]



# Generated at 2022-06-24 09:51:41.173864
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect() as pbar:
        log = logging.getLogger('redirect')
        log.info("Redirected")

# Generated at 2022-06-24 09:51:48.143553
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test the method emit in class _TqdmLoggingHandler.
    We use logging_redirect_tqdm to redirect the logs to tqdm.write and check
    if the redirection is working.
    """
    logger = logging.getLogger(name='test_logger')
    logger.setLevel(logging.INFO)
    handler1 = logging.StreamHandler()
    handler1.setLevel(logging.INFO)
    handler1.setFormatter(logging.Formatter('%(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler1)
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info(msg="hello")
        logger.info(msg="world")

# Generated at 2022-06-24 09:51:49.640613
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler().__class__ == _TqdmLoggingHandler


# Generated at 2022-06-24 09:51:57.132978
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    # test logging_redirect_tqdm()
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                # pylint: disable=logging-format-interpolation
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:51:58.723621
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr

# Generated at 2022-06-24 09:51:59.561986
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:03.057294
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    log = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:52:06.666803
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.getLogger().handlers = []
    handler = _TqdmLoggingHandler()
    record = logging.makeLogRecord({'msg': 'hello'})
    handler.emit(record)

# Generated at 2022-06-24 09:52:08.639935
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm



# Generated at 2022-06-24 09:52:16.524142
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm
    from .std import tqdm as std_tqdm
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.DEBUG)
    log.addHandler(log_handler)

    log.debug("This is a debug message.")
    log.info("This is an info message.")
    log.warning("This is a warning message.")
    log.error("This is an error message.")
    log.critical("This is a critical message.")

    log.debug("This is a debug message that tqdm should redirect to write.")
    log.info("This is an info message that tqdm should redirect to write.")

# Generated at 2022-06-24 09:52:19.081748
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:52:21.354636
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.emit(logging.LogRecord('test', logging.INFO, 'f', 1, 'test message %s %s', ('test',), None))

# Generated at 2022-06-24 09:52:27.060806
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import cStringIO

    class FakeLogger(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, captured_stdout):
            self.captured_stdout = captured_stdout
        def handleError(self, *args, **kwargs):
            raise NotImplementedError()
        def setFormatter(self, formatter):
            raise NotImplementedError()

    class FakeFormatter(object):
        def __init__(self, format_str):
            self._format_str = format_str
        def format(self, record):
            return self._format_str % record.__dict__

    class FakeRecord(object):
        def __init__(self, level, msg):
            self.levelname = level
            self.msg = msg

    test

# Generated at 2022-06-24 09:52:33.645207
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
    except ImportError:
        return

    import logging
    loggers = logging.getLogger(__name__)
    with tqdm_logging_redirect(3, loggers=loggers) as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info("a")
        LOG.info("b")
        LOG.info("c")
    assert pbar.n == 3

# Generated at 2022-06-24 09:52:34.783918
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()

# Generated at 2022-06-24 09:52:41.809902
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    try:
        with tqdm_logging_redirect(desc='logging redirected to `tqdm.write()`'):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    except ValueError as e:
        assert str(e) == "No logger defined to redirect to tqdm."

# Generated at 2022-06-24 09:52:43.658879
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:52:49.910437
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test for the method emit of class _TqdmLoggingHandler
    """
    record = logging.LogRecord(None, logging.DEBUG, None, None, None, None, None)
    stream = sys.stdout
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    try:
        handler.emit(record)
        handler.flush()
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        handler.handleError(record)



# Generated at 2022-06-24 09:52:57.458180
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    output = []
    # Mocking tqdm write method
    class tqdmMock(_TqdmLoggingHandler):
        def write(self, message, file=None):
            # print "Calling write method of tqdmMock with %s" % message
            output.append(message)

    class LogRecordMock(object):
        def __init__(self, msg, lvl):
            self.levelno = lvl
            self.msg = msg
        def __str__(self):
            return self.msg

        def getMessage(self):
            return self.msg

    TQDM_MOCK = tqdmMock()

    # Test if message is appended to output when log-level >= logging INFO level
    test_log_lvl = (logging.INFO, logging.WARNING, logging.ERROR, logging.DEBUG)


# Generated at 2022-06-24 09:53:03.634608
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None

    # Import here for convenience of tqdm developers (this module is not in
    # the main tqdm namespace)
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    if not LOG.handlers:
        logging.basicConfig(level=logging.INFO)

    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                LOG.info("console logging redirected to `tqdm.write()`")
        if i >= 6:
            with logging_redirect_tqdm(loggers=[LOG], tqdm_class=trange):
                LOG.info("custom loggers and tqdm")

    print("Done.")

# Generated at 2022-06-24 09:53:07.820859
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert(isinstance(handler, _TqdmLoggingHandler))


# Generated at 2022-06-24 09:53:15.750308
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from unittest import TestCase, main
    from unittest.mock import patch

    _file = StringIO()
    _handler = _TqdmLoggingHandler()
    _handler.stream = _file
    with patch('tqdm.contrib.logging._TqdmLoggingHandler.stream', _file):
        _handler.emit(logging.LogRecord(
            'test', 10, 'foo.py', 42, 'test message', None, None))
    _file.seek(0)
    TestCase().assertEqual(_file.read(), 'test message\n')


if __name__ == '__main__':
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-24 09:53:24.073557
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    import os
    import logging
    import _io
    import six

    try:
        # Python 2 case
        # Testing for str
        if six.PY2:
            assert isinstance(u"\N{SNOWMAN}", unicode)
            assert isinstance(u"\N{SNOWMAN}".encode("utf-8"), str)
        else:
            msg = u"\N{SNOWMAN}"
            assert isinstance(msg, str)
        msg = u"\N{SNOWMAN}"
        assert isinstance(msg, str)
        from tqdm import tqdm
    except ImportError:
        return
    handler = _TqdmLoggingHandler()
    out = _io.StringIO()
    handler.stream = out

# Generated at 2022-06-24 09:53:27.065273
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)


# Generated at 2022-06-24 09:53:35.585115
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    assert str(tqdm_logging_redirect(['a', 'b', 'c'])) == '100%|##########| 3/3 [00:00<?, ?it/s]'
    assert str(tqdm_logging_redirect(['a', 'b', 'c'], bar_format=' >')) == '100%|##########| 3/3 [00:00<?, ?it/s] >'
    assert str(tqdm_logging_redirect([1, 2, 3], total=5)) == ' 60%|#####4/5 [00:00<?, ?it/s]'

if __name__ == '__main__':
    from multiprocessing import Pool
    from time import sleep


# Generated at 2022-06-24 09:53:43.241478
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:53:47.167003
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    log_record = logging.LogRecord("name", "INFO", "filename", 1,
                                   "msg1", (), None)
    tqdm_handler.emit(log_record)
    assert(std_tqdm.get_write_set() == "[name] msg1\n")

# Generated at 2022-06-24 09:53:55.191470
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import os
    import shutil
    import tempfile

    from ..std import tqdm as std_tqdm

    from . import setup_logging, tgr, tgr_s

    log_fd, log_path = tempfile.mkstemp(
        prefix='tqdm_logging_test_', suffix='.log', text=True)

# Generated at 2022-06-24 09:53:59.825125
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_class = std_tqdm
    logger=logging.getLogger('root')
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    logger.addHandler(tqdm_handler)
    logger.info('This is the logger.')

# Generated at 2022-06-24 09:54:07.290787
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from os import devnull
    import random
    import string
    from tempfile import TemporaryFile
    from logging import Formatter, StreamHandler, LogRecord
    from tqdm import std_tqdm

    # Mock logging handlers
    mock_logger = logging.getLogger('test_logger')
    mock_logger.setLevel(logging.DEBUG)
    mock_logger.handlers = []

    _test_msg = ''.join(random.choice(string.ascii_lowercase)
                        for _ in range(int(random.choice('1' + string.digits))))
    mock_record = LogRecord('test_name', logging.INFO, 'test_pathname',
                            0, _test_msg, ('test_args',), None)
    handler = _TqdmLoggingHandler()
    formatter

# Generated at 2022-06-24 09:54:13.855756
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert len(handler.tqdm_class.write.__code__.co_varnames) == 3
    assert handler.tqdm_class.write.__code__.co_argcount == 3


# Generated at 2022-06-24 09:54:23.258436
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    test_str = StringIO()
    rec = logging.LogRecord(
        name='test__TqdmLoggingHandler_emit',
        level=logging.INFO,
        pathname='test__TqdmLoggingHandler_emit.py',
        lineno=1,
        msg='test__TqdmLoggingHandler_emit',
        args=None,
        exc_info=None)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.stream = test_str
    tqdm_handler.emit(rec)
    assert ('%s\n' % rec.getMessage() == test_str.getvalue())

# Generated at 2022-06-24 09:54:27.930760
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, loggers=log) as pbar:
        for _ in range(10):
            pbar.update()
            log.info('Pass')
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.last_print_n == 10



# Generated at 2022-06-24 09:54:37.702191
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        # Test tqdm_logging_redirect
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

        # Test logging_redirect_tqdm
        LOG2 = logging.getLogger('Test2')

# Generated at 2022-06-24 09:54:39.043840
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(std_tqdm)

# Generated at 2022-06-24 09:54:47.505937
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile, os
    tmpfile = tempfile.NamedTemporaryFile(mode='r+t')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    stream = tmpfile
    log = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord(__name__, logging.INFO,
                               '/path/to/file.py', 10, 'Hello, logging!', None, None)
    handler.stream = stream
    handler.setFormatter(formatter)
    handler.emit(record)
    tmpfile.seek(0)
    assert tmpfile.readline().strip('\n') == 'Hello, logging!'
    tmpfile.close()

# Generated at 2022-06-24 09:54:58.631977
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create fake stream and logger
    log = logging.getLogger(__name__)
    # set logger to DEBUG so we can see the message
    log.setLevel(logging.DEBUG)
    # create a stream handler
    stream_handler = logging.StreamHandler()
    # add stream handler to the logger
    log.addHandler(stream_handler)

    # create message for logger
    message = "test message"
    # log message
    log.debug(message)

    # create handler with fake stream
    fake_stream = 'stream'
    fake_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    fake_handler.stream = fake_stream

    # put message into stream and flush stream
    fake_handler.emit(message)

# Generated at 2022-06-24 09:55:05.051689
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    LOG = logging.getLogger(__name__)
    try:
        from bare_bones_test_suite_mixin import BareBonesTestSuiteMixin
    except ImportError:
        return
    import io
    from contextlib import redirect_stdout

    class TestLoggingRedirectTqdm(BareBonesTestSuiteMixin):
        def test_logging_redirect_tqdm(self):
            # type: () -> None
            logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:55:11.415710
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:55:16.845139
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler().stream  # default stream stdout


# Generated at 2022-06-24 09:55:24.540139
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create handler for testing
    tqdm_handler = _TqdmLoggingHandler()

    # create log message for testing
    log_message = 'This is a test log message.'

    # create record
    record = logging.LogRecord(
        name='tqdm._tqdm',
        level=logging.DEBUG,
        pathname=None,
        lineno=0,
        msg=log_message,
        args=None,
        exc_info=None
    )

    # call the emit method
    tqdm_handler.emit(record)

    # check that message was written
    assert log_message in sys.stderr.getvalue(), \
        'Message was not written to stderr.'

# Generated at 2022-06-24 09:55:26.261682
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, _TqdmLoggingHandler)


# Generated at 2022-06-24 09:55:28.747330
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.stream in {sys.stderr, sys.stdout}


# Generated at 2022-06-24 09:55:37.818107
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('sys.stdout') as mock_stdout:
        logging_redirect_tqdm()
        logging.info("console logging redirected to `tqdm.write()`")
        assert mock_stdout.write.call_count == 1
    with patch('sys.stdout') as mock_stdout:
        with logging_redirect_tqdm(loggers=[logging.getLogger("foo_bar")]):
            logging.info("not redirected")
            assert mock_stdout.write.call_count == 0
        logging.info("not redirected")
    with patch('sys.stdout') as mock_stdout:
        assert mock_stdout.write.call_count == 0

# Generated at 2022-06-24 09:55:39.538818
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.Logger('test')
    logger.level = logging.INFO
    handler = _TqdmLoggingHandler()
    logger.handlers = [handler]
    logger.info('This is a test.')

# Generated at 2022-06-24 09:55:45.562324
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..tqdm import trange
    from .testing import log_capture
    import logging
    import time

    with tqdm_logging_redirect(desc='test', miniters=2) as pbar:
        pbar.write("Running...")
        for i in trange(10):
            time.sleep(.1)
            if i % 2 == 0:
                logging.warning("Unavoidable warning: %d" % i)



# Generated at 2022-06-24 09:55:53.853838
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    from tqdm.contrib.concurrent import thread_map
    from .test_concurrent import test_thread_map

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar:
        test_thread_map(thread_map, pbar=pbar)


__all__ = ['tqdm_logging_redirect', 'logging_redirect_tqdm']

# Generated at 2022-06-24 09:55:55.576697
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    w_handler = _TqdmLoggingHandler()
    assert isinstance(w_handler, logging.StreamHandler)


# Generated at 2022-06-24 09:56:03.993348
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    # just in case disable tqdm output
    std_tqdm.disable = True
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-24 09:56:08.646840
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    return handler

# Generated at 2022-06-24 09:56:17.999256
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    import logging

    def mock_get_inst_tqdm_write(write=None):
        import tqdm
        import tqdm.std

        class Instance(tqdm.std.tqdm):
            def __init__(self):
                super(Instance, self).__init__()
                if write is not None:
                    self.write_orig = write
            def write(self, *args, **kwargs):
                return self.write_orig(self, *args, **kwargs)

        return Instance

    f = io.StringIO()
    for write in [None, lambda instance, *args, **kwargs: (print(args), print(kwargs))]:
        tqdm_class = mock_get_inst_tqdm_write(write=write)
       

# Generated at 2022-06-24 09:56:24.286771
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        tqdm_logging_handler = _TqdmLoggingHandler()
        assert tqdm_logging_handler.tqdm_class == std_tqdm
    except Exception:
        raise Exception('Constructor of class _TqdmLoggingHandler is broken.')


# Generated at 2022-06-24 09:56:31.087365
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import six
    import mock
    import logging
    from tqdm import trange

    # Check whether redirecting logging works as expected
    test_msg = "test message"
    with six.assertRaisesRegex(
            TypeError,
            "write\(\): expected str, not logging.LogRecord"
    ):
        with logging_redirect_tqdm():
            trange(1, desc=test_msg)
            logging.info(test_msg)

    with logging_redirect_tqdm(loggers=[logging.getLogger(__name__)]):
        trange(1, desc=test_msg)
        mock.patch('tqdm.contrib.logging.std_tqdm.write').assert_called_once_with(
            mock.ANY, mock.ANY)



# Generated at 2022-06-24 09:56:37.327912
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import StringIO
    import logging
    io = StringIO()
    tlh = _TqdmLoggingHandler(
        tqdm_class=std_tqdm,
        stream=io
    )
    record = logging.LogRecord(name='name', level=logging.DEBUG,
                               pathname='pathname', lineno=1,
                               msg='DEBUG', args=None, exc_info=None)
    tlh.emit(record)
    assert io.getvalue() == 'DEBUG\n'

# Generated at 2022-06-24 09:56:46.203540
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .contrib.delorean import Delorean
    from .contrib.delorean._logger import _Logger
    from .contrib.delorean._logger import _get_time
    from .contrib.delorean.time_agent import register
    from .contrib.delorean.travel_machine import travel

    logger = logging.getLogger()
    logger.propagate = False
    logger.setLevel(logging.DEBUG)
    register("time_agent", _get_time)
    travel("time_agent")
    my_pbar = std_tqdm("Time travel")
    std_tqdm.write("Welcome")
    logger.addHandler(_TqdmLoggingHandler())
    logger.info("Love")

# Generated at 2022-06-24 09:56:53.227502
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in range(3):
            # Should be printed in logging
            LOG.info(i)
            # Should be printed in tqdm
            print(i)
            # Should be printed in tqdm
            import tqdm  # pylint: disable=wrong-import-position
            tqdm.write(i)
            # Should be printed in stdout
            print(i)
            time.sleep(1)

# Generated at 2022-06-24 09:56:59.589850
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm
    from tqdm.contrib._logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)  # type: ignore
    logger.setLevel(logging.DEBUG)

    hdlr = _TqdmLoggingHandler(tqdm_class=tqdm)
    logger.addHandler(hdlr)

    logger.debug('hello')
    logger.info('debugging')

# Generated at 2022-06-24 09:57:06.099916
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())


# Generated at 2022-06-24 09:57:11.878961
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm

    loggers = [logging.getLogger("tqdm.contrib.logging")]

    def _test(bar_format, msg, expected_strout):
        expected_strout = bar_format + ' ' + expected_strout
        # test: loggers=None
        with tqdm_logging_redirect(
            total=2,
            bar_format=bar_format,
            loggers=loggers,
        ) as pbar:
            pbar.update()
            logger = logging.getLogger("tqdm.contrib.logging")
            logger.info(msg)
        assert pbar.format_dict['bar'] == expected_strout


# Generated at 2022-06-24 09:57:21.348247
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import cStringIO
    import logging

    def assert_redirect_tqdm(
        loggers,  # type: Optional[List[logging.Logger]]
    ):
        # type: (...) -> None
        """Asserts that logging_redirect_tqdm correctly redirects logs"""
        memory_file = cStringIO.StringIO()
        tqdm_class = std_tqdm
        tqdm_class._instances = []
        original_stdout = sys.stdout

        def write(*args, **kwargs):
            """
            write(...)
            Write string to file
            """
            kwargs.pop('file', None)  # type: ignore
            text = args[0]
            memory_file.write(text)


# Generated at 2022-06-24 09:57:31.894301
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    buf = io.StringIO()
    buf.write("test_pre")
    buf.seek(0)
    buf_err = io.StringIO()
    buf_err.write("test_pre_err")
    buf_err.seek(0)

    handler = _TqdmLoggingHandler()
    handler.stream = buf

    record = logging.LogRecord(name='test',
                               level=logging.INFO,
                               pathname='test.py',
                               lineno=1,
                               msg='{}',
                               args=('test_message',),
                               exc_info=None)

    try:
        handler.emit(record)
    except (KeyboardInterrupt, SystemExit):
        raise

# Generated at 2022-06-24 09:57:33.970439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:41.707634
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    record = LogRecord("test logger", level=INFO, pathname="test_pathname", lineno=1, msg="test message", args=("test",), exc_info=None)
    # Test if record is printed by tqdm write
    tlh.emit(record)
    assert hasattr(tlh, "tqdm_class")
    assert tlh.stream == sys.stderr
    # Test if exc_info is None
    assert tlh.handleError(record) == None



# Generated at 2022-06-24 09:57:47.240837
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=10):
        for i in range(10):
            LOG.info('console logging redirected to `tqdm.write()`')
            time.sleep(0.1)

# Generated at 2022-06-24 09:57:55.033198
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from .test_tqdm import pretest_posttest  # type: ignore
    from .test_tqdm import closing  # type: ignore
    from .test_tqdm import closing_fft  # type: ignore
    from .test_tqdm import closing_iter  # type: ignore
    from .test_tqdm import closing_pandas  # type: ignore
    from .test_tqdm import closing_file  # type: ignore

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger('Test Logger')


# Generated at 2022-06-24 09:57:58.901831
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(4):
            if i == 3:
                LOG.info("logging redirected to `tqdm.write()`")
                break



# Generated at 2022-06-24 09:58:05.463875
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test for logging_redirect_tqdm
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:14.538915
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm

    class TestTqdm(tqdm):
        def write(self, s, file=None, end="\n"):
            if end == "\n":
                self.write_history = []
            self.write_history.append(s)

    class _TestTqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self, tqdm_class=TestTqdm):
            super(_TestTqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class

        def handleError(self, record):
            """
            Overwrite logging.StreamHandler.handleError to avoid
            printing the error message to stderr.
            """
            pass

    tqdm_handler = _TestTqdmLogging

# Generated at 2022-06-24 09:58:24.195749
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm as std_tqdm

    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-24 09:58:33.848126
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    stream = StringIO()

    # Test handling of KeyboardInterrupt
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    try:
        raise KeyboardInterrupt
    except KeyboardInterrupt:
        record = logging.Logger.makeRecord(
            logging.getLogger(),
            logging.INFO,
            "/home/foo.py",
            87,
            "Test logging",
            (),
            None,
            None
        )
        handler.emit(record)
    assert stream.getvalue() == "INFO:root:Test logging\n"

    # Test handling of a regular exception
    stream.truncate(0)
    handler = _TqdmLoggingHandler()
    handler.stream = stream

# Generated at 2022-06-24 09:58:35.354734
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = _TqdmLoggingHandler()
    assert tqdm_class is not None

# Generated at 2022-06-24 09:58:42.371841
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():

    class TestTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            super(TestTqdm, self).__init__(*args, **kwargs)
            self.flush_count = 0
            self.write_message = None

        def flush(self):
            self.flush_count += 1

        def write(self, s, file=None):
            self.write_message = s


# Generated at 2022-06-24 09:58:46.584463
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.stream == sys.stderr
    assert tqdm_handler._name == 'tqdm'


# Generated at 2022-06-24 09:58:56.316513
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    from .test_tqdm import pretest_posttest  # noqa

    logger = logging.getLogger(__name__)
    msg = 'test'
    iterations = 1000

    def test_tqdm_logging_redirect_inner(logger, msg, iterations):
        # type: (logging.Logger, str, int) -> None

        with tqdm_logging_redirect(
                total=iterations,
                logger=logger,
                loggers=logger,
                desc=msg,
                tqdm_class=std_tqdm,
        ):
            for i in range(iterations):
                logger.info(msg + str(i))
