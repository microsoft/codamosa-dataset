

# Generated at 2022-06-24 09:48:48.685036
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    def logtest():
        # type: () -> None
        logger = logging.getLogger(__name__)
        logger.info('log')
        logger.exception('log')
        logger.error('log')

    logging.basicConfig(level=logging.INFO)
    logtest()
    with logging_redirect_tqdm():
        logtest()
    logtest()
    with logging_redirect_tqdm([logging.root]):
        logtest()
    logtest()


# Generated at 2022-06-24 09:48:57.395946
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    import logging
    import re

    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(3):
            if i == 1:
                logger.info('info')
            if i == 2:
                logger.warning('warning')

    with logging_redirect_tqdm():
        list(trange(3, desc='simple'))

    with logging_redirect_tqdm() as pbar:
        for i in trange(3, desc='complex'):
            if i == 1:
                logger.info('info')
            if i == 2:
                logger.warning('warning')
            pbar.set_description('Foo')
            pbar.set_postfix(postfix='postfix')

# Generated at 2022-06-24 09:49:06.753258
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import INFO
    from logging import Handler
    from logging import StreamHandler
    from logging import basicConfig
    from logging import getLogger

    with StringIO() as log_output:
        logger = getLogger(__name__)
        basicConfig(
            level=INFO, format='[%(levelname)s] %(message)s',
            file=log_output, stream=log_output,
        )

# Generated at 2022-06-24 09:49:10.788132
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for logging_redirect_tqdm
    """
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:49:13.978751
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.root]
    with tqdm_logging_redirect(loggers=loggers):
        print("Hello world")



# Generated at 2022-06-24 09:49:15.813164
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert isinstance(h, logging.StreamHandler)

# Generated at 2022-06-24 09:49:22.526309
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    import tqdm.contrib.logging as tqdm_logging

    LOG = logging.getLogger('test.logger')

    with tqdm_logging_redirect(
        'Iterating',
        tqdm=tqdm.tqdm_notebook,
        logger=LOG,
        loggers=[LOG],
        tqdm_class=tqdm.tqdm_notebook,
    ) as pbar:
        pbar.update(1)



# Generated at 2022-06-24 09:49:27.930999
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("console logging restored")
    else:
        assert False



# Generated at 2022-06-24 09:49:33.216988
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info("test_start")  # flush logging buffer
    with tqdm_logging_redirect():
        for i in range(10):
            LOG.info("redirected %d", i)

# Generated at 2022-06-24 09:49:39.979911
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from _pytest.python import Skip
        raise Skip("pytest-cov unavailable")

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)s   %(message)s (%(filename)s:%(lineno)d)")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    def emulate_logging():
        logger.info("hello world")

    emulate_logging()


# Generated at 2022-06-24 09:49:50.451165
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Unit test for method emit of class _TqdmLoggingHandler"""
    class TestTqdm(object):
        """Test class for testing purposes"""
        def __init__(self):
            """Just to create the attribute file"""
            self.file = None

        def write(self, msg, file=None):
            """Just to store the last message"""
            self.file = file

    logger = logging.getLogger('test')
    tqdm_handler = _TqdmLoggingHandler(TestTqdm)
    tqdm_handler.stream = sys.stderr
    logger.addHandler(tqdm_handler)

    record = logging.LogRecord('test', logging.DEBUG,
                               __file__, 53, 'test',
                               None, None)

# Generated at 2022-06-24 09:49:56.496541
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    import sys
    from contextlib import redirect_stdout

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    out = io.StringIO()
    with redirect_stdout(out):
        with tqdm_logging_redirect():
            LOG.info('<tqdm_write> Hello world!')

    assert out.getvalue() == '<tqdm_write> Hello world!\n'


__all__ = ['tqdm_logging_redirect', 'logging_redirect_tqdm']

# Generated at 2022-06-24 09:50:00.351897
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(desc='Loading') as pbar:
        logger = logging.getLogger(__name__)
        logger.info("Hello world!")
        for i in range(50):
            logger.info("Foo %d", i)
            pbar.update(1)

# Generated at 2022-06-24 09:50:03.499949
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    loggers = logging.getLogger(__name__)
    with logging_redirect_tqdm(loggers):
        loggers.info('message')

# Generated at 2022-06-24 09:50:11.797104
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class _TqdmLoggingHandler_test(_TqdmLoggingHandler):
        def emit(self, record):
            try:
                msg = self.format(record)
                assert(msg is not None)
                self.stream.write(msg)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    test_logging_handler = _TqdmLoggingHandler_test()
    logging.getLogger('test_logging_handler').addHandler(test_logging_handler)
    logging.getLogger('test_logging_handler').error("test")

# Generated at 2022-06-24 09:50:13.511868
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger()
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.warning('test warning')


# Generated at 2022-06-24 09:50:23.042081
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys
    import tempfile

    def get_input_output(input_str):
        # type: (str) -> Tuple[str, str]
        """
        Get input and output of function.
        """
        from pytest import capfd

        with capfd.disabled():
            from six.moves import StringIO as StringIO_

            stdout_orig = sys.stdout
            sys.stdout = StringIO_()
            with logging_redirect_tqdm():
                dd_logging_redirect(input_str)

            sys.stdout = stdout_orig
            # ensure print on stdout (not redirected to tqdm)
            print('[redirected] %s' % input_str.upper(), file=sys.stdout)

        output = sys.stdout

# Generated at 2022-06-24 09:50:31.191618
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger()

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                assert str(pbar) == "console logging redirected to `tqdm.write()`"

    logging_redirect_tqdm()
    assert logging.root.handlers[0].stream == std_tqdm._instances[0].fp
    assert logging.root.handlers[0].tqdm_class == std_tqdm

# Generated at 2022-06-24 09:50:39.785888
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    import sys
    import time
    import unittest
    try:
        from unittest import mock  # py3
    except ImportError:
        import mock

    from tqdm.contrib.logging import tqdm_logging_redirect

    class LoggingRedirectTest(unittest.TestCase):

        @mock.patch('sys.stdout', new_callable=io.StringIO)
        @mock.patch('sys.stderr', new_callable=io.StringIO)
        def test_tqdm_logging_redirect(self, mock_stderr, mock_stdout):
            # type: (unittest.TestCase) -> None
            orig_stdout = sys.stdout
            orig_stderr = sys.stderr

# Generated at 2022-06-24 09:50:42.205060
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = _TqdmLoggingHandler()
    assert tqdm_class.tqdm_class is std_tqdm


# Generated at 2022-06-24 09:50:43.888487
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import tqdm
    handler = _TqdmLoggingHandler(tqdm)
    assert handler

# Generated at 2022-06-24 09:50:48.638968
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    if __name__ == '__main__':
        with logging_redirect_tqdm():
            with open("test_logging_redirect_tqdm_output", "a") as output_file:
                LOG = logging.getLogger(__name__)
                LOG.info("This file was created by test_logging_redirect_tqdm")
                for i in range(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:50:54.970868
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    logging.basicConfig(level=logging.INFO)
    msg = 'console logging redirected to `tqdm.write()`'
    with tqdm_logging_redirect(total=9) as pbar:
        time.sleep(0.01)
        pbar.update(3)
        logging.info(msg)
        time.sleep(0.01)
        pbar.update(6)

    pbar.close()

# Generated at 2022-06-24 09:51:01.794018
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.root]
    tqdm_handler = _TqdmLoggingHandler(logging.root)
    orig_handler = _get_first_found_console_logging_handler(loggers)
    tqdm_handler.setFormatter(orig_handler.formatter)
    tqdm_handler.stream = orig_handler.stream
    loggers = [
        handler for handler in loggers
        if not _is_console_logging_handler(handler)] + [tqdm_handler]
    assert loggers


# Generated at 2022-06-24 09:51:11.095487
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    from ..std import logger as std_logger
    from .stdout import set_tqdm_write_to_stdout
    set_tqdm_write_to_stdout()

    # Test external logger
    logger = logging.getLogger("mylogger")
    with tqdm_logging_redirect("test1", leave=True, logger=logger) as pbar:
        assert "logger" in pbar.desc.lower()

    # Test tqdm(...)
    with tqdm_logging_redirect("test2", leave=True) as pbar:
        assert "logger" in pbar.desc.lower()

    # Test std logger

# Generated at 2022-06-24 09:51:12.551233
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logging.info('test')


# Generated at 2022-06-24 09:51:20.892101
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    # ------------- Test with tqdm.std.tqdm -----------------
    log_list = list()
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                logging.info('console logging redirected to `tqdm.write()`')
            log_list.append(pbar.format_meter(pbar.n, pbar.total))

    # test for console logging redirect
    assert 'console logging redirected to `tqdm.write()`' in log_list
    # test for status messages

# Generated at 2022-06-24 09:51:23.686699
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_logger = _TqdmLoggingHandler()
    assert test_logger.stream == sys.stderr


# Generated at 2022-06-24 09:51:31.233319
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        tqdm_test = std_tqdm()
        tqdm_test.write = lambda x: sys.stderr.write("tqdm.write: {}\n".format(x))
        std_out = sys.stdout
        std_err = sys.stderr
        tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm_test)
        tqdm_logging_handler._TqdmLoggingHandler__emit("test")
        std_err.write("test\n")
    except Exception:
        print("_TqdmLoggingHandler.__emit() failed.")
    finally:
        sys.stdout = std_out
        sys.stderr = std_err
        tqdm_test.close()

# Generated at 2022-06-24 09:51:40.606840
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .std import tqdm, tqdm_notebook

    tqdm_obj = _TqdmLoggingHandler(tqdm)
    assert isinstance(tqdm_obj, logging.StreamHandler)

    tqdm_obj = _TqdmLoggingHandler(tqdm_notebook)
    assert isinstance(tqdm_obj, logging.StreamHandler)

if __name__ == '__main__':  # pragma: no cover
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:46.528739
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # set up logger with one handler
        log_handler = logging.StreamHandler()
        log = logging.getLogger(__name__ + '_logging_redirect_tqdm')
        log.addHandler(log_handler)
        with tqdm_logging_redirect(loggers=[log]) as pbar:
            log.info('log from logging_redirect_tqdm')
            pbar.write('log from tqdm')
        assert pbar.n == 1
    except AssertionError:
        return False
    else:
        return True


# Generated at 2022-06-24 09:51:57.769212
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import mock
    tqdm_obj = mock.Mock()
    rec_obj = mock.Mock()
    rec_obj.getMessage = mock.Mock(return_value='whatever')
    rec_obj.asctime = mock.Mock(return_value='whatever')

    rec_obj.levelname = mock.Mock(return_value='WARNING')
    rec_obj.name = mock.Mock(return_value='whatever')
    rec_obj.filename = mock.Mock(return_value='whatever')
    rec_obj.lineno = mock.Mock(return_value='whatever')
    rec_obj.funcName = mock.Mock(return_value='whatever')
    rec_obj.process = mock.Mock(return_value='whatever')

# Generated at 2022-06-24 09:52:02.669775
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(8):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:52:12.492299
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from sys import version_info
    from logging import StreamHandler, Formatter

    # StringIO object
    file = StringIO()
    # Create stream handler
    stream_handler = StreamHandler(file)
    # Set format to stream handler
    formatter = Formatter('%(asctime)s - %(message)s')
    stream_handler.setFormatter(formatter)
    # Create logger with stream handler
    logger = logging.getLogger('Test')
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO)
    # Run logging
    logger.info('Test logging')
    # Get content from file object
    file.seek(0)
    console_result = file.read()
    # Python 2 string type

# Generated at 2022-06-24 09:52:21.179787
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    def test(
        redirect=False,  # type: bool
    ):
        # type: (...) -> None
        # Check if logging works
        LOG.info("console logging normally visible")

        if redirect:
            # Redirect
            with logging_redirect_tqdm():
                # Check if logging is redirected
                LOG.info("console logging redirected to `tqdm.write()`")
                # Check if logging and tqdm coexist well
                for _ in trange(3):
                    LOG.info("console logging redirected and displayed with tqdm")
        else:
            # Check if logging is not redirected
            LOG.info("console logging NOT redirected to `tqdm.write()`")
            # Check if logging

# Generated at 2022-06-24 09:52:31.016567
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging

    log_io = io.StringIO()
    log = logging.getLogger(__name__ + '.test')
    ch = logging.StreamHandler(log_io)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(message)s")
    ch.setFormatter(formatter)
    log.addHandler(ch)
    log.setLevel(logging.DEBUG)

    log.info("foo")  # should not be shown by `tqdm.write()`

    for logger in [log, logging.root]:
        with logging_redirect_tqdm(loggers=[logger]):
            log.info("bar")
        log.info("baz")  # should not be shown by `tqdm.write()`

    assert log_

# Generated at 2022-06-24 09:52:34.508919
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    with logging_redirect_tqdm():
        for _ in tqdm(range(10)):
            logging.info('test')



# Generated at 2022-06-24 09:52:38.432177
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    record = logging.LogRecord(
        name="name", level=logging.INFO, pathname="pathname", lineno=1,
        msg="msg", args=(), exc_info=None)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.emit(record)

# Generated at 2022-06-24 09:52:40.376829
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(std_tqdm)
    assert handler.tqdm_class is std_tqdm


# Generated at 2022-06-24 09:52:42.547365
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Unit test for constructor of class _TqdmLoggingHandler"""
    tqdmLoggingHandler = _TqdmLoggingHandler()
    assert tqdmLoggingHandler


# Generated at 2022-06-24 09:52:48.693106
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    class TestHandler(logging.StreamHandler):
        def __init__(self):
            super(TestHandler, self).__init__()
            self.log_messages = []
            self.setFormatter(logging.Formatter())

        def emit(self, record):
            try:
                msg = self.format(record)
                self.log_messages += [msg]
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    with TestHandler() as log_handler:
        log_handler.setLevel(logging.getLevelName('INFO'))
        logger = logging.getLogger(__name__)

# Generated at 2022-06-24 09:52:55.081918
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Avoid importing tqdm
    class MockTqdm(object):
        @staticmethod
        def write(msg, file):
            pass
    tqdm_handler = _TqdmLoggingHandler(MockTqdm)
    tqdm_handler.emit(logging.makeLogRecord({'msg': 'foo', 'levelname': 'INFO'}))

# Generated at 2022-06-24 09:53:05.882012
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        desc='test',
        total=1,
        mininterval=0,
        smoothing=0,
        level=0,
    ) as pbar:
        LOG.info("Info 1")
        pbar.update()
        LOG.info("Info 2")
        LOG.info("Info 3")


if __name__ == '__main__':
    # Unit tests
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:53:14.263336
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            loggers=None,
            tqdm_class=None,
            total=1,
            desc='Test tqdm_logging_redirect function',
            logger=logging.getLogger(__name__),
            file=sys.stderr) as pbar:
        pbar.write('Test tqdm_logging_redirect function')
        pbar.set_description('Write log')
        pbar.set_postfix_str(' = 99')
        pbar.write('Log write.')
        pbar.update(1)

# Generated at 2022-06-24 09:53:20.091860
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:53:31.886761
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(range(10), desc='bar',
                               file=open('test.log', 'w')) as pbar:
        for i in pbar:
            if i == 5:
                logging.info('console logging redirected to `tqdm.write()`')
    with open('test.log') as fobj:
        logs = list(fobj)
    assert 'bar: 100%|██████████| 10/10 [00:00<00:00, 3257.68it/s]' in logs[0]
    assert 'console logging redirected to `tqdm.write()`' in logs[1]


if __name__ == '__main__':
    test_tqdm

# Generated at 2022-06-24 09:53:42.778252
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    # create logger for this test
    test_log = logging.getLogger('test_logger')
    test_log.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    test_log.addHandler(ch)

    # create tqdm handler
    tqdm_handler = _TqdmLoggingHandler()

    # add tqdm handler to logger
    test_log.addHandler(tqdm_handler)

    # 'application' code
    test_log.debug('foo')

# Generated at 2022-06-24 09:53:50.646153
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    try:
        from unittest.mock import Mock  # Python 3.3+
    except ImportError:
        from mock import Mock  # Python 2

    # a mock tqdm.write function
    tqdm_write_mock = Mock()

    class MockTqdm(object):
        def __init__(self, *args, **kwargs):
            pass
        # pylint: disable=unused-argument
        def write(self, msg, file=None):
            tqdm_write_mock(msg, file)
        def __call__(self, *args, **kwargs):
            return self
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass

    # a dummy context (not really used for back

# Generated at 2022-06-24 09:54:01.607967
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    This test will fail if the tqdm instance does not receive the logging messages.
    """
    from tqdm.auto import tqdm

    # Create a dummy logger and a tqdm instance
    logger = logging.getLogger('dummy')
    logger.setLevel(logging.DEBUG)

    # Use the dummy logger to count the number of logging messages
    # sent to the tqdm instance.
    count = 0
    with tqdm(total=1) as pbar:
        with logging_redirect_tqdm(loggers=[logger]):
            logger.debug('test1')
            logger.debug('test2')
            logger.debug('test3')

            logger.info('test1')
            logger.info('test2')
            logger.info('test3')


# Generated at 2022-06-24 09:54:10.499466
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=protected-access,invalid-name
    from io import StringIO
    import sys
    from contextlib import contextmanager
    from tqdm import tqdm_proxy
    from tqdm.contrib.logging import _TqdmLoggingHandler

    @contextmanager
    def replace_stdout(new_stream):
        old_stdout = sys.stdout
        sys.stdout = new_stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    message = "This should be a record message"
    with tqdm_proxy(10) as pbar:
        with StringIO() as stream:
            with replace_stdout(stream):
                tqdm_handler = _TqdmLoggingHandler(tqdm_proxy)
                tq

# Generated at 2022-06-24 09:54:13.307479
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    print("Unit test for constructor of class _TqdmLoggingHandler")
    # test initialization
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-24 09:54:16.992290
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    try:
        return test__TqdmLoggingHandler_emit_noexcept()
    except (KeyboardInterrupt, SystemExit):
        return None
    except:  # noqa pylint: disable=bare-except
        raise



# Generated at 2022-06-24 09:54:22.508479
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Make sure that the emit method of the _TqdmLoggingHandler class
    creates no exception.

    Returns
    -------
    out : bool
        True if test succeed, False if otherwise,
    """
    log_handler = _TqdmLoggingHandler()
    try:
        for _ in range(100):
            log_handler.emit(logging.INFO)
        return True
    except:
        return False



# Generated at 2022-06-24 09:54:24.761603
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        with _TqdmLoggingHandler():
            pass
    except:
        assert False, 'unexpected error in _TqdmLoggingHandler()'

# Generated at 2022-06-24 09:54:36.298485
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    with tqdm_logging_redirect(unit='bytes', unit_scale=True,
                               total=1000, desc='test description') as pbar:
        for i in range(10):
            pbar.update(100)
            logger.debug('written %s bytes so far' % pbar.n)
        assert pbar.n == 1000
        assert pbar.total == 1000
        assert pbar.desc == 'test description'
        assert pbar.dynamic_messages == []

# Generated at 2022-06-24 09:54:37.859597
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    foo = _TqdmLoggingHandler(std_tqdm)
    assert foo


# Generated at 2022-06-24 09:54:44.376744
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:55.233294
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm
    import logging
    import io
    pbar = tqdm(total=100)
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.setLevel(2)
    handler.stream = io.StringIO()

# Generated at 2022-06-24 09:55:01.047557
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9, loggers=[LOG], desc="this is a desc") as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                assert pbar.n == i, "Output does not match"

# Generated at 2022-06-24 09:55:07.501865
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    """
    Test helper method of _TqdmLoggingHandler class
    """
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = sys.stderr = StringIO()
    try:
        handler = _TqdmLoggingHandler()
        handler.createLock()
        record = logging.LogRecord(logging.getLevelName(10), None, None, None, 'test1', None, None)
        handler.emit(record)
        record = logging.LogRecord(logging.getLevelName(10), None, None, None, 'test2', None, None)
        handler.emit(record)
        assert sys.stderr.getvalue() == 'test1\n' + 'test2\n'
    finally:
        sys.std

# Generated at 2022-06-24 09:55:17.737792
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    log_format = '%(levelname)s %(message)s'

    with tqdm_logging_redirect(unit='msgs',
                               set_level=logging.DEBUG,
                               loggers=[logging.getLogger(__name__)],
                               log_format="%(levelname)s %(message)s") as pbar_logger:
        pbar = pbar_logger
        log = logging.getLogger(__name__)
        log.debug('message1')
        pbar.update()
        log.info('message2')
        pbar.update()
        log.warn('message3')
        pbar.update()
        log.error('message4')
        pbar.update()



# Generated at 2022-06-24 09:55:19.594211
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.Handler)
    assert handler.formatter is None
    assert handler.level == 0
    assert handler.stream is None
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:55:24.113795
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from tqdm import trange
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.handlers = []  # Remove all handlers
    logger.addHandler(_TqdmLoggingHandler())
    for i in trange(3):
        logger.debug(i)


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-24 09:55:28.513344
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up
    # noqa
    # pylint: disable=protected-access

    log = logging.getLogger('foo')
    log.setLevel(logging.INFO)
    sh = logging.StreamHandler()
    log.addHandler(sh)

    with logging_redirect_tqdm():
        log.info('example')



# Generated at 2022-06-24 09:55:37.635414
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    test_error = ValueError("!")
    test_logging_handler = None
    def _test_logging_handler(record):
        raise test_error

    root_logger = logging.getLogger()
    saved_handlers = root_logger.handlers

# Generated at 2022-06-24 09:55:46.016095
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    record = logging.LogRecord(name='foo', level=logging.INFO,
                               pathname='foo', lineno=1, msg='bar',
                               args=None, exc_info=None)
    handler = _TqdmLoggingHandler(std_tqdm)
    try:
        handler.emit(record)
        assert True  # Success!
    except BaseException:
        raise AssertionError("_TqdmLoggingHandler().emit() raised exception.")
    try:
        record.level = logging.CRITICAL
        handler.emit(record)
        assert False  # Failure!
    except SystemExit:
        pass



# Generated at 2022-06-24 09:55:49.162287
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect():
        logging.info("test")

# Generated at 2022-06-24 09:55:58.070831
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    from tqdm.autonotebook import tqdm

    log = StringIO()
    logger = logging.getLogger('logger')
    logger.setLevel(logging.INFO)
    logger.handlers = [logging.StreamHandler(log)]
    assert not isinstance(logger.handlers[0],
                          _TqdmLoggingHandler)
    logger.info('this should print to console')
    assert 'this should print to console' in log.getvalue()

    with tqdm_logging_redirect(
            loggers=[logger], tqdm_class=tqdm):
        logger.info('this should print to tqdm')
    assert 'this should print to tqdm' not in log.getvalue()

# Generated at 2022-06-24 09:56:03.125805
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    stream = sys.stdout
    tqdm_class = std_tqdm
    try:
        del tqdm_class.msg
    except AttributeError:
        pass
    handler = _TqdmLoggingHandler(tqdm_class)
    assert handler.level == logging.NOTSET
    assert handler.formatter is None
    assert not handler.filters
    assert handler.stream == stream
    assert handler.tqdm_class is tqdm_class


# Generated at 2022-06-24 09:56:16.622247
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm._tqdm import _StringIO

    log = logging.getLogger(__name__)

    with _StringIO() as io:
        with logging_redirect_tqdm(loggers=[log]):
            for _ in trange(4):
                log.info('console logging redirected to `tqdm.write()`')
        assert io.getvalue() == 'console logging redirected to `tqdm.write()`\n' * 4

    with _StringIO() as io:
        with logging_redirect_tqdm(loggers=[log]):
            log.info('logger -> %d', 0)
            log.info('logger -> %d', 1)
            log.info('logger -> %d', 2)
            log.info

# Generated at 2022-06-24 09:56:26.860060
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Test: redirect logging messages to tqdm write
    with tqdm_logging_redirect(total=1, desc='with tqdm_logging_redirect',
                               loggers=[LOG], tqdm_class=tqdm) as pbar:
        assert pbar is not None
        LOG.info("console logging redirected to `tqdm.write()`")

    # Test: redirect logging messages to tqdm write
    with tqdm(total=1, desc='with tqdm_logging_redirect') as pbar:
        assert pbar is not None

# Generated at 2022-06-24 09:56:28.280677
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        _TqdmLoggingHandler()
        assert True
    except:
        assert False


# Generated at 2022-06-24 09:56:33.493432
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    TqdmLoggingHandler_inst = _TqdmLoggingHandler(tqdm_class)
    assert TqdmLoggingHandler_inst.__class__ == _TqdmLoggingHandler
    assert TqdmLoggingHandler_inst.tqdm_class.__name__ == 'tqdm' #tqdm_class.__name__


# Generated at 2022-06-24 09:56:38.171637
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test for the logging_redirect_tqdm function.
    """
    from .tests import TestCase, pretest_posttest_testsuite
    from .tests import _test_logging_tqdm_integration
    TestCase(_test_logging_tqdm_integration(logging_redirect_tqdm)).run()



# Generated at 2022-06-24 09:56:40.589843
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class Test:
        def __init__(self):
            self.bar = 'bar'
    t = Test()
    _TqdmLoggingHandler(t)



# Generated at 2022-06-24 09:56:45.034644
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm_class)
    tqdm_handler.stream = sys.stdout
    record = logging.LogRecord('name', logging.INFO, '', 1, 'message', (), None)
    tqdm_handler.emit(record)

# Generated at 2022-06-24 09:56:50.988297
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.test import MockTqdmType

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(tqdm_class=MockTqdmType):
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    assert MockTqdmType.write.called
    assert MockTqdmType.n == 4

# Generated at 2022-06-24 09:56:55.751034
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(5):
                LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("logging restored")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:57:03.856913
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9, desc="progress:"):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:10.107084
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class TqdmHandlerLogger(object):
        def __init__(self):
            self.handlers = []
            self.logger = logging.getLogger("TqdmHandlerLogger")
            self.logger.handlers = []

        def addHandler(self, handler):
            self.handlers.append(handler)

        def removeHandler(self, handler):
            self.handlers.remove(handler)
    logger = TqdmHandlerLogger()
    logger.addHandler(_TqdmLoggingHandler(std_tqdm))
    assert isinstance(logger.handlers[0], _TqdmLoggingHandler)
    handler = logger.handlers[0]
    assert isinstance(handler.tqdm_class, type(std_tqdm))

# Generated at 2022-06-24 09:57:20.381385
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Unit test for method emit of class _TqdmLoggingHandler
    """
    import sys
    import io
    import logging
    import pytest
    from pytest import raises
    from tqdm.contrib.logging import _TqdmLoggingHandler

    @pytest.fixture
    def log_out(self):
        # type: (Any) -> io.StringIO
        return io.StringIO()

    @pytest.fixture
    def hdlr(self, log_out):
        # type: (Any, io.StringIO) -> _TqdmLoggingHandler
        return _TqdmLoggingHandler(stream=log_out)


# Generated at 2022-06-24 09:57:29.621448
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm

    import logging
    from .tqdm import trange

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    if __name__ == '__main__':
        with tqdm_logging_redirect(unit='b', unit_scale=True, unit_divisor=1024, total=5, smoothing=0) as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info('console logging redirected to `pbar.write()`')
                pbar.update(1)
    # logging restored

# Generated at 2022-06-24 09:57:31.720069
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    my_handler = _TqdmLoggingHandler()
    assert type(my_handler) is _TqdmLoggingHandler
    return True

# Generated at 2022-06-24 09:57:41.498257
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(filename='tqdm.log', level=logging.INFO)
        with tqdm_logging_redirect(total=10, tqdm_class=std_tqdm,
                                   loggers=[LOG]) as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        with open('tqdm.log', 'r') as f:
            assert f.readline() == 'INFO:__main__:console logging redirected to `tqdm.write()`\n'

# Generated at 2022-06-24 09:57:50.079106
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib import logging as tqdm_logging

    lgr = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[lgr], total=100) as pbar:
        for i in trange(4):
            pbar.update()
            if i == 2:
                lgr.info('should be printed in redirection with tqdm.write().')
        pbar.close()
        print('outside the redirect with pbar.close() of pbar')
    print('outside the redirect with tqdm.close() of pbar')



# Generated at 2022-06-24 09:57:53.505903
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger()
    with logging_redirect_tqdm([logger]):
        logging.info("Test Logging Redirect Tqdm")

# Generated at 2022-06-24 09:58:01.444314
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import io
    import logging
    from unittest import TestCase
    from .tests_tqdm import StringIO
    from .tests_tqdm import StringIOWrapper

    class FakeTqdm:
        _instances = []  # type: List[FakeTqdm]

        def __init__(self, file=None):
            # type: (Optional[StringIO]) -> None
            self._file = file
            self._instances.append(self)

        def write(self, msg, file=None):
            # type: (str, Optional[StringIO]) -> None
            if file is None:
                file = self._file
            file.write(msg)


# Generated at 2022-06-24 09:58:11.681219
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger()

    # Check that there's no initial logging
    logger_handlers_init = LOG.handlers[:]
    with tqdm_logging_redirect():
        pass
    assert LOG.handlers == logger_handlers_init

    # Check that logging is redirected
    for handler in logger_handlers_init:
        handler.flush()
    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        LOG.info('hello')
    LOG.handlers = logger_handlers_init
    for handler in logger_handlers_init:
        if not hasattr(handler, 'buffer'):
            raise ValueError('expected `handler.buffer` to be defined!')
        out = ''.join(handler.buffer)
    assert out == 'hello\n'
   

# Generated at 2022-06-24 09:58:21.991559
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.auto import trange
    from .my_tqdm import my_tqdm
    import logging
    import sys
    import re

    with trange(1, desc="Default") as pbar:
        with tqdm_logging_redirect(loggers=[logging.root]):
            pbar.write('test pbar write')
            logging.getLogger().info('test logging info')

    with my_tqdm(1, desc="My tqdm") as pbar:
        with tqdm_logging_redirect(loggers=[logging.root],
                                   tqdm_class=my_tqdm):
            pbar.write('test pbar write')
            logging.getLogger().info('test logging info')


# Generated at 2022-06-24 09:58:32.174749
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from tqdm.tests.tests_tqdm import discret_diff
    import logging
    import datetime
    try:
        from logging import LogRecord
    except ImportError:
        from logging import LogRecord as LogRecord

    f = StringIO()
    formatter = logging.Formatter('%(message)s')
    th = _TqdmLoggingHandler(file=f)
    th.setFormatter(formatter)
    logger = logging.getLogger(__name__)
    logger.addHandler(th)
    logger.setLevel(logging.DEBUG)
    date_time_obj = datetime.datetime.now()
    message = 'test'

# Generated at 2022-06-24 09:58:41.497946
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test for functions: tqdm_logging_redirect,
    logging_redirect_tqdm.
    """
    import logging
    LOG = logging.getLogger(__name__)

    def test_func():
        """Test function for tqdm_logging_redirect."""
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm
        with logging.basicConfig(level=logging.INFO):
            with logging_redirect_tqdm():
                for _ in trange(3):
                    LOG.info('logging_redirect_tqdm')

    assert test_func() is None

    def test_func2():
        """Test function for tqdm_logging_redirect."""

# Generated at 2022-06-24 09:58:46.435076
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    with tqdm_logging_redirect(
            loggers=[LOG], total=4
    ) as bar:
        for _ in bar:
            LOG.info("console logging redirected to `tqdm.write()`")