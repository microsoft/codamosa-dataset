

# Generated at 2022-06-24 09:48:54.716796
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    def test_stream(str_io):
        handler = _TqdmLoggingHandler()
        handler.stream = str_io

        handler.emit('TEST1')
        assert str_io.getvalue() == 'TEST1'
        handler.emit('TEST2')
        assert str_io.getvalue() == '\r                                                                               \rTEST1TEST2'

    from io import StringIO
    # Test with a unix like stream
    test_stream(StringIO())
    # Test with a Windows like stream
    test_stream(StringIO(u"\r"))


# Generated at 2022-06-24 09:49:00.222932
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.root]
    class Tqdm(std_tqdm):
        def write(self, s, file=None, end="\n"):
            super(Tqdm, self).write(s, file=file, end=end)
            self.total += 1
            self.refresh()
    with tqdm_logging_redirect(loggers=loggers, tqdm_class=Tqdm) as pbar:
        logging.info("logging redirected to `tqdm.write()`")
    assert pbar.total == 1

# Generated at 2022-06-24 09:49:01.398144
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    _TqdmLoggingHandler()


# Generated at 2022-06-24 09:49:04.625458
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import tqdm
    test_string = 'test message'

    logger = logging.getLogger(__name__)
    logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm)

    stream = io.StringIO()
    logging_handler.stream = stream
    logger.addHandler(logging_handler)
    logger.setLevel(logging.INFO)
    logger.info(test_string)
    logging_handler.close()

    assert test_string in stream.getvalue()

# Generated at 2022-06-24 09:49:08.472975
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in std_tqdm(range(9)):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    except KeyboardInterrupt:
        return  # logging restored

# Generated at 2022-06-24 09:49:19.206248
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Test _TqdmLoggingHandler.emit"""
    import io
    import unittest  # type: ignore
    from tqdm.contrib import logging as tqdm_logging
    from unittest import mock

    class TestEmit(unittest.TestCase):
        @mock.patch('tqdm.contrib.logging.std_tqdm')
        def test_emit_success(self, tqdm_mock):  # noqa pylint: disable=no-self-use
            # type: (mock.Mock) -> None
            stream = io.StringIO()

            handler = tqdm_logging._TqdmLoggingHandler(tqdm_class=tqdm_mock)
            handler.stream = stream
            handler

# Generated at 2022-06-24 09:49:22.688628
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        logging.info('XD')
        logging.debug('HMM?')
    logging.info('O_O')

# Generated at 2022-06-24 09:49:29.178639
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # This is a unit test for function logging_redirect_tqdm
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:49:34.503166
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    # pylint: disable=too-many-boolean-expressions
    assert (tqdm_handler.emit(logging.LogRecord("a", logging.DEBUG, "b", 1, "c",
                                                (), None))
            is None)



# Generated at 2022-06-24 09:49:40.692500
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..tqdm import trange
    from ..std import capture_output
    import logging
    import sys

    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger(__name__)

    old_stderr = sys.stderr

    with capture_output() as c, logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            sys.stderr.write("ERROR\n")

    stderr = c.get_stderr()

    import re
    assert re.search(r"\[.* INFO\] console logging redirected to `tqdm\.write\(\)`",
                     stderr, flags=re.MULTILINE)

# Generated at 2022-06-24 09:49:44.788429
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()

    assert isinstance(handler, logging.StreamHandler), \
        "Handler was not of type logging.StreamHandler"
    assert handler.stream == sys.stderr, \
        "Stderr should have been the default stream"


# Generated at 2022-06-24 09:49:49.827099
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(4):
                if i == 2:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:49:55.896972
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    original_handlers_list = [logging.root.handlers]
    original_handlers = logging.root.handlers
    try:
        tqdm_handler = _TqdmLoggingHandler(std_tqdm)
        logging.root.handlers = [
            handler for handler in logging.root.handlers if not _is_console_logging_handler(handler)] + [tqdm_handler]
    finally:
        logging.root.handlers = original_handlers

if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:50:03.203455
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Test _TqdmLoggingHandler.emit"""
    import io
    import time

    # Mocking tqdm
    class Mock_Tqdm():
        """Mock _TqdmLoggingHandler.emit"""
        def __init__(self):
            self.output = io.StringIO()

        def write(self, x, file=None):
            # pylint: disable=unused-argument
            self.output.write(x)

        def set_description_str(self, x, refresh=True):
            # pylint: disable=unused-argument
            # print("set_description_str {}".format(x))
            pass


# Generated at 2022-06-24 09:50:05.414395
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler is not None, "class can't be found"


# Generated at 2022-06-24 09:50:13.656784
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import std_tqdm

    with logging_redirect_tqdm():
        logging.info('stdout redirected to `tqdm.write()`')
        logging.error('stderr redirected to `tqdm.write()`')

    with logging_redirect_tqdm():
        with std_tqdm.external_write_mode():
            logging.info('stdout redirected to `tqdm.write()`')
            logging.error('stderr redirected to `tqdm.write()`')

    with logging_redirect_tqdm(tqdm_class=std_tqdm.tqdm):
        std_tqdm.write('this is a regular call to `tqdm.write()`')

# Generated at 2022-06-24 09:50:23.122161
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
        from tqdm import trange
        from tqdm import tqdm_notebook
    except ImportError:
        # tqdm not installed
        return
    import logging
    _logging_redirect_tqdm = logging_redirect_tqdm
    _tqdm_logging_redirect = tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)

    with _logging_redirect_tqdm():
        LOG = logging.getLogger(__name__)
        with trange(0, 5) as pbar:
            LOG.info(pbar)
        with trange(0, 5) as pbar:
            pass

# Generated at 2022-06-24 09:50:24.953690
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log_handler = _TqdmLoggingHandler()
    assert isinstance(log_handler, logging.StreamHandler)


# Generated at 2022-06-24 09:50:31.737262
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import pytest
    from tqdm.auto import tqdm
    out = io.BytesIO()
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.stream = out
    handler.emit(logging.LogRecord("foo", "INFO", None, None,
                                   "bar", None, None))
    out.seek(0)
    assert out.read() == "bar\n".encode("utf-8")
    with pytest.raises(Exception):
        handler.emit(logging.LogRecord("foo", "INFO", None, None, 1, None, None))



# Generated at 2022-06-24 09:50:32.769003
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # coverage helper
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:50:38.077454
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test for function logging_redirect_tqdm"""
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:50:48.174483
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    We test if tqdm_logging_redirect works:
    1. we create a logger.
    2. we test that the logger is *not* writing in our pre-defined tqdm
        class.
    3. we create our tqdm_logging_redirect class, which should take care of
        redirecting the logging output to our tqdm class.
    4. we test that the logger *is* writing in our pre-defined tqdm class.
    """
    import logging
    from tqdm import tqdm

    class Tqdm2(*args, **kwargs):  # type: ignore

        def __init__(self, *args, **kwargs):
            self.data = {'output': []}


# Generated at 2022-06-24 09:50:53.106380
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect.
    """
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    import warnings

    # pylint: disable=no-member
    LOG = logging.getLogger(__name__)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        with logging_redirect_tqdm() as pbar:
            pbar.update()
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

        assert len(w) == 0


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:51:02.554013
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with open("temp_file", 'a') as file:
        handler = _TqdmLoggingHandler(std_tqdm)
        handler.setFormatter(logging.Formatter("%(name)s - %(levelname)s - %(message)s"))
        handler.setLevel(logging.DEBUG)
        handler.stream = file
        logger = logging.getLogger("com.test")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
        logger.debug("debug message")
        logger.info("info message")
        logger.warn("warn message")
        logger.error("error message")
        logger.critical("critical message")
    file.close()
    import filecmp

# Generated at 2022-06-24 09:51:07.143808
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from ._tqdm_logging_common import _no_logging
    with _no_logging():
        logging.basicConfig()
        logging.getLogger().setLevel(logging.DEBUG)
        logging.debug('A debug message')
        handler = _TqdmLoggingHandler()
        assert isinstance(handler, logging.Handler)

# Generated at 2022-06-24 09:51:15.351009
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest import mock
    except ImportError:
        import mock

    from .tests_tqdm import pretest_posttest, _range
    from ..std import logging as std_logging

    # Define the test function
    def test_logging_redirected(logger):
        with logging_redirect_tqdm(loggers=[logger]):
            for i in _range(9):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")

    # Unit test
    with pretest_posttest():
        # Test that logging output gets redirected to the tqdm progress bar
        logger = std_logging.getLogger('test-logger')
        orig_handlers = logger.handlers

# Generated at 2022-06-24 09:51:17.250698
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(std_tqdm).tqdm_class == std_tqdm


# Generated at 2022-06-24 09:51:27.311337
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    for i in tqdm_logging_redirect(
            loggers=[logging.getLogger(__name__)],
            total=9,
            desc='dummy',
    ):
        if i == 3:
            # redirection
            logging.info('console logging redirected to `tqdm.write()`')
        elif i == 6:
            # console logging is not redirected
            logging.info('console logging is not redirected')
        pass
    # redirection is uninstalled

    tqdm(leave=False, total=9, desc='dummy').close()

# Generated at 2022-06-24 09:51:38.044723
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    # Create some log messages
    log = logging.getLogger('TestLog')
    log.setLevel(level=logging.INFO)
    log.info('This is the first log message.')

    # Redirect logger to tqdm
    with tqdm_logging_redirect(level=logging.INFO, desc='My progress') as pbar:
        log.info('This is the second log message.')
        pbar.update(1)
        log.info('This is the third log message.')
        pbar.update(1)
        log.info('This is the fourth log message.')
        pbar.update(1)
        log.info('This is the fifth log message.')
        pbar.update(1)

    # Test that we can

# Generated at 2022-06-24 09:51:44.450810
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    import tempfile

    test_file_name = tempfile.gettempdir() + "/test_logging_redirect_tqdm.txt"
    file_handler = logging.FileHandler(filename=test_file_name)
    # pylint: disable=protected-access
    assert sys._getframe(0).f_code.co_name in file_handler.baseFilename

    logger = logging.getLogger(__name__)
    logger.addHandler(file_handler)
    logger.setLevel(logging.INFO)

    with open(test_file_name, 'w') as f:
        f.write("Test logging_redirect_tqdm before use\n")


# Generated at 2022-06-24 09:51:48.577508
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from .tqdm import trange
    from .logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:51:52.703675
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import sys
    log = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[log]):
        for _ in tqdm(range(9)):
            if _ == 4:
                log.info("console logging redirected to `tqdm.write()`")
    for _ in tqdm(range(3)):
        sys.stdout.write('{}'.format(_))

# Generated at 2022-06-24 09:52:01.991271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Test logging functionality"""
    import logging
    from time import sleep
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def log_to_stdout():
        for i in trange(3):
            LOG.info("console logging redirected to `tqdm.write()`")
            sleep(1)
        LOG.info("logging restored")

    logging.basicConfig(stream=sys.stdout, level=logging.INFO)
    with logging_redirect_tqdm():
        log_to_stdout()

    print("")
    print("..-------------------------")
    print("..")
    test_logging_redirect_tqdm_context_loggername()
    print("..")
    test_logging_redirect_

# Generated at 2022-06-24 09:52:12.225211
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys

    from tqdm.contrib.logging import _TqdmLoggingHandler

    # Mock the `tqdm` namespace with the `logging` module
    old_tqdm = sys.modules['tqdm']
    sys.modules['tqdm'] = sys.modules['logging']  # type: ignore

    def mock_tqdm_write(msg, file=None):
        if file is sys.stdout:
            print("stdout: {}".format(msg))
        elif file is sys.stderr:
            print("stderr: {}".format(msg))

    sys.modules['tqdm'].write = mock_tqdm_write  # type: ignore

    # Test the `emit` method of a `_TqdmLoggingHandler` object

# Generated at 2022-06-24 09:52:17.605619
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
  # Write string to tqdm
  with std_tqdm.stdout_redirect_tqdm() as pbar:
      tqdm_handler = _TqdmLoggingHandler()
      tqdm_handler.emit('hello')

      # There is logging output
      assert(pbar.format_meter(pbar.last_print_n, pbar.n, pbar.sum_vals, pbar.avg_time))

# Generated at 2022-06-24 09:52:26.211493
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    # The following section is a test to verify functionality of
    # tqdm_logging_redirect
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    # Creating a logger object
    LOG = logging.getLogger(__name__)

    # Ensures that logging information from the root logger is not
    # redirected to stdout
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        datefmt='%m/%d/%Y %I:%M:%S %p')

    # Creates a tqdm object

# Generated at 2022-06-24 09:52:32.362900
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    for i in range(1, 10):
        logger.debug(i)
    # Restore original stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 09:52:36.050870
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}
    assert handler.level == logging.NOTSET
    assert handler.formatter is not None


# Generated at 2022-06-24 09:52:41.336438
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG], desc="foo") as pbar:
        LOG.info("bar")
        pbar.update()


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:51.340782
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    # logging to stdout by default
    logging.info("console logging by default")
    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")
        for _ in trange(9):
            LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    logging.info("console logging by default")

    # custom log file
    log_file = 'test_log.log'
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    fh = logging.File

# Generated at 2022-06-24 09:52:55.958207
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    return True

# Generated at 2022-06-24 09:53:00.651881
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .std import tqdm
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    assert handler.tqdm_class is tqdm


# Test logging_redirect_tqdm

# Generated at 2022-06-24 09:53:05.056655
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    TqdmHandler = _TqdmLoggingHandler()
    assert(isinstance(TqdmHandler, logging.StreamHandler))
    assert(TqdmHandler.stream == sys.stderr) #default stream is sys.stderr
    assert(TqdmHandler.tqdm_class == std_tqdm)

# Generated at 2022-06-24 09:53:15.183755
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import TestCase, main
    import logging
    import sys

    class TestEmit(_TqdmLoggingHandler):
        def __init__(self, tqdm_class=None):
            super(TestEmit, self).__init__(tqdm_class=tqdm_class)
            self.messages = []
            self.flushes = []

        def write(self, msg, file=sys.stdout):
            self.messages.append(msg)

        def flush(self):
            self.flushes.append(None)

    class _Test(TestCase):
        def setUp(self):
            self.logger = logging.getLogger("test")
            self.handler = TestEmit()
            self.logger.addHandler(self.handler)


# Generated at 2022-06-24 09:53:19.898828
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    tlh_2 = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tlh.stream is tlh_2.stream, 'Stream is not set as sys.stderr'



# Generated at 2022-06-24 09:53:24.429163
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    f = lambda: None  # noqa pylint: disable=unnecessary-lambda
    o = _TqdmLoggingHandler()
    o.stream = f
    o.format = lambda: ''
    o.flush = lambda: None
    o.handleError = lambda: None
    o.emit(object())

# Generated at 2022-06-24 09:53:26.593310
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        assert pbar.total == 10

# Generated at 2022-06-24 09:53:27.600897
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:53:33.852394
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Tests _TqdmLoggingHandler's constructor."""
    from ..std import tqdm as std_tqdm
    std_tqdm.write = lambda line: None
    std_tqdm.flush = lambda line: None
    _TqdmLoggingHandler()
    std_tqdm.write = std_tqdm.std_write
    std_tqdm.flush = std_tqdm.std_flush


# Generated at 2022-06-24 09:53:39.294734
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger(__name__)]
    with tqdm_logging_redirect(
            loggers=loggers, bar_format='{l_bar}', total=1,
            desc='tqdm_logging_redirect', disable=False):
        logging.info('tqdm_logging_redirect')

# Generated at 2022-06-24 09:53:48.603951
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import unittest

    # Hide stdout when running unit test
    output = io.StringIO()

    logging.basicConfig(level=logging.INFO, stream=output)

    class SimpleTqdm(object):
        def __init__(self, file=sys.stdout):
            self.file = file
            self.output = ""

        def write(self, msg, file=None):
            # save the message in the output
            self.output += msg

    handler = _TqdmLoggingHandler(tqdm_class=SimpleTqdm)
    log = logging.getLogger("test")
    log.addHandler(handler)

    # create a logging record

# Generated at 2022-06-24 09:54:01.128094
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import contextlib
    from .std import tqdm as std_tqdm

    class UselessTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            kwargs.update(miniters=0)
            super(UselessTqdm, self).__init__(*args, **kwargs)

        @contextlib.contextmanager
        def disabled(*args, **kwargs):
            yield

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with tqdm_logging_redirect(tqdm_class=UselessTqdm) as pbar:
        assert pbar is not None

test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:54:02.917877
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm.test
    tqdm.test._test()  # nosec
    tqdm.test._test_logging()  # nosec

# Generated at 2022-06-24 09:54:15.322076
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import tempfile

    logfile = os.path.join(tempfile.gettempdir(), 'log_redirect_test.log')

    # Test stdout
    with logging_redirect_tqdm(loggers=[logging.root]):
        logging.info('tqdm stdout log test')
    # Test file handler
    with open(logfile, 'w') as f, logging.root.handlers[0].stream as s:
        logging.root.handlers[0].stream = f
        with logging_redirect_tqdm(loggers=[logging.root]):
            logging.info('tqdm file log test')
        logging.root.handlers[0].stream = s


# Generated at 2022-06-24 09:54:19.466140
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect('test logging_redirect_tqdm', unit='B', leave=False) as pbar:
        assert pbar is not None
        LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:54:25.090003
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10, smoothing=0,file=sys.stderr) as pbar:
        for i in range(10):
            logging.warn("hello")
            pbar.update(1)
    assert pbar.n == 10
    assert pbar.smoothing == 0


__all__ = ['logging_redirect_tqdm', 'tqdm_logging_redirect']

# Generated at 2022-06-24 09:54:36.381912
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    dummy_format = '[{levelname}] : {msg}'
    tlh.setFormatter(logging.Formatter(dummy_format))

    class FakeStream(object):

        def __init__(self):
            self.written = ''

        def write(self, s):
            self.written += s

        def flush(self):
            pass

    tlh.stream = FakeStream()

    # type is INFO
    record = logging.LogRecord('name', logging.INFO, 'pathname', 1,
                               'msg', {}, None)
    tlh.emit(record)
    assert tlh.stream.written == '[INFO] : msg\n'

    # type is ERROR

# Generated at 2022-06-24 09:54:45.258148
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import pretest_posttest  # pylint: disable=import-outside-toplevel

    def test_logging_tqdm_context_manager():
        logging.root.handlers = []
        with logging_redirect_tqdm():
            logging.info('hello')
        assert logging.root.handlers == []

    def test_logging_tqdm_context_manager_loggers():
        logger = logging.getLogger('test_loggers')
        logging.root.handlers = []
        logger.handlers = []
        with logging_redirect_tqdm(loggers=[logger]):
            logging.info('hello')
            logger.info('hello')

        assert logging.root.handlers == []
        assert logger.handlers == []


# Generated at 2022-06-24 09:54:56.141839
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import sys
    import logging
    from _pytest.outcomes import Failed
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    buf = io.StringIO()
    logging.basicConfig(stream=buf, level=logging.INFO)
    try:
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        if "redirected to `tqdm.write()`" not in buf.getvalue():
            raise Failed('error')
    except (KeyboardInterrupt, SystemExit):
        raise

# Generated at 2022-06-24 09:55:04.062992
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if not __name__ == '__main__':
        assert True
        return
    import logging
    import time

    def test():
        """
        Test logging redirection

        With loggers=None, this should redirect the root logger
        """
        for i in range(5):
            print("[test %i]" % i, end=" ")
            logging.info("hi from logging")
            logging.getLogger().info("hi from root logger")
        print()

    with tqdm_logging_redirect(desc="tqdm with logging",
                               logging_format="%(message)s", leave=False) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()
        test()

    test()

# Generated at 2022-06-24 09:55:08.928172
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for `logging_redirect_tqdm` function.
    """
    import logging
    from tqdm import trange

    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:18.648289
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import subprocess
    import tempfile


# Generated at 2022-06-24 09:55:20.627809
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm)


# Generated at 2022-06-24 09:55:25.129490
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Test if _TqdmLoggingHandler construct successfully
    """
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, _TqdmLoggingHandler)
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-24 09:55:26.937793
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    #type: () -> None
    handler = _TqdmLoggingHandler()
    handler.emit(logging.LogRecord('name', 'DEBUG', '/path', 1, 'message', None, None))

# Generated at 2022-06-24 09:55:30.596327
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert callable(handler.emit)
    assert callable(handler.flush)


# Generated at 2022-06-24 09:55:38.737405
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging

    log_stream = io.StringIO()  # type: ignore
    log_handler = _TqdmLoggingHandler()

    log_handler.setLevel(logging.INFO)
    log_handler.setFormatter(logging.Formatter("%(message)s"))
    log_handler.stream = log_stream

    log_record = logging.Logger.makeRecord(
        name='example.logger',
        level=logging.INFO,
        pathname='/example/full/path/to/file.py',
        lineno=8,
        msg='logging redirected to tqdm',
        args=(),
        exc_info=None
    )

    log_handler.emit(log_record)


# Generated at 2022-06-24 09:55:46.508129
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    import io
    s = io.StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=tqdm.tqdm)
    handler.setLevel(100)
    handler.setFormatter(logging.Formatter("%(message)s"))
    handler.stream = s
    logging.basicConfig(level=0)
    logger = logging.getLogger("tqdm")
    logger.addHandler(handler)

    # Test for emit message
    logger.critical("A simple test for tqdm")
    assert s.getvalue() == "\rA simple test for tqdm"

# Generated at 2022-06-24 09:55:55.281057
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import mock
    import sys
    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler
    with mock.patch.object(_TqdmLoggingHandler, 'write', return_value=None) as m:
        tqdm_handler = _TqdmLoggingHandler(std_tqdm)
        orig_handler = logging.StreamHandler
        orig_handler.setFormatter = mock.Mock()
        orig_handler.stream = sys.stdout
        tqdm_handler.emit(orig_handler)
        assert m.called

# Generated at 2022-06-24 09:56:01.059066
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log_format = "%(asctime)s %(levelname)-8s %(message)s"
    datefmt = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=log_format, datefmt=datefmt, level=logging.DEBUG)
    handler = _TqdmLoggingHandler()
    logging.getLogger().addHandler(handler)
    logging.info('Hello, World!')
    assert handler.stream.getvalue() == 'Hello, World!\n'

# Generated at 2022-06-24 09:56:06.027733
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:56:11.597256
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:56:20.558673
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from tqdm.contrib.logging import _TqdmLoggingHandler

    console_out = BytesIO()

    logger = logging.getLogger(__name__)
    logger.setLevel('INFO')

    log_console_handler = _TqdmLoggingHandler()
    log_console_handler.setFormatter(
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s')
    )
    log_console_handler.stream = console_out

    logger.addHandler(log_console_handler)

    logger.info("This is a test")
    print("This is a print test")
    logger.error("This is an error test")

# Generated at 2022-06-24 09:56:26.233843
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9), desc='redirected logging'):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:56:32.755463
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    def main():
        # Initialize logging, set logger level and output format
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)-15s %(message)s')

        # Get the root logger
        logger = logging.getLogger()
        with tqdm_logging_redirect(loggers=[logger], total=3) as pbar:
            for _ in range(3):
                logger.info("Hello world")
                pbar.update()

    main()

# Generated at 2022-06-24 09:56:35.977708
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert h.stream in [sys.stdout, sys.stderr]
    assert isinstance(h.formatter, logging.Formatter)
    assert h.tqdm_class == std_tqdm

# Generated at 2022-06-24 09:56:40.882507
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    logger = logging.getLogger("test")
    logger.setLevel(logging.INFO)
    handler_stream = io.StringIO()
    handler = _TqdmLoggingHandler(handler_stream)
    logger.addHandler(handler)
    logger.info("test")
    assert handler_stream.getvalue() == "test\n"
    logger.removeHandler(handler)

# Generated at 2022-06-24 09:56:49.800210
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    #Need to be run from the real tqdm
    from tqdm import tqdm, tnrange
    from tqdm.contrib.logging import _TqdmLoggingHandler

    from logging import StreamHandler, StreamHandler, StreamHandler
    from time import sleep
    import sys
    import logging

    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())

    logger.info("Test of info")
    logger.warning("Test of warning")
    logger.error("Test of error")
    logger.critical("Test of critical")

    with tqdm(total=100) as pbar:
        while pbar.n < pbar.total:
            try:
                sleep(.1)
            except (KeyboardInterrupt, SystemExit):
                break

            pbar

# Generated at 2022-06-24 09:56:52.708767
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.tests import _test_logging_redirect_tqdm
    with _test_logging_redirect_tqdm(logging_redirect_tqdm):
        pass



# Generated at 2022-06-24 09:57:04.159631
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm

    LOG = logging.getLogger(__name__)

    def _test_logging_redirect_tqdm(
        loggers  # type: List[logging.Logger]
    ):
        # type: (...) -> None
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm):
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    _test_logging_redirect_tqdm([logging.root])
    _test_logging_redirect_tqdm([logging.getLogger("TqdmLoggingHandler")])
    _test_log

# Generated at 2022-06-24 09:57:08.668570
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    sio = io.StringIO()
    logger_handler = logging.StreamHandler(sio)
    logger.addHandler(logger_handler)

    tqdm_logger_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logger_handler)

    logger.info('hello')
    assert sio.getvalue() == 'hello\n'

# Generated at 2022-06-24 09:57:14.404547
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    handler = _TqdmLoggingHandler(MagicMock())
    handler.emit(logging.LogRecord('name', 'info', __name__,
                                   0, 'foo', None, 'func'))

# Generated at 2022-06-24 09:57:20.749256
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Check if the emit method of class _TqdmLoggingHandler works as expected.
    """
    import tqdm

    test_str = 'test'
    stream = tqdm.tqdm(range(5))
    _test_logging_handler = _TqdmLoggingHandler()
    _test_logging_handler.stream = stream
    _test_logging_handler.emit(test_str)
    assert test_str in stream.write.call_args[0][0]

# Generated at 2022-06-24 09:57:23.103095
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        logger.info("console logging redirected to `tqdm.write()`")