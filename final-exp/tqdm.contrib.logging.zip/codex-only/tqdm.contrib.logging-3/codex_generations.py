

# Generated at 2022-06-24 09:48:54.263302
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    tqdm_handler = _TqdmLoggingHandler()

    assert(tqdm_handler.stream == sys.stderr)
    assert(tqdm_handler.tqdm_class == std_tqdm)

# Generated at 2022-06-24 09:48:56.036883
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_handler.tqdm_class is std_tqdm



# Generated at 2022-06-24 09:49:00.746625
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:49:09.329806
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from .test_main import closing  # pylint: disable=unused-import
    out = sys.stdout
    sys.stdout = StringIO()
    stream = sys.stdout
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log_handler = _TqdmLoggingHandler()
    log_handler.setFormatter(logging.Formatter(fmt='%(asctime)s: %(message)s'))
    log_handler.stream = stream
    log.addHandler(log_handler)
    log.info('test_emit')
    log_handler.flush()
    out.write(stream.getvalue())
    assert stream.getvalue() == 'test_emit\n'
    sys.std

# Generated at 2022-06-24 09:49:14.082720
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    try:
        import numpy as np
    except:
        return
    with tqdm_logging_redirect():
        for i in np.arange(9):
            logging.info("console logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:49:20.174756
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import StringIO
    import logging
    import sys
    sys.stdout = StringIO()

    # Check if we can write to tqdm.std.tqdm
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.handlers = [handler]
    logger.info('TEST')
    assert('TEST\n' == sys.stdout.getvalue())

# Generated at 2022-06-24 09:49:21.947793
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect():
        logging.info("message")

# Generated at 2022-06-24 09:49:23.497948
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        handler = _TqdmLoggingHandler()
    except:
        assert False
    assert handler

# Generated at 2022-06-24 09:49:34.099237
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    def noop():
        pass

    def throw():
        # type: () -> None
        raise ValueError()

    class MockTqdm:
        @staticmethod
        def write(msg, file):
            # type: (str, int) -> None
            pass  # noqa

    pbar = MockTqdm()
    record = logging.LogRecord(
        "name", logging.ERROR, "pathname", 0,
        "msg", (), None)

    h = _TqdmLoggingHandler(tqdm_class=pbar)
    h.emit(record)

    h.handleError = noop
    h.flush = noop
    h.emit(record)

    h.tqdm_class.write = throw
    h.emit(record)

# Generated at 2022-06-24 09:49:45.209087
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    '''Unit test for method emit of class _TqdmLoggingHandler'''
    class AssertStream(object):
        def __init__(self):
            self.content = ''

        def write(self, output):
            self.content = output.strip()

        def flush(self):
            pass

    class DummyTQDMClass(object):
        @staticmethod
        def write(output, file=None):
            pass

    output_stream = AssertStream()
    dummy_handler = _TqdmLoggingHandler(DummyTQDMClass)
    dummy_handler.stream = output_stream
    dummy_handler.setFormatter(logging.Formatter())

# Generated at 2022-06-24 09:49:54.735009
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logger = logging.getLogger(__name__)

    def run(msg1, msg2, msg3):
        log_list = [msg1, msg2, msg3]

        logger.info(log_list[0])
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logger.info(log_list[1])
        logger.info(log_list[2])

    std_tqdm_msgs = []

    class MockTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            pass

        @classmethod
        def write(cls, msg):
            std_tqdm_msgs.append(msg)
            return

# Generated at 2022-06-24 09:49:57.981133
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger('foo')]
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        logging.getLogger('foo').warn('bar')
        assert pbar.n == 1

# Generated at 2022-06-24 09:50:03.572450
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test the emit method of _TqdmLoggingHandler, which is in charge of
    the proper redirection of the logging module to the tqdm module
    """
    logging.basicConfig(level=logging.INFO)
    pbar = std_tqdm(total=1, desc='Test tqdm')
    logger = logging.getLogger(__name__)
    test_message = 'This is a test message for tqdm'

    handler = _TqdmLoggingHandler(tqdm_class=pbar)
    logger.handlers = [handler]
    logger.info(test_message)
    pbar.close()



# Generated at 2022-06-24 09:50:10.274394
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import tqdm
    except ImportError as e:
        e.args = ('tqdm not installed', )
        raise
    import logging
    import sys

    logger = logging.getLogger(__name__)

    with tqdm.std.capture_output() as captured:
        with _TqdmLoggingHandler(tqdm_class=tqdm.tqdm) as h:
            logger.setLevel(logging.INFO)
            logger.addHandler(h)
            logger.info('test')
    assert b'test' in captured.stdout, 'test with tqdm.tqdm'
    captured.stdout = ''


# Generated at 2022-06-24 09:50:11.107218
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:50:16.728872
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from tqdm import tqdm
    except ImportError:
        from tqdm import std as tqdm

    try:
        from tqdm import trange
        is_ipython = True
    except ImportError:
        is_ipython = False

    # Test on uninteractive mode
    class StdLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super(StdLogger, self).__init__(*args, **kwargs)
            stdout = sys.stdout  # type: ignore
            if hasattr(stdout, 'buffer'):
                # Python 3
                stdout = stdout.buffer
            self.stdout = stdout
            self.stdout_fileno = stdout.fileno()


# Generated at 2022-06-24 09:50:20.253324
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None

    # ensure that the method emit raises no exception if called on an instance of _TqdmLoggingHandler
    _TqdmLoggingHandler().emit(logging.LogRecord('', logging.DEBUG, '', 1, '', None, None))



# Generated at 2022-06-24 09:50:28.869093
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from tqdm import tqdm as std_tqdm
    from tqdm.contrib import _TqdmLoggingHandler
    # Create a logger
    logger = logging.getLogger('test_TqdmLoggingHandler')
    logger.setLevel(logging.DEBUG)
    # Create handlers
    # Add handler to logger
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logger.addHandler(handler)
    # create formatter
    formatter = logging.Formatter(
                '[%(asctime)s] {%(filename)s:%(lineno)d} %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.debug('test')

# Generated at 2022-06-24 09:50:32.303978
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    log.addHandler(tqdm_handler)
    log.info('My log', 'is', 'multiline')
    log.removeHandler(tqdm_handler)


# Generated at 2022-06-24 09:50:40.086412
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import warnings
    from . import tqdm
    try:
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore

    with patch('tqdm._tqdm.std.sys.stderr', new=None):
        warnings.warn("No sys.stderr: logging redirect test skipped")
        return

    # Example of usage of `logging_redirect_tqdm`:
    import logging
    logging.basicConfig(level=logging.WARNING)
    log = logging.getLogger('A.B.C')
    with tqdm.logging_redirect_tqdm(log) as pbar:
        log.warning("Test warning message")
        pbar.update(100)

# Generated at 2022-06-24 09:50:45.028209
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
    # logging restored
    assert LOG.handlers == [], 'logger was not restored properly'

# Generated at 2022-06-24 09:50:48.337534
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Test tqdm_logging_redirect function.
    """
    import logging
    with std_tqdm as pbar:
        with logging_redirect_tqdm() as pbar:
            pass

# Generated at 2022-06-24 09:50:57.264502
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TqdmTester(std_tqdm):
        @classmethod
        def write(cls, *args):
            pass

    handler = _TqdmLoggingHandler(tqdm_class=TqdmTester)

    def try_emit(level, msg):
        record = logging.makeLogRecord({'levelname': level, 'msg': msg})
        handler.emit(record)

    try_emit('WARNING', 'WARNING MESSAGE')
    try_emit('ERROR', 'ERROR MESSAGE')
    try_emit('CRITICAL', 'CRITICAL MESSAGE')
    try_emit('DEBUG', 'DEBUG MESSAGE')



# Generated at 2022-06-24 09:51:01.446261
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler
    """
    test_handler = _TqdmLoggingHandler()
    assert isinstance(test_handler.tqdm_class, type)
    assert issubclass(test_handler, logging.StreamHandler)
    assert test_handler.tqdm_class == logging.tqdm

# Generated at 2022-06-24 09:51:04.174388
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.emit('Foo msg')
    assert sys.stdout.getvalue() == 'Foo msg\n'
    sys.stdout.close()
    sys.stdout = sys.__stdout__


# Generated at 2022-06-24 09:51:13.591500
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    from ..std import tqdm

    class FakeTqdm(object):
        ''' Fake TQDM object just so we can test the method. '''
        class _instances(object):  # pylint: disable=invalid-name
            @staticmethod
            def clear_instances(some_obj):
                # pylint: disable=unused-argument
                pass

        def __init__(self):
            self.write_called = False
        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 09:51:21.712818
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    def main_1():
        """failed without stdout buffer before stderr"""
        with logging_redirect_tqdm():
            logging.info("info")
            for i in trange(4):
                logging.info("info " + str(i))
            for i in trange(4):
                logging.error("error " + str(i))

    def main_2():
        """failed without stdout buffer after stderr"""
        with logging_redirect_tqdm():
            logging.info("info")
            for i in trange(4):
                logging.error("error " + str(i))
            for i in trange(4):
                logging.info("info " + str(i))


# Generated at 2022-06-24 09:51:30.652889
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange, tqdm

    logger = logging.getLogger(__name__)
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

    logging.basicConfig(level=logging.DEBUG)

    if not hasattr(logger, 'manager'):
        class Manager(object):
            def __init__(self):
                self.loggerDict = {name: logger}
        logger.manager = Manager()


# Generated at 2022-06-24 09:51:34.490305
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Unit test for constructor of class _TqdmLoggingHandler"""
    import tqdm

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)

# Generated at 2022-06-24 09:51:40.872217
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    with logging_redirect_tqdm(loggers=[logging.getLogger(__name__)]):
        logging.info('%s', 'TEST')
        for i in tqdm(range(9)):
            if i == 4:
                logging.info('%s', 'TEST')
    logging.info('%s', 'TEST')

# Generated at 2022-06-24 09:51:45.675559
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import TestCase
    import logging

    class TqdmLoggingHandlerTest(TestCase):
        def assert_log(self, msg='', level='INFO', assert_raise=False):
            # type: (str, str, bool) -> None
            try:
                logger = logging.getLogger()
                logger.handlers = []
                handler = _TqdmLoggingHandler()
                logger.addHandler(handler)
                for _level in [logging.DEBUG, logging.INFO, logging.WARNING]:
                    if level == logging.getLevelName(_level):
                        logger.log(_level, msg)
                self.assertEqual(msg, handler.stream.getvalue())
            except AssertionError:
                if assert_raise:
                    raise

        def test_emit(self):
            self.assert_

# Generated at 2022-06-24 09:51:56.909279
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import pytest
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    LOG.info("A logging message")

    with tqdm_logging_redirect(
        desc='Redirecting logging to tqdm.write()',
        total=3,
        loggers=[LOG]) as pbar:
        LOG.info("Another logging message")
        pbar.update()
        LOG.info("A third logging message")
        pbar.update()


# Generated at 2022-06-24 09:52:03.550784
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm.auto import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    
    loggers = [logging.getLogger('tqdm_logging_redirect')]
    with tqdm_logging_redirect(
        tqdm(range(10), ascii=True),
        loggers=loggers,
    ):
        logging.debug('Debug message')
        logging.info('Info message')
        logging.warning('Warning message')
        logging.error('Error message')
        logging.critical('Critical message')
        time.sleep(1)

# Generated at 2022-06-24 09:52:12.974773
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    import io
    import tqdm
    from contextlib import redirect_stdout

    LOG = logging.getLogger(__name__)

    # simulate StreamHandler
    out = io.StringIO()

    try:
        with redirect_stdout(out):
            with logging_redirect_tqdm(tqdm_class=tqdm.tqdm):
                for i in range(9):
                    if i == 4:
                        LOG.info('This should be redirected to tqdm.write().')
            assert 'This should be redirected to tqdm.write().' in out.getvalue()
    except:  # noqa pylint: disable=bare-except
        assert False, "logging_redirect_tqdm unit test failed"

# Generated at 2022-06-24 09:52:22.218478
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import unittest
    import io
    import logging

    class Test(unittest.TestCase):
        def setUp(self):
            self.logname = 'test'
            self.logger = logging.getLogger(self.logname)
            self.logger.setLevel(logging.INFO)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(stream=self.stream)
            self.handler.setFormatter(logging.Formatter('%(message)s'))
            self.logger.addHandler(self.handler)

        def test_tqdm_logging_redirect(self):
            from tqdm import tqdm

            self.logger.info('1')

# Generated at 2022-06-24 09:52:23.345782
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-24 09:52:33.398130
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test"""
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    with logging_redirect_tqdm():
        logging.info('Hello World!')

    with logging_redirect_tqdm(loggers=[logging.getLogger()]):
        logging.info('Hello World!')

    logger = logging.getLogger()
    orig_handlers = logger.handlers
    logger.handlers = [
        Mock(stream=sys.stdout),
        Mock(stream=None),
        Mock(stream=sys.stderr),
        Mock(stream=sys.stdout)
    ]
    with logging_redirect_tqdm(loggers=[logger]):
        logging.info('Hello World!')

# Generated at 2022-06-24 09:52:34.508418
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # TODO: write unit test
    pass

# Generated at 2022-06-24 09:52:43.313397
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import logging
    import sys
    import unittest

    class _Test_TqdmLoggingHandler(unittest.TestCase):
        def setUp(self):
            sys.stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = sys.__stdout__  # type: ignore


# Generated at 2022-06-24 09:52:51.928343
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import trange
    from .isatty import isatty

    # Set up logger
    LOG = logging.getLogger(__name__)
    LOG.handlers = []
    LOG.setLevel(logging.DEBUG)
    LOG_FILE = 'logging_redirect_tqdm.log'
    file_handler = logging.FileHandler(LOG_FILE, mode='w')
    file_handler.setLevel(logging.INFO)
    msg_format = logging.Formatter('%(asctime)s (%(levelname)s) %(message)s')
    file_handler.setFormatter(msg_format)
    LOG.addHandler(file_handler)

    # Run test

# Generated at 2022-06-24 09:53:03.477706
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())
    with tqdm_logging_redirect(level=logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        try:
            raise RuntimeError("raised")
        except RuntimeError:
            logger.exception("exception")
        sys.stdout.write("stdout")
    logger.removeHandler(logging.NullHandler())

# Generated at 2022-06-24 09:53:08.184306
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:53:14.025378
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from logging import (
        CRITICAL,
        DEBUG,
        ERROR,
        INFO,
        NOTSET,
        WARN,
        WARNING
    )
    from logging import LogRecord
    from sys import exc_info

    LEVELS = dict(
        CRITICAL='CRITICAL',
        DEBUG='DEBUG',
        ERROR='ERROR',
        INFO='INFO',
        NOTSET='NOTSET',
        WARN='WARNING',
        WARNING='WARNING')

    NullHandler = logging.NullHandler  # pylint: disable=invalid-name
    tqdm = std_tqdm  # pylint: disable=invalid-name

    # Create fake logger
    logger = logging.Logger('FakeLogger', NOTSET)
    logger.addHandler(NullHandler())

    # Create fake stream


# Generated at 2022-06-24 09:53:18.191665
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10) as pbar:
        logging.info('info message')
    assert pbar.n == 10
    assert pbar.refresh_lock.locked()

# Generated at 2022-06-24 09:53:24.842489
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    try:
        import unittest2 as unittest  # type: ignore
    except ImportError:
        import unittest
    try:
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    stdout_str = []

    class TqdmMock(std_tqdm):
        def __init__(
            self, *args,
            file=sys.stdout,
            **kwargs
        ):
            self.file = file
            self.file_str = stdout_str

# Generated at 2022-06-24 09:53:29.763112
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io

    stream = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler(stream=stream)

    tqdm_handler.emit('hello')
    stream.seek(0)

    result = stream.read()
    assert result == 'hello\n'

# Generated at 2022-06-24 09:53:32.219312
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log = logging.getLogger('test_log')
    log.addHandler(logging.StreamHandler())
    log.addHandler(_TqdmLoggingHandler())
    log.warning('hello world')
    log.warning('hello world')

# Generated at 2022-06-24 09:53:43.156732
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import gc
    import io
    import logging
    import re
    import unittest

    class TqdmTester(std_tqdm):
        """Tqdm tester class. Inherits from tqdm.std.tqdm.

        This class can be used to test the logging functionality
        by replacing the `write()` method of the stdlib tqdm
        implementation with a version that intercepts calls
        and records the arguments. It can then detect
        if its `write()` method has been called directly
        from tqdm or from the _TqdmLoggingHandler
        and thereby test the functionality of the logging functionality.
        """


# Generated at 2022-06-24 09:53:50.915353
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    # Test that no exceptions are raised
    record = logging.LogRecord(name="name",
                               level=logging.INFO,
                               pathname='pathname',
                               lineno=100,
                               msg='msg',
                               args=(),
                               exc_info=None)
    handler.emit(record)
    # Test that KeyboardInterrupt is passed through
    try:
        handler.emit(KeyboardInterrupt())
        assert False, "KeyboardInterrupt was not raised"
    except KeyboardInterrupt:
        pass
    # Test that SystemExit is passed through
    try:
        handler.emit(SystemExit())
        assert False, "SystemExit was not raised"
    except SystemExit:
        pass
    # Test that another exception type is passed through


# Generated at 2022-06-24 09:53:54.530079
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    my_handler = _TqdmLoggingHandler()
    assert my_handler.tqdm_class == std_tqdm

# Generated at 2022-06-24 09:54:04.241704
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _SubclassOfStdTqdm(std_tqdm):  # noqa pylint: disable=no-member
        @staticmethod
        def write(message, file):
            """
            Mock function of std_tqdm write for testing
            """
            file.write(message)

    custom_tqdm = _SubclassOfStdTqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=custom_tqdm)
    import io
    import tempfile
    output_file = tempfile.NamedTemporaryFile(mode='w')
    tqdm_handler.stream = output_file
    tqdm_handler.emit('msg')
    output_file.seek(io.SEEK_SET,0)

# Generated at 2022-06-24 09:54:08.111602
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert_report = _TqdmLoggingHandler().emit(record=None)
    assert_report

# Generated at 2022-06-24 09:54:11.593345
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm.write('test__TqdmLoggingHandler')


__all__ = ['logging_redirect_tqdm', 'tqdm_logging_redirect']
if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:54:14.842624
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        with tqdm_logging_redirect(total=9) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:23.842895
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import StringIO
    from tqdm import tqdm

    val = 'value'
    with StringIO() as io:
        io_orig = io
        tqdm_inst = tqdm(file=io)
        tqdm_handle = _TqdmLoggingHandler(tqdm_class=tqdm)
        tqdm_handle.stream = io
        tqdm_handle.emit(logging.LogRecord(
            name="name",
            levels=logging.INFO,
            pathname="path",
            lineno=0,
            msg=val,
            args=None,
            exc_info=None,
        ))
        assert io_orig.getvalue() == val + '\n'

# Generated at 2022-06-24 09:54:28.881044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Setup a logger
    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger(__name__)
    LOG.info("Test logging")

    # Redirect test
    with logging_redirect_tqdm():
        LOG.debug('debug message')
        LOG.info('info message')
        LOG.warning('warning message')
        LOG.error('error message')
        LOG.critical('critical message')

    # Teardown

    # Cleanup logging configuration
    logging.shutdown()



# Generated at 2022-06-24 09:54:33.462428
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    #logger = logging.getLogger("test_logging")
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.stream == sys.stderr
    #logger.addHandler(tqdm_handler)
    #assert logger.handlers[-1] == tqdm_handler



# Generated at 2022-06-24 09:54:42.560037
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .misc import captured_output
    import logging
    from .misc import ensure_repeat_fixture_is_calling
    ensure_repeat_fixture_is_calling(__file__)

    LOG = logging.getLogger(__name__)

    def _test():
        with captured_output() as (out, _):
            logging.basicConfig(level=logging.DEBUG)
            with logging_redirect_tqdm():
                LOG.warning("warning")
                LOG.info("info")
                LOG.debug("debug")
            logging.debug("debug")
            logging.info("info")
            logging.warning("warning")
        assert out.getvalue() == 'warning\ninfo\n'

    _test()
    std_tqdm.stdout = sys.stderr
    _test()

# Generated at 2022-06-24 09:54:46.100166
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_msg = 'Test Message'

    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(level='DEBUG', msg=test_msg, args=None, exc_info=None)
    tqdm_handler.emit(record)

    assert sys.stdout.getvalue().strip() == test_msg

# Generated at 2022-06-24 09:54:57.506762
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from . import std as _std
    from .tqdm import tqdm as _tqdm
    
    tqdm_logging_handler = _TqdmLoggingHandler(_std.tqdm)
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)
    assert tqdm_logging_handler.tqdm_class == _std.tqdm

    tqdm_logging_handler = _TqdmLoggingHandler(_tqdm)
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)
    assert tqdm_logging_handler.tqdm_class == _tqdm

    # error will be raised if tqdm_class is not an instance of tqdm.std.tqdm

# Generated at 2022-06-24 09:55:04.938112
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tempfile
    import unittest

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.message = "sample message"
            self.out_f = tempfile.TemporaryFile()

        def test_emit(self):
            _TqdmLoggingHandler(_tqdm_class=MockTqdmClass)\
                ._emit(self.message, self.out_f)
            self.out_f.flush()
            self.out_f.seek(0)
            self.assertEqual(self.message, self.out_f.read().decode())

    class MockTqdmClass:
        write = staticmethod(logging.StreamHandler.write)

    unittest.main()

# Generated at 2022-06-24 09:55:11.974063
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        LOG.info("logging info 1")
        with tqdm_logging_redirect():
            LOG.info("logging info 2")
        LOG.info("logging info 3")

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:55:16.614551
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:55:27.542575
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from .logging import tqdm_logging_redirect
    from .main import tqdm
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc="Test logging redirect"):
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    assert(tqdm.write.buf == "Test logging redirect: 100%|██████████| 9/9 [00:00<00:00, 2196.63it/s]\n")

# Generated at 2022-06-24 09:55:30.596374
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-24 09:55:38.737307
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import std, trange

    logging.basicConfig(level=logging.INFO)

    # default: stdout
    with std.capture_output() as captured:
        with logging_redirect_tqdm():
            logging.info("redirected to tqdm")
    assert (
        captured.getvalue()
        ==
        "redirected to tqdm\n"
        )

    # default: sys.stderr
    with std.capture_output(stdout=True) as captured:
        with logging_redirect_tqdm():
            logging.error("redirected to tqdm")

    assert (
        captured.getvalue()
        ==
        "redirected to tqdm\n"
        )

    # manual

# Generated at 2022-06-24 09:55:40.005837
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    _TqdmLoggingHandler().emit(logging.LogRecord('', '', '', 0, "[FAIL]", (), '', '', '',))

# Generated at 2022-06-24 09:55:46.748193
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import StreamHandler, DEBUG

    msg = "test__TqdmLoggingHandler_emit"
    log = logging.getLogger(__name__)
    stream = StringIO()
    handler = _TqdmLoggingHandler()
    log.addHandler(handler)

    for handler in log.handlers:
        handler.setFormatter(logging.Formatter(logging.BASIC_FORMAT))
        handler.stream = stream
    log.log(DEBUG, msg)
    assert msg in stream.getvalue()

# Generated at 2022-06-24 09:55:56.065396
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm

    # Testing for valid argument for __init__
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class is std_tqdm
    # Testing for invalid argument for __init__
    # def func():
    #     pass
    # try:
    #     handler = _TqdmLoggingHandler(tqdm_class=func)
    # except TypeError:
    #     assert True
    # except:
    #     assert False



# Generated at 2022-06-24 09:55:57.103001
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-24 09:56:04.071901
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm.contrib._logging import _TqdmLoggingHandler

    # Create a file-like object
    s = StringIO()
    handler = _TqdmLoggingHandler()
    handler.setStream(s)
    handler.emit("test")
    # Make sure it was written to the stream
    assert (s.getvalue() == "test\n")

# Generated at 2022-06-24 09:56:05.609832
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with open('test.log', 'w') as f:
        handler = _TqdmLoggingHandler(f)
        assert handler.stream == f


# Generated at 2022-06-24 09:56:08.147378
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import _test_logging_redirect_tqdm, test_tqdm
    test_tqdm('tqdm_logging_redirect', globals(),
              lambda: _test_logging_redirect_tqdm(tqdm_class=std_tqdm))



# Generated at 2022-06-24 09:56:14.964671
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:56:21.334549
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # TODO: some more tests are needed


# Generated at 2022-06-24 09:56:25.569651
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    try:
        from unittest import mock
    except ImportError:
        from unittest import mock

    with mock.patch('tqdm.contrib.logging._TqdmLoggingHandler.emit') as mock_emit:
        with logging_redirect_tqdm():
            LOG.info('Test logging')

    mock_emit.assert_called_with(mock.ANY)

# Generated at 2022-06-24 09:56:31.235450
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import tqdm

    stream = io.StringIO()  # type: io.TextIOWrapper
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.tqdm_class = tqdm.tqdm
    tqdm_handler.stream = stream

    def _test_emit(msg):
        # type: (str) -> None
        record = logging.LogRecord("name", logging.INFO, "pathname", 1,
                                   msg, tuple(), None)
        tqdm_handler.emit(record)
        assert stream.getvalue() == msg

    _test_emit("foo")
    _test_emit("bar")
    _test_emit("baz")



# Generated at 2022-06-24 09:56:32.611778
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:56:41.617440
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._utils import _term_move_up as tmu

    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger('my-logger')
    log.info("this is a test")

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored
    log.info("this is also a test")

    with logging_redirect_tqdm(loggers=[log]):
        for i in range(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored
    log.info("this is also a test")
    assert log

# Generated at 2022-06-24 09:56:42.829582
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()


# Generated at 2022-06-24 09:56:47.054392
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange

    loggers = [logging.getLogger()]
    with tqdm_logging_redirect(
            loggers=loggers, unit='foo', total=3):
        for i in trange(3):
            if i == 1:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:56:54.968627
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from io import StringIO

    Logger = logging.getLogger(__name__)  # pylint: disable=invalid-name

    out = StringIO()

    logging.basicConfig(
        level=logging.INFO,
        stream=out,
        format="%(message)s")
    with logging_redirect_tqdm():
        for i in range(5):
            Logger.info("test")
    result = out.getvalue()
    expected = "\n".join("test" for i in range(5)) + "\n"

    assert result == expected, \
        "'{0}' is not '{1}'".format(result, expected)



# Generated at 2022-06-24 09:57:03.082878
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=9, loggers=[LOG],
                               desc='test', file=sys.stderr) as pbar:
        for _ in pbar:
            if pbar.n == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:57:07.031703
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:57:14.953512
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    logger.addHandler(stream_handler)
    assert isinstance(stream_handler, logging.StreamHandler)
    assert stream_handler.stream in {sys.stdout, sys.stderr}
    tqdm_logging_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logging_handler)
    assert isinstance(tqdm_logging_handler, _TqdmLoggingHandler)
    assert tqdm_logging_handler.stream in {sys.stdout, sys.stderr}

# Generated at 2022-06-24 09:57:23.034131
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    import traceback
    test_stream = StringIO()

    def raises_keyboard_interrupt():
        if test_stream.getvalue() == 'test_log\n':
            raise KeyboardInterrupt

    def raises_system_exit():
        if test_stream.getvalue() == 'test_log\n':
            raise SystemExit

    def raises_exception():
        if test_stream.getvalue() == 'test_log\n':
            raise OptionError

    class OptionError(Exception):
        pass

    class TestTqdm:
        def __init__(self, file=None):
            self.file = file

        def write(self, msg, file=None):
            test_stream.write(msg)

        def flush(self):
            return

    # test_stream.write is

# Generated at 2022-06-24 09:57:32.097337
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    import io
    import tqdm

    out = io.StringIO()
    tqdm_log_handler = _TqdmLoggingHandler(tqdm.tqdm)
    # IOError: sys.stdout access restricted by mod_wsgi
    tqdm_log_handler.stream = out
    tqdm_log_handler.emit(logging.LogRecord('root', logging.INFO, 'foo.py', 1,
                                            msg='This is a test.', args=(),
                                            exc_info=None))
    out.seek(0)
    assert out.readline() == 'This is a test.\n'



# Generated at 2022-06-24 09:57:37.886389
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from io import StringIO
    from tqdm import tqdm

    # Expected output

# Generated at 2022-06-24 09:57:38.984925
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:57:48.820414
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = 'test message'

    # Test logging to stdout
    stdout_handler = _TqdmLoggingHandler()
    stdout_handler.stream = sys.stdout
    stdout_handler.emit(logging.LogRecord(
        'name_logger',
        logging.INFO,
        None,
        None,
        msg,
        (),
        None
    ))
    # Test logging to stderr
    stderr_handler = _TqdmLoggingHandler()
    stderr_handler.stream = sys.stderr
    stderr_handler.emit(logging.LogRecord(
        'name_logger',
        logging.INFO,
        None,
        None,
        msg,
        (),
        None
    ))

# Generated at 2022-06-24 09:57:53.137948
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    logger = logging.getLogger(__name__)
    console = _TqdmLoggingHandler()
    logger.addHandler(console)
    logger.setLevel(logging.INFO)
    logger.info('test')


# Generated at 2022-06-24 09:58:01.166375
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    # Minimum code
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # Without context manager
    logging.basicConfig(level=logging.INFO)
    logging_redirect_tqdm()
    for i in range(9):
        if i == 4:
            LOG.info("console logging redirected to `tqdm.write()`")

    # With specified logger and tqdm class
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:58:10.082062
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(format='%(message)s', level=logging.INFO)
    try:
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    logging.info("test_logging_redirect_tqdm")
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        raise AssertionError("Unknown exception caught")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:58:10.969680
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:58:17.989638
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    import sys

    msg = None

    def test_logging(msg):
        def _test_logging_redirect(msg):
            LOG = logging.getLogger(__name__)
            # set logging.StreamHandler, to be able to test
            stream_handler = logging.StreamHandler()
            LOG.handlers = [stream_handler]
            with io.StringIO() as buf, tqdm_logging_redirect():
                LOG.critical(msg)
                LOG.error(msg)
                LOG.warning(msg)
                LOG.info(msg)
                LOG.debug(msg)
                return [msg for msg in buf.getvalue().split('\n') if msg != '']

        messages = _test_logging_redirect(msg)
        # correct logging redirect to `t

# Generated at 2022-06-24 09:58:27.186589
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    with std_tqdm.stdout_redirector(sys.stdout):
        try:
            std_tqdm.tqdm.write('hello1')
            handler = _TqdmLoggingHandler()
            std_tqdm.tqdm.write('hello2')
            handler.emit(logging.Formatter().format(logging.LogRecord('hello', logging.DEBUG, '', 0, 'hello', tuple(), None)))  # pylint: disable=bad-option-value
            std_tqdm.tqdm.write('hello3')
        except AttributeError:
            std_tqdm.tqdm.write('hello0')

# Generated at 2022-06-24 09:58:31.078869
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    handler.emit(logging.getLogger().makeRecord("test_logger.info", 1, "test", 1, "test_logger", None, None))
    assert "test" in sys.stderr.getvalue()


# Generated at 2022-06-24 09:58:39.331205
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    with tqdm_logging_redirect(
        logger=logger,
        tqdm_class=std_tqdm):
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:47.141957
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-24 09:58:56.712500
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import logging
    from .compat import StringIO

    # Prepare some mockup data
    class MockupTqdm(object):
        def __init__(self, file=sys.stdout):
            super(MockupTqdm, self).__init__()
            self.file = file
        def write(self, msg, file=None):
            self.file.write("written: '{}'\n".format(msg))

    mock_stderr = StringIO()  # type: StringIO
    mock_handler = _TqdmLoggingHandler(tqdm_class=MockupTqdm)

    # Override the stream attribute
    mock_handler.stream = mock_stderr

    # Prepare a test logger
    logger = logging.getLogger("test_logger")
    logger