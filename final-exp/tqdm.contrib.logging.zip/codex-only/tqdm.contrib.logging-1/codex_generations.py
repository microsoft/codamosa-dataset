

# Generated at 2022-06-24 09:48:54.510578
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: (Union[str, None]) -> None
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(total=100, desc='Loading modules') as pbar:
        # module loading
        pbar.set_description("Processing module 1")
        pbar.update(10)
        logging.info("Processing module 2")
        pbar.update(20)
        pbar.set_description("Processing module 3")
        pbar.update(65)
        logging.warning("Processing module finished")


test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:48:57.772780
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys

    msg = 'I am a test log message'
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = sys.stdout  # pretend to be a console
    tqdm_logging_handler.emit(logging.LogRecord('', logging.INFO, '', '', msg, '', ''))  # noqa pylint: disable=logging-format-interpolation

# Generated at 2022-06-24 09:49:06.949843
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from time import sleep
    import sys
    from tqdm import trange

    import logging
    from .utils import __test_bar, __test_bar_desc, __test_bar_total

    def assert_logging_redirect_tqdm(logger, expected_msg):
        with logging_redirect_tqdm():
            assert logger.level == logging.INFO
            logger.info(expected_msg)

        log_messages = [
            record.getMessage() for record in logger.handlers[0].buffer
        ]
        assert expected_msg in log_messages

    assert_logging_redirect_tqdm(logging.getLogger(), 'test message')
    assert_logging_redirect_tqdm(
        logging.getLogger(), 'test message: logger => logging.getLogger')

# Generated at 2022-06-24 09:49:07.747451
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(std_tqdm)


# Generated at 2022-06-24 09:49:16.406784
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    from contextlib import redirect_stdout

    stream = io.StringIO()
    h = _TqdmLoggingHandler()
    h.stream = stream
    h.emit(logging.LogRecord('test', logging.INFO, '', 0, 'msg1', None, None))
    with redirect_stdout(stream):
        print('test')
    h.emit(logging.LogRecord('test', logging.INFO, '', 0, 'msg2', None, None))

    assert stream.getvalue() == 'msg1\ntest\nmsg2\n'

# Generated at 2022-06-24 09:49:22.525719
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO  # type: ignore

    log_msg = 'a log message'
    stream = StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = stream
    record = logging.LogRecord('logger_name', logging.INFO, None, None, log_msg, None, None)
    handler.emit(record)
    assert stream.getvalue() == log_msg + '\n'


# Generated at 2022-06-24 09:49:27.930512
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:49:29.226652
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:49:37.147608
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    from tqdm import tqdm
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(_TqdmLoggingHandler())
    for i in range(9):
        logger.info(i)
    for i in range(100):
        logger.info(i)
    for i in tqdm(range(9)):
        logger.info(i)
    for i in tqdm(range(9)):
        logger.info(i)
    for i in tqdm(range(9)):
        logger.info(i)



# Generated at 2022-06-24 09:49:41.811069
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    temp_stream = open("temp_stream.txt", "w")
    with _TqdmLoggingHandler(stream=temp_stream) as tqdm_handler:
        assert tqdm_handler.tqdm_class == std_tqdm
    temp_stream.close()
    os.remove("temp_stream.txt")



# Generated at 2022-06-24 09:49:51.662504
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import StringIO
    from cStringIO import StringIO as CStringIO
    from datetime import datetime
    from time import sleep

    log_file = StringIO()

    h = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    h.stream = log_file
    h.setLevel(20)
    h.setFormatter(logging.Formatter(
        '\n' +
        '------ test_TqdmLoggingHandler_emit ------\n' +
        '%(levelname)s\n' +
        '[%(asctime)s]: %(message)s\n'))


# Generated at 2022-06-24 09:49:59.756283
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.DEBUG)
    logging.basicConfig(format='[%(levelname)s] %(asctime)-15s %(message)s', 
        datefmt='%m/%d/%Y %I:%M:%S %p', 
        level=logging.DEBUG)
    test_logger.addHandler(_TqdmLoggingHandler())
    test_logger.debug('test debug')
    test_logger.info('test info')
    test_logger.warning('test warning')
    test_logger.error('test error')
    test_logger.critical('test critical')

    print('finish')

# Generated at 2022-06-24 09:50:02.453785
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info('test')



# Generated at 2022-06-24 09:50:12.208452
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """"""
    import io

    output_stream = io.StringIO()
    log_handler = logging.StreamHandler(stream=output_stream)
    LOG = logging.getLogger(__name__)
    LOG.addHandler(log_handler)
    LOG.setLevel(logging.INFO)
    for i in tqdm_logging_redirect(range(5), desc='test', file=output_stream):
        if i == 1:
            LOG.info("This is test")
    output_stream.seek(0)
    assert output_stream.getvalue() == 'test:   20%|██    | 1/5 [00:00<' \
                                       '00:00,  6.55it/s]\nThis is test\n'

# Generated at 2022-06-24 09:50:22.640175
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm._utils import _decode as utils_decode

    for tqdm_class in extended_tqdms:
        with tqdm_logging_redirect(miniters=1, desc=utils_decode('Test 1'),
                                   tqdm_class=tqdm_class) as pbar:
            assert pbar.total == pbar.n == 0
            assert pbar.desc == utils_decode('Test 1')
            logging.info("info: %r", pbar)
            assert pbar.n == 1
        with tqdm_logging_redirect(desc=utils_decode('Test 2'),
                                   tqdm_class=tqdm_class) as pbar:
            assert pbar.total == pbar.n == 0

# Generated at 2022-06-24 09:50:30.859336
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm_test_cases import DiscreteTestCase, TotalTestCase
    from ..autonotebook import tqdm

    class TestTqdmLoggingRedirect(DiscreteTestCase):
        def test_logging_redirect(self):
            with tqdm_logging_redirect(
                    total=40, miniters=20, mininterval=0,
                    leave=True, smoothing=1, bar_format='{n_fmt} {bar} {rate_fmt}') as pbar:
                pbar.update(10)
                import logging
                LOG = logging.getLogger(__name__)
                LOG.warning('Testing logging redirector')
                LOG.error('Testing logging redirector')
                LOG.critical('Testing logging redirector')
                LOG.info('Testing logging redirector')


# Generated at 2022-06-24 09:50:39.731257
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    LOG = logging.getLogger(__name__)

    def test_console_logging_handler():
        for logger in [logging.root, LOG]:
            for handler in logger.handlers:
                if _is_console_logging_handler(handler):
                    return True
        return False

    with tqdm_logging_redirect(logging.root.handlers) as pbar:
        assert len(logging.root.handlers) == 1
        assert _is_console_logging_handler(logging.root.handlers[0])
        assert logging.root.handlers[0].stream == pbar.write
        assert len(LOG.handlers) == 1
        assert _is_console_logging_handler(LOG.handlers[0])
        assert LOG.handlers

# Generated at 2022-06-24 09:50:47.035598
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    # test using the logging module directly
    with tqdm_logging_redirect():
        for _ in trange(9):
            logging.info("console logging redirected to `tqdm.write()`")

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    with tqdm_logging_redirect():
        for _ in trange(9):
            log.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:50:49.849310
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None

    handler = _TqdmLoggingHandler()
    assert isinstance(handler, _TqdmLoggingHandler)


# Generated at 2022-06-24 09:50:53.394511
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit tests for the constructor of class _TqdmLoggingHandler
    """
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)


# Generated at 2022-06-24 09:50:54.460944
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:03.296378
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from . import tqdm_logging_redirect, tqdm_notebook
    try:
        import IPython
        tqdm_notebook.tqdm = tqdm_notebook.tqdm_notebook

        with tqdm_logging_redirect() as pbar:
            pbar.write('test 123')
        assert isinstance(pbar, std_tqdm)

        with tqdm_logging_redirect(tqdm_class=tqdm_notebook.tqdm) as pbar:
            pbar.write('test 123')
        assert isinstance(pbar, tqdm_notebook.tqdm)

    except ImportError as e:
        # IPython is not installed
        pass


# Generated at 2022-06-24 09:51:12.872697
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    import io

    sio = io.StringIO()
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sio))

    # with logging_redirect_tqdm():
    #     for i in trange(4):
    #         if i == 2:
    #             log.info('Test')

    with tqdm_logging_redirect(file=sio) as pbar:
        for i in trange(4):
            if i == 2:
                log.info('Test')
            pbar.update()

    sio.seek(0)

# Generated at 2022-06-24 09:51:15.034814
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(5):
            logging.info("Test logging redirect tqdm")


# Generated at 2022-06-24 09:51:22.573906
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import unittest
    import logging
    import io
    import sys
    class _Test_tqdm_logging_redirect(unittest.TestCase):
        def test_logging_redirect_tqdm(self):
            # function `logging_redirect_tqdm`
            with tqdm_logging_redirect(
                total=9,
                file=io.StringIO(),
                mininterval=0.01,
                smoothing=0,
                disable=False
            ) as pbar:
                for i in range(9):
                    if i == 4:
                        logging.info('console logging redirected to `tqdm.write()`')
                self.assertTrue(pbar.n == 9)
                self.assertTrue(pbar.total == 9)


# Generated at 2022-06-24 09:51:26.211380
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tqdm_logger = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logger)
    logger.info("Test")

# Generated at 2022-06-24 09:51:27.347228
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-24 09:51:38.044621
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import tqdm._utils as _utils
    import tqdm.std as std

    # redirect the output to a file
    with _utils.redirect_stdout(std.sys.stdout):
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        handler = _TqdmLoggingHandler()
        logger.addHandler(handler)

        logger.info("this is a test")
        handler.flush()  # flush the output

    # check that it was written in the file
    with open(std.sys.stdout.name, "r") as f:
        txt = f.read()
        assert txt == "this is a test\n"

    # delete the file
    os.remove(std.sys.stdout.name)

# Generated at 2022-06-24 09:51:42.598254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:49.456204
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger()
    # get original logging handler
    original_logging_handler = _get_first_found_console_logging_handler(logger.handlers)

    with logging_redirect_tqdm():
        assert not any(_is_console_logging_handler(handler) for handler in logger.handlers)

    # verify that the logging redirection was restored
    assert (
        original_logging_handler ==
        _get_first_found_console_logging_handler(logger.handlers))



# Generated at 2022-06-24 09:51:53.853120
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    try:
        with tqdm_logging_redirect(loggers=[logger]):
            logger.info('hello')
    except BaseException:
        raise Exception('test_tqdm_logging_redirect failed')

# Generated at 2022-06-24 09:52:02.835253
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.contrib import tenumerate

    buf = StringIO()

    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = buf
    handler.setFormatter(logging.Formatter())

    # Successful message logging
    handler.handle(logging.LogRecord(
        name='test', level=logging.INFO, pathname=None,
        lineno=None, msg='hello world!', args=None,
        exc_info=None))


# Generated at 2022-06-24 09:52:12.522235
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(
            desc='Test',
            total=24,
            leave=False,
            disable=False,
            mininterval=0
    ) as pbar:
        for i in range(24):
            if i == 4:
                pbar.set_description_str('console logging redirected')
            pbar.update()


# Generated at 2022-06-24 09:52:21.214512
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm, trange

    def test_tqdm_with_logging_redirect():
        """Function which must be compatible with:
        with tqdm_logging_redirect(*args, **kwargs) as pbar:
            # do something
        pbar.update(1)
        """
        with tqdm_logging_redirect(total=10,
                                   tqdm=trange,  # pylint: disable=unexpected-keyword-arg
                                   loggers=[logging.root]) as pbar:
            with logging_redirect_tqdm(loggers=[logging.root]):
                pbar.update(1)


# Generated at 2022-06-24 09:52:27.790209
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    sh = logging.StreamHandler()
    sh.setLevel(logging.DEBUG)
    fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    sh.setFormatter(fmt)
    log.addHandler(sh)
    with tqdm_logging_redirect():
        for _ in std_tqdm(range(10)):
            log.debug('Test Message')



# Generated at 2022-06-24 09:52:37.199244
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    desc = 'Test'
    import logging
    logging.basicConfig(level=logging.DEBUG)  # , filename='example.log', filemode='w')
    tqdm_logging_handler = _TqdmLoggingHandler()

    def test_function(i):
        tqdm_logging_handler.emit(logging.LogRecord(
            'name',
            logging.DEBUG,
            'pathname',
            i,
            desc,
            (),
            None,
            'test_function'
        ))

    test_function(0)
    test_function(1)
    test_function(2)
    test_function(3)
    test_function(4)

# Generated at 2022-06-24 09:52:40.136376
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.std import tqdm

    with tqdm_logging_redirect(total=3) as pbar:
        assert(pbar.__class__ == tqdm)
        assert(pbar.total == 3)

# Generated at 2022-06-24 09:52:50.361327
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)


# Generated at 2022-06-24 09:52:57.887930
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up
    from tqdm import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        loggers = [logging.root, LOG]
        with logging_redirect_tqdm(loggers=loggers):
            for i in tqdm(range(9), leave=False):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # Unit test for function tqdm_logging_redirect

# Generated at 2022-06-24 09:53:04.897528
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    from contextlib import redirect_stdout

    test_string = ""
    with redirect_stdout(StringIO()) as out:
        test_handler = _TqdmLoggingHandler()
        test_logger = logging.getLogger("test_logger")
        test_logger.addHandler(test_handler)
        test_logger.info("Test info message")
        test_string = out.getvalue().strip()
    assert test_string == "Test info message"

# Generated at 2022-06-24 09:53:13.611015
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info('console logging redirected to `tqdm.write()`')
        # logging restored

# Generated at 2022-06-24 09:53:23.191191
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger('tqdm')
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    orig_handler = _get_first_found_console_logging_handler(logger.handlers)
    if orig_handler is not None:
        tqdm_handler.setFormatter(orig_handler.formatter)
        tqdm_handler.stream = orig_handler.stream
    logger.handlers = [
        handler for handler in logger.handlers
        if not _is_console_logging_handler(handler)] + [tqdm_handler]
    logger.info("test__TqdmLoggingHandler:logging_redirect_tqdm")
    logger.handlers = []


# Generated at 2022-06-24 09:53:32.625388
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger()
    log.setLevel(logging.INFO)

    # Make sure logging does not interfere with unit testing output
    log.addHandler(logging.NullHandler())

    # Test handler with output to tqdm.write(file=sys.stderr)
    log.info("Hello, world!")

    # Test handler with output to tqdm.write(file=sys.stdout)
    log.addHandler(_TqdmLoggingHandler(tqdm_class=std_tqdm))
    log.info("Hello, world!")
    log.removeHandler(_TqdmLoggingHandler)

# Generated at 2022-06-24 09:53:42.902862
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import tqdm
    tqdm.tqdm = tqdm.std.tqdm = tqdm.std.tqdm_gui = tqdm.tqdm_gui = tqdm.tqdm_pandas = tqdm.tqdm_notebook = None

    # set up a logger to test with
    handler = _TqdmLoggingHandler()
    str_io = io.StringIO()
    handler.stream = str_io
    logger = logging.Logger('foo')
    logger.addHandler(handler)

    logger.info('foo bar')
    assert str_io.getvalue() == 'foo bar\n'

    logger.handlers[0].close()

# Generated at 2022-06-24 09:53:44.833218
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.emit(_TqdmLoggingHandler.emit.__code__)

# Generated at 2022-06-24 09:53:51.938158
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from .logging import tqdm_logging_redirect, logging_redirect_tqdm
    from .logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler())
    with tqdm_logging_redirect(loggers=[logger]):
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(loggers=[logger]):
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

    # loggers not redirected
   

# Generated at 2022-06-24 09:53:59.701603
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:54:05.979490
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import sys
    from tqdm.utils import _range

    with _range(4, ncols=80) as pbar:
        for _ in pbar:
            pass

    handler = _TqdmLoggingHandler()
    record = logging.LogRecord(level=logging.INFO, msg="Test", name=None, pathname=None,
                               lineno=None, msgfmt=None, args=None, exc_info=None)
    handler.emit(record)
    assert sys.stdout.getvalue() == "\x1b[KTest\n\x1b[K\r", "TqdmHandler Type test failed"

# Generated at 2022-06-24 09:54:16.426244
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    # Basic test of console logging redirected to `tqdm.write()`
    TESTS = """\
    ##########################################################################
    ##############                    0%                    ################
    ##############                    0%                    ################
    ##########################################################################
    """
    with tqdm_logging_redirect() as pbar:
        logging.info('console logging redirected to `tqdm.write()`')
        for _ in trange(9):
            pass
    assert TESTS in pbar.get_internal_loc()._io.getvalue()

    # Test of logging output with custom formatters

# Generated at 2022-06-24 09:54:22.916327
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in trange(9):
        if i == 4:
            logging.info("console logging restored")


# Generated at 2022-06-24 09:54:30.010797
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('tqdm.std.tqdm', spec=True) as mock_tqdm:
        import logging
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)

        with logging_redirect_tqdm():
            LOG.info('test')
        mock_tqdm.write.assert_called_once_with('test')

        with logging_redirect_tqdm(tqdm_class=mock_tqdm):
            LOG.info('test')
        mock_tqdm.write.assert_called_with('test')
        mock_tqdm.reset_mock()


# Generated at 2022-06-24 09:54:40.276675
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_tqdm = std_tqdm(maxiter=1)
    test_handler = _TqdmLoggingHandler(tqdm_class=test_tqdm)

    assert test_handler.tqdm_class == test_tqdm
    with tqdm_logging_redirect(tqdm_class=test_tqdm, loggers=[logging.root]):
        test_handler.emit(logging.LogRecord(
            name='tqdm_logging_handler_test',
            level=logging.INFO,
            pathname='tqdm/contrib/logging.py',
            lineno=0,
            msg='success',
            args=None,
            exc_info=None
        ))
    assert "success" in test_tqdm.get_last_message

# Generated at 2022-06-24 09:54:46.881826
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # pylint: disable=unused-variable
    # type: () -> None
    """Unit test for constructor of class _TqdmLoggingHandler"""
    from tqdm.auto import tqdm

    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    assert tqdm_logging_handler.tqdm_class == tqdm
    assert tqdm_logging_handler.level == logging.NOTSET
    assert tqdm_logging_handler.formatter == logging.BASIC_FORMAT


# Generated at 2022-06-24 09:54:48.769773
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.getLogger(__name__).addHandler(_TqdmLoggingHandler())
    logging.getLogger(__name__).info('hello')


# Generated at 2022-06-24 09:54:59.585802
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.auto import tqdm, trange
    import logging
    import sys
    out = StringIO()
    with redirect_stdout(out):
        with tqdm_logging_redirect(unit='B', unit_scale=True,
                                   unit_divisor=1024, miniters=1,
                                   file=sys.stdout) as pbar:
            pbar.update(10)
            pbar.update(20)
            pbar.set_postfix(loss=0.6, acc=0.9, refresh=False)
            pbar.set_postfix(loss=0.4, acc=0.8, refresh=False)
            pbar.update(30)
            for i in trange(4, desc='2nd loop'):
                pbar.update(30)


# Generated at 2022-06-24 09:55:04.611473
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)

    # Suppress the tqdm logging output
    class _EmptyLoggingHandler(logging.NullHandler):
        def emit(self, record):
            pass
    tqdm_handler = _EmptyLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.handlers = [tqdm_handler]

    # Make sure that the logger does not have any _TqdmLoggingHandler
    assert not [h for h in logger.handlers if type(h) is _TqdmLoggingHandler]
    logger.info("Do not show this info log")

    tqdm_logging_handler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:55:06.415190
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info("Foo Bar Baz")

# Generated at 2022-06-24 09:55:16.188522
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger('')
    logger.setLevel(logging.INFO)
    stream = logging.StreamHandler()
    stream.setLevel(logging.INFO)
    logger.addHandler(stream)

    # with logging_redirect_tqdm(loggers=[logger]):  # old tqdm (not function)
    with logging_redirect_tqdm(loggers=[logger], tqdm_class=std_tqdm):  # new tqdm (function)
        logger.info("logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:55:26.351959
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.utils import _term_move_up

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(logging.INFO, total=9):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-24 09:55:29.983365
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert h.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:55:34.884732
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:55:45.105586
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    # -------------------------------------------------------------------------
    # Create logger and root logger
    logger = logging.getLogger("test_logger")
    root_logger = logging.getLogger("")
    # -------------------------------------------------------------------------
    # Test tqdm_logging_redirect_with_root_logger
    with tqdm_logging_redirect(total=3, loggers=[root_logger],
                               bar_format="{n}/{total} [{elapsed}<{remaining}]"):
        pass
    # -------------------------------------------------------------------------
    # Test tqdm_logging_redirect_with_logger

# Generated at 2022-06-24 09:55:56.326433
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import contextlib  # noqa

    @contextlib.contextmanager
    def logger_capture():
        # type: () -> Iterator[None]
        """
        Captures log messages in a list.

        Returns
        -------
        Iterator[None]
            calls `log.setLevel(level)` and `log.setLevel(old_level)`
        """
        log = logging.getLogger('ContextLogger')
        log.setLevel(logging.DEBUG)

        handler = logging.StreamHandler()
        log.addHandler(handler)

        # Capture messages
        logmessages = []  # type: List[str]

        class CapturingHandler(logging.StreamHandler):

            def emit(self, record):
                logmessages.append(self.format(record))


# Generated at 2022-06-24 09:56:06.834364
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    from . import test_main


# Generated at 2022-06-24 09:56:16.817304
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    allowed_missing = {'formatter', 'flush', 'stream'}
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")
    original_handlers = logger.handlers.copy()
    original_tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    orig_handler = original_handlers[-1]
    missing_attrs = {attr for attr in orig_handler.__dict__
                     if not attr.startswith('_') and not hasattr(orig_handler, attr)
                     and attr not in allowed_missing}
    assert missing_att

# Generated at 2022-06-24 09:56:22.076543
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for class _TqdmLoggingHandler.
    """
    tqdm_logger = logging.getLogger(__name__)
    tqdm_logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_logger.addHandler(tqdm_handler)
    tqdm_logger.info('test')

# Generated at 2022-06-24 09:56:31.042866
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import pickle
    from io import StringIO
    from tqdm import tqdm_notebook
    from traceback import format_exception_only as _format_exception_only

    log = logging.getLogger('test')
    log.setLevel(logging.INFO)

    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    log.handlers = [handler]

    class MyException(Exception):
        pass

    try:
        raise MyException
    except:
        _, _, traceback = sys.exc_info()
        exception_only = format_exception_only(MyException, traceback)

    original_stdout = sys.stdout

# Generated at 2022-06-24 09:56:36.473804
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import io
    import sys
    handle = io.StringIO()
    sys.stdout = handle
    logger = logging.getLogger('logger')
    logging_handler = _TqdmLoggingHandler()
    logger.addHandler(logging_handler)
    logger.warning('warning')
    handle.flush()
    output = handle.getvalue()
    assert output == 'warning\n'
    sys.stdout = sys.__stdout__


# Generated at 2022-06-24 09:56:46.776584
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit of class _TqdmLoggingHandler
    """
    import tempfile
    import unittest

    class MyTest(unittest.TestCase):
        def setUp(self):
            f = tempfile.TemporaryFile()
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = sys.stderr = f

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def test__TqdmLoggingHandler_emit(self):
            # type: () -> None
            """
            Unit test for method emit of class _TqdmLoggingHandler
            """

            # This is a simplified version of the code in logging.StreamHandler to avoid

# Generated at 2022-06-24 09:56:48.359126
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:56:56.364022
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import logging
        import tqdm.std
    except ImportError:
        return
    with logging.root.handlers:
        with tqdm_logging_redirect(
            total=None,
            desc='foo',
            dynamic_ncols=True,
            ascii=True,
            loggers=None,  # default to [logging.root]
        ):
            logging.info("logging redirected to tqdm.std.tqdm")
        with tqdm_logging_redirect(
            total=None,
            desc='foo',
            dynamic_ncols=True,
            ascii=True,
            loggers=[logging.getLogger("foo")],
        ):
            logging.info("logging redirected to tqdm.std.tqdm")


# Generated at 2022-06-24 09:57:04.585469
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    capture = sys.stdout
    with open('out.txt', 'w') as file:
        sys.stdout = file
        class FakeLogger:
            @staticmethod
            def exception(exc):
                return exc

        try:
            record = FakeLogger()
            handler = _TqdmLoggingHandler()
            handler.emit(record)
        except Exception as exc:
            raise
        finally:
            sys.stdout = capture
    capture.close()

# Generated at 2022-06-24 09:57:06.527237
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.tqdm_class is std_tqdm



# Generated at 2022-06-24 09:57:16.738448
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import trange
    # Testing common case (default logger)
    for _ in trange(2):
        with logging_redirect_tqdm():
            logging.info("test")
        try:
            raise ValueError("test")
        except:  # noqa pylint: disable=bare-except
            logging.exception("test")
    # Testing create a new logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("test")
        logger.debug("test")

# Generated at 2022-06-24 09:57:22.579191
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:57:29.581618
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    root_logger = logging.getLogger()
    original_handlers = root_logger.handlers
    root_logger.handlers = [tqdm_handler]
    logger = logging.getLogger(__name__)

    logger.info("test__TqdmLoggingHandler_emit")
    root_logger.handlers = original_handlers

# Generated at 2022-06-24 09:57:41.831924
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm.contrib.tests import TqdmTestCase

    class TestTqdmLoggingRedirect(TqdmTestCase):
        """Test `tqdm.contrib.logging.tqdm_logging_redirect`"""

        def setUp(self):
            # type: () -> None
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.INFO)

        def test_tqdm_logging_redirect(self):
            # type: () -> None
            with tqdm_logging_redirect(desc="Test", leave=False) as pbar:
                self.logger.info("Info message")
                pbar.update()

# Generated at 2022-06-24 09:57:52.777877
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    Test that class _TqdmLoggingHandler
    """
    from unittest import mock
    from ..tqdm import trange

    # Mock function `emit` of parent class logging.StreamHandler
    with mock.patch('logging.StreamHandler.emit') as emit_mock:
        with mock.patch('tqdm.std.sys.stderr', new_callable=lambda: 'mock_stderr'):
            tqdm_handler = _TqdmLoggingHandler()
            record = logging.makeLogRecord({})
            tqdm_handler.emit(record)
            # function `emit` of parent class logging.StreamHandler should be called
            emit_mock.assert_called_once_with(record)

    # Test that attribute `t

# Generated at 2022-06-24 09:58:00.831894
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import sys
    import logging
    # import tqdm.std as tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import pytest
    from ..utils import _range

    def test_tqdm_logging_redirect_nologger(capsys):
        """test_tqdm_logging_redirect_nologger

        """
        pytest.importorskip("logging")
        LOG = logging.getLogger(__name__)

        with capsys.disabled():
            with logging_redirect_tqdm():
                for i in _range(10):
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:01.668490
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:58:06.552535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test logging_redirect_tqdm():
    """
    # To avoid print() output from these tests
    from contextlib import redirect_stdout

    import logging
    from tqdm import tqdm

    log = logging.getLogger(__name__)

    # Run the test
    with redirect_stdout(open('/dev/null', 'w')):
        with logging_redirect_tqdm():
            for _ in tqdm(range(9)):
                if _ == 4:
                    log.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:58:12.223605
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_msg = 'test'
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)

    orig_stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        handler.emit(test_msg)
        output = sys.stdout.getvalue().strip()
        assert output == test_msg
    finally:
        sys.stdout = orig_stdout

# Generated at 2022-06-24 09:58:12.966060
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pass

# Generated at 2022-06-24 09:58:19.736246
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Tests _TqdmLoggingHandler.emit"""
    logger = logging.getLogger(__name__)
    logger.handlers = []
    logger.addHandler(_TqdmLoggingHandler())
    logger.setLevel(logging.DEBUG)

    # Testing the log message with the log level `DEBUG`. Should write the log
    # message to the console.
    msg = 'Test log message'
    logger.debug(msg)


# Generated at 2022-06-24 09:58:28.279030
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            logger=LOG, total=9, leave=True
    ) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # restore normal logging
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:58:36.854294
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import random
    # DO NOT USE TQDM IN THE TEST CASES
    def tqdm_func(it):
        for i in it:
            yield i
    def tqdm_func_logging(it):
        for i in it:
            logging.info("logging message %d" % i)
            yield i
    def tqdm_func_raise(it):
        for i in it:
            if i == 10:
                raise ValueError
            yield i

    # Test cases:
    # 1. No exception raised.
    # 2. Exception raised in the global scope
    # 3. Exception raised in the logging context manager

    # Test case 1
    logging.info("--- Test case 1 ---")

# Generated at 2022-06-24 09:58:42.568585
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler


# Generated at 2022-06-24 09:58:44.697212
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream == sys.stderr
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:58:54.644608
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    class DummyTqdmClass(object):
        def __init__(self):
            # type: () -> None
            self._stdout = ''

        def write(self, s, file=None):
            # type: (str, file) -> None
            self._stdout += s

        def __str__(self):
            # type: () -> str
            return self._stdout

    dummy_tqdm_class = DummyTqdmClass()

    filename = 'filename'
    line_no = 123
    func_name = 'func_name'
    log_level = 'log_level'
    msg = 'msg'
    stream = 'stream'

    logger = logging.getLogger(__name__)

    # check if logging.LogRecord instance is created properly