

# Generated at 2022-06-24 09:48:47.963371
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import io
    import sys

    # Set up a StreamHandler for testing tqdm.write()
    stream = io.BytesIO()
    sys.stdout = stream

    # Set up a _TqdmLoggingHandler for testing _TqdmLoggingHandler.emit()
    logger = logging.Logger(__name__)
    sys.stderr = io.BytesIO()
    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    handler.stream = sys.stderr
    logger.addHandler(handler)

    logger.info('Info')
    logger.warning('Warning')
    logger.error('Error')

# Generated at 2022-06-24 09:48:51.993696
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = logging.getLogger(__name__)
    loggers = [logger]

    # Basic success test
    logger.info('Before')
    with logging_redirect_tqdm(loggers=loggers):
        logger.info('In tqdm')
        logger.info('Still in tqdm')
    logger.info('After')

    # Basic failure test
    try:
        with logging_redirect_tqdm(loggers=loggers):
            1/0
    except ZeroDivisionError:
        pass
    logger.info('After ZeroDivisionError')

    # Standard output test
    logger.info('Before stdout')

# Generated at 2022-06-24 09:48:57.651765
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    from logging import StreamHandler
    orig_handler = StreamHandler()
    orig_handler.stream = tqdm_handler.stream = sys.stdout
    orig_handler.setFormatter(None)
    tqdm_handler.setFormatter(orig_handler.formatter)
    tqdm_handler.stream = orig_handler.stream

    logging.getLogger().handlers = [orig_handler]
    logging.getLogger().info("Console logging")
    tqdm_handler.emit(logging.LogRecord(
        logger='test', level=20, pathname=None, lineno=None, msg="Tqdm logging",
        args=None, exc_info=None))

# Generated at 2022-06-24 09:49:05.056603
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=missing-docstring
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord(__name__, logging.INFO, None, 0, 'test_message',
                               None, None)
    try:  # python 2&3
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        handler.emit(record)
        assert sys.stdout.getvalue() == 'test_message\n'
    finally:
        sys.stdout = stdout

# Generated at 2022-06-24 09:49:12.400397
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    ```python
    from tqdm.contrib.logging import _TqdmLoggingHandler
    import logging

    for i in range(1):
        with _TqdmLoggingHandler() as handler:
            logging.getLogger().addHandler(handler)
            logging.getLogger().addHandler(_TqdmLoggingHandler())
            logging.getLogger().info('test' + str(i))
    ```
    """

# Generated at 2022-06-24 09:49:15.663797
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_log_handler = _TqdmLoggingHandler()
    assert tqdm_log_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:49:25.144259
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # Testing with logger
    loggers = logging.getLogger(__name__)

    # Testing with multiple loggers
    loggers_list = [
        logging.getLogger("tqdm"),
        logging.getLogger("tqdm.contrib.logging"),
        logging.getLogger("logging")
    ]

    # Testing with a single tqdm instance
    actual = []

    def fake_write(s, file=None, end="\n"):
        """Fake tqdm write function."""
        actual.append(s.rstrip())

    # Testing with tqdm list
    def fake_write_list(s, file=None, end="\n"):
        """Fake tqdm write function."""

# Generated at 2022-06-24 09:49:29.967848
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Test constructor of _TqdmLoggingHandler
    try:
        handler = _TqdmLoggingHandler()
    except Exception as exception:
        assert False, (
            'Could not create a handler in _TqdmLoggingHandler:\n{}'
            ''.format(exception)
        )



# Generated at 2022-06-24 09:49:35.165790
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from logging import getLogger
    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = getLogger('test_tqdm_logging_handler')
    logger.handlers = [_TqdmLoggingHandler(tqdm)]
    logger.info('Test 1')

# Generated at 2022-06-24 09:49:45.946976
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    import numpy as np

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        print('Testing tqdm_logging_redirect')
        t0 = time.time()
        with tqdm_logging_redirect(range(9),
                                   logger=LOG,
                                   loggers=[logging.root],
                                   tqdm_class=std_tqdm) as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        t1 = time.time()
        print('It took {} seconds to run'.format(t1-t0))



# Generated at 2022-06-24 09:49:55.247309
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import sys
    import tempfile
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # Create temporary file
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, "temp_log.txt")

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a file handler
    fh = logging.FileHandler(temp_file)

    # Create a console handler
    ch = logging.StreamHandler()

    # Create a formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Generated at 2022-06-24 09:49:56.993684
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm = _TqdmLoggingHandler()
    assert(tqdm.tqdm_class == std_tqdm)

# Generated at 2022-06-24 09:50:01.011254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import tqdm

    tqdm.monitor_interval = 0
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect():
        for _ in range(10):
            logging.info('dummy')
            time.sleep(0.1)



# Generated at 2022-06-24 09:50:06.150097
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    LOG = logging.getLogger(__name__)
    h = _TqdmLoggingHandler()  # type: ignore
    f = logging.Formatter('%(message)s')
    h.setFormatter(f)
    LOG.addHandler(h)
    LOG.info('test')

# Generated at 2022-06-24 09:50:11.904142
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        logger = logging.getLogger()
        logger.handlers = []
        with logging_redirect_tqdm():
            assert len(logger.handlers) == 1
            logging.info('test')
            assert len(logger.handlers) == 1
        assert len(logger.handlers) == 0
    except BaseException:
        raise


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:50:17.243727
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    assert logging.root.handlers  # logging should be set up

    # no_tqdm
    with tqdm_logging_redirect(disable=True) as pbar:
        assert pbar is None
        assert len(logging.root.handlers) == 1  # logging should be unharmed

    # normal tqdm
    with tqdm_logging_redirect() as pbar:
        assert isinstance(pbar, std_tqdm)
        assert len(logging.root.handlers) == 2  # logging should be redirected

    # normal tqdm again
    with tqdm_logging_redirect(disable=False) as pbar:
        assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-24 09:50:20.417526
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig()
    with tqdm_logging_redirect(logging_format="%(message)s"):
        logging.info("test")
    out, err = capsys.readouterr()
    assert out == 'test\n'

# Generated at 2022-06-24 09:50:22.680408
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(handler, _TqdmLoggingHandler)



# Generated at 2022-06-24 09:50:28.283422
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm
    from .tqdm import trange

    with tqdm_logging_redirect(total=3, desc='progress', unit='it',
                               position=0, leave=False):
        for i in trange(3):
            logging.info('Info %d' % i)


__all__ = ["logging_redirect_tqdm", "tqdm_logging_redirect"]
__all__ += ["std_tqdm"]

# Generated at 2022-06-24 09:50:33.679121
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:50:43.598797
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test to check if logging messages are written to tqdm output.
    """
    try:
        stream = sys.stdout
        class_1 = _TqdmLoggingHandler()
        # Check if the stream of logging handler is set to sys.stdout
        check_1 = class_1.stream == stream
        # Check if the stream of logging handler is set to sys.stdout
        check_2 = class_1.tqdm_class == std_tqdm
        assert check_1 and check_2
    except AssertionError:
        print("test_TqdmLoggingHandler: Failed")
        raise
    print("test_TqdmLoggingHandler: Passed")

# Generated at 2022-06-24 09:50:53.440774
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm.utils import _term_move_up
    from .utils import _range

    with tqdm_logging_redirect(
            unit_scale=True,  # type: ignore
            unit='B',
            unit_divisor=1024,
            total=1000,
            leave=False,
            disable=False,
    ) as pbar:
        logging.info('Logger good')
        pbar.set_postfix(
            msg3='A',
            msg4='B',
        )


# Generated at 2022-06-24 09:50:54.512799
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:03.627118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Test: context manager redirecting console logging to `tqdm.write()`, leaving
    other logging handlers (e.g. log files) unaffected.
    """
    import logging
    from contextlib import redirect_stdout
    from io import StringIO
    from tqdm.auto import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # Init logger.
        logging.basicConfig(level=logging.INFO)
        # String buffer to capture output.
        capture = StringIO()

        # Test redirect.

# Generated at 2022-06-24 09:51:04.878891
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.getLogger(__name__).addHandler(_TqdmLoggingHandler())

# Generated at 2022-06-24 09:51:11.537218
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import numpy as np
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    LOOP_COUNT = 100
    with tqdm_logging_redirect(leave=True) as _:
        for i in range(LOOP_COUNT):
            if i == LOOP_COUNT//2:
                logging.info('logging from tqdm')
            np.random.random()

# Generated at 2022-06-24 09:51:18.851910
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler
    """
    from .tests_tqdm import StringIO, closing
    from .tests_tqdm import _range

    my_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert my_handler.tqdm_class is std_tqdm

    with closing(StringIO()) as our_file:
        our_tqdm = std_tqdm(file=our_file, disable=True)
        our_tqdm.write("Hello, world!\n")
        assert our_file.getvalue() == "Hello, world!\n"

        our_tqdm = std_tqdm(file=our_file, disable=False)

# Generated at 2022-06-24 09:51:21.181986
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .tests_tqdm import discretize
    with discretize() as d:  # noqa
        handler = _TqdmLoggingHandler()
        assert handler.stream == d.stdout

# Generated at 2022-06-24 09:51:30.023467
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = None
    tqdm_class = std_tqdm
    # Silently skip unit test if `tqdm` is not installed
    try:
        with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
            pass
    except NameError:
        return
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:40.079348
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    # Generate test output
    sample_output = "\n" + (
        "root     INFO     console logging redirected to `tqdm.write()`\n"
        "root     WARNING  console logging is redirected\n"
        "root     ERROR    console logging is redirected\n"
        "root     CRITICAL console logging is redirected\n")

    # Testing logging_redirect_tqdm()
    tqdm_logger = logging.getLogger('tqdm.logging.test')
    with tqdm_logger.catch_warnings():
        tqdm_logger.setLevel(logging.INFO)

# Generated at 2022-06-24 09:51:46.294249
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    LOG.handlers = []
    assert len(LOG.handlers) == 0

    with logging_redirect_tqdm():
        assert len(LOG.handlers) == 1
        assert _is_console_logging_handler(LOG.handlers[0])
        assert isinstance(LOG.handlers[0], _TqdmLoggingHandler)
    assert len(LOG.handlers) == 0

    with logging_redirect_tqdm():
        LOG.info("test")
    assert len(LOG.handlers) == 0


# Generated at 2022-06-24 09:51:57.629087
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    log = logging.getLogger('test_tqdm_logging_redirect')
    with tqdm_logging_redirect(
            loggers=[log], tqdm_class=std_tqdm, total=10,
            bar_format="{n_fmt}: {rate_fmt:.3f}") as pbar:
        assert isinstance(pbar, std_tqdm)
        assert log.handlers[0]._pbar is pbar
        log.info("test_tqdm_logging_redirect")
        log.handlers[0]._pbar = None
        std_tqdm.write("test_tqdm_logging_redirect")
        assert std_tqdm.get_lock().is_locked()
        pbar.n = 4

# Generated at 2022-06-24 09:52:02.834982
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create a test log record
    testlog = logging.getLogger("TestLog")
    testlog.setLevel(logging.INFO)
    log_msg = "log message"

    # Add the handler to the logger:
    handler = _TqdmLoggingHandler()
    testlog.addHandler(handler)

    # Log a message:
    testlog.info(log_msg) # to "TestLog"

    # Check the order of the records:
    print("msg: " + str(handler.records))

# Generated at 2022-06-24 09:52:12.523574
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, \
        _is_console_logging_handler

    logger = logging.getLogger('mylogger')
    logger.setLevel(logging.DEBUG)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    console.setFormatter(formatter)
    logger.addHandler(console)


# Generated at 2022-06-24 09:52:19.149580
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    root = logging.root
    for handler in root.handlers:
        root.removeHandler(handler)

    LOG = logging.getLogger(__name__ + "_test")
    LOG.setLevel(logging.INFO)
    LOG.propagate = False

    with logging_redirect_tqdm():
        LOG.info('test')

    assert len(root.handlers) == 1
    handler = root.handlers[0]
    assert isinstance(handler, _TqdmLoggingHandler)
    assert handler.stream == sys.stderr

# Generated at 2022-06-24 09:52:26.822017
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from ..std import tqdm
    except ImportError:
        return

    import logging
    LOG = logging.getLogger(__name__)

    def get_logger_handlers():
        """
        Check whether the logging handlers are correctly replaced by
        `logging_redirect_tqdm`.
        """
        return tuple([handler for handler in LOG.handlers
                      if handler.stream in {sys.stdout, sys.stderr}])

    def test_handlers_are_replaced():
        """
        Test whether the handlers are correctly replaced by
        `logging_redirect_tqdm`.
        """
        orig_handlers = get_logger_handlers()
        with tqdm_logging_redirect():
            assert orig_handlers != get_logger_handlers()

# Generated at 2022-06-24 09:52:37.357252
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-24 09:52:45.125622
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    This function is a test that checks that the _TqdmLoggingHandler.emit
    method works as expected. The following assertions are made:

    1. That the input message is printed by the tqdm.write()
    2. That the input message is not printed in the console
    3. That the message passed to the _TqdmLoggingHandler.emit does not
       contain the newline character.
    """
    # Import modules for this function
    import contextlib
    import io
    import logging
    from tqdm.contrib import log

    # Create a context manager redirecting stdout to a string buffer
    @contextlib.contextmanager
    def stdout_to_string():
        output = io.StringIO()  # type: io.StringIO

# Generated at 2022-06-24 09:52:49.149371
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    from io import StringIO
    from contextlib import redirect_stdout
    out = StringIO()
    with redirect_stdout(out):
        with _TqdmLoggingHandler() as handler:
            handler.emit(logging.LogRecord(
                name='Test', level=logging.INFO, pathname='', lineno=0,
                msg='hello\nworld', args=(), exc_info=None))
    assert out.getvalue() == 'hello\nworld'



# Generated at 2022-06-24 09:52:54.481779
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    #pylint: disable=no-member
    assert isinstance(_TqdmLoggingHandler().stream, logging._IOStream)
    # assert _TqdmLoggingHandler().tqdm_class.__name__ == 'tqdm'
    #pylint: enable=no-member

# Generated at 2022-06-24 09:53:05.611485
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    import unittest
    import io
    import sys

    class TestRedirectTqdm(unittest.TestCase):
        def setUp(self):
            self.old_stdout = sys.stdout  # type: ignore
            self.old_stderr = sys.stderr  # type: ignore
            sys.stdout = self.output_stdout = io.StringIO()
            sys.stderr = self.output_stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.old_stdout
            sys.stderr = self.old_stderr

        def test_redirect_log_print(self):
            for i in range(9):
                if i == 4:
                    logging

# Generated at 2022-06-24 09:53:07.182596
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()


# Generated at 2022-06-24 09:53:09.049212
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # stub: _TqdmLoggingHandler.emit
    raise NotImplementedError


# Generated at 2022-06-24 09:53:15.525911
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from . import _TestHandlerBase

    msg = 'Test message'
    record = logging.makeLogRecord({'msg': msg})
    with _TestHandlerBase(_TqdmLoggingHandler()) as handler:
        handler.emit(record)
        assert msg in handler.stream.getvalue()

# Generated at 2022-06-24 09:53:24.072532
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    # clear logger
    logging.root.handlers = []
    # make a dummy logger to testing redirect
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    # check that if loggers argument isn't given,
    # the default logger will be redirected
    with tqdm_logging_redirect():
        LOG.info('tqdm logging redirect')
        assert 'tqdm logging redirect' == sys.stdout.getvalue().rstrip()

    # clear any output
    sys.stdout.truncate(0)
    sys.stdout.seek(0)
    # check that default logger won't be

# Generated at 2022-06-24 09:53:34.309462
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=unused-variable
    import logging
    import sys
    from tqdm.contrib.logging import _TqdmLoggingHandler
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    log = logging.getLogger()
    log.handlers = []
    log.addHandler(_TqdmLoggingHandler())
    log.setLevel(logging.DEBUG)
    msg = "Hello world"
    log.debug(msg)
    # Check if the message has been printed to the stream
    assert sys.stdout.getvalue() == msg
    assert sys.stderr.getvalue() == ""
    sys.stdout = StringIO()
    log.error(msg)
    # Check if the message has been printed to the stream

# Generated at 2022-06-24 09:53:43.991817
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    handler = _TqdmLoggingHandler(tqdm.tqdm)
    assert handler.tqdm_class is tqdm.tqdm
    handler = _TqdmLoggingHandler(tqdm=tqdm.tqdm)
    assert handler.tqdm_class is tqdm.tqdm
    handler = _TqdmLoggingHandler(tqdm.std.tqdm)
    assert handler.tqdm_class is tqdm.std.tqdm
    handler = _TqdmLoggingHandler(tqdm=tqdm.std.tqdm)
    assert handler.tqdm_class is tqdm.std.tqdm

# Generated at 2022-06-24 09:53:51.483710
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test _TqdmLoggingHandler.emit()
    """
    import io
    import logging
    import warnings
    import tqdm.contrib
    import tqdm.contrib.test

    class FakeLogger:
        def __init__(self, stream_string_io, level=logging.DEBUG):
            self.stream_string_io = stream_string_io
            self.level = logging.DEBUG
            self.handlers = []

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        stream = io.StringIO()
        fake_logger = FakeLogger(stream)
        fake_logger.handlers = [_TqdmLoggingHandler()]
        logger = logging.getLogger()
        logger.handlers = fake_logger.handlers

       

# Generated at 2022-06-24 09:54:03.100843
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Unit test"""
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    import mock
    import cStringIO
    # import logging
    import sys

    s = cStringIO.StringIO()
    out = sys.stdout

# Generated at 2022-06-24 09:54:13.981774
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    loggers = [logging.root]
    with tqdm_logging_redirect(
        total=9,
        tqdm_class=std_tqdm,
        loggers=loggers,
        smoothing=0,
        dynamic_ncols=True,
        desc="test",
        disable=False,
        miniters=1,
        mininterval=0,
        maxinterval=10,
        leave=True,
        mininterval=0,
        file=sys.stderr,
    ) as pbar:
        pbar.update(1)
        # logging restored

# Generated at 2022-06-24 09:54:23.634408
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    mock_tqdm = MagicMock()
    mock_pbar = MagicMock(spec=std_tqdm)
    mock_pbar.__enter__.return_value = mock_pbar
    mock_tqdm.return_value = mock_pbar
    mock_tqdm.write = MagicMock()

    mock_logging = MagicMock()
    mock_logger = MagicMock()
    mock_logger.__iter__.return_value = [MagicMock(stream=MagicMock())]
    mock_logging.getLogger.return_value = mock_logger


# Generated at 2022-06-24 09:54:30.658838
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    # Logging (redirected) with tqdm-write :
    for _ in tqdm(range(3), total=3, desc='test_logging_redirect_tqdm'):
        LOG.info('console logging redirected to `tqdm.write()`')
        # Output should look like:
        # test_logging_redirect_tqdm: 100%|####################
        # console logging redirected to `tqdm.write()`| 3/3 [00:00<00:00]

    # Logging (not redirected) without tqdm-write :
    with logging_redirect_tqdm(loggers=[LOG]):
        for i in range(3):
            LOG.info

# Generated at 2022-06-24 09:54:35.134490
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    import sys
    from contextlib import contextmanager
    from contextlib import redirect_stdout
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    test_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    test_handler.setLevel(logging.DEBUG)
    logger.addHandler(test_handler)

    def test(message, stream_expectation,
             exception=None, expected_success=True):
        """
        Test the functionality of method emit of class _TqdmLoggingHandler by
        checking that it writes to the stream as expected.
        """


# Generated at 2022-06-24 09:54:43.907699
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    This test case is a unit test for method emit of class _TqdmLoggingHandler.
    """
    import sys
    import logging
    import StringIO
    import tqdm

    # prepare for unit test
    # set stdout as StringIO for capture output message
    sys.stdout = StringIO.StringIO()

    # test case 1
    # create a logger and set handler as _TqdmLoggingHandler,
    # then handle the message with logging.info
    logger = logging.getLogger('test_emit')
    tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
    logger.addHandler(tqdm_handler)
    logger.info('emit test case 1')

    # check if the output message contains '[emit test case 1]'
    log_content

# Generated at 2022-06-24 09:54:49.826838
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> Any
    from io import StringIO
    import tqdm
    def assert_in(string, seq):
        # type: (str, List[str]) -> None
        for line in seq:
            if string in line:
                return
        assert False, "{} is not in {}".format(string, seq)

    with tqdm.external.tqdm(tqdm.tqdm) as pbar:
        real_stdout = sys.stdout
        stdout = sys.stdout = StringIO()  # type: ignore
        handler = _TqdmLoggingHandler(tqdm_class=pbar.__self__)

# Generated at 2022-06-24 09:54:56.945126
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)



# Generated at 2022-06-24 09:54:59.192957
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pbar = _TqdmLoggingHandler()
    assert isinstance(pbar, logging.StreamHandler)
    

# Generated at 2022-06-24 09:55:05.534011
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    test_logger = logging.getLogger('test_log')
    # Mock StreamHandler.emit() is not necessary
    # pylint: disable=protected-access
    original_handlers = logging.StreamHandler._emit

    def _emit_mock(self, record):
        test_logger.debug("mocked emit", record=record)

    logging.StreamHandler._emit = _emit_mock

    test_logger.debug("before redirect")

    with tqdm_logging_redirect(
            bar_format='{desc:<5.5}{r_bar}',
            loggers=[test_logger],
            desc='test',
            disable=False):
        test_logger.debug("after redirect")

    test_logger.debug("after context close")

   

# Generated at 2022-06-24 09:55:17.064952
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test for redirecting logging to `tqdm.write()`
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    output = []
    tqdm = std_tqdm
    tqdm.write = lambda s: output.append(s)
    handler = logging.StreamHandler(stream=tqdm)

    LOG = logging.getLogger(__name__)

    handlers_orig = LOG.handlers.copy()
    LOG.handlers = [handler]

    # logging redirected
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-24 09:55:28.944413
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import logging
    from tqdm import tqdm
    s = StringIO()
    with tqdm_logging_redirect(total=10, file=s,
                               disable=True,
                               loggers=[logging.getLogger('itertools')]) \
            as pbar:
        pbar.update(3)  # will only show if logging enabled
        logging.getLogger('itertools').info('test')
        pbar.update(7)  # will only show if logging enabled
    assert s.getvalue() == ''
    #
    s = StringIO()

# Generated at 2022-06-24 09:55:31.714042
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test constructor of class _TqdmLoggingHandler."""
    tlh = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(tlh, _TqdmLoggingHandler), \
        "Constructor of class _TqdmLoggingHandler failed."



# Generated at 2022-06-24 09:55:33.801740
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)

# Generated at 2022-06-24 09:55:38.303981
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:55:47.478725
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    import time
    import logging
    from contextlib import contextmanager

    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(self, tqdm_class=std_tqdm):
            super(_TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class

        def emit(self, record):
            try:
                msg = self.format(record)
                self.tqdm_class.write(msg, file=self.stream)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    LOG = logging.getLogger(__name__)

   

# Generated at 2022-06-24 09:55:52.924455
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock  # type: ignore
    mocker = MagicMock()
    mocker.getLogger().handlers = [MagicMock()]
    logging.root.handlers = [MagicMock()]
    original_handlers_list = [logger.handlers for logger in [logging.root]]
    tqdm_class = MagicMock()
    with logging_redirect_tqdm(loggers=[mocker], tqdm_class=tqdm_class):
        pass
    assert mocker.getLogger().called
    assert logging.root.called
    assert tqdm_class.called

# Generated at 2022-06-24 09:55:55.544260
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:55:56.454676
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-24 09:56:04.147485
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    logger = logging.getLogger(__name__)
    stdout = sys.stdout
    sys.stdout = open('test', 'w')
    logging.basicConfig(level=logging.INFO)
    logger.handlers = [_TqdmLoggingHandler()]
    logger.info('Logging message')
    # logger.handlers = [_TqdmLoggingHandler()]
    # logger.info('Logging message')
    logger.handlers = [_TqdmLoggingHandler()]
    logger.info('Logging message')
    sys.stdout.close()
    sys.stdout = stdout
    with open('test', 'r') as h:
        content = h.read()
    assert content == 'Logging message\nLogging message\n'




# Generated at 2022-06-24 09:56:11.309594
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect

    :return:
    """
    import io
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    log = io.StringIO()
    err_log = io.StringIO()
    root_logger = logging.getLogger()
    root_logger.addHandler(logging.StreamHandler(log))
    root_logger.addHandler(logging.StreamHandler(err_log))
    root_logger.setLevel(logging.INFO)

    n = 9
    msg1 = "console logging redirected to `tqdm.write()`"
    msg2 = "resumed logging to console"
    msg3

# Generated at 2022-06-24 09:56:20.735138
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.raiseExceptions = True
    logger = logging.getLogger("test")
    log_formatter = logging.Formatter("%(message)s")
    # See docstring in `tqdm.contrib.logging` for context.
    logger.addFilter(logging.Filter("test"))
    tqdm_class = std_tqdm  # type: Type[std_tqdm]
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    logger.addHandler(tqdm_handler)
    logger.setLevel(logging.INFO)
    #logger.addFilter(logging.Filter("test"))

    for i in range(9):
        if i == 4:
            logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:56:30.467803
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from logging import StreamHandler, Formatter

    _TqdmLoggingHandler(tqdm_class=None)
    lh = logging.StreamHandler()
    lh.setFormatter(Formatter())
    _TqdmLoggingHandler(tqdm_class=None).setFormatter(lh.formatter)

    f1 = _TqdmLoggingHandler(tqdm_class=None).format
    f2 = StreamHandler().format
    assert f1 == f2

    lh = logging.StreamHandler()
    lh.emit(logging.LogRecord('name', 'level', 'pathname', 1, 'msg', (),
                              'exc_info', None))
    # no exceptions

# Generated at 2022-06-24 09:56:33.235239
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import tqdm
    log_handler = _TqdmLoggingHandler(tqdm)
    assert log_handler.tqdm_class == tqdm

# Generated at 2022-06-24 09:56:42.080522
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm


    tqdm_class = tqdm
    # get payload
    payload = 'hello'
    # get logger object via logging package
    log = logging.getLogger("Hello")
    # create handler for _TqdmLoggingHandler
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    # add handler to logger object
    log.addHandler(tqdm_handler)
    # get the only handler in the logger object
    assert len(log.handlers) == 1
    assert log.handlers[0].__class__ == _TqdmLoggingHandler
    # store the handler of the logger object
    handler = log.handlers[0]
    # create another handler for logging.StreamHandler

# Generated at 2022-06-24 09:56:51.361492
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for function tqdm_logging_redirect.
    """
    import logging
    import os

    from .utils import StringIO

    logging.basicConfig(level=logging.INFO)
    orig_stderr = sys.stderr

    # Test logging_redirect_tqdm

# Generated at 2022-06-24 09:56:56.341487
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc='logging redirected to tqdm') as pbar:
        logging.info("Test logging redirected to tqdm")
        pbar.update(1)
        assert pbar.n == 1
        assert pbar.last_print_n == 1
        assert logging.root.handlers[-1].stream == pbar.file

# Generated at 2022-06-24 09:57:07.230970
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from io import StringIO

    class IO(StringIO):
        """
        Inherit StringIO to override write method to avoid writing
        to stdout.
        """

        def write(self, buffer):
            # Write to buffer rather than stdout
            self.buf.write(buffer)

    io = IO()
    logger = logging.getLogger('test_logger')
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:57:14.654566
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert tlh.tqdm_class is std_tqdm
    assert tlh.stream is sys.stderr
    assert tlh.level is logging.NOTSET
    assert tlh.formatter is logging.Formatter('%(message)s')

    class FakeTqdmClass(object):
        @staticmethod
        def write(msg, file=None):
            pass
    #
    tlh = _TqdmLoggingHandler(tqdm_class=FakeTqdmClass)
    assert tlh.tqdm_class is FakeTqdmClass



# Generated at 2022-06-24 09:57:22.885647
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # fake a logging.StreamHandler
    # Cannot use mock as StreamHandler is a final
    class MockLoggingHandler(object):
        stream = None

    tqdm_handler = _TqdmLoggingHandler()
    # test the passing of stream to tqdm_handler
    mock_logging_handler = MockLoggingHandler()
    mock_logging_handler.stream = sys.stderr
    tqdm_handler.__init__(stream=mock_logging_handler.stream)
    assert tqdm_handler.stream == sys.stderr
    # test the passing of a tqdm_class to tqdm_handler
    tqdm_handler.__init__(tqdm_class=std_tqdm)
    assert tqdm_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:57:25.043587
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log_handler = _TqdmLoggingHandler()
    assert isinstance(log_handler, logging.StreamHandler)

# Generated at 2022-06-24 09:57:29.934799
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:57:40.063816
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Test if method `emit` of class `_TqdmLoggingHandler()`
    doesn't have an error with a record of level above warning.
    Example : logging.INFO, logging.DEBUG.
    """
    # test formating a message of level above warning
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname="test", lineno=1,
        msg="test", args=(), exc_info=None, func=None)
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.emit(record)

    # test formating a message of level warning

# Generated at 2022-06-24 09:57:41.982092
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(logging_handler, logging.StreamHandler)



# Generated at 2022-06-24 09:57:49.734519
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    LOG.info("test success")



# Generated at 2022-06-24 09:57:59.236358
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    the_loggers = []
    the_args = []
    the_tqdm = []
    the_kwargs = []

    def tqdm_logging_redirect_mock(loggers=None, tqdm_class=None):
        the_loggers.append(loggers)
        the_tqdm.append(tqdm_class)
        return tqdm_class(**kwargs)

    def tqdm_mock(**kwargs):
        the_kwargs.append(kwargs)
        return mock_tqdm

    args = ['hello', 'world']
    kwargs = {'bar_format': '==={l_bar}==='}
    mock_tqdm = object()

# Generated at 2022-06-24 09:58:09.234047
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .testing import _suppress_stdout_stderr
    from .testing import _discard_tqdm_instance, using_tqdm

    logging.getLogger(__name__).setLevel(logging.INFO)

    with _suppress_stdout_stderr():
        with logging_redirect_tqdm():
            logging.getLogger(__name__).info("This is info 1")
            logging.getLogger(__name__).info("This is info 2")

    logger = logging.getLogger(__name__ + '.test')
    logger.setLevel(logging.INFO)

    with _suppress_stdout_stderr():
        with logging_redirect_tqdm(loggers=[logger]):
            logger.info("This is info 3")

# Generated at 2022-06-24 09:58:16.742632
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    # Redirect stdout to stderr
    sys.stdout = sys.stderr

    tr = std_tqdm(range(9), file=sys.stderr)
    logger = logging.getLogger()
    with tqdm_logging_redirect(loggers=[logger], miniters=1, tqdm_class=std_tqdm) as tr:
        for i in range(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
    try:
        assert std_tqdm.write.has_auto_update
    finally:
        std_tqdm.write.has_auto_update = True

# Generated at 2022-06-24 09:58:26.295399
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test function logging_redirect_tqdm"""
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test_call(log_level, des):
        with logging_redirect_tqdm():
            LOG.log(log_level, des)

    with trange(9) as pbar:
        for i in pbar:
            if i == 4:
                test_call(logging.DEBUG, 'debug level log')
                test_call(logging.INFO, 'info level log')
                test_call(logging.WARNING, 'warning level log')
                test_call(logging.ERROR, 'error level log')

# Generated at 2022-06-24 09:58:35.459333
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect():
        logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:58:40.410286
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Example of using tqdm_logging_redirect
    """
    LOG = logging.getLogger(__name__)
    from tqdm import tqdm

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:44.070395
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.tqdm_class == std_tqdm
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}
