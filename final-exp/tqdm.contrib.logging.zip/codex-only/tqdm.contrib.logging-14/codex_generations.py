

# Generated at 2022-06-24 09:48:47.965135
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange

    @contextmanager
    def render_tqdm(
        n=100,
        desc="test tqdm_logging_redirect",
        unit="it",
        leave=True,
        unit_scale=True,
        disable=False,
        tqdm_class=std_tqdm,
        ascii=None,
        dynamic_ncols=False,
        **kwargs
    ):
        # type: (...) -> Iterator[None]
        kwargs_filtered = {}
        for k, v in kwargs.items():
            if v is not None:
                kwargs_filtered[k] = v

# Generated at 2022-06-24 09:48:56.831132
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import re

    from tqdm import trange

    # Clean up the logging handlers
    LOG = logging.getLogger(__name__)
    LOG.handlers = []

    # Setup the logging handlers
    logging.basicConfig(
        filename='/tmp/logging_redirect_tqdm_test.log',
        filemode='w',
        level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    with open('/tmp/logging_redirect_tqdm_test.log', 'r') as f_in:
        logging_output = f_in.read()


# Generated at 2022-06-24 09:49:06.672952
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # redefine the tqdm.write method:
    class TqdmStub(object):
        write_data = ''
        def write(self, data, file=None):
            self.write_data = data

    tqdm_instance = TqdmStub()

    # create a logging handler, and associate it with tqdm instance
    handler = _TqdmLoggingHandler(tqdm_class=TqdmStub)
    handler.setStream(tqdm_instance)

    # create a logger which uses this logging handler
    logger = logging.getLogger('test_logger')
    logger.addHandler(handler)

    # print log message
    logger.info('Test message')
    assert tqdm_instance.write_data == 'INFO:test_logger:Test message\n'
    tq

# Generated at 2022-06-24 09:49:10.043135
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from . import _TqdmLoggingHandler
    from .std import tqdm
    from .tests_tqdm import with_prog_hook

    tqdm_handler = _TqdmLoggingHandler(tqdm)
    tqdm_handler.setLevel(logging.INFO)
    test_logger = logging.Logger(__name__)
    test_logger.addHandler(tqdm_handler)
    test_logger.setLevel(logging.INFO)

    with with_prog_hook(lambda x: None):
        test_logger.info('test')



# Generated at 2022-06-24 09:49:12.321532
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logHandler=_TqdmLoggingHandler()
    assert isinstance(logHandler, logging.StreamHandler)


# Generated at 2022-06-24 09:49:15.162432
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_log = _TqdmLoggingHandler()
    assert isinstance(tqdm_log, logging.StreamHandler)


# Generated at 2022-06-24 09:49:20.051822
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:49:22.812052
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        _TqdmLoggingHandler(tqdm_class=None)
    except Exception as e:
        assert(1 == 0)
    assert(1 == 1)


# Generated at 2022-06-24 09:49:33.735877
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Unit test for `_TqdmLoggingHandler.emit()`"""
    from tqdm.tests import _range

    class _Tqdm(std_tqdm):
        @staticmethod
        def write(*args, **kwargs):
            pass

    tqdm = _Tqdm()

    handler = _TqdmLoggingHandler(tqdm_class=_Tqdm)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter(
        '%(levelname)s %(asctime)s %(message)s'))

    logger = logging.getLogger('__tmp_test__logging_redirect_tqdm')
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


# Generated at 2022-06-24 09:49:44.694861
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    import tqdm
    from ..std import tqdm as std_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(
            tqdm=tqdm, loggers=[LOG], total=9, desc='redirecting'
    ) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored


# Generated at 2022-06-24 09:49:54.325728
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None

    # initialize logging module
    logging.basicConfig(format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p',
                        level=logging.DEBUG, stream=sys.stdout)
    # get logger
    log = logging.getLogger(__name__)
    log.info('info')
    # test
    tqdm_handler = _TqdmLoggingHandler()
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    tqdm_handler.emit(logging.getLogger().handlers[0].createLock()._RLock__owner)
    sys.stdout = old_std

# Generated at 2022-06-24 09:50:01.878126
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from . import test_tqdm

    with test_tqdm._test_redirect_tqdm(tqdm_logging_redirect, mode='l') as f:
        for i in range(10):
            print(' ', end='')
    assert f.getvalue() == '          \n'
    logger = logging.getLogger('tqdm_logging_redirect')
    logger.setLevel(logging.INFO)
    with test_tqdm._test_redirect_tqdm(tqdm_logging_redirect,
                                       mode='l', loggers=[logger]) as f:
        for i in range(10):
            logger.info('foo')
    assert f.getvalue() == 'foo\n'



# Generated at 2022-06-24 09:50:11.973431
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests the method emit of the class _TqdmLoggingHandler.
    """
    from .test_utils import CountCalls, CustomTqdm
    # Create handler
    handler = _TqdmLoggingHandler(tqdm_class=CustomTqdm)
    # Create mockup emit function
    emit_mockup = CountCalls(handler.emit)
    # Replace emit function of the handler
    handler.emit = emit_mockup
    # Create logger
    logger = logging.getLogger(__name__)
    logger.addHandler(handler)
    # Create mockup logger error function
    logger_error_mockup = CountCalls(logger.error)
    # Replace error function of the logger
    logger.error = logger_error_mockup
    # Raise logger error
    logger

# Generated at 2022-06-24 09:50:13.655808
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = None  # type: Optional[List[logging.Logger]]
    with tqdm_logging_redirect() as pbar:
        pbar.write("test")

# Generated at 2022-06-24 09:50:15.326914
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    TqdmLoggingHandler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:50:24.258149
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test if logging is redirected or not
    """
    import logging
    from trange import trange

    logger = logging.getLogger()
    tqdm_handler = _get_first_found_console_logging_handler(logger.handlers)
    original_handlers = logger.handlers
    assert (_is_console_logging_handler(tqdm_handler) is False)

    with logging_redirect_tqdm():
        for loop in trange(1):
            logger = logging.getLogger()
            tqdm_handler = _get_first_found_console_logging_handler(logger.handlers)
            assert (_is_console_logging_handler(tqdm_handler) is True)

    logger = logging.getLogger()

# Generated at 2022-06-24 09:50:29.164072
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord('name', 'DEBUG', 'file', 1, 'message', None, None, None)

    try:
        with std_tqdm.external_write_mode():
            handler.emit(record)
    except:  # noqa pylint: disable=bare-except
        assert False, 'Uncaught exception in test'
    else:
        assert True

# Generated at 2022-06-24 09:50:38.697525
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging

    old_stdout = sys.stdout
    sys.stdout = StringIO()
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.debug("This is debug")
    logger.info("This is info")
    logger.warning("This is warning")
    logger.error("This is error")
    logger.critical("This is critical")
    sys.stdout.seek(0)
    file_content = sys.stdout.read()
    sys.stdout = old_stdout
    assert 'This is debug' in file_content
    assert 'This is info' in file_content
    assert 'This is warning' in file_content

# Generated at 2022-06-24 09:50:40.725528
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert isinstance(tlh, logging.StreamHandler)

# Generated at 2022-06-24 09:50:50.202136
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import sys
    import logging

    # Dummy logger
    dummy_stream = StringIO()  # type: ignore
    logger = logging.getLogger("dummy_logger")
    logger.addHandler(logging.StreamHandler(stream=dummy_stream))

    # Normal output
    print("Test normal output:")
    logger.info("Test message")
    print("--- Expected:")
    print("--- Test message")
    print("--- Actual:")
    print("--- {}".format(dummy_stream.getvalue()))

    # tqdm output
    dummy_stream.truncate(0)
    print("Test tqdm output:")
    with tqdm_logging_redirect():
        logger.info("Test message")
    print("--- Expected:")
   

# Generated at 2022-06-24 09:50:59.473786
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # convenience shortcut:
    with tqdm_logging_redirect(leave=False):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:04.324726
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s : %(levelname)s : %(message)s',
        datefmt='%m/%d/%Y %I:%M:%S %p')
    handler = _TqdmLoggingHandler()
    logging.info("Hello World!")

# Unit tests for function logging_redirect_tqdm()

# Generated at 2022-06-24 09:51:13.732410
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # pylint: disable=redefined-outer-name
    logger = logging.getLogger('TEST')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logger.propagate = False
    # pylint: enable=redefined-outer-name

    logger.debug('test_tqdm_logging_redirect: debug')
    logger.info('test_tqdm_logging_redirect: info')
    logger.warning('test_tqdm_logging_redirect: warning')
    logger.error('test_tqdm_logging_redirect: error')
    logger.critical('test_tqdm_logging_redirect: critical')


# Generated at 2022-06-24 09:51:20.147024
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import unittest.mock as mock  # python 3.3+
    except ImportError:
        import mock  # type: ignore
    import logging

    _mock_tqdm_write = mock.MagicMock()

    class _MockTqdm:
        write = _mock_tqdm_write

    _TqdmLoggingHandler(_MockTqdm).emit(logging.getLogger('test').info('test'))
    _mock_tqdm_write.assert_called_with('test\n', file=sys.stderr)


# Generated at 2022-06-24 09:51:29.400754
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    import tqdm
    import logging

    logging.basicConfig()
    logger = logging.getLogger('_TqdmLoggingHandler')
    logger.setLevel(logging.DEBUG)

    # Implementing a custom tqdm class to log the written message
    class MyTqdm(tqdm.std.tqdm):
        def __init__(self, *args, **kwargs):
            super(MyTqdm, self).__init__(*args, **kwargs)
            self.messages = []  # type: List[str]

        def write(self, message, file=None):
            self.messages.append(message)
            super(MyTqdm, self).write(message, file=file)

    # Instanciating a handler with a custom tqdm class

# Generated at 2022-06-24 09:51:34.101216
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr

    class TestTqdm(std_tqdm):
        pass

    handler = _TqdmLoggingHandler(tqdm_class=TestTqdm)
    assert handler.stream == sys.stderr


# Generated at 2022-06-24 09:51:42.708840
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    tqdm_instance = std_tqdm()
    tqdm_instance.file = StringIO()
    handler = _TqdmLoggingHandler(tqdm_instance)
    handler.emit(logging.LogRecord('name', logging.DEBUG, None, 0,
                                   'msg', None, None))
    out = tqdm_instance.file.getvalue()
    assert out == 'msg\n'
    #
    tqdm_instance.file = StringIO()
    handler.emit(logging.LogRecord('name', logging.INFO, None, 0,
                                   'msg', None, None))
    out = tqdm_instance.file.getvalue()
    assert out == 'msg\n'
    #
    tqdm_instance.file = StringIO()

# Generated at 2022-06-24 09:51:51.734538
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger('tqdm_logging_redirect')
    with tqdm_logging_redirect() as pbar:
        logger.info('test')
        pbar.write('test!')


if __name__ == '__main__':
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.getcwd())))


# Generated at 2022-06-24 09:51:55.837850
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Unit test for _TqdmLoggingHandler.emit"""
    from pytests.contrib.logging import _FakeTqdm
    from pytests.contrib import _StdStreamCapturer

    class _FakeRecord(object):
        """Fake logging.LogRecord"""
        pass

    record = _FakeRecord()
    record.msg = 'FakeRecord'
    record.args = ()
    record.levelname = 'INFO'
    record.exc_info = None
    record.exc_text = None
    record.stack_info = None

    with _StdStreamCapturer() as streams:
        tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=_FakeTqdm)
        tqdm_logging_handler.emit(record)

# Generated at 2022-06-24 09:52:02.566486
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import logging

    handler = _TqdmLoggingHandler(std_tqdm)
    handler.setFormatter(logging.Formatter(u'%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

    out = io.StringIO()
    handler.stream = out

    logging.getLogger().addHandler(handler)

    logging.getLogger().setLevel(logging.DEBUG)
    logging.debug('test')
    assert out.getvalue() == 'test\n'

    logging.getLogger().removeHandler(handler)

# Generated at 2022-06-24 09:52:10.066127
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange

        logging.basicConfig(level=logging.DEBUG)
        with logging_redirect_tqdm():
            for _ in trange(2):
                logging.debug("foo")
                logging.info("bar")
                logging.warning("baz")
                logging.error("boo")
    except Exception as e:
        raise type(e)(e.message +
                      "\n(unit tests crash with Python 2, which is expected)")


del sys
del logging

# Generated at 2022-06-24 09:52:20.026136
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create mock for StreamHandler and tqdm
    class Mock(dict):
        def __init__(self):
            self.__dict__ = self
            self.counter = 0
        def write(self, msg, file=None):
            self['write_' + str(self.counter)] = msg
            self.counter += 1
        def flush(self):
            pass
    stream = Mock()
    handler = _TqdmLoggingHandler(tqdm_class=Mock)
    handler.stream = stream

    # do not check exception
    handler.emit('test_msg_no_exception')
    assert stream['write_0'] == 'test_msg_no_exception'
    assert len(stream) == 1

    # check KeyboardInterrupt
    with pytest.raises(KeyboardInterrupt):
        handler

# Generated at 2022-06-24 09:52:25.067472
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    test_file_stream = tempfile.TemporaryFile(mode='w+')
    logging_handler = _TqdmLoggingHandler(std_tqdm)
    logging_handler.setFormatter(logging.Formatter('%(message)s'))
    logging_handler.stream = test_file_stream
    logging_handler.emit(logging.LogRecord('name', logging.INFO, 'pathname', 0, 'msg', (), None))

# Generated at 2022-06-24 09:52:33.077278
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from StringIO import StringIO
    from sys import stdout
    old_stdout = stdout
    stdout = StringIO()
    try:
        log = logging.getLogger()
        log.setLevel(logging.INFO)
        handler = _TqdmLoggingHandler()
        log.addHandler(handler)
        log.info("TEST")
        stdout.seek(0)
        res = stdout.read()
        assert res == "TEST\n"
    finally:
        stdout = old_stdout

test__TqdmLoggingHandler_emit()

# Generated at 2022-06-24 09:52:41.729892
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    LOG.addHandler(console_handler)

    with logging_redirect_tqdm():
        with trange(9) as t:
            for i in t:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:52:46.346907
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import tqdm
    from tqdm.contrib import logging as contrib_logging

    h = contrib_logging._TqdmLoggingHandler(tqdm_class = tqdm)
    assert isinstance (h, logging.StreamHandler)


# Generated at 2022-06-24 09:52:50.774712
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    example_log_message = "a log message"
    for logger_name in ["tqdm", "tqdm.contrib.logging"]:
        with StringIO() as capture_stream:
            logger = logging.getLogger(logger_name)
            logger.setLevel(logging.INFO)
            tqdm_handler = _TqdmLoggingHandler()
            tqdm_handler.stream = capture_stream
            logger.addHandler(tqdm_handler)
            logger.info(example_log_message)

            assert capture_stream.getvalue() == example_log_message + "\n"



# Generated at 2022-06-24 09:52:58.382932
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect('test'):
        logging.debug('test')

# Generated at 2022-06-24 09:53:04.732122
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    class FakeTqdm(object):
        def __init__(self):
            self.buf = StringIO()

        def write(self, msg, file=None):  # pylint: disable=unused-argument
            self.buf.write(msg)
            self.buf.write('\n')

        def flush(self):  # pylint: disable=no-self-use
            return

    fake_tqdm = FakeTqdm()
    formatter = logging.Formatter('[%(levelname)s] %(message)s')
    handler = _TqdmLoggingHandler(fake_tqdm)
    handler.setFormatter(formatter)

    fake_logger = logging.Logger('TEST')
    fake_logger.addHandler(handler)

    fake

# Generated at 2022-06-24 09:53:08.227922
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    std_tqdm.write('TEST', file=sys.stdout)
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:53:13.887617
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import tqdm
    import logging

    with logging_redirect_tqdm([logging.root]):  # Using tqdm.write
        logging.info("testing logging redirect tqdm")

    loggers = [logging.getLogger(__name__)]
    with tqdm.std.tqdm(
            desc='testing with tqdm_logging_redirect',
            total=2) as pbar:
        with tqdm_logging_redirect(
                loggers=loggers, tqdm_class=tqdm.std.tqdm):
            logging.info("testing tqdm_logging_redirect")
            pbar.update()
            logging.info("testing tqdm_logging_redirect")
            pbar.update()

# Generated at 2022-06-24 09:53:19.158092
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm() as pbar:
        for i in range(10):
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-24 09:53:23.401920
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG.info("foo")


# Generated at 2022-06-24 09:53:33.852895
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit tests for interop with stdlib `logging` module
    """
    # prints "hello world" on screen
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    # logger = logging.root
    with logging_redirect_tqdm():
        # with tqdm_logging_redirect():
        s = "hello"
        for i in range(5):
            s += " world"
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("logging restored")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:53:34.818218
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:53:36.042867
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:53:46.397049
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.utils import _term_move_up
    from tqdm.std import tqdm
    from .test_tqdm import check_html_rendering

    with tqdm_logging_redirect(redirect_stdout=True) as pbar:
        for _ in range(8):
            logging.error('foo')
            pbar.update(10)
            pbar.refresh()

    assert pbar.desc == 'foo'
    assert pbar.total == 100
    assert pbar.pos == 80
    check_html_rendering(pbar)
    assert _term_move_up() + '\x1b[2A'

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:53:51.703340
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..main import tqdm
    from .bar_template import ALL_CLS_DYN_KWARGS

    for t in list(ALL_CLS_DYN_KWARGS.keys())[:3]:
        with tqdm_logging_redirect(tqdm_class=t) as pbar:
            pbar  # noqa

# Generated at 2022-06-24 09:53:57.151077
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.DEBUG)
    record = logging.LogRecord(
        name='foo', level=logging.DEBUG, pathname='bar', lineno=0,
        msg='foobarbaz', args=(), exc_info=None)
    handler.emit(record)

# Generated at 2022-06-24 09:54:03.686645
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    # with tqdm_logging_redirect():
    #     LOG.info("hello world")

    with tqdm_logging_redirect(total=9, desc="1st tqdm", loggers=[LOG],
                               tqdm_class=std_tqdm) as pbar:
        for _ in trange(9):
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()
            pbar.refresh()

# Generated at 2022-06-24 09:54:09.877977
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    try:
        import mock  # type: ignore
    except ImportError:
        return

    logger = logging.getLogger(__name__)
    with mock.patch('tqdm.contrib.logging.tqdm_notebook') as mock_tqdm_notebook:
        mock_tqdm = mock.Mock()
        mock_tqdm_notebook.return_value = mock_tqdm
        with tqdm_logging_redirect(tqdm_class=mock_tqdm_notebook, desc='UnitTest'):
            logger.info("console logging redirected to `tqdm.write()`")
            assert mock_tqdm.write.called


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:54:15.279231
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class dummy_tqdm(object):
        @staticmethod
        def write(output, file):
            pass
    tqdm_logging_handler = _TqdmLoggingHandler(dummy_tqdm)
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)

# Generated at 2022-06-24 09:54:21.742720
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    try:
        from StringIO import StringIO  # Python 2 compat
    except ImportError:
        from io import StringIO

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with StringIO() as io:
            sys.stdout = io  # type: ignore

            with tqdm_logging_redirect(total=10) as pbar:
                for _ in pbar:
                    if _ == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

            assert "console logging redirected to `tqdm.write()`" in io.getvalue()

            sys.stdout = sys.__stdout__  # type

# Generated at 2022-06-24 09:54:23.045726
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler() is not None

# Generated at 2022-06-24 09:54:30.083036
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_message = "test message"
    test_message_2 = "test message 2"
    test_message_3 = "test message 3"
    logger = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    # No error for normal logging
    logger.info(test_message)
    assert handler.tqdm_class.write.call_args[0][1] == sys.stderr

    # Normal message when a KeyboardInterrupt is raised
    try:
        raise KeyboardInterrupt
    except KeyboardInterrupt:
        logger.exception(test_message_2, exc_info=True)

# Generated at 2022-06-24 09:54:31.902042
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    _TqdmLoggingHandler(tqdm_class)

# Generated at 2022-06-24 09:54:37.660164
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=10, desc="Logging to tqdm.write()") as pbar:
            for i in pbar:
                if i == 5:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:54:44.860331
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    write_stream = sys.stdout
    tqdm_cls = _TqdmLoggingHandler(tqdm_class=write_stream)
    test_msg = "Test Message"
    try:
        tqdm_cls.emit(test_msg)
        # This test case was failing on k20x nodes.
        # It appears that logging.StreamHandler.emit() calls
        #  for record in map(self.format, args):
        # Apparently it does not loop over the args with the given format (a string)
        # But rather it expects a log record object.
        assert True
    except:
        assert False


# Generated at 2022-06-24 09:54:45.285614
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    pass

# Generated at 2022-06-24 09:54:45.936072
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:54:53.780156
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    i = 0
    with tqdm_logging_redirect(total=9) as pbar:
        LOG = logging.getLogger(__name__)
        for pbar in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
            i += 1

# Generated at 2022-06-24 09:55:01.392833
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging as lo
    output = StringIO()

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=lambda: None)
    tqdm_handler.stream = output
    tqdm_handler.emit(
        lo.LogRecord(
            name='__name__',
            level=lo.INFO,
            fn='__file__',
            lno='__line__',
            msg='test_msg',
            args=(1, 2, 3),
            exc_info=(None, None, None),
            func='__func__'))
    assert output.getvalue() == 'test_msg'

    output.close()

# Generated at 2022-06-24 09:55:11.158394
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class Tqdm(std_tqdm):
        def write(self, str_):
            self.msg = str_
            self.close()

    handler = _TqdmLoggingHandler(tqdm_class=Tqdm)
    # use a Tqdm instance as a file stream
    handler.stream = Tqdm()
    # write a log message
    handler.emit(logging.LogRecord("testlogger", logging.INFO, "__test__",
                                   1, "test message", None, None))
    # test message written
    assert handler.stream.msg == "test message\n"
    # close the stream
    handler.stream.close()



# Generated at 2022-06-24 09:55:23.709033
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tests_tqdm import with_unit_option, _test_write
    class _TqdmFake(std_tqdm):
        def __init__(self):
            self._write_yield = False

        def write(self, s, file=None, end="\n", nolock=False):
            if self._write_yield:
                self._write_yield = not self._write_yield
                yield 1

        def set_description(self, desc=None, refresh=True):
            pass

    def test_emit():
        # type: () -> None
        tqdm_fake = _TqdmFake()  # type: _TqdmFake
        tqdm_fake._write_yield = True

# Generated at 2022-06-24 09:55:29.954692
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Patch stdout of sys module to write to log_msg string
    import tqdm.contrib.logging
    old_stdout = sys.stdout
    log_msg = ""

    class StringIO(object):
        def write(self, msg):
            global log_msg  # pylint: disable=global-statement
            log_msg += msg

        def flush(self):
            pass
    sys.stdout = StringIO()

    logging.info("test")

    # Restore original stdout of sys module
    sys.stdout = old_stdout

    # Check for expected string
    assert "test" in log_msg

# Generated at 2022-06-24 09:55:37.039402
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys

    capturer = io.StringIO()
    sys.stdout = capturer

    tqdm_logging_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        'tqdm', logging.INFO, os.path.realpath(__file__), 100, 'logging message', [], None)

    tqdm_logging_handler.emit(record)
    output = capturer.getvalue()[:26]

    sys.stdout = sys.__stdout__
    assert output == 'logging message\n  0%|          | 0/1 [00:00<?, ?it/s]\n'

# Generated at 2022-06-24 09:55:46.715388
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import io

    def logging_write_test(handler):
        handler.stream = io.StringIO()
        handler.emit(logging.LogRecord(
            name="logging_write_test",
            level=logging.INFO,
            pathname="foo.py",
            lineno=42,
            msg="hello",
            args=(),
            exc_info=None,
        ))
        return handler.stream.getvalue()

    with tempfile.TemporaryFile(mode="w+t") as f:
        handler_out_file = logging.StreamHandler(stream=f)
        assert logging_write_test(handler_out_file) == "hello\n"

        handler_tqdm = _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:55:52.645535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:56:00.519089
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # import tqdm

    log = logging.getLogger('test')
    log.addHandler(logging.StreamHandler())
    log.setLevel(logging.INFO)
    log.info('log1')

    with logging_redirect_tqdm():
        log.info('log2')

        from tqdm import tqdm

        pbar = tqdm(total=100)

        for i in range(10):
            log.info('log %d' % i)
            pbar.update()

        pbar.close()

    log.info('log3')


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:56:06.581684
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO

    stream = StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = stream

    logger = logging.getLogger(__name__ + 'test_emit')
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    logger.info("test")

    handler.flush()

    assert stream.getvalue() == "\ntest\n"
    return 0

# Generated at 2022-06-24 09:56:15.584146
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import logging

    # Create a temporary file
    f = tempfile.TemporaryFile()

    # Create a handler for this file
    my_handler = _TqdmLoggingHandler()
    my_handler.stream = f

    # Create a logger
    logger = logging.getLogger()
    logger.addHandler(my_handler)

    # Log something
    logger.info("This is a test")

    # Reset the file stream
    f.seek(0)

    # Read the log message from the file stream
    log_msg = f.read()

    f.close()

    # Delete the content of the file stream
    f.truncate(0)

    return log_msg

# Generated at 2022-06-24 09:56:20.230812
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    with tqdm_logging_redirect(total=9, bar_format='{postfix} {pbar} {rate_fmt}'):
        for i in trange(9):
            if i == 4:
                logging.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-24 09:56:30.658580
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    filename = 'test__TqdmLoggingHandler.txt'
    logging.basicConfig(level=logging.INFO, filename=filename)
    logger = logging.getLogger(__name__)
    logger.info('test logging redirect')
    with open(filename, 'r') as f:
        assert (f.readlines() == ['test logging redirect\n'])
        assert len(f.readlines()) == 1
    with open(filename, 'w'):
        pass  # erase file
    logger.info('test logging redirect')
    with open(filename, 'r') as f:
        assert (f.readlines() == ['test logging redirect\n'])
        assert len(f.readlines()) == 1



# Generated at 2022-06-24 09:56:36.143320
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("console logging restored to a console")

# Generated at 2022-06-24 09:56:44.950139
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from StringIO import StringIO  # python2
        from contextlib import closing
        from io import BytesIO as StringIO
        from contextlib import redirect_stderr, redirect_stdout
    except ImportError:
        from io import StringIO  # python3
        from contextlib import redirect_stderr, redirect_stdout
    import logging
    import os
    from .tqdm_gui import tqdm

    def create_logger(name, level=logging.DEBUG):
        """Create a logger instance."""
        lgr = logging.getLogger(name)
        lgr.setLevel(level)
        return lgr

    LOG = create_logger('test_tqdm_logging_redirect logger')


# Generated at 2022-06-24 09:56:54.138205
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import sys

    if sys.version_info[:2] <= (2, 6):
        return

    # Set up logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # Create handler
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    # create formatter and add it to the handlers
    formatter = logging.Formatter(
        '%(asctime)s :: %(levelname)s :: %(message)s')
    handler.setFormatter(formatter)
    # add the handlers to the logger
    logger.addHandler(handler)

    output = []

# Generated at 2022-06-24 09:57:01.112044
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test that logging to root redirects to tqdm"""
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in pbar:
            if i == 4:
                LOG = logging.getLogger()  # root logger
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:08.016577
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    stream = StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = stream
    handler.setFormatter(logging.Formatter('%(message)s'))
    record = logging.LogRecord(
        name='test', level=logging.INFO, pathname='/a/b/c', lineno=1,
        msg='test message', args=(), exc_info=None)
    handler.emit(record)
    assert (stream.getvalue() == 'test message\n')

# Generated at 2022-06-24 09:57:14.798618
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    >>> import logging
    >>> logging.basicConfig(level=logging.INFO)
    >>> logger = logging.getLogger(__name__)
    >>> with tqdm_logging_redirect(desc='foobar', total=9, smoothing=0) as pbar:
    ...     for i in range(9):
    ...         pbar.update()
    ...         if i == 4:
    ...             logger.info('Python logging redirected to `pbar.write()`')
    [foobar] 100%|#####################| 9/9
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 09:57:17.625174
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig()
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm([LOG]):
        LOG.info('test')

# Generated at 2022-06-24 09:57:25.168957
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import unittest
    import io

    handler = _TqdmLoggingHandler()
    handler.stream = io.StringIO()
    logging.error("test")

    class TestCase(unittest.TestCase):
        def test_emit(self):
            record = logging.LogRecord(
                name='test', level=logging.WARNING,
                pathname='test.py',
                lineno=1, msg='test',
                args=(),
                exc_info=None)
            assert handler.emit(record) is None
            assert handler.stream.getvalue() == 'test\n'
            
    unittest.main()


# Generated at 2022-06-24 09:57:31.683351
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO
    import tqdm.std as std_tqdm
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    io_stream = StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = io_stream
    logger.addHandler(handler)
    logger.info("Hello World!")
    assert io_stream.getvalue() == "Hello World!"
    logger.removeHandler(handler)

# Generated at 2022-06-24 09:57:42.325328
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    logger = logging.getLogger(__name__)

    # Test if context manager redirects console logging to `tqdm.write()`
    with patch("sys.stdout") as mock_stdout:
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")

    # Test if console logging is restored after using the context manager
    with patch("sys.stdout") as mock_stdout:
        for i in trange(9):
            if i == 4:
                logger.info("console logging restored")

# Generated at 2022-06-24 09:57:47.446023
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        for i in range(100):
            if i == 20:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-24 09:57:56.880584
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys

    def redirect_stdout():
        return sys.stdout, sys.stdout.fileno(), io.TextIOWrapper(io.StringIO(), sys.stdout.encoding, 'replace'), \
               sys.stderr, sys.stderr.fileno(), io.TextIOWrapper(io.StringIO(), sys.stderr.encoding, 'replace')

    # save original stdout and stderr
    original_stdout, original_stdout_fd, stdout, original_stderr, original_stderr_fd, stderr = redirect_stdout()

    record = logging.LogRecord("name", "INFO", "/tmp", 1, "message", args=(), exc_info=None)
    tqdm_logger = _TqdmLogging

# Generated at 2022-06-24 09:57:58.481386
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    
test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:58:08.447131
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import time
    import threading
    import logging
    s = time.time()
    with tqdm_logging_redirect() as pbar:
        with tqdm.std.tqdm(total=1) as subpbar:
            logging.info("bar")
            time.sleep(1)
            subpbar.update(1)
            logging.info("baz")
    # custom loggers
    loggers = [logging.getLogger("logger1"), logging.getLogger("logger2")]
    for logger in loggers:
        logger.info("bar")
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        for logger in loggers:
            logger.info("baz")
    # custom tqdm

# Generated at 2022-06-24 09:58:16.842338
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.contrib.logging._tqdm_logging import _TqdmLoggingHandler
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    record = logging.LogRecord(
        name='logger',
        level=logging.INFO,
        pathname='/tmp/foo.py',
        lineno=42,
        msg='foo',
        args=None,
        exc_info=None)
    expected = 'foo\n'
    stream = StringIO()
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.stream = stream
    tqdm_handler.emit(record)
    assert expected == stream.getvalue()

    stream = StringIO()
   

# Generated at 2022-06-24 09:58:21.714411
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    import sys

    with StringIO() as buf:
        with redirect_stdout(buf):
            with logging_redirect_tqdm():
                logging.root.error("test")
            sys.stdout.write("stdout")
        assert "test" in buf.getvalue()
        assert "stdout" in buf.getvalue()

# Generated at 2022-06-24 09:58:27.213021
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:58:34.360221
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(
            total=10,
            file=sys.stdout,  # for testing, needs to be None
            ascii=True
    ) as pbar:
        assert isinstance(pbar, std_tqdm)
        for i in range(10):
            pbar.update(1)
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:58:38.741311
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    with tqdm_logging_redirect(tqdm_class=tqdm, total=1) as pbar:
        assert pbar.total == 1

# Generated at 2022-06-24 09:58:39.658017
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-24 09:58:44.926410
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    import io

    iostream = io.StringIO()
    handler.set_tqdm_output_file(iostream)
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    logger.info('foobar')
    assert iostream.getvalue() == 'foobar\n'