

# Generated at 2022-06-24 09:48:56.499221
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from .std import trange
    from .logging import logging_redirect_tqdm
    from .logging import tqdm_logging_redirect as tqdm_logging_redirect_

    LOG = logging.getLogger(__name__)

    # run without exception raised
    with tqdm_logging_redirect_():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:48:58.394463
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pass


# Generated at 2022-06-24 09:49:05.325909
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    with tqdm_logging_redirect(
        total=3, desc='TqdmLoggingRedirect',
        bar_format=r'{desc}: {n:>3}/{total:<3} {percentage:3.0f}%  '
                   r'[{bar}{postfix}]'
    ) as pbar:
        pbar.set_postfix_str('postfix')
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.update()



# Generated at 2022-06-24 09:49:12.595502
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.captureWarnings(True)

# Generated at 2022-06-24 09:49:23.023475
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function `tqdm_logging_redirect()`.
    """
    import logging
    import sys

    try:
        import mock
    except ImportError:
        from unittest import mock

    class FakeLogger(logging.Logger):
        def __init__(self):
            # type: () -> None
            self.handlers = []

    fake_logger = FakeLogger()

    with mock.patch('sys.stdout', new=mock.Mock()) as stdout:
        with logging_redirect_tqdm([fake_logger]):
            logging.info('redirected to tqdm.write()')
        assert stdout.write.call_count == 2

# Generated at 2022-06-24 09:49:25.003249
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = _TqdmLoggingHandler()
    assert(tqdm_class is not None)


# Generated at 2022-06-24 09:49:29.416388
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.root]
    with tqdm_logging_redirect(loggers=loggers):
        LOG = logging.getLogger(__name__)
        LOG.info("Logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:49:33.261140
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class_var = type('', (), {})()
    class_var.write = lambda x, y: None
    _TqdmLoggingHandler(tqdm_class=class_var)



# Generated at 2022-06-24 09:49:39.431524
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    import logging
    from ..std import tqdm
    out = StringIO()
    logger = logging.getLogger('Test')
    logger.setLevel(logging.INFO)
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.setFormatter(
        logging.Formatter('[%(levelname)s]: %(message)s')
    )
    handler.stream = out
    logger.addHandler(handler)
    logger.info("Hello World")
    assert out.getvalue() == "[INFO]: Hello World\n"
    out.close()



# Generated at 2022-06-24 09:49:42.777935
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    logging.basicConfig()
    logger = logging.getLogger()
    th = _TqdmLoggingHandler()
    logger.addHandler(th)
    logger.info("foo")

# Generated at 2022-06-24 09:49:52.356588
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    def log_test(log_file):
        # type: (Optional[TextIO]) -> None
        root_logger = logging.getLogger(__name__)
        root_logger.setLevel(logging.INFO)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        if log_file:
            file_handler = logging.FileHandler(log_file)
        else:
            file_handler = logging.StreamHandler()
        root_logger.addHandler(file_handler)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)


# Generated at 2022-06-24 09:49:54.880855
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    # handler.stream = sys.stdout
    record = logging.makeLogRecord({'msg': 'test'})
    handler.emit(record)

# Generated at 2022-06-24 09:50:02.534060
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    if sys.version_info >= (3, 4):
        # The following testcase is not well designed:
        # the logging message is not output in the try-except block as intended.
        # It is unclear how to fix it and at the moment we keep the code as it
        # is in order to avoid breaking the users' code.
        return

    logger = logging.getLogger(__name__)
    original_handlers = logger.handlers

# Generated at 2022-06-24 09:50:12.530706
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import sys
    import tqdm

    tqdm_write_handler = _TqdmLoggingHandler()

    # Normal case
    f = StringIO()
    sys.stdout = f
    tqdm_write_handler.emit('Hello World!')
    f.seek(0)
    assert f.read() == 'Hello World!'
    f.close()

    # Test flushing
    f = StringIO()
    sys.stdout = f
    tqdm_write_handler.stream = f
    tqdm_write_handler.emit('Hello World!')
    f.seek(0)
    assert f.read() == 'Hello World!'
    f.close()

    # Test flushing of tqdm
    f = StringIO()
    sys.stdout = f

# Generated at 2022-06-24 09:50:14.882740
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler


# Generated at 2022-06-24 09:50:24.015832
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Unit test for method emit of class _TqdmLoggingHandler

    It uses the pytest module.
    """
    import mock
    from .tstclass import FakeTqdmFile

    mock_file = mock.MagicMock(wraps=FakeTqdmFile())
    mock_record = mock.MagicMock()

    # The test object
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = mock_file

    tqdm_logging_handler.emit(mock_record)

    mock_file.write.assert_called_once_with(mock.ANY, file=mock.ANY)
    mock_file.flush.assert_called_once()



# Generated at 2022-06-24 09:50:28.944725
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm

    # Create an in-memory stream
    stream = StringIO()
    th = _TqdmLoggingHandler(tqdm_class=tqdm)
    th.stream = stream

    r = logging.makeLogRecord({'msg': 'Hello'})
    th.emit(r)

    assert stream.getvalue() == '| Hello\n'



# Generated at 2022-06-24 09:50:38.472264
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    # Monkey patch `tqdm.std.tqdm.write()` to return its keyword argument `bar`
    write_save = std_tqdm.write
    tqdm_bar = []

# Generated at 2022-06-24 09:50:40.861680
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging

    def main():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")

    main()

# Generated at 2022-06-24 09:50:50.331442
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm import tqdm  # pylint: disable=unused-import
    import logging

    # Unit test for function logging_redirect_tqdm
    def test_logging_redirect_tqdm(capsys):
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            logging.getLogger().info('print')
        out, _ = capsys.readouterr()
        assert out == 'print\n'

    # Unit test for context manager logging_redirect_tqdm
    def test_logging_redirect_tqdm_cm(capsys):
        with logging_redirect_tqdm(), tqdm(total=9) as pbar:
            logging.getLogger().info('print')
        out, _ = caps

# Generated at 2022-06-24 09:50:57.441911
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger(__name__)]
    def _(level):
        for g in ["red", "green", "blue", "cyan", "yellow", "black"]:
            logging.log(level, "It is a %s car.", g)
    with tqdm_logging_redirect(loggers=loggers):
        _(logging.ERROR)
        _(logging.WARNING)
        _(logging.INFO)
        _(logging.DEBUG)
    _(logging.CRITICAL)

# Generated at 2022-06-24 09:51:02.965265
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(ncols=50) as pbar:
        LOG = logging.getLogger(__name__)
        for _ in range(10):
            LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update()

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:51:12.519506
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    def test_logging_handlers(tqdm_class):
        LOG = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        with tqdm_class(leave=False, desc='with logging_redirect_tqdm',
                        dynamic_ncols=True) as pbar:
            with logging_redirect_tqdm([LOG], tqdm_class=tqdm_class):
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()
        with tqdm_class(leave=False, desc='without logging_redirect_tqdm',
                        dynamic_ncols=True) as pbar:
            LOG.info("console logging NOT redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:16.873512
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    assert trange(9)
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:51:27.272405
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)
    # redirect to tqdm
    handler = _TqdmLoggingHandler(tqdm.tqdm)
    logger.addHandler(handler)

# Generated at 2022-06-24 09:51:38.044847
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    log = ''
    with tqdm_logging_redirect(
        total=3,
        bar_format='{n_fmt}/{total_fmt} {bar} {postfix}',
        leave=True,
        dynamic_ncols=True,
        mininterval=0.1,
        disable=False,
        unit_scale=True,
        logger=LOG
    ) as pbar:
        for i in range(3):
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.set_description(str(i))
            pbar.refresh()
            pbar.reset(total=i+1)
            log += pbar.format_dict['postfix'][0]

# Generated at 2022-06-24 09:51:45.701434
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import os
    import logging
    from tqdm import tqdm_notebook
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Create logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s\t%(levelname)s\t%(message)s",
    )
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    # Create notebook
    _ = tqdm_notebook(range(5))


# Generated at 2022-06-24 09:51:49.988416
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    var = 5
    logging.basicConfig(level=logging.INFO)
    pbar = _TqdmLoggingHandler(std_tqdm)
    pbar.emit('test')
    for i in range(var):
        pbar.emit(i)

# Generated at 2022-06-24 09:52:00.156532
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import io
    import logging
    import sys
    from tqdm import trange

    # Monkey-patch tqdm.format_interval
    import tqdm
    tqdm.format_interval = lambda x: '0s'

    LOG = logging.getLogger(__name__)

    def test(tqdm_class, stream=None):
        # type: (Type[std_tqdm], io.TextIOWrapper) -> None
        if stream is None:
            stream = sys.stderr
        sio = io.StringIO()

# Generated at 2022-06-24 09:52:06.207615
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """tests constructor of class _TqdmLoggingHandler"""
    import tqdm
    _TqdmLoggingHandler(tqdm.std.tqdm)
    _TqdmLoggingHandler(tqdm.tqdm)
    _TqdmLoggingHandler(tqdm.tqdm_notebook)



# Generated at 2022-06-24 09:52:11.073515
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}
    assert isinstance(tqdm_handler.formatter, logging.Formatter)
    assert isinstance(tqdm_handler.filter, logging.Filter)


# Generated at 2022-06-24 09:52:18.637310
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    from tqdm.utils import _term_move_up
    with capturedOutput:
        tqdm_handler = _TqdmLoggingHandler()
        tqdm_handler.stream = capturedOutput
        tqdm_handler.emit(logging.LogRecord('name', logging.INFO, 'pathname', 0, 'msg', (), None))
        assert capturedOutput.getvalue() == 'msg\n'
    sys.stdout = sys.__stdout__
    capturedOutput.close()

# Generated at 2022-06-24 09:52:23.260617
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.handlers = [logging.StreamHandler()]
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)
    with logging_redirect_tqdm():
        assert len(logger.handlers) == 1
        assert isinstance(logger.handlers[0], _TqdmLoggingHandler)



# Generated at 2022-06-24 09:52:24.834579
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(object=_TqdmLoggingHandler(), classinfo=logging.StreamHandler)


# Generated at 2022-06-24 09:52:35.192348
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.root]
    try:
        # logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(loggers=loggers):
            for i in range(9):
                if i == 4:
                    # logging.log(logging.INFO, "console logging redirected to `tqdm.write()`")
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
    finally:
        for logger, original_handlers in zip(loggers, original_handlers_list):
            logger.handlers = original_handlers

# Run unit test when this file is directly executed
if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:39.046518
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import time
    from .std_wrap import tqdm

    time.sleep(0.1)
    with tqdm_logging_redirect() as pbar:
        time.sleep(0.1)
        pbar.pbar.update(1)
        time.sleep(0.1)

# Generated at 2022-06-24 09:52:43.445758
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with std_tqdm(ncols=70) as tqdm_handler:
        assert hasattr(tqdm_handler, "tqdm_class")
        assert tqdm_handler.tqdm_class == std_tqdm
        assert hasattr(tqdm_handler, "stream")
        assert tqdm_handler.stream == sys.stderr


# Generated at 2022-06-24 09:52:44.324123
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-24 09:52:47.229093
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        logger.info("console logging redirected to `tqdm.write()`")
    logger.info("logging restored")

# Generated at 2022-06-24 09:52:48.760520
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    h = _TqdmLoggingHandler()
    assert hasattr(h, 'emit')


# Generated at 2022-06-24 09:52:58.923175
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    LOG = logging.getLogger(__name__)

    with patch('sys.stderr', new_callable=lambda: StringIO()) as mock_stderr, \
         logging_redirect_tqdm():
        LOG.error('No output')
        assert not mock_stderr.getvalue()

        LOG.debug('No output')
        assert not mock_stderr.getvalue()

        LOG.warning('Console logging redirected to `tqdm.write()`')
        assert mock_stderr.getvalue() == 'Console logging redirected to `tqdm.write()`'

# Generated at 2022-06-24 09:53:05.232928
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tempfile import NamedTemporaryFile
    from time import sleep
    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    out_file = NamedTemporaryFile()
    handler.stream = out_file
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    # raise messages
    logger.info("First message")
    sleep(0.05)
    logger.info("Second message")
    # ValueError: I/O operation on closed file
    try:
        logger.removeHandler(handler)
        handler.close()
    except ValueError:
        pass
    # read file and check content
    out_file.seek(0)
    output = out_file.read()
   

# Generated at 2022-06-24 09:53:13.639145
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tempfile
    from ..autonotebook import trange
    from io import StringIO
    with tempfile.TemporaryDirectory() as tempdir:
        handler = _TqdmLoggingHandler(tqdm_class=trange)
        buf = StringIO()
        handler.stream = buf
        handler.emit(logging.LogRecord(
            'foo', logging.DEBUG, pathname=__file__, lineno=0,
            msg='bar', args=(), exc_info=None))
        assert buf.getvalue() == 'bar\n'

# Generated at 2022-06-24 09:53:22.706257
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = StringIO()
    msg = "This is a log message."
    record = logging.LogRecord(
        name=__name__,
        level=logging.INFO,
        pathname=__file__,
        lineno=65,
        msg=msg,
        args=[],
        exc_info=None)
    tqdm_logging_handler.emit(record)
    assert (msg + '\n') == tqdm_logging_handler.stream.getvalue()

# Generated at 2022-06-24 09:53:31.292947
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:53:38.275129
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:53:45.003393
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import inspect
    import logging

    # Check that function tqdm_logging_redirect returns a context manager
    assert 'contextmanager' in inspect.getsource(tqdm_logging_redirect)

    # Check that tqdm_logging_redirect calls basicConfig if logging has not
    # been configured before
    loggers = [logging.getLogger(__name__)]
    with tqdm_logging_redirect(loggers=loggers):
        pass

# Generated at 2022-06-24 09:53:51.485407
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Given:
    from contextlib import redirect_stdout
    from io import StringIO
    from .main import tqdm
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter('%(message)s'))
    record = logging.LogRecord('name', logging.INFO, 'pathname', 0, 'msg', None, None)
    stream = StringIO()
    tqdm_handler.stream = stream
    # When:
    with redirect_stdout(stream):
        tqdm_handler.emit(record)
    # Then:
    assert stream.getvalue() == 'msg\n'


# Generated at 2022-06-24 09:54:03.100417
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm_gui
    import logging
    with tqdm_logging_redirect(tqdm_class=tqdm_gui.tqdm) as pbar:
        logging.info("Test")
        pbar.update()


try:
    from ..std import tqdm  # pylint: disable=unused-import
    _tqdm_module_available = True
    tqdm_logging_redirect = tqdm(
        [tqdm_logging_redirect],
        leave=True,
        ascii=True,
        desc="tqdm logging"
    )
except (ImportError, AttributeError):
    _tqdm_module_available = False


# Generated at 2022-06-24 09:54:09.296952
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-24 09:54:16.936414
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # type: () -> None
    import io
    import pytest
    import logging
    from tqdm import tqdm

    def do_logging(logger, log_level):
        # type: (logging.Logger, int) -> None
        logger.log(log_level, 'logging message {}'.format(log_level))

    @contextmanager
    def catch_stdout_stderr(stdout=None, stderr=None):
        # type: (Optional[io.TextIOWrapper], Optional[io.TextIOWrapper]) -> Iterator[None]
        import sys
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = stdout, stderr
        yield
        sys.stdout, sys

# Generated at 2022-06-24 09:54:26.049044
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    tqdm = __import__('tqdm')
    tqdm.tqdm = __import__('tqdm.std')
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    else:
        # just test that it imports
        tqdm_logging_redirect(total=0)
    assert True


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:54:33.755801
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Example of function tqdm_logging_redirect
    """
    from tqdm import tqdm
    from tqdm.contrib import logger

    count = 10
    with logger.tqdm_logging_redirect(
            loggers=[logger.logging.getLogger()],
            total=count,
            unit='characters'
    ) as pbar:
        for i in tqdm(range(count)):
            pbar.update()



# Generated at 2022-06-24 09:54:41.484967
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import closing
    from .std import StringIO
    import time
    import logging

    with closing(StringIO()) as our_file:
        with logging_redirect_tqdm(tqdm_class=std_tqdm,
                                   loggers=[logging.getLogger('mylogger')],
                                   file=our_file):
            LOG = logging.getLogger('mylogger')
            LOG.info("Hello World!")
            time.sleep(0.01)
            std_tqdm.write("Test")
        assert our_file.getvalue().rstrip() == "Hello World!\rTest"

# Generated at 2022-06-24 09:54:42.942084
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handle = _TqdmLoggingHandler()
    assert handle.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:54:53.830120
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    def run_TqdmLoggingHandler_emit(
        msg,  # type: str
        file_,  # type: file
        exc_info=None  # type: Optional[Tuple[Type[BaseException], BaseException, TracebackType]]
    ):
        # type: (...) -> None
        handler = _TqdmLoggingHandler()
        handler.stream = file_
        record = logging.LogRecord(
            name='foo', level=logging.INFO, pathname=__file__, lineno=5,
            msg=msg, args=(), exc_info=exc_info)
        handler.handle(record)
        handler.flush()
        file_.seek(0)
        assert file_.read() == 'foo\n'

    run_TqdmLoggingHandler_em

# Generated at 2022-06-24 09:54:59.249286
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':

        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:55:02.546373
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:55:04.649250
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger()]
    with tqdm_logging_redirect(tqdm=tqdm, loggers=loggers):
        logging.info('console output redirected to `tqdm.write()`')

# Generated at 2022-06-24 09:55:07.674088
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from multiprocessing import Process
    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    msg = 'test logging handler'

    def logging_emit(msg):
        LOG = logging.getLogger(__name__)
        LOG.handlers = [_TqdmLoggingHandler(tqdm_class=tqdm)]
        LOG.info(msg)

    p = Process(target=logging_emit, args=(msg,))
    p.start()
    p.join()
    assert msg in tqdm.write.cache  # pylint: disable=no-member

# Generated at 2022-06-24 09:55:18.038893
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TestLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super().__init__()
            self.msg = ""

        def emit(self, record):
            try:
                self.msg = self.format(record)
                self.flush()
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    logger = logging.getLogger("TestLogger")
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter("%(name)s: %(message)s"))
    test_handler = TestLoggingHandler()
    test_handler.setFormatter(logging.Formatter("%(name)s: %(message)s"))
    logger.handlers

# Generated at 2022-06-24 09:55:20.038343
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        with _TqdmLoggingHandler():
            pass
    except NotImplementedError:
        pass

# Generated at 2022-06-24 09:55:26.240511
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    logging.basicConfig(
        format="%(levelname)s:%(message)s", level=logging.INFO)

    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:29.475451
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    logging.root.handlers = [tqdm_handler]
    logging.info("hello")
    assert tqdm_handler.tqdm_class.format_sizeof(
        len(sys.stdout.getvalue()), "B").endswith("B\n")

# Generated at 2022-06-24 09:55:35.373302
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _TqdmLoggingHandlerTester(_TqdmLoggingHandler):
        def __init__(self):
            super(_TqdmLoggingHandlerTester, self).__init__()
            self.stream = []

        def write_as_stream(self, message):
            self.stream.append(message)

    record = logging.LogRecord(
        name='test',
        level=logging.INFO,
        pathname=None,
        lineno=None,
        msg='test message',
        args=None,
        exc_info=None)
    test_handler = _TqdmLoggingHandlerTester()
    test_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    test_handler.stream = test_handler.write_as_stream

# Generated at 2022-06-24 09:55:42.655059
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.propagate = False

    with tqdm_logging_redirect(loggers=[logger]):
        for _ in tqdm(range(10)):
            # logging a message
            logging.info('test')
            time.sleep(0.1)

# Generated at 2022-06-24 09:55:49.917912
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.auto import trange

    # Create loggers and add a console handler
    logger_1 = logging.getLogger('logger_1')
    logger_2 = logging.getLogger('logger_2')
    logger_1.setLevel(logging.INFO)
    logger_2.setLevel(logging.INFO)
    logger_1.handlers.append(logging.StreamHandler())
    logger_2.handlers.append(logging.StreamHandler())

    # Redirect console logging to tqdm.write() through logger_1
    print('logger_1.info(...) should use tqdm.write()')
    with tqdm_logging_redirect('logger_1') as pbar:
        assert pbar.__class__ is std_tqdm
       

# Generated at 2022-06-24 09:55:51.952241
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr
    assert handler.formatter is not None

# Generated at 2022-06-24 09:55:59.884721
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    loggers = [logging.root]; tqdm_class = trange
    with tqdm_logging_redirect(total=5, loggers=loggers, tqdm_class=tqdm_class):
        logging.info("console logging redirected to `tqdm.write()`")
    assert tqdm_class(total=5)._instances != []
    assert logging.root.handlers != []
    assert logging.root.handlers[0].level == 0
    assert logging.root.handlers[0].stream == logging.root.handlers[0].stream


# test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:56:01.209762
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:56:09.764456
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler
    import logging
    import sys


# Generated at 2022-06-24 09:56:16.661326
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm


    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:56:24.657245
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys

    # Redirect stdout
    stdout_tqdm_out = io.StringIO()
    sys.stdout = stdout_tqdm_out

    # Create a handler, and apply it on a logger
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger('foo')
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    # Log a message
    logger.info('Testing')

    # Check that the message appears in stdout
    assert 'Testing' == stdout_tqdm_out.getvalue().rstrip()

    # Restore stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 09:56:26.094841
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-24 09:56:35.176966
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    import unittest

    class Test(unittest.TestCase):
        def test_emit(self):
            with io.BytesIO() as buf:
                sys.stdout = buf

                tqdm_handler = _TqdmLoggingHandler()
                tqdm_handler.setFormatter(logging.Formatter(
                    "%(asctime)s - %(levelname)s - %(message)s"))
                tqdm_handler.setLevel(logging.DEBUG)

                record1 = logging.LogRecord("name1", logging.DEBUG,
                                            "filename1", 1000, "msg1",
                                            None, None)
                tqdm_handler.emit(record1)


# Generated at 2022-06-24 09:56:43.958259
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange

    # doing this way as printing from inside the contextmanager
    #  doesn't work on python 2.7
    LOG = logging.getLogger(__name__)
    l_out = []

    def test_log(l_out=l_out):
        class NullHandler(logging.Handler):
            def emit(self, record):
                pass
        LOG.addHandler(NullHandler())
        with logging_redirect_tqdm(loggers=[LOG]):
            for _ in trange(9):
                if _ == 4:
                    l_out.append("console logging redirected to `tqdm.write()`")
                    LOG.info("console logging redirected to `tqdm.write()`")
    test_log()

# Generated at 2022-06-24 09:56:53.265471
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import sys

    import tqdm
    import logging

    logging_out = StringIO()
    logging_err = StringIO()

    console_out = StringIO()
    console_err = StringIO()

    sys.stdout = console_out
    sys.stderr = console_err

    h = _TqdmLoggingHandler(tqdm_class=tqdm)
    h.stream = logging_out

    logger = logging.getLogger()
    logger.addHandler(h)
    logger.setLevel(50)
    logger.error('TEST ERROR')

    assert logging_out.getvalue() == 'TEST ERROR\n'
    assert console_out.getvalue() == ''
    assert console_err.getvalue() == 'TEST ERROR\n'

# Generated at 2022-06-24 09:56:55.582756
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    tlh.emit(logging.LogRecord('name', logging.INFO, 'file', 0, 'message',
                               None, None))

# Generated at 2022-06-24 09:57:06.964349
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test the method emit of class _TqdmLoggingHandler.
    """
    from logging import basicConfig, getLogger
    from io import StringIO
    import sys
    import pytest

    basicConfig(level=10)
    logger = getLogger('TqdmLogger')
    logfile = StringIO()
    logger.addHandler(_TqdmLoggingHandler(logging.StreamHandler(logfile)))

    logger.debug('Hello')
    assert 'Hello' in logfile.getvalue()
    logger.info('Hello')
    assert 'Hello' in logfile.getvalue()
    logger.warning('Hello')
    assert 'Hello' in logfile.getvalue()
    logger.error('Hello')
    assert 'Hello' in logfile.getvalue()

    # If a logging handler writes to sys.stdout

# Generated at 2022-06-24 09:57:15.257013
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # make sure that tqdm_logging_redirect works as expected
    # see https://github.com/tqdm/tqdm/issues/847
    import unittest
    import logging
    import sys
    from io import StringIO
    from tqdm import tqdm

    class TqdmLoggingRedirectTest(unittest.TestCase):
        def test_tqdm_logging_redirect(self):
            # Use case 1: logging configuration is not set
            # In this case, we configure the root logger to print to stdout
            # and we catch the logging message in a StringIO
            root_logger = logging.root
            original_handlers = root_logger.handlers
            root_logger.handlers = []

# Generated at 2022-06-24 09:57:23.203291
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    def check_example():
        LOG = logging.getLogger(__name__)
        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                LOG.info("console logging redirected to `tqdm.write()`")
                # logging restored

    from io import StringIO
    buf = StringIO()
    with std_tqdm.redirect_stdout(buf):
        check_example()

# Generated at 2022-06-24 09:57:31.405094
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger, handler = None, None
    try:
        logger, handler = create_logger()
        with tqdm_logging_redirect(desc='loggings') as pbar:
            pbar.update(1.0)
            logger.info('logging test')  # This should automatically appear in tqdm
            pbar.update(1.0)
    finally:
        logger.removeHandler(handler)
        if handler is not None:
            handler.close()
    # If everything went well, the printed line should be in the format:
    # [100%] logging test|loggings



# Generated at 2022-06-24 09:57:35.581236
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from .tests import pretest_posttest

    with pretest_posttest() as (p, _):
        with logging_redirect_tqdm():
            logging.info("message")
            logging.warning("message")
            p.stdout.seek(0)
            assert p.stdout.read() == 'message\n'


test_logging_redirect_tqdm.visible = False

# Generated at 2022-06-24 09:57:47.644799
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import unittest

    from .tests.common_tests import CommonTestMixin

    class _TqdmLoggingHandlerTest(CommonTestMixin, unittest.TestCase):
        def test_emit(self):
            # type: () -> None
            handler = _TqdmLoggingHandler(
                tqdm_class=std_tqdm
            )
            handler.setLevel(logging.INFO)
            handler.stream = io.BytesIO()
            handler.emit(logging.makeLogRecord({
                'name': 'fake_name',
                'msg': 'fake_msg',
                'args': (),
            }))
            self.assertIn('fake_msg', handler.stream.getvalue())

    _TqdmLoggingHandlerTest().test_

# Generated at 2022-06-24 09:57:57.062530
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for the emit method of class _TqdmLoggingHandler
    """
    # pylint: disable=protected-access

    record = logging.LogRecord('name', logging.DEBUG, 'pathname', 'lineno',
                               'msg', None, None)

    # pylint: disable=attribute-defined-outside-init
    class TqdmMock(std_tqdm):
        # pylint: disable=arguments-differ
        def __init__(self, *args, **kwargs):
            super(TqdmMock, self).__init__(*args, **kwargs)
            self.msg = ''

        def write(self, msg, file=None):
            self.msg = msg

    # pylint: disable=abstract-class-little-used

# Generated at 2022-06-24 09:58:03.668603
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # Test that we can use logging and `tqdm.write()` in the same iteration
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:13.734767
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import open
    from tempfile import NamedTemporaryFile
    import os
    import tqdm.auto
    import textwrap

    # Fake tqdm.py file

# Generated at 2022-06-24 09:58:21.873821
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Unit test for function tqdm_logging_redirect"""
    loggers = [logging.root]
    tqdm_kwargs = {}
    tqdm_class = std_tqdm

    with tqdm_logging_redirect(
        loggers=loggers,
        tqdm_class=tqdm_class,  # type: ignore
    ) as pbar:  # noqa
        pbar.update(2)
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            pass  # noqa

# Generated at 2022-06-24 09:58:32.092408
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler
    
    # Save the original stdout (1) and stderr (2) file descriptors.
    orig_stdout_fd = sys.stdout.fileno()
    orig_stderr_fd = sys.stderr.fileno()

    # Create a pipe for capturing stdout.
    capture_stdout_r, capture_stdout_w = os.pipe()

    # Create a pipe for capturing stderr.
    capture_stderr_r, capture_stderr_w = os.pipe()

    # Replace stdout with our write pipe
    os.dup2(capture_stdout_w, orig_stdout_fd)

    # Replace stderr with our write pipe

# Generated at 2022-06-24 09:58:45.591558
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from tqdm.contrib.test_utils import StringIO

    # Setup
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    msg = "this is a test message"

    # Side effects:
    # Modify sys.stderr in a way that it can be restored to its original value
    # after the test ends.
    sys.stderr = StringIO()

# Generated at 2022-06-24 09:58:55.028546
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def test_logging_redirect_tqdm_run(sio):
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        sio.truncate(0)
        return sio.getvalue()

    # Test
    sio = io.StringIO()
    with tqdm_logging_redirect(file=sio):
        test_logging_redirect_tqdm_run(sio)
    test_logging_redirect_tqdm_run(sio)