

# Generated at 2022-06-24 09:48:54.549989
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit in class _TqdmLoggingHandler
    """
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.handlers = [handler]
    logger.warning('test_logger_with_tqdm_handler')


# Generated at 2022-06-24 09:48:56.685922
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    s = StringIO()
    handler = _TqdmLoggingHandler()
    handler.stream = s
    handler.emit(None)
    handler.emit((1, 2))

# Generated at 2022-06-24 09:49:06.672580
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import mock
    from tqdm import tqdm

    with mock.patch.object(tqdm, 'write') as mocked_write:
        with mock.patch.object(sys, 'stdout') as mocked_stdout:
            _TqdmLoggingHandler(tqdm_class=tqdm).emit(logging.makeLogRecord({
                'levelno': logging.INFO,
                'msg': 'test'
            }))
        mocked_write.assert_called_once_with('test\n', file=mocked_stdout)


# Generated at 2022-06-24 09:49:10.324187
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    logger = logging.getLogger(__name__)
    old_handlers = logger.handlers
    logger.handlers = [_TqdmLoggingHandler()]
    logger.setLevel(logging.DEBUG)
    logger.debug('a')
    assert logger.handlers == old_handlers, '_TqdmLoggingHandler failed to work'

# Generated at 2022-06-24 09:49:14.277840
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:49:20.700086
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:49:31.580708
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import StreamHandler, LogRecord
    from logging import getLogger
    from tqdm import tqdm

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)

    # Configure a handler with a StringIO stream to capture the log output
    s = StringIO()
    tqdm_handler.stream = s
    getLogger().addHandler(tqdm_handler)

    # Formatting needed to compare with the output of the StreamHandler
    tqdm_handler.setFormatter(StreamHandler(None).formatter)

    log_record = LogRecord(
        name='',
        level=10,
        pathname='',
        lineno=0,
        msg='Test message',
        args=None,
        exc_info=None)

# Generated at 2022-06-24 09:49:35.923953
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from time import sleep

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            sleep(.5)



# Generated at 2022-06-24 09:49:44.177096
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    with tqdm_logging_redirect(
            tqdm=std_tqdm,
            bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} ',
            unit='s',
            unit_scale=True,
            smoothing=1.0,
            dynamic_ncols=False,
            leave=False,
            mininterval=0.1,
            maxinterval=10.0,
            miniters=1,
    ) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 09:49:48.811692
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with logging_redirect_tqdm():
        LOG.info("hello world")
        LOG.info("foo bar")

    logging.shutdown()
    assert True

######################################################################

# Generated at 2022-06-24 09:49:50.580648
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # No error is thrown for this test
    _TqdmLoggingHandler(std_tqdm)



# Generated at 2022-06-24 09:49:59.867381
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import cStringIO
    import logging
    from tqdm import tqdm, trange

    # Redirect stdout to a string buffer
    old_stdout = sys.stdout
    stringio = cStringIO.StringIO()
    sys.stdout = stringio

    log_format = '%(asctime)-15s %(levelname)-8s %(message)s'
    logging.basicConfig(level=logging.INFO, format=log_format)

    LOG = logging.getLogger(__name__)


# Generated at 2022-06-24 09:50:10.326355
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.utils import _supports_unicode
    from tqdm.auto import trange

    log = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=1, loggers=[log]) as pbar:
        pbar.set_description('bar')
        log.info('✓')

    title = ('TEST: console logging redirected to `tqdm.write()` with "bar"'
             + (_supports_unicode and ' ✓' or ''))
    with tqdm_logging_redirect(total=1, desc=title, loggers=[log]) as pbar:
        log.info('✓')

# Generated at 2022-06-24 09:50:16.331539
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-24 09:50:25.158569
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import std_tqdm as tqdm, tqdm_gui

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                total=9, desc="test_tqdm_logging_redirect",
                dynamic_ncols=True, unit="items", leave=True,
                unit_scale=True, unit_divisor=4,
                loggers=[LOG]):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-24 09:50:30.248279
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger(logging.__name__)]
    with tqdm_logging_redirect('Testing...', total=5, loggers=loggers,
                               tqdm_class=std_tqdm) as pbar:
        assert pbar.total == 5
        logging.info('Test')
        pbar.update()
    # Make sure that the logger is unchanged outside
    logging.info('This will not be redirected to pbar')

# Generated at 2022-06-24 09:50:35.745845
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=unused-variable, too-many-locals, superfluous-parens
    from io import StringIO
    from tqdm import std_tqdm
    import logging

    log = logging.getLogger('test')
    log.setLevel(logging.DEBUG)

    buf = StringIO()

    hdlr = _TqdmLoggingHandler(std_tqdm)  # pylint: disable=redefined-outer-name
    hdlr.setLevel(logging.DEBUG)
    hdlr.stream = buf
    log.addHandler(hdlr)

    log.debug('DEBUG')
    log.info('INFO')
    log.warn('WARN')
    log.error('ERROR')
    log.critical('CRITICAL')


# Generated at 2022-06-24 09:50:42.383514
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        log = logging.getLogger(__name__)
        # pylint: disable=protected-access
        log._log(logging.INFO, 'hello', ())
    # logging restored
    # pylint: disable=protected-access
    log._log(logging.INFO, 'world', ())

# Generated at 2022-06-24 09:50:44.788610
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    obj = _TqdmLoggingHandler()
    assert hasattr(obj, 'doRollover')
    assert hasattr(obj, 'terminator')



# Generated at 2022-06-24 09:50:48.227242
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(unit='B', unit_scale=True,
                                   total=100, desc="replication 1"):
            for i in range(100):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:50:53.331566
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import redirect_stdout
    import logging
    from .std import tqdm as test_tqdm

    LOG = logging.getLogger(__name__)

    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    with StringIO() as buf, redirect_stdout(buf):
        with logging_redirect_tqdm():
            for i in test_tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    assert buf.getvalue() == \
        '100%|██████████████████████████████████████████████████| 9/9 [00:00<00:00, 1713.95it/s]\n'


# Generated at 2022-06-24 09:51:02.757286
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .__init__ import _unittest_run_print as _unittest_run
    from .__init__ import tqdm_func_get_write_file

    def unit_test():
        import logging
        from tqdm import trange

        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                # print(i)
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")

    unit_test_name = 'tqdm.tests._tqdm_gui.test_logging_redirect_tqdm'
    output, _ = _unittest_run(unit_test_name, unit_test)

# Generated at 2022-06-24 09:51:04.878338
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    hdlr = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    hdlr.emit("test")



# Generated at 2022-06-24 09:51:10.229687
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger('main')
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info('logging redirected to `tqdm.write()`')
        for i in range(9):
            LOG.info(i)



# Generated at 2022-06-24 09:51:14.851138
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    logger = logging.Logger(__name__)
    logger.addHandler(tqdm_handler)
    logger.info("This is a test for the method emit of tqdm_logging_handler.")
    logger.removeHandler(tqdm_handler)



# Generated at 2022-06-24 09:51:15.702395
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:22.573740
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.tests import tests as tqdm_tst
    from tqdm import tqdm, trange
    for my_tqdm in (trange, tqdm):
        with tqdm_logging_redirect(
            my_tqdm,
            iterations=9,
            desc='testing console logging redirected to `tqdm.write()`',
            leave=False,
            loggers=[logging.getLogger(__name__)],
            tqdm_class=tqdm_tst.TqdmStreamStdCapture,
        ) as pbar:
            for i in pbar:
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:29.059320
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test for example code snippet.
    """
    import logging
    from tqdm import trange

    # Test that code snippet is valid
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    logging.basicConfig(level=logging.INFO)
    LOG.info("logging restored")



# Generated at 2022-06-24 09:51:35.152832
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("this msg is redirected to tqdm")
    logger.info("another message")
    with logging_redirect_tqdm():
        logger.info("this msg is also redirected to tqdm")
    logger.info("this msg should be displayed in stdout")



# Generated at 2022-06-24 09:51:41.211866
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    LOG.addHandler(logging.StreamHandler())

    for i in range(2):
        with logging_redirect_tqdm(loggers=[LOG]):
            for j in range(5):
                LOG.info(j)
                time.sleep(0.2)
        # logging restored

# Generated at 2022-06-24 09:51:44.916838
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """
    import logging

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, desc='test') as pbar:
        for _ in pbar:
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:56.061246
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    test_logging_redirect_tqdm checks that the tqdm.write() and logging operations
    work simultaneously.
    """
    try:
        from unittest.mock import patch
    except ImportError:  # python 2
        from mock import patch
    from contextlib import contextmanager

    @contextmanager
    def mock_std_tqdm(*args, **kwargs):  # pylint: disable=unused-argument
        """
        Mock :func:`std_tqdm` so that it does not write to stdout
        """
        yield std_tqdm(0)

    log1 = logging.getLogger('log1')
    log2 = logging.getLogger('log2')


# Generated at 2022-06-24 09:52:03.905690
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import os
    # Monkey patching tqdm
    test_text = io.StringIO()
    os.environ['TEST_STDOUT'] = test_text.getvalue()
    tqdm = std_tqdm
    def write(text, file=None):
        if file is None:
            file = sys.stdout
        if file is sys.stdout:
            os.environ['TEST_STDOUT'] = text
        else:
            os.environ['TEST_STDERR'] = text

    tqdm.write = write
    # Unit test
    record = logging.LogRecord('test', logging.INFO, pathname='/test/file',
                               lineno=10, msg='test record', args=None,
                               exc_info=None)
    handler = _TqdmLog

# Generated at 2022-06-24 09:52:09.159635
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    with logging_redirect_tqdm():
        logging.info("logging redirected to `tqdm.write()`")
        logging.info("logging redirected to `tqdm.write()` " +
                     "with formatter %s", "test")

# Generated at 2022-06-24 09:52:17.000010
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests that log messages are successfully captured by _TqdmLoggingHandler.
    """
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    fake_stdout = StringIO()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler()
    handler.stream = fake_stdout
    logger.addHandler(handler)
    logger.warning("foobar")
    logger.debug("something")
    logger.debug("something else")
    logger.warning("baz")
    logger.info("i am info")
    logger.info("done")
    captured = fake_stdout.getvalue()

# Generated at 2022-06-24 09:52:21.492811
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    import logging
    log = logging.getLogger()
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler(sys.stdout)) # type: ignore
    print('logging before')
    with tqdm_logging_redirect() as pbar:
        log.info('logging within')
    print('logging after')


# Generated at 2022-06-24 09:52:26.030661
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    string = "Hello, World!"
    # File stream
    file = open("pylint.stdout", "w")
    handler = _TqdmLoggingHandler()
    handler.stream = file
    handler.emit(string)
    file.close()
    file = open("pylint.stdout", "r")
    assert file.readline() == string + "\n"
    file.close()


# Generated at 2022-06-24 09:52:30.554131
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, loggers=[log], tqdm_class=tqdm.tqdm) as pbar:
        for i in pbar:
            log.info("{}".format(i))

# Generated at 2022-06-24 09:52:31.722163
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    stream = handler.stream
    assert isinstance(handler.stream, (sys.stdout, sys.stderr))

# Generated at 2022-06-24 09:52:34.096959
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.emit(logging.LogRecord("1", "1", "1", 1, "msg", "1", "1"))

# Generated at 2022-06-24 09:52:43.109892
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import cStringIO
    import unittest
    import logging

    logging.basicConfig(
        format='%(filename)s::%(funcName)s::%(lineno)d::%(message)s',
        level=logging.DEBUG,
        stream=cStringIO.StringIO())
    logger = logging.getLogger()
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.debug('Message')
    handler.stream.seek(0)
    assert handler.stream.read() == '__main__::test__TqdmLoggingHandler_emit::20::Message\n'
    logger.removeHandler(handler)
    logger.debug('Message')
    handler.stream.seek(0)
    assert handler.stream.read() == ''



# Generated at 2022-06-24 09:52:47.017656
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    import sys
    sys.stderr = io.StringIO()
    handler = _TqdmLoggingHandler()
    handler.emit(logging.LogRecord('foo', logging.DEBUG, 'pathname', 1, 'msg', tuple(), None))
    assert 'msg' in sys.stderr.getvalue()

# Generated at 2022-06-24 09:52:48.405832
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # No error while creating object of class _TqdmLoggingHandler
    _TqdmLoggingHandler()



# Generated at 2022-06-24 09:52:50.361272
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info('testing')

# Generated at 2022-06-24 09:52:52.774211
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler().tqdm_class is std_tqdm
    assert _TqdmLoggingHandler(tqdm_class=tqdm).tqdm_class is tqdm

# Generated at 2022-06-24 09:53:04.999886
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.std import tqdm

    class FakeTqdm(object):
        def __init__(self):
            self.data = []

        def write(self, data, file=None):
            self.data.append(data)

    # tqdm_class = FakeTqdm
    tqdm_class = tqdm
    log_data = []
    with logging_redirect_tqdm([logging.root], tqdm_class):
        for i in range(4):
            logging.info(i)

    for i in range(4):
        log_data.append("%d" % i)
    assert len(tqdm_class().data) == len(log_data)

# Generated at 2022-06-24 09:53:11.131051
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[LOG], desc=__name__):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:53:18.854824
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    from .std import tqdm as std_tqdm
    
    with tqdm_logging_redirect(total=2, tqdm_class=std_tqdm) as pbar:
      for _ in range(2):
        logging.info('Neat, huh?')

    assert hasattr(std_tqdm.write, '__call__')

# Generated at 2022-06-24 09:53:22.057894
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    with logging_redirect_tqdm(tqdm_class=tqdm):
        for i in range(10):
            logging.info(i)

# Generated at 2022-06-24 09:53:33.289744
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    assert hasattr(tqdm_logging_redirect, '__name__')
    import logging

    # without arguments:
    with tqdm_logging_redirect() as pbar:  # type: ignore
        pass

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:  # type: ignore
        logging.error('test')
        pbar.write('test')

    # Unfortunatly the current way to test the
    # ``logging_redirect_tqdm`` does not work on windows.
    # On windows it seems that the logger is instantiated with a
    # FhilHandler and not a StreamHandler, thus we skip this test
    # on windows.

# Generated at 2022-06-24 09:53:41.141112
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.tqdm_class is std_tqdm
    assert handler.stream is sys.stderr
    assert handler.formatter is not None

    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(handler, logging.StreamHandler)
    assert handler.tqdm_class is std_tqdm
    assert handler.stream is sys.stderr
    assert handler.formatter is not None



# Generated at 2022-06-24 09:53:46.516642
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from random import random
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
    for _ in tqdm_logging_redirect(total=4, loggers=[LOG]):
        if _ == 2:
            LOG.error("console logging redirected to `tqdm.write()`")
        _ += random()

# Generated at 2022-06-24 09:53:53.331235
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, tnrange
    log = logging.getLogger(__name__)
    with tnrange(10) as pbar:
        with tqdm_logging_redirect(total=10,
                                   smoothing=0,
                                   tqdm_class=tqdm,
                                   loggers=[log]):
            assert len(pbar) == 10
            assert next(pbar) == 0
            assert log.handlers[-1].__class__.__name__ == '_TqdmLoggingHandler'



# Generated at 2022-06-24 09:54:00.473846
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:54:07.759451
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import StringIO
    tqdm_logger = logging.getLogger('TqdmLogger')
    tqdm_logger.setLevel(logging.DEBUG)
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tqdm_logging_handler_stream = StringIO.StringIO()
    tqdm_logging_handler.setStream(tqdm_logging_handler_stream)
    tqdm_logger.addHandler(tqdm_logging_handler)
    tqdm_logger.debug(message='This is a debug message')
    assert tqdm_logging_handler_stream.getvalue() == 'This is a debug message\n'

    # Clean up
    logging.shutdown()

# Generated at 2022-06-24 09:54:14.751141
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO

    tqdm_strio = StringIO()
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.stream = tqdm_strio
    tqdm_handler.emit(logging.LogRecord(
        'foo', 1, 'bar', 1, 'oops', (), None))
    assert tqdm_strio.getvalue() == 'oops\n'

# Generated at 2022-06-24 09:54:21.451566
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc='Test logger', leave=False) as pbar:
        for j in trange(10):
            for i in trange(10):
                pbar.update()
            pbar.write('this is a test')
        pbar.close()

    with tqdm_logging_redirect(desc='Test logger', leave=False):
        pbar = std_tqdm()
        for j in trange(10):
            for i in trange(10):
                pbar.update()
            pbar.write('this is a test')
        pbar.close()


# Generated at 2022-06-24 09:54:29.209016
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO        # Python 3
    from ..std import tqdm

    s = StringIO()
    with tqdm.std.tqdm(
            # file=s,
            desc='testing',
            mininterval=0,
            bar_format='{desc}: {bar}',
            leave=False) as pbar:
        pbar.update(10)
        with tqdm.contrib.logging.logging_redirect_tqdm(tqdm_class=tqdm.std.tqdm):
            logging.info('info')
            logging.error('error')
        pbar.update(90)
    assert s.getvalue().strip

# Generated at 2022-06-24 09:54:39.553099
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(name='test', level=0, fn='test', lno=1, msg='test',
                               args=None, exc_info=None)

    from io import StringIO
    sio = StringIO()
    tqdm_handler.stream = sio

    tqdm_handler.emit(record)
    assert sio.getvalue() == 'test\n'

    # Test for handling error
    import mock
    tqdm_handler.handleError = mock.MagicMock()
    msg = 'test\n'
    with mock.patch('tqdm.contrib.logging._TqdmLoggingHandler.write') as write:
        write.side_effect = IOError()
        tqdm_handler.em

# Generated at 2022-06-24 09:54:46.629665
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test direct redirection to `tqdm.write()`.
    """
    tqdm = std_tqdm
    sys.stderr.write("testing direct redirection to `tqdm.write()`:\n\n")
    sys.stderr.flush()
    logger = logging.getLogger('test')
    logger.setLevel(level=logging.DEBUG)
    original_handlers = logger.handlers
    with tqdm.std.trange(100) as tr:
        with logging_redirect_tqdm():
            logger.debug("1")
            tr.write(" !")
            logger.info("2")
            tr.write(" !")
            logger.warning("3")
            tr.write(" !")
    tqdm

# Generated at 2022-06-24 09:54:52.392222
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_logging_handler, _TqdmLoggingHandler)


# test_is_console_logging_handler tests whether handler is a logging.StreamHandler
# which writes to console or not

# Generated at 2022-06-24 09:55:01.582188
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    Unit test for the constructor of class _TqdmLoggingHandler
    """
    class FakeTqdm:
        """
        Fake class to test _TqdmLoggingHandler
        """

        @staticmethod
        def write(msg, file):
            # type: (str, Optional[io.IOBase]) -> None
            """
            Fake write function to test _TqdmLoggingHandler
            """
            file.write(msg)

    class FakeLoggingObject:
        """
        Fake class to test _TqdmLoggingHandler
        """

        def __init__(self):
            # type: () -> None
            self.msg = ''
            self.error_msg = ''


# Generated at 2022-06-24 09:55:05.497302
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log_file = open("log1.txt","w")
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.emit("message")
    tqdm_handler.flush()
    log_file.close()
    

# Generated at 2022-06-24 09:55:11.243977
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=7) as pbar:
        for i in range(9):
            if i == 4:
                logging.info('console logging redirected to tqdm.write()')
            pbar.update()
    assert list(map(str, pbar)) == list('012357')

# Generated at 2022-06-24 09:55:21.082120
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..utils import _term_move_up
    import logging
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, desc=__name__) as pbar:
        for i in pbar:
            pbar.write("test example")
            logger.info("console logging redirected to `tqdm.write()`")

    # Test if the logging_redirect_tqdm is called correctly.
    log_line = _term_move_up() + 'test example\n\r' + _term_move_up() \
        + 'console logging redirected to `tqdm.write()`' + _term_move_up()

# Generated at 2022-06-24 09:55:22.753081
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:55:23.585660
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-24 09:55:30.900588
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

# Generated at 2022-06-24 09:55:39.000432
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.std import tqdm as tqdm_obj

    def _print_log(logger, level, msg):
        # pylint: disable=invalid-name
        #pylint:disable=eval-used
        eval('logger.{}({!r})'.format(level, msg))

    # logging via function
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[logging.root]):
        _print_log(logging.root, 'info', 'console logging redirected to `tqdm.write()`')
        _print_log(logging.root, 'info', 'console logging redirected to `tqdm.write()`')

    # logging via object

# Generated at 2022-06-24 09:55:43.595207
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import re
    import logging
    with tqdm_logging_redirect() as pbar:
        assert pbar == pbar._instances[0]
        logging.info('redirected message')
    assert re.match('\\[.*100%\\]  1 of 1 | redir.*', pbar.format_dict['desc'])

# Generated at 2022-06-24 09:55:44.592107
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()

# Generated at 2022-06-24 09:55:55.761733
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import inspect
    import re
    import unittest
    import unittest.mock as utm

    class T1(std_tqdm):
        pass

    logger = logging.getLogger(__name__)

    # For single line messages
    for i in range(4):
        T1.write = utm.Mock(wraps=T1.write)
        tqdm_logging_handler = _TqdmLoggingHandler(T1)
        tqdm_logging_handler.setFormatter(logging.Formatter('%(message)s'))
        logger.addHandler(tqdm_logging_handler)
        logger.info('Testing: %d', i)
        assert T1.write.called
        T1.write.reset_mock()

    # For multiline messages

# Generated at 2022-06-24 09:56:05.700838
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _DummyTqdmClass(object):
        @staticmethod
        def write(msg, **kwargs):
            print(msg)

    tqdm_logging_handler = _TqdmLoggingHandler(_DummyTqdmClass)
    record = logging.LogRecord(name="test", level=logging.INFO,
                               pathname="path/to/file.py",
                               lineno=10, msg="Test",
                               args=None, exc_info=None)
    sys.stdout = open('dummy_output.txt', 'w')
    tqdm_logging_handler.emit(record)
    sys.stdout.close()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 09:56:08.453167
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    # pylint: disable=protected-access
    assert isinstance(handler, _TqdmLoggingHandler)
    assert handler.tqdm_class is std_tqdm
    assert handler.stream == sys.stderr

# Generated at 2022-06-24 09:56:11.824764
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test _TqdmLoggingHandler constructor"""
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class == std_tqdm

# Generated at 2022-06-24 09:56:14.763508
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=1, desc='test') as pbar:
        assert pbar.total == 1
        assert pbar.n == 0
        pbar.update()
        assert pbar.n == 1



# Generated at 2022-06-24 09:56:21.185497
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = []

    class TestLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super(TestLoggingHandler, self).__init__()

        def emit(self, record):
            log.append(self.format(record))

    logging.basicConfig(handlers=[TestLoggingHandler()])

    with logging_redirect_tqdm():
        logging.info("redirected")

    assert log == []
    assert std_tqdm.write.get_lock()._count == 0

# Generated at 2022-06-24 09:56:28.886269
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:  # handle both python2/3
        from StringIO import StringIO
    except:
        from io import StringIO
    handler = _TqdmLoggingHandler()
    handler.stream = StringIO()
    record = logging.LogRecord(
        'name', logging.INFO, 'filename', 1, 'msg', tuple(), None)
    handler.emit(record)
    assert handler.stream.getvalue() == 'msg\n'

# Generated at 2022-06-24 09:56:36.436156
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .utils import silence

    _TqdmLoggingHandler(tqdm_class=std_tqdm).emit(logging.LogRecord(
        name="tqdm", level=logging.DEBUG, pathname="", lineno=0,
        msg="hello world", args=(), exc_info=None))
    with silence():
        _TqdmLoggingHandler(tqdm_class=std_tqdm).emit(logging.LogRecord(
            name="tqdm", level=logging.DEBUG, pathname="", lineno=0,
            msg="hello world", args=(), exc_info=None
        ))



# Generated at 2022-06-24 09:56:41.456734
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import util

    with util.capture_output() as out:
        with logging_redirect_tqdm(loggers=[],
                                   tqdm_class=std_tqdm):
            logging.info("message")

    assert out.getvalue() == "message\r\n", out.getvalue()

# Generated at 2022-06-24 09:56:50.580769
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from distutils.log import WARN, INFO
    from functools import partial

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    LOG = logging.getLogger(__name__)
    LOG.addHandler(logging.StreamHandler())
    LOG.setLevel(INFO)
    EXAMPLE_LOG_CALL = "console logging redirected to `tqdm.write()`"
    NB_ITERATIONS = 10

# Generated at 2022-06-24 09:56:54.909205
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    print("Starting test")
    import logging
    h1 = _TqdmLoggingHandler()
    logger = logging.getLogger("Test")
    logger.setLevel(logging.DEBUG)
    logger.addHandler(h1)
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.critical("Critical message")
    print("Finished test")

# Generated at 2022-06-24 09:57:06.533050
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    @contextmanager
    def contexting(n, d):
        print('entering: {}'.format(d))
        yield n
        print('leaving: {}'.format(d))

    with tqdm_logging_redirect(total=7, desc='outer context') as pbar:
        pbar.update(1)  # 1
        with contexting(5, 'inner context') as five:
            pbar.update(five)  # 6
            pbar.update(1)  # 7


if __name__ == '__main__':  # pragma: no cover
    # Run nose tests for this module
    from .noseclasses import TqdmNoseTests
    result = TqdmNoseTests().run()
    sys.exit(result.wasSuccessful())

# Generated at 2022-06-24 09:57:16.966372
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest.mock as mock  # py3
    except ImportError:
        import mock  # py2

    @mock.patch("tqdm.contrib.logging._TqdmLoggingHandler")
    @mock.patch("tqdm.contrib.logging.logging.root",
                mock.MagicMock(logging.Logger))
    def test(mock_logger, mock_handler):
        # type: (MagicMock, MagicMock) -> None
        mock_logging_redirect_tqdm = mock.patch(
            'tqdm.contrib.logging.logging_redirect_tqdm',
            wraps=logging_redirect_tqdm)

# Generated at 2022-06-24 09:57:18.845272
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class = std_tqdm).tqdm_class is std_tqdm

# Generated at 2022-06-24 09:57:30.130195
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler
    test_string = 'test'
    expected_string = '\r{0}'.format(test_string).encode('utf-8')
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.BytesIO()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    tqdm_handler.stream = stream
    logger.addHandler(tqdm_handler)
    logger.debug(test_string)
    assert expected_string == stream.getvalue()

# Generated at 2022-06-24 09:57:40.266745
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # The following is the same as tqdm_logging_redirect() with
        # logging_redirect_tqdm()
        # except it doesn't allow changing the tqdm class
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            with trange(5) as pbar:
                for i in pbar:
                    if i == 1:
                        LOG.info('test_tqdm_logging_redirect')


# Generated at 2022-06-24 09:57:43.527041
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging as py_logging
    with tqdm_logging_redirect(
            loggers=None,
            tqdm_class=std_tqdm,
            total=10,
            desc="Test tqdm logging redirection") as pbar:
        py_logging.info("Test")
        assert pbar.total == 10
        assert pbar.desc == "Test tqdm logging redirection"

# Generated at 2022-06-24 09:57:48.243395
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    dummy_list = range(9)
    with tqdm_logging_redirect(dummy_list) as pbar:
        LOG = logging.getLogger(__name__)
        log_msg = "console logging redirected to `tqdm.write()`"
        for i in dummy_list:
            time.sleep(1)
            if i == 4:
                LOG.info(log_msg)
    assert pbar.desc == log_msg

# Generated at 2022-06-24 09:57:49.263002
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)

# Generated at 2022-06-24 09:57:56.466176
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import pretest_posttest

    def setup_logging():
        logging.basicConfig(level=logging.INFO)

    def test_and_cleanup():
        from tqdm import trange
        from tqdm import std_tqdm
        from tqdm.contrib.logging import logging_redirect_tqdm

        log = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    log.info("console logging redirected to `tqdm.write()`")

    return pretest_posttest(setup_logging, test_and_cleanup)


if __name__ == "__main__":
    import nose

# Generated at 2022-06-24 09:58:03.374803
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-24 09:58:10.731416
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(5):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-24 09:58:12.183430
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler()
    assert isinstance(logging_handler, logging.StreamHandler)

# Generated at 2022-06-24 09:58:22.615638
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging
    from io import StringIO
    from contextlib import redirect_stdout

    def _assert_log_to_pbar(pbar, log_func, msg, tqdm_msg, in_progress=False,
                            unit_scale=1):
        # Set pbar to be in progress to skip the messages being printed out twice
        if in_progress:
            pbar.__enter__()
        log_func(msg)
        assert msg in pbar._get_description()
        if unit_scale > 1:
            assert tqdm_msg in pbar._get_description()

    # Check logging.debug
    with StringIO() as buf, redirect_stdout(buf):
        with tqdm_logging_redirect(unit='B') as pbar:
            _

# Generated at 2022-06-24 09:58:24.640316
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.Handler)


# Generated at 2022-06-24 09:58:30.687496
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    def foo():
        LOG.debug("debug")
        LOG.info("info")
        LOG.warning("warning")
        LOG.error("error")
        LOG.critical("critical")

    with logging_redirect_tqdm():
        for i in tqdm.trange(10):
            foo()
        for i in tqdm.tqdm(range(10)):
            foo()
        for i in tqdm.tgrange(10):
            foo()
        with tqdm.trange(10) as t:
            for i in t:
                foo()


# Generated at 2022-06-24 09:58:41.265222
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(
        loggers=[logger],
        file=sys.stderr,
        dynamic_ncols=True,
        tqdm_class=std_tqdm
    ) as pbar:
        logger.debug('tqdm_logging_redirect')
        logger.info('test')
        logger.warning('test')
        logger.debug('test')
        logger.error('test')
        logger.info('test')
        pbar.update(1)


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:58:48.848825
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys
    import unittest
    from tqdm.contrib.logging import _TqdmLoggingHandler
    logging.basicConfig()
    logger = logging.getLogger()
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    old_stdout = sys.stdout

# Generated at 2022-06-24 09:58:57.697713
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Simple tqdm_logging_redirect unit test"""
    import logging

    tqdm_class = std_tqdm

    # Redirects a loop of logs into a tqdm bar
    with tqdm_logging_redirect(loggers=[logging.getLogger()], tqdm_class=tqdm_class):
        for i in range(9):
            logging.info("console logging redirected to `tqdm.write()`")

    # (Expected output:
    # [INFO] console logging redirected to `tqdm.write()`
    # [INFO] console logging redirected to `tqdm.write()`
    # [INFO] console logging redirected to `tqdm.write()`
    # [INFO] console logging redirected to `tqdm.write()