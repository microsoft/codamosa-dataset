

# Generated at 2022-06-24 09:48:50.768130
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert hasattr(tlh,'tqdm_class')
    assert hasattr(tlh,'emit')


# Generated at 2022-06-24 09:48:53.156468
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Test for the constructor of class _TqdmLoggingHandler.
    """
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-24 09:49:00.305449
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import re
    import io
    import sys
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    _TqdmLoggingHandler.emit(
        logging.LogRecord(
            name='',
            level=logging.DEBUG,
            pathname='',
            lineno=1,
            msg='test message',
            args=None,
            exc_info=None),
        sys.stdout,
        log)
    assert re.match(r'^(\x1b[^m]*m)?test message(\x1b[^m]*m)?$',
                    sys.stdout.getvalue())
    # warning: `sys.stdout` is still in use! this is for the demonstration
    # only. don't use `sys.stdout` in real life.
   

# Generated at 2022-06-24 09:49:08.984955
# Unit test for function tqdm_logging_redirect

# Generated at 2022-06-24 09:49:16.656770
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:49:25.975155
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm_testing
    from ..std import tqdm
    from .common import with_docstrings

    # used for testing redirect_stdout
    from io import StringIO
    from contextlib import redirect_stdout

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)


    with _captured_output() as (out, err):
        with logging_redirect_tqdm():
            for i in tqdm_testing.trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:49:29.274382
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert issubclass(logging_handler.tqdm_class, std_tqdm)


# Generated at 2022-06-24 09:49:34.584362
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.root.handlers = []
    logger = logging.getLogger("test")
    logger.setLevel(logging.INFO)
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:49:43.253672
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(0.2)
        assert "console logging redirected to `tqdm.write()`" in open('tqdm_2.txt').read()



# Generated at 2022-06-24 09:49:52.777968
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import warnings
    try:
        from StringIO import StringIO
    except:
        from io import StringIO
    from tqdm import trange


# Generated at 2022-06-24 09:49:58.989789
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    test_string = "test_logging_redirect_tqdm"
    loggers = [logging.getLogger("test_logging_redirect_tqdm")]
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        pbar.write("handler_redirected_to_tqdm_write")
        assert pbar.logger.handlers[0].stream is sys.stderr
        loggers[0].info("logging_redirect_tqdm", extra={"test_key": test_string})
        pbar.write("restored")
        assert pbar.logger.handlers[0].stream is None
        loggers[0].info("logging_redirect_tqdm", extra={"test_key": test_string})

    #

# Generated at 2022-06-24 09:50:08.899029
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from . import util
    from .std import tqdm

    # This is mostly a bogus test, but it ensures that the above unit
    # does not fail catastrophically.
    class DummyTqdm(tqdm):
        def __init__(self, *_, **__):
            pass

    ascii_tqdm, _, _ = util.get_tqdm_class()
    unicode_tqdm, _, _ = util.get_tqdm_class(ascii=False)

    logger = logging.getLogger('dummylogger')
    logger.addHandler(_TqdmLoggingHandler(tqdm_class=DummyTqdm))
    logger.addHandler(_TqdmLoggingHandler(tqdm_class=ascii_tqdm))
    logger.add

# Generated at 2022-06-24 09:50:18.193134
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import pandas as pd
    import csv
    from io import StringIO
    data=pd.read_csv("../../tqdm/tqdm_unicode/examples/tutorials/tutorial_basic.py", header=None, delimiter='\n', quoting=csv.QUOTE_NONE, skipinitialspace=True)
    output = StringIO()
    data.to_csv(output, header=False, index=False)
    with tqdm.redirect_stdout(output):
        temp=output.getvalue()
        test_handler=_TqdmLoggingHandler()
        #assert type(test_handler.tqdm_class)==std_tqdm
        assert test_handler.tqdm_class.__name__=="tqdm"


# Generated at 2022-06-24 09:50:27.208462
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    import time
    from tqdm import tqdm
    from .logging import logging_redirect_tqdm, tqdm_logging_redirect, _TqdmLoggingHandler
    LOG = logging.getLogger(__name__)
    my_logger = logging.getLogger('my_logger')
    my_logger.setLevel(logging.DEBUG)

    # sanity check unit test
    with logging_redirect_tqdm():
        for i in tqdm(range(10), desc="tqdm_logging_redirect test"):
            # logging should be redirected to tqdm
            LOG.info(i)
            # this should be logged to console
            print('-', i)
            time.sleep(.1)
        assert len

# Generated at 2022-06-24 09:50:37.789165
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from typing import Any, Dict
    from tqdm import trange

    from .utils import TestCaseIO

    class MyTqdm(object):
        file = None

        @staticmethod
        def write(s, file=None):
            if file is None:
                file = MyTqdm.file

            if file is not None:
                file.write(str(s))

    class MyLoggingHandler(logging.Handler):

        def emit(self, record):
            pass

    class Test_TqdmLoggingHandler(TestCaseIO):

        def __init__(self, *args, **kwargs):
            super(Test_TqdmLoggingHandler, self).__init__(*args, **kwargs)
            self._expected_results_by_logger_name = {}  #

# Generated at 2022-06-24 09:50:42.972804
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with tqdm_logging_redirect(
            total=2, ncols=40, desc='mode: logging', leave=False) as pbar:
        pbar.set_postfix_str('logging: 0')
        logging.info('logging: 1')
        pbar.set_postfix_str('logging: 2')
        logging.info('logging: 3')

# Generated at 2022-06-24 09:50:44.294882
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-24 09:50:48.143956
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:50:53.269264
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO, format='%(levelname)s:%(message)s')
    with logging_redirect_tqdm([logging.getLogger()]):
        # pylint: disable=W0212
        assert '\n' not in std_tqdm._instances[-1]._postfix_str  # b/c there is no progressbar
        logging.info("logging redirected to `tqdm.write()`")
        assert '\n' not in std_tqdm._instances[-1]._postfix_str
    # logging restored

# Generated at 2022-06-24 09:51:02.717556
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from io import StringIO
    from contextlib import redirect_stdout
    import logging
    import sys

    # test string
    msg = "message"
    # setting up tqdm
    class TestTqdm(object):
        def __init__(self, stream):
            self.stream = stream
            self.init()

        def write(self, msg):
            self.stream.write(msg)
            self.stream.write("\n")

        def init(self):
            self.write("test init")

    test_stream = StringIO()
    test_tqdm = TestTqdm(test_stream)
    # setting up logging
    logger = logging.getLogger()
    logger.addHandler(_TqdmLoggingHandler(test_tqdm))
    logger.warning

# Generated at 2022-06-24 09:51:11.659134
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Check that _TqdmLoggingHandler.emit prints message as expected
    """
    import io

    tempt_out = io.StringIO()
    tempt_in = io.StringIO('test_message\n')
    msg = 'msg'
    record = logging.LogRecord(name='test', level=logging.DEBUG,
                               pathname='path', lineno=1, msg=msg,
                               args={}, exc_info=None)

    t = _TqdmLoggingHandler()
    t.stream = tempt_out

    t.emit(record)

    assert tempt_out.getvalue() == msg + "\n"


# Unit tests for method _get_first_found_console_logging_handler

# Generated at 2022-06-24 09:51:19.127946
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import re
    import sys

    import logging
    import tqdm

    with tqdm_logging_redirect() as pbar:
        logging.info('logging')
    pbar_text = pbar.read()
    assert re.findall('logging', pbar_text)

    with tqdm_logging_redirect(tqdm_class=tqdm.tqdm, desc='tqdm',
                               leave=True, file=sys.stdout) as pbar:
        logging.info('logging')

    pbar_text = pbar.read()
    assert re.findall('tqdm', pbar_text) and re.findall('logging', pbar_text)


# Generated at 2022-06-24 09:51:21.140193
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm
    assert handler.stream == sys.stderr


# Generated at 2022-06-24 09:51:23.013425
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)

# Generated at 2022-06-24 09:51:29.658418
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    # Test the basic functionality
    with logging_redirect_tqdm([], tqdm_class=std_tqdm):
        std_tqdm.write('foo')
        time.sleep(2)
    # Test the context manager
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('foo')
    # Test the context manager
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.root.info('foo')



# Generated at 2022-06-24 09:51:31.383357
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    # TODO: add unit test.
    """

# Generated at 2022-06-24 09:51:41.333393
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    h = _TqdmLoggingHandler()
    class DummyStream(object):
        def __init__(self):
            self.written = []
        def write(self, s):
            self.written.append(s)
    ds = DummyStream()
    h.stream = ds
    h.emit(logging.LogRecord("name", 10, 'filename', 42, "msg %s", ('foo',), None))
    assert ds.written == ["msg foo\n"]
    h.emit(logging.LogRecord("name", 10, 'filename', 42, "%s msg", ('foo',), None))
    assert ds.written == ["msg foo\n", "foo msg\n"]
    h.emit(logging.LogRecord("name", 10, 'filename', 42, "", (), None))


# Generated at 2022-06-24 09:51:48.275917
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    # Can't use logging_redirect_tqdm before logging.basicConfig has been run
    logging.basicConfig(level=logging.INFO)
    for tqdm_class in [tqdm, std_tqdm]:
        with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
            pbar.set_description('foo')
        with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
            with logging_redirect_tqdm(tqdm_class=tqdm_class):
                pbar.set_description('foo')

# Generated at 2022-06-24 09:51:53.022920
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import unittest

    class Test_TqdmLoggingHandler(unittest.TestCase):
        def setUp(self):
            self.handler = _TqdmLoggingHandler()
            self.stream = io.StringIO()
            self.handler.stream = self.stream

        def test_something(self):
            record = logging.LogRecord(
                name='test', level=logging.WARNING, pathname='', lineno=0,
                msg='message', args=(), exc_info=None)
            self.handler.emit(record)
            self.assertEqual(self.stream.getvalue(), 'WARNING:test:message\n')

    unittest.main()

# Generated at 2022-06-24 09:51:58.480600
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc='test', total=2) as pbar:
        logger = logging.getLogger(__name__)
        for i in range(2):
            if i == 1:
                logger.info('console logging redirected to `tqdm.write()`')
    assert pbar.n == 2, pbar

# Generated at 2022-06-24 09:52:08.129486
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest.mock as mock
    except:  # noqa
        import mock
    import logging
    from io import StringIO

    log = logging.getLogger('my_logger')
    handler = mock.MagicMock(spec=logging.Handler)
    log.addHandler(handler)
    log.info("Some info")
    handler.handle.assert_called_once_with(mock.ANY)
    mock.patch("sys.stdout", StringIO()).start()
    with logging_redirect_tqdm([log]):
        log.info("Some info")
        log.warning("Some warning")
        log.error("Some error")
        log.critical("Some critical")
    handler.handle.assert_called_once_with(mock.ANY)

# Generated at 2022-06-24 09:52:12.018493
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        assert(logging.root.handlers[-1].__class__ == _TqdmLoggingHandler)
    assert(logging.root.handlers[-1].__class__ != _TqdmLoggingHandler)

# Generated at 2022-06-24 09:52:19.228159
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import trange
    from .utils import _supports_unicode
    import logging
    with tqdm_logging_redirect(total=9, unicode=_supports_unicode) as pbar:
        for i in trange(9):
            if i == 4:
                logging.warning("console logging redirected to `pbar.write()`")
    # logging restored
    for i in trange(9):
        if i == 4:
            logging.warning("console logging NOT redirected")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:22.862549
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout

    record = logging.LogRecord("test_logger", 0, filename, 1, "test message", [], None)
    handler.emit(record)
    assert handler.stream.getvalue() == "test message\n"


# Generated at 2022-06-24 09:52:30.554135
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from unittest import TestCase
    from ..std import tqdm
    from .logging import _TqdmLoggingHandler as TqdmLoggingHandler

    class DummyLogger(logging.Logger):

        def __init__(self, level, handlers, propagate):
            super(DummyLogger, self).__init__("dummy", level)
            self.handlers = handlers
            self.propagate = propagate

    class TestTqdmLoggingHandler(TestCase):
        def setUp(self):
            out = StringIO()
            tqdm.base_format = '{n}/{total_fmt} - {bar}'
            tqdm.format_meter_size = 9

# Generated at 2022-06-24 09:52:40.741753
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    class MockTqdm(object):
        def __init__(self):
            self.last_written = None

        def write(self, msg, file=None):
            self.last_written = (msg, file)

    tqdm = MockTqdm()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)

    # If no file is supplied, write to stderr
    record = logging.makeLogRecord({})
    tqdm_handler.emit(record)
    assert tqdm.last_written[0] == record.getMessage()
    assert tqdm.last_written[1] is sys.stderr

    # If a file is supplied, write to it
    mock_file = object()
    record = logging.makeLogRecord

# Generated at 2022-06-24 09:52:44.239503
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-24 09:52:52.739233
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from sys import stderr
    from time import time

    stream = StringIO()
    server = logging.handlers.BufferingHandler(
        capacity=65536)
    root = logging.getLogger()
    root.handlers = [server]
    logger = logging.getLogger(__name__)

    handler = _TqdmLoggingHandler(file=stream, tqdm_class=std_tqdm)
    logger.handlers = [handler]

    # log a message
    logger.info('test')
    assert stream.getvalue() == '[{:.0f}] test\n'.format(time())

    # test no stream
    handler.stream = None
    stream.seek(0)
    stream.truncate(0)

# Generated at 2022-06-24 09:52:56.084173
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test = _TqdmLoggingHandler()
    assert test

# Generated at 2022-06-24 09:53:03.709942
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
    assert (tqdm_handler.tqdm_class == tqdm.tqdm)
    assert (isinstance(tqdm_handler, logging.StreamHandler))
    assert (tqdm_handler.stream in {sys.stdout, sys.stderr})
    assert (not hasattr(tqdm_handler, 'stream'))

# Generated at 2022-06-24 09:53:13.296118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(desc="console logging redirected to `tqdm.write()`"):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:53:22.991308
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TestProgress:
        n = 0
        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

        def update(self, i):
            self.n += i

        def write(self, s):
            self.n += len(s)

    stream = TestProgress()
    handler = _TqdmLoggingHandler(tqdm_class=stream)
    handler.emit(logging.LogRecord(
        name='logging_redirect_tqdm',
        level=logging.INFO,
        pathname='',
        lineno=1,
        msg='test 1',
        args=(),
        exc_info=None
    ))
    assert stream.n == 10

# Generated at 2022-06-24 09:53:29.664373
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from time import sleep
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    with tqdm_logging_redirect():
        for i in range(5):
            LOG.info("logging redirected to `tqdm.write()`")
            sleep(0.1)

# Generated at 2022-06-24 09:53:30.613268
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-24 09:53:36.823287
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests.utils import silence_logging  # pylint: disable=redefined-outer-name

    with silence_logging():
        test_message = "test message"
        tqdm_handler = _TqdmLoggingHandler()
        logger = logging.Logger(__name__)
        logger.addHandler(tqdm_handler)
        logger.info(test_message)
        assert std_tqdm.write.get_last_write_out() == test_message

# Generated at 2022-06-24 09:53:46.749863
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # Test that logging works
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)
        LOG.info("Test logging output")
    except:  # noqa pylint: disable=bare-except
        assert False, "logging module not functional"

    # Test redirection to tqdm
    redirected = False
    for _ in tqdm_logging_redirect(total=10, file=sys.stderr, leave=False):
        LOG.info("Testing logging redirection to tqdm")
        redirected = True

    # Test that message was actually displayed by tqdm
    with open("test_logging_redirect_tqdm.txt", "w") as f:
        f.write("Testing logging redirection to tqdm\n")


# Generated at 2022-06-24 09:53:50.405366
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_handler = _TqdmLoggingHandler()
    assert(isinstance(test_handler, logging.StreamHandler))


# Generated at 2022-06-24 09:53:58.741307
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test for `_TqdmLoggingHandler`."""
    from tqdm import tqdm_notebook

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.info("This is a test")
    handler = _TqdmLoggingHandler(tqdm_class=tqdm_notebook)
    logger.handlers = []
    logger.addHandler(handler)
    logger.info("This is another test")



# Generated at 2022-06-24 09:54:06.467356
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test tqdm_logging_redirect function."""
    from .defaults import _DEFAULT_BAR_FORMAT, _DEFAULT_BAR_FORMAT
    from .metaview import _decompose_format_str, _get_unicode_len
    from sys import stdout
    import itertools
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.tests import pretest_posttest, RandomArguments

    def test_tqdm_logging_redirect_fn(
            bar_format=_DEFAULT_BAR_FORMAT,
            loggers=None,
            leave=False):
        """Unit test function of logging_redirect_tqdm."""
        # Test basic use

# Generated at 2022-06-24 09:54:13.624324
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for tqdm_logging_redirect"""
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:17.986516
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    print("** Unit test for constructor of class _TqdmLoggingHandler")
    tqdm_logging_handler = _TqdmLoggingHandler()
    s = tqdm_logging_handler.__class__.__name__
    print("Passed unit test " + s)

test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:54:26.920963
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import trange
    from .std import tqdm as std_tqdm

    # Dummy logger for testing
    class DummyLogger:
        def __init__(self):
            self.handlers = []

        def info(self, msg):
            self.handlers[0].emit(msg)

    logger = DummyLogger()
    logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logger.handlers.append(logging_handler)

    logger.info("TEST")
    assert len(logging_handler.tqdm_class.write.calls) == 1


# Generated at 2022-06-24 09:54:30.748372
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with logging_redirect_tqdm([logging.root]) as pbar:
        logging.info('Info')
        assert 'Info\n' == pbar.read()



# Generated at 2022-06-24 09:54:31.304117
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pass


# Generated at 2022-06-24 09:54:40.828139
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    def assert_str_equal(*strs):
        for s in strs:
            assert isinstance(s, str)
        return all(s == strs[0] for s in strs[1:])

    record = logging.LogRecord(
        name='name',
        level=logging.INFO,
        pathname='path',
        lineno=12,
        msg='msg',
        args=(),
        exc_info=None)

    tqdm_handler = _TqdmLoggingHandler()
    # Test without any handler stream and without any formatter
    tqdm_handler.stream = None
    tqdm_handler.formatter = None
    tqdm_handler.emit(record)
    assert_str_equal(tqdm_handler.stream, sys.stderr)

    # Test without

# Generated at 2022-06-24 09:54:48.230702
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from time import sleep
    from tqdm import tqdm

    with tqdm_logging_redirect(total=1e7) as pbar:
        for i in pbar:
            sleep(0.0001)
            if i > 5e4:
                tqdm.write('test')


if __name__ == '__main__':
    from tqdm import _tqdm
    test_tqdm_logging_redirect()
    test_tqdm_logging_redirect(total=1e7, miniters=0, mininterval=0)
    test_tqdm_logging_redirect(total=1e7, tqdm_class=_tqdm)

# Generated at 2022-06-24 09:54:59.503708
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test logging in a subprocess
    from multiprocessing import Process
    from pytest import raises
    from .utils import SimpleNamespace
    from ..std import tqdm_gui, tqdm_notebook

    def proc_run(tqdm_class):
        with SimpleNamespace() as ns:  # noqa
            ns.called = 0
            ns.tqdm_class = tqdm_class
            ns.handler = _TqdmLoggingHandler(ns.tqdm_class)

            def exc_handler(record):
                # type: (logging.LogRecord) -> None
                ns.called += 1
                print(record)
                assert record.getMessage() == 'Test'

            ns.handler.handleException = exc_handler  # type: ignore

# Generated at 2022-06-24 09:55:06.503119
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    stream = io.StringIO()
    # print(f'real_stdout {real_stdout}')
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)  # type: ignore
    logger = logging.getLogger('ut_logger')
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    handler.stream = stream
    logger.addHandler(handler)
    logger.info('hello world')
    assert stream.getvalue() == 'hello world\n'
    handler.close()
    logger.removeHandler(handler)


# Generated at 2022-06-24 09:55:09.771388
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logger = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(tqdm_logger, logging.StreamHandler)

# Generated at 2022-06-24 09:55:17.682219
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(desc='a-logging_test') as log_pbar:
        assert log_pbar.total == 1,  "Expected: 1, actual: {}".format(log_pbar.total)
        log_pbar.update(1)
        logging.info("Test message")
    assert log_pbar.total == 1, "Expected: 1, actual: {}".format(log_pbar.total)

# Generated at 2022-06-24 09:55:23.567018
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    >>> logging.basicConfig(level=logging.INFO)
    >>> with logging_redirect_tqdm():
    ...     logging.info("current state: ok")
    current state: ok
    """
    pass

# Generated at 2022-06-24 09:55:26.313498
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test the constructor of class _TqdmLoggingHandler"""
    fh = _TqdmLoggingHandler()
    assert fh.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:55:32.215792
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import _range, _writeln  # pylint: disable=import-error
    try:
        from unittest.mock import patch  # python 3
    except ImportError:
        from mock import patch  # python 2
    # redirecting logging.StreamHandler to tqdm.write()
    with patch('sys.stdout', _writeln), logging_redirect_tqdm():
        logging.info('message')
        _range(3)
        logging.info('message')

    # redirecting logging.StreamHandler to tqdm.write()
    with patch('sys.stdout', _writeln), logging_redirect_tqdm():
        logging.info('message')
        _range(3)
        logging.info('message')

    # preserving logging.StreamHandler to sys.stdout


# Generated at 2022-06-24 09:55:35.944207
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    t = _TqdmLoggingHandler()
    record = logging.LogRecord(name='name',
                               level=logging.INFO,
                               pathname='path',
                               lineno=42,
                               msg='Hello World',
                               args=(),
                               exc_info=None)
    t.emit(record)

# Generated at 2022-06-24 09:55:38.331515
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)


# Generated at 2022-06-24 09:55:47.508635
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    # default loggers=[logging.root]
    with tqdm_logging_redirect():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # loggers=[LOG]
    with tqdm_logging_redirect(loggers=[LOG]):
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # with tqdm instance `pbar`

# Generated at 2022-06-24 09:55:52.950007
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import time

    class FooTqdm(std_tqdm):
        def write(self, s, file=sys.stderr, refresh=True):
            super(FooTqdm, self).write(s, file=file)


    class FooLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            super(FooLoggingHandler, self).__init__(FooTqdm)

    def test_foo_logging_handler():
        logging.basicConfig(level=logging.DEBUG, format='%(message)s')
        log = logging.getLogger(__name__)
        handler = FooLoggingHandler()
        log.disabled = False
        log.addHandler(handler)
        log.info("this is a test")
       

# Generated at 2022-06-24 09:55:57.589075
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from . import tqdm_test_cases as test_cases
    with tqdm_logging_redirect(loggers=[logging.getLogger()]) as pbar:
        for __ in range(2):
            pbar.update()
    test_cases.test_tqdm_logging_redirect_logging_redirect_tqdm()

# Generated at 2022-06-24 09:56:04.470932
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    import sys
    import unittest

    sys.stderr = io.StringIO()  # redirect stderr in unit tests

    class Test__TqdmLoggingHandler(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.handler = _TqdmLoggingHandler()

        @classmethod
        def tearDownClass(cls):
            del cls.handler

        def test_constructor(self):
            self.assertIsInstance(self.handler, _TqdmLoggingHandler)
            self.assertIs(self.handler.tqdm_class, std_tqdm)

    unittest.main(buffer=True, exit=False)



# Generated at 2022-06-24 09:56:14.208059
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=unused-variable
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to tqdm.write()")

# Generated at 2022-06-24 09:56:23.374936
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm as std_tqdm
    from io import StringIO
    import logging
    import sys
    import time

    _IS_IN_IPYTHON = True
    try:
        import IPython  # pylint: disable=unused-import
    except ImportError:
        _IS_IN_IPYTHON = False

    out_stream = StringIO()
    err_stream = StringIO()
    std_tqdm.tqdm_gui.io.stdout = out_stream
    std_tqdm.tqdm_gui.io.stderr = err_stream
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler = tqdm_handler.emit
    logger = logging.getLogger()

# Generated at 2022-06-24 09:56:27.921074
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(0, 10):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
    # logging restored


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:56:30.973658
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = _TqdmLoggingHandler()
    logger.addHandler(ch)
    logger.debug("test__TqdmLoggingHandler")

# Generated at 2022-06-24 09:56:36.677212
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:56:41.506093
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # no top level tqdm object exists, so should get the std_tqdm object
    assert _TqdmLoggingHandler().tqdm_class is std_tqdm
    # not running in an ipython shell should also get the std_tqdm object
    class MockShell(object):
        ipython_shell = False
    ishell = MockShell()

# Generated at 2022-06-24 09:56:50.579425
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ._tqdm_test_cases import BaseTestTqdm
    with BaseTestTqdm(__name__) as bt:

        # Kernel tests
        import logging

        with bt.hidden(), bt.nested(1, leave=False) as ns:
            with logging_redirect_tqdm():
                logger = logging.getLogger(__name__)
                logger.warn('warn')
                logger.info('info')
                logger.debug('debug')

        with bt.hidden(), bt.nested(2, leave=False) as ns:
            with logging_redirect_tqdm(loggers=[logging.getLogger('test_logger')]):
                logger = logging.getLogger(__name__)
                logger.warn('warn')
                logger.info('info')
               

# Generated at 2022-06-24 09:56:56.171944
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    r"""Unit test for function `logging_redirect_tqdm`."""
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:57:05.556497
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm
    LOG = logging.getLogger()
    LOG.setLevel('INFO')
    LOG.handlers = []
    try:
        with tqdm_logging_redirect(total=2, desc='test log redirect') as bar:
            bar.write('test `tqdm.write()`')  # should not redirect
            bar.n = 1
            bar.refresh()
            LOG.info('console logging redirected to `tqdm.write()`')
    except Exception as e:
        raise e
        return False
    else:
        return True

# Generated at 2022-06-24 09:57:08.873004
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger('TestLogger')
    try:
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("Console logging redirected to `tqdm.write()`")
    except:
        pass


# Generated at 2022-06-24 09:57:09.925116
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:57:12.458855
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_l = _TqdmLoggingHandler()
    return tqdm_l

# Generated at 2022-06-24 09:57:18.651234
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.shutdown()
    # Testing class constructor
    try:
        tqdm_logging_handler = _TqdmLoggingHandler()
    except Exception as error:
        raise Exception(
            "Failed when attempting to create class _TqdmLoggingHandler: {}"
            .format(error))

    if not isinstance(tqdm_logging_handler, logging.StreamHandler):
        raise Exception("_TqdmLoggingHandler is not of type StreamHandler")

# Generated at 2022-06-24 09:57:31.404790
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class MockTqdm(object):
        def __init__(self):
            self.msg_list = []

        def write(self, msg, file=None, flush=None):
            self.msg_list.append(msg)

    mock_tqdm_obj = MockTqdm()
    handler = _TqdmLoggingHandler(tqdm_class=mock_tqdm_obj)
    assert(handler.stream is sys.stderr)
    assert(isinstance(handler, logging.Handler))
    record = logging.LogRecord(name='foo', level=logging.INFO,
                               pathname='/foo/bar.py', lineno=23,
                               msg='logging.info(%s)', args='test_msg',
                               exc_info=None)

# Generated at 2022-06-24 09:57:42.221704
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm as _std_tqdm
    from six import StringIO

    def _test_function(
            old_logger,
            new_logger,
            new_logger_stream,
            old_logger_stream,
            tqdm_class=_std_tqdm
    ):
        old_logger_format = old_logger.handlers[0].formatter._fmt
        old_logger.info('test_message')
        assert new_logger_stream.getvalue() == 'test_message\n'
        assert old_logger_stream.getvalue() == ''
        old_logger.info('test_message2')
        assert (new_logger_stream.getvalue() ==
                'test_message\ntest_message2\n')

# Generated at 2022-06-24 09:57:47.644691
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = ['logger1', 'logger2']
    with tqdm_logging_redirect('test', loggers=loggers) as pbar:
        assert pbar._name == 'test'
        assert pbar.loggers == loggers

# Testing the function tqdm_logging_redirect
test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:57:57.062728
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger(__name__)
    try:
        import unittest
        import unittest.mock
    except ImportError:
        import mock
        unittest = mock.Mock()
        unittest.mock = mock

    class TqdmLoggingHandler_(TqdmLoggingHandler):
        @unittest.mock.patch('tqdm.std.tqdm.write')
        def write(self, tqdm_write_mock, msg):
            TqdmLoggingHandler.write(msg)

    with unittest.mock.patch('tqdm.contrib.logging._TqdmLoggingHandler',
                             new=TqdmLoggingHandler_):
        with logging_redirect_tqdm():
            log.info('F')
           

# Generated at 2022-06-24 09:57:58.940372
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    _TqdmLoggingHandler().emit(logging.LogRecord(level=logging.INFO, msg='x'))

# Generated at 2022-06-24 09:58:08.603952
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Initialize logging
    logging.basicConfig(level=logging.INFO)

    # Log to console
    logging.info("This is the usual console logging...")

    # Run logging_redirect_tqdm
    with logging_redirect_tqdm():
        # Log to console
        logging.info("... but this is redirected to tqdm.write()!")
        # Log to file
        logging.getLogger().addHandler(
            logging.FileHandler("test_logging_redirect_tqdm.log", mode='w'))
        logging.info("This is file logging.")

    # Log to console
    logging.info("console logging restored")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:58:16.315952
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from . import _TqdmLoggingHandler
    class MockPbar(object):
        def __init__(self, file):
            self.file = file
            self.msg = None
        def write(self, msg):
            self.msg = msg
    pbar = MockPbar(sys.stdout)
    with redirect_stdout(sys.stdout):
        handler = _TqdmLoggingHandler(tqdm_class=pbar)
        msg = 'Test message'
        record = logging.LogRecord(name='Test', level='INFO',
                                   filename='filename', lineno=1,
                                   msg=msg, args=None, exc_info=None)
        handler.emit(record)
        assert pbar.msg == msg

# Generated at 2022-06-24 09:58:21.618078
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging
    LOGGER = logging.getLogger()
    for i in trange(4):
        LOGGER.info(i)
        if i == 1:
            with logging_redirect_tqdm():
                for j in trange(4):
                    LOGGER.info(j)
    for i in trange(4):
        LOGGER.info(i)


# Generated at 2022-06-24 09:58:28.279264
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test function tqdm_logging_redirect."""
    from tqdm import tqdm

    tqdm_stdout = tqdm_logging_redirect(tqdm_class=tqdm)
    loggers = [logging.getLogger('tqdm'), logging.root]

    with tqdm_stdout(total=99):
        with logging_redirect_tqdm(loggers=loggers):
            logging.info('hello world!')

# Generated at 2022-06-24 09:58:34.984577
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test the method emit of _TqdmLoggingHandler.
    This method is the one responsible for the logging display.
    """
    from tqdm.auto import tqdm
    tqdm.monitor_interval = 0
    original_handlers = tqdm.wrapattr(sys.stdout, '_handlers')

# Generated at 2022-06-24 09:58:39.234206
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=2, file=sys.stdout) as pbar:
        assert isinstance(pbar, std_tqdm)
        assert pbar.total == 2
        assert pbar.file == sys.stdout
        assert pbar.disable is False

# Generated at 2022-06-24 09:58:46.197522
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    # pylint: disable=import-outside-toplevel, unused-import
    import logging

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger('test_logging_redirect_tqdm')

    with logging_redirect_tqdm():
        for i in range(3):
            LOG.info('Hello World')
    for i in range(3):
        LOG.info('Hello Again')


test_logging_redirect_tqdm.unit = True  # pylint: disable=invalid-name

# Generated at 2022-06-24 09:58:49.710600
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .tests import tqdm_class_instantiation
    tqdm_class = tqdm_class_instantiation()
    assert _TqdmLoggingHandler(tqdm_class=tqdm_class)