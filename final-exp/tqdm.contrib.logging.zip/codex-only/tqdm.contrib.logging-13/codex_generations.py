

# Generated at 2022-06-24 09:48:52.728190
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm
    import io

    tqdm_class = tqdm
    tqdm_class.write = lambda s, file: file.write(s)
    tqdmlh = _TqdmLoggingHandler(tqdm_class)
    tqdmlh.stream = io.StringIO()

    record = 'abc'
    tqdmlh.emit(record)
    assert tqdmlh.stream.getvalue() == record + '\n'
    tqdmlh.stream.close()

# Generated at 2022-06-24 09:48:56.294557
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    for i in range(10):
        logger.info('Log message %d', i)
    logger.handlers[0].setLevel(logging.INFO)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 5:
                logger.info('Log message %d', i)
            pbar.update()

# Generated at 2022-06-24 09:49:01.683992
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(desc='console logging redirected to `tqdm.write()`'):
            LOG.info('hello')

# Generated at 2022-06-24 09:49:03.465773
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)



# Generated at 2022-06-24 09:49:07.071037
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from .logging_redirect_tqdm import _TqdmLoggingHandler  # type: ignore
    import logging
    import sys

    with StringIO() as buffer:
        handler = _TqdmLoggingHandler()
        handler.stream = buffer
        record = logging.LogRecord(
            level=logging.INFO, msg="hello world!", name="name")
        handler.emit(record)
        assert buffer.getvalue() == "hello world!\n"

# Generated at 2022-06-24 09:49:11.217420
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tnrange, logging as tqdm_logging
    from . import tqdm
    import logging

    log = logging.getLogger(__name__)

    try:
        # Test tqdm_logging_redirect
        log.setLevel(logging.INFO)
        with tqdm_logging_redirect(total=5, tqdm_class=tnrange,
                                   loggers=[tqdm_logging.root]):
            for i in range(5):
                if i == 2:
                    log.info('Message')
    finally:
        tqdm_logging.root.level = tqdm_logging.root.level

# Generated at 2022-06-24 09:49:21.824510
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .common import comparison  # avoid circular imports

    import logging
    LOG = logging.getLogger()
    LOG.setLevel(logging.DEBUG)
    log_stream = sys.stderr

    def get_log_messages():
        log_stream.seek(0)
        return [line.strip() for line in log_stream.readlines()]

    with tqdm_logging_redirect():
        logging.debug('this is a debug msg')
        logging.info('this is an info msg')
        logging.warning('this is a warning msg')
        logging.error('this is an error msg')
        logging.critical('this is a critical msg')


# Generated at 2022-06-24 09:49:32.621703
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # test for succeed case
    logging.root.handlers = []
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logging.root.addHandler(handler)
    logging.root.setLevel(logging.DEBUG)
    logging.debug("test")
    # test for error case
    logging.root.handlers = []
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logging.root.addHandler(handler)
    logging.root.setLevel(logging.DEBUG)

# Generated at 2022-06-24 09:49:37.750692
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = logging.getLogger('loggers')
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(loggers=loggers):
        logging.error("logging.error")
        logging.warning("logging.warning")
        logging.info("logging.info")
        logging.debug("logging.debug")
        logging.info("console logging redirected to tqdm.write")
        logging.info("end of test")
    logging.info("logging restored")

# Generated at 2022-06-24 09:49:45.940022
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:49:50.214984
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}


# # Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-24 09:49:53.978395
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Tests constructor with default tqdm class
    _TqdmLoggingHandler()
    # Tests constructor with StdTqdm
    from ..std import tqdm as std_tqdm_class
    _TqdmLoggingHandler(std_tqdm_class)


# Generated at 2022-06-24 09:49:58.141194
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(unit='I', unit_scale=True,
                               desc="It's a trap!") as pbar:
        for i in pbar:
            if i == 1000:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:50:04.406615
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm
    from tqdm._utils import _term_move_up

    # Initialize tqdm_handler
    out = StringIO()
    tqdm_handler = _TqdmLoggingHandler(tqdm)
    tqdm_handler.stream = out

    # Test write message to logger by tqdm_handler
    logger = logging.getLogger("test_tqdm_logging_handler_emit_logger")
    logger.setLevel(logging.INFO)
    logger.addHandler(tqdm_handler)
    logger.info("Hello world!")
    assert out.getvalue() == "Hello world!" + _term_move_up()

    # Test write error message
    out = StringIO()
    tqdm_handler.stream

# Generated at 2022-06-24 09:50:10.080488
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import sys
    with StringIO() as buffer:
        sys.stdout = buffer
        tlh = _TqdmLoggingHandler()
        record = logging.LogRecord('name', logging.INFO, 
                                   pathname='/a/b/c', lineno=1,
                                   msg='message', args={}, exc_info=None)
        tlh.emit(record)
        assert buffer.getvalue() == 'message\n'

# Generated at 2022-06-24 09:50:19.962962
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger("test")
    LOG.setLevel(logging.DEBUG)

    if __name__ == '__main__':
        # set up logger
        LOG.propagate = False
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        ch = logging.StreamHandler(stream=sys.stdout)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        LOG.addHandler(ch)

        # test case

# Generated at 2022-06-24 09:50:21.888015
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger()
    logger.addHandler(_TqdmLoggingHandler())
    logger.info("Test")

# Generated at 2022-06-24 09:50:30.249540
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    with StringIO() as buf:
        handler.stream = buf
        logger.info('test')
        logger.warning('test')
        logger.error('test')

    # test different log level
    assert len(buf.getvalue().splitlines()) == 3

    # test output is stdout/stderr
    handler.stream = sys.stderr
    logger.info('test')

# Generated at 2022-06-24 09:50:39.648665
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    tqdm_class = std_tqdm
    loggers = [logging.root, logging.getLogger()]
    msg = ['Foo', 'Bar']

    for logger in loggers:
        for handler in logger.handlers:
            assert isinstance(handler, logging.Logger)

    with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
        for logger in loggers:
            for handler in logger.handlers:
                assert not _is_console_logging_handler(handler)
            logger.info(msg[0])
        with tqdm_class() as pbar:
            for logger in loggers:
                logger.info(msg[1])


# Generated at 2022-06-24 09:50:44.294337
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with _TqdmLoggingHandler(std_tqdm.tqdm) as tqdm_handler:
        assert tqdm_handler.tqdm_class == std_tqdm.tqdm
        assert type(tqdm_handler) is _TqdmLoggingHandler
        assert len(tqdm_handler.stream) == 1



# Generated at 2022-06-24 09:50:48.386962
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:50:52.672054
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.Logger(name=__name__)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)

    with tqdm_logging_redirect(loggers=[logger]):
        logger.info('hello world')

# Generated at 2022-06-24 09:50:57.172905
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    for i in range(9):
        if i == 4:
            with logging_redirect_tqdm():
                LOG.info("console logging redirected to `tqdm.write()`")
        else:
            LOG.info("console logging NOT redirected")



# Generated at 2022-06-24 09:51:03.334786
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:51:10.062193
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.utils import _term_move_up

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(5):
            if i == 2:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

# Generated at 2022-06-24 09:51:17.145124
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import time
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    with std_tqdm(loop=True) as pbar:
        time.sleep(0.1)
        logger.info("Some information!")
        time.sleep(0.1)
        logger.debug("Some debug information!")
        time.sleep(0.1)
        logger.warn("A warning!")
        time.sleep(0.1)
        logger.warning("Another warning!")
        time.sleep(0.1)
        logger.info("Some more information!")
        time.sleep(0.1)
        logger.critical("A critical message!")
        time.sleep(0.1)

# Generated at 2022-06-24 09:51:27.316927
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    import tqdm
    s_io = StringIO()
    with std_tqdm(file=s_io) as pbar:
        # redirect logging
        with logging_redirect_tqdm(loggers=[logging.root]):
            for _ in range(20):
                if _ == 4:
                    LOG.info('console logging redirected to `tqdm.write()`')
                pbar.update()
        # restore logging
        for _ in range(20):
            if _ == 4:
                LOG.info('console logging restored to `stdout`')
            pbar

# Generated at 2022-06-24 09:51:33.161668
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    obj = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert obj.stream in {sys.stdout, sys.stderr}
    assert obj.lock is None
    assert obj.formatter is None
    assert obj.level == 0
    assert obj.tqdm_class == std_tqdm



# Generated at 2022-06-24 09:51:36.093123
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Test constructor of class _TqdmLoggingHandler
    """
    obj = _TqdmLoggingHandler();
    return True;


# Generated at 2022-06-24 09:51:43.515330
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    __test__ = True  # type: ignore[assignment]
#     import logging
#     log_format = "%(asctime)s - %(levelname)s | %(message)s"
#     logging.basicConfig(level=logging.DEBUG, format=log_format)
#     LOG = logging.getLogger(__name__)
# #     LOG.info("Start test a")
#     with tqdm_logging_redirect():
#         with tqdm_logging_redirect():
#             with tqdm_logging_redirect():
# #                 LOG.info("Start test b")
#                 for i in range(100):
#                     LOG.debug(i)
#                 for i in range(100):
#                     LOG.info(i)
#                 for i in range(100):


# Generated at 2022-06-24 09:51:53.128245
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.utils import _supports_unicode
    log_level = logging.INFO
    logging.basicConfig(
        format="%(levelname)s:%(message)s", level=log_level)
    handler = _TqdmLoggingHandler()
    handler.setLevel(log_level)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.info('\u2028')
    assert handler.tqdm_class.write.called
    assert not handler.handleError.called
    assert handler.format.called
    assert getattr(handler.stream, 'buffer', None) is None
    if _supports_unicode():
        assert handler.tqdm_class.write.called_with('INFO: ')


# Generated at 2022-06-24 09:52:02.320888
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import tempfile
    with tempfile.TemporaryFile() as temp_file:
        # Create a logging handler that is bound to a temporary file
        temp_handler = logging.StreamHandler(temp_file)
        # Create a _TqdmLoggingHandler instance and bind it to the same temporary file
        tqdm_handler = _TqdmLoggingHandler()
        tqdm_handler.stream = temp_file
        # Emit two log messages with both handlers
        temp_handler.emit(logging.LogRecord('name', logging.INFO, None, None, 'message 1', None, None))
        tqdm_handler.emit(logging.LogRecord('name', logging.INFO, None, None, 'message 2', None, None))
        # Assert that the two messages have been written to the

# Generated at 2022-06-24 09:52:11.802642
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect.

    Example
    -------
    >>> test_tqdm_logging_redirect()
    """
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9) as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:52:14.003563
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-24 09:52:19.534396
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:52:24.887169
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tnrange

    with tnrange(10) as pbar:
        log = _TqdmLoggingHandler(tqdm_class=pbar.__class__)
        log.stream = StringIO()
        log.emit(logging.LogRecord("logger", 10, "path/to/file", 10, "message", None, None))

if __name__ == "__main__":
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-24 09:52:30.513916
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    stdout = sys.stdout
    try:
        from io import StringIO
        f = StringIO()
        sys.stdout = f
        stream = _TqdmLoggingHandler().stream
        stream.write('hello')
        sys.stdout = stream
        print('world')
        sys.stdout = f
        assert f.getvalue() == 'hello\nworld\n'
    finally:
        sys.stdout = stdout

# Generated at 2022-06-24 09:52:35.877451
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import trange
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:52:44.039882
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create _TqdmLoggingHandler object
    t = _TqdmLoggingHandler()

    # create logging message
    msg = "test message"

    # create logging object
    logger = logging.getLogger(__name__)

    # set level of logging object
    logger.setLevel(logging.INFO)

    # create console logger
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)

    # set format of logger
    formatter = logging.Formatter('%(asctime)s  %(levelname)-8s %(message)s')
    console.setFormatter(formatter)

    # add handler to logger
    logger.addHandler(console)

    # write test message
    logger.info(msg)

# Generated at 2022-06-24 09:52:46.308229
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert (isinstance(tqdm_handler, _TqdmLoggingHandler))


# Generated at 2022-06-24 09:52:50.575059
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test _TqdmLoggingHandler constructor."""
    default = _TqdmLoggingHandler()
    assert(default.tqdm_class == std_tqdm)

    alternate = _TqdmLoggingHandler(tqdm_class=tqdm.tqdm)
    assert(alternate.tqdm_class == tqdm.tqdm)



# Generated at 2022-06-24 09:53:02.060820
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Make a mock logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    tqdm_handler.setFormatter(formatter)
    logger.addHandler(tqdm_handler)

    # Write an info message
    logger.info('write to tqdm')

# Generated at 2022-06-24 09:53:10.518461
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    handler_obj = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    orig_stream = handler_obj.stream
    try:
        handler_obj.stream = StringIO()

        # Test handler_obj with an empty record
        test_record = logging.LogRecord('', 0, '', 0, '', [], None)
        handler_obj.emit(test_record)
        assert handler_obj.stream.getvalue() == ''

        # Test handler_obj with a proper record
        test_record = logging.LogRecord('', 0, '', 0, 'Message', [], None)
        handler_obj.emit(test_record)
        assert handler_obj.stream.getvalue() == 'Message'
    finally:
        handler_obj.stream = orig_

# Generated at 2022-06-24 09:53:19.162960
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    log = logging.getLogger(__name__)
    assert not any([_is_console_logging_handler(h) for h in log.handlers])
    with tqdm_logging_redirect(total=1) as pbar:
        log.info("Hello world!")
        pbar.update(1)
    assert not any([_is_console_logging_handler(h) for h in log.handlers])

# Generated at 2022-06-24 09:53:30.324412
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys

    test_string = "test emit method"

    # Set stdout to io.StringIO
    sys.stdout = io.StringIO()
    # Test on file not sys.stdout
    tqdm_logging_file = io.StringIO()

    # test logging handler
    test_tqdm_logging_handler = _TqdmLoggingHandler()

    # Set stream of logging handler to io.StringIO instance
    test_tqdm_logging_handler.stream = tqdm_logging_file

    # Create a record
    record = logging.LogRecord("root", logging.INFO, "test_file", 123, test_string, None, None)

    # Call emit method with record
    test_tqdm_logging_handler.emit(record)



# Generated at 2022-06-24 09:53:36.667207
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import sys
    import time
    from contextlib import contextmanager
    from ..std import tqdm as std_tqdm
    from ..std import time as std_time
    from .std import get_terminal_size


# Generated at 2022-06-24 09:53:38.778754
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdmlogHandler = _TqdmLoggingHandler()
    assert tqdmlogHandler is not None


# Generated at 2022-06-24 09:53:48.225008
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """ Test the functionality of tqdm_logging_redirect """
    tqdm_class = std_tqdm
    output_list = []

    def _mock_write(msg):
        """ Mock tqdm.write """
        output_list.append(msg)

    with tqdm_class(unit='B', leave=False, ascii=True) as pbar:
        # Make sure only root logger is affected
        pbar.write('It is not a valid message.\n')
        output_list.clear()

        with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
            pbar.write('It is not a valid message.\n')
            assert len(output_list) == 0

            # Make sure messages are submitted to logging with log level

# Generated at 2022-06-24 09:54:01.407683
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test function for the _TqdmLoggingHandler class.
    """
    import re

    import six

    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler

    class _TqdmLoggingHandlerTester(object):
        """
        Class for testing the _TqdmLoggingHandler class.
        """

        @staticmethod
        def _get_logger():
            """
            Return a logger.
            """
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.INFO)
            return logger

        def _get_handler(self):
            """
            Return a handler for the logger..
            """
            return _TqdmLoggingHandler()


# Generated at 2022-06-24 09:54:05.292927
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests_common import _suppress_stderr

    handler = _TqdmLoggingHandler()
    record = logging.makeLogRecord({'msg': 'test_message'})

    for stream in [sys.stdout, sys.stderr]:
        with _suppress_stderr():
            handler.stream = stream
            handler.emit(record)

# Generated at 2022-06-24 09:54:16.662680
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm.utils import _supports_unicode  # pylint: disable=import-error
    text = 'abc'
    if _supports_unicode():
        text += '\u2665'  # heart symbol
    with _TqdmLoggingHandler() as hdl:
        hdl.emit(logging.LogRecord(
            'LoggerName',
            logging.INFO,  # pylint: disable=no-member
            '',
            0,
            text,
            None,
            None))


if __name__ == '__main__':
    import logging
    from tqdm import trange

# Generated at 2022-06-24 09:54:21.344616
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=undefined-variable
    log = logging.getLogger("tqdm")
    hand = _TqdmLoggingHandler()
    log.addHandler(hand)
    log.warning("before")
    with logging_redirect_tqdm():
        log.warning("during")
    log.warning("back to normal")



# Generated at 2022-06-24 09:54:29.114282
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange, tqdm_notebook, tqdm_gui, tqdm_pandas

    try:
        from matplotlib import pyplot as plt
        from tqdm import tqdm_pandas
    except ImportError:
        pass

    is_jupyter = 'ipykernel' in sys.modules

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-24 09:54:39.465511
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import (
        logging_redirect_tqdm, tqdm_logging_redirect)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        # test that the handler is removed
        len_before = len(LOG.handlers)
        with logging_redirect_tqdm():
            pass
        len_after = len(LOG.handlers)
        assert len

# Generated at 2022-06-24 09:54:46.570966
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    from . import tgrange

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Set up stream for testing
    s = io.StringIO()
    logger.handlers = [logging.StreamHandler(s)]

    # Write test messages to logger
    with tgrange(9) as bar:
        logger.info("logging to tqdm")
        logger.info("logging to tqdm again")
        bar.update()

    with tgrange((i for i in range(9))) as bar:
        logger.info("logging to lazy tqdm")

# Generated at 2022-06-24 09:54:49.200876
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdmLogHandler = _TqdmLoggingHandler()
    assert tqdmLogHandler.tqdm_class == std_tqdm

# Generated at 2022-06-24 09:54:57.593125
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging

    log_capture_string = StringIO()
    test_logger = logging.getLogger()

    test_logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.stream = log_capture_string
    test_logger.addHandler(tqdm_handler)

    test_logger.info('test')
    log_test = log_capture_string.getvalue()
    assert log_test == 'test\n'

# Generated at 2022-06-24 09:55:04.089607
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    loggers = [logging.root, logging.getLogger("__main__")]
    # loggers = None

    logging.basicConfig(level=logging.INFO)

    for i in trange(9):
        if i == 4:
            with tqdm_logging_redirect(
                    loggers=loggers,
                    tqdm_class=lambda x: x) as pbar:
                for k in range(9):
                    if k == 4:
                        assert pbar is not None
                        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:05.759499
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert(isinstance(handler, logging.StreamHandler))

# Generated at 2022-06-24 09:55:12.444936
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:55:24.046270
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    log_msg = 'log'
    record = logging.LogRecord(
        level=logging.INFO,
        pathname='pathname',
        lineno=1,
        msg=log_msg,
        args=None,
        exc_info=None
    )

    # direct call -> no output
    handler.emit(record)

    # tqdm write -> output
    handler_stream = handler.stream
    handler.stream = sys.stdout
    handler.emit(record)
    assert handler_stream.getvalue().strip() == 'INFO:pathname:1:log'
    handler_stream.truncate(0)
    handler_stream.seek(0)

# Generated at 2022-06-24 09:55:30.399271
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9, desc='logging redirected') as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        # print something to stdout to make sure that we still have stdout
        print('stdout restored')
        # assert that the loop is finished
        assert pbar.n == 9



# Generated at 2022-06-24 09:55:38.304068
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    buf = StringIO()
    old_stdout, sys.stdout = sys.stdout, buf
    hdlr = _TqdmLoggingHandler()
    hdlr.setFormatter(logging.Formatter('%(filename)s:%(lineno)d:%(msg)s'))
    hdlr.emit(logging.LogRecord(
        name='test', level=logging.INFO, fn='foo', lno=123, msg='hello',
        args=(), exc_info=None, func='bar'))
    assert buf.getvalue().strip() == 'foo:123:hello'
    sys.stdout = old_stdout

# Generated at 2022-06-24 09:55:45.862984
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    import logging
    from tqdm import tqdm

    # This is necessary to avoid the RuntimeWarning:
    # "No handlers could be found for logger "tqdm.contrib.logging"."
    logging.basicConfig()

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect():
            for i in tqdm(range(0, 10)):
                if i == 5:
                    LOG.info("hello world")

# Generated at 2022-06-24 09:55:52.298434
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging_redirect_tqdm(loggers=[logging.getLogger('tqdm')])
    logging.getLogger('tqdm').error('tqdm error message')
    logging.getLogger('tqdm').info('tqdm info message')
    logging.getLogger('tqdm.contrib').info('tqdm.contrib info message')

# Generated at 2022-06-24 09:56:01.135061
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tests_tqdm._utils import closing, testing

    class _TqdmClassStub(object):
        @staticmethod
        def write(*a, **k):
            pass  # pragma: nocover

    with testing.captured_output() as captured, closing(
            logging.getLogger()  # type: ignore
    ) as logger:
        logger.setLevel(logging.DEBUG)
        tqdm_handler = _TqdmLoggingHandler(_TqdmClassStub)
        tqdm_handler.setFormatter(logging.Formatter('[%(asctime)s %(levelname)s] %(message)s'))
        logger.addHandler(tqdm_handler)
        logger.debug('test')
        assert captured.getvalue() == ''

# Generated at 2022-06-24 09:56:08.064874
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    import logging
    from tqdm.contrib import logging_redirect_tqdm
    logger = logging.getLogger(__name__)
    hdlr = logging.StreamHandler(sys.stderr)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        logger.info('Hello World!')



# Generated at 2022-06-24 09:56:17.633917
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect."""
    import logging
    from tqdm import _utils

    def test_logging_redirect_tqdm():
        """Unit test for function logging_redirect_tqdm."""
        logger = logging.getLogger(__name__)
        with tqdm_logging_redirect() as pbar:
            for i in range(9):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")
                pbar.update()
            assert pbar.n == 9

    def test_logging_redirect_tqdm_custom():
        """Unit test for function logging_redirect_tqdm_custom."""
        logging.root.setLevel(logging.INFO)
        logger = logging

# Generated at 2022-06-24 09:56:26.426017
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            with tqdm(desc="test1") as pbar:
                for i in range(9):
                    pbar.update()
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

        with tqdm_logging_redirect(desc="test2"):
            LOG.info("All in one function")

# Generated at 2022-06-24 09:56:28.164644
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with logging_redirect_tqdm():
        assert isinstance(_TqdmLoggingHandler(), logging.StreamHandler)


# Generated at 2022-06-24 09:56:37.342009
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import unittest.mock as mock
    import io

    class FakeTqdm:

        def __init__(self):
            self.count_write = 0
            self.fake_write = list()

        def write(self, *args, **kwargs):
            self.count_write += 1
            self.fake_write.append(args)

    fake_tqdm = FakeTqdm()
    fake_stream = io.StringIO()
    fake_record = mock.Mock()

    fake_record.msg = 'print once'

    logger = _TqdmLoggingHandler(tqdm_class=fake_tqdm)
    logger.setLevel(logging.INFO)
    logger.setFormatter(logging.Formatter(''))
    logger.stream = fake_stream

    logger.emit

# Generated at 2022-06-24 09:56:46.245121
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import closing
    from io import StringIO
    import logging
    import re
    from .std import tqdm
    from .tests import maybe_test_gpu

    @closing(StringIO())  # type: ignore
    def main(f):
        # type: (StringIO) -> None
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(logging.FileHandler(f))
        log_msg = "console logging redirected to tqdm.write()"
        with logging_redirect_tqdm():
            for _ in tqdm(list(range(9))):
                if _ == 4:
                    logger.info(log_msg)
        return str(f.getvalue())


# Generated at 2022-06-24 09:56:50.290623
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-24 09:56:52.882802
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler
    """
    from .tests_tqdm import pretest_posttest
    with pretest_posttest() as (_, __):
        _TqdmLoggingHandler()
        _TqdmLoggingHandler().emit("test")



# Generated at 2022-06-24 09:57:04.395701
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from unittest import TestCase, skipUnless
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # noqa

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    class MockLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super(MockLoggingHandler, self).__init__()
            self.records = []

        def emit(self, record):
            self.records.append(self.format(record))


# Generated at 2022-06-24 09:57:07.333914
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect() as pbar:
        with pbar:
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:15.368511
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.captureWarnings(True)
    warnings_logger = logging.getLogger("py.warnings")
    logging.addLevelName(logging.WARNING, "WARNING")

    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    for log in [logger, warnings_logger]:
        assert isinstance(log.handlers[0], logging.StreamHandler)

    for i in range(2):
        with logging_redirect_tqdm([logger, warnings_logger]) as pbar:
            assert pbar.__class__ is std_tqdm
            assert len(logger.handlers) == 1
            assert len(warnings_logger.handlers) == 1

# Generated at 2022-06-24 09:57:23.249149
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.autonotebook import tqdm

    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        tqdm.write("Redirected!")
        logger.info("Redirected!")

    with logging_redirect_tqdm(loggers=[logger]):
        tqdm.write("Redirected again!")
        logger.info("Redirected again!")
        logger.warning("Redirected warning!")

    with logging_redirect_tqdm(loggers=[logger], tqdm_class=tqdm):
        tqdm.write("Redirected again, again!")
        logger.info("Redirected again, again!")
        logger.warning("Redirected warning, again!")
       

# Generated at 2022-06-24 09:57:27.927758
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    logger.info("tqdm_logging started")



# Generated at 2022-06-24 09:57:41.773540
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..tqdm_logging import TQDMLogHandler
    import logging
    # logging to file
    fh = logging.FileHandler('tqdm_logging_redirect.log')
    logging.root.addHandler(fh)
    # logging to stdout
    sh = logging.StreamHandler()
    sh.setFormatter(logging.Formatter())
    logging.root.addHandler(sh)
    # logging to tqdm
    th = TQDMLogHandler()
    logging.root.addHandler(th)

    # with log_device(TQDMLogHandler()):
    with tqdm_logging_redirect():
        logging.info('test_tqdm_logging_redirect...')

    # read back the logging result

# Generated at 2022-06-24 09:57:42.425716
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    return None

# Generated at 2022-06-24 09:57:51.266207
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    # Mock pbar to simulate the _TqdmLoggingHandler.emit method
    h = _TqdmLoggingHandler()
    # Mock pbar
    pbar_class = type('pbar', (object,), {'write': lambda x: None,
                                          'file': sys.stderr})
    pbar = pbar_class()
    # Mock record
    record = type('record', (object,), {'getMessage': lambda: 'hello',
                                        'levelname': 'INFO'})()
    # Run function emit
    try:
        h.emit(record)
    except Exception:
        pass

# Generated at 2022-06-24 09:57:56.383031
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    kwargs = dict( ascii=True, leave=False, total=1000,
                   loggers=[logging.getLogger('tqdm')],
                   tqdm_class=tqdm, desc="Test tqdm logging" )
    with tqdm_logging_redirect(**kwargs) as pbar:
        for i in range(1000):
            pbar.update(1)
            if i == 500:
                logging.getLogger('tqdm').info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:58:03.350524
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    import logging
    import sys
    from io import StringIO
    from tqdm._utils import _supports_unicode

    # Disable Unicode
    sys.stdout = (StringIO() if _supports_unicode else io.BytesIO())
    # Make a Python logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # Make a tqdm logger
    tqdm_logger = _TqdmLoggingHandler()
    # Add tqdm logger to logger
    logger.addHandler(tqdm_logger)
    # Make a "write" message
    msg = 'A MESSAGE'
    # Log message on tqdm logger
    logger.info(msg)
    # Check if message is written in stdout
    assert sys.stdout.get

# Generated at 2022-06-24 09:58:08.207319
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 3:
                    LOG.info("testing")

# Generated at 2022-06-24 09:58:11.255165
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    return tqdm_handler


# Generated at 2022-06-24 09:58:18.182181
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    class FakeTqdm:
        def __init__(self, *args, **kwargs):
            pass

        def write(self, message, file=None):
            print(message)

    # Create the handler and redirect stdout to a pipe
    handler = _TqdmLoggingHandler(tqdm_class=FakeTqdm)
    old_stdout = sys.stdout
    sys.stdout = open('test_TqdmLoggingHandler_emit.log', 'w')

    # Record and process a message
    msg = 'test_TqdmLoggingHandler_emit'
    handler.emit(msg)

    # Read the pipe
    sys.stdout.close()
    sys.stdout = old_stdout

    # Check the message in the pipe

# Generated at 2022-06-24 09:58:27.993215
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with redirect_stdout(io.StringIO()) as stdout:
        with logging_redirect_tqdm():
            logging.info('foo')
            logging.getLogger('bar').info('foo2')
        assert "foo" in stdout.getvalue()
        assert "foo2" in stdout.getvalue()
    with redirect_stdout(io.StringIO()) as stdout:
        with logging_redirect_tqdm(loggers=[logging.getLogger('bar')]):
            logging.info('foo')
            logging.getLogger('bar').info('foo2')
        assert "foo" not in stdout.getvalue()
        assert "foo2" in stdout.getvalue()

# Generated at 2022-06-24 09:58:31.122382
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Unit test for constructor of class _TqdmLoggingHandler"""
    try:
        _TqdmLoggingHandler()
    except:
        raise AssertionError("_TqdmLoggingHandler test failed")


# Generated at 2022-06-24 09:58:40.808210
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import tqdm
    import time
    import numpy as np

    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        logger.info("Redirected to tqdm")
        time.sleep(1)
        pbar.set_description("Some description")
        time.sleep(1)
        for i in np.arange(10):
            logger.info("Test logging")
            time.sleep(.1)
            pbar.update(1)
        logger.info("Done")


# Generated at 2022-06-24 09:58:47.376252
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    from io import StringIO
    from tqdm._utils import _term_move_up

    log = logging.getLogger()
    log.setLevel(logging.INFO)
    # Simulate console logging handler
    file = StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = file
    log.addHandler(handler)

    log.info('logging message')
    assert file.getvalue() == 'logging message' + _term_move_up()

    log.info('another logging message')
    assert file.getvalue() == 'logging message' + _term_move_up() + \
        '\nanother logging message' + _term_move_up() + _term_move_up()

    # Check that exception is caught

# Generated at 2022-06-24 09:58:51.203481
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    record = logging.makeLogRecord({'msg': 'Hello, world'})
    handler = _TqdmLoggingHandler()
    handler.emit(record)
    assert sys.stdout.getvalue() == 'Hello, world\n'
