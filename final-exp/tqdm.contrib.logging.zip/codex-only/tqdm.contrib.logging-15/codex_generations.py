

# Generated at 2022-06-24 09:48:45.719603
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Set up a logger with _TqdmLoggingHandler handler
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.DEBUG)
    console_handler = _TqdmLoggingHandler()
    logger.addHandler(console_handler)
    logger.debug("Test the emit method")

# Generated at 2022-06-24 09:48:49.656739
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    stream = sys.stderr
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    handler.emit(logging.LogRecord('test_logger', logging.INFO, '__file__', 1, 'test_msg', None, None))

# Generated at 2022-06-24 09:48:58.158284
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test to see if tqdm_logging_redirect works correctly
    """
    try:
        import pytest


        def test(capsys):
            # Simple function of tqdm_logging_redirect
            with tqdm_logging_redirect(total=10, desc='test progressbar',
                                       file=sys.stdout):
                for _ in range(10):
                    logging.info('a')

            # Check if correct logs to stderr
            with pytest.raises(Exception):
                with tqdm_logging_redirect(total=10, desc='test progressbar',
                                           file=sys.stderr):
                    for _ in range(10):
                        logging.info('a')

        test('sys.stdout')
    except ImportError:
        pass

# Generated at 2022-06-24 09:49:02.205651
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info(
                    "console logging redirected to "
                    "`tqdm.write()`")

# Generated at 2022-06-24 09:49:07.717987
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            LOG.info("logging restored")


# Generated at 2022-06-24 09:49:15.813896
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..utils import _range
    from .std import tqdm as std_tqdm
    from .import trange

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.addHandler(_TqdmLoggingHandler())

    for _ in _range(3):
        for i in trange(3, leave=False):
            log.info("tqdm console")

        for i in std_tqdm(range(3), leave=False):
            log.info("std.tqdm console")

# Generated at 2022-06-24 09:49:24.193175
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # suppress prints
        orig_stdout, sys.stdout = sys.stdout, open('/dev/null', 'w')

        # change logging level to INFO
        logging.basicConfig(level=logging.INFO)

        LOG = logging.getLogger(__name__)
        LOG.debug("debug message")  # this should not be redirected
        with logging_redirect_tqdm():
            with tqdm_logging_redirect("Test redirect"):
                LOG.info("message")

    finally:
        # restore original prints
        sys.stdout = orig_stdout
        # uninstall logging_redirect_tqdm
        logging.getLogger(__name__).handlers = []

# Generated at 2022-06-24 09:49:35.089964
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests that a record is written to the stream when emit is called.
    """

    class MockTqdm(std_tqdm):
        def write(self, message, file=None):
            self.message = message
            self.file = file

    mock_tqdm = MockTqdm()

    mock_record = logging.LogRecord(
        name='test_logger',
        level=logging.INFO,
        pathname='foo/bar/baz',
        lineno=4,
        msg='This is a test',
        args=(),
        exc_info=None
    )

    handler = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    handler.stream = mock_tqdm
    handler.emit(mock_record)

    message = handler

# Generated at 2022-06-24 09:49:37.962529
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler(std_tqdm)
    assert callable(h.tqdm_class)


# Generated at 2022-06-24 09:49:45.810590
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    # with logging_redirect_tqdm():
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:49:55.179880
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        with logging_redirect_tqdm(loggers=[]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging not redirected")
        # logging restored

# Generated at 2022-06-24 09:50:02.720311
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import logging
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    output = StringIO()
    logger = logging.getLogger('test')
    handler = _TqdmLoggingHandler()
    handler.stream = output
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)
    logger.debug("Hello, world!")
    assert output.getvalue() == ""
    logger.info("Hello, world!")
    assert output.getvalue() == "Hello, world!\n"
    logger.warning("Hello, world!")
    assert output.getvalue() == "Hello, world!\nHello, world!\n"
    logger.error("Hello, world!")


# Generated at 2022-06-24 09:50:07.849882
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler.
    """
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)
    assert tqdm_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:50:10.366160
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr, \
        "Expected handler.stream to be sys.stderr"

# Generated at 2022-06-24 09:50:13.541339
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:50:20.002114
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm._tqdm import trange
    # from tqdm._tqdm import tqdm
    import tqdm
    with logging_redirect_tqdm():
        for i in trange(10):
            logging.info('Hello, World!')
    with tqdm_logging_redirect(ncols=80):
        for i in trange(10):
            logging.info('Hello, World!')



# Generated at 2022-06-24 09:50:24.532860
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-24 09:50:28.829625
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    tqdmhandler = _TqdmLoggingHandler(tqdm_class=tqdm)
    import logging
    root = logging.getLogger()
    root.addHandler(tqdmhandler)
    root.info('Hello, world')

# Generated at 2022-06-24 09:50:38.336803
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import tqdm.contrib.logging
    import logging
    global_test_file = tempfile.mktemp(prefix="test_tqdm_contrib_logging_")
    with open(global_test_file, "w") as f:
        pbar = std_tqdm(total=100, file=f)
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        tqdm_handler = tqdm.contrib.logging._TqdmLoggingHandler(pbar.__class__)
        logger.addHandler(tqdm_handler)
        pbar.update(50)
        logger.info("test")
        pbar.close()

# Generated at 2022-06-24 09:50:48.379632
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Unit test for logging_redirect_tqdm
    def test_logging_redirect_tqdm():
        logging.basicConfig(level=logging.INFO)
        log_msg = 'console logging redirected to `tqdm.write()`'

        with patch('sys.stderr', new=sys.stdout), patch('tqdm.contrib.logging._TqdmLoggingHandler') as mock_tqdm_handler:
            mock_tqdm_handler.return_value = mock_logging_handler = mock_tqdm_handler.return_value
            mock_logging_handler.emit = lambda *args, **kwargs: None


# Generated at 2022-06-24 09:50:53.062150
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.makeLogRecord({'msg': 'message'})
    with std_tqdm.redirect_stdout(sys.stdout):
        handler.emit(record)  # emit the message
    assert sys.stdout.getvalue() == 'message\n'

# Generated at 2022-06-24 09:50:59.382726
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler.
    """

    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    def assertEqual(a, b):
        assert a == b, "{} != {}".format(repr(a), repr(b))

    handler = _TqdmLoggingHandler(tqdm)
    assertEqual(type(handler.tqdm_class), type(tqdm))

# Generated at 2022-06-24 09:51:07.029881
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import unittest
    import io

    the_record = logging.LogRecord(
        'asd', 100, '/path/', 0, 'msg', None, None)
    handler = _TqdmLoggingHandler(std_tqdm)
    stream = io.StringIO()
    handler.stream = stream
    handler.emit(the_record)
    assert stream.getvalue() == '100 - - msg' + '\n'
    the_record.levelname = 'ERROR'
    assert handler.format(the_record) == 'ERROR:msg'

    class NullStream(io.StringIO):
        def write(self, x):
            pass

        def flush(self):
            pass

    handler.stream = NullStream()


# Generated at 2022-06-24 09:51:12.759537
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    log.addHandler(ch)

    with logging_redirect_tqdm(loggers=[log]):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')

# Generated at 2022-06-24 09:51:21.058520
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    class tqdm_class_test:
        def __init__(self):
            self.write_message = []
        def write(self, message, file):
            self.write_message.append(message)
            file.write(message)

    # Set up tqdm_class_test instance
    tqdm_test = tqdm_class_test()

    class LoggingTest(logging.Logger):
        def __init__(self, name):
            self.name = name
            self.handlers = [logging.StreamHandler()]
            self.level = logging.DEBUG

        def error(self, message, *args, **kwargs):
            message = message % (args, kwargs)
            each_message = 'TestLog: error: %s' % (message)

# Generated at 2022-06-24 09:51:23.278206
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert tlh is not None


# Generated at 2022-06-24 09:51:30.703107
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._tqdm import _tqdm_notebook_failsafe
    from tqdm._utils import _term_move_up
    from tqdm._utils import _unicode

    log_handler = _TqdmLoggingHandler()
    log_handler.stream = sys.stdout
    log_handler.formatter = log_handler.createFormatter()

    log_record = logging.LogRecord(
        'prueba', logging.INFO,
        None, None, 'probando', (), None)

    try:
        _tqdm_notebook_failsafe()
        log_handler.emit(log_record)
    finally:
        print(_term_move_up() + _unicode(''))

# Generated at 2022-06-24 09:51:40.715637
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-24 09:51:48.003002
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .utils import _test_get_bar, _test_get_crange, _test_get_range
    tqdm = std_tqdm
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setLevel(logging.DEBUG)
    logger.addHandler(tqdm_handler)
    logger.debug("Test debug message")
    logger.info("Test info message")
    logger.warning("Test warning message")
    logger.error("Test error message")
    bar = _test_get_bar(tqdm)
    assert bar.last_print_t == bar.fp.tell()
    bar.write("Test bar.write message")

# Generated at 2022-06-24 09:51:49.390932
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests.tests_guides import tqdm_logging_redirect_test
    tqdm_logging_redirect_test()

# Generated at 2022-06-24 09:51:56.501345
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    
    LOG = logging.getLogger(__name__)
    
    try:
        with tqdm_logging_redirect():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    except:  # noqa pylint: disable=bare-except
        raise Exception("Failure in tqdm_logging_redirect")

# Generated at 2022-06-24 09:52:04.163302
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def test_log():
        # type: () -> None
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    try:
        # test logging in the same process
        test_log()
    except AssertionError:
        # test logging in a different process
        # to see if redirect handles `sys.stdout` correctly
        import multiprocessing as mp

# Generated at 2022-06-24 09:52:13.261271
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """ Unit test for _TqdmLoggingHandler class """
    from .logging_redirect_tqdm import _TqdmLoggingHandler
    import logging
    import tqdm
    logger = logging.getLogger('tqdm-logging')
    logger.setLevel(logging.INFO)

# Generated at 2022-06-24 09:52:22.567855
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging

    LOG = logging.getLogger('mylog')
    LOG.setLevel(logging.DEBUG)
    LOG.propagate = False

    # test: No redirection
    lh = logging.StreamHandler(stream=io.StringIO())
    lh.setFormatter(logging.Formatter('%(message)s'))
    LOG.addHandler(lh)

    with logging_redirect_tqdm():
        LOG.info('test')
    assert lh.stream.getvalue() == 'test\n'
    lh.stream.truncate(0)

    # test: Redirecting
    with tqdm_logging_redirect():
        LOG.info('test')
    assert lh.stream.getvalue() == 'test\n'
    lh.stream

# Generated at 2022-06-24 09:52:30.394275
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.makeLogRecord({
        'msg': 'test message',
        'args': None,
        'levelname': 'INFO',
        'levelno': 20,
        'pathname': 'test_file.py',
        'filename': 'test_file.py',
        'module': 'test_file',
        'lineno': 1,
        'funcName': 'test',
        'created': 1517249656.929171,
        'msecs': 929.1712646484375,
        'relativeCreated': 9.291712646484375e-05,
        'thread': 140654828755712,
        'threadName': 'MainThread',
        'processName': 'MainProcess',
        'process': 10868})
   

# Generated at 2022-06-24 09:52:36.449088
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test for _TqdmLoggingHandler.emit method.
    """
    def logger_emit(record):
        """
        Test for _TqdmLoggingHandler.emit method.
        """
        tqdm_stream_handler = _TqdmLoggingHandler(std_tqdm)
        tqdm_stream_handler.stream = std_tqdm
        tqdm_stream_handler.emit(record)

# Generated at 2022-06-24 09:52:42.293172
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        desc='unit test',
        total=1,
        loggers=[logger],
        # tqdm_class=trange,
    ) as pbar:
        logger.info("logging redirected to pbar.write()")


if __name__ == '__main__':
    # Unit test
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:45.031947
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert str(type(_TqdmLoggingHandler())) == "<class 'tqdm._tqdm.tqdm_gui._TqdmLoggingHandler'>"

# Generated at 2022-06-24 09:52:52.264675
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tnrange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def test_function():
        with tqdm_logging_redirect(total=9, desc="logging test") as pbar:
            for i in tnrange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    try:
        test_function()
        assert False, "tqdm_logging_redirect should throw an exception"
    except RuntimeError:
        pass

# Generated at 2022-06-24 09:53:01.529667
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import tqdm, trange

    with tqdm_logging_redirect(miniters=1, mininterval=0.5, logger=logging.root):
        for _ in trange(3):
            logging.getLogger('logger').debug('test')
        for _ in tqdm(range(3)):
            logging.info('test')

# Generated at 2022-06-24 09:53:04.206299
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm) is not None


# Generated at 2022-06-24 09:53:13.330120
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    tr = trange(9)
    log = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in tr:
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in tr:
        if i == 4:
            log.info("console logging restored")
    tr.close()



# Generated at 2022-06-24 09:53:14.293000
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:53:23.611276
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    with tqdm.std.tqdm() as pbar:
        with logging_redirect_tqdm(loggers=[LOG]):
            LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update(2)
        pbar.set_description("test")
    with tqdm_logging_redirect(loggers=[LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:53:28.433264
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm_logging import _TqdmLoggingHandler

    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit("test_info")
    assert sys.stdout.getvalue() == "test_info\n"

# Generated at 2022-06-24 09:53:33.578565
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._utils import _term_move_up
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        LOG.info("A")
        LOG.info("B")
        print("C")
    assert _term_move_up() == '\x1b[2A'

# Generated at 2022-06-24 09:53:43.489555
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for tqdm_logging_redirect"""
    import logging
    from ..std import trange

    with tqdm_logging_redirect(total=9, leave=False) as pbar:
        logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
    assert list(pbar) == list(range(9))
    assert pbar.n == 9
    assert pbar.total == 9

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:53:51.147614
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm as std_tqdm

    class FakeStream(object):
        def __init__(self):
            self.output = []

        def write(self, output):
            self.output.append(output)

    record = logging.LogRecord(
        name='logger name',
        level=logging.INFO,
        pathname='/path/to/file.py',
        lineno=1,
        msg='message',
        args=(),
        exc_info=None,
    )
    stream_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    stream_handler.stream = FakeStream()
    stream_handler.emit(record)
    assert stream_handler.stream.output[0] == 'INFO:logger name:message\n'

# Generated at 2022-06-24 09:53:54.686852
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_emit_handler = _TqdmLoggingHandler()
    tqdm_emit_handler.emit('test')

# Generated at 2022-06-24 09:53:57.234204
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:54:04.953871
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    record = logging.LogRecord(
        name='root',
        level=logging.WARNING,
        pathname='/path/to/foo.py',
        lineno=42,
        msg='hello world',
        args=None,
        exc_info=None
    )

    output_string = ''

    # the original logging stream handler does not work well with the stdout.
    # stdout is replaced with a string object for testing.
    # the `emit()` method does not work with stdout, but only with output_string.
    class MyStringIO(object):
        def write(self, s):
            output_string = s

    my_string_io = MyStringIO()

    # the original handler writes:
    #   'hello world'
    # then set a new stream and the new handler should
    #  

# Generated at 2022-06-24 09:54:09.910073
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # opt-in for showing traceback in unittest
    assert _TqdmLoggingHandler().tb_msg is True

# Generated at 2022-06-24 09:54:13.387248
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.stream == sys.stderr

# Generated at 2022-06-24 09:54:19.612824
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(loggers=[LOG], desc="Log") as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()


# Generated at 2022-06-24 09:54:23.923510
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    with tqdm_logging_redirect(total=3) as pbar:
        assert isinstance(pbar, tqdm)
        assert pbar.total == 3
        assert not pbar.disable
        logging.info("This is a test")
        pbar.update()



# Generated at 2022-06-24 09:54:29.809301
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tnrange, trange, tqdm, tqdm_notebook  # type: ignore
    except ImportError:
        raise ImportError("Please install `tqdm` for this test.")

    for tqdm_class in [tqdm, tqdm_notebook, trange, tnrange]:
        with tqdm_logging_redirect(
                tqdm_class=tqdm_class, total=9, leave=False,
                loggers=[logging.root]) as pbar:
            for i in pbar:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:54:40.153325
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _term_move_up

    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    handler.stream = sys.stdout
    logger = logging.getLogger("logging_redirect_tqdm")
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.info("This is a test of %s", "logging.info()")
    print("\r" + "_"*10)
    handler.flush()
    print("\r" + "_"*10)
    logger.warning("This is a test of %s", "logging.warning()")
    print("\r" + "_"*20)
    handler.flush()
   

# Generated at 2022-06-24 09:54:41.049753
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-24 09:54:49.185169
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    def log_stuff(loglevel):
        for i in range(4):
            LOG.log(loglevel, "This is a log message, using log level {}".format(i))

    if __name__ == '__main__':
        # First test the simple case, log everything
        with tqdm_logging_redirect(leave=True) as pbar:
            log_stuff(logging.DEBUG)
        # Test the case, log only INFO and above
        with tqdm_logging_redirect(leave=True) as pbar:
            log_stuff(logging.INFO)
        # Test the case, log only ERROR and above
        with tqdm_logging_redirect(leave=True) as pbar:
            log_

# Generated at 2022-06-24 09:54:58.632342
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import tqdm
        from tqdm.contrib.logging import logging_redirect_tqdm

        log = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for _ in tqdm(range(3)):
                log.info("I am redirected!")
            for _ in tqdm(range(7)):
                pass
    except Exception:
        pass  # ok for Windows users (esp. pip install)


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:55:05.910967
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():

    # required to prevent error:
    #   AttributeError: Can't get attribute 'Bar' on <module '__main__' from
    #   '.../tqdm/_tqdm.py'>
    from ..std import tqdm
    tqdm = tqdm.tqdm

    class MockTqdm(tqdm):
        pass

    # create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = sys.stdout

    # create handler
    handler = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    handler.stream = stream
    handler.setFormatter(logging.Formatter('%(message)s'))

    # add handler to the logger
    logger.addHandler(handler)



# Generated at 2022-06-24 09:55:14.151520
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test for the tqdm_logging_redirect function
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:20.039469
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdmLogHandler = _TqdmLoggingHandler()
    assert isinstance(tqdmLogHandler, _TqdmLoggingHandler)


# Generated at 2022-06-24 09:55:27.089394
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class FakeSigint(Exception):  # noqa pylint: disable=missing-docstring
        pass

    class FakeTqdmException(Exception):  # noqa pylint: disable=missing-docstring
        pass

    class FakeWrite(object):
        # noqa pylint: disable=missing-docstring
        def __init__(self):
            self.msg = None

        def __call__(self, msg, file=None):
            self.msg = msg

    class FakeStream(object):
        # noqa pylint: disable=missing-docstring
        def write(self, msg, file=None):
            pass

        def flush(self, msg, file=None):
            pass

    handler = _TqdmLoggingHandler(FakeWrite())
    handler.stream = FakeStream()
    # create the

# Generated at 2022-06-24 09:55:34.494101
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig(level=logging.INFO)
    try:
        from io import StringIO
        string_stream = StringIO()
        with tqdm_logging_redirect(file=string_stream, loggers=[logging.root]):
            logging.info("console logging redirected to `tqdm.write()`")
            assert string_stream.getvalue() == u"console logging redirected to `tqdm.write()`\n"
    finally:
        logging.shutdown()


# Generated at 2022-06-24 09:55:41.242386
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.test_utils import _fake_streams

    # Test 'tqdm_class' argument
    with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar:
        pass
    assert isinstance(pbar, std_tqdm)

    # Test 'loggers' argument
    LOG = logging.getLogger(__name__)
    @tqdm_logging_redirect(loggers=[LOG])
    def func(pbar):
        pass
    assert func.__closure__[0].cell_contents is LOG

    # Test 'pbar=...'
    with _fake_streams() as (out, err):
        pbar = std_tqdm()

# Generated at 2022-06-24 09:55:43.702708
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=5) as pbar:
        assert pbar.total == 5
        assert not pbar.n
        pbar.update()
        assert pbar.n



# Generated at 2022-06-24 09:55:44.671040
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    pass

# Generated at 2022-06-24 09:55:51.380712
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    LOGGER = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        LOGGER.info("hello")
        LOGGER.warning("hello")
        LOGGER.info("world")
        # The following should not appear in console
        LOGGER.debug("hello")
    # The following should not appear in console
    LOGGER.warning("world")

# Generated at 2022-06-24 09:56:00.191434
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .main import tqdm
    from tqdm.contrib.test import with_setup
    import logging

    def setUp():
        logging.basicConfig(level=logging.INFO)

    @with_setup(setUp)
    def test_tqdm_logging_redirect_ascii(sio):
        LOG = logging.getLogger(__name__)
        with tqdm_logging_redirect(desc="test", total=10) as pbar:
            pbar.update(5)
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update(5)

# Generated at 2022-06-24 09:56:09.243176
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import tqdm

    class _TestTqdmLoggingHandler(_TqdmLoggingHandler):
        pass

    tqdm_handler = _TestTqdmLoggingHandler()
    tqdm_handler.stream = tempfile.TemporaryFile()
    logging.root.addHandler(tqdm_handler)

    logging.critical('critical')
    tqdm_handler.tqdm_class.write('critical', file=tqdm_handler.stream)
    tqdm_handler.stream.flush()
    tqdm_handler.stream.seek(0)
    assert tqdm_handler.stream.read() == b'critical\n'

    # Test tqdm.tqdm.write() is called

# Generated at 2022-06-24 09:56:12.883180
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:56:22.114364
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm.__main__  # noqa
    if tqdm.__main__.__file__.endswith("__main__.pyc"):
        return

    import tqdm, logging  # noqa

    log_formatter = logging.Formatter('%(levelname)-8s %(message)s')
    root_logger = logging.getLogger()
    root_logger.handlers = []
    root_logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)
    root_logger.addHandler(console_handler)

    def test_emit():
        tqdm_handler = _TqdmLoggingHandler()
        root_logger.addHandler(tqdm_handler)

# Generated at 2022-06-24 09:56:28.181361
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    import sys
    from unittest import mock
    from tqdm.contrib.logging import _TqdmLoggingHandler
    stream = StringIO()
    original_stream = sys.stdout
    sys.stdout = stream

    # Test _TqdmLoggingHandler.emit()
    logging_handler = _TqdmLoggingHandler()
    mock_record = mock.Mock()
    mock_record.levelname = "INFO"
    logging_handler.emit(mock_record)

    # Test _TqdmLoggingHandler.flush()
    mock_record.levelname = "WARNING"
    logging_handler.handleError = mock.MagicMock()
    logging_handler.emit(mock_record)
    logging_handler.handleError.assert_called_once()

# Generated at 2022-06-24 09:56:31.286161
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    _TqdmLoggingHandler().emit(logging.LogRecord(name='test', level='INFO',
                                                 msg='test message',
                                                 args=(), exc_info=None))

# Generated at 2022-06-24 09:56:41.052357
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from types import BuiltinMethodType
    
    # Create object
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.tqdm_class is std_tqdm
    
    # Check StreamHandler attributes
    assert isinstance(tqdm_handler.stream, StringIO)
    assert isinstance(tqdm_handler.formatter, logging.Formatter)
    assert tqdm_handler.level == logging.NOTSET
    assert tqdm_handler.filters == []
    assert tqdm_handler.lock is None
    
    # Check StreamHandler methods
    assert isinstance(tqdm_handler.flush, BuiltinMethodType)

# Generated at 2022-06-24 09:56:47.579927
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Test whether method emit of class _TqdmLoggingHandler works as expected.
    """

    # if error occurs, we will catch it and assert False in except clause
    try:
        handler = _TqdmLoggingHandler()
        handler.emit(logging.LogRecord('name', logging.INFO, 'pathname',
                                       99, 'msg', None, None))
        handler.flush()
    except:  # noqa pylint: disable=bare-except
        assert False

    # if no error occurs, we will assert True
    assert True

# Generated at 2022-06-24 09:56:54.071288
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    if __name__ == "__main__":
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(5)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:00.312432
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    from contextlib import redirect_stdout
    test = io.StringIO()
    with redirect_stdout(test):
        handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.debug('foo')
    assert test.getvalue().strip() == 'foo'

# Generated at 2022-06-24 09:57:06.839371
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        socket = __import__('socket').socket
        from io import StringIO
        s = socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('localhost', 0))
        s.listen(1)
        _, port = s.getsockname()
        with StringIO() as buf, logging_redirect_tqdm():
            log = logging.getLogger('test._TqdmLoggingHandler')
            log.info(port)
            import socket
            c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            c.connect(('localhost', port))
            with c.makefile() as f:
                assert f.readline().strip() == str(port)
    except socket.error:
        pass

# Generated at 2022-06-24 09:57:17.441046
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test function `tqdm_logging_redirect`.
    """
    import logging
    try:
        from unittest.mock import patch  # Python 3.x
    except ImportError:
        from mock import patch  # Python 2.x
    from tqdm import tqdm, tqdm_notebook, trange

    original_handlers_list = [logger.handlers for logger in [logging.root]]

    with tqdm_logging_redirect(ncols=80):
        # test that handlers are redirected
        assert all([
            _is_console_logging_handler(handler)
            for handler in logging.root.handlers])
        logging.info("check redirected logging info")

    # test that handlers are restored

# Generated at 2022-06-24 09:57:25.712257
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_decorator import lmap, no_tqdm
    from .test_tqdm import with_unit_option, closing
    from .utils import lrange, arg_transparent, unicode
    from .std import tqdm as std_tqdm

    @lmap
    def test(unit_scale, tqdm_class, cli):
        total = 200 if unit_scale else 2
        with closing(tqdm_class(total=total, disable=not cli)) as t:
            with logging_redirect_tqdm(
                    tqdm_class=tqdm_class) as pbar:
                pbar.set_description("TEST")
                tqdm_class.write("This is a test.", file=sys.stderr)
                t.update()
                t.update

# Generated at 2022-06-24 09:57:27.943828
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:57:41.773222
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    from unittest.mock import sentinel

    test_io = io.StringIO()
    LOG = logging.getLogger(__name__)
    LOG_HANDLER = logging.StreamHandler(test_io)
    LOG_LEVEL = LOG.level
    LOG.addHandler(LOG_HANDLER)

    class TestTqdm:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return sentinel.pbar

        def __exit__(self, *exc):
            pass

        def write(*args, **kwargs):
            return sentinel.write

    def mock_logging_redirect_tqdm(*args, **kwargs):
        return sentinel.logging_redirect_tqdm

   

# Generated at 2022-06-24 09:57:52.695123
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    # make sure that the test is really running in a console
    assert(sys.stderr.isatty())

    # start with a warning:
    logging.basicConfig(level=logging.WARN)
    logger = logging.getLogger()
    text_at_start = sys.stderr.getvalue()

    # write a message (should not appear)
    logger.info("this should not appear")
    text_so_far = sys.stderr.getvalue()
    assert(text_at_start == text_so_far)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            pbar.update()
            time.sleep(0.1) # so we can follow the progress

            # write a message

# Generated at 2022-06-24 09:58:00.764873
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test with the default tqdm_class
    with tqdm_logging_redirect(['a', 'b']) as pbar:
        assert isinstance(pbar, std_tqdm)
        assert pbar.n == 2

    # Test with custom tqdm_class
    class test_tqdm:
        def __init__(self, iterable=None, total=None, **_kwargs):
            self.write = self.__call__
            self.n = 0 if (total is None) else total
            if iterable is not None:
                self.update(len(iterable))

        def update(self, n):
            self.n += n

        def __call__(self, *_args, **_kwargs):
            pass

        def __enter__(self):
            return self



# Generated at 2022-06-24 09:58:10.973824
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm import tqdm

    stdout = sys.stdout  # type: Optional[StringIO]

# Generated at 2022-06-24 09:58:15.056285
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:58:24.619308
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import tempfile
    from tqdm import trange, tqdm

    log_file = os.path.join(tempfile.gettempdir(), 'tqdm.log')

    if os.path.isfile(log_file):
        os.remove(log_file)

    logging.basicConfig(filename=log_file, level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info('foo1')
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')
    LOG.info('bar1')
    assert os.path.isfile(log_file)

# Generated at 2022-06-24 09:58:34.174103
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange

    # Initialize logging (root logger)
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    # Test logging.handlers setup for root logger
    for handler in logging.root.handlers:
        assert isinstance(handler, logging.StreamHandler), \
            "StreamHandler not found."
        assert handler.stream == sys.stderr, \
            "Console handler not found."
        assert handler.formatter is not None, \
            "Console handler formatter not found."
    # Test logging.handlers setup for specific logger (same as root logger)
    for handler in LOG.handlers:
        assert isinstance(handler, logging.StreamHandler), \
            "StreamHandler not found."
        assert handler.stream == sys.stder

# Generated at 2022-06-24 09:58:36.269662
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler


# Generated at 2022-06-24 09:58:47.124607
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    import time
    LOGGER = logging.getLogger(__name__)
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False
    original_handlers = LOGGER.handlers[:]
    try:
        with logging_redirect_tqdm():
            for i in trange(5):
                if i == 4:
                    LOGGER.info("console logging redirected to `tqdm.write()`")
        # logging restored
    finally:
        LOGGER.handlers = original_handlers