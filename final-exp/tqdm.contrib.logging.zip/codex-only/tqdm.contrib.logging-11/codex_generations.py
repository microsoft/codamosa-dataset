

# Generated at 2022-06-24 09:48:55.191617
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import time

    with tqdm_logging_redirect(loggers=[logging.getLogger('logger')], dynamic_ncols=True):
        logging.getLogger('logger').info('logging to tqdm.write and stdout')

    with tqdm_logging_redirect(loggers=[logging.getLogger('logger')], dynamic_ncols=True) as pbar:
        for _ in range(10):
            time.sleep(0.1)
            logging.getLogger('logger').info('logging to tqdm.write and stdout')
            pbar.update(1)
            sys.stderr.write('this will stay on stderr\n')


# Generated at 2022-06-24 09:48:56.665389
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from logging import StreamHandler
    assert isinstance(_TqdmLoggingHandler(), StreamHandler)

# Generated at 2022-06-24 09:49:06.676098
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.contrib.concurrent_log_handler import ConcurrentLogHandler
    from tqdm.contrib.test_utils import FakeFileIO

    tqdm_handler = _TqdmLoggingHandler()
    # Capture stdout
    stdout = sys.stdout
    try:
        sys.stdout = FakeFileIO()
        log = logging.getLogger(__name__)
        log.addHandler(tqdm_handler)
        log.info("hello world")
        assert sys.stdout.data == [
            "INFO:[%s - %s]hello world\n" % (
                __name__, logging.getLevelName(logging.INFO))]
    finally:
        sys.stdout = stdout

    tqdm_handler = _TqdmLoggingHandler()
    tq

# Generated at 2022-06-24 09:49:07.278937
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:49:09.808942
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import unittest
    import logging

    class TestCase(unittest.TestCase):
        def test_tqdm_logging_redirect(self):
            with tqdm_logging_redirect(loggers=[logging.getLogger()]):
                logging.info('Test message')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 09:49:20.539893
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import unittest

    class MockTqdm(object):
        """
        Mock class to simulate tqdm.
        """

        # pylint: disable=too-few-public-methods
        def __init__(self, *args, **kwargs):
            # type: (object, object) -> None
            self.args = args
            self.kwargs = kwargs
            self.n = 0
            self.last_write = None

        def __enter__(self):
            # type: () -> None
            self.n += 1
            return self

        def __exit__(self, *args):
            # type: (...) -> None
            self.n -= 1

        def write(self, s):
            # type: (str) -> None
            self.last_write

# Generated at 2022-06-24 09:49:25.096977
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            total=9, unit='tests'
            ) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            pbar.update(1)

# Generated at 2022-06-24 09:49:35.782749
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Test method emit of class _TqdmLoggingHandler
    """
    import io
    import sys
    import unittest
    try:
        from unittest import mock  # py3
    except ImportError:
        import mock  # pylint: disable=unused-import

    from tqdm.contrib.logging import _TqdmLoggingHandler

    class FakeTqdm(object):
        @staticmethod
        def write(*args, **kwargs):
            pass

    class TestTqdmLoggingHandler(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            out = io.StringIO()
            sys.stdout = out
            self.addCleanup(sys.stdout.flush)
           

# Generated at 2022-06-24 09:49:40.581664
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import main

    @main
    def main_console_logging(bar):
        import logging
        LOG = logging.getLogger(__name__)

        for i in bar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    main_console_logging(list(range(9)))



# Generated at 2022-06-24 09:49:42.829144
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler(std_tqdm)
    assert logging_handler


# Generated at 2022-06-24 09:49:47.928007
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    msg = "A message"
    try:
        handler.emit(logging.LogRecord(msg, '', '', '', msg, (), None))
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        handler.handleError()



# Generated at 2022-06-24 09:49:56.336068
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """
    from ..std import tqdm as std_tqdm

    # Use custom ProgressBarClass
    class MyTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            self.text = kwargs.pop('text', None)
            super(MyTqdm, self).__init__(*args, **kwargs)

        def display(self, *args, **kwargs):
            if self.text is not None:
                self.write(self.text)

    import contextlib
    logger = logging.getLogger(__name__)

    @contextlib.contextmanager
    def mock_std(mock_stdout):
        save_stdout = sys.stdout

# Generated at 2022-06-24 09:49:59.643442
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9):
        for i in range(8):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:50:09.997447
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import TestCase
    logging.basicConfig(level=logging.INFO)

    def redirect_tqdm_with(logger, verbosity):
        with logging_redirect_tqdm(loggers=[logger]):
            logger.setLevel(verbosity)
            logger.info('info')
            logger.error('error')
            logger.warning('warning')
            logger.debug('debug')

    with std_tqdm(disable=False) as t, \
            TestCase('verbose', 'error', 'warning', 'debug'):
        redirect_tqdm_with(logging.root, logging.DEBUG)


# Generated at 2022-06-24 09:50:19.879178
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import _range
    from .tqdm_test_cases import EntireTqdmTestCase

    for disable in EntireTqdmTestCase.DISABLE_TEST:
        EntireTqdmTestCase.DISABLE_TEST.remove(disable)


# Generated at 2022-06-24 09:50:28.520692
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from cStringIO import StringIO  # py2
    except ImportError:
        from io import StringIO
    from .tqdm import trange

    LOG = logging.getLogger(__name__)

    DEBUG_OUTPUT = 'debug output'
    INFO_OUTPUT = 'info output'

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(StringIO()))

    with logging_redirect_tqdm():
        LOG.debug(DEBUG_OUTPUT)
        LOG.info(INFO_OUTPUT)
        for _ in trange(4):
            LOG.debug(DEBUG_OUTPUT)
            LOG.info(INFO_OUTPUT)


# Generated at 2022-06-24 09:50:32.405688
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    from tqdm._utils import _term_move_up

    sys.stdout.write("\nTest output from stdio\n")
    # Test stdio output
    with tqdm.tqdm_logging_redirect():
        logging.info("stdio logging works")
    # Test default output
    with tqdm.tqdm_logging_redirect():
        logging.info("stdio logging works")
    # Test tqdm output
    with tqdm.tqdm_logging_redirect(tqdm=tqdm.tqdm):
        logging.info("stdio logging works")
    # Test trange output

# Generated at 2022-06-24 09:50:34.611089
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(desc='Task', file=sys.stdout) as pbar:
        pbar.update(50)

# Generated at 2022-06-24 09:50:36.732887
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.Logger('test')
    handler = _TqdmLoggingHandler()
    logger.handlers = [handler]
    logger.error("test")


# Generated at 2022-06-24 09:50:42.248382
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:50:51.533923
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # check function existence
    test_tqdm_logging_redirect.__doc__  # type: ignore
    # check that it compiles
    with tqdm_logging_redirect():
        pass
    # check that it works
    from .miscs import test_cases, unskip_if_not, unittest  # noqa
    unittest.TestCase.assertIsInstance  # type: ignore
    unittest.TestCase.assertNotIn  # type: ignore

    @unskip_if_not
    def test_tqdm_logging_redirect(tqdm_class):
        if tqdm_class != std_tqdm:
            return
        with tqdm_logging_redirect():
            logging.info("console logging redirected to `tqdm.write()`")
   

# Generated at 2022-06-24 09:50:57.264902
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function logging_redirect_tqdm

    >>> with logging_redirect_tqdm():
    ...     LOG.info('first')
    ...     LOG.error('second')
    ...     for _ in trange(4):
    ...         LOG.info('third')
    ...         pass
    first
    second
    third
    third
    third
    third
    """

# Generated at 2022-06-24 09:51:02.469459
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange

    logging.basicConfig()

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:51:11.970352
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test tqdm_logging_redirect

    Returns
    -------
    message: str
        Test message.
    """
    import logging
    from tqdm import tqdm

    log_msg = "console logging redirected to `tqdm.write()`"
    logger_name = "tqdm_logging_redirect"
    LOG = logging.getLogger(logger_name)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=5, loggers=[LOG],
                               desc=logger_name) as t:
        for _ in range(4):
            time.sleep(0.2)
            t.update()
        LOG.info(log_msg)
        time.sleep(0.2)
        t.update()

# Generated at 2022-06-24 09:51:12.483248
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pass

# Generated at 2022-06-24 09:51:20.858161
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-24 09:51:27.074965
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm import tnrange
    import logging

    # logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    with logging_redirect_tqdm(tqdm_class=tnrange, loggers=[logger]):
        for i in tnrange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:51:33.041023
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    LOG = logging.getLogger(__name__)
    try:
        from tqdm.utils import _term_move_up
    except ImportError:
        _term_move_up = None

    logging.root.setLevel(logging.CRITICAL)
    with _term_move_up():
        with tqdm_logging_redirect(unit_scale=True, unit='B', smoothing=0) as pbar:
            assert pbar.desc == 'B/s'
            pbar.set_description('Foo')
            LOG.warning('Foo')
            LOG.error('Bar')
            if _term_move_up is not None:
                assert pbar.n == 5
                pbar.set_description('Foo', refresh=False)
                assert pbar

# Generated at 2022-06-24 09:51:41.551802
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Logging handler
    LOG = logging.getLogger(__name__)

    # Configure logging handler for root logger
    logging.basicConfig(level=logging.INFO)

    # Redirect logging to tqdm.write()
    with logging_redirect_tqdm():
        # Loop
        pbar = trange(9)
        for i in pbar:
            if i == 4:
                LOG.info("Console logging redirected to tqdm.write()")

if __name__ == '__main__':
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-24 09:51:48.860374
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(
        total=9,
        desc="Redirecting stdout to tqdm",
        file=sys.stderr,
        ncols=80,
        miniters=1
    ) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:53.517920
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:59.167898
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    sio = StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm.tqdm)
    handler.stream = sio
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.info('test')
    assert sio.getvalue() == 'test\n'

# Generated at 2022-06-24 09:52:00.982198
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert(tqdm_logging_handler)

# Generated at 2022-06-24 09:52:11.912663
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    buffer = StringIO()
    if __name__ == '__main__':
        with redirect_stdout(buffer):
            with tqdm_logging_redirect(8) as pbar:
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
                    pbar.update()

# Generated at 2022-06-24 09:52:16.536299
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm

    loggers = None
    tqdm_class = std_tqdm

    with tqdm_logging_redirect(
        *(),
        loggers=loggers, tqdm_class=tqdm_class
    ):
        pass


# Generated at 2022-06-24 09:52:23.098403
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    # This will log to stdout
    logger.warning("logging")

    with logging_redirect_tqdm():  # Overrides stdout with tqdm
        logger.warning("redirected")


# Due to cyclic import, this assertion is placed in the end
# of the file.
assert logging_redirect_tqdm
assert tqdm_logging_redirect

# Generated at 2022-06-24 09:52:30.675176
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None

    from . import tests
    import logging
    from tqdm import trange

    with tests.captured_output() as captured:
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # noinspection PyUnresolvedReferences
    captured_out = captured.getvalue()
    captured_out = '\n'.join([x.strip() for x in captured_out.split('\n')])
    # print(captured_out)
    # print(captured_out == translations.gettext("console logging redirected

# Generated at 2022-06-24 09:52:34.968084
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from ..main import tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm)
    assert tqdm_handler.tqdm_class == tqdm
    assert tqdm_handler.stream == sys.stderr



# Generated at 2022-06-24 09:52:42.828522
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Setup a console handler
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    # Setup a tqdm handler and assign it to stream attribute
    tqdm_logger = _TqdmLoggingHandler()
    tqdm_logger.setLevel(logging.DEBUG)
    tqdm_logger.stream = sys.stdout
    # Setup a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(console)
    logger.addHandler(tqdm_logger)

    # Test logging information
    logger.info('info')
    logger.debug('debug')


# Generated at 2022-06-24 09:52:51.506227
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm_test_cases import range_, StringIO, tnrange

    try:
        from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL
        from logging import basicConfig, getLogger
    except ImportError:
        raise unittest.SkipTest('logging module not installed')

    logger = getLogger(__name__)

    class TestLoggingRedirect():
        """Class to test function tqdm_logging_redirect"""

        def test_tqdm_redirect(self):
            """Test std.tqdm class"""
            with StringIO() as buf, range_(100) as t:
                with logging_redirect_tqdm():
                    logger.debug('debug')
                    logger.info('info')
                    logger.warning('warning')
                    logger.error('error')
                    logger

# Generated at 2022-06-24 09:53:00.134370
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler

    handler = _TqdmLoggingHandler()
    handler.stream = StringIO()
    handler.emit('test')
    assert handler.stream.getvalue() == 'test\n'

# Generated at 2022-06-24 09:53:07.254010
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored
    with tqdm_logging_redirect(total=9, file=sys.stdout):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    def dummy_is_interactive(self):
        # type: (logging.Logger) -> bool
        return True
    # Note: trange() auto-redirects to tqdm

# Generated at 2022-06-24 09:53:11.463060
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    logging.getLogger().addHandler(logging.StreamHandler())
    with tqdm_logging_redirect(total=10, unit='B', unit_scale=True) as pbar:
        logging.info("console logging redirected to `tqdm.write()`")
        pbar.update(5)
    logging.info("restored to console logging")

# Generated at 2022-06-24 09:53:21.957680
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Test the functionality of method emit of class _TqdmLoggingHandler"""
    from io import StringIO
    from logging import basicConfig, getLogger
    from tempfile import TemporaryFile
    logger = getLogger(__name__)
    basicConfig()

    # test stdout
    test_stdout = sys.stdout
    test_stringio = StringIO()
    sys.stdout = test_stringio
    test_log = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    test_log.stream = sys.stdout
    test_log.emit(logging.makeLogRecord({'msg': 'unit test'}))
    assert 'unit test' in test_stringio.getvalue()
    assert '\n' in test_stringio.getvalue()
    sys.std

# Generated at 2022-06-24 09:53:32.735687
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit tests for blacklisting in `tqdm.utils.gen_bar_updater()`.
    """
    import logging
    log = logging.getLogger('tqdm.contrib.logging')
    with tqdm_logging_redirect(log=log, file=sys.stdout, ascii=True,
                               level=logging.INFO) as pbar:
        log.info('log test')
        for i in range(5):
            pbar.set_description('desc%d' % i)
            pbar.update(i)
        pbar.clear()


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:53:39.799431
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    The constructor should take one optional argument tqdm_class. The default tqdm class should be tqdm.std.tqdm.
    The tqdm class can be changed when needed.
    """
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm
    import tqdm
    handler = _TqdmLoggingHandler(tqdm.tqdm)
    assert handler.tqdm_class == tqdm.tqdm

# Generated at 2022-06-24 09:53:45.701240
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    kwargs = {}
    loggers = kwargs.pop('loggers', None)
    tqdm_class = kwargs.pop('tqdm_class', std_tqdm)
    with tqdm_class(**kwargs) as pbar:
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            yield pbar



# Generated at 2022-06-24 09:53:52.321682
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    logger = logging.Logger('test')
    log_stream = StringIO()
    handler = _TqdmLoggingHandler()
    handler.tqdm_class = std_tqdm
    handler.stream = log_stream
    logger.addHandler(handler)
    logger.info('Test')
    log_stream.seek(0)
    assert log_stream.read() == 'Test\n'

# Generated at 2022-06-24 09:54:00.843224
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    for logger_flag in (None, [logging.root]):
        for tqdm_class in (std_tqdm, std_tqdm.tqdm):
            with tqdm_logging_redirect(
                    loggers=logger_flag, tqdm_class=tqdm_class,
                    total=3) as pbar:
                pbar.write("test_tqdm_logging_redirect")
                assert pbar.n == pbar.total == 3

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:54:06.175108
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    with tqdm_logging_redirect(total=10, unit="B",
                               unit_scale=True,
                               miniters=1,
                               desc="test tqdm_logging_redirect")\
            as pbar:
        with logging_redirect_tqdm(loggers=[logging.root],
                                   tqdm_class=std_tqdm):
            logging.info("Redirected to tqdm.write")



# Generated at 2022-06-24 09:54:13.909310
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    from io import StringIO

    with StringIO() as buff, logging_redirect_tqdm():
        buff.write('foo')
        logging.warning('hello')
        buff.write('bar')
        assert buff.getvalue() == 'foohellobar'

# Generated at 2022-06-24 09:54:18.394227
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}
    assert handler.tqdm_class == std_tqdm

# Unit tests for function _get_first_found_console_logging_handler

# Generated at 2022-06-24 09:54:25.714264
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tempfile
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tempfile.TemporaryFile() as f:
        with tqdm_logging_redirect(file=f):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        f.seek(0)
        for line in f:
            if b'console logging redirected to `tqdm.write()`' in line:
                break
        else:
            raise AssertionError("console logging redirection failed")

# Generated at 2022-06-24 09:54:32.922245
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    def logging_redirect_tqdm_tests():
        # type: () -> None
        with tqdm_logging_redirect(__name__, loggers=[LOG]):
            for i in range(5):
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    logging_redirect_tqdm_tests()  # should not raise

# Generated at 2022-06-24 09:54:40.935366
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:54:49.091375
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    import sys

    log_stream = StringIO()
    tqdm_stream = StringIO()
    logging_handler = _TqdmLoggingHandler()
    logging_handler.stream = log_stream
    tqdm_class = std_tqdm
    tqdm_class.stream = tqdm_stream
    logging_handler.tqdm_class = tqdm_class

    try:
        stream_handler = logging.StreamHandler(log_stream)
        stream_handler.emit(logging.LogRecord('test',logging.INFO,'path','line','msg','args','exc_info',10))
        stream_handler.flush()
        stream = log_stream.getvalue()
    except:
        e = sys.exc_info()[0]

# Generated at 2022-06-24 09:54:59.868214
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # prepare a file to write the logging messages
    import sys
    from io import StringIO
    import tqdm
    import logging

    # create a stream object for writing into it the logging messages
    logger_out = StringIO()
    log_handler = logging.StreamHandler(logger_out)
    log_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    LOG = logging.getLogger(__name__)
    LOG.addHandler(log_handler)

    # create a stream object for writing into it the messages of tqdm
    tqdm_out = StringIO()
    # get the default loopback function of tqdm
    loopback_func = tqdm.tqdm.write

    # create a loopback function


# Generated at 2022-06-24 09:55:05.219538
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def foo():
        import logging
        from tqdm import trange

        LOG = logging.getLogger(__name__)

        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    return foo()

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:55:16.770072
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm_text  # pylint: disable=import-error
    class TestOutput(object):
        def __init__(self):
            self._output_msg = None
        def write(self, output_msg):
            self.output_msg = output_msg
        @property
        def output_msg(self):
            return self._output_msg
        @output_msg.setter
        def output_msg(self, output_msg):
            self._output_msg = output_msg
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    log_handler = _TqdmLoggingHandler(tqdm_class=tqdm_text.tqdm)
    log_handler.stream = TestOutput()

# Generated at 2022-06-24 09:55:24.740608
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from unittest import mock  # py3
    except ImportError:
        import mock  # py2
    mock_stream = mock.Mock()
    mock_record = mock.Mock()
    mock_record.getMessage.return_value = 'test message'
    mock_formatter = mock.Mock()
    mock_formatter.format.return_value = 'formatted message'

    h = _TqdmLoggingHandler()
    h.stream = mock_stream
    h.setFormatter(mock_formatter)
    h.emit(mock_record)
    mock_stream.write.assert_called_with('formatted message')
    mock_stream.flush.assert_called_once()

# Generated at 2022-06-24 09:55:29.264032
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import logging
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info("test_console")
    handler = logger.handlers[0]
    # Trying to test that the message is correctly printed in stdout.
    assert handler.stream == sys.stdout
    logger.removeHandler(handler)
    os.remove('temp_tqdm_log')

# Generated at 2022-06-24 09:55:37.889135
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import tqdm

    std_out = sys.stdout

# Generated at 2022-06-24 09:55:39.850767
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr
    return handler

# Generated at 2022-06-24 09:55:42.167663
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:46.787181
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(2):
                if i == 1:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:55:54.598428
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Unit test for method emit of class _TqdmLoggingHandler"""
    tqdm_class = std_tqdm
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class)
    tqdm_logging_handler.emit("Log test 1")
    tqdm_logging_handler.emit("Log test 2")
    tqdm_logging_handler.emit("Log test 3")


# Generated at 2022-06-24 09:56:01.733094
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import io

    output_stream = io.StringIO()

    logger = logging.getLogger(__name__)

    # Remove all handlers associated with the root logger object.
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = output_stream

    logger.addHandler(handler)

    logger.warning('Test warning message.')
    
    output_stream.seek(0)
    assert output_stream.getvalue() == '[WARNING] Test warning message.\n'


# Generated at 2022-06-24 09:56:04.112206
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    return isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:56:11.281682
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # create logger
    logger = logging.getLogger('simple_example')
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    # 'application' code
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')
    logger.error('error message')
    logger.critical('critical message')


# Generated at 2022-06-24 09:56:15.854376
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    emitt_tqdm = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    record = logging.LogRecord(name='name', level=0,
                               pathname='pathname',
                               lineno=0, msg='message',
                               args='args', exc_info='exc_info')
    emitt_tqdm.emit(record=record)
    assert True

# Generated at 2022-06-24 09:56:18.668922
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    msg = logging.makeLogRecord({"msg": "test"})
    tqdm_class.emit(msg)

# Generated at 2022-06-24 09:56:23.618558
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with open('redirect_logging_tqdm_test.txt', 'w') as f:
        handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        handler.stream = f
        handler.emit('test')
    assert open('redirect_logging_tqdm_test.txt', 'r').read() == 'test\n'

# Generated at 2022-06-24 09:56:28.048927
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:56:33.278712
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Tests for constructor of class _TqdmLoggingHandler.
    """
    # Test case 1: assert calls to constructor of class _TqdmLoggingHandler are successful.
    assert _TqdmLoggingHandler() is not None, \
            "Constructor of class _TqdmLoggingHandler returned None. Expected a " \
            "non-None value to be returned by constructor."



# Generated at 2022-06-24 09:56:38.869462
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # set up logger
    logger = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)

    # redirect to stdout
    import sys
    handler.stream = sys.stdout

    logger.info('test')

    # redirect to stderr
    handler.stream = sys.stderr

    logger.info('test')



# Generated at 2022-06-24 09:56:47.669191
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    orig_handler = _get_first_found_console_logging_handler(logger.handlers)
    if orig_handler is not None:
        tqdm_handler.setFormatter(orig_handler.formatter)
        tqdm_handler.stream = orig_handler.stream

    logger.handlers = [
            handler for handler in logger.handlers
            if not _is_console_logging_handler(handler)] + [tqdm_handler]

    logging.info('emit test')
    logger.removeHandler(tqdm_handler)

# Generated at 2022-06-24 09:56:53.854675
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:56:54.922233
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert tlh

# Generated at 2022-06-24 09:56:57.595500
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-24 09:57:05.922459
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:57:09.688097
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import unittest
    class TestTqdmLoggingHandler(unittest.TestCase):
        def test_emit(self):
            handler = _TqdmLoggingHandler()
            record = logging.LogRecord(
                "name",
                logging.INFO,
                "pathname",
                1,
                "msg",
                None,
                None,
            )
            handler.emit(record)

# Generated at 2022-06-24 09:57:18.290879
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger('logging_redirect_tqdm')
    logger.propagate = False
    logger.setLevel(logging.INFO)
    ch = _TqdmLoggingHandler()
    logger.addHandler(ch)
    logger.info("Testing logging redirect to tqdm write")
    assert sys.stderr.getvalue() == "INFO:logging_redirect_tqdm:Testing logging redirect to tqdm write\n"


# Generated at 2022-06-24 09:57:25.321855
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    logging.basicConfig(
        format='[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d]'
        ' %(message)s',
        level=logging.INFO)
    LOG = logging.getLogger('test_logging_redirect_tqdm')

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")
    print("Logging restored")

# Generated at 2022-06-24 09:57:27.740709
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger()
    with tqdm_logging_redirect():
        LOG.info('test')

# Generated at 2022-06-24 09:57:41.773311
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    # logging restored

    with logging_redirect_tqdm():
        with trange(10) as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(.1)

# Generated at 2022-06-24 09:57:46.289054
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:48.860002
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    hdlr = _TqdmLoggingHandler()
    assert isinstance(hdlr, logging.StreamHandler)
    assert isinstance(hdlr.tqdm_class, type(std_tqdm))


# Generated at 2022-06-24 09:57:58.405599
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    import pytest

    class FakeTqdm:
        file = None

        @classmethod
        def write(*args, **kwargs):
            return None

        @classmethod
        def flush(cls):
            return None

    fake_tqdm = FakeTqdm()
    fake_logger = logging.Logger("test")
    fake_record = logging.LogRecord(
        "test_name", logging.DEBUG, "test_path", 1, "test_msg", None, None)


# Generated at 2022-06-24 09:58:00.295865
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(std_tqdm)

# Generated at 2022-06-24 09:58:10.472144
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function logging_redirect_tqdm.
    """
    import logging
    from tqdm import trange, tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:58:14.014034
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:58:21.264580
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    >>> import logging
    >>> import sys
    >>> LOG = logging.getLogger(__name__)
    >>> with logging_redirect_tqdm() as pbar:
    ...     for i in range(9):
    ...         if i == 4:
    ...             LOG.info('console logging redirected to `tqdm.write()`')
    ...         sys.stdout.write('.')
    ...     sys.stdout.write('\\n')
    console logging redirected to `tqdm.write()`
    """
    pass

# Generated at 2022-06-24 09:58:22.721189
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    print("TODO: implement test")

# Generated at 2022-06-24 09:58:32.534722
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import pretest_posttest  # noqa: F401

    loggers = [logging.root]

# Generated at 2022-06-24 09:58:38.951452
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(3):
                LOG.info("console logging redirected to `tqdm.write()` {}".format(i))
                time.sleep(0.001)
        # logging restored



# Generated at 2022-06-24 09:58:42.841842
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert type(tqdm_logging_handler) == _TqdmLoggingHandler


# Generated at 2022-06-24 09:58:48.413180
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect
    """
    from .main import tqdm

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(unit='B', unit_scale=True, miniters=1,
                               desc='foo', total=10) as pbar:
        for i in pbar:
            if i == 5:
                logging.info('console logging redirected to `tqdm.write()`')
            assert pbar.n == i, (pbar.n, i)

    # Example restricted to a particular logger
    logger = logging.getLogger('foo')
    logger.propagate = False
    logger.setLevel(logging.DEBUG)
