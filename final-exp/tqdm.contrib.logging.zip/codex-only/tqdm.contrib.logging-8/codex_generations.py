

# Generated at 2022-06-24 09:48:55.468956
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import logging.handlers
    import time

    # pre-test: logging is correctly redirected by default
    with logging_redirect_tqdm() as pbar:
        logging.info("test")
        time.sleep(0.2)  # to check that context manager is indeed working

    # Test for issue #420
    # Test that non-stream handlers are not affected
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    log_file = 'logging_redirect_tqdm.log'
    file_handler = logging.handlers.RotatingFileHandler(log_file, maxBytes=1)

# Generated at 2022-06-24 09:49:05.445327
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: (...) -> None
    import logging
    import os
    from tqdm.autonotebook import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # Test for tqdm_logging_redirect
        with open('test.txt', 'w') as f:
            with tqdm_logging_redirect(
                    # fd=f,
                    loggers = [LOG],
                    tqdm_class=tqdm
            ) as pbar:
                pbar.write("test1")
                pbar.set_description("test1desc")
                pbar.update(10)
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:49:12.675487
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    class MockTqdm(std_tqdm):
        def __init__(self):
            super(MockTqdm, self).__init__(file=sys.stdout, disable=False)
            self.captured_string = ""
        def write(self, s, *args, **kwargs):
            self.captured_string += s + "\n"
        def __str__(self):
            return self.captured_string

    logging.basicConfig()
    LOG = logging.getLogger(__name__)
    mock_tqdm = MockTqdm()
    with logging_redirect_tqdm(tqdm_class=MockTqdm):
        assert mock_tqdm.captured_string == ""
        LOG.info("Test message")
        assert mock_t

# Generated at 2022-06-24 09:49:23.103638
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.std import tqdm_class as std_tqdm

    # Create a fake stream for tests
    fake_string_io = StringIO()
    fake_string_io.write("")
    fake_string_io.seek(0)

    # Test the case that msg is str
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tqdm_logging_handler.stream = fake_string_io
    tqdm_logging_handler.emit("fake_record")
    assert fake_string_io.getvalue() == "fake_record\n"
    fake_string_io.seek(0)
    fake_string_io.write("")

    # Test the case that msg is not

# Generated at 2022-06-24 09:49:31.364635
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import StringIO as io
    except ImportError:
        import io
    stream = io.StringIO()

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = stream
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug('test')
    stream.seek(0)
    assert stream.read() == 'test\n'

# Generated at 2022-06-24 09:49:39.054341
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.utils import _term_move_up
    from io import StringIO

    def _check(out_s, expected):
        # type: (StringIO, bytes) -> None
        out_s.seek(0)  # to start
        ans = out_s.getvalue().encode('utf-8').strip(b'\r\n')
        if expected != ans:
            raise AssertionError("Expected: %r\n"
                                 "Actual:   %r\n" % (expected, ans))

    def _emit_and_check(log_msg, expected):
        # type: (str, bytes) -> None
        out_s = StringIO()

        # Instantiate _TqdmLoggingHandler
        handler = _TqdmLoggingHandler(std_tqdm)

       

# Generated at 2022-06-24 09:49:46.809096
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit tests for logging_redirect_tqdm.
    """
    import logging
    from tqdm import tqdm

    with tqdm_logging_redirect(total=1, desc='testing logging') as pbar:
        logging.warning('This is a warning')
        logging.info('This is an info message')
        logging.error('This is an error message')
    assert pbar.n == 0  # No lines should have been written yet
    assert pbar.last_print_n == 2  # 3 lines should have been written



# Generated at 2022-06-24 09:49:48.713000
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=100, file=sys.stderr, desc="Test") as pbar:
        for i in range(10):
            pbar.update(i)
            logging.info(str(i))


# Generated at 2022-06-24 09:49:56.795353
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with open('/dev/null', 'w') as f:
        class TestTqdm(std_tqdm):
            def write(self, s, **kwargs):
                for c in s.strip():
                    f.write(c)
        test_log_format = "%(asctime)s %(name)s %(levelname)s: %(message)s"
        test_record = logging.Logger('test').makeRecord(
            name='test',
            level=logging.INFO,
            pathname='/an/path',
            lineno=1,
            msg="test123",
            args=(),
            exc_info=None,
            func='foo')
        _TqdmLoggingHandler(tqdm_class=TestTqdm).format(test_record)

# Generated at 2022-06-24 09:50:01.622432
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    from tqdm import trange

    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect() as pbar:
        for i in trange(2):
            logger.info("logged info")
            assert pbar.write_bytes == len("logged info\n")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:50:02.491981
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()



# Generated at 2022-06-24 09:50:12.498743
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger('test')
    tqdm.set_lock(sys.__stdout__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.error('error')
    logger.info('info')
    logger.debug('debug')
    with tqdm_logging_redirect(loggers=logger, level=logging.DEBUG):
        logger.error('error')
        logger.info('info')
        logger.debug('debug')
    # Just to test internal logic
    tqdm.set_lock(sys.__stderr__)
    logger.handlers = []
    logger.error('error')
    logger.info('info')
    logger.debug('debug')

# Generated at 2022-06-24 09:50:16.206791
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream == sys.stderr


# Generated at 2022-06-24 09:50:25.039197
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler
    import logging

    stream = StringIO()
    handler = _TqdmLoggingHandler()
    log = logging.getLogger('foo')
    log.addHandler(handler)
    log.setLevel(logging.INFO)  # show everything by default

    handler.stream = stream
    tqdm.write = lambda *x: None
    handler.emit(logging.LogRecord('foo', logging.INFO, None, None, 'test1', None, None))
    assert stream.getvalue() == 'INFO:foo:test1\n'
    stream._file.seek(0)
    stream._file.truncate(0)

# Generated at 2022-06-24 09:50:30.137115
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.tests.test_logging import MyTqdm, main_test_logging
    main_test_logging(tqdm_cls=MyTqdm, tqdm_kwargs={'tqdm': 'test'})


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:50:35.888761
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler(std_tqdm)
    record = logging.LogRecord(
        name='name',
        level=logging.INFO,
        pathname='pathname',
        lineno=1,
        msg='msg',
        args=[],
        exc_info=None,
    )
    handler.emit(record)

# Generated at 2022-06-24 09:50:37.948683
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class = std_tqdm)

# Generated at 2022-06-24 09:50:41.325210
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        'a', logging.INFO, 'file', 1, 'a', None, None)
    handler.emit(record)

# Generated at 2022-06-24 09:50:50.744332
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    >>> logging.basicConfig(level=logging.DEBUG)
    >>> log = logging.getLogger(__name__)
    >>> log.info('test_log_1')
    >>> with open('_test.log', 'w') as test_log_file:
    ...     with tqdm.contrib.logging._TqdmLoggingHandler(tqdm.tqdm) as tqdm_handler:
    ...         tqdm_handler.stream = test_log_file
    ...         log.info('test_log_2')
    ...         log.error('test_log_3')
    >>> import os; os.remove('_test.log')
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod(raise_on_error=True)

# Generated at 2022-06-24 09:51:00.785367
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        from unittest.mock import patch  # py3
    except ImportError:
        from mock import patch  # py2
    from tqdm import tqdm

    # Test that logging works as expected with tqdm_logging_redirect
    progress_bar = tqdm(total=5, desc='Test')

    with patch.object(tqdm, 'write') as mock_write:
        with tqdm_logging_redirect(tqdm_class=tqdm, loggers=[logging.getLogger()]):
            logging.info("redirected stdlib logging")
            logging.info("redirected stdlib logging 2")
            assert mock_write.call_count == 2

        logging.info("not redirected stdlib logging")
        assert mock_write.call_

# Generated at 2022-06-24 09:51:05.407831
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..main import tqdm
    tqdm_class = tqdm
    loggers = None
    with tqdm_logging_redirect(desc='test', loggers=loggers, tqdm_class=tqdm_class) as pbar:
        pbar.write("console logging redirected to `tqdm.write()`")

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:51:10.353987
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    output = StringIO()

    handler = _TqdmLoggingHandler()
    handler.stream = output

    logger = logging.getLogger(__name__)
    logger.addHandler(handler)

    logger.info("log message")

    assert output.getvalue() == "log message\n"

# Generated at 2022-06-24 09:51:11.217193
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:17.246407
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler

    class DummyTqdm(object):
        def __init__(self):
            self.file = io.StringIO()

        def write(self, msg, file=None):
            file.write(msg)

    dummy_tqdm = DummyTqdm()
    _TqdmLoggingHandler(tqdm_class=DummyTqdm).emit(
        logging.makeLogRecord(dict(levelname='INFO',
                                   levelno=logging.INFO,
                                   msg='hello world')))
    assert dummy_tqdm.file.getvalue() == 'hello world\n'

# Generated at 2022-06-24 09:51:21.601031
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert_msg = "Constructor for class _TqdmLoggingHandler failed."
    blah = _TqdmLoggingHandler(std_tqdm)
    assert blah.tqdm_class is std_tqdm, assert_msg
    assert isinstance(blah.tqdm_class(), std_tqdm), assert_msg


# Generated at 2022-06-24 09:51:24.984293
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Test constructor of class _TqdmLoggingHandler"""
    output = _TqdmLoggingHandler()
    assert output.stream == sys.stderr


# Generated at 2022-06-24 09:51:31.854442
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class Logger(object):
        @staticmethod
        def exception(format, exc_info=None):
            pass

    class Exception(object):
        pass

    class Stream(object):
        def write(self, msg):
            pass

        def flush(self):
            pass

    # basic case
    format = '%(levelname)s %(name)s: %(message)s'
    stream = Stream()
    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter(format))
    handler.stream = stream
    record = logging.LogRecord('name', logging.INFO, None, 0, 'message',
                               None, None)
    handler.emit(record)

    # raise exception

# Generated at 2022-06-24 09:51:37.815991
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    output_stream = logging.StreamHandler()
    instance = _TqdmLoggingHandler(output_stream)
    assert(instance.stream == output_stream)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for _ in range(9):
            logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:45.160549
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import random
    import time
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger("TEST")

    @logging_redirect_tqdm(loggers=[LOG])
    def inner1():
        for _ in range(5):
            LOG.info("In inner1")
            time.sleep(random.uniform(0.1, 0.3))

    with logging_redirect_tqdm():
        for i in range(3):
            LOG.info("Outer loop %s" % i)
            inner1()


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:51:48.186375
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    L = _TqdmLoggingHandler()

if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:53.443303
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from unittest import TestCase

    logging.basicConfig(level=logging.DEBUG)

    class _MyTqdm(std_tqdm):
        def __init__(*args, **kwargs):
            # type: (*Any, **Any) -> None
            self.called_args = args
            self.called_kwargs = kwargs

    class _TestHandler(_TqdmLoggingHandler):
        def __init__(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            self.called_args = args
            self.called_kwargs = kwargs
            super(_TestHandler, self).__init__(*args, **kwargs)

    class _Test(TestCase):
        handler_class = _TestHandler


# Generated at 2022-06-24 09:52:02.533975
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    log = logging.getLogger("")
    log.handlers = []
    log.addHandler(logging.StreamHandler())

    import os

    with tqdm_logging_redirect(leave=True) as pbar:
        assert len(pbar) == 0
        assert str(pbar) == "0it [00:00, ?it/s]"

        log.info("test")
        assert len(pbar) == 0
        assert str(pbar) == "0it [00:00, ?it/s]"

        log.warning("test2")
        assert len(pbar) == 0
        assert str(pbar) == "0it [00:00, ?it/s]"

        log.info("\rtest3")
        assert len(pbar) == 1


# Generated at 2022-06-24 09:52:07.903927
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    log = logging.getLogger(__name__)
    stdout = sys.stdout
    with logging_redirect_tqdm():
        log.info('test')  # this should go to stdout
    stdout.write('this should go to stdout\n')  # normally this would be intercepted by tqdm

# Generated at 2022-06-24 09:52:15.843470
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    def test_logging_redirect_tqdm(with_context, tqdm_class):
        LOG = logging.getLogger(__name__)

        if with_context:
            with logging_redirect_tqdm(tqdm_class=tqdm_class):
                for i in tqdm_class(range(9)):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
        else:
            for i in tqdm_class(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    with logging_redirect_tqdm(tqdm_class=tqdm_class):
                        pass


# Generated at 2022-06-24 09:52:17.073101
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # TODO: add test
    pass


# Generated at 2022-06-24 09:52:18.592015
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)


# Generated at 2022-06-24 09:52:22.000361
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        logging.debug("LOG.debug()")
        logging.info("LOG.info()")
        logging.warning("LOG.warning()")
        logging.error("LOG.error()")
        logging.critical("LOG.critical()")



# Generated at 2022-06-24 09:52:26.649879
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        with tqdm_logging_redirect(desc='main') as pbar:
            pbar.write('Start')
            pbar.update(10)
            LOG = logging.getLogger(__name__)
            LOG.debug('Some debug information')
            LOG.info('Some info')
            LOG.warning('Some warning')
            pbar.update(20)
    except TypeError:
        raise TypeError('test_tqdm_logging_redirect failed')

# Generated at 2022-06-24 09:52:32.452684
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # pylint:disable=protected-access
    # test that the constructor works correctly
    handler = _TqdmLoggingHandler()
    assert handler._tqdm_class is std_tqdm

    class TestTqdm(object):
        pass

    handler = _TqdmLoggingHandler(tqdm_class=TestTqdm)
    assert handler._tqdm_class is TestTqdm

# Generated at 2022-06-24 09:52:37.399523
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-24 09:52:45.152743
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm

    import logging

    out = StringIO()
    logging.basicConfig(level=logging.INFO, stream=out)

    info = logging.getLogger("INFO_LOGGER")
    info.info("Hello info")

    err = logging.getLogger("ERROR_LOGGER")
    err.error("Hello error")

    with tqdm(total=10) as pbar:

        pbar.set_postfix(console_logging_=None)
        assert out.getvalue() == ""

        pbar.set_postfix(console_logging_="Hello info")
        assert out.getvalue() == ""

        pbar.set_postfix(console_logging_="INFO_LOGGER Hello info\n")

# Generated at 2022-06-24 09:52:50.704027
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm import tqdm
    from tqdm._utils import _term_move_up
    log_capture_string = StringIO()
    log_stream = logging.StreamHandler(log_capture_string)
    log_stream.setLevel(logging.DEBUG)
    logger = logging.getLogger('foo')
    logger.addHandler(log_stream)
    with tqdm(ascii=True) as bar:
        bar.write(_term_move_up() + 'X' * 10)
        logger.debug('a')
        logger.info('b')
        logger.warn('c')
        logger.error('d')
        bar.write(_term_move_up() + 'Y' * 10)

# Generated at 2022-06-24 09:52:56.625237
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler() , _TqdmLoggingHandler)



# Generated at 2022-06-24 09:52:59.747827
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm


# Generated at 2022-06-24 09:53:03.905556
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    stdout = StringIO()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = stdout
    handler.emit(logging.makeLogRecord({"msg": "XXX"}))
    handler.emit(logging.makeLogRecord({"msg": "YYY"}))
    assert stdout.getvalue() == "XXX\nYYY\n"

# Generated at 2022-06-24 09:53:09.133070
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        # Remove this part along with the "import pylint" line
        from ..tests import _deprecate_old_test  # pylint: disable=unused-import
        _deprecate_old_test(__file__)
    except:  # noqa pylint: disable=bare-except
        pass

    import logging
    from ..utils import _range

    # Initialize the logger
    LOG = logging.getLogger('logging_test')
    LOG.setLevel(logging.INFO)
    LOG.addHandler(logging.StreamHandler())

    # Write a few lines, should appear in console
    for i in _range(5):
        LOG.info(str(i))

    # Redirect stdout to tqdm using tqdm_logging_redirect

# Generated at 2022-06-24 09:53:20.015075
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # TODO: make this work both for python 2 and python 3
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3

    from .tests_tqdm import _suppress_stderr

    with _suppress_stderr():
        sio = StringIO()
        with tqdm_logging_redirect(file=sio):
            logging.info('test')
            logging.debug('test')
            logging.warning('test')
            logging.error('test')
        assert sio.getvalue() == 'test\n'

# Generated at 2022-06-24 09:53:31.843345
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    try:
        import tqdm.std  # noqa: F401
    except ImportError:
        LOG.error("tqdm std is not installed")
        exit()

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-24 09:53:42.734713
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    from contextlib import redirect_stdout
    import logging
    from tqdm import trange

    with StringIO() as stream:
        handler = logging.StreamHandler(stream)
        logging.basicConfig(level=logging.INFO, handlers=[handler])

        with redirect_stdout(stream):
            with logging_redirect_tqdm():
                for _ in trange(9):
                    logging.info("hello")
            assert "[INFO] hello" in stream.getvalue()

            logging.info("console logging restored")
            assert "[INFO] console logging restored" in stream.getvalue()

    # logging.basicConfig(level=logging.INFO)
    # with logging_redirect_tqdm():
    #     for _ in trange(9):
    #         pass



# Generated at 2022-06-24 09:53:50.614902
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class EnhancedTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            self.flush_count = 0
            super(EnhancedTqdm, self).__init__(*args, **kwargs)

        def write(self, *args, **kwargs):
            super(EnhancedTqdm, self).write(*args, **kwargs)
            self.flush_count += 1
            self.flush()

    class MyLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super(MyLogger, self).__init__(*args, **kwargs)
            self.stream = sys.stdout

    myLogger = MyLogger('test.logger')

# Generated at 2022-06-24 09:53:56.521613
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)
    for i in tqdm_logging_redirect(range(3)):
        LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:54:00.897151
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(unit="x", total=27) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    assert (pbar._n == 9 and pbar.total == 27)

# Generated at 2022-06-24 09:54:06.466837
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import default_mininterval, default_miniters
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_handler.tqdm_class == std_tqdm
    assert tqdm_handler.mininterval == default_mininterval
    assert tqdm_handler.miniters == default_miniters
    assert tqdm_handler.dynamic_ncols

if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:54:14.271213
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':

        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-24 09:54:16.473259
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    log = logging.getLogger('test')
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    log.addHandler(tqdm_handler)
    log.setLevel(logging.INFO)
    log.info('hahaha')

# Generated at 2022-06-24 09:54:21.570700
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    qbar = tqdm_logging_redirect(total=2, file=sys.stdout)
    log.info("test")
    qbar.update()

    with tqdm_logging_redirect(total=2, file=sys.stdout) as qbar:
        log.info("test")
        qbar.update()


## Unit test for function tqdm_logging_redirect

# Generated at 2022-06-24 09:54:23.593002
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert tlh.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:54:30.636431
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import LogRecord
    from unittest import TestCase
    from .test_std import mock_stdout_yield

    # Create logging handler
    handler = _TqdmLoggingHandler()
    # Create log record
    log_message = 'test'
    log_record = LogRecord(
        name='TqdmLoggingHandler',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg=log_message,
        args=(),
        exc_info=None)
    # Create console output buffer
    with mock_stdout_yield() as stdout:
        # Emit log record
        handler.emit(log_record)
        # Check output
        output = stdout.getvalue().strip()
        assert log_message == output



# Generated at 2022-06-24 09:54:33.295460
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:54:42.431428
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=unused-variable
    from tqdm.tests import pretest_posttest_run  # NOQA

    class TestTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            self.called = 0
            super(TestTqdm, self).__init__(*args, **kwargs)

        def write(self, *args, **kwargs):
            self.called += 1

    test_tqdm = TestTqdm()
    handler = _TqdmLoggingHandler(tqdm_class=TestTqdm)
    log_record = logging.LogRecord(
        'name', logging.DEBUG, 'filename', 0,
        'message', [], None)  # pylint: disable=protected-access
    handler.emit

# Generated at 2022-06-24 09:54:46.717298
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        assert trange(9)[4] == 4, \
            "`tqdm` does not work with `logging_redirect_tqdm`"



# Generated at 2022-06-24 09:54:52.906178
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from ..std import tqdm as std_tqdm
    except ImportError:
        return

    with tqdm_logging_redirect(bar_format="{postfix[0]!r}") as pbar:
        logging.info("foo")
    assert pbar.postfix[0] == "foo"

# Generated at 2022-06-24 09:54:57.366279
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Tests _TqdmLoggingHandler constructor.
    """
    expected_tqdm_class = std_tqdm
    test_tqdm_handler = _TqdmLoggingHandler()
    assert(test_tqdm_handler.tqdm_class == expected_tqdm_class)


# Generated at 2022-06-24 09:55:02.953518
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    LOG = logging.getLogger(__name__)

    # These lines are only to allow doctests to run under Python 2
    try:
        input = raw_input  # pylint: disable=undefined-variable
    except NameError:
        pass

    # log some stuff in the usual way
    print('Testing logging_redirect_tqdm')
    for i in range(3):
        LOG.info('regular log line #{}'.format(i))
        time.sleep(0.1)

    # stop and wait for user input at the end of the test
    print('(press enter to continue)')
    input()

# Generated at 2022-06-24 09:55:11.734622
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from logging import getLogger, INFO
    LOG = getLogger('test_tqdm_logging_redirect')
    with tqdm_logging_redirect(
        unit='it', miniters=0, desc='Test', ncols=0,
        total=10, leave=False, logger='test_tqdm_logging_redirect'
    ) as pbar:
        for i in trange(10):
            pbar.update(1)
            if i == 4:
                LOG.log(INFO, "console logging redirected to `tqdm.write()`")
    assert pbar.position == 10

# Generated at 2022-06-24 09:55:18.057674
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
  handler = _TqdmLoggingHandler()
  assert handler.tqdm_class is std_tqdm


# Generated at 2022-06-24 09:55:26.094336
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import tempfile
    import unittest

    from tqdm.contrib.logging import _TqdmLoggingHandler

    class _TqdmLoggingHandlerTestCase(unittest.TestCase):

        def setUp(self):
            self._temp_file = tempfile.TemporaryFile()
            self._temp_stream = sys.stdout
            sys.stdout = self._temp_file
            self._logger = logging.getLogger('some_name')
            self._logger.setLevel(logging.DEBUG)
            self._logger.addHandler(_TqdmLoggingHandler())

        def tearDown(self):
            sys.stdout = self._temp_stream
            self._temp_file.close()

        def test_debug(self):
            self._logger

# Generated at 2022-06-24 09:55:27.470162
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:55:31.804961
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:55:34.207412
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log = logging.getLogger('log')
    log.addHandler(_TqdmLoggingHandler())
    log.info('test log')


# Generated at 2022-06-24 09:55:44.871817
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    import sys
    from tqdm.contrib.logging import logging_redirect_tqdm

    with io.StringIO() as f:
        with logging_redirect_tqdm(tqdm_class=std_tqdm) as pbar:
            pbar.write('first')
            logger = logging.getLogger('logging_redirect_tqdm')
            logger.info('second')
        written = f.getvalue()
        assert written in [
            'firstsecond\n',
            'second\nfirst',
            'second\nfirst\n',
        ]  # depending on stream flush order
    # Check that logging was restored

# Generated at 2022-06-24 09:55:49.393906
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__ + "_test_logging_redirect_tqdm")
    with logging_redirect_tqdm():
        LOG.info("hello world")



# Generated at 2022-06-24 09:55:56.581181
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import trange
    from .utils import testsize
    from .tests import pretest_posttest, _range

    @pretest_posttest
    def test():
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(_range(9, unit_scale=True), desc='test',
                                   unit='iB') as pbar:
            for _ in pbar:
                if pbar.n == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored

    test()
    testsize()

# Generated at 2022-06-24 09:56:00.058001
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        _TqdmLoggingHandler(tqdm_class=std_tqdm)
    except:  # noqa pylint: disable=bare-except
        assert False


# Generated at 2022-06-24 09:56:07.863261
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logging.debug("logging.debug")
    logging.info("logging.info")
    logging.warning("logging.warning")
    logging.error("logging.error")
    logging.critical("logging.critical")
    try:
        with logging_redirect_tqdm():
            logging.debug("logging.debug")
            logging.info("logging.info")
            logging.warning("logging.warning")
            logging.error("logging.error")
            logging.critical("logging.critical")
    except:
        pass



# Generated at 2022-06-24 09:56:17.477733
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function `logging_redirect_tqdm`
    """
    from .utils import _make_dummy_log_and_logger

    log, log_handler = _make_dummy_log_and_logger(
        __name__ + '.test_logging_redirect_tqdm')

    with logging_redirect_tqdm(loggers=[log]):
        log.info('before tqdm')
        with tqdm_logging_redirect():
            log.info('inside tqdm')
        log.info('after tqdm')

    log_output = log_handler.stream.getvalue()
    assert "'inside tqdm' redirected to `tqdm.write()`\n" in log_output
    assert "'before tqdm'\n" in log

# Generated at 2022-06-24 09:56:27.555439
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import io
    import shutil
    import tempfile
    import logging

    test_file = os.path.join(tempfile.gettempdir(), 'test_tqdm.log')
    if os.path.isfile(test_file):
        os.remove(test_file)
    shutil.copy(test_file, test_file)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(test_file)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)


# Generated at 2022-06-24 09:56:34.173554
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        from .. import tqdm as tqdm_module  # pylint: disable=import-outside-toplevel
    except ImportError:
        # No point in doing the test without tqdm!
        return
    with tqdm_module.tqdm() as pbar:
        with logging_redirect_tqdm():
            logging.info("Testing logging redirect...")
            pbar.write("Testing tqdm write...")
    pbar.write("Testing write after restore...")

# Generated at 2022-06-24 09:56:42.595438
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test if execution in tqdm_logging_redirect works
    """
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9, desc='logging redirected') as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:56:48.878108
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function `logging_redirect_tqdm()`."""
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:56:53.419177
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..utils import _Term
    from .tqdm import tqdm

    lst = [1, 2, 3, 4, 5]
    with tqdm_logging_redirect(lst, total=len(lst)) as pbar:
        for i in lst:
            pbar.update()



# Generated at 2022-06-24 09:57:00.944887
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s',
                        level=logging.INFO)
    from tqdm import trange
    with tqdm_logging_redirect(trange(9), tqdm_class=trange, miniters=1, ) as pbar:
        LOG = logging.getLogger(__name__)
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:04.793216
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    >>> import logging
    >>> LOG = logging.getLogger(__name__)
    >>> with tqdm_logging_redirect(total=9, tqdm_class=tqdm.tqdm): #doctest: +SKIP
    ...     for i in range(9):
    ...         if i == 4:
    ...             LOG.info("console logging redirected to `tqdm.write()`")
    """
    pass

# Generated at 2022-06-24 09:57:06.613304
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Check that _TqdmLoggingHandler has been imported
    assert _TqdmLoggingHandler is not None
    test_handler = _TqdmLoggingHandler()
    assert test_handler is not None

# Generated at 2022-06-24 09:57:08.031550
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)

# Generated at 2022-06-24 09:57:18.690958
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock
    def side_effect(*args, **kwargs):
        return Mock(*args, **kwargs)

    patcher = patch(
        'tqdm.contrib.logging.logging_redirect_tqdm', side_effect=side_effect)
    patcher_2 = patch(
        'tqdm.contrib.logging.std_tqdm', side_effect=side_effect)
    with patcher as m, patcher_2 as m_2:
        m.start()
        m_2.start()
        with tqdm_logging_redirect(total=2):
            pass
        assert m.called
        assert m_2.called

    patcher.stop

# Generated at 2022-06-24 09:57:26.742563
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-24 09:57:32.726792
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    my_class = _TqdmLoggingHandler(std_tqdm)


# Generated at 2022-06-24 09:57:39.154085
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    logger = logging.getLogger('test')
    with logging_redirect_tqdm([logging.getLogger('test')]):
        for _ in tqdm(range(4)):
            logger.info('tqdm logging redirect')
        logging.info('tqdm logging redirect')



# Generated at 2022-06-24 09:57:46.665913
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger(__name__)]

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        loggers=loggers,
        tqdm_class=std_tqdm,
    ) as pbar:
        for i in pbar(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-24 09:57:54.481370
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    from . import _TqdmLoggingHandler

    str_io = StringIO()
    logging.basicConfig(stream=str_io, level=logging.DEBUG)
    log = logging.getLogger(__name__)

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tqdm_handler.setFormatter(logging.Formatter('%(message)s'))
    tqdm_handler.stream = str_io

    with tqdm_logging_redirect(
        total=100, bar_format="{desc}: {percentage:3.0f}%"
    ) as pbar:
        for i in range(3):
            pbar.update(i)

# Generated at 2022-06-24 09:57:59.560842
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    str1 = "This is a test"
    record = logging.LogRecord(logging.getLogger(__name__), logging.INFO, filename='', line=1, msg=str1, args=None, exc_info=None)
    tqdm_handler.emit(record)
    log_msg = tqdm_handler.stream.getvalue().strip()
    assert str1 == log_msg

# Generated at 2022-06-24 09:58:04.594906
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    try:
        with tqdm_logging_redirect():
            logging.info('test')
    except Exception as e:
        if repr(e) == "'tqdm_logging_redirect' object is not iterable":
            return

    raise ValueError('tqdm_logging_redirect is not working correctly')

# Generated at 2022-06-24 09:58:13.300259
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Example
    -------
    >>> from time import sleep
    >>> from tqdm import trange
    >>> from tqdm.contrib import logging
    >>> LOG = logging.getLogger(__name__)
    >>> logging.basicConfig(level=logging.INFO)
    >>> with logging.logging_redirect_tqdm():
    ...     for i in trange(9):
    ...         if i == 4:
    ...             LOG.info("I'm redirected to the tqdm bar")
    ...         sleep(.1)  # Slow down to read the state
    [INFO  ] I'm redirected to the tqdm bar
    8/8 [00:01,  6.69it/s]

    """
    pass

# Generated at 2022-06-24 09:58:22.738312
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    log_file = 'test_log.txt'
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(log_file)
    formatter = logging.Formatter('%(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    with logging_redirect_tqdm(loggers=[logger]):
        logger.info('redirected')

    with open(log_file, 'r') as f:
        assert f.read() == 'redirected\n'
    import os
    os.remove(log_file)



# Generated at 2022-06-24 09:58:25.941992
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with std_tqdm.std.stdout_redirector(sys.stderr):
        _TqdmLoggingHandler().emit(logging.makeLogRecord(dict(msg='Test', name='Name')))

# Generated at 2022-06-24 09:58:35.348372
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    import os
    import random
    import time

    # set up testing
    test_file = "./test_logging_redirect.log"
    if os.path.exists(test_file):
        os.remove(test_file)

    logging.basicConfig(filename=test_file, level=logging.INFO)
    LOG = logging.getLogger(__name__)

    # range value
    rng = random.randint(100, 1000)

    # testing
    with tqdm_logging_redirect(total=rng, desc="job") as pbar:
        for i in range(rng):
            sleep_time = random.uniform(0, 0.2)
            time.sleep(sleep_time)
            pbar.update(1)

# Generated at 2022-06-24 09:58:42.107282
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging
    fake_stdout = []  # type: list

    def test_pbar_write(msg):
        fake_stdout.append(msg)
    log.root.handlers = []
    log.root.addHandler(log.StreamHandler(sys.stdout))
    log.basicConfig(level=log.DEBUG)
    assert len(log.root.handlers) == 1

    def test_logging_redirect_tqdm():
        with logging_redirect_tqdm(
                loggers=[log.root],
                tqdm_class=lambda *a, **k: fake_stdout.append(a),  # type: ignore
        ):
            log.debug('spam')
            log.info('eggs')
    test_logging_redirect_tqdm

# Generated at 2022-06-24 09:58:44.878027
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.Handler)

# Generated at 2022-06-24 09:58:47.728694
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    hndlr = _TqdmLoggingHandler()
    assert isinstance(hndlr, logging.StreamHandler)