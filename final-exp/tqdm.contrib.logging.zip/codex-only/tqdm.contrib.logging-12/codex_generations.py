

# Generated at 2022-06-24 09:48:57.677129
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for function tqdm_logging_redirect"""
    import logging
    from tqdm import std  # type: ignore
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)

    loggers = [LOG]
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        assert pbar is None, "pbar is not None"
        with pbar:
            LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()
            assert pbar.n == 1.0, "pbar has not been updated"


# Generated at 2022-06-24 09:49:06.870673
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test method emit of class _TqdmLoggingHandler
    """
    class TestTqdm(object):
        def __init__(self, file_object=None):
            self.file_object = file_object

        def write(self, msg, file=None):
            self.msg = msg
            self.file = file

    # Test with no exception
    record = logging.LogRecord(
        name='test_name',
        level='test_level',
        pathname='test_pathname',
        lineno=1,
        msg='test_msg',
        args='test_args',
        exc_info='test_exc_info',
        func='test_func')
    handler = _TqdmLoggingHandler(TestTqdm)

# Generated at 2022-06-24 09:49:09.665334
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    if __name__ == '__main__':
        with tqdm_logging_redirect(
                loggers=[logger], total=10, desc='the loop'):
            for i in range(10):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:49:16.707991
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    test_stream = StringIO()
    test_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    test_handler.stream = test_stream
    test_handler.emit(logging.LogRecord(
        'test.name', logging.INFO, '/tmp/foo.py', 1, 'test message', [], None))
    assert test_stream.getvalue() == 'test message\n'

# Generated at 2022-06-24 09:49:23.143976
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # assert that format string with %(name)s and %(levelno)s works correctly
    # create a logger with an INFO level and a handler
    logger = logging.getLogger()
    logger.addHandler(_TqdmLoggingHandler())
    # set level of logger to Level.INFO
    logger.setLevel(logging.INFO)
    # log message
    logger.info("start")
    # check if a message was logged when the handler has a stream
    handler = logger.handlers[0]
    assert handler.stream is not None

# Generated at 2022-06-24 09:49:27.831627
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from six.moves import StringIO

    log = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.DEBUG)
    log.setLevel(logging.DEBUG)
    log.addHandler(handler)


# Generated at 2022-06-24 09:49:34.860638
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm

    LOG = logging.getLogger(__name__)

    with tqdm.std.tqdm_logging_redirect() as pbar:
        for _ in tqdm.std.tqdm(range(9)):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

        assert isinstance(pbar, tqdm.tqdm)

# Generated at 2022-06-24 09:49:45.809790
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    from tqdm._tqdm import tqdm as tqdm_orig
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from contextlib import contextmanager
    
    @contextmanager
    def logging_redirect_tqdm(
        loggers=None,  # type: Optional[List[logging.Logger]],
        tqdm_class=tqdm_orig  # type: Type[tqdm_orig]
    ):
        # type: (...) -> Iterator[None]
        if loggers is None:
            loggers = [logging.root]
        original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-24 09:49:48.597361
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOGGER = logging.getLogger()
    with tqdm_logging_redirect() as _:
        LOGGER.info("This should display in tqdm.")

# Generated at 2022-06-24 09:49:54.513232
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .external import mock
    with mock.patch('sys.stderr', new=open('/dev/null', 'w')):
        with mock.patch('sys.stdout', new=open('/dev/null', 'w')):
            import logging
            logging.basicConfig()
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            with logging_redirect_tqdm():
                logger.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-24 09:49:59.030020
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    def main():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    main()



# Generated at 2022-06-24 09:50:00.575158
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-24 09:50:07.523197
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    name = 'test__TqdmLoggingHandler_emit'
    logger = logging.getLogger(name)
    try:
        tqdm_handler = _TqdmLoggingHandler()
        logger.addHandler(tqdm_handler)
        with tqdm_logging_redirect(desc=name, disable=True):
            logger.info('Test')
    finally:
        logger.removeHandler(tqdm_handler)


# Generated at 2022-06-24 09:50:11.582008
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}


# Generated at 2022-06-24 09:50:16.663155
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc="test_logging_redirect_tqdm") as pbar:
        from time import sleep
        for i in range(3):
            sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-24 09:50:20.170518
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        logger = logging.getLogger("mylog")
        logger.setLevel(logging.INFO)
        handler = _TqdmLoggingHandler()
        logger.addHandler(handler)
        logger.info("Test")
    finally:
        logger.removeHandler(handler)

# Generated at 2022-06-24 09:50:25.037420
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    draw_handler = _TqdmLoggingHandler(std_tqdm)
    assert draw_handler.stream == sys.stderr

    logging.basicConfig(stream=sys.stdout)
    logger = logging.getLogger()

    logger.info(u"a")

    logger.handlers = [draw_handler]
    logger.info(u"b" + u"\n" + u"c")



# Generated at 2022-06-24 09:50:32.000339
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    def test_progress():
        """Test progress bar upon logging."""
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    # Run test
    test_progress()

# Generated at 2022-06-24 09:50:36.507024
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger()
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.info('')
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-24 09:50:47.035929
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler()
    # for Handler.setFormatter
    handler.setFormatter(None)
    handler.setFormatter(logging.Formatter())
    # for Handler.acquire, setLevel, setFormatter, addFilter, etc
    handler.acquire()
    handler.setLevel(0)
    handler.addFilter(None)
    handler.removeFilter(None)
    handler.flush()
    handler.close()
    # for Handler.createLock
    handler.createLock()
    # for Handler.setStream
    handler.setStream(None)
    # for Handler.set_name
    handler.set_name(None)
    # for Handler.emit
    logging.info("TEST_INFO")


# Unit test of function logging_redirect

# Generated at 2022-06-24 09:50:49.579028
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger("test")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    # create my console handler and set level to debug
    logger.debug("here is a debug message")
    logger.info("here is an info message")

# Generated at 2022-06-24 09:50:57.442273
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        with logging_redirect_tqdm():
            logging.info("logging redirected to `tqdm.write()`")
            for i in trange(3):
                logging.info("still redirected")
            logging.error("errors are still visible")
        logging.info("back to normal")
    except:  # noqa pylint: disable=bare-except
        logging.exception("test_logging_redirect_tqdm failed")
    else:
        logging.info("test_logging_redirect_tqdm passed")

# Generated at 2022-06-24 09:51:05.705646
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    from tqdm import tqdm
    import logging
    import tempfile
    import os

    def _test_logging_redirect_tqdm():
        # type: () -> None
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    temp_testing_file = tempfile.NamedTemporaryFile(suffix='.log', delete=False)
    original_handlers_len = len(logging.root.handlers)
    _

# Generated at 2022-06-24 09:51:07.043890
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:10.223420
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    h = _TqdmLoggingHandler(tqdm_class=tqdm.tqdm)
    assert h.tqdm_class == tqdm.tqdm


# Generated at 2022-06-24 09:51:14.811334
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import trange

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    with trange(4) as range_4:
        for i in range_4:
            with tqdm_logging_redirect():
                log.info('Iter {} of 4'.format(i))
            time.sleep(0.01)

# Generated at 2022-06-24 09:51:18.936714
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect.std(*range(9),
                                   loggers=[LOG],
                                   mininterval=0) as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:51:20.073891
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()



# Generated at 2022-06-24 09:51:26.528855
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO  # type: ignore

    logger = logging.getLogger('Test_emit')
    logger.setLevel(logging.INFO)
    my_string_io = StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.setLevel(logging.INFO)
    handler.stream = my_string_io
    logger.addHandler(handler)
    logger.info('Test')
    assert my_string_io.getvalue() == 'Test\n'

# Generated at 2022-06-24 09:51:32.395830
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        # Initialize the logger and its handler
        logging.basicConfig(level=logging.DEBUG)
        log = logging.getLogger(__name__)
        tqdm_handler = _TqdmLoggingHandler()
        log.addHandler(tqdm_handler)

        # Log messages at each level
        log.debug('This is a debug message.')
        log.info('This is an info message.')
        log.warning('This is a warning message.')
        log.error('This is an error message.')
        log.critical('This is a critical message.')

    finally:
        logging.shutdown()

if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-24 09:51:41.864845
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import StreamHandler, root
    import sys
    import warnings

    log_buffer = StringIO()
    handler = StreamHandler(log_buffer)
    root.addHandler(handler)

    log_msg = 'log_msg1'
    expected_stdout_msg = '\r' + log_msg
    tqdm_log_handler = _TqdmLoggingHandler()

    # set capture_warnings to False to avoid warnings
    # with warnings.catch_warnings():
    #     warnings.simplefilter("ignore")
    with capture_warnings(False):
        with redirect_stds(stdout=sys.stdout, stderr=sys.stderr):
            tqdm_log_handler.emit(log_msg)
        sys.stdout.flush()
        sys

# Generated at 2022-06-24 09:51:51.392916
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    assert not hasattr(handler, 'stream')
    assert not hasattr(handler, 'tqdm_class')

    import io
    stream = io.StringIO()
    handler.stream = stream
    handler.tqdm_class = std_tqdm

    import logging
    record = logging.LogRecord('logger', logging.INFO, 'pathname', 'lineno',
                               'msg', args, 'exc_info')
    assert record.exc_info is None
    handler.emit(record)
    assert record.exc_info is None
    assert stream.getvalue() == ''

    record = logging.LogRecord('logger', logging.INFO, 'pathname', 'lineno',
                               'msg', args, None)
    handler.emit(record)
   

# Generated at 2022-06-24 09:51:53.996043
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert isinstance(h, logging.Handler)

# Generated at 2022-06-24 09:52:02.935423
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    class CustomTqdm(std_tqdm):
        '''Tqdm class whose "write()" method simply stores the strings
        in a list instead of printing it to the terminal.
        '''
        def __init__(self):
            super(CustomTqdm, self).__init__()
            self.buffer = []

        def write(self, str_):
            self.buffer.append(str_)

        def flush(self):
            pass

    LOG = logging.getLogger(__name__)

# Generated at 2022-06-24 09:52:10.436514
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-24 09:52:17.322083
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect():
            for i in tqdm(list(range(9))):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:52:22.278233
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys

    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO

    logger = logging.Logger('test', logging.INFO)
    stream = StringIO()
    logger.handlers = [_TqdmLoggingHandler(tqdm_class=std_tqdm, stream=stream)]
    logger.info('test')

    assert stream.getvalue() == 'test\n'

# Generated at 2022-06-24 09:52:23.137350
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()

# Generated at 2022-06-24 09:52:26.426990
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:52:36.762518
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _DummyPBar():
        def __init__(self, file):
            self.file = file

        def write(self, msg, file=None):
            file.write(msg)

    class DummyTqdm():
        def __init__(self, file):
            self.file = file

        def write(self, msg, file=None):
            self.pbar = _DummyPBar(file)

    handler = _TqdmLoggingHandler(DummyTqdm)
    handler.stream = sys.stdout
    handler.setFormatter(logging.Formatter())
    handler.emit(logging.LogRecord("name", "INFO", "pth", "lineno",
                                   "msg", None, None))
    assert(handler.tqdm_class.pbar is not None)


# Generated at 2022-06-24 09:52:44.841095
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger('test_logging_redirect_tqdm')
    logger.setLevel(logging.INFO)

    # add a file handler to logger
    fh = logging.FileHandler('tmp.txt', mode='w')
    fh.setLevel(logging.DEBUG)
    logger.addHandler(fh)

    # add a stream handler to logger
    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    logger.addHandler(sh)

    # check original handlers before redirecting
    assert len(logger.handlers) == 2

    def test_log():
        logger.info('Test logging redirect to `tqdm.write()`')
        logger.debug('Test logging with `logger.debug`')

    # redirect
    test_log()

# Generated at 2022-06-24 09:52:48.264468
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Test function for constructor of class _TqdmLoggingHandler
    """
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    h = _TqdmLoggingHandler()
    h = _TqdmLoggingHandler(tqdm_class=type(h.tqdm_class))
    # pylint: enable=unused-variable
    # pylint: enable=protected-access

# Generated at 2022-06-24 09:52:56.292784
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from sys import stdout
    from logging import root, getLogger, StreamHandler, INFO, basicConfig

    import time
    from tqdm import trange

    with open('tmp', 'wb') as f:
        with logging_redirect_tqdm(loggers=[root], tqdm_class=trange):
            for i in trange(9):
                if i == 4:
                    getLogger().info("console logging redirected to `tqdm.write()`")
                f.write(b'\n')
                time.sleep(0.01)
        assert (f.read() == b'')

    with open('tmp', 'wb') as f:
        basicConfig(level=INFO)

# Generated at 2022-06-24 09:52:59.889390
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler_1 = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_handler_1 is not None

# Generated at 2022-06-24 09:53:03.817195
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def get_log_text(test_info=None):
        return 'This is a test.'

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info(get_log_text())
    # logging restored

# Generated at 2022-06-24 09:53:13.783246
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import re
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    log = logging.getLogger(__name__)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    log.info("console logging redirected to `tqdm.write()`")
        # logging restored


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:53:16.608122
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None


# Generated at 2022-06-24 09:53:24.203715
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=unused-argument,unused-variable
    import io
    idx = 0
    stdout = io.StringIO()
    stderr = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tqdm_handler.stream = stdout
    record = logging.LogRecord(
        name='',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg='test message',
        args=(),
        exc_info=None)
    tqdm_handler.emit(record)
    assert stdout.getvalue() == 'test message\n'
    stdout = io.StringIO()
    tqdm_handler.stream = stderr
    t

# Generated at 2022-06-24 09:53:33.940223
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():

    handler = _TqdmLoggingHandler()

    # Test message is logged on pbar
    record = logging.LogRecord("xxx", logging.INFO, "xxx", 0, "message", None, None)
    handler.handle(record)
    # pylint: disable=protected-access
    assert handler._file.getvalue() == "message\n"

    # Test exception is logged on pbar
    record = logging.LogRecord("xxx", logging.INFO, "xxx", 0, "error", None, None)
    try:
        raise ValueError("")
    except ValueError:
        record.exc_info = sys.exc_info()
    handler.handle(record)
    assert "ValueError" in handler._file.getvalue()

# Generated at 2022-06-24 09:53:43.657738
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import time
    import numpy as np
    log = logging.getLogger(__name__)

    def test_func():
        """Test function"""
        log.info('start')
        log.info('...')
        log.info('end')

    # test with "logging_redirect_tqdm"
    with logging_redirect_tqdm():
        test_func()
        with tqdm_logging_redirect(total=1):
            time.sleep(0.001)  # add some time for the logger to write
    # test without "logging_redirect_tqdm"
    test_func()

# Generated at 2022-06-24 09:53:48.941473
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-24 09:54:01.441468
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from os import devnull
    from io import StringIO
    from contextlib import redirect_stdout
    from logging import getLogger, WARNING

    s = StringIO()

    logger = getLogger('test__TqdmLoggingHandler_emit')
    logger.setLevel(WARNING)
    logger.propagate = False

    h = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    h.setLevel(WARNING)

    h.setFormatter(logging.Formatter('%(message)s'))

    # temporarily redirect stdout to s
    with redirect_stdout(s):
        f = logging.FileHandler(devnull)
        f.setLevel(WARNING)
        logger.addHandler(h)
        logger.addHandler(f)
        logger.warning('log')

   

# Generated at 2022-06-24 09:54:08.467595
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # suppress warning log
    logging.getLogger('tqdm').setLevel(logging.CRITICAL)
    from unittest import TestCase
    from io import StringIO

    class Test_tqdm_logging_redirect(TestCase):

        def setUp(self):
            self.log = logging.getLogger(__name__)
            self.log.setLevel(logging.INFO)
            self.stream = StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            self.handler.setFormatter(formatter)

# Generated at 2022-06-24 09:54:13.855266
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_handler = _TqdmLoggingHandler()
    test_handler.emit(logging.LogRecord('NAME', logging.INFO, 'PATH', 1, 'message', (), None))
    assert test_handler.stream.getvalue() == 'message\n'

# Generated at 2022-06-24 09:54:20.944347
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    record = logging.LogRecord(
        name = "name",
        level = logging.INFO,
        pathname = "pathname",
        lineno = 12,
        msg = "msg",
        args = "args",
        exc_info = "exc_info")
    with tqdm.tqdm(file=open('/dev/null','w')) as pbar:
        h = _TqdmLoggingHandler(pbar.__class__)
        h.stream = sys.stdout
        h.emit(record)

# Generated at 2022-06-24 09:54:26.547371
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    std_tqdm_write_backup = std_tqdm.write
    try:
        sys.stdout = sys.__stdout__
        std_tqdm.write = lambda msg: None
        _TqdmLoggingHandler().emit(logging.LogRecord(__name__, logging.INFO, __file__, 0,
                                                     'hello world!', None, None))
    finally:
        std_tqdm.write = std_tqdm_write_backup

# Generated at 2022-06-24 09:54:35.024965
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger('test.logging_redirect_tqdm')]
    _tqdm_class = type(tqdm_logging_redirect(loggers=loggers))
    with logging_redirect_tqdm(loggers=loggers, tqdm_class=_tqdm_class):
        for logger in loggers:
            for handler in logger.handlers:
                assert hasattr(handler, "tqdm_class")
                assert handler.tqdm_class is _tqdm_class



# Generated at 2022-06-24 09:54:39.328564
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with tqdm_logging_redirect(loggers=[logger]) as pbar:
        for i in pbar:
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
                break

# Generated at 2022-06-24 09:54:40.161760
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler().emit('test')

# Generated at 2022-06-24 09:54:44.619738
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                logging.info('console logging redirected to `tqdm.write()`')


# Generated at 2022-06-24 09:54:46.957008
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, (logging.StreamHandler, _TqdmLoggingHandler))


# Generated at 2022-06-24 09:54:54.025014
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from tqdm.std import tqdm as std_tqdm
    except ImportError:
        from tqdm import tqdm as std_tqdm

    tqdm_class = std_tqdm

    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    assert isinstance(tqdm_handler, logging.StreamHandler)


# Generated at 2022-06-24 09:55:00.662810
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Runs a sanity check that logging_redirect_tqdm() works.

    Note: The test suite will fail if logging_redirect_tqdm() is broken,
    **regardless** of whether this function passes or not.
    """
    import logging
    from tqdm import trange

    with trange(9) as t:
        with logging_redirect_tqdm():
            for i in t:
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    assert t.pos == 9



# Generated at 2022-06-24 09:55:04.572937
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging

    x = 10
    with tqdm_logging_redirect(*range(x), unit='it') as pbar:
        for i in pbar:
            logging.info('iteration %d', i)
            time.sleep(0.1)
    print()


# Generated at 2022-06-24 09:55:09.911315
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Unit test for method emit of class _TqdmLoggingHandler."""
    from ..std import tqdm as std_tqdm
    def dummy_write(text, file=None):
        # type: (str, Optional[TextIO]) -> None
        """This function is called to print text to stand out stream."""
        print(text, file=file)

    # patch tqdm.write to use dummy_write
    with patch.object(std_tqdm, 'write', side_effect=dummy_write) as mock_write:
        # expected record to pass to _TqdmLoggingHandler.emit method
        record = logging.LogRecord(
            'name', logging.INFO, __file__, 1, 'Hello world!', None, None, 'f')
        # expected text

# Generated at 2022-06-24 09:55:16.324087
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    tqdm_logginghandler = _TqdmLoggingHandler(tqdm_class)
    assert(tqdm_logginghandler.tqdm_class == tqdm_class)


# Generated at 2022-06-24 09:55:22.959013
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    logging.basicConfig(level=logging.INFO)

    loggers = [logging.root]
    pbar = tqdm_logging_redirect(
        total=10,
        miniters=0,
        mininterval=0.1,
        loggers=loggers,
        tqdm_class=std_tqdm)

    for _ in range(10):
        logging.info('Hi %s' % int(time.time()))
        pbar.update(1)
        time.sleep(0.1)
    pbar.close()

# Generated at 2022-06-24 09:55:25.213343
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm  # noqa
    from tqdm import trange  # noqa
    from tqdm.contrib import logging  # noqa
    with trange(5,
                desc="test_tqdm",
                unit="it") as pbar:
        with logging.tqdm_logging_redirect():
            pbar.set_postfix_str("test_log")

# Generated at 2022-06-24 09:55:26.780134
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    TqdmLoggingHandler = _TqdmLoggingHandler()
    assert isinstance(TqdmLoggingHandler,_TqdmLoggingHandler)


# Generated at 2022-06-24 09:55:37.039865
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import textwrap
    import logging
    import io
    import os
    import sys

    # Remove existing console handler (e.g. the one added by nose2)
    logging.getLogger().handlers = []


# Generated at 2022-06-24 09:55:42.124303
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    import tqdm.contrib.logging
    handler = tqdm.contrib.logging._TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}


# Generated at 2022-06-24 09:55:52.819074
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from unittest import TestCase
    from io import StringIO
    logging.basicConfig(level=logging.INFO)
    log_capture_string = ""

    class TestTqdmLoggingRedirect(TestCase):
        def test_tqdm_logging_redirect(self):
            with tqdm_logging_redirect() as pbar:
                global log_capture_string
                log_capture_string = StringIO()
                pbar.write("Hello, World!")
                # self.assertEqual(log_capture_string.getvalue(), "Hello, World!")

    TestTqdmLoggingRedirect().test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:55:56.792368
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    _TqdmLoggingHandler()
    """
    try:
        test = _TqdmLoggingHandler()
        assert test.tqdm_class == std_tqdm
        assert test.stream == sys.stderr
    except:
        return 1
    return 0


# Generated at 2022-06-24 09:56:03.165132
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        old_stderr = sys.stderr
        try:
            sys.stderr = open('test_logging_redirect_tqdm.log', 'w')
            logger = logging.getLogger()
            logger.setLevel(logging.INFO)
            handler = _TqdmLoggingHandler()
            logger.addHandler(handler)
            logger.info('test_logging_redirect_tqdm')
        finally:
            sys.stderr.close()
            sys.stderr = old_stderr
    except Exception:
        raise

test__TqdmLoggingHandler_emit()

# Generated at 2022-06-24 09:56:16.622759
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _term_move_up
    from tqdm.contrib.concurrent import thread_map
    from logging import getLogger

    LOG = getLogger(__name__)
    class StdTqdm(std_tqdm):
        def __init__(self):
            super(StdTqdm, self).__init__()
            self.lines = []

        def write(self, line):
            self.lines.append(line)

        def refresh(self):
            self.lines.append(_term_move_up())

    std_tqdm_orig = std_tqdm
    std_tqdm = StdTqdm
    TRACE = 5

# Generated at 2022-06-24 09:56:27.507096
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TestTqdm(std_tqdm):  # pytype: disable=module-attr
        """ TestTqdm """
        def __init__(self):
            self.written = []
            std_tqdm.__init__(self)

        def write(self, msg, _file=None):
            self.written.append(msg)
            std_tqdm.write(self, msg, _file)

        def flush(self):
            """ Flush """
            pass

    tqdm_inst = TestTqdm()
    handler = _TqdmLoggingHandler(TestTqdm)  # pytype: disable=wrong-arg-types
    record = logging.LogRecord('foo', 12, 'foo.py', 23, 'hello', [], None)
    handler.emit(record)

# Generated at 2022-06-24 09:56:34.130285
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-24 09:56:36.910462
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    logger = logging.getLogger()
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    logger.info("Test")



# Generated at 2022-06-24 09:56:46.216770
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test case for logging_redirect_tqdm()
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    COUNT = 9
    for _ in trange(COUNT, desc='outer', leave=False):
        with logging_redirect_tqdm():
            for _ in trange(COUNT, desc='inner', leave=False):
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:56:50.242049
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:56:57.340573
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""

    import re
    import sys
    try:
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore

    from ..std import tqdm as std_tqdm

    log_level = logging.INFO

    logger = logging.getLogger(__name__)
    logger.setLevel(log_level)
    logger.addHandler(logging.NullHandler())

    with patch('sys.stdout', new=sys.stderr):
        with tqdm_logging_redirect(ascii=True, desc=__name__):
            logger.info('This is a test message')


# Generated at 2022-06-24 09:57:05.992155
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function `tqdm_logging_redirect`
    """
    logging.basicConfig(format='%(message)s', level=logging.INFO)
    with tqdm_logging_redirect([1], loggers=[logging.root]) as pbar:
        logging.info('console logging redirected to `tqdm.write()`')
    try:
        # pylint: disable=expression-not-assigned
        with tqdm_logging_redirect([1, 2, 3]) as pbar:
            assert False
    except AssertionError:
        pass

# Generated at 2022-06-24 09:57:09.325038
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-24 09:57:10.507265
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler


# Generated at 2022-06-24 09:57:18.611025
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import tqdm

    log_out = io.StringIO()
    handler = _TqdmLoggingHandler(tqdm.tqdm)

    log = logging.getLogger("test")
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)
    log.propagate = False
    with tqdm.std.redirect_stdout(log_out):
        log.info("test")
        log.error("test2")
        log.debug("test3")

    assert("test\n" in log_out.getvalue())

# Generated at 2022-06-24 09:57:23.885453
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    counter = 0
    with tqdm_logging_redirect(total=4, desc="example") as pbar:
        for i in range(4):
            logging.info("Logging in loop #{}".format(i))
            counter += 1
            pbar.update(1)
    assert counter == 4


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:57:29.870664
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    stream = sys.stderr  # type: int
    tqdm_logging_handler = _TqdmLoggingHandler(stream=stream)
    assert tqdm_logging_handler.stream == stream

# Generated at 2022-06-24 09:57:34.639173
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    msg = "logging redirected to `tqdm.write()`"

    with tqdm_logging_redirect(total=1) as _:
        logger.error(msg)


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:57:35.743536
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()

# Generated at 2022-06-24 09:57:47.846842
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test for `tqdm_logging_redirect`
    """
    import tqdm
    pbar = None
    with tqdm_logging_redirect(total=10) as pbar:
        # tqdm_logging_redirect modifies logging handler
        assert len(logging.root.handlers) == 1
        assert isinstance(logging.root.handlers[0], _TqdmLoggingHandler)
        assert logging.root.handlers[0].stream is sys.stderr
        # progress bar is created
        assert isinstance(pbar, tqdm.std.tqdm)

    # logging handler is restored
    assert len(logging.root.handlers) == 1
    assert isinstance(logging.root.handlers[0], logging.StreamHandler)

# Generated at 2022-06-24 09:57:57.360085
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    from contextlib import redirect_stdout

    original_stdout = sys.stdout
    output_buffer = StringIO()
    tqdm_class = std_tqdm
    tqdm_kwargs = {'desc': 'Test'}
    with redirect_stdout(output_buffer):
        with tqdm_logging_redirect(
            tqdm_class=tqdm_class,
            **tqdm_kwargs) as pbar, logging_redirect_tqdm(tqdm_class=tqdm_class):
            pbar.update(1)
            logging.info("hello world")
            pbar.update(2)
    sys.stdout = original_stdout

# Generated at 2022-06-24 09:58:02.892895
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info("test_info")
        raise KeyboardInterrupt()
    assert True


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-24 09:58:08.780545
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
        total=9, desc="redirect logging to `tqdm.write()`", position=4
    ) as pbar:
        for i in range(9):
            pbar.update()
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-24 09:58:13.188531
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    with logging_redirect_tqdm() as pbar:
        assert pbar.tty
        assert not pbar.disable


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-24 09:58:20.213549
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging

    def message(it):
        for i in tqdm.trange(it):
            log = i
            logging.info(log)
            yield log

    with tqdm_logging_redirect(total=10,
                               loggers=[logging.getLogger()],
                               tqdm_class=tqdm.tqdm_notebook) as pbar:
        for i in message(10):
            pbar.update(1)

# Generated at 2022-06-24 09:58:30.295077
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from io import StringIO
    except ImportError:
        from io import StringIO

    test_message = 'Test Logging Message'

    tqdm_class = std_tqdm
    hdlr = _TqdmLoggingHandler(tqdm_class)
    hdlr.stream = StringIO()
    record = logging.LogRecord(name='name',
                               level=logging.INFO,
                               pathname='pathname',
                               lineno=1,
                               msg=test_message,
                               args=(),
                               exc_info=None)
    hdlr.emit(record)
    assert test_message in hdlr.stream.getvalue()



# Generated at 2022-06-24 09:58:40.142978
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from pytest import raises  # pylint: disable=unused-import
    except ImportError:
        raise ImportError("PyTest is required to run doctests.")
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.stream = sys.stdout
    tqdm_handler.emit("DEBUG")
    tqdm_handler.stream = sys.stderr
    tqdm_handler.emit("ERROR")
    with raises(Exception):
        tqdm_handler.emit("Bad message!")



# Generated at 2022-06-24 09:58:42.698035
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(logging.getLogger(__name__))
    assert(isinstance(handler, _TqdmLoggingHandler))


# Generated at 2022-06-24 09:58:43.371079
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-24 09:58:52.396615
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import Mock, patch  # type: ignore
    except ImportError:
        from mock import Mock, patch  # type: ignore

    pbar = Mock()
    with patch('tqdm.tqdm.tqdm', return_value=pbar):
        with logging_redirect_tqdm():
            logging.info('Test')
            logging.error('Test2')
    assert pbar.write.call_count == 2