

# Generated at 2022-06-22 04:56:16.959289
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock
    from .logging_tests import Test_Perf  # pylint: disable=import-outside-toplevel

    record = Test_Perf().setUp()
    LOG = logging.getLogger(__name__)
    LOG.addHandler(_TqdmLoggingHandler())
    handler = _get_first_found_console_logging_handler(LOG.handlers)
    msg = handler.format(record)
    with patch(
        'tqdm.contrib.logging._TqdmLoggingHandler.write',
        new_callable=Mock()
    ) as mock_write:
        handler.emit(record)
    tqdm_write = mock_write.call_

# Generated at 2022-06-22 04:56:28.099074
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm_std as tqdm
    from ..std import FakeTqdmFile, FakeTqdmType
    import logging

    # Use a custom TQDM class to test
    class CustomTqdm(FakeTqdmType):
        @staticmethod
        def write(*args, **kwargs):
            return

    tqdm_class = CustomTqdm
    tqdm_kwargs = {'file': FakeTqdmFile, 'static_format': '{value} {bar} {n}'}
    loggers = [logging.getLogger(__name__)]
    tqdm_kwargs_tqdm = tqdm_kwargs.copy()
    tqdm_kwargs_tqdm['loggers'] = loggers


# Generated at 2022-06-22 04:56:35.512419
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange

    with tqdm_logging_redirect(total=11, desc='logging-test',
                               loggers=[logging.getLogger("mylogger")]) as pbar:
        for i in trange(10):
            logging.getLogger("mylogger").error(str(i))
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:56:38.986038
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    Test for constructor of class _TqdmLoggingHandler
    """
    tqdm_log_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_log_handler, logging.StreamHandler)


# Generated at 2022-06-22 04:56:43.172255
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Verify that the emit function is present
    assert hasattr(_TqdmLoggingHandler(tqdm_class=std_tqdm), 'emit')


# Generated at 2022-06-22 04:56:54.773586
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import with_setup
    from tqdm.utils import _term_move_up

    @with_setup(pretest=lambda: sys.stdout.write(_term_move_up()))
    def test(loggers, tqdm_class, tqdm_kwargs):
        test_args = map(str, range(int(tqdm_kwargs.get('total', 10))))

        # Make sure same output with and without tqdm_logging_redirect

# Generated at 2022-06-22 04:56:59.452119
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(total=3) as pbar:
        logging.info("abc")
        assert pbar.n == 1
        logging.info("def")
        assert pbar.n == 2
        logging.info("ghi")
        assert pbar.n == 3


# Generated at 2022-06-22 04:57:08.011137
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import StringIO
    import logging

    buffer = StringIO.StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    handler.stream = buffer
    record = logging.LogRecord("foo", 10,
                               "bar.py", 10,
                               "hello world", [], None)
    handler.emit(record)
    assert buffer.getvalue() == "[INFO] hello world\n"

# Generated at 2022-06-22 04:57:12.732548
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_logging_handler.tqdm_class == std_tqdm
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)


# Generated at 2022-06-22 04:57:20.662411
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import re
    import StringIO
    import logging

    log = logging.getLogger()
    log_stream = StringIO.StringIO()

    # Case 1 - basic information
    logging.basicConfig(level=logging.INFO, stream=log_stream)
    with logging_redirect_tqdm():
        log.info('message')
    log_stream.seek(0)
    assert re.match(r'^\rmessage\r\n', log_stream.read())

    # Case 2 - test log format
    log_stream = StringIO.StringIO()
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s : %(levelname)s : %(message)s',
                        stream=log_stream)
    with logging_redirect_tqdm():
        log

# Generated at 2022-06-22 04:57:37.441394
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    log.info('hello world')
    log.info('how are you?')

    class TqdmLoggingHandlerMock(object):
        def __init__(self):
            self.written_text = ''

        def write(self, text, file=None):
            self.written_text += text

        def flush(self):
            pass

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=TqdmLoggingHandlerMock)
    tqdm_handler.emit(logging.root.handlers[0].createLock()._RLock__block.records[0])

# Generated at 2022-06-22 04:57:48.719507
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        LOG.handlers = []  # Needed for unittest (repeated tests)
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(4):
                if i == 2:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        with logging_redirect_tqdm([LOG]):
            for i in trange(4):
                if i == 2:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 04:57:56.039401
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        LOG = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    except ImportError:
        pass

# Generated at 2022-06-22 04:58:02.480214
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # no coverage in Python 2
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore
    with patch('sys.stdout', new=None):
        import logging
        with logging_redirect_tqdm(), tqdm_logging_redirect(
                total=10, desc='test'
        ) as pbar:
            pbar.update()
            logging.info("msg")

# Generated at 2022-06-22 04:58:10.373991
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    tqdm_class = std_tqdm
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    with logging_redirect_tqdm([logger], tqdm_class):
        for i in range(9):
            if i == 4:
                logger.info('console logging redirected to `tqdm.write()`')



# Generated at 2022-06-22 04:58:20.442642
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import inspect
    import re
    import logging
    import time

    out = ''
    with tqdm_logging_redirect(
            total=10, desc='TEST', unit='units', smoothing=0.0, miniters=1) as pbar:
        for i in range(10):
            time.sleep(0.05)
            logging.info('test_logging_redirect, i={0}'.format(i))

    assert re.search('^TEST +[0-9]+%|TEST +[0-9]+/[0-9]+[ *]$', out)


# Test function tqdm_logging_redirect with a custom tqdm class

# Generated at 2022-06-22 04:58:27.873933
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm

    class TestLogger:
        def __init__(self):
            self.call_count = 0
            self.handler_called = None
            self.level_called = None
            self.msg_called = None

        def call_fn(self, handler, level, msg):
            self.call_count += 1
            self.handler_called = handler
            self.level_called = level
            self.msg_called = msg

        def info(self, msg, *args, **kwargs):
            self.call_fn(logging.StreamHandler, logging.INFO, msg)

        def warn(self, msg, *args, **kwargs):
            self.call_fn(logging.StreamHandler, logging.WARN, msg)


# Generated at 2022-06-22 04:58:32.849279
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=100, desc="Progress") as t:
        for i in range(100):
            # Use a different logger so we can be sure it's the console logger
            # that's affected.
            log.info("%i", i)
            t.update()

# Generated at 2022-06-22 04:58:39.079162
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=2) as pbar:
        assert pbar is not None
    with tqdm_logging_redirect(total=2, tqdm_class=std_tqdm) as pbar:
        assert pbar is not None

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:58:50.061031
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    from ..std import tqdm as std_tqdm
    from ..std import tqdm

    # Create a logger that uses a stream of type io.StringIO as destination
    log_stream = io.StringIO()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Make sure the stream is empty before proceeding
    assert log_stream.getvalue() == ''

    # Create a logger that uses tqdm as destination
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)

# Generated at 2022-06-22 04:59:07.919705
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import os

    tqdm_logger = logging.getLogger('tqdm')
    tqdm_logger.setLevel(logging.INFO)

    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    try:  # Test if tqdm.write() supports file-like objects
        tqdm_handler.stream = open(os.devnull, 'w')
        tqdm_logger.addHandler(tqdm_handler)
        tqdm_logger.info('test')
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa
        pass

# Generated at 2022-06-22 04:59:17.356271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig()
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 04:59:22.389421
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger(__name__)
    logging.basicConfig()
    tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
    tqdm_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(tqdm_handler)
    for i in tqdm.trange(9):
        if i == 4:
            logger.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test__TqdmLoggingHandler()

# Generated at 2022-06-22 04:59:29.295241
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Small unit test for function logging_redirect_tqdm.
    """
    import logging
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3
    try:
        from unittest import mock  # Python 3.3+
    except ImportError:
        from mock import mock  # Python 2.6-3.2

    @contextmanager
    def captured_output():
        """
        Helper class for obtaining printed output.
        @credit: http://stackoverflow.com/a/17981937/730257
        """
        new_out = StringIO()
        old_out = sys.stdout
        try:
            sys.stdout = new_out
            yield sys.stdout
        finally:
            sys.stdout

# Generated at 2022-06-22 04:59:34.321921
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    from contextlib import redirect_stdout
    from tqdm import trange
    import logging

    with io.StringIO() as buf, redirect_stdout(buf):
        logger = logging.getLogger('test_logger')
        logger.addHandler(_TqdmLoggingHandler(tqdm_class=trange))
        for _ in trange(10, desc='bar'):
            logger.info('foo')
        sys.stdout.flush()
        assert buf.getvalue() == 'bar: 100%|##########| 10/10 [00:00<00:00, ?it/s]\n'

# Generated at 2022-06-22 04:59:41.234626
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    # logging.basicConfig(level=logging.INFO)
    pbar_handler = _TqdmLoggingHandler()
    pbar_logger = logging.getLogger('')
    pbar_logger.handlers = []
    pbar_logger.addHandler(pbar_handler)
    pbar_logger.info('redirected to `tqdm.write()`')

# Generated at 2022-06-22 04:59:48.964595
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    from tqdm.autonotebook import tqdm as autonotebook_tqdm
    from tqdm.std import tqdm as standard_tqdm

    msg = 'Hello World!'
    custom_stream = StringIO()
    logging.basicConfig(stream=custom_stream)

    for tqdm_class in (standard_tqdm, autonotebook_tqdm):
        custom_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm_class)
        custom_logging_handler.emit(logging.makeLogRecord({'msg': msg}))
        stream_content = custom_stream.getvalue()

# Generated at 2022-06-22 05:00:00.224286
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    try:
        from tqdm import tqdm
        has_tqdm = True
    except ImportError:
        from tqdm import std as tqdm
        has_tqdm = False
    LOG = logging.getLogger(__name__)
    try:
        with tqdm_logging_redirect(total=9) as pbar:
            tqdm_write = pbar.write
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                tqdm_write(str(i))
    except Exception:
        assert not has_tqdm
    else:
        assert has_tqdm

# Generated at 2022-06-22 05:00:05.481943
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.debug('debug message')
        LOG.info('info message')
        LOG.warning('warning message')
        LOG.error('error message')
        LOG.critical('critical message')



# Generated at 2022-06-22 05:00:10.685990
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    with tqdm_logging_redirect(total=20) as pbar:
        logging.info("tqdm_logging_redirect() test")
        for i in trange(20):
            pbar.update(1)


# Generated at 2022-06-22 05:00:44.290486
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tempfile
    import os

    logfile = tempfile.NamedTemporaryFile()
    logging.basicConfig(
        level=logging.INFO,
        filename=logfile.name,
        filemode='w',
        format='%(asctime)s [%(levelname)s] %(name)s : %(message)s'
    )
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in std_tqdm(range(10), desc='blub', unit='b'):
            if i == 5:
                LOG.info('console output redirected to tqdm')
            else:
                LOG.info('console output not redirected')

    logfile.seek(0)
    print(logfile.read())


# Generated at 2022-06-22 05:00:56.930318
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    try:
        from io import StringIO  # Python 3
    except ImportError:
        from StringIO import StringIO  # Python 2
    try:
        from contextlib import redirect_stdout  # Python 3.4+
    except ImportError:
        from contextlib import contextmanager
        @contextmanager
        def redirect_stdout(stream):  # type: (StringIO) -> Iterator[None]
            oldstdout = sys.stdout
            sys.stdout = stream
            try:
                yield
            finally:
                sys.stdout = oldstdout
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-22 05:00:59.288404
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, _TqdmLoggingHandler)

# Generated at 2022-06-22 05:01:11.959808
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger('test_logging_redirect_tqdm')
    # logging.basicConfig(level=logging.DEBUG)
    logging.basicConfig(level=logging.INFO)

    class TqdmMock:

        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    tqdm_out = TqdmMock()

    # Ensure `tqdm.write()` transfers logs to `tqdm.out`
    with logging_redirect_tqdm([LOG]):
        LOG.info('foobar')
        assert tqdm_out.text == 'foobar'

    # Ensure other handlers unaffected

# Generated at 2022-06-22 05:01:23.358192
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

        with tqdm_logging_redirect(loggers=[LOG]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:01:26.270921
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler.tqdm_class, type)
    assert issubclass(handler.tqdm_class, std_tqdm)


# Generated at 2022-06-22 05:01:35.342184
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    # [test output]
    # 100%|██████████| 9/9 [00:00<00:00, 15874.80it/s]

# Generated at 2022-06-22 05:01:36.267946
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:01:43.853084
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    try:
        import colorama
    except ImportError:
        colorama = None

    # Disable colourama init
    if colorama:
        colorama.init_orig = colorama.init
        colorama.init = lambda autoreset=True: None

    LOG = logging.getLogger(__name__)
    assert LOG.handlers == []
    logging.basicConfig(level=logging.INFO,
                        format='%(levelname 7s)s [%(name)s] %(message)s')
    assert LOG.handlers != []

    assert LOG.getEffectiveLevel() == logging.INFO
    for _ in trange(9):
        if _ == 4:
            assert len(LOG.handlers) == 1

# Generated at 2022-06-22 05:01:55.630149
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)

    class Dummy(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.message = None
            self.file = None

        def write(self, msg, file=None):
            self.message = msg
            if file is not None:
                self.file = file

    with tqdm_logging_redirect(
            'Test', dynamic_ncols=True, file=sys.stderr,
            loggers=[LOG], tqdm_class=Dummy) as pbar:
        pbar.set_description('Test')
        pbar.set_postfix(dict(eta='1m', postfix='aabb'))

# Generated at 2022-06-22 05:02:53.452367
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class FakeTqdm(std_tqdm):
        def __init__(self, file):
            super(FakeTqdm, self).__init__('fake_tqdm')
            self.file = file

        def write(self, msg, file=None):
            self.file.write(msg)

    class ExceptionHandler(logging.StreamHandler):
        def emit(self, record):
            raise Exception('emit an exception')

    tqdm_logging_handler = _TqdmLoggingHandler(FakeTqdm)
    tqdm_logging_handler.stream = sys.stdout

    # default handleError method not raise any exception, so there is not assertion

# Generated at 2022-06-22 05:03:01.522900
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # because of the context manager, stdout and stderr should be redirected
    # to the logger handler
    tqdm_handler = _TqdmLoggingHandler()
    with logging_redirect_tqdm(loggers=[logging.root], tqdm_class=std_tqdm):
        std_tqdm.write('std_tqdm')
        tqdm_handler.emit()
    assert 'std_tqdm' in sys.stdout.getvalue()
    # test when stdout and/or stderr are not in the logger handler
    tqdm_handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    orig_handler = logger.handlers[0]

# Generated at 2022-06-22 05:03:06.242287
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    logger = logging.getLogger("test")

    with tqdm_logging_redirect("MESSAGE",
                               bar_format="{l_bar}",
                               logger_class=logging.StreamHandler):
        logger.warning("test")

# Generated at 2022-06-22 05:03:10.770179
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-22 05:03:22.915156
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from .main import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        pbar = None
        with logging_redirect_tqdm():
            try:
                for i in tqdm(range(9)):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            except:  # noqa pylint: disable=bare-except
                pass

        # logging restored
        with tqdm(total=10) as pbar:
            for i in range(5):
                LOG.info("console logging NOT redirected to `tqdm.write()`")
                pbar.update()


test_logging_redirect

# Generated at 2022-06-22 05:03:24.588031
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler(None)
    assert isinstance(h, logging.StreamHandler)



# Generated at 2022-06-22 05:03:30.716663
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger('foo'), logging.getLogger('bar')]
    with tqdm_logging_redirect(
        loggers=loggers,
        tqdm_class=std_tqdm,
        total=10,
        file=sys.stdout
    ) as pbar:
        for _ in range(10):
            logging.info('hello world')
    assert '10/10' in str(pbar)

# Generated at 2022-06-22 05:03:42.405671
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import io

    import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger()

    if __name__ == '__main__':
        # go to stdout
        sys.stdout = io.StringIO()

        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=100, unit='B', unit_scale=True):
            for i in range(100):
                LOG.info('Welcome to tqdm_logging_redirect test!')
        sys.stdout.seek(0)
        assert(sys.stdout.read().count('Welcome to tqdm_logging_redirect test!') == 100)

        # go to stderr

# Generated at 2022-06-22 05:03:44.571431
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_obj = _TqdmLoggingHandler()
    assert isinstance(test_obj, logging.StreamHandler)



# Generated at 2022-06-22 05:03:55.652724
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tempfile
    from tqdm import std as tqdm_std
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    with tempfile.TemporaryFile(mode='w+') as f:
        with tqdm_logging_redirect(file=f):
            print("testing tqdm_logging_redirect", file=sys.stderr)
            LOG.info("testing tqdm_logging_redirect")
        f.seek(0)
        assert f.read().startswith("testing tqdm_logging_redirect\n")


# Generated at 2022-06-22 05:05:44.478104
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("test completed")

# Generated at 2022-06-22 05:05:53.596777
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.auto import tqdm

    tqdm.write("1, with default")
    tqdm.write("2, with default")

    with logging_redirect_tqdm():
        logging.info("1, redirected")
        logging.info("2, redirected")

    tqdm.write("3, with default")
    tqdm.write("4, with default")

    class MockTqdm(object):
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

        @staticmethod
        def write(msg):
            return sys.stdout.write("mocked: " + msg)


# Generated at 2022-06-22 05:05:54.182159
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert True

# Generated at 2022-06-22 05:06:01.967910
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Example:
        >>> from tqdm.contrib.logging import _TqdmLoggingHandler
        >>> with open('tmp', 'w') as f:
        ...     with _TqdmLoggingHandler(file=f) as h:
        ...         h.emit(None)  # doctest: +ELLIPSIS
        ...     with open('tmp') as g:
        ...         print(g.read())
        <BLANKLINE>
    """
    pass



# Generated at 2022-06-22 05:06:09.111573
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests whether the tqdm.write and flush methods are called when record is
    emitted.
    """
    try:
        from unittest import mock
    except ImportError:
        import mock

    p = mock.patch('tqdm.std.tqdm.write', autospec=True)
    p.start()
    tqdm_handler = _TqdmLoggingHandler()
    record_string = 'record'
    tqdm_handler.emit(record_string)
    p.stop()
    assert p.call_args[0][0] == record_string