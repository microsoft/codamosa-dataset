

# Generated at 2022-06-22 04:56:16.822648
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None, "Failed to create _TqdmLoggingHandler"

# Generated at 2022-06-22 04:56:21.202096
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord('a', 'b', 'c', 1, 'd', None, 'e')
    assert handler.emit(record) is None

# Generated at 2022-06-22 04:56:30.359908
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import tqdm.contrib.test_utils as stubs
    from ..std import tqdm
    from .std_logging import getLogger

    LOG = getLogger(__name__)

# Generated at 2022-06-22 04:56:40.246376
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from ..std import tqdm

    def logging_func():
        # type: () -> None
        LOG = logging.getLogger(__name__)
        LOG.info("console logging redirected to `tqdm.write()`")

    loggers = [logging.getLogger(__name__)]
    tqdm_kwargs = dict(total=9)
    with tqdm_logging_redirect(**tqdm_kwargs) as pbar:
        for i in pbar:
            if i == 4:
                logging_func()
    assert i == 4

    with tqdm_logging_redirect(**tqdm_kwargs) as pbar:
        for i in pbar:
            if i == 4:
                logging_func()


# Generated at 2022-06-22 04:56:47.216961
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Creates a logging.LogRecord() and sends it to the _TqdmLoggingHandler
    using the method emit().
    """
    tlh = _TqdmLoggingHandler()
    lr = logging.LogRecord('name', logging.DEBUG, 'filename', 1,
                           'msg', None, None)
    with tqdm_logging_redirect():
        tlh.emit(lr)
    return True

# Generated at 2022-06-22 04:56:51.708914
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Tests method emit of class _TqdmLoggingHandler
    """

    # create _TqdmLoggingHandler
    handler = _TqdmLoggingHandler()

    # write exception to stream
    try:
        a = 10/0
    except Exception as exception:
        handler.emit(exception)

# Generated at 2022-06-22 04:57:02.554402
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: (...) -> None
    """
    Test for logging_redirect_tqdm
    """
    from nose.tools import assert_less
    from .testing import TqdmHandler, TestCase

    # Suppress possible TqdmDeprecationWarning for comparisons below
    try:
        with TestCase.suppress_warnings(category=TqdmDeprecationWarning):
            pass
    except:  # noqa pylint: disable=bare-except
        pass

    log = logging.getLogger(test_logging_redirect_tqdm.__name__)

    with TestCase.system_suppress_stdout_stderr():
        # Ensure that the logger hasn't been configured
        assert len(log.handlers) == 0

        # Set up logging
        log.setLevel(logging.DEBUG)

# Generated at 2022-06-22 04:57:10.585211
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # pylint: disable=missing-docstring
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

        # logging restored
        LOG.info("console logging restored")


# Generated at 2022-06-22 04:57:19.813765
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
    import logging
    from pytest import raises
    import tqdm

    LOG = logging.getLogger(__name__)

    # Test basic logging
    with tqdm.std.tqdm() as pbar, \
            logging_redirect_tqdm(tqdm_class=tqdm.std.tqdm):
        LOG.info('1')
        LOG.error('2')
    assert pbar.get_lock()._manager.state != pbar.get_lock()._manager.RUN
    assert pbar.n != 0
    assert '1' in pbar.format_dict['postfix'][0]
    assert '2' in pbar.format_dict['postfix'][1]

# Generated at 2022-06-22 04:57:30.641044
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    import tqdm.contrib.logging
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from tqdm.std import tqdm as std_tqdm
    from tqdm.std import tqdm_gui as std_tqdm_gui
    from tqdm._utils import _environ_cols_wrapper
    import six
    import struct

    for tqdm_class in [std_tqdm, std_tqdm_gui]:
        root_logger = logging.getLogger()
        root_logger.handlers = []
        handler = _TqdmLoggingHandler(tqdm_class=tqdm_class)
        root_logger.addHandler(handler)
        root_logger.set

# Generated at 2022-06-22 04:57:43.193713
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info('console logging redirected to `tqdm.write()`')
        # logging restored


# Generated at 2022-06-22 04:57:53.096282
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Setting up a logger for logging message on console
    logger = logging.getLogger('logger')
    logger.setLevel(logging.INFO)
    console_handler = logging.StreamHandler()
    logger.addHandler(console_handler)
    # Setting up a tqdm_handler to redirect console logging to tqdm.write
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    # Checking if the same message is both logged on console and redirected
    # to tqdm.write
    for i in range(9):
        if i == 4:
            logger.addHandler(tqdm_handler)
            logger.info('This is a test message')

# Generated at 2022-06-22 04:58:03.382971
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """ This method should append test cases of the
    method emit of class _TqdmLoggingHandler.

    The method emit is hard to test. We check if the
    message is correctly written to the output.
    """
    # mock output
    import io
    from contextlib import redirect_stdout
    import sys

    f = io.StringIO()
    with redirect_stdout(f):
        # Create a default logger
        logger = logging.getLogger()
        # Set the level to DEBUG
        logger.setLevel(logging.DEBUG)
        # Create a _TqdmLoggingHandler
        tqdm_handler = _TqdmLoggingHandler()
        # Use the same stream as the logger
        tqdm_handler.stream = logger.stream
        # Create a record

# Generated at 2022-06-22 04:58:05.484810
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler().tqdm_class == std_tqdm

# Generated at 2022-06-22 04:58:11.266485
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pylint: disable=unused-variable
    """
    Pytest unit tests
    """
    # pylint: disable=unused-variable,expression-not-assigned,undefined-variable,singleton-comparison
    # pylint: disable=unused-argument
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from io import StringIO
    from tqdm.auto import tqdm

    class Loggy(object):
        def __init__(self, logger):
            self.logger = logger
            self.logger.stream = StringIO()

        def log(self, message):
            self.logger.info(message)
            self.logger.stream.seek(0)

# Generated at 2022-06-22 04:58:19.007911
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        # Python 2
        import StringIO  # pylint: disable=import-error
    except ImportError:
        # Python 3
        import io as StringIO

    logging_handler = _TqdmLoggingHandler()
    s = StringIO.StringIO()
    logging_handler.stream = s
    logging_handler.emit(logging.LogRecord('foo', logging.INFO, None, None, 'bar', None, None))
    assert s.getvalue() == 'bar\n'

# Generated at 2022-06-22 04:58:26.522077
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.std import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:58:37.769082
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from unittest import TestCase, main
    from contextlib import redirect_stdout
    from io import StringIO

    class LoggingRedirectTqdmTest(TestCase):
        def setUp(self):
            self.stream = StringIO()
        def test_logging_redirect_tqdm(self):
            # type: () -> None
            with redirect_stdout(self.stream):
                import logging

                LOG = logging.getLogger(__name__)

                if __name__ == '__main__':
                    logging.basicConfig(level=logging.INFO)
                    with logging_redirect_tqdm():
                        for i in range(9):
                            if i == 4:
                                LOG.info("console logging redirected to `tqdm.write()`")
                   

# Generated at 2022-06-22 04:58:43.320471
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()

    # Check if normal logging doesn't break
    record = logging.makeLogRecord({'msg': 'message', 'level': logging.INFO})
    handler.emit(record)

    # Check if custom logger class works
    class MyTqdmClass:
        def write(self, *args, **kwargs):
            pass
    handler = _TqdmLoggingHandler(MyTqdmClass)
    handler.emit(record)

    # Check if exception in tqdm.write() propagated correctly
    tqdm_stderr_orig = handler.tqdm_class.stderr
    handler.tqdm_class.stderr = None
    try:
        handler.emit(record)
    except RuntimeError:
        pass

# Generated at 2022-06-22 04:58:47.254323
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class A:
        def write(self, *args, **kwargs):  # noqa
            return 1

    assert _TqdmLoggingHandler(A()).stream.write(1) == 1
    assert _TqdmLoggingHandler().stream is std_tqdm.tqdm.write

# Generated at 2022-06-22 04:58:55.520902
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert tqdm_logging_handler is not None

# Generated at 2022-06-22 04:59:01.505504
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Avoid printing warnings
    logging.getLogger("tqdm").setLevel(logging.ERROR)

    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    doctest.testfile("test_logging.rst", optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:59:09.032526
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._utils import _term_move_up as term_move_up
    from .utils import _range

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in _range(10):
            LOG.info("inside")
        LOG.warning("this")
        LOG.warning("is")
        LOG.warning("a warning")
        for _ in _range(5):
            LOG.info("outside")

    print("\x1b[A" * 4 + term_move_up() + "outside")

# Generated at 2022-06-22 04:59:16.560834
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import unittest.mock as mock  # py3k
    except ImportError:
        import mock  # type: ignore

    my_mock = mock.Mock()
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.stream = my_mock
    tqdm_logging_handler.emit('test')
    my_mock.write.assert_called_once_with('test\n')
    my_mock.flush.assert_called_once()

# Generated at 2022-06-22 04:59:22.783107
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import multiprocessing as mp

    # logger
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    def my_func(x):
        LOG.info("Hello")
        return x**2

    # Test 1: with tqdm_logging_redirect
    with tqdm_logging_redirect(*tqdm_kwargs()) as pbar:
        with mp.Pool(2) as p:
            list(pbar(p.imap(
                my_func,
                [1, 2, 3, 4, 5])))
    # Test 2: with logging_redirect_tqdm

# Generated at 2022-06-22 04:59:25.318810
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    '''
    Test function for the _TqdmLoggingHandler constructor.
    '''
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-22 04:59:32.729983
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm

    with tqdm(_out=StringIO()) as pbar:
        handler = _TqdmLoggingHandler(tqdm)
        handler.emit(logging.LogRecord(
            name="tqdm_logging_test",
            level=logging.INFO,
            pathname=None,
            lineno=None,
            msg="message",
            args=(),
            exc_info=None))
        assert pbar.readline() == "message\n"

# Generated at 2022-06-22 04:59:44.400635
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import mock
    def assert_write_called_with(mock_write, msg, fp):
        assert len(mock_write.call_args_list) == 1
        mock_write_args, mock_write_kwargs = mock_write.call_args
        assert msg == mock_write_args[0]
        assert fp == mock_write_args[1]

    with mock.patch('tqdm.contrib.logging._TqdmLoggingHandler.write') as mock_write:
        mock_stream = io.BytesIO()
        th = _TqdmLoggingHandler()
        th.stream = mock_stream
        record = logging.LogRecord('foo', logging.INFO, None, None, 'bar', None, None)
        th.emit(record)
        assert_write_

# Generated at 2022-06-22 04:59:55.344471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
            loggers=[LOG]
        ) as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        assert pbar is not None

# Generated at 2022-06-22 05:00:03.574411
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class Test_TqdmLoggingHandler(unittest.TestCase):
        """unit test"""
        def test_constructor(self):
            """Test constructor"""
            handler = _TqdmLoggingHandler()
            self.assertTrue(isinstance(handler, logging.StreamHandler))
            self.assertEqual(handler.tqdm_class, std_tqdm)
            handler = _TqdmLoggingHandler(tqdm_class=logging)
            self.assertEqual(handler.tqdm_class, logging)



# Generated at 2022-06-22 05:00:17.594091
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MyTqdm(std_tqdm):
        _instances = set()  # type: Set[MyTqdm]
        def __init__(self, *args, **kwargs):
            self.write_msgs = []  # type: List[Any]
            super(MyTqdm, self).__init__(*args, **kwargs)
        def write(self, msg, file=None):
            # type: (Any) -> None
            self.write_msgs.append(msg)
        def __del__(self):
            # type: () -> None
            MyTqdm._instances.remove(self)
            super(MyTqdm, self).__del__()

    log = logging.getLogger("test_logger")

# Generated at 2022-06-22 05:00:19.848206
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler() is not None


# Generated at 2022-06-22 05:00:29.072894
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import tempfile
    from io import StringIO
    from contextlib import closing
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)

    # Capture stdout
    out = StringIO()
    with closing(out):
        with tqdm_logging_redirect(total=5, file=out):
            logging.info("tqdm_logging_redirect OK")
            for _ in range(5):
                logging.info("tqdm_logging_redirect OK")

    # Check stdout
    assert 'tqdm_logging_redirect OK' in out.getvalue().strip()

# Generated at 2022-06-22 05:00:35.262176
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import logging
    import cStringIO

    handler = _TqdmLoggingHandler()

    # sys.stdout supposed to be a tty,
    # handler.stream needs to be an object with a file descriptor
    # (otherwise, the following handler.emit will fail)
    handler.stream = sys.stdout

    # mock the handler.stream.write method
    original_write = sys.stdout.write
    sys.stdout.write = lambda value: None
    buf = cStringIO.StringIO()
    try:
        logging.warning('test')
        # failed if _tqdm_write() failed
    finally:
        sys.stdout.write = original_write
    assert not buf.getvalue()  # test that nothing was written

# Generated at 2022-06-22 05:00:45.727198
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord("name", "levelno", "pathname", 1,
                               "msg", None, None)

    class FakeTqdm(object):
        def __init__(self):
            self.write_calls = 0
            self.flush_calls = 0

        def write(self, msg, file=None):
            self.write_calls += 1
            assert msg == "msg"

        def flush(self):
            self.flush_calls += 1

    fake_tqdm = FakeTqdm()
    handler.stream = fake_tqdm
    handler.emit(record)
    assert fake_tqdm.write_calls == 1
    assert fake_tqdm.flush_calls == 1

# Generated at 2022-06-22 05:00:51.703484
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}
    assert tqdm_handler.tqdm_class == std_tqdm



# Generated at 2022-06-22 05:00:55.845355
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    level = logging.DEBUG
    s = 'test'.ljust(10)

    record = logging.LogRecord(None, level, None, None, s, None, None)

    handler = _TqdmLoggingHandler()
    handler.emit(record)

    assert s == sys.stdout.getvalue()

# Generated at 2022-06-22 05:01:07.682947
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.utils import _deprecate_new_instance_args
    class DeprecatedTqdm(std_tqdm):

        def __init__(self, *args, **kwargs):
            # type: (*Any, **Any) -> None
            _deprecate_new_instance_args('tqdm_class')
            std_tqdm.__init__(self, *args, **kwargs)

        def __iter__(self):
            # type: () -> Iterator[None]
            try:
                yield self
            finally:
                self.close()

    logger = logging.getLogger(__name__)
    try:
        logger.info('text')
    except ValueError as e:
        assert e.args[0] == "I/O operation on closed file."

    # Test that

# Generated at 2022-06-22 05:01:16.949379
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tempfile
    import unittest

    log_file = tempfile.NamedTemporaryFile(delete=True)

    def foo(logger, name):
        logger.info('logging redirected to `tqdm.write()`')

    def bar(logger, name):
        logger.info('console logging redirected to `tqdm.write()`')

    class MyTest(unittest.TestCase):
        def test_logging_redirect_tqdm(self):
            import sys
            import tqdm

# Generated at 2022-06-22 05:01:27.142741
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test of function logging_redirect_tqdm.

    Note: Use ``python -m tqdm.contrib.logging`` to run only this unit test.
    """
    import logging
    from tqdm import trange
    # import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        print('starting\n')
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        print('\nfinished')


# No test for function tqdm_logging_redirect, covered by `

# Generated at 2022-06-22 05:01:41.273326
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # testing python 2 and python 3 compatibility for dict generation
    LOG = logging.getLogger(__name__)

    if __name__ == "__main__":
        logging.basicConfig(level=logging.INFO)

        # Testing python 3 dict generation
        with tqdm_logging_redirect(loggers=[LOG], total=9) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)
        # logging restored

        # Testing python 2 dict generation

# Generated at 2022-06-22 05:01:43.361028
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    Unit test for constructor of class _TqdmLoggingHandler
    """
    _TqdmLoggingHandler()


# Generated at 2022-06-22 05:01:49.420334
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    r"""
    Example
    -------
    >>> import logging
    >>> from tqdm import trange
    >>> from tqdm.contrib.logging import tqdm_logging_redirect

    >>> LOG = logging.getLogger(__name__)

    >>> if __name__ == '__main__':
    ...     logging.basicConfig(level=logging.INFO)
    ...     with tqdm_logging_redirect(total=9):
    ...         for i in trange(9):
    ...             if i == 4:
    ...                 LOG.info("console logging redirected to `tqdm.write()`")
    ...     # logging restored
    console logging redirected to `tqdm.write()`
    """
    pass

# Generated at 2022-06-22 05:02:00.782699
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import TextIOWrapper
    import io
    import logging
    # Create a stream where output can be read
    io_stream = io.StringIO()
    # Create a StreamHandler and provide it with the stream
    stream_handler = logging.StreamHandler(io_stream)
    stream_handler.setLevel(logging.INFO)
    # Create a Logger object and provide it with the StreamHandler
    logger = logging.getLogger('Test Logger')
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO)
    # Create a TqdmLoggingHandler and provide it with the stream
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    tqdm_handler.setLevel(logging.INFO)
    # Write a message to the logger
   

# Generated at 2022-06-22 05:02:03.364567
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-22 05:02:10.097393
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    def do_logging():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            do_logging()

# Generated at 2022-06-22 05:02:16.113673
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(tqdm_class=tqdm.tqdm):
        for i in range(50):
            if i == 20:
                LOG.info('logging redirected to tqdm.write()')

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 05:02:18.064661
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pass
    assert pbar.n == 1


# Generated at 2022-06-22 05:02:27.300784
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tqdm(range(1, 9)):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-22 05:02:34.367911
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from unittest import mock
    except ImportError:
        import mock
    mock_noticebar = mock.Mock()
    mock_noticebar.write = mock.Mock()
    mock_noticebar.writeln = mock.Mock()
    mock_noticebar.flush = mock.Mock()

    handler = _TqdmLoggingHandler(std_tqdm)
    record = logging.LogRecord(
        name='name',
        level=logging.INFO,
        pathname='pathname',
        lineno=42,
        msg='message',
        args=(),
        exc_info=None)

    handler.emit(record)

# Generated at 2022-06-22 05:02:46.884703
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    rh = _TqdmLoggingHandler()
    assert rh

# Generated at 2022-06-22 05:02:57.147950
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("logging restored")

    logging.basicConfig(level=logging.INFO)
    LOG.info("logging before redirect")
    with logging_redirect_tqdm():
        LOG.info("logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:03:02.570891
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:03:10.718328
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = open('/dev/null', 'w')
    old_handlers = logging.root.handlers
    old_level = logging.root.level
    logging.root.handlers = []
    logging.root.level = logging.DEBUG
    logging.basicConfig(level=logging.DEBUG)

    from ..std import tqdm as std_tqdm
    from ..std import format_interval
    import io
    import gc
    import time
    f = io.StringIO()

# Generated at 2022-06-22 05:03:22.864291
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    from io import StringIO
    from tqdm import tqdm
    from tqdm._utils import _term_move_up
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from unittest import TestCase

    class EmitTest(TestCase):
        def setUp(self):
            self.tqdm_stream = StringIO()
            self.handler = _TqdmLoggingHandler(tqdm_class=tqdm)
            self.handler.stream = self.tqdm_stream


# Generated at 2022-06-22 05:03:33.522352
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm._utils import _term_move_up
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from tqdm.tests.common import suppress_stderr, captured_output
    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        level=logging.INFO,
        pathname='/path/to/myapp',
        lineno=42,
        msg='Hello world!',
        args=None,
        exc_info=None
    )
    formatter = logging.Formatter()
    tqdm_handler.setFormatter(formatter)
    with captured_output(StringIO()) as (out, err):
        tqdm_handler.emit(record)
    assert out.get

# Generated at 2022-06-22 05:03:44.571981
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import io
    import tqdm

    stream = io.StringIO()

    class TqdmLogger(tqdm.tqdm):
        def __init__(self, stream=None, *args, **kwargs):
            super(TqdmLogger, self).__init__(
                *args,
                file=stream,
                dynamic_ncols=True,
                ascii=True,
                ncols=80,
                mininterval=0.5,
                disable=False,
                leave=True,
                **kwargs)

        def close(self):
            self.file = None


# Generated at 2022-06-22 05:03:55.652649
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO
    from tqdm import tqdm_gui
    import tempfile
    try:
        from unittest import mock
    except ImportError:
        import mock

    buff = StringIO()
    # buff.close = lambda: None

    with mock.patch('tqdm.tqdm_gui.AnsiToWin32') as mock_ansitowin32:
        mock_ansitowin32.__getattr__.return_value = buff
        pbar = tqdm_gui.tqdm(desc="Creating file",
                             total=1, leave=False, file=buff,
                             miniters=1, mininterval=0)
        mock_ansitowin32().write = lambda x: buff.write(x)

# Generated at 2022-06-22 05:03:57.423194
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-22 05:04:07.557312
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    #logging.setLevel(logging.INFO)
    stream = open("tqdmtest__TqdmLoggingHandler.log", "w")
    handler = _TqdmLoggingHandler(stream=stream)
    handler.emit(logging.LogRecord("name", logging.INFO, "pathname", 1, "msg",
                                None, None))
    handler.emit(logging.LogRecord("name", logging.WARNING, "pathname", 1, "msg",
                                None, None))
    handler.emit(logging.LogRecord("name", logging.DEBUG, "pathname", 1, "msg",
                                None, None))
    stream.close()