

# Generated at 2022-06-22 04:56:26.883728
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    log = logging.getLogger(__name__)
    log.addHandler(_TqdmLoggingHandler())
    log.setLevel(logging.INFO)
    # "Log message" should appear on stdout
    log.info("Log message")
    # Close sys.stdout to check that the handler is safe to use even when
    # python "thinks" it's writing to an unclosed stream handle that's
    # actually closed.
    sys.stdout.close()
    # "Log message 2" should appear on stdout
    log.info("Log message 2")


# Generated at 2022-06-22 04:56:37.199143
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class Writer(object):
        def __init__(self):
            self.msg = None

        def write(self, msg):
            self.msg = msg

    writer = Writer()

    class _TestTqdm(object):
        def __init__(self):
            self.file = writer

    tqdm = _TestTqdm()
    thandler = _TqdmLoggingHandler(tqdm_class=tqdm)

    record = logging.LogRecord('name', 'DEBUG', 'pathname', 'lineno',
                               'msg', 'args', 'exc_info', 'func')
    record.msg = 'hello'
    thandler.emit(record)

    assert writer.msg == 'hello\n'

# Generated at 2022-06-22 04:56:41.485369
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.getLogger('test_tqdm_logging_handler')
    tqdm_logging_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_logging_handler)
    logger.warning("test")

# Generated at 2022-06-22 04:56:52.088658
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import StreamHandler, Logger
    from logging.handlers import BufferingHandler

    def test_handle(record, mock_handle_error, mock_flush):
        handler = _TqdmLoggingHandler(std_tqdm)
        # Case 1: no exc_info.
        handler.emit(record)
        logger_mock("Error 1.").assert_called_once()
        mock_flush.assert_called_once()
        # Case 2: exc_info is not None.
        handler.emit(record)
        logger_mock("Error 1.").assert_called_once()
        mock_flush.assert_called_once()

    # Case 3: handleError is called.
    # The exception should be ignored, but an error message is
    # output.
    mock_stream

# Generated at 2022-06-22 04:56:56.703466
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_handler = _TqdmLoggingHandler()
    assert(test_handler.tqdm_class is std_tqdm)

    test_handler2 = _TqdmLoggingHandler(tqdm_class=logging)
    assert(test_handler2.tqdm_class is logging)


# Generated at 2022-06-22 04:57:04.518567
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import re
    import shutil
    import tempfile
    from time import sleep

    # Setup
    temp_dir = tempfile.mkdtemp()
    temp_log_path = temp_dir + '/log.txt'
    print('Testing tqdm_logging_redirect', end=" ... ")
    logger = logging.getLogger('Test')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.FileHandler(temp_log_path))
    regex_match = re.compile(r'.*\|.*')


# Generated at 2022-06-22 04:57:16.590461
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Test for method _TqdmLoggingHandler.emit."""
    from logging import NOTSET, CRITICAL, ERROR, WARNING, INFO, DEBUG, Formatter
    from logging.handlers import MemoryHandler

    logger = logging.getLogger('test-logger')
    logger.setLevel(DEBUG)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(INFO)
    memory_handler = MemoryHandler(1)
    memory_handler.setLevel(NOTSET)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setLevel(WARNING)
    logger.addHandler(stream_handler)
    logger.addHandler(memory_handler)
    logger.addHandler(tqdm_handler)


# Generated at 2022-06-22 04:57:29.201955
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys
    import tempfile

    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test_logger_handlers_Seteq(logger):
        """The logging keys are not guaranteed to be unique, so only check
        the set equality for the testing purposes"""
        log_handlers = set(logger.handlers)
        tqdm_handlers = set(_TqdmLoggingHandler)
        return log_handlers == tqdm_handlers


# Generated at 2022-06-22 04:57:30.715277
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = _TqdmLoggingHandler()
    assert tqdm_class is not None


# Generated at 2022-06-22 04:57:34.267043
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import unittest

    class MockTqdm(type(std_tqdm())):
        def __init__(self):
            self.file = sys.stdout

        def write(self, *args):
            setattr(self, *args)

        def flush(self):
            pass

    # Build a fake logging record, taken directly from the logging module's
    # code for testing
    r = logging.makeLogRecord(dict(msg='message', levelno=logging.INFO))

    # Build the handler itself
    handler = _TqdmLoggingHandler(MockTqdm)
    handler.emit(r)
    assert hasattr(handler.tqdm_class, 'record')

# Generated at 2022-06-22 04:57:50.500310
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging, os
    from tqdm import trange
    try:
        # setup logging/tqdm redirect
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
        assert os.linesep.join(logging.root.handlers[0].stream.getvalue().splitlines()[-2:]) == (
            "INFO:__main__:console logging redirected to `tqdm.write()`" + os.linesep +
            "console logging redirected to `tqdm.write()`")
    except Exception as e:
        print("Exception: " + str(e))



# Generated at 2022-06-22 04:57:58.910457
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:58:06.142386
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    logger = logging.getLogger(__name__)

    # Case 1: Without tqdm_logging_redirect
    with trange(10) as t:
        for i in t:
            if i == 5:
                logger.info('console logging is not redirected to tqdm')
                break

    # Case 2: With tqdm_logging_redirect
    with tqdm_logging_redirect(total=10) as t:
        for i in t:
            if i == 5:
                logger.info('console logging is redirected to tqdm')
                break

# Generated at 2022-06-22 04:58:09.847761
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm
    assert handler.stream is sys.stderr

# Generated at 2022-06-22 04:58:21.029059
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import unittest
    import logging
    import StringIO
    import io

    class TqdmLoggingHandler(
        _TqdmLoggingHandler
    ):
        def __init__(self):
            super(TqdmLoggingHandler, self).__init__()
            self.stream = io.StringIO()

    class LoggingRedirectTestCase(unittest.TestCase):
        def setUp(self):
            super(LoggingRedirectTestCase, self).setUp()
            self.logger = logging.getLogger('test_logging')
            self.logger.setLevel(logging.INFO)
            self.logger_handler = TqdmLoggingHandler()
            self.logger.addHandler(self.logger_handler)

        def test_emit(self):
            self.log

# Generated at 2022-06-22 04:58:31.884076
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # TODO: find a method to test this function without
    #       having to use _is_console_logging_handler
    import logging
    import sys
    import tqdm.contrib.logging

    old_stdout = sys.stdout


# Generated at 2022-06-22 04:58:33.835339
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """This function is only a formality."""
    with tqdm_logging_redirect(total=1, desc='test'):
        pass

# Generated at 2022-06-22 04:58:36.819072
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert not hasattr(handler, 'stream')


# Generated at 2022-06-22 04:58:42.756170
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        pbar.set_description(__name__)
        for _ in pbar:
            LOG.info('info')


# Expose contents of 'logging' from this namespace
from tqdm.utils import logging  # NOQA

# Generated at 2022-06-22 04:58:46.740637
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:59:04.178529
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO  # Python 3
    # wrap stdout
    orig_stdout = sys.stdout

# Generated at 2022-06-22 04:59:10.343677
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    out_stream = StringIO()
    handler = _TqdmLoggingHandler()
    handler.stream = out_stream
    handler.emit(logging.LogRecord('name', logging.INFO, 'path', 'lineno', 'msg', None, None))
    assert out_stream.getvalue() == 'msg\n'

    out_stream = StringIO()
    handler = _TqdmLoggingHandler()
    handler.stream = out_stream
    handler.emit(logging.LogRecord('name', logging.ERROR, 'path', 'lineno', 'msg', None, None))
    assert out_stream.getvalue() == 'msg\n'



# Generated at 2022-06-22 04:59:16.026760
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger()
    i = 0
    with logging_redirect_tqdm():
        for _ in trange(9):
            if i == 4:
                # redirects this log to tqdm_write
                LOG.info("console logging redirected to `tqdm.write()`")
            i += 1
    # logging restored

# Generated at 2022-06-22 04:59:22.526805
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log_str = ""
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect() as pbar:
        for _ in range(3):
            pbar.update(1)
            log_str += "hola\n"
            LOG.info("hola")
    assert (pbar.get_lock_tqdm()._instances[0]._fp.getvalue() == log_str)
    # restore the loggers
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    for logger in loggers:
        tqdm_handler = _TqdmLoggingHandler(std_tqdm)
        orig_

# Generated at 2022-06-22 04:59:30.273052
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger(__name__)]
    try:
        with tqdm_logging_redirect(
            iterable=range(0, 2), total=2, loggers=loggers,
            desc='Testing tqdm_logging_redirect',
            unit='msgs', leave=True) as pbar:
            for i in pbar:  # noqa pylint: disable=unused-variable
                logging.info('Redirected!')
    except (KeyboardInterrupt, SystemExit):
        pass
    assert pbar.pos == 1

# Generated at 2022-06-22 04:59:35.857471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            iterable=range(10),
            log_level=logging.INFO,
            desc='Redirect logging to tqdm',
            unit='step',
            leave=True) as pbar:
        logging.info('Test')
        for i in pbar:
            pass

# Generated at 2022-06-22 04:59:46.006794
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from io import StringIO
    from tqdm.contrib.logging import tqdm_logging_redirect
    from .utils import print_stdout_on_exception

    with print_stdout_on_exception():
        logger = logging.Logger(name='test')
        with StringIO() as output:
            logger.handlers = [logging.StreamHandler(output)]
            with tqdm_logging_redirect(desc='foo') as pbar:
                logger.info('bar')  # should be printed
                logger.info(pbar)  # should *not* be printed
            assert 'bar' in output.getvalue()
            assert str(pbar) in output.getvalue()
            output.truncate(0)

        with StringIO() as output:
            logger.hand

# Generated at 2022-06-22 04:59:53.989298
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._tqdm_test import pretest

    with pretest(autojump=False):
        log = logging.getLogger("test")
        log.setLevel(logging.DEBUG)
        stream = sys.stderr
        log.addHandler(logging.StreamHandler(stream))

        with logging_redirect_tqdm():
            log.debug("debug")
            log.info("info")
            log.warning("warning")
            log.error("error")
            log.critical("critical")

# Generated at 2022-06-22 04:59:59.225586
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.__class__.emit(handler, logging.LogRecord(
        name='tqdm.contrib.logging', level='DEBUG', pathname=None,
        lineno=None, msg='Test message', args=None, exc_info=None))

# Generated at 2022-06-22 05:00:05.862245
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from pytest import raises
    from tqdm import trange

    @contextmanager
    def _disable_stdout():
        # type: () -> Iterator[None]
        """Disable stdout"""
        quiet = False
        try:
            sys.stdout, stdout = None, sys.stdout
            sys.stderr, stderr = None, sys.stderr
            quiet = True
            yield
        finally:
            if quiet:
                sys.stdout, sys.stderr = stdout, stderr

    with _disable_stdout():
        with raises(ValueError):
            with logging_redirect_tqdm():
                logging.error('This should raise a ValueError')


# Generated at 2022-06-22 05:00:18.129830
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logging.info('foo')



# Generated at 2022-06-22 05:00:25.105637
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
  import logging
  from tqdm import tqdm
  from tqdm.contrib.logging import tqdm_logging_redirect

  LOG = logging.getLogger(__name__)

  if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:33.325765
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm.autonotebook import tqdm

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    stream = Mock(**{'write.return_value': None})

    handler = _TqdmLoggingHandler()
    handler.stream = stream
    handler.emit(Mock(msg='test'))
    stream.write.assert_called_with('test\n')

    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.stream = stream
    handler.emit(Mock(msg='test'))
    stream.write.assert_called_with('test\n', file=stream)

    stream = Mock()
    handler = _TqdmLoggingHandler()
    handler.stream = stream
   

# Generated at 2022-06-22 05:00:43.327078
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3

    with StringIO() as buf:
        sys.stderr, old_stderr = buf, sys.stderr
        try:
            logging.basicConfig()  # Not called yet
            logger = logging.getLogger('tqdm')
            logger.handlers = []
            logger.addHandler(_TqdmLoggingHandler())
            logger.error('Hello world')
        finally:
            sys.stderr = old_stderr
        assert buf.getvalue() == 'Hello world'
        buf.close()

# Generated at 2022-06-22 05:00:56.101826
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    test_str = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'
    log.error(test_str)
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    with _TqdmLoggingHandler() as h:
        log.error(test_str)
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    with tqdm_logging_redirect() as pbar:
        log.error(test_str)
    log = logging

# Generated at 2022-06-22 05:01:02.623407
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    assert not any(isinstance(x, _TqdmLoggingHandler) for x in LOG.handlers)
    with logging_redirect_tqdm():
        assert any(isinstance(x, _TqdmLoggingHandler) for x in LOG.handlers)
    assert not any(isinstance(x, _TqdmLoggingHandler) for x in LOG.handlers)


# Generated at 2022-06-22 05:01:14.689114
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # test that no error is raised by tqdm_logging_redirect()
    # when logging.root is not defined (e.g. in a sub process)
    import logging
    import multiprocessing
    import os
    import subprocess

    def sub_process():
        # type: () -> None
        with tqdm_logging_redirect(total=1):
            pass
    if os.name == 'nt':  # multiprocessing on windows
        sub_process()  # call sub process twice to load it properly
    p = multiprocessing.Process(target=sub_process)
    p.start()
    p.join()

    # logging.root defined again
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect(total=1):
        pass

# Generated at 2022-06-22 05:01:23.436285
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect():
        with trange(3) as pbar:
            for i in range(3):
                pbar.update()
                assert pbar.n == i + 1
                assert pbar.last_print_n == i + 1
    assert pbar.n == 3
    assert pbar.last_print_n == None


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:01:34.197714
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.info("Logging start")
    for _ in tqdm_logging_redirect(total=10, unit='B', unit_scale=True):
        LOG.info("console logging redirected to `tqdm.write()`")
    logger

# Generated at 2022-06-22 05:01:35.781431
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()

# Test for _get_first_found_console_logging_handler

# Generated at 2022-06-22 05:01:55.189613
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger('test_logging_redirect_tqdm')
    with tqdm_logging_redirect(total=9, desc="Test: ", file=sys.__stdout__) as pbar:
        for _ in pbar:
            if _ == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert len(log.handlers) == 1
    assert isinstance(log.handlers[0], logging.StreamHandler)
    assert log.handlers[0].stream == sys.stdout

# Generated at 2022-06-22 05:02:03.343503
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    # Test when logging.root is the default logger
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # Test when we have multiple logger objects
    class DummyLogger(object):
        def __init__(self):
            self.handlers = []
            self.level = logging.INFO

        def addHandler(self, handler):
            self.handlers.append(handler)


# Generated at 2022-06-22 05:02:08.378290
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():

    # This test verifies that a class object can be constructed with no error,
    # and that no exception is thrown by emit.

    tlh = _TqdmLoggingHandler()
    # tlh.tqdm_class.write('Hello')
    # tlh.emit(None)

    return tlh

# Generated at 2022-06-22 05:02:11.393395
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as st
    with tqdm_logging_redirect(total=5, tqdm_class=st) as pbar:
        assert pbar is not None
        assert isinstance(pbar, st)

# Generated at 2022-06-22 05:02:22.875513
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from logging import basicConfig, DEBUG, INFO, getLogger
    from tqdm import tqdm

    LOG = getLogger(__name__)

    with tqdm_logging_redirect(unit_scale=True, miniters=1, level=DEBUG):
        LOG.info("Console logging redirected to tqdm.write()")
        LOG.info("still redirected")

    with tqdm_logging_redirect(unit_scale=True, miniters=1, level=DEBUG, ncols=40,
                               total=100, unit_divisor=1000, unit="B") as pbar:
        LOG.info("Console logging redirected to tqdm.write()")
        LOG.info("still redirected")
        pbar.set_description("Hello!")

# Generated at 2022-06-22 05:02:32.082993
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Dummy test just to ensure that the code is executed at least once
    to detect potential errors in import- or initialization-time.
    """
    try:
        from unittest import mock
    except ImportError:
        # If unittest.mock is not available, use `six.moves.mock`
        import mock
    import logging
    from tqdm import trange

    # Mock tqdm.write()
    original_write = std_tqdm.write
    with mock.patch('tqdm.std.tqdm.write') as pbar_write:
        log = logging.getLogger(__name__)
        log.handlers = []  # make sure that no handlers are defined
        log.setLevel(logging.INFO)


# Generated at 2022-06-22 05:02:42.278632
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Avoid warnings about deprecated error input
    logging.raiseExceptions = False

    logger = logging.getLogger(__name__)

    # Add a handler to the root logger
    # which logs DEBUG and higher messages to `sys.stdout`
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    assert len(logger.handlers) == 1
    assert logger.getEffectiveLevel() == logging.DEBUG

    with logging_redirect_tqdm():
        logger.debug('foo')
        logger.info('bar')
        logger.warning('baz')
        logger

# Generated at 2022-06-22 05:02:45.474115
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.getLogger("test").setLevel(logging.DEBUG)
    logging.getLogger("test").addHandler(_TqdmLoggingHandler())
    logging.debug("test")

# Unit tests for function logging_redirect_tqdm

# Generated at 2022-06-22 05:02:56.607796
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_tqdm import discretize
    from .tqdm import trange

    # Set up the logger and a handler at DEBUG level
    log = logging.getLogger('testlog_redirect')
    log.setLevel(logging.DEBUG)

    # Remove pre-existing console handlers for this logger (e.g. stderr)
    handlers = [h for h in log.handlers if not isinstance(h, logging.StreamHandler)]
    log.handlers = handlers

    # Create our handler
    fh = logging.FileHandler('test_redirect_tqdm.log', encoding='utf-8')
    fh.setLevel(logging.DEBUG)

    # Create a formatter

# Generated at 2022-06-22 05:02:58.964031
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm

# Generated at 2022-06-22 05:03:11.117000
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.debug('test__TqdmLoggingHandler_emit')

# Generated at 2022-06-22 05:03:12.996761
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:03:20.473162
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Initializing a TqdmLoggingHandler class and passing it as argument
    to the logging.StreamHandler.__init__ function.
    """
    test_handler = _TqdmLoggingHandler()
    # Testing the __init__ of TqdmLoggingHandler class
    assert test_handler.stream == sys.stderr
    # Testing the emit of TqdmLoggingHandler class
    test_handler.emit("test")



# Generated at 2022-06-22 05:03:23.961990
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Dummy function to create handler
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = sys.stdout
    formatter = handler.formatter
    handler.setFormatter(formatter)
    handler.emit("Glue")


# Generated at 2022-06-22 05:03:34.662870
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import pytest
    except ImportError:
        pytest = None
    if pytest is None:
        return
    import logging
    import logging.handlers
    from io import StringIO
    from tempfile import TemporaryFile
    from tqdm import trange
    from tqdm import tqdm as std_tqdm
    from tqdm.contrib import logging_redirect_tqdm

    LOG = logging.getLogger('test_tqdm_logging_redirect')

    # Test console logging
    f = StringIO()
    with pytest.raises(AttributeError):
        with logging_redirect_tqdm(
                loggers=[LOG], tqdm_class=std_tqdm) as pbar:
            pbar.write("this should fail")


# Generated at 2022-06-22 05:03:45.637934
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if sys.version_info >= (2, 7):
        from .tests_tqdm import pretest_posttest  # pylint: disable=import-error

        @pretest_posttest
        def check():
            import logging
            from tqdm import trange
            from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
            LOG = logging.getLogger(__name__)

            if __name__ == '__main__':
                logging.basicConfig(level=logging.INFO)
                logging_redirect_tqdm()
                print("logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:03:53.186742
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect(total=9,
                               desc='Console logging redirected to `tqdm.write()`',
                               file=sys.stderr,
                               leave=True):
        logging.root.error('test error message')
        logging.root.info('test info message')
        logging.root.warning('test warning message')
        logging.root.debug('test debug message')

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 05:04:03.988990
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for the function `logging_redirect_tqdm`.
    """

    import io
    import logging
    import sys  # nosec  # nosec required for mocking stdout

    from ..std import tqdm as std_tqdm
    from ..std import time
    from ..utils import _term_move_up, _range

    def _log_to_stdout(
        logger=None,  # type: Optional[logging.Logger]
        stdout=sys.stdout):  # type: (...) -> None
        # type: (...) -> None
        """Dummy function to test logging to stdout"""
        if logger is None:
            logger = logging.getLogger('logging_test')
        logger.info('before')

        # Print something to the

# Generated at 2022-06-22 05:04:12.660449
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    from tqdm import tqdm
    from ..std import tqdm as std_tqdm
    from .logging import _TqdmLoggingHandler

    print('testing _TqdmLoggingHandler()')

    for tqdm_class in [std_tqdm, tqdm]:
        stream = StringIO()
        handler = _TqdmLoggingHandler(tqdm_class)
        handler.stream = stream

        handler.emit(logging.INFO)
        assert stream.getvalue() == 'INFO:root:None\n'
        assert stream.getvalue() == 'INFO:root:None\n'

# Generated at 2022-06-22 05:04:17.429612
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("This should appear in tqdm")
    logging.info("This should not appear in tqdm")


# Functional test for function logging_redirect_tqdm
if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:04:31.138092
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)



# Generated at 2022-06-22 05:04:43.607355
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for tqdm_logging_redirect.
    """
    import logging
    import sys
    import os
    import tempfile
    import time
    import traceback
    try:
        os.remove('logging_output_redirect_tqdm.txt')
    except:  # noqa pylint: disable=bare-except
        pass

    LOG = logging.getLogger(__name__)

    # Test case 1: default tqdm is being used
    with open('logging_output_redirect_tqdm.txt', mode='w') as f:
        with tqdm_logging_redirect(file=f, desc='test1') as pbar:
            for _ in range(3):
                pbar.update(1)

# Generated at 2022-06-22 05:04:53.807345
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _FakeTqdm(object):
        class __metaclass__(type):
            def __init__(self, *args, **kwargs):  # NOQA
                super(_FakeTqdm.__metaclass__, self).__init__(*args, **kwargs)
                self.write_called = False

            def write(self, msg, file=None):
                self.write_called = True
                assert file is None

    fake_tqdm = _FakeTqdm()
    with _TqdmLoggingHandler(tqdm_class=_FakeTqdm) as tqdm_log_handler, \
            tqdm(disable=True) as tqdm_bar:
        tqdm_log_handler.tqdm_class = _FakeTqdm
        tqdm_log_

# Generated at 2022-06-22 05:05:00.565305
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from cStringIO import StringIO  # NOQA
    except ImportError:
        from io import StringIO  # NOQA
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm._utils import _term_move_up

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':

        # save previous stdout and stderr
        _err = sys.stderr
        _out = sys.stdout

# Generated at 2022-06-22 05:05:04.476961
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    import logging
    # Initialize a test class which inherits from tqdm.tqdm
    class TestTqdm(tqdm.tqdm):
        def __init__(self, *args, **kwargs):
            self.msg = ''
            super(TestTqdm, self).__init__(*args, **kwargs)

        def write(self, s, file=None, end="\n", nolock=False):
            self.msg += s

    with TestTqdm() as pbar:
        # Initialize a logger
        logger = logging.getLogger(__name__)
        # Add handler: _TqdmLoggingHandler
        handler = _TqdmLoggingHandler(tqdm_class=TestTqdm)
        logger.addHandler(handler)
       

# Generated at 2022-06-22 05:05:06.139447
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None



# Generated at 2022-06-22 05:05:12.750143
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    output_string = ""
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        from tqdm import tqdm
        for i in tqdm(range(9)):
            output_string += i
    assert output_string == "012345678"


# Generated at 2022-06-22 05:05:15.713844
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(level=logging.INFO) as pbar:  # noqa
        logging.warning('it works!')

# Generated at 2022-06-22 05:05:16.612238
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # TODO: add unit tests for this function
    pass

# Generated at 2022-06-22 05:05:24.007804
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    pbar = tqdm_logging_redirect()
    LOG.debug('test1')
    pbar.write('test2')
    with pbar:
        LOG.debug('test3')
        pbar.write('test4')
    with pbar as outer_pbar:
        pbar.update(1)
        with pbar as inner_pbar:
            assert inner_pbar is pbar
            assert inner_pbar is outer_pbar
        LOG.debug('test5')
        pbar.write('test6')
    for i in pbar(range(3)):
        LOG.debug('test7')
        pbar.write('test8')

# Generated at 2022-06-22 05:06:03.128945
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger('logging_redirect_test')]
    try:
        with tqdm_logging_redirect(atoms=str, loggers=loggers) as pbar:
            LOG = logging.getLogger('logging_redirect_test')
            pbar.update(str('start'))
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(str('.'))
        assert False, 'should raise exception'
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        assert True

# Generated at 2022-06-22 05:06:04.192639
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(std_tqdm)

# Generated at 2022-06-22 05:06:12.626187
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO as BytesIO
        from StringIO import StringIO  # type: ignore
    except ImportError:
        from io import BytesIO, StringIO  # type: ignore

    with BytesIO() as b:
        with StringIO() as s:
            logging.basicConfig(stream=b, level=logging.INFO)
            lh = _TqdmLoggingHandler(std_tqdm)
            lh.setFormatter(logging.Formatter('%(message)s'))
            lh.stream = s
            lh.emit(logging.LogRecord(
                'foo', logging.INFO, 'test.py', 1, 'bar', (), None, None))
            assert b.getvalue() == 'bar\n'

# Generated at 2022-06-22 05:06:18.422286
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


if __name__ == "__main__":
    test_logging_redirect_tqdm()