

# Generated at 2022-06-22 04:56:12.054421
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Ensure the method emit logs messages in the tqdm.write()
    # stream.

    # Set up the _TqdmLoggingHandler
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    msg = "hello world!"

    # Setup the log record
    record = logging.LoggerAdapter(logging.Logger(__name__), {})
    record.levelno = logging.INFO
    record.msg = msg

    # Call emit
    handler.emit(record)

    # Test that the message has been logged
    assert std_tqdm.write.call_args[0][0] == msg

# Generated at 2022-06-22 04:56:18.797411
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _term_move_up
    from tempfile import NamedTemporaryFile
    from itertools import chain
    from logging import INFO, getLogger
    for tqdm_class in [std_tqdm, tqdm]:
        tf = NamedTemporaryFile(mode="w+")
        tqdm_handler = _TqdmLoggingHandler(tqdm_class)
        tqdm_handler.stream = tf
        logger = getLogger("test")
        logger.addHandler(tqdm_handler)
        logger.setLevel(INFO)
        sample_msg = "test message"
        logger.info(sample_msg)
        assert tf.tell() == 0  # no output
        tf.seek(0)
        assert "test message" in tf.read()
        tqdm

# Generated at 2022-06-22 04:56:23.975177
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")
        logging.log(logging.INFO, "multiline logging\nredirected to `tqdm.write()`")
    logging.info("logging restored")

# Generated at 2022-06-22 04:56:30.127808
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    logger = logging.getLogger('')
    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        # redirecting console logging to tqdm.write()
        for i in range(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")
    # console logging should be restored
    logger.info("console logging restored")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:56:34.894317
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm

    tqdm.logging_redirect_tqdm(loggers=[logging.root], tqdm_class=tqdm.tqdm)
    with tqdm.tqdm(range(10)) as progress:
        progress.write('hello')



# Generated at 2022-06-22 04:56:39.434084
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    from ..std import tqdm

    handler = _TqdmLoggingHandler(tqdm)
    string_stream = io.StringIO()
    handler.stream = string_stream
    logging.info("test")

    string_stream.seek(0)
    assert string_stream.readlines()[0] == "test\n"


# Generated at 2022-06-22 04:56:43.014786
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    _TqdmLoggingHandler(tqdm_class)

# Generated at 2022-06-22 04:56:45.202477
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(None)
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-22 04:56:49.021184
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    # By default, tqdm_handler inherit its stream from logging.StreamHandler
    assert tqdm_handler.stream == sys.stderr
    assert tqdm_handler.tqdm_class == std_tqdm

# Generated at 2022-06-22 04:56:54.693450
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    try:
        import io as _io
        stdout_ = _io.StringIO()
        _TqdmLoggingHandler().emit('test')
        assert (stdout_.getvalue() == 'test\n')
    except ImportError:
        tqdm_test_py2_skip("requires `io` module")

# Generated at 2022-06-22 04:57:11.355459
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm._utils import _term_move_up
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(unit='s') as pbar:
        pbar.write('test')
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        pbar.write('test', end='')
        pbar.write('test')
        pbar.write('test', end='')
    assert pbar.closed

    # Unit test that resetting the logger works as expected (

# Generated at 2022-06-22 04:57:20.280178
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test tqdm_logging_redirect function.
    """
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        for method in ['tqdm_logging_redirect', 'logging_redirect_tqdm']:

            with eval(method)(total=10) as pbar:
                for i in pbar:
                    pbar.set_description('L1')
                    for j in pbar:
                        pbar.set_description('L2')
                        for k in pbar:
                            pbar.set_description('L3')

# Generated at 2022-06-22 04:57:23.741386
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('test')
    logging.info('test')

# Generated at 2022-06-22 04:57:35.069398
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import tqdm
    import logging
    import logging.config
    logging.config.dictConfig({
        'version': 1,
        'formatters': {'default': {
            'format': '%(asctime)s %(levelname)-8s %(message)s',
        }},
        'handlers': {'console': {
            'class': 'tqdm._tqdm.tqdm_logging._TqdmLoggingHandler',
        }},
        'root': {
            'level': 'INFO',
            'handlers': ['console'],
        },
    })
    logger = logging.getLogger(__name__)
    tqdm.tqdm.monitor_interval = 0
    tqdm.tqdm.monitor_interval = 0

# Generated at 2022-06-22 04:57:46.185100
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import tqdm
    import logging

    # Test: test the constructor of class _TqdmLoggingHandler

    class MyTqdm(tqdm.tqdm):
        def __init__(self, *args, **kwargs):
            super(MyTqdm, self).__init__(*args, **kwargs)
            self.custom_data = []

        def write(self, s, file=None):
            super(MyTqdm, self).write(s, file)
            self.custom_data.append(s)

    logger = logging.getLogger('TestTqdmLoggingHandler')
    logger.setLevel(logging.INFO)

    handler = _TqdmLoggingHandler(tqdm_class=MyTqdm)

    # By default, a TqdmLoggingHandler should write its

# Generated at 2022-06-22 04:57:53.209903
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    pass



# Generated at 2022-06-22 04:58:03.383310
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)

    with logging_redirect_tqdm():
        logger.info("redirect to tqdm")
    print()

    with logging_redirect_tqdm():
        logger.info("redirect to tqdm")
        logger.info("redirect to tqdm")
    print()

    logging.basicConfig()
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("redirect to tqdm")
    print()

    logging.basicConfig()
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("redirect to tqdm")
        logger.info("redirect to tqdm")
    print()

    logging.basicConfig

# Generated at 2022-06-22 04:58:11.044221
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 04:58:12.726322
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-22 04:58:15.800830
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with logging_redirect_tqdm():
        logging.info("hello")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:58:26.164183
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            title='test',
            desc='desc',
            total=10,
            logger='test',
            level=logging.INFO) as pbar:
        for i in range(10):
            logging.info(i)
            pbar.update(1)

# Generated at 2022-06-22 04:58:30.982800
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG = logging.getLogger(__name__)
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:58:42.624562
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    with tqdm.std.tqdm(total=5000, desc="Progress:") as pbar:
        with tqdm_logging_redirect(loggers=[logging.getLogger()],
                                   tqdm_class=tqdm.std.tqdm,
                                   total=5000):
            pbar.update(1000)
            logging.info('working')
            pbar.update(1000)
            logging.warn('warning')
            pbar.update(1000)
            logging.error('error')
            pbar.update(1000)
            logging.fatal('fatal')
            pbar.update(1000)


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:58:43.567532
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:58:49.851561
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.level = logging.INFO
    handler.setFormatter(logging.Formatter('%(message)s'))

    record = logging.LogRecord('name', logging.INFO, pathname='path',
                               lineno=1, msg='msg', args=(), exc_info=None)
    handler.emit(record)  # shouldn't raise any exception
    handler.close()  # shouldn't raise any exception

# Generated at 2022-06-22 04:58:53.236021
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    msg = 'test'
    assert msg != std_tqdm.write(msg)
    handler.emit(msg)

# Generated at 2022-06-22 04:59:02.222189
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from tqdm.std import tqdm as std_tqdm

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9, desc="Unit test for tqdm_logging_redirect") as pbar:
        for i in trange(9):
            assert pbar.n == i
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")
    assert pbar.n == 9

# Generated at 2022-06-22 04:59:05.101381
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    assert handler.tqdm_class == tqdm



# Generated at 2022-06-22 04:59:11.271880
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    class TestLogger(logging.Logger):
        def __init__(self, level=0):
            self.counter_level = 0
            super(TestLogger, self).__init__('test', level)

        def debug(self, msg, *args, **kwargs):
            self.counter_level += 1
            super(TestLogger, self).debug(msg, *args, **kwargs)

    log = TestLogger()
    log.setLevel(logging.DEBUG)

    def test_func():
        for i in range(4):
            log.debug('i: {}'.format(i))
            yield i

    with tqdm_logging_redirect(test_func()) as pbar:
        for i in pbar:
            pass

    assert log.counter_level == 4

# Generated at 2022-06-22 04:59:20.393717
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import unittest
    import sys

    class TestLoggingHandler(unittest.TestCase):
        def get_stream(self):
            try:
                # python 2
                from cStringIO import StringIO
            except ImportError:
                # python 3
                from io import StringIO
            return StringIO()

        def setUp(self):
            self.stream = self.get_stream()
            self.handler = _TqdmLoggingHandler()
            self.handler.stream = self.stream
            self.handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
            self.logger = logging.getLogger('tqdm')
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

# Generated at 2022-06-22 04:59:38.791029
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging, time

    # create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warn message')
    logger.error('error message')
    logger.critical('critical message')

    # create handler for redirect logging

# Generated at 2022-06-22 04:59:40.851015
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert h is not None

# Generated at 2022-06-22 04:59:44.525576
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler()
    assert handler.stream in {sys.stderr, sys.stdout}
    assert handler.level == logging.NOTSET
    assert handler.formatter is None


# Generated at 2022-06-22 04:59:52.285867
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info("test_tqdm_logging_redirect")
    with tqdm_logging_redirect(desc='TEST', total=100):
        for i in range(100):
            LOG.info("tqdm_logging_redirect")

# Generated at 2022-06-22 05:00:02.916030
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, _TqdmLoggingHandler

    class TestLogger(object):
        def __init__(self):
            self.log_messages = []
            self.handlers = []

        def log(self, log_msg):
            self.log_messages.append(log_msg)

        def emit(self, msg):
            self.log(msg)

        def add_handler(self, handler):
            self.handlers.append(handler)

    log_level = logging.INFO
    test_logger = TestLogger()

    test_logger.add_handler(_TqdmLoggingHandler())
    assert len(test_logger.handlers) == len(test_logger.log_messages)

   

# Generated at 2022-06-22 05:00:08.869915
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm

    import tqdm
    handler = _TqdmLoggingHandler(tqdm.tqdm)
    assert handler.tqdm_class is tqdm.tqdm


# Generated at 2022-06-22 05:00:17.149302
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Convenience shortcut test.
    """
    import tqdm
    import logging
    log = logging.getLogger(__name__)
    try:
        with tqdm_logging_redirect(unit='B', unit_scale=True,
                                   miniters=1, desc='Loading via tqdm'):
            log.debug("This is a debug message")
            log.info("This is an info message")
            log.warning("This is a warning message")
            log.error("This is an error message")
            log.critical("This is a critical message")
    except IndexError:
        pass
    log.info('test_tqdm_logging_redirect succeeded')

# Generated at 2022-06-22 05:00:27.774129
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Write message "mess" on the console, then on a file.
    """
    test_file = open("__TqdmLoggingHandler.txt", "w")
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tqdm_handler.stream = test_file
    test_record = logging.LogRecord(
        name="Root_logger",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="mess",
        args=(),
        exc_info=None
    )
    tqdm_handler.emit(test_record)
    test_file.close()
    test_file = open("__TqdmLoggingHandler.txt", "r")


# Generated at 2022-06-22 05:00:34.761244
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests _TqdmLoggingHandler.emit
    """
    import logging
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    record = logging.LogRecord('name', logging.WARNING, 'pathname', 1, 'msg',
                               (None, None), None)
    try:
        # exception thrown by tqdm_class.write
        tqdm_class.write = None
        tqdm_handler.emit(record)
    except:  # noqa pylint: disable=bare-except
        pass
    else:
        raise Exception('Exception not thrown')

    # exception thrown by tqdm_class.flush
    tqdm_class.flush = None

# Generated at 2022-06-22 05:00:45.634780
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import logging  # pylint: disable=unused-import, import-outside-toplevel

    # Uncomment for debugging:
    # logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s: %(message)s')

    loggers = [logging.getLogger(__name__)]
    for handler in logging.root.handlers:
        loggers.append(handler.stream)

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with logging_redirect_tqdm():
            std_tqdm.write('This is a test')
            LOG.info("console logging redirected to `tqdm.write()`")
       

# Generated at 2022-06-22 05:01:00.528608
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    with tqdm_logging_redirect(total=2) as pbar:
        LOG = logging.getLogger(__name__)
        for i in range(2):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-22 05:01:03.313897
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.getLogger(__name__).addHandler(_TqdmLoggingHandler())
    logging.getLogger(__name__).warning("test_log_warning")



# Generated at 2022-06-22 05:01:13.999897
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    handler = _TqdmLoggingHandler()

    def handler_test(val):
        assert val in [0, 1]
        if val:
            raise ValueError('value error')

    handler.stream = handler_test
    handler.emit('This debug message should produce value 0:')
    # handler.stream = sys.stdout

    # test exception handling
    handler.stream = sys.stdout
    with open('handler_test_output.txt', 'w') as handler.stream:
        handler.emit('This exception should produce value 1:')

# Generated at 2022-06-22 05:01:25.692524
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys

    # workaround for python 2.6
    class InterruptedError(Exception):
        pass

    def redirect_logging(
            loggers=None,  # type: Optional[List[logging.Logger]]
            tqdm_class=std_tqdm  # type: Type[std_tqdm]
    ):
        original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-22 05:01:35.101535
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from .tests import pretest_posttest

    handler = _TqdmLoggingHandler()
    handler.stream = StringIO()
    handler.emit(logging.LogRecord('foo', logging.INFO, None, None, 'foobar',
                                   None, None))
    assert handler.stream.getvalue() == 'foo: foobar'
    assert handler.stream.getvalue() == 'foo: foobar'

    handler.stream = StringIO()
    handler.emit(logging.LogRecord('foo', logging.INFO, None, None, 'foobar',
                                   None, None))
    assert handler.stream.getvalue() == 'foo: foobar'



# Generated at 2022-06-22 05:01:41.551966
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-22 05:01:48.647728
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    log = logging.getLogger(__name__)
    with logging_redirect_tqdm() as pbar:
        for _ in pbar(range(10)):
            log.info("hello world!")

    with logging_redirect_tqdm():
        for _ in tqdm(range(10)):
            log.info("hello world!")

    with tqdm_logging_redirect() as pbar:
        for _ in pbar(range(10)):
            log.info("hello world!")


# Generated at 2022-06-22 05:02:00.252059
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # emulated stdout
    out_handler = logging.StreamHandler(sys.stdout)
    out_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    out_handler.setFormatter(out_formatter)
    logger.addHandler(out_handler)

    # example from above
    logger.info('hello, world')

    # this will be redirected to tqdm.write()
    logger.tqdm = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logger.addHandler(logger.tqdm)


# Generated at 2022-06-22 05:02:06.183268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time

    def print_test(tqdm_class):
        with logging_redirect_tqdm(tqdm_class=tqdm_class):
            for i in range(1000):
                print("testing...")
                time.sleep(.0001)

    print_test(std_tqdm)
    print("done")

# Generated at 2022-06-22 05:02:16.077882
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from ..std import tqdm
    import logging
    import sys
    import os
    import tempfile
    logger = logging.getLogger('test.logging.logging_redirect_tqdm')
    logger.setLevel(logging.INFO)
    logger.addHandler(_TqdmLoggingHandler(tqdm))

# Generated at 2022-06-22 05:02:43.747905
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        LOG.info("from logger")
        LOG.info("from logger")
        pbar.write("from pbar")
        pbar.write("from pbar")
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:02:48.203735
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.getLogger().setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.DEBUG)
    # Make a logger
    logger = logging.getLogger('test')
    # Test logger at root level
    with logging_redirect_tqdm():
        for i in range(3):
            logger.debug('This is a test #%s.', i)
        # Test specific level
        logger.setLevel(logging.INFO)
        for i in range(3, 6):
            logger.info('This is a test #%s.', i)
        # Test logger with propagate off
        logger.propagate = False
        for i in range(6, 10):
            logger.warning('This is a test #%s.', i)
        # Test logger at level higher than root
        logger.setLevel

# Generated at 2022-06-22 05:02:56.943541
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    logging.basicConfig(level=logging.INFO,
                        format='%(message)s')
    logger = logging.getLogger('test')
    orig_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        with logging_redirect_tqdm():
            logger.info("should appear in tqdm")
        assert sys.stdout.getvalue() == "should appear in tqdm\n", \
            "redirecting to tqdm.write() failed"
    finally:
        sys.stdout = orig_stdout


# Generated at 2022-06-22 05:03:01.865935
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    # set root logger
    logging.basicConfig(level=logging.DEBUG)

    # test that logging_redirect_tqdm works on nested loops
    trange_range = trange(10)
    for i in trange_range:
        with logging_redirect_tqdm():
            for j in trange(4):
                logging.info("hello!")
                trange_range.set_description("logging redirect test: %d" % i)

# Generated at 2022-06-22 05:03:10.591391
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    class FakeTqdm(object):
        """Fake tqdm to unit test the function."""

        def __init__(self):
            self.called = 0

        def write(self, *args, **kwargs):
            """Fake write function for tqdm."""
            self.called += 1

    class MockStream(io.StringIO):
        """Mock stream to unit test the function."""

        def __init__(self, *args, **kwargs):
            super(MockStream, self).__init__(*args, **kwargs)
            self.called = 0


# Generated at 2022-06-22 05:03:22.754104
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests import tqdm_decorator
    import logging
    from ..std import tqdm
    from .util import new_bar_as_txt

    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    tqdm_handler.tqdm_class = tqdm_decorator(
        tqdm.tqdm,
        bar_format='{l_bar}{bar}| {n_fmt}',
        bar_template='{bar} {desc}',
        ncols=80,
    )
    tqdm_handler.stream = sys.stdout

    # unit test for method emit of class _TqdmLoggingHandler
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)

# Generated at 2022-06-22 05:03:26.571075
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect() as pbar:
        pbar.update(5)

    with tqdm_logging_redirect(desc='Test tqdm_logging_redirect') as pbar:
        pbar.update(10)


# Generated at 2022-06-22 05:03:37.425841
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    import warnings
    warnings.filterwarnings('error')

    class TqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self, *args, **kwargs):
            super(TqdmLoggingHandler, self).__init__(*args, **kwargs)
            self.exception_1_emitted = False
            self.exception_2_emitted = False
            self.exception_3_emitted = False

        def emit(self, record):
            try:
                super(TqdmLoggingHandler, self).emit(record)
            except RuntimeError as e:
                assert 'Exception from within the write() method' in str(e)
                self.exception_1_emitted = True


# Generated at 2022-06-22 05:03:45.725089
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit of class _TqdmLoggingHandler
    """
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    new_stdout = StringIO()
    test_obj_emit = _TqdmLoggingHandler()
    test_obj_emit.stream = new_stdout
    record = logging.Logger('name')
    record.msg = 'Test Message'
    test_obj_emit.emit(record)
    assert new_stdout.getvalue() == 'Test Message\n'

# Generated at 2022-06-22 05:03:56.917774
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    import unittest

    class Stream(object):

        def __init__(self):
            self.buf = ''

        def write(self, data):
            self.buf = self.buf + data

    class Test_TqdmLoggingHandler(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__TqdmLoggingHandler(self):
            stream = Stream()
            logger = logging.getLogger('mylogger')
            logger.setLevel(logging.DEBUG)
            tqdm_handler = _TqdmLoggingHandler()
            tqdm_handler.__del__()
            tqdm_handler.stream = stream
            t

# Generated at 2022-06-22 05:04:44.718611
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert h is not None

# Generated at 2022-06-22 05:04:50.560517
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    tqdm_logging_handler = _TqdmLoggingHandler()

    with tqdm_logging_redirect(loggers=[logger],
                               tqdm_class=std_tqdm):
        logger.info('Logging test')  # noqa: disable=undefined-variable

# Generated at 2022-06-22 05:04:55.494478
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    def _emit(record):
        return record

    logging.setLoggerClass(logging.RootLogger)
    logger = logging.getLogger('test')
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.emit = _emit
    logger.addHandler(handler)

    msg = 'hello'
    logger.info(msg)

# Generated at 2022-06-22 05:05:06.059471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from io import BytesIO
    from tqdm import trange
    from .logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with BytesIO() as f:
            with tqdm_logging_redirect(
                    file=f,
                    loggers=[LOG],
                    bar_format='{l_bar}'
            ) as pbar, BytesIO() as f2:
                for _ in range(10):
                    f2.write(b'x')
                    pbar.update()
            # logging redirected
            assert f.getvalue() != f2.getvalue()
        # logging restored

# Generated at 2022-06-22 05:05:12.990247
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    logger = logging.getLogger(__name__)

    # mock stdout
    with patch.object(sys, 'stdout', new_callable=StringIO) as mock_stdout:
        tqdm_handler = _TqdmLoggingHandler()
        logger.addHandler(tqdm_handler)
        logger.info("Hello")
        assert(mock_stdout.getvalue() == "Hello\n")

    # mock stderr

# Generated at 2022-06-22 05:05:22.394274
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from unittest.mock import patch
    from . import _TqdmLoggingHandler
    # Test if _TqdmLoggingHandler.emit works correctly

    # Test _TqdmLoggingHandler.emit with record.msg and without record.exc_info
    with patch('tqdm.contrib.logging._TqdmLoggingHandler.stream',
               new_callable=StringIO) as stream:
        logger = logging.Logger(__name__)
        logger.setLevel(logging.INFO)
        logger.addHandler(_TqdmLoggingHandler())
        logger.info('A template {0}', 'string')
        assert stream.getvalue() == 'A template string\n'

    # Test _TqdmLoggingHandler.emit with record.msg and with record

# Generated at 2022-06-22 05:05:32.978697
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    """
    import logging
    try:
        from tqdmgit.tqdm.tqdm import tqdm  # type: ignore
    except ImportError:
        from tqdm import tqdm  # type: ignore

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:05:40.888885
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            total=9,
            desc="test_tqdm_logging_redirect",
            disable=False,
            leave=False
    ) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
                assert isinstance(pbar, std_tqdm)
                assert pbar.desc == "test_tqdm_logging_redirect"
            pbar.update()

# Generated at 2022-06-22 05:05:50.340004
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test _TqdmLoggingHandler.emit()
    """
    try:
        from unittest import mock
    except ImportError:
        import mock  # type: ignore

    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    with mock.patch('tqdm.std.tqdm.write') as mocked_write:
        tqdm_logging_handler.emit(logging.LogRecord('', logging.INFO, 'filename',
                                  'lineno', 'msg', None, None))
        assert mocked_write.call_count == 1
        assert mocked_write.call_args[0][0] == 'msg'

# Generated at 2022-06-22 05:06:02.456879
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import getLogger

    # Initialize tqdm handler
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter('%(message)s'))
    # Write output to buffer
    out = StringIO()
    tqdm_handler.stream = out
    # Create logger object
    logger = getLogger('logger')
    logger.setLevel(logging.INFO)
    logger.addHandler(tqdm_handler)

    # Test
    logger.info('message')
    assert out.getvalue() == 'message\n'

    # Test without newline character
    out.truncate()
    logger.info('message2')
    assert out.getvalue() == 'message2'