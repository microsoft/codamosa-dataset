

# Generated at 2022-06-22 04:56:21.150364
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(desc="test", logger=logger, loggers=[logger]) as pbar:
        for i in range(1):
            logger.info("Hello")
            pbar.update(1)

# Generated at 2022-06-22 04:56:28.651225
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    loggers = [logging.getLogger('test_app')]
    time_delay = 0.01
    with tqdm_logging_redirect(loggers=loggers, desc='Test', unit_scale=True,
                               unit='B', unit_divisor=1024, mininterval=0.1,
                               leave=False) as pbar:
        LOG = logging.getLogger('test_app')
        for i in range(10):
            LOG.info('Write log')
            time.sleep(time_delay)
        pbar.update(0)

# Generated at 2022-06-22 04:56:39.213068
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger('tqdm.test_logging_redirect')]
    with tqdm_logging_redirect(
            loggers=loggers, total=9, bar_format='{n}'
        ) as pbar:
        assert pbar.total == 9
        assert pbar.miniters == 1
        assert pbar.file.name == sys.stderr.name
        assert pbar.write_bytes == pbar.handle_write_byte
        assert pbar.handle_write_byte(b'\n') is None
        assert pbar.handle_write_byte(b'a') == 1
        assert pbar.handle_write_byte(b'\r') is None
        assert pbar.handle_write_byte(b'b\n') == 1

# Generated at 2022-06-22 04:56:42.416750
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for constructor of class _TqdmLoggingHandler
    """
    pass

# Generated at 2022-06-22 04:56:45.630339
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert isinstance(handler.stream, sys.stdout)


# Generated at 2022-06-22 04:56:53.752806
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm as std_tqdm

    LOG = logging.getLogger(__name__)
    LOG.info("First log msg")
    try:
        for i in std_tqdm(range(int(5))):
            LOG.info("%d log msg", i)
        raise AttributeError("Testing logging_redirect_tqdm()")
    except AttributeError:
        if i > 1:  # pragma: no cover
            raise  # pragma: no cover



# Generated at 2022-06-22 04:56:56.127812
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 04:57:03.691287
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=2) as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info("test info")
        LOG.error("test error")
        pbar.set_description("test set_description")
        pbar.update(1)

    with tqdm_logging_redirect() as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info("test info")
        LOG.error("test error")
        pbar.set_description("test set_description")
        pbar.update(1)

# Generated at 2022-06-22 04:57:16.010873
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import unittest
    import sys

    from ..std import tqdm

    from . import _TqdmLoggingHandler
    from . import _is_console_logging_handler
    from . import _get_first_found_console_logging_handler

    class TestTqdmLoggingHandler(unittest.TestCase):
        def test_is_console_logging_handler(self):
            handler = logging.StreamHandler()
            # Two tests to ensure that the handler is not considered as a console
            # logging handler
            handler.stream = sys.stdout
            self.assertFalse(_is_console_logging_handler(handler))
            handler.stream = sys.stderr
            self.assertFalse(_is_console_logging_handler(handler))


# Generated at 2022-06-22 04:57:22.328271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with tqdm_logging_redirect(total=3):
        logging.info('info')
        logging.debug('debug')
        logging.warning('warning')


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:57:29.887554
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class is std_tqdm


# Generated at 2022-06-22 04:57:36.373792
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger(__name__)]
    with logging_redirect_tqdm(loggers=loggers):
        for logger in loggers:
            for i in range(4):
                logger.info('info message #%d' % i)
                logger.warning('warning message #%d' % i)
                logger.debug('debug message #%d' % i)



# Generated at 2022-06-22 04:57:47.917734
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TqdmMockup(std_tqdm):
        def __init__(self, file=None):
            super(TqdmMockup, self).__init__(desc="Test", file=file)
            self.write_args = []  # type: List[str]

        def write(self, s, file=None, end="\n", nolock=False):
            assert file is self.file
            self.write_args.append(s)

    tqdm_mockup = TqdmMockup(file=sys.stderr)
    handler = _TqdmLoggingHandler(tqdm_mockup)
    handler.setFormatter(logging.Formatter("{message}", style="{"))

# Generated at 2022-06-22 04:57:51.161679
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    _TqdmLoggingHandler()
    unittest.TestCase().assertTrue('tqdm_class' in locals().keys())

# Generated at 2022-06-22 04:58:03.202215
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    This is unit test for _TqdmLoggingHandler class
    """
    from . import _TqdmLoggingHandler
    from .formatters import TqdmLoggingFormatter

    test_message = "Test message"
    test_record = logging.LogRecord("TEST_LOGGER", logging.INFO, pathname="",
                                    lineno=123, msg=test_message, args=None,
                                    exc_info=None)
    test_fmt = "[{levelname}] {msg}"
    test_tqdm_logging_handler = _TqdmLoggingHandler(logging.Formatter(fmt=test_fmt))
    test_tqdm_logging_handler.handle(test_record)
    test_tqdm_logging_formatter = TqdmLoggingFormatter

# Generated at 2022-06-22 04:58:15.109306
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .external_write import _close_fd_and_unlink
    from tqdm import trange
    import logging
    import os
    import tempfile

    LOG = logging.getLogger(__name__)

    with tempfile.TemporaryDirectory(prefix="tqdm-") as tmpdir:
        tmpfile = os.path.join(tmpdir, "logging.log")
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        fh = logging.FileHandler(tmpfile)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

# Generated at 2022-06-22 04:58:19.371714
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_handler = _TqdmLoggingHandler(tqdm_class = std_tqdm)
    assert test_handler.tqdm_class == std_tqdm


# Generated at 2022-06-22 04:58:21.162166
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert(type(handler) == _TqdmLoggingHandler)

# Generated at 2022-06-22 04:58:22.883135
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    LOG = logging.getLogger(__name__)
    LOG.setLevel('DEBUG')
    # Add a

# Generated at 2022-06-22 04:58:24.077245
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    print(_TqdmLoggingHandler())

# Generated at 2022-06-22 04:58:38.909398
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # set up tqdm for test
    ptqdm = logging_redirect_tqdm()
    ptqdm.__enter__()
    trange(1)
    ptqdm.__exit__(None, None, None)

    # test logging_redirect_tqdm
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:58:49.893396
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import unittest
    logger = logging.getLogger("tqdm")
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter('%(message)s'))
    tqdm_handler.stream = sys.stdout
    logger.handlers = [tqdm_handler]
    logger.debug("test_debug")
    logger.info("test_info")
    logger.warning("test_warning")
    logger.error("test_error")
    logger.critical("test_critical")
    with captured_output() as (out, err):
        logger.debug("test_debug")
        logger.info("test_info")
        logger.warning("test_warning")
        logger.error("test_error")

# Generated at 2022-06-22 04:58:58.251738
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:59:06.376495
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _TqdmMock(object):
        def __init__(self):
            self.data = []

        def write(self, msg, file=None):
            self.data.append(msg.strip())

    record = logging.Logger('test').makeRecord(
        'test', logging.INFO, '/', None, 'test', (), None, 'test')
    tqdm_mock = _TqdmMock()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=_TqdmMock)
    tqdm_handler.emit(record)
    assert tqdm_mock.data[0] == 'test'
    tqdm_mock.data = []

# Generated at 2022-06-22 04:59:18.342918
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    log = logging.getLogger(__name__)

    with open('/dev/null', 'w') as dn:
        with logging_redirect_tqdm(loggers=[log], tqdm_class=tqdm):
            log.info("A message")
            with tqdm(leave=True, file=sys.stdout) as pbar:
                pbar.update(1)
            print("B")
            log.info("C")
        with tqdm(leave=True, file=dn) as pbar:
            pbar.update(1)
        log.info("D")

    with logging_redirect_tqdm(tqdm_class=tqdm):
        log.info("E message")

# Generated at 2022-06-22 04:59:28.719097
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import pandas as pd
    except ImportError:
        pass
    else:
        with tqdm_logging_redirect(
            loggers=[pd.core.common.logger],
            tqdm_class=type(std_tqdm()),
            total=None,
            desc='Test',
            file=sys.stderr
        ) as pbar:
            p = pd.read_csv('tests/test_tqdm.py')
            p.describe()
        assert str(pbar) == 'Test: 100%|██████████| 4/4 [00:00<00:00, 51.12it/s]'

# Generated at 2022-06-22 04:59:33.044965
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    msg = "this is a test"
    # Create a test handler object
    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout
    # Call the method of interest
    handler.emit(msg)
    # Check that the right thing happened (method write should have been called)
    assert(std_tqdm.write.called)

# Generated at 2022-06-22 04:59:40.806828
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Test TqdmLoggingHandler.emit"""
    log_record = logging.makeLogRecord({'msg': 'message', 'levelno': 1})
    stream = sys.stdout
    tqdm_log_handler = _TqdmLoggingHandler()
    tqdm_log_handler.emit(log_record)
    tqdm_log_handler.stream = stream
    tqdm_log_handler.emit(log_record)



# Generated at 2022-06-22 04:59:43.456121
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-22 04:59:49.867802
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create temporary file to store log output
    import tempfile
    import os
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close() # Don't need the file open at this time

    # Create logging handler which overrides write to go to the temporary file
    from io import StringIO
    import sys
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.stream = sys.stdout = StringIO()
    handler.format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s').format
    handler.emit(logging.LogRecord('test', logging.INFO, None, 0, 'TEST_LOGGING', (), None))
    sys.stdout.seek(0) #

# Generated at 2022-06-22 04:59:59.371308
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit tests:

    - expect the correct tqdm args to be passed through to tqdm.
    - expect a console logging handler to be added to the default logger.
    - expect no logging handlers to be added to a non-default logger.
    - expect logging handlers to be removed and restored correctly.

    These tests are weak, as they do not exercise the actual functionality.
    For example, the handler would write to tqdm.std.tqdm, not to the pbar
    that was yielded from tqdm_logging_redirect().  And the pbar would update
    if it could receive the logging statements, but currently it does not.
    """
    import logging
    from tqdm import tqdm as std_tqdm

    # Ensure that the `logging` module is up and running


# Generated at 2022-06-22 05:00:05.896711
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm as std_tqdm
    # output
    out = StringIO()
    tqdm_class = std_tqdm
    tqdm_class.write = out.write
    tqdm_class.flush = out.flush
    # dummy logger
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger('tqdm.tests')
    with logging_redirect_tqdm(
        loggers=[log],
        tqdm_class=tqdm_class,
    ):
        log.info('message')
        log.info('another message')
    # check string is correct
    assert out.getvalue() == 'message\n'
    # check there is still some logging
    log.info('test')

# Generated at 2022-06-22 05:00:08.015079
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler

# Generated at 2022-06-22 05:00:15.364730
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for `logging_redirect_tqdm()`
    """
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            total=9,
            loggers=[logging.getLogger(__name__)],
            tqdm_class=std_tqdm) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-22 05:00:18.188821
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    #__init__
    assert _TqdmLoggingHandler(std_tqdm)


# Generated at 2022-06-22 05:00:28.313506
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    def test_logging(logger):
        logger.debug("debug message")
        logger.info("info message")
        logger.warn("warn message")
        logger.error("error message")
        logger.critical("critical message")
        logger.exception("exception message")
        try:
            raise Exception("exception message")
        except:  # noqa pylint: disable=bare-except
            logger.exception("exception message")

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    logger.handlers = [tqdm_handler]
    test_logging(logger)
    logger.removeHandler(tqdm_handler)



# Generated at 2022-06-22 05:00:30.580065
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    t = _TqdmLoggingHandler()
    assert isinstance(t, logging.StreamHandler)
    assert t.stream == sys.stderr


# Generated at 2022-06-22 05:00:37.239181
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[LOG], total=1) as pbar:
        LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update(1)
        assert(pbar.n == 1)
        pbar.close()
        assert(pbar.n == 0)

# Generated at 2022-06-22 05:00:41.662260
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)
    assert tqdm_logging_handler.tqdm_class == std_tqdm


# Generated at 2022-06-22 05:00:48.850104
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm as stdtqdm  # pylint: disable=wrong-import-position
    from .tqdm_test_cases import tqdm_test_cases

    # Dummy tests
    for kwargs in tqdm_test_cases():
        with tqdm_logging_redirect(**kwargs):
            pass

    tqdm_class = stdtqdm.tqdm
    with tqdm_logging_redirect(
            {'desc': 'testing logging_redirect_tqdm'},
            tqdm_class=tqdm_class) as pbar:
        assert pbar._instances  # pylint: disable=protected-access
        assert len(pbar._instances) == 1  # pylint: disable=protected-access


# Generated at 2022-06-22 05:01:03.574428
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from six import StringIO
    from logbook.base import Logbook
    from logbook.handlers import StreamHandler

    # create a logbook for testing
    logbook = Logbook()

    # this is the text we want to display
    msg = "Message for testing"

    # create a logger for testing
    logger = logbook.get_logger('Logger_test')

    # capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # instantiate the class under test
    handler = _TqdmLoggingHandler()

    # get the log-level of the logger
    lvl = logger.level

    # create a logbook record
    record = logger.makeRecord(
        "Logger_test", lvl, "src_filename", 0, msg, None, None)

# Generated at 2022-06-22 05:01:15.413386
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    import logging

    if '--logging-interop' in sys.argv:
        # Unit test
        # python -m tqdm.contrib.logging --logging-interop
        log = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for i in range(10):
                log.info('Test message: %s', i)
    elif '--logging-interop-import' in sys.argv:
        # Unit test
        # python -m tqdm.contrib.logging --logging-interop-import
        from .logging import logging_redirect_tqdm

        log = logging.getLogger(__name__)

# Generated at 2022-06-22 05:01:18.560076
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
  handler = _TqdmLoggingHandler(logging.StreamHandler)
  assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-22 05:01:28.101911
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import sys
    import tempfile
    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.warn('a')
    logger.warning('b')
    logger.error('c')

    with tempfile.TemporaryFile('w+') as output_file:
        handler = _TqdmLoggingHandler(file=output_file)
        logger.addHandler(handler)
        logger.warn('a')
        logger.warning('b')
        logger.error('c')

        handler.flush()
        output_file.flush()
        output_file.seek(0)
        assert (output_file.read() == 'c\n')



# Generated at 2022-06-22 05:01:33.856409
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    log = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    stream = BytesIO()
    handler.stream = stream
    log.handlers = [handler]
    log.info("test logging")
    assert stream.getvalue() == b"test logging\n"

# Generated at 2022-06-22 05:01:38.176926
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        name='level',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg='This is a test case',
        args=None,
        exc_info=None
    )
    tqdm_handler.emit(record)



# Generated at 2022-06-22 05:01:41.111375
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger('test_logging_redirect_tqdm')
    with logging_redirect_tqdm():
        log.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:01:48.408267
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    from .tests_tqdm._utils import _range

    class MyTqdm(std_tqdm):
        def write(self, msg, file=None):
            self.tqdm_write_called = True

    def mylog(msg):
        logger.info(msg)

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = _TqdmLoggingHandler(MyTqdm)
    logger.addHandler(handler)
    try:
        with MyTqdm() as mypbar:
            for i in _range(10):
                mypbar.update()
                mylog('logging should be redirected to tqdm.write()')
        assert mypbar.tqdm_write_called
    finally:
        logger

# Generated at 2022-06-22 05:01:51.338011
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger('foo')]
    with logging_redirect_tqdm(loggers=loggers):
        logging.warning('hi')

# Generated at 2022-06-22 05:01:58.859907
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            # Logging redirected at this point
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:02:14.684924
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: (...) -> None

    import logging
    import sys
    import io

    class _TestTqdmClass(std_tqdm):
        def __init__(self):
            # type: (...) -> None
            self._buffer = []
            self._empty = True
            self._file = io.StringIO()


# Generated at 2022-06-22 05:02:21.240229
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # patch the stdout to check if everything is printed in tqdm
    with patch('sys.stdout', new=StringIO()) as fake_stdout:
        logging.basicConfig(level=logging.INFO)

        LOG = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    # check if redirected to tqdm

# Generated at 2022-06-22 05:02:31.379867
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    from .tqdm import tqdm
    from .std import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    sio = io.StringIO()
    logger.addHandler(logging.StreamHandler(sio))
    with tqdm_logging_redirect(
            ['item {:d}'.format(i) for i in range(3)],
            ascii=True,
            desc='test_tqdm_log_redirect',
            logger=logger,
            total=3) as pbar:
        logger.debug('debug')
        logger.info('info')
        logger.error('error')
        pbar.update()
        logger.warning('warning')
        pbar.update()

# Generated at 2022-06-22 05:02:39.142902
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9), ascii=True):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:02:45.881154
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)
    assert handler.tqdm_class is std_tqdm


if __name__ == '__main__':
    # python -m tqdm.contrib.logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    print("print()")
    with logging_redirect_tqdm():
        LOG.debug("debug")
        LOG.info("info")
        LOG.warning("warning")
        LOG.error("error")
        print("print()")
    print("print()")

    print("\ntqdm():")

# Generated at 2022-06-22 05:02:56.877935
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import uuid
    import logging
    import re
    import tqdm

    OUTPUT_LOG_FILENAME = 'logging_redirect_tqdm-{0}.log'.format(str(uuid.uuid4()))
    # print(OUTPUT_LOG_FILENAME)

    # create logger
    logger = logging.getLogger("logging_redirect_tqdm")
    logger.setLevel(logging.INFO)

    # create console handler and set level to info
    tqdm_handler = _TqdmLoggingHandler()
    # tqdm_handler.setLevel(logging.INFO)
    # create file handler and set level to debug
    file_handler = logging.FileHandler(OUTPUT_LOG_FILENAME)
    # file_handler.setLevel(logging.DEBUG

# Generated at 2022-06-22 05:03:03.510876
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from contextlib import contextmanager
    from io import StringIO
    from tqdm import trange

    from tqdm.contrib.logging import logging_redirect_tqdm

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-22 05:03:11.193722
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from os import linesep
    from unittest import TestCase, mock

    from ..tqdm import trange

    class _TqdmLoggingHandlerTestCase(TestCase):
        def setUp(self):
            self.log_handler = _TqdmLoggingHandler()
            self.log_record = logging.LogRecord(
                'TEST', logging.DEBUG, 'pathname', 0, '', None, None)

        def assertWrite(self, msg, file=sys.stderr):
            with mock.patch.object(self.log_handler, 'stream') as mock_stream:
                self.log_handler.write = mock.Mock()
                mock_stream.__enter__.return_value = file
                self.log_handler.emit(self.log_record)
                mock_stream.__enter__

# Generated at 2022-06-22 05:03:20.386394
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test function logging_redirect_tqdm."""
    from . import tqdm

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    logger = logging.getLogger()
    with logging_redirect_tqdm():
        for _ in tqdm(range(3)):
            logging.debug("Test message")
    for handler in logger.handlers:
        assert handler.stream != sys.stderr, "Logging still going to stderr!"


# Generated at 2022-06-22 05:03:27.792212
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    try:
        with tqdm_logging_redirect(total=10):
            assert True
        assert True
    except Exception as e:
        assert False, e

    try:
        with tqdm_logging_redirect(total=10, tqdm_class=trange):
            assert True
        assert True
    except Exception as e:
        assert False, e

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-22 05:03:36.085404
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    handler.emit(1)

# Generated at 2022-06-22 05:03:48.073032
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import logging
    import io
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    class Tests(unittest.TestCase):
        def test(self):
            sio = io.StringIO()

            with tqdm_logging_redirect(
                    file=sio,
                    leave=True,
                    miniters=1).__enter__() as pbar:
                for i in trange(9, file=sys.stdout, leave=False):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            #

# Generated at 2022-06-22 05:03:58.935607
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import io
    from io import StringIO
    import logging
    import unittest
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm import trange

    # Default unit test class in Python3.3+ has an assertLogs method but
    # not in older versions.
    class TestCase(unittest.TestCase):
        pass

    try:
        TestCase.assertLogs
    except AttributeError:
        TestCase.assertLogs = unittest.TestCase._AssertLogsContext

    # Set up simple logger.
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    logging.basicConfig(format='%(message)s')


# Generated at 2022-06-22 05:04:07.997520
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.getLogger(__name__).setLevel(logging.DEBUG)

    from io import StringIO

    output = StringIO()

    handler = _TqdmLoggingHandler(file=output)

    logger = logging.getLogger(__name__)
    logger.addHandler(handler)

    logger.debug('test debug message')
    logger.info('test info message')
    logger.warning('test warning message')
    logger.error('test error message')
    logger.critical('test critical message')

    assert output.getvalue() == ('test debug message\n'
                                 'test info message\n'
                                 'test warning message\n'
                                 'test error message\n'
                                 'test critical message\n')

    output.close()



# Generated at 2022-06-22 05:04:18.073802
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import sys

    class _TqdmLoggingHandlerFail(logging.StreamHandler):
        def __init__(self, tqdm_class=tqdm):
            super(_TqdmLoggingHandlerFail, self).__init__()
            self.tqdm_class = tqdm_class

        def emit(self, record):
            try:
                raise RuntimeError("mock error")
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)


# Generated at 2022-06-22 05:04:20.253585
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import trange, tqdm
    with trange(10) as pbar:
        handler = _TqdmLoggingHandler(tqdm)
        assert handler.tqdm_class == tqdm

# Generated at 2022-06-22 05:04:25.388623
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    from io import StringIO

    from tqdm.std.logging import _TqdmLoggingHandler
    from tqdm._utils import _environ_cols_wrapper

    orig_stderr = sys.stderr
    try:
        sys.stderr = StringIO()

        handler = _TqdmLoggingHandler()
        handler.flush = lambda: None
        log = logging.Logger("test")
        log.addHandler(handler)
        log.warning("test")
        assert sys.stderr.getvalue() == "WARNING:test:\n"
    finally:
        sys.stderr = orig_stderr



# Generated at 2022-06-22 05:04:29.445654
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(unit='B', unit_scale=True, miniters=1,
                               desc="test"):
        for i in range(10):
            logging.info("test")


# Generated at 2022-06-22 05:04:35.968382
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import logging
    from tests_tqdm import with_setup, pretest, posttest, _range, _dir, \
        _multiprocessing, _raises, _test_closed
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    def test_progress(tqdm_class, loggers):
        with tqdm_logging_redirect(loggers=loggers, tqdm_class=tqdm_class) as pbar:
            for i in _range(9):
                pbar.update()
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 05:04:43.998451
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info('hello')

    # intercept output
    import StringIO
    ilog = StringIO.StringIO()
    tqdm_class = type(tqdm)

    # check if _TqdmLoggingHandler works as expected
    handler = _TqdmLoggingHandler(tqdm_class)
    handler.stream = ilog
    handler.emit('hello')
    assert ilog.getvalue() == 'hello\n'

# Generated at 2022-06-22 05:04:58.048092
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(loggers=[logging.root]):
        logging.info('Log line')



# Generated at 2022-06-22 05:05:08.773646
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Unit test for function tqdm_logging_redirect"""
    from .tqdm import tqdm

    logging.basicConfig()
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        for i in range(3):
            pbar.update(1)
            LOG.debug("debug message")
            LOG.info("info message")
            LOG.warning("warning message")
            LOG.error("error message")
            LOG.critical("critical message")


# Generated at 2022-06-22 05:05:20.180553
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import logging
    from tqdm import trange
    from io import StringIO

    class LoggingRedirectTest(unittest.TestCase):
        """
        Checks that the logging redirection to tqdm outputs the appropriate
        messages.
        """
        def setUp(self):
            try:
                from StringIO import StringIO  # Python 2
            except ImportError:
                from io import StringIO  # Python 3
            try:
                from unittest.mock import patch
            except ImportError:
                from mock import patch
            self.stream = StringIO()
            self.handler = logging.StreamHandler(self.stream)
            logging.root.addHandler(self.handler)

# Generated at 2022-06-22 05:05:30.009129
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.models import TqdmType
    from .tests_tqdm import pretest_posttest

    for t in (TqdmType.auto, TqdmType.default):
        # Test if default root logger is redirected
        with pretest_posttest(tqdm_class=t) as (pre, post):
            with logging_redirect_tqdm():
                logging.warning("test")
        pre()
        post("test_logging_redirect_tqdm")

        # Test if given logger is redirected
        logger = logging.getLogger("test_logger")
        logger.setLevel(logging.INFO)

# Generated at 2022-06-22 05:05:41.705227
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler, _get_first_found_console_logging_handler
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.DEBUG)

    assert (
        [
            isinstance(x, _TqdmLoggingHandler)
            for x in logging.root.handlers
        ] == [False])
    assert (_get_first_found_console_logging_handler(logging.root.handlers)
            is not None)


# Generated at 2022-06-22 05:05:49.360827
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    loggers = [logging.getLogger('1'), logging.getLogger('2')]
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        assert pbar.__class__ == std_tqdm
        loggers[0].info('test 0')
        loggers[1].info('test 1')
        assert pbar.n == 2
        loggers[0].info('test 2')
        loggers[1].info('test 3')
        assert pbar.n == 4

# Generated at 2022-06-22 05:05:54.273215
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc='desc') as pbar:
        LOG.info('redirected')
        LOG.info('redirected')
        pbar.update(1)
    pbar.write('inside tqdm.write()')


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 05:06:05.466728
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile
    import io
    import logging

    def _tqdm_class_write(msg, file=None):
        if file is None:
            file = sys.stderr
        msg1 = 'tqdm.write: ' + msg
        file.write(msg1)

    tqdm_logging_handler = _TqdmLoggingHandler(_tqdm_class_write)
    log_msg = None  # type: str

    def _emit_func(msg):
        log_msg = msg
        with tempfile.TemporaryFile() as tmp_file:
            tqdm_logging_handler.stream = tmp_file
            tqdm_logging_handler.emit(msg)
            tmp_file.seek(0)
            return tmp_file.read()


# Generated at 2022-06-22 05:06:09.768405
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    # test the constructor
    with tqdm_logging_redirect(tqdm_class=std_tqdm):
        logging.root.info('This message should be printed on tqdm terminal')
        logging.root.info('This is a test of __init__ of class _TqdmLoggingHandler')

