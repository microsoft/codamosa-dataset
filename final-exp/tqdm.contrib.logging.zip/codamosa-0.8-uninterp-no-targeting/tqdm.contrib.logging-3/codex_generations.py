

# Generated at 2022-06-22 04:56:19.555466
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.makeLogRecord({'msg': 'Test'})
    handler.emit(record)

# Generated at 2022-06-22 04:56:29.638083
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    root_logger = logging.getLogger()
    def _test_emit(pbar, level, msg, expected):
        print("test name: " + _test_emit.__name__ + ", message: " + msg + "; level: " + str(level))
        with logging_redirect_tqdm(loggers=[root_logger]):
            root_logger.log(level, msg)
        assert pbar.get_postfix() == expected
    _test_emit.__name__ = "test__TqdmLoggingHandler_emit"
    import subprocess
    import os
    import sys
    import time
    import tempfile

    if __name__ == '__main__':
        temp_dir = tempfile.mkdtemp(prefix='tmp.tqdm_logging_test.')

# Generated at 2022-06-22 04:56:30.980199
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:56:37.919441
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Test for method emit of class _TqdmLoggingHandler.
    """
    check = 'Message à l\'écran.'
    log_record = logging.LogRecord('name', logging.DEBUG, 'pathname',
                                   10, check, None, None)
    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout
    handler.emit(log_record)
    assert check == sys.stdout.getvalue().strip()

# Generated at 2022-06-22 04:56:48.463984
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)
    logging.info('foo')
    tqdm_handler = _TqdmLoggingHandler()
    logging.info('bar')

# Generated at 2022-06-22 04:56:55.802257
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    LOG=logging.getLogger()
    LOG.setLevel(logging.INFO)
    LOG.info("Hello")
    with logging_redirect_tqdm(tqdm_class=tqdm.tqdm):
        LOG.info("This is redirected to tqdm.write")
    LOG.info("This is not redirected")

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:57:02.084036
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(leave=True):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 04:57:06.581428
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test_handler = _TqdmLoggingHandler()
    assert isinstance(test_handler, logging.StreamHandler)
    assert test_handler.stream in [sys.stdout, sys.stderr]

# Generated at 2022-06-22 04:57:16.665796
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    LOG = logging.getLogger('test_tqdm')

    for _ in range(1):
        with tqdm_logging_redirect(
                "test",
                unit="B",
                unit_scale=True,
                desc="test",
                loggers=[LOG]) as pbar:
            for i in range(100):
                LOG.info("test")
            pbar.update(100)

        with tqdm(
                "test",
                unit="B",
                unit_scale=True,
                desc="test",
                leave=False) as pbar:
            for i in range(100):
                LOG.info("test")
            pbar.update(100)

# Generated at 2022-06-22 04:57:28.462170
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    
    # In case tqdm is not installed
    try:
        import tqdm
        tqdm_installed = True
    except ImportError:
        tqdm_installed = False

    # Pass tqdm.tqdm as tqdm_class argument
    if tqdm_installed:
        tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
        assert (tqdm_handler.tqdm_class == tqdm.tqdm)

    # Pass None as tqdm_class argument
    tqdm_handler = _TqdmLoggingHandler(None)
    assert (tqdm_handler.tqdm_class is std_tqdm)


# Generated at 2022-06-22 04:57:39.076872
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    # Remember original stdout
    original_stdout = sys.stdout
    # StringIO object
    import io
    s = io.StringIO()
    # replace stdout
    sys.stdout = s
    logging.warning("spam")
    sys.stdout = original_stdout
    output = s.getvalue()
    assert output.count("spam") == 2

# Generated at 2022-06-22 04:57:40.717634
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm

# Generated at 2022-06-22 04:57:42.500748
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with logging_redirect_tqdm():
        LOG = logging.getLogger(__name__)
        LOG.info("This is a test of our unit test")


# Generated at 2022-06-22 04:57:53.397691
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore
    try:
        import unittest.mock as mock  # type: ignore
    except ImportError:
        import mock

    with patch('tqdm.std.tqdm', new=mock.Mock()) as mock_tqdm:
        with tqdm_logging_redirect('testme') as pbar:
            assert isinstance(pbar, mock_tqdm.Mock)
            assert pbar.write.call_count == 0
            logging.info('Line1')
            logging.info('Line2')
        assert pbar.write.call_count == 2
        assert pbar.write.call_args_list

# Generated at 2022-06-22 04:58:01.352666
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    with tqdm.tqdm_logging_redirect(loggers=[LOG]):
        for i in tqdm.trange(10):
            if i == 9:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:58:05.485110
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    with tqdm_logging_redirect(total=9) as pbar:
        for i in pbar:
            if i == 4:
                logging.info("hello")

# Generated at 2022-06-22 04:58:12.319575
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("logging restored")


# Generated at 2022-06-22 04:58:20.192210
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(
            total=0,
            bar_format='{desc}: {percentage:3.0f}%|{bar}|',
            dynamic_ncols=True,
            desc='foo'
    ) as pbar:
        logging.info('{foo}'.format(foo='bar'))
        logging.info(pbar.get_description())
        assert pbar.get_description() == 'foo: 100%|██████████████████████████████████████████████████|'

# Generated at 2022-06-22 04:58:21.785630
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler()
    pass

# Generated at 2022-06-22 04:58:26.983148
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert isinstance(tqdm_handler.stream, logging.StreamHandler)
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}


# Generated at 2022-06-22 04:58:43.956858
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from StringIO import StringIO  # FOR PY2
    except:
        from io import StringIO
    tqdm_class = std_tqdm
    my_logger = logging.getLogger('My Logger')
    my_logger.setLevel(logging.INFO)
    log_handler = logging.StreamHandler(StringIO())
    log_handler.setLevel(logging.INFO)
    my_logger.addHandler(log_handler)
    my_logger.info('Unredirected logging output')
    with logging_redirect_tqdm(loggers=[my_logger], tqdm_class=tqdm_class):
        my_logger.info('Redirected logging output')
    my_logger.info('Unredirected logging output')


# Generated at 2022-06-22 04:58:54.538133
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    import logging
    loggers = [logging.getLogger()]
    format_str = "%(asctime)s %(message)s"
    logging.basicConfig(format=format_str, level=logging.INFO)
    try:
        with tqdm_logging_redirect(logging.INFO, loggers=loggers) as pbar:
            assert isinstance(pbar, std_tqdm)
            assert any("Console logging redirected to tqdm.write()" in t
                       for t in pbar.format_dict['desc'].split("\r")), \
                "Log redirected to pbar"
    except BaseException as e:
        raise e

# Generated at 2022-06-22 04:59:00.085710
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .logging_redirect_tqdm import _TqdmLoggingHandler

    class LogRecord(object):
        def __init__(self, msg):
            self.msg = msg

    logging_handler = _TqdmLoggingHandler()
    msg = "test"
    record = LogRecord(msg)
    logging_handler.emit(record)

# Generated at 2022-06-22 04:59:04.488971
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    a = _TqdmLoggingHandler()
    assert a.stream is sys.stderr
    assert a.formatter is not None

# Generated at 2022-06-22 04:59:11.020180
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    # Use "StringIO" (string-based in-memory file interface)
    # as a temporary sink for _TqdmLoggingHandler messages
    import io
    import tqdm  # under CI, tqdm/tqdm is not importable
    io_sink = io.StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = io_sink
    handler.emit(logging.LogRecord(
        name='tqdm_logging_test',
        level=logging.INFO,
        pathname=__file__,
        lineno=2,
        msg='hello world!',
        args=None,
        exc_info=None
    ))

# Generated at 2022-06-22 04:59:20.212501
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test tqdm_logging_redirect().

    Unit test for function tqdm_logging_redirect.

    """

    class FakeLogger(object):
        pass

    class FakeLogging(object):
        Logger = FakeLogger
        root = FakeLogger()

    class FakeTqdm(object):
        def __init__(self, iterable, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            pass

        def __call__(self, iterable, *args, **kwargs):
            return FakeTqdm(iterable)

    class FakeLoggingRedirect(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 04:59:30.752781
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    # import logging
    from collections import namedtuple
    from contextlib import redirect_stderr
    from io import StringIO
    import re

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    log_str = StringIO()
    with redirect_stderr(log_str), tqdm_logging_redirect():
        for i in tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    output = log_str.getvalue().split('\n')

# Generated at 2022-06-22 04:59:42.525096
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import tqdm

    def capture_logging(logging_function, logging_level) -> str:
        output = tqdm.tqdm_pandas(sys.stdout, disable=True)
        # Set up logging in the `with` block and catch any logs sent to
        # stderr via the `with` block exit's pop method.
        with tqdm.tqdm_logging_redirect(pbar=output), \
             tqdm.capt_stderr(sys.stderr) as captured:
            logging_function()

        for line in captured:
            if logging_level in line:
                return line

    def run_logging_test(logging_level):
        logger = tqdm.std.logging.getLogger(__name__)

# Generated at 2022-06-22 04:59:49.139911
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    import tqdm.std
    buf = StringIO()
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm.std)
    tqdm_logging_handler.stream = buf
    tqdm_logging_handler.setFormatter(
        logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(message)s'))
    logging.getLogger().handlers = [tqdm_logging_handler]
    logging.warning('Test logging_redirect_tqdm')
    assert buf.getvalue().strip() == 'WARNING:root:Test logging_redirect_tqdm'

# Generated at 2022-06-22 04:59:59.123518
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class FakeTqdm(object):
        def __init__(self):
            self.output = []

        def write(self, message, file=None):
            self.output.append(message)

    fake_tqdm = FakeTqdm()

    log_msg = logging.getLogger()
    log_msg.setLevel(logging.INFO)
    tqdm_log_handler = _TqdmLoggingHandler(tqdm_class=fake_tqdm)
    log_msg.addHandler(tqdm_log_handler)
    log_msg.info("test")
    assert fake_tqdm.output == ["test\n"]

# Generated at 2022-06-22 05:00:09.253855
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.tqdm_class is std_tqdm



# Generated at 2022-06-22 05:00:17.837518
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    assert len(sys.stderr.getvalue()) == 0
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.debug("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:25.545905
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    test_msg = 'test_msg'
    test_record = logging.LogRecord(
        name='<module>',
        level=logging.DEBUG,
        pathname='tqdm/contrib/logging.py',
        lineno=42,
        msg=test_msg,
        args=None,
        exc_info=None)

    # Test whether _TqdmLoggingHandler.emit does not raise
    # Exception when calling tqdm.write()
    handler.emit(record=test_record)



# Generated at 2022-06-22 05:00:30.926862
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s - %(message)s')

    # tqdm logger already exists, no warning
    with logging_redirect_tqdm([logging.getLogger('tqdm')]) as _:
        logging.getLogger('tqdm').info('test')

# Generated at 2022-06-22 05:00:42.299405
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Create a handler for this logger
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)

    # Create a formatter and add it to the handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Log some messages
    logger.info('Test start...')

# Generated at 2022-06-22 05:00:53.250290
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test to verify the redirection of logging to tqdm.write()"""
    import logging  # Logging comes after tqdm (otherwise it gets redirected as well)
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm(loggers=[LOG]):
        for i in trange(6):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:00:55.309392
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import _test_tqdm_logging_redirect
    _test_tqdm_logging_redirect()

# Generated at 2022-06-22 05:01:07.073667
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    try:  # Python 2.x
        from StringIO import StringIO
    except ImportError:  # Python 3.x
        from io import StringIO

    # This unit test is intended to check if logging_redirect_tqdm works correctly.
    # It's divided into 2 sections:
    # 1. Verify that the context manager intercepts the messages properly.
    # 2. Verify that the context manager restores the logging handlers.
    # Note that this unit test uses the stdout as the StreamHandler for the logger,
    # since it's the one usually used for the root logger and it's the one used by
    # tqdm.
    # If a logger has a FileHandler, the messages will be logged in the file.
    # If a logger has a StreamHandler and the stream is different from sys.stdout,
    #

# Generated at 2022-06-22 05:01:15.269170
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MyLogger:
        def __init__(self):
            self.msgs = []

        def write(self, msg):
            self.msgs.append(msg)

    logger = MyLogger()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = logger  # type: ignore

    handler.emit(logging.LogRecord(
        'name', logging.INFO, 'filename', 1, 'msg', None, None))
    assert logger.msgs == [handler.format(logging.LogRecord(
        'name', logging.INFO, 'filename', 1, 'msg', None, None))]

# Generated at 2022-06-22 05:01:26.195119
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test whether the defined function works
    import logging
    import tqdm
    try:
        with tqdm_logging_redirect():
            logging.info("hello world")
    except Exception as e:
        raise Exception("Failed: {}".format(e))

    # Test whether the defined function works under input arguments
    try:
        with tqdm_logging_redirect(ncols=70):
            logging.info("hello world")
    except Exception as e:
        raise Exception("Failed: {}".format(e))

    # Test whether the defined function works under input arguments

# Generated at 2022-06-22 05:01:38.917263
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert isinstance(h, _TqdmLoggingHandler)


# Generated at 2022-06-22 05:01:44.495902
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib import logger

    logger.basicConfig(level=logger.INFO)
    with tqdm_logging_redirect(
        total=9, desc="test", disable=False, unit="it", mininterval=0, smoothing=0,
        bar_format="{l_bar}", logger=logger
    ) as pbar:
        for i in range(9):
            if i == 4:
                # logging redirected to `tqdm.write()`
                logger.info("console logging redirected to `tqdm.write()`")
        assert pbar.total == 9

# Generated at 2022-06-22 05:01:49.968171
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    import logging
    import tqdm

    class Silent(object):
        """
        A no-op write function (that doesn't print anything)
        """
        def write(self, x):
            pass

    test_out = Silent()
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler(test_out))

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logger.info('message')
    assert sys.stdout.getvalue() == 'message\n'
    sys.stdout = Silent()

    with logging_redirect_tqdm():
        logger.info('message')
    assert tqdm.tqdm.write.call_args[0][0] == 'message\n'

# Generated at 2022-06-22 05:02:00.963006
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    class TestHandler(_TqdmLoggingHandler):
        def __init__(self):
            super(TestHandler, self).__init__(tqdm_class=std_tqdm)
            self.lines = []

        def emit(self, record):
            self.lines.append(self.format(record))

    # test
    handler = TestHandler()  # type: ignore
    logger = logging.Logger(__name__)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

    assert handler.lines[0] == 'DEBUG:root:debug\n'
    assert handler.lines

# Generated at 2022-06-22 05:02:12.392462
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm
    import logging

    logging.basicConfig(level=logging.INFO, format='%(message)s')
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    with logging_redirect_tqdm(tqdm_class=tqdm):
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:02:16.871031
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_msg = "Test"
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.emit("Test")
    # Test if stream is written
    assert len(std_tqdm.queue) == 1
    # Test if it has only one message
    assert std_tqdm.queue[0] == test_msg

# Generated at 2022-06-22 05:02:29.524894
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from tqdm._utils import _environ_cols_wrapper
    from tqdm import tnrange
    from tqdm._utils import _term_move_up

    stream = BytesIO()
    _environ_cols_wrapper.cols = 80
    with tnrange(1) as pbar:
        original_pbar_fd = pbar.fd
        pbar.fd = stream
        handler = _TqdmLoggingHandler(tqdm_class=tnrange)
        handler.setFormatter(logging.Formatter("%(name)s - %(message)s"))
        handler.setLevel(logging.DEBUG)
        handler._buf = ""  # type: ignore

        logger = logging.getLogger(__name__)

# Generated at 2022-06-22 05:02:35.292222
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .testing import _TestDummySentinels

    def _():
        # type: () -> None
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        handler = _TestDummySentinels()
        logger.addHandler(handler)
        logging_redirect_tqdm()
        logger.info('spam')
        logger.info('eggs')
        return handler.buffer

    _buf1 = _()
    _buf2 = _()
    _buf3 = _()
    _buf4 = _()

    assert _buf1 == ['spam\n', 'eggs\n']
    assert _buf2 == _buf1
    assert _buf3 == _buf2
    assert _buf4 == _buf3

# Generated at 2022-06-22 05:02:36.775708
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    f = _TqdmLoggingHandler()
    assert f is not None


# Generated at 2022-06-22 05:02:42.933492
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:03:10.856781
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.root]

    # No redirection
    original_handlers_list = [logger.handlers for logger in loggers]
    assert original_handlers_list == [[]]

    # Redirect
    with logging_redirect_tqdm(loggers=loggers):
        assert [logger.handlers for logger in loggers] == [[_TqdmLoggingHandler]]

    # Restore
    assert [logger.handlers for logger in loggers] == original_handlers_list

    # Error handling
    # - TODO: messing with the logger is kinda dangerous... need to test it properly
    # - TODO: fix [logging.root] to [logging.root] + [logging.getLogger('tqdm')] (see #1018)
    # with pytest.raises(

# Generated at 2022-06-22 05:03:20.471895
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test tqdm_logging_redirect"""
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect() as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()

        # logging restored
        LOG.info("logging restored.")

# Generated at 2022-06-22 05:03:27.810274
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    from unittest import TestCase, main

    class CaptureTqdmHandling(TestCase):
        def setUp(self):
            self.handler = _TqdmLoggingHandler()
            self.record = logging.makeLogRecord({
                'msg': 'this is a test',
                'args': (),
                'levelno': logging.INFO,
            })

        def test_call(self):
            # now we need a patch to hook in to their write
            import io
            f = io.StringIO()
            self.handler.stream = f

            self.handler.emit(self.record)

            self.assertEqual(f.getvalue(), 'this is a test\n')

if __name__ == '__main__':  # pragma: no cover
    main()

# Generated at 2022-06-22 05:03:34.227805
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    test case 1:
    print(logging_redirect_tqdm) >>> logging_redirect_tqdm
    """
    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord('name','DEBUG','path','lineno','msg','args','exc_info',None)
    tqdm_handler.emit(record)
    assert tqdm_handler.format(record) == 'msg'


# Generated at 2022-06-22 05:03:36.299551
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert (
        _TqdmLoggingHandler(tqdm_class=std_tqdm)  # type: ignore
    )


# Generated at 2022-06-22 05:03:39.861193
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, _TqdmLoggingHandler)
    assert isinstance(handler.tqdm_class, type)
    assert handler.tqdm_class is std_tqdm

# Generated at 2022-06-22 05:03:51.063752
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdmLoggingHandler1 = _TqdmLoggingHandler()
    tqdmLoggingHandler2 = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    with std_tqdm.external_write_mode():
        tqdmLoggingHandler1.emit(logging.info("Started"))
        tqdmLoggingHandler1.emit(logging.error("Failed"))
        tqdmLoggingHandler1.emit(logging.warning("Warning"))
        tqdmLoggingHandler2.emit(logging.info("Started"))
        tqdmLoggingHandler2.emit(logging.error("Failed"))
        tqdmLoggingHandler2.emit(logging.warning("Warning"))
    return

# Generated at 2022-06-22 05:04:02.351759
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.root]
    # Test the context manager
    with logging_redirect_tqdm(loggers=loggers):
        LOG = logging.getLogger(__name__)
        for i in range(5):
            if i == 2:
                LOG.info("console logging redirected to `tqdm.write()`")
    # Test the context manager with a custom logger
    logger_test = logging.getLogger('test')
    logger_test.setLevel(logging.DEBUG)
    logger_test.addHandler(logging.StreamHandler())
    with logging_redirect_tqdm(loggers=[logger_test]):
        logger_test.info("This should not be printed on the console")
    # Test the context manager with a custom logger and a
    # custom console logging StreamHandler
   

# Generated at 2022-06-22 05:04:07.465258
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(tqdm_class=tqdm):
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:04:12.093923
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    output = b''.join(
        _TqdmLoggingHandler(tqdm_class=std_tqdm).emit(None) for _ in
        range(3))  # type: ignore[call-overload]
    assert output == b'None\nNone\nNone\n'



# Generated at 2022-06-22 05:05:06.401889
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import os
    import tempfile
    from tqdm import tqdm

    tmp_dir = tempfile.mkdtemp()
    filename = os.path.join(tmp_dir, 'logging_redirect_tqdm_test')

    def cleanup_log_file():
        # type: () -> None
        try:
            os.remove(filename)
        except FileNotFoundError:  # Windows
            pass

    cleanup_log_file()

    # Only make the file, don't write to it yet
    with tqdm_logging_redirect(loggers=[logging.root], desc='test_redir',
                               file=open(filename, 'w')) as pbar:
        pbar.update(5)
        logging.info('a')
       

# Generated at 2022-06-22 05:05:10.899545
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .std import tqdm
    from pytest import raises

    # Should raise an error if `tqdm` has no attribute `write`
    with raises(AttributeError):
        _TqdmLoggingHandler(tqdm_class=tqdm)

    # Should not raise an error if `tqdm` has attribute `write`
    assert _TqdmLoggingHandler(tqdm_class=logging_redirect_tqdm.std_tqdm)

# Generated at 2022-06-22 05:05:13.613291
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-22 05:05:22.564893
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    if __file__.endswith('setup.py'):  # pragma: no cover
        # Avoid `Exception: Cannot perform relative import` on `setup.py test`
        return
    from . import test_docstrings
    from .test_docstrings import get_tqdm_class
    _tqdm = get_tqdm_class()  # type: tqdm
    test_docstrings.test_docstrings(__name__, globals(),
                                    exclude_closure=['test_logging_redirect_tqdm'])
    loggers = [logging.getLogger()]
    test_logger = logging.getLogger('test_logger')

# Generated at 2022-06-22 05:05:30.010282
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import time
    import logging
    from tqdm import trange

    logging.getLogger().handlers = []
    with tqdm_logging_redirect(disable=True) as pbar:
        pbar.write("\n")
        with logging_redirect_tqdm(loggers=[logging.getLogger()]):
            for i in trange(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
                time.sleep(0.01)
        pbar.write("\n")
    logging.getLogger().info('test success')

# Generated at 2022-06-22 05:05:34.445803
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-22 05:05:44.984955
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm_test_cases import (
        DiscreteTimer,
        with_unknown_length,
        _range)

    with DiscreteTimer() as timer:
        with _range(10) as forloop:
            for i in forloop:
                if i == 4:
                    with logging_redirect_tqdm():
                        LOG = logging.getLogger(__name__)
                        LOG.info("console logging redirected to `tqdm.write()`")
                for _ in _range(i):
                    for _ in _range(i):
                        pass
                    timer.sleep()

        with logging_redirect_tqdm():
            LOG = logging.getLogger(__name__)
            LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 05:05:53.217598
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .compatibility import captured_output
    from .main import trange

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with captured_output() as (out, err):
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    try:
        assert "console logging redirected to `tqdm.write()`" in err.getvalue()
    except AssertionError as e:
        raise AssertionError(str(e) + "\n" + err.getvalue())



# Generated at 2022-06-22 05:06:03.832231
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io

    def _find(array, func):
        # type: (List[str], Callable[[str], bool]) -> Optional[str]
        for item in array:
            if func(item):
                return item
        return None

    class _Tqdm(object):

        def __init__(self):
            self.content = []  # type: List[str]

        def write(self, msg, file=None):
            # type: (str, Optional[io.TextIOBase]) -> None
            self.content.append(msg)

    _tqdm = _Tqdm()
    _handler = _TqdmLoggingHandler(tqdm_class=_Tqdm)
    logger = logging.getLogger('test')

# Generated at 2022-06-22 05:06:12.372274
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test that tqdm_logging_redirect can provide write() to tqdm."""
    import logging
    import sys
    import time

    # Initialize logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    with tqdm_logging_redirect(total=10) as pbar:
        for i in pbar:
            time.sleep(0.1)
            logger.debug(str(i))
            pbar