

# Generated at 2022-06-22 04:56:08.881134
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:56:10.997309
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.info("test")

# Generated at 2022-06-22 04:56:16.362633
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            loggers=[LOG, logging.root],
            desc='TEST',
            file=sys.stdout
    ):
        with tqdm_logging_redirect(
                loggers=[LOG, logging.root],
                desc='TEST',
                file=sys.stdout
        ):
            LOG.info('Test 1')
            LOG.debug('Test 2')



# Generated at 2022-06-22 04:56:21.730944
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    stream = io.BytesIO()
    sys.stderr = stream
    logging_handler = _TqdmLoggingHandler()
    logging_handler.emit('testing')
    output = stream.getvalue()
    assert output == b'testing'

# Generated at 2022-06-22 04:56:30.711984
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import sys
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    x = list(range(10))

    for LOG in [logging.getLogger(), logging.getLogger('foo')]:
        LOG.setLevel(logging.INFO)
        with tqdm_logging_redirect(loggers=[LOG]):
            for i in x:
                LOG.info('hi!')
        assert not len(x)  # empty log

    with open(os.devnull, 'w') as f:
        # something that's not stdout/stderr
        # shouldn't be redirected
        h = logging.StreamHandler(f)
        LOG.addHandler(h)

# Generated at 2022-06-22 04:56:40.472905
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    # Capture the stderr
    orig_stderr = sys.stderr
    captured_stderr = io.StringIO()
    sys.stderr = captured_stderr


    # Create a logger with at least one handler
    logger = logging.getLogger('test')
    handler = logging.StreamHandler(sys.stderr)
    logger.addHandler(handler)

    # Create the TqdmLoggingHandler and add it to the logger
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)

    # Generate a logging message
    logger.info('test')
    # Make sure the logging message was sent to the TqdmLoggingHandler
    captured_stderr.seek(0)
    output = captured

# Generated at 2022-06-22 04:56:44.847196
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

            trange(11, desc="no logging redirect")
            LOG.info("console logging restored")
        # logging restored
        trange(3)

# Generated at 2022-06-22 04:56:48.318527
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.tqdm_class is std_tqdm



# Generated at 2022-06-22 04:56:54.051228
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-22 04:56:55.843189
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm = _TqdmLoggingHandler()
    assert isinstance(tqdm, _TqdmLoggingHandler)


# Generated at 2022-06-22 04:57:13.467066
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _is_console_logging_handler(logging.StreamHandler())
    assert not _is_console_logging_handler(logging.FileHandler("log.txt"))

    logger1 = logging.getLogger("logger1")
    logger1.handlers = [logging.StreamHandler()]
    logger2 = logging.getLogger("logger2")
    logger2.handlers = [logging.StreamHandler()]
    logger3 = logging.getLogger("logger3")
    logger3.handlers = [logging.FileHandler("log.txt")]
    assert _get_first_found_console_logging_handler(
        [logger1, logger2]) is logger1.handlers[0]

# Generated at 2022-06-22 04:57:23.311330
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm import tqdm
    except ImportError:
        return  # Nothing to test
    import logging

    log_test = "console logging redirected to `tqdm.write()`"

    # Check basic tqdm logging redirection
    with tqdm_logging_redirect(leave=False) as pbar:
        pbar.set_description(log_test)

    # Check multiple loggers tqdm logging redirection
    LOG_1 = logging.getLogger(__name__ + '_1')  # pylint: disable=invalid-name
    LOG_2 = logging.getLogger(__name__ + '_2')  # pylint: disable=invalid-name

# Generated at 2022-06-22 04:57:34.628801
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class tqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            self.__file = kwargs.pop('file')
            super(tqdm, self).__init__(*args, **kwargs)

        @property
        def file(self):
            return self.__file

        def write(self, msg, file=None):
            file.write(msg + '\n')

    class Stream(object):
        def __init__(self):
            self.lines = []

        def write(self, msg):
            self.lines.append(msg)

    test_logger = logging.getLogger(__name__)
    logger_stream = Stream()
    test_logger.addHandler(logging.StreamHandler(stream=logger_stream))
    test

# Generated at 2022-06-22 04:57:46.088254
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Tests method emit of class _TqdmLoggingHandler"""
    from io import StringIO
    from tqdm import tqdm
    buf = StringIO()
    logger = logging.getLogger()
    logging.handlers.clearLogHandlers()
    logger.handlers = [_TqdmLoggingHandler()]
    logger.info('hello')
    assert buf.getvalue() == ''
    with std_tqdm(file=buf):
        pass
    logger.info('info')
    assert buf.getvalue() == 'info\n'
    buf.seek(0)
    buf.truncate()
    with tqdm(file=buf):
        pass
    logger.info('hello')
    assert buf.getvalue() == 'hello\n'



# Generated at 2022-06-22 04:57:50.624588
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with std_tqdm.tgrange(5, desc='tgrange') as pbar:
        with std_tqdm.std_logger(logging.DEBUG) as logger:
            for i in pbar:
                logger.info(str(i))

# Generated at 2022-06-22 04:58:03.016342
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from shutil import get_terminal_size as get_term_size
    except ImportError:
        from backports.shutil_get_terminal_size import get_terminal_size as get_term_size

    from . import tqdm
    from .std import tqdm as std_tqdm

    std_tqdm.write('std_tqdm:')
    # test custom setup
    with tqdm.tqdm(total=100, file=sys.stderr, bar_format='!{l_bar}{bar}|') as pbar:
        for i in range(10):
            logger = std_tqdm.logging.getLogger(str(i))
            with tqdm.logging_redirect_tqdm():
                logger.info('\nhello')

# Generated at 2022-06-22 04:58:12.459319
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import TextIOWrapper
    from contextlib import redirect_stdout
    from tempfile import TemporaryFile

    with TemporaryFile(mode='w+') as f:
        with redirect_stdout(f):
            for msg in ['Hello world!', 'Bye bye world!']:
                _TqdmLoggingHandler().emit(logging.LogRecord('', '', '', 1, msg, None, None))
        f.seek(0)
        handler_dumped = TextIOWrapper(f).readlines()
    assert handler_dumped == ['Hello world!\n', 'Bye bye world!\n']

# Generated at 2022-06-22 04:58:19.520244
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with logging_redirect_tqdm(loggers=[LOG]):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(.01)
    # logging restored



# Generated at 2022-06-22 04:58:30.496714
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Unit tests for function `tqdm_logging_redirect`"""
    Logger = logging.getLogger('tqdm.logging_redirect_test')
    Logger.setLevel(logging.DEBUG)
    Logger.handlers = [logging.StreamHandler()]
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('tqdm.contrib.logging.logging_redirect_tqdm') as mock_func:
        with tqdm_logging_redirect('message', disable=True):
            pass
        mock_func.assert_called_once_with(loggers=None, tqdm_class=std_tqdm)


# Generated at 2022-06-22 04:58:32.498737
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_handler is not None

# Generated at 2022-06-22 04:58:52.519614
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.getLogger().handlers = []
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    logging.basicConfig(level=logging.INFO)
    tqdm_handler.emit(logging.makeLogRecord({'msg': 'testing'}))
    tqdm_log = sys.stderr.getvalue()
    std_log = sys.stdout.getvalue()
    assert tqdm_log == '[INFO    ] testing\n'
    assert std_log == ''

# Generated at 2022-06-22 04:59:03.512082
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test logging redirection to `tqdm.write()`
    """
    import logging
    from tqdm import trange, tqdm

    test_log = logging.getLogger(__name__)
    test_log.setLevel(logging.INFO)
    test_log.handlers.clear()

    log_msg = "console logging redirected to `tqdm.write()`"
    with tqdm_logging_redirect(loggers=[test_log]):
        # check if logging messages erased by tqdm methods
        for i in trange(9):
            if i == 4:
                test_log.info(log_msg)
        # check if logging messages erased by tqdm methods
        for i in tqdm(range(9)):
            if i == 4:
                test_

# Generated at 2022-06-22 04:59:10.631534
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-22 04:59:14.610990
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.info("first message")
        LOG.info("second message")

# Generated at 2022-06-22 04:59:21.803548
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.handlers = []
    logging.basicConfig(level=logging.INFO)
    assert 'console' == logging.root.handlers[0].stream.name
    assert 'console' == LOG.handlers[0].stream.name
    with tqdm_logging_redirect() as pbar:
        assert 'sys.stdout' == logging.root.handlers[0].stream.name
        assert 'sys.stdout' == LOG.handlers[0].stream.name
        LOG.info("console logging redirected to `tqdm.write()`")
        assert 'sys.stdout' == logging.root.handlers[0].stream.name
        assert 'sys.stdout' == LOG.handlers[0].stream.name


# Generated at 2022-06-22 04:59:32.366945
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import traceback

# Generated at 2022-06-22 04:59:44.063343
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    import logging
    from tqdm import tqdm

    class TestLoggingRedirectTqdm(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger()
            self.logger.setLevel(logging.DEBUG)
            self.log_handler = logging.StreamHandler()
            self.logger.addHandler(self.log_handler)

        def test_logging_redirect_tqdm(self):
            from tqdm.contrib.logging import logging_redirect_tqdm
            from io import StringIO
            from sys import stdout
            f = StringIO()

# Generated at 2022-06-22 04:59:50.727845
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    LOG = logging.getLogger(__name__)

    with std_tqdm(total=9) as pbar:
        with logging_redirect_tqdm():
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:02.212237
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-22 05:00:14.315639
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    with tqdm_logging_redirect(total=1) as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    # logging restored
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=1) as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    logging_redirect_tqdm  # noqa
    tqdm_logging_redirect  # noqa



# Generated at 2022-06-22 05:00:30.255702
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:00:37.981038
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()

    class MyException(Exception):
        pass

    def raise_my_exception():
        raise MyException

    handler.flush = raise_my_exception
    handler.handleError = raise_my_exception

    import io
    string_io = io.StringIO()
    handler.stream = string_io

    handler.emit("foo")

    assert string_io.getvalue() == 'foo\n'



# Generated at 2022-06-22 05:00:39.606047
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert tlh != None

# Generated at 2022-06-22 05:00:47.163429
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import StreamHandler
    from tempfile import NamedTemporaryFile

    dummy_log_content = "dummy_log_content"
    tqdm_obj = std_tqdm(desc="test")
    tqdm_original_write = tqdm_obj.write


# Generated at 2022-06-22 05:00:58.044004
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    from io import StringIO as SIO

    sio = SIO()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    handler.setFormatter(logging.Formatter("%(message)s"))
    handler.setLevel(logging.DEBUG)
    handler.stream = sio
    logger.addHandler(handler)
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    handler.flush()
    sio.seek(0)
    assert sio.read() == "info message\n"



# Generated at 2022-06-22 05:01:09.893406
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    log_output = StringIO()
    logger_handlers = [log_output]

    with redirect_stdout(log_output):
        with tqdm_logging_redirect(loggers=[LOG], logger_handlers=logger_handlers):
            for i in range(3):
                tqdm.write(str(i))
                LOG.info(str(i))
    assert log_output.getvalue() == (
        "0\n1\n2\n0\n1\n2\n")



# Generated at 2022-06-22 05:01:15.268661
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import tqdm
    except ImportError:
        tqdm = std_tqdm

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(range(4), total=4, unit='asc',
                               loggers=[LOG, logging.root]):
        for i in range(4):
            LOG.info("test %d", i)

# Generated at 2022-06-22 05:01:25.241828
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    try:
        import tqdm as _tqdm
    except ImportError:
        return  # noqa test skipped
    handler = _TqdmLoggingHandler(tqdm_class=_tqdm)
    record = logging.LogRecord(
        name="test__TqdmLoggingHandler_emit",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="Test message",
        args=None,
        exc_info=None)
    handler.emit(record)
    _tqdm.tqdm.write.assert_called_once_with(
        record.getMessage(), file=sys.stdout)



# Generated at 2022-06-22 05:01:33.454123
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import logging
    logger = logging.getLogger(__name__)
    logger.propagate = False
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    tqdm_handler.setFormatter(logging.Formatter('[%(levelname)s] %(message)s'))
    tqdm_handler.stream = sys.stderr
    logger.setLevel(logging.DEBUG)
    logger.addHandler(tqdm_handler)
    logger.error("test")

# Generated at 2022-06-22 05:01:41.508670
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class Tqdm(std_tqdm):
        @staticmethod
        def write(message, file=None):
            print(message)  # nosec

    msg_log = 'Test message'
    handler = _TqdmLoggingHandler(Tqdm)
    logging.basicConfig(stream=handler.stream)
    logger = logging.getLogger('Tqdm')
    logger.info(msg_log)



# Generated at 2022-06-22 05:02:11.008249
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import tempfile
    with tempfile.TemporaryFile(mode='r+') as f:
        msg = 'test_message'
        logging_handler = _TqdmLoggingHandler()
        logging_handler.stream = f
        logging_handler.emit(logging.LogRecord('tqdm', logging.INFO, '', 0, msg, (), None))

        # seek to the beginning of the file
        f.seek(0)
        assert msg == f.readline()

# Generated at 2022-06-22 05:02:22.285151
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    # manually call sleep here because when using
                    # logging_redirect_tqdm, tqdm has no way of knowing
                    # when the underlying write function has finished outputting
                    # the log message
                    time.sleep(0.2)
    print("logging restored")

# Generated at 2022-06-22 05:02:24.835593
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    from contextlib import redirect_stdout
    import logging

    # Suppress print() in the unit test
    out = StringIO()
    with redirect_stdout(out):
        with logging_redirect_tqdm():
            print("redirected")
            print("logging")
            logging.error("message")

    assert "redirected" not in out.getvalue()
    assert "logging" not in out.getvalue()
    assert "message" in out.getvalue()



# Generated at 2022-06-22 05:02:33.773301
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import os
    import tempfile

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    fd, file_path = tempfile.mkstemp(text=True)
    os.close(fd)
    fileHandler = logging.FileHandler(file_path)
    log.addHandler(fileHandler)
    log.addHandler(_TqdmLoggingHandler())
    log.debug('debug')
    log.info('info')
    log.warn('warning')
    log.error('error')
    log.critical('critical')
    log.debug('debug')

    # Read the test file and check the output
    with open(file_path, "r") as f:
        lines = f.readlines()

    output = ''.join(lines)
   

# Generated at 2022-06-22 05:02:43.443388
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Disable output of logging to prevent noise while testing
    logging.disable(logging.CRITICAL)
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        """Redirect stdout and stderr to fake streams for testing."""
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:02:54.811203
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .main import tqdm
    from .utils import TqdmTypeError

    try:
        import logging
    except ImportError:
        raise unittest.SkipTest

    log = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        log.info('message')
        log.info('message 2')
    assert ('message\n'
            'message 2') in pbar.write.get_buf()

    logging.basicConfig(level=logging.INFO)
    loggers = [logging.getLogger(__name__)]
    with logging_redirect_tqdm(loggers=loggers):
        log.info('message')
        logging.getLogger('other').info('message 2')

# Generated at 2022-06-22 05:03:06.529098
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os

    tmp_path = os.path.normpath(os.path.join(os.getcwd(), '..'))
    if not os.path.exists(tmp_path):
        os.makedirs(tmp_path)

    tmp_file = os.path.join(tmp_path, 'test.log')
    if os.path.exists(tmp_file):
        os.remove(tmp_file)

    # Write log file
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)-8s %(message)s',
        datefmt='%a, %d %b %Y %H:%M:%S',
        filename=tmp_file,
        filemode='w')


# Generated at 2022-06-22 05:03:14.529718
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Tests that the constructor of class _TqdmLoggingHandler returns an object
    of the same class with the correct class members.
    """
    test_tqdm_class = "test_tqdm_class"
    test_handler = _TqdmLoggingHandler(tqdm_class=test_tqdm_class)
    assert type(test_handler) == _TqdmLoggingHandler
    assert test_handler.tqdm_class == test_tqdm_class



# Generated at 2022-06-22 05:03:16.486477
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-22 05:03:26.571635
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import getLogger, INFO, Formatter, StreamHandler
    from io import StringIO
    import re

    # logging system
    log = getLogger(__name__)
    log.setLevel(INFO)
    msg = 'This is a test.'
    handler = StreamHandler()
    formatter = Formatter('%(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)

    # logging with tqdm
    with StringIO() as s:
        handler.stream = s
        with logging_redirect_tqdm():
            log.info(msg)
        s.seek(0)
        assert bool(re.match(msg, s.read())), "logging with tqdm failed"

    # logging without tqdm

# Generated at 2022-06-22 05:04:20.045726
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys
    # Firstly the program will run on a non-tty file and then on a tty file
    for stream in io.FileIO(__file__), sys.stdout:
        try:
            test_handler = _TqdmLoggingHandler()
            test_handler.stream = stream
            test_handler.setFormatter(logging.Formatter('%(message)s'))
            test_handler.emit(logging.LogRecord('TestLogger', logging.INFO,
                                                __file__, 42, 'test',
                                                (), None))
            stream.flush()
        except (KeyboardInterrupt, SystemExit):
            raise

# Generated at 2022-06-22 05:04:29.445594
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging

    logging.basicConfig(format="%(message)s", level=logging.INFO)

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect() as pbar:
            for i in pbar(range(10)):
                if i == 4:
                    LOG.info("tqdm_logging_redirect() test")
            pbar.write("pbar.write test")


# Generated at 2022-06-22 05:04:31.591885
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys

    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.info("Hello")


# Generated at 2022-06-22 05:04:43.646692
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import tqdm
    tqdm.monitor_interval = 0

    msg = "test log message"
    out = io.StringIO()
    lvl = logging.INFO
    with tqdm.std.tqdm(desc=msg, unit="chars", file=out, leave=False) as pbar:
        handler = _TqdmLoggingHandler(tqdm_class=tqdm.std.tqdm)
        handler.stream = pbar.fp
        record = logging.LogRecord("name", lvl,
                                   "pathname", 123, msg, [], None)
        handler.emit(record)

# Generated at 2022-06-22 05:04:53.843593
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tempfile

    test_file_name = tempfile.mktemp()
    test_file = open(test_file_name, 'w')

    test_record = logging.LogRecord(
        name='log',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg='message',
        args=(),
        exc_info=None)

    test_file.close()
    test_file = open(test_file_name, 'r')

    tqdm_log_handler = _TqdmLoggingHandler()
    tqdm_log_handler.stream = test_file
    tqdm_log_handler.emit(test_record)

    expected = '{}: {}\n'.format('log', 'message')
    assert test_file.read() == expected

   

# Generated at 2022-06-22 05:04:58.197464
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        LOG.debug("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:05:05.110485
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-22 05:05:09.706837
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function logging_redirect_tqdm
    """
    import logging
    from tqdm import trange

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:05:19.157496
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:05:24.030291
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_record = logging.LogRecord("name", "level", "path", 1, "test", [], None)
    test_record.msg = "test message"
    test_string = "test\n"
    handler = _TqdmLoggingHandler()
    f = open("test.txt", "w")
    handler.stream = f
    handler.emit(test_record)
    f.close()
    assert open("test.txt", "r").read() == test_string
    import os
    os.remove("test.txt")
