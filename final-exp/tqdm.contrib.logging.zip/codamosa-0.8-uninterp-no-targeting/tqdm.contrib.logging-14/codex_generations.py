

# Generated at 2022-06-22 04:56:12.458970
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class FakeTqdm:

        def __init__(self):
            self.stream = sys.stdout
            self.file = self.stream

        def write(self, message, file):
            pass

        def flush(self):
            pass

    handler = _TqdmLoggingHandler(FakeTqdm)
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream == sys.stdout
    assert handler.stream == handler.file
    assert handler.formatter is None



# Generated at 2022-06-22 04:56:20.422497
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        LOG.info('redirected to tqdm.write')

    # test custom logger
    logger = logging.getLogger(__name__ + '.logger')
    with logging_redirect_tqdm([logger]):
        logger.info('redirected to tqdm.write')

# Generated at 2022-06-22 04:56:28.507166
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import cStringIO as StringIO
    output = StringIO.StringIO()
    logging._srcfile = ''  # pylint: disable=protected-access
    logger = logging.getLogger("example")
    logger.propagate = False
    handler = _TqdmLoggingHandler()
    handler.stream = output
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.info("test")
    assert output.getvalue().strip() == 'test'


if __name__ == '__main__':
    from . import _test_logging_redirect_tqdm  # pylint: disable=unused-variable
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-22 04:56:34.316594
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in pbar:
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    logging.info("logging restored")


# Generated at 2022-06-22 04:56:42.877266
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import warnings
    import cStringIO
    import logging

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    def _assert_warn_msg(record, msg):
        for line in msg.split('\n'):
            assert line in record.getMessage()

    class _DummyStream(cStringIO.StringIO):
        def write(self, msg):
            pass

    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(self, tqdm_class):
            super(_TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class


# Generated at 2022-06-22 04:56:46.337818
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logger = _TqdmLoggingHandler(std_tqdm)
    assert tqdm_logger.tqdm_class == std_tqdm


# Generated at 2022-06-22 04:56:56.530924
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _get_min_interval
    from io import StringIO
    stream = StringIO()
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    _TqdmLoggingHandler().emit(logging.makeLogRecord({"msg": "Test"}))
    _TqdmLoggingHandler(
        tqdm_class=std_tqdm(
            out=stream,
            desc="Test:",
            mininterval=_get_min_interval()
        )
    ).emit(logging.makeLogRecord({"msg": "Test"}))
    assert stream.getvalue() == "Test:\nTest\n"

# Generated at 2022-06-22 04:57:04.002814
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # pylint: disable=redefined-outer-name,invalid-name
        import logging
        from tqdm import tqdm
        from tqdm.contrib import logging_redirect_tqdm
        from .__init__ import _range

        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(tqdm_class=tqdm):
            for i in _range(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    except:  # noqa pylint: disable=bare-except
        # if tqdm not installed, just pass
        pass

# Generated at 2022-06-22 04:57:13.133268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:57:13.857323
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import test_tqdm_logging_redirect
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:57:20.030881
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:57:30.828051
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest  # python 2.6+
    except ImportError:
        import unittest
    import logging
    import sys

    class MockLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super(MockLoggingHandler, self).__init__()
            self.logs = []

        def emit(self, record):
            self.logs.append(self.format(record))

    class TestLoggingRedirectTqdm(unittest.TestCase):
        def test_basic(self):
            logger1 = logging.getLogger('logger1')
            logger2 = logging.getLogger('logger2')
            handler1 = MockLoggingHandler()
            handler1.setLevel(logging.ERROR)
            logger1.add

# Generated at 2022-06-22 04:57:34.640699
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    logger = logging.getLogger(__name__)  # pylint: disable=invalid-name
    with StringIO() as log_capture_string:
        # redirect stdout
        with std_tqdm(disable=None, file=log_capture_string) as stdout_tqdm:
            # redirect stderr
            with std_tqdm(disable=None, file=log_capture_string,
                          dynamic_ncols=True) as stderr_tqdm:
                # redirect logging
                with logging_redirect_tqdm(loggers=[logger],
                                           tqdm_class=std_tqdm):
                    stdout_tqdm.write("stdout_tqdm")

# Generated at 2022-06-22 04:57:36.691342
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler()
    assert logging_handler is not None

# Generated at 2022-06-22 04:57:43.085762
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    for tqdm_class in [std_tqdm]:
        for loggers in [[],
                        [logging.root]]:
            with tqdm_class(total=10) as pbar:
                with tqdm_logging_redirect(loggers=loggers, tqdm_class=tqdm_class):
                    assert pbar.n == 0
                    assert pbar.total == 10
            assert pbar.n == 10



# Generated at 2022-06-22 04:57:53.904380
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import random
    import string
    import threading
    import time

    logger = logging.getLogger()

    test_out = []

    def test_thread():
        class TestLoggingHandler(logging.StreamHandler):
            def emit(self, record):
                try:
                    msg = self.format(record)
                    test_out.append(msg)
                except (KeyboardInterrupt, SystemExit):
                    raise
                except:  # noqa pylint: disable=bare-except
                    self.handleError(record)

        logger.addHandler(TestLoggingHandler())
        for _ in range(10):
            time.sleep(0.3*(random.random() - 0.5))

# Generated at 2022-06-22 04:57:57.058984
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import test.support as support
    except ImportError:
        import test.test_support as support
    support.cleanup_import_cache()

    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:58:01.221731
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    log = logging.getLogger()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=logging.StreamHandler)
    log.addHandler(tqdm_handler)
    log.info("Hello world")


# Generated at 2022-06-22 04:58:13.037897
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    import io
    if sys.version_info[:2] == (2, 6):
        raise unittest.SkipTest
    import logging
    from tqdm import trange

    log_output = io.StringIO()
    handler = logging.StreamHandler(log_output)
    handler.setFormatter(
        logging.Formatter('%(levelname)s:%(name)s:%(message)s'))
    LOG = logging.getLogger('tqdm')
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)
    LOG.propagate = False

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
       

# Generated at 2022-06-22 04:58:24.754168
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    import tqdm
    import logging

    handler = _TqdmLoggingHandler()

    # Test normal
    buffer = BytesIO()
    sys.stderr = buffer
    record = logging.LogRecord('test', logging.DEBUG, __file__, 1, 'test_message', [], None)
    handler.emit(record)
    assert buffer.getvalue() == b'  0%|          | 0/1 [00:00<?, ?it/s]test_message\n'

    # Test error
    buffer = BytesIO()
    sys.stderr = buffer
    record = logging.LogRecord('test', logging.DEBUG, '__file__', 1, 'test_message', [], None)
    record.name = None
    handler.emit(record)

# Generated at 2022-06-22 04:58:42.488991
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.std import tqdm

    handler = _TqdmLoggingHandler(tqdm)
    handler.stream = StringIO()
    logger = logging.Logger('test')
    logger.addHandler(handler)
    logger.error("log message")
    assert handler.stream.getvalue() == "\x1b[A\x1b[KERROR:test:log message\n"

# Generated at 2022-06-22 04:58:52.977238
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import logging
    import unittest
    from unittest.mock import patch

    class InMemoryStream(object):
        def __init__(self):
            self.lines = []

        def __iadd__(self, line):
            self.lines.append(line)
            return self

    # We create a fake logger and a fake record
    logging.basicConfig(level=logging.DEBUG)
    LOGGER = logging.getLogger(__name__)
    record = logging.LogRecord(name="my_tqdm_logger",
                               level=logging.INFO,
                               pathname="my_pathname",
                               lineno=1,
                               msg="this is a test",
                               args=None,
                               exc_info=None)
    # We create a fake t

# Generated at 2022-06-22 04:58:56.728439
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(desc='example') as pbar:
        assert pbar.total == 1
        assert pbar.disable == False
    assert pbar.disable == True



# Generated at 2022-06-22 04:59:07.716566
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import io
    import logging
    from contextlib import redirect_stdout, redirect_stderr

    class _StdIoStream(io.StringIO):
        def __getattr__(self, attr):
            return getattr(io.StringIO, attr)

    sys.stdout = _StdIoStream()
    sys.stderr = _StdIoStream()

    tqdm_handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.propagate = False
    logger.setLevel(logging.INFO)
    logger.addHandler(tqdm_handler)

    logger.info("test _TqdmLoggingHandler.emit")
    tqdm_handler.flush()

    result_stdout = sys.std

# Generated at 2022-06-22 04:59:12.450827
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Initializing an instance
    obj = _TqdmLoggingHandler()

    # Determining if the instance is correctly created
    assert( isinstance(obj, _TqdmLoggingHandler) )
    assert( isinstance(obj, logging.StreamHandler) )


# Generated at 2022-06-22 04:59:14.928063
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)


# Generated at 2022-06-22 04:59:16.434336
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, _TqdmLoggingHandler)


# Generated at 2022-06-22 04:59:19.942268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler())
    log.debug('test debug')
    with logging_redirect_tqdm():
        log.debug('test debug')

# Generated at 2022-06-22 04:59:30.354525
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm  # pylint: disable=wrong-import-position

    orig_stdout = sys.stdout


# Generated at 2022-06-22 04:59:37.182236
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import test

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for _ in range(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    test.runner()


# Generated at 2022-06-22 04:59:58.111535
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # TODO
    assert True

# Generated at 2022-06-22 05:00:05.409372
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm

    def _unittest():
        # type: () -> None
        LOG = logging.getLogger(__name__)

        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

        with logging_redirect_tqdm(tqdm_class=tqdm):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

        logger_child = LOG.getChild("child")

# Generated at 2022-06-22 05:00:16.013731
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger('logging_redirect_tqdm')
    logger.handlers = [logging.StreamHandler()]
    logger.setLevel(logging.DEBUG)

# Generated at 2022-06-22 05:00:19.667817
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert hasattr(_TqdmLoggingHandler, 'emit'), \
        'missing method "emit"'


# Generated at 2022-06-22 05:00:23.462686
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """Unit test for constructor of class _TqdmLoggingHandler"""

    logging_handler = _TqdmLoggingHandler()

    assert isinstance(logging_handler, _TqdmLoggingHandler)

    assert isinstance(logging_handler.tqdm_class, type)



# Generated at 2022-06-22 05:00:29.115419
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest.mock import MagicMock
    from io import StringIO

    out = StringIO()

    handler = _TqdmLoggingHandler(MagicMock())
    handler.stream = out
    handler.emit(logging.LogRecord(  # pylint: disable=no-member
        "test", logging.INFO, "test.py", 1, "test", (), None))

    assert out.getvalue() == "test\n"


# Generated at 2022-06-22 05:00:32.198449
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm():
        logging.info('Hello')

# Generated at 2022-06-22 05:00:43.571043
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.auto import trange

    # Create object of test class
    tlh = _TqdmLoggingHandler()
    # Create object of class logging.LogRecord
    lr = logging.LogRecord('name', logging.INFO, 'fname',
                           'lno', 'msg', None, None)
    # Execute test method
    tlh.emit(lr)
    # Creating object of class logger
    logger = logging.getLogger('name')
    # Creating object of class handler
    tqdm_handler = _TqdmLoggingHandler()
    # Set Formater and Stream of TqdmLoggingHandler
    orig_handler = _get_first_found_console_logging_handler(logger.handlers)
    if orig_handler is not None:
        tqdm_handler.set

# Generated at 2022-06-22 05:00:53.798785
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    def new_handler():
        return _TqdmLoggingHandler()

    assert new_handler().tqdm_class is std_tqdm  # type: ignore
    assert new_handler().tqdm_class is not std_tqdm  # type: ignore
    assert new_handler(tqdm_class=std_tqdm).tqdm_class is std_tqdm  # type: ignore
    assert new_handler(tqdm_class=std_tqdm).tqdm_class is not std_tqdm  # type: ignore



# Generated at 2022-06-22 05:01:01.466029
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .utils import _range

    logging.basicConfig()
    redirection_handler = _TqdmLoggingHandler()
    LOG = logging.getLogger(__name__)
    LOG.addHandler(redirection_handler)
    try:
        for i in _range(3, desc="Test"):
            if i == 1:
                LOG.info("This is a INFO message")
            elif i == 2:
                LOG.warning("This is a WARNING message")
    except:  # noqa pylint: disable=bare-except
        raise
    finally:
        LOG.removeHandler(redirection_handler)

# Generated at 2022-06-22 05:01:46.230267
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    f = io.StringIO()
    hdlr = logging.StreamHandler(f)
    fmtr = logging.Formatter('%(levelname)s: %(message)s')
    hdlr.setFormatter(fmtr)
    log.addHandler(hdlr)

    log.info("before")
    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(11):
            log.info("hello")
            pbar.update()
    log.info("after")

# Generated at 2022-06-22 05:01:57.826075
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    import sys
    import io
    import logging

    output = io.StringIO()  # type: BytesIO
    #output = io.StringIO() if sys.version_info >= (3,) else io.BytesIO()
    stream = sys.stdout if sys.version_info >= (3,) else sys.stdout
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.WARNING)
    handler.stream = output
    record = logging.LogRecord(
        'name', logging.WARNING, '/path', 42,
        'msg', {}, None)
    handler.emit(record)
    assert output.getvalue() == 'msg\n'



# Generated at 2022-06-22 05:02:01.793854
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm(tqdm_class=std_tqdm):
        for i in std_tqdm(range(9)):
            LOG.info("test")
            time.sleep(0.1)

# Generated at 2022-06-22 05:02:09.974030
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    logger = logging.getLogger('tqdm')
    logger_handler = _TqdmLoggingHandler(logger)
    logger.addHandler(logger_handler)
    # print(logger)
    logger.error('tqdm')
    logger_handler.flush()
    logger.removeHandler(logger_handler)
    assert sys.stdout.getvalue() == 'tqdm\n'
    assert sys.stderr.getvalue() == ''
    assert logger_handler.tqdm_class == logger


# Generated at 2022-06-22 05:02:13.853064
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    __builtins__['_range'] = range  # backwards compatibility for 2.6
    with tqdm_logging_redirect(total=9):
        for _ in _range(9):
            logging.info('console logging redirected to `tqdm.write()`')
    del __builtins__['_range']

# Generated at 2022-06-22 05:02:22.718705
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    try:
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
    except Exception as e:  # pylint: disable=broad-except
        assert False, "Caught exception " + str(e)

# Generated at 2022-06-22 05:02:31.984479
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    import sys
    import logging
    from .format_opts import format_time
    from .std import tqdm
    from .contrib import logging as tqdm_logging
    # First, create and configure a test logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    # Create a stream for the handler to write to.
    stream = io.StringIO()
    tqdm_handler = tqdm_logging._TqdmLoggingHandler(tqdm_class=tqdm)
    tqdm_handler.setLevel(logging.DEBUG)
    tqdm_handler.stream = stream
    logger.addHandler(tqdm_handler)
    # Send a few test messages

# Generated at 2022-06-22 05:02:42.204456
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None

    class TqdmMock(std_tqdm):
        def __init__(self):
            self.written_content = []  # type: List[str]
            self.file = None

        def write(self, *args, **kwargs):
            self.written_content.append(str(args[0]))

    tqdm_mock = TqdmMock()
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=TqdmMock)
    tqdm_logging_handler.tqdm_class = TqdmMock
    tqdm_logging_handler.write = TqdmMock

# Generated at 2022-06-22 05:02:48.622930
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    string = 'test_emit'
    tqdm_handler = _TqdmLoggingHandler()

    record = logging.LogRecord('name', logging.INFO, '/tmp/foo.py', 1,
                               string, (), None)
    tqdm_handler.emit(record)
    stream = tqdm_handler.stream
    assert stream.read() == string + '\n'


# Generated at 2022-06-22 05:02:57.888459
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import closing, _range, _test_exception_exit

    loggers = [logging.getLogger("a"), logging.getLogger("b")]
    with closing(logging.StreamHandler()) as streamhandler:
        loggers[1].addHandler(streamhandler)

# Generated at 2022-06-22 05:04:24.718671
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    # Use:
    >>> test__TqdmLoggingHandler_emit()
    """
    pass

# Generated at 2022-06-22 05:04:33.891408
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    def _test(test_str, expected_str=None):
        f = StringIO()
        tqdm.write(test_str, file=f)
        assert test_str == f.getvalue().strip()

    test_str = "test_str"
    _test(test_str)

    class MockTqdm(object):
        @staticmethod
        def write(line, file=sys.stderr):
            file.write("MOCK " + line)

    test_str = "test_str"
    _test(test_str, "MOCK " + test_str)
    handler = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    handler.stream = StringIO()

# Generated at 2022-06-22 05:04:34.901634
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:04:41.595342
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    logger = logging.getLogger('tqdm')
    logger.addHandler(tqdm_handler)
    logger.setLevel(logging.DEBUG)

    logger.debug('testing debug')
    logger.info('testing info')
    logger.warn('testing warn')
    logger.error('testing error')
    logger.critical('testing critical')

# Generated at 2022-06-22 05:04:45.137131
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Test if it is the same tqdm
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    assert tqdm_handler.tqdm_class is tqdm_class



# Generated at 2022-06-22 05:04:47.605390
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging_handler = _TqdmLoggingHandler()
    assert isinstance(logging_handler, logging.StreamHandler)
    assert logging_handler.tqdm_class == std_tqdm

# Generated at 2022-06-22 05:04:58.112263
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create a logger
    tqdm_logger = logging.getLogger('TqdmLoggingHandler')
    tqdm_logger.setLevel(logging.INFO)
    # create a 'console' logging handler
    log_handler = logging.StreamHandler()
    log_handler.setLevel(logging.INFO)
    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    log_handler.setFormatter(formatter)
    # add the handler to the logger
    tqdm_logger.addHandler(log_handler)

    # Create the TqdmLoggingHandler
    tqdm_handler = _TqdmLoggingHandler()
    # Create a form

# Generated at 2022-06-22 05:05:02.115530
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.tqdm_class == std_tqdm



# Generated at 2022-06-22 05:05:10.665220
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test method emit of _TqdmLoggingHandler class when
    there are error and exception
    """
    from unittest import TestCase
    import os
    import io
    from io import StringIO
    import tqdm
    import random
    from random import randrange

    class TqdmLoggingHandlerTester(TestCase):
        def __init__(self):
            self.old_stdout = sys.stdout
            sys.stdout = StringIO()

        def test_method_emit(self):
            # Test when there are errors
            emittestlog = logging.getLogger(__name__)
            emitter = _TqdmLoggingHandler(tqdm_class=tqdm.tqdm)
            emitter.stream = sys.stdout
            emittestlog.setLevel

# Generated at 2022-06-22 05:05:12.600449
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)