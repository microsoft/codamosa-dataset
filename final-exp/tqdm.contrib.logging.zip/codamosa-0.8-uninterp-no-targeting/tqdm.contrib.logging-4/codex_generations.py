

# Generated at 2022-06-22 04:56:16.530768
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    mock_handler = _TqdmLoggingHandler()
    mock_record = logging.makeLogRecord({"msg": "test"})
    mock_handler.emit(mock_record)

# Generated at 2022-06-22 04:56:19.414157
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect
    """
    import logging
    from tqdm import trange

    try:
        # noqa
        with tqdm_logging_redirect() as pbar:
            for _ in trange(9):
                if _ == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    except (KeyboardInterrupt, SystemExit):
        pass

# Generated at 2022-06-22 04:56:24.132397
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                logger = logging.getLogger('test_logger')
                logger.warn("console logging redirected to `tqdm.write()`")
        elif i == 6:
            # TODO: this should actually not work
            with logging_redirect_tqdm(loggers=[logging.getLogger('foo')]):
                logger = logging.getLogger('test_logger')
                logger.error("console logging redirected to `tqdm.write()`")
        elif i == 8:
            logging.warning("console logging restored")

# Generated at 2022-06-22 04:56:28.845121
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger('tt')
    logger.handlers = [_TqdmLoggingHandler()]
    logger.info("test")

# Generated at 2022-06-22 04:56:33.899080
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)
    logger.info("Some info message")
# END test__TqdmLoggingHandler_emit


# Generated at 2022-06-22 04:56:41.849318
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # NOTE: Do not use print() in this function,
    # as it will lead to test fail on Python 2.
    try:
        import tqdm
    except ImportError:
        raise SkipTest
    import logging

    with std_tqdm(
        desc='With',
        unit='flog',
        smoothing=1,
        total=3,
    ) as flog_with, std_tqdm(
        desc='Without',
        unit='flog',
        smoothing=1,
        total=3,
    ) as flog_without:

        log_with = tqdm.tqdm_logging_redirect(
            loggers=[logging.getLogger('with')],
            tqdm_class=std_tqdm,
        )


# Generated at 2022-06-22 04:56:53.804341
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Example unit tests for `logging_redirect_tqdm()`.
    """
    import logging

    logger = logging.getLogger('logging_redirect_tqdm_test')
    logging.basicConfig(level=logging.INFO)
    logger.info("this line should only be printed on the console, not here")
    with logging_redirect_tqdm(loggers=[logger], tqdm_class=std_tqdm):
        logger.info("this line should be redirected to `std_tqdm.write()`")
    logger.info("resuming normal console logging")
    with tqdm_logging_redirect(
        total=42,
        loggers=[logger],
        tqdm_class=std_tqdm):
        logger

# Generated at 2022-06-22 04:57:02.989739
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Tests `logging_redirect_tqdm`."""
    from logging import LogRecord
    from ._tqdm_std import tqdm as tqdm_logging_redirect_tqdm  # pylint: disable=no-name-in-module
    rec1 = LogRecord('name', 20, '/foo/bar', 5, 'msg1', None, None)
    rec2 = LogRecord('name', 20, '/foo/bar', 5, 'msg2', None, None)
    rec3 = LogRecord('name', 20, '/foo/bar', 5, 'msg3', None, None)

# Generated at 2022-06-22 04:57:09.912852
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    try:
        with logging_redirect_tqdm(loggers=[logger]):
            logger.debug("debug test")
            logger.info("info test")
            logger.warning("warning test")
            logger.error("error test")
            logger.critical("critical test")
    except KeyError:
        pass

# Generated at 2022-06-22 04:57:11.316954
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    test = _TqdmLoggingHandler()
    assert test

# Generated at 2022-06-22 04:57:19.902691
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm

# Generated at 2022-06-22 04:57:22.628394
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None


# Generated at 2022-06-22 04:57:33.796837
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from test_tqdm.utils import cwd, tmp_write
    with tmp_write(
            # type: ignore
            'test__TqdmLoggingHandler_emit.log',
            '\n'.join(['%d' % i for i in range(10)])) as tmp:
        logger = logging.getLogger('logger_test')
        logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler(
            # type: ignore
            tmp.name,
            delay=False  # no buffering
        )
        logger.addHandler(fh)

        with cwd(tmp.dir):
            tqdm_handler = _TqdmLoggingHandler()
            logger.addHandler(tqdm_handler)
            for i in range(5):
                logger.info(i)

# Generated at 2022-06-22 04:57:42.906173
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .std import tqdm_pandas
    import logging

    # Setup tqdm_pandas
    tqdm_kwargs = dict(mininterval=0.01, smoothing=0, miniters=1)
    pbt = tqdm_pandas(**tqdm_kwargs)
    df = pbt.range(100)

    # Setup logging
    log_string = 'test_tqdm_logging_redirect'
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    log_listener = logging.handlers.BufferingHandler(capacity=1000)
    LOG.addHandler(log_listener)
    logging.basicConfig(level=logging.INFO)

    # First run, no tqdm redirect
    df

# Generated at 2022-06-22 04:57:51.609982
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Initialize logger
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    orig_logging_handlers = log.handlers

    try:
        # Apply the redirect
        with logging_redirect_tqdm():
            for i in range(4):
                log.info("Test message: {}".format(i))
    except:
        assert False
    finally:
        # logging.handlers is restored to its original value
        log.handlers = orig_logging_handlers



# Generated at 2022-06-22 04:57:57.059211
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Unit test for method emit of class _TqdmLoggingHandler
    # this test is example in the docstring of the same method
    logger = logging.getLogger()
    logger.info("test message")
    std_tqdm.write("test message")

# Generated at 2022-06-22 04:58:05.794631
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logger = logging.getLogger('foo')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                logger.info("console logging redirected to `tqdm.write()`")
            # logging restored
        else:
            logger.info("console logging NOT redirected")



# Generated at 2022-06-22 04:58:15.009170
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():

    from tqdm.utils import _term_move_up

    # Setup
    test_str = 'TEST'
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler())

    # Test
    with logging_redirect_tqdm():
        log.info(test_str)

    # Check
    tqdm_out = sys.stdout.getvalue().rstrip()
    logging_out = _term_move_up() + '\r' + test_str + '\n'
    assert (tqdm_out == logging_out)

# Generated at 2022-06-22 04:58:22.010243
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 04:58:32.806398
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from ..std import tqdm as std_tqdm
    mytqdm = std_tqdm
    _TqdmLoggingHandler(tqdm_class=mytqdm)

if __name__ == '__main__':
    import logging
    from tqdm import trange
    #from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        #with logging_redirect_tqdm():

# Generated at 2022-06-22 04:58:41.123662
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    log_output = StringIO()
    logger = logging.getLogger('Test')
    logger.addHandler(_TqdmLoggingHandler(file=log_output))
    logger.warning('TqdmLoggingHandler test')
    log_output.seek(0)
    assert log_output.read() == 'WARNING:Test:TqdmLoggingHandler test\n'

# Generated at 2022-06-22 04:58:44.307482
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    test case to check emit method of _TqdmLoggingHandler class

    Parameters
    ----------

    Returns
    -------
    """
    fake_record = 'foo bar'
    tqdm_logging_handler = _TqdmLoggingHandler()
    try:
        tqdm_logging_handler.emit(fake_record)
    except:
        assert False, 'Exception should not be raised in emit method'
    assert True

# Generated at 2022-06-22 04:58:48.939519
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 04:58:52.977660
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=3) as tl_pbar:
        for i in range(3):
            logging.info('Test {}'.format(i))
            tl_pbar.update()

# Generated at 2022-06-22 04:59:00.465177
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(desc="bar", disable=False):
        assert True
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:59:02.887410
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:59:10.498811
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.warning("console logging redirected to `tqdm.write()`")

    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.debug("console logging redirected to `tqdm.write()`")

    logging

# Generated at 2022-06-22 04:59:18.066857
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    class TqdmLoggingHandler(_TqdmLoggingHandler):
        def emit(self, record):
            print("{}".format(record))

    root_logger = logging.getLogger()
    root_handlers = root_logger.handlers
    with logging_redirect_tqdm(
        loggers=[root_logger],
        tqdm_class=TqdmLoggingHandler
    ):
        logging.warning('foo')
    assert root_logger.handlers == root_handlers
    assert sys.stdout.getvalue() == ''

# Generated at 2022-06-22 04:59:23.544024
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    >>> from tqdm.contrib.logging import _TqdmLoggingHandler
    >>> handler = _TqdmLoggingHandler()
    >>> 'Tqdm' in type(handler).__name__
    True
    """
    pass



# Generated at 2022-06-22 04:59:30.273651
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    for tqdm_class in [std_tqdm, std_tqdm]:
        with tqdm_logging_redirect(tqdm_class=tqdm_class, leave=False) as pbar:
            logger = logging.getLogger(__name__)
            logger.info("logging redirected to `tqdm.write()`")
            assert pbar.format_dict['desc'] == "logging redirected to `tqdm.write()`"



# Generated at 2022-06-22 04:59:43.103158
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Method emit of _TqdmLoggingHandler asserts if no exception is raised
    """
    test_log_msg = "Unit test 1"
    test_record = logging.LogRecord(test_log_msg, logging.WARNING,
                                    '/test_log_file', 1, test_log_msg, [],
                                    'test_func', None)

    tqdm_log_handler = _TqdmLoggingHandler()
    tqdm_log_handler.emit(test_record)



# Generated at 2022-06-22 04:59:44.689876
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    t = _TqdmLoggingHandler()
    assert isinstance(t, logging.StreamHandler)

# Generated at 2022-06-22 04:59:46.706508
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    pass

# Generated at 2022-06-22 04:59:58.654671
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # import tqdm_class and set up logging
    tqdm_class = std_tqdm
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    for logger in loggers:
        tqdm_handler = _TqdmLoggingHandler(tqdm_class)
        orig_handler = _get_first_found_console_logging_handler(logger.handlers)
        if orig_handler is not None:
            tqdm_handler.setFormatter(orig_handler.formatter)
            tqdm_handler.stream = orig_handler.stream

# Generated at 2022-06-22 05:00:03.052195
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-22 05:00:15.077413
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging

    # Set underlying stdout stream.
    out_stream = []
    _TqdmLoggingHandler.write = out_stream.append

    tqdm_handler = _TqdmLoggingHandler()
    logging.root.addHandler(tqdm_handler)

    # Test write.
    logging.info('hello world')
    assert 'hello world\n' == ''.join(out_stream)

    # Test exception.
    out_stream.pop()
    try:
        1 / 0  # noqa pylint: disable=pointless-statement
    except ZeroDivisionError:
        logging.exception('oops!')
    assert 'oops!\n' in ''.join(out_stream)
    assert 'ZeroDivisionError' in ''.join(out_stream)



# Generated at 2022-06-22 05:00:22.321325
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    def f(msg):
        print(msg)

    tbh = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    tbh.stream = f
    tbh.emit(logging.LogRecord("Logger Name",
                               logging.INFO,
                               "Logger Path",
                               1,
                               "This is a test",
                               list(),
                               None))

# Generated at 2022-06-22 05:00:31.274349
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    loggers = [logging.root]
    tqdm_class = std_tqdm

    # Set up logging
    # TODO: Should we use both file and console output to check?
    logging.basicConfig(level=logging.INFO)
    original_handlers_list = [logger.handlers for logger in loggers]
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    orig_handler = _get_first_found_console_logging_handler(logger.handlers)
    if orig_handler is not None:
        tqdm_handler.setFormatter(orig_handler.formatter)
        tqdm_handler.stream = orig_handler.stream

# Generated at 2022-06-22 05:00:42.648571
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    import unittest
    import tqdm
    import tqdm.contrib.logging

    # Capture stdout/stderr by setting these environment vars
    unittest.TestCase().assertTrue(hasattr(tqdm.tqdm, '_instances'))
    unittest.TestCase().assertFalse(bool(tqdm.tqdm._instances))
    sys_stdout = sys.stdout

    test_output = io.StringIO()
    sys.stdout = test_output

    tqdm.contrib.logging.tqdm_logging_redirect()
    unittest.TestCase().assertTrue(bool(tqdm.tqdm._instances))

    logging.debug('test_debug')

# Generated at 2022-06-22 05:00:47.329559
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info(u"console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:01:02.394693
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit tests for logging_redirect_tqdm."""

    import logging
    from tqdm import trange
    log_level = logging.INFO
    logging.basicConfig(level=log_level)
    LOG = logging.getLogger(__name__)

    # Test that logging_redirect_tqdm() redirects console logging to `tqdm.write()`
    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

    # Check that logging_redirect_tqdm() still works with custom loggers
    custom_logger = logging.getLogger("tqdm_tests.test_logging_redirect_tqdm")
    custom_

# Generated at 2022-06-22 05:01:13.158381
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = []
    with tqdm_logging_redirect() as pbar:
        with open('a.txt', 'w') as f:
            logging.basicConfig()
            loggers.append(logging.getLogger())
            for _ in range(8):
                f.write('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')
                pbar.update(1)
            loggers.append(logging.getLogger())
            for _ in range(8):
                f.write('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')
                pbar.update(1)
    assert loggers[0].handlers != loggers[1].handlers

# Generated at 2022-06-22 05:01:20.118513
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tedana import logging
    tqdm_logger = logging.getLogger('tqdmLogging')
    tqdm_logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_logger.addHandler(tqdm_handler)
    tqdm_logger.debug('Test')

# Generated at 2022-06-22 05:01:24.733756
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    log = logging.getLogger(__name__)

    stream = logging.StreamHandler()
    stream.setLevel(logging.DEBUG)
    log.addHandler(stream)

    with logging_redirect_tqdm():
        log.debug('Hi!')


# Generated at 2022-06-22 05:01:31.300749
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from io import StringIO
    from contextlib import redirect_stdout

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        f = StringIO()
        with redirect_stdout(f):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:01:33.246871
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:01:41.970532
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = _TqdmLoggingHandler()
    logger._name = 'test_logger'
    logger_record = logging.LogRecord(name='test',
                                      level=logging.ERROR,
                                      pathname='/',
                                      lineno=21,
                                      msg='I am a test',
                                      args=(),
                                      exc_info=None)
    logger.emit(logger_record)
    assert logger_record.__dict__  == logger_record.__dict__

# Generated at 2022-06-22 05:01:48.872602
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def verbosep_test():
        verbosep(level=0)
        verbosep(level=1)
        verbosep(level=2)
        verbosep(level=3)

    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    logger = logging.getLogger()

    with tqdm_logging_redirect(loggers=[logger], tqdm_class=tqdm):
        verbosep_test()

    with tqdm_logging_redirect(loggers=[logger], tqdm_class=tqdm, mininterval=0.1):
        verbosep_test()


# Generated at 2022-06-22 05:01:57.499744
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from .logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        print("logging restored")



# Generated at 2022-06-22 05:02:00.043271
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    h = _TqdmLoggingHandler()
    assert h.tqdm_class is std_tqdm



# Generated at 2022-06-22 05:02:22.769505
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    # verbosity = 2 -> should fail
    # verbosity = 3 -> should fail
    # verbosity = 4 -> should pass
    for i in range(2, 5):
        result = {'passed': False}

# Generated at 2022-06-22 05:02:26.469238
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert (handler.level is logging.NOTSET)
    assert (handler.tqdm_class is std_tqdm)


# Generated at 2022-06-22 05:02:33.948264
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import sys
    import logging

    my_tqdm_class = type('', (object,), {'write': None})

    class MyTqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self, *args, **kwargs):
            super(MyTqdmLoggingHandler, self).__init__(tqdm_class=my_tqdm_class)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    my_tqdm_handler = MyTqdmLoggingHandler()
    logger.addHandler(my_tqdm_handler)
    # Check that stream, format, tqdm_class are set
    assert my_tqdm_handler.stream == sys.stderr
    assert my_tqdm_handler.formatter


# Generated at 2022-06-22 05:02:43.526875
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for logging_redirect_tqdm
    """
    from ._tqdm_test import TqdmTypeError, _test_write_file, _test_logger
    from ._tqdm_gui import _test_closing
    from ._tqdm_pandas import _test_pandas_bar_desc  # NOQA

    with TqdmTypeError():
        with logging_redirect_tqdm():
            _test_write_file()
    with TqdmTypeError():
        with logging_redirect_tqdm():
            _test_logger()
    with TqdmTypeError():
        with logging_redirect_tqdm():
            _test_closing()

# Generated at 2022-06-22 05:02:54.892076
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io

    class FakeTqdm(object):
        write = staticmethod(lambda x, **kwargs: None)

    # Newline at end of string
    m = io.StringIO(newline='\n')
    h = _TqdmLoggingHandler(FakeTqdm)
    h.stream = m
    r = logging.LogRecord(
        'foo', logging.INFO, None, None, 'bar\n', None, None)
    h.emit(r)
    assert m.getvalue() == 'bar\n'

    # Newline at end of string except last char
    m = io.StringIO(newline='\n')
    h = _TqdmLoggingHandler(FakeTqdm)
    h.stream = m

# Generated at 2022-06-22 05:02:58.880581
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig(level=logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    logging.info('This is a test message')

# Generated at 2022-06-22 05:03:08.512952
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import re
    import six
    import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(loggers=[logging.getLogger('test')]) as pbar:
        logging.getLogger('test').warn('ETA: %s', pbar.n)

    with tqdm_logging_redirect(loggers=[logging.getLogger('test')]) as pbar:
        logging.getLogger('test').warn('ETA: %s', pbar.n)

    with tqdm_logging_redirect(loggers=[logging.getLogger('test')]) as pbar:
        logging.getLogger('test').warn('ETA: %s', pbar.n)


# Generated at 2022-06-22 05:03:17.983445
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9) as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:03:27.961173
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import closing, capture_stdout
    from .std import io, io_tqdm
    for _tqdm_class, _io_class, _io_tqdm_class in [
            (std_tqdm, io, io_tqdm),
            (std_tqdm, io, io_tqdm),
    ]:
        test_str = 'test'
        with closing(capture_stdout(True)) as captured:
            with tqdm_logging_redirect(
                    test_str,
                    ascii=True,
                    total=10,
                    # loggers=[logging.root],
                    tqdm_class=_tqdm_class,
            ) as _pbar:
                logging.info('redirected: ' + test_str)
        assert test

# Generated at 2022-06-22 05:03:28.833588
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-22 05:04:01.590871
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-22 05:04:08.602273
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO

    class _FakeTqdm(object):
        write = lambda *a, **kw: None  # NOQA

    tqdm_handler = _TqdmLoggingHandler(_FakeTqdm)
    tqdm_handler.stream = StringIO()

    # test UnicodeEncodeError
    record = logging.LogRecord(
        name='root', level=1, pathname='/', lineno=1, msg='test', args=None,
        exc_info=None)
    tqdm_handler.setFormatter(logging.Formatter(
        fmt='%(levelname)s %(message)s'))
    tqdm_handler.emit(record)



# Generated at 2022-06-22 05:04:14.667015
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm.std import tqdm as std_tqdm
    my_tqdm_logging_handler = _TqdmLoggingHandler()

    # Check if the default behavior is to use the same class
    # as the default tqdm package from tqdm.std
    assert my_tqdm_logging_handler.tqdm_class is std_tqdm


# Generated at 2022-06-22 05:04:17.356605
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tgrange
    with logging_redirect_tqdm():
        for i in tgrange(10):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:04:22.126289
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            if i == 5:
                LOG.info("logging_redirect_tqdm functionality restored")

# Generated at 2022-06-22 05:04:30.125535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with logging_redirect_tqdm(loggers=loggers):
        LOG = logging.getLogger(__name__)
        LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert (loggers == original_handlers_list)


# Generated at 2022-06-22 05:04:32.020669
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_class = std_tqdm
    loggers = [logging.root]  # type: List[logging.Logger]
    with tqdm_logging_redirect(
        tqdm_class=tqdm_class,
        loggers=loggers,
    ):
        pass


# Generated at 2022-06-22 05:04:43.716775
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from .tqdm import tqdm
    from .tqdm import trange

    try:
        from contextlib import ExitStack
    except ImportError:
        from contextlib2 import ExitStack

    with ExitStack() as stack:
        # Setup logging
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)

        stdout_handler = logging.StreamHandler(stream=sys.stdout)
        stdout_handler.setLevel(logging.INFO)
        root_logger.addHandler(stdout_handler)

        output_file = stack.enter_context(
            open("tqdm_logging_redirect_function_testcase.txt", "w"))
        file_handler = logging.StreamHandler(stream=output_file)

# Generated at 2022-06-22 05:04:53.916454
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test for function logging_redirect_tqdm."""
    LOG = logging.getLogger(__name__)
    LOG.handlers = []
    # import pylint
    # pylint: disable=all,no-member
    logging.basicConfig(format="%(message)s")
    try:
        with logging_redirect_tqdm():
            LOG.info("message")
        assert False, "Should not get here"
    except AssertionError:
        pass
    except SystemExit:
        pass
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-22 05:04:55.728067
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:05:51.906111
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    class _TqdmTestLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            self.messages = []
            super(_TqdmLoggingHandler, self).__init__()
        def emit(self, record):
            try:
                msg = self.format(record)
                self.messages.append(msg)
            except:
                self.handleError(record)
    tqdm_handler = _TqdmTestLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.addHandler(tqdm_handler)

    logger.critical('critical message')
    logger.error('error message')
    logger.warning('warning message')
    logger.info('info message') # Only messages above level INFO are handled

# Generated at 2022-06-22 05:05:54.135131
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert(handler.tqdm_class == std_tqdm)

# Generated at 2022-06-22 05:05:59.284244
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with _TqdmLoggingHandler() as hndlr:
        assert isinstance(hndlr.tqdm_class, type)
    assert hndlr.tqdm_class is std_tqdm



# Generated at 2022-06-22 05:06:07.638026
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with std_tqdm(total=3) as pbar:
        pbar.write("")
        assert pbar.n == 1

        handler = _TqdmLoggingHandler(std_tqdm)
        handler.emit(logging.LogRecord('tqdm', 'DEBUG', 'tqdm.py', 1, 'test'))
        assert pbar.n == 2

        # default stream is sys.stdout
        handler2 = _TqdmLoggingHandler(std_tqdm)
        handler2.emit(logging.LogRecord('tqdm', 'DEBUG', 'tqdm.py', 1, 'test'))
        assert pbar.n == 3

