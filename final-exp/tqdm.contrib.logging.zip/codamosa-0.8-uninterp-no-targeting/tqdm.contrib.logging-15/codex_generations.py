

# Generated at 2022-06-22 04:56:25.294655
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=100, desc='Unit test') as pbar:
        for i in range(100):
            pbar.update()
            if i == 50:
                LOG.info('console logging redirected to `tqdm.write()`')
    # assert pbar.unit_scale == 'B'
    assert pbar.unit == 'it'

# For backwards compatibility
tqdm_logging_handler = _TqdmLoggingHandler
tqdm_logging = tqdm_logging_redirect

# Generated at 2022-06-22 04:56:36.491389
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger_instance = logging.getLogger(__name__)
    streamHandler = logging.StreamHandler()
    formatter = logging.Formatter(
        fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    streamHandler.setFormatter(formatter)
    logger_instance.addHandler(streamHandler)

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    buffer = StringIO()
    logger_instance.info('info message')
    result = buffer.getvalue()
    expected_result = 'INFO:__main__:info message\n'
    assert result == expected_result

# Generated at 2022-06-22 04:56:39.760001
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(unit_scale=True, total=10**3) as pbar:
        for _ in range(10**3):
            pbar.update()

# Generated at 2022-06-22 04:56:45.934307
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored
    # tqdm.write("Test line")

# Generated at 2022-06-22 04:56:56.501786
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc="Test", leave=True) as pbar:
        pbar.update(10)
        pbar.write("hi !")
        logging.info("console logging redirected to `tqdm.write()`")
    print("\nTesting non-global redirect:")
    LOG = logging.getLogger("non-global")
    with tqdm_logging_redirect(loggers=[LOG], desc="Test2", leave=True) as pbar:
        pbar.update(10)
        pbar.write("hi !")
        LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_tqdm_logging_redirect

# Generated at 2022-06-22 04:57:02.154160
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm

    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    record = logging.LogRecord('name', level=logging.INFO,  # pylint: disable=unused-variable
                               fn='filename', lno=1, msg='msg',
                               args=[], exc_info=None)
    handler.emit(record)
    tqdm.close()

# Generated at 2022-06-22 04:57:08.540283
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=100, desc='test_tqdm_logging_redirect',
                               loggers=[logging.getLogger()],
                               tqdm_class=std_tqdm) as pbar:
        pbar.update(50)
        logging.info('foobar')
        pbar.update(50)

# Generated at 2022-06-22 04:57:18.584965
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    import logging
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from tqdm.contrib.logging import logging_redirect_tqdm


    logger = logging.getLogger(__name__)

    with patch(
        'sys.stdout', new_callable=lambda: sys.stdout
    ) as stdout:
        with logging_redirect_tqdm():
            logger.info("console logging redirected to `tqdm.write()`")
            assert len(stdout.method_calls) == 1
            _, (message,), _ = stdout.method_calls[0]
            assert message == "console logging redirected to `tqdm.write()`\n"



# Generated at 2022-06-22 04:57:24.943309
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .misc import _range

    with tqdm_logging_redirect(total=9, ncols=80) as pbar:
        for i in _range(9):
            if i == 4:
                logging.info('console logging redirected to `tqdm.write()`')


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 04:57:35.726659
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tnrange

    with tnrange(100) as pbar:
        logging.captureWarnings(True)
        log = logging.getLogger('test')
        formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
        handler = _TqdmLoggingHandler()
        handler.setFormatter(formatter)
        log.addHandler(handler)
        log.setLevel(logging.DEBUG)
        log.debug('test debug')
        log.info('test info')
        log.warning('test warning')
        log.error('test error')
        log.critical('test critical')

# Generated at 2022-06-22 04:57:54.648849
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in range(5,9):
        LOG.info("Note this got logged, just not in the tqdm bar")
# test_logging_redirect_tqdm()


# Generated at 2022-06-22 04:58:05.148835
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from contextlib import contextmanager
    from tqdm import trange

    @contextmanager
    def _tqdm():
        yield

    @contextmanager
    def _logging_redirect_tqdm(*args, **kwargs):
        yield

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=9, unit='it', disable=None):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 04:58:08.282243
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    th = _TqdmLoggingHandler()
    th.setLevel(logging.WARNING)
    assert th.tqdm_class == std_tqdm

# Generated at 2022-06-22 04:58:20.192829
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    console_handler = logging.StreamHandler()
    tqdm_handler = _TqdmLoggingHandler()
    msg = "test message"
    tqdm_handler.setFormatter(console_handler.formatter)
    tqdm_handler.stream = console_handler.stream

# Generated at 2022-06-22 04:58:27.874354
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.auto import tqdm

    class TqdmLoggingHandler(logging.StreamHandler):
        def __init__(
            self,
            tqdm_class=std_tqdm  # type: Type[std_tqdm]
        ):
            super(TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class

        def emit(self, record):
            try:
                msg = self.format(record)
                self.tqdm_class.write(msg, file=self.stream)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise

# Generated at 2022-06-22 04:58:32.848834
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:58:38.741277
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=5, loggers=(LOG,), desc="test") as pbar:
        for i in range(5):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-22 04:58:44.684060
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)

    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        for i in pbar(range(5)):
            if i == 3:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:58:52.617008
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test for _TqdmLoggingHandler class.
    """
    import logging
    import io
    import os
    import tempfile

    # Create temp dir
    # https://stackoverflow.com/questions/19296146/tempfile-temporarydirectory-context-manager-in-python-3
    td = tempfile.TemporaryDirectory()
    os.chdir(td.name)

    # Create temp file
    log_fname = "temp_TqdmLoggingHandler.log"
    logging.basicConfig(filename=log_fname, filemode="w")

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    log_handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 04:59:00.873027
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.contrib import io
    from io import StringIO

    test_string = 'test_string'
    buf = StringIO()
    h = _TqdmLoggingHandler(tqdm_class=io)
    h.stream = buf
    record = logging.LogRecord(
        'logger', logging.INFO, 'path.py', 'lineno', test_string,
        [], "stack"
    )
    h.emit(record)
    assert buf.getvalue().rstrip() == test_string

# Generated at 2022-06-22 04:59:15.170327
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:59:22.095227
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        from tqdm.auto import tqdm
    except ImportError:
        from tqdm import tqdm
    from tqdm.contrib.logging import _is_console_logging_handler

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(4)):
            if i == 2:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored

    assert not any(_is_console_logging_handler(h) for h in logging.root.handlers)
    assert any(isinstance(h, logging.StreamHandler) for h in logging.root.handlers)
    # logging.root.handlers  # doctest: +

# Generated at 2022-06-22 04:59:24.923634
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    with tqdm_logging_redirect(["test"], tqdm_class=std_tqdm) as pbar:
        assert type(pbar) == std_tqdm

# Generated at 2022-06-22 04:59:36.610931
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import shutil
    import tempfile
    from tqdm.contrib import sample
    with tempfile.NamedTemporaryFile() as fp:
        file_name = fp.name
        with sample.tqdm_logging_redirect(
            file_name,
            loggers=[logging.root],
            tqdm_class=sample.TqdmDefaultWrite
        ):
            with open(file_name, 'rb') as fp:
                assert fp.read() == b''
            for i in range(2):
                logging.info('hello world!')
            with open(file_name, 'rb') as fp:
                assert fp.read() == b'hello world!\nhello world!\n'

# Generated at 2022-06-22 04:59:37.934344
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler

# Generated at 2022-06-22 04:59:47.416552
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test method emit of class _TqdmLoggingHandler.
    """
    import io

    # Simple test
    test_log_string = "test log string"
    test_out = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler()
    with tqdm_handler.tqdm_class(file=test_out) as t:
        tqdm_handler.tqdm_class = t.__class__
        tqdm_handler.stream = test_out
        tqdm_handler.emit(test_log_string)
        tqdm_handler.flush()
    assert test_out.getvalue() == test_log_string + '\n'

    # Test with args

# Generated at 2022-06-22 04:59:49.098296
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    my_class = _TqdmLoggingHandler()


# Generated at 2022-06-22 05:00:00.610109
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    def _run_test(tqdm_class, expected_output):
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with tqdm_logging_redirect(
                total=9,
                tqdm_class=tqdm_class,
            ) as pbar:
                for i in range(9):
                    pbar.update()
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:12.690845
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import pandas as pd
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm
    test_logging_message = "console logging redirected to `tqdm.write()`"
    LOG = logging.getLogger('tqdm_logging_redirect_test')
    # use with tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            desc='with tqdm_logging_redirect',
            loggers=[LOG]
            ) as pbar:
        for i in pd.np.arange(4):
            if i == 0:
                pbar.write(test_logging_message) # first use pbar.

# Generated at 2022-06-22 05:00:21.782544
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    try:  # Test
        logger.info("Test: TqdmLoggingHandler")
    except:  # noqa pylint: disable=bare-except
        # This raise an exception if the test fail.
        raise Exception("Test fail")

# Generated at 2022-06-22 05:00:44.833874
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = logging.getLogger('tqdm')
    handlers = logging.StreamHandler()
    loggers.addHandler(handlers)
    with tqdm_logging_redirect(loggers=loggers, tqdm_class=std_tqdm) as pbar:
        loggers.critical('Testing')

# Generated at 2022-06-22 05:00:50.545653
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from logging import getLogger
    logger = getLogger('logging_test')
    logger.setLevel(logging.INFO)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info('logging')
    # pass


# Generated at 2022-06-22 05:00:55.265700
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger('test')
    with logging_redirect_tqdm():
        LOG.info("hello world")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:01:02.407454
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test `logging_redirect_tqdm()` function.
    """
    import logging
    from tqdm import tqdm, trange, tnrange

    # Initialize test logger
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    # Test raw logging
    with logging_redirect_tqdm():
        LOG.info("Test logging")
        trange(1)

    # Test tqdm.write()
    with logging_redirect_tqdm():
        tqdm.write("Test tqdm.write()")
        trange(1)

    # Test exceptions
    try:
        LOG.exception("Test 1")
    except Exception:
        LOG.exception("Test 2")

   

# Generated at 2022-06-22 05:01:09.429848
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10, desc='hello', ncols=130) as pbar:
        assert pbar.position == 0
        for _ in range(10):
            logging.info('world')
            pbar.update()
        assert pbar.position == 11


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 05:01:17.884057
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # We should be able to pass the test with minimal changes
    # to the original code (i.e. without changes in try-except blocks).
    class TestTqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            super(TestTqdmLoggingHandler, self).__init__()
            self.exc_info = None
            self.formatted_record = None
            self.record = None
            self.stream = None
            self.exc_info_call_count = 0
            self.handleError_call_count = 0


# Generated at 2022-06-22 05:01:27.182477
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import io  # python 3
        sys.stdout = io.StringIO()  # type: ignore
        sys.stderr = io.StringIO()  # type: ignore
    except ImportError:
        import StringIO
        sys.stdout = StringIO.StringIO()
        sys.stderr = StringIO.StringIO()

    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:01:37.529098
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from six import StringIO
    from io import open
    my_tqdm = std_tqdm
    # Hack the built-in class to make it easier to test
    # (and to save typing)
    my_tqdm.write = lambda msg, file=sys.stderr, end="\n", nolock=False: file.write(
        msg + end)
    with open(u"/dev/null", "w") as f:
        my_tqdm.file_handler = f
    my_tqdm.file_like = my_tqdm.file_handler.fileno
    with open(u"/dev/null", "w") as f:
        my_tqdm.messages_queue = f
    # END OF HACK

    # Set up the basic configuration (actually it is the default

# Generated at 2022-06-22 05:01:44.726341
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO  # py2
    except ImportError:
        from io import StringIO  # py3

    import logging
    import sys

    class TqdmLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            self.stream = StringIO()
            super(TqdmLoggingHandler, self).__init__()

    tqdm_logging_handler = TqdmLoggingHandler()
    stdout_logging_handler = logging.StreamHandler(sys.stdout)
    record = logging.LogRecord('name', logging.DEBUG, 'pathname', 1, 'msg', None, None)
    tqdm_logging_handler.emit(record)
    stdout_logging_handler.emit(record)
    assert tqdm_logging_

# Generated at 2022-06-22 05:01:49.215390
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    try:
        from unittest.mock import patch
    except ImportError:  # Py2
        from mock import patch  # type: ignore

    LOG = logging.getLogger(__name__)

    with patch('sys.stdout', new=open(os.devnull, 'w')):
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-22 05:02:33.473067
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-22 05:02:40.282549
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    import logging
    MSG = "Test output"
    msg_stream = MSG + "\n"
    # Non ASCII encoding
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    record = logging.makeLogRecord({"msg": MSG})
    tqdm.write = lambda msg, file=None, end=None: print(msg.encode('utf8'))
    handler.emit(record)
    assert msg_stream == sys.stdout.getvalue()

# Generated at 2022-06-22 05:02:46.884491
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger()
    with tqdm_logging_redirect(logging_format='{message}',
                               disable=False,
                               loggers=[logger]) as pbar:
        logger.info('some message')
        logger.info('another message')
        logger.info('yet another message')
        pbar.update(8)



# Generated at 2022-06-22 05:02:54.771062
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(100) as pbar:
            for i in range(9):
                pbar.update()
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:03:05.628363
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in trange(9, desc="Test", bar_format="{desc}: {n_fmt}", unit="%", postfix={"T": 42, "X": 26}):
                pbar.update()
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:03:13.410483
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(std_tqdm)
    formatter = logging.Formatter('%(levelname)s:%(message)s')
    handler.setFormatter(formatter)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.critical('critical')
    logger.error('error')
    logger.warning('warning')
    logger.info('info')


# Generated at 2022-06-22 05:03:20.387203
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=10):
            for _ in range(5):
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:03:27.772864
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import subprocess
    import unittest

    # command run
    with unittest.mock.patch("subprocess.check_output") as mock_subprocess_check_output:
        mock_subprocess_check_output.return_value = b"a" * 1000
        # needed to check that the exception does not propagate
        with unittest.mock.patch("tqdm.auto.tqdm.stderr") as mock_stderr:
            mock_stderr.isatty.return_value = True  # type: ignore
            subprocess.check_output("true")

    # get log record
    thandler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:03:37.938631
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    test unit for function tqdm_logging_redirect
    """
    # pylint: disable=protected-access

    # import local packages
    from ..std import tqdm

    def get_pbar_sm(pbar):
        # type: (tqdm.tqdm) -> List[str]
        """
        get settings of tqdm
        """
        return pbar._smoothing, pbar._dynamic_ncols, pbar._last_len  # pylint: disable=W0212

    def get_pbar_options(pbar):
        # type: (tqdm.tqdm) -> tqdm.tqdm._Monitor
        """
        get settings of tqdm
        """
        return pbar._monitor  # p

# Generated at 2022-06-22 05:03:44.405069
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger('test')
    loggers = [logging.root, LOG]
    with logging_redirect_tqdm(loggers=loggers):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:05:22.025792
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .tqdm_class import tqdm
    from logging import getLogger, StreamHandler, StreamHandler
    import sys

    tqdm_class = tqdm
    # tqdm_class = tqdm.std.tqdm
    with tqdm(range(5)) as t:
        # dt = _TqdmLoggingHandler(tqdm_class)
        # dt = _TqdmLoggingHandler(tqdm_class=tqdm_class)
        dt = _TqdmLoggingHandler(tqdm_class=tqdm_class)
        logger = getLogger("foo")
        sh = StreamHandler(sys.stderr)
        print(dir(sh))
        print(dir(dt))
        print(dir(logger))

# Generated at 2022-06-22 05:05:30.010223
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    with StringIO() as s, tqdm_logging_redirect(
            file=s, total=10, miniters=0, mininterval=0):
        LOG.info('test')

    assert 'test' in s.getvalue()

# Generated at 2022-06-22 05:05:41.697499
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    from io import StringIO
    import sys


    # Mocking the logger
    class _MockLoggingHandler(logging.Handler):
        def __init__(self):
            super(_MockLoggingHandler, self).__init__()
            self.pbar = None

        def emit(self, record):
            self.pbar.write(record.msg)


    mock_handler = _MockLoggingHandler()


# Generated at 2022-06-22 05:05:52.009206
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import TestHandler
    from .tqdm import tqdm

    test_logger = logging.getLogger(__name__)
    test_logger.propagate = False
    test_logger.addHandler(TestHandler())
    with tqdm(total=10) as pbar:
        with logging_redirect_tqdm(loggers=[test_logger, logging.getLogger()]):
            test_logger.info("This should be written to the test handler")
            pbar.write("This should be written to the `tqdm` progress bar")
            test_logger.info("This should be written to the test handler")
    assert pbar.n == 10
    assert len(test_logger.handlers) == 1
    handler = test_logger.handlers[0]
   

# Generated at 2022-06-22 05:05:58.310500
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    for i in trange(9):
        if i == 4:
            logging.info("This was redirected to tqdm.write()")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:05:59.764199
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .std import tqdm
    obj = _TqdmLoggingHandler(tqdm_class = tqdm)
    assert(obj.tqdm_class == tqdm)
    return

# Generated at 2022-06-22 05:06:08.651384
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm
    import logging

    # define a logger
    LOG = logging.getLogger(__name__)
    LOG.setLevel(level=logging.DEBUG)

    with tqdm_logging_redirect():
        for i in tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # Now test the context manager
    with tqdm_logging_redirect():
        for i in tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:06:10.482005
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    log_handler = _TqdmLoggingHandler()
    logging.root.handlers = [log_handler]
    logging.info('test log.')