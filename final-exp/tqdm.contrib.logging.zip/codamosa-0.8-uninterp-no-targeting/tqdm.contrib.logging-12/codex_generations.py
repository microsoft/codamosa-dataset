

# Generated at 2022-06-22 04:56:15.013008
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(None) is not None


# Generated at 2022-06-22 04:56:19.211026
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
    LOG.info("console logging restored to sys")

# Generated at 2022-06-22 04:56:22.435224
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class is std_tqdm
    assert isinstance(handler, logging.StreamHandler)

# Generated at 2022-06-22 04:56:31.755066
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    if 'tqdm.contrib.logging' not in sys.modules:
        # We are in a CIs, skip this test
        return

    logging.getLogger().setLevel(logging.INFO)

    from tqdm import tqdm

    def my_class(iterable, *args, **kwargs):
        for i in iterable:
            yield i

    for _i in tqdm_logging_redirect(
            range(5),
            desc='Logging test',
            smoothing=0,
            loggers=[logging.getLogger()],
    ):
        # The next two lines act as the test:
        # 1. logging.info("Test message")
        # 2. The progress bar is smooth
        assert not _i
        logging.info("Test message")

# Generated at 2022-06-22 04:56:40.441743
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Capturing stdout output is inspired by
    http://stackoverflow.com/questions/4219717/how-to-assert-output-with-nosetest-unittest-in-python/
    """
    import sys
    from io import StringIO

    output = StringIO()
    sys.stdout = output

    logging.root.handlers = []
    tqdm_handler = _TqdmLoggingHandler()
    logging.root.handlers = [tqdm_handler]
    logging.root.setLevel(logging.DEBUG)
    logging.debug("test")

    sys.stdout = sys.__stdout__
    assert output.getvalue() == "test\n"

# Generated at 2022-06-22 04:56:45.632317
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger('my_logger')]
    with tqdm_logging_redirect(loggers=loggers, total=3) as pbar:
        for i in range(3):
            loggers[0].info('My message')
            pbar.update()

# Generated at 2022-06-22 04:56:55.120456
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    fake_stdout = StringIO()
    fake_stderr = StringIO()

    # make sure we can overwrite stdout/stderr
    sys.stdout = fake_stdout
    sys.stderr = fake_stderr

    # make sure we now output to those
    print('Hello world', file=sys.stdout)
    print('Hello error', file=sys.stderr)

    fake_stdout.seek(0)
    fake_stderr.seek(0)
    assert fake_stdout.read() == 'Hello world\n'
    assert fake_stderr.read() == 'Hello error\n'



# Generated at 2022-06-22 04:57:03.862310
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # A class with a constant stream to which to write
    class MockTqdm(std_tqdm):
        stream = 'stream'
        def write(self, *args, **kwargs):
            print(args)
    # A class with a stream with a write attribute
    class MockTqdm2(std_tqdm):
        stream = lambda self: None
        stream.write = 'stream'
        def write(self, *args, **kwargs):
            print(args)

    handler = _TqdmLoggingHandler(MockTqdm)

    message = 'message'

    # Test with stream constant
    assert handler.stream == 'stream'
    handler.emit(message)
    assert handler.stream == 'stream'
    handler = _TqdmLoggingHandler(MockTqdm2)

   

# Generated at 2022-06-22 04:57:16.129335
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm as std_tqdm


# Generated at 2022-06-22 04:57:25.617716
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(tqdm_class = std_tqdm)
    print(isinstance(handler,logging.StreamHandler))
    print(handler.stream in {sys.stdout, sys.stderr})
    try:
        msg = handler.format(logging.record)
        handler.tqdm_class.write(msg, file=handler.stream)
        handler.flush()
    except Exception as e:
        handler.handleError(logging.record)
    print('test for _TqdmLoggingHandler is complete!')



# Generated at 2022-06-22 04:57:42.001928
# Unit test for method emit of class _TqdmLoggingHandler

# Generated at 2022-06-22 04:57:48.461011
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    lh = _TqdmLoggingHandler()
    lh.stream = sys.stdout
    lh.setFormatter(logging.Formatter('\n' + '%(levelname) -8s: %(message)s'))
    lh.emit(logging.LogRecord('root', logging.INFO, '', 0,
                              'Test Message'))

# Generated at 2022-06-22 04:57:56.172817
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from .utils import closing

    logger = logging.getLogger(__name__)

    with closing(patch('sys.stdout', new=None)) as stdout:
        logging_redirect_tqdm()
        assert list(logger.handlers) == []

    with closing(patch('sys.stdout')) as stdout:
        with closing(patch('sys.stderr')) as stderr:
            with closing(patch('tqdm.tqdm.write')) as tqdm_write:

                logger.setLevel(logging.INFO)

                formatter = logging.Formatter('[%(asctime)s] %(message)s')
                stream_handler = logging.StreamHandler

# Generated at 2022-06-22 04:58:02.519045
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Tests `tqdm_logging_redirect` and `logging_redirect_tqdm` via
    `tqdm.contrib.logging.test_tqdm_logging_redirect`.
    """
    pass


if __name__ == '__main__':
    test_tqdm_logging_redirect()
    print('test_tqdm_logging_redirect passed successfully')

# Generated at 2022-06-22 04:58:14.410335
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    # test: file not named console
    logger = logging.getLogger()
    logger.addHandler(logging.FileHandler('example_log.txt'))
    logger.setLevel(logging.INFO)
    for i in tqdm_logging_redirect(range(5)):
        logger.info(str(i))

    # test: file named console
    logger = logging.getLogger()
    logger.handlers = []
    logger.addHandler(logging.FileHandler('console'))
    logger.setLevel(logging.INFO)
    for i in tqdm_logging_redirect(range(5)):
        logger.info(str(i))

    # test: no file
   

# Generated at 2022-06-22 04:58:26.471524
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    import io
    import warnings

    warnings.filterwarnings("ignore")
    log_string_io = io.StringIO()
    log = logging.getLogger("Test Logger")
    log.setLevel(logging.DEBUG)
    log.propagate = False
    log.handlers = [logging.StreamHandler(log_string_io)]

    with tqdm_logging_redirect(
        total=10, logger=log, gauge_width=1,
    ) as pbar:
        time.sleep(0.01)
        log.info("we are logging")
        time.sleep(0.01)
        for i in range(9):
            log.info("we are logging %i", i)
            time.sleep(0.01)
            pbar.update()



# Generated at 2022-06-22 04:58:31.305766
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    with tqdm.tqdm_logging_redirect() as pbar:
        logging.info("console logging redirected to `tqdm.write()`")
        assert pbar is not None
        pbar.update()
        pbar.close()
        logging.info("hello")



# Generated at 2022-06-22 04:58:43.273531
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    import unittest

    class TqdmLoggingHandlerTest(unittest.TestCase):
        def testLoggingHandler(self):
            logger = logging.getLogger('test')

            self.assertFalse(logger.hasHandlers())

            # Test custom logging handler
            tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
            logger.addHandler(tqdm_handler)

            logger.warning('Test warning')

            self.assertTrue(_is_console_logging_handler(tqdm_handler))
            self.assertTrue(logger.hasHandlers())

            # Test of logging initialization from `logging` itself
            logger.removeHandler(tqdm_handler)
            logger.handlers = []

            logging.basic

# Generated at 2022-06-22 04:58:46.524407
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger(__name__)]
    with tqdm_logging_redirect(loggers=loggers, title='title',
                               desc='desc', bar_format='bar_format'):
        pass

# Generated at 2022-06-22 04:58:58.646264
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up
    from tqdm.std import tqdm
    logger = logging.getLogger(__name__)
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    logger.handlers = [tqdm_handler]
    logger.info('1')
    with logging_redirect_tqdm():
        for i in tqdm(range(3)):
            logger.info(str(i))
    assert tqdm.write.get_lock()._count > 0, 'tqdm_handler did not write anything'
    try:
        with logging_redirect_tqdm():
            logger.info('2')
    except KeyboardInterrupt:
        pass
    assert tqdm.write.get_lock

# Generated at 2022-06-22 04:59:19.776312
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO

    class TqdmStream(StringIO):
        def write(self, s):
            super(TqdmStream, self).write(s)

        @property
        def closed(self):
            return False

    stream = TqdmStream()
    logger = logging.Logger('test')
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    handler.setLevel(logging.DEBUG)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug('message 1')
    assert stream.buflist == ["message 1\n"]

    logger.debug('message 2')
    assert stream.buflist == ["message 1\n", "message 2\n"]

# Generated at 2022-06-22 04:59:21.612142
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert tqdm_logging_handler

# Generated at 2022-06-22 04:59:32.157917
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Unit test for method emit of class _TqdmLoggingHandler."""
    class TestTqdm(object):
        """Emit test class."""

        @classmethod
        def write(cls, msg, file=None):
            # type: (str, Optional[str]) -> None
            if file:
                file.write('test')

    def _test():
        # type: () -> None
        tqdm_handler = _TqdmLoggingHandler(tqdm_class=TestTqdm)
        tqdm_handler.stream = sys.stdout
        tqdm_handler.emit('test')
        assert sys.stdout.getvalue() == 'test'

    sys.stdout = open('sys_stdout.txt', 'w')
    _test()


# Generated at 2022-06-22 04:59:38.536305
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        name='foo',
        level=logging.DEBUG,
        pathname='foo.py',
        lineno=42,
        msg='foo message',
        args=(),
        exc_info=None,
    )
    std_tqdm.write = lambda msg: None
    handler.emit(record)

# Generated at 2022-06-22 04:59:47.774643
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pylint: disable=invalid-name
    from tqdm.auto import trange
    from .pandas import tqdm_pandas  # noqa
    from .ipython import tqdm_ipython  # noqa
    from .keras import tqdm_keras  # noqa
    from .sqlalchemy import tqdm_sqlalchemy  # noqa

    import pandas as pd
    import numpy as np
    import keras
    import sqlalchemy as sa

    pbar_classes = [std_tqdm]  # type: List[Type[std_tqdm]]
    try:
        import pandas as pd
        pbar_classes.append(tqdm_pandas)
    except ImportError:
        pass

# Generated at 2022-06-22 04:59:52.022360
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)
    assert isinstance(_TqdmLoggingHandler(tqdm_class=std_tqdm), _TqdmLoggingHandler)



# Generated at 2022-06-22 04:59:58.432294
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    capture_logger = logging.getLogger()
    capture_logger.setLevel(logging.INFO)
    capture_handler = _TqdmLoggingHandler()
    capture_logger.handlers = [capture_handler]

    logging.info('test')
    sys.stdout.seek(0)
    assert sys.stdout.read() == '[ INFO] test\n'

# Generated at 2022-06-22 05:00:01.302062
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_main import _test_logging_redirect_tqdm
    _test_logging_redirect_tqdm(std_tqdm, logging_redirect_tqdm)

# Generated at 2022-06-22 05:00:07.282192
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    from contextlib import contextmanager

    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    # type checking
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}



# Generated at 2022-06-22 05:00:10.782797
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)
    assert isinstance(_TqdmLoggingHandler(std_tqdm), _TqdmLoggingHandler)


# Generated at 2022-06-22 05:00:36.947073
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in std_tqdm(range(3)):
            if i == 1:
                LOG.info("Hello")


# Generated at 2022-06-22 05:00:45.993503
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class FakeTqdm(object):
        def __init__(self):
            self.msg = ''

        def write(self, msg, file):
            self.msg = msg

    class FakeLogger(object):
        def __init__(self):
            self.msg = ''
            # noqa: E501
            self.error = lambda msg, *args, **kwargs: setattr(self, 'msg', msg)

    logger = FakeLogger()
    tqdm = FakeTqdm()
    h_tqdm = _TqdmLoggingHandler(tqdm_class=FakeTqdm)
    h_tqdm.stream = sys.stdout
    record = logging.LogRecord(
        "name", logging.INFO, "pathname", 1, "msg", None, None)
    h_tq

# Generated at 2022-06-22 05:00:56.885163
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.tests_tqdm import _RandomIO
    log_msg = "Lorem ipsum dolor sit amet"
    record = logging.LogRecord(
        name=__name__,
        level=logging.INFO,
        pathname=__file__,
        lineno=0,
        msg=log_msg,
        args=None,
        exc_info=None,
    )
    with _RandomIO(encoding='utf-8') as stream:
        handler = _TqdmLoggingHandler(stream=stream)
        handler.emit(record)
        # Output is written to the stream
        assert stream.getvalue() == log_msg + '\n'



# Generated at 2022-06-22 05:01:08.589181
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import tempfile
    from ..std import tqdm
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    # create a temporary file to store message
    templog = tempfile.NamedTemporaryFile()
    # create a handler that use tempfile to log
    handler = logging.FileHandler(templog.name)
    handler.setLevel(logging.DEBUG)
    # create a formatter
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.info('info message')
    handler.close()
    tqdm_handler = _TqdmLoggingHandler(tqdm)
    tqdm_handler.setFormatter(formatter)


# Generated at 2022-06-22 05:01:17.458281
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import datetime
    import time

    from .tests_tqdm import StringIO, closing

    with StringIO() as s:  # type: StringIO
        with closing(s), tqdm_logging_redirect(total=5, file=s) as pbar:
            for msg, logger, sleep in [('hello', logging.debug, 0.05),
                                       ('world', logging.info, 0.01)]:
                logger(msg)
                time.sleep(sleep)
                pbar.update()

        # output should be roughly like this

# Generated at 2022-06-22 05:01:23.199596
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-22 05:01:26.080973
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler(std_tqdm)
    assert(tqdm_logging_handler.tqdm_class == std_tqdm)


# Generated at 2022-06-22 05:01:26.985653
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:01:37.299069
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger('test')
    log.setLevel(logging.DEBUG)
    stream = sys.stdout

# Generated at 2022-06-22 05:01:44.553760
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Test logging redirection
    import logging
    from tqdm import trange
    LOG = logging.getLogger()

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

    # Test that logging redirection is restored
    with logging_redirect_tqdm():
        pass

    # Test that logging doesn't break
    # with redirected logging
    with logging_redirect_tqdm():
        LOG.info("test")
        LOG.info("test")
        LOG.info("test")

    # Test that logging handler is correctly snatched

# Generated at 2022-06-22 05:02:34.382622
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    th = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert th.tqdm_class is std_tqdm
    assert isinstance(th, logging.StreamHandler)

# Generated at 2022-06-22 05:02:38.313296
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        assert pbar is None
        logging.info('console logging redirected to tqdm.write()')
    logging.info('logging restored')

# Generated at 2022-06-22 05:02:41.298084
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    assert handler.tqdm_class == tqdm_class


# Generated at 2022-06-22 05:02:53.452313
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger("test_logging_redirect_tqdm")
    if "test_logging_redirect_tqdm" in [logger.name for logger in logging.root.handlers]:
        logging.getLogger("test_logging_redirect_tqdm").handlers = []
        logger_ = logging.getLogger("test_logging_redirect_tqdm")
        logger_.setLevel(logging.DEBUG)
    else:
        logger_ = logging.getLogger("test_logging_redirect_tqdm")
        logger_.propagate = False
        logger_.setLevel(logging.DEBUG)
        handler_ = logging.StreamHandler()
        handler_.setLevel(logging.DEBUG)

# Generated at 2022-06-22 05:02:56.911079
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        logging.debug("first")
    except BaseException:
        pass
    handler_ = _TqdmLoggingHandler()
    record = logging.makeLogRecord({'msg': "second"})
    handler_.emit(record)
    # TODO: check if "second" was written to stdout

# Generated at 2022-06-22 05:03:03.362678
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import getLogger, INFO

    from .compat import PY3

    out_string = StringIO()
    log = getLogger('test')
    log.setLevel(INFO)

    tqdm_logger = _TqdmLoggingHandler(tqdm_class=std_tqdm)  # type: ignore
    tqdm_logger.setLevel(INFO)
    tqdm_logger.setStream(out_string)
    log.addHandler(tqdm_logger)

    log.info('test')
    if PY3:
        assert out_string.getvalue() == 'test\n'
    else:
        assert out_string.getvalue() == 'test\n'



# Generated at 2022-06-22 05:03:11.133609
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)
    try:
        from unittest import mock
    except ImportError:
        import mock

    logging.basicConfig(level=logging.INFO)
    with mock.patch('tqdm.std.tqdm', wraps=std_tqdm) as m:
        with tqdm_logging_redirect(total=9, desc=__name__):
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:03:22.594506
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys
    stream = io.StringIO()  # type: io.StringIO
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    logger.debug('hello')
    sys.stderr.write('hello\n')
    sys.stderr.flush()
    assert stream.getvalue() == 'hello\n'
    stream.close()

# Generated at 2022-06-22 05:03:33.172682
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm._utils import _term_move_up

    class TqdmKwargs(dict):
        def __init__(self, kwargs):
            self.update(kwargs)
            self.file = kwargs.get('file', sys.stderr)

    class TqdmFake(object):
        def __init__(self, tqdm_kwargs=None, **kwargs):
            self.kwargs = tqdm_kwargs if tqdm_kwargs else TqdmKwargs(kwargs)
            # self.n = n
            self.i = 0

        def write(*args, **kwargs):
            tqdm_kwargs = kwargs.get('tqdm_kwargs', TqdmKwargs(kwargs))
            # kwargs['file'].

# Generated at 2022-06-22 05:03:42.838797
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    # pbar = tqdm_notebook(total=100)
    # tqdm_handler = _TqdmLoggingHandler(pbar)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)

    try:
        logger.info('info')
        logger.warning('warning')
        # pbar.close()
    except KeyboardInterrupt:
        logger.exception()
        raise
    finally:
        logger.removeHandler(tqdm_handler)
        # pbar.close()


# Generated at 2022-06-22 05:05:23.511467
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    class MockRecord(object):
        def __init__(self, msg, levelno, exc_info):
            self.msg = msg
            self.levelno = levelno
            self.exc_info = exc_info
            pass
        def __str__(self):
            return self.msg + '-' + str(self.levelno)
    for exc_info in [None, True, False]:
        for msg in ['msg', '']:
            for levelno in [10, 10**10]:
                record = MockRecord(msg, levelno, exc_info)
                handler.emit(record)

# Generated at 2022-06-22 05:05:30.010432
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys

    with tqdm_logging_redirect(total=9) as pbar:
        logging.basicConfig(level=logging.INFO)
        for i in pbar:
            if i == 4:
                logging.info("console logging redirected to "
                             "`tqdm.write()`")
    logger = logging.getLogger()
    assert logger.handlers[0].stream is sys.__stdout__

# Generated at 2022-06-22 05:05:39.607940
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger(__name__)
    logger.addHandler(handler)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.warning('one')
    logger.warning('two')
    handler.emit(logging.LogRecord(
        'name',
        logging.WARNING,
        'pathname',
        1,
        'three',
        (),
        None,
        None
    ))
    assert std_tqdm.write.refresh_state.called == 3

# Generated at 2022-06-22 05:05:41.624639
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    assert("INFO" in tqdm_handler.stream)



# Generated at 2022-06-22 05:05:47.550470
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import redirect_stdout

    with redirect_stdout(None):
        with tqdm_logging_redirect(desc='Progress') as pbar:
            logging.info('info')
            logging.warning('warning')
            pbar.set_description_str('description')
            pbar.refresh()
            logging.error('error')

# Generated at 2022-06-22 05:05:54.301335
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import os

    for loglevel in {logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL}:
        logging.basicConfig(level=loglevel)

        class MockTqdm(object):
            def __init__(self, *args, **kwargs):
                pass

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                pass

            def write(self, msg):
                pass

        with tqdm_logging_redirect(tqdm_class=MockTqdm) as pbar:
            assert(pbar is not None)

# Generated at 2022-06-22 05:06:02.093091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOGGER = logging.getLogger('TEST')
    # Try to overload logging handler to raise exception
    try:
        with logging_redirect_tqdm(loggers=[LOGGER]):
            LOGGER.info('This is test log')
    except IOError:
        pass
    else:
        assert False, 'logging.redirect_tqdm failed'

if __name__ == "__main__":
    test_logging_redirect_tqdm()
    print('Success')

# Generated at 2022-06-22 05:06:02.907575
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:06:06.674109
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # If a subclass did not include a constructor method, the superclass
    # method would be called in its place.
    # This is a test for the constructor.
    assert _TqdmLoggingHandler.__init__