

# Generated at 2022-06-22 04:56:17.807418
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_logging_handler, logging.StreamHandler)

# Generated at 2022-06-22 04:56:28.986387
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: (...) -> None
    # No pylint because test is executed in a child process
    # pylint: disable=redefined-outer-name
    from io import StringIO
    import logging
    import sys

    # Setup
    stream = StringIO()
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = stream
    sys.stderr = stream
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Test
    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter())
    handler.stream = stream
    logger.addHandler(handler)
    logger.info("good message")

    # Assert
    assert stream.getvalue()

# Generated at 2022-06-22 04:56:39.509462
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    # import logging
    import os
    import tempfile
    import threading
    from io import StringIO
    from tqdm import trange
    from tqdm.contrib import logging as tqdm_logging

    try:
        from unittest import mock
    except ImportError:
        import mock  # type: ignore
    tqdm = mock.MagicMock()
    tqdm.stream = StringIO()

    with tqdm_logging.logging_redirect_tqdm(tqdm_class=tqdm):
        logging.info('This is a test.')

    # reset the original value of stream
    tqdm.stream = sys.stderr

    assert tqdm.write.call_count == 1
    assert tqdm.write.call_

# Generated at 2022-06-22 04:56:43.013016
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    from .tests.test_logging import logging_redirect_tqdm as test_func
    test_func()

# Generated at 2022-06-22 04:56:54.655176
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm as std_tqdm

    class _DummyTqdm(object):
        def __init__(self):
            self._file = sys.stderr
            self._msg = None

        def write(self, msg, file=None):
            self._msg = msg
            self._file = file


# Generated at 2022-06-22 04:57:00.040020
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.Logger(__name__)]
    with tqdm_logging_redirect(
            loggers=loggers, desc="Test"):
        logging.info("console logging redirected to `tqdm.write()`")
    original_handlers_list = loggers[0].handlers
    assert len(original_handlers_list) != 0

# Generated at 2022-06-22 04:57:10.267045
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm(
            loggers=[logging.getLogger('tqdm.contrib.logging')]):
        logging.getLogger('tqdm.contrib.logging').debug('test1')
        with logging_redirect_tqdm(
                loggers=[logging.getLogger('tqdm.contrib.logging')]):
            logging.getLogger('tqdm.contrib.logging').debug('test2')
        logging.getLogger('tqdm.contrib.logging').debug('test3')



# Generated at 2022-06-22 04:57:19.644754
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import logging
    import sys
    from . import _TqdmLoggingHandler
    from ..std import tqdm
    from ..utils import _term_move_up, format_sizeof, format_interval

    class MockFile:
        def write(self, x):
            # type: (str) -> None
            sys.stdout.write(repr(x) + '\n')

    original_handlers = logging.root.handlers
    mock_file = MockFile()
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.stream = mock_file

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
    logger.info('start')

    tqdm

# Generated at 2022-06-22 04:57:30.489269
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    for attr in [None, '', '\r']:
        string = '\r{0}'.format(attr if attr is not None else '')
        # Check that a string with just a carriage return is not displayed
        assert _TqdmLoggingHandler(tqdm_class=std_tqdm).emit('\r') == '', \
            "Passing the string '{0}' to a _TqdmLoggingHandler object should " \
            "return ''".format(string)
    # Check that strings without a carriage return are displayed
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm).emit('test') == 'test', \
        "Passing the string 'test' to a _TqdmLoggingHandler object should " \
        "return 'test'"

# Generated at 2022-06-22 04:57:30.961822
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    t = _TqdmLoggingHandler()

# Generated at 2022-06-22 04:57:37.428696
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-22 04:57:43.132090
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MyTqdm(std_tqdm):
        def write(self, data):
            raise KeyboardInterrupt

    log = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler(tqdm_class=MyTqdm)
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    try:
        log.error("Test exception")
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-22 04:57:53.939974
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import tqdm.contrib.test


    class Tqdm(std_tqdm):
        def __init__(self, **kwargs):
            super(Tqdm, self).__init__(**kwargs)
            self.reset()

        def reset(self):
            self.out_str = []  # type: List[str]

        def write(self, s, *args, file=None, **kwargs):
            # type: (str, Optional[str], **Any) -> None
            self.out_str.append(s)

        def get_out_str(self):
            out_str = ''.join(self.out_str)
            self.reset()
            return out_str


# Generated at 2022-06-22 04:58:02.438800
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange

    class TestLogger(object):
        def __init__(self, level=0):
            self.level = level

        def log(self, level, msg):
            if level >= self.level:
                print(msg)

    test_logger = TestLogger(level=0)
    try:
        with logging_redirect_tqdm():
            for i in trange(5):
                test_logger.log(1, "with logging_redirect_tqdm")
    except AttributeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 04:58:08.032624
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    pbar = tqdm_handler.tqdm_class(0)
    tqdm_handler.emit(logging.LogRecord('', logging.ERROR, '', 0, "Hello World", [], []))
    pbar.close()

# Generated at 2022-06-22 04:58:16.839565
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm.contrib.logging

    LOG = logging.getLogger(__name__)

    # Test that redirects to tqdm.write()
    with tqdm.contrib.logging.tqdm_logging_redirect():
        LOG.info("console logging redirected to `tqdm.write()`")

    # Test that redirects to tqdm.write() (specific logger)
    with tqdm.contrib.logging.tqdm_logging_redirect(loggers=[LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:58:28.153365
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from unittest.mock import patch
    import logging

    test_str = "This is a test string"
    test_str_with_newline = test_str + '\n'
    test_str_without_newline = test_str

    logging.basicConfig(level=logging.INFO)
    # Create our test logger and test handler
    log = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()

    # Create a fake file object to write to
    temp_file = StringIO()
    with patch('sys.stdout', temp_file):
        # Add the handler to the logger
        log.addHandler(handler)

        # output to console
        log.info(test_str_with_newline)

# Generated at 2022-06-22 04:58:35.210680
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    import io

    f = io.BytesIO()
    handler = _TqdmLoggingHandler()
    handler.tqdm_class.write = lambda s, **kwargs: f.write(s.encode('utf-8'))
    handler.stream = f
    handler.setFormatter(logging._defaultFormatter)  # type: ignore
    handler.emit(logging.LogRecord('foo', logging.INFO, 'bar',
                                   0, 'baz', (), None))
    assert f.getvalue() == b'foo: baz\n'

# Generated at 2022-06-22 04:58:43.417416
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(1, 10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                elif i == 8:
                    LOG.info("finished")

# Unit testing for function tqdm_logging_redirect

# Generated at 2022-06-22 04:58:45.447526
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    if not hasattr(tlh, 'tqdm_class'):
        raise Exception('_TqdmLoggingHandler constructor failure!')


# Generated at 2022-06-22 04:59:05.532356
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    from six import StringIO
    from ..std import tqdm

    # Create a String IO that redirects all output
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    fake_stdout = StringIO()
    fake_stderr = StringIO()
    # We must replace stdout and stderr to capture the output.
    sys.stdout = fake_stdout
    sys.stderr = fake_stderr

    # Create fake logger
    log = logging.getLogger(__name__)

    # Test default to `tqdm.write()`
    with tqdm_logging_redirect(
            desc='passing description',
            total=2):
        log.warning('bar')
        log.warning('baz')

# Generated at 2022-06-22 04:59:14.704716
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)

    logger.info('Test logging')

    tqdm_handler.acquire()
    tqdm_handler.flush()
    tqdm_handler.release()



# Generated at 2022-06-22 04:59:17.514650
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in range(10):
            logging.info("test")
            time.sleep(1)

# Generated at 2022-06-22 04:59:28.889154
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class TestTqdm(object):
        def __init__(self):
            self.file = sys.stdout
            self.write_called = False

        def write(self, msg, file):
            assert file == sys.stdout
            self.write_called = True

    tqdm_class = TestTqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    record = logging.LogRecord(name='root', level=10, pathname='/foo/bar',
                               lineno=10, msg='hello', args=(), exc_info=None)
    tqdm_handler.emit(record)
    assert tqdm_handler.tqdm_class.write_called

# Generated at 2022-06-22 04:59:30.105376
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.Handler.__init__(_TqdmLoggingHandler())



# Generated at 2022-06-22 04:59:42.082063
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_class = std_tqdm
    loggers = None
    tqdm_kwargs = {'desc': 'test'}
    tqdm_kwargs2 = {'desc': 'test2'}
    loggers2 = [logging.root]
    tqdm_kwargs3 = {'desc': 'test3'}
    loggers3 = loggers2
    # pylint: disable=unused-variable
    with tqdm_logging_redirect(**tqdm_kwargs):
        pass
    with tqdm_logging_redirect(**tqdm_kwargs2, loggers=loggers2):
        pass
    with tqdm_logging_redirect(**tqdm_kwargs3, loggers=loggers3):
        pass
    # p

# Generated at 2022-06-22 04:59:49.280904
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    log_message = 'test'
    # find and remove test logger if already exists
    if LOG in logging.Logger.manager.loggerDict.values():
        logger_name = next(
            name for name, logger in logging.Logger.manager.loggerDict.items() if logger == LOG)
        del logging.Logger.manager.loggerDict[logger_name]

    LOG.setLevel(logging.DEBUG)
    LOG.addHandler(logging.FileHandler('test_log.log'))

    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.debug(log_message)

    # check if the message was written to tqdm
    assert log_message in std_tqdm.get_

# Generated at 2022-06-22 05:00:00.802554
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(
            self,
            tqdm_class=std_tqdm  # type: Type[std_tqdm]
        ):
            super(_TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class

        def emit(self, record):
            try:
                msg = self.format(record)
                self.tqdm_class.write(msg, file=self.stream)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    import sys

# Generated at 2022-06-22 05:00:03.317311
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.addHandler(_TqdmLoggingHandler())
    log.info('info')


# Generated at 2022-06-22 05:00:08.968208
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        time.sleep(0.1)
        logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 05:00:30.418399
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler is not None


# Generated at 2022-06-22 05:00:38.436031
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:00:43.692261
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log = logging.getLogger('test_log')

    with logging_redirect_tqdm():
        for i in trange(10):
            if i == 4:
                log.info('hello test_logging_redirect_tqdm')

    log.info('test_logging_redirect_tqdm end')



# Generated at 2022-06-22 05:00:56.621001
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    from ..std import trange as std_trange
    from ..std import time

    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(10):
            pbar.set_description("test with tqdm.std.tqdm")
            time.sleep(0.1)
            pbar.update()

    with tqdm_logging_redirect(total=10, tqdm_class=std_tqdm) as pbar:
        for i in range(10):
            pbar.set_description("test with custom tqdm.std.tqdm")
            time.sleep(0.1)
            pbar.update()


# Generated at 2022-06-22 05:01:03.051397
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    test
    """
    from tqdm import tnrange
    from tqdm.contrib.logging import tqdm_logging_redirect
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(leave=False,
                               loggers=[LOG],
                               tqdm_class=tnrange) as pbar:
        for _ in pbar:
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:01:14.413877
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm._tqdm_test_case import TqdmTestCase

    record = logging.LogRecord('test', 'INFO',
                               'root', 0, 'test message', (), None, None)

    tqdm_test_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_test_class)

    handler.stream = StringIO()
    handler.emit(record)
    TqdmTestCase.assertEqual(handler.stream.getvalue(), '')

    handler.stream = sys.stderr
    handler.emit(record)
    TqdmTestCase.assertEqual(handler.stream.getvalue(), 'test message\n')

# Generated at 2022-06-22 05:01:19.720274
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger('test')
    with tqdm_logging_redirect(loggers=[log]):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')

# Generated at 2022-06-22 05:01:21.574781
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm

# Generated at 2022-06-22 05:01:28.511528
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    tqdm_class = std_tqdm  # type: Type[std_tqdm]

    LOG = logging.getLogger(__name__)

    try:
        with tqdm_logging_redirect(
            total=9,
            loggers=[logging.root],
            tqdm_class=tqdm_class,
        ) as pbar:
            for i in range(9):
                pbar.update(1)
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    except RuntimeError:
        raise

# Generated at 2022-06-22 05:01:36.277346
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import sys
    from .utils import format_sizeof

    from .tests_tqdm import pretest_posttest_run
    from logging import INFO

    def test():
        # noinspection PyUnresolvedReferences
        sys.stdout.write(format_sizeof(list(range(10))))
        logging.root.handlers[0].setLevel(INFO)
        with logging_redirect_tqdm():
            logging.info('hello')
            logging.info('world')

    return pretest_posttest_run(test)

# Generated at 2022-06-22 05:02:23.143117
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert(tqdm_handler.tqdm_class.__name__ == 'tqdm')

# Generated at 2022-06-22 05:02:27.799437
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Make sure each of the arguments in constructor of class _TqdmLoggingHandler is set as expected
    class SuperTqdm(std_tqdm):
        def write(self, *args, **kwargs):
            pass
    handler = _TqdmLoggingHandler(SuperTqdm)
    assert handler.tqdm_class is SuperTqdm

# Generated at 2022-06-22 05:02:34.613739
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    def logger_output():
        """Mock logging output"""
        save_stdout = sys.stdout  # keep pointer to STDOUT
        # save_stderr = sys.stderr
        class LoggerStream(object):
            """stream object"""
            def __init__(self):
                """constructor"""
                self.data = []
            def write(self, s):
                """write method"""
                self.data.append(s)
                # sys.stderr.write(s)
        sys.stdout = LoggerStream()  # redirect STDOUT
        # sys.stderr = LoggerStream()

# Generated at 2022-06-22 05:02:36.524050
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    _TqdmLoggingHandler(tqdm_class)

# Generated at 2022-06-22 05:02:42.464705
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from logging import NullHandler
    except ImportError:
        return

    log = logging.getLogger('test')
    log.addHandler(NullHandler())
    log.setLevel(logging.DEBUG)

    with logging_redirect_tqdm([log]):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')

# Generated at 2022-06-22 05:02:51.559511
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import trange
    except ImportError:
        return
    import logging
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                closed=False, desc="test", total=10) as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:02:53.116448
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm)


# Generated at 2022-06-22 05:02:55.211484
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    t = _TqdmLoggingHandler()
    v = t.tqdm_class
    assert v == std_tqdm


# Generated at 2022-06-22 05:03:02.067218
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:03:09.798212
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import os
    import tempfile
    tf = tempfile.NamedTemporaryFile(mode='w', delete=False)
    tf.write("\n")
    tf.close()
    try:
        log_file = tf.name
        f = open(log_file)
        log_handler = _TqdmLoggingHandler()
        log_handler.emit(logging.LogRecord('name1', 'INFO', 'path', 5, 'message', (), None))
        f.seek(0)
        assert f.readline() == 'message\n'
        f.close()
    finally:
        os.unlink(tf.name)



# Generated at 2022-06-22 05:04:43.855639
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    # test basic functionality
    with logging_redirect_tqdm():
        logging.info('hello')
    # test the restore functionality
    with logging_redirect_tqdm():
        logging.info('hello')
    logging.info('again')
    # test the handler still bothers on multiple loggers
    log = logging.getLogger('test')
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    with logging_redirect_tqdm([logging.root, log]):
        logging.info('hello')
        log.info('hello')
    # test with a custom tqdm

# Generated at 2022-06-22 05:04:48.691268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger('my_logger')
    with logging_redirect_tqdm():
        for i in trange(3):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-22 05:04:57.301970
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from _io import StringIO
    import sys
    import logging

    # Create handler
    hdlr = _TqdmLoggingHandler()

    # Create logger and set level
    logger = logging.getLogger('test_log__TqdmLoggingHandler_emit')
    logger.setLevel(logging.INFO)
    logger.addHandler(hdlr)

    # write to file
    orig_stdout = sys.stdout
    try:
        f = StringIO()
        sys.stdout = f
        logger.info('test')
        assert f.getvalue() == 'test\n'
    finally:
        sys.stdout = orig_stdout

# Generated at 2022-06-22 05:05:07.812503
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    stream = StringIO()
    logging.basicConfig(level=logging.INFO, stream=stream)
    logger = logging.getLogger('test')
    logger.info("log message before redirection")

    with logging_redirect_tqdm():
        logger.info("log message during redirection")

    logger.info("log message after redirection")

    stream.seek(0)
    assert stream.read() == ""

    with logging_redirect_tqdm([logger], tqdm_class=std_tqdm):
        logger.info("log message using tqdm")

    stream.seek(0)
    assert stream.read().strip() == "log message using tqdm"


#

# Generated at 2022-06-22 05:05:18.915133
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:  # Python >= 3.5
        import filecmp  # pylint: disable=redefined-outer-name,import-outside-toplevel
    except ImportError:
        filecmp = None

    import tempfile
    import logging
    import shutil
    from ..std import tqdm

    with tempfile.TemporaryDirectory() as td:
        temp_log_fname = td + '/log.txt'
        LOG = logging.getLogger(__name__)

        with open(temp_log_fname, 'w') as log_file:
            logging.basicConfig(level=logging.INFO, filename=temp_log_fname)


# Generated at 2022-06-22 05:05:25.075855
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import sys
    import logging
    from tqdm._utils import _environ_cols_wrapper
    from contextlib import contextmanager

    @contextmanager
    def _mock_streams(stdout):
        """Context-manager to replace sys.std & friends."""
        old_streams = sys.stdout, sys.stderr, sys.stdin
        sys.stdout, sys.stderr, sys.stdin = stdout, stdout, stdout
        yield
        sys.stdout, sys.stderr, sys.stdin = old_streams

    @contextmanager
    def _mock_environ(env):
        """Context-manager to replace os.environ."""
        old_environ = dict(os.environ)

# Generated at 2022-06-22 05:05:34.985484
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    fake_logger = logging.getLogger('Fake')
    fake_logger.setLevel(logging.INFO)
    fake_handler = _TqdmLoggingHandler()
    fake_logger.addHandler(fake_handler)
    fake_logger.info('Hello world!')

# Generated at 2022-06-22 05:05:38.451142
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # test the contructor of tqdm logging handler
    _TqdmLoggingHandler()
    return True


# Generated at 2022-06-22 05:05:42.717301
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:05:49.780924
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from pytest import raises
    except ImportError:
        from tqdm.utils import _raise_if_not_import
        _raise_if_not_import('pytest', 'test_logging_redirect_tqdm')

    import logging
    from tqdm import tnrange

    LOG = logging.getLogger(__name__)

    with raises(ValueError):
        with logging_redirect_tqdm(loggers=[LOG], tqdm_class=tnrange):
            1 / 0