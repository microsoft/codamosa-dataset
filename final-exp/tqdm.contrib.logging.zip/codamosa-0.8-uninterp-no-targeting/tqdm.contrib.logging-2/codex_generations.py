

# Generated at 2022-06-22 04:56:23.931268
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Create the handler
    handler = _TqdmLoggingHandler()
    # Create a logger
    logger = logging.getLogger()
    logger.addHandler(handler)
    # Try to catch the Exception
    try:
        raise RuntimeError('Test exception')
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        logger.exception('Error message')

# Generated at 2022-06-22 04:56:30.094370
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm_notebook

    LOG = logging.getLogger(__name__)

    def test_logging_redirect_tqdm():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(tqdm_class=tqdm_notebook):
            for i in tqdm_notebook(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:56:40.121619
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test with blackhole stream
    fake_stream = open('/dev/null', 'w')
    handler = _TqdmLoggingHandler()
    handler.stream = fake_stream

    # Test with regular stream
    handler.stream = sys.stderr
    try:
        handler.emit(logging.LogRecord('', logging.INFO, '', 0, "Test", (), None))
    except Exception:  # pylint: disable=broad-except
        assert False, "Should not raise any exception"
    handler.stream = sys.stderr.buffer
    try:
        handler.emit(logging.LogRecord('', logging.INFO, '', 0, "Test", (), None))
    except Exception:  # pylint: disable=broad-except
        assert False, "Should not raise any exception"

    # Test

# Generated at 2022-06-22 04:56:50.696973
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test function tqdm_logging_redirect"""
    import logging
    from tqdm import trange

    # pylint: disable=unused-argument

    # Test with root logger
    with tqdm_logging_redirect() as pbar:
        assert pbar.__class__ == std_tqdm
        for i in trange(3):
            logging.info(str(i))

    # Test with custom logger
    mylogger = logging.Logger('mylogger')
    with tqdm_logging_redirect(loggers=[mylogger]):
        assert pbar.__class__ == std_tqdm
        for i in trange(3):
            mylogger.info(str(i))

# Generated at 2022-06-22 04:57:00.961338
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import trange

    class _TestTqdm(std_tqdm):
        def write(self, s, file=None):
            self.stream.write(s)

        def writelines(self, lines):
            self.stream.writelines(lines)

    handler = _TqdmLoggingHandler(_TestTqdm)
    handler.stream = StringIO()
    logger = logging.getLogger('_TestLogger')
    logger.addHandler(handler)

    def _test_messages():
        logger.debug('Test message %s', 1)
        logger.info('Test message %s', 2)
        logger.warning('Test message %s', 3)
        logger.error('Test message %s', 4)
        logger.critical('Test message %s', 5)



# Generated at 2022-06-22 04:57:13.332702
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    '''Test tqdm_logging_redirect function'''
    import logging
    import time
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.INFO)
    test_handler = logging.StreamHandler()
    test_handler.setFormatter(logging.Formatter('%(message)s'))
    test_logger.addHandler(test_handler)

    with tqdm_logging_redirect(
            desc="test #1",
            loggers=[test_logger],
            total=2,
            unit_scale=True,
            unit='test',
            smoothing=0.3,
            dynamic_ncols=True,
            ) as pbar:
        pbar.set_postfix(test_1='test_1')

# Generated at 2022-06-22 04:57:18.550368
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:57:23.578890
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.std import tqdm as std_tqdm
    with tqdm_logging_redirect(ascii=True) as pbar:
        assert pbar is not None
        assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-22 04:57:29.838793
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for tqdm_logging_redirect()"""
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    def f(pbar):
        for i, _ in enumerate(pbar):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(total=9) as pbar:
        f(pbar)

# Generated at 2022-06-22 04:57:40.642781
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logger = logging.getLogger(__name__)

    # make sure there is no logging handler set
    assert len(logger.handlers) == 0

    # set console handler for logging
    logging.basicConfig(level=logging.INFO)
    assert len(logger.handlers) == 1
    assert _is_console_logging_handler(logger.handlers[0])

    # redirect logging to tqdm
    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("Test logging")

    # logging handler should be restored
    assert len(logger.handlers) == 1
    assert _is_console_logging_handler(logger.handlers[0])

# Generated at 2022-06-22 04:57:49.794606
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Test constructor of class TqdmLoggingHandler

    Testing that the class is an instance of
    :class:`logging.StreamHandler <logging.StreamHandler>`
    """
    assert isinstance(_TqdmLoggingHandler(), logging.StreamHandler)


# Generated at 2022-06-22 04:57:50.846277
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(None)



# Generated at 2022-06-22 04:58:03.165040
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # pylint: disable=unused-variable
    with tqdm_logging_redirect(total=9) as pbar:
        logging.info("Console logging redirected to `tqdm.write()`")
    # Test that loggers is optional
    with tqdm_logging_redirect(total=9) as pbar:
        logging.info("Console logging redirected to `tqdm.write()`")
    # Test that tqdm_class is optional
    with tqdm_logging_redirect(total=9) as pbar:
        logging.info("Console logging redirected to `tqdm.write()`")
    # Test that tqdm_logging_redirect accepts all tqdm arguments
    with tqdm_logging_redirect(total=9) as pbar:
        logging.info

# Generated at 2022-06-22 04:58:11.171837
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            loggers=[LOG],
            tqdm_class=std_tqdm,
            total=5,
            leave=False,
            unit='it',
            unit_scale=True,
    ) as iterable:
        for i in iterable:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:58:22.412202
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class FakeTqdm(object):
        def __init__(self):
            self.value = ''

        def write(self, msg):
            self.value += msg + '\n'

    fake_tqdm = FakeTqdm()
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=FakeTqdm)
    record = logging.LogRecord(
        name='test__TqdmLoggingHandler_emit',
        level=logging.INFO,
        pathname='/test_pathname',
        lineno=100,
        msg='test message',
        args='test_args',
        exc_info='test_exc_info')

    tqdm_handler.emit(record)

# Generated at 2022-06-22 04:58:31.754115
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.tests import tests

    test_verbose = False
    if tests.is_installed("logbook"):
        logger = tests.get_logger("test_logging_redirect_tqdm", test_verbose)
        logger.info("foo")
        loggers = [logging.root]
        with logging_redirect_tqdm(loggers=loggers):
            logger.info("console logging redirected to `tqdm.write()`")
        with tqdm_logging_redirect(loggers=loggers, desc="test"):
            logger.info("console logging redirected to `tqdm.write()`")
        logger.info("bar")

# Generated at 2022-06-22 04:58:43.358726
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    from .__init__ import logging_redirect_tqdm, _TqdmLoggingHandler
    import logging
    import sys

    LOG = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()

    LOG.handlers = [handler]
    with mock.patch.object(handler, "stream", sys.stdout):
        handler.emit(logging.makeLogRecord({"msg": "test"}))

    LOG.handlers = []
    with mock.patch.object(handler, "stream", sys.stdout):
        handler.emit(logging.makeLogRecord({"msg": "test"}))

# Generated at 2022-06-22 04:58:50.409397
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_class = std_tqdm
    stdout = sys.stdout  # backup
    sys.stdout = StringIO()

    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class)
    tqdm_logging_handler.emit(logging.LogRecord('name', 'DEBUG', 'pathname',
                                                1, 'msg', None, None))
    assert(sys.stdout.getvalue() == 'msg\n')

    sys.stdout = stdout  # restore



# Generated at 2022-06-22 04:59:00.284612
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with open('/tmp/tqdm_logging_handler_test.txt', 'w') as fh:
        handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        handler.stream = fh
        handler.emit(logging.LogRecord('foo', 0, 'bar', 0, 'baz', None, None))
        fh.flush()
        with open('/tmp/tqdm_logging_handler_test.txt') as fh_test:
            assert fh_test.read() == 'baz\n'
            fh_test.close()

# Generated at 2022-06-22 04:59:09.151600
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import tempfile
    import os
    import tqdm as std_tqdm
    test_str = "test"
    with tempfile.NamedTemporaryFile() as tf:
        handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        handler.stream = tf
        logging.root.addHandler(handler)
        logging.root.warning(test_str)
        handler.flush()
        tf.flush()
        tf.seek(0)
        assert test_str in tf.read()
        logging.root.removeHandler(handler)
        os.unlink(tf.name)


# Generated at 2022-06-22 04:59:22.298013
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(unit='B', unit_scale=True, unit_divisor=1024):
        logging.info("hello world")

# Generated at 2022-06-22 04:59:28.782787
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    try:
        from unittest import mock
    except ImportError:
        import mock

    orig_logging_redirect_tqdm = logging_redirect_tqdm
    orig_tqdm_class = std_tqdm
    orig_logging_handlers = [logger.handlers for logger in [logging.root]]


# Generated at 2022-06-22 04:59:40.353505
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    from tqdm.std import tqdm

    # Set a StringIO as the output stream
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    try:
        sys.stdout = StringIO()

        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        handler = _TqdmLoggingHandler(tqdm_class=tqdm)
        handler.setLevel(logging.DEBUG)
        logger.addHandler(handler)

        # Test that the emitted message is written to the StringIO object
        logger.debug('test')
        assert sys.stdout.getvalue().rstrip() == 'test'
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-22 04:59:41.854114
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler(tqdm_class=std_tqdm)

# Generated at 2022-06-22 04:59:49.164963
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    def get_handler(emit_raise=False):
        # type: (bool) -> _TqdmLoggingHandler
        class MockTqdm(object):
            def __init__(self):
                self.writes = []  # type: List[str]

            def write(self, msg, file=None):
                # type: (str, Any) -> None
                self.writes.append(msg)

        tqdm_class = MockTqdm

        class _MockTqdmLoggingHandler(_TqdmLoggingHandler):
            def __init__(self):
                super(_MockTqdmLoggingHandler, self).__init__()
                self.tqdm = tqdm_class()
                self.emit_raise = emit_raise


# Generated at 2022-06-22 04:59:58.745962
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm.std import tqdm
    except ImportError:
        from tqdm import tqdm

    try:
        from logging import getLogger, INFO, StreamHandler
    except ImportError:
        from log import getLogger, INFO, StreamHandler

    log = getLogger('tqdm.tests.log')
    log.addHandler(StreamHandler())
    log.setLevel(INFO)

    with tqdm_logging_redirect(tqdm_class=tqdm) as pbar:
        for _ in pbar:
            log.info('redirected to tqdm.write')

# Generated at 2022-06-22 05:00:01.932321
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    >>> logging.basicConfig(level=logging.DEBUG)
    >>> logger = logging.getLogger(__name__)
    >>> logger.info("Info message")
    Info message
    """
    pass


# Generated at 2022-06-22 05:00:14.063097
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import tempfile
    import unittest

    import logging
    import tqdm

    from .tqdm_tqdm import tqdm_tqdm

    LOG = logging.getLogger(__name__)

    def get_log_file_path(func):
        # type: (Any) -> str
        log_file_name = os.path.basename(func.__code__.co_filename)
        return os.path.join(tempfile.gettempdir(), log_file_name)


# Generated at 2022-06-22 05:00:25.820335
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def test_logging_redirect_tqdm_with_logging_levels(logging_level):
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.log(logging_level, "console logging redirected to `tqdm.write()`")

    logging.basicConfig(level=logging.DEBUG)
    test_logging_redirect_tqdm_with_logging_levels(logging.DEBUG)
    logging.basicConfig(level=logging.INFO)
    test_logging_redirect_tqdm_with_logging_levels(logging.DEBUG)
    test_logging_redirect_tq

# Generated at 2022-06-22 05:00:31.160422
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter("%(name)s - %(message)s"))
    log.addHandler(tqdm_handler)

    log.debug("hello world")
    log.debug("foo")
    log.debug("bar")

# Generated at 2022-06-22 05:00:47.889262
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logging.basicConfig()
    a = logging.root.handlers[0]
    tqdm_handler = _TqdmLoggingHandler()
    format = getattr(a.formatter, '_fmt', None)
    if format is None:
        format = getattr(a.formatter, 'format', '[%(levelname)s] %(message)s')
    tqdm_handler.setFormatter(logging.Formatter(format))
    tqdm_handler.stream = a.stream
    b = logging.root.handlers[0]
    assert a == b
    logging.root.handlers = [tqdm_handler]
    b = logging.root.handlers[0]
    assert a != b
    logging.root.handlers = [a]

# Generated at 2022-06-22 05:00:54.607713
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 05:01:02.672604
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO
    from tqdm.contrib.logging import _TqdmLoggingHandler

    # setup
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.INFO)

    buf = StringIO()

    handler = _TqdmLoggingHandler(file=buf)
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)

    # emit log message
    logger.info('test message')

    # test
    assert buf.getvalue() == 'test message\n'

    # teardown
    logger.removeHandler(handler)

# Generated at 2022-06-22 05:01:14.726873
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import new_stdout, new_stderr
    import tqdm

    LOG = logging.getLogger('logging_redirect_tqdm')

    with new_stdout(), new_stderr():
        with tqdm_logging_redirect():
            for i in tqdm.trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored

    with open("stdout.txt", "r") as fd:
        stdout = fd.read()
    with open("stderr.txt", "r") as fd:
        stderr = fd.read()


# Generated at 2022-06-22 05:01:25.847429
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    # use a custom formatter, so that the logs are easier to read
    formatter = logging.Formatter('[%(levelname)s] %(message)s')
    console_handler.setFormatter(formatter)
    log.addHandler(console_handler)

    # Log some information with default handler (console)
    log.info("1st run")

    # Log some information with redirected handler
    with logging_redirect_tqdm():
        log.info("2nd run")

    # Log some information with default handler (console)
    log.info("3rd run")

# Unit test

# Generated at 2022-06-22 05:01:36.239603
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import os
    import tempfile
    import logging
    from tqdm._utils import _term_move_up
    from tqdm.contrib.logging import _TqdmLoggingHandler

    # Create a logger and attach the stream handler to it
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tmp_file_fd, tmp_file_path = tempfile.mkstemp()
    stream_handler = logging.StreamHandler(stream=sys.stderr)
    tqdm_handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:01:39.410774
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    try:
        with tqdm_logging_redirect():
            raise RuntimeError('error')
    except RuntimeError:
        LOG.info('hello')

# Generated at 2022-06-22 05:01:48.207440
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from io import StringIO
    import logging
    import sys
    from tqdm import tqdm
    from tqdm.contrib import logging as tqdm_logging
    assert sys.stderr.encoding is not None

    log_msg = 'to stdout'
    tqdm_msg = 'to stderr'

    _TqdmLoggingHandler(std_tqdm)

    log_file = StringIO()
    handler = logging.StreamHandler(stream=log_file)
    logger = logging.getLogger()
    logger.handlers = [handler]
    tqdm_handler = tqdm_logging._TqdmLoggingHandler(tqdm)
    logger.handlers.append(tqdm_handler)

    logger.error(log_msg)
    assert tqdm_

# Generated at 2022-06-22 05:01:54.876787
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm.std import tqdm

    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    assert tqdm_logging_handler.tqdm_class == tqdm
    assert tqdm_logging_handler.stream == sys.stderr

# Generated at 2022-06-22 05:01:56.861418
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler.tqdm_class == std_tqdm


# Generated at 2022-06-22 05:02:24.734828
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm() as pbar:
        LOG.warning('test')
    assert pbar.get_lock().locked() is False

# Generated at 2022-06-22 05:02:32.577291
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # Initialize logger and logging handler
    log = logging.getLogger(__name__)  # noqa
    log.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)

    # Redirect logging to tqdm
    with tqdm_logging_redirect():
        log.debug("Debug statement")
        log.info("Info statement")
        log.warning("Warning statement")
        try:
            raise KeyboardInterrupt()
        except KeyboardInterrupt:
            log.exception("Error statement")

# Generated at 2022-06-22 05:02:33.855946
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler().tqdm_class is std_tqdm

# Generated at 2022-06-22 05:02:37.786328
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from time import sleep
    from contextlib import contextmanager
    from tqdm.contrib.logging import tqdm_logging_redirect

    # utility function to verify that all logging handlers are TqdmLoggingHandlers
    @contextmanager
    def capture(handler):
        old_handlers = handler.handlers
        old_level = handler.level
        old_propagate = handler.propagate
        handler.handlers = []
        handler.level = logging.NOTSET
        handler.propagate = False
        try:
            yield handler
        finally:
            handler.handlers = old_handlers
            handler.level = old_level
            handler.propagate = old_propagate

    # Logging configuration
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-22 05:02:38.801774
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()


# Generated at 2022-06-22 05:02:42.009202
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=4, tqdm_class=std_tqdm, file=sys.stdout) as pbar:
        for _ in range(4):
            pbar.update()



# Generated at 2022-06-22 05:02:50.008676
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:02:51.678296
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler


# Generated at 2022-06-22 05:02:56.847376
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MockTqdm(_TqdmLoggingHandler):
        stream = ''

        def write(self, string):
            self.stream += string

    tqdm_handler = MockTqdm()
    tqdm_handler.emit('abcde')
    assert tqdm_handler.stream == 'abcde'
    tqdm_handler.emit('fghij')
    assert tqdm_handler.stream == 'abcdefghij'



# Generated at 2022-06-22 05:03:03.492068
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """ Test _TqdmLoggingHandler._emit() """
    from io import StringIO
    from .miscs import _range

    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    log = logging.getLogger('test_log')
    handler.setFormatter(logging.Formatter('%(message)s'))
    log.addHandler(handler)

    saved_stdout = sys.stdout
    try:
        fake_stdout = StringIO()
        sys.stdout = fake_stdout
        for _ in _range(10):
            log.info('Test logging')
        assert fake_stdout.getvalue() == ''.join(['Test logging\n'] * 10)
    finally:
        sys.stdout = saved_

# Generated at 2022-06-22 05:03:49.141564
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(total=1):
        with std_tqdm(total=1) as pbar:
            pbar.update()

# Generated at 2022-06-22 05:03:56.750412
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    old_stderr = sys.stderr

    try:
        sys.stderr = open('/dev/null', 'w')
        tqdm_log_handler = _TqdmLoggingHandler()
        tqdm_log_handler.stream = sys.stderr
        tqdm_log_handler.emit(logging.LogRecord(
            'name', logging.INFO, 'path', 1, 'msg', (), None))
    finally:
        sys.stderr.close()
        sys.stderr = old_stderr



# Generated at 2022-06-22 05:04:07.001459
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """

    import logging

    LOGGER = logging.getLogger()
    LOGGER.setLevel(logging.INFO)

    # The following 2 lines are necessary to prevent a warning from the
    # root logger (about no handlers)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"))
    LOGGER.addHandler(stream_handler)

    class Tqdm:
        """
        Fake class definition of tqdm
        """
        def __init__(self, iterable, *args, **kwargs):
            # type: (int, ..., ...) -> None
            self.iterable = iterable

# Generated at 2022-06-22 05:04:11.374424
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # The constructor for _TqdmLoggingHandler has no logic, so
    # there is no need to test it in detail.
    _TqdmLoggingHandler()
    _TqdmLoggingHandler('tqdm.cli.main')

# Unit tests for function _is_console_logging_handler

# Generated at 2022-06-22 05:04:16.050885
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger('tqdm_logging_redirect')]
    for logger in loggers:
        logger.setLevel(logging.INFO)
        logger.propagate = False
    with tqdm_logging_redirect(loggers=loggers):
        for logger in loggers:
            logger.info('test')

# Generated at 2022-06-22 05:04:22.753875
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os

    LOG = logging.getLogger(__name__)

    def echo():
        LOG.info("console logging redirected to `tqdm.write()`")

    eval("@" + "contextmanager")
    def capture_output():
        import io
        import sys

        old_stdout, old_stderr = sys.stdout, sys.stderr
        try:
            new_stdout, new_stderr = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = new_stdout, new_stderr
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr


# Generated at 2022-06-22 05:04:33.141548
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm_notebook
    from tqdm import tnrange
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(tqdm_class=tqdm_notebook) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    with tqdm_logging_redirect(tqdm_class=trange) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:04:41.263320
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == "__main__":
    # Unit test
    from doctest import testmod
    testmod(name='logging_redirect_tqdm', optionflags=+doctest.ELLIPSIS)

# Generated at 2022-06-22 05:04:46.437464
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import StringIO
    except ImportError:
        # Python 2
        from io import StringIO
    import logging
    import sys
    import tqdm

    # Create the logger
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    # Create a handler which prints to a StringIO instance
    stringio_handler = logging.StreamHandler(StringIO.StringIO())
    stringio_handler.setLevel(logging.DEBUG)
    log.addHandler(stringio_handler)

    # Create a tqdm handler
    tqdm_logging_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    tqdm_logging_handler.setLevel(logging.DEBUG)

# Generated at 2022-06-22 05:04:57.230574
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import logging

    out_str = io.StringIO()
    error_str = io.StringIO()
    log_str = io.StringIO()

    _logger = logging.getLogger(__name__)
    _logger.handlers = [
        _TqdmLoggingHandler(tqdm_class=std_tqdm),
        logging.StreamHandler(error_str),
        logging.StreamHandler(log_str),
    ]

    # To not print to the screen
    sys.stdout = out_str
    sys.stderr = error_str

    # logs going to tqdm
    _logger.info('hello-1')

    assert len(out_str.getvalue()) == 0