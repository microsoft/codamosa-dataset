

# Generated at 2022-06-22 04:56:23.050084
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.std import tqdm
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Unit tests for function tqdm_logging_redirect

# Generated at 2022-06-22 04:56:28.914451
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler._TqdmLoggingHandler__tqdm_class == std_tqdm

    def dummy_tqdm_class():
        return 'this is dummy tqdm class'

    handler2 = _TqdmLoggingHandler(tqdm_class=dummy_tqdm_class)
    assert handler2._TqdmLoggingHandler__tqdm_class == dummy_tqdm_class


# Generated at 2022-06-22 04:56:37.833984
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    import logging
    import io
    import contextlib
    try:
        from contextlib import redirect_stdout
    except ImportError:
        import contextlib2 as contextlib

    logging.basicConfig(level=logging.INFO)

    sio = io.StringIO()

    with contextlib.redirect_stdout(sio):
        with tqdm_logging_redirect(total=10) as pbar:
            for _ in range(10):
                logging.info('test')

    assert sio.getvalue() == """\
test
test
test
test
test
test
test
test
test
test
"""

# Generated at 2022-06-22 04:56:43.386110
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    log_msg = "This is a log message"

    handler = _TqdmLoggingHandler()
    handler.stream = StringIO()

    record = logging.LogRecord(
        name='',
        level=logging.INFO,
        pathname='',
        lineno=0,
        msg=log_msg,
        args=(),
        exc_info=None
    )

    handler.emit(record)
    assert handler.stream.getvalue() == log_msg + "\n"

# Generated at 2022-06-22 04:56:51.036603
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    def test():
        # type: () -> None
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        logging.info("This should go to stdout")
    test()



# Generated at 2022-06-22 04:56:58.397390
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import discretesleep

    expected_output = "console logging redirected to `tqdm.write()`"
    with tqdm_logging_redirect() as pbar:
        pbar.write('foobar')
        discretesleep(0.1)
        logging.info(expected_output)

    assert expected_output in pbar.get_internal_state()['last_print_n'], \
        "tqdm_logging_redirect doesn't work as expected"

# Generated at 2022-06-22 04:57:02.624349
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import tempfile
    import logging
    with open(os.path.join(tempfile.gettempdir(), 'tqdm_LoggingHandler.txt'), 'w') as f:
        handler = _TqdmLoggingHandler()
        handler.stream = f
        handler.emit(logging.LogRecord("main", logging.INFO, "foo.py", 0, "message", [], None))

# Generated at 2022-06-22 04:57:14.625759
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class CustomTqdm(std_tqdm):
        def __init__(self, *args, **kwargs):
            pass
    assert isinstance(_TqdmLoggingHandler(), _TqdmLoggingHandler)
    assert isinstance(_TqdmLoggingHandler(CustomTqdm), _TqdmLoggingHandler)
    assert not isinstance(_TqdmLoggingHandler(CustomTqdm),
                          logging.StreamHandler)


if __name__ == '__main__':
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-22 04:57:18.680090
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    loggers = [logging.root, LOG]

    with logging_redirect_tqdm(loggers=loggers):
        for i in range(1, 4):
            logging.info('INFO %d' % i)
            LOG.info('INFO %d' % i)



# Generated at 2022-06-22 04:57:29.656372
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from sys import stdout
    from contextlib import redirect_stdout
    from tqdm import tqdm

    handler = _TqdmLoggingHandler(tqdm)
    handler.setLevel(logging.INFO)
    fmt = logging.Formatter(
        '[%(levelname)s] %(name)s - %(message)s')
    handler.setFormatter(fmt)
    handler.stream = StringIO()
    record = logging.LogRecord(
        'foo', logging.INFO, 'None', 0, 'bar', None, None)

    with redirect_stdout(handler.stream):
        handler.emit(record)

    assert handler.stream.getvalue() == '[INFO] foo - bar\n'

# Generated at 2022-06-22 04:57:46.036582
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Avoid no handlers could be found for logger "fake_logger"'
    # because sys.stderr is not writable in Travis CI.
    from io import StringIO
    fake_stderr = StringIO()
    fake_logger = logging.Logger('fake_logger')  # type: ignore
    fake_handler = logging.StreamHandler(fake_stderr)
    fake_logger.addHandler(fake_handler)

    fake_msg = 'fake_logging_message'
    fake_record = logging.LogRecord(
        name=fake_logger.name,
        level=logging.INFO,
        pathname='fake_pathname',
        lineno=0,
        msg=fake_msg,
        args=(),
        exc_info=None)
    tqdm_handler = _Tqdm

# Generated at 2022-06-22 04:57:55.238465
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    from io import StringIO
    from logging import LogRecord, getLogger
    from tqdm import std_tqdm

    # Dummy tqdm_class
    @contextmanager
    def tqdm_class(*args, **kwargs):
        yield std_tqdm(*args, **kwargs)

    # Dummy logging configuration
    root_logger = getLogger()
    original_handlers = root_logger.handlers

    # Unit test
    with tqdm_logging_redirect('Testing', total=3, ncols=50, loggers=[root_logger], tqdm_class=tqdm_class) as pbar:
        assert pbar.n == 3

# Generated at 2022-06-22 04:58:00.083473
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    with tqdm_logging_redirect(loggers=None, tqdm_class=std_tqdm):
        logger = logging.getLogger(__name__)
        logger.info("console logging redirected to `tqdm.write()`")

test__TqdmLoggingHandler()

# Generated at 2022-06-22 04:58:07.801950
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm._utils import _term_move_up
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3

    # Setup
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    logger.addHandler(ch)

    stream = StringIO()
    with tqdm_logging_redirect(file=stream) as pbar:
        pbar.set_description('mybar')
        for _ in trange(3):
            logger.info('test')

    # Check
    stream.seek(0)

# Generated at 2022-06-22 04:58:11.745529
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger('TestLogger')
    LOG.info('Test message')
    with logging_redirect_tqdm():
        LOG.info('Test message')
    LOG.info('Test message')



# Generated at 2022-06-22 04:58:13.081967
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-22 04:58:24.803896
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from time import sleep
    from logging import info, basicConfig, INFO
    from tqdm import trange

    basicConfig(level=INFO)
    with tqdm_logging_redirect(total=5, desc="I'm a logger") as pbar:
        for i in range(5):
            info("Some message #%d" % i)
            sleep(0.25)
    assert hasattr(pbar, 'n') and hasattr(pbar, 'total') and pbar.n == pbar.total

    basicConfig(level=INFO)
    with tqdm_logging_redirect(total=5, desc="I'm a logger") as pbar:
        for i in trange(5):
            info("Some message #%d" % i)
            sleep(0.25)

# Generated at 2022-06-22 04:58:31.530702
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..main import tqdm
    logg_handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    logger = logging.getLogger('test')
    logger.addHandler(logg_handler)
    with tqdm_logging_redirect(total=42) as pbar:
        logger.info('hello')
        pbar.update(2)
        logger.info('world')
        pbar.update(40)

# Generated at 2022-06-22 04:58:32.806345
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler is not None

# Generated at 2022-06-22 04:58:33.708820
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 04:58:47.095971
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    fake_stream = object()
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert handler.level == 0
    assert handler.formatter is None
    assert handler.stream is not None
    handler.stream = fake_stream
    assert handler.stream is fake_stream

# Unit tests for functions:
#   - _is_console_logging_handler
#   - _get_first_found_console_logging_handler
#   - logging_redirect_tqdm
#   - tqdm_logging_redirect

# Generated at 2022-06-22 04:58:48.942052
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler_object = _TqdmLoggingHandler()
    # No exception raised
    assert True

# Generated at 2022-06-22 04:59:00.988395
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO

    logging.basicConfig(level=logging.INFO)

    out = StringIO()

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.setFormatter(logging.Formatter('%(levelname)s\t%(message)s'))
    tqdm_logging_handler.setLevel(logging.INFO)
    tqdm_logging_handler.stream = out
    logger.addHandler(tqdm_logging_handler)

    logger.info("Example info message")
    # Flush logger to remove any remaining content
    logging.shutdown()

    output = out.getvalue()


# Generated at 2022-06-22 04:59:07.092727
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)  # NOQA
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        log.info('info message')
        log.warning('warning message')
        log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.debug('debug message')

# Generated at 2022-06-22 04:59:18.418018
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    from tqdm import std
    from tqdm.contrib.logging import _TqdmLoggingHandler
    from logging import Handler, LogRecord, Logger
    with StringIO() as s:
        tlh = _TqdmLoggingHandler(tqdm_class=std)
        tlh.stream = s
        assert isinstance(tlh, Handler)
        assert tlh.tqdm_class is std
        assert tlh.stream is s
        tlh.emit(LogRecord(*(None,) * 5))
        assert s.getvalue() == ' '
        tlh.emit(LogRecord('name', 0, '', 0, 'msg', None, None))
        assert s

# Generated at 2022-06-22 04:59:29.144452
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    loggers = [logging.getLogger(__name__)]
    with logging_redirect_tqdm(loggers=loggers):
        for i in range(0, 10):
            LOG.info("console logging redirected to `tqdm.write()`")
        for i in range(0, 10):
            print("console logging not redirected to `tqdm.write()`")
    assert loggers[0].handlers[-1].__class__.__name__ == '_TqdmLoggingHandler'
    # logging restored



# Generated at 2022-06-22 04:59:32.458543
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pbar = _TqdmLoggingHandler()
    # Assert that the class writes to stderr by default
    assert isinstance(pbar.stream, logging.StreamHandler)
    assert pbar.stream.stream is sys.stderr

# Generated at 2022-06-22 04:59:35.657986
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tlh = _TqdmLoggingHandler()
    assert isinstance(tlh, logging.StreamHandler)



# Generated at 2022-06-22 04:59:38.361922
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():  # pragma: no cover
    handler = _TqdmLoggingHandler()
    assert handler.stream == sys.stderr
    assert len(handler.level) == 3

# Generated at 2022-06-22 04:59:44.890498
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> str
    """
    Currently the only way to test this is to run it in the parent process.
    """
    import logging
    from tqdm import trange
    log = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                log.info('console logging redirected to `tqdm.write()`')
    return 'OK'



# Generated at 2022-06-22 05:00:00.955708
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    import traceback

    try:
        LOG = logging.getLogger(__name__)

        with tqdm_logging_redirect(loggers=[LOG]) as pbar:
            sys.stderr.write('test_logging_redirect_tqdm std err\n')
            sys.stdout.write('test_logging_redirect_tqdm std out\n')
            LOG.info('This message should be displayed in pbar\n')
            LOG.info('This message should be displayed in pbar')
            LOG.info('This message should be displayed in pbar\n')
    except Exception:
        traceback.print_exc()

    assert "test_logging_redirect_tqdm std err" not in str(pbar)

# Generated at 2022-06-22 05:00:06.234896
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    >>> logging.getLogger().setLevel(logging.NOTSET)
    >>> handler = _TqdmLoggingHandler()
    >>> logger = logging.getLogger()
    >>> logger.addHandler(handler)
    >>> logger.info('hello world')
    hello world
    """

# Generated at 2022-06-22 05:00:16.233542
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    from contextlib import contextmanager
    from io import StringIO

    try:
        from typing import Iterator, List, Optional, Type  # pylint: disable=unused-import
    except ImportError:
        pass

    from ..std import tqdm as std_tqdm

    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(
            self,
            tqdm_class=std_tqdm  # type: Type[std_tqdm]
        ):
            super(_TqdmLoggingHandler, self).__init__()
            self.tqdm_class = tqdm_class


# Generated at 2022-06-22 05:00:26.795837
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    f = io.StringIO()
    _TqdmLoggingHandler(stream=f).emit(logging.LogRecord('', logging.DEBUG,
                                                         '', '', '', '', '', ''))
    assert f.getvalue() == ''

    f = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler(stream=f)
    tqdm_handler.emit(logging.LogRecord('', logging.INFO,
                                        '', '', '', '', '', ''))
    assert f.getvalue() == '\n'

    f = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler(stream=f)

# Generated at 2022-06-22 05:00:34.228835
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    saved_stdout = sys.stdout
    logging.getLogger().handlers[0].flush()
    try:
        # replace sys.stdout (necessary in case of doctest)
        sys.stdout = StringIO()

        logger = logging.getLogger(__name__)
        my_tqdm = std_tqdm.tqdm
        logger.handlers = [_TqdmLoggingHandler(my_tqdm)]
        logger.warning('warning')
        assert 'warning' in sys.stdout.getvalue()
    finally:
        sys.stdout = saved_stdout
        logging.getLogger().handlers[0].flush()

# Generated at 2022-06-22 05:00:42.254667
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    log = logging.getLogger('test')
    with logging_redirect_tqdm():
        for i in trange(3):
            log.info('hello')
        for j in trange(3):
            print('world')
        for k in trange(3):
            print(k)


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:00:52.728415
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger('tqdm.contrib.logging')
    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("console logging redirected to `tqdm.write()`")

    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:57.697781
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    assert True


# Test the context manager tqdm_logging_redirect

# Generated at 2022-06-22 05:01:02.790767
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from .logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.debug("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:01:14.841013
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    from contextlib import redirect_stdout
    tqdm = tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    def test_log_messages(redirect_output):
        log_messages = []
        logging.basicConfig(level=logging.INFO, stream=sys.stdout)
        if not redirect_output:
            log_handler = logging.StreamHandler(sys.stdout)
            log_handler.setFormatter(logging.Formatter('%(message)s'))
            LOG.addHandler(log_handler)
        LOG.info("First line")

# Generated at 2022-06-22 05:01:27.532256
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm
    import sys
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        for i in tqdm.trange(9):
            if i == 4:
                with logging_redirect_tqdm():
                    LOG.info("console logging redirected to `tqdm.write()`")
                # logging restored

        # logging NOT restored
        LOG.info("console logging NOT redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:01:37.847029
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    class FakeTqdm(object):

        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def write(self, s):
            pass

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(tqdm_class=FakeTqdm):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:01:42.843134
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging  # noqa
    from tqdm import trange, tqdm
    from tqdm.contrib import logger as tqdm_logger
    logger = tqdm_logger.getLogger(__name__)
    tqdm.set_slower_interval(default=1e10)
    with tqdm_logging_redirect(desc=__name__, logger=logger,
                               tqdm=trange):
        logger.info(__name__)

# Generated at 2022-06-22 05:01:45.803298
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    """
    Tests the constructor of class `_TqdmLoggingHandler`
    """
    _TqdmLoggingHandler()
    # TODO: How to ensure that the constructor does nothing wrong?


# Generated at 2022-06-22 05:01:58.043094
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect, _TqdmLoggingHandler

    # Test loggers -> stdout/stderr
    default_handlers = [logging.getLogger().handlers]
    try:
        with tqdm_logging_redirect(leave=True):
            logging.info("test")
    finally:
        # Restore loggers
        logging.getLogger().handlers = default_handlers[0]
    assert isinstance(logging.getLogger().handlers[-1], _TqdmLoggingHandler)
    assert logging.getLogger().handlers[-1].stream in {sys.stdout, sys.stderr}

    # Test loggers -> log

# Generated at 2022-06-22 05:02:04.906513
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test ``_TqdmLoggingHandler.emit()`` by utilizing the verbose
    ``logging.StreamHandler.emit()`` code.
    """
    from tqdm.contrib.test import _patchable_print, _patchable_input

    orig_stdout = sys.stdout

# Generated at 2022-06-22 05:02:15.019204
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os

    # Test that the output is added to the stream (stdout for example)
    output = 'test_tqdm_logging_redirect'
    with tqdm_logging_redirect(total=1, desc=output) as pbar:
        pbar.update()
        assert output in sys.stdout.getvalue()

    # Test that the output is added to the file
    output = 'test_tqdm_logging_redirect'
    fd, file_name = tempfile.mkstemp()
    with open(fd, 'w'):
        with tqdm_logging_redirect(total=1, desc=output, file=file_name) as pbar:
            pbar.update()
        with open(file_name, 'r') as f:
            assert output in f



# Generated at 2022-06-22 05:02:19.026384
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler(std_tqdm)
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream in {sys.stdout, sys.stderr}
    assert handler.tqdm_class(disable=True).disable is True


# Generated at 2022-06-22 05:02:29.523127
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import time
    import tqdm
    from tqdm.contrib import logging as tqdlg
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdlg.tqdm_logging_redirect() as pbar:
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    time.sleep(.01)
                elif i == 8:
                    break
        print('\n' * 2)

# Generated at 2022-06-22 05:02:41.600421
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    #from tqdm.tests import common
    #from tqdm import tqdm

    # Monkey-patching tqdm to use StringIO
    old_stdout, sys.stdout = sys.stdout, io.StringIO()

# Generated at 2022-06-22 05:02:56.130694
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .main import tqdm
    LOG = logging.getLogger(__name__)

    def test():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test()
    # logging restored



# Generated at 2022-06-22 05:03:00.072852
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import test_logging_redirect_tqdm
    test_logging_redirect_tqdm()

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-22 05:03:09.313952
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import tqdm

    # Create logger object
    log = logging.getLogger('logger')
    log.setLevel(logging.INFO)

    # Test TQDMRedirectHandler
    log.addHandler(_TqdmLoggingHandler())
    log.info('Testing')
    assert log.handlers[-1].stream is sys.stdout

    # Test logging_redirect_tqdm
    with logging_redirect_tqdm():
        with tqdm(disable=True, leave=True) as pbar:
            for _ in range(10):
                log.info('Testing')

    # Original logging handlers should be restored
    assert pbar.fp is sys.stdout
    assert log.handlers[-1].stream is sys.stdout

# Generated at 2022-06-22 05:03:18.017120
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Tests the method emit of class _TqdmLoggingHandler.
    """
    # Set some reasonable defaults
    handler = _TqdmLoggingHandler()  # type: ignore
    handler.setLevel(logging.DEBUG)

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Emit a log
    logger.debug("info msg")
    # Should not fail

# Generated at 2022-06-22 05:03:20.886971
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from .tests import test_main
    try:
        from mock import patch  # type: ignore
    except ImportError:
        return  # e.g. python3.4 on openSUSE.
    with patch('logging.Handler.__init__', lambda self: None):
        # (1) No argument
        handler = _TqdmLoggingHandler()
        assert handler.tqdm_class is std_tqdm
        # (2) Argument
        handler = _TqdmLoggingHandler(tqdm_class=test_main.Dummy)
        assert handler.tqdm_class is test_main.Dummy


# Generated at 2022-06-22 05:03:28.044481
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import unittest
    import os

    LOG = logging.getLogger(__name__)

    class TestLoggingRedirect(unittest.TestCase):
        def setUp(self):
            logging.basicConfig(level=logging.INFO)

        def test_tqdm_logging_redirect(self):
            from tqdm.contrib.logging import tqdm_logging_redirect

            with tqdm_logging_redirect():
                for i in range(4):
                    if i == 2:
                        LOG.info("console logging redirected to `tqdm.write()`")

        def test_logging_redirect_tqdm(self):
            from tqdm.contrib.logging import logging_redirect_tqdm


# Generated at 2022-06-22 05:03:38.267044
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class AbcTqdm(object):
        def __init__(self):
            pass

        def write(self, msg, file=sys.stderr):
            self.msg = msg

        def flush(self):
            pass

    class DummyLogger(object):
        def __init__(self):
            pass
        def handleError(self, error):
            pass

    dummy_logger = DummyLogger()
    abc_tqdm = AbcTqdm()
    stream = sys.stderr
    verbosity = 2
    abc_tqdm.verbosity = verbosity
    assert abc_tqdm.verbosity == 2
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=AbcTqdm)
    tqdm_handler.tq

# Generated at 2022-06-22 05:03:44.047807
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-22 05:03:51.471838
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=2):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 05:03:54.072426
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.getLogger(__name__).info('Hello')



# Generated at 2022-06-22 05:04:21.517174
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    from .tests_tqdm import pretest_posttest

    with pretest_posttest():
        with tqdm_logging_redirect(None, desc="test", tqdm=tqdm) as pbar:
            for i in range(9):
                if i == 4:
                    LOG = logging.getLogger(__name__)
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()
        # logging restored

# Generated at 2022-06-22 05:04:24.157106
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_handler, logging.StreamHandler)
    assert tqdm_handler.level == logging.NOTSET
    assert tqdm_handler.formatter is None
    assert tqdm_handler.stream == sys.stderr


# Generated at 2022-06-22 05:04:29.778746
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    pbar = None
    try:
        with tqdm_logging_redirect():
            pbar = std_tqdm(range(9))
            for i in pbar:
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
    finally:
        pbar.close()

# Generated at 2022-06-22 05:04:35.328109
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    root_handler = logging.root.handlers[0]

    message = "console logging redirected to `tqdm.write()`"
    with tqdm_logging_redirect(desc='test'):
        for i in trange(9):
            if i == 4:
                logging.info(message)

    assert message in open('/dev/null').read()
    assert not root_handler.stream.isatty()

# Generated at 2022-06-22 05:04:45.904956
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    LOG = logging.getLogger(__name__)

# Generated at 2022-06-22 05:04:49.898107
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        tqdm_logging_handler = _TqdmLoggingHandler()
    except Exception:
        assert False, 'Exception in the constructor of class _TqdmLoggingHandler.'


# Generated at 2022-06-22 05:04:58.617823
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys
    import unittest

    class LoggingRedirectorTestCase(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.handler = _TqdmLoggingHandler()
            self.handler.stream = self.output
            self.logger = logging.getLogger('test logger')
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.INFO)

        def tearDown(self):
            for handler in self.logger.handlers:
                self.logger.removeHandler(handler)
            self.handler.close()
            self.output.close()

        def test_emit(self):
            msg = 'test message'
            self.output.trunc

# Generated at 2022-06-22 05:05:09.304536
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test logging_redirect_tqdm function
    """
    import logging
    import sys
    import tqdm
    from tqdm._tqdm import TqdmType

    assert not sys.stderr.isatty()  # for testing: can't write to stdout/err
    try:
        import tqdm
    except ImportError:
        print("ERROR: tqdm not found; skipping logging_redirect_tqdm() "
              "function test.")
    else:
        with tqdm.tqdm(disable=True) as pbar:
            pbar.clear()

            with logging_redirect_tqdm():
                logging.info("info message")
                # The above two lines should be displayed on pbar (and not on
                # any other

# Generated at 2022-06-22 05:05:15.024543
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9, leave=False):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:05:17.836860
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        _TqdmLoggingHandler()
    except Exception as e:
        print("Caught exception: " + str(e))
        assert False


# Generated at 2022-06-22 05:06:05.089710
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    for i in tqdm_logging_redirect(range(9)):
        if i == 4:
            logging.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-22 05:06:12.787874
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class MockTqdm():
        def __init__(self):
            pass

        def write(self):
            pass

        @classmethod
        def write(cls):
            pass

        @staticmethod
        def write(self):
            pass

    # test class method write
    handler = _TqdmLoggingHandler(MockTqdm)
    assert handler.tqdm_class.write is MockTqdm.write

    # test static method write
    handler = _TqdmLoggingHandler(MockTqdm)
    assert handler.tqdm_class.write is MockTqdm.write

    # test instance method write
    MockTqdm.__init__ = lambda self: setattr(self, 'write', lambda *args, **kwargs: None)