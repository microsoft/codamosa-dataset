

# Generated at 2022-06-22 04:56:16.605778
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import unittest
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm
    logg = logging.getLogger('test_tqdm_logging_redirect')

    class Test_tqdm_logging_redirect(unittest.TestCase):
        def setUp(self):
            super(Test_tqdm_logging_redirect, self).setUp()
            self.loggers = [logging.root, logg]
            logging.basicConfig(level=logging.INFO)

        def test(self):
            with tqdm_logging_redirect():
                logg.error('logging redirected to `tqdm.write()`')


# Generated at 2022-06-22 04:56:24.725314
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import std_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)

# Generated at 2022-06-22 04:56:37.555885
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm.notebook as nt
    nt.tqdm.pandas('test', dynamic_ncols=True)
    from tqdm._tqdm_notebook import tqdm_notebook
    from tqdm.pandas import tqdm_pandas
    from tqdm.autonotebook import tqdm
    from .tests_tqdm import pretest_posttest_print_report, _range
    from .tests_tqdm import closing, closing_iter, closing_set_description
    from .tests_tqdm import closing_set_description_dict
    import logging
    import time

    with closing(logging.getLogger()) as root_logger:
        root_logger.setLevel(logging.INFO)

# Generated at 2022-06-22 04:56:49.303787
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .gui import tqdm_notebook
    from .gui import tqdm_pandas
    from .std import tqdm
    from .std import tqdm_gui

    def test_func(tqdm_, loggers):
        with tqdm_logging_redirect(
            total=4,
            desc='foobar',
            tqdm_class=tqdm_,
            loggers=loggers
        ) as pbar:
            assert pbar.total == 4
            assert pbar.desc == 'foobar'
            assert len(loggers) == 1
            LOG = loggers[0]
            LOG.info('console logging redirected to `tqdm.write()`')
            assert not _is_console_logging_handler(LOG.handlers[0])
            pbar.update()

# Generated at 2022-06-22 04:56:51.799018
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.stream == sys.stderr

# Generated at 2022-06-22 04:56:59.509340
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # Test for default value of
    # `tqdm_class` in class `_TqdmLoggingHandler`
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert tqdm_logging_handler.tqdm_class is std_tqdm

    class NewTqdm(std_tqdm):
        pass

    tqdm_logging_handler = _TqdmLoggingHandler(
            tqdm_class=NewTqdm)
    assert tqdm_logging_handler.tqdm_class is NewTqdm

# Generated at 2022-06-22 04:57:01.655089
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info('Abcd')

# Generated at 2022-06-22 04:57:14.007844
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)

    msg = 'This is a test'
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logger.info(msg)
        assert msg

# Unit test

# Generated at 2022-06-22 04:57:18.801446
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
    # pylint: disable=unused-argument
    def func(*args):
        """logging functionality test function"""
        LOG.info("console logging redirected to `tqdm.write()`")
    with logging_redirect_tqdm():
        func()



# Generated at 2022-06-22 04:57:29.656864
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from logging import StreamHandler, getLogger, INFO
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stdout', new=BytesIO()) as fake_stdout:
        tqdm_handler = _TqdmLoggingHandler()
        tqdm_handler.stream = fake_stdout
        tqdm_handler.setFormatter(StreamHandler(fake_stdout).formatter)
        logger = getLogger('logging_redirect_tqdm')
        logger.setLevel(INFO)

        logger.info('Hello info!')
        assert fake_stdout.getvalue().strip() == 'INFO:logging_redirect_tqdm:Hello info!'

# Generated at 2022-06-22 04:57:41.899683
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)

    # check that no exception raised if no logger
    with tqdm_logging_redirect():
        pass

    # check that logger redirected to tqdm
    with tqdm_logging_redirect(loggers=[logger], desc='test_logging_redirect'):
        logger.info('line1')
        logger.info('line2')

# Generated at 2022-06-22 04:57:52.907701
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from six import StringIO
    from unittest import TestCase
    from ..std import tqdm
    from logging import StreamHandler, StreamHandler, INFO, basicConfig

    class TestTqdm(tqdm):
        def write(self, *args, **kwargs):
            super(TestTqdm, self).write(*args, **kwargs)
            self.data += args
            self.write_kwargs += kwargs

    class TestHandler(_TqdmLoggingHandler):
        def __init__(self):
            super(TestHandler, self).__init__(TestTqdm)
            self.data = []
            self.write_kwargs = []
            self.stream = StringIO()

    test_logger = logging.getLogger(__name__ + '.test_logger')

# Generated at 2022-06-22 04:57:57.103303
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    log_msg = "test logging msg"
    handler = _TqdmLoggingHandler()
    handler.stream = io.StringIO()
    record = logging.LogRecord(name='test', level=100,
                               pathname='/', lineno=1, msg=log_msg, args=None,
                               exc_info=None)
    handler.emit(record)
    assert (handler.stream.getvalue() == log_msg + '\n')


# Generated at 2022-06-22 04:58:05.993122
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    "Test logging_redirect_tqdm with the standard logger"
    from tqdm import tqdm
    import logging
    try:
        with logging_redirect_tqdm():
            try:
                tqdm.set_lock(True)
                # Redirecting logger to tqdm
                log = logging.getLogger(__name__)
                # Logging 4 lines
                for i in range(4):
                    log.info('{}'.format(i))
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                pass
    finally:
        tqdm.lock_instances(False)
        tqdm.set_lock(False)

# Generated at 2022-06-22 04:58:12.590951
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class FakeLogger(object):
        def __init__(self):
            self.handlers = []
    logger1 = FakeLogger()
    logger2 = FakeLogger()
    loggers = [logger1, logger2]
    with logging_redirect_tqdm(loggers=loggers):
        assert len(logger2.handlers) == 1
        assert len(logger1.handlers) == 1


# Generated at 2022-06-22 04:58:24.076914
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.contrib import DummyTqdmFile
    with DummyTqdmFile() as f:
        _TqdmLoggingHandler(tqdm_class=std_tqdm).emit(
            logging.makeLogRecord(dict(msg='foo', levelname='INFO')))
        assert f.getvalue() == 'foo\n'
    with DummyTqdmFile() as f:
        _TqdmLoggingHandler(tqdm_class=std_tqdm).emit(
            logging.makeLogRecord(
                dict(msg='foo', levelname='ERROR', exc_info=True)))
        assert f.getvalue() == 'foo\nTraceback (most recent call last):\n'

# Generated at 2022-06-22 04:58:35.151193
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import logging.config
    import os
    import shutil
    import tempfile

    from tqdm.contrib import logging_redirect_tqdm


# Generated at 2022-06-22 04:58:46.785086
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logging.basicConfig(level=logging.INFO)

    # reset log handlers
    logging.root.handlers = []

    tqdm_handler = _TqdmLoggingHandler()
    logging.root.addHandler(tqdm_handler)

    def check_streams(stream):
        original_log = logging.Logger.info
        def info(logger, msg):
            assert logger.handlers[0].stream == stream
            original_log(logger, msg)

        logging.Logger.info = info
        logging.info("TEST REDIRECT")
        assert stream.getvalue() == "TEST REDIRECT\n"
        logging.Logger.info = original_log


# Generated at 2022-06-22 04:58:54.682331
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    try:
        from unittest.mock import Mock  # type: ignore
    except ImportError:
        from mock import Mock  # type: ignore

    def assert_called(obj):
        if isinstance(obj, list):
            for o in obj:
                assert_called(o)
        elif isinstance(obj, Mock):
            obj.assert_called()

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect() as pbar:
        # pbar = Mock()
        # assert_called(pbar)
        pbar.write(str(pbar))
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:59:00.644718
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    msg = 'test'
    with std_tqdm.TqdmDummy() as pbar:
        _TqdmLoggingHandler().emit(logging.LogRecord('name', 20, 'pathname', 1, msg, (), None, None))
        assert pbar.n == 0
        assert pbar.last_print_n == 0
        assert pbar.msg == msg

# Generated at 2022-06-22 04:59:18.304313
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    with tqdm(leave=True, disable=True) as pbar:
        with logging_redirect_tqdm(loggers=[LOG], tqdm_class=tqdm):
            for i in range(3):  # pylint: disable=unused-variable
                pbar.write("foo")
                LOG.info("bar")
    assert pbar.n == 3
    print("\n".join(pbar.write.write.call_args_list))
    assert pbar.write.write.call_args_list == [
        call('foo\n'), call('bar\n'), call('bar\n')]


if __name__ == '__main__':
    test_logging_

# Generated at 2022-06-22 04:59:23.556014
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(4):
            if i == 2:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-22 04:59:30.832990
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import inspect
    test_out = StringIO()
    module_name = inspect.getmodule(inspect.stack()[0][0]).__name__
    logger = logging.getLogger(module_name)
    logger.addHandler(_TqdmLoggingHandler())
    logger.setLevel(logging.DEBUG)
    logger.info("info")
    logger.debug("debug")
    logger.warning("warning")
    logger.error("error")
    assert test_out.getvalue() == "info\ndebug\nwarning\nerror\n"

# Generated at 2022-06-22 04:59:40.936301
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from .tqdm import trange
    from .contrib import logging as tqdm_logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                desc='console logging redirected to `tqdm.write()`',
                loggers=[LOG],
                tqdm_class=tqdm_logging.tqdm) as pbar:
            for _ in trange(9):
                LOG.info("It works!")
                pbar.update()
        # logging restored

# Generated at 2022-06-22 04:59:44.930752
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.getLogger(__name__)

    # This is just a smoke test for now
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:59:54.208538
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)
    with tqdm.tqdm(total=10) as pbar:
        for _ in range(10):
            logger.info(str(_))
            pbar.update()
    logger.removeHandler(tqdm_handler)
    logger.setLevel(logging.NOTSET)
    logger.propagate = True

# Generated at 2022-06-22 05:00:00.225588
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Arrange
    _TqdmLoggingHandler_emit_setup()
    handler = _TqdmLoggingHandler()
    handler.stream = sys.stdout

    # Act
    handler.emit(None)

    # Assert
    _TqdmLoggingHandler_emit_teardown()
    assert(not sys.stdout.closed)


# Generated at 2022-06-22 05:00:04.761175
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        import StringIO
    except ImportError:
        from io import StringIO
    tqdm_log_stream = StringIO()
    logging_handler = _TqdmLoggingHandler(tqdm_class = std_tqdm)
    logging_handler.stream = tqdm_log_stream
    logging_handler.emit('Test_Message')
    tqdm_log_stream.seek(0)
    assert tqdm_log_stream.read() == 'Test_Message' + '\n'

# Generated at 2022-06-22 05:00:10.967852
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger('test_tqdm_logging_redirect')
    LOG.setLevel(logging.INFO)
    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        for i in pbar(range(4)):
            LOG.info('{} info'.format(i))

# Generated at 2022-06-22 05:00:12.226189
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:00:27.816892
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(unit='B', unit_scale=True, miniters=1,
                               desc='test') as pbar:
        assert isinstance(pbar, std_tqdm)
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:34.784063
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    with tqdm_logging_redirect(total=9, desc='redirected console logging') as pbar:
        for i in trange(9):
            if i == 4:
                logging.warning('console logging redirected to `tqdm.write()`')
        assert pbar._desc == 'redirected console logging:'
    from logging import getLogger
    LOG = getLogger(__name__)
    with tqdm_logging_redirect(total=9, desc='redirected console logging', loggers=[LOG]) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.warning('console logging redirected to `tqdm.write()`')
        assert pbar._desc == 'redirected console logging:'




# Generated at 2022-06-22 05:00:45.638179
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    tqdm_class_ = std_tqdm
    with tqdm_class_(["a", "b", "c"], desc='foo') as pbar, \
         logging_redirect_tqdm(tqdm_class=tqdm_class_):
        pbar.update(1)
        assert pbar.format_dict == {'n': 1, 'total': 3}
        assert str(pbar) == '  0%|          | '
    LOG = logging.getLogger(__name__)
    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:00:57.672957
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import io
    import pytest

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(stream=io.StringIO())
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    def test_msg(expected, actual):
        # type: (str, str) -> None
        pytest.assume(expected == actual)

    # Testing tqdm_logging_redirect

# Generated at 2022-06-22 05:01:09.479544
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import pytest
    from contextlib import redirect_stdout, redirect_stderr

    LOG = logging.getLogger(__name__)

    def run_test():
        with tqdm_logging_redirect(loggers=[LOG]):
            LOG.info("warning")
            LOG.warning("warning")
            LOG.error("error")


# Generated at 2022-06-22 05:01:14.984212
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    class MyTqdm(std_tqdm):
        def write(self, msg, file=None):
            if file is None:
                pass
            else:
                file.write('<MyTqdm>:' + msg)
    handler = _TqdmLoggingHandler(MyTqdm)
    assert (isinstance(handler.tqdm_class, type))



# Generated at 2022-06-22 05:01:25.965844
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_msg = 'test_msg'
    stream_backup = std_tqdm.write.stream
    std_tqdm.write.stream = open('test_logging.txt', 'w')
    logging_handler = _TqdmLoggingHandler()

# Generated at 2022-06-22 05:01:27.761327
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_log_handler = _TqdmLoggingHandler()
    assert isinstance(tqdm_log_handler, logging.StreamHandler)

# Generated at 2022-06-22 05:01:36.200807
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    def test_func(logging_redirect_kwargs):
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9, desc=__name__,
                                   logging_redirect_kwargs=logging_redirect_kwargs):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test_func(None)
    test_func({'loggers': [LOG]})

# Generated at 2022-06-22 05:01:37.334763
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    assert _TqdmLoggingHandler() is not None


# Generated at 2022-06-22 05:01:59.419523
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()



# Generated at 2022-06-22 05:02:11.173959
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from signal import signal, SIGPIPE, SIG_DFL
    signal(SIGPIPE, SIG_DFL)
    import time
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    from ..std import tqdm

    log.info('before')
    with logging_redirect_tqdm() as pbar:
        time.sleep(0.1)
        log.info('logging redirected to tqdm')
        time.sleep(0.1)
        with tqdm_logging_redirect(
                tqdm_class=tqdm,
                desc='desc',
                leave=False,
                total=1) as pbar2:
            time.sleep(0.1)

# Generated at 2022-06-22 05:02:22.594127
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Logging test case
    """
    # pylint: disable=redefined-outer-name
    from tqdm.tests import tests
    from tqdm._utils import _term_move_up

    @contextmanager
    def stdout_redirect(stdout):
        # type: ([str]) -> Iterator[None]
        old_stdout = sys.stdout
        sys.stdout = stdout
        try:
            yield
        finally:
            sys.stdout = old_stdout

    with tests("with logging_redirect_tqdm() as pbar:", end_at=True):
        log_str = []


# Generated at 2022-06-22 05:02:29.565175
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        # Create a StringIO object to write to
        import StringIO  # Python 2
        from cStringIO import StringIO  # Python 3
    except ImportError:
        from io import StringIO  # Python 3.0 - 3.2
    my_string_io = StringIO()
    my_handler = _TqdmLoggingHandler(std_tqdm)
    my_handler.stream = my_string_io
    my_handler.emit('test')
    assert 'test' == my_string_io.getvalue()

# Generated at 2022-06-22 05:02:38.166512
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    logger.info('Start of logger info test. No redirection.')
    with tqdm_logging_redirect():
        logger.info('Redirected debug to tqdm.')
    logger.info('End of logger info test.')

# Generated at 2022-06-22 05:02:41.517679
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log = logging.getLogger('test_log')
    log.setLevel(logging.INFO)
    log_handlers = log.handlers
    with tqdm_logging_redirect():
        log.info('test')

# Generated at 2022-06-22 05:02:45.865965
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    assert tqdm_handler.stream in {sys.stdout, sys.stderr}
    assert tqdm_handler.tqdm_class == std_tqdm


# Generated at 2022-06-22 05:02:46.762998
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler()

# Generated at 2022-06-22 05:02:55.987468
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from logging import LogRecord
    stream = BytesIO()
    handler = _TqdmLoggingHandler()
    handler.stream = stream
    record = LogRecord(
        name='test_th',
        level=logging.INFO,
        pathname='tqdm/contrib/__init__.py',
        lineno=448,
        msg='test message',
        args=(),
        exc_info=None,
    )
    handler.emit(record)
    assert stream.getvalue() == b'INFO:test_th:test message\n'


# Generated at 2022-06-22 05:03:06.695113
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test `logging_redirect_tqdm`.
    """
    import logging
    from tqdm import trange
    log = logging.getLogger(__name__)
    log.addHandler(logging.NullHandler())
    log.propagate = False
    log.setLevel(logging.INFO)
    # nothing happens if no handlers are specified
    with logging_redirect_tqdm():
        for _ in trange(3):
            log.info('logging should not be redirected')
    # default redirect
    log.handlers = []
    with logging_redirect_tqdm():
        for _ in trange(3):
            log.info('logging should be redirected')
    # only selected loggers redirected
    log.handlers = []

# Generated at 2022-06-22 05:03:57.465933
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    from tqdm import std_tqdm
    from tqdm.test import _range

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = StringIO()
    tqdm_handler = _TqdmLoggingHandler(std_tqdm)
    tqdm_handler.stream = stream
    logger.addHandler(tqdm_handler)

    logger.info("a message")
    assert stream.getvalue() == ""

    for i in _range(10):
        logger.info("a message")

    assert stream.getvalue() == "a message\n"

# Generated at 2022-06-22 05:04:04.402294
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log_str = "test log string"
    captured_output = io.StringIO()
    test_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    test_handler.stream = captured_output
    test_record = logging.LogRecord(
        "test_name", logging.INFO, "test_pathname", 1,
        log_str, "test_args", None)
    test_handler.emit(test_record)
    assert captured_output.getvalue() == log_str + "\n"

# Generated at 2022-06-22 05:04:15.210383
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log_tqdm = logging.getLogger('TEST')
    log_tqdm.propagate = False

    log_stdout = logging.getLogger('TEST.STDOUT')
    log_stdout.propagate = False

    log_stderr = logging.getLogger('TEST.STDERR')
    log_stderr.propagate = False

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s'))
    log_stdout.addHandler(console)

    console = logging.StreamHandler()
    console.setLevel(logging.ERROR)

# Generated at 2022-06-22 05:04:22.896375
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    log_list = list()
    with open('test.log', 'a+') as test_file:
        root_logger = logging.getLogger()
        root_logger.addHandler(logging.StreamHandler(test_file))
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
        # logging restored
        test_file.seek(0)
        log_list = test_file.readlines()
        test_file.close()
    assert "console logging redirected to `tqdm.write()`\n" in log_list



# Generated at 2022-06-22 05:04:28.588368
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import io
    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    stream = io.StringIO()
    logger.info("hello", file=stream)
    assert "hello" in stream.getvalue()

# Generated at 2022-06-22 05:04:35.449618
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    if __name__ == '__main__':
        import unittest
        import logging
        import tqdm
        from tqdm.contrib.logging import _TqdmLoggingHandler
        from .tests_tqdm import StringIO

        class TestUnitLogging(unittest.TestCase):
            def test__TqdmLoggingHandler(self):
                tqdm_class = tqdm.std.tqdm
                tqdm_handler = _TqdmLoggingHandler(tqdm_class)
                tqdm_handler.setFormatter('%(message)s')
                tqdm_handler.stream = StringIO()

                # check emit
                msg = 'test message'

# Generated at 2022-06-22 05:04:45.673906
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    try:
        from tqdm import tqdm
    except ImportError:
        raise ImportError('Requires `tqdm` package.')

    with logging_redirect_tqdm():
        logger.info('123')
        logger.error('456')
        logger.critical('789')

        with tqdm(total=100) as pbar:
            logger.debug('Lorem')
            pbar.update(pbar.total // 2)
            logger.info('Ipsum')
            pbar.update(pbar.total // 2)
            logger.warn('Dolor')
        logger.error('Sit')
        logger.critical('Amet')

# Generated at 2022-06-22 05:04:53.695418
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time
    LOG = logging.getLogger(__name__)
    def test_function():
        with tqdm_logging_redirect(desc="test desc", unit="B", ascii=True) as pbar:
            for i in range(0, 10):
                pbar.update(i)
                time.sleep(0.03)
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    test_function()


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-22 05:04:58.741978
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    hdlr1 = _TqdmLoggingHandler()
    assert isinstance(hdlr1, _TqdmLoggingHandler)

    # assigned it to a class, not a type
    tqdm_class = std_tqdm
    hdlr2 = _TqdmLoggingHandler(tqdm_class=tqdm_class)
    assert isinstance(hdlr2, _TqdmLoggingHandler)


# Generated at 2022-06-22 05:05:06.332020
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for function logging_redirect_tqdm"""
    import logging

    LOG = logging.getLogger(__name__)
    try:
        with logging_redirect_tqdm():
            LOG.info('test message')
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        raise AssertionError('function logging_redirect_tqdm failed')