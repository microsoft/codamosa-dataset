

# Generated at 2022-06-22 04:56:25.467635
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    import logging
    import sys
    import unittest
    import warnings
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    logger = logging.getLogger()
    logger.propagate = False

    class _TqdmLoggingHandlerTester(_TqdmLoggingHandler):
        def __init__(self, *args, **kwargs):
            self.logger = logger
            self.stream = StringIO()
            super(_TqdmLoggingHandlerTester, self).__init__(*args, **kwargs)

    original_stderr = sys.stderr

# Generated at 2022-06-22 04:56:31.491387
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # initializing the handler with no argument
    # before running the test
    handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    # testing if the handler.tqdm_class is not None
    assert handler.tqdm_class is not None


# Generated at 2022-06-22 04:56:38.172530
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    else:
        test_logging_redirect_tqdm()

# Generated at 2022-06-22 04:56:43.219138
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if __name__ == '__main__':
        import logging
        from tqdm import trange

        logging.basicConfig(level=logging.INFO)
        try:
            with tqdm_logging_redirect(desc='test', unit='a'):
                for i in trange(9):
                    logging.info('In test an iteration')
        except (KeyboardInterrupt, SystemExit):
            raise
        except:  # noqa pylint: disable=bare-except
            logging.info('Error in test')
        # logging restored

# Generated at 2022-06-22 04:56:47.825434
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)
    buffer = []
    with logging_redirect_tqdm():
        for i in range(3):
            LOG.info(i)
    assert buffer == ['0\n', '1\n', '2\n']


# Generated at 2022-06-22 04:56:58.519516
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from os.path import join
    from tempfile import gettempdir
    from tqdm import tqdm
    from .utils import suppress_stderr, suppress_stdout
    # Create a new logging handler to redirect logging to stderr
    handler = _TqdmLoggingHandler()
    logger = logging.getLogger("test_logging")
    logger.addHandler(handler)
    # Save the current handlers and stream and replace stderr with a file
    current_stream = handler.stream
    current_handlers = logger.handlers
    handler.stream = open(join(gettempdir(), 'test_logging_redirect.out'), 'w')
    # Check the behaviour of the emit method within a context manager

# Generated at 2022-06-22 04:57:08.718146
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from contextlib import redirect_stdout

    capture_stdout = sys.stdout

    class FakeTqdm:
        def write(self, msg, file=None):
            capture_stdout.write(msg)

    fake_tqdm = FakeTqdm()

    fake_logging_handler = _TqdmLoggingHandler(tqdm_class=fake_tqdm)

    fake_record = logging.LogRecord("", "", "", "", "", "", "")
    fake_record.msg = "test"

    fake_logging_handler.emit(fake_record)

    with redirect_stdout(capture_stdout):
        print("test")

# Generated at 2022-06-22 04:57:14.089614
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    stream = sys.stdout
    with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar:
        tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        assert pbar.file == stream
        assert tqdm_handler.stream == stream


# Generated at 2022-06-22 04:57:24.774297
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.test_utils import StringIO

    # Disable logger info level, otherwise the test will fail due to
    # the fact that tqdm_notebook progressbar and logging.root.info()
    # both print to stdout.
    logging.basicConfig(level=logging.WARNING)

    from tqdm import tqdm_notebook
    from logging import getLogger

    log = getLogger()

    capture_streams = StringIO()
    pbar = None
    with capture_streams.redirect_stdout(mode='capture'):
        pbar = tqdm_logging_redirect(loggers=[log, logging.root],
                                     file=capture_streams.stdout)

    msg = 'this is a test message'
    log.info(msg)
    #

# Generated at 2022-06-22 04:57:30.012560
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-22 04:57:45.837508
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect
    """
    from ..std import tqdm

    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in pbar:
                pbar.set_description("test")
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 04:57:49.264217
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        for i in range(10):
            pbar.update(1)



# Generated at 2022-06-22 04:58:01.808882
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _decode
    from tqdm import trange
    from .logging import tqdm_logging_redirect

    # logging.basicConfig(level=logging.INFO)
    log_text = 'console logging redirected to `tqdm.write()`'
    log_text_decode = (log_text if _supports_unicode
                       else _decode(log_text, errors='ignore'))
    with tqdm_logging_redirect() as pbar:
        for i in trange(9, file=pbar):
            if i == 4:
                logging.info(log_text)
    assert log_text_decode in pbar.write.buf

# Generated at 2022-06-22 04:58:13.621691
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert isinstance(handler, logging.StreamHandler)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored

    with logging_redirect_tqdm(loggers=[logging.getLogger()]):
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-22 04:58:20.025631
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    tqdm_handler.stream = sys.stdout
    tqdm_handler.emit("hello world\n")
    tqdm_handler.emit("hello world\n")
    sys.stdout.close()

# Generated at 2022-06-22 04:58:27.241114
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    log = logging.getLogger(__name__)
    log.setLevel('DEBUG')
    log.propagate = False
    log_stdout = logging.StreamHandler(sys.stdout)
    log_stdout.setLevel('DEBUG')
    log_stdout.setFormatter(logging.Formatter('%(name)s %(levelname)s: %(message)s'))
    log.addHandler(log_stdout)
    with logging_redirect_tqdm():
        for _ in trange(5):
            log.info('console logging redirected to `tqdm.write`')

# Generated at 2022-06-22 04:58:38.365663
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm import trange
    except ImportError:
        print('SKIP: tqdm not installed')
        return

    from tqdm.contrib.logging import logging_redirect_tqdm, logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    original_logging_handlers = logging.root.handlers
    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm() as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    finally:
        logging.root.handlers = original_logging_handlers
    assert list(pbar) == list(range(9))

# Generated at 2022-06-22 04:58:44.977937
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler(std_tqdm)
    import io
    handler.stream = io.StringIO()

    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    logger.info("blah blah blah")

    assert handler.stream.getvalue() == "INFO:root:blah blah blah\n"
    handler.stream.close()



# Generated at 2022-06-22 04:58:56.550661
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tests_class import pretest, posttest  # pylint: disable=unused-variable

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    # initial test
    LOG.info('This is a test.')
    # test 1
    with tqdm_logging_redirect():
        LOG.info('This is a test.')
    # test 2
    with tqdm_logging_redirect(desc='Test 2'):
        LOG.info('This is a test.')
    with tqdm_logging_redirect(desc='Test 3', total=2):
        LOG.info('This is a test.')
        LOG.info('This is a test.')

# Generated at 2022-06-22 04:58:58.991979
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler=_TqdmLoggingHandler(std_tqdm)
    assert TRUE
    return handler

# Generated at 2022-06-22 04:59:07.723137
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    try:
        import tqdm
    except ImportError:
        return
    logger = logging.getLogger('logging_redirect_tqdm')

    with logging_redirect_tqdm():
        logger.info('hello world')

    logger.info('done')



# Generated at 2022-06-22 04:59:18.566471
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import (
        _TqdmLoggingHandler, _get_first_found_console_logging_handler,
        logging_redirect_tqdm)

    LOG = logging.getLogger(__name__)

    # redirect to tqdm.write()
    original_handlers = logging.root.handlers
    handlers = [logging.StreamHandler()]
    logging.root.handlers = handlers
    tqdm_handler = _get_first_found_console_logging_handler(handlers)
    assert tqdm_handler is not None
    assert not isinstance(tqdm_handler, _TqdmLoggingHandler)

# Generated at 2022-06-22 04:59:23.295711
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    try:
        assert _TqdmLoggingHandler(tqdm_class=std_tqdm)
    except:
        assert False
    assert True

# Unit tests for function _is_console_logging_handler

# Generated at 2022-06-22 04:59:26.860296
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    tqdm_logging_handler = _TqdmLoggingHandler()
    assert isinstance(
        tqdm_logging_handler, logging.StreamHandler) is True


# Generated at 2022-06-22 04:59:32.570960
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    with open("temp.txt", "w") as f:
        tlh.stream = f
        record = logging.LogRecord("name", logging.WARN, "/", 1, "msg", None, None)
        tlh.emit(record)
    with open("temp.txt") as f:
        lines = f.readlines()
    assert lines[0] == "WARN:name:msg\n"



# Generated at 2022-06-22 04:59:40.074941
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Note: this function should be run from the parent directory
    """
    from . import tgr_sample  # pylint: disable=import-outside-toplevel

    res = []
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for _ in tqdm.trange(5):
            tgr_sample.logging_function(res)



# Generated at 2022-06-22 04:59:45.725787
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    assert True

# Generated at 2022-06-22 04:59:58.161318
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    import io
    import os
    import time
    import tqdm.auto
    import numpy as np
    try:
        from typing import Literal
    except ImportError:
        tqdm_logging_redirect_mode = None
    else:
        tqdm_logging_redirect_mode = Literal['stdout', 'stderr']

    def _test_redirect(mode):
        # type: (tqdm_logging_redirect_mode) -> None
        assert isinstance(mode, str)
        if mode == 'stderr':
            stream = sys.stderr  # type: tqdm.utils.WriteFile
            out_stream = sys.stdout  # type: tqdm.utils.WriteFile

# Generated at 2022-06-22 05:00:05.430181
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    from tqdm.contrib import logger

    class CustomTqdm(tqdm.tqdm):
        """Subclass to allow customizing of the __enter__ and __exit__ methods.

        This class is necessary because the Pythonic way to override
        __enter__ and __exit__ is to define a manager class, but
        tqdm.tqdm doesn't allow that. It assumes that callers will
        directly instantiate a tqdm.tqdm object.
        """

        def __enter__(self):
            # This is necessary to avoid the default tqdm behavior,
            # which is to output a newline character when
            # __exit__ is called.
            self.leave = True

            # But that means we have to output manually.
            self.write('Progress: ')
            return self



# Generated at 2022-06-22 05:00:09.157245
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    logger = logging.Logger('test')
    tlh = _TqdmLoggingHandler()
    logger.addHandler(tlh)
    logger.info('hi')


# Generated at 2022-06-22 05:00:21.324033
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    with logging_redirect_tqdm():
        for _ in trange(3):
            pass
        log.warning("test")



# Generated at 2022-06-22 05:00:27.501420
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        import logging
        import unittest
        with tqdm_logging_redirect(total=100, unit='B', unit_scale=True):
            logging.info('this is a log message')  # noqa pylint: disable=logging-format-interpolation
            assert isinstance(sys.stdout.buffer, tqdm._io.StringIO)  # noqa pylint: disable=protected-access
    except BaseException as e:
        if 'no module' not in str(e):
            raise
    sys.stdout.buffer = sys.__stdout__



# Generated at 2022-06-22 05:00:34.008981
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    """
    Unit test to confirm that the constructor of _TqdmLoggingHandler
    returns a logging handler that uses tqdm.write to write
    """
    # Given
    tqdm_handler = _TqdmLoggingHandler()
    assert_format_method = """
    assert tqdm_handler.stream == sys.stdout
    """

    # When
    tqdm_handler.emit(logging.LogRecord("name", logging.INFO, "path", 1, "msg", (), None, None))

    # Then
    assert tqdm_handler.tqdm_class.write_called
    assert tqdm_handler.tqdm_class.file == sys.stdout

# Generated at 2022-06-22 05:00:42.342740
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from .logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:00:54.049104
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _MockTqdmSuperclass(std_tqdm):
        # pylint: disable=super-init-not-called
        def __init__(self, file=None):
            self.file = file
            self.write_called = False

        def write(self):
            self.write_called = True

    record = logging.LogRecord('name', logging.DEBUG, None, None, 'test', None, None)
    _TqdmLoggingHandler(tqdm_class=_MockTqdmSuperclass).emit(record)

if __name__ == '__main__':
    test__TqdmLoggingHandler_emit()

# Generated at 2022-06-22 05:00:55.184987
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    pass


# Generated at 2022-06-22 05:01:02.052020
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:01:08.336227
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # This test will fail if there is an exception in the code of method emit
    # - an exception that is not captured.
    msg = "test"
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.info(msg)

# Generated at 2022-06-22 05:01:17.293773
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import _range
    from .tqdm_gui import tgrange
    log_capture_string = "console logging redirected to `tqdm.write()`"
    log_capture_string_2 = "console logging redirected to `tqdm.write()_2`"
    log_test_begin = "tqdm._tqdm_gui_inst = <tqdm._tqdm_gui.tqdm._tqdm_gui.TQDMNotebook instance at 0x7f0f37467898>"
    log_test_end = "tqdm._tqdm_gui_inst = None"
    import logging
    import re
    import unittest

# Generated at 2022-06-22 05:01:27.181822
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    class _MockTqdm(object):
        def __init__(self):
            self.instr = ''

        def write(self, instr, file=None):
            if len(self.instr) > 0:
                self.instr = self.instr + '\n'
            self.instr += instr

    tqdm_class = _MockTqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    tqdm_handler.emit('Test emit')
    assert tqdm_handler.tqdm_class().instr == 'Test emit'
    tqdm_handler.emit('Test emit 2')
    assert tqdm_handler.tqdm_class().instr == 'Test emit\nTest emit 2'

# Generated at 2022-06-22 05:01:45.085925
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: (...) -> None
    # Set debug level to DEBUG to show debug msgs
    logging.basicConfig(level=logging.INFO)

    log = logging.getLogger(__name__)

    # Check that logging_redirect_tqdm works. Should write to console
    log.info("First message")
    with logging_redirect_tqdm():
        log.info("First message in tqdm")

    # Check that logging_redirect_tqdm works only for the right logger
    logger2 = logging.getLogger(__name__ + "2")
    logger2.info("Second message")
    with logging_redirect_tqdm(loggers=[logger2]):
        log.info("Second message in tqdm")

    # Check that logging_redirect_tqdm works only for the

# Generated at 2022-06-22 05:01:55.278694
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm

    def main():
        logging.basicConfig(level=logging.INFO)
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

    with std_tqdm.stdout_redirected(std_tqdm.std_captured_stdout()):
        main()
    with std_tqdm.stdout_redirected(std_tqdm.std_captured_stdout()):
        with logging_redirect_tqdm():
            main()



# Generated at 2022-06-22 05:02:00.130387
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    # pylint: disable=undefined-variable
    import logging
    from .tqdm import tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm(loggers=[LOG], tqdm_class=tqdm):
        LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:02:08.597333
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Check on temporary redirection of logging output to `tqdm.write()`"""
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=100, miniters=10,
                               leave=False, logger=LOG) as pbar:
        for i in pbar:
            if i == 50:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-22 05:02:17.196670
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from logging import (
        NOTSET,
        DEBUG,
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    )

    from io import StringIO

    from tqdm import tqdm

    _log_levels = {
        NOTSET: "NOTSET",
        DEBUG: "DEBUG",
        INFO: "INFO",
        WARNING: "WARNING",
        ERROR: "ERROR",
        CRITICAL: "CRITICAL"
    }

    # If a formatter is not explicitly set, a _TqdmLoggingHandler uses the
    # default Formatter configuration.
    # See <https://docs.python.org/3.5/library/logging.html>
    # We want to do like the default formatter, hence `levelname` is used to
    # get the level name, and `levelno` is

# Generated at 2022-06-22 05:02:27.966747
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    test method for _TqdmLoggingHandler class
    """
    class MockTqdmWrite(object):
        """
        Mocked tqdm.write
        """
        def __init__(self):
            self.called_list = []

        def __call__(self):
            self.called_list.append(1)

    _mock_tqdm_write = MockTqdmWrite()
    _handler = _TqdmLoggingHandler(tqdm_class=_mock_tqdm_write)
    _handler.emit(1)
    return _mock_tqdm_write.called_list != []

# Generated at 2022-06-22 05:02:33.579852
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test for function logging_redirect_tqdm"""
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:02:43.298075
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import _range

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:02:54.728475
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with StringIO() as our_stderr, logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")
        for _ in range(4):
            LOG.info("This is a test log")
    assert (our_stderr.getvalue()
            == "This is a test log\nThis is a test log\n"
               "This is a test log\nThis is a test log\n")



# Generated at 2022-06-22 05:03:05.586430
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    """
    # Skip Test if tqdm is not installed
    import tqdm
    # Skip Test if logging is not installed
    import logging
    # Skip Test if pytest is not installed
    import pytest

    with tqdm_logging_redirect(desc='Test tqdm_logging_redirect'):
        logging.info('Hello from logging')
        tqdm.write('Hello from tqdm')

    with tqdm_logging_redirect() as pbar:
        logging.info('Hello from logging')
        pbar.write('Hello from tqdm')

    with pytest.raises(ValueError):
        with tqdm_logging_redirect():
            raise ValueError

# Generated at 2022-06-22 05:03:34.441343
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with contextlib.redirect_stdout(None):
        tokens = [str(i) for i in range(10)]
        with tqdm_logging_redirect(loggers=[logging.root]) as pbar:
            logging.info("Start")
            for token in tokens:
                pbar.update()
                logging.info("Processing token: %s", token)
        logging.info("Finish")

# Generated at 2022-06-22 05:03:40.860057
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-22 05:03:46.639488
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm([LOG]):
        LOG.info("")
        LOG.info("console logging redirected to `tqdm_logging_redirect.write()`")
    assert True

# Generated at 2022-06-22 05:03:55.508472
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    try:
        from tqdm.contrib import ttest
    except:
        return

    with ttest.temporary_file(delete=False) as fobj:
        import logging
        import os
        from tqdm.contrib import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        with logging_redirect_tqdm(loggers=['logger'],
                                   tqdm_class=ttest):
            LOG.info("console logging redirected to `tqdm_class.write()`")
        LOG.info("logging restored")
        os.remove(fobj.name)

# Generated at 2022-06-22 05:03:59.334317
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.root]
    with tqdm_logging_redirect(loggers=loggers):
        logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-22 05:04:06.675478
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    # type: () -> None
    from tqdm import tqdm
    with tqdm_logging_redirect(int(1e6)) as pbar:
        logging.info("test")
        pbar.update(100)
        with tqdm_logging_redirect(int(1e6), tqdm_class=tqdm) as pbar2:
            logging.info("test2")
            pbar2.update(100)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test__TqdmLoggingHandler()

# Generated at 2022-06-22 05:04:15.210927
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create a logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)


# Generated at 2022-06-22 05:04:16.818634
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    handler = _TqdmLoggingHandler()
    assert handler


# Generated at 2022-06-22 05:04:17.963772
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logging.basicConfig(level=logging.INFO)
    logging.info('test')

# Generated at 2022-06-22 05:04:20.930059
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    _TqdmLoggingHandler(tqdm_class=std_tqdm)

if __name__ == '__main__':
    from .test_logging import test_redirect_logging
    test_redirect_logging()

# Generated at 2022-06-22 05:05:20.762762
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            iterable=range(3),
            tqdm_class=std_tqdm,
            loggers=[logging.root]
    ) as pbar:
        assert isinstance(pbar, std_tqdm)
        assert pbar.total == 3

        logging.info(
            "console logging redirected to "
            "`tqdm.write()` through `logging_redirect_tqdm()`"
        )
        # logging restored

# Generated at 2022-06-22 05:05:30.010683
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """Test for method emit of class _TqdmLoggingHandler."""
    # Silence all logging messages in this test
    logging.disable(logging.CRITICAL)

    import io
    from tqdm._utils import _term_move_up
    with io.StringIO() as f:
        sys.stderr = f
        s = "abcd\n"
        with _TqdmLoggingHandler() as handler:
            record = logging.LogRecord(
                name="",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=s,
                args=None,
                exc_info=None,
            )
            handler.emit(record)

        # Check we got the log message out of the stream
        assert f.getvalue

# Generated at 2022-06-22 05:05:41.697157
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from ..main import tqdm
    from .utils import FakeTQDM

    with tqdm(range(10)) as pbar, logging_redirect_tqdm([logging.root]):
        for i in range(5):
            logging.info('test')
        pbar.write('redirected console logging to tqdm.write()')
        for i in range(5):
            logging.info('test')

    # test with FakeTQDM
    with tqdm(range(10), tqdm_class=FakeTQDM) as pbar, logging_redirect_tqdm([logging.root]):
        for i in range(5):
            logging.info('test')
        pbar.write('redirected console logging to tqdm.write()')
       

# Generated at 2022-06-22 05:05:51.135870
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect(file=sys.stdout, desc='redirect_test') as pbar:
        for i in range(4):
            logging.info(str(i))
            pbar.update()
        pbar.n = None
        pbar.update()
        assert pbar.n == 5
        pbar.set_postfix(dict(pbar_postfix_key=pbar.n))

    try:
        with tqdm_logging_redirect() as pbar:
            assert False, 'tqdm_logging_redirect() invokes tqdm_class().__init__()'
    except TypeError:
        pass



# Generated at 2022-06-22 05:06:01.583496
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                total=9, desc='Redirect Console Logging to tqdm.write()'
        ) as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)
        # logging restored

# Generated at 2022-06-22 05:06:03.689122
# Unit test for constructor of class _TqdmLoggingHandler
def test__TqdmLoggingHandler():
    from tqdm import tqdm_notebook

    handler = _TqdmLoggingHandler(tqdm_class=tqdm_notebook)
    handler.emit("hello")

# Generated at 2022-06-22 05:06:07.963748
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")