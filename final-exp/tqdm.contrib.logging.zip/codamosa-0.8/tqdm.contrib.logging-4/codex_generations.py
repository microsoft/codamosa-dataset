

# Generated at 2022-06-12 14:42:50.843535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test function logging_redirect_tqdm"""
    from logging import basicConfig, StreamHandler, Formatter, INFO, NullHandler
    from io import StringIO
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.std import trange

    stream_out = StringIO()
    stream_err = StringIO()

    def get_tqdm_output(handlers):
        log = logging.getLogger('mylogger')
        for handler in handlers:
            log.addHandler(handler)

        trange(9)

        # assert that logging is still setup
        assert len(log.handlers) == 3
        assert set([type(handler) for handler in log.handlers]) == set([
            StreamHandler, NullHandler, _TqdmLoggingHandler])

        return

# Generated at 2022-06-12 14:42:58.146065
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect.
    """
    import logging
    import sys

    def logging_test(pbar):
        logging_handler = logging.StreamHandler(stream=sys.stdout)
        logging_handler.setLevel(logging.INFO)
        logger = logging.getLogger()
        logger.addHandler(logging_handler)

        for i in range(100):
            pbar.update(1)
            if i == 50:
                logging.info('Test tqdm_logging_redirect: %s', i)


# Generated at 2022-06-12 14:43:06.738502
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib import logging_redirect_tqdm
    from ..std import StringIO
    output = StringIO()
    # pylint: disable=protected-access
    with tqdm_logging_redirect(
            total=1, file=output, tqdm_class=tqdm, loggers=[logging.root],
            bar_format='{desc}{n_fmt}'
    ) as _:
        logging.info('logged')
    assert output.getvalue() == 'logged\r100%|██████████| 1/1 [00:00<00:00, ?it/s]\n'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:43:12.828508
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import unittest
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream_handler)

    with unittest.mock.patch('tqdm.std.tqdm.write') as mocked_write:
        with logging_redirect_tqdm([logger]):
            logger.info('this should go to tqdm')
        mocked_write.assert_called_with('this should go to tqdm', file=stream_handler.stream)



# Generated at 2022-06-12 14:43:17.127100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger()
    LOG.info("TEST")
    assert "TEST" in sys.stdout.getvalue()
    assert "TEST" not in std_tqdm.write.calls[0][0][0]

    with logging_redirect_tqdm():
        LOG.info("TEST")
    assert "TEST" not in sys.stdout.getvalue()
    assert "TEST" in std_tqdm.write.calls[-1][0][0]

    logging.shutdown()



# Generated at 2022-06-12 14:43:26.118595
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-12 14:43:34.011776
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test for `logging_redirect_tqdm()` function.
    """
    # We need to use `logging.getLogger()` because a previous
    # `logging.basicConfig()` with `stream=sys.stderr` has already been
    # called in `tqdm.__init__.py` and thus is above the logger stack.
    logger = logging.getLogger('tqdm_contrib_test')
    logger.propagate = False
    logger.handlers = []
    logger.addHandler(logging.StreamHandler())

    with logging_redirect_tqdm(loggers=[logger]):
        logger.warning('console logging redirected to `tqdm.write()`')

    logger.warning('back to normal')

# Generated at 2022-06-12 14:43:39.376367
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from io import StringIO  # py2 compat
    except ImportError:
        from io import StringIO  # type: ignore
    import logging
    from ..std import tqdm

    LOG = logging.getLogger('test')
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter('%(message)s'))
    LOG.addHandler(console)
    LOG.setLevel(logging.INFO)

    f = StringIO()
    with tqdm_logging_redirect(file=f, mininterval=0.0001) as pbar:
        LOG.info('tqdm: ' + pbar.format_dict['desc'])
        LOG.info('logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:43:45.354153
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test function tqdm_logging_redirect with no errors
    """
    import logging
    from tqdm import trange
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG_test2 = logging.getLogger(__name__)
                LOG_test2.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:50.086993
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    import logging

    log = logging.getLogger(__name__)

    try:
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    log.info("console logging redirected to `tqdm.write()`")
    except IOError:
        # Do not print to console while unittesting
        pass



# Generated at 2022-06-12 14:44:05.078177
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger(__name__)]

    original_handlers_list = [logger.handlers for logger in loggers]
    handler_logs = []

    def test_handler(record):
        handler_logs.append(record)


# Generated at 2022-06-12 14:44:14.434545
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import unittest
    from contextlib import contextmanager
    from io import StringIO

    class TestLoggingRedirectTqdm(unittest.TestCase):
        @contextmanager
        def captured_output(self, stream=sys.stdout):  # type: (...) -> Iterator[StringIO]
            new_out, new_err = StringIO(), StringIO()
            old_out, old_err = sys.stdout, sys.stderr
            try:
                sys.stdout, sys.stderr = new_out, new_err
                yield sys.stdout
            finally:
                sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-12 14:44:21.131514
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tempfile import TemporaryFile

    text = []

    # Setup a log file to use with tqdm_logging_redirect
    file = TemporaryFile()

    # Setup a console logger
    console_logger = logging.getLogger('console_logger')
    console_logger.addHandler(logging.StreamHandler())

    # Setup a file logger pointing to the temp file created above
    file_logger = logging.getLogger('file_logger')
    file_logger_handler = logging.FileHandler(file)
    file_logger.addHandler(file_logger_handler)
    file_logger_handler.setLevel(logging.INFO)

    def tqdm_write(s):
        text.append(s)


# Generated at 2022-06-12 14:44:31.698166
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from .std import tqdm as std_tqdm

    try:
        from unittest import mock
    except ImportError:
        import mock

    class MockTqdm(object):
        def write(self, message):
            self.messages.append(message)

    with mock.patch('tqdm.contrib.logging.std_tqdm', MockTqdm()):
        LOG = logging.getLogger(__name__)
        LOG.info('Before')
        with logging_redirect_tqdm():
            LOG.info('During')
        LOG.info('After')
        assert std_tqdm.messages == ['During\n']


# Generated at 2022-06-12 14:44:38.108360
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tnrange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tnrange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:44:41.921248
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from StringIO import StringIO
    t = StringIO()

    handler = _TqdmLoggingHandler()
    handler.stream = t

    record = logging.LogRecord("name", "DEBUG", None, None, "msg", None, None)
    handler.emit(record)

    t.seek(0)
    assert t.read() == "msg\n"

# Generated at 2022-06-12 14:44:49.268887
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import pytest
    from six import StringIO
    tqdm_class = std_tqdm
    tqdm_handler = _TqdmLoggingHandler(tqdm_class)
    record = logging.LogRecord('name', logging.INFO, 'pathname', 1, "msg",
                               args=None, exc_info=None)
    tqdm_handler.stream = sys.stdout
    orig_stdout = sys.stdout
    sys.stdout = StringIO()
    tqdm_handler.emit(record)
    sys.stdout = orig_stdout
    assert sys.stdout.getvalue() == "msg" + '\n'

# Generated at 2022-06-12 14:44:54.518482
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9) as pbar:
        log.info("console logging redirected to `tqdm.write()`")
        for i in range(9):
            pbar.update()

# Generated at 2022-06-12 14:44:57.673913
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10,
                               logger=logging.getLogger(),
                               dynamic_ncols=True) as pbar:
        for i in range(10):
            logging.info(pbar)
            pbar.update()

# Generated at 2022-06-12 14:45:02.557106
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logfmt = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logging.basicConfig(level=logging.INFO, format=logfmt)
    LOG = logging.getLogger(__name__)
    tqdm_bar = None
    with tqdm_logging_redirect() as tqdm_bar_:
        LOG.info('Hello World!')
        tqdm_bar = tqdm_bar_
    assert 'Hello World!' in tqdm_bar.format_dict

# Generated at 2022-06-12 14:45:18.279620
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import tqdm
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with tqdm_logging_redirect('Test', file=sys.stdout,
            loggers=loggers, tqdm_class=tqdm.tqdm):
        with tqdm.tqdm('Test', file=sys.stdout) as pbar:
            for i in [1,2,3]:
                if i == 2:
                    logging.info("console logging redirected to `pbar.write()`")
                pbar.update()
    for logger, original_handlers in zip(loggers, original_handlers_list):
        logger.handlers = original_handlers

# Generated at 2022-06-12 14:45:19.312530
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    with tqdm_logging_redirect():
        logging.info("test")

# Generated at 2022-06-12 14:45:23.876439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:45:29.628185
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in tqdm(range(9), total=9):
            pass
        print()
        LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:45:36.912985
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(
        format="%(asctime)s %(levelname)s [%(pathname)s:%(lineno)s] %(message)s",
        level=logging.DEBUG)

    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    log = logging.getLogger(__name__)

    with tqdm_logging_redirect(miniters=5) as pbar:
        for _ in trange(9):
            if _ == 4:
                log.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:40.056350
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    # test basic case
    with tqdm_logging_redirect():
        LOG.info('Test logging redirect to tqdm')



# Generated at 2022-06-12 14:45:46.569584
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:45:54.411148
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm

    try:
        # Python 3.4
        from unittest import mock
    except ImportError:
        import mock

    LOG = logging.getLogger(__name__)

    with mock.patch('sys.stdout') as mock_stdout:
        with mock.patch('logging.Logger.handlers', new=[mock.Mock()]):
            with logging_redirect_tqdm():
                tqdm.write('write')
                LOG.info('info')
                LOG.error('error')

    assert mock_stdout.write.call_count == 3
    expected_stdout_calls = [mock.call('write'), mock.call('info'), mock.call('error')]
    assert mock_stdout.write.call_args_list == expected_std

# Generated at 2022-06-12 14:46:03.020681
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    def test_logging_redirect_tqdm_test_func(test_logging_redirect_tqdm_test_arg):
        LOG = logging.getLogger(__name__)
        LOG.debug(test_logging_redirect_tqdm_test_arg)
        LOG.info(test_logging_redirect_tqdm_test_arg)
        LOG.warning(test_logging_redirect_tqdm_test_arg)
        LOG.error(test_logging_redirect_tqdm_test_arg)
        LOG.critical(test_logging_redirect_tqdm_test_arg)

    # Test logging.getLogger(__name__)
    logger = logging.getLogger(__name__)

# Generated at 2022-06-12 14:46:08.824750
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """ test for logging_redirect_tqdm() """
    import logging
    from tqdm import tqdm, trange

    LOG = logging.getLogger(__name__)


    with tqdm_logging_redirect(
            total=2,
            miniters=1,
            desc='test',
            loggers=[LOG],
            tqdm_class=tqdm
    ) as pbar:
        pbar.update()
        LOG.info("console logging redirected to `tqdm.write()`")
        for _ in trange(9):
            # Empty loop to simulate activity
            pass
        LOG.info("and back")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:46:20.936313
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig()
    with logging_redirect_tqdm() as m:
        logging.info('logging to tqdm')



# Generated at 2022-06-12 14:46:29.095266
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    log = logging.getLogger(__name__)

    log.info("console logging redirected to `tqdm.write()`")

    try:
        with tqdm_logging_redirect(loggers=[log], tqdm_class=tqdm):
            for i in trange(5):
                log.info("i am redirect to tqdm")
    except TypeError as e:
        pass

# Generated at 2022-06-12 14:46:32.194218
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import pytest  # pylint: disable=unused-import
    except ImportError:
        print("Please install pytest")
        return
    loggers = [logging.root]
    with tqdm_logging_redirect(loggers=loggers):
        logging.info("test")
        logging.error("test")

# Generated at 2022-06-12 14:46:38.819866
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    log = logging.getLogger()
    with logging_redirect_tqdm():
        log.info("console logging redirected to `tqdm.write()`")
    with logging_redirect_tqdm(loggers=[log], tqdm_class=std_tqdm):
        log.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:47.153891
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    import logging
    from tqdm import trange
    from tqdm._tqdm import _term_move_up
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Without context manager
    with StringIO() as test_out:
        with trange(2) as pbar:  # NOQA
            logging.basicConfig(level=logging.INFO, stream=test_out)
            LOG.info("logging to console")
        assert (test_out.getvalue() == "INFO:__main__:logging to console\n")

    # With context manager

# Generated at 2022-06-12 14:46:49.343528
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.getLogger().setLevel(logging.INFO)
    with logging_redirect_tqdm():
        logging.info('test')

# Generated at 2022-06-12 14:46:58.664119
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    stderr = sys.stderr  # type: Optional[Type[sys.stderr]]
    sys.stderr = None  # type: ignore
    try:
        from tqdm import tqdm as tqdm_
    except ImportError:
        class tqdm_(object):
            @staticmethod
            def write(msg, file=None):
                # type: (str, Optional[file]) -> None
                if file is None:
                    file = sys.stderr
                file.write(msg)
            write = staticmethod(write)
            # noinspection PyShadowingBuiltins
            class default(object):
                _inst = None

# Generated at 2022-06-12 14:47:05.657464
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:11.930786
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:18.074139
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOGGER = logging.getLogger(__name__)

    # Sanity check
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOGGER.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:47:46.364312
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.tests import tqdm as tqdm_test

    LOG = logging.getLogger(__name__)

    def _test_range(
        tqdm_class,  # type: Type[std_tqdm]
        loggers=None,  # type: Optional[List[logging.Logger]]
        *args,
        **kwargs
    ):
        # type: (...) -> None
        with tqdm_logging_redirect(
                loggers=loggers,
                tqdm_class=tqdm_class,
                *args,
                **kwargs) as pbar:
            assert pbar is not None
            pbar.set_description("test_tqdm_logging_redirect")
            for _ in pbar:
                pass

# Generated at 2022-06-12 14:47:54.374787
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch, mock_open
    except ImportError:
        from mock import patch, mock_open

    from ..std import tqdm

    from . import tqdm_redirect_std

    loggers = [logging.getLogger(__name__), logging.getLogger()]
    with patch('tqdm.contrib.logging._TqdmLoggingHandler',
               new=lambda: mock_open()), \
            patch('tqdm.std.tqdm.write',
                  new=lambda x: None), \
            tqdm_redirect_std():
        logging.basicConfig(level=logging.INFO, format='%(message)s')

        # Redirect logging to tqdm

# Generated at 2022-06-12 14:47:58.180171
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=10):
            for i in range(10):
                if i == 9:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:48:06.784588
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOGGER = logging.getLogger(__name__)

    # Check that the logging handler was properly removed
    try:
        with tqdm_logging_redirect("") as t:  # type: ignore
            assert len(LOGGER.handlers) == 0
    finally:
        for h in t.handlers:
            t.removeHandler(h)
        t.close()
        assert_raises(RuntimeError, len, t)  # type: ignore

    # Check that the logging handler was properly restored
    original_handlers = LOGGER.handlers
    original_level = LOGGER.level
    original_propagate = LOGGER.propagate

# Generated at 2022-06-12 14:48:08.916531
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.debug('should be ignored')
        logging.info('should be redirected')



# Generated at 2022-06-12 14:48:14.057596
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import sys
    import os
    import logging
    import tempfile
    from io import StringIO
    from contextlib import redirect_stdout
    from .tqdm_std import tqdm_std

    def _test_run(handler, logger, log_expect):
        handler.stream = sys.stdout
        handler.setFormatter(logging.Formatter(
            fmt='%(asctime)s - %(levelname)s - %(message)s'))
        with redirect_stdout(StringIO()) as buf:
            logger.critical('critical')
            logger.error('error')
            logger.warning('warning')
            logger.info('info')
            logger.debug('debug')
            buf.seek(0)
            output = buf.read()
        assert log_expect == output


# Generated at 2022-06-12 14:48:24.550666
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    from string import ascii_letters
    from random import choice
    from pytest import raises
    from tqdm import tqdm as std_tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    # Make sure that the _TqdmLoggingHandler handler works properly
    # by comparing it to the logging.StreamHandler.
    for test in range(100):
        test_emit_msg = ''.join(choice(ascii_letters) for _ in range(50))
        emitter = _TqdmLoggingHandler()
        emitter.stream = io.StringIO()
        emitter.setFormatter(logging.Formatter())

        # Test _TqdmLoggingHandler method emit

# Generated at 2022-06-12 14:48:28.153029
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:48:31.224874
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(['a', 'b'], total=2, disable=False,
                               mininterval=0.01, miniters=1, loggers=[logging.root]) as pbar:
        print(pbar)
        assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-12 14:48:38.461915
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    lg = logging.getLogger("test__TqdmLoggingHandler_emit")
    lg.setLevel(logging.INFO)
    lg.handlers = []
    tqdm.tqdm.write = lambda x: x
    hdlr = _TqdmLoggingHandler()
    lg.addHandler(hdlr)
    lg.info("Message 1")
    assert tqdm.tqdm.write.call_count == 0
    lg.info("Message 2")
    assert tqdm.tqdm.write.call_count == 1
    assert tqdm.tqdm.write.call_args_list[
        -1][0] == ("Message 2",)  # pylint: disable=unsubscriptable-object



# Generated at 2022-06-12 14:49:25.415435
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm._utils import _term_move_up
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.test_utils import StringIO

    LOG = logging.getLogger(__name__)

    def run_logging_redirect_tqdm(redirect_stdout=True):
        stdout_orig = sys.stdout
        if redirect_stdout:
            stdout_io = StringIO()
            sys.stdout = stdout_io


# Generated at 2022-06-12 14:49:30.049722
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    logger = logging.getLogger()
    maxInt = 100
    with tqdm_logging_redirect(total=maxInt) as pbar:
        for i in range(maxInt):
            pbar.update(1)
            logger.info("i = %s" % i)


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:49:36.056100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    RedirectedLoggingHandler = _TqdmLoggingHandler
    with logging_redirect_tqdm() as pbar:
        for _ in range(9):
            LOG.info("console logging redirected to `tqdm.write()`")

    assert len(pbar.log_handlers) == 1
    assert pbar.log_handlers[0] == RedirectedLoggingHandler
    assert LOG.handlers[0] == pbar.log_handlers[0]

# Generated at 2022-06-12 14:49:44.645206
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange, tqdm_notebook
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect():
        for i in trange(10):
            if i == 5:
                success = False
                try:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    success = True
                except:
                    pass
                assert success
    print()

    with tqdm_logging_redirect(tqdm_class=tqdm_notebook):
        for i in trange(10):
            if i == 5:
                success = False

# Generated at 2022-06-12 14:49:52.444118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.auto import tqdm
    from tqdm import std as tqdm_std
    import tempfile
    import logging
    from contextlib import redirect_stdout

    with tempfile.NamedTemporaryFile('w+') as tmp:
        fd = tmp.file
        with redirect_stdout(fd):
            with tqdm_logging_redirect(total=10) as pbar:
                assert pbar.__class__ is tqdm_std.tqdm
                with logging_redirect_tqdm():
                    LOG = logging.getLogger(__name__)
                    for i in range(10):
                        pbar.update()
                        if i == 5:
                            LOG.info("console logging redirected to `tqdm.write()`")
                        fd.flush()

# Generated at 2022-06-12 14:49:55.545708
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:50:04.036871
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
        from tqdm import tgrange
    except ImportError:
        print("Module 'tgrange' not found. Skipping unit-test")
        return
    import logging
    logger = logging.getLogger('test_tgrange')
    with tqdm_logging_redirect(
        desc='Now logging to tqdm',
        total=9,
        disable=False,
        leave=False,
        loggers=[logger],
    ) as pbar:
        for i in tgrange(9):
            if i == 4:
                logger.info("tqdm_tgrange is working")
            if i == 8:
                assert pbar.total == 9

# Generated at 2022-06-12 14:50:06.961021
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from .util import TPrint
    import logging

    with TPrint():
        with logging_redirect_tqdm():
            logging.warning('Warning from logger')
            logging.info('Info from logger')
            logging.error('Error from logger')
        print('Done')


# Generated at 2022-06-12 14:50:12.420240
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    from tqdm import tqdm, trange

    LOG = logging.getLogger(__name__)

    with StringIO() as io, std_tqdm(io=io) as pbar:
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:19.742340
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tests_tqdm._utils import override_std_streams
    except ImportError:
        sys.stderr.write("Unable to import override_std_streams (no nose?)\n")
    else:
        with override_std_streams() as streams:

            # "logging_redirect_tqdm" test:
            with tqdm_logging_redirect() as progressbar:
                progressbar.set_description('logging_redirect_tqdm')
                import logging
                log = logging.getLogger()
                log.info('foo')
            assert 'foo\n' == streams.stderr.getvalue()

            # "logging_redirect_tqdm" test with a custom logger:

# Generated at 2022-06-12 14:51:45.598067
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def helper_stdout_and_stderr_refresh_redirect():
        sys.stdout.write("SYSOUT\n")
        sys.stderr.write("SYSERR\n")
        sys.stdout.flush()
        sys.stderr.flush()

    with tqdm_logging_redirect(loggers=[LOG], total=9):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

            if i == 5:
                helper_stdout_and_stderr_refresh_redirect()

# Generated at 2022-06-12 14:51:50.818577
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:51:55.154926
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import mock

    log_text = 'console logging redirected to `tqdm.write()`'
    with mock.patch('tqdm._tqdm.std_tqdm.write') as mock_write:
        with tqdm_logging_redirect():
            logging.info(log_text)
    mock_write.assert_called_once_with(log_text)

# Generated at 2022-06-12 14:52:00.999109
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    from .utils import FormatStdout
    from .utils import _range

    with FormatStdout(bar_format="{l_bar}") as (_, err):
        with tqdm_logging_redirect(_range(0, 5)) as pbar:
            for i in pbar:
                logging.info("hello tqdm!")


# Generated at 2022-06-12 14:52:10.669602
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.utils import _range

    import logging
    import os
    import shutil
    import tempfile

    # Set up logging
    logging.basicConfig(level=logging.INFO)
    log_dir = tempfile.mkdtemp()
    log_path = os.path.join(log_dir, 'log.txt')
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.FileHandler(log_path)
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    # Do some loggin'
    with tqdm_logging_redirect(loggers=[logger]):
        for i in _range(10):
            logger.debug(str(i))

    # Check that tqdm is

# Generated at 2022-06-12 14:52:16.741756
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                elif i == 9:
                    LOG.info("Now, console logging is restored")
        # logging restored


# Generated at 2022-06-12 14:52:20.643279
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to tqdm.write")
        # logging restored


# Generated at 2022-06-12 14:52:27.461260
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        # first use of logging doesn't show up in `tqdm.write()`
        logging.info('first message')
    # second uses logging.info() will show up in `tqdm.write()`
    logging.info('second message')

# Generated at 2022-06-12 14:52:30.220662
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=2) as pbar:
        logger.info('Test message 1')
        pbar.update()
        logger.info('Test message 2')
        pbar.update()
    assert pbar.n == 2

# Generated at 2022-06-12 14:52:34.150215
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm.contrib import logging as contrib_logging

    log = logging.getLogger(__name__)

    contrib_logging.logging_redirect_tqdm()
    log.info('Test')


if __name__ == '__main__':
    test_logging_redirect_tqdm()