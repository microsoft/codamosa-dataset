

# Generated at 2022-06-12 14:42:46.229071
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in trange(10):
            LOG.info("console logging redirected to `tqdm.write()`")
        LOG.info("console logging restored")


# Generated at 2022-06-12 14:42:48.142026
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in range(9):
            logging.info(i)

# Test for nested logging context

# Generated at 2022-06-12 14:42:52.615224
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import warnings
    warnings.filterwarnings("ignore")
    from logging import basicConfig, ERROR, INFO, getLogger

    basicConfig(level=ERROR)
    getLogger('tqdm').level = INFO  # Reduce noise

    with tqdm_logging_redirect(desc='(TqdmLoggingRedirect)') as pbar:
        pbar.write("OK")



# Generated at 2022-06-12 14:42:55.250094
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=2):
        logger.info('Dummy message1')
        logger.info('Dummy message2')

# Generated at 2022-06-12 14:43:00.958867
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    from logging import getLogger
    from shutil import rmtree
    from tempfile import mkdtemp
    import os
    import time

    LOG = getLogger(__name__)
    LOG.setLevel(20)

    @contextmanager
    def logger_redirect(logger):
        # type: (logging.Logger) -> Iterator[None]
        original_handlers_list = logger.handlers

# Generated at 2022-06-12 14:43:03.492792
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger('test')
    with logging_redirect_tqdm([LOG]):
        LOG.info('my message')



# Generated at 2022-06-12 14:43:08.689345
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with std_tqdm(total=1024, leave=False) as progressbar:
        with logging_redirect_tqdm():
            def write_log(i):
                # type: (int) -> None
                logging.info('%s/1024', i)

            for i in range(1024):
                write_log(i)
                progressbar.update()


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:43:13.087999
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
    logger = logging.getLogger('test_logger')
    with logging_redirect_tqdm():
        logger.info('info')
        logger.debug('debug')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.info('info')
    logger.debug('debug')

# Generated at 2022-06-12 14:43:21.206100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:43:29.827696
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Test for function tqdm_logging_redirect"""
    from os import getpid
    from time import sleep
    from subprocess import Popen, PIPE

    def get_log_output():
        # type: () -> str
        """Get log output from tqdm_logging_redirect"""
        proc = Popen(
            ['tail', '-f', '-n', '+0', '/tmp/tqdm_logging_redirect.%d' % getpid()],
            stdout=PIPE)
        sleep(2)
        proc.kill()
        return proc.stdout.read().decode('utf-8')


# Generated at 2022-06-12 14:43:45.670135
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging  # pylint: disable=import-outside-toplevel
    import tqdm  # pylint: disable=import-outside-toplevel

    def tqdm_fake(*args, **kwargs):
        """
        Fake tqdm function
        """
        return tqdm.trange(*args, **kwargs)

    LOG = logging.getLogger(__name__)
    #Test 1: No loggers
    with tqdm_logging_redirect(tqdm_class=tqdm_fake):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    #Test 2: [logging.root] loggers
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:43:51.083342
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logger = logging.getLogger('_test_logger')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    logger.debug('outside')
    with tqdm_logging_redirect(total=10, unit='it', loggers=(logger, ), ascii=True) as pbar:
        for _ in range(10):
            logger.debug('inside')
            pbar.update()
    logger.debug('outside')

# Generated at 2022-06-12 14:43:53.618955
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # tqdm_class = tqdm.standard.tqdm
    with tqdm_logging_redirect(total=100, desc="test"):
        logging.info('Okay!')

# Generated at 2022-06-12 14:44:02.572789
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        from unittest import mock
    except ImportError:
        import mock

    logger = logging.getLogger('tqdm_logging_redirect')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.addHandler(logging.NullHandler())
    with mock.patch('sys.stdout', new=mock.MagicMock()) as mock_stdout:
        with tqdm_logging_redirect(loggers=None) as pbar:
            assert pbar == mock_stdout
            logger.info('console logging redirected to `tqdm.write()`')


del absolute_import, contextmanager, logging

# Generated at 2022-06-12 14:44:09.800374
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import suppress
    import logging
    from io import TextIOWrapper
    from tempfile import TemporaryFile

    with TemporaryFile() as f:
        print("this should not be printed to file", file=f)
        f.seek(0)

        def assert_redirection_to_tqdm(handler, tqdm_class):
            try:
                with tqdm_logging_redirect(loggers=[logging.root], file=f):
                    LOG.warning("test")
            except AttributeError:
                # AttributeError: 'TextIOWrapper' object has no attribute 'write_lock'
                # (for some reason, raised on Travis CI, but not on local conda env)
                with suppress(AttributeError):
                    assert f.getvalue() == b""

# Generated at 2022-06-12 14:44:13.767200
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    print("after redirect")

# Generated at 2022-06-12 14:44:20.654462
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os

    logging.basicConfig()

    pbar = tqdm_logging_redirect(
        total=9,
        # loggers=[logging.getLogger(__name__)],
        tqdm_class=std_tqdm)
    # Assert that loggers are redirected to tqdm.write
    with pbar as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    assert pbar.n == 9
    assert pbar.total == 9
    # Ensure that logging was redirected to tqdm.write
    assert "console logging redirected to `tqdm.write()`\n" \
        in sys.stdout.getvalue()

    # Restore stdout
    sys

# Generated at 2022-06-12 14:44:22.116904
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect():
        logging.info("hello")
        logging.info("world")

# Generated at 2022-06-12 14:44:34.262546
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch


# Generated at 2022-06-12 14:44:42.393074
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    import io
    import sys

    sys.stderr = io.StringIO()
    sys.stdout = io.StringIO()
    LOG = logging.getLogger(__name__)

    trange(9)  # call trange in advance to check condition of `logging_redirect_tqdm`

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        assert "console logging redirected to `tqdm.write()`" in sys.stderr.getvalue()  #

# Generated at 2022-06-12 14:44:56.811410
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:00.822741
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO
    from tqdm import std
    logging.basicConfig(format='%(message)s')
    with StringIO() as s:
        logger = logging.getLogger('test')
        handler = _TqdmLoggingHandler(tqdm_class=std)
        handler.stream = s
        logger.handlers = []
        logger.addHandler(handler)
        logger.info('test')
        assert len(s.getvalue()) == len('test\n')



# Generated at 2022-06-12 14:45:06.302864
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os

    returned = []

    def write_fun(tqdm_class):
        def fun(msg, file=None, end="\n", nolock=False):
            if end == "\n":
                returned.append(msg)
        return fun

    f = write_fun(std_tqdm)
    std_tqdm.write = f  # type: ignore
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc="test_tqdm_logging_redirect_console"):
        logging.info("console logging redirected to `tqdm.write()`")

    out_file = "logging_redirect_tqdm.log"
    with open(out_file, "w") as file:
        std_t

# Generated at 2022-06-12 14:45:17.774181
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tnrange, tqdm

    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tnrange(2):  # console logging redirected to `tqdm.write()`
            pass
        logger.info("test message")  # console logging redirected to `tqdm.write()`
        print("printed to stdout")
        for i in tqdm(range(2)):
            pass
        for i in tnrange(2):  # tnrange doesn't work inside tqdm
            pass
    # logging restored
    for i in tnrange(2):
        pass
    logger.info("test message")
    print("printed to stdout")

# Generated at 2022-06-12 14:45:22.188510
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange
    from tqdm.cli import main

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:23.578169
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:34.639169
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import pretest_posttest
    from logging import StreamHandler, getLogger, INFO, basicConfig

    class MockTqdm(std_tqdm):
        flushed = False
        def clear(self, nolock=False):
            self.flushed = True

    def mock_flush(self):
        self.flush_called = True

    logger = getLogger()
    original_handlers = logger.handlers

    with pretest_posttest(logger):
        with pretest_posttest(logger.handlers):
            logger.setLevel(INFO)
            basicConfig(level=INFO)
            logger.handlers = [StreamHandler()]
            logger.handlers[0].flush = mock_flush
            logger.handlers[0].flush_called = False


# Generated at 2022-06-12 14:45:39.976095
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with tqdm_logging_redirect(desc='test') as pbar:
        for _ in pbar:
            LOG.info('test')

    LOG.setLevel(logging.NOTSET)
    logging.shutdown()

# Generated at 2022-06-12 14:45:49.342315
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # set up test message
    test_msg = 'string to be logged'

    # Redirect logging to tqdm using tqdm_logging_redirect
    with tqdm_logging_redirect() as tqdm:
        for i in range(3):
            tqdm.write(test_msg)

    # Testing of tqdm_logging_redirect
    # 1. check tqdm_logging_redirect as a context manager
    # 2. check that logging is redirected to tqdm
    # 3. check expected output
    n = 1
    # 1. check that tqdm_logging_redirect is a context manager

# Generated at 2022-06-12 14:45:54.196913
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        # loggers=[],  # type: Optional[List[logging.Logger]]
    ):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:26.152659
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    import logging
    import io
    import tqdm.testsuite.tcls as test_tqdm

    stream = io.StringIO()
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(stream=stream, ncols=80) as pbar:
        # No logging output
        assert stream.getvalue() == '\n'
        LOG.info("Test message")
        # Logging routed to tqdm successfully
        assert stream.getvalue().rstrip() == 'Test message'
        assert pbar.n == 0
        with pbar.hidden_to_stdout():
            LOG.info("Test message 2")
        assert stream.getvalue().rstrip() == 'Test message'
        # Hide flag is cleared after leaving context manager

# Generated at 2022-06-12 14:46:33.389919
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import random
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s:%(filename)s:%(lineno)d: %(message)s")
    with logging_redirect_tqdm():
        logging.info("Info 1")
        with logging_redirect_tqdm():
            logging.info("Info 2")
    logging.info("Info 3")

    random.seed(0)
    with logging_redirect_tqdm():
        for i in range(4):
            logging.info("Info %d", i)
            for j in range(3):
                logging.debug("Debug %d.%d", i, j)

# Generated at 2022-06-12 14:46:44.503522
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.std import tqdm

    def _setup_logging():
        # type: () -> logging.Logger
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        # create file handler which logs even debug messages
        fh = logging.FileHandler('test_log.log')
        fh.setLevel(logging.DEBUG)
        # create console handler with a higher log level
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        # create formatter and add it to the handlers

# Generated at 2022-06-12 14:46:53.412133
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit of class _TqdmLoggingHandler
    """
    from tqdm.tests._utils import _io_wrapper

    class DummyLogger():
        def __init__(self):
            self.dummy_list = []
            self.tqdm_logging_handler = _TqdmLoggingHandler()

        def emit(self, record):
            self.dummy_list.append(self.tqdm_logging_handler.emit(record))

    d_logger = DummyLogger()
    record = logging.Logger("test-logger", level=logging.DEBUG)
    record.msg = "test message"

    with _io_wrapper():
        d_logger.emit(record)
    assert d_logger.dummy_list == [None]

# Generated at 2022-06-12 14:47:03.003729
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import logging as std_logging
    from ..std import io as std_io
    with tqdm_logging_redirect(desc='Testing') as pbar:
        assert isinstance(pbar, std_tqdm)
        std_logging.info('Testing')
        std_logging.info('{} Testing'.format(pbar))
        assert pbar.n == len('Testing\nTesting {}\n'.format(pbar))

    with std_io.StringIO() as buffer:
        # Test non-default logging setup
        pbar = std_tqdm(
            desc='Testing', file=buffer, leave=False, mininterval=0.01)

# Generated at 2022-06-12 14:47:12.917125
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys

    if sys.version_info.major < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    logger = logging.getLogger(__name__)
    stream = StringIO()
    ch = logging.StreamHandler(stream)
    logger.addHandler(ch)
    logger.setLevel(logging.DEBUG)

    # in context
    with logging_redirect_tqdm():
        logger.debug("debug message")
        logger.info("info message")
        logger.warn("warn message")
        logger.error("error message")
        logger.critical("critical message")

# Generated at 2022-06-12 14:47:18.677396
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:47:22.913398
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    import time
    import tqdm

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            total=9999,
            desc="testing...",
            logger=LOG,
            file=sys.stdout):
        for _ in range(9999):
            LOG.info("Hello")
            time.sleep(0.001)

# Generated at 2022-06-12 14:47:27.955770
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import tqdm
    from unittest import TestCase
    
    class TestEmit(TestCase):

        def setUp(self):
            self.handler = _TqdmLoggingHandler()

        def test_emit(self):
            with tqdm.std.redirect_stdout() as f:
                self.handler.emit(logging.LogRecord('name', logging.WARNING, 'pathname', 0,
                                                    'msg', (), None))
                self.assertEqual(f.getvalue(), 'WARNING:msg\n')

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-12 14:47:34.189137
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    try:
        from cStringIO import StringIO  # type: ignore
    except ImportError:
        from io import StringIO

    try:
        from contextlib import redirect_stdout  # Python 3.4+
        def writercapture(tqdm_class, writer, func):
            with redirect_stdout(writer):
                with logging_redirect_tqdm(tqdm_class=tqdm_class):
                    func()
    except ImportError:
        def writercapture(tqdm_class, writer, func):
            with logging_redirect_tqdm(tqdm_class=tqdm_class):
                with tqdm_class.wrapattr(sys, 'stdout', writer):
                    func()


# Generated at 2022-06-12 14:48:03.738672
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    import time

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        time.sleep(0.1)

# Generated at 2022-06-12 14:48:11.205593
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Q: Does `logging_redirect_tqdm` redirect logging?
    # A: implicitly answered by next line, but let's be explicit
    assert len(logging.root.handlers) == 1
    assert isinstance(logging.root.handlers[0], logging.StreamHandler)

    if __name__ == '__main__':
        # Q: Does `logging_redirect_tqdm` preserve existing logging?
        logging.basicConfig(level=logging.INFO)
        assert len(logging.root.handlers) == 1
        assert isinstance(logging.root.handlers[0], logging.StreamHandler)

        # Q

# Generated at 2022-06-12 14:48:14.544978
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(10):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:48:20.213348
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm import trange
    except ImportError:
        return
    import logging

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:25.175109
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:48:29.334596
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(file=sys.stderr, loggers=[LOG]) as pbar:
        LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update()

# Generated at 2022-06-12 14:48:33.518776
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import tqdm
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler(tqdm)
    logger.handlers = []
    logger.addHandler(tqdm_handler)
    logger.info("TEST")
    tqdm.write("TEST")

# Generated at 2022-06-12 14:48:37.965004
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-12 14:48:45.786324
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    import logging
    import threading
    import time

    logger = logging.getLogger('logging_test')
    logger.setLevel(logging.INFO)
    logger.propagate = False

    def worker():
        # type: () -> None
        logger.info('hello')
        logger.info('world')

    original_handlers = logger.handlers
    # TODO: non-standard log format
    expected = [[['INFO:logging_test:hello', 'INFO:logging_test:world']]]

    with tqdm_logging_redirect(unit='it', leave=False) as pbar:
        assert len(logger.handlers) == 1
        assert isinstance(logger.handlers[0], _TqdmLoggingHandler)
        t = threading

# Generated at 2022-06-12 14:48:53.413923
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    with open('test.log', 'w') as f:
        log = logging.getLogger('test')
        log.addHandler(logging.StreamHandler(f))
        with logging_redirect_tqdm():
            log.error('Error 1')
            for i in trange(4):
                log.info('Info {}'.format(i))
                log.warn('Warning {}'.format(i))
                log.error('Error {}'.format(i))
        log.error('Error 2')
    with open('test.log', 'r') as f:
        lines = f.readlines()
    assert lines[1].strip() == 'Error 1'
    assert lines[4].strip() == '[INFO][test] Info 0'

# Generated at 2022-06-12 14:49:43.416821
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import time
    from tqdm import tqdm
    from tqdm.contrib.logging import (
        logging_redirect_tqdm,
        tqdm_logging_redirect,
    )
    # Initialise
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    def std_logging_redirect_tqdm():
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:49:47.296251
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            desc='Redirecting logging to tqdm',
            logger=logging.getLogger('logging_redirect_tqdm')
    ) as pbar:
        logging.getLogger('logging_redirect_tqdm').warning('Expected message')
    assert pbar.n == 1

# Generated at 2022-06-12 14:49:52.410039
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()
    console_handler = _get_first_found_console_logging_handler(logger.handlers)
    assert console_handler is not None
    with logging_redirect_tqdm():
        logger.info("console logging redirected to `tqdm.write()`")
    console_handler = _get_first_found_console_logging_handler(logger.handlers)
    assert console_handler is not None

# Generated at 2022-06-12 14:49:57.477611
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from .test_tqdm import TqdmTest
    try:
        from .test_tqdm_notebook import tqdm_notebook as tn
    except ImportError:
        tn = None

    def test_tqdm_logging_redirect_(tqdm_class, *args, **kwargs):
        # type: (Type[std_tqdm], *Any, **Any) -> None
        """
        Test tqdm_logging_redirect
        """
        with tqdm_logging_redirect(tqdm_class, *args, **kwargs) as pbar:
            pass
        with tqdm_logging_redirect(*args, **kwargs) as pbar:
            pass


# Generated at 2022-06-12 14:50:02.604347
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:50:09.394472
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm, trange, tgrange
    import logging
    import textwrap
    from io import StringIO

    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)

    with tqdm(range(3)) as pbar:
        with logging_redirect_tqdm():
            for i in pbar:
                log.info("foo")
                pbar.set_description_str("bar")

    with tqdm(range(3)) as pbar:
        with logging_redirect_tqdm():
            for i in pbar:
                log.info("foo")
                pbar.set_description(textwrap.dedent("""\
                        bar
                        baz"""))


# Generated at 2022-06-12 14:50:18.286302
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log = logging.getLogger(__name__)

    # Test with loggers = [logging.root]
    # logger.handlers = [] so that new logging messages get propagated to
    # stdout and stderr by default (and caught by our unit test)
    logging.root.handlers = []
    with logging_redirect_tqdm():
        log.info('info message')
        with trange(3) as pbar:
            for _ in pbar:
                log.debug('debug message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    # Test with loggers = [log]

# Generated at 2022-06-12 14:50:21.657628
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    stream_handler = _TqdmLoggingHandler()
    logger.addHandler(stream_handler)
    try:
        logger.info("test")
        assert stream_handler.stream.getvalue() == "\n"
    finally:
        logger.removeHandler(stream_handler)
        stream_handler.stream.close()

# Generated at 2022-06-12 14:50:30.246876
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import sys
    from contextlib import contextmanager
    from tqdm.contrib.logging import _TqdmLoggingHandler

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # For unit test only:
    # Check that sys.stderr.getvalue() for expected messages:
    #     * contains the expected message if smth went wrong;
    #     * does not contain the expected message if everything is OK.
    def test_sys_stderr_getvalue_for_expected_msg(
            is_msg_expected_in_stderr=False,  # type: bool
            expected_msg=None  # type: str
    ):
        # type: (...) -> None
        if is_msg_expected_in_stderr:
            assert expected_msg in sys.stderr.getvalue()


# Generated at 2022-06-12 14:50:35.236475
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.std import tqdm
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        for i in pbar(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:52:07.648051
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """
    # Make sure the unit test is executed in the same directory or parent directory of file tqdm_logging.py
    import os
    try:
        os.chdir(os.path.dirname(__file__) or os.getcwd())
    except NameError:
        os.chdir(os.path.dirname(os.path.abspath(__file__)) or os.getcwd())

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to info
    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setLevel(logging.INFO)

# Generated at 2022-06-12 14:52:15.023865
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    It redirects to tqdm.write()
    """
    import logging
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                        datefmt='%m-%d %H:%M',
                        filename='logging_redirect_tqdm.log',
                        filemode='w')
    # create console handler and set level to info
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    # create formatter
    formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    # add formatter to console_handler
    console_

# Generated at 2022-06-12 14:52:18.233404
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from ..std import tqdm as std_tqdm
    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    record = logging.LogRecord('name', logging.INFO, 'arg', 0, 'msg', (), None, None)
    handler.emit(record)

# Generated at 2022-06-12 14:52:21.118985
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            LOG.info('This should display in the terminal')
            raise Exception('This should be caught and logged in the terminal')
    except Exception as e:
        print('This should display in the terminal')
        assert str(e) == 'This should be caught and logged in the terminal'
    # logging restored


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:52:27.807488
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[logger]) as pbar:
        for _ in pbar:
            logger.info("console logging redirected to `tqdm.write()`")
            time.sleep(0.01)
        logger.info("exiting tqdm")



# Generated at 2022-06-12 14:52:29.694949
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test for function logging_redirect_tqdm

    """
    from .examples import logging_redirect_tqdm_example

    logging_redirect_tqdm_example()

# Generated at 2022-06-12 14:52:37.571057
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    msg_test = 'Test message'
    def test(use_logging_redirect_tqdm = False):
        logger = logging.getLogger('test_logger')
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        logger.addHandler(handler)
        ch = logger.handlers[0]
        if use_logging_redirect_tqdm:
            with logging_redirect_tqdm([logger]):
                logger.debug(msg_test)
        else:
            logger.debug(msg_test)
        return ch.stream.getvalue().rstrip()
    assert(test() == msg_test)
    assert(test(True) == f"{msg_test}\n")