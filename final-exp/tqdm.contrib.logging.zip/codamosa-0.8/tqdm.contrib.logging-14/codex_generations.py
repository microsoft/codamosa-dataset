

# Generated at 2022-06-12 14:42:50.105031
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-12 14:42:55.386268
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9, desc='test') as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
                pbar.update()
    assert pbar.n == 9
    assert pbar.desc == 'test'
    assert pbar.total == 9
    assert pbar.dynamic_messages

# Generated at 2022-06-12 14:43:01.045948
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm.contrib.logging

    # Setup logging logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # Create handler
    handler = logging.FileHandler(filename='test.log')
    handler.setLevel(logging.INFO)
    # Create formatter and add it to the handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    # Add the handler to the logger
    logger.addHandler(handler)

    # Test tqdm_logging_redirect

# Generated at 2022-06-12 14:43:09.771768
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import tqdm

    import sys
    sys.stderr.flush()
    sys.stdout.flush()

    log = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            total=2, desc="Example usecase",
            file=sys.stdout,
            dynamic_ncols=True,
            ):
        log.info("Console logging redirected to `tqdm.write()`")
        log.info("Console logging redirected to `tqdm.write()` 2")

    # logging restored
    log = logging.getLogger(__name__)


# Generated at 2022-06-12 14:43:15.942485
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io  # NOQA
    from tqdm import tqdm  # NOQA

    # Test with tqdm
    tqdm_out = io.StringIO()  # type: ignore  # NOQA
    with tqdm_logging_redirect(file=tqdm_out):
        logging.info('test_tqdm')
        assert tqdm_out.getvalue().endswith(' test_tqdm\n')

    # Test with custom tqdm
    class TqdmDummy(tqdm):
        @staticmethod
        def write(msg, file=None):
            if file is None:
                file = sys.stderr
            file.write('TqdmDummy: {}\n'.format(msg))

    tqdm_

# Generated at 2022-06-12 14:43:19.966691
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Given
    tqdm_logging_handler = _TqdmLoggingHandler()

    # When
    record = logging.LogRecord('tqdm_logging_handler_test', logging.INFO,
                               None, 0, 'test', (), None)

    # Then
    tqdm_logging_handler.emit(record)

# Generated at 2022-06-12 14:43:24.670941
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib import logging_redirect_tqdm

    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:43:32.797954
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    import unittest

    def check_log(msg):
        """Test that message is logged"""
        log_messages = [msg, 'called']
        return bool(len(log_messages) ==
                    len([m for m in log_messages if m in logs]))

    def check_progress_and_log(msg):
        """Test that message is logged and tqdm progressbar exists"""
        return bool((msg in logs) and (tqdm_logging_redirect.pbar is not None))

    with tqdm_logging_redirect():
        logging.getLogger().info("called")
    
    logs = TestLog._logs

    assert(check_log("called"))
    write_

# Generated at 2022-06-12 14:43:38.964233
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:43:45.012049
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import BytesIO
    from logging import INFO, getLogger

    LOG = getLogger("test")
    LOG.setLevel(INFO)
    LOG.propagate = False
    OUT = BytesIO()
    HANDLER = _TqdmLoggingHandler(out=OUT)
    LOG.addHandler(HANDLER)
    LOG.info("info message")
    assert OUT.getvalue() == b"info message\n"

# Generated at 2022-06-12 14:44:04.289788
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging

    with io.StringIO() as s:
        with logging_redirect_tqdm(tqdm_class=std_tqdm) as pbar:
            logging.info('foo')
            assert pbar.n == 3

    with io.StringIO() as s:
        with logging_redirect_tqdm(tqdm_class=std_tqdm) as pbar:
            logging.info('bar')
            assert pbar.n == 3

    with io.StringIO() as s:
        with tqdm_logging_redirect(tqdm_class=std_tqdm) as pbar:
            logging.info('foo')
            assert pbar.n == 3


# Generated at 2022-06-12 14:44:08.353778
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    try:
        with tqdm_logging_redirect(unit='s', desc='testing', loggers=[logging.root]) as pbar:
            logging.info('test')
            time.sleep(1)
        assert pbar.n == 1
        assert pbar.desc == 'testing'
    except Exception as e:
        assert False, "Exception occured: %s" % e



# Generated at 2022-06-12 14:44:11.979628
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    _test_logging_redirect_tqdm(std_tqdm)
    try:
        import tqdm.notebook
        _test_logging_redirect_tqdm(tqdm.notebook.tqdm)
    except (ImportError, IOError, NameError):
        pass



# Generated at 2022-06-12 14:44:15.862251
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    # W0612: Unused variable 'trange'
    # pylint: disable=W0612

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:44:18.016423
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    with logging_redirect_tqdm():
        for i in tqdm(range(1)):
            logging.info('Test Logging 1')
    logging.info('Test Logging 2')



# Generated at 2022-06-12 14:44:23.470138
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import tqdm, test, trange  # type: ignore
    from tqdm.contrib import logger  # type: ignore

    with test.disable_gc():
        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.DEBUG)
            with tqdm_logging_redirect(total=9,
                                       bar_format='{elapsed} {desc}: {n_fmt}/{total_fmt}',
                                       logger=LOG):
                for i in trange(9):
                    if i == 4:
                        LOG.debug("tqdm_logging_redirect call test")
            # logging restored


# Generated at 2022-06-12 14:44:34.982211
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.DEBUG)

    tqdm_class = std_tqdm.tqdm
    if tqdm_class.from_dict(dict(desc="logging_redirect_tqdm"))[0] is None:
        raise RuntimeError(
            "Tqdm logging_redirect_tqdm test failed -"
            " probably due to https://github.com/tqdm/tqdm/issues/650")

    with tqdm_class(desc="logging_redirect_tqdm") as pbar:
        with logging_redirect_tqdm(loggers=[LOG]):
            pbar.update()

# Generated at 2022-06-12 14:44:42.632931
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class _TqdmStub(object):
        def __init__(self):
            self.file = None
        def write(self, msg, file=None):
            self.file = file
    _tqdm = _TqdmStub()
    handler = _TqdmLoggingHandler(tqdm_class=_tqdm)
    import datetime
    class _RecordStub(object):
        def __init__(self):
            self.levelname = "INFO"
            self.msg = "msg"
            self.name = "name"
            self.time = datetime.datetime.now()
    record = _RecordStub()
    handler.emit(record)
    assert(_tqdm.file == sys.stderr)

# Generated at 2022-06-12 14:44:48.600812
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
    import logging
    from tqdm import tqdm

    f = StringIO()
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in tqdm(range(10)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                f.write("console logging redirected to `tqdm.write()`\n")

# Generated at 2022-06-12 14:44:54.797199
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect(100) as pbar:
            for i in range(100):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update(1)

# Generated at 2022-06-12 14:45:16.094598
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test that function tqdm_logging_redirect works as expected
    import logging
    from unittest import TestCase

    logger = logging.getLogger('foo')
    logger.setLevel(logging.INFO)
    # logging.basicConfig()

    class T(TestCase):
        def test_tqdm_logging_redirect(self):
            with tqdm_logging_redirect(unit_scale=True, unit='B', total=100,
                                       desc='test', leave=False, disable=False) as t:
                logger.info('test')
            self.assertEqual(str(t), 'test:  0%|      | 0.00B [00:00<?, ?B/s]\ntest: test\n')


# Generated at 2022-06-12 14:45:19.932162
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # set up logging
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    log = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    log.info("console logging redirected to `tqdm.write()`")
        # logging restored

    return None



# Generated at 2022-06-12 14:45:31.130677
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """ Unit test for logging_redirect_tqdm funciton """
    import logging
    import random
    import string
    from tqdm.contrib.logging import logging_redirect_tqdm

    log_entry = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(8)])
    log_caught = False

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:45:37.312866
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test a dummy logger.
    """
    from .tests_tqdm import with_setup, _range
    log = logging.getLogger("dummy_logger")
    log.propagate = False
    with open("tmp-tg-logging.txt", "w") as file_log, with_setup(
            lambda: log.addHandler(logging.StreamHandler(file_log)),
            lambda: log.removeHandler(log.handlers[0])):
        with logging_redirect_tqdm(), with_setup(lambda: _range(1)):
            log.info("some msg")

# Generated at 2022-06-12 14:45:47.114812
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm.std import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.utils import _term_move_up

    # Define a test logger
    class TestLogger(object):
        def __init__(self):
            # type: () -> None
            self.text = ""

        def addHandler(self, handler):
            # type: (logging.Handler) -> None
            self.text += handler.formatter.format(None)

        def removeHandler(self, handler):
            # type: (logging.Handler) -> None
            pass


# Generated at 2022-06-12 14:45:54.660029
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import subprocess
    import io
    import os

    def check_stream(stream_str, target_str):
        stream_str = stream_str.decode("utf-8")
        assert target_str in stream_str

    # set up test logger
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    stream = io.BytesIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter("%(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    LOG.addHandler(handler)

    # used to capture output by tee
    file = open(os.devnull, 'w')

    # run unit test

# Generated at 2022-06-12 14:46:03.245903
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm as std_tqdm
    except ImportError:
        import sys
        import os
        sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
        try:
            from tqdm import tqdm as std_tqdm
        except ImportError:
            raise

    import unittest
    import logging

    class TestLoggingRedirectTqdm(unittest.TestCase):

        def setUp(self):
            self.original_handlers_list = [logger.handlers for logger in [logging.getLogger(__name__)]]

# Generated at 2022-06-12 14:46:07.180354
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test1():
        with logging_redirect_tqdm(loggers=[LOG]):
            LOG.info("console logging redirected to `tqdm.write()`")
    try:
        test1()
    except:  # noqa
        assert False, "logging_redirect_tqdm did not work"



# Generated at 2022-06-12 14:46:13.209118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(position=1) as pbar0:
        with tqdm_logging_redirect(loggers=[LOG], position=2) as pbar1:
            with tqdm_logging_redirect(loggers=[LOG], position=3) as pbar2:
                import time
                time.sleep(0.01)

# Generated at 2022-06-12 14:46:23.670591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> List[logging.Logger]
    """
    Test usage of `tqdm_logging_redirect`
    """
    import tqdm
    loggers = [logging.getLogger(), logging.getLogger(__name__)]

    with tqdm_logging_redirect(total=9, loggers=loggers, unit='B'):
        logging.info('console logging redirected to `tqdm.write()`')
    return loggers


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    loggers = test_tqdm_logging_redirect()

    all_handlers = list(set([h for logger in loggers
                             for h in logger.handlers]))

    # Ensure that logger handlers were restored to

# Generated at 2022-06-12 14:46:43.446846
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored


# Generated at 2022-06-12 14:46:48.772482
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            time.sleep(1e-1)

# Generated at 2022-06-12 14:46:52.429424
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Tests tqdm_logging_redirect with 2 message loggers.
    """
    import logging

# Generated at 2022-06-12 14:47:02.032942
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test the logging_redirect_tqdm function."""
    import logging
    import tempfile
    import io
    from tqdm.contrib.test_utils import StringIO, DiscreteTimer

    test_log = logging.getLogger(__name__)
    test_log.setLevel(logging.DEBUG)  # needed for tests to work

    with tempfile.TemporaryFile() as log_file:
        log_stream = io.TextIOWrapper(log_file, encoding='utf-8')
        hdlr = logging.StreamHandler(log_stream)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)
        test_log.addHandler(hdlr)


# Generated at 2022-06-12 14:47:11.979747
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    test_args = [1, 2, 3]
    test_kwargs = {'desc': 'testing'}

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(*test_args, **test_kwargs) as pbar:
            pbar.write("console logging redirected to `{}.write()`".format(pbar.__class__.__name__))


# Generated at 2022-06-12 14:47:19.062994
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    string = 'test'
    with std_tqdm(total=1, bar_format='{l_bar}{bar}|', leave=True) as pbar:
        with tqdm_logging_redirect(total=1, bar_format='{l_bar}{bar}|', leave=True):
            assert len(pbar) == 1
            assert pbar.bar_format == '{l_bar}{bar}|'
            assert pbar.leave
            assert str(pbar) == string  # Compatibility with old `bar_fmt`
            assert pbar.n == 0

# Generated at 2022-06-12 14:47:26.509847
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class _TestLogger(object):
        def __init__(self):
            self._is_inited = False

        def __enter__(self):
            # type: () -> Iterator[None]
            self._is_inited = True
            self._stdout = String

# Generated at 2022-06-12 14:47:30.897154
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    # Save the original state
    original_handlers = logging.root.handlers
    picked_logger = logging.getLogger(__name__ + ".test")
    with logging_redirect_tqdm(loggers=[picked_logger]):
        picked_logger.info("test")
        assert logging.root.handlers == original_handlers
        assert len(picked_logger.handlers) == 1
        assert picked_logger.handlers[0].stream is sys.stderr
    assert logging.root.handlers == original_handlers



# Generated at 2022-06-12 14:47:35.654789
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from contextlib import contextmanager

    LOG = logging.getLogger(__name__)

    @contextmanager
    def _test_logging():  # pragma: no cover
        INFO = logging.INFO
        with logging_redirect_tqdm():
            LOG.setLevel(INFO)
            try:
                yield
            finally:
                LOG.setLevel(INFO)

    with _test_logging():
        LOG.info('console logging redirected to `tqdm.write()`')

if __name__ == '__main__':  # pragma: no cover
    test_logging_redirect_tqdm()  # type: ignore

# Generated at 2022-06-12 14:47:43.276141
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from ..tqdm import trange
    try:
        from unittest import mock
    except ImportError:
        import mock
    LOG = logging.getLogger(__name__)

    with mock.patch('tqdm.tqdm.write') as mock_write:
        with tqdm_logging_redirect(total=10):
            for i in trange(10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        assert mock_write.write.call_count == 3

# Generated at 2022-06-12 14:48:09.059734
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    logging.basicConfig(filename='test_tqdm_logging_redirect.log',
                        level=logging.INFO)
    with tqdm_logging_redirect(total=2) as pbar:
        pbar.set_description("foo")
        pbar.update()
        logging.info("bar")
        pbar.update()
    content = []
    with open('test_tqdm_logging_redirect.log') as f:
        content = f.readlines()
    os.remove('test_tqdm_logging_redirect.log')
    assert len(content) == 1
    assert content[0] == "INFO:root:bar\n"



# Generated at 2022-06-12 14:48:17.127898
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import pytest
    except ImportError:
        return
    except:  # noqa pylint: disable=bare-except
        pytest.skip("Failed to import pytest. Skipping tests.")

    import logging
    from tqdm import tnrange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect(total=4, unit="foo", desc="desc",
                                   loggers=None, tqdm_class=tnrange):
            for i in range(4):
                if i == 2:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:22.248647
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:48:28.036295
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import tqdm
    import logging
    loop = tqdm(range(4))
    for i in loop:
        loop.write('First: {}'.format(i))
    with logging_redirect_tqdm():
        for i in tqdm(range(4)):
            loop.write('Second: {}'.format(i))
            logging.info('Message: {}'.format(i))
    for i in range(4):
        loop.write('Third: {}'.format(i))



# Generated at 2022-06-12 14:48:33.945156
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tempfile
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger('test-logger')
    with tempfile.TemporaryFile() as fp:
        log.addHandler(logging.StreamHandler(fp))
        with tqdm_logging_redirect(total=10, unit='B') as t:
            for i in range(5):
                t.update(1)
                log.info('Test {}'.format(i))
        fp.seek(0)
        assert fp.read().decode() == 'Test 0\nTest 1\nTest 2\nTest 3\nTest 4\n'

# Generated at 2022-06-12 14:48:40.692065
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    with logging_redirect_tqdm():
        trange(5)

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(3):
            if i == 1:
                LOG.debug('DEBUG')
            elif i == 2:
                LOG.info('INFO')
            else:
                LOG.warning('WARNING')

    with logging_redirect_tqdm(loggers=[]):
        for i in trange(9):
            if i == 4:
                LOG.info('console logging not redirected')

# Generated at 2022-06-12 14:48:49.812403
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange

    # Initialize a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # Create a handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    # Create a formatter and add it to the handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    # Add the handler to the logger
    logger.addHandler(handler)


# Generated at 2022-06-12 14:48:54.513777
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Example to test tqdm_logging_redirect.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    with logging_redirect_tqdm(loggers=[logging.getLogger()]):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:01.707055
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        with tqdm_logging_redirect(total=2) as pbar:
            for i in range(2):
                assert pbar.n == 0  # unstarted
                if i == 0:
                    LOG.debug("console logging redirected to `tqdm.write()`")
                pbar.update()
            assert pbar.n == 2  # finished
        # logging restored
        LOG.debug("this logging should not be redirected")

# Generated at 2022-06-12 14:49:12.729159
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Asserts that tqdm_logging_redirect is the union of
    tqdm_class(*args, **tqdm_kwargs) as pbar: and
    logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
    """

    import logging
    import io
    import sys

    out = io.StringIO()
    err = io.StringIO()
    sys.stdout = out
    sys.stderr = err

    def mock_logging_redirect_tqdm(*args, **kwargs):
        import contextlib

        @contextlib.contextmanager
        def yield_bar():
            yield
        yield yield_bar

    logger = logging.Logger('logger')