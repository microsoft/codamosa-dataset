

# Generated at 2022-06-12 14:42:48.003191
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import tqdm

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
    logger.addHandler(tqdm_handler)
    logger.debug('haha')
    logger.info('hehe')
    logger.warning('heihei')
    logger.error('hohoho')
    logger.critical('heiheihei')
    tqdm_handler.stream = sys.stderr
    logger.critical('heiheihei')



# Generated at 2022-06-12 14:42:56.090862
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test that verifies logging_redirect_tqdm
    """
    try:
        from unittest.mock import Mock
        from unittest.mock import patch
    except ImportError:
        from mock import Mock
        from mock import patch

    def logger_write(logger, text, end='\n'):
        # type: (logging.Logger, str, str) -> None
        """
        Function which simulates a logger writing to stdout
        """
        stdout_write(text, end=end)

    def stdout_write(text, end='\n'):
        # type: (str, str) -> None
        """
        Function which simulates writing to stdout
        """
        if not isinstance(text, str):
            text = str(text)

        sys.std

# Generated at 2022-06-12 14:43:00.885275
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    loggers = logging.getLogger("test")

    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    # workaround for https://github.com/python/mypy/issues/4384
    with mock.patch.object(sys, 'stdout', spec=sys.stdout):
        with logging_redirect_tqdm(loggers=loggers):
            loggers.info("testing")



# Generated at 2022-06-12 14:43:05.784956
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:43:13.361017
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s:%(levelname)s:%(message)s')
        with logging_redirect_tqdm():
            for i in tqdm(range(6)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        for i in tqdm(range(3)):
            LOG.info("test_logging_redirect_tqdm is done")

    # Unit test for function tqdm_logging_redirect

# Generated at 2022-06-12 14:43:20.471881
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from contextlib import closing
    from tqdm.std import tqdm
    from .wrap_tqdm import wrap_tqdm

    log_orig, log_new = logging.getLogger('orig'), logging.getLogger('new')
    log_orig.setLevel(logging.INFO)
    log_new.setLevel(logging.INFO)
    with closing(wrap_tqdm(tqdm(__name__, file=sys.stdout))) as pbar:
        with logging_redirect_tqdm(
                [log_orig, log_new], tqdm_class=pbar.__class__):
            log_orig.info('orig')
            log_new.info('new')



# Generated at 2022-06-12 14:43:26.118118
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            total=10, desc='Bar', unit='b',
            logger=LOG,
            tqdm_class=trange) as pbar:
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:31.860208
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class MyTqdm(std_tqdm):
        def __init__(self):
            self.last_msg = ""

        def write(self, s):
            self.last_msg = s

    tqdm_handler = _TqdmLoggingHandler(MyTqdm)
    log = logging.getLogger(__name__)
    log.addHandler(tqdm_handler)
    log.info("hello")
    assert tqdm_handler.tqdm_class.last_msg == "hello\n"



# Generated at 2022-06-12 14:43:35.601630
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:43:40.304367
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord('logger1', logging.DEBUG, '/foo/bar.py', 10, "Hello World", None, None)
    record.thread = 1
    handler.emit(record)

# Generated at 2022-06-12 14:43:52.864857
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange, tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Setup logging
    logging.basicConfig(level=logging.INFO)
    LOGGER = logging.getLogger(__name__)

    # Test part 1:
    #   check that message is printed when logging_redirect_tqdm
    #   is not used
    trange(3)
    LOGGER.info("test message")
    # Test part 2:
    #   check that message is printed on tqdm progress bar when
    #   logging_redirect_tqdm is used
    with logging_redirect_tqdm():
        trange(3)
        LOGGER.info("test message")
    # Test part 3:
    #   check that

# Generated at 2022-06-12 14:43:56.563899
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import inspect
    # check that the docstring is valid
    assert inspect.getdoc(logging_redirect_tqdm) == \
        inspect.getdoc(inspect.getclosurevars(tqdm_logging_redirect).nonlocals['logging_redirect_tqdm'])



# Generated at 2022-06-12 14:44:05.210734
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    from tqdm import trange

    with tqdm_logging_redirect(total=9,
                               desc="logging redirected to tqdm.write()") as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert pbar.n == 9
    assert pbar.total == 9
    assert pbar.desc == "logging redirected to tqdm.write()"
    LOG.info("logging restored")

# Generated at 2022-06-12 14:44:10.781615
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import redirect_stdout
    import tempfile
    import io
    import logging
    with tempfile.TemporaryFile() as f:
        with redirect_stdout(f):
            with logging_redirect_tqdm():
                logging.info("test info")
        f.seek(0)
        assert f.read().decode("utf8") == "test info\n"



# Generated at 2022-06-12 14:44:15.160711
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger('test_logging_redirect_tqdm')

    def wait():
        import time
        for _ in range(10):
            time.sleep(0.1)
            LOG.info('console logging redirected to `tqdm.write()`')

    with logging_redirect_tqdm():
        wait()
    LOG.info('logging restored')



# Generated at 2022-06-12 14:44:19.199719
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    my_logger = logging.getLogger('MyLogger')
    stream = StringIO()
    log_handler = _TqdmLoggingHandler(stream=stream)
    my_logger.addHandler(log_handler)
    my_logger.warning("You're using my logger")
    assert stream.getvalue() == "You're using my logger\n"
    my_logger.warning("You're using my logger\n"*10)
    assert stream.getvalue() == "You're using my logger\n"*11

# Generated at 2022-06-12 14:44:21.105023
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:44:26.631309
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    log = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                log.info('console logging redirected to `tqdm.write()`')



# Generated at 2022-06-12 14:44:35.451490
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            loggers=[LOG],
            desc="console logging redirected to `tqdm.write()`") as pbar:
        pbar.update()
        LOG.info("in tqdm context")
        pbar.update()
        pbar.close()

    # logging restored
    LOG.info("after tqdm context")

# Generated at 2022-06-12 14:44:41.067629
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    log = logging.getLogger()
    with tqdm.tqdm_notebook() as pbar:
        with tqdm_logging_redirect(total=5, leave=True, disable=True,
                                   unit='i', unit_scale=True, unit_divisor=1024,
                                   loggers=[log]):
            for i in range(5):
                log.info("Hello")
            pbar.set_description("My description")



# Generated at 2022-06-12 14:44:50.300368
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm as std_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in std_tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:44:56.128662
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    import logging
    from ..main import tqdm
    from ..std import StringIO

    tqdm_class = tqdm
    loggers = [logging.root]

    with StringIO() as buf, tqdm_logging_redirect(
            unit='s',
            file=buf,
            loggers=loggers,
            tqdm_class=tqdm_class
    ):
        assert str(buf.getvalue()) == ''
        LOG = logging.getLogger(__name__)
        LOG.info("hello")
        assert str(buf.getvalue()) == "hello\n"



# Generated at 2022-06-12 14:44:59.808334
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:45:01.652852
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            logging.info(i)

# Generated at 2022-06-12 14:45:06.940820
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging
    from ..std import StringIO

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    def redirect_stdout(stdout=None):
        if stdout is None:
            stdout = sys.stdout
        return stdout

    with redirect_stdout(StringIO()) as new_stdout:
        with tqdm_logging_redirect(
            loggers=[LOG], bar_format="{postfix[0]} |{bar}{r_bar}",
            desc='progress', total=10):
            LOG.info('Hello World')
        sys.stdout.flush()
        assert str(new_stdout.getvalue()).strip().endswith('Hello World')



# Generated at 2022-06-12 14:45:18.115330
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from .tqdm_test_cases import with_unit_option, tqdm_class

    with_unit_option(
        dict(desc="",
             unit=""),
        tqdm_class(100).__enter__(),
        post_check=lambda _, x: x.format_dict['desc'] == "",
        post_check_msg="{}, '{}', {}".format(
            "set_description '' + ' '", "", "set output desc to ''"))


# Generated at 2022-06-12 14:45:24.599245
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """This function tests logging_redirect_tqdm function for
    stdlib logging functionality.
    """
    import logging
    from tqdm import trange
    from ..std import StringIO

    from .test_stdlib import captured_output

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with captured_output() as (out, err):
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

            output = out.getvalue().strip()
            assert ('console logging redirected to `tqdm.write()`' in output)



# Generated at 2022-06-12 14:45:35.596041
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger('test logger')
    LOG.propagate = False  # enable logging without parent logger (disable propagation)
    test_msg = "test message"

    # NOTE: it is not possible to capture sys.stdout.write() output inside a
    # context manager, and this is why we have to build/run a separate test
    # process and capture its output to verify the correctness of this function
    # (see test_logging_redirect_tqdm_wrapper.py)
    with logging_redirect_tqdm():
        LOG.critical(test_msg)
        LOG.warning(test_msg)
        LOG.error(test_msg)
        LOG.info(test_msg)
        LOG.debug(test_msg)


if __name__ == '__main__':
    test_logging_red

# Generated at 2022-06-12 14:45:41.383360
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)
    for n_iterations in range(10):
        with std_tqdm(desc='iteration', total=n_iterations) as pbars:
            with tqdm_logging_redirect(pbars, loggers=[LOG], tqdm_class=std_tqdm):
                for i in range(n_iterations):
                    pbars.update()
                    LOG.info('iteration %d running', i)

# Generated at 2022-06-12 14:45:47.033999
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time

    with tqdm_logging_redirect(bar_format='{l_bar} {n_fmt}/{total_fmt} [{elapsed}<{remaining}, '
                                          '{rate_fmt}{postfix}]',
                               desc='abc') as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()



# Generated at 2022-06-12 14:45:58.997736
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test_logging_redirect_tqdm_functionality():
        with logging_redirect_tqdm():
            for i in trange(10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            LOG.info("This should be invisible to the user")

    test_logging_redirect_tqdm_functionality()

# Generated at 2022-06-12 14:46:06.520712
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm_notebook
    from io import StringIO
    import logging
    import sys

    out = StringIO()

    def test_logging(tqdm=std_tqdm):
        sys.stdout = out
        logging.basicConfig(level=logging.DEBUG)

        with tqdm_logging_redirect(
                total=10,
                # loggers=[logging.getLogger()],
                tqdm_class=tqdm,
                desc="To an external logger") as pbar:
            assert pbar is not None
            pbar.update(1)
            logging.info("A logging message")
            # Prints to sys.stdout
            pbar.write("Can you see me?")
            pbar.update(pbar.total - pbar.n)

# Generated at 2022-06-12 14:46:11.996196
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    #logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm([LOG]):
        LOG.warning("console logging redirected to `tqdm.write()`")
    with logging_redirect_tqdm([LOG]):
        LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:46:18.571979
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    h = _TqdmLoggingHandler()
    h.flush = lambda: None
    h.handleError = lambda record: record
    h.stream = sys.stdout
    for x in [
        logging.NOTSET,
        logging.DEBUG,
        logging.INFO,
        logging.WARNING,
        logging.ERROR,
        logging.CRITICAL,
    ]:
        h.emit(logging.LogRecord('name', x, '/p/n.py', 23, 'message', [], None))

# Generated at 2022-06-12 14:46:22.658967
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    for _ in logging_redirect_tqdm():
        logging.warning("this should be redirected to write(), not stdout")

# Generated at 2022-06-12 14:46:28.218641
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # Code being tested
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            # Some code that should print some logging
            logging.info("test")
        # All good: the logging should now be displayed within tqdm
    except AssertionError:
        assert False, "An AssertionError was raised"
    except Exception:
        assert False, "Exception raised"
    else:
        assert True

# Generated at 2022-06-12 14:46:32.867867
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import __main__
    import logging
    import tqdm
    import tqdm.contrib.test  # must be imported after tqdm
    # type: ignore

    LOG = logging.getLogger(__main__.__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:46:36.334343
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import tqdm_logging_redirect

        LOG = logging.getLogger(__name__)

        with tqdm_logging_redirect(desc="Test Tqdm Logging Redirect"):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    except ImportError:
        pass

# Generated at 2022-06-12 14:46:45.491198
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test that the logging_redirect_tqdm function works properly.
    """
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    # Only in trange
    with logging_redirect_tqdm():
        for i in trange(3):
            pass

    # In trange and tqdm
    with logging_redirect_tqdm():
        with trange(3) as pbar:
            for i in pbar:
                pass

    # Only in tqdm
    with trange(3) as pbar:
        with logging_redirect_tqdm():
            for i in pbar:
                pass

    # Only in trange, but multiple loggers

# Generated at 2022-06-12 14:46:50.469579
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9, desc='test_logging_redirect') as pbar:
        LOG = logging.getLogger(__name__)
        for i in pbar:
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(0.05)



# Generated at 2022-06-12 14:47:04.716164
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
    except ImportError:
        raise unittest.SkipTest("logging module not found")

    import contextlib
    import io
    import sys

    if sys.version_info >= (3, 4):
        @contextlib.contextmanager
        def captured_output(stream_name):
            # type: (str) -> Iterator[io.StringIO]
            orig_stdout = getattr(sys, stream_name)
            captured_stdout = io.StringIO()
            setattr(sys, stream_name, captured_stdout)
            try:
                yield captured_stdout
            finally:
                setattr(sys, stream_name, orig_stdout)

# Generated at 2022-06-12 14:47:12.321179
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    formatter = logging.Formatter('[%(asctime)s] %(message)s', '%H:%M:%S')
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    LOG.addHandler(stream_handler)

    with tqdm_logging_redirect():
        for i in range(4):
            if i == 2:
                LOG.info("Info message")
            if i == 3:
                LOG.debug("Debug message")

# Generated at 2022-06-12 14:47:17.170345
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger('logging_redirect_tqdm')
    logging.basicConfig(level=logging.INFO)
    # Without logging_redirect_tqdm
    for i in trange(9):
        if i == 4:
            LOG.info('console logging not redirected to `tqdm.write()`')
    # With logging_redirect_tqdm
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:47:25.101637
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logger = _TqdmLoggingHandler()
    try:
        raise KeyboardInterrupt
    except:  # noqa pylint: disable=bare-except
        error_record = logging.LoggerAdapter(
            logging.getLogger(__name__), {"cnt": 1}
        ).makeRecord(
            name=__name__,
            level=logging.ERROR,
            fn=__file__,
            lno=sys.exc_info()[2].tb_lineno,
            msg="",
            args=None,
            exc_info=sys.exc_info(),
        )

    # Test that error is thrown within the method

# Generated at 2022-06-12 14:47:29.199338
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        assert pbar.__class__.__name__ == 'tqdm'
        assert pbar.desc == '100%|██████████| 1/1 [00:00<00:00, ...]'
        logging.info('aa')
        assert pbar.desc == '100%|██████████| 1/1 [00:00<00:00, ...]\n' + 'aa\n'

# Generated at 2022-06-12 14:47:32.624457
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[logger], total=5, disable=None, desc=__name__) as pbar:
        assert pbar.total == 5
        for i in range(5):
            if i == 3:
                logger.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-12 14:47:36.191171
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG_FORMAT = "%(message)s"
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    loggers = [logging.root, logging.getLogger("urllib3")]
    with tqdm_logging_redirect(loggers=loggers):
        logging.info("console logging redirected")
    # logging restored

# Generated at 2022-06-12 14:47:43.462639
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:48.789081
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger("test_logging_redirect_tqdm")
    with logging_redirect_tqdm():
        for i in range(3):
            LOG.info("info")
            LOG.warning("warning")
            LOG.error("error")
    log_out = "info\nwarning\nerror\ninfo\nwarning\nerror\ninfo\nwarning\nerror\n"
    # check StreamHandler was redirected
    assert (std_tqdm.stdout_write.getvalue() == log_out)


# Generated at 2022-06-12 14:47:56.890155
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger('foo')
    LOG.setLevel(logging.DEBUG)
    LOG.propagate = False

    # Cannot use @contextmanager since logging.basicConfig() must be called before
    # logging_redirect_tqdm() to avoid the 'No handlers could be found' error.
    with logging_redirect_tqdm(loggers=[LOG]):
        logging.debug('Debug message.')
        logging.info('Info message.')

    with logging_redirect_tqdm(loggers=[LOG], tqdm_class=tqdm.tqdm):
        logging.debug('Debug message.')
        logging.info('Info message.')
        tqdm.tqdm.write('Direct tqdm.tqdm.write()')
    return



# Generated at 2022-06-12 14:48:09.260936
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from random import random

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=10,
                               desc="Logged tqdm",
                               ncols=80,
                               mininterval=0,
                               leave=False,
                               log_level=logging.DEBUG,
                               loggers=[LOG]):

        for _ in range(10):
            LOG.debug("random num (DEBUG): {}".format(random()))
            LOG.info("random num (INFO): {}".format(random()))
            LOG.warning("random num (WARNING): {}".format(random()))
            LOG.error("random num (ERROR): {}".format(random()))

# Generated at 2022-06-12 14:48:13.892393
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:48:19.978086
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        name='name',
        level=logging.DEBUG,
        pathname='pathname',
        lineno=4,
        msg='message',
        args=(),
        exc_info=None,
    )
    tqdm_logging_handler.emit(record)

# Generated at 2022-06-12 14:48:24.631271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger()

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:48:28.539209
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    with tqdm_logging_redirect(
        trange(9),
        loggers=[logging.root],
    ) as pbar:
        for i in pbar:
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:35.097218
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    test_out = 'Testing tqdm.contrib.logging.logging_redirect_tqdm()'
    # Create TqdmLoggingHandler object
    tqdm_log = _TqdmLoggingHandler()
    # Create fake record
    record = logging.LogRecord(
        name='LoggerName', level=0, pathname='PathName',
        lineno=0, msg=test_out, args=(), exc_info=None
    )
    # Call the emit method with the fake record
    tqdm_log.emit(record)
    # Retrieve the written text
    written_out = tqdm_log.stream.getvalue().strip()
    # Test if the written text is equal to the test_out text
    assert written_out == test_out



# Generated at 2022-06-12 14:48:41.006839
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .main import tqdm
    from .std import tqdm as std_tqdm

    logging.basicConfig(level=logging.INFO)
    func = lambda: 1
    with tqdm_logging_redirect(iterable=range(2),
                               loggers=[logging.getLogger(__name__)]) as pbar:
        for i in pbar:
            func()

    if tqdm.gui:
        assert isinstance(pbar, pbar.__class__)
    else:
        assert isinstance(pbar, std_tqdm)

# Generated at 2022-06-12 14:48:44.605515
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:46.106412
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig()
    with logging_redirect_tqdm():
        logging.info("Hello world")

# Generated at 2022-06-12 14:48:53.616299
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import tqdm
    with tqdm_logging_redirect(logging.root, ncols=80, total=10):
        for i in range(10):
            logging.info("test1")
    with tqdm_logging_redirect(logging.root, tqdm=tqdm, ncols=80, total=10):
        for i in range(10):
            logging.info("test2")
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(ncols=80, total=10):
        for i in range(10):
            logging.info("test3")

# Generated at 2022-06-12 14:49:06.921044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:49:12.997261
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    with tqdm_logging_redirect(
            total=9, desc='test_tqdm_logging_redirect',
            loggers=[logging.getLogger()]):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:49:18.051219
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import pretest_posttest  # noqa
    import logging
    logger = logging.getLogger('__main__')
    with tqdm_logging_redirect(desc='test', unit='it', mininterval=0.1,
                               loggers=[logger]):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-12 14:49:25.305573
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:49:30.772020
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:49:33.081777
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import tqdm

    with tqdm_logging_redirect(total=1) as pbar:
        logging.info('message')
        pbar.update()



# Generated at 2022-06-12 14:49:38.038659
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    
    LOG = logging.getLogger(__name__)
    
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:49:46.869124
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest  # type: ignore  # noqa
    except ImportError:
        import unittest  # type: ignore

    class TestLoggingRedirectTqdm(unittest.TestCase):
        def test_logging_redirect_tqdm(self):
            from tqdm.contrib import logging_redirect_tqdm

            try:
                logging.basicConfig(level=logging.INFO)
                LOG = logging.getLogger(__name__)
                with logging_redirect_tqdm():
                    LOG.info("console logging redirected to `tqdm.write()`")
            except ImportError:
                pass
    unittest.main(argv=['ignored', '-v'], exit=False)



# Generated at 2022-06-12 14:49:54.109795
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .test_tqdm import pretest_posttest  # pylint: disable=unused-variable
    import logging
    try:
        from StringIO import StringIO  # python 2
    except ImportError:
        from io import StringIO

    from .std import tqdm as std_tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    LOG.handlers = []
    str_io = StringIO()
    ch = logging.StreamHandler(str_io)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    ch.setFormatter(formatter)
    LOG.addHandler(ch)


# Generated at 2022-06-12 14:50:00.461569
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    logger = logging.getLogger()

    with tqdm_logging_redirect(loggers=logger) as pbar:
        pbar.write("logging_redirect_tqdm: redirecting basic console logging to tqdm.write()")
        logger.info("logging_redirect_tqdm: logging from logger is also redirected")

    logger.info("logging_redirect_tqdm: restored to logger.handlers")

# Generated at 2022-06-12 14:50:21.687574
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=100):
        for _ in range(100):
            logger.info("this is a test")

# Generated at 2022-06-12 14:50:30.246948
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import os
    import tempfile
    import traceback
    import logging

    def call_emit(msg):
        writer = logging.StreamHandler()
        handler = _TqdmLoggingHandler()
        handler.stream = writer.stream
        handler.emit(logging.LogRecord("test.log","test",__file__,10,"test",None,None))
        return writer.stream.getvalue()

    def create_temp_file(content):
        fd, fname = tempfile.mkstemp()
        with os.fdopen(fd, "w") as f:
            f.write(content)
        return fname

    def delete_temp_file(fname):
        os.unlink(fname)


# Generated at 2022-06-12 14:50:38.947082
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    # First, suppress tqdm logging messages:
    logging.getLogger("tqdm").setLevel(logging.WARNING)
    # Make a logger and test if all is working as is:
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    try:
        log_message = "console logging redirected to tqdm"
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info(log_message)
    except AttributeError:
        raise AssertionError("logging_redirect_tqdm did not un-redirect logging")
    # Now test the logging_redirect_tqdm context manager:

# Generated at 2022-06-12 14:50:47.007708
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name

    try:
        import tqdm
    except ImportError:
        return

    log_data = []  # type: List[str]
    with tqdm.std.tqdm(total=9) as pbar:
        # Make sure tqdm.std.tqdm is used
        with logging_redirect_tqdm(loggers=[LOG], tqdm_class=std_tqdm):
            for i in range(9):
                if i == 4:
                    log_data.append(LOG.info("console logging redirected to `tqdm.write()`"))
                pbar.update()

# Generated at 2022-06-12 14:50:57.397901
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    from tqdm.tests import _random_bool
    from . import _capture_stdout

    log = logging.getLogger(__name__)

    with _capture_stdout() as caught_output:
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    log.info(i)
                else:
                    print(i)
    captured_lines = caught_output.getvalue().splitlines()
    assert len(captured_lines) == 9
    assert all([c.isdigit() for c in captured_lines])


# Generated at 2022-06-12 14:51:00.461054
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import _test_tqdm_logging_redirect
    _test_tqdm_logging_redirect(tqdm_logging_redirect)
    _test_tqdm_logging_redirect(tqdm_logging_redirect,
                                "my_logging_redirect")

# Generated at 2022-06-12 14:51:07.005818
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    mock_tqdm = MagicMock()
    mock_tqdm_close = MagicMock()
    mock_tqdm.return_value.__enter__.return_value.close = mock_tqdm_close

    mock_logging_redirect_tqdm = MagicMock()
    mock_logging_redirect_tqdm_close = MagicMock()
    mock_logging_redirect_tqdm.return_value.__enter__.return_value = \
        mock_logging_redirect_tqdm_close

    with tqdm_logging_redirect():
        pass
    mock_tqdm.assert_called_once_with()
   

# Generated at 2022-06-12 14:51:09.410393
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm
    from .std import trange
    LOG = logging.getLogger(__name__)
    try:
        with tqdm_logging_redirect(loggers=[LOG]) as pbar:
            for _ in trange(9):
                if pbar.n == 4:
                    LOG.info('console logging redirected to `tqdm.write`')
    except AttributeError:
        pass

# Generated at 2022-06-12 14:51:19.932595
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    import tqdm
    from contextlib import redirect_stdout

    # test with default loggers
    with open('/dev/null', 'w') as null:
        with redirect_stdout(null):
            with tqdm_logging_redirect():
                logging.info('Content to write')

    # test with loggers
    loggers = [logging.getLogger('loggers')]
    with open('/dev/null', 'w') as null:
        with redirect_stdout(null):
            with tqdm_logging_redirect(loggers=loggers):
                logging.info('Content to write')

    # test with tqdm

# Generated at 2022-06-12 14:51:27.832778
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    >>> LOG = logging.getLogger(__name__)
    >>> logging.basicConfig(level=logging.INFO)
    >>> with tqdm_logging_redirect(unit_scale=True) as pbar:
    ...     for i in trange(9):
    ...         if i == 4:
    ...             LOG.info("console logging redirected to `tqdm.write()`")
    ...     with logging_redirect_tqdm():
    ...         LOG.info("another message")
    ...     LOG.info("but now console logging restored again")
    2it [00:00,  9.99it/s]console logging redirected to `tqdm.write()`
    another message
    [04:00<00:00,  6.00it/s]but now console logging restored again
    """

# Generated at 2022-06-12 14:52:10.963921
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # set instance of class _TqdmLoggingHandler to the logger
    tqdm_handler = _TqdmLoggingHandler()
    logger.addHandler(tqdm_handler)

    # test the emit method of class _TqdmLoggingHandler
    logger.info('this is a info message')



# Generated at 2022-06-12 14:52:14.555379
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-12 14:52:21.473412
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm as std_tqdm

    try:
        from .._tqdm import tqdm as tqdm_notebook
    except ImportError:
        tqdm_notebook = None

    for tqdm_class in [std_tqdm, tqdm_notebook]:
        with logging_redirect_tqdm():
            logging.info("testing")
            assert "testing" in sys.stdout.getvalue()
            assert not "testing" in sys.stderr.getvalue()
            logging.error("testing")
            assert not "testing" in sys.stdout.getvalue()
            assert "testing" in sys.stderr.getvalue()

# Generated at 2022-06-12 14:52:28.469786
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        assert pbar.n == 0
        LOG.info("console logging redirected to `tqdm.write()`")
        assert pbar.n == 1
        # logging restored

# Generated at 2022-06-12 14:52:33.779082
# Unit test for function logging_redirect_tqdm

# Generated at 2022-06-12 14:52:38.668199
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                pbar = std_tqdm.tqdm(total=9)
                pbar.update()
                logging.info('console logging redirected to `tqdm.write()`')
                pbar.close()
                break
        else:
            # logging restored
            raise AssertionError('4 not found')

