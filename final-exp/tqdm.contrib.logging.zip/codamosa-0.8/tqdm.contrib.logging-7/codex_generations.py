

# Generated at 2022-06-12 14:42:49.080735
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm import tqdm_gui
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(loggers=[LOG], tqdm_class=tqdm_gui) as pbar:
        for i in trange(9, desc='test', leave=True):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        assert len(pbar.n) == 9

# Generated at 2022-06-12 14:42:55.109923
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    try:
        from test_tqdm import with_bar
        from test_tqdm import closing
    except ImportError:
        from .tests.test_tqdm import with_bar
        from .tests.test_tqdm import closing

    with closing(with_bar()) as (_, pbar):
        with tqdm_logging_redirect(total=10, tqdm_class=pbar):
            LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:42:56.996551
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as logger:
        logging.info("info1")
        logging.info("info2")

# Generated at 2022-06-12 14:43:06.033900
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    tqdm_output = '\n'.join([str(i + 1) for i in range(10)])
    logging_output = '\n'.join([str(i + 1) for i in range(8, 10)])

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    logging.basicConfig(format='%(levelname)s:%(message)s')

    # tqdm_logging_redirect
    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(10):
            pbar.update()
            if i == 8:
                LOG.info("console logging redirected to `tqdm.write()`")
                LOG.info("second log")
    assert pbar.format_

# Generated at 2022-06-12 14:43:13.507226
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger('test_logging_redirect_tqdm')
    logging.basicConfig(level=logging.INFO)

    expected_stdout = [
        "INFO:test_logging_redirect_tqdm:console logging redirected to `tqdm.write()`\n",
        "INFO:test_logging_redirect_tqdm:console logging restored\n"
    ]


# Generated at 2022-06-12 14:43:16.178832
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(unit='B', unit_scale=True, unit_divisor=1024,
                               miniters=1, mininterval=1, maxinterval=1) as t:
        t.update(4321)
    assert t.n == 4321

# Generated at 2022-06-12 14:43:20.542586
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=10, miniters=1, mininterval=1) as pbar:
        for i in pbar:
            LOG.info('Logging a bunch of stuff')



# Generated at 2022-06-12 14:43:26.406255
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import TqdmTypeError, TqdmKeyError, TqdmWarning, TqdmDeprecationWarning

    class TqdmHandler(_TqdmLoggingHandler):
        def __init__(self):
            self.errors = []  # type: List[Exception]
            self.warnings = []  # type: List[Exception]

        def emit(self, record):
            try:
                super(TqdmHandler, self).emit(record)
            except (TqdmTypeError, TqdmKeyError, TqdmWarning, TqdmDeprecationWarning) as e:
                self.warnings.append(e)
            except Exception as e:
                self.errors.append(e)

    message = 'Test message'
    logger = logging.Logger('test')

# Generated at 2022-06-12 14:43:34.101439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_util import _decode_if_py2_bytes_logging
    import logging

    log = logging.getLogger()
    log.handlers = []

    with logging_redirect_tqdm():
        log.warning('hello')
    assert _decode_if_py2_bytes_logging(_tqdm.write_str) == "INFO:root:hello\n"

    with open('tqdm.log', 'w') as f:
        log_handler = logging.StreamHandler(f)
        log.handlers.append(log_handler)
        with logging_redirect_tqdm():
            log.warning('foo')
    with open('tqdm.log', mode='r') as f:
        log_contents = f.read()
    assert log_contents == ""


# Generated at 2022-06-12 14:43:39.442343
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import sys
    import logging
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.INFO)
    io = StringIO()
    streamhandler = logging.StreamHandler(io)
    test_logger.addHandler(streamhandler)

    logger_message = 'This is my logger message'
    tqdm_message = 'This is my tqdm message'

    with tqdm_logging_redirect(loggers=[test_logger], total=1) as pbar:
        pbar.write(tqdm_message)
        test_logger.info(logger_message)

    result = io.getvalue()

    assert tqdm_message

# Generated at 2022-06-12 14:43:51.331595
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Example of how to test the logging_redirect_tqdm function"""
    import logging
    # import tqdm
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        LOG.info("first")
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to tqdm")
        LOG.info("last")

        # Output:
        # INFO:__main__:first
        # INFO:__main__:console logging redirected to tqdm
       

# Generated at 2022-06-12 14:44:00.457515
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging, sys
    from tqdm import tqdm
    from tqdm.contrib.logging import redirect_logs

    # Check that no error is raised, and that tqdm is used
    LOGGER = logging.getLogger('my_logger')
    LOGGER.setLevel(logging.INFO)
    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setFormatter(logging.Formatter('%(asctime)s %(message)s',
                                           '%Y/%m/%d %H:%M:%S'))
    LOGGER.addHandler(handler)

    tqdm_kwargs = dict(ascii=True, desc='my tqdm loop', leave=False)

# Generated at 2022-06-12 14:44:07.672042
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm import tqdm

    with tqdm_logging_redirect(total=5,
                               desc="test",
                               loggers=None,
                               tqdm_class=tqdm) as pbar:
        import logging
        LOG = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        for i in range(5):
            if i == 4:
                # logging redirected to `tqdm.write()`
                LOG.info("in iteration %s", i)


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:44:12.828091
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    console_logging_handler = logging.StreamHandler(sys.stdout)
    tqdm_handler.stream = console_logging_handler.stream
    record = logging.LogRecord(
        'name', logging.INFO, 'pathname', 0, 'msg', args=None, exc_info=None)
    tqdm_handler.emit(record)
    tqdm_handler.flush()



# Generated at 2022-06-12 14:44:19.354416
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import subprocess
    import sys

    if 'TRAVIS' in os.environ:
        # Travis CI runs tests in a separate subprocess
        # and so logging messages may get lost
        raise RuntimeError(
            "Travis CI is known to have a logging problem "
            "causing this unit test to fail intermittently. See: "
            "https://github.com/tqdm/tqdm/issues/485")

    # Setting up the logger
    logging.basicConfig(level=logging.INFO)
    LOGGER = logging.getLogger(__name__)

    # Testing with a few different methods

# Generated at 2022-06-12 14:44:24.585814
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Tests logging_redirect_tqdm()."""
    import logging
    from .test_tqdm import with_setup

    LOG = logging.getLogger(__name__)

    def test_exception():
        # type: () -> None
        """Test that exception catching works correctly for the
        tqdm_logging_redirect context manager."""
        with logging_redirect_tqdm():
            raise ValueError

    @with_setup(pretest=test_exception)
    def test_logging_redirect_tqdm_reset_logging():
        # type: () -> None
        """Tests that the console handler is not left in the logger."""
        assert not logging.getLogger(__name__).handlers


# Generated at 2022-06-12 14:44:35.710096
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(
        total=2, tqdm_class=std_tqdm, desc='test',
        loggers=[logging.root],
    ) as pbar:
        logging.info('logging redirected to `tqdm.write()`')
        pbar.update()
    with tqdm_logging_redirect(
        total=2, tqdm_class=std_tqdm, desc='test',
        loggers=[logging.root],
    ) as pbar:
        logging.info('logging redirected to `tqdm.write()`')
        pbar.update()
        raise Exception

# Generated at 2022-06-12 14:44:42.176234
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # create a logger
    log = logging.getLogger(__name__)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    log.addHandler(ch)

    with logging_redirect_tqdm():
        log.info('hello world')



# Generated at 2022-06-12 14:44:50.637572
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import logging
    from tqdm import trange

    class TestLoggingRedirectTqdm(unittest.TestCase):
        """
        Unit tests for tqdm.contrib.logging.logging_redirect_tqdm
        """

        def setUp(self):
            for handler in logging.root.handlers[:]:
                logging.root.removeHandler(handler)

        def test_logging_redirect_tqdm(self):
            """
            Unit test for tqdm.contrib.logging.logging_redirect_tqdm
            """
            # Test with 1 logger
            logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:44:59.955146
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import io
        import logging
        import unittest
        import tqdm
        from tqdm.contrib.logging import _TqdmLoggingHandler
    except ImportError:
        return

    class MockLoggingHandler(logging.Handler):
        def __init__(self):
            self.messages = []
            super(MockLoggingHandler, self).__init__()

        def emit(self, record):
            self.messages.append(record.msg)

    class TestTqdmLoggingHandler(unittest.TestCase):
        """
        Check that _TqdmLoggingHandler works as expected
        """
        def setUp(self):
            self.mock_handler = MockLoggingHandler()
            self.stream = io.StringIO()


# Generated at 2022-06-12 14:45:10.742573
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(miniters=1) as pbar:
        for i in range(3):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()

    assert pbar.n == i + 1



# Generated at 2022-06-12 14:45:20.683200
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    from . import tqdm
    from .contrib import logging_redirect_tqdm, tqdm_logging_redirect

    logger = mock.MagicMock(logging.Logger)
    logger.handlers = []
    mock_pbar = mock.MagicMock()

    with mock.patch('logging.root.handlers', [logger]):
        with mock.patch('tqdm.std.tqdm', mock.Mock(return_value=mock_pbar)) as mock_tqdm:
            with tqdm_logging_redirect('Testing'):
                pass
            mock_tqdm.assert_called_once_with('Testing')
    mock_pbar.__enter

# Generated at 2022-06-12 14:45:25.311248
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():  # doctest: +SKIP
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:30.267405
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    tlh.emit(logging.LogRecord(name='test', level=logging.INFO, fn=__file__,
                               lno=0, msg='test message', args=(), exc_info=None))

# Generated at 2022-06-12 14:45:35.634309
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange, tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 8:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:44.640551
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class LogLevelFilter(logging.Filter):
        def __init__(self, upper_level_limit):
            self.upper_level_limit = upper_level_limit

        def filter(self, record):
            return record.levelno <= self.upper_level_limit

    tqdm_handler = _TqdmLoggingHandler()
    logger = logging.Logger('Test')
    logger.addHandler(tqdm_handler)
    logger.addFilter(LogLevelFilter(logging.ERROR))

    # check without exception
    logger.error('Test')

    # check exception handling
    tqdm_handler.emit(logging.DEBUG())
    tqdm_handler.emit(logging.DEBUG('Test'))

# Generated at 2022-06-12 14:45:53.050502
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import tempfile
    import unittest
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    class TestTqdmLoggingRedirect(unittest.TestCase):
        def setUp(self):
            self.fd, self.log_file = tempfile.mkstemp()
            self.handler = logging.FileHandler(self.log_file)
            self.handler.setLevel(logging.DEBUG)
            LOG.addHandler(self.handler)
            self.original_stdout_stream = sys.stdout
            self.temp_stdout_file = tempfile.TemporaryFile()
            sys.stdout = self.temp_stdout_file
            self.original_stderr_stream = sys.stderr
           

# Generated at 2022-06-12 14:45:55.473633
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for _ in trange(5):
            logging.info('foo')



# Generated at 2022-06-12 14:46:00.512979
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Test case: success message
    tlh = _TqdmLoggingHandler(tqdm_class=std_tqdm)
    record = logging.LogRecord(
        name='test',
        level=logging.INFO,
        pathname=None,
        lineno=0,
        msg='test pass',
        args=(),
        exc_info=None
    )
    tlh.emit(record)

# Generated at 2022-06-12 14:46:07.288215
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Test for function `tqdm_logging_redirect`
    """
    import time
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger()

    if __name__ == '__main__':
        # Test whether logger works as expected
        LOG.setLevel(logging.INFO)
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for _ in pbar:
                LOG.info("console logging redirected to `tqdm.write()`")
                time.sleep(0.01)
        # logging restored
        print("logging restored")
        LOG.info("logging restored")



# Generated at 2022-06-12 14:46:23.006281
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import tqdm
    from ..utils import tqdm_proxy
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        try:
            with logging_redirect_tqdm():
                for i in tqdm.trange(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
        except KeyboardInterrupt:
            pass


# Generated at 2022-06-12 14:46:28.217384
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect("Testing tqdm_logging_redirect", total=4) as pbar:
        for i in range(4):
            pbar.update(1)
            if i == 2:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:31.395483
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with io.StringIO() as s:
        with logging_redirect_tqdm():
            for i in trange(9, file=s):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        assert s.getvalue() == "console logging redirected to `tqdm.write()`\r"


# Generated at 2022-06-12 14:46:36.901244
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # create logger
    logger = logging.getLogger('test_log')
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)
    with logging_redirect_tqdm():
        logger.debug('started process')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')

# Generated at 2022-06-12 14:46:45.798637
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from contextlib import contextmanager
    from tqdm import trange

    def is_module_available(module_name):
        try:
            __import__(module_name)
        except ImportError:
            return False
        else:
            return True

    @contextmanager
    def _assert_log_printed(log_msg):
        """
        Helper context manager that verifies that a message has been logged.
        """
        try:
            yield

        except AssertionError:
            raise

        except KeyboardInterrupt:
            raise

        except SystemExit:
            raise

        except BaseException:
            raise

        else:
            msg = "expected log message not logged to console: '%s'" % log_msg
            raise AssertionError(msg)


# Generated at 2022-06-12 14:46:55.112968
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    @contextmanager
    def logging_redirect_tqdm():
        with tqdm_logging_redirect(
                total=9, ascii=True, mininterval=0, desc='tqdm'):
            for i in range(9):
                if i == 4:
                    LOG.debug("logging redirected to `tqdm.write()`")
                if i == 6:
                    LOG.info("logging redirected to `tqdm.write()`")

    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        pass


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:02.725303
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from unittest import mock
    from io import StringIO
    test_file = StringIO()
    mock_pbar = mock.Mock(spec=std_tqdm)
    mock_pbar.write.return_value = None
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.tqdm_class = mock_pbar
    tqdm_handler.stream = test_file
    record = logging.LogRecord('name', 'INFO', 'pathname', 0, 'msg', None, None)
    tqdm_handler.emit(record)
    assert mock_pbar.write.call_count == 1

# Generated at 2022-06-12 14:47:09.365998
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("this is logged normally again")

# Generated at 2022-06-12 14:47:13.310038
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.std import tqdm
    log = []
    with tqdm_logging_redirect() as pbar:
        tqdm.write("Hello World")
        log.append("Hello World")
        logging.info("logging redirected to `tqdm.write()`")
        log.append("logging redirected to `tqdm.write()`")
    assert pbar.n == 2



# Generated at 2022-06-12 14:47:18.716651
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=10) as pbar:
        assert isinstance(pbar, std_tqdm)
        with logging_redirect_tqdm():
            LOG = logging.getLogger(__name__)
            for i in pbar:
                if i == 5:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:47:32.532984
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Since we are using the default logger (the root logger)
    # it must first be configured.
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:47:42.622188
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm, logging

    def set_up():
        a_logger = logging.getLogger('a_logger')
        a_logger.handlers = []

        with tqdm_logging_redirect(
                loggers=[a_logger], tqdm_class=tqdm, desc='a_bar'):
            a_logger.info('a_log')
        return a_logger.handlers[0].tqdm_class

    def clean_up():
        a_logger = logging.getLogger('a_logger')
        a_logger.handlers = []

    # test
    try:
        assert set_up()(desc='a_bar')
    finally:
        clean_up()



# Generated at 2022-06-12 14:47:48.344787
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test logging_redirect_tqdm
    """
    handler_class = _get_first_found_console_logging_handler
    assert handler_class([]) is None

    handler = _TqdmLoggingHandler()
    assert handler_class([handler]) is None

    handler = logging.StreamHandler()
    assert handler_class([handler]) is handler

    handler = logging.StreamHandler(sys.stdout)
    assert handler_class([handler]) is handler

    handler = logging.StreamHandler(sys.stderr)
    assert handler_class([handler]) is handler



# Generated at 2022-06-12 14:47:51.495727
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    log = logging.getLogger()
    log.setLevel(logging.INFO)
    log.propagate = False
    # log.handlers = []
    with tqdm_logging_redirect():
        log.info("This should be written by tqdm")

# Generated at 2022-06-12 14:47:58.018547
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from io import StringIO
    import logging
    from tqdm import trange
    from tqdm import tqdm as std_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger()
    stream = StringIO()
    try:
        handler = logging.StreamHandler(stream=stream)
    except TypeError:
        handler = logging.StreamHandler(strm=stream)
    LOG.addHandler(handler)

    def validate_redirect(tqdm_class, loggers=None):
        # type: (Type[std_tqdm], Optional[List[logging.Logger]]) -> None
        prefix = 'test_prefix'
        LOG.debug('test')

# Generated at 2022-06-12 14:48:06.653239
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import StringIO
    from .tests_tqdm import closing, _range  # NOQA

    log = logging.getLogger()
    assert log.handlers, "No existing logging handlers found"
    orig_handlers = log.handlers
    try:
        sio = StringIO()
        with closing(sio), logging_redirect_tqdm():
            for i in _range(9):
                if i == 4:
                    log.warning("test_logging_redirect_tqdm")
        assert sio.getvalue() == "100%|##########| 9/9 [00:00<00:00, 1795.53it/s]test_logging_redirect_tqdm\n", \
            "Incorrect log output"
    finally:
        log.handlers = orig_

# Generated at 2022-06-12 14:48:11.872136
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        pbar.set_description('logging_redirect_tqdm')
        pbar.update(1)
        LOG.info('logging.root')
        LOG.info('logging redirected to `tqdm.write()`')
        for x in trange(4):
            pbar.update(1)

# Generated at 2022-06-12 14:48:17.557609
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time

    with tqdm_logging_redirect() as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info("one")
        time.sleep(0.01)
        LOG.info("two")
        time.sleep(0.01)
        LOG.info("three")
        time.sleep(0.01)
        pbar.update(3)

# Generated at 2022-06-12 14:48:24.352977
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        logger.info('test')
        logger.warning('test 1')
        pbar.write('test 2')
    assert len(pbar.format_dict) == 3
    assert 'test' in pbar.format_dict
    assert 'test 1' in pbar.format_dict
    assert 'test 2' in pbar.format_dict

# Generated at 2022-06-12 14:48:32.355524
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    from contextlib import redirect_stdout
    from .main import tqdm, tqdm_notebook
    import logging

    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.stream = io.StringIO()
    record = logging.LogRecord('name', logging.INFO, None, 0, "Message",
                               'args', None)
    with redirect_stdout(handler.stream):
        handler.emit(record)
        assert "Message\n" == handler.stream.getvalue()

    record.msg = "%s"
    with redirect_stdout(handler.stream):
        handler.emit(record)
        assert "%s\n" == handler.stream.getvalue()

    record.msg = "%s %s"

# Generated at 2022-06-12 14:48:57.375093
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.auto import tqdm

    loggers = [logging.root]
    for i, f in enumerate(tqdm([1, 2, 3], desc='tqdm in function')):
        if i == 1:
            with logging_redirect_tqdm(loggers=loggers):
                logging.info("console logging redirected to `tqdm.write()`")
    assert [i.get_description() for i in tqdm.tqdm.instances] == ['tqdm in function']
    del tqdm.tqdm.instances[:]

# Generated at 2022-06-12 14:49:04.606510
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Function unit test for tqdm.contrib.logging.logging_redirect_tqdm()

    Example
    -------
    >>> import logging
    >>> from tqdm import trange
    >>> from tqdm.contrib.logging import logging_redirect_tqdm
    >>> LOG = logging.getLogger(__name__)
    >>> if __name__ == '__main__':
    ...     logging.basicConfig(level=logging.INFO)
    ...     with logging_redirect_tqdm():
    ...         for i in trange(9):
    ...             if i == 4:
    ...                 LOG.info("console logging redirected to `tqdm.write()`")
    ...     # logging restored

    """
    import logging

# Generated at 2022-06-12 14:49:14.105680
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import math
    import os
    import tempfile
    from tqdm import trange

    log_path = tempfile.mktemp()
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(log_path)
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))
    root_logger.addHandler(file_handler)

    with tqdm_logging_redirect(total=100):
        for i in range(100):
            logging.info("Progress: {:3.2f}".format(i / 100.0 * 100.0))

# Generated at 2022-06-12 14:49:19.172958
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(name='test_logger',
                               level=logging.DEBUG,
                               pathname='path',
                               lineno=1,
                               msg='test_msg',
                               args=(),
                               exc_info=None)
    tqdm_handler.emit(record)

# Generated at 2022-06-12 14:49:28.475504
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Only tests if it can be imported and run.
    """
    from tqdm._utils import _term_move_up

    def get_indent(string, indent="   "):
        # type: (str, str) -> str
        return ''.join(indent + line for line in string.splitlines(True))

    if not _term_move_up:
        return

    # Nothing redirected (logging.warning to console)
    logging.warning("foo")  # pylint: disable=logging-format-interpolation
    print("bar")
    before_list = [line.rstrip() for line in sys.stdout.getvalue().splitlines()]

    # Reset buffer
    sys.stdout.flush()
    sys.stdout.seek(0)
   

# Generated at 2022-06-12 14:49:35.329292
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    with tqdm_logging_redirect():
        logging.info("This must be redirected to tqdm")
        logging.info("This must be redirected to tqdm")
        logging.error("This must be redirected to tqdm")
    with tqdm(disable=True) as pbar:
        with logging_redirect_tqdm(loggers=[logging.getLogger(__name__)],
                                   tqdm_class=pbar.__class__):
            logging.info("This must be redirected to tqdm")
            logging.error("This must be redirected to tqdm")

# Generated at 2022-06-12 14:49:41.807327
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    # create an instance of logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stream_handler)

    # logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[logger]):
        for i in std_tqdm(range(9)):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:49:49.913919
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    import sys

    class LogFormatter(logging.Formatter):
        GREY, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)

        RESET_SEQ = "\033[0m"
        COLOR_SEQ = "\033[1;%dm"
        COLORS = {
            'WARNING': YELLOW,
            'INFO': WHITE,
            'DEBUG': BLUE,
            'CRITICAL': YELLOW,
            'ERROR': RED
        }

        def __init__(self, msg, use_color=True):
            logging.Formatter.__init__(self, msg)
            self.use_color = use_color

        def format(self, record):
            levelname = record.levelname

# Generated at 2022-06-12 14:49:54.492926
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm
    with tqdm_logging_redirect() as pbar:
        for it in range(100):
            if it == 50:
                logging.info('Redirecting logging to tqdm')
            pbar.update()
        assert (sys.stdout.getvalue().count('\n') ==
                100 + sys.stdout.getvalue().split('\n')[-2].count('\r'))
        assert ('\r' + sys.stdout.getvalue().split('\r')[-2]).endswith('Redirecting logging to tqdm')



# Generated at 2022-06-12 14:50:03.797186
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger('logging_redirect_tqdm')

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(tqdm_class=tqdm) as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update()


# Generated at 2022-06-12 14:50:46.521374
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.tests import unittest
    from tqdm.auto import tqdm
    from tqdm.pytest_tqdm import log
    from tqdm.contrib.logging import tqdm_logging_redirect
    with log.call_log(tqdm) as clog:
        with tqdm_logging_redirect(iterable=range(10), total=10, loggers=[logging.getLogger()], tqdm_class=tqdm) as pbar:
            logging.warning("hello")
    assert clog

# Generated at 2022-06-12 14:50:48.664043
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    # Case: no logger set
    with logging_redirect_tqdm():
        pass



# Generated at 2022-06-12 14:50:58.610131
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from logging import StreamHandler
    except ImportError:
        return
    from . import trange, tqdm, logging_redirect_tqdm, tgrange
    log = logging.getLogger('test_logging_redirect_tqdm')
    logging.basicConfig(level=logging.INFO)

    with trange(5) as t:
        with logging_redirect_tqdm():
            for i in t:
                if i == 4:
                    log.info('console logging redirected to `tqdm.write()`')
        assert 'console logging redirected to `tqdm.write()`' in t.refresh()

    def check_handlers(handlers):
        for handler in handlers:
            assert not isinstance(handler, StreamHandler)

# Generated at 2022-06-12 14:51:05.620834
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import sys
    # setup logging
    logging.basicConfig(level=logging.INFO)
    # setup tqdm
    tqdm.tqdm = tqdm.std.tqdm
    tqdm.tqdm.write = tqdm.std.tqdm.write  # type: ignore

    # perform desired functionality
    with logging_redirect_tqdm(tqdm_class=tqdm.tqdm):
        for _ in tqdm.tqdm(range(9)):
            logging.info('test')
    logging.info('test')

    # restore stdout/stderr
    sys.stdout = sys

# Generated at 2022-06-12 14:51:12.308706
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in tqdm(range(5)):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:51:22.199632
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import Mock
    except ImportError:  # python < 3.3
        from mock import Mock
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    import logging

    # mocks
    mock_logging = Mock()

    # mock root logger
    mock_root_logger = Mock(logging.Logger)
    mock_root_logger.handlers = []

    # mocks root logger handlers
    mock_root_logger_handler = Mock(logging.Handler)
    mock_root_logger_handler.stream = sys.stdout
    mock_root_logger_handler.setFormatter = Mock()

    # mock logger
    mock_logger = Mock(logging.Logger)


# Generated at 2022-06-12 14:51:27.265388
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=10, leave=False):
            for i in range(10):
                if i == 0:
                    LOG.info("console logging redirected to `tqdm.write()`")
                LOG.info("unit test for logging redirect")
        # logging restored


# Generated at 2022-06-12 14:51:32.998064
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest
        import unittest.mock
    except ImportError:
        import mock
    import logging

    class TqdmTest(std_tqdm):
        """
        See tqdm.tests.test_tqdm.tqdm_deprecated_args.
        """
        def __init__(self, *args, **kwargs):
            self.write = kwargs.pop('write', None)
            super(TqdmTest, self).__init__(*args, **kwargs)

    def tqdm_write(msg, file=None):
        """
        tqdm.write wrapper for mocking
        """
        del file
        TqdmTest.write(msg)


# Generated at 2022-06-12 14:51:39.385671
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:51:46.625812
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def test_simple(tqdm_class=std_tqdm):  # noqa
        logger = logging.getLogger(__name__ + 'test_simple')
        logger.addHandler(logging.StreamHandler())
        logger.setLevel(logging.DEBUG)
        logger.debug('Some debug')
        with tqdm_class(total=10) as pbar:
            with logging_redirect_tqdm(loggers=[logger],
                                       tqdm_class=tqdm_class):
                pbar.update(5)
                logger.debug('Some debug')
                pbar.update(5)
                logger.debug('Some debug')
                pbar.close()
        logger.debug('Some debug')

    test_simple(std_tqdm)