

# Generated at 2022-06-12 14:42:46.847078
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    fd1, fd2 = sys.stdout, sys.stderr
    try:
        with patch('sys.stdout', fd2), patch('sys.stderr', fd1):
            logger = logging.getLogger()
            logger.setLevel(logging.INFO)
            with logging_redirect_tqdm():
                logger.info("message")
    finally:
        sys.stdout, sys.stderr = fd1, fd2
    assert len(logger.handlers) == 1
    assert _term_move_up() in fd2.getvalue()

# Generated at 2022-06-12 14:42:48.167903
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        for _ in range(9):
            pbar.update()



# Generated at 2022-06-12 14:42:53.387182
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:42:59.724474
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.tests import CommonTestCases
    from logging import root, getLogger

    log = getLogger(__name__)

    log.addHandler(logging.NullHandler())

    with CommonTestCases.get_no_stderr_io():
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
        root.setLevel(logging.DEBUG)
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
        with logging_redirect_tqdm():
            log.debug("debug")
            log.info("info")
            log.warning("warning")

# Generated at 2022-06-12 14:43:08.727887
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    assert not LOG.handlers
    with logging_redirect_tqdm():
        assert len(LOG.handlers) == 1
        assert isinstance(LOG.handlers[0], _TqdmLoggingHandler)
        LOG.info("hi")
    assert not LOG.handlers

    logging.basicConfig(level=logging.INFO)
    assert len(LOG.handlers) == 1
    with logging_redirect_tqdm():
        assert len(LOG.handlers) == 1
        assert isinstance(LOG.handlers[0], _TqdmLoggingHandler)
        LOG.info("hello")
    assert len(LOG.handlers) == 1


# Generated at 2022-06-12 14:43:15.287750
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig()
    logging.getLogger().setLevel(logging.INFO)

    import functools  # pylint: disable=import-outside-toplevel
    from tqdm import trange
    from tqdm.contrib import logging_redirect_tqdm
    tr = functools.partial(trange, bar_format='{l_bar}{bar}| ')

    with tr(1) as t:
        with logging_redirect_tqdm():
            for _ in tr(3):
                logging.info('hello')

    with tr(1) as t:
        with logging_redirect_tqdm():
            logging.info('world')


# Generated at 2022-06-12 14:43:23.998738
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Logging should work as normal
    for i in tqdm(range(9)):
        if i == 4:
            LOG.info("foo")

    # Logging should be redirected
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("foo")

    # Logging should be redirected to custom tqdm class

# Generated at 2022-06-12 14:43:27.050220
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        LOG.info('hello')

# Generated at 2022-06-12 14:43:34.602914
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import re
    import sys
    from tqdm import trange

    log_format = "%(asctime)s (%(filename)s:%(lineno)d) %(levelname)s - %(message)s"
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    log_stream = StringIO()
    logging.basicConfig(level=logging.INFO, format=log_format, stream=log_stream)

    def test():
        LOG = logging.getLogger(__name__)


# Generated at 2022-06-12 14:43:41.532447
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        with tqdm_logging_redirect("Testing tqdm_logging_redirect function",
                                   total=9, desc="Logs: ") as pbar:
            with logging_redirect_tqdm(tqdm_class=pbar.__class__):
                for i in pbar:
                    if i == 4:
                        logging.info("This was logged")
    except:
        raise Exception("Failed tqdm_logging_redirect function test")

# Generated at 2022-06-12 14:43:52.994181
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import warnings
    import logging

    LOG = logging.getLogger(__name__)

    for i in tqdm_logging_redirect(range(9), desc="Testing logging (1/2)",
                                   logger=LOG, leave=True, dynamic_ncols=True):
        if i == 4:
            LOG.info("console logging redirected to `tqdm.write()`")

    warnings.warn("This is a warning!")

    try:
        raise RuntimeError("Test runtime error!")
    except:
        LOG.exception("console logging redirected to `tqdm.write()`")

    try:
        raise RuntimeError("Test runtime error!")
    except:
        LOG.error("console logging redirected to `tqdm.write()`",
                  exc_info=True)


# Generated at 2022-06-12 14:44:02.817993
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .main import tqdm
    from .tests import pretest_posttest  # noqa: F401
    with tqdm_logging_redirect(total=4,  # type: ignore
                               desc="redirected",
                               write_to_stdout=False,
                               leave=False,
                               logger=logging.Logger("test_tqdm_logging_redirect")) as pbar_redir:
        pbar_redir.update(2)
        logging.getLogger("test_tqdm_logging_redirect").info("Hello", extra={'phase': 'update'})
        pbar_redir.update()
        pbar_redir.update()

# Generated at 2022-06-12 14:44:09.972785
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests_tqdm import with_setup  # for pytest.skip

    # pylint: disable=unused-variable
    @with_setup(pretest=lambda: None, posttest=lambda: None)
    def test_tqdm_logging_redirect():
        """
        Tests tqdm_logging_redirect.
        """
        import logging
        import os
        import shutil
        import tempfile
        from tqdm import trange
        from tqdm.contrib.logging import tqdm_logging_redirect
        LOG = logging.getLogger(__name__)

        fout, fout_name = tempfile.mkstemp()
        TEST_LOG_FILE = os.fdopen(fout, 'w')
        logger = logging.getLogger()
        logger

# Generated at 2022-06-12 14:44:17.100831
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log_capture_string = ""

    class tqdm_write_string(std_tqdm):

        def write(self, s, file=None, end="\n", nolock=False):
            # type: (str, Any, str, bool) -> None
            global log_capture_string  # pylint: disable=global-statement
            log_capture_string += s + end

    def test_logging_redirect_tqdm_func():
        LOG = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:44:21.375733
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter("%(message)s")
    console.setFormatter(formatter)
    LOG.addHandler(console)

    # logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in trange(10, desc='redirect_trange_1'):
            LOG.info("redirect_LOG_info_1")

# Generated at 2022-06-12 14:44:33.291830
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm_notebook
    import logging
    import io
    import unittest

    class Test_Tqdm_Logging_Redirect(unittest.TestCase):
        def setUp(self):
            self.out = io.StringIO()
            tqdm_handler = _TqdmLoggingHandler(tqdm_class=tqdm_notebook.tqdm)
            tqdm_handler.stream = self.out
            logging.root.handlers = [tqdm_handler]

        def test_logging_redirect(self):
            LOG = logging.getLogger(__name__)
            with tqdm_logging_redirect(tqdm_class=tqdm_notebook.tqdm):
                LOG.info('Test')

# Generated at 2022-06-12 14:44:41.772392
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import unittest
    import logging

    class TqdmLoggingHandlerTester(unittest.TestCase):
        def test_emit(self):
            with io.StringIO() as test_stream:
                logger = logging.getLogger(__name__)
                handler = logging.StreamHandler()
                tqdm_handler = _TqdmLoggingHandler()
                tqdm_handler.stream = test_stream
                logger.handlers = [handler, tqdm_handler]

                logger.info("test")
                self.assertEqual(test_stream.getvalue(), "test\n")
                self.assertIsNotNone(test_stream.getvalue())

    # Unit test for method is_console_logging_handler

# Generated at 2022-06-12 14:44:50.518805
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from .std import capture_output
    from .std import tqdm

    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.NullHandler())
    log.addHandler(logging.StreamHandler())

    with capture_output() as captured:
        with logging_redirect_tqdm(loggers=log):
            tqdm.write('foo')
    assert captured.stdout == 'foo\n'

    with capture_output() as captured:
        with logging_redirect_tqdm(loggers=log):
            log.debug('foo')
    assert captured.stdout == 'foo\n'



# Generated at 2022-06-12 14:44:59.829107
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(desc='tqdm logging redirect', ncols=80):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:45:04.815918
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in pbar:
            pbar.set_description("foobar")
            if i == 5:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:22.555291
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect.
    """
    import logging
    import time
    import unittest

    if sys.version_info >= (3, 3):
        from unittest.mock import patch
    else:
        from mock import patch

    class Test(unittest.TestCase):
        def test_tqdm_logging_redirect_not_in_progress(self):
            with patch('tqdm.tqdm.write', autospec=True) as patched_write:
                with tqdm_logging_redirect(total=10) as pbar:
                    logging.info('foo')
                patched_write.assert_not_called()
                pbar.update(1)


# Generated at 2022-06-12 14:45:33.915949
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange

    # create logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)
    logger.warning('before logging_redirect_tqdm')

    with logging_redirect_tqdm():
        for k in trange(100):
            logger.info('this is %s', k)


# Generated at 2022-06-12 14:45:43.754044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for `logging_redirect_tqdm()`.
    """
    try:
        import unittest  # noqa pylint: disable=unused-import
    except ImportError as e:  # pragma: no cover
        raise SkipTest(e)
    from unittest import TestCase  # noqa pylint: disable=unused-import
    from contextlib import contextmanager, redirect_stdout
    from io import BytesIO
    import logging
    import sys

    @contextmanager
    def redirect_stdout_as_string():
        # type: () -> Iterator[BytesIO]
        f = BytesIO()
        with redirect_stdout(f):
            yield f


# Generated at 2022-06-12 14:45:52.325036
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import tempfile
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Set up a temporary file for logging
    with tempfile.NamedTemporaryFile(mode='w+') as log_file:

        # Redirect stdout to this temporary file
        old_stdout = sys.stdout
        sys.stdout = log_file

        # Set up the logger
        handler = logging.StreamHandler(sys.stdout)
        LOG.addHandler(handler)
        LOG.setLevel(logging.DEBUG)

        # Run the logger and tqdm in the context manager

# Generated at 2022-06-12 14:45:55.195486
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()
    tlh.stream = sys.stderr
    record = logging.makeLogRecord({'msg': 'hey-hey'})
    tlh.emit(record=record)

# Generated at 2022-06-12 14:46:00.855152
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    from tqdm.auto import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:07.721119
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import StringIO
    capture = StringIO()
    red = '\033[31m'  # red (for test purposes only)

    # Default Stream
    tqdm_handler = _TqdmLoggingHandler()
    assert tqdm_handler.stream == sys.stderr
    tqdm_handler.stream = capture
    tqdm_handler.emit(logging.LogRecord(
        name='__main__',
        level=logging.ERROR,
        pathname='<string>',
        lineno=1,
        msg='whoops!',
        args=(),
        exc_info=None
    ))
    assert capture.getvalue() == 'whoops!\n'

    # Custom stream

# Generated at 2022-06-12 14:46:13.607547
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    buff = []
    fake_tqdm = type('fake_tqdm', (object,), {'write': lambda s: buff.append(s)})

    handler = _TqdmLoggingHandler(tqdm_class=fake_tqdm)
    record = logging.LogRecord('foo', logging.INFO, None, None, 'bar', None, None)
    handler.emit(record)

    assert buff == ['bar']

# Generated at 2022-06-12 14:46:17.332800
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(4):
            if i == 2:
                LOG.info('console logging redirected to tqdm.write()')
    # logging restored

# Generated at 2022-06-12 14:46:27.281696
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io

    # here we simulate stdout
    out = io.BytesIO()

    # set up a stream logger (for stdout)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    writer = logging.StreamHandler(out)
    writer.setLevel(logging.DEBUG)
    logger.addHandler(writer)

    # set up a _TqdmLoggingHandler
    handler = _TqdmLoggingHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # do a test log to make sure everything is working as expected
    logger.debug('test')

    # make sure the right string is written
    assert (out.getvalue().strip() == 'test')



# Generated at 2022-06-12 14:46:42.856570
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:46:51.260992
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test the method emit of class _TqdmLoggingHandler.

    Create a logger, set a handler of type _TqdmLoggingHandler to it,
    and write to the logger with info() and warning(). The output of
    tqdm.write() should be equal to the output of the handlers stream.
    """
    import unittest
    import io

    class TestTqdmLoggingHandler(unittest.TestCase):

        def test_emit(self):
            logger = logging.getLogger('test')
            stream = io.StringIO()
            logging_handler = _TqdmLoggingHandler()
            logging_handler.stream = stream
            logger.addHandler(logging_handler)

# Generated at 2022-06-12 14:46:57.687239
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function logging_redirect_tqdm.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    for _ in trange(3):
        with logging_redirect_tqdm():
            LOG.info('test')
        LOG.info('test')



# Generated at 2022-06-12 14:47:02.961087
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logging_redirect_tqdm() as _:
        for i in std_tqdm.trange(5, desc='test trange'):
            logger.info("logging redirected to tqdm.write()")
    logger.info("logging restored")

# Generated at 2022-06-12 14:47:12.881881
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from logging import getLogger, INFO, DEBUG
    from io import StringIO
    import tqdm

    log = getLogger('logger')
    log.setLevel(DEBUG)
    log.handlers = []

    # assert INFO is less than DEBUG
    assert INFO < DEBUG, "INFO is not less than DEBUG"

    # test INFO level logging
    output = StringIO()
    with tqdm_logging_redirect(total=10, logging_on=True, logger=log,
                               file=output, level=INFO):
        log.info("tqdm is awesome")
        log.debug("tqdm is awesome")
        assert "INFO:logger:tqdm is awesome" in output.getvalue(), "INFO not logging"
        assert "DEBUG:logger:tqdm is awesome" not in output.getvalue

# Generated at 2022-06-12 14:47:19.341673
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm._tqdm_test import tqdm_get_instances

    trange_instance = tqdm_logging_redirect(
        trange(10), logger_names=['root'], miniters=0)
    LOG = logging.getLogger('root')
    LOG.info('TEST')
    pbars = tqdm_get_instances()
    assert len(pbars) == 1
    assert 'TEST' in pbars[0].stdout



# Generated at 2022-06-12 14:47:25.202939
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm

    with tqdm_logging_redirect(tqdm_class=tqdm.tqdm, mininterval=0) as pbar:
        pbar.update(1)
        with tqdm_logging_redirect(loggers=[logging.getLogger('tqdm')],
                                   tqdm_class=tqdm.trange, total=5) as pbar2:
            pbar2.update(1)
        # pbar2 is closed, pbar should be unaffected by it
        pbar.update(1)

# Generated at 2022-06-12 14:47:31.165652
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from tqdm.std import tqdm

    class FakeTqdm(object):
        def __init__(self):
            self.written = []  # type: List[str]
        def write(self, msg):
            self.written.append(msg)

    # Redirect everything to a FakeTqdm instance
    tqdm_class = FakeTqdm
    with tqdm_logging_redirect(tqdm_class=tqdm_class) as pbar:
        assert pbar.written == []
        logging.warning("123")
        assert pbar.written == ['WARNING:root:123\n']

    # Redirect only the "a" logger
    tqdm_class = FakeTqdm
    a = logging.getLogger("a")

# Generated at 2022-06-12 14:47:33.554114
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    import sys

    stderr = io.StringIO()
    sys.stderr = stderr

    with logging_redirect_tqdm():
        logging.error("test")
    assert "test" in stderr.getvalue()

# Generated at 2022-06-12 14:47:42.821581
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from .main import tqdm

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(
            tqdm_class=tqdm,
            desc="testing tqdm_logging_redirect",
            file=sys.stdout,
            miniters=1,
            mininterval=0.1,
            loggers=[LOG],
            leave=True
    ) as pbar:
        for i in pbar:
            pbar.set_description('tqdm_logging_redirect')
            LOG.info("console logging redirected to `tqdm.write()`")
            if i == 3:
                break

# Generated at 2022-06-12 14:48:09.598600
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import setup_python_imports
    from .utils import _range

    with setup_python_imports():
        import logging

        log_counter = 0

        for i in _range(10):
            LOGGER = logging.getLogger('tqdm.contrib.test_logging_redirect_tqdm')
            LOGGER.info('{0}'.format(i))

        class CustomTqdm(std_tqdm):
            def write(self, *args, **kwargs):
                global log_counter
                log_counter += 1
                super(CustomTqdm, self).write(*args, **kwargs)


# Generated at 2022-06-12 14:48:19.392871
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import contextmanager
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    def test_flag_set(flag):
        return test_flags.get(flag)

    loggers = [logging.getLogger()]
    test_flags = {'logging_redirect_tqdm': False, 'tqdm_logging_redirect': False}

    def test_iter(loggers):
        with logging_redirect_tqdm(loggers=loggers):
            test_flags['logging_redirect_tqdm'] = True
            for _ in range(10):
                yield _


# Generated at 2022-06-12 14:48:28.578044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    tqdm_class = std_tqdm
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
        for logger in loggers:
            tqdm_handler = _TqdmLoggingHandler(tqdm_class)
            orig_handler = _get_first_found_console_logging_handler(logger.handlers)
            if orig_handler is not None:
                tqdm_handler.setFormatter(orig_handler.formatter)
                tqdm_handler.stream = orig_handler.stream

# Generated at 2022-06-12 14:48:34.012031
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm.auto
    from tqdm.tests.tests_tqdm import _range

    # Test infinite bars
    with tqdm_logging_redirect(_range(4)) as pbar:
        for i in _range(4):
            logging.info(i)
            pbar.update()

    # Test bars with total
    with tqdm_logging_redirect(_range(4), total=4) as pbar:
        for i in _range(4):
            logging.info(i)
            pbar.update()

# Generated at 2022-06-12 14:48:39.735491
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm._tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        LOG.info("back on track")

# Generated at 2022-06-12 14:48:48.738836
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import getLogger, StreamHandler, DEBUG
    from tqdm._utils import _term_move_up

    logger = getLogger(__name__)
    logger.setLevel(DEBUG)
    test_logging_redirect_tqdm._original_handlers = logger.handlers
    logger.handlers = [StreamHandler(sys.stdout)]

    logger.info("not covered")

    with logging_redirect_tqdm(loggers=[logger]):
        logger.info("is covered")

    logger.handlers = test_logging_redirect_tqdm._original_handlers
    logger.info("not covered")
    _term_move_up()  # Remove "is covered" from output
    logger.removeHandler(logger.handlers[0])

# Generated at 2022-06-12 14:48:52.941350
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    # create a tqdm instance and redirect logging to it
    with tqdm_logging_redirect(total=100) as pbar:
        # add progress to progress bar
        pbar.update(1)
        # create a logger instance and log something to the console
        LOG = logging.getLogger(__name__)
        LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:01.972383
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest.mock as mock  # 3.3+
    except ImportError:
        import mock  # 2.7 to 3.2
    import logging

    LOG = logging.getLogger(__name__)

    with mock.patch('tqdm.std.tqdm', __name__ + '.mocked_tqdm'):
        with logging_redirect_tqdm():
            assert logging.root.handlers[-1].stream is sys.stdout
            for i in range(3):
                if i == 1:
                    LOG.info('console logging redirected to `tqdm.write()`')
            assert logging.root.handlers[-1].stream is sys.stdout


# Mocked equivalent of tqdm.std.tqdm()

# Generated at 2022-06-12 14:49:12.877968
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import main

    class DummyLoggingHandler(logging.Handler):
        def emit(self, record):
            pass

    def _test(count):
        with tqdm_logging_redirect(count, loggers=[main.logger],
                                   smoothing=0,
                                   bar_format='{name}: {n} / {total} |{bar}|') as pbar:
            main.init_tqdm(pbar)
            main.main(count)

    # assert that tqdm is properly patched
    main.logger.setLevel(logging.DEBUG)
    orig_handlers = main.logger.handlers
    main.logger.handlers = [DummyLoggingHandler()]
    _test(1000)
    # assert that other handlers are not affected
    main.logger

# Generated at 2022-06-12 14:49:21.921342
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm

    log = logging.getLogger('test_logging')
    # log.setLevel(logging.DEBUG)

    def logtest(loggers, tqdm_class):
        with tqdm_logging_redirect(
            loggers=loggers, tqdm_class=tqdm_class
        ) as pbar:
            for i in range(5):
                log.info(('info' * 100)[:100])
                pbar.update()
                log.debug(('debug' * 100)[:100])
                log.error(('error' * 100)[:100])
                pbar.update()

    logtest([], tqdm)
    logtest(logging.getLogger('test_logging'), tqdm)

# Generated at 2022-06-12 14:49:47.226334
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest  # pylint: disable=import-outside-toplevel
    except ImportError:
        return
    import logging

    class TestLoggingRedirectTqdm(unittest.TestCase):
        def test_logging_redirect_tqdm(self):
            log = logging.getLogger(__name__)
            with logging_redirect_tqdm():
                self.assertFalse(log.handlers)
                log.error("Shouldn't be printed")
                log.info("Should be printed")
            self.assertTrue(log.handlers)
    unittest.main(exit=False)



# Generated at 2022-06-12 14:49:54.346678
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger()
    LOG.setLevel(logging.DEBUG)
    LOG.propagate = False

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    console.setFormatter(formatter)
    LOG.addHandler(console)

    # without tqdm
    with logging_redirect_tqdm():
        LOG.debug("this should be invisible")
        with std_tqdm() as pbar:
            LOG.debug("this should be visible")
        LOG.debug("this should be invisible")

    # with tqdm
    with tqdm_logging_redirect():
        LOG.debug("this should be invisible")

# Generated at 2022-06-12 14:49:59.710964
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    logging.shutdown()

# Generated at 2022-06-12 14:50:07.440334
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)
    LOG.handlers = []

    def assert_default_logging_redirect_tqdm():
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    def assert_customised_logging_redirect_tqdm():
        tqdm_class = trange
        logging.basicConfig(level=logging.INFO)
        loggers = [logging.getLogger(__name__)]

# Generated at 2022-06-12 14:50:14.212220
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib import testing_xrange_yield_async_gen
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    LOG.debug('debug message')
    LOG.info('info message')
    LOG.warning('warning message')
    LOG.error('error message')
    LOG.critical('critical message')

    with logging_redirect_tqdm():
        for i in testing_xrange_yield_async_gen(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:17.875091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:50:23.818204
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # the following two lines will be removed by the removal of
    # the function tqdm_logging_redirect
    try:
        from tqdm import tqdm
    except ImportError:
        tqdm = std_tqdm

    with tqdm_logging_redirect(*[1], **{'desc': 'foo'}) as pbar:
        pbar.update()

    with tqdm_logging_redirect(*[1], **{'desc': 'foo', 'loggers': []}) as pbar:
        pbar.update()

    with tqdm_logging_redirect(*[1], **{'desc': 'foo', 'tqdm_class': tqdm}) as pbar:
        pbar.update()


# Generated at 2022-06-12 14:50:31.167340
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests import TestCase

    with TestCase.base_tqdm(tqdm_class=std_tqdm) as tq_tqdm:
        with logging_redirect_tqdm():
            tq_tqdm([0])

    with TestCase.base_tqdm(tqdm_class=std_tqdm) as tq_tqdm:
        with logging_redirect_tqdm(tqdm_class=std_tqdm):
            tq_tqdm([0])


# Generated at 2022-06-12 14:50:39.928905
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect(desc="test", ncols=100):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:45.324871
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tqdm
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect(
            total=10,
            mininterval=0.25,
            desc='tqdm logging redirect',
            logger=logging.getLogger()) as pbar:
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.update(7)
    logging.info('logging restored')

# Generated at 2022-06-12 14:51:29.834105
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import sys

    logger = logging.getLogger(__name__)

    # Mock stdout to check the output
    mock_stdout = []
    with open(os.devnull, 'w') as null:
        sys.stdout = mock_stdout
        with tqdm_logging_redirect(
                loggers=[logger], tqdm_class=std_tqdm
        ) as pbar:
            for _ in pbar:
                logger.info("Redirected message")

    print(mock_stdout[0])
    assert mock_stdout[0] == 'Redirected message\n'

# Generated at 2022-06-12 14:51:39.216374
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.concurrent import thread_map
    from .test_tqdm import closing, pretest

    pretest()

    with closing(tqdm_logging_redirect(total=10, mininterval=0,
                                       ascii=None, disable=None)) as pbar:
        assert isinstance(pbar, tqdm)
        thread_map(lambda _: logging.warning("test"), range(10))

# Generated at 2022-06-12 14:51:44.609590
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:51:48.299724
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())
    with logger.log_level(logging.INFO):
        logger.info("INFO")
        logger.warning("WARNING")

        with _TqdmLoggingHandler() as handler:
            logger.addHandler(handler)
            logger.info("INFO")
            raise RuntimeError("cannot be logged")
        logger.removeHandler(handler)

        logger.info("INFO")
        logger.warning("WARNING")

# Generated at 2022-06-12 14:51:51.614905
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Function to unit test function `logging_redirect_tqdm()`
    """
    import logging
    from tqdm import stdtqdm
    from .logging_redirect_tqdm import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    with logging_redirect_tqdm():
        for i in stdtqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-12 14:51:56.601175
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    msg = "console logging redirected to `tqdm.write()`"

    # redirect to stdout
    with logging_redirect_tqdm():
        logging.info(msg)

    # redirect to stderr
    with logging_redirect_tqdm(tqdm_class=std_tqdm.tqdm_notebook,
                               loggers=[logging.getLogger('__main__')]):
        logging.getLogger('__main__').info(msg)


# Generated at 2022-06-12 14:51:59.343100
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import Mock  # python 3.3+
    except ImportError:
        from mock import Mock  # python2.6-2.7

    logger = Mock()
    logger.handlers = [Mock()]
    with logging_redirect_tqdm(loggers=[logger]):
        pass

# Generated at 2022-06-12 14:52:04.182255
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=undefined-variable,redefined-outer-name
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:52:06.748229
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with tqdm_logging_redirect():
        logging.info('test')

# Generated at 2022-06-12 14:52:09.858903
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(loggers=[LOG]):
        LOG.info('testing')