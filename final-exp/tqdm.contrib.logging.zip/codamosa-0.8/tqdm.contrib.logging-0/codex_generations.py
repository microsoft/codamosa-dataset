

# Generated at 2022-06-12 14:42:50.110951
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import io
    import sys
    import unittest
    from contextlib import contextmanager

    @contextmanager
    def mock_stdout():
        """
        Returns a context manager containing a mock stdout to be tested.

        """
        stdout = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout
        yield stdout
        stdout.close()
        sys.stdout = old_stdout

    class TestTqdmLoggingHandler(unittest.TestCase):
        """
        Unit test function for class _TqdmLoggingHandler.

        """
        def test_emit(self):
            """
            Tests method emit.

            """

# Generated at 2022-06-12 14:42:54.827378
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:42:59.163446
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        msg = ["test message {0}".format(i) for i in range(100)]
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        logger.addHandler(_TqdmLoggingHandler())
        for i in range(100):
            logger.info(msg[i])
    except (KeyboardInterrupt, SystemExit):
        raise
    except:  # noqa pylint: disable=bare-except
        assert False, "The generated message does not match the original"

# Generated at 2022-06-12 14:43:02.090910
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from .tests.contrib import test_tqdm_logging_redirect
        test_tqdm_logging_redirect.test_tqdm_logging_redirect()
    except ImportError:
        pass

# Generated at 2022-06-12 14:43:05.668069
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        with tqdm_logging_redirect(disable=False, unit="test_emit"):
            logging.info("test_emit")
            assert 1 == 2
    except:  # noqa pylint: disable=bare-except
        pass



# Generated at 2022-06-12 14:43:09.438906
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    # test scenario
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:43:15.743729
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import logging.handlers
    from io import StringIO
    from tqdm._utils import _term_move_up
    from tqdm.contrib._test_tqdm import _IO

    if std_tqdm is None:
        raise ImportError('std_tqdm is None')

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log_msgs = [
        "First logging",
        "Redirect to tqdm.write()",
        "And again",
    ]
    log_msgs_len = [len(msg) for msg in log_msgs]
    log_total = sum(log_msgs_len)

    # console logger
    console = logging.StreamHandler()

# Generated at 2022-06-12 14:43:20.895887
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from tqdm._utils import _term_move_up
    from tqdm.tests import _is_in_ci
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    # Generate a message to be printed
    msg = 'console logging redirected to `tqdm.write()`'

    # If a terminal is detected
    if not _is_in_ci():
        # Get the current cursor position
        with _term_move_up():
            pass
        cursor_position = _term_move_up()()
    else:
        cursor_position = 0

    # Run the function
    with tqdm_logging_redirect():
        LOG.info(msg)
    # Check that the message is being printed
    assert msg

# Generated at 2022-06-12 14:43:29.565851
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Tests the logging_redirect_tqdm function.
    """
    import logging
    import os
    import tempfile

    fs = False  # flag for failure at `assert`
    log_path = os.path.join(tempfile.mkdtemp(),
                            'test_logging_redirect_tqdm_log.txt')
    logger = logging.getLogger('MyLogger')
    str_handler = logging.StreamHandler()
    str_handler.setFormatter(logging.Formatter('%(asctime)s :: %(levelname)s :: %(message)s'))
    file_handler = logging.FileHandler(log_path)

# Generated at 2022-06-12 14:43:33.685925
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(total=9) as pbar:
        for i in trange(9):
            if i == 4:
                LOG = logging.getLogger()
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:42.733966
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        from ..tests.test_logging import _test_logging_redirect_tqdm  # type: ignore[import]
    except ImportError:  # pragma: no cover
        return
    _test_logging_redirect_tqdm(logger_name=__name__)

# Generated at 2022-06-12 14:43:50.700757
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Tests function logging_redirect_tqdm
    """
    try:
        from tqdm.std import tqdm, trange
    except ImportError:
        from tqdm import tqdm, trange
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")
                assert isinstance(_get_first_found_console_logging_handler(LOG.handlers),
                                  _TqdmLoggingHandler)
    # logging restored

# Generated at 2022-06-12 14:43:53.150296
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm.contrib import test_logging
    test_logging.test_logging_redirect_tqdm(logging_redirect_tqdm, std_tqdm)

# Generated at 2022-06-12 14:44:01.489560
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function logging_redirect_tqdm().
    """
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in tqdm(range(9)):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    with tqdm_logging_redirect(loggers=[LOG]):
        for _ in range(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:44:06.923308
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:44:11.283527
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import TestHandler, test_cli

    with TestHandler(delay=1) as h:
        with logging_redirect_tqdm():
            lcl = logging.getLogger("logging_redirect_tqdm")
            lcl.info("output")
    assert h.msg == "output\n"



# Generated at 2022-06-12 14:44:13.944579
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger('test_logging_redirect_tqdm')
    logger.info("original message")
    with logging_redirect_tqdm():
        logger.info("redirected message")



# Generated at 2022-06-12 14:44:20.209229
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from six.moves import StringIO
    from .testing import discretize_range

    # Redirect stdout for testing
    orig_stdout = sys.stdout
    output = StringIO()
    sys.stdout = output

    # Test logging_redirect_tqdm()
    for i in discretize_range(9):
        logging.info('message {}'.format(i))
    assert output.getvalue().split('\n')[-2] == 'message 8'
    output.truncate(0)

    with logging_redirect_tqdm():
        for i in discretize_range(9):
            logging.info('message {}'.format(i))
    assert output.getvalue().strip() == ''
    output.truncate(0)


# Generated at 2022-06-12 14:44:25.192123
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    def test_callback():
        with logging_redirect_tqdm():
            for i in range(10):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
            LOG.info("logging restored")

    # Expected output
    with open("LOGGER_TEST_EXPECTS.txt", "rb") as logger_expect_fd:
        logger_expect = logger_expect_fd.read()
    logger_expect = logger_expect.decode("utf-8")

    # Actual output
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    stream_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler

# Generated at 2022-06-12 14:44:30.128493
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    with tqdm_logging_redirect() as pbar:
        pbar.set_description('Testing logging redirect:')
        for i in range(10):
            pbar.update(1)
            logging.info(i)

# Generated at 2022-06-12 14:44:44.717981
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """Test the tqdm-logging redirect."""
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:44:51.496975
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import trange

    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    LOG.handlers = []

    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')

    # logging restored, so we should get stdout output again
    LOG.info('stdout output restored, only terminal output is visible')



# Generated at 2022-06-12 14:44:57.931788
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import pretest_posttest
    import logging
    import os
    import tempfile
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    # Test `logging_redirect_tqdm`
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "output.txt"), 'w') as tmp:
            with logging_redirect_tqdm([LOG]) as pbar:
                for i in trange(9, file=tmp):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

            # Test that logging is still being caught and written to temp file
            for i in trange(2, file=tmp):
                LOG.info('.')

# Generated at 2022-06-12 14:45:04.264422
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9), desc='abc'):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert logging.root.handlers[0].level == logging.INFO
    assert input('Did the string "console logging redirected to `tqdm.write()` appear (y/n)?') == 'y'

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:45:16.465056
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for `logging_redirect_tqdm`"""
    import logging
    from tqdm import trange
    orig_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        LOG = logging.getLogger()

        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        output = sys.stdout.getvalue().strip().splitlines()
        assert output[9] == 'INFO:root:console logging redirected to `tqdm.write()`'
    finally:
        sys.stdout = orig_stdout



# Generated at 2022-06-12 14:45:21.755955
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def test_func(tqdm_class=std_tqdm):
        with tqdm_class() as pbar:
            pbar.update(2)
            with logging_redirect_tqdm(tqdm_class=tqdm_class):
                logging.info('test')
            pbar.update(2)

    try:
        # Save stdout handler
        from io import StringIO
        from contextlib import contextmanager
        from sys import stdout
    except ImportError:
        # Python 2 fallback
        from StringIO import StringIO
        from contextlib2 import contextmanager
        from sys import stdout

    @contextmanager
    def stdout_redirector(new_target):
        old_target, sys.stdout = sys.stdout, new_target

# Generated at 2022-06-12 14:45:27.602499
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)

    with logging_redirect_tqdm() as r:
        logging.info('hello')
        r.write('hey')

    with logging_redirect_tqdm():
        logging.info('hello')
        std_tqdm.write('hey')



# Generated at 2022-06-12 14:45:36.966312
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        # Unit testing
        import unittest
        from io import StringIO
    except ImportError:
        return

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.saved_stdout = sys.stdout
            self.saved_handlers = logging.root.handlers

        def tearDown(self):
            sys.stdout = self.saved_stdout
            logging.root.handlers = self.saved_handlers

        def test_logging_redirect_tqdm(self):
            # Redirect stdout to StringIO
            output = StringIO()
            sys.stdout = output

            import logging.config
            import os


# Generated at 2022-06-12 14:45:46.871522
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler(std_tqdm)
    try:
        """
        Test that function emit of class _TqdmLoggingHandler
        write to tqdm.write stream
        """
        with std_tqdm.patch_std_streams() as streams:
            streams[0].write = lambda *args, **kwargs: None
            streams[1].write = lambda *args, **kwargs: None
            handler.emit(None)
            assert streams[0].write.called
    except AttributeError:
        """
        Test that function emit of class _TqdmLoggingHandler
        call tqdm.write file attribute
        """

# Generated at 2022-06-12 14:45:52.924929
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger()

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:46:20.657747
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.utils import _term_move_up

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm() as pbar:
        logging.info("1")
        logging.info("2")
        try:
            raise Exception("3")
        except Exception:
            logging.exception("3")
        logging.info("4")
    assert pbar.n > 4  # ensure progressbar progress
    assert _term_move_up() in pbar.format_dict['desc']  # ensure progress bar ended
    assert logging.root.handlers[-1] is not pbar.log_handler  # ensure handler restored

# Generated at 2022-06-12 14:46:27.133903
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    # Set verbosity level to WARNING
    logging.basicConfig(level=logging.WARNING)
    # Set logger verbosity to WARNING
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.WARNING)
    # Write message
    with tqdm_logging_redirect(format='%(message)s'):
        logger.warning('This message is being displayed!')
        logger.info('This message is NOT being displayed!')

# Generated at 2022-06-12 14:46:34.012024
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for method emit of class _TqdmLoggingHandler
    """
    with tqdm_logging_redirect(
        "Test_TqdmLoggingHandler_emit",
        file=sys.stderr,
        dynamic_ncols=True,
        desc="testing emit",
        total=2
    ) as pbar:
        h = _TqdmLoggingHandler(pbar.__class__)
        h.emit(logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="foo",
            args=(),
            exc_info=None
        ))
        assert pbar.n == 1

# Generated at 2022-06-12 14:46:44.505233
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            loggers=[LOG],
            tqdm_class=std_tqdm,
            total=9) as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.update(1)


# Backward compatibility
kwargs_deprecated = [
    ('tqdm_class', 'tqdm_class', std_tqdm),
    ('loggers', 'loggers', None),
]

for old, new, default in kwargs_deprecated:
    globals()[old] = globals()[new]

# Generated at 2022-06-12 14:46:50.433246
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .test_tqdm import StringIO

    out = StringIO()
    logger = logging.getLogger(__name__)

    # Ensure we have at least one handler
    logger.addHandler(logging.NullHandler())
    # Ensure we have the correct class type
    logger.handlers = [_TqdmLoggingHandler()]

    logger.warning("Test")
    logger.warning("Test")
    logger.warning("Test")
    logger.warning("Test")

    # Ensure no errors where thrown
    out.close()

# Generated at 2022-06-12 14:46:58.274267
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:02.605453
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=3):
            LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:08.721443
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(total=3, desc='Test') as pbar:
        for i in range(3):
            pbar.update(1)
            if i == 1:
                LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:47:16.226435
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    try:
        from importlib import reload
    except ImportError:
        from imp import reload
    try:
        from six.moves import cStringIO as StringIO  # type: ignore
    except ImportError:
        from io import StringIO

    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def _test_method(loggers):
        reload(logging)
        with StringIO() as buf, logging_redirect_tqdm(loggers=loggers):
            for i in trange(9):
                LOG.info("i = %s", i)

# Generated at 2022-06-12 14:47:21.999177
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    import logging
    import os

    orig_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')

    try:
        with tqdm_logging_redirect(tqdm_class=tqdm, total=10) as pbar:
            logging.info('test')
            assert isinstance(pbar, tqdm)
    finally:
        sys.stderr.close()
        sys.stderr = orig_stderr



# Generated at 2022-06-12 14:48:09.191837
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, _TqdmLoggingHandler
    logger = logging.getLogger('test_logging_redirect_tqdm')
    with logging_redirect_tqdm(loggers=[logger]):
        for i in trange(9):
            if i == 4:
                logger.info('console logging redirected to `tqdm.write()`')
    captured_log = logger.handlers[0].stream.getvalue()
    assert 'console logging redirected to `tqdm.write()`' in captured_log

# Generated at 2022-06-12 14:48:15.175557
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import tempfile
    import logging
    logging.root.setLevel(logging.NOTSET)

# Generated at 2022-06-12 14:48:19.489093
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    >>> logging.basicConfig(level=logging.INFO)
    >>> log = logging.getLogger(__name__)
    >>> with logging_redirect_tqdm():
    ...     log.info('test')
    test
    """



# Generated at 2022-06-12 14:48:28.578025
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from .tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    # NullHandler for python2 compatibility
    logging.getLogger(__name__).addHandler(logging.NullHandler())
    with tqdm_logging_redirect(total=10,
                               desc='Logging test',
                               logger=logging.getLogger(__name__)) as pbar:
        LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
        for i in range(11):
            pbar.update()
            if i == 5:
                LOG.info("console logging redirected to 'tqdm.write()'")
    logging.shutdown()

# Unit

# Generated at 2022-06-12 14:48:34.763036
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger("1"),
               logging.getLogger("2")]
    with tqdm_logging_redirect(loggers=loggers):
        assert len(loggers[0].handlers) == 1
        assert len(loggers[1].handlers) == 1
        assert isinstance(loggers[0].handlers[0], _TqdmLoggingHandler)
        assert isinstance(loggers[1].handlers[0], _TqdmLoggingHandler)
    assert len(loggers[0].handlers) == 0
    assert len(loggers[1].handlers) == 0

# Generated at 2022-06-12 14:48:39.225987
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Start test
    try:
        # Set up console logging handler
        logging.basicConfig(level=logging.INFO)

        # Redirect to tqdm.write
        with logging_redirect_tqdm():
            # Issue log message
            logging.info("Hello World")
    finally:
        # Cleanup
        logging.shutdown()


# Generated at 2022-06-12 14:48:48.321636
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange, tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    for log_class in [logging.Logger, tqdm.tqdm]:
        with log_class(name='0', level=logging.INFO) as log0, log_class(
                name='1', level=logging.INFO) as log1:
            for i in trange(3):
                log0.info(i)
                log1.info(i)
            with logging_redirect_tqdm(loggers=[log0, log1]):
                for i in trange(3):
                    log0.info(i)
                    log1.info(i)
            for i in trange(3):
                log0.info(i)

# Generated at 2022-06-12 14:48:53.878094
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.test_utils import discard_stderr

    LOG = logging.getLogger('TEST LOGGER')
    LOG.setLevel(logging.INFO)
    log_string = 'console logging redirected to `tqdm.write()`'
    with discard_stderr(True) as f:
        with logging_redirect_tqdm():
            # logging redirected to tqdm.write()
            LOG.info(log_string)
    assert log_string in f.getvalue()



# Generated at 2022-06-12 14:48:56.724573
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger('dummy')
    log.addHandler(_TqdmLoggingHandler())
    log.info('Hello.')

# Generated at 2022-06-12 14:49:04.144324
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    # simple case
    with tqdm_logging_redirect(total=3) as pbar:
        for _ in pbar:
            pass
    # with loggers
    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(
            total=3, loggers=[log], tqdm_class=std_tqdm) as pbar:
        for _ in pbar:
            log.warning('testing...')
    # with prefix

# Generated at 2022-06-12 14:49:49.298891
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=redefined-outer-name
    import io
    import logging
    from tqdm.contrib.logging import _TqdmLoggingHandler

    class TestTqdm(object):
        def __init__(self):
            self.out = io.StringIO()

        def write(self, s, end=''):
            self.out.write(s + end)

        def flush(self):
            pass

    testlogger = logging.getLogger(__name__)
    testlogger.setLevel(logging.INFO)
    tqdm_handler = _TqdmLoggingHandler(TestTqdm)
    testlogger.handlers = [tqdm_handler]
    testlogger.info('Test')

# Generated at 2022-06-12 14:49:54.836399
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    logger = logging.getLogger()
    orig_stream = logger.handlers[0].stream
    logger.handlers[0].stream = StringIO()

# Generated at 2022-06-12 14:50:03.830932
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.utils import _term_move_up

    LOG = logging.getLogger(__name__)

    out = StringIO()

    with tqdm_logging_redirect(
            file=out,
            loggers=[logging.root],
            tqdm_class=std_tqdm,
            ascii=True,
            miniters=1,
            mininterval=0
    ):
        for i in trange(9, file=out):
            if i == 4:
                LOG.info('console logging redirected to tqdm.write()')

# Generated at 2022-06-12 14:50:08.511232
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    logger = LOG
    LOG.info("1")
    LOG.info("2")

    with logging_redirect_tqdm():
        for i in trange(4):
            if i == 2:
                LOG.info("console logging redirected to `tqdm.write()`")
    LOG.info("3")


# Generated at 2022-06-12 14:50:17.285898
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm_test_cases import TestCase, pretest_posttest  # noqa
    class Test_tqdm_logging_redirect(TestCase):
        def test_tqdm_logging_redirect(self):
            for tqdm_cls in [std_tqdm]:
                with self.subTest(tqdm_class=tqdm_cls):
                    with tqdm_logging_redirect(
                        desc='test',
                        total=3,
                        tqdm_class=tqdm_cls,
                    ) as pbar:
                        self.assertTrue(pbar._daemonic)
                        pbar.update(1)
                        pbar.update(1)
                        with self.assertRaises(Exception):
                            raise Exception
                        pbar.update(1)

# Generated at 2022-06-12 14:50:21.324761
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """
    import logging
    logging.basicConfig(level=logging.INFO)
    loggers = [logging.root]
    tqdm_class = tqdm
    with tqdm_logging_redirect(total=3, loggers=loggers, tqdm_class=tqdm_class):
        logging.info('this is an info message')
        logging.warning('this is a warning message')
        logging.error('this is an error message')

# Generated at 2022-06-12 14:50:25.070486
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:31.710840
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tests import TestCase

    tqdm_class = TestCase.get_tqdm()  # type: Type[std_tqdm]

    with TestCase.captured_stdout() as so:
        with TestCase.captured_stderr() as se:
            with tqdm_logging_redirect(total=3, file=so):
                logging.info("test 0")
                logging.info("test 0")
        TestCase.assertTrue(so.getvalue() == "")
        TestCase.assertTrue(se.getvalue() == "")

        tqdm_kwargs = {
            'total': 3,
            'file': so,
        }
        with tqdm_logging_redirect(**tqdm_kwargs) as pbar:
            logging.info("test 1")

# Generated at 2022-06-12 14:50:40.391674
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    msgs = ["This is a log message.", "This is another message."]

    with StringIO() as buf:  # If using python >=3.3, use `io.StringIO`
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        logger.addHandler(logging.StreamHandler(buf))

        with tqdm_logging_redirect():
            for msg in msgs:
                logger.info(msg)

        buf.seek(0)
        out = buf.read()
        for msg in msgs:
            assert msg in out

        # Test that logging is restored

# Generated at 2022-06-12 14:50:48.143067
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    class MyHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(MyHandler, self).__init__(*args, **kwargs)
            self.messages = []

        def emit(self, record):
            self.messages.append(record.getMessage())

    class MyLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super(MyLogger, self).__init__(*args, **kwargs)
            self.setLevel(logging.INFO)
            self.handler = MyHandler()  # type: ignore
            self.addHandler(self.handler)


# Generated at 2022-06-12 14:51:38.428535
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Test that logging_redirect_tqdm context manager works"""
    import logging  # noqa
    from tqdm import trange

    # Disable INFO logging to not overcomplicate tests
    logging.getLogger('tqdm').setLevel(logging.ERROR)

    # Check that logging redirect works
    with logging_redirect_tqdm():
        with trange(2, desc='outer') as t:
            # The next lines should appear in the progress bar
            logging.info('test')
            logging.debug('test')
            for _ in t:
                with trange(2, desc='inner') as t:
                    for _ in t:
                        logging.info('test')
                        logging.debug('test')



# Generated at 2022-06-12 14:51:46.145293
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from .utils import TestHandler

    def _test_log(output):
        # type: (io.StringIO) -> None
        LOG = logging.getLogger(__name__)
        log_handler = TestHandler()
        LOG.addHandler(log_handler)

        with logging_redirect_tqdm():
            LOG.info("test")

        tqdm_out = output.getvalue()
        logging_out = log_handler.output
        assert tqdm_out == logging_out

    output = io.StringIO()
    with std_tqdm(file=output, disable=True) as pbar:
        _test_log(pbar.file)



# Generated at 2022-06-12 14:51:54.750573
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
    except ImportError:
        return None
    import logging

    with tqdm_logging_redirect(
            total=10, file=sys.stdout, loggers=None, leave=True,
            tqdm_class=tqdm) as pbar:
        for i in range(3):
            pbar.update(i)
            logging.warn("hello")
            pbar.refresh()

    with tqdm_logging_redirect(
            total=10, file=sys.stdout, loggers=None, leave=False,
            tqdm_class=tqdm) as pbar:
        for i in range(3):
            pbar.update(i)
            logging.warn("hello")
            pbar.refresh()

   

# Generated at 2022-06-12 14:51:58.177692
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from ..std import tqdm as std_tqdm

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:52:08.323117
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import escape_ansi
    from .std import tqdm as std_tqdm_noval_test

    log_string = 'test log string'

    # Test parameter 'loggers'
    with logging_redirect_tqdm():
        logging.info(log_string)

    try:  # Python 3.4
        assert escape_ansi(std_tqdm_noval_test.get_write_set().pop()) == (
            'INFO:root:' + log_string)
    except AttributeError:  # Python 2.7, 3.0-3.3
        assert escape_ansi(std_tqdm_noval_test._instances.pop()) == (
            'INFO:root:' + log_string)


# Generated at 2022-06-12 14:52:12.508309
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import tqdm
    with logging_redirect_tqdm() as get_log_handler:
        logging.error("Message")
        log_handler = get_log_handler()
        log_handler.tqdm_class.write(log_handler.tqdm_class.default_write_params[0])

# Generated at 2022-06-12 14:52:18.237745
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import io
    with io.StringIO() as stream:
        with logging_redirect_tqdm(loggers=[logging.getLogger('test')],
                                   tqdm_class=std_tqdm) as pbar:
            pbar.set_description("Test for function tqdm_logging_redirect")
            logging.getLogger('test').info("console logging redirected to 'tqdm.write()'")
        result = stream.getvalue()
    assert "console logging redirected to 'tqdm.write()'" in result

# Generated at 2022-06-12 14:52:21.246813
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    LOG = logging.getLogger(__name__)

    def f():
        pass

    with tqdm_logging_redirect(unit='B', unit_scale=True, unit_divisor=1024) as pbar:
        f()
        pbar.update()
        LOG.info('tqdm_logging_redirect: with tqdm_logging_redirect')

# Generated at 2022-06-12 14:52:29.060687
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:52:32.898503
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    #from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in trange(9):
        if i == 4:
            LOG.info("console logging restored")