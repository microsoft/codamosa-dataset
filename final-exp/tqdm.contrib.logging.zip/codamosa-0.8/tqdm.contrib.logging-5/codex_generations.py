

# Generated at 2022-06-12 14:42:45.201316
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit-tests for tqdm_logging_redirect
    """
    import time
    import random
    import logging
    from tqdm import tqdm

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
            desc='test', total=10, smoothing=0, mininterval=0,
            maxinterval=10, miniters=1, loggers=[LOG],
    ) as pbar:
        for _ in range(10):
            pbar.update()
            # time.sleep(random.random())
            LOG.info('log')


__all__ = list(filter(lambda s: not s.startswith('_'), dir()))

# Generated at 2022-06-12 14:42:53.278133
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    class TestLogger(logging.Logger):
        """
        Logger to store all log messages locally
        """
        def __init__(self, name):
            # type: (str) -> None
            super().__init__(name)
            self.log_msgs = []  # type: List[str]

        def log(self, level, msg, *args, **kwargs):
            # type: (int, str, *Any, **Any) -> None
            self.log_msgs.append(msg)

        def get_log_msgs(self, reverse=True):
            # type: (bool) -> List[str]
            return list(reversed(self.log_msgs)) if reverse \
                else self.log_msgs


# Generated at 2022-06-12 14:42:59.980928
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from ..std import tqdm as std_tqdm
    from .gui import tgrange

    logger = logging.getLogger("test_tqdm_logging_redirect")
    logger.setLevel(logging.DEBUG)

    with tqdm_logging_redirect(10, loggers=[logger]) as t:
        # "progress bar" with text
        for _ in t:
            logger.debug("hello world")
    assert t.n == 10

    with tqdm_logging_redirect(10, loggers=[logger]) as t:
        # "progress bar" with text
        for _ in t:
            logger.info("hello world")
    assert t.n == 10


# Generated at 2022-06-12 14:43:08.920055
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    from logging import Logger
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('logging.StreamHandler'):
        from .logging import logging_redirect_tqdm, _TqdmLoggingHandler

    tqdm_class = mock.MagicMock(spec=std_tqdm)

    # No `loggers` passed: the root Logger should be used
    with logging_redirect_tqdm(tqdm_class=tqdm_class):
        pass
        # logger = logging.getLogger()
        # assert _logger_has_handler(logger, _TqdmLoggingHandler)
        # assert logger.handlers[-1]._tqdm_class is tqdm_class



# Generated at 2022-06-12 14:43:11.297640
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # Test for some basic functionality in the function
    # tqdm_logging_redirect()
    import logging
    _tqdm = tqdm_logging_redirect(
        total=1,
        loggers=[logging.getLogger()],
        tqdm_class=std_tqdm)
    with _tqdm as _pbar:
        logging.info('TEST')
    assert _pbar.n == 1

# Generated at 2022-06-12 14:43:18.409880
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    for logger in loggers:
        tqdm_handler = _TqdmLoggingHandler(std_tqdm)
        orig_handler = _get_first_found_console_logging_handler(logger.handlers)
        if orig_handler is not None:
            tqdm_handler.setFormatter(orig_handler.formatter)
            tqdm_handler.stream = orig_handler.stream
        logger.handlers = [
            handler for handler in logger.handlers
            if not _is_console_logging_handler(handler)] + [tqdm_handler]
    logging.debug("logging_redirect_tqdm")

# Generated at 2022-06-12 14:43:25.849009
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function logging_redirect_tqdm
    """
    # create logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    # create console handler and set level to info
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # enable and disable tqdm_logging_redirect
    with tqdm_logging_redirect():
        logger.info("logging with tqdm")
    logger.info("logging without tqdm")

# Generated at 2022-06-12 14:43:33.784442
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import sys

    class _Tqdm(std_tqdm):
        def __init__(self, msg, file=sys.stdout, **kwargs):
            # type: (str, IO[Any], **Any) -> None
            """ Parameters
            ----------
            msg  : str
                Message to display (Default: None)
            file  : _io.IOBase, optional
                The file to write the progress message to.
                (Default: sys.stderr)
            **kwargs  : Any
                Keyword arguments to `tqdm.tqdm.__init__`
            """
            super(_Tqdm, self).__init__(
                total=len(msg), unit_scale=True,
                disable=None, file=file, **kwargs)
            self.msg

# Generated at 2022-06-12 14:43:40.683897
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ._tqdm_test_case import _TqdmTestCase, pretest_posttest  # pylint: disable=unused-variable
    import logging

    LOG = logging.getLogger(__name__)

    with _TqdmTestCase(disable=False), logging_redirect_tqdm():
        for i in std_tqdm(range(9), file=sys.stdout, unit=" "):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:43:46.557983
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    with logging_redirect_tqdm() as pbar:
        for i in tqdm(range(9)):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")
    logging.info('test')

    # Read pbar.file.getvalue() and manually check


# Generated at 2022-06-12 14:43:55.591763
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.NullHandler())
    with tqdm_logging_redirect():
        logger.info("hello")
        logger.warning("world")
    logger.info("goodbye")
    logger.warning("cruel world")

# Generated at 2022-06-12 14:44:05.787040
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm  # noqa
    from tqdm.contrib import logging_redirect_tqdm, logging

    def _demo(tqdm_class=tqdm):
        for _ in range(3):
            logging.root.info("you'll see this message")
        with logging_redirect_tqdm(tqdm_class=tqdm_class):
            for _ in range(3):
                logging.root.info("but NOT this one")
        for _ in range(3):
            logging.root.info("and you'll see this one again")

    print('testing function logging_redirect_tqdm()...')
    _demo()
    print('testing function logging_redirect_tqdm(tqdm_class=tqdm.tqdm)...')
   

# Generated at 2022-06-12 14:44:12.051790
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    The method emit call write from tqdm
    :return: None
    """
    from io import StringIO

    class FakeTQDM:
        @staticmethod
        def write(*args, **kwargs):
            pass

    handler = _TqdmLoggingHandler(FakeTQDM)

    handler.stream = fh = StringIO()

    handler.emit(logging.makeLogRecord({'msg': 'Hello world!'}))

    assert fh.getvalue() == 'Hello world!\n'

# Generated at 2022-06-12 14:44:19.806872
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test `logging_redirect_tqdm`.
    """
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    from tqdm.std import tqdm
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    with tqdm_logging_redirect() as pbar:
        for i in pbar:
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:44:23.733072
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from ..main import tqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9), desc='a'):
                if i == 4:
                    raise Exception('test logging_redirect_tqdm')
                if i == 8:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:44:31.520443
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm
    sio = StringIO()
    sys.stdout = sio
    logger = logging.getLogger("test_logger")
    handler = _TqdmLoggingHandler(tqdm_class=tqdm)
    handler.stream = sys.stdout
    logger.addHandler(handler)
    logger.warning("Test Message")
    assert sio.getvalue() == "Test Message"

# Generated at 2022-06-12 14:44:35.064327
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG], start=0, total=10):
        for i in range(11):
            LOG.info('msg {}'.format(i))


# Generated at 2022-06-12 14:44:43.145706
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import random
    import shutil

    # Note: to run the unit test, you need to have tqdm installed
    logger = logging.getLogger('tqdm')
    assert os.path.exists('.tqdm_logging')
    shutil.rmtree('.tqdm_logging')
    os.mkdir('.tqdm_logging')
    assert not os.path.exists('.tqdm_logging/out')
    with open('.tqdm_logging/out', 'w') as f:
        with tqdm_logging_redirect(loggers=[logger]) as pbar:
            for _ in range(10):
                logger.info(str(random.randint(0, 100)))
                pbar.update(1)

# Generated at 2022-06-12 14:44:51.498144
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def test_tqdm_logging_redirect(self):
            LOG = logging.getLogger(__name__)
            LOG.setLevel(logging.INFO)
            logging.basicConfig()

            with tqdm_logging_redirect():
                for i in range(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

            with tqdm_logging_redirect(loggers=[LOG]):
                for i in range(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")

            LOG.info("will be logged")
            orig_stdout = sys.stdout

# Generated at 2022-06-12 14:44:55.473305
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tnrange
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in tnrange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
        assert pbar.total == 9
        assert pbar.n == 9
    # logging restored



# Generated at 2022-06-12 14:45:17.210120
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    sample_log_string = "INFO:test:test"
    sample_end_stream = '\n'
    sample_log_level = logging.INFO
    class TestHandler(_TqdmLoggingHandler):
        def __init__(self):
            super(TestHandler, self).__init__()
            self.evt_logs = []
            self.evt_stream = ''
        def write(self, txt, file=None):
            self.evt_logs.append(txt)
            self.evt_stream += txt
    sample_handler = TestHandler()
    sample_handler.stream = sys.stdout

# Generated at 2022-06-12 14:45:22.123668
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for `logging_redirect_tqdm()`
    """
    import logging
    from tqdm import tqdm_notebook as tn
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tn.tqdm(range(9)):
            if i == 4:
                LOG.info("LOG: console logging redirected to `tqdm.write()`")
    # logging restored
    for i in tn.tqdm(range(3)):
        LOG.info("LOG: this is back to normal logging")

# Generated at 2022-06-12 14:45:33.873811
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import logging
    from tqdm import tqdm

    output = StringIO()
    test_logger = logging.getLogger("test_tqdm_logging_redirect")
    test_logger.setLevel(logging.DEBUG)
    test_logger.handlers = []
    test_logger.addHandler(logging.StreamHandler(output))

    pbar = None
    try:
        with tqdm_logging_redirect("testing", file=output,
                                   loggers=[test_logger],
                                   tqdm_class=tqdm) as pbar:
            test_logger.debug("debug message")

    except KeyboardInterrupt:
        pass

    assert pbar is not None

    assert pbar.total == 100
    assert output.getvalue

# Generated at 2022-06-12 14:45:39.203591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)

    # Test default tqdm_class
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in std_tqdm(range(4)):
            if i == 2:
                LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:45:44.733466
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(
            loggers=[logging.getLogger(__name__)],
            tqdm_class=std_tqdm):
        for i in std_tqdm(range(10)):
            if i == 5:
                logging.info("console logging redirected to `tqdm.write()`")
            logging.debug("debug")

# Generated at 2022-06-12 14:45:53.118769
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm, _get_first_found_console_logging_handler, _is_console_logging_handler
    from tqdm import tqdm, trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    # test if no console logging handler
    no_console_logging_handler_logger = logging.getLogger(__name__)
    no_console_logging_handler_logger.handlers = [
        logging.FileHandler("test.log", mode="w")]

# Generated at 2022-06-12 14:46:00.398561
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    print("Testing tqdm_logging_redirect")

    import logging
    import os

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        for i in range(3):
            LOG.info("console logging redirected to `tqdm.write()`")
    with tqdm_logging_redirect(file=open(os.devnull, 'w')):
        for i in range(3):
            LOG.info("console logging redirected to `tqdm.write()`")

    print("DONE Testing tqdm_logging_redirect")

# Generated at 2022-06-12 14:46:02.021095
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:05.866299
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect(
        loggers=[logging.getLogger(__name__)],
        total=3, unit="test") as pbar:
        while pbar.n < pbar.total:
            logging.debug('test')
            pbar.update()

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:46:15.502703
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Return whether the test of method emit of class _TqdmLoggingHandler
    passes.
    """
    logging_handler = _TqdmLoggingHandler()
    record = logging.LogRecord(
        "name", logging.INFO, "pathname", 1234, "msg", (), None)
    logging_handler.emit(record)
    return True

if __name__ == "__main__":
    import logging

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in std_tqdm.trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:48.502951
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm.autonotebook import trange
    from tqdm.tests.test_pandas import setup_tqdm_pandas
    with setup_tqdm_pandas():
        from tqdm import tqdm_pandas  # type: ignore
    import pandas as pd  # type: ignore
    import logging

    LOG = logging.getLogger(__name__)

    def logger():
        LOG.info('console logging redirected to `tqdm.write()`')

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:46:57.804879
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import unittest

    class _TestLoggingRedirectTqdm(unittest.TestCase):
        def setUp(self):
            self.log_msg = 'test message'

        def _test_logging_redirect_tqdm(
            self,
            expected_log_msg,  # type: str
            loggers_to_redirect=None,  # type: Optional[List[logging.Logger]]
        ):
            # type: (...) -> None
            self.log_stream = sys.stdout
            self.log_handler = self._setup_logging()

            self.log_stream.seek(0)
            self.log_stream.truncate()


# Generated at 2022-06-12 14:47:01.444920
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger('my_log')
    log.setLevel(logging.INFO)

    with logging_redirect_tqdm():
        log.info('info')
        log.warning('warning')
        log.error('error')

# Generated at 2022-06-12 14:47:11.442077
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for function `logging_redirect_tqdm`."""
    import logging

    LOG = logging.getLogger(__name__)

    def log_within_tqdm_context(loggers, tqdm_class):
        # type: (Optional[List[logging.Logger]], Type[std_tqdm]) -> None
        with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
            LOG.info('msg')

    logging.basicConfig(level=logging.INFO)
    log_within_tqdm_context(None, std_tqdm)
    log_within_tqdm_context([], std_tqdm)

# Generated at 2022-06-12 14:47:19.724344
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    # First use logging without context manager
    logger.info("hello console")
    # Use logging with context manager
    with logging_redirect_tqdm():
        for i in range(10):
            logger.info("hello tqdm")
            time.sleep(0.1)
    logger.info("hello console")

# Generated at 2022-06-12 14:47:22.590384
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:26.723599
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test :py:func:`tqdm.contrib.logging.logging_redirect_tqdm`"""
    from tqdm.auto import tqdm

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for _ in tqdm(range(9)):
            if _ == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:47:29.740500
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    logger = logging.getLogger('__test_logging_redirect_tqdm__')
    for level in [logging.INFO, logging.WARNING, logging.DEBUG]:
        logger.setLevel(level)
        with logging_redirect_tqdm(loggers=[logger]):
            logger.info('Test')
            time.sleep(0.1)


# Generated at 2022-06-12 14:47:34.034028
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:47:44.181070
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from io import StringIO
    import logging
    from tqdm import tqdm
    try:
        from tqdm.contrib import logger
        from tqdm.contrib.logging import tqdm_logging_redirect
    except ImportError:
        return
    output = StringIO()
    with tqdm_logging_redirect(
            n_iter=2, file=output, logger=logger, level=logging.INFO,
            desc='progress'
    ) as pbar:
        logger.info('hello')
        pbar.update(1)
    assert output.getvalue() == 'progress: 0it [00:00, ?it/s]\n'
    assert pbar.n == 2

if __name__ == '__main__':
    test

# Generated at 2022-06-12 14:48:31.762063
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    import logging
    import time

    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    LOG.info('before')
    with tqdm_logging_redirect(trange(3), tqdm_class=trange) as pbar:
        time.sleep(0.1)
        LOG.info('in')
        time.sleep(0.1)
        LOG.info('between')
        time.sleep(0.1)
        pbar.update(1)
        LOG.info('middle')
        time.sleep(0.1)
        pbar.update(1)
        LOG.info('after')
        time.sleep(0.1)
    LOG.info('out')

# Generated at 2022-06-12 14:48:35.829107
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up

    def main():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm() as pbar:
            for i in pbar(range(9)):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`")

    with _term_move_up():
        main()

# Generated at 2022-06-12 14:48:41.466858
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        import pytest
        running_pytest = True
    except ImportError:
        running_pytest = False

    # init logging
    logging.basicConfig(level=logging.DEBUG)
    LOG = logging.getLogger(__name__)

    # init test variable
    test_msg = "Hello World!"

    # test stdout capture
    with tqdm_logging_redirect(desc='test', total=3) as pbar:
        for i in pbar:
            if i == 1:
                LOG.info(test_msg)

    if not running_pytest:
        assert 'test: Hello World!' in pbar.get_description()

    # test stderr capture

# Generated at 2022-06-12 14:48:50.446892
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:  # Python 3
        from io import StringIO
    except ImportError:  # Python 2
        from StringIO import StringIO

    try:  # Python 3
        from contextlib import ExitStack
    except ImportError:  # Python 2
        from contextlib2 import ExitStack

    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    # custom logger used to avoid interferences from other tests
    class CustomLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super(CustomLogger, self).__init__(*args, **kwargs)

    # else: logging redirected to stdout
    custom_logging_root = CustomLogger('')

# Generated at 2022-06-12 14:48:59.825273
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from contextlib import redirect_stderr

    # Test the logger redirection
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    log.addHandler(handler)

    # Note: stderr is redirected to /dev/null (see nose.tools.redirect_stderr)
    with tqdm_logging_redirect(total=5, logger=log):
        log.info('Redirecting to tqdm')
        time.sleep(0.01)
        log.info('Standard')
        time.sleep(0.01)
        log.info('Logging')
        time.sleep(0.01)

    # Test the output

# Generated at 2022-06-12 14:49:05.030293
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma no cover
    import logging
    import time
    import warnings

    logging.basicConfig(level=logging.INFO)
    tqdm = tqdm_logging_redirect(desc='logging_redirected', leave=True)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for _ in tqdm():
            LOG = logging.getLogger(__name__)
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            time.sleep(0.1)
    assert(not tqdm.n)

# Generated at 2022-06-12 14:49:11.719384
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(desc='test_tqdm_logging_redirect') as pbar:
        pbar.update(1)
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:21.172531
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """ Test tqdm_logging_redirect function """
    import tqdm
    import logging
    with tqdm_logging_redirect(logging.getLogger()) as pbar:
        pbar.update(1)
    with tqdm_logging_redirect(logging.getLogger(), ncols=50) as pbar:
        pbar.update(1)
    with tqdm_logging_redirect(
            logging.getLogger(), ncols=50, tqdm_class=tqdm.tqdm) as pbar:
        pbar.update(1)

# Generated at 2022-06-12 14:49:26.914792
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:49:28.704452
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect():
        logging.info('test')

# Generated at 2022-06-12 14:50:54.950250
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:51:02.668376
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if not sys.version_info[0] >= 3:
        return
    try:
        from tqdm import tqdm
    except ImportError:
        return

    tqdm_class = tqdm

    from .test_tqdm import pretest_posttest, with_bar_unit

    def test_tqdm_logging_redirect_partial(
            __init__kwargs=None,
            **kwargs):
        # type: (**str) -> None
        """
        Run tests.

        Parameters
        ----------
        __init__kwargs : dict, optional
            Passed to `tqdm.tqdm`.
        **kwargs
            Passed to :func:`test_tqdm_logging_redirect()`.
        """
        if __init__kwargs is None:
            __init

# Generated at 2022-06-12 14:51:08.065403
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .._tqdm import tqdm_module_disabled
    if tqdm_module_disabled():
        return
    import logging
    from ..std import tqdm as std_tqdm

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    # Test if logger is found and captured
    if not any(logger == LOG for logger in logging.root.manager.loggerDict.values()):
        raise Exception("Logger not found")

    # Test if normal logging message works
    try:
        LOG.warning("Should show up on the console")
    except:
        raise Exception("Logger not working")

    # Test if setting logger root level works
    logging.root.setLevel(logging.INFO)

    # Test if redirecting logging to tqdm.write

# Generated at 2022-06-12 14:51:17.992341
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest2 as unittest  # type: ignore[import]
    except ImportError:
        import unittest  # type: ignore[import]

    class LoggingRedirectTqdmTestCase(unittest.TestCase):
        def setUp(self):
            self.loggers = [logging.getLogger('test.logger.%s' % i)
                            for i in range(5)]
            for logger in self.loggers:
                logger.handlers = []
                logger.propagate = False

        def test_logging_redirect_tqdm(self):
            with logging_redirect_tqdm(loggers=self.loggers):
                for logger in self.loggers:
                    self.assertEqual(len(logger.handlers), 1)
                   

# Generated at 2022-06-12 14:51:24.580989
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:51:31.207610
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import re
    import sys
    import unittest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    std_tqdm.write("ThIs Is tESt sTrInG")
    # monkey-patching sys.stdout to `write` to class-property,
    # being a list to store all the `write` to it
    sys.stdout = type(sys.stdout)([""])

    class MockLoggingHandler(logging.Handler):
        def emit(self, _):
            std_tqdm.write("ThIs Is tESt sTrInG")

    mock_handler = MockLoggingHandler()

# Generated at 2022-06-12 14:51:39.746711
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Test logging redirection to `tqdm.write()`"""
    return
    # TODO: use `unittest` instead?
    # import logging
    # from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm
    # LOG = logging.getLogger(__name__)
    #
    # if __name__ == '__main__':
    #     logging.basicConfig(level=logging.INFO)
    #     with logging_redirect_tqdm():
    #         for i in trange(9):
    #             if i == 4:
    #                 LOG.info("console logging redirected to `tqdm.write()`")
    #     # logging restored

# Generated at 2022-06-12 14:51:47.094669
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    log_no_redirect = []
    log_redirect = []
    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        logger = logging.getLogger()
        original_handlers = logger.handlers
        original_handlers_list = [handler.stream for handler in original_handlers]

        with trange(10) as t:
            LOG.info("hello")
            log_no_redirect.append(t.logger.handlers)

            with logging_redirect_tqdm():
                LOG.info("redirected to write")

# Generated at 2022-06-12 14:51:53.073177
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:51:59.611452
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from random import random
    from time import sleep
    import logging

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    def slow_func(sleeptime):
        # type: (float) -> float
        LOG.info('starting slow operation')
        sleep(sleeptime)
        LOG.info('operation done')
        return sleeptime

    with tqdm_logging_redirect(total=2) as pbar:
        slist = [random() for _ in pbar]
        for s in pbar:
            pbar.set_postfix_str('anything')
            pbar.update(1)
            slow_func(s)
    assert slist == pbar.n

