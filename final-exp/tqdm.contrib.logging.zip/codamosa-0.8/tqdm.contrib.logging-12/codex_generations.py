

# Generated at 2022-06-12 14:42:45.011910
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    with std_tqdm.hidden_cursor():
        with logging_redirect_tqdm():
            std_tqdm.tqdm.write('test')
            logging.info('test')



# Generated at 2022-06-12 14:42:50.442970
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging

    class MockTqdm(std_tqdm):
        def __init__(self):
            super(MockTqdm, self).__init__()
            self.out = io.StringIO()

        def write(self, msg, file=None):
            self.out.write(msg)

    tqdm = MockTqdm()
    mock_logger = logging.getLogger(__name__)
    log_handler = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    log_handler.setLevel(logging.INFO)
    mock_logger.addHandler(log_handler)

    msg = "Test message."
    mock_logger.info(msg)

    tqdm.close()
    assert tqdm.out.get

# Generated at 2022-06-12 14:42:56.404493
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    _logger = logging.getLogger(__name__)
    _logger.setLevel(logging.DEBUG)
    try:
        with tqdm_logging_redirect() as pbar:
            _logger.debug('debug')
            pbar.update()
            _logger.info('info')
            pbar.update()
            _logger.warning('warning')
            pbar.update()
            _logger.error('error')
            pbar.update()
            _logger.critical('critical')
            pbar.update()
    except ImportError:
        pass

# Generated at 2022-06-12 14:43:05.157825
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    log1 = logging.getLogger('1')
    log2 = logging.getLogger('2')
    log3 = logging.getLogger('3')
    log1.handlers = [
        logging.StreamHandler(sys.stderr),
        logging.FileHandler('err.log'),
    ]
    log2.handlers = [logging.FileHandler('1.log')]
    log3.handlers = []
    with logging_redirect_tqdm([log1, log2, log3]):
        with trange(9) as t:
            for i in t:
                if i == 4:
                    log1.info("console logging redirected to `tqdm.write()`")
    assert log1.handlers[-1].stream == 0


# Generated at 2022-06-12 14:43:08.464915
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = []
    with tqdm_logging_redirect(loggers=loggers) as pbar:
        assert not loggers
        assert pbar
        assert isinstance(pbar, std_tqdm)

    # TODO: test random order of context manager

# Generated at 2022-06-12 14:43:15.117753
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from ..std import tqdm as std_tqdm

    log_info = 'console logging redirected to `tqdm.write()`'

    # test default logger
    with logging_redirect_tqdm():
        for i in std_tqdm(range(4)):
            for j in std_tqdm(range(4), desc="j"):
                if i == j:
                    logging.info(log_info)
    # test specific logger
    log = logging.getLogger(__name__)

# Generated at 2022-06-12 14:43:23.708677
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.getLogger().setLevel(logging.INFO)

    def log_msg(logger, msg):
        logger.info(msg)

    def gen_log_msg(logger):
        def lm(msg):
            log_msg(logger, msg)
        return lm

    def logger_to_list(logger):
        """
        Returns a logging handler which saves formatted messages
        into `list_of_msgs`.
        """
        list_of_msgs = []

        class ListHandler(logging.Handler):
            """
            Listing handler appends (formatted) messages
            to the `list_of_msgs` list.
            """


# Generated at 2022-06-12 14:43:27.420915
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:34.776375
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    import warnings

    LOG = logging.getLogger(__name__)

    log_level = LOG.getEffectiveLevel()  # noqa
    # I could have just done `logging.getLogger().setLevel(logging.WARN)`,
    # but some users like to subclass tqdm and override default logging level.
    # So the best option is to set the lowest level and selectively
    # allow higher logging in unit tests.
    for handler in LOG.handlers:  # noqa
        handler.setLevel(logging.CRITICAL)
    LOG.setLevel(logging.CRITICAL)

    class Stderr(object):
        def __lshift__(self, x):
            sys.stderr.write(str(x) + "\n")

    err

# Generated at 2022-06-12 14:43:41.377481
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm
    except ImportError:
        return
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for _ in trange(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:43:53.043000
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Test logging_redirect_tqdm."""
    try:
        from unittest import mock
    except ImportError:
        import mock

    import logging
    import sys
    from tqdm import tqdm

    loggers = [
        logging.getLogger(__name__),
        logging.getLogger(),
        logging.getLogger("only.this"),
    ]

    with mock.patch("logging.StreamHandler.stream", sys.stderr, create=True):
        with mock.patch("sys.stderr", sys.stdout, create=True):
            with mock.patch.object(sys.stdout, "write"):

                with logging_redirect_tqdm(loggers):
                    for log in loggers:
                        log.info("abc")



# Generated at 2022-06-12 14:44:02.898592
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm as std_tqdm
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def _test_logging_redirect_tqdm():
        """
        Test logging_redirect_tqdm function
        """
        with logging_redirect_tqdm():
            for i in trange(3):
                if i == 1:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    class _Test_logging_redirect_tqdm(object):
        """
        Class for unittest of logging_redirect_tqdm function
        """

# Generated at 2022-06-12 14:44:08.154619
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.root]
    pbar = tqdm_logging_redirect(total=32, loggers=loggers)
    with pbar:
        assert list(pbar) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
                              15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
                              27, 28, 29, 30, 31]
    # logging restored


# Generated at 2022-06-12 14:44:15.803835
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    # Create a TqdmLoggingHandler
    class TqdmLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super(TqdmLoggingHandler, self).__init__()
            self.tqdm_class = std_tqdm

        def emit(self, record):
            try:
                msg = self.format(record)
                self.tqdm_class.write(msg, file=self.stream)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)


# Generated at 2022-06-12 14:44:18.595205
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from ..std import tqdm

    tqdm.write('test1')
    with logging_redirect_tqdm():
        logging.info('test2')
        tqdm.write('test3')
    tqdm.write('test4')



# Generated at 2022-06-12 14:44:23.967742
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import tqdm_notebook
    import logging
    import sys


# Generated at 2022-06-12 14:44:32.578840
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:44:38.107993
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.std import tqdm

    def test_logger():
        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)

        with logging_redirect_tqdm():
            for i in tqdm(range(10), desc="Testing"):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    test_logger()

# Generated at 2022-06-12 14:44:43.276501
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def main():
        # type: () -> None
        import logging
        import time
        import tqdm

        loggers = [logging.getLogger('logtest')]

        with tqdm_logging_redirect(loggers=loggers):
            for i in tqdm.trange(10):
                time.sleep(0.1)
                logging.getLogger('logtest').info('foo')


if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:44:51.627880
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from sys import stdout
    from . import tqdm

    class TqdmLoggingHandlerPseudo(logging.StreamHandler):
        def __init__(self):
            super(TqdmLoggingHandlerPseudo, self).__init__()

        def emit(self, record):
            try:
                msg = self.format(record)
                self.stream.write(msg)
                self.flush()
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa pylint: disable=bare-except
                self.handleError(record)

    # check tqdm.write
    string = "the quick brown fox jumped over the lazy dogs"
    print(string, end='')
    stdout.flush()

# Generated at 2022-06-12 14:45:02.393002
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: (...) -> None
    """ Unit test for function tqdm_logging_redirect """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger()
    logging.basicConfig(level=logging.INFO)

    with tqdm_logging_redirect(loggers=[LOG]) as pbar:
        for i in trange(4):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")
            pbar.set_description('A description')
            pbar.set_postfix({"postfix_name": "postfix_val"})

# Generated at 2022-06-12 14:45:14.843420
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # pylint: disable=too-many-locals
    import io
    import logging
    import sys
    import threading
    from contextlib import closing
    from unittest import TestCase

    from ..std import tqdm

    class RedirectStdStreams(object):
        def __init__(self, stdout=None, stderr=None):
            self._stdout = stdout or sys.stdout
            self._stderr = stderr or sys.stderr

        def __enter__(self):
            self.old_stdout, self.old_stderr = sys.stdout, sys.stderr
            self.old_stdout.flush()
            self.old_stderr.flush()
            sys.stdout, sys.stderr = self._stdout, self._st

# Generated at 2022-06-12 14:45:22.096704
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        import cStringIO as io
    except ImportError:
        import io
    # Create StringIO object
    string_buffer = io.StringIO()

    # Create a logging record
    record = logging.LogRecord(
        name='name',
        level=logging.INFO,
        pathname='/test.py',
        lineno=1,
        msg='INFO message',
        args=(),
        exc_info=None)

    # Create an instance of logging.StreamHandler
    console = _TqdmLoggingHandler()
    # Assign our StringIO object as logging's output stream
    console.stream = string_buffer

    # Emit the record using the custom emitter
    # The emitter will write directly to the StringIO object
    console.emit(record)

    # Observe results

# Generated at 2022-06-12 14:45:26.623604
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm([LOG]):
        LOG.info('This message should be redirected to tqdm')


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 14:45:34.991471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    with tqdm_logging_redirect(unit='it', total=3,
                               loggers=[logging.root],
                               tqdm_class=tqdm) as pbar:
        logging.info('a')
        pbar.update()
        logging.info('b')
        pbar.update()

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:45:44.553589
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        pbar.write('first write')
        pbar.n = 10
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.update()
        pbar.n = 5
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.update()
        pbar.n = 15
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.update()
        pbar.write('second write')
        logging.info('console logging redirected to `tqdm.write()`')
        pbar.n = 5
        pbar.update()

# Generated at 2022-06-12 14:45:52.980309
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
    except ImportError:
        from tqdm import __main__ as tqdm  # type: ignore

    # create a logger for testing
    log = logging.getLogger(__name__)

    # test that logging_redirect_tqdm works with logging.getLogger('my_logger')
    with tqdm_logging_redirect(loggers=[log], total=10) as my_pbar:
        for _ in range(10):
            my_pbar.update(1)
            log.info('console logging redirected to `tqdm.write()`')
    # logging restored in tqdm_logging_redirect

    # test that logging_redirect_tqdm works with the default root logger

# Generated at 2022-06-12 14:45:58.341595
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect(total=9, leave=False) as pbar:
            for i in range(pbar.total):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()
        # logging restored

# Generated at 2022-06-12 14:46:03.649023
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    with logging_redirect_tqdm():
        log.debug('test')
    with logging_redirect_tqdm([log]):
        log.debug('test')
    try:
        with logging_redirect_tqdm([None]):
            pass
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'



# Generated at 2022-06-12 14:46:07.077248
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = _TqdmLoggingHandler()
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.debug('hello')
    logger.info('hi')
    logger.error('err')
    logger.removeHandler(handler)



# Generated at 2022-06-12 14:46:29.060259
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm._version import get_versions

    with tqdm_logging_redirect(total=9, desc="Test logging_redirect_tqdm") as pbar:
        logging.basicConfig(level=logging.INFO)
        for i in trange(3, desc="Logging redirect to tqdm"):
            logging.info("Test logging_redirect_tqdm")

        for i in trange(3, desc="Test logging_redirect_tqdm 2"):
            logging.info("Test logging_redirect_tqdm 2")

        for i in trange(3, desc="Test logging_redirect_tqdm 3"):
            logging.info("Test logging_redirect_tqdm 3")


# Generated at 2022-06-12 14:46:35.018271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import unittest
        import unittest.mock as mock
    except ImportError:
        import mock  # type: ignore
        import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            from logging import INFO
            from . import logging_redirect_tqdm


# Generated at 2022-06-12 14:46:42.877539
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # test if context manager works as expected
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:46:48.713439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    import tqdm
    tqdm_class = tqdm.tqdm
    log = logging.getLogger('testlog')
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        log.info('test')
    with tqdm.tqdm(total=10) as pbar:
        with logging_redirect_tqdm(tqdm_class=tqdm_class):
            time.sleep(0.1)
            pbar.update(1)
            log.info('test')

# Generated at 2022-06-12 14:46:58.038878
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import shutil
    import tempfile
    import time
    import unittest
    import warnings


# Generated at 2022-06-12 14:47:07.075487
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm
    # pylint: disable=redefined-outer-name
    # pylint: disable=undefined-variable
    logging.basicConfig(level=logging.DEBUG)

    log = logging.getLogger(__name__)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for _ in tqdm(range(10), desc='bar'):
                log.info('blah')
            # logging restored
        for _ in tqdm(range(10), desc='bar'):
            log.info('blah')



# Generated at 2022-06-12 14:47:12.165621
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)

    logger_handlers = LOG.handlers
    with logging_redirect_tqdm():
        LOG.info("console logging redirected to `tqdm.write()`")

    assert LOG.handlers != logger_handlers



# Generated at 2022-06-12 14:47:18.040068
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    log_msg_1 = 'my logger info 1'
    log_msg_2 = 'my logger info 2'
    log_msg_3 = 'my logger info 3'
    log_msg_4 = 'my logger info 4'
    log_msg_5 = 'my logger info 5'

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=3, leave=False, desc='my logger info') as pbar:
        # logging redirected

        pbar.update(1)
        LOG.info(log_msg_1)

        pbar.update(1)
        LOG.info(log_msg_2)

        pbar.update(1)

# Generated at 2022-06-12 14:47:24.497638
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ._tqdm_test_cases import pretest_posttest  # noqa

    logging.basicConfig(level=logging.INFO)

    for i in pretest_posttest(
            range(9), logging_redirect_tqdm,
            "console logging redirected to `tqdm.write()`",
            expected_log_info=(
                "INFO:__main__:console logging redirected to `tqdm.write()`\n"
            )):
        if i == 4:
            logging.info("console logging redirected to `tqdm.write()`")
        pass


# fix for Python 2.6

# Generated at 2022-06-12 14:47:28.670262
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    LOG.info("test_logging_redirect_tqdm passed")


# Generated at 2022-06-12 14:47:55.758433
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Unit test for function logging_redirect_tqdm
    from logging import DEBUG, Logger, StreamHandler, basicConfig, getLogger
    from six.moves import StringIO
    from tqdm.std import tqdm
    import warnings

    stream = StringIO()  # type: StringIO
    handler = StreamHandler(stream)
    handler.setLevel(DEBUG)
    logging.root.setLevel(DEBUG)
    logging.root.addHandler(handler)
    LOG = Logger(__name__)

    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        with logging_redirect_tqdm():
            for _ in tqdm(range(5)):
                logging.debug('hello')
    assert 'hello' in stream.getvalue().replace('\n', '')


# Generated at 2022-06-12 14:48:00.152558
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    with logging_redirect_tqdm():
        for _ in tqdm(range(2)):
            logging.info('hello')
        for _ in tqdm(range(4)):
            logging.info('world')

# Generated at 2022-06-12 14:48:03.697186
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    def _test():
        import logging

        logging.basicConfig(level=logging.INFO)
        LOG = logging.getLogger(__name__)
        LOG.info('1')
        with logging_redirect_tqdm():
            LOG.info('2')
        LOG.info('3')

    _test()

# Generated at 2022-06-12 14:48:09.190766
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect"""
    import logging
    import tqdm
    with tqdm_logging_redirect() as tqdm_pbar:
        pbar = tqdm_pbar
        assert isinstance(tqdm_pbar, tqdm.tqdm)
        for i in pbar(range(4)):  # pylint: disable=not-an-iterable
            logger = logging.getLogger('logger' + str(i))
            logger.warning('msg' + str(i))


# Generated at 2022-06-12 14:48:15.044549
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:48:22.831815
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            LOG.info('test')
            with logging_redirect_tqdm():
                for i in trange(9):
                    if i == 4:
                        LOG.info('console logging redirected to `tqdm.write()`')
    except:
        pass

# Generated at 2022-06-12 14:48:31.214055
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import os
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)  # pylint: disable=invalid-name
    with open("tqdm_logging_redirect_test.log",
              'w') as file_stream:  # pylint: disable=invalid-name
        log_handlers = [logging.StreamHandler(file_stream),
                        logging.StreamHandler(sys.stdout)]
        logging.root.handlers = log_handlers
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-12 14:48:32.623591
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG]):
        LOG.info("Message")

# Generated at 2022-06-12 14:48:40.020598
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    import logging

    LOG = logging.getLogger(__name__)

    # Set basic logging options
    logging.basicConfig(level=logging.INFO)

    # Check that the logging output is not redirected
    LOG.info("This is a normal logging message.")

    # Redirect logging output to write()
    with logging_redirect_tqdm(tqdm_class=trange.__class__):

        # Now the logging output should go to write()
        LOG.info("This message goes to write().")

        # This loop is also shown in the console
        # as logging output to write()
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    # Check that

# Generated at 2022-06-12 14:48:47.970126
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test if class _TqdmLoggingHandler can handle errors while logging.
    """
    # Case where there is an error with the logger
    tqdm_handler = _TqdmLoggingHandler()
    record = {}
    with open(__file__, 'r') as f:
        tqdm_handler.stream = f
        try:
            tqdm_handler.emit(record)
        except:
            assert True
    # Case where there is no error
    with open(__file__, 'r') as f:
        tqdm_handler.stream = f
        tqdm_handler.emit(record)
        assert True

# Generated at 2022-06-12 14:49:34.943397
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .utils import _range as range
    import logging
    from .std import tqdm as std_tqdm

    log = logging.getLogger(__name__)
    with tqdm_logging_redirect(
            desc="Example", loggers=[log, logging.root], miniters=1, mininterval=0,
            maxinterval=0, maxiters=None, ncols=None, initial=0, total=10) as pbar:
        assert "Example" not in str(pbar)
        assert ("0it [00:00, ?it/s]", "1it [00:00, 999.00it/s]") == (str(pbar), pbar.format_dict['desc'])
        log.info("INFO: first")
        assert ("INFO: first", ) == pbar

# Generated at 2022-06-12 14:49:43.292779
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..main import tqdm
    from .utils import _supports_unicode
    with tqdm_logging_redirect(
            loggers=[logging.getLogger('_test')],
            disable=True,
            desc='tqdm_logging_redirect',
    ) as pbar:
        for ii in range(3):
            pbar.update()
            logging.getLogger('_test').info(pbar.__repr__()[1:])
    if _supports_unicode():
        assert pbar.format_dict['desc'] == u'tqdm_logging_redirect:   0%|          | 0/3 [00:00<?, ?it/s]\r'  # pylint: disable=line-too-long
    else:
        assert pbar.format_

# Generated at 2022-06-12 14:49:46.344220
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    with logging_redirect_tqdm(loggers=None):
        for _ in trange(9):
            logging.info('Test')
    tqdm_logging_redirect(range(9), loggers=None)

# Generated at 2022-06-12 14:49:53.713492
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tqdm_logging_handler = _TqdmLoggingHandler()
    import logging
    import sys
    log = logging.getLogger('test._TqdmLoggingHandler_emit')
    log.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.addHandler(tqdm_logging_handler)

    # test 1: if it can write to file stream
    log.info('hello world 1')
    tqdm_logging_handler.__del__()

    # test 2: if it can handle exception
    try:
        log.warning('hello world 2')
        raise RuntimeError
    except RuntimeError:
        tqdm_logging_handler.handleError(None)
    tqdm_logging_handler

# Generated at 2022-06-12 14:50:00.927842
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # pylint: disable=line-too-long
    # https://github.com/tqdm/tqdm/blob/04be938/tests/test_contrib.py#L140-L171
    import logging
    from tqdm import trange
    with logging_redirect_tqdm() as pbar:
        for _ in trange(9):
            # type: (int) -> None
            logging.warning("hello")
    assert pbar.n == 9

# Generated at 2022-06-12 14:50:04.344361
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    test_logger = logging.getLogger()
    test_logger.addHandler(_TqdmLoggingHandler())
    try:
        test_logger.info("This is a log test")
    except Exception:
        raise Exception("Fail to test method emit of _TqdmLoggingHandler")

# Generated at 2022-06-12 14:50:10.553102
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging

    root_logger = logging.getLogger()
    root_logger.handlers = []

    class MyLogger(logging.Logger):
        def __init__(self, *args, **kwargs):
            super(MyLogger, self).__init__(*args, **kwargs)
            self.stdout = []
            self.stderr = []

        def write(self, msg, fd=sys.stdout):
            if fd == sys.stdout:
                self.stdout.append(msg)
            else:
                self.stderr.append(msg)

    logging.setLoggerClass(MyLogger)

    logger = logging.getLogger(__name__)
    logger.setLevel(1)

# Generated at 2022-06-12 14:50:18.633393
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import BytesIO  # nosec
    from .tests_tqdm import closing, UnicodeIO  # type: ignore
    from .utils import _range

    try:
        _ = BytesIO().write('test')
    except TypeError:
        return

    with closing(UnicodeIO()) as our_file:
        with logging_redirect_tqdm(tqdm_class=std_tqdm) as pbar:
            pbar.write("CHECK")
            for i in _range(9):
                logging.info("console logging redirected to `tqdm.write()`")
            pbar.write("CHECK")
        assert len(our_file.getvalue().splitlines()) == 2



# Generated at 2022-06-12 14:50:23.947082
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.std import tqdm as tqdm_std
    import logging
    capturer = StringIO()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    handler = _TqdmLoggingHandler(tqdm_std)
    handler.stream = capturer
    handler.setFormatter(logging.Formatter(
        fmt="{levelname}:{name}:{message}",
        style="{"))
    logger.addHandler(handler)
    logger.info("Hello from handler")
    logger.removeHandler(handler)
    assert capturer.getvalue() == "INFO:root:Hello from handler\n"

# Generated at 2022-06-12 14:50:31.233949
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import os
    import logging
    from tqdm import tqdm

    if os.name == 'nt':
        raise SkipTest("TODO: https://github.com/tqdm/tqdm/issues/142")

    # Create test file
    outfile, errfile, logfile = 'out.log', 'err.log', 'log.log'
    for test_file in [outfile, errfile, logfile]:
        try:
            os.remove(test_file)
        except FileNotFoundError:
            pass

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.FileHandler(logfile)
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)


# Generated at 2022-06-12 14:51:52.404279
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig()
    with tqdm_logging_redirect(loggers=[logging.getLogger('foo'), logging.getLogger('bar')]) as pbar:
        pbar.write('tqdm via logging')
        logging.getLogger('foo').info('logging via foo')
        logging.getLogger('bar').info('logging via bar')
    logging.getLogger('foo').info('vanilla logging')



# Generated at 2022-06-12 14:51:58.524889
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from time import time, sleep
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, _get_first_found_console_logging_handler, logging_redirect_tqdm
    import logging

    loggers = None
    tqdm_class = std_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                sleep(0.3)

        # logging restored

# Generated at 2022-06-12 14:52:05.416872
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:52:12.104373
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:52:19.767817
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    def _test():
        import logging
        from tqdm import trange
        LOG = logging.getLogger(__name__)
        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in trange(100):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
    from logging import getLogger
    log = getLogger(__name__)
    if not log.handlers:  # create a handler if not existing
        log.addHandler(logging.NullHandler())
    with log.log_every(2, level=log.level, refresh_interval=0) as pbar:  # noqa
        _test()

# Generated at 2022-06-12 14:52:23.609712
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:52:30.364589
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    # import pdb; pdb.set_trace()
    with logging_redirect_tqdm():
        assert isinstance(logging.root.handlers[-1], _TqdmLoggingHandler)
        LOG.info("console logging redirected to `tqdm.write()`")
        assert isinstance(logging.root.handlers[-1], _TqdmLoggingHandler)
    assert isinstance(logging.root.handlers[-1], logging.StreamHandler)

# Generated at 2022-06-12 14:52:37.123075
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time

    from ..std import tqdm as std_tqdm_mod

    for std_tqdm_mod in [std_tqdm_mod, std_tqdm_mod.tqdm]:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm([logging.getLogger()]):
            logging.info('Info message')
            logging.warning('Warning message')
            logging.error('Error message')
            time.sleep(2)
        # logging restored
        logging.warning('Warning message after logging restored')
        logging.error('Error message after logging restored')

