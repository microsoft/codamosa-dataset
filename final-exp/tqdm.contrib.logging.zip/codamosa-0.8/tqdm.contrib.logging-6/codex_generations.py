

# Generated at 2022-06-12 14:42:48.297713
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .utils import _range
    from .docs import _extract_tqdm_source
    import time
    import io

    info_msg = "console logging redirected to `tqdm.write()`"
    info_msg_len = len(info_msg)
    max_msg_len = 78
    header = "test__TqdmLoggingHandler_emit"
    header_len = len(header) + 2
    min_line_len = header_len + info_msg_len + 2

    logger = logging.getLogger('_TqdmLoggingHandler_emit_test')
    logger.setLevel(logging.INFO)
    file = io.StringIO()
    handler = _TqdmLoggingHandler(std_tqdm)
    handler.stream = file

# Generated at 2022-06-12 14:42:56.369898
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    example_kwargs = dict(
        total=100,
        unit='B'
    )

    class MockTqdm:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args, **kwargs):
            pass

    # Raise exception if kwargs are passed to constructor of tqdm class
    with tqdm_logging_redirect(tqdm_class=MockTqdm, **example_kwargs):
        pass

    # Raise exception if kwargs are passed to logging_redirect_tqdm
    with tqdm_logging_redirect(tqdm_class=MockTqdm, loggers=[], **example_kwargs):
        pass

# Generated at 2022-06-12 14:42:59.431293
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:04.660262
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Tests logging redirection with :func:`logging_redirect_tqdm`."""
    from .test_std import test_main

    log = logging.getLogger("__main__")

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:43:12.601754
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import sys
    from contextlib import redirect_stdout
    from ..std import tqdm
    from .logging import getLogger, DEBUG, INFO
    # create an example logging message
    logger = getLogger(__name__)
    logger.propagate = False
    logger.setLevel(DEBUG)
    logger.handlers = []

    f = io.StringIO()
    with tqdm_logging_redirect(loggers=[logger], file=f, level=INFO) as pbar:
        # logging message should be redirected to the tqdm pbar
        logger.warning("a warning!")
        # normal print statement should be printed on screen to stdout
        print("a regular print stmt")

        # check that the stdout is still redirected to the tqdm pbar

# Generated at 2022-06-12 14:43:15.832111
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger()
    with tqdm_logging_redirect(loggers=[LOG]):
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:43:24.636400
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if LOG.hasHandlers():
        logging.root.handlers = []

    with trange(9) as pbar:
        with logging_redirect_tqdm():
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    with trange(9) as pbar:
        # can pass loggers argument:
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in pbar:
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
           

# Generated at 2022-06-12 14:43:30.489850
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    assert pbar.total == None
                    pbar.total = 9
                pbar.update()
        # logging restored

# Generated at 2022-06-12 14:43:35.413098
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(loggers=[LOG]) as pbar:
            for _ in trange(9):
                if pbar.n == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:43:46.225586
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import re
    import sys
    # We want to log everything to a file, but show only INFO or above on the
    # terminal.
    logging.basicConfig(level=logging.DEBUG,
                        filename='test_logging_redirect_tqdm.log')
    root_logger = logging.getLogger()

    # Create some test data.
    test_strings = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L",
                    "M", "N", "O", "P", "Q", "R"]

    # Dump test strings to log.
    for test_string in test_strings:
        root_logger.info(test_string)

    # Run logging_redirect_tqdm.


# Generated at 2022-06-12 14:44:01.025868
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(total=3, loggers=[LOG]):
        for i in range(3):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:44:05.927810
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(miniters=1) as pbar:
        for i in pbar(range(3)):
            if i == 1:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:44:11.376636
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def foo():
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    foo()

# Generated at 2022-06-12 14:44:15.802766
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    tlh = _TqdmLoggingHandler()

    if hasattr(tlh, "flush"):
        with open("tlh_emit.tmp", "w") as test_file:
            tlh.stream = test_file
            tlh.emit("test")
            tlh.flush()

        with open("tlh_emit.tmp") as test_file:
            assert test_file.read() == "test\n"



# Generated at 2022-06-12 14:44:21.440392
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Unit test for emit() method of _TqdmLoggingHandler.
    """
    # importing sys, logging and contextlib.contextmanager in the body of the
    # test is suggested by
    # https://www.pthom.net/blog/2018/testing-functions-which-use-contextlib-contextmanager/  # noqa
    # This allows us to mock the contextmanager.
    from contextlib import contextmanager
    from unittest.mock import patch
    import logging
    import sys

    from .logging_redirect_tqdm import _TqdmLoggingHandler

    @contextmanager
    def mock_context_manager(*args, **kwargs):
        """
        Mock the implementation of contextmanager.
        """
        yield

    # Setup
    handler = _TqdmLoggingHandler()

   

# Generated at 2022-06-12 14:44:27.976703
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import trange

    from logging import basicConfig, getLogger, INFO
    basicConfig(level=INFO)
    LOG = getLogger(__name__)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to tqdm.write()")
    # logging restored



# Generated at 2022-06-12 14:44:35.191236
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect.
    """
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        LOG.info('Hello pbars')
        for i in trange(9):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:44:43.245288
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import tqdm

    output = io.StringIO()
    tqdm_handler = _TqdmLoggingHandler(tqdm.tqdm)
    tqdm_handler.stream = output
    logger = logging.getLogger(__name__)
    logger.addHandler(tqdm_handler)
    logger.setLevel(logging.DEBUG)

    logger.debug("debug message")
    expected_output = "debug message\n"
    actual_output = output.getvalue()
    assert expected_output == actual_output

    logger.info("info message")
    expected_output += "info message\n"
    actual_output = output.getvalue()
    assert expected_output == actual_output

    logger.warning("warning message")

# Generated at 2022-06-12 14:44:49.229099
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9), desc='POW'):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert logging.getLogger(__name__).handlers[0].stream is sys.stderr



# Generated at 2022-06-12 14:44:58.590660
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import StringIO
    import logging
    import unittest

    class TqdmLoggingHandlerTestCase(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.tqdm_logging_handler = _TqdmLoggingHandler()
            self.logger.addHandler(self.tqdm_logging_handler)
            self.fake_stream = StringIO.StringIO()
            self.tqdm_logging_handler.stream = self.fake_stream

        def tearDown(self):
            self.logger.removeHandler(self.tqdm_logging_handler)
            self.fake_stream.close()


# Generated at 2022-06-12 14:45:19.557693
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect, std_tqdm
    from tqdm.utils import _term_move_up

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(desc="redirect_logging", bar_format="{desc}") as pbar:
        for _ in trange(10):
            LOG.info("message")
            pbar.update(1)

    # check that tqdm bar is set up again

# Generated at 2022-06-12 14:45:28.645160
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:45:37.216473
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function logging_redirect_tqdm
    """

    import logging

    try:
        from unittest import mock
    except ImportError:
        import mock

    logger = logging.getLogger(__name__)

    handler = _TqdmLoggingHandler()

# Generated at 2022-06-12 14:45:47.114541
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm.autonotebook import tqdm
        tqdm.monitor_interval = 0
    except ImportError:
        pass

    loggers = [logging.getLogger("run_test_1"),
               logging.getLogger("run_test_2")]

    for log in loggers:
        log.propagate = True
        log.setLevel(logging.INFO)
        log.addHandler(logging.StreamHandler())


# Generated at 2022-06-12 14:45:53.788655
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    log = logging.getLogger('test_logging_redirect_tqdm')
    log.prog = 'test'
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(10)):
            log.info("logging redirected to `tqdm.write()`")
        with tqdm_logging_redirect(loggers=[log]):
            for i in tqdm(range(10)):
                log.info("logging redirected to `tqdm.write()` by tqdm_logging_redirect")

# Generated at 2022-06-12 14:46:02.489113
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import tempfile

    logger = logging.getLogger(__name__)

    with tempfile.TemporaryFile('r+') as t:
        hdl = logging.StreamHandler(t)
        logger.addHandler(hdl)
        logger.setLevel(logging.INFO)

        with logging_redirect_tqdm(loggers=[logger]):
            logger.info('console logging redirected to `tqdm.write()`')

        # Test if stream is restored
        logger.info('should be printed and flushed')
        t.seek(0)
        msg = t.read()

    assert 'console logging redirected to' not in msg
    assert 'should be printed and flushed' in msg

    # Test if the restored stream is buffered

# Generated at 2022-06-12 14:46:07.409807
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from time import sleep

    LOG = logging.getLogger(__name__)
    LOG.addHandler(logging.NullHandler())

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            sleep(0.1)

    with logging_redirect_tqdm():
        for i in range(120):
            if i == 66:
                LOG.info("console logging redirected to `tqdm.write()`")
            sleep(0.1)

# Generated at 2022-06-12 14:46:13.554726
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    _TqdmLoggingHandler.emit(record="A", stream=io.StringIO())
    _TqdmLoggingHandler.stream = sys.stdout
    _TqdmLoggingHandler.emit(record="B", stream=sys.stdout)
    _TqdmLoggingHandler.stream = sys.stderr
    _TqdmLoggingHandler.emit(record="C", stream=sys.stderr)
    return None


# Generated at 2022-06-12 14:46:18.858926
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logger = logging.getLogger()
    handler_set = set(logger.handlers)
    with logging_redirect_tqdm([logger]):
        assert set(logger.handlers) - set(handler_set) == {_TqdmLoggingHandler()}
    assert set(logger.handlers) == set(handler_set)



# Generated at 2022-06-12 14:46:22.049799
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with logging_redirect_tqdm():
        log = logging.getLogger(__name__)
        log.info('test logging redirect')



# Generated at 2022-06-12 14:46:51.632881
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Here, we test if log messages are printed only if the handler is active,
    are not printed if the handler is inactive, and that the `flush()` method
    of a handler flushes the log message to the screen.
    """

    # Create a logging handler
    log_handler = _TqdmLoggingHandler()

    # Create a logger object and attach the handler to the logger object
    log = logging.getLogger('test')
    log.handlers = [log_handler]
    log.setLevel(logging.INFO)

    # Import StringIO to redirect logs to a stream
    import io
    import sys

    # Record the original `sys.stdout` to reset it later
    original_stdout = sys.stdout

    # Create a stream to save the logs
    log_stream = io.StringIO()
    sys

# Generated at 2022-06-12 14:47:01.238625
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    import logging
    import sys
    import time

    stringio = StringIO()
    # Save the original stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    tqdm_class = std_tqdm

    # Create a logger
    Logger = logging.getLogger()
    # Create handlers and formatter
    handler = logging.StreamHandler(stringio)
    formatter = logging.Formatter('(%(name)s) %(message)s')
    # Add the handler and formatter to the logger
    handler.setFormatter(formatter)
    Logger.addHandler(handler)
    Logger.setLevel(logging.INFO)

    Logger.info("Test if logging is working before the context manager")



# Generated at 2022-06-12 14:47:06.500642
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:14.986312
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from io import StringIO
    from tqdm import tqdm

    # Set up fake stdout
    _out = StringIO()
    _orig_out = sys.stdout
    sys.stdout = _out

    # Set up a logger
    logger = logging.getLogger('__main__')
    logger.setLevel(logging.INFO)

    # Test tqdm.write()
    with _TqdmLoggingHandler(tqdm_class=tqdm) as tqdm_handler:
        tqdm_handler.stream = sys.stdout
        tqdm_handler.emit(
            logging.LogRecord(
                '__main__',
                logging.INFO,
                '',
                0,
                'This is line 1',
                [],
                None))

# Generated at 2022-06-12 14:47:20.433261
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    def test_function():
        logger.error('test error')
        logger.warning('test warning')
        logger.info('test info')
        logger.debug('test debug')
        if logger.getEffectiveLevel() != logging.WARNING:
            logger.info('test info')

    with logging_redirect_tqdm([logger]):
        test_function()



# Generated at 2022-06-12 14:47:27.107548
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging, time
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(
        total=1,
        bar_format="{desc}: {percentage:3.0f}%|{bar}|"
        ) as pbar:
        for i in range(1):
            LOG.info("this line should show in the bar")
            time.sleep(0.1)
    assert pbar.n == pbar.total
    assert "console logging redirected to `tqdm.write()`" in pbar.desc
    assert pbar.desc.endswith("100%|")

# Generated at 2022-06-12 14:47:33.269978
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    assert tqdm_logging_redirect.__doc__ is not None

    LOG = logging.getLogger()
    with tqdm_logging_redirect() as pbar1:
        LOG.info("This is logged on tqdm")
        assert pbar1
        LOG.info("This is logged on tqdm")
        loggers = None  # type: Optional[List[logging.Logger]]

# Generated at 2022-06-12 14:47:43.439141
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    tqdm.set_lock(lambda: None)
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)

    # with tqdm(ncols=120) as pbar:
    with tqdm_logging_redirect(ncols=120) as pbar:
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:47:49.916886
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # create the logging handler
    handler = _TqdmLoggingHandler()
    assert handler.stream is sys.stderr

    # create a log record
    log_record = logging.LogRecord('name', logging.INFO, '/', 1,
                                   'Message', None, None)
    log_record.name = 'name'
    log_record.levelno = logging.INFO
    log_record.pathname = '/'
    log_record.lineno = 1
    log_record.msg = 'Message'
    log_record.args = None
    log_record.exc_info = None

    # call method
    handler.emit(log_record)

# Generated at 2022-06-12 14:47:53.611812
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # This testcase is only for generate coverage percentage
    # not for real test.
    handler = _TqdmLoggingHandler(None)
    handler.tqdm_class = std_tqdm

    handler.tqdm_class.write = lambda *args, **kwargs: type(None)
    handler.tqdm_class.write(None, file=None)

    handler.flush = lambda *args: type(None)
    handler.flush()

# Generated at 2022-06-12 14:48:24.670565
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    try:
        from cStringIO import cStringIO as cStringIO_py2
    except ImportError:
        from io import StringIO as cStringIO_py2  # type: ignore
    import sys

    logging.basicConfig(level=logging.INFO)
    try:
        from contextlib import redirect_stderr
    except ImportError:
        from contextlib2 import redirect_stderr  # type: ignore

    log = logging.getLogger(__name__)
    for i in range(4):
        log.info("stuff %d" % i)
    f = cStringIO_py2()
    with redirect_stderr(f):
        with logging_redirect_tqdm():
            log.info("console logging redirected to `tqdm.write()`")
            # also test

# Generated at 2022-06-12 14:48:32.569217
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # Unit test for function logging_redirect_tqdm

    from six.moves import StringIO
    from tqdm import trange
    from tqdm.contrib import DummyTqdmFile
    LOG = logging.getLogger(__name__)

    with DummyTqdmFile(unit=' Bytes') as tfile:
        with logging_redirect_tqdm(tfile=tfile):
            for _ in trange(9):
                if _ == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:35.464177
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm import tqdm
    with tqdm(total=10) as pbar:
        with logging_redirect_tqdm():
            for i in range(10):
                if i == 2:
                    logging.info("console logging redirected to tqdm.write()")
                if i == 4:
                    break
                pbar.update()

# Generated at 2022-06-12 14:48:43.264431
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging

    # Creates a logger and add a handler
    log = logging.getLogger()
    handler = logging.StreamHandler()
    log.addHandler(handler)

    # Create a log message
    with logging_redirect_tqdm():
        for _ in range(1):
            time.sleep(0.1)
            log.error('hello')

        for _ in tqdm(
                range(1),
                disable=True,
                bar_format='Custom: {percentage:3.0f}%'
        ):
            time.sleep(0.1)
            log.error('world')
        # logging restored

    # Create a log message
    with tqdm_logging_redirect():
        for _ in range(1):
            time.sleep(0.1)
           

# Generated at 2022-06-12 14:48:51.577236
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Notes
    -----
    It is necessary to modify sys.stdout to capture the output of the logger,
    else sys.stdout is used instead of the _TqdmLoggingHandler instance stream.
    This is not a problem since the file descriptor is not changed.

    References
    ----------
    https://stackoverflow.com/questions/415511/how-to-get-the-current-time-in-python
    """
    import time
    import tempfile
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    log = logging.getLogger('log_redirect')
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler())


# Generated at 2022-06-12 14:48:53.654583
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('hello world')  # prints to stdout

# Generated at 2022-06-12 14:48:58.427268
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger()
    log.setLevel(logging.INFO)
    logging.warning("this should not be shown")
    with logging_redirect_tqdm():
        logging.warning("this should be redirected to tqdm.write()")
    log.info("and this should go back to stdout")

# Generated at 2022-06-12 14:49:04.230703
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL
    from .utils import closing

    try:
        from cStringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3

    # logging.basicConfig()
    stream = StringIO()

    with closing(stream):
        with tqdm_logging_redirect(file=stream, level=logging.DEBUG):
            logging.warning("warning")
            logging.error("error")
            logging.critical("critical")
        assert stream.getvalue() == "warning\nerror\ncritical\n"



# Generated at 2022-06-12 14:49:14.081854
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import colorama
    stream = sys.stderr
    stream_colorama = stream

    h = _TqdmLoggingHandler()
    h.stream = stream
    h.level = 0

    # logging -> tqdm
    with std_tqdm(total=9, file=stream) as pbar:
        h.emit(
            logging.LogRecord("logging", "DEBUG", "logging.py", 42,
                              "test", (), None))
        assert h.tqdm_class.format_meter(0, pbar) in stream.getvalue()

    # logging -> tqdm colorama
    if hasattr(colorama, 'initialise'):
        colorama.initialise(autoreset=True)
        # colorama must be initialised in every single thread,
        # since it works via reset

# Generated at 2022-06-12 14:49:23.777936
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_tqdm import with_unit_option, pretest_posttest  # pylint: disable=no-name-in-module


# Generated at 2022-06-12 14:50:07.641257
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=3):
            for i in range(3):
                if i == 1:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:50:16.072250
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm

    try:
        # Fails on Python 2.6
        from unittest import TestCase
    except ImportError:
        from unittest2 import TestCase

    LOG = logging.getLogger(__name__)

    class FakeTqdm(object):
        """Intentionally causing tqdm to fail to test logging fallback"""
        def __init__(self, *args, **kwargs):
            pass

        def update(*args, **kwargs):
            raise RuntimeError("FakeTqdm intentionally failing")


# Generated at 2022-06-12 14:50:20.583556
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # Given - Object of class _TqdmLoggingHandler
    handler = _TqdmLoggingHandler()

    # When - Call method emit
    handler.emit('Test Pasing Message')

    # Then - Message is written by tqdm.write
    # tqdm.write is called in emit method which is not available unittest.
    # Hence mocking tqdm.write
    # Mocked tqdm.write is tested in unittest.
    if __name__ == '__main__':
        from tqdm.tests import CommonTest

        CommonTest._test_enter_exit(test__TqdmLoggingHandler_emit)

# Generated at 2022-06-12 14:50:24.133195
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm  # type: ignore
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=5) as progressbar:
        progressbar.set_description("Testing function tqdm_logging_redirect")
        for i in range(5):
            if i == 2:
                LOG.info("console logging redirected to `progressbar.update()`")
            progressbar.update(1)


# Generated at 2022-06-12 14:50:31.313247
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys
    import tempfile
    import time

    # Set up logger
    logger = logging.getLogger("example")
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.INFO)
    tqdm.write("foo")

    with tempfile.NamedTemporaryFile(mode="w") as fd:
        fd_path = fd.name
        # Redirect stdout to log file
        with tqdm.std.redirect_stdout(fd):
            with tqdm.contrib.logging.logging_redirect_tqdm():
                tqdm.write("bar")
                logger.info("log to tqdm")

        fd.seek(0)
        output = fd.read()

# Generated at 2022-06-12 14:50:39.995001
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if '__main__' == __name__:
        import logging
        from tqdm import std_tqdm
        from tqdm.contrib.logging import tqdm_logging_redirect

        LOG = logging.getLogger(__name__)

        def is_logger_handler_of_type(logger, handlertype):
            return len([lh for lh in logger.handlers if isinstance(lh, handlertype)])

        with tqdm_logging_redirect(total=5) as pbar:
            assert is_logger_handler_of_type(LOG, std_tqdm.TqdmHandler)

        def is_logger_handlers_restored(logger, original_handlers):
            return len(logger.handlers) == len(original_handlers)

# Generated at 2022-06-12 14:50:44.792037
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import tqdm_logging_redirect, loggers

    with tqdm_logging_redirect(unit='it',
                               leave=False,
                               loggers=loggers) as pbar:
        for _ in trange(3):
            logging.info("Hola mundo")

# Generated at 2022-06-12 14:50:50.203373
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    def _test_logging_redirect(tqdm_cls):
        with tqdm_logging_redirect(tqdm_class=tqdm_cls):
            logger = logging.getLogger(__name__)
            for i in trange(9):
                if i == 4:
                    logger.info("console logging redirected to `tqdm.write()`")
                # else:
                #     logger.info('Desu Desu Desu')

    for tqdm_cls in [std_tqdm, std_tqdm.tqdm, std_tqdm.tqdm.__wrapped__]:
        _test_logging_redirect(tqdm_cls)

# Generated at 2022-06-12 14:50:59.642878
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Testing tqdm_logging_redirect."""
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect
    from time import sleep

    LOG = logging.getLogger(__name__)

    def log(logger, n):
        for i in range(n):
            if i == n // 2:
                LOG.info("console logging redirected to `tqdm.write()`")
            logger.debug(str(i) * 5 + ' ' * (i % 5))
        logger.info(str(n) * 5)


# Generated at 2022-06-12 14:51:06.379322
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm.tests import pretest
        pretest()
    except ImportError:
        pass

    class TestLogger(logging.Logger):
        def __init__(self):
            super(TestLogger, self).__init__("TestLogger")
            self.last_message = None

        def handle_message(self, message):
            self.last_message = message

        def handle(self, record):
            self.handle_message(record.getMessage())

    # Need custom class to override the handler
    # https://docs.python.org/2/library/logging.html#logging.Logger.handle
    class TestHandler(logging.Handler):
        def emit(self, record):
            pass

    logger = TestLogger()
    logger.addHandler(TestHandler())

   

# Generated at 2022-06-12 14:52:29.839068
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect() as pbar:
        for _ in range(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:52:37.691993
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm(loggers=[LOG], tqdm_class=tqdm.tqdm):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # Check if logging restored
    with logging.StreamHandler() as handler:
        LOG.addHandler(handler)
        LOG.info("check if logging restored")
        assert str(handler.stream) == "<_io.TextIOWrapper name='<stdout>' mode='w' encoding='UTF-8'>"

