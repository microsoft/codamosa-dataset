

# Generated at 2022-06-12 14:42:50.279498
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm._utils import _term_move_up

    # trap
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    # set-up
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    # test
    with logging_redirect_tqdm():
        logging.info('console logging redirected to `tqdm.write()`')

    # test
    with logging_redirect_tqdm():
        # ensure we clear the line
        print('\n')
        logging.info('console logging redirected to `tqdm.write()`')

    # test

# Generated at 2022-06-12 14:42:57.144273
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(logging.root) as pbar:
            for i in pbar(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
    assert True

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:43:06.078935
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test function logging_redirect_tqdm.
    """
    # pylint: disable=missing-docstring, invalid-name, no-self-use
    from warnings import warn
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    class AssertionError(Exception):
        pass

    class AssertWarnsContext():
        """A context manager used to implement TestCase.assertWarns()."""

        def __init__(self, expected_warning):
            # type: (Type[Warning]) -> None
            self._expected_warning = expected_warning

        def __enter__(self):
            # type: () -> AssertWarnsContext
            return self


# Generated at 2022-06-12 14:43:13.546874
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect

    Since tqdm_logging_redirect uses the logging module in the background, we need to
    capture the output while running the main test part. This is done by defining
    a helper class named Capturing.
    """
    import io
    import logging
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out,

# Generated at 2022-06-12 14:43:19.207265
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=5) as pbar:
        # Do not use 'logging.info', because it will print log message to std::cerr
        # which is not redirected by tqdm_logging_redirect.
        # pbar.should_redirect_stdout is True.
        pbar.write("test_tqdm_logging_redirect")

        # Same as above.
        # pbar.should_redirect_stdout is False.
        pbar.write("test_tqdm_logging_redirect")

# Generated at 2022-06-12 14:43:28.013170
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)
    logging.basicConfig(stream=tmp_file, format=None)
    with tqdm_logging_redirect(total=3, ascii=True,
                               desc='Running tests', smoothing=0,
                               loggers=[LOG], tqdm_class=std_tqdm) as pbar:
        assert str(pbar) == 'Running tests:   0.0%|'
        LOG.info("console logging redirected to `tqdm.write()`")
        assert str(pbar) == 'Running tests:  33.3%|'

# Generated at 2022-06-12 14:43:35.154876
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .helpers import TestHandler
    import logging

    LOG = logging.getLogger(__name__)

    # Basic test
    with tqdm_logging_redirect(verbose=True):
        for n in range(10):
            LOG.info(str(n))

    # Test with blocking=True
    with tqdm_logging_redirect(verbose=True, blocking=True) as pbar:
        for n in range(10):
            LOG.info(str(n))
            pbar.update()
        pbar.close()

    # Test with custom loggers
    with tqdm_logging_redirect(verbose=True,
                               loggers=[logging.getLogger('logger1'),
                                        logging.getLogger('logger2')]):
        logging.getLog

# Generated at 2022-06-12 14:43:45.464380
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    assert list(map(type, logging.root.handlers)) == [logging.StreamHandler]
    assert logging.root.handlers[0].stream in {sys.stdout, sys.stderr}
    with logging_redirect_tqdm():
        assert list(map(type, logging.root.handlers)) == [_TqdmLoggingHandler]
        assert logging.root.handlers[0].stream in {sys.stdout, sys.stderr}
    assert list(map(type, logging.root.handlers)) == [logging.StreamHandler]
    assert logging.root.handlers[0].stream in {sys.stdout, sys.stderr}



# Generated at 2022-06-12 14:43:49.444409
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    sio = io.StringIO()
    handler = _TqdmLoggingHandler()
    handler.stream = sio
    handler.emit(logging.LogRecord(
        "name", logging.INFO, "pathname", 42, "msg", None, None))
    output = sio.getvalue()
    assert "msg" in output, output



# Generated at 2022-06-12 14:43:57.549487
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import sys

    import pytest

    # Test that console logging is redirected to `tqdm.write()`
    with tqdm_logging_redirect() as pbar:
        logging.info("write")
        assert pbar.written == ["write"]

    # Test that file logging is not affected
    with pytest.raises(IOError):
        with tqdm_logging_redirect() as pbar:
            with open("_non-existing-file") as f:
                logging.info("write", file=f)
                assert pbar.written == []

    # Test that logging is restored after exiting context manager
    with tqdm_logging_redirect() as pbar:
        logging.info("write")
        assert pbar.written == ["write"]
   

# Generated at 2022-06-12 14:44:04.990488
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger(__name__)

    log.info("should not show")
    with logging_redirect_tqdm():
        log.info("should show")

# Generated at 2022-06-12 14:44:12.512539
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for `tqdm.contrib.logging.logging_redirect_tqdm`
    """
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    for _ in trange(9):
        if 5 < _ < 7:
            with logging_redirect_tqdm():
                for _ in trange(9):
                    if _ == 6:
                        LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:44:15.985651
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import INFO

    # setup
    logging.basicConfig(level=INFO)
    with tqdm_logging_redirect(logging.getLogger()) as pbar:
        logging.info("Hello")
        logging.warning("World")
        assert pbar.n == 2

    # teardown

# Generated at 2022-06-12 14:44:21.628903
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    test_cases = [
        {"message": "test_message", "expected": "test_message\n"},
        {"message": "test\nmessage", "expected": "test\nmessage\n"},
        {"message": "test\rmessage", "expected": "test\rmessage\n"},
        {"message": "test\r\nmessage", "expected": "test\r\nmessage\n"},
    ]
    for case in test_cases:
        record = logging.LogRecord("name", logging.INFO, "/path/file.py",
                                   42, case['message'], None, None)
        handler.emit(record)
        assert getattr(sys.stdout, "getvalue")() == case['expected']
        import StringIO
        sys.stdout = String

# Generated at 2022-06-12 14:44:28.753019
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    if __name__ == '__main__':
        import logging

        LOG = logging.getLogger(__name__)

        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect(total=6):
            for i in range(6):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

        # logging restored



# Generated at 2022-06-12 14:44:38.707655
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Simple test for tqdm.contrib.logging"""
    # pylint: disable=protected-access
    from tqdm.auto import tqdm
    try:
        import unittest
        import unittest.mock as mock
    except ImportError:
        import mock
    # pylint: enable=protected-access
    # Create a mock object to replace sys.stdout
    mock_stdout = mock.Mock()
    # Save original
    original = sys.stdout

# Generated at 2022-06-12 14:44:45.571604
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import re
    pattern = re.compile(r'.*\|-test_tqdm_logging_redirect-\|.*')
    for logger in [logging.root, logging.getLogger('tqdm')]:
        logger.setLevel(logging.DEBUG)
    with tqdm_logging_redirect(
            loggers=[logging.getLogger('tqdm')],
            tqdm_class=std_tqdm):
        log_info_pattern(pattern, "test_tqdm_logging_redirect")
        logging.warning("IGNORED")



# Generated at 2022-06-12 14:44:48.721168
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from asyncore import dispatcher
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info('test log message')
    d = dispatcher()
    d.add_channel()

# Generated at 2022-06-12 14:44:55.593583
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import StringIO
    import unittest
    from contextlib import closing

    class _TqdmLoggingHandlerTest(unittest.TestCase):
        @staticmethod
        def _get_handler_output_lines(custom_handler):
            output_stream = StringIO.StringIO()
            with closing(output_stream):
                custom_handler.stream = output_stream
                custom_handler.emit(logging.makeLogRecord({}))
                return [line.strip() for line in output_stream.getvalue().splitlines()]

        def test_emit(self):
            self.assertEqual([''], self._get_handler_output_lines(_TqdmLoggingHandler()))

    unittest.main(module=__name__, buffer=True)


# Generated at 2022-06-12 14:45:00.888701
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    with tqdm_logging_redirect(
            total=9, mininterval=0, miniters=1,
            file=sys.stdout, leave=False,
            unit='t_unit', unit_scale=True, desc='Description'
            ) as pbar:
        for i in range(9):
            logger.info('step %d' % i)
            pbar.update()


# Generated at 2022-06-12 14:45:12.023426
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:21.033730
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # test with multiple loggers
    loggers = [LOG, logging.getLogger('test')]
    with logging_redirect_tqdm(loggers):
        with tqdm(total=6) as pbar:
            for i in range(6):
                pbar.update(1)
                LOG.info('test log ' + str(i))

    # test without any logger
    loggers = []
    with logging_redirect_tqdm(loggers):
        with tqdm(total=6) as pbar:
            for i in range(6):
                pbar.update(1)
                LOG

# Generated at 2022-06-12 14:45:32.769746
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import os
    import shutil
    import tempfile
    import logging
    import logging.config
    import json

    LOGGER_NAME = 'test_logger'

    def _assert_logger_handlers_redirected(logger_name):
        # type: (str) -> None
        """
        Assert that the handlers of a given logger has been redirected
        to `tqdm.write()`.
        """
        logger_handlers = [
            handler for handler in list(logging.getLogger(logger_name).handlers)
            if isinstance(handler, _TqdmLoggingHandler)]

        assert len(logger_handlers) == 1


# Generated at 2022-06-12 14:45:38.751438
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    LOG = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)

    def log_func():
        # type: () -> None
        LOG.debug("Debug: console logging not affected")
        LOG.info("Info: console logging redirected to `tqdm.write()`")
        LOG.warning("Warning: console logging redirected to `tqdm.write()`")
        LOG.error("Error: console logging redirected to `tqdm.write()`")

    tqdm_class = std_tqdm
    log_func()
    with logging_redirect_tqdm(tqdm_class=tqdm_class):
        log_func()
    log_func()

# Generated at 2022-06-12 14:45:48.090852
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import logging
    except ImportError:
        return
    import os
    import sys
    from io import StringIO
    from contextlib import contextmanager

    # Context manager to capture stdout
    @contextmanager
    def captured_output():
        new_out = StringIO()
        old_out = sys.stdout
        try:
            sys.stdout = new_out
            yield sys.stdout
        finally:
            sys.stdout = old_out

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    log_format = logging.Formatter("%(asctime)s %(levelname)-8s %(message)s")
    console_handler.setFormatter(log_format)


# Generated at 2022-06-12 14:45:53.248925
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        class MockTqdm():
            def __init__(self):
                self.messages = []
            def write(self, msg):
                self.messages.append(msg)

        x = _TqdmLoggingHandler(MockTqdm)
        x.emit(0)
        assert len(x.tqdm_class.messages) == 1 and len(x.tqdm_class.messages[0]) > 0
    except Exception as e:
        raise e


# Generated at 2022-06-12 14:45:58.265415
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:46:00.398021
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        LOG.info('test')
        LOG.debug('invisible')

# Generated at 2022-06-12 14:46:04.320737
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()

    from io import StringIO
    import sys

    sys.stderr = StringIO()  # redirect output to stderr
    assert handler.__class__.__module__ == 'tqdm.contrib.logging'
    handler.emit('foo')
    assert sys.stderr.getvalue() == 'foo'

# Generated at 2022-06-12 14:46:10.816281
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tqdm

    logger = logging.getLogger(__name__)
    log_count = 0
    try:
        with logging_redirect_tqdm():
            with tqdm.trange(1, ncols=25) as t:
                logger.info('foo')
                log_count += 1
                t.update(1)
                logger.info('bar')
                log_count += 1
                t.update(1)
            # check logging is restored
            logger.info('baz')
    except RuntimeError:
        # only raised if `tqdm` context still exists
        pass
    assert log_count == 2

# Generated at 2022-06-12 14:46:20.409534
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9) as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-12 14:46:28.319617
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .main import tqdm
    import logging

    with tqdm_logging_redirect(desc='test', loggers=[logging.getLogger('tqdm_contrib')],
                               logging_level=logging.DEBUG) as pbar:
        logging.getLogger('tqdm_contrib').debug('test')
        pbar.update()


with logging_redirect_tqdm(loggers=[logging.getLogger('tqdm')]):
    logging.getLogger('tqdm').debug('tqdm logging redirected to `std_tqdm.write()`')

# Generated at 2022-06-12 14:46:32.309698
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    # confirm that tqdm_logging_redirect redirects logging to tqdm.write
    log_message = "log_message"
    result = -1
    with tqdm_logging_redirect(total=1, desc="test_logging_redirect") as pbar:
        pbar.update(1)
        logging.info(log_message)
        result = len(pbar.desc)
    assert log_message in pbar.desc, \
        "logging_redirect_tqdm should redirect logs to tqdm.write"
    assert result == len(pbar.desc) - len(log_message), \
        "tqdm desc text should not be modified"



# Generated at 2022-06-12 14:46:37.346530
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit tests for function logging_redirect_tqdm()
    """
    from .assert_logging_redirect_tqdm import assert_logging_redirect_tqdm
    assert_logging_redirect_tqdm()

# Generated at 2022-06-12 14:46:46.032330
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import pretest_posttest  # pylint: disable=redefined-outer-name
    from .tests_tqdm import with_prog_bar
    from .tests_tqdm import _range
    from .tests_tqdm import closing
    from .tests_tqdm import StringIO

    @with_prog_bar(False)
    def test(capture_stdout=True):
        # type: (bool) -> str
        if capture_stdout:
            with closing(StringIO()) as our_file:
                with logging_redirect_tqdm():
                    with pretest_posttest(out=our_file):
                        for _ in _range(4):
                            logging.info("TEST")
                return our_file.getvalue()

# Generated at 2022-06-12 14:46:55.014574
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    def log_test():
        LOG.error("Testing error")
        LOG.warning("Testing warning")
        LOG.info("Testing info")
        LOG.debug("Testing debug")

    def no_log_test():
        logging.error("Testing error")
        logging.warning("Testing warning")
        logging.info("Testing info")
        logging.debug("Testing debug")

    with logging_redirect_tqdm():
        log_test()
        no_log_test()

    with logging_redirect_tqdm([LOG]):
        log_test()
        no_log_test()

    with tqdm_logging_redirect():
        log_test()
        no_log_test()

# Generated at 2022-06-12 14:47:04.243673
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """ Unit test for tqdm logging support. """
    import logging
    try:
        from unittest import mock
    except ImportError:
        import mock

    # Redirecting to tqdm.write() should have no effect if the message
    # level is not enabled.
    logging.basicConfig(level=logging.WARNING)
    with logging_redirect_tqdm():
        logger = logging.getLogger(__name__)
        with mock.patch('tqdm.tqdm.write') as mocked_write:
            logger.info("not displayed")
            assert mocked_write.call_count == 0

    # Logging messages at the level of logging.INFO or higher should go to
    # tqdm.write().
    with logging_redirect_tqdm():
        logger

# Generated at 2022-06-12 14:47:13.670169
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from logging import Logger
    from logging import StreamHandler
    from logging import basicConfig
    from logging import getLogger
    from logging import NullHandler
    from logging import StreamHandler
    from tempfile import TemporaryFile
    from tqdm import tqdm
    from tqdm import trange
    from .tqdm_pandas import tqdm_pandas
    from .tqdm_gui import tqdm_gui
    from .tqdm_notebook import tqdm_notebook

    # Test with custom logger
    loggers = [getLogger('TEST_LOGGER')]
    loggers[0].addHandler(NullHandler())
    # Capture logging messages via StringIO
    out = TemporaryFile()
    loggers[0].addHandler(StreamHandler(out))
    
    # Test with different tqdm

# Generated at 2022-06-12 14:47:20.727464
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    LOG.info("I will appear on stdout.")
    assert True
test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:23.734554
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm, trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:47:32.922944
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    def test_function(name):
        LOG = logging.getLogger(name)
        LOG.info("INFO! (%s)" % name)

    with tqdm_logging_redirect(sys.stderr, enabled=False) as pbar:
        test_function('test1')
        pbar.update(1)
        test_function('test2')
        pbar.update(1)
    test_function('test3')

# Generated at 2022-06-12 14:47:43.128364
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    # logging.raiseExceptions = False
    # logging.basicConfig(format='%(asctime)s:%(levelname)s:%(message)s', level=logging.INFO)

    with tqdm_logging_redirect(desc='This is a test', unit='foo', total=5, logging_format='%(message)s', loggers=[LOG],
                               tqdm_class=std_tqdm) as t:
        assert(t._desc == 'This is a test')
        LOG.info('info: %d', 1)
        LOG.info('info: %d', 2)
        LOG.warning('info: %d', 3)
        LOG.error('info: %d', 4)

# Generated at 2022-06-12 14:47:45.038105
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("Hello World")



# Generated at 2022-06-12 14:47:51.462929
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from . import tqdm
    logger = logging.getLogger()

    with tqdm.std_tqdm() as pbar:
        # Clean the logger
        logger.handlers = []

        with logging_redirect_tqdm():
            assert any(isinstance(h, _TqdmLoggingHandler) for h in logger.handlers)
            logging.info('hello')
            assert 'hello' in pbar.last_print_t

    # After the context manager, the logger has been restored
    assert not any(isinstance(h, _TqdmLoggingHandler) for h in logger.handlers)



# Generated at 2022-06-12 14:47:56.265279
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:48:05.056159
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging


# Generated at 2022-06-12 14:48:08.779068
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:48:13.899227
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import sys

    # Redirect stdout and stderr to a file
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    # Create a logging handler
    handler = _TqdmLoggingHandler()

    # Set the level of the logging handler
    handler.setLevel(logging.DEBUG)

    # Create a logger
    logger = logging.getLogger('tqdm_logger')

    # Set the level of the logger
    logger.setLevel(logging.DEBUG)

    # Create a formatter and add it to the logging handler
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)

    # Add the logging handler to the logger
    logger.addHandler(handler)

    # Create

# Generated at 2022-06-12 14:48:24.353492
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tempfile
    import shutil
    import logging
    from ..std import tqdm

    LOG = logging.getLogger(__name__)

    dir_name = tempfile.mkdtemp()
    logging.basicConfig(filename=dir_name + "/foo.log", level=logging.INFO)

# Generated at 2022-06-12 14:48:32.355045
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Unit test for function logging_redirect_tqdm
    """
    import logging
    logging.basicConfig(level=logging.INFO)

    log_str = "console logging redirected to `tqdm.write()`"

    with open('file_redirect_tqdm.txt', 'w') as f:
        with logging_redirect_tqdm():
            logging.info(log_str)

        logging.info(log_str)

        with tqdm_logging_redirect(file=f):
            logging.info(log_str)

    assert open('file_redirect_tqdm.txt').read().endswith(log_str + '\n')


if __name__ == "__main__":
    test_logging_redirect_t

# Generated at 2022-06-12 14:48:46.659417
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    assert True



# Generated at 2022-06-12 14:48:48.926374
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    log = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        log.info("Hello world!")

# Generated at 2022-06-12 14:48:55.133892
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import StringIO
    import logging
    import tqdm

    # Initialize a StringIO object
    out = StringIO.StringIO()

    # Initialize a handler using the StringIO object
    handler = _TqdmLoggingHandler()
    handler.stream = out

    # Initialize a typical logger
    logger = logging.getLogger(__name__)
    logger.propagate = False
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Write a simple log message
    logger.debug('test_emit')
    out.seek(0)

    # Initialize a tqdm object
    pbar = tqdm.tqdm(total=1, file=out)


    # Check that the logger output is indeed in the tqdm object
    pbar.update()
   

# Generated at 2022-06-12 14:49:03.478461
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.root]
    original_handlers_list = [logger.handlers for logger in loggers]
    with tqdm_logging_redirect("Passing_test") as pbar:
        for logger in loggers:
            tqdm_handler = _TqdmLoggingHandler(std_tqdm)
            orig_handler = _get_first_found_console_logging_handler(logger.handlers)
            if orig_handler is not None:
                tqdm_handler.setFormatter(orig_handler.formatter)
                tqdm_handler.stream = orig_handler.stream
            logger.handlers = [
                handler for handler in logger.handlers
                if not _is_console_logging_handler(handler)] + [tqdm_handler]
        assert p

# Generated at 2022-06-12 14:49:10.253153
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ._test_tqdm import _test_tqdm_logging_redirect
    _test_tqdm_logging_redirect(
        tqdm_class=std_tqdm,
        loggers=None,
        tqdm_kwargs={},
        pbar={'smoothing': 0},
    )



# Generated at 2022-06-12 14:49:13.163961
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:49:18.636819
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import itertools
    import logging
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in itertools.count():
            pbar.update(1)
            logging.info("test_tqdm_logging_redirect")
            assert i == pbar.n
            if i == 10:
                break

# Generated at 2022-06-12 14:49:20.868446
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:30.120631
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    original_stderr = sys.stderr
    sys.stderr = open('test.log', 'w')

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)


# Generated at 2022-06-12 14:49:32.929761
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    for i in tqdm_logging_redirect(4):
        LOG.info('Hello World!')
    LOG.info('Hello World!')

