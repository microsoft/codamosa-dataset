

# Generated at 2022-06-12 14:42:49.152419
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import tqdm
    try:
        from unittest import mock
    except ImportError:
        from unittest import mock
    logger = mock.Mock()
    logger.handlers = []
    with mock.patch('tqdm.contrib.logging.logging.root', logger):
        with logging_redirect_tqdm():
            assert len(logger.handlers) == 1
            assert isinstance(logger.handlers[0], _TqdmLoggingHandler)
            assert logger.handlers[0].tqdm_class == tqdm
        assert not logger.handlers


# Generated at 2022-06-12 14:42:57.116176
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..tqdm import trange
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from io import StringIO
    try:
        from unittest import mock
    except ImportError:
        import mock

    class _TqdmLoggingHandler(logging.StreamHandler):
        def __init__(self):
            super(_TqdmLoggingHandler, self).__init__()

        def emit(self, record):
            msg = self.format(record)
            std_tqdm.write(msg, file=self.stream)
            self.flush()

    class _TqdmLoggingHandlerTest(unittest.TestCase):
        loggers = [logging.root]

# Generated at 2022-06-12 14:43:06.034061
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from io import StringIO
    import logging
    from tqdm import trange
    from tqdm import tqdm as original_tqdm

    from .utils_logging import TqdmHandler

    LOG = logging.getLogger(__name__)

    # without redirect:
    s = StringIO()
    logging.basicConfig(level=logging.INFO, stream=s)
    original_tqdm.write('bla', file=s, end='')
    for i in trange(9, file=s):
        if i == 4:
            LOG.info("bla")
    assert s.getvalue() == 'bla\nbla\n'
    s.close()

    # with redirect:
    s = StringIO()

# Generated at 2022-06-12 14:43:11.100752
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from time import time
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in range(10):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
            time.sleep(0.5)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:43:16.716810
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from .tqdm_test_cases import TestBasic, TestMixin
    import io
    import logging
    import tqdm.contrib.logging


# Generated at 2022-06-12 14:43:22.407249
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(
            desc='test_tqdm_logging_redirect',
            disable=False,
    ) as pbar:
        pbar.update(10)
        LOG = logging.getLogger(__name__)
        LOG.info("test logging interop")
        pbar.update(10)
    logging.shutdown()

# Generated at 2022-06-12 14:43:30.890382
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Test emit method of class _TqdmLoggingHandler
    """
    msg = 'Test logging message'
    tlh = _TqdmLoggingHandler()
    assert getattr(tlh.tqdm_class, '_instances', None) is None
    tlh.emit(logging.makeLogRecord({'msg': msg}))
    # Checking parent class emit is called
    assert hasattr(tlh.tqdm_class, '_instances')
    assert tlh.tqdm_class._instances
    assert tlh.tqdm_class._instances[0]._file.getvalue() == msg + "\n"
    tlh.tqdm_class.write = lambda msg, file: file.write(msg + '\n')

# Generated at 2022-06-12 14:43:35.225597
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Enable logging to console in current context
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    assert handler.stream == sys.stderr
    logger.info("Should be printed from logging.")

    # Enable tqdm's write to console in current context
    with logging_redirect_tqdm(tqdm_class=tqdm):
        logger.info("Should be printed from tqdm.write().")

    # Disable logging to console in current context
    logger.removeHandler(handler)
    logger.info("Should not be printed anymore.")

# Generated at 2022-06-12 14:43:40.521824
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.autonotebook import tqdm

    log = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:43:49.041155
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    # Test with loggers argument
    my_loggers = [logging.root]
    with logging_redirect_tqdm(loggers=my_loggers):
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to tqdm.write()")
    # logging restored

    # Test without loggers argument
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to tqdm.write()")
    # logging restored

    # Test with custom formatter

# Generated at 2022-06-12 14:44:04.917241
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from six import StringIO
    from tqdm import tqdm
    from logging import DEBUG, getLogger, StreamHandler, Formatter

    string_stream = StringIO()
    # Create stream handler attached to the string stream
    stream_handler = StreamHandler(string_stream)
    # Create formatter for the stream handler
    stream_handler_formatter = Formatter('%(message)s')
    stream_handler.setFormatter(stream_handler_formatter)

    logging_handler = _TqdmLoggingHandler()
    logging_handler.setFormatter(stream_handler_formatter)

    blank_line = '\n'
    log_message = 'Text'

    # The goal here is simply to assert that something gets written to
    # the stream by _TqdmLoggingHandler, and that the formatting is correct.
    #

# Generated at 2022-06-12 14:44:10.406530
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect(total=10, bar_format='{desc}') as pbar:
        for i in range(10):
            time.sleep(0.1)
            LOG.info('info')
            pbar.update()

# Generated at 2022-06-12 14:44:16.059998
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    LOG.info("out of function logging")

    with tqdm_logging_redirect() as pbar:
        LOG.info("in function logging")
        for _ in range(9):
            if _ == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
        pbar.update()
    # logging restored
    LOG.info("out of function logging")


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:44:21.705370
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import time
    import sys
    import tqdm._tqdm_gui as _tqdm_gui  # pylint: disable=import-error

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        def do_test():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        with logging_redirect_tqdm():
            do_test()
        # logging restored
        with logging_redirect_tqdm(loggers=[LOG], tqdm_class=_tqdm_gui.tqdm):
            do_test()
        # logging restored

# Generated at 2022-06-12 14:44:33.671516
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logger = logging.getLogger("test_tqdm_logging_redirect")
    logger.setLevel(logging.DEBUG)

    # restore if _module_state.default_gui on import
    default_gui_on_import = tqdm._module_state.default_gui
    tqdm._module_state.default_gui = False
    default_gui_on_tqdm_logging_redirect = tqdm._module_state.default_gui

    default_gui_on_constructor = tqdm.tqdm.default_gui
    tqdm.tqdm.default_gui = False
    default_gui_on_tqdm_logging_redirect_constructor = tqdm.tqdm.default_gui


# Generated at 2022-06-12 14:44:42.008798
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    def _test_unit():
        root_logger = logging.getLogger()

        # Ensure logging redirection is working
        before_handlers = root_logger.handlers
        with logging_redirect_tqdm():
            root_logger.warning("Test logging redirection")
        after_handlers = root_logger.handlers
        assert before_handlers != after_handlers

        # Ensure logging redirection is reverted
        with logging_redirect_tqdm():
            root_logger.warning("Test logging redirection")
        after_handlers = root_logger.handlers
        assert before_handlers == after_handlers

    # The `logging_redirect_tqdm` context manager is only called
    # when the `with` statement is entered; therefore, we run this
   

# Generated at 2022-06-12 14:44:44.796536
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord('name', logging.INFO, 'pathname', 1, 'Message', None, None)
    handler.emit(record)

# Generated at 2022-06-12 14:44:52.616222
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def main(tqdm):
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

    test_tqdm_class(main, tqdm_cls=std_tqdm,
                    leave=None, desc="test_logging_redirect_tqdm")

# Generated at 2022-06-12 14:44:57.277967
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect() as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:01.555374
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(5):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:16.575593
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.DEBUG)
    with tqdm_logging_redirect(total=1, leave=False) as pbar:
        logging.debug('test')
        assert pbar._instances  # pylint: disable=protected-access

# Generated at 2022-06-12 14:45:18.563169
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    LOG = logging.getLogger(__name__)
    LOG.setLevel('DEBUG')

    with logging_redirect_tqdm([LOG]):
        LOG.debug('logging was redirected to `tqdm.write()`')
    # logging restored

# Generated at 2022-06-12 14:45:24.870543
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import os
    import sys
    import unittest
    import warnings

    from ..standard_lib import StringIO

    CAPTURE_STREAMS = [sys.stdout, sys.stderr]

    class TestLoggingRedirect(unittest.TestCase):
        # TODO(wgiersche): Migrate to pytest
        def setUp(self):
            self.logger = logging.getLogger('TestLoggingRedirect')
            self.captures = {stream: StringIO() for stream in CAPTURE_STREAMS}
            self.handler = logging.StreamHandler(
                {
                    sys.stdout: self.captures[sys.stdout],
                    sys.stderr: self.captures[sys.stderr],
                }[sys.stdout])

# Generated at 2022-06-12 14:45:29.050228
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    with tqdm_logging_redirect(total=1000):
        for _ in range(1000):
            logging.info('testing')
            time.sleep(0.001)

# Generated at 2022-06-12 14:45:35.811014
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:45.565489
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import os
    import warnings
    warnings.simplefilter('ignore', ResourceWarning)
    # Change directory to the project root
    os.chdir('..')
    # Change directory to the test folder
    os.chdir('tests')
    # Create a test file
    with open('log_test.log', 'w') as file:
        pass
    # Test that tqdm_logging_redirect creates the same output with & without tqdm_logging_redirect
    logger = logging.getLogger()
    logger.propagate = False
    logger.setLevel(1)
    handler = logging.FileHandler('log_test.log')
    logger.addHandler(handler)
    for i in range(5):
        log_file = open('log_test.log', 'r')
        original = log_

# Generated at 2022-06-12 14:45:53.723848
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .tqdm_test_cases import range_, closing, string_io, unicode
    from .tqdm_test_cases import get_monitorable_stdout, get_monitorable_stderr
    from .tqdm_test_cases import pretest_posttest  # NOQA
    from logging import basicConfig, INFO, getLogger

    log_test = getLogger("test")
    log_test.setLevel(INFO)

    with closing(string_io()) as our_file, get_monitorable_stdout() as s:
        with tqdm_logging_redirect(our_file, desc=unicode, total=9):
            log_test.info("console logging redirected to `tqdm.write()`")
            for _ in range_(9):
                pass

# Generated at 2022-06-12 14:45:58.851675
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(loggers=[LOG], msg='testing', file=sys.stdout) as pbar:
        LOG.info("console logging redirected to `tqdm.write()`")
        assert len(pbar) == 0
        pbar.update(1)
        assert len(pbar) == 1



# Generated at 2022-06-12 14:46:06.439480
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from .logging_redirect_tqdm import logging_redirect_tqdm, _TqdmLoggingHandler
    from .logging_redirect_tqdm import _get_first_found_console_logging_handler
    from .logging_redirect_tqdm import _is_console_logging_handler

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:46:10.961111
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
    assert pbar.n == 9



# Generated at 2022-06-12 14:46:34.148782
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    from .tqdm_logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(desc='Some desc', logger=LOG, leave=True) as pbar:
        for i in pbar(range(5)):
            if i == 4:
                LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:46:44.995040
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from nose.tools import assert_equal, assert_true
    from logging import getLogger, basicConfig, INFO

    log = getLogger(__name__); log.setLevel(INFO)

    try:
        import unittest.mock as mock
        from io import StringIO
        from tqdm import tqdm

        progress_bar_mock = mock.Mock(name='bar')
    except (ImportError, TypeError):
        import mock
        from io import BytesIO as StringIO
        from tqdm import tqdm

        progress_bar_mock = mock.Mock(name='bar')

    def test_logging(output_str=None, desc=None):
        log.info('Input value =')
        log.info('%d', 10)
        log.info('%d', 50)


# Generated at 2022-06-12 14:46:49.836907
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:46:59.207056
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    from tqdm.autonotebook import tqdm as tqdm_class

    with mock.patch.object(tqdm_class, 'write') as write:
        with mock.patch.object(tqdm_class, '_instances', {}):
            with tqdm_logging_redirect(
                iterable=range(3), desc='foo', tqdm_class=tqdm_class,
                loggers=[logging.getLogger(__name__)]) as pbar:
                assert pbar.desc == 'foo'
                logging.info('bar')
                assert pbar.desc == 'foo'
                pbar.n = 1
                logging.info('baz')
                assert pbar

# Generated at 2022-06-12 14:47:02.881146
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(filename='report.log', filemode='w')
    with logging_redirect_tqdm():
        logging.info('test logging')

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:12.775589
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None

    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm.auto import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)

        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:47:17.846899
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    logging_format = '%(levelname)s: %(message)s'
    logging.basicConfig(format=logging_format)
    with tqdm_logging_redirect(total=2, unit='test',
                               loggers=[logging.root]) as pbar:
        assert pbar.total == 2
        pbar.update(1)
        logging.info('hello')

# Generated at 2022-06-12 14:47:25.665164
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    This test will only be run if the following conditions are met:
    - If a logger named `tqdm.contrib.logging_test` is defined
    - If a log_file named tqdm_contrib_logging_test_log.txt
    """
    from pathlib import Path
    import logging

    log_file = Path(__file__).parent / 'tqdm_contrib_logging_test_log.txt'
    log_file.unlink(missing_ok=True)
    test_logger = logging.getLogger('tqdm.contrib.logging_test')
    logging_handler = logging.FileHandler(str(log_file))
    logging_handler.setLevel(logging.DEBUG)
    test_logger.setLevel(logging.DEBUG)

# Generated at 2022-06-12 14:47:31.639281
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    import sys
    from contextlib import redirect_stdout
    from io import StringIO
    from _64_bit_workaround import _64BitWorkaround

    handler = _TqdmLoggingHandler()

    # Set a string buffer as the handler stream and redirect stdout
    stream = StringIO()
    handler.stream = stream
    with redirect_stdout(stream):
        # Set up a record
        record = logging.LogRecord(
            name='test',
            level=logging.DEBUG,
            pathname='test.py',
            lineno=1,
            msg='This is a test',
            args=(),
            exc_info=None)
        # Emit the record
        handler.emit(record)

    # The string buffer now contains the formatted message

# Generated at 2022-06-12 14:47:35.863090
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    import io

    class TqdmMock(tqdm.tqdm):
        def __init__(self, *args, **kwargs):
            super(TqdmMock, self).__init__(*args, **kwargs)
            self.out = io.StringIO()
            self.bar_format = ''

    f = io.StringI

# Generated at 2022-06-12 14:48:22.289412
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(unit='units', miniters=10):
        for i in range(10, 30, 10):
            LOG.info('console logging redirected to `tqdm.write()`')
            assert len(tqdm.tqdm.instances) == 1

    # logging restored
    assert not len(tqdm.tqdm.instances)



# Generated at 2022-06-12 14:48:30.773686
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from . import tgr
    import time
    import random
    import logging
    logging.basicConfig()
    log = logging.getLogger(__name__)
    print("\n"
          "Check if logging messages are written to tqdm output, "
          "with standard logging configuration\n")
    with tgr(loggers=log, ascii=True):
        for _ in tgr():
            log.info("info message")
        for i in tgr(list(range(3))):
            time.sleep(random.random())
            log.info("info message {}".format(i))
        time.sleep(random.random())
    print("\n"
          "Check if logging messages are written to tqdm output and "
          "logging file, with standard logging configuration\n")

# Generated at 2022-06-12 14:48:36.545163
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock  # type: ignore
    mock_logger = MagicMock()
    mock_logger.handlers = []
    mock_handler = MagicMock()
    mock_handler.stream = sys.stdout
    mock_logger.handlers.append(mock_handler)

    mock_stderr_handler = MagicMock()
    mock_stderr_handler.stream = sys.stderr
    mock_logger.handlers.append(mock_stderr_handler)

    with logging_redirect_tqdm(loggers=[mock_logger]):
        assert len(mock_logger.handlers) == 1



# Generated at 2022-06-12 14:48:41.612254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from .tqdm import trange
    from .logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9, desc=''):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:48:48.624587
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tpbar
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    i = 0
    try:
        with logging_redirect_tqdm([logging.getLogger()], tqdm_class=tpbar):
            for k in tpbar(range(9), desc="logging"):
                if k == 4:
                    logging.info("console logging redirected to `tqdm.write()`")
                i += k
    except SystemExit:
        pass
    return i == 98



# Generated at 2022-06-12 14:48:53.278044
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test for function test_logging_redirect_tqdm.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm([logger]):
        for i in trange(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:02.238178
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    _logger = logging.getLogger('tqdm_logging_redirect')
    _logger.propagate = False
    _logger.setLevel(logging.DEBUG)
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter('%(name)s:%(levelname)s: %(message)s'))
    _logger.addHandler(_handler)

    with tqdm_logging_redirect(
        desc='test',
        total=10,
        bar_format='- |{desc}| {percentage:3.0f}%',
        loggers=[_logger],
    ) as pbar:
        for _ in range(10):
            _logger.debug('logging test')
            pbar.update(1)

# Generated at 2022-06-12 14:49:10.768064
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tnrange, tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tnrange(9, desc='test_logging_redirect_tqdm'):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:49:14.428489
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for logging_redirect_tqdm"""
    import logging
    from tqdm import trange

    log = logging.getLogger('test_logging_redirect_tqdm')
    log.setLevel(logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(10):
            log.info('test_logging_redirect_tqdm %d', i)



# Generated at 2022-06-12 14:49:18.194955
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10) as pbar:
        assert isinstance(pbar, std_tqdm)
        LOG = logging.getLogger(__name__)
        LOG.info('test')

# Generated at 2022-06-12 14:50:41.240494
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    test_logging_redirect_tqdm()

    Tests the context manager logging_redirect_tqdm.
    """
    logging.basicConfig(level=logging.INFO)

    log = logging.getLogger("mylogger")
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                log.error("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:46.745264
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        logger.info(1)
        time.sleep(2)
        logger.info(2)
        time.sleep(2)
        logger.info(3)
        time.sleep(2)
        logger.info(4)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:50:57.185958
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    from tqdm.contrib import tgrange  # noqa: F401

    import logging
    LOG = logging.getLogger('test_logging_redirect_tqdm')

    def test(with_tgrange=False):
        try:
            with logging_redirect_tqdm():
                for i in (tgrange if with_tgrange else tqdm)(range(4)):
                    if i == 1:
                        LOG.info('console logging redirected to `tqdm.write()`')
                    elif i == 2:
                        LOG.error('console logging redirected to `tqdm.write()`')
                    elif i == 3:
                        LOG.debug('debugging messages')
        except KeyboardInterrupt:
            pass

    # Test tqdm
   

# Generated at 2022-06-12 14:51:04.421679
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    log = logging.getLogger('MyLogger')
    log.setLevel(logging.INFO)
    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    log.addHandler(ch)

    log.info('foo')

    with tqdm_logging_redirect():
        time.sleep(0.2)
        log

# Generated at 2022-06-12 14:51:09.273030
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    from ..utils import _term_move_up
    try:
        from unittest.mock import patch  # py3
    except ImportError:
        from mock import patch  # py2

    def test_emit(record, stdout, tqdm_stdout):
        obj = _TqdmLoggingHandler(tqdm_class=_TqdmLoggingHandler.tqdm_class)
        obj.stream = stdout
        with patch('tqdm.std.tqdm.write') as mock_tqdm_write:
            obj.emit(record)
            mock_tqdm_write.assert_called_with(
                'My msg', file=tqdm_stdout)


# Generated at 2022-06-12 14:51:14.873471
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:51:24.581881
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.utils import _term_move_up

    loggers = [logging.getLogger('test_log')]
    for logger in loggers:
        logger.setLevel(logging.INFO)
        logger.handlers = []
        logger.addHandler(logging.StreamHandler())
        logger.propagate = False

    logging.getLogger('test_log').info('test line 1')

    with tqdm_logging_redirect(
            total=None,
            file=sys.stderr,
            bar_format='{l_bar}{bar}|',
            loggers=loggers,
    ) as pbar:
        logging.getLogger('test_log').info('test line 2')
        pbar.set_description('test line 2\n')
        pbar.set_description

# Generated at 2022-06-12 14:51:31.233764
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from time import sleep
    from logging import getLogger
    from tqdm.contrib.logging import (
        tqdm_logging_redirect,
        _TqdmLoggingHandler,
        logging_redirect_tqdm)
    LOG = getLogger(__name__)
    with tqdm_logging_redirect():
        for i in range(10):
            sleep(0.1)
            LOG.info(i)
    with tqdm_logging_redirect(loggers=[LOG]):
        for i in range(10):
            sleep(0.1)
            LOG.info(i)

# Generated at 2022-06-12 14:51:40.430258
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import _range, formatted_timer
    from .main import tqdm
    from .std import tqdm as std_tqdm  # pylint: disable=c-extension-no-member
    from io import StringIO
    import logging
    import time

    try:
        from unittest.mock import patch  # py3
    except ImportError:
        from mock import patch  # py2

    # quiet tqdm
    old_format = tqdm.format_interval
    tqdm.format_interval = formatted_timer
    logging_stream = StringIO()

# Generated at 2022-06-12 14:51:46.935020
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Construct the simplest logger possible and redirect its output to
    a tqdm progress bar with tqdm_logging_redirect.
    """
    logger = logging.getLogger()
    logger.setLevel(logging.NOTSET)
    logger.addHandler(logging.StreamHandler())
    logger.warning('log message before redirect')

    with tqdm_logging_redirect('redirected output') as pbar:
        logger.warning('log message in redirect')

    logger.warning('log message after redirect')

    message = pbar.format_dict["n"]
    assert "before redirect" not in message
    assert "in redirect" in message
    assert "after redirect" not in message

