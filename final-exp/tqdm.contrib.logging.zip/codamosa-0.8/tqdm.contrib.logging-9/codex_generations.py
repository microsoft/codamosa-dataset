

# Generated at 2022-06-12 14:42:36.563382
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Tests the logging_redirect_tqdm() function context manager.
    """
    import logging
    from tqdm._utils import _term_move_up

    _term_move_up()
    logging.basicConfig(format='[%(levelname)s] %(message)s',
                        level=logging.INFO)
    log = logging.getLogger(__name__)
    # logging_redirect_tqdm()
    with logging_redirect_tqdm():
        log.info('Logging redirected to tqdm.write()')
    # logging_redirect_tqdm(loggers=[log])
    with logging_redirect_tqdm(loggers=[log]):
        log.info('Logging redirected to tqdm.write()')
    # logging_redirect_tq

# Generated at 2022-06-12 14:42:39.652735
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    logger = logging.Logger(__name__)
    tqdm_handler = _TqdmLoggingHandler()
    tqdm_handler.setFormatter(logging.Formatter())
    logger.addHandler(tqdm_handler)
    logger.error("str")

# Generated at 2022-06-12 14:42:44.671304
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:42:48.334104
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    print("logging restored")



# Generated at 2022-06-12 14:42:56.404676
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    import tempfile
    from tqdm.auto import tqdm

    captured_output = io.StringIO()  # To capture standard output

    # Assume logging level is INFO
    LOG = logging.getLogger("test_tqdm_logging_redirect")

    # To suppress output, we change the level of the logging engine to WARNING
    logging.getLogger().setLevel(logging.WARNING)

    # Redirect stdout to the io stream
    sys.stdout = captured_output

# Generated at 2022-06-12 14:43:02.907189
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Unit test

    Console logging is the default handler for the root logger.
    This handler is expected to be redirected to write to stdout.
    """
    import logging
    import tqdm
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        with tqdm.std.tqdm() as pbar:
            with logging_redirect_tqdm(tqdm_class=tqdm.std.tqdm):
                LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:43:09.327819
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # the purpose of the test is to verify that the context manager
    # does not break the python logging system.
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger()

    c_handler = logging.StreamHandler()
    c_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(levelname)s: %(message)s')
    c_handler.setFormatter(formatter)
    logger.addHandler(c_handler)

    with tqdm_logging_redirect():
        logger.info('test message')

# Generated at 2022-06-12 14:43:15.696713
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = []

    try:
        with logging_redirect_tqdm():
            pass
    except Exception as e:
        assert "no loggers given" in str(e)

    try:
        with logging_redirect_tqdm(loggers=loggers):
            pass
    except Exception as e:
        assert "no loggers given" in str(e)

    # Following code is used for pytest tests

    # import logging
    # from tqdm import trange
    # from tqdm.contrib.logging import logging_redirect_tqdm

    # LOG = logging.getLogger(__name__)
    # loggers.append(LOG)
    # logging.basicConfig(level=logging.INFO)
    # with logging_redirect_tqdm(loggers=loggers):


# Generated at 2022-06-12 14:43:24.600670
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    # logging function
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    for i in range(5):
        LOG.info(i)
    with logging_redirect_tqdm():
        for i in range(5, 10):
            LOG.info(i)
    for i in range(10, 15):
        LOG.info(i)
    # tqdm function
    with tqdm_logging_redirect(
        total=10,
        desc="hello world, tqdm logging redirect works",
        dynamic_ncols=True,
        loggers=[LOG]
    ) as pbar:
        for i in range(10):
            pbar.update(1)

# Generated at 2022-06-12 14:43:32.765412
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # import logging
    import random
    # from tqdm import tqdm
    # from tqdm.contrib.logging import (
    #     logging_redirect_tqdm, tqdm_logging_redirect)
    from .tests_tqdm import StringIO, with_setup

    old_sysout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-12 14:43:48.696465
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from pytest import raises
    from pytest import set_trace as bp
    from tqdm import tqdm, trange

    log = logging.getLogger('')
    log.handlers = []
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler())

    # test class-based tqdm
    with tqdm_logging_redirect(total=10, loggers=[log]) as pbar:
        for i in trange(5):
            log.debug("logging redirected to `tqdm.write()`")
        pbar.update(5)

    # test function-based tqdm

# Generated at 2022-06-12 14:43:54.518458
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import mock
    import six
    with mock.patch('tqdm.contrib.logging.logging_redirect_tqdm') as p1, \
            mock.patch('tqdm.contrib.logging.std_tqdm') as p2:

        fake_pbar = six.next(six.moves.zip(['a', 'b', 'c'], ['d', 'e', 'f']))
        fake_handler = p2.return_value

        fake_handler.__enter__.return_value = fake_pbar

        with tqdm_logging_redirect() as pbar:
            assert pbar == ('a', 'd')
        assert p1.call_count == 1
        assert p2.call_count == 1
        assert p2.call_args == mock

# Generated at 2022-06-12 14:43:55.883751
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=1) as pbar:
        assert pbar.n == 1

# Generated at 2022-06-12 14:44:02.450853
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:44:08.056985
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    import logging
    from contextlib import redirect_stdout
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler())
    logger.setLevel(logging.INFO)

    logFile = StringIO()
    with redirect_stdout(logFile):
        logger.info('testing')

    logFile.seek(0)
    output = logFile.read()
    assert output == 'testing\n'

# Generated at 2022-06-12 14:44:12.014494
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    loggy = logging.getLogger('test')
    with logging_redirect_tqdm([loggy]):
        loggy.info('foo')
        with tqdm(total=1) as pbar:
            pbar.update()
        loggy.info('bar')

# Generated at 2022-06-12 14:44:17.787749
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import tqdm
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    with tqdm_logging_redirect(
            total=10,
            desc=__name__,
            disable=False,
            unit='i',
            leave=False,
            miniters=1,
            loggers=[logger],
            tqdm_class=tqdm
    ) as pbar:
        pbar.update(2)
        logger.info('Tqdm logging redirect should work')
        pbar.update(8)



# Generated at 2022-06-12 14:44:20.569610
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=5, desc="logging stdout",
                               file=sys.stdout) as pbar:
        for i in range(5):
            pbar.update()
            logging.info(i)

if __name__ == "__main__":
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:44:32.035206
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm._utils import _term_move_up
    from tqdm.std import tqdm
    from logging import root

    with tqdm_logging_redirect(total=1, desc="testing...") as p:
        for _ in range(1):
            root.info("This is a console log.")
            root.info("And this one too.")
        assert p.n == 1
        p.set_description("finished! :)")

    assert p.desc is None
    assert p.n == 1
    with tqdm.tqdm(total=1) as p:
        root.info("This is a console log.")
        root.info("And this one too.")
        assert p.n == 0
        assert p.desc == '                                                 '
        assert p.file.closed is False
        p

# Generated at 2022-06-12 14:44:40.267070
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    class logger(logging.Logger):
        formatted_message = None

        def _log(self, level, msg, args, exc_info=None, extra=None):
            self.formatted_message = super(logger, self).format(msg, args, extra)

    from tqdm import tqdm_notebook as tqdm_class  # noqa pylint: disable=unused-variable
    LOG = logger("test_logging_redirect_tqdm")
    with logging_redirect_tqdm([LOG], tqdm_class):
        LOG.info("logging to tqdm")
    assert LOG.formatted_message == "logging to tqdm"



# Generated at 2022-06-12 14:44:53.311253
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    import logging
    from .tqdm import tqdm

    class FakeTqdm(object):

        def __init__(self):
            self.msgs = []

        def write(self, msg):
            self.msgs.append(msg)

    faketqdm = FakeTqdm()

    with logging_redirect_tqdm(tqdm_class=faketqdm):
        logging.info('Test')
        time.sleep(1)

    assert len(faketqdm.msgs) == 2
    assert faketqdm.msgs[0].endswith(': Test')
    assert faketqdm.msgs[1].endswith('100%|##########| 1/1')

    logger = logging.getLogger(__name__)
   

# Generated at 2022-06-12 14:44:56.998222
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:45:02.583873
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Test for the tqdm_logging_redirect context manager."""
    import logging
    import unittest2
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class TestTqdmLoggingRedirect(unittest2.TestCase):
        """Class to test the tqdm_logging_redirect context manager."""

        def test_tqdm_logging_redirect(self):
            """Test tqdm_logging_redirect."""
            console = StringIO()

            with tqdm_logging_redirect(file=console):
                logging.warning('test')

            self.assertEqual(console.getvalue().strip(),
                             "WARNING:root:test")


# Generated at 2022-06-12 14:45:10.189309
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:45:20.351047
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from inspect import currentframe, getfile
    from os.path import abspath, dirname, join


# Generated at 2022-06-12 14:45:31.740385
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import shutil
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def temp_text_file(contents=""):
        with tempfile.NamedTemporaryFile(mode='w+') as f:
            f.write(contents)
            f.flush()
            yield f

    # Unit test for function tqdm_logging_redirect
    with temp_text_file() as log_file:
        LOG = logging.getLogger(__name__)
        logging.basicConfig(filename=log_file.name, level=logging.INFO)

# Generated at 2022-06-12 14:45:36.600711
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    original_handlers = LOG.handlers[:]

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    assert LOG.handlers == original_handlers



# Generated at 2022-06-12 14:45:46.369176
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import contextmanager
    from tempfile import TemporaryFile
    from .tqdm import tqdm, tqdm_gui, trange
    import logging
    import sys
    import time

    log = logging.getLogger('main.logging_redirect_tqdm')
    logging.basicConfig(level=logging.WARNING)

    @contextmanager
    def redirect(file_path):
        # type: (str) -> Generator[None, None]
        sys.stdout.flush()
        tfile = open(file_path, 'a')
        tfile_stream = tfile.fileno()
        old = os.dup(1)
        os.dup2(tfile_stream, 1)
        try:
            yield
        finally:
            sys.stdout.flush()
            os.du

# Generated at 2022-06-12 14:45:54.281582
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    with tqdm_logging_redirect(ascii=True) as pbar:
        logging.info("hello world")
        logging.info("hello world 2")

    print(pbar)  # doctest: +ELLIPSIS
    assert pbar.n == 2
    assert str(pbar) == "[2]: |hello world|hello world 2|"

    with tqdm_logging_redirect(ascii=True, loggers=[logging.getLogger('A')],
                               desc="foobar") as pbar:
        logging.getLogger('A').info("hello world")
        logging.getLogger('A').info("hello world 2")
        logging.getLogger('B').info("hello world")  # hidden by loggers

    print(pbar)  # doctest:

# Generated at 2022-06-12 14:46:02.907809
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.tests import IS_PYTHON, IS_WIN
    if IS_PYTHON:
        from ..tests.py2_3 import Mock, call

    logger = logging.getLogger(__name__)
    try:
        logger_handler = logger.handlers[0]
        logger_handler.stream = sys.stdout
    except IndexError:
        logger_handler = logging.StreamHandler(sys.stdout)
        logger.addHandler(logger_handler)

    def mock_write(s, **kwargs):
        logger_handler.stream = sys.stderr
        logger.info('tqdm_logging_redirect redirects logging to tqdm write.')


# Generated at 2022-06-12 14:46:23.375949
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect."""
    # setup
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    mock_logging_redirect = mock.MagicMock()
    mock_tqdm = mock.MagicMock()
    mock_tqdm.return_value.__enter__.return_value = mock_tqdm
    mock_tqdm.return_value.__exit__.return_value = False

    # run
    with tqdm_logging_redirect(1, 2, 3, tqdm_class=mock_tqdm, loggers=[1, 2, 3],
                               do_this=4) as pbar:
        pass

    # tests
    mock_tqdm.assert_called_

# Generated at 2022-06-12 14:46:29.200334
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from logging import Logger

    loggers = [logging.getLogger('logger1'), logging.getLogger('logger2')]
    with tqdm_logging_redirect(
            ascii=True, desc='tqdm logging redirect test',
            loggers=loggers):
        for logger in loggers:
            logger.info('logger test message')


if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:46:33.444334
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:46:42.845108
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored
        for i in trange(9):
            if i == 4:
                LOG.info("console logging restored")


# Generated at 2022-06-12 14:46:47.040054
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect.
    """
    LOG = logging.getLogger(__name__)
    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:46:56.463510
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Test for logging_redirect_tqdm.
    """
    from .tests_tqdm import with_setup, _range, StringIO
    from .utils import FakeTqdmDeprecationWarning, _deprecate_kwarg_only

    def _test_logging_redirect_tqdm_core(
            loggers=None,
            tqdm_class=std_tqdm):
        # type: (Optional[List[logging.Logger]], Type[std_tqdm]) -> None
        if loggers is None:
            loggers = [logging.root]
        original_handlers_list = [logger.handlers for logger in loggers]

# Generated at 2022-06-12 14:47:01.690588
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        for i in trange(9):
            if i == 4:
                with tqdm_logging_redirect():
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:47:03.658408
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect() as pbar:
        pass
    assert pbar  # pylint: disable=unused-variable

# Generated at 2022-06-12 14:47:11.565733
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    >>> LOG.info("test")
    test
    """
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        LOG.info("test")
    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info("test")
    with tqdm_logging_redirect(loggers=[LOG]):
        LOG.info("test")


if __name__ == '__main__':
    import doctest
    LOG = logging.getLogger(__name__)
    doctest.testmod()

# Generated at 2022-06-12 14:47:20.838634
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from test_tqdm import with_setup, pretest, posttest

    def setup():
        logging.basicConfig(level=logging.INFO)

    @with_setup(pretest, posttest)
    @with_setup(setup)
    def _test_logging_redirect_tqdm():
        LOG = logging.getLogger(__name__)
        from io import StringIO
        buf = StringIO()
        with tqdm_logging_redirect(buf, total=9, logging_format="{message}"):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        assert buf.getvalue() == 'console logging redirected to `tqdm.write()`\n'

    _test_log

# Generated at 2022-06-12 14:47:46.157568
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """
    Test logging_redirect_tqdm function
    """
    import logging
    import mock
    import sys

    logging.basicConfig(level=logging.INFO)
    with mock.patch.object(sys, 'stdout') as mocked:
        with logging_redirect_tqdm():
            logging.info('hello world')
            std_tqdm.write('console logging redirected to `tqdm.write()`')

        assert mocked.write.call_args_list == [
            mock.call('hello world\n'),
            mock.call('console logging redirected to `tqdm.write()`\n')]

# Generated at 2022-06-12 14:47:54.198571
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import trange
    from .logging import _TqdmLoggingHandler

    total = 100
    desc = "test_desc"
    content = "test_content"

    logging.basicConfig()

    logger = logging.getLogger(__name__)
    handler = _TqdmLoggingHandler()
    logger.addHandler(handler)

    # case 1: tqdm bar is not initialized
    logger.info(content)

    # case 2: tqdm bar initialized
    for _ in trange(total, desc=desc):
        logger.info(content)

    # case 3: tqdm bar initialized and set position
    handler.tqdm_class.set_position(1, 1)
    logger.info(content)

    # case 4: tqdm bar initialized, set position, and set total

# Generated at 2022-06-12 14:47:59.814011
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    try:
        from StringIO import StringIO  # python 2
    except ImportError:
        from io import StringIO

    # Create a logger and a console handler (default behavior)
    logger = logging.getLogger(__name__)
    logger.handlers = [logging.StreamHandler(sys.stdout)]
    logger.setLevel(logging.DEBUG)

    # Create a StringIO object
    output = StringIO()

    # Monkey patch sys.stdout (only for this test).
    # This way, we can run the test without
    # having a output on the console.
    sys.stdout = output

    with tqdm_logging_redirect(total=9):
        for i in trange(9):
            print(i)

# Generated at 2022-06-12 14:48:05.874826
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    logger = logging.getLogger()
    original_handlers_list = logger.handlers
    try:
        with logging_redirect_tqdm() as pbar:
            for i in pbar(range(5)):
                LOG.info("hello")
    except KeyboardInterrupt:  # pragma: no cover
        pass
    logger.handlers = original_handlers_list



# Generated at 2022-06-12 14:48:12.040999
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import tempfile
    f_ref = tempfile.NamedTemporaryFile(suffix='.ref')
    f_ref.write(b"ok")
    logging.basicConfig(level=logging.DEBUG, filename=f_ref.name)
    log = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in range(4):
            log.info("i=%s" % i)
        log.info("console logging redirected to `tqdm.write()`")
    assert f_ref.read().decode().strip() == \
        "INFO:__main__:console logging redirected to `tqdm.write()`"



# Generated at 2022-06-12 14:48:22.704749
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from unittest import TestCase, main
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    class TestTqdmLoggingRedirect(TestCase):
        def test_tqdm_logging_redirect(self):
            from tqdm import trange
            from tqdm import tqdm_notebook
            import logging
            LOG = logging.getLogger(__name__)
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for _ in trange(9):
                    LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:48:31.084703
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    loggers = [logging.getLogger(__name__)]
    original_handlers_list = [logger.handlers for logger in loggers]
    def count_handlers():
        """Return the number of StreamHandlers in the loggers"""
        return sum(1 for logger in loggers
                   for handler in logger.handlers
                   if isinstance(handler, _TqdmLoggingHandler))
    logging.basicConfig(level=logging.DEBUG)
    # Iterate twice to check that context manager is idempotent
    for _ in range(2):
        assert count_handlers() == 0
        with logging_redirect_tqdm(loggers=loggers):
            assert count_handlers() == len(loggers)
            logging.debug("test")
        assert count_handlers() == 0
    assert log

# Generated at 2022-06-12 14:48:38.344433
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from contextlib import contextmanager
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm, _TqdmLoggingHandler
    logger = logging.getLogger('test_logging_redirect_tqdm')

    @contextmanager
    def capture_console_output(handler):
        # type: (logging.Handler) -> Iterator[None]
        old_handlers = logger.handlers
        try:
            logger.handlers = [handler]
            yield
        finally:
            logger.handlers = old_handlers

    output_str = ''

    class FakeStream:
        def write(self, str_):
            # type: (str) -> None
            nonlocal output_str
            output_str += str_


# Generated at 2022-06-12 14:48:46.580540
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Test for function tqdm_logging_redirect
    """
    import sys, logging
    from tqdm import tqdm, trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def main():
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
            loggers=[LOG],  # tqdm_class=tqdm,  # optional
        ) as pbar:
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
                    # print("console logging redirected to `tqdm.write()`")
                    #

# Generated at 2022-06-12 14:48:51.577666
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in std_tqdm.trange(9):
            if i == 4:
                LOG = logging.getLogger(__name__)
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored
    assert not logging.getLogger().handlers[0].stream._tqdm



# Generated at 2022-06-12 14:49:39.202047
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from tqdm.auto import trange
    except ImportError:
        from tqdm import trange

    import logging
    from .tests_tqdm import with_setup

    LOG = logging.getLogger(__name__)

    def log_to_stdout():
        logger = logging.getLogger(__name__)

        logger.debug("This is a debug log message.")
        logger.info("This is an info log message.")
        logger.warning("This is a warning log message.")
        logger.error("This is an error log message.")
        logger.critical("This is a critical log message.")

    def log_to_stderr():
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)

        logger.debug("This is a debug log message.")

# Generated at 2022-06-12 14:49:47.588287
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    logging.basicConfig(level=logging.INFO)

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        assert logging.root.handlers
        assert logging.root.handlers[0].stream == sys.stderr
        assert logging.getLogger(__name__).handlers == logging.root.handlers

        with logging_redirect_tqdm():
            assert logging.root.handlers
            assert logging.root.handlers[0].stream is None
            assert logging.getLogger(__name__).handlers == logging.root.handlers

            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        #

# Generated at 2022-06-12 14:49:54.546439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler, logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    def test_func():
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(loggers=[LOG]):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    LOG = logging.getLogger(test_func.__name__)
    LOG.handlers = []
    try:
        test_func()
    except RuntimeError:
        pass
    assert len(LOG.handlers) == 0


# Generated at 2022-06-12 14:50:01.991754
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logger = logging.Logger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.FileHandler('/dev/null'))
    assert len(logger.handlers) == 1

    with logging_redirect_tqdm([logger]):
        assert len(logger.handlers) == 2

        logger.debug('logger debug')
        logger.info('logger info')
        logger.warning('logger warning')
        logger.error('logger error')
        logger.critical('logger critical')

    assert len(logger.handlers) == 1

# Generated at 2022-06-12 14:50:08.941540
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from io import StringIO
    from tqdm import tqdm
    from tqdm.contrib import logging_redirect_tqdm

    log_string = StringIO()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(stream=log_string))
    tqdm_string = StringIO()
    tqdm_logger = logging.getLogger()
    tqdm_logger.setLevel(logging.INFO)
    tqdm_logger.addHandler(logging.StreamHandler(stream=tqdm_string))
    with logging_redirect_tqdm(tqdm_class=tqdm):
        LOG = logging.getLogger(__name__)

# Generated at 2022-06-12 14:50:14.361170
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import tqdm
    import logging

    logging.basicConfig(level=logging.INFO)

    LOG = logging.getLogger(__name__)
    LOG.info("This is the initial log")

    with logging_redirect_tqdm([LOG], tqdm_class=tqdm.tqdm):
        LOG.info("This log should be redirected to tqdm")

    LOG.info("Logging should be restored.")


# Generated at 2022-06-12 14:50:19.267543
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .utils import MemoryIO

    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    with MemoryIO() as output:
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")
        assert "console logging redirected to `tqdm.write()`" in str(output)
    with MemoryIO() as output:
        LOG.info("console logging restored")
        assert "console logging restored" in str(output)



# Generated at 2022-06-12 14:50:21.952128
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    log_msg = "this is a test message"
    try:
        with tqdm_logging_redirect(unit="itr") as pbar:
            logging.info(log_msg)
    except AttributeError:
        return
    assert log_msg in pbar.get_readable()

# Generated at 2022-06-12 14:50:27.886155
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm import tqdm as std_tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm() as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:50:31.729263
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect, logging_redirect_tqdm
    from tqdm.test import _suppress_stderr

    LOG = logging.getLogger(__name__)
    LOG.handlers = []

    with _suppress_stderr():
        with tqdm_logging_redirect() as pbar:
            for i in range(3):
                if i == 1:
                    with logging_redirect_tqdm():
                        LOG.info("console logging redirected to `tqdm.write()`")
                pbar.update()
            assert pbar.n == 3

# Generated at 2022-06-12 14:51:56.784842
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # Clear out all other loggers, so we don't get output from other tests
    logging.root.handlers = []
    logger = logging.getLogger("")
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stderr))
    logger.addHandler(logging.FileHandler("./log.txt"))
    assert len(logger.handlers) == 2
    with logging_redirect_tqdm():
        logging.getLogger("").info("test_logging_redirect_tqdm")
    # logging restored
    assert len(logger.handlers) == 2

# Generated at 2022-06-12 14:51:59.970574
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    handler.emit(logging.LogRecord("", logging.INFO, "", 1, 'logging_test', (), None))
    handler.emit(logging.LogRecord("", logging.INFO, "", 2, 'logging_test', (), None))


# Generated at 2022-06-12 14:52:07.204232
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging

    class FakeTqdm(object):
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def write(self, *args, **kwargs):
            pass

    with tqdm_logging_redirect(tqdm_class=FakeTqdm, loggers=[logging.root]) as _:
        pass

# Generated at 2022-06-12 14:52:15.560554
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    original_stdout = sys.stdout
    sys.stdout = open('logging_test.log', 'w')
    tqdm_class = std_tqdm
    handler = _TqdmLoggingHandler(tqdm_class)
    assert handler.stream == sys.stdout
    record = logging.makeLogRecord({'msg': 'test_emit'})
    assert handler.format(record) == 'test_emit'
    handler.emit(record)
    sys.stdout.close()
    with open('logging_test.log', 'r') as f:
        tqdm_log = f.read()
    assert tqdm_log == 'test_emit\n'
    sys.stdout = original_stdout


# Generated at 2022-06-12 14:52:19.857865
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger("logging test")
    with tqdm_logging_redirect(total=10) as pbar:
        for i in range(10):
            LOG.info("i={}".format(i))
            pbar.update()
    assert pbar.n == 10

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:52:31.294469
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """ Test function logging_redirect_tqdm """
    import logging
    import logging.handlers

    level = logging.INFO

    # Test standard logger
    logger = logging.getLogger('test_logging_redirect_tqdm_1')
    logger.setLevel(level)
    ch = logging.StreamHandler()
    ch.setLevel(level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # Test logger without StreamHandler
    logger2 = logging.getLogger('test_logging_redirect_tqdm_2')
    logger2.setLevel(level)

