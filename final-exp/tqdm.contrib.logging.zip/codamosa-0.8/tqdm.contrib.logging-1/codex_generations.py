

# Generated at 2022-06-12 14:42:45.789645
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import time, logging
    from tqdm.utils import _term_move_up
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        'test tqdm_logging_redirect',
        file=sys.stderr,
        max_value=3,
        min_interval=0,
        miniters=1,
        leave=True,
        bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining},{rate_noinv_fmt}]'):
        for i in range(4):
            LOG.info("test")
            time.sleep(.1)


# Generated at 2022-06-12 14:42:50.913342
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    class NullLogger(logging.Logger):
        def addHandler(self, x):
            pass

    class NulHandler(logging.Handler):
        def emit(self, record):
            pass

    logger = NullLogger("null_logger", level=logging.INFO)
    logger.addHandler(NulHandler())
    hdlr = _TqdmLoggingHandler()
    logger.addHandler(hdlr)

    record1 = logging.LogRecord("null_logger", logging.INFO, None, 0, "Test", None, None)
    record2 = logging.LogRecord("null_logger", logging.INFO, None, 0, "\nTest\n", None, None)

# Generated at 2022-06-12 14:42:57.736198
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():

    from io import StringIO

    class MockTqdm(object):

        def write(self, msg, file=None):
            self.file.write(msg)
            self.file.write('\n')

        def __init__(self):
            self.file = StringIO()

    mock_tqdm_instance = MockTqdm()

    test_obj = _TqdmLoggingHandler(tqdm_class=MockTqdm)
    test_obj.emit(logging.LogRecord('name', logging.INFO, 'pathname', 'lineno',
                                    'msg', None, None))
    output = mock_tqdm_instance.file.getvalue()
    assert 'INFO:root:msg' in output

# Generated at 2022-06-12 14:43:06.812471
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Check if tqdm_logging_redirect() works as expected.
    """
    import logging
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock

    def test_try_logging_redirect_tqdm(
            mock_std_tqdm_write,
            mock_std_tqdm,
            mock_logging_redirect_tqdm
    ):
        # type: (...) -> None
        """
        Check the output when tqdm_logging_redirect() is called.
        """

# Generated at 2022-06-12 14:43:09.551941
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(3):
            LOG.info('console logging redirected to `tqdm.write()`')

# Generated at 2022-06-12 14:43:13.297451
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    loggers = [logging.getLogger("test")]
    lines = []
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    with tqdm_logging_redirect(
            loggers=loggers,
            file=open('/dev/null', 'w'),
            hook=lambda x: lines.append(x)):
        logging.info("console logging redirected to `tqdm.write()`")
    assert len(lines) == 1
    assert lines[0] == "INFO:test:console logging redirected to `tqdm.write()`"



# Generated at 2022-06-12 14:43:14.990931
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    with logging_redirect_tqdm():
        logging.info(['foo', 'bar', 'baz'])
    sys.stderr.write('\n')

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:43:20.508517
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import time
    import logging
    logging.basicConfig(level=logging.INFO)
    tqdm_logging_handler = _TqdmLoggingHandler()
    tqdm_logging_handler.setFormatter(logging.Formatter("%(message)s"))
    logging.getLogger("test").addHandler(tqdm_logging_handler)
    for i in range(3):
        logging.getLogger("test").info("hello")
        time.sleep(1)


# Generated at 2022-06-12 14:43:29.378277
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from test_tqdm import discretize, total_seconds
    from time import sleep
    import logging
    import datetime as dt
    import re

    def start_end_time(std_tqdm_out):
        start_re = re.compile(r'\|.*\|\s*')
        end_re = re.compile(r'\|.*\|.*\n')

        start_match = start_re.search(std_tqdm_out)
        start_time_string = start_match.group()[1:-1]
        start_time = dt.datetime.strptime(start_time_string, '%H:%M:%S')
        end_match = end_re.search(std_tqdm_out)
        end_time_string = end_

# Generated at 2022-06-12 14:43:36.192902
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        from cStringIO import StringIO  # Py2
    except ImportError:
        from io import StringIO  # Py3

    handler = _TqdmLoggingHandler()

    # NOTE: logging.getLogger().addHandler(handler) will hang
    #       during tests because of infinite recursion
    lg = logging.Logger('test_logger')
    lg.setLevel(logging.DEBUG)
    lg.addHandler(handler)

    # test `record` without `exc_info`
    output = StringIO()
    handler.stream = output

    record = logging.LogRecord(
        'test_logger', logging.DEBUG,
        '/path/to/logging.py', 123,
        'This is a test log message with file "output.txt"',
        (), None)
    handler

# Generated at 2022-06-12 14:43:49.420281
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():  # pragma: no cover
    from .tests import TestCase, _range, _range_exc
    from .tests_tqdm import pretest_posttest, StringIO

    class TestStringIO(StringIO):
        def write(self, *a, **kw):
            self.value = a[0]
            super(TestStringIO, self).write(*a, **kw)

    class TqdmLoggingHandlerTest(TestCase):
        def test_emit(self):
            with pretest_posttest(logging.basicConfig) as bc:
                stream = TestStringIO()
                bc(level=logging.DEBUG, stream=stream)

                tqdm_handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
                tqdm_handler.stream = stream
                tqdm

# Generated at 2022-06-12 14:43:53.264380
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import tqdm
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in tqdm(range(9), file=sys.stdout):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:44:01.693763
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    import os

    LOG = logging.getLogger(__name__)

    def log_range(start, end):
        for i in trange(start, end):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

    # with logging_redirect:
    #     log_range(5)

    # run unit test
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            log_range(9)
        # logging restored



# Generated at 2022-06-12 14:44:06.543317
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handle = _TqdmLoggingHandler()
    test_record = logging.LogRecord('name',
                                    'level',
                                    'pathname',
                                    'lineno',
                                    'msg',
                                    'args',
                                    'exc_info',
                                    'func')
    try:
        handle.emit(test_record)
    except:  # noqa pylint: disable=bare-except
        pass

# Generated at 2022-06-12 14:44:10.929224
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    try:
        with logging_redirect_tqdm():
            log.info("logging redirected to `tqdm.write()`")
    except TypeError:
        pass


# Generated at 2022-06-12 14:44:18.126048
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import sys
    import tempfile
    r"""Check logging_redirect_tqdm()"""
    with tempfile.TemporaryFile('w') as tempf:
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
        handler = logging.StreamHandler(stream=tempf)
        handler.setFormatter(formatter)
        logging.root.addHandler(handler)
        with logging_redirect_tqdm():
            logging.error('foo')
            logging.warning('bar')
            logging.info('baz')
        logging.error('quux')
        logging.warning('quuux')

# Generated at 2022-06-12 14:44:22.179227
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:44:32.132721
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    test_string = 'test string'
    with tqdm_logging_redirect(
        total=1,
        miniters=1,
        mininterval=0.1,
        loggers=[log],
        file=sys.stdout
    ) as pbar:
        log.info(test_string)
    tqdm.write('\n')
    assert pbar.n == 1
    assert test_string in pbar.format_meter(pbar.n)

# Generated at 2022-06-12 14:44:38.756438
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from ..std import time
    pbar = std_tqdm(total=100, dynamic_ncols=True)
    try:
        pbar.write("TEST START")
        with logging_redirect_tqdm():
            for i in range(10):
                logging.info("Test line " + str(i))
                time.sleep(0.1)
        pbar.write("TEST END")
    finally:
        pbar.close()

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:44:47.790002
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Simply test that `tqdm_logging_redirect` function is working
    """
    def func(s, **kwargs):
        """
        Function to test tqdm_logging_redirect
        """
        pbar = None  # type: Optional[tqdm]
        with tqdm_logging_redirect(total=len(s), **kwargs) as p:
            for c in s:
                pbar = p
                # time.sleep(0.1)
                if c:
                    LOG.info('haha')
        if pbar:
            pbar.close()

    # Create a logger for the 'tqdm' module
    LOG = logging.getLogger('tqdm')
    LOG.propagate = False
    # Create handlers

# Generated at 2022-06-12 14:45:00.833137
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging_redirect_tqdm()



# Generated at 2022-06-12 14:45:05.709102
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    class FakeTqdm:
        def write(self, *args, **kwargs):
            print('FAKE: write:', args, kwargs)
    fake_tqdm_class = FakeTqdm
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm(tqdm_class=fake_tqdm_class):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `FakeTqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:08.811275
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm

    with tqdm_logging_redirect() as pbar:
        for i in range(7):
            pbar.update(1)



# Generated at 2022-06-12 14:45:17.564254
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # Imports
    import time
    import logging

    # Setup logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect(
        # loggers=[LOG],
        desc="test tqdm_logging_redirect",
        total=3
    ) as pbar:
        for i in range(4):
            LOG.info("%s", i)
            time.sleep(0.1)
            if i != 2:
                pbar.update(1)

# Generated at 2022-06-12 14:45:24.226430
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import contextlib2
        contextlib2_available = True
    except ImportError:
        contextlib2_available = False

    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

        # logging restored
        LOG.info('logging restored')

        logger = logging.getLogger(__name__ + '2')
        logger.setLevel(logging.INFO)

# Generated at 2022-06-12 14:45:32.388712
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """Unit test for method emit of class _TqdmLoggingHandler.

    # Added in 0.4.9.
    """
    with std_tqdm(_range(1)) as t:
        # Test that no exception is raised.
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(message)s',
            handlers=[t._inst._logging_handler])
        logger = logging.getLogger('name')
        logger.info('message')



# Generated at 2022-06-12 14:45:35.445540
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("%s", "tqdm logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:45:45.152090
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    tqdm_buffer = ""

    # Define logging messages
    class TestLogger(logging.Logger):
        def __init__(self, name):
            super(TestLogger, self).__init__(name)

        def _log(self, level, msg, args, exc_info=None, extra=None):
            logging.Logger._log(self, level, msg, args, exc_info, extra)
            global tqdm_buffer
            tqdm_buffer += msg

    # Define a function that has logging statements
    def test_logger(logger):
        for i in range(5):
            logger.info("test")

    # Test for logging redirect

# Generated at 2022-06-12 14:45:53.416164
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    original_handlers_list = [logging.root.handlers[:]]
    with tqdm_logging_redirect(total=10, desc="Testing logging_redirect_tqdm"):
        logging.info("original root LOG output redirected to tqdm.write()")
        # test logging.redirect_tqdm()
        with logging_redirect_tqdm([logging.getLogger("test_logging")],
                                   tqdm_class=std_tqdm):
            logging.getLogger("test_logging").info("custom LOG redirected "
                                                   "to tqdm.write()")
    for handlers in original_handlers_list:
        logging.root.handlers = handlers

test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:45:57.283101
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    LOGGER = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOGGER.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:46:25.543784
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    This function tests the function logging_redirect_tqdm.
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored



# Generated at 2022-06-12 14:46:33.014098
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import unittest
    from unittest import TestCase
    import logging, sys
    from io import StringIO
    from tqdm._utils import _term_move_up

    class LoggingRedirectTqdmTest(TestCase):
        ORIGINAL_STREAM = sys.stdout
        REDIRECTED_STREAM = StringIO()

        @classmethod
        def setUpClass(cls):
            logging.basicConfig(level=logging.INFO)
            logger = logging.getLogger(__name__)
            with logging_redirect_tqdm([logger]):
                logger.info('Console logging redirected to `tqdm.write()`')
            cls.ORIGINAL_STREAM.seek(0)

# Generated at 2022-06-12 14:46:43.970157
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib import tgrange

    with tqdm_logging_redirect(
            ('foo', 'bar'),
            total=100,
            dynamic_ncols=True,
            desc='testing',
            leave=True,
            bar_format='{desc}',
            loggers=[logging.getLogger('baz')]
    ) as pbar:
        # Should be redirected
        logging.getLogger('foo').info('hello world')
        logging.getLogger('foo').info('hello world2')
        logging.getLogger('foo').info('hello world3')
        logging.warning('qux qux qux\nqux qux')
        logging.error('foo bar')

        # Shouldn't be redirected

# Generated at 2022-06-12 14:46:49.002396
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:46:58.361439
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    # logging.basicConfig(level=logging.DEBUG)

    LOG = logging.getLogger()
    with logging_redirect_tqdm():
        LOG.warn('see me')
        LOG.info('not see me')

    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        LOG.warn('see me')
        LOG.info('not see me')

    with logging_redirect_tqdm(loggers=[logging.getLogger(__name__)]):
        LOG.warn('see me')
        LOG.info('see me')


# Generated at 2022-06-12 14:47:07.967000
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # set up the logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')

    # set up the tqdm display
    fh = logging.FileHandler('test.log', mode='w')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    with tqdm_logging_redirect(loggers=[logger]):
        logger.info("test")

    with open("test.log","r") as f:
        assert ('test\n' in f.read())

if __name__ == '__main__':
    test_tqdm_logging_redirect()

# Generated at 2022-06-12 14:47:11.688835
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect():
        for i in trange(5):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:47:20.943042
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.contrib.test import closing, _range
    import logging

    # Can be called with no arguments
    with closing(std_tqdm.tqdm()) as pbar:
        with logging_redirect_tqdm():
            logging.info("logging redirected to `tqdm.write()`")
    assert pbar.n == 0

    # Can be passed custom loggers
    log = logging.getLogger("example")  # different namespace
    with closing(std_tqdm.tqdm()) as pbar:
        with logging_redirect_tqdm(loggers=[log]):
            log.info("logging redirected to `tqdm.write()`")
    assert pbar.n == 1

    # Can be passed custom tqdm class

# Generated at 2022-06-12 14:47:28.005324
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm.utils import _supports_unicode
    import logging
    import time
    for logger in [logging.getLogger('test'), logging.getLogger()]:
        for tqdm in [std_tqdm, trange]:
            for n in [1, 10]:
                logger.info('start test: %s', tqdm.__name__)

                with tqdm_logging_redirect(
                        total=n,
                        leave=False,
                        desc=tqdm.__name__,
                        loggers=[logger],
                        tqdm_class=tqdm) as pbar:
                    for _ in range(n):
                        logger.info('hello')
                        pbar.update()
                        time.sleep(.01)

                logger.info('end test')

# Generated at 2022-06-12 14:47:30.956611
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    LOG = logging.getLogger(__name__)
    with logging_redirect_tqdm():
        assert len(logging.root.handlers) == 1
        assert isinstance(logging.root.handlers[0], _TqdmLoggingHandler)
        LOG.info("hi")

# Generated at 2022-06-12 14:48:21.683121
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    # Test tqdm_logging_redirect
    with tqdm_logging_redirect(total=100) as pbar:
        LOG = logging.getLogger(__name__)
        LOG.info("Won't output anything")
        pbar.n = 10
        LOG.info("But now it will")

    # Test tqdm_logging_redirect again with custom loggers.
    with tqdm_logging_redirect(total=100, loggers=[logging.Logger('TEST')]) \
            as pbar:
        TEST = logging.getLogger('TEST')
        TEST.info("This should output")
        pbar.n = 20



# Generated at 2022-06-12 14:48:30.258370
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import io

    from ..std import tqdm
    from ..std import logging
    from .contextlib import redirect_stdout
    from .misc import format_sizeof

    log_stream = io.StringIO()
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.handlers = [logging.StreamHandler(log_stream)]

    def test(pbar, n):
        log.debug("1: %d", n)
        pbar.update(1)
        log.debug("2: %d", n ** 2)
        log.debug("3: %d", n ** 3)
        pbar.update(1)
        log.debug("4: %s", format_sizeof(n ** 4))
        pbar.update(1)

# Generated at 2022-06-12 14:48:35.861378
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:48:42.154935
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    import logging

    class _TestLoggingHandler(_TqdmLoggingHandler):
        def __init__(self):
            self.handleList = []
            super(_TestLoggingHandler, self).__init__()

        def emit(self, record):
            self.handleList.append(record.msg)
            super(_TestLoggingHandler, self).emit(record)

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    handler = _TestLoggingHandler()
    logger.addHandler(handler)
    logger.info('test emit')
    assert handler.handleList[0] == 'test emit'

# Generated at 2022-06-12 14:48:45.403881
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    tqdm.write = lambda s: sys.stdout.write(s)
    with tqdm_logging_redirect(desc="test"):
        tqdm.write("OK")
        tqdm.write("OK")

# Generated at 2022-06-12 14:48:51.952036
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    """
    Unit test for function tqdm_logging_redirect
    """
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:49:01.027590
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.INFO)

    def print_logs():
        LOG.info('foo')
        LOG.info('bar')

    # Normal logging (no redirect)
    handler = logging.StreamHandler(sys.stdout)
    LOG.addHandler(handler)
    print_logs()
    assert not handler.stream.getvalue()

    # Redirect logging to a StringIO
    f = sys.stdout
    sys.stdout = sys.__stdout__ = handler.stream
    try:
        with logging_redirect_tqdm(logging.Logger.manager.loggerDict.values()):
            print_logs()
    except Exception:
        sys.stdout = f
        raise
   

# Generated at 2022-06-12 14:49:02.883457
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect():
        assert True

# Generated at 2022-06-12 14:49:13.319275
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    # to test the `logging_redirect_tqdm` in the `__main__` scope
    class LoggingRedirectTqdm(object):
        def __init__(self):
            self.tqdm_class = std_tqdm

        def __enter__(self):
            pass

        def __exit__(self, *args, **kwargs):
            pass

    logging_redirect_tqdm = LoggingRedirectTqdm()


# Generated at 2022-06-12 14:49:20.525318
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging  # noqa
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:50:48.316445
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    # Creates a fake stream to test the method emit of class _TqdmLoggingHandler.
    test_stream = io.StringIO()

    tqdm_handler = _TqdmLoggingHandler(sys.stdout)
    # Creates a fake logging record with loglevel and message to test the method emit of class _TqdmLoggingHandler.
    fake_record = logging.LogRecord("", logging.DEBUG, "", 0, "fake_message", (), None)
    tqdm_handler.set_stream(test_stream)

    # Writes fake logging record to fake stream.
    tqdm_handler.emit(fake_record)
    # Asserts that the fake logging record was written to fake stream.
    assert test_stream.getvalue() == "fake_message\n"

# Generated at 2022-06-12 14:50:58.378444
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm._tqdm_test_utils import StringIO

    # pylint: disable=redefined-outer-name
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Test redirecting to sys.stdout
    with StringIO() as buf, logging_redirect_tqdm():
        logger.warning('test')
        assert '\rtest' in buf.getvalue()

    # Test redirecting to tqdm.write()
    with StringIO() as buf, tqdm_logging_redirect(
        ascii=True, file=buf, dynamic_ncols=True, mininterval=0, unit_scale=0
    ) as pbar:
        logger.info('test')
        logger

# Generated at 2022-06-12 14:51:05.439587
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm import tqdm
    from tqdm._utils import _environ_cols_wrapper
    from tqdm.contrib.logging import _TqdmLoggingHandler, std_tqdm
    try:
        from unittest import mock
    except ImportError:
        import mock


# Generated at 2022-06-12 14:51:15.198588
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """
    Unit test for function tqdm_logging_redirect
    """
    import unittest
    from unittest.mock import patch
    import logging
    import sys

    class TestTqdmLoggingRedirect(unittest.TestCase):
        def setUp(self):
            logging.basicConfig(level=logging.INFO)
            console_handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter('%(message)s')
            console_handler.setFormatter(formatter)
            self.logger = logging.getLogger(__name__)
            self.logger.handlers = []
            self.logger.addHandler(console_handler)

        def test_tqdm_logging_redirect(self):
            from io import StringIO  #

# Generated at 2022-06-12 14:51:20.439852
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    with std_tqdm.python_2_unicode_compatible(False):
        with logging_redirect_tqdm():
            logging.info("hello")
            logging.info("world")
        for _ in std_tqdm(range(1), desc='hello world', leave=False):
            logging.info("hello")



# Generated at 2022-06-12 14:51:28.189603
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.tests.test_tqdm import DiscreteTimer, StringIO

    class TestTqdm(std_tqdm):
        """ Test tqdm class """

        def __init__(self, *args, **kwargs):
            if kwargs.get('file') is None:
                kwargs['file'] = StringIO()
            super(TestTqdm, self).__init__(*args, **kwargs)

        @property
        def n(self):
            return self.total - 1

        def set_postfix_str(self, s=''):
            self.postfix = [s]

        def set_description_str(self, s=''):
            self.desc = s

    class LoggingChecker(object):
        """Check that all logging output has been processed"""

# Generated at 2022-06-12 14:51:37.486829
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)
    assert not LOG.handlers  # By default, no handlers are set

    # Check that the context manager works correctly
    with tqdm_logging_redirect() as pbar:
        assert len(pbar.handlers) == 1 and LOG.handlers
        LOG.info("test")
        LOG.info("test2")
        LOG.debug("test3")
        pbar.close()
        assert len(pbar.handlers) == 0 and not LOG.handlers
    assert not LOG.handlers

    # Check that no handlers are set by default and they are set correctly
    with tqdm_logging_redirect() as pbar:
        assert len(pbar.handlers) == 1 and LOG.hand

# Generated at 2022-06-12 14:51:45.449720
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import pretest_posttest  # pylint: disable=import-outside-toplevel

    @pretest_posttest
    def test_function(old_root_handlers):
        logger = logging.getLogger(__name__)

        @pretest_posttest
        def test_function_inner(old_handlers):
            print("This should appear before the tqdm bar")
            with logging_redirect_tqdm([logger]):
                pbar = std_tqdm(range(3))
                for i in pbar:
                    if i == 1:
                        logger.info("console logging redirected to `tqdm.write()`")
                    pbar.set_description("TEST")
                print("This should appear after the tqdm bar")
        test_function_inner

# Generated at 2022-06-12 14:51:50.576552
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    try:
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore

    with patch("tqdm.std.tqdm") as mocked_tqdm:
        with tqdm_logging_redirect("test") as pbar:
            assert pbar is mocked_tqdm.return_value.__enter__.return_value
            assert mocked_tqdm.call_args[0][0] == "test"
            # assert mocked_tqdm.call_args[1] == {}  # dict is not ordered in py2

        assert mocked_tqdm.return_value.__enter__.return_value.close.called


# Generated at 2022-06-12 14:51:58.163683
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    _LOG = logging.getLogger('tqdm_contrib.test_logging_redirect_tqdm')

    # Test basic functionality
    with logging_redirect_tqdm(_LOG):
        # Create some new handlers to replace, just to make sure all handlers
        # are removed and replaced. We don't have to remove the original
        # handlers because the context manager will remove them, we just need
        # to be sure they are replaced in the end.
        _LOG.addHandler(logging.StreamHandler())
        _LOG.addHandler(logging.StreamHandler())
        for i in range(4):
            _LOG.info(str(i))
    # Test with tqdm_class=std_tqdm