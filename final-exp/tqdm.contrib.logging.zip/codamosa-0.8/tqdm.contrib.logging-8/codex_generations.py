

# Generated at 2022-06-12 14:42:44.936327
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger("test")
    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:42:51.110932
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import pytest
    from .pandas import tqdm_pandas as tqdm
    from .utils import TqdmDeprecationWarning

    try:
        with tqdm_logging_redirect(tqdm_class=tqdm):
            # Deprecated usage, should raise TqdmDeprecationWarning
            with tqdm.tqdm_notebook(total=3) as pbar:
                pbar.update()
    except Exception as ex:
        pytest.fail("tqdm_logging_redirect() raised an unexpected exception "
                    "{}".format(ex))



# Generated at 2022-06-12 14:42:55.560446
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:43:01.107876
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from tqdm.utils import _range
    from .test_tqdm import FakeTTY
    from .test_tqdm import pretest_posttest

    try:
        from unittest import mock  # noqa
    except ImportError:
        import mock  # type: ignore

    with mock.patch('sys.stderr', new_callable=StringIO):
        tqdm_handler = _TqdmLoggingHandler()
        tqdm_handler.setLevel(logging.INFO)
        with FakeTTY():
            tqdm_handler.emit(
                logging.LogRecord('test', logging.INFO, 'test.py', 10,
                                  'Test', {}, None))
    assert sys.stderr.getvalue().endswith('Test\n')

   

# Generated at 2022-06-12 14:43:06.368564
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(
            iterable=range(10),
            desc='logging redirected to tqdm',
            logger='test',
            level=logging.INFO
        ) as pbar:

        logging.getLogger('test').info('This should appear in tqdm')
        assert pbar.desc == 'logging redirected to tqdm: This should appear in tqdm'

# Generated at 2022-06-12 14:43:13.729749
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import io
    import logging
    from tqdm import tqdm
    from tqdm.contrib import logging_redirect_tqdm as lrtqdm

    LOG = logging.getLogger(__name__)

    # Create a fake file for testing
    fake_out = io.StringIO()

    if __name__ == '__main__':
        # Set up fake file with logging
        logging.basicConfig(level=logging.INFO, side='logging')

        with tqdm_logging_redirect(desc='Test', total=24,
                                   file=fake_out, loggers=[logging.root]) as pbar:
            # Run a loop to test the logger
            for i in pbar:
                LOG.info('logging redirected to `tqdm.write()`')

        # Check if the

# Generated at 2022-06-12 14:43:21.848192
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from pytest import raises  # pylint: disable=unused-import
    except ImportError:
        raise ImportError(
            "This function requires pytest to run its unit tests")

    try:
        from unittest.mock import patch  # pylint: disable=unused-import
    except ImportError:
        from mock import patch  # pylint: disable=unused-import

    with patch('tqdm.contrib.logging._TqdmLoggingHandler.emit') as mock_emit:
        with tqdm_logging_redirect(total=10) as pbar:
            logging.info('hi')
            assert pbar.n == 2
            assert pbar.desc == 'hi'
            logging.info('bye')
            assert pbar.n == 3

# Generated at 2022-06-12 14:43:29.186291
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from ..std import tqdm as std_tqdm
    from .tests import _TestRedirect

    with std_tqdm(redirect_stdout=_TestRedirect) as pbar:
        with logging_redirect_tqdm(tqdm_class=std_tqdm):
            logging.info("redirected")
        assert pbar.stdout[0] == "INFO:root:redirected\n"

    with tqdm_logging_redirect(redirect_stdout=_TestRedirect) as pbar:
        logging.info("redirected")
    assert pbar.stdout[0] == "INFO:root:redirected\n"

# Generated at 2022-06-12 14:43:36.065269
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        from tqdm import tqdm
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(
                desc='Doing something',
                iterable=range(3),
                tqdm=tqdm,
                loggers=[LOG],
        ) as pbar:
            for i in pbar:
                pbar.set_description("Current number: %s " % i)
                LOG.info("console logging redirected to `tqdm.write()`")


if __name__ == '__main__':
    # Test suite
    import logging
    import unittest
    # from tqdm import tqdm


# Generated at 2022-06-12 14:43:44.687559
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.tests import run_logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with run_logging_redirect_tqdm(__name__):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:43:59.732343
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from tqdm import tqdm
    with tqdm_logging_redirect(total=2, unit="test") as pbar:
        assert pbar.__enter__() == pbar
        pbar.update()
        assert isinstance(pbar, tqdm)
        assert pbar.__exit__() is None

# Generated at 2022-06-12 14:44:08.296737
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.WARNING)
    console = logging.StreamHandler()
    console.setLevel(logging.WARNING)
    console.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    LOG = logging.getLogger("test")
    LOG.setLevel(logging.WARNING)
    LOG.addHandler(console)
    original_handlers = LOG.handlers
    try:
        with logging_redirect_tqdm(tqdm_class=std_tqdm):
            assert len(LOG.handlers) == 1
            assert isinstance(LOG.handlers[0], _TqdmLoggingHandler)
            LOG.warning("foo")
    finally:
        LOG.handlers = original_handlers



# Generated at 2022-06-12 14:44:13.068364
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
    except ImportError:
        return  # skip

    with tqdm_logging_redirect(
            iterable=range(0, 9),
            desc='logging intercepted',
            unit='foo',
            dynamic_ncols=True
    ) as pbar:
        for _ in pbar:
            logging.warning('logging intercepted by tqdm_logging_redirect')

# Generated at 2022-06-12 14:44:20.269711
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    def my_logger(loggers, tqdm_class):
        # type: (List[logging.Logger], Type[std_tqdm]) -> None
        for i in trange(9):
            if i == 4:
                with logging_redirect_tqdm(loggers=loggers, tqdm_class=tqdm_class):
                    LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:44:21.923432
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    with tqdm_logging_redirect(total=10):
        logging.info("wololo")
    logging.warn("bla")

# Generated at 2022-06-12 14:44:33.998552
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest import mock
    except ImportError:
        import mock
    import logging
    from tqdm import tqdm
    from tqdm.contrib import logging as logging_tqdm

    root_logger = logging.getLogger()
    assert len(root_logger.handlers) == 1, \
        "Need one logging handler for test (otherwise logs will be ignored)"
    assert isinstance(root_logger.handlers[0], logging.StreamHandler), \
        "One logging handler should be a StreamHandler for test"
    assert isinstance(root_logger.handlers[0], logging_tqdm._TqdmLoggingHandler), \
        "One logging handler should be a TqdmLoggingHandler for test"
    m = mock.MagicMock()
    # trigger mock to

# Generated at 2022-06-12 14:44:40.694091
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    """Unit test for function logging_redirect_tqdm"""
    import logging
    from tqdm.contrib.testing import closing_to_stdout
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)
    with closing_to_stdout() as out:
        with logging_redirect_tqdm():
            LOG.warning("warning message")
            LOG.info("info message")
            LOG.debug("debug message")
    assert out.lines == ["warning message", "info message", "debug message"]



# Generated at 2022-06-12 14:44:44.757271
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    with logging_redirect_tqdm():
        logger = logging.getLogger(__name__)
        logger.info("Hello World")
        for _ in trange(3):
            logger.info("Hello World")

# Generated at 2022-06-12 14:44:50.110875
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.DEBUG)
        with logging_redirect_tqdm([LOG]):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:44:55.344835
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    """Unit test for function tqdm_logging_redirect."""
    import logging
    from tqdm import trange
    with tqdm_logging_redirect():
        for i in trange(9, desc="test"):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:45:17.794979
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    log = logging.getLogger('logging-redirect-tqdm')
    log.setLevel(logging.DEBUG)
    with logging_redirect_tqdm():
        log.info('info message')
        log.warning('warning message')
        log.error('error message')



# Generated at 2022-06-12 14:45:24.418721
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.disable(logging.CRITICAL)  # Disable all logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    test_logger(logger, tqdm_class=std_tqdm)

    with tqdm_logging_redirect(tqdm_class=std_tqdm):
        test_logger(logger, tqdm_class=std_tqdm)

    with tqdm_logging_redirect(tqdm_class=std_tqdm, loggers=[logger]):
        test_logger(logger, tqdm_class=std_tqdm)


# Generated at 2022-06-12 14:45:35.446158
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    # Do not log to stderr
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    # Fake log entry to create the logger
    logging.getLogger().info("This text should not appear")
    # Only show INFO and above
    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)

    if __name__ == '__main__':
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.debug("This text should not appear")

# Generated at 2022-06-12 14:45:39.895903
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import _TqdmLoggingHandler

    logger = logging.getLogger(__name__)
    logger.addHandler(_TqdmLoggingHandler(tqdm))

    logger.info("logger message")



# Generated at 2022-06-12 14:45:49.267046
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for function logging_redirect_tqdm"""
    import logging
    import sys
    import tqdm
    from tqdm.contrib.logging import (
        _TqdmLoggingHandler, logging_redirect_tqdm)

    # Simple test case
    #
    # If this test fails, then logging_redirect_tqdm does not work at all.
    logger = logging.getLogger(__name__)
    log_text = """This is a simple test case.
    The log message should appear in the tqdm progress bar.
    """
    with tqdm.std.tqdm() as progressbar:
        with logging_redirect_tqdm():
            logger.info(log_text)
        log_lines = progressbar.full_

# Generated at 2022-06-12 14:45:52.771150
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import random

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(4):
                LOG.info(i)



# Generated at 2022-06-12 14:45:55.237966
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("This should appear in the tqdm stream")



# Generated at 2022-06-12 14:46:00.589339
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:46:07.548515
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from io import StringIO
    from tqdm import trange
    from .utils import tqdm_proxy

    # Mocking actual `sys.stderr` to unit-test is a pain
    # It's easier to check if stream is `isatty()` instead
    sys.stderr = StringIO()
    try:
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for _ in trange(3):
                logging.info('foo')
        assert sys.stderr.getvalue() == 'foo\nfoo\nfoo\n'
    finally:
        sys.stderr.close()
        sys.stderr = sys.__stderr__  # type: ignore

    # See if it works without changing `logging.root`
    out

# Generated at 2022-06-12 14:46:17.497727
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    def demo_logging_redirect_tqdm():
        import logging
        from tqdm.contrib.logging import logging_redirect_tqdm
        LOG = logging.getLogger(__name__)
        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            with logging_redirect_tqdm():
                for i in range(9):
                    if i == 4:
                        LOG.info("console logging redirected to `tqdm.write()`")
            # logging restored
    from io import StringIO
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm
    LOG = logging.getLogger(__name__)
    buf = StringIO()
    # tqdm is a context manager

# Generated at 2022-06-12 14:46:57.017150
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    with tqdm_logging_redirect(total=10, bar_format='{l_bar}') as pbar:
        for _ in range(10):
            pbar.update()

# Generated at 2022-06-12 14:47:06.666070
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import time
    import random
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger("test_tqdm")

    # Simple test
    with logging_redirect_tqdm():
        LOG.info("test_1")

    # test with explicitly set logger
    with logging_redirect_tqdm(loggers=[LOG]):
        LOG.info("test_2")

    # make sure logging works after the context manager
    LOG.info("test_3")

    # check that logging does not go to tqdm
    LOG.removeHandler(logging.root.handlers[-1])
    with logging_redirect_tqdm():
        LOG.info("test_4")
    logging.root.handlers.pop()

    #

# Generated at 2022-06-12 14:47:13.088399
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:47:19.223205
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        from unittest.mock import patch  # type: ignore
    except ImportError:
        from mock import patch  # type: ignore

    with patch('tqdm.std.tqdm.write') as mock_write:
        log = logging.getLogger(__name__)
        with logging_redirect_tqdm():
            for i in range(3):
                log.info(i)
            for i in range(3):
                log.error(i)
        assert mock_write.call_count == 6

# Generated at 2022-06-12 14:47:21.956040
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        with tqdm_logging_redirect(ncols=100, leave=False):
            logging.info('This is an example')
            logging.info('Of logging redirected to tqdm')

            import time
            for i in range(4):
                time.sleep(0.01)
                logging.info('Pinning this logging{0}'.format(i))
    except:  # noqa
        assert False, 'logging_redirect_tqdm failed'

# Generated at 2022-06-12 14:47:28.758776
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from io import StringIO
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import tqdm_logging_redirect

    log_str = StringIO()

    with tqdm_logging_redirect(total=5, file=log_str) as pbar:
        for _ in range(2):
            logging.info('hello world')
        for _ in range(5):
            pbar.update()

    assert 'hello world\n' * 2 == log_str.getvalue()


# def _test_tqdm_logging_redirect(monkeypatch):
#     from io import StringIO
#     import logging
#     from tqdm import tqdm
#     from tqdm.contrib.logging import tqdm_logging_redirect


# Generated at 2022-06-12 14:47:32.711373
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.scripts import tqdm
    _TqdmLoggingHandler_obj = _TqdmLoggingHandler(tqdm_class=tqdm)
    log_test_msg = '[TqdmLoggingHandler] Testing...'
    _TqdmLoggingHandler_obj.emit(logging.getLogger().makeRecord('test', logging.DEBUG, 'path', 'lineno', log_test_msg, {}, None))


# Generated at 2022-06-12 14:47:42.902105
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import time  # noqa
    import sys  # noqa
    import subprocess  # noqa

    stdout_file = sys.stdout
    try:
        sys.stdout = open('/tmp/test_tqdm_redirect.log', 'w')
    except:  # noqa  # pylint: disable=bare-except
        sys.stderr.write('WARNING: Could not open stdout for writing\n')
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(desc='Testing tqdm_logging_redirect',
                               loggers=[logging.getLogger()]):
        for i in range(0, 5):
            time.sleep(0.4)
            logging.info('test')

# Generated at 2022-06-12 14:47:49.785727
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    import logging
    from tqdm import trange, tqdm

    LOG = logging.getLogger(__name__)

    def setup():
        LOG.handlers = []

    def test_with_default_logger():
        setup()
        with logging_redirect_tqdm():
            for i in trange(8):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    def test_with_custom_logger():
        setup()
        logger = logging.getLogger('test')  # type: ignore[call-arg]
        logger.setLevel(logging.INFO)

# Generated at 2022-06-12 14:47:56.838036
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    if sys.version_info < (3, ):
        return
    import os
    import shutil
    import tempfile
    import logging

    from ..std import tqdm, tqdm_notebook, trange

    logfile = "test.log"
    logfile_clean = "test_clean.log"
    logfile_tqdm = "test_tqdm.log"
    logfile_tqdm_clean = "test_tqdm_clean.log"

    # import tqdm

    tmp_dir = tempfile.mkdtemp()
    logfile = os.path.join(tmp_dir, logfile)
    logfile_clean = os.path.join(tmp_dir, logfile_clean)

# Generated at 2022-06-12 14:49:18.296621
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit tests for function `logging_redirect_tqdm`."""
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:49:21.513823
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time

    with logging_redirect_tqdm():
        logging.info("Log")
        time.sleep(0.5)
        logging.info("Another log")
        time.sleep(0.5)
        logging.info("A different log")


# Generated at 2022-06-12 14:49:30.707773
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():

    # Mocking the logging StreamHandler and Logger for testing function
    class _logging_StreamHandler:
        def __init__(self):
            self.formatter = "logging formatter"
            self.stream = 2

    class _logging_Logger:
        def __init__(self):
            self.handlers = [_logging_StreamHandler(), _logging_StreamHandler()]

    # Mock the logging module for testing function
    class _logging_module:
        def __init__(self):
            self.root = _logging_Logger()
            self.Logger = _logging_Logger

    # Mock the tqdm module for testing function

# Generated at 2022-06-12 14:49:38.645559
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import tqdm_logging_redirect

    class Logger(object):
        """A logger to test tqdm_logging_redirect with any class."""
        def __init__(self):
            self.handlers = []
            self.handlers.append(logging.StreamHandler())

        def info(self, msg):
            self.handlers[0].emit(msg)

    logging.Logger = Logger
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect(total=9, desc='123', ncols=76,
                               leave=True, loggers=[logging.Logger]) as pbar:
        for _ in pbar:
            logging

# Generated at 2022-06-12 14:49:47.087818
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    LOG = logging.getLogger(__name__)

    # setup
    loggers = [LOG]
    with logging_redirect_tqdm(loggers=loggers):
        pass  # `logging_redirect_tqdm`

    # Assert that logging data is being redirected.
    # Expecting that the output of logging is on the same line as tqdm
    with tqdm_logging_redirect(
            range(2),
            loggers=loggers,
    ) as pbar:
        LOG.info("using logger {!r}".format(LOG.name))
    expected_first_line = "\r  0%|          | 0/2 [00:00<?, ?it/s] using logger '{}'\n".format(__name__)
    assert pbar.write.call_args

# Generated at 2022-06-12 14:49:54.255569
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # simplify testing with fake tqdm class
    class FakeTqdm(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.iterable = args[0]
            self.enabled = False

        def __iter__(self):
            self.enabled = True
            return iter(self.iterable)

        def write(self, message, **kwargs):
            self.message = message
            self.write_kwargs = kwargs

        def __enter__(self):
            return self

        def __exit__(self, exception_type, exception_value, traceback):
            pass

    def get_fake_logging():
        class FakeLogger(object):
            def __init__(self):
                self.handlers

# Generated at 2022-06-12 14:50:03.554357
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_tqdm import pretest_posttest  # noqa pylint: disable=import-outside-toplevel


# Generated at 2022-06-12 14:50:07.309844
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    LOG = logging.getLogger(__name__)

    try:
        with tqdm_logging_redirect() as pbar:
            for i in pbar:
                assert pbar.lock_args_values is not None
                if i == 4:
                    LOG.info('console logging redirected to `tqdm.write()`')
                    break
    except AssertionError:
        pass

# Generated at 2022-06-12 14:50:10.952795
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:50:17.521173
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    try:
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9, desc="Test1") as pbar:
            for i in trange(9, desc="Test2"):
                if i == 4:
                    logging.info("console logging redirected to `tqdm.write()`.")
                pbar.update()
    except Exception:
        pass

# Generated at 2022-06-12 14:51:41.244622
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.DEBUG)
    with logging_redirect_tqdm():
        logging.debug('debug message')
        logging.info('info message')
        logging.warning('warning message')
        logging.error('error message')
        logging.critical('critical message')



# Generated at 2022-06-12 14:51:46.905880
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tqdm_test_classes import TestClass
    from .tqdm_test_classes import TestClassNoWrite

    try:
        with logging_redirect_tqdm(tqdm_class=TestClass):
            logging.info('Logging redirected to TestClass')
        with logging_redirect_tqdm(tqdm_class=TestClassNoWrite):
            logging.info('Logging redirected to TestClassNoWrite')
        with logging_redirect_tqdm():
            logging.info('Logging redirected to std_tqdm')
    except AttributeError:
        pass

# Generated at 2022-06-12 14:51:52.294628
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:51:58.696158
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm.auto import trange
    from .tests_tqdm import with_setup, pretest, posttest
    from .tests_tqdm import _range, closing

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    @with_setup(pretest, posttest)
    def main():
        """
        Testing function for logging_redirect_tqdm
        """

# Generated at 2022-06-12 14:52:08.845296
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import logging.handlers
    # import logging.root

    log_file = 'test_logging_redirect_tqdm.log'
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    fh = logging.handlers.RotatingFileHandler(log_file, maxBytes=0)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    log.addHandler(fh)

    for _ in range(5):
        with logging_redirect_tqdm():
            log.info('this message should appear in tqdm window')
        log.info('this message should appear in the log file only')


# Generated at 2022-06-12 14:52:16.742234
# Unit test for function tqdm_logging_redirect

# Generated at 2022-06-12 14:52:22.178697
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)

    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with tqdm(total=1) as pbar:
        with logging_redirect_tqdm():
            for i in range(5):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")

    with tqdm(total=1) as pbar:
        with logging_redirect_tqdm():
            LOG.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:52:28.811748
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    import time

    log = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm(loggers=[log]):
        log.info('Console logging redirected to `tqdm.write()`')
        time.sleep(0.1)



# Generated at 2022-06-12 14:52:32.736998
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm.std import StringIO
    tqdm_class = type('tqdm_class', (std_tqdm, ), {'_file': StringIO()})
    handler = _TqdmLoggingHandler(tqdm_class)
    logger = logging.getLogger(__name__)
    fmt = '%(message)s'
    formatter = logging.Formatter(fmt)
    logger.addHandler(handler)
    logger.info('test_message')
    assert tqdm_class._file.getvalue().rstrip() == 'test_message'

# Generated at 2022-06-12 14:52:34.386221
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logging.warning('test logging_redirect_tqdm')