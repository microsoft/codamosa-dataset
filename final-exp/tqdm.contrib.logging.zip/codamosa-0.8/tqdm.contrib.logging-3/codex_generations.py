

# Generated at 2022-06-12 14:42:50.011882
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from unittest import TestCase, main
    from io import StringIO
    import logging

    # Modified from https://stackoverflow.com/a/7863505/3725580
    class TestTQDMLoggingRedirect(TestCase):
        def setUp(self):
            self.handler = StringIO()
            logging.basicConfig(stream=self.handler, level=logging.INFO)
            self.handler.truncate(0)

        def test_logging_redirect(self):
            # type: () -> None
            with tqdm_logging_redirect(desc='Test', total=0):
                logging.info('hello world')

            self.assertIn('hello world\n', self.handler.getvalue())

    main()



# Generated at 2022-06-12 14:42:56.993748
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """
    Testing that logging_redirect_tqdm does not crash when interacting with `ThreadedLogger`

    (we don't check the output of logging_redirect_tqdm as the logging module
    is inaccessible at the moment when `__exit__` is called)
    """
    try:
        from loguru import logger  # type: ignore
    except ImportError:
        return  # No loguru installed
    logger.info("ThreadedLogger: start")
    logger.remove()
    logger.add(sys.stderr, format="{time} - {level} - {message}", level="INFO")
    logger.info("ThreadedLogger: end")

# Generated at 2022-06-12 14:43:01.301269
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in range(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:43:09.988374
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    """Unit test for function logging_redirect_tqdm"""
    import logging
    import sys
    import tempfile
    import unittest
    from contextlib import contextmanager

    try:
        from mock import MagicMock, patch  # type: ignore
    except ImportError:
        sys.exit('Please install mock module to run unit tests')

    LOG = logging.getLogger('test_logging_redirect_tqdm')
    LOG.addHandler(logging.NullHandler())

    @contextmanager
    def captured_output():
        # type: () -> Iterator[None]
        """Context manager for capturing stdout and stderr"""
        new_out, new_err = tempfile.TemporaryFile(), tempfile.TemporaryFile()

# Generated at 2022-06-12 14:43:14.150848
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm.contrib.logging import logging_redirect_tqdm
    from tqdm.auto import trange

    LOG = logging.getLogger(__name__)
    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

# Generated at 2022-06-12 14:43:18.494565
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm

    def test():
        test_log = logging.getLogger(__name__)

        for i in tqdm(range(9)):
            if i == 4:
                test_log.info('This will be redirected to tqdm.write()')

    with logging_redirect_tqdm():
        test()



# Generated at 2022-06-12 14:43:23.525486
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():  # pragma: no cover
    from ..tqdm import tqdm

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in tqdm(range(9)):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:43:32.000029
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import tqdm
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    written_messages = []  # type: List[str]
    written = tqdm.write
    tqdm.write = lambda msg: written_messages.append(msg)

    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        for i in tqdm(range(9)):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")
    # logging restored

    tqdm.write = written


# Generated at 2022-06-12 14:43:42.734023
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    level = logging.WARN
    logger = logging.getLogger('__main__')
    logger.setLevel(level)
    stream = sys.stdout
    stream.truncate(0)
    stream.seek(0)
    formatter = logging.Formatter('%(levelname)s:\t%(message)s')
    with logging_redirect_tqdm(loggers=[logger]):
        for handler in logger.handlers:
            assert isinstance(handler, _TqdmLoggingHandler)
            assert handler.tqdm_class == std_tqdm

        with tqdm_logging_redirect(loggers=[logger]):
            for handler in logger.handlers:
                assert isinstance(handler, _TqdmLoggingHandler)
                assert handler.tqdm_

# Generated at 2022-06-12 14:43:50.700894
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    import logging
    import logbook
    from tqdm import trange

    # Logger
    log = logging.getLogger(__name__)

    # Log handlers
    log.addHandler(logging.NullHandler())
    fh = logbook.TestHandler()

    # Logging level
    log.setLevel(logging.DEBUG)

    assert [h.stream for h in log.handlers] == [logging.NullHandler()]
    with tqdm_logging_redirect(desc='Test', file=sys.stdout, miniters=100) as pbar:
        with fh:
            for i in trange(5):
                log.debug('This is a test log in DEBUG mode.')

# Generated at 2022-06-12 14:44:08.854549
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import NOTSET, LogRecord
    from six import PY2
    from ..std import tqdm, tqdm_gui
    from ..pandas import tqdm_pandas

    for tqdm_class in [tqdm, tqdm_gui, tqdm_pandas]:
        string_io = StringIO()
        tqdm_class = tqdm_class.__class__
        handler = _TqdmLoggingHandler(tqdm_class)
        handler.stream = string_io
        handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s'))

# Generated at 2022-06-12 14:44:15.097594
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> ...
    """
    Testing function.
    """
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        pbar = trange(3)
        with logging_redirect_tqdm(pbar):
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        pbar.close()

        # logging restored
        logging.info("console logging restored")

# Generated at 2022-06-12 14:44:20.613442
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # type: () -> None
    """
    Unit test for method emit of class _TqdmLoggingHandler

    This test creates a fake logger using a custom log record, and makes sure
    that the fake logger's message is printed when the emit method is called.
    """
    # Create fake log record to setup fake logger
    logging_record = logging.LogRecord(
        'logger_name',
        logging.INFO,
        'pathname',
        line_no=10,
        msg='fake log message',
        args=[],
        exc_info=None)

    # Create fake logger
    logger = logging.Logger('logger_name')

    # Create instance of _TqdmLoggingHandler with fake logger
    tqdm_logger = _TqdmLoggingHandler()

    # Provide fake log record to logger
    logger

# Generated at 2022-06-12 14:44:24.700138
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import trange
    loggers = [logging.root]
    with tqdm_logging_redirect(loggers=loggers):
        for i in trange(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")

# Generated at 2022-06-12 14:44:36.079894
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import re
    import os
    import sys

    # Click was causing an issue during testing on Windows
    # https://github.com/tqdm/tqdm/issues/667
    try:
        import click
    except ImportError:
        pass
    else:
        if 'click' in sys.modules:
            del sys.modules['click']

    from .iris_tqdm import tqdm

    s = []
    logger = logging.getLogger(__name__)

    def test():
        # type: () -> None
        for i in tqdm(range(9)):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")


# Generated at 2022-06-12 14:44:43.700994
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import sys

    # Set up a stream to catch output
    class TqdmStream(object):
        def __init__(self):
            self.buf = ''

        def write(self, string):
            self.buf += string

    with TqdmStream() as stream:
        old_sysout = sys.stdout

# Generated at 2022-06-12 14:44:51.959533
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    import threading
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = logging.getLogger(__name__)

    # Redirection
    with logging_redirect_tqdm(tqdm_class=lambda x: x):
        for i in range(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

    # Redirection via direct call to tqdm
    with tqdm_logging_redirect():
        for i in range(9):
            if i == 4:
                logger.info("console logging redirected to `tqdm.write()`")

    # Redirection via direct call to tqdm and log specific loggers

# Generated at 2022-06-12 14:44:56.159376
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from .helper import TestLoggingRedirection
    with TestLoggingRedirection(redirect_logs=True) as logger:
        LOG = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=9):
            for i in range(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored



# Generated at 2022-06-12 14:45:00.900364
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from tqdm import trange
    import logging
    import logging.handlers
    log = logging.getLogger()
    log.handlers = []
    tqdm_handler = _TqdmLoggingHandler()
    log.addHandler(tqdm_handler)
    with tqdm_logging_redirect(total=100, unit='it', loggers=[log]) as pbar:
        for _ in trange(10):
            log.info("this is a test")
        # test a non-string message
        log.info(42)
        for _ in trange(10):
            pbar.update(10)

# Generated at 2022-06-12 14:45:11.462373
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import contextlib
    import io
    import tempfile
    import unittest

    @contextlib.contextmanager
    def outfile_cached(func):
        # type: (Callable[..., Any]) -> Iterator[str]
        with tempfile.SpooledTemporaryFile() as stdout:
            with tempfile.SpooledTemporaryFile() as stderr:
                with io.StringIO() as out:
                    with io.StringIO() as err:
                        setattr(sys, '__stdout__', stdout)
                        setattr(sys, '__stderr__', stderr)
                        sys.stdout = out
                        sys.stderr = err
                        try:
                            yield func()
                        finally:
                            sys.stdout = sys.__stdout__
                            sys.st

# Generated at 2022-06-12 14:45:26.576714
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                LOG.info("console logging redirected to `tqdm.write()`")



# Generated at 2022-06-12 14:45:36.858272
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    import io
    import logging
    import unittest

    class TestWriter(object):
        def __init__(self):
            self._io_buf = io.StringIO()

        def write(self, text):
            self._io_buf.write(text)
            self._io_buf.write('\n')

        def get_all(self):
            self._io_buf.seek(0)
            return self._io_buf.read()

    class _TestTqdmWriter(std_tqdm):
        _file = None

        @classmethod
        def write(cls, text, file=None):
            if file is None or cls._file is None or file is cls._file:
                cls._file = file


# Generated at 2022-06-12 14:45:46.608531
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import time
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    logger = logging.getLogger('test')
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    capture_string = StringIO()
    handler.setFormatter(logging.Formatter('%(message)s'))
    handler.stream = capture_string

    # Without logging redirection
    with tqdm_logging_redirect(
            total=3,
            desc='test1',
            leave=True,
            disable=False,
            logger=logger,
    ):
        logger.info('string 1')
        time.sleep(3)
        logger.info('string 2')
        time.sleep(3)
        logger.info('string 3')

# Generated at 2022-06-12 14:45:53.722831
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    from io import StringIO
    from logging import WARNING, getLogger
    log = getLogger()
    log.addHandler(_TqdmLoggingHandler())
    log.setLevel(WARNING)
    log.warning("This is a warning")
    out = sys.stderr.getvalue()
    out = out[:out.rfind('\r') + len('\r')]
    assert "This is a warning" in out, out
    with StringIO() as buffer:
        log.warning("This is a warning")
        out = buffer.getvalue()
        out = out[:out.rfind('\r') + len('\r')]
    assert "This is a warning" in out, out

# Generated at 2022-06-12 14:45:58.886243
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


# Generated at 2022-06-12 14:46:06.439043
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    LOG.info("starting...")
    with tqdm_logging_redirect(
        ["foo", "bar", "baz"],
        disable=False,
        miniters=1,
    ) as pbar:
        for i in range(3):
            pbar.set_description(str(i))
            LOG.info("console logging redirected to `tqdm.write()`")
    LOG.info("done.")
    # You should see "starting..." and "done." in stderr
    # You should see "0", "1", "2" in stderr but with a progress bar
    # You should see "console logging redirected to `tqdm.write()`"
    #

# Generated at 2022-06-12 14:46:11.095691
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    def test():
        # type: () -> None
        import logging
        from tqdm.contrib.logging import tqdm_logging_redirect

        logger = logging.getLogger(__name__)

        with tqdm_logging_redirect(
            desc='test',
            total=2,
            bar_format='{desc}: {bar}|{n_fmt}/{total_fmt}') as test_pbar:
            for i in range(test_pbar.total):
                test_pbar.set_description_str(__name__)
                logger.debug(__name__)
                logger.info(__name__)
                logger.warning(__name__)
                logger.error(__name__)
                logger.critical(__name__)
                test_pbar.update

# Generated at 2022-06-12 14:46:19.289405
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = logging.getLogger(__name__)

    logging.basicConfig(level=logging.INFO)

    for i in trange(9):
        if i == 4:
            with logging_redirect_tqdm():
                for i in trange(3):
                    logger.info("console logging redirected to `tqdm.write()`")

    logger.info("back to normal logging")
    logger.info("another normal line")



# Generated at 2022-06-12 14:46:23.412162
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    with logging_redirect_tqdm():
        logging.info("INFO")


if __name__ == "__main__":
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:46:27.768109
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    logging.basicConfig(level=logging.INFO)
    for i in range(9):
        if i == 4:
            with logging_redirect_tqdm():
                logging.info('test_logging_redirect_tqdm')
        else:
            logging.info('test_logging_redirect_tqdm')

# Generated at 2022-06-12 14:46:57.651964
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from os import remove
    from os.path import exists
    LOG = logging.getLogger("TEST_LOGGER")
    LOG.setLevel(logging.DEBUG)
    logging.getLogger().setLevel(logging.DEBUG)
    # Check if the file doesn't exist:
    if exists("test.log"):
        remove("test.log")
    # Add the log message handler to the logger
    fh = logging.FileHandler("test.log")
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    LOG.addHandler(fh)
    # logging.root is expected to emit log messages to console.
    # But in this context console log output

# Generated at 2022-06-12 14:47:07.883401
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    handler = _TqdmLoggingHandler()
    old_tqdm_write = std_tqdm.write
    handler.stream = sys.stdout

# Generated at 2022-06-12 14:47:14.902016
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    try:
        import logging
        from tqdm import trange
        from tqdm.contrib.logging import logging_redirect_tqdm

        LOG = logging.getLogger(__name__)

        if __name__ == '__main__':
            logging.basicConfig(level=logging.INFO)
            for i in trange(4):
                if i == 1:
                    with logging_redirect_tqdm():
                        LOG.info("console logging redirected to `tqdm.write()`")
                    LOG.info("logging restored")
    except Exception as e:
        print("Exception in test_logging_redirect_tqdm: {0}".format(e))

# Generated at 2022-06-12 14:47:23.106297
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from unittest.mock import Mock  # type: ignore
    except ImportError:
        from mock import Mock  # type: ignore
    from tqdm import tqdm, std
    try:
        from contextlib import ExitStack  # type: ignore
    except ImportError:
        from contextlib2 import ExitStack  # type: ignore
    from tqdm.contrib.logging import logging_redirect_tqdm

    logger = Mock()
    with ExitStack() as stack:
        stack.enter_context(logging_redirect_tqdm(tqdm_class=std.tqdm))
        stack.enter_context(tqdm_logging_redirect(tqdm_class=std.tqdm))
        # test
        logger.info('test')
    assert logger.info

# Generated at 2022-06-12 14:47:28.996193
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .tests_tqdm import with_setup, _range
    import logging

    logger = logging.getLogger('tqdm')
    logger.handlers = []

    def _test_logging_redirect_tqdm():
        for _ in _range(3):
            logger.info("This is a test")

    with with_setup(_test_logging_redirect_tqdm):
        handler = _get_first_found_console_logging_handler(logger.handlers)
        assert handler is None, handler
        with logging_redirect_tqdm():
            for _ in _range(3):
                logger.info("This is a test")
        handler = _get_first_found_console_logging_handler(logger.handlers)
        assert handler is None, handler

# Generated at 2022-06-12 14:47:34.656109
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    from .tests import TestCaseMixin, _range
    from .tests._utils import CatchLogging
    import tqdm
    import logging

    log = logging.getLogger(__name__)
    with CatchLogging(log, logging.DEBUG, tqdm=tqdm) as clog:
        with tqdm_logging_redirect(
                total=10,
                loggers=[log],
                tqdm_class=tqdm
        ):
            for _ in _range(10):
                log.debug('test_logging_redirect_tqdm')

        assert 'test_logging_redirect_tqdm' in clog.value()



# Generated at 2022-06-12 14:47:42.780224
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored


if __name__ == '__main__':
    # _test()  # test console output
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:47:49.541318
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from .tqdm import tqdm
    import logging
    import time

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    with logging_redirect_tqdm(logger=logger, tqdm_class=tqdm):
        logger.info("console logging redirected to tqdm.write")
    logger.removeHandler(stream_handler)

# Generated at 2022-06-12 14:47:57.745844
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    # python3 -c "import tqdm; import tqdm.contrib; tqdm.contrib.test(tqdm.contrib.logging.test_tqdm_logging_redirect)"
    from unittest import TestCase

    class Test(TestCase):
        """Tests that logging is redirected to tqdm.write()."""

        def setUp(self):
            # type: () -> None
            """Set up logging.Logger and capture stderr."""
            super(Test, self).setUp()
            self.logger = logging.getLogger('my_logger')
            self.logger.setLevel(logging.INFO)
            self.stream = sys.stderr = StringIO.StringIO()


# Generated at 2022-06-12 14:48:06.379890
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import random
    import os
    import sys
    # import urllib.request
    import logging
    from unittest import TestCase
    from tqdm import trange
    from tqdm.contrib.logging import logging_redirect_tqdm

    LOG = logging.getLogger(__name__)

    class Shell(TestCase):

        def setUp(self):
            self._orig_stdout = sys.stdout
            self._orig_stderr = sys.stderr
            self._stdout_fd = open(os.devnull, 'w')  # pragma: no cover
            self._stderr_fd = open(os.devnull, 'w')  # pragma: no cover
            sys.stdout = self._stdout_fd
            sys.stderr = self._stder

# Generated at 2022-06-12 14:49:07.412846
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect

    LOG = logging.getLogger(__name__)

    with tqdm_logging_redirect() as pbar:
        pbar.write("This is tqdm")
        LOG.info("This is logging")

# Generated at 2022-06-12 14:49:12.376101
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    original_handlers_list = [logging.root.handlers]
    with tqdm_logging_redirect() as pbar:
        assert isinstance(pbar, std_tqdm)
        orig_handler = _get_first_found_console_logging_handler(logging.root.handlers)
        assert orig_handler is None
        assert logging.root.handlers != original_handlers_list

# Generated at 2022-06-12 14:49:21.589019
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    from contextlib import redirect_stdout
    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3
    import logging
    from tqdm.contrib.logging import tqdm_logging_redirect
    from tqdm import trange

    log_str = StringIO()
    logging.basicConfig(stream=log_str, level=logging.INFO)

    with redirect_stdout(log_str):
        with tqdm_logging_redirect(total=9, loggers=logging.root.manager.loggerDict.values()) as pbar:
            for i in trange(9):
                if i == 4:
                    logging.info("console logging redirected to tqdm.write()")


# Generated at 2022-06-12 14:49:28.572549
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger()
    from tqdm import trange
    with logging_redirect_tqdm():
        for i in trange(9):
            if i == 4:
                log.info("console logging redirected to `tqdm.write()`")
    # logging restored
    for i in range(9):
        if i == 4:
            log.info("console logging NOT redirected")

if __name__ == '__main__':
    test_logging_redirect_tqdm()

# Generated at 2022-06-12 14:49:36.483912
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    import tempfile
    import os
    import io


    logging.basicConfig(level=logging.INFO)
    LOG = logging.getLogger(__name__)
    log_file = os.path.join(tempfile.mkdtemp(), 'log_file')

    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(logging.Formatter(''))
    LOG.addHandler(file_handler)

    for i in range(10):
        LOG.info('Iteration {}'.format(i))

    with io.open(log_file, encoding='utf-8') as _:
        assert _.read(2) == '1 '
        assert _.read(2) == '2 '


# Generated at 2022-06-12 14:49:40.436095
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    logging.basicConfig(level=logging.INFO)
    with tqdm_logging_redirect() as pbar:
        for i in range(9):
            if i == 4:
                logging.info("console logging redirected to `tqdm.write()`")
            pbar.update()

# Generated at 2022-06-12 14:49:48.336756
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    # Test default
    with tqdm_logging_redirect() as pbar:
        pbar.write("test_logging_redirect_tqdm")
        logging.info("test_logging_redirect_tqdm")
        # logging.info("  (called from within test_logging_redirect_tqdm)")
    # logging.info("test_logging_redirect_tqdm")

    # Test explicitly defined
    with tqdm_logging_redirect(loggers=[logging.getLogger()]) as pbar:
        pbar.write("test_logging_redirect_tqdm")
        logging.info("test_logging_redirect_tqdm")
        # logging.info("  (called from within test_logging_redirect_tq

# Generated at 2022-06-12 14:49:54.957069
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    try:
        # pylint: disable=unused-variable
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import logging
    loggers = [logging.getLogger('tqdm'), logging.getLogger('foo')]
    for logger in loggers:
        logger.setLevel(logging.DEBUG)
        logger.addHandler(_TqdmLoggingHandler())

    with tqdm_logging_redirect() as pbar:
        for logger in loggers:
            logger.debug('testing tqdm + logging')
            logger.info('testing tqdm + logging')
    # check that they are still present
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], _TqdmLoggingHandler)


#

# Generated at 2022-06-12 14:50:01.348097
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    """
    Test for the emit method of class _TqdmLoggingHandler.
    We test if the method of tqdm.write is called or not.
    """
    log = logging.getLogger('test')
    with std_tqdm.patch(tqdm_class=std_tqdm):
        handler = _TqdmLoggingHandler(tqdm_class=std_tqdm)
        log.addHandler(handler)
        log.handlers[0].emit('test')


# Generated at 2022-06-12 14:50:08.401310
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from .tests_tqdm import discretize, pretest_posttest  # type: ignore
    except (ImportError, ValueError):
        return

    @pretest_posttest
    @discretize
    def test_tqdm_logging_redirect_():
        import logging
        import time

        logging.basicConfig(level=logging.INFO)
        with tqdm_logging_redirect(total=5) as pbar:
            pbar.postfix = 'pbar'
            pbar.update()
            time.sleep(.1)  # to show update()
            LOG = logging.getLogger(__name__)
            LOG.info('logging')
            pbar.update()
            # restore logging
            # logging already restored in yield

# Generated at 2022-06-12 14:51:36.893257
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    from .test_std import TestTqdmLoggingHandler

    with TestTqdmLoggingHandler() as stream:
        with tqdm_logging_redirect(total=4) as log_bar:
            logging.warn('hello')
            assert stream.data[-1] == '\rwarn:hello'

            logging.exception('blah')
            assert stream.data[-1] == '\rexception:blah'

            logging.getLogger().warning('yep')
            assert stream.data[-1] == '\rwarning:yep\n'

            log_bar.update(1)  # NB: tqdm does not appear

            logging.info('info')
            assert stream.data[-1] == '\rinfo:info\n'

            log_bar.update(1)  #

# Generated at 2022-06-12 14:51:45.180379
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    try:
        from tqdm import tqdm
    except ImportError:
        return
    from tqdm.utils import _decode as de  # noqa pylint: disable=unused-import

    lines = []
    with open("test_log", "w") as f_log:
        lines.append("line0")
        f_log.write(lines[-1] + "\n")
        logging.basicConfig(filename=f_log.name, level=logging.INFO)
        LOG = logging.getLogger(__name__)

# Generated at 2022-06-12 14:51:48.807057
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm import trange
    logger = logging.getLogger(__name__)

    with logging_redirect_tqdm([logger]):
        for i in trange(10):
            logger.info('Test %d', i)



# Generated at 2022-06-12 14:51:51.269857
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    import logging
    from tqdm import tqdm
    with tqdm_logging_redirect(tqdm_kwargs={'total': 10}) as pbar:
        logging.info(pbar)

# Generated at 2022-06-12 14:51:55.210310
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    # type: () -> None
    import logging
    from tqdm import trange

    LOG = logging.getLogger(__name__)

    if __name__ == '__main__':
        logging.basicConfig(level=logging.INFO)
        with logging_redirect_tqdm():
            for i in trange(9):
                if i == 4:
                    LOG.info("console logging redirected to `tqdm.write()`")
        # logging restored

# Generated at 2022-06-12 14:51:56.229667
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging

    with logging_redirect_tqdm():
        logging.info('test log')


# Generated at 2022-06-12 14:51:57.003861
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    pass
    #TODO

# Generated at 2022-06-12 14:52:01.895763
# Unit test for method emit of class _TqdmLoggingHandler
def test__TqdmLoggingHandler_emit():
    # capture console output
    output = sys.stdout
    sys.stdout = open('test_TqdmLoggingHandler_emit.txt', 'w')
    handler = _TqdmLoggingHandler()
    record = logging.LogRecord('my_logger', logging.INFO, None, None, 'my_msg', (), None, None)
    handler.emit(record)



# Generated at 2022-06-12 14:52:12.041495
# Unit test for function tqdm_logging_redirect
def test_tqdm_logging_redirect():
    # type: () -> None
    from .tests import closing, _range, tqdm
    from .std import TestCase

    def _raise():
        # type: () -> None
        raise AssertionError

    with closing(TestCase.CapturedIO()):
        with tqdm_logging_redirect(
                _range(4),
                loggers=[logging.root],
                tqdm_class=tqdm,
                desc='Logging',
                disable=True):
            _raise()
        assert 'Logging:   0it [00:00, ?it/s]' in TestCase.CapturedIO.getvalue()


# Generated at 2022-06-12 14:52:19.703396
# Unit test for function logging_redirect_tqdm
def test_logging_redirect_tqdm():
    import logging
    from tqdm._utils import _term_move_up
    from tqdm.auto import tqdm

    with tqdm(total=5, dynamic_ncols=True) as pbar:
        with logging_redirect_tqdm():
            logger = logging.getLogger(__name__)
            logger.info("console logging redirected to `tqdm.write()`")
            pbar.update()
    print("Output restored")

    assert pbar.n == 1

    # Check no output is printed
    with tqdm(total=5, dynamic_ncols=True) as pbar:
        with logging_redirect_tqdm(tqdm_class=lambda x: x):
            logger = logging.getLogger(__name__)