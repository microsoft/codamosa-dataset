

# Generated at 2022-06-23 05:11:20.158816
# Unit test for function jsonify
def test_jsonify():
    import nose
    import sys

    if sys.version_info < (2, 7):
        raise nose.SkipTest("jsonify unit tests require python >= 2.7")

    import json

    # test simple dict
    result = dict(foo=1, bar='two', bam=None)
    jsonified = jsonify(result)
    assert jsonified == '{"bar": "two", "bam": null, "foo": 1}'

    # test simple dict with formatting
    result = dict(foo=1, bar='two', bam=None)
    jsonified = jsonify(result, True)
    assert jsonified == json.dumps(result, sort_keys=True, indent=4, ensure_ascii=False)

    # test simple list
    result = [1, 'two', None]
    jsonified = jsonify

# Generated at 2022-06-23 05:11:22.248281
# Unit test for function jsonify
def test_jsonify():
    #assert False, jsonify('test')
    assert False, jsonify(None)
    assert False, jsonify(False)
    assert False, jsonify(True)

# Generated at 2022-06-23 05:11:33.309694
# Unit test for function jsonify
def test_jsonify():

    import sys
    import io

    # Capture stdout for later restoring to it
    old_stdout = sys.stdout
    sys.stdout = mystdout = io.StringIO()

    # no indentation
    print(jsonify({'a': 2}))
    assert mystdout.getvalue().strip() == '{"a": 2}'

    # indentation
    print(jsonify({'a': 2}, format=True))
    assert mystdout.getvalue().rstrip() == '{\n    "a": 2\n}'

    # Restore stdout
    sys.stdout = old_stdout

# Generated at 2022-06-23 05:11:36.900636
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}'
    assert jsonify(dict(changed=False, rc=0), True) == '{\n    "changed": false, \n    "rc": 0\n}'

# Generated at 2022-06-23 05:11:47.559783
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify

    def _validate(input_string, valid):
        output = jsonify(input_string)
        assert valid == output

    _validate("foo", '"foo"')
    _validate("foo\nbar", '"foo\\nbar"')
    _validate("foo\rbar", '"foo\\rbar"')
    _validate("foo\tbar", '"foo\\tbar"')
    _validate("foo\bbar", '"foo\\bbar"')
    _validate("foo\"bar", '"foo\\"bar"')
    _validate("foo\\bar", '"foo\\\\bar"')
    _validate("foo/bar", '"foo/bar"')



# Generated at 2022-06-23 05:11:54.135007
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''

    assert jsonify(None, format=True) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({}, format=True) == "{\n    \"changed\": false, \n    \"failed\": false, \n    \"meta\": {}\n}"

    # This is valid input, but uses keys we can't cleanly format with the above.
    jsons = '{"changed": false, "failed": "true"}'
    assert jsonify(jsons, format=True) == jsons

# Generated at 2022-06-23 05:12:02.735879
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-23 05:12:05.215032
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":1}) == '{"a": 1}'
    assert jsonify({"a":1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-23 05:12:15.207209
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({}, format=True) == '{}'
    assert jsonify({'a':1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify({'a':1, 'b':2, 'c':3}, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert jsonify({'a':1, 'b':2, 'c':{'d':4, 'e':5}}, format=True) == '{\n    "a": 1,\n    "b": 2,\n    "c": {\n        "d": 4,\n        "e": 5\n    }\n}'

# vim: set expand

# Generated at 2022-06-23 05:12:19.010333
# Unit test for function jsonify
def test_jsonify():
    result = { 'a' : 1, 'b' : 2}
    assert jsonify(result, format=False) == "{\"a\": 1, \"b\": 2}"
    assert jsonify(result, format=True)  == "{\n    \"a\": 1, \n    \"b\": 2\n}"

# Generated at 2022-06-23 05:12:23.054227
# Unit test for function jsonify
def test_jsonify():
    result = { 'abc': 5, 'def': 7, 'ghi': [1,2,3] }
    for indent in (None, 2, 4):
        assert json.loads(jsonify(result, indent)) == result

    result = { u'abc': 5, u'def': 7 }
    assert json.loads(jsonify(result)) == result

# Generated at 2022-06-23 05:12:31.578270
# Unit test for function jsonify
def test_jsonify():
    # Test normal dictionary
    json_str = jsonify({'skipped':False, 'msg':'', 'failed':False, 'invocation':{'module_name':'shell', 'module_args':'echo 123'}, 'changed':False, 'rc':0, 'stdout':'123\n', 'stdout_lines':['123'], 'stderr':'', 'results':123, '_ansible_verbose_always':False, '_ansible_no_log':False})
    assert isinstance(json_str,basestring)
    assert len(json_str) == 176

# Generated at 2022-06-23 05:12:43.575005
# Unit test for function jsonify
def test_jsonify():
    indented = False
    for result in [None, {},
                   {'a': ['foo', 'bar', 1234, None]},
                   {'a': {'b': {'c': [1, 2, 3]},
                          'd': ['a', 'b', 'c'],
                          'f': True}},
                   {'a': ['foo', {'bar': ('baz', None, 1.23, 2)},
                         {'f': 'f'}],
                    'd': {'z': 'z'}}]:
        if indented:
            print("%s\n" % jsonify(result, True))
        else:
            print("%s\n" % jsonify(result))
        indented = True


if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-23 05:12:52.019806
# Unit test for function jsonify
def test_jsonify():
    data = {
        "a": [1,2,3],
        "b": [4,5,6],
    }
    assert jsonify(data) == '{"a": [1, 2, 3], "b": [4, 5, 6]}'
    assert jsonify(data, True) == '''{
    "a": [
        1,
        2,
        3
    ],
    "b": [
        4,
        5,
        6
    ]
}'''

# Generated at 2022-06-23 05:12:58.983880
# Unit test for function jsonify
def test_jsonify():
    # test formatting
    data = {"test":"test","test1":1}
    result = jsonify(data, format=True) + "\n"
    assert(result == '{\n    "test": "test", \n    "test1": 1\n}\n')
    # test not formatting
    result = jsonify(data, format=False)
    assert(result == '{"test": "test", "test1": 1}')


# Generated at 2022-06-23 05:13:06.342306
# Unit test for function jsonify
def test_jsonify():
    result = {'a':1, 'b':[2,3]}
    retval = jsonify(result)
    assert retval == u'{"a": 1, "b": [2, 3]}'
    retval = jsonify(result, True)
    assert retval == u'{\n    "a": 1, \n    "b": [\n        2, \n        3\n    ]\n}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:13:15.939615
# Unit test for function jsonify
def test_jsonify():
    import unittest
    import sys

    class TestSequenceFunctions(unittest.TestCase):

        def test_jsonify(self):
            # Make sure the results are correct
            result = {"a": 1, "b": [1, 2, 3], "c": {"1": "2", "3": "4"}}

            # Simple test
            self.assertEqual(jsonify(result),
                '{"a": 1, "b": [1, 2, 3], "c": {"1": "2", "3": "4"}}')

            # Simple test with format set to True

# Generated at 2022-06-23 05:13:21.556822
# Unit test for function jsonify
def test_jsonify():

    # Test with None
    assert jsonify(None) == '{}'

    # Test with a dict containing some non-ascii characters
    result = dict(hostname='foo.bar', name='will-richards', changed=True, foo='\xc3\xbcnic\xc3\xb6de')
    assert jsonify(result) == jsonify(result, True) == '{"changed": true, "foo": "\\u00fcnic\\u00f6de", "hostname": "foo.bar", "name": "will-richards"}'

# Generated at 2022-06-23 05:13:29.130593
# Unit test for function jsonify
def test_jsonify():
    result = dict(foo="bar")
    formatted = jsonify(result, format=True)
    unformatted = jsonify(result, format=False)

    assert formatted.count('\n') == 2
    assert formatted.count('    ') == 1

    assert unformatted.count('\n') == 0

    assert formatted == '{\n    "foo": "bar"\n}'
    assert unformatted == '{"foo": "bar"}'

# Generated at 2022-06-23 05:13:39.159676
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify({'a':1, 'b':2, 'c':3}) == "{\"a\": 1, \"b\": 2, \"c\": 3}"

    assert jsonify(None, format=True) == "{}"
    assert jsonify([1, 2, 3], format=True) == "[1, 2, 3]"
    assert jsonify({'a':1, 'b':2, 'c':3}, format=True) == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3\n}"

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:13:48.031953
# Unit test for function jsonify
def test_jsonify():
    from collections import namedtuple

    # Test tuple
    test_tuple = (1, 2, 3)
    assert isinstance(jsonify(test_tuple, True), basestring)
    assert jsonify(test_tuple, True) == '{\n    "args": [\n        1, \n        2, \n        3\n    ], \n    "kwargs": {}\n}'
    assert isinstance(jsonify(test_tuple), basestring)
    assert jsonify(test_tuple) == '{"args": [1, 2, 3], "kwargs": {}}'

    # Test named tuple
    test_named_tuple = namedtuple("TestNamedTuple", "a b c")

# Generated at 2022-06-23 05:13:58.304268
# Unit test for function jsonify
def test_jsonify():
    # Test None, empty string, and empty array
    assert(jsonify(None) == '{}')
    assert(jsonify({}) == '{}')
    assert(jsonify([]) == '[]')

    # Test JSON format
    expected = '''{
    "a": "1",
    "b": "2"
}'''
    assert(jsonify({'a': '1', 'b': '2'}, True) == expected)

    # Test Unicode
    assert(jsonify({'a': '\xc2\xa2'}) == '{"a": "\xc2\xa2"}')
    assert(jsonify({'a': '\xc2\xa2'}, True) == '{\n    "a": "\xc2\xa2"\n}')

# Generated at 2022-06-23 05:14:04.143450
# Unit test for function jsonify
def test_jsonify():
    result = {
        'changed': False,
        'failed': False,
        'pong': 'pong',
    }

    output = jsonify(result)
    assert output == '{"changed": false, "failed": false, "pong": "pong"}'

    output = jsonify(result, True)
    assert output == '{\n    "changed": false,\n    "failed": false,\n    "pong": "pong"\n}'

# Generated at 2022-06-23 05:14:14.597436
# Unit test for function jsonify
def test_jsonify():
    ''' Check that jsonify returns the right value '''
    assert '"foo"' in jsonify({'foo':1})
    assert '"foo"' in jsonify(dict(foo=1))
    assert '"foo"' in jsonify([1])
    assert '"foo"' in jsonify({'foo':[1,2,3]})
    assert '"foo"' in jsonify([{'foo':1}])
    assert jsonify(None) == '{}'
    assert jsonify(False) == 'false'
    assert jsonify(True) == 'true'
    assert jsonify("foo") == '"foo"'
    assert jsonify(0) == '0'
    assert jsonify(1) == '1'
    assert jsonify("JSON\n") == '"JSON\\n"'

# Generated at 2022-06-23 05:14:21.261817
# Unit test for function jsonify
def test_jsonify():

    # Test an empty dictionary
    assert jsonify({}) == "{}"

    # Test a simple list
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"

    # Test a simple dictionary
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'

    # Test a dictionary with objects
    assert jsonify({"a": [1, 2], "b": {"c": "d"}}) == '{"a": [1, 2], "b": {"c": "d"}}'

# Generated at 2022-06-23 05:14:31.258114
# Unit test for function jsonify
def test_jsonify():
    tests = [
        ([], '[]'),
        ({}, '{}'),
        ({'a': [1, 2, 3]}, '{"a": [1, 2, 3]}'),
        ({'a': [1, 2, 3], 'b': [4, 5, 6]}, '{"a": [1, 2, 3], "b": [4, 5, 6]}'),
        ({"a": [1, 2, 3], "b": [4, 5, 6]}, '{"a": [1, 2, 3], "b": [4, 5, 6]}'),
    ]
    for testcase in tests:
        assert jsonify(testcase[0]) == testcase[1]

if __name__ == '__main__':
  test_jsonify()

# Generated at 2022-06-23 05:14:33.153908
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"


# Generated at 2022-06-23 05:14:41.937241
# Unit test for function jsonify
def test_jsonify():
    # Dict
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    # List
    assert jsonify(["a", 1, "b", 2]) == '["a", 1, "b", 2]'
    # Str
    assert jsonify("test") == '"test"'
    # Int
    assert jsonify(1) == '1'
    # None
    assert jsonify(None) == '{}'
    # Set
    assert jsonify(set(["a", "b"])) == '["a", "b"]'

# Generated at 2022-06-23 05:14:47.567617
# Unit test for function jsonify
def test_jsonify():
    import sys
    if __name__ == '__main__':
        if sys.version_info[0] >= 3 and sys.version_info[1] >= 3:
            json.dumps = None
        class dummy_json(object):
            @staticmethod
            def dumps(result, sort_keys=True, indent=None, ensure_ascii=False):
                return "dummy_json"
        sys.modules["json"] = dummy_json
        jsonify_result = jsonify(dict(), False)
        assert "dummy_json" == jsonify_result

# Generated at 2022-06-23 05:14:54.935129
# Unit test for function jsonify
def test_jsonify():

    # Test normal case
    result = dict(foo=0, bar=1, bam=2)
    assert(jsonify(result, False) == '{"bar": 1, "bam": 2, "foo": 0}')

    # Test pretty print option
    assert(jsonify(result, True) == '{\n    "bar": 1, \n    "bam": 2, \n    "foo": 0\n}')

# Generated at 2022-06-23 05:15:05.523178
# Unit test for function jsonify
def test_jsonify():
    data = dict(foo="bar", bam=["boom", 1, 2, 3],
                null_value=None, int_value=1, float_value=3.1415)
    expected = '''{
    "bam": [
        "boom",
        1,
        2,
        3
    ],
    "foo": "bar",
    "float_value": 3.1415,
    "int_value": 1,
    "null_value": null
}'''

    # test jsonify of dict with various parameters
    assert expected == jsonify(data, True)
    assert expected == jsonify(data, False)
    assert expected == jsonify(data)

    # test jsonify of None returns '{}'
    assert '{}' == jsonify(None)

# Generated at 2022-06-23 05:15:16.983840
# Unit test for function jsonify
def test_jsonify():

    def test_assertion(result, format=False):
        j1 = jsonify(result, format=format)
        j2 = jsonify(json.loads(j1), format=format)
        assert j1 == j2

    test_assertion({}, format=False)
    test_assertion({}, format=True)
    test_assertion({'foo': 1}, format=False)
    test_assertion({'foo': 1}, format=True)
    test_assertion({'foo': {'bar': 2}}, format=False)
    test_assertion({'foo': {'bar': 2}}, format=True)
    test_assertion({'foo': {'bar': {'baz': 3}}}, format=False)

# Generated at 2022-06-23 05:15:18.530613
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'value': 'ok'}, format=True) == '{\n    "value": "ok"\n}'

# Generated at 2022-06-23 05:15:30.100470
# Unit test for function jsonify
def test_jsonify():
    from ansible.inventory.host import Host

    # Make sure we can jsonify a Host
    a = Host(name='just.testing')
    assert jsonify(a.get_vars()) == '{"ansible_python_interpreter": "/usr/bin/python", "ansible_ssh_host": "just.testing"}'

    # Make sure we can jsonify a list of hosts
    b = [Host(name='b1'), Host(name='b2'), Host(name='b3')]

# Generated at 2022-06-23 05:15:36.706756
# Unit test for function jsonify
def test_jsonify():
    result = dict(contacted=dict(server01=dict(invocation=dict(module_args=dict())))) # missing u'changed'
    assert jsonify(result) == '{"contacted": {"server01": {"invocation": {"module_args": {}}}}}'
    assert jsonify(result, True) == '''{
    "contacted": {
        "server01": {
            "invocation": {
                "module_args": {}
            }
        }
    }
}'''

# Generated at 2022-06-23 05:15:47.456253
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    mem_inventory = InventoryManager(loader=loader, sources=None)
    host = Host(name="foo")
    hostvars = HostVars(host=host, variables={ "bar": "baz" })
    mem_inventory.add_host(host, group=None)
    mem_inventory.set_variable(host, "foo", "bar")
    mem_inventory.set_variable(host, "ansible_connection", "local")
    mem_inventory.set_

# Generated at 2022-06-23 05:15:58.799822
# Unit test for function jsonify
def test_jsonify():
    import os
    import tempfile

    if not os.path.exists('/tmp/test_jsonify'):
        os.mkdir('/tmp/test_jsonify')

    tmpfd, tmpfile = tempfile.mkstemp(prefix='ansible_test_jsonify_', dir='/tmp/test_jsonify')

    test_data = { 'a': 1, 'b': 2, 'c': 3 }

    json_string = jsonify(test_data, True)
    assert '\n' in json_string
    assert json.loads(json_string) == test_data

    json_string = jsonify(test_data, False)
    assert '\n' not in json_string
    assert json.loads(json_string) == test_data

# Generated at 2022-06-23 05:16:04.612027
# Unit test for function jsonify
def test_jsonify():

    # this is an example return from a module
    x = dict(omg="zomg",
             answer=42,
             changed=False,
             foo=dict(bar='baz'),
             listy=[1,2,3],
             null=None)

    # this should be exactly what the function returns
    y = '{"changed": false, "answer": 42, "foo": {"bar": "baz"}, "listy": [1, 2, 3], "omg": "zomg", "null": null}'

    assert jsonify(x) == y


# Generated at 2022-06-23 05:16:07.539082
# Unit test for function jsonify
def test_jsonify():
   assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:16:15.146797
# Unit test for function jsonify
def test_jsonify():
    ''' make sure we format JSON like a boss '''

    result = {
        "changed" : False,
        "ping"    : "pong",
        "foo"     : [ "one", "two", "three" ],
    }

    assert jsonify(result, format=False) == '{"changed": false, "foo": ["one", "two", "three"], "ping": "pong"}'
    assert jsonify(result, format=True)  == '''{
    "changed": false,
    "foo": [
        "one",
        "two",
        "three"
    ],
    "ping": "pong"
}'''

# Generated at 2022-06-23 05:16:26.345741
# Unit test for function jsonify
def test_jsonify():
    result = {
        "msg": "the answer is {0}".format(42),
        "changed": False
    }
    assert jsonify(result) == '{"changed": false, "msg": "the answer is 42"}'

    result = {
        "failed": True,
        "invocation": {
            "module_args": {
                "branch": "foo",
                "repo": "git://github.com/ansible/ansible.git",
                "dest": "/tmp/ansible"
            },
            "module_name": "git"
        },
        "msg": "Failed to find requested branch foo in repo 'git://github.com/ansible/ansible.git'"
    }

# Generated at 2022-06-23 05:16:33.230889
# Unit test for function jsonify
def test_jsonify():
    ''' return: function jsonify '''
    import pytest
    result = {
        "key1": "value1",
        "key2": "value2"
    }
    target = jsonify(result, format=True)
    expect = """{
    "key1": "value1",
    "key2": "value2"
}"""
    assert target == expect
    with pytest.raises(Exception):
        jsonify(result, None)
    with pytest.raises(Exception):
        jsonify(None)
    with pytest.raises(Exception):
        jsonify(None, True)

# Generated at 2022-06-23 05:16:37.619491
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == "{}"
    assert jsonify(dict(foo=dict(bar="baz"))) == '{"foo": {"bar": "baz"}}'
    assert jsonify(dict(foo=dict(bar="baz")), format=True) == \
'''{
    "foo": {
        "bar": "baz"
    }
}'''


# Generated at 2022-06-23 05:16:49.336101
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    # (result, format) : expected

# Generated at 2022-06-23 05:16:57.712342
# Unit test for function jsonify
def test_jsonify():
    data = {
            'a': [1, 2, 3],
            'b': [4, 5, 6],
            }

    # default formatting
    json = jsonify(data)
    assert json == '{"a": [1, 2, 3], "b": [4, 5, 6]}'

    # explicit format
    json = jsonify(data, format=True)
    assert json == '''{
    "a": [
        1,
        2,
        3
    ],
    "b": [
        4,
        5,
        6
    ]
}'''

# Generated at 2022-06-23 05:17:08.194117
# Unit test for function jsonify
def test_jsonify():
    '''
    Validate jsonify function
    '''
    import datetime
    import time

    # Test input types
    string_data = "Test String"
    list_data   = ['a','b','c','d','e','f','g']
    dict_data   = {'string': 'value', 'list': ['a','b','c']}

    # Test input results
    json_string = '"Test String"'
    json_list   = '["a", "b", "c", "d", "e", "f", "g"]'
    json_dict   = '{"list": ["a", "b", "c"], "string": "value"}'

    # Test formatting

# Generated at 2022-06-23 05:17:16.113432
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import wrap_var

    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '''{
    "foo": "bar"
}'''
    assert jsonify(None) == '{}'
    assert jsonify(wrap_var(dict, {'foo': 'bar'})) == '{"foo": "bar"}'
    assert jsonify(wrap_var(unicode, u'\u2713')) == '"\u2713"'

# Generated at 2022-06-23 05:17:23.828648
# Unit test for function jsonify
def test_jsonify():
    test_result = {'a': 1, 'b': 2}
    test_result_json = jsonify(test_result)
    assert test_result_json == '{"a": 1, "b": 2}'

    test_result_json_format = jsonify(test_result, True)
    assert test_result_json_format == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 05:17:29.801488
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'

    assert jsonify({"a": 1}, format=True) == '{\n    "a": 1\n}'

    assert jsonify({"a": AnsibleUnsafeText("\u1234")}) == u'{"a": "\u1234"}'

# Generated at 2022-06-23 05:17:33.181723
# Unit test for function jsonify
def test_jsonify():
    result = dict()
    result['foo.bar'] = 1
    result['foo.baz'] = 2
    assert jsonify(result) == "{}"

# Generated at 2022-06-23 05:17:34.414461
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}, True) == '{\n}'

# Generated at 2022-06-23 05:17:37.593434
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a":"b"}) == "{\"a\": \"b\"}"
    assert jsonify({"a":"b"}, True) == "{\n    \"a\": \"b\"\n}\n"

# Generated at 2022-06-23 05:17:49.010270
# Unit test for function jsonify
def test_jsonify():

    print("Testing jsonify")
    print("================")

    try:
        import simplejson as json
    except:
        import json

    unjsoned = {"a": "apple", "b": "banana", "c": "chocolate", 0: 0}

    # assert that we get back the same structure
    # when we encode it and decode it as JSON
    jsoned = jsonify(unjsoned, format=False)
    assert unjsoned == json.loads(jsoned)

    # assert that we get back the same structure
    # when we encode it and decode it as JSON
    jsoned = jsonify(unjsoned, format=True)
    assert unjsoned == json.loads(jsoned)

    # assert that if we have a unicode character we
    # can still encode it fine if we have ensure_ascii=False

# Generated at 2022-06-23 05:18:01.135838
# Unit test for function jsonify
def test_jsonify():
    # Test for ascii characters only
    result = {'ansible_facts': {'test': 'abc'}}
    if jsonify(result, False) != '{"ansible_facts": {"test": "abc"}}' \
        or jsonify(result, True) != '{\n    "ansible_facts": {\n        "test": "abc"\n    }\n}':
        return (False, "jsonify failed when invalid characters not present")

    # Test for non-ascii characters present
    result = {'ansible_facts': {'test': '\u00ed'}}

# Generated at 2022-06-23 05:18:10.120351
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify
    import sys, types

    # jsonify a list of ints and strings
    data = [1, 2, "three"]
    assert jsonify(data) == "[1, 2, \"three\"]"

    # jsonify a dict with mixed types
    data = {"foo": "bar", "blah": 3, "asdf": [1, 2, "three"]}
    assert jsonify(data) == "{\"blah\": 3, \"asdf\": [1, 2, \"three\"], \"foo\": \"bar\"}"

    # jsonify None as empty dict
    assert jsonify(None) == "{}"

    # jsonify Unicode
    if sys.version_info.major >= 3:
        assert jsonify("\u263a") == "\"\\u263a\""

# Generated at 2022-06-23 05:18:11.508739
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo":"bar"}) == '{"foo": "bar"}'

# Generated at 2022-06-23 05:18:18.025814
# Unit test for function jsonify
def test_jsonify():
    # check for proper formatting
    assert jsonify({'key': 'value'}, True) == '{\n    "key": "value"\n}'
    # check for no values
    assert jsonify(None) == "{}"
    # check for non-ascii characters
    assert jsonify({'key': u'\u00df'}, True) == '{\n    "key": "\\u00df"\n}'

# Generated at 2022-06-23 05:18:26.371110
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([{"a": 1, "b": 2}], True) == '[\n    {\n        "a": 1, \n        "b": 2\n    }\n]'
    assert jsonify({"a": 1, "b": 2}, True) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(["test"]) == '["test"]'

if __name__ == '__main__':
    # Test all above functions/classes/methods
    test_jsonify()

# vim: filetype=python sts=4 sw=4 et

# Generated at 2022-06-23 05:18:34.392366
# Unit test for function jsonify
def test_jsonify():
    # Test 1
    test1 = {}
    assert jsonify(test1) == '{}'
    # Test 2
    test2 = {'key1': 'val1', 'key2': 'val2'}
    assert jsonify(test2) == '{"key1": "val1", "key2": "val2"}'
    # Test 3
    test3 = {'key1': 'val1', 'key2': 'val2', 'key3': {'key4': 'val4'}}
    assert jsonify(test3) == '{"key1": "val1", "key2": "val2", "key3": {"key4": "val4"}}'

    # Test 4

# Generated at 2022-06-23 05:18:44.163109
# Unit test for function jsonify
def test_jsonify():
    result = {1:1, 2:2, 'a':'a', 'b':'b'}
    result_sorted = {1:1, 2:2, 'a':'a', 'b':'b'}
    result_formatted = '''{
    "1": 1,
    "2": 2,
    "a": "a",
    "b": "b"
}'''
    result_formatted_sorted = '''{
    "1": 1,
    "2": 2,
    "a": "a",
    "b": "b"
}'''
    assert jsonify(result, False) == jsonify(result_sorted, False)
    assert jsonify(result, True) == jsonify(result_sorted, True)
    assert jsonify(result, True) == result

# Generated at 2022-06-23 05:18:50.715029
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({ 'a': 1, 'b': 2 }, format=True)
    assert result.startswith('{')
    assert result.endswith('}')
    print(result)
    result = jsonify(['a', 'b'], format=True)
    assert result.startswith('[')
    assert result.endswith(']')
    print(result)


# Generated at 2022-06-23 05:18:56.602867
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestJsonify(unittest.TestCase):
        def test_jsonify(self):
            self.assertEqual(jsonify(None), "{}")
            self.assertEqual(jsonify(None, True), "{\n}\n")
            self.assertEqual(jsonify({"a": 1}), '{"a": 1}')
            self.assertEqual(jsonify({"a": 1}, True), '{\n    "a": 1\n}\n')

# Generated at 2022-06-23 05:19:02.728277
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1,b=2,c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1,b=2,c=3), True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-23 05:19:13.236303
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify("foo", True) == '"foo"'
    assert jsonify(42, True) == '42'
    assert jsonify(42) == '42'
    assert jsonify(list(range(10)), True) == '[\n    0,\n    1,\n    2,\n    3,\n    4,\n    5,\n    6,\n    7,\n    8,\n    9\n]'
    assert jsonify(dict(a=42, b="foo", c=list(range(10)))) == '{"a": 42, "b": "foo", "c": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}'

# Generated at 2022-06-23 05:19:23.073323
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'
    assert jsonify({'hello': 'world'}, True) == '''{
    "hello": "world"
}'''

    assert jsonify(None) == '{}'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify([1, 2, 3], True) == '''[
    1,
    2,
    3
]'''

    assert jsonify({'ansible_facts': {'a':'b'}}) == '{"ansible_facts": {"a": "b"}}'

# Generated at 2022-06-23 05:19:29.489066
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(1) == "1"
    assert jsonify(1.1) == "1.1"
    assert jsonify("a") == "\"a\""
    assert jsonify(["a", 1]) == "[\"a\", 1]"
    assert jsonify({"a": "b"}) == "{\"a\": \"b\"}"

# Generated at 2022-06-23 05:19:31.476091
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(key='value')) == '{"key": "value"}'

# Generated at 2022-06-23 05:19:36.422085
# Unit test for function jsonify
def test_jsonify():
    print("testing function jsonify")
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": None}, format=True) == '{\n    "a": null\n}'

# Generated at 2022-06-23 05:19:42.490786
# Unit test for function jsonify
def test_jsonify():
    input = {'foo': 'bar'}
    output = jsonify(input, format=True)
    assert output == '{\n    "foo": "bar"\n}'

    output = jsonify(input)
    assert output == '{"foo": "bar"}'

    input = 'string'
    output = jsonify(input)
    assert output == '"string"'

# Generated at 2022-06-23 05:19:51.299804
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1, b=2, c=3, d=dict(a=1, b=2, c=3, d=dict(a=1, b=2, c=3)))

    # test output
    res = jsonify(result, format=True)
    assert res == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": 3, \n    \"d\": {\n        \"a\": 1, \n        \"b\": 2, \n        \"c\": 3, \n        \"d\": {\n            \"a\": 1, \n            \"b\": 2, \n            \"c\": 3\n        }\n    }\n}"

# Generated at 2022-06-23 05:20:01.664439
# Unit test for function jsonify
def test_jsonify():
    import ansible.utils

    # test=dict(a=1,b="foo",c=[1,2,3])

    # print jsonify(test, format=True)
    # print json.dumps(test, sort_keys=True, indent=4)
    # print jsonify(test)
    # print json.dumps(test, sort_keys=True)

    assert jsonify(dict(a=1,b="foo",c=[1,2,3]), format=True) == '{\n    "a": 1, \n    "b": "foo", \n    "c": [\n        1, \n        2, \n        3\n    ]\n}'

# Generated at 2022-06-23 05:20:11.118541
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify(result, format=False) '''

    class AnsibleModuleFake:
        params = {'format': False}

    # Comparison dictionary and data structure
    expected_unformatted_result_dict     = {'a':1, 'b':[1, 2, 'string'], 'c':'string'}
    expected_formatted_result_dict       = {
        'a'     : 1,
        'b'     : [
            1,
            2,
            'string'],
        'c'     : 'string'
    }

    # JSONify result
    unformatted_result = jsonify(expected_unformatted_result_dict)
    formatted_result   = jsonify(expected_formatted_result_dict, format=True)

    # Evaluate the result
    assert unformatted_

# Generated at 2022-06-23 05:20:13.662598
# Unit test for function jsonify
def test_jsonify():
    data = 'Il était une fois'

    # Check return type and value
    assert isinstance(jsonify(data), str)
    assert jsonify(data) == "\"Il \\u00e9tait une fois\""



# Generated at 2022-06-23 05:20:16.995936
# Unit test for function jsonify
def test_jsonify():
    def test_equal(expected, data):
        assert jsonify(data, True) == expected

    test_equal('{}\n', None)
    test_equal('{"A": "B"}\n', {'A':'B'})


# Generated at 2022-06-23 05:20:18.025110
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:20:29.665139
# Unit test for function jsonify
def test_jsonify():
    ''' Test jsonify() '''

    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar', 'asc': '\xe2\x9c\x93'}) == '{"asc": "\\u2713", "foo": "bar"}'
    assert jsonify({'foo': 'bar', 'asc': '\xe2\x9c\x93'}, True) == '{\n    "asc": "\\u2713", \n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:20:36.475407
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert(jsonify({'spam': 'foo'}) == '{"spam": "foo"}')
    assert(jsonify({'spam': AnsibleUnsafeText('foo')}) == '{"spam": "foo"}')
    assert(jsonify({'spam': '\u001b[2Kfoo'}) == '{"spam": "foo"}')
    assert(jsonify({'pwd': AnsibleUnsafeText('/home/foo')}, True) == '{\n    "pwd": "/home/foo"\n}')

# Generated at 2022-06-23 05:20:45.325331
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'
    assert jsonify(None) == '{}'
    assert jsonify({'unicode': 'f\xf8\xf8'}) == '{\n    "unicode": "f\xf8\xf8"\n}'
    assert jsonify([1, 2, 3]) == '[\n    1, \n    2, \n    3\n]'
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-23 05:20:56.212434
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}'
    assert jsonify({'name': 'bob', 'age': 10}) == '{"age": 10, "name": "bob"}'
    assert jsonify({'name': 'bob', 'age': 10}, True) == '{\n    "age": 10,\n    "name": "bob"\n}'

# Run unit tests when invoked directly
if __name__ == '__main__':
    import sys
    import doctest
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__
    def mock_open(filename):
        # Presume all fixtures are in tests/units/modules/utils
        fixture_path = 'tests/units/modules/utils/'

# Generated at 2022-06-23 05:20:58.177471
# Unit test for function jsonify
def test_jsonify():
    assert jsonify( { 'foo': 'bar' }, format=True) == '''{
    "foo": "bar"
}'''

# Generated at 2022-06-23 05:21:00.837922
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''

    assert jsonify({"Hello": "World"}) == '{ "Hello": "World" }'
    assert jsonify({"Hello": "World"}, format=True) == '''{
    "Hello": "World"
}'''

# Generated at 2022-06-23 05:21:03.956351
# Unit test for function jsonify
def test_jsonify():
    result = {
        "test": "success",
    }
    assert jsonify(result, True) == '{\n    "test": "success"\n}'

# Generated at 2022-06-23 05:21:10.277259
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''

    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'
    assert jsonify(None) == "{}"

if __name__ == '__main__':
    test_jsonify()