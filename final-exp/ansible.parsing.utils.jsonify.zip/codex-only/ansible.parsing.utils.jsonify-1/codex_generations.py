

# Generated at 2022-06-23 05:11:15.219031
# Unit test for function jsonify
def test_jsonify():
    assert '"foo"' == jsonify({'foo': None})
    assert '"foo"' != jsonify({'foo': None}, True)
    assert '"foo"' == jsonify({'foo': 'bar'})
    assert '"foo"' != jsonify({'foo': 'bar'}, True)

# Generated at 2022-06-23 05:11:22.111299
# Unit test for function jsonify
def test_jsonify():

    def is_json(result):
        try:
            json.loads(result)
            return True
        except:
            return False

    def assert_json(result):
        assert is_json(result)

    # run the tests
    assert_json(jsonify(None))
    assert_json(jsonify(True))
    assert_json(jsonify("foobar"))
    assert_json(jsonify([True, False]))
    assert_json(jsonify({"foo": True, "bar": False}))

# Generated at 2022-06-23 05:11:25.921938
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar', 'value': 42}
    assert jsonify(result) == '{"foo": "bar", "value": 42}'
    assert jsonify(result, True) == '''{
    "foo": "bar",
    "value": 42
}'''

# Generated at 2022-06-23 05:11:36.292151
# Unit test for function jsonify
def test_jsonify():
    result = dict(failed=False)
    assert jsonify(result) == "{}"

    result = dict(failed=False, changed=True, foo=1)
    assert jsonify(result) == '{"changed": true, "foo": 1}'

    result = dict(failed=False, changed=False, foo=1)
    assert jsonify(result) == '{"changed": false, "foo": 1}'

    result = dict(failed=True, foo=1)
    assert jsonify(result) == '{"failed": true, "foo": 1}'

    result = dict(failed=False, changed=True, foo=1, diff={'before': 'foo', 'after': 'bar'})

# Generated at 2022-06-23 05:11:46.179007
# Unit test for function jsonify
def test_jsonify():
    import datetime

    test_data = [
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 1, 'b': True},
        {'a': [1,2,3]},
        {'a': {'b': 1}, 'c': datetime.datetime(2014, 5, 9)},
    ]
    for td in test_data:
        assert jsonify(td, True) == json.dumps(td, sort_keys=True, indent=4, ensure_ascii=False)
        assert jsonify(td, False) == json.dumps(td, sort_keys=True, ensure_ascii=False)

# Generated at 2022-06-23 05:11:54.599958
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}, format=True) == "{\n    \"a\": \"b\"\n}"
    assert isinstance(jsonify({"a": "b"}, format=True), str)
    assert jsonify({"a": "b"}) == "{\"a\":\"b\"}"
    assert jsonify({"a": u"b"}) == u"{\"a\":\"b\"}"
    assert jsonify({"a": 1.0}) == "{\"a\":1.0}"
    assert jsonify({"a": True}) == "{\"a\":true}"
    assert jsonify({"a": False}) == "{\"a\":false}"
    assert jsonify({"a": None}) == "{\"a\":null}"

# Generated at 2022-06-23 05:11:57.454696
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({"a" : "b"}) == '{"a": "b"}'
    assert jsonify({"a" : "b"}, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 05:12:04.265083
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys

    # Mock out the args
    class Options(object):
        def __init__(self):
            self.verbosity = None
            self.inventory = None
            self.ask_vault_pass = False
            self.vault_password_file = None
            self.module_path = None
            self.forks = None
            self.timeout = None
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None

# Generated at 2022-06-23 05:12:10.156009
# Unit test for function jsonify
def test_jsonify():
    # return a JSON-serialized string
    assert jsonify({'a': 1}) == "{\"a\": 1}"
    assert jsonify({'a': 1}, format=True) == "{\n    \"a\": 1\n}"

    # return None if result is None
    assert jsonify(None) == "{}"

    # handle unicode output
    assert type(jsonify({'a': u'\u20ac'})) == unicode


# --- Module execution

# Generated at 2022-06-23 05:12:19.740096
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        "a": 1,
        "b": [2, 3, 4],
        "c": { "d": 1, "e": [2, 3, 4], "f": 5 }
    }
    assert jsonify(test_data) == '{"a": 1, "b": [2, 3, 4], "c": {"d": 1, "e": [2, 3, 4], "f": 5}}'
    assert jsonify(test_data, format=False) == '{"a": 1, "b": [2, 3, 4], "c": {"d": 1, "e": [2, 3, 4], "f": 5}}'

# Generated at 2022-06-23 05:12:26.617921
# Unit test for function jsonify
def test_jsonify():
    rval = jsonify({'a': 1, 'b': [2, {'x': 3 }]})
    assert rval == '{"a": 1, "b": [2, {"x": 3}]}'
    rval = jsonify({'a': 1, 'b': [2, {'x': 3 }]}, True)
    assert rval == '{\n    "a": 1, \n    "b": [\n        2, \n        {\n            "x": 3\n        }\n    ]\n}'

# Generated at 2022-06-23 05:12:34.144555
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''

    ds = {
        'a': 1,
        'b': [ 2, 3, 4, { 'c': 5, 'd': 6 } ],
        'c': [ 7, 8, 9, [ 10, 11 ] ]
    }
    assert jsonify(ds) == '{"a": 1, "b": [2, 3, 4, {"c": 5, "d": 6}], "c": [7, 8, 9, [10, 11]]}'

# Generated at 2022-06-23 05:12:45.074089
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(True) == "true"
    assert jsonify(None) == "{}"
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"c": [1,2,3], "a": True, "b": None}) == '{"a": true, "b": null, "c": [1, 2, 3]}'

    # Here we test unicode output
    assert jsonify({"a": u"H\xe9llo, world!"}) == u'{"a": "H\\xe9llo, world!"}'

__all__ = ['jsonify']

# Generated at 2022-06-23 05:12:53.051528
# Unit test for function jsonify
def test_jsonify():
    test_array  = [ 'a', 'b' ]
    test_dict   = { 'a': 'b' }
    test_string = 'hello world'
    test_none   = None

    assert jsonify(test_array) == '["a", "b"]'
    assert jsonify(test_dict) == '{"a": "b"}'
    assert jsonify(test_string) == '"hello world"'
    assert jsonify(test_none) == '{}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:12:57.673041
# Unit test for function jsonify
def test_jsonify():
    # Test a string
    assert jsonify("string") == '"string"'
    # Test a list
    assert jsonify(["test", "list"]) == '["test", "list"]'
    # Test a dict
    assert jsonify({"test": "dict"}) == '{"test": "dict"}'
    # Test a list with a dict
    assert jsonify(["test", {"test": "dict"}]) == '["test", {"test": "dict"}]'

# Generated at 2022-06-23 05:13:08.345541
# Unit test for function jsonify
def test_jsonify():

    # Test when we are passed None
    assert jsonify(None) == "{}"

    # Test when we are passed an empty dict
    my_dict = {}
    assert jsonify(my_dict) == "{}"

    # Test when we are passed an empty list
    my_list = []
    assert jsonify(my_list) == "[]"

    # Test when we are passed a dict
    dict_test = {'a': 'b'}
    assert jsonify(dict_test) == '{\n    "a": "b"\n}'

    # Test when we are passed a dict with nested things
    dict_test2 = {'a': {'b': {'c': 'd'}}, 'e': {'f': {'g': 'h'}}}

# Generated at 2022-06-23 05:13:20.272765
# Unit test for function jsonify
def test_jsonify():
    # Simple test jsonification of a dictionary
    x = {}
    x['a'] = 1
    x['b'] = 2
    y = jsonify(x)
    print(y)
    assert y == u'{"a": 1, "b": 2}'

    # check the optional format option, which does some pretty printing
    y = jsonify(x, True)
    print(y)
    assert y == u'{\n    "a": 1, \n    "b": 2\n}'

    # and make sure it works with ascii
    x = { 'a': 'ascii', 'b' : u'こんにちは' }
    z = jsonify(x)
    print(z)

# Generated at 2022-06-23 05:13:30.192529
# Unit test for function jsonify
def test_jsonify():
    # Testing jsonify with None
    assert jsonify(None) == "{}"

    # Testing jsonify with empty dict
    assert jsonify(dict()) == "{}"

    # Testing jsonify with empty dict
    assert jsonify(dict()) == "{}"

    # Testing jsonify with dict
    assert jsonify({ "KEY": "VALUE" }) == '{\"KEY\": \"VALUE\"}'
    assert jsonify({ "KEY": "VALUE" }, format=True) == '{\n    \"KEY\": \"VALUE\"\n}'

    # Testing jsonify with list
    assert jsonify([ "KEY", "VALUE" ]) == '[\"KEY\", \"VALUE\"]'
    assert jsonify([ "KEY", "VALUE" ], format=True) == '[\n    \"KEY\", \n    \"VALUE\"\n]'

    # Testing jsonify with numbers
    assert jsonify

# Generated at 2022-06-23 05:13:33.585848
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify'''
    assert jsonify({"a": "b"}) == "{\"a\": \"b\"}"

# vim: set expandtab: ts=4:sw=4

# Generated at 2022-06-23 05:13:38.455549
# Unit test for function jsonify
def test_jsonify():
    structure = {
        'foo': 'bar',
        'baz': 'bax'
    }
    assert jsonify(structure, format=False) == '{"baz": "bax", "foo": "bar"}'
    assert jsonify(structure, format=True) == '{\n    "baz": "bax", \n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:13:43.610752
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify function '''

    obj = dict(a=1, b=10, c=20, d=dict(aa=1, bb=2, cc=3))

    ret = jsonify(obj, format=False)
    assert json.loads(ret) == obj

    ret = jsonify(obj, format=True)
    assert json.loads(ret) == obj

# Generated at 2022-06-23 05:13:49.584283
# Unit test for function jsonify
def test_jsonify():
    result = {u'failed': False, u'invocation': {u'module_args': u'', u'module_name': u'command'}, u'item': u'', u'changed': False, u'rc': 0}
    assert jsonify(result) == "{\"invocation\": {\"module_name\": \"command\", \"module_args\": \"\"}, \"changed\": false, \"failed\": false, \"item\": \"\", \"rc\": 0}"


# Generated at 2022-06-23 05:13:50.749246
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'


# Generated at 2022-06-23 05:14:02.662611
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-23 05:14:12.756919
# Unit test for function jsonify
def test_jsonify():
    import sys
    from ansible.compat.tests import unittest

    if sys.version_info < (2, 7):
        return

    class TestModule(unittest.TestCase):

        def test_jsonify_encoding(self):
            r1 = jsonify({})
            r2 = jsonify({u'unicode': u'\u00f3'})
            r3 = jsonify({'unicode': u'\u00f3'})

            self.assertEquals(r1, '{}')
            self.assertEquals(r2, '{"unicode": "\\u00f3"}')
            self.assertEquals(r3, '{"unicode": "\\u00f3"}')

    unittest.main()

# Generated at 2022-06-23 05:14:15.225935
# Unit test for function jsonify
def test_jsonify():
    result = '{"a":1,"b":2}'
    assert (result == jsonify(json.loads(result)))

# Generated at 2022-06-23 05:14:24.924539
# Unit test for function jsonify
def test_jsonify():
    test_string = "Just a string"
    assert jsonify(test_string) == "\"Just a string\""

    test_list = [1,2,3,4]
    assert jsonify(test_list) == "[1, 2, 3, 4]"

    test_dict = {'a': 1, 'b': 2}
    assert jsonify(test_dict) == "{\"a\": 1, \"b\": 2}"

    test_dict = {'a': 1, 'b': {'c':2}}
    assert jsonify(test_dict) == "{\"a\": 1, \"b\": {\"c\": 2}}"

    test_dict = {'a': 1, 'b': [{'c':2}, {'d':3}]}

# Generated at 2022-06-23 05:14:34.599027
# Unit test for function jsonify
def test_jsonify():

    class Obj:
        def __init__(self):
            self.a = 1
            self.b = 2

    # Test simple type
    try:
        jsonify(2)
        assert False
    except TypeError:
        pass

    # Test simple list
    try:
        jsonify([2,3])
        assert False
    except TypeError:
        pass

    # Test unserializable list
    try:
        jsonify([2, Obj()])
        assert False
    except TypeError:
        pass

    # Test simple dict
    try:
        jsonify({"a":1})
        assert False
    except TypeError:
        pass

    # Test unserializable dict
    try:
        jsonify({"a":1, "b":Obj()})
        assert False
    except TypeError:
        pass

# Generated at 2022-06-23 05:14:45.239370
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(0) == "0"
    assert jsonify(False) == "false"
    assert jsonify(None) == "{}"
    assert jsonify("") == "\"\""
    assert jsonify("foo") == "\"foo\""
    assert jsonify("f\u00f6\u00f6") == "\"f\u00f6\u00f6\""
    assert jsonify("f\u00f6\u00f6".decode("utf-8")) == "\"f\u00f6\u00f6\""
    assert jsonify(1.1) == "1.1"
    assert jsonify([]) == "[]"
    assert jsonify({}) == "{}"
    assert jsonify([{}]) == "[{}]"

# Generated at 2022-06-23 05:14:52.663133
# Unit test for function jsonify
def test_jsonify():
    def asserteq(a, b):
        assert a == b

    # Test a bunch of simple cases
    asserteq(jsonify(None), "{}")
    asserteq(jsonify(dict(foo=1)), '{"foo": 1}')
    asserteq(jsonify(dict(foo=dict(bar=[]))), '{"foo": {"bar": []}}')
    asserteq(jsonify(dict(foo=dict(bar=[]))), '{"foo": {"bar": []}}')
    asserteq(jsonify(dict(foo=dict(bar=dict(baz=1)))), '{"foo": {"bar": {"baz": 1}}}')

# Generated at 2022-06-23 05:15:02.033849
# Unit test for function jsonify
def test_jsonify():
    import sys

    input_data = dict(a=1, b=2, c=3, d=dict(aa=11, bb=22, cc=33))
    expected_results = {
        False: '{"a": 1, "b": 2, "c": 3, "d": {"aa": 11, "bb": 22, "cc": 33}}',
        True: '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": {
        "aa": 11,
        "bb": 22,
        "cc": 33
    }
}'''
    }

    # Check Python2
    py_version = sys.version_info[0]

# Generated at 2022-06-23 05:15:06.728626
# Unit test for function jsonify
def test_jsonify():

    # This simple test was written to prove that the jsonify
    # function allows unicode characters to be returned.  More
    # advanced tests would be a welcome addition as time permits
    test_dict = {'unicode': u'\u5b57'}

    result = jsonify(test_dict, True)
    assert u'\u5b57' in result

# Generated at 2022-06-23 05:15:17.435526
# Unit test for function jsonify
def test_jsonify():
    # test None
    assert jsonify(None) == "{}"

    # test blank
    assert jsonify("") == jsonify("{}") == jsonify("{}") == jsonify("{}") == "\"\""
    assert jsonify("") == jsonify("{}") == jsonify("{}") == jsonify("{}") == "\"\""

    # test a real result
    assert jsonify("hello world") == "\"hello world\""
    assert jsonify("hello world") == "\"hello world\""

    # test a real dict
    assert jsonify({'hello': 'world'}) == "{\"hello\": \"world\"}"
    assert jsonify({'hello': 'world'}) == "{\"hello\": \"world\"}"

    # test a format result

# Generated at 2022-06-23 05:15:22.821220
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1, 'b':2, 'c':None}) == '{"a": 1, "b": 2, "c": null}'
    assert jsonify({'a':1, 'b':2, 'c':None}, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": null\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:15:28.784610
# Unit test for function jsonify
def test_jsonify():

    res = jsonify({"a": 2, "b": 3})
    assert res == '{"a": 2, "b": 3}'

    res = jsonify({"a": 2, "b": 3}, format=True)
    assert res == '{\n    "a": 2, \n    "b": 3\n}'

# Generated at 2022-06-23 05:15:39.582484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(False) == "false"
    assert jsonify(True) == "true"
    assert jsonify(1) == "1"
    assert jsonify({"a": "b"}) == "{\"a\": \"b\"}"
    assert jsonify(["a", "b", "c"]) == "[\"a\", \"b\", \"c\"]"
    assert jsonify({"a": {"b": "c"}}) == "{\"a\": {\"b\": \"c\"}}"
    assert jsonify({"a": ["b", "c"]}) == "{\"a\": [\"b\", \"c\"]}"
    assert jsonify({"a": ["b", {"c": "d"}]}) == "{\"a\": [\"b\", {\"c\": \"d\"}]}"

# Generated at 2022-06-23 05:15:49.025410
# Unit test for function jsonify
def test_jsonify():
    # Python 2/3 compat
    try:
        unicode('')
    except NameError:
        unicode = str
    assert jsonify(None) == '{}'

    orig = {
        'a': 1,
        'b': 'c',
    }

    res = jsonify(orig)
    # I've seen 2.5 jsonify in to {'a': 1, 'b': u'c'}
    # unindented and 2.6 in to
    # {
    #   "a": 1,
    #   "b": "c"
    # }

    assert res == json.dumps(orig, indent=None, sort_keys=True)

    res = jsonify(orig, format=True)
    assert res == json.dumps(orig, indent=4, sort_keys=True)



# Generated at 2022-06-23 05:16:00.625575
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants as C
    from ansible.utils.unicode import to_unicode

    def _test_jsonify_format():
        assert jsonify({ "a": 1 }) == '{\n    "a": 1\n}'

    def _test_jsonify_no_format():
        assert jsonify({ "a": 1 }, format=False) == '{"a": 1}'

    def _test_jsonify_format_unstr_dict():
        assert jsonify(dict(a=1), format=True) == '{\n    "a": 1\n}'

    def _test_jsonify_no_format_unstr_dict():
        assert jsonify(dict(a=1), format=False) == '{"a": 1}'

    def _test_jsonify_format_none():
        assert jsonify

# Generated at 2022-06-23 05:16:05.280475
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify code '''

    from ansible.utils.unicode import to_bytes

    unformatted = jsonify({'foo': 'bar'}, False)
    assert unformatted == '{"foo": "bar"}'
    assert isinstance(unformatted, str)

    formatted = jsonify({'foo': 'bar'}, True)
    assert formatted == '{\n    "foo": "bar"\n}'
    assert isinstance(formatted, str)

# Generated at 2022-06-23 05:16:09.114527
# Unit test for function jsonify
def test_jsonify():
    result = {'test':'123'}
    assert jsonify(result, True) == '{\n    "test": "123"\n}'

# Generated at 2022-06-23 05:16:11.759522
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'

# Generated at 2022-06-23 05:16:23.840302
# Unit test for function jsonify
def test_jsonify():
   data = {
      'stdout' : [
         "10.255.255.1",
         "10.255.255.2",
         "10.255.255.3",
      ],
   }
   assert jsonify(data) == '''{
    "stdout": [
        "10.255.255.1",
        "10.255.255.2",
        "10.255.255.3"
    ]
}'''

   assert jsonify(data, True) == '''{
    "stdout": [
        "10.255.255.1",
        "10.255.255.2",
        "10.255.255.3"
    ]
}'''

   assert jsonify(None, True) == "{}"
   assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:16:24.872481
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"



# Generated at 2022-06-23 05:16:28.682020
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"http_host":"www.example.com","http_port":8080}) == '{"http_host": "www.example.com", "http_port": 8080}'

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-23 05:16:33.662616
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None, format=False) == "{}"
    assert jsonify(None, format=True) == "{}"
    assert jsonify({'a':1, 'b':2}, format=True) == "{\"a\": 1, \"b\": 2}"

# Generated at 2022-06-23 05:16:41.652186
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo=1)) == '{"foo": 1}'
    assert jsonify(dict(foo='one')) == '{"foo": "one"}'
    assert jsonify(dict(foo='ru\u20AC')) == u'{"foo": "ru\u20ac"}'

    assert jsonify(dict(foo=1), True) == '{\n    "foo": 1\n}'
    assert jsonify(dict(foo='one'), True) == '{\n    "foo": "one"\n}'
    assert jsonify(dict(foo='ru\u20AC'), True) == u'{\n    "foo": "ru\u20ac"\n}'

# Generated at 2022-06-23 05:16:45.589549
# Unit test for function jsonify
def test_jsonify():
    results = dict(changed=True, rc=0, stdout="this is a test")
    expected = '{"changed": true, "rc": 0, "stdout": "this is a test"}'
    assert jsonify(results, False) == expected



# Generated at 2022-06-23 05:16:49.059922
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a='b')) == '{"a": "b"}'
    assert jsonify(dict(a='b'), True) == '''{
    "a": "b"
}'''

# Generated at 2022-06-23 05:16:52.976802
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should format JSON output '''

    res = jsonify({'key':'value'}, format=True)
    assert '\n' in res
    assert '    ' in res
    assert '{\n' in res
    assert '    "key": "value"\n' in res
    assert '}' in res


# Generated at 2022-06-23 05:17:05.065339
# Unit test for function jsonify
def test_jsonify():
    import ansible.utils
    ansible.utils.jsonify = jsonify

    from ansible.callbacks import display
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, host_list='localhost')

    # test JSON output (uncompressed)
    display(inventory, 'elaborate')    # cache inventory
    display.display('{"a": 1, "b": "c"}', "json")
    display.display('{"a": 1, "b": "c"}', "json_pp")
    display.display('{"a": 1, "b": "c"}', "json_failed")

# Generated at 2022-06-23 05:17:15.260417
# Unit test for function jsonify
def test_jsonify():
    from json import dumps
    from ansible.utils.jsonify import jsonify

    # Testing for None
    r = jsonify(None)
    assert r == dumps(None)

    # Testing for empty dict
    r = jsonify({})
    assert r == dumps({})

    # Testing for integer
    r = jsonify(7)
    assert r == dumps(7)

    # Testing for str
    r = jsonify('7')
    assert r == dumps('7')

    # Testing for list
    r = jsonify([7, 4])
    assert r == dumps([7, 4])

    # Testing for tuple
    r = jsonify((7, 4))
    assert r == dumps([7, 4])


# Generated at 2022-06-23 05:17:21.974323
# Unit test for function jsonify
def test_jsonify():
    result = {
        'foo': 'bar',
        'meh': [ 'one', 'two', 'three', {'four': 'fish'} ]
    }
    assert jsonify(result, format=False) == '{"foo": "bar", "meh": ["one", "two", "three", {"four": "fish"}]}'
    assert jsonify(result, format=True) == '{\n    "foo": "bar", \n    "meh": [\n        "one", \n        "two", \n        "three", \n        {\n            "four": "fish"\n        }\n    ]\n}'

# Generated at 2022-06-23 05:17:23.589499
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, format=False) == '{}'

# Generated at 2022-06-23 05:17:33.404021
# Unit test for function jsonify
def test_jsonify():

    # Test simple dict
    test = {'a':1,'b':2,'c':{'d':4,'e':5}}
    json_formatted = jsonify(test)
    assert(json_formatted == "{\"a\": 1, \"b\": 2, \"c\": {\"d\": 4, \"e\": 5}}")
    json_pretty = jsonify(test, True)
    assert(json_pretty == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": {\n        \"d\": 4, \n        \"e\": 5\n    }\n}")

    # Test simple list
    test = [1,2,3,4,5]
    json_formatted = jsonify(test)
    assert(json_formatted == "[1, 2, 3, 4, 5]")

# Generated at 2022-06-23 05:17:40.605436
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1}, True) == '{\n    "a": 1\n}'
    assert jsonify({'b': {'a': 1}}) == '{"b": {"a": 1}}'
    assert jsonify(['a', 1]) == '["a", 1]'
    assert jsonify(1) == '1'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:17:44.568926
# Unit test for function jsonify
def test_jsonify():
    j = dict(a=dict(b="c",d=[1,2,3]))
    assert jsonify(j) == '{"a": {"b": "c", "d": [1, 2, 3]}}'



# Generated at 2022-06-23 05:17:55.034853
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(1) == '1'
    assert jsonify(3.14) == '3.14'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify(['foo', 'bar', 'baz']) == '["foo", "bar", "baz"]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'

# Generated at 2022-06-23 05:18:06.166622
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo':'bar'}) == '{\n    "foo": "bar"\n}'
    assert jsonify({"Bart": [1,2,3]}) == '{\n    "Bart": [\n        1, \n        2, \n        3\n    ]\n}'
    assert jsonify({"Bart": {"Skate": [4,5,6,7]}}) == '{\n    "Bart": {\n        "Skate": [\n            4, \n            5, \n            6, \n            7\n        ]\n    }\n}'

# Generated at 2022-06-23 05:18:16.772941
# Unit test for function jsonify
def test_jsonify():
    result = dict(foo='bar', baz=42)
    result_str = "{\"baz\": 42, \"foo\": \"bar\"}"
    assert jsonify(result, format=False) == result_str
    assert jsonify(result, format=True) == "{\n    \"baz\": 42, \n    \"foo\": \"bar\"\n}"
    try:
        result_str = json.dumps(result)
    except Exception as e:
        print("ERROR: Could not dump %s as JSON: %s" % (result, e))
    try:
        result_str = json.dumps(result, indent=2)
    except Exception as e:
        print("ERROR: Could not dump %s as JSON: %s" % (result, e))

# Generated at 2022-06-23 05:18:25.833806
# Unit test for function jsonify
def test_jsonify():
    import io
    import sys

    g = globals()
    g['jsonify'] = jsonify
    print("hi", file=sys.stderr)
    f = io.StringIO()
    with redirect_stdout(f):
        exec(open(__file__).read(), g)
        results = f.getvalue()
    print(results)
    assert 'success' in results

if __name__ == '__main__':
    from ansibullbot.utils.shlex_wrapper import ShlexWrapper, ShlexError
    import sys
    import pprint

    try:
        cmdargs = ShlexWrapper.split(sys.argv[1:])
    except ShlexError as e:
        print(e)
        sys.exit(1)

    if len(cmdargs) < 1:
        print

# Generated at 2022-06-23 05:18:29.392709
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':2, 'b':3}) == '{"a": 2, "b": 3}'

    formatted = jsonify({'a':2, 'b':3}, format=True)
    assert formatted.startswith('{\n')
    assert formatted.endswith('\n}')

# Generated at 2022-06-23 05:18:38.782305
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify unit tests '''

    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def test_jsonify(self):
            ''' Test the jsonify function '''

            self.assertEqual(jsonify(None), '{}')
            self.assertEqual(jsonify({'fizz': 'buzz'}), '{"fizz": "buzz"}')
            self.assertEqual(jsonify([1, 2, 3]), '[1, 2, 3]')
            self.assertEqual(jsonify(3), '3')

    unittest.main()

# Generated at 2022-06-23 05:18:45.726000
# Unit test for function jsonify
def test_jsonify():
    assert json.loads(jsonify(dict(foo='bar'))) == dict(foo='bar')
    assert json.loads(jsonify(dict(foo=dict(bar='baz')))) == dict(foo=dict(bar='baz'))
    assert json.loads(jsonify(dict(foo=None))) == dict(foo=None)
    assert json.loads(jsonify(None)) == {}
    assert json.loads(jsonify(dict(foo="b\xe4r"))) == di

# Generated at 2022-06-23 05:18:53.874130
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 42}) == '{"a": 42}'
    assert jsonify({"a": 42}, True) == '{\n    "a": 42\n}'
    assert jsonify({"a":{"b":"c"}, "d": "e"}, True) == '{\n    "a": {\n        "b": "c"\n    }, \n    "d": "e"\n}'
    assert jsonify({"a":{"b":["c", "d"]}, "e":"f"}, True) == '{\n    "a": {\n        "b": [\n            "c", \n            "d"\n        ]\n    }, \n    "e": "f"\n}'

# Generated at 2022-06-23 05:18:58.167267
# Unit test for function jsonify
def test_jsonify():
    input = {
        'item1': {
            'item2': 'item3'
        }
    }
    print(jsonify(input))
    print(jsonify(input, True))

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-23 05:19:08.365108
# Unit test for function jsonify
def test_jsonify():
    '''Function ``jsonify`` converts dictionaries to JSON strings.'''

    import os
    import tempfile

    test_data = dict(
        test_data_1 = 'test data 1',
        test_data_2 = 'test data 2',
    )

    test_json = jsonify(test_data)
    # Check that we can convert it back to a dict
    dict(json.loads(test_json))

    test_json_formatted = jsonify(test_data, True)
    # Check that we can convert it back to a dict
    dict(json.loads(test_json_formatted))

    # Check that test_json_formatted is an indented version of test_json
    # We need a temporary file to compare the two strings
    tmp_fd, tmp_path = tempfile.mkstemp()
    tmp

# Generated at 2022-06-23 05:19:13.924748
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1,2,3])                == json.dumps([1,2,3], sort_keys=True, indent=None, ensure_ascii=False)
    assert jsonify([1,2,3], format=True)   == json.dumps([1,2,3], sort_keys=True, indent=4, ensure_ascii=False)

# Generated at 2022-06-23 05:19:14.872142
# Unit test for function jsonify
def test_jsonify():
    assert len(jsonify({"foo": "bar"}, True)) > 10

# Generated at 2022-06-23 05:19:23.992466
# Unit test for function jsonify
def test_jsonify():
    def assert_json(in_, out_):
        assert jsonify(in_) == out_

    assert_json(1, '1')
    assert_json("1", '"1"')
    assert_json("foo", '"foo"')
    assert_json(u"foo", '"foo"')
    assert_json(None, '{}')
    assert_json({}, '{}')
    assert_json({'a': 1}, '{"a": 1}')
    assert_json([1,2,3], '[1, 2, 3]')
    assert_json([1,2,{'a': 1}], '[1, 2, {"a": 1}]')
    assert_json({'a': [1,2,3]}, '{"a": [1, 2, 3]}')
    assert_

# Generated at 2022-06-23 05:19:25.645418
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'

# Generated at 2022-06-23 05:19:35.352184
# Unit test for function jsonify
def test_jsonify():
    # Check an empty result
    result = None
    expected = "{}"
    returned = jsonify(result)
    assert returned == expected

    # Check a small result
    result = dict(a=1,b=2,c=3)
    expected = '{"a": 1, "b": 2, "c": 3}'
    returned = jsonify(result)
    assert returned == expected

    # Check a small result with indent
    result = dict(a=1,b=2,c=3)
    expected = '''{
    "a": 1,
    "b": 2,
    "c": 3
}'''
    returned = jsonify(result, True)
    assert returned == expected

    # Check larger result

# Generated at 2022-06-23 05:19:37.111636
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'

# Generated at 2022-06-23 05:19:45.906939
# Unit test for function jsonify
def test_jsonify():
    test_result1 = {'bananas': 24, 'mangos': 42, 'apple': 'red'}
    test_json1 = '{"apple": "red", "bananas": 24, "mangos": 42}\n'

    test_result2 = {u'bananas': 24, u'mangos': 42, u'apple': u'red'}
    test_json2 = '{"apple": "red", "bananas": 24, "mangos": 42}\n'

    assert(jsonify(test_result1) == test_json1)
    assert(jsonify(test_result2) == test_json2)

# Generated at 2022-06-23 05:19:57.232852
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info >= (3,0):
        unicode_string = "«ταБЬℓσ»: 1"
        real_unicode = {"«ταБЬℓσ»": 1}
    else:
        unicode_string = u"\u00ab\u03b1\u03b2\u03c9\u03b8\u03b5\u00bb: 1"
        real_unicode = {u"\u00ab\u03b1\u03b2\u03c9\u03b8\u03b5\u00bb": 1}
    assert jsonify(real_unicode) == '{"' + unicode_string + '": 1}'

if __name__ == '__main__':
    print

# Generated at 2022-06-23 05:20:06.521615
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'

    assert jsonify(dict(foo='bar', baz=None)) == '{"foo": "bar", "baz": null}'

    assert jsonify(dict(foo='bar', baz=None), format=True).replace(' ', '') == '''{
        "foo": "bar",
        "baz": null
    }'''.replace(' ', '')

    assert jsonify(dict(foo=dict(bar=dict(baz="baz")))) == '{"foo": {"bar": {"baz": "baz"}}}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:20:09.582293
# Unit test for function jsonify
def test_jsonify():
    result = {"hello": "world"}
    result_formatted = jsonify(result, format=True)
    assert result_formatted == "{\"hello\": \"world\"}"

# Generated at 2022-06-23 05:20:17.071330
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import PY3
    assert jsonify({}) == "{}"
    assert jsonify({1:2}) == '{"1": 2}'
    assert jsonify({'a': {'b': [{'c': 'd'}]}}) == '{"a": {"b": [{"c": "d"}]}}'
    if PY3:
        assert jsonify({b'a': b'b'}) == '{"a": "b"}'

# Generated at 2022-06-23 05:20:26.965122
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, msg="Hello", meta=dict(foo=1.1, bar="baz"))
    assert jsonify(result, False) == '{"changed": true, "msg": "Hello", "meta": {"foo": 1.1, "bar": "baz"}}'

    result = dict(changed=True, msg="Hello", meta=dict(foo=1.1, bar="baz"))
    assert jsonify(result, True) == '{\n    "changed": true,\n    "msg": "Hello",\n    "meta": {\n        "bar": "baz",\n        "foo": 1.1\n    }\n}'

# Generated at 2022-06-23 05:20:36.283454
# Unit test for function jsonify
def test_jsonify():
    result = {
        "changed": False,
        "failed": False,
        "invocation": {
            "module_args": {
                "name": "httpd",
                "state": "present"
            }
        },
        "module_name": "yum",
        "rc": 0,
        "stderr": "",
        "stdout": ""
    }

    assert jsonify(result, True) == """{
    "changed": false,
    "failed": false,
    "invocation": {
        "module_args": {
            "name": "httpd",
            "state": "present"
        }
    },
    "module_name": "yum",
    "rc": 0,
    "stderr": "",
    "stdout": ""
}"""

# Generated at 2022-06-23 05:20:40.969661
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2 }
    assert "{\"a\": 1, \"b\": 2}" == jsonify(result)
    assert "{\n    \"a\": 1, \n    \"b\": 2\n}" == jsonify(result, True)

# Test that jsonify fails on invalid input

# Generated at 2022-06-23 05:20:52.960986
# Unit test for function jsonify
def test_jsonify():
    ''' test that jsonify produces expected output '''
    # Test different types of input lists with different types of output
    assert jsonify(["foo"]) == '["foo"]'
    assert jsonify(["foo"], format=True) == '''[
    "foo"
]'''
    assert jsonify({"bar": "baz"}) == '{"bar": "baz"}'
    assert jsonify({"bar": "baz"}, format=True) == '''{
    "bar": "baz"
}'''
    assert jsonify({"bar": {"baz": "qux"}}) == '{"bar": {"baz": "qux"}}'

# Generated at 2022-06-23 05:21:01.721297
# Unit test for function jsonify
def test_jsonify():
    test_dict = {
        "name": "test_host",
        "some": {
            "nested": {
                "data": "here"
            }
        }
    }
    result = jsonify(test_dict)
    assert len(result) == 43
    result = jsonify(test_dict, format=True)
    assert len(result) == 73

    test_dict = {
        1: "test_host",
        2: {
            "nested": {
                "data": "here"
            }
        }
    }
    result = jsonify(test_dict)
    assert len(result) == 40
    result = jsonify(test_dict, format=True)
    assert len(result) == 70


# Generated at 2022-06-23 05:21:11.135561
# Unit test for function jsonify
def test_jsonify():
    data = jsonify(['foo','bar','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','qux'])
    assert data == json.dumps(['foo','bar','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','baz','qux'])

# Generated at 2022-06-23 05:21:16.724793
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should be able to return JSON with or without formatting'''

    result = {'a': 1, 'b': 2, 'c': 3}

    assert jsonify(result, format=False) == '{"a":1,"b":2,"c":3}'
    assert jsonify(result, format=True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'