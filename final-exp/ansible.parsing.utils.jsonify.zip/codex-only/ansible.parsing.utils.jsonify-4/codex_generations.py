

# Generated at 2022-06-23 05:11:14.674031
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1, b=2)
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-23 05:11:21.779838
# Unit test for function jsonify
def test_jsonify():
    myresult = {'a': 1, 'b': ['c', 'd', 'e'], 'f': {'g': 'h', 'i': 1}}
    assert(jsonify(myresult) == "{\"a\": 1, \"b\": [\"c\", \"d\", \"e\"], \"f\": {\"g\": \"h\", \"i\": 1}}")
    assert(jsonify(myresult, True) == "{\n    \"a\": 1, \n    \"b\": [\n        \"c\", \n        \"d\", \n        \"e\"\n    ], \n    \"f\": {\n        \"g\": \"h\", \n        \"i\": 1\n    }\n}")

# Generated at 2022-06-23 05:11:25.982345
# Unit test for function jsonify
def test_jsonify():
    json.dumps # suppress pyflakes error on this import
    assert(jsonify(dict(foo='bar')) == '{\n    "foo": "bar"\n}')

# Generated at 2022-06-23 05:11:32.128200
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsanitize import _unsanitize_json

    result = {'test':'foo'}
    compare = '{"test": "foo"}'
    assert jsonify(result, format=False) == compare

    result = {'test':'foo'}
    compare = '''{
    "test": "foo"
}'''
    assert jsonify(result, format=True) == compare



# Generated at 2022-06-23 05:11:41.274701
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify '''
    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    FakeVars = namedtuple('FakeVars', ['hostvars'])
    FakeVars.hostvars = {}

    myhost = Host('myhost')
    mygroup = Group('mygroup')
    mygroup.add_host(myhost)
    mygroup.vars = FakeVars()

    # test basic result
    assert jsonify({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'

    # test passing in None to result
    assert jsonify(None) == '{}'

    # test passing in an array

# Generated at 2022-06-23 05:11:51.617055
# Unit test for function jsonify

# Generated at 2022-06-23 05:11:56.230959
# Unit test for function jsonify
def test_jsonify():
    assert '{' == jsonify(None)
    assert '"foo"' == jsonify("foo")
    assert '{"bar": "baz"}' == jsonify({"bar": "baz"})

# Generated at 2022-06-23 05:11:58.921750
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({"foo" : 1, "bar" : 2}, True)
    assert result == "{\"bar\": 2, \"foo\": 1}"


# Generated at 2022-06-23 05:12:08.400354
# Unit test for function jsonify
def test_jsonify():
    import sys
    import json

    from ansible.utils.jsonify import jsonify
    if sys.version_info < (2, 6):
        raise SystemExit("FAIL: Python < 2.6 detected, cannot run this test.  Exiting.")
    else:
        data = [{"name": "foo"}, {"name": "bar"}]

        result = jsonify(data)
        data = json.loads(result)
        assert(data[0]['name'] == 'foo')

        formatted = jsonify(data, True)
        try:
            data = json.loads(formatted)
        except ValueError:
            raise
        else:
            assert(data[0]['name'] == 'foo')

    print("SUCCESS: jsonify module tests passed.")


# Generated at 2022-06-23 05:12:12.221328
# Unit test for function jsonify
def test_jsonify():
    ''' Test function to return JSON of a given object '''
    mock_result_1 = {'a':1,'b':2}
    mock_result_2 = None
    assert jsonify(mock_result_1) == '{"a": 1, "b": 2}'
    assert jsonify(mock_result_2) == '{}'

# Generated at 2022-06-23 05:12:24.134483
# Unit test for function jsonify
def test_jsonify():
    ''' function jsonify '''
    test_dict = json.loads('{"city": "Seoul", "country": "Korea"}')
    test_list = json.loads('["city", "Seoul", "country", "Korea", "continent", "Asia"]')
    test_bool = json.loads('[True]')
    test_set = set([1, 2, 3])
    test_int = [0]
    test_none = None

    assert jsonify(test_dict) == '{"city": "Seoul", "country": "Korea"}'
    assert jsonify(test_dict, True) == '{\n    "city": "Seoul", \n    "country": "Korea"\n}'

# Generated at 2022-06-23 05:12:30.187514
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": [1]}) == '{"a": [1]}'
    assert jsonify({"a": [1]}, True) == '{\n    "a": [\n        1\n    ]\n}'
    assert jsonify({"a": u'\u2601'}) == '{"a": "\\u2601"}'
    assert jsonify({"a": u'\u2601'}, True) == '{\n    "a": "\\u2601"\n}'

# Generated at 2022-06-23 05:12:39.858585
# Unit test for function jsonify
def test_jsonify():
    # Testing for format=False
    result = {'test': {'test1': 'test'}}
    output = jsonify(result)
    assert output == '{"test": {"test1": "test"}}'

    # Testing for format=True
    result = {'test': {'test1': 'test'}}
    output = jsonify(result, format=True)
    assert output == '{\n    "test": {\n        "test1": "test"\n    }\n}'

    # Testing for empty var
    result = None
    output = jsonify(result)
    assert output == '{}'

# Generated at 2022-06-23 05:12:46.796576
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"example": "test"}) == '{"example": "test"}'
    assert jsonify({"example": "test"}, True) == '{\n    "example": "test"\n}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify([1,2,3], True) == '[\n    1, \n    2, \n    3\n]'
    assert jsonify("test") == '"test"'
    assert jsonify("test", True) == '"test"'

# Generated at 2022-06-23 05:12:55.748390
# Unit test for function jsonify
def test_jsonify():

    result = {
        'hello': 'world',
        'foo': [1,2,3],
        'bar': {
            'cats': 10,
            'dogs': 20,
        }
    }

    j1 = jsonify(result, format=False)
    j2 = jsonify(result, format=True)

    assert j1 == '{"bar": {"cats": 10, "dogs": 20}, "foo": [1, 2, 3], "hello": "world"}'
    assert j2 == '''{
    "bar": {
        "cats": 10,
        "dogs": 20
    },
    "foo": [
        1,
        2,
        3
    ],
    "hello": "world"
}
'''

# Generated at 2022-06-23 05:13:06.859747
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    import ansible.module_utils.json_utils

    def mock_json_dumps(indent=None):
        return json.dumps({'a':1}, sort_keys=True, indent=indent, ensure_ascii=False)

    with patch.object(ansible.module_utils.json_utils, 'json', return_value=mock_json_dumps):
        assert ansible.module_utils.json_utils.jsonify({'a':1}) == '{\n    "a": 1\n}'
        assert ansible.module_utils.json_utils.jsonify({'a':1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-23 05:13:16.451803
# Unit test for function jsonify
def test_jsonify():

    # Test non-dict input
    assert jsonify(None) == "{}"
    assert jsonify(["foo"]) == json.dumps(["foo"], sort_keys=True)

    # Test non-ascii
    test_data = {
        u'\u2665': 'Value',
        'Key2': 'Value2'
    }

    # Test format=True with non-ascii
    assert jsonify(test_data, format=True) == json.dumps(test_data, ensure_ascii=False, indent=4, sort_keys=True)

    # Test format=False with non-ascii
    assert jsonify(test_data, format=False) == json.dumps(test_data, ensure_ascii=False, sort_keys=True)

    # Test format=True with as

# Generated at 2022-06-23 05:13:21.006254
# Unit test for function jsonify
def test_jsonify():
    result1 = {
        "invocation": {
            "module_name": "ping",
            "module_args": ""
        },
        "ping": "pong"
    }
    result2 = jsonify(result1)
    assert result2 == '{"invocation": {"module_args": "", "module_name": "ping"}, "ping": "pong"}'
    result3 = jsonify(result1)
    assert result3 == '{\n    "invocation": {\n        "module_args": "", \n        "module_name": "ping"\n    }, \n    "ping": "pong"\n}'

# Generated at 2022-06-23 05:13:29.773720
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(a=1, b=2, c=3)

    # check that it doesn't break with None input
    assert jsonify(None) == "{}"

    # check that it doesn't break with a dict input
    assert jsonify(test_dict) == '{"a": 1, "b": 2, "c": 3}'

    # check that it doesn't break with a dict input and format=True
    assert jsonify(test_dict, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# make sure we can call it without ansible-test
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:13:36.698302
# Unit test for function jsonify
def test_jsonify():

    result = jsonify(None)
    assert result == "{}"

    result = jsonify(None, True)
    assert result == "{}"

    result = jsonify(dict(a=1, b=2))
    assert result == '{"a": 1, "b": 2}'

    result = jsonify(dict(a=1, b=2), True)
    assert result == '{\n    "a": 1, \n    "b": 2\n}'


# Generated at 2022-06-23 05:13:45.427555
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 05:13:54.730423
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2 }
    formatted = jsonify(result, format=True)
    assert formatted == '{\n    "a": 1,\n    "b": 2\n}', formatted

# Run unit test only if invoked directly
if __name__ == '__main__':
    from ansible.utils import jsonify

    class AnsibleModule:
        def exit_json(self):
            pass

    def get_bin_path(binary):
        return '{binary}'.format(binary=binary)

    test_jsonify()

# Generated at 2022-06-23 05:14:02.469126
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({}) == '{}'
    assert jsonify(42) == '42'
    assert jsonify(3.14) == '3.14'
    assert jsonify("foo") == '"foo"'
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    #assert jsonify({u"fóo": u"bár"}) == '{"fóo": "bár"}'
    #assert jsonify({u"fóo": u"bár"}, True) == '{\n    "fóo": "bár"\n}'

# Generated at 2022-06-23 05:14:04.112196
# Unit test for function jsonify
def test_jsonify():
        assert jsonify({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:14:09.429781
# Unit test for function jsonify
def test_jsonify():
     assert jsonify({'a' : 1}, False) == '{"a": 1}'
     assert jsonify({'a' : 1}, True) == '''{
    "a": 1
}'''
     assert jsonify(None, False) == '{}'
     assert jsonify(None, True) == '{}'

# Generated at 2022-06-23 05:14:11.503994
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == '"foo"'

# Generated at 2022-06-23 05:14:21.693929
# Unit test for function jsonify
def test_jsonify():
    # fmt: off
    assert (jsonify("hello world")   == '"hello world"')
    assert (jsonify("hello world\n") == '"hello world\\n"')

    assert (jsonify(None)       == "{}")
    assert (jsonify([1,2,3])    == "[1, 2, 3]")
    assert (jsonify({"a": 1})   == '{"a": 1}')

    assert (jsonify(1, True)    == "1")
    assert (jsonify([1,2,3], True)  == "[\n    1,\n    2,\n    3\n]")
    assert (jsonify({"a": 1}, True) == "{\n    \"a\": 1\n}")
    # fmt: on

# Generated at 2022-06-23 05:14:31.956440
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("test") == '"test"'
    assert jsonify({"test": "test"}) == '{"test": "test"}'
    assert jsonify({"test": {"test2": "test2"}}, False) == '{"test": {"test2": "test2"}}'
    assert jsonify(["test", "test2"], False) == '["test", "test2"]'

    assert jsonify(None, True) == "{}"
    assert jsonify("test", True) == '"test"'
    assert jsonify({"test": "test"}, True) == '{\n    "test": "test"\n}'

# Generated at 2022-06-23 05:14:43.477948
# Unit test for function jsonify
def test_jsonify():
    def assert_equal(value, expected):
        result = jsonify(value)
        if result != expected:
            raise AssertionError('Result: %s is not equal to expected: %s' % (repr(value), repr(expected)))

    assert_equal(None, '{}')
    assert_equal(True, 'true')
    assert_equal('a', '"a"')
    assert_equal({'a': 'b'}, '{"a": "b"}')
    assert_equal({'a': 'b', 'c': 'd'}, '{"a": "b", "c": "d"}')
    assert_equal({'a': 'b', 'c': 'd', 'b': 'c'}, '{"a": "b", "b": "c", "c": "d"}')

# Generated at 2022-06-23 05:14:54.024594
# Unit test for function jsonify
def test_jsonify():
    ''' Test the jsonify function '''

    assert jsonify({}) == '{}'
    assert jsonify({}) == "{}"
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'

    assert jsonify(None) == "{}"
    assert jsonify({}, False) == "{}"
    assert jsonify({}, True)  == "{\n    \"\": {}\n}"
    assert jsonify({}, True) == jsonify({}, format=True)
    assert jsonify({"a": 1}, False) == '{"a": 1}'

# Generated at 2022-06-23 05:14:59.522144
# Unit test for function jsonify
def test_jsonify():
    ''' unit tests for jsonify '''
    assert jsonify({}) == '{}'
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, format=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-23 05:15:05.577655
# Unit test for function jsonify
def test_jsonify():
    a = dict(a=1, b=2)
    j = jsonify(a)
    assert(j == '{"a": 1, "b": 2}')

    j = jsonify(a, True)
    assert(j == '{\n    "a": 1, \n    "b": 2\n}')

# Generated at 2022-06-23 05:15:09.684987
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == "{\"a\": 1}"
    assert jsonify(dict(a=1, b=2)) == "{\"a\": 1, \"b\": 2}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:15:12.868474
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"failed": False}) == '{"failed": false}'
    assert jsonify({"failed": False}, format=True) == '{\n    "failed": false\n}'

# Generated at 2022-06-23 05:15:20.331414
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b'}, False) == '{"a": "b"}'
    assert jsonify({'a': {'b':{'c':'d'}}}, False) == '{"a": {"b": {"c": "d"}}}'
    assert jsonify({'a': {'b':{'c':'d'}}}, True) == '{\n    "a": {\n        "b": {\n            "c": "d"\n        }\n    }\n}'


# Generated at 2022-06-23 05:15:28.973486
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=False)) == '{"changed": false}'
    assert jsonify(dict(changed=False, foo=dict(bar='baz'))) == '{"changed": false, "foo": {"bar": "baz"}}'
    assert jsonify(dict(changed=False, foo=dict(bar=[dict(bam='baz', boz='buz')]))) == '{"changed": false, "foo": {"bar": [{"bam": "baz", "boz": "buz"}]}}'

# Generated at 2022-06-23 05:15:39.618825
# Unit test for function jsonify
def test_jsonify():
    data = {'status': True, 'results': ['444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444']}

# Generated at 2022-06-23 05:15:45.775902
# Unit test for function jsonify
def test_jsonify():
    # TODO: more tests

    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), True) == '''{
    "a": 1,
    "b": 2,
    "c": 3
}'''
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:15:51.990374
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify('foo') == '"foo"'
    assert jsonify(dict(a=1,b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1,b=2), True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-23 05:15:58.952273
# Unit test for function jsonify
def test_jsonify():

    # jsonify with ascii-only output
    result = jsonify({u'foo': [u'ba\u00e7']})
    assert result == '''{
    "foo": [
        "ba\\u00e7"
    ]
}'''

    # jsonify with unicode output
    result = jsonify({u'foo': [u'ba\u00e7']}, format=True)
    assert result == '''{
    "foo": [
        "baç"
    ]
}'''

# Generated at 2022-06-23 05:16:02.101617
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:16:03.742494
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(dict(name='John Doe')) == '{"name": "John Doe"}'

# Generated at 2022-06-23 05:16:15.070150
# Unit test for function jsonify
def test_jsonify():
    # pylint: disable=missing-docstring
    # jsonify(None) -> "{}"
    assert jsonify(None) == "{}"
    # jsonify()     -> "{}"
    assert jsonify() == "{}"

    # For future reference if we need to test with json.dumps with arguments, the tests would
    # look like this.
    #
    # jsonify({}, indent=2) -> a dictionary converted to json string with 2 unit indenting
    # assert jsonify({}, indent=2) == '{\n  \n}'
    #
    # jsonify({'a': 'b'}, indent=2) -> {'a': 'b'} converted to json string with 2 unit indenting
    # assert jsonify({'a': 'b'}, indent=2) == '{\n  "a": "b"\n}

# Generated at 2022-06-23 05:16:20.782637
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert isinstance(jsonify(True), basestring)
    assert jsonify({ 'foo': 'bar' }) == '{"foo": "bar"}'

    assert jsonify({ 'foo': 'bar' }, format=True) == "{\n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-23 05:16:25.113884
# Unit test for function jsonify
def test_jsonify():
    d = {'a': 1, 'b': 2}
    assert jsonify(d, format=False) == '{"a": 1, "b": 2}'
    assert jsonify(d, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-23 05:16:28.263572
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None, format=False) == "{}"
    assert jsonify(None) == "{}"
    assert jsonify({'foo': 'bar'}, format=False) == '{"foo": "bar"}'

# Generated at 2022-06-23 05:16:33.472870
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({}) == '{}'
    assert jsonify("foo") == '"foo"'
    assert jsonify("foo\nbar\n") == '"foo\nbar\n"'



# Generated at 2022-06-23 05:16:42.651985
# Unit test for function jsonify
def test_jsonify():
  result = {'changed': False, 'failed': False, 'msg': '', 'parsed': {'alert': {'/etc/passwd': 'owner=root mode=0644 uid=0 gid=0'}}}
  assert jsonify(result, format=False) == '{"changed": false, "failed": false, "msg": "", "parsed": {"alert": {"/etc/passwd": "owner=root mode=0644 uid=0 gid=0"}}}'

# Generated at 2022-06-23 05:16:54.563753
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys

    if not os.path.exists('/tmp/ansible_test_inventory.py'):
        print('\nNo test inventory (/tmp/ansible_test_inventory.py) found, skipping jsonify tests')
        return

    print('Testing ansible.utils jsonify')
    sys.path.insert(0, '/tmp')
    from ansible_test_inventory import TestInventory
    from ansible.playbook import PlayBook
    from ansible.callbacks import PlaybookCallbacks
    from ansible import callbacks

    stats = callbacks.AggregateStats()
    playbook_cb = PlaybookCallbacks(verbose=3)
    runner_cb = callbacks.DefaultRunnerCallbacks()

# Generated at 2022-06-23 05:17:02.794304
# Unit test for function jsonify
def test_jsonify():
    # Test with no argument
    no_argument = None
    assert jsonify(no_argument) == "{}"

    # Test with argument 'format' equals True
    assert jsonify({"a": "1", "b": "2"}, format=True) == '''{
    "a": "1",
    "b": "2"
}'''

    # Test with argument 'format' equals False
    assert jsonify({"a": "1", "b": "2"}) == '{"a": "1", "b": "2"}'

# Generated at 2022-06-23 05:17:13.875809
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None), jsonify(None)
    assert '{}' == jsonify({}), jsonify({})
    assert '' == jsonify(''), jsonify('')
    assert 'null' == jsonify(None), jsonify(None)
    assert '1' == jsonify(1), jsonify(1)
    assert '[1]' == jsonify([1]), jsonify([1])
    assert '{"a": 1}' == jsonify({'a': 1}), jsonify({'a': 1})

    # unicode support should not fail
    try:
        jsonify(u'caf\xE9')
    except UnicodeDecodeError:
        assert False, "UnicodeDecodeError not expected"

    # formatting should not fail

# Generated at 2022-06-23 05:17:21.137969
# Unit test for function jsonify
def test_jsonify():
    ''' functional test the jsonify function '''

    # Test basic json
    test_data = {
        "num": 1,
        "str": "abc",
        "list": ["a", "b", "c"],
    }

    result = jsonify(test_data)
    assert result == '{"list": ["a", "b", "c"], "num": 1, "str": "abc"}'

    # Test formatting
    result = jsonify(test_data, format=True)
    assert result == '''{
    "list": [
        "a",
        "b",
        "c"
    ],
    "num": 1,
    "str": "abc"
}'''



# Generated at 2022-06-23 05:17:29.050082
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}, True) == '''{
    "a": 1,
    "b": 2,
    "c": 3
}'''
    assert jsonify({'a': 'a', 'b': u'\u1234', 'c': 'c'}, True) == '''{
    "a": "a",
    "b": "\u1234",
    "c": "c"
}'''


# Generated at 2022-06-23 05:17:41.356814
# Unit test for function jsonify
def test_jsonify():
    # None
    result = jsonify(None, True)
    assert result == '{}'
    # Empty list
    result = jsonify([], True)
    assert result == '[]'
    # one item
    result = jsonify(dict(localhost=dict(debian=dict(rc=0, failed=False))), True)
    assert result == ("{\n"
"    \"localhost\": {\n"
"        \"debian\": {\n"
"            \"failed\": false,\n"
"            \"rc\": 0\n"
"        }\n"
"    }\n"
"}")
    # multiple items
    result = jsonify(dict(localhost=dict(debian=dict(rc=0, failed=False)),
                          myhost=dict(debian=dict(rc=0, failed=False))), True)
   

# Generated at 2022-06-23 05:17:52.595928
# Unit test for function jsonify
def test_jsonify():
    # check jsonify handles pretty printing
    ansible_output_compressed = '{"result": {"_ansible_no_log": false, "_ansible_item_result": true, "changed": false, "item": "test1"}}'
    ansible_output_uncompressed = '''{
    "result": {
        "_ansible_no_log": false,
        "_ansible_item_result": true,
        "changed": false,
        "item": "test1"
    }
}'''
    assert jsonify({'result': {'changed': False, 'item': 'test1'}}, format=False) == ansible_output_compressed
    assert jsonify({'result': {'changed': False, 'item': 'test1'}}, format=True) == ansible_output_uncompressed

   

# Generated at 2022-06-23 05:18:04.303866
# Unit test for function jsonify
def test_jsonify():
    test_cases = [
            ['foo', False],
            [u'foo', False],
            ['foo', True],
            [u'foo', True],
            [{'foo': 'bar'}, True],
            [{u'foo': u'bar'}, True],
            [{'foo': u'bar'}, True],
            ]

    for item in test_cases:
        assert(jsonify(item[0], format=item[1]) == '"%s"' % item[0])

    assert(jsonify(None) == '{}')
    assert(jsonify(False) == '"False"')
    assert(jsonify(True) == '"True"')

    assert(jsonify({'foo': 'bar'}) == '{"foo": "bar"}')

# Generated at 2022-06-23 05:18:08.460222
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:18:15.009752
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'hello': 'world'}) == '{"hello": "world"}'
    assert jsonify({'hello': u'你好'}) == '{"hello": "\\u4f60\\u597d"}'


# Generated at 2022-06-23 05:18:17.975724
# Unit test for function jsonify
def test_jsonify():
    print(jsonify({'a': 'b'}, True))


# Generated at 2022-06-23 05:18:28.549233
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_native

    assert jsonify(None) == '{}'
    assert jsonify('') == '""'
    assert jsonify([]) == '[]'
    assert jsonify({}) == '{}'
    assert jsonify({u'hi': u'hello'}) == u'{"hi": "hello"}'

    if to_native(b'\xe4\xb8\xad\xe6\x96\x87'.decode('utf-8')) == '中文':
        assert jsonify({u'hi': u'中文'}) == u'{"hi": "中文"}'

    # FIXME: Windows reports an error
    # assert jsonify({u'hi': u'中文'}, True) == '{\n    "hi": "中

# Generated at 2022-06-23 05:18:40.015406
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.color import ANSIBLE_COLOR, stringc

    json_in = { 'changed': False,
                'ping': 'pong',
                'failed': False,
                'item': 5 }

    json_out = jsonify(json_in, format=False)
    if json_out != '{"changed": false, "failed": false, "item": 5, "ping": "pong"}':
        print("ERROR: unexpected output for jsonify w/ format=False: %s" % json_out)

    json_out = jsonify(json_in, format=True)

# Generated at 2022-06-23 05:18:50.830147
# Unit test for function jsonify
def test_jsonify():
    input_data = {
        "changed": False,
        "ping": "pong",
        "words": [
            "a","b","c"
        ],
        "numbers": [
            0,1,2,3,4,5,6,7,8,9
        ]
    }
    non_format = jsonify(input_data, format=False)
    format = jsonify(input_data, format=True)
    assert non_format == '{"changed": false, "numbers": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], "ping": "pong", "words": ["a", "b", "c"]}'

# Generated at 2022-06-23 05:18:57.969473
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    data = {
        'foo': 'bar',
        'unsafe_text': AnsibleUnsafeText(u'I am unsafe text'),
        'unsafe_bytes': AnsibleUnsafeBytes(b'I am unsafe bytes'),
        u'unicode_key': u'unicode value'
    }
    data_formatted = jsonify(data)
    data_unformatted = jsonify(data, format=True)
    assert data_formatted == '{"foo": "bar", "unsafe_bytes": "I am unsafe bytes", "unsafe_text": "I am unsafe text", "unicode_key": "unicode value"}'


# Generated at 2022-06-23 05:19:03.277533
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1}) == '{"a": 1}'
    assert jsonify({'a':1}, format=True) == '{\n    "a": 1\n}'
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(False) == "false"

# Generated at 2022-06-23 05:19:14.495273
# Unit test for function jsonify
def test_jsonify():

    import copy
    from ansible.module_utils._text import to_text


# Generated at 2022-06-23 05:19:23.730708
# Unit test for function jsonify

# Generated at 2022-06-23 05:19:34.029782
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert jsonify({}) == "{}"
    assert jsonify({}, format=True) == "{\n    \n}"
    assert jsonify({'test': 1}) == '{"test": 1}'
    assert jsonify({'test': 1}, format=True) == '{\n    "test": 1\n}'
    assert jsonify({'test': AnsibleUnsafeText('\x00')}) == '{"test": "\u0000"}'
    assert jsonify({'test': AnsibleUnsafeText('\x00')}, format=True) == '{\n    "test": "\u0000"\n}'
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'

# Generated at 2022-06-23 05:19:40.621279
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    data = {"a": [1,2,3], "b": {"ba": u"bar", "bb": u"b\xe4r", "bc": AnsibleUnsafeText(u"b\xe4r")}}
    assert jsonify(data, True) == '''{
    "a": [
        1,
        2,
        3
    ],
    "b": {
        "ba": "bar",
        "bb": "b\\u00e4r",
        "bc": "b\\u00e4r"
    }
}'''

# Generated at 2022-06-23 05:19:47.750613
# Unit test for function jsonify
def test_jsonify():
    x = {'name': 'TestJoe', 'age': '6'}
    assert jsonify(x) == '{"age": "6", "name": "TestJoe"}'  # unformatted
    assert jsonify(x, format=True) == '{\n    "age": "6", \n    "name": "TestJoe"\n}'  # formatted
    assert jsonify(None) == '{}'  # unformatted
    assert jsonify(None, format=True) == '{}'  # formatted
    assert jsonify("") == '{}'  # unformatted
    assert jsonify("", format=True) == '{}'  # formatted

# Generated at 2022-06-23 05:19:54.678635
# Unit test for function jsonify
def test_jsonify():
    json_str = {'a': 1, 'b': 2}
    ans_str = jsonify(json_str)
    exp_str = '''{
    "a": 1,
    "b": 2
}'''
    assert ans_str == exp_str
    json_str = "test"
    ans_str = jsonify(json_str)
    exp_str = '"test"'
    assert ans_str == exp_str



# Generated at 2022-06-23 05:20:04.596476
# Unit test for function jsonify
def test_jsonify():
    result = {
        'foo': 'bar',
        'bam': {
            'boo': 'faz',
            'far': 'faz',
        },
    }
    # Test non-formatted output
    assert jsonify(result) == "{\"bam\": {\"boo\": \"faz\", \"far\": \"faz\"}, \"foo\": \"bar\"}"
    # Test formatted output
    assert jsonify(result, format=True) == "{\n    \"bam\": {\n        \"boo\": \"faz\", \n        \"far\": \"faz\"\n    }, \n    \"foo\": \"bar\"\n}"

# Generated at 2022-06-23 05:20:07.950359
# Unit test for function jsonify
def test_jsonify():
    j = jsonify({'ping': 'pong'})
    assert j == '{"ping": "pong"}'
    j = jsonify({'ping': 'pong'}, format=True)
    assert j == '{\n    "ping": "pong"\n}'


# Generated at 2022-06-23 05:20:14.304578
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed="yes")) == '{"changed": "yes"}'
    assert jsonify(dict(changed="yes"), format=True) == '{\n    "changed": "yes"\n}'
    assert jsonify(None) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'

# Generated at 2022-06-23 05:20:16.731176
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}) == '{"a": "b"}'


# Generated at 2022-06-23 05:20:20.424201
# Unit test for function jsonify
def test_jsonify():
    result = { "success" : True, "result" : "Hello world" }
    assert jsonify(result, True) == \
        "{\n"\
        "    \"result\": \"Hello world\", \n"\
        "    \"success\": true\n"\
        "}"

# Generated at 2022-06-23 05:20:25.205690
# Unit test for function jsonify
def test_jsonify():
    result = { 'unicode': u'\xe9', 'byte': '\xc3' }
    expected = '{"byte": "\\u00c3", "unicode": "\\u00e9"}'
    assert jsonify(result) == expected

# Generated at 2022-06-23 05:20:34.078668
# Unit test for function jsonify
def test_jsonify():

    # None should be returned as {}
    result = jsonify(None)
    assert result == '{}'

    # A simple JSON structure
    result = jsonify({"esx1": {"hostname": "localhost", "ram": 2048}})
    assert result == '{"esx1": {"hostname": "localhost", "ram": 2048}}'

    # A more complex JSON structure
    result = jsonify({"esx1": {"hostname": "localhost", "ram": 2048}, "esx2": {"hostname": "localhost", "ram": 4096}})
    assert result == '{"esx1": {"hostname": "localhost", "ram": 2048}, "esx2": {"hostname": "localhost", "ram": 4096}}'

# Generated at 2022-06-23 05:20:37.064647
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'key': 'value'}) == '{"key": "value"}'
    assert jsonify({'key': 'value'}, format=True) == '{\n    "key": "value"\n}'

# Generated at 2022-06-23 05:20:42.347754
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify([{"a":"b"}]) == '[{"a": "b"}]'
    assert jsonify({"a":"b"}) == '{"a": "b"}'
    assert jsonify("") == "\"\""
    assert jsonify("a") == "\"a\""
    assert jsonify([{"a":"b"}, {"c":"d"}]) == '[{"a": "b"}, {"c": "d"}]'

# Generated at 2022-06-23 05:20:46.153802
# Unit test for function jsonify
def test_jsonify():
    from ansible.inventory.host import Host
    hosts = [Host(name="127.0.0.1")]
    results = jsonify({"contacted": {"127.0.0.1": {"ping": "pong"}}}, format=True)
    assert results == '''{
    "contacted": {
        "127.0.0.1": {
            "ping": "pong"
        }
    }
}'''

# Generated at 2022-06-23 05:20:47.534882
# Unit test for function jsonify
def test_jsonify():
    # Test None input
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:20:57.109287
# Unit test for function jsonify
def test_jsonify():
    dict = dict(ansible_facts=dict(a=1,b=2))
    assert jsonify(dict) == '{"ansible_facts": {"a": 1, "b": 2}}'
    assert jsonify(dict, True) == '''{
    "ansible_facts": {
        "a": 1,
        "b": 2
    }
}'''

    dict = dict(a=1,b=2)
    assert jsonify(dict) == '{"a": 1, "b": 2}'
    assert jsonify(dict, True) == '''{
    "a": 1,
    "b": 2
}'''

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:21:04.674025
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify()
    Test the format option for the output for the jsonify function.
    '''

    test_simple = jsonify({'msg':'OK'})
    test_simple_formatted = jsonify({'msg':'OK'}, True)
    assert test_simple == '{"msg": "OK"}'
    assert test_simple_formatted == '{\n    "msg": "OK"\n}'

    # This is a regression test to ensure we avoid a UnicodeDecodeError
    # when ansible_facts contains a non-ascii string.

# Generated at 2022-06-23 05:21:15.632539
# Unit test for function jsonify
def test_jsonify():
    ''' return valid JSON using various inputs '''

    assert(jsonify(None) == "{}")
    assert(jsonify([]) == "[]")
    assert(jsonify({}) == "{}")
    assert(jsonify(dict(changed=False, rc=0)) == '{"changed": false, "rc": 0}')
    assert(jsonify(dict(changed=False, rc=0, failed=False, stdout="OK")) == '{"changed": false, "failed": false, "rc": 0, "stdout": "OK"}')
    assert(jsonify(dict(changed=True, rc=0, failed=False, stdout="OK")) == '{"changed": true, "failed": false, "rc": 0, "stdout": "OK"}')

# Test for function jsonify with format=True