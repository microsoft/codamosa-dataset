

# Generated at 2022-06-23 05:11:14.469111
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'



# Generated at 2022-06-23 05:11:22.515104
# Unit test for function jsonify
def test_jsonify():

    result = jsonify(None, False)
    assert result == "{}"

    result = jsonify({}, False)
    assert result == "{}"

    result = jsonify({'foo': 'bar'}, False)
    assert result == '{"foo": "bar"}'

    result = jsonify({'foo': 'bar'}, True)
    assert result == '{\n    "foo": "bar"\n}'

    result = jsonify({'foo': 'bar', 'baz': {'faz': 'blah'}}, True)
    assert result == '{\n    "baz": {\n        "faz": "blah"\n    }, \n    "foo": "bar"\n}'

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-23 05:11:35.357617
# Unit test for function jsonify
def test_jsonify():
    from collections import namedtuple
    Test = namedtuple('Test', ['result', 'expected'])


# Generated at 2022-06-23 05:11:43.438902
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should serialize a Python data structure to JSON '''

    from ansible.compat.tests import unittest
    from ansible.parsing import vault

    class TestJsonify(unittest.TestCase):

        def test_serialize_dict(self):
            test_dict = dict(a=1, b='string', c=[1, 2, 3])
            test_json = jsonify(test_dict)
            self.assertEqual(test_json, '{"a": 1, "b": "string", "c": [1, 2, 3]}')
            self.assertEqual(json.loads(test_json), test_dict)


# Generated at 2022-06-23 05:11:47.886909
# Unit test for function jsonify
def test_jsonify():
    assert '{\n    "test_key": "test_value",\n    "test_key2": "test_value2"\n}' == jsonify({"test_key":"test_value", "test_key2":"test_value2"}, format=True)

# Generated at 2022-06-23 05:11:54.094231
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(["a", "b"]) == '["a", "b"]'
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify(5) == "5"
    assert jsonify(None) == "{}"
    assert jsonify({"a": "b"}, True).startswith('{\n    "a": "b"\n')

if __name__ == '__main__':
    # Run unit tests if called directly
    test_jsonify()

# Generated at 2022-06-23 05:12:00.674516
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a='a',b='b')) == '{"a": "a", "b": "b"}'
    assert jsonify(dict(a='a',b='b'), True) == '{\n    "a": "a", \n    "b": "b"\n}'
    assert jsonify(dict(a='a',b='b'), False) == '{"a": "a", "b": "b"}'

# Generated at 2022-06-23 05:12:07.506741
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify

    test_dict = {'a': 1, 'b': 2, 'c': [1,2,3]}

    assert jsonify(test_dict) == "{\"a\": 1, \"b\": 2, \"c\": [1, 2, 3]}"
    assert jsonify(test_dict, True) == "{\n    \"a\": 1, \n    \"b\": 2, \n    \"c\": [\n        1, \n        2, \n        3\n    ]\n}"
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:12:15.278749
# Unit test for function jsonify
def test_jsonify():
    # Test format=False
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'
    # Test format=True
    assert jsonify({'foo':'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    # Test None
    assert jsonify(None) == '{}'
    # Test UnicodeDecodeError
    result = {'foo': 'b\xe4r'}
    assert jsonify(result) == '{"foo": "b\\u00e4r"}'
    # Test UnicodeDecodeError in format=True
    assert jsonify(result, format=True) == '{\n    "foo": "b\\u00e4r"\n}'

# Generated at 2022-06-23 05:12:17.937806
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}, format=True) == '{\n    "foo": "bar"\n}'


# Generated at 2022-06-23 05:12:24.090784
# Unit test for function jsonify
def test_jsonify():
    results = [
        {},
        {'msg': 'fake_message'},
        {'failed' : True, 'msg': 'fake_message'},
        {'failed' : True, 'changed': True, 'msg': 'fake_message'}
    ]

    for result in results:
        assert jsonify(result) == jsonify(result, False)
        assert jsonify(result) != jsonify(result, True)

# Generated at 2022-06-23 05:12:29.779945
# Unit test for function jsonify
def test_jsonify():
    # Test result that is None
    result = None
    json_results = jsonify(result, format=True)
    expected = '{\n}\n'
    assert json_results == expected

    # Test jsonify of a flat list
    result = ['a', 'b', 'c']
    json_results = jsonify(result, format=True)
    expected = '[\n    "a",\n    "b",\n    "c"\n]\n'
    assert json_results == expected

# Generated at 2022-06-23 05:12:37.596292
# Unit test for function jsonify
def test_jsonify():
    # Ensure that the jsonify function handles unset input
    assert jsonify(None) == "{}"

    # Ensure that the jsonify function properly formats output
    assert jsonify({'foo': 'bar'}, format=True) == '''{
    "foo": "bar"
}'''

    # Ensure that the jsonify function handles non-printing characters
    assert jsonify({'foo': b'bar'}, format=True) == '''{
    "foo": "bar"
}'''

# Generated at 2022-06-23 05:12:46.515327
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

    assert jsonify({"a": "b"}) == '{"a": "b"}'

    assert jsonify({"a": {"b": "c"}}, True) == '{\n    "a": {\n        "b": "c"\n    }\n}'

    assert jsonify({"ascii": "\xe2\x9d\xa4"}, True) == '{\n    "ascii": "\xe2\x9d\xa4"\n}'

    assert jsonify({"unicode": "\xe2\x9d\xa4"}, True) == '{\n    "unicode": "\\u2764"\n}'

# Generated at 2022-06-23 05:12:54.191991
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert jsonify({'a': 1, 'b': 2, 'c': 'foo'}, True) == \
        """{
    "a": 1,
    "b": 2,
    "c": "foo"
}"""
    assert jsonify('foo') == '"foo"'
    assert jsonify(['foo']) == '["foo"]'
    assert jsonify(['foo', AnsibleUnsafeText(u'bar\u2603')]) == \
        '["foo", "bar\\u2603"]'

# Generated at 2022-06-23 05:13:02.004917
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(1) == "1"
    assert jsonify("xyz") == '"xyz"'
    assert jsonify({"a": 1, "b": "xyz"}) == '{"a": 1, "b": "xyz"}'
    assert jsonify("xyz", format=True) == '"xyz"'
    assert jsonify({"a": 1, "b": "xyz"}, format=True) == '{\n    "a": 1,\n    "b": "xyz"\n}'

# Generated at 2022-06-23 05:13:05.573456
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, indent=True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:13:10.281290
# Unit test for function jsonify
def test_jsonify():
    result = {'a': 1, 'b': 2}
    assert jsonify(result) == '{"a": 1, "b": 2}'
    assert jsonify(result, True) == '{\n    "a": 1, \n    "b": 2\n}'

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:13:15.492121
# Unit test for function jsonify
def test_jsonify():

    result = {
        "somehost": {
            "changed": False,
            "ping": "pong"
        }
    }

    assert jsonify(result) == '{"somehost":{"changed":false,"ping":"pong"}}'
    assert jsonify(result, format=True) == '{\n    "somehost": {\n        "changed": false, \n        "ping": "pong"\n    }\n}'

# Generated at 2022-06-23 05:13:23.492334
# Unit test for function jsonify
def test_jsonify():
    import sys
    import platform
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class JsonifyTester(unittest.TestCase):
        @patch.object(sys, 'version_info', MagicMock(major=2))
        def test_jsonify_is_not_string(self):
            self.assertEqual(jsonify(42), '42')

        @patch.object(sys, 'version_info', MagicMock(major=3))
        def test_jsonify_is_not_string_py3(self):
            self.assertEqual(jsonify(42), '42')


# Generated at 2022-06-23 05:13:30.355984
# Unit test for function jsonify
def test_jsonify():
    # test format=False
    data = dict(a=dict(b="c"))
    out = jsonify(data)
    assert out == '{"a": {"b": "c"}}'

    # test format=True
    data = dict(a=dict(b="c"))
    out = jsonify(data, True)
    assert out == '{\n    "a": {\n        "b": "c"\n    }\n}'

# Generated at 2022-06-23 05:13:36.415541
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, format=False) == '{}'

    assert jsonify(dict(a=1,b=2), format=False) == '{"a": 1, "b": 2}'

    assert jsonify(dict(a=1,b=2), format=True) == '''{
    "a": 1,
    "b": 2
}'''.replace("    ", " "*indent)

# Generated at 2022-06-23 05:13:39.203679
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(dict(a=1)) == '{"a": 1}')
    assert(jsonify(None) == '{}')


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:13:42.083301
# Unit test for function jsonify
def test_jsonify():
    result = dict(a=1,b=2)
    assert jsonify(result, True) == json.dumps(result, sort_keys=True, indent=4)

# Generated at 2022-06-23 05:13:45.379258
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:13:54.120564
# Unit test for function jsonify
def test_jsonify():
    # jsonify a simple dict
    print(jsonify({'foo': 'bar'}))
    # assert jsonify({'foo': 'bar'}) == "{'foo': 'bar'}"

    # jsonify a more complex dict and format it
    print(jsonify({'foo': 'bar', 'baz': 'qux'}, format=True))
    # assert jsonify({'foo': 'bar', 'baz': 'qux'}, format=True) == '{\n    "baz": "qux", \n    "foo": "bar"\n}'

    # jsonify and format a string
    print(jsonify('foobar', format=True))
    # assert jsonify('foobar', format=True) == '"foobar"'

    # jsonify and format a number

# Generated at 2022-06-23 05:14:03.778395
# Unit test for function jsonify
def test_jsonify():
    # Test that jsonify is successfully able to encode some datatypes
    my_dict = {'a_key': 'a_value', 'b': True}
    assert jsonify(my_dict) == '{"a_key": "a_value", "b": true}'
    my_list = [1,2,3,4]
    assert jsonify(my_list) == '[1, 2, 3, 4]'
    my_string = 'a_string_value'
    assert jsonify(my_string) == '"a_string_value"'
    my_int = 100
    assert jsonify(my_int) == '100'
    my_bool = True
    assert jsonify(my_bool) == 'true'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:14:14.639026
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.script import InventoryScript
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.basic import AnsibleModule

    loader= DataLoader()
    inv = InventoryParser(loader=loader, sources=['tests/inventory/test_inventory.ini'])
    inv_script = InventoryScript(loader=loader, filename='tests/inventory/test_inventory.sh')
    inv_script.parse()
    inv.add_group(Group(name='custom'))
    inv.add_

# Generated at 2022-06-23 05:14:19.255508
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() '''
    assert jsonify(None) == '{}'
    assert jsonify("somedata") == '"somedata"'
    assert jsonify(1) == '1'
    assert jsonify({"a": [1,2,3]}) == '{"a": [1, 2, 3]}'


# Generated at 2022-06-23 05:14:23.618710
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'name': 'test'})
    assert result == '{\n    "name": "test"\n}'
    result = jsonify({'name': 'test'}, False)
    assert result == '{"name": "test"}'

# Generated at 2022-06-23 05:14:24.973504
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-23 05:14:31.261092
# Unit test for function jsonify
def test_jsonify():
    # Tests for the raw output
    test1 = jsonify({'a': 1, 'b': 2})
    assert test1 == '{"a": 1, "b": 2}', 'raw output must not be formatted'

    # Tests for the formatted output
    test2 = jsonify({'a': 1, 'b': 2}, format=True)
    assert test2 == '{\n    "a": 1, \n    "b": 2\n}', 'raw output must be formatted'



# Generated at 2022-06-23 05:14:38.427960
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info < (2, 7):
        raise Exception("We need python 2.7 or higher")

    assert jsonify({'a': '\\xe4'}) == '{"a": "\\\\u00e4"}'
    assert jsonify({'a': '\\xe4'}, True) == '{\n    "a": "\\\\u00e4"\n}'

# Generated at 2022-06-23 05:14:43.901127
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == json.dumps(dict(foo='bar'))
    assert jsonify(dict(foo='bar'), True) == json.dumps(dict(foo='bar'), indent=4)

# Generated at 2022-06-23 05:14:47.597029
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"

    assert jsonify([1, 2]) == '[1, 2]'

    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-23 05:14:55.527714
# Unit test for function jsonify
def test_jsonify():
    args = ('', False)
    kwargs = {'format': True}
    assert jsonify(["a", "b"]) == '["a", "b"]'
    assert jsonify("a") == '"a"'
    assert '{\n    "a": "b", \n    "c": [\n              "d", \n              "e"\n          ]\n}' in jsonify({"a":"b","c":["d","e"]},**kwargs)

# Generated at 2022-06-23 05:15:05.726232
# Unit test for function jsonify
def test_jsonify():
    result = {u'foo': u'bar', 'baz': 'g\xf5r'}
    expected_result = '{"baz": "g\\xf5r", "foo": "bar"}'
    assert jsonify(result, format=False) == expected_result
    assert jsonify(result, format=True) == '{\n    "baz": "g\\xf5r", \n    "foo": "bar"\n}'
    assert jsonify(None, format=False) == '{}'
    result = {u'foo': u'bar', 'baz': 'g\xf5r'}
    assert jsonify(result, format=True) == '{\n    "baz": "g\\xf5r", \n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:15:17.127443
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test UnsafeText
    test_str = AnsibleUnsafeText(u'{"foo":"bar"}')
    ret = jsonify(test_str)
    assert ret == '"{\\"foo\\": \\"bar\\"}"'

    # Test JSON output
    test_dict = {"foo": "bar"}
    ret = jsonify(test_dict)
    assert ret == '{"foo": "bar"}'

    # Test JSON output with format
    test_dict = {"foo": "bar"}
    ret = jsonify(test_dict, True)
    assert ret == '{\n    "foo": "bar"\n}'

    # Test JSON output with None
    ret = jsonify(None)
    assert ret == '{}'

# Generated at 2022-06-23 05:15:27.341506
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test 0: None is returned as {}
    assert '{}' == jsonify(None)

    # Test 1: A regular data structure is returned as JSON string
    _result = {'_ansible_verbose_override': False, '_ansible_no_log': False,
                '_ansible_verbosity': 0, '_ansible_version': '2.1.1.0',
                'invocation': {'module_args': {'build_info': {'date': 1623, 'kernel': '3.13.0-43-generic',
                                                              'version': '2.5'}}}
                }

# Generated at 2022-06-23 05:15:31.134799
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':'b'}) == '{\"a\": \"b\"}'
    assert jsonify({'a':'b'}, True) == '{\n    \"a\": \"b\"\n}'

# Generated at 2022-06-23 05:15:34.956657
# Unit test for function jsonify
def test_jsonify():
    mydic = {'foo': 1, 'bar': 2, 'baz': 3 }
    print(mydic)
    print(jsonify(mydic, True))
    print(jsonify(mydic))

#test_jsonify()

# Generated at 2022-06-23 05:15:38.584902
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, True) == '{\n    "a": 1\n}'

# Generated at 2022-06-23 05:15:48.447511
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True)) == '{"changed": true}'
    assert jsonify(dict(changed=False)) == '{"changed": false}'
    assert jsonify(dict(failed=True)) == '{"failed": true}'
    assert jsonify(dict(failed=False)) == '{"failed": false}'
    assert jsonify(dict(skipped=True)) == '{"skipped": true}'
    assert jsonify(dict(skipped=False)) == '{"skipped": false}'
    assert jsonify(dict(changed=True,failed=False,skipped=False,rc=0)) == '{"changed": true, "failed": false, "rc": 0, "skipped": false}'

# Generated at 2022-06-23 05:15:54.216996
# Unit test for function jsonify
def test_jsonify():
    test_dict = {'some': 'random', 'dictionary': 'toJsonify', 'foo': 'bar'}
    test_json = '{"dictionary": "toJsonify", "foo": "bar", "some": "random"}'
    result = jsonify(test_dict, False)
    assert result == test_json

# Generated at 2022-06-23 05:15:59.538792
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':False, 'b':True}) == '{"a": false, "b": true}'
    assert jsonify({'a':False, 'b':True}, True) == '{\n    "a": false, \n    "b": true\n}'

if __name__ == '__main__':
    # Run local unit tests
    test_jsonify()

# Generated at 2022-06-23 05:16:02.024453
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}
    x = jsonify(result)
    assert x == json.dumps(result, sort_keys=True, ensure_ascii=False)


# Generated at 2022-06-23 05:16:06.031442
# Unit test for function jsonify
def test_jsonify():
    ''' make sure we are converting to JSON as expected '''

    assert jsonify({}) == "{}"
    assert jsonify(dict(changed=False, rc=0)) == '{"rc": 0, "changed": false}'
    assert jsonify(dict(changed=False, rc=0, results="somedata")) == '{"rc": 0, "changed": false, "results": "somedata"}'

# Generated at 2022-06-23 05:16:14.832506
# Unit test for function jsonify
def test_jsonify():
    import json
    import nose

    # Make sure that jsonify works with empty input
    assert json.loads(jsonify(None)) == {}

    # Make sure that jsonify works with regular json input
    data = {'key': 'value'}
    assert json.loads(jsonify(data)) == data

    # Test with non-ascii characters
    data = {'with': {'array': [1, 2, 3], 'non-ascii': u'\xfa'}}
    nose.tools.assert_equal(jsonify(data), json.dumps(data, ensure_ascii=False))


# Generated at 2022-06-23 05:16:19.280934
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 05:16:24.118607
# Unit test for function jsonify
def test_jsonify():
    result_dict = dict(changed=True, rc=0, stdout='foo', stderr='bar')
    assert json.loads(jsonify(result_dict)) == result_dict
    assert jsonify(None) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'



# Generated at 2022-06-23 05:16:26.311940
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'


# Generated at 2022-06-23 05:16:32.554616
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': True}) == '{"a": true}'
    assert jsonify({'a': True}, True) == '''{
    "a": true
}'''
    assert jsonify({'a': 'føø', 'b': 'bar'}, True) == '''{
    "a": "føø",
    "b": "bar"
}'''
    assert jsonify(True) == 'true'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:16:42.008927
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.json_utils import jsonify
    module = AnsibleModule(argument_spec=dict())
    result = dict(
        jsonify=dict(
            foo=dict(
                bar=4,
                baz=True
            ),
            baz=dict(
                foo=3
            )
        )
    )
    assert module.from_json(jsonify(result, format=True)) == module.from_json("""{
    "jsonify": {
        "baz": {
            "foo": 3
        },
        "foo": {
            "bar": 4,
            "baz": true
        }
    }
}
""")

# Generated at 2022-06-23 05:16:46.857475
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants as C
    from ansible.utils.color import stringc

    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:16:57.316450
# Unit test for function jsonify
def test_jsonify():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play

    host = Host("testhost")
    group = Inventory("group")
    group.add_host(host)

    variables = VariableManager(loader=None)
    variables.add_group_vars("group", {"key": "value"})
    variables.add_host_vars("testhost", {"key": "override"})

    play = Play()
    play.connection = "local"
    play.hosts = "group"
    play.variables = variables

    assert "{\"key\": \"override\"}" == jsonify(variables.get_vars(play=play, host=host))


# Generated at 2022-06-23 05:17:00.212282
# Unit test for function jsonify
def test_jsonify():

    result = {'a': 1, 'b': 2}
    assert jsonify(result) == "{\"a\": 1, \"b\": 2}"
    assert jsonify(result, format=True) == """{
    "a": 1,
    "b": 2
}"""

# Generated at 2022-06-23 05:17:11.698657
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == u'{}'
    assert jsonify({}, format=True) == u'{\n}'
    assert jsonify({'a':1, 'b':2}, format=True) == u'{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({u'ü':1}, format=True) == u'{\n    "ü": 1\n}'

# Generated at 2022-06-23 05:17:20.529305
# Unit test for function jsonify
def test_jsonify():
    import pytest
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        def test_format(self):
            # ensure that formatting leaves newlines in the json
            data = {
                'a': 1,
                'b': 2,
            }
            formatted_data = jsonify(data, format=True)

            print(formatted_data)
            assert '\n' in formatted_data

        def test_no_format(self):
            # ensure that not formatting removes newlines from the json
            data = {
                'a': 1,
                'b': 2,
            }
            formatted_data = jsonify(data, format=False)

            print(formatted_data)
            assert '\n' not in formatted_data


# Generated at 2022-06-23 05:17:21.969024
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(dict(a=1,b=2)) == dict(a=1,b=2)

# Generated at 2022-06-23 05:17:29.345127
# Unit test for function jsonify
def test_jsonify():
    ''' This is a small test suite for the jsonify function '''

    # simple test
    test_dict = { 'a': 1, 'b': 2 }
    result = jsonify(test_dict)
    assert result == '{"a": 1, "b": 2}'

    # test with format
    test_dict = { 'a': 1, 'b': 2 }
    result = jsonify(test_dict, True)
    assert result == '''{
    "a": 1,
    "b": 2
}'''

# Generated at 2022-06-23 05:17:36.069735
# Unit test for function jsonify
def test_jsonify():
    result = {
        'key1': 'value1',
        'key2': [ 'value2', 'value3' ],
    }
    expected_result = '{\n    "key1": "value1", \n    "key2": [\n        "value2", \n        "value3"\n    ]\n}'
    assert expected_result == jsonify(result, format=True)

# Generated at 2022-06-23 05:17:43.491199
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(False) == 'false'
    assert jsonify(True) == 'true'
    assert jsonify(42) == '42'
    assert jsonify(42.3) == '42.3'
    assert jsonify('foo') == '"foo"'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'a':1,'b':2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-23 05:17:50.984960
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'spam': 'eggs'}, format=False)
    assert result == '{"spam": "eggs"}'

    result = jsonify({'spam': 'eggs'}, format=True)
    assert  result == '{\n    "spam": "eggs"\n}'

    result = jsonify(['spam', 'eggs'], format=True)
    assert  result == '[\n    "spam", \n    "eggs"\n]'

# Generated at 2022-06-23 05:17:52.543161
# Unit test for function jsonify
def test_jsonify():
    assert "    " in jsonify({'test':{'test':True}}, True)

# Generated at 2022-06-23 05:18:04.260845
# Unit test for function jsonify
def test_jsonify():
    ''' test the jsonify function '''

    # Jsonify a None value
    result = jsonify(None, format=True)
    if result != '{}':
        raise AssertionError('result: %s' % result)

    # Jsonify a single string value
    result = jsonify('foo', format=True)
    if result != '"foo"':
        raise AssertionError('result: %s' % result)

    # Jsonify a dict with one string entry
    result = jsonify({'foo': 'bar'}, format=True)
    if result != '{\n    "foo": "bar"\n}':
        raise AssertionError('result: %s' % result)

    # Jsonify a dict with one integer entry
    result = jsonify({'foo': 1}, format=True)

# Generated at 2022-06-23 05:18:16.360962
# Unit test for function jsonify
def test_jsonify():
    result = dict()
    result['a'] = 1
    result['b'] = 2
    result['c'] = 3
    result['d'] = { 'da': '4', 'db': '5' }
    result['e'] = None
    result['f'] = [ 'fa', 'fb', 'fc' ]
    result['g'] = "7"
    result['h'] = [ ('ha', 'hb'), ('hc', 'hd') ]
    result['i'] = { 'ia': '8', 'ib': [ '9', '10' ] }
    result['j'] = { 'ja': [ 11, 12 ] }
    result['k'] = [ 13, 14, { 'ka': '15', 'kb': [ 16, 17 ] } ]


# Generated at 2022-06-23 05:18:27.283968
# Unit test for function jsonify
def test_jsonify():
    from ansible.parsing.dataloader import DataLoader
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback.default import CallbackModule
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    runner_name = 'jsonify'
    options = ['-c local']
    passwords = {}

    callback = CallbackModule(runner_name)
    callback.set_options(direct=options)

    play_context = PlayContext()
    play_context.network_os = 'ios'
   

# Generated at 2022-06-23 05:18:36.608263
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo', True) == '"foo"'
    assert jsonify({'a':1, 'b':2}, True) == '''{
    "a": 1,
    "b": 2
}'''
    assert jsonify(['a', 'b'], True) == '''[
    "a",
    "b"
]'''
    assert jsonify({'a':1, 'b':None}, True) == '''{
    "a": 1,
    "b": null
}'''

# Generated at 2022-06-23 05:18:43.301630
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=True, rc=0, stdout="Hello World", stderr="")
    json_str = jsonify(result)
    assert json_str == "{\"changed\": true, \"rc\": 0, \"stderr\": \"\", \"stdout\": \"Hello World\"}"
    json_str = jsonify(result, True)
    assert json_str == """{
    "changed": true,
    "rc": 0,
    "stderr": "",
    "stdout": "Hello World"
}"""

# Generated at 2022-06-23 05:18:45.682002
# Unit test for function jsonify
def test_jsonify():
    r = {'a': 'b'}
    assert jsonify(r) == '{"a": "b"}'
    assert jsonify(r, True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 05:18:52.375410
# Unit test for function jsonify
def test_jsonify():
    result = {'test': 'foo'}
    assert jsonify(result) == '{"test": "foo"}'
    assert jsonify(result, format=True) == '{\n    "test": "foo"\n}'
    result = {'test': 'fóo'.decode('utf-8')}
    assert jsonify(result) == '{"test": "f\\u00f3o"}'
    assert jsonify(result, format=True) == '{\n    "test": "f\\u00f3o"\n}'

# Generated at 2022-06-23 05:19:03.381938
# Unit test for function jsonify
def test_jsonify():
    json_data = jsonify({'foo': 'bar'}, True)
    assert json_data == '{\n    "foo": "bar"\n}'

    json_data = jsonify({'foo': 'bar'})
    assert json_data == '{"foo": "bar"}'

    json_data = jsonify({'foo': 'bar'}, True)
    assert json_data == '{\n    "foo": "bar"\n}'

    json_data = jsonify({'foo': 'bar'}, True)
    assert json_data == '{\n    "foo": "bar"\n}'

    json_data = jsonify(None)
    assert json_data == '{}'

# Generated at 2022-06-23 05:19:08.474421
# Unit test for function jsonify
def test_jsonify():
    result_dict = { 'A': 'a', 'B': 'b', 'C': 'c' }
    result_json = jsonify(result_dict, format=True)
    assert result_json == '{' + '\n    ' + '"A": "a",' + '\n    ' + '"B": "b",' + '\n    ' + '"C": "c"' + '\n' + '}'

# Generated at 2022-06-23 05:19:11.784172
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should generate valid JSON output (uncompressed) '''
    print(jsonify({'result': 'OK'}))
    print(jsonify({'result': 'OK'}, format=True))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:19:21.039681
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''
    from ansible.utils import jsonify
    import json

    # test basic dict serialization
    data = {'foo':'bar'}
    assert jsonify(data) == json.dumps(data, sort_keys=True, indent=None, ensure_ascii=False)
    assert jsonify(data, True) == json.dumps(data, sort_keys=True, indent=4, ensure_ascii=False)

    # test unicode serialization
    data = {'baz': u'\u00b6'}
    assert jsonify(data) == json.dumps(data, sort_keys=True, indent=None)

# Generated at 2022-06-23 05:19:27.613301
# Unit test for function jsonify
def test_jsonify():
    ''' test_jsonify module returns formatted JSON strings'''
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}'''
    assert jsonify(None) == "{}"



# Generated at 2022-06-23 05:19:32.858242
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify({"a": 1}) == "{\"a\": 1}"
    assert jsonify({"a": 1}, format=True) == "{\n    \"a\": 1\n}"

# Test with a nested dict

# Generated at 2022-06-23 05:19:42.285617
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict()) == '{}'
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=dict(c=2, d=3))) == '{"a": 1, "b": {"c": 2, "d": 3}}'
    assert jsonify(dict(a=1, b=[dict(c=2, d=3), dict(e=4, f=5)])) == '{"a": 1, "b": [{"c": 2, "d": 3}, {"e": 4, "f": 5}]}'

# Generated at 2022-06-23 05:19:52.185546
# Unit test for function jsonify
def test_jsonify():
    result = { "a": 1,
               "b": 2,
               "c": 3,
               "d": { "a": 1,
                      "b": 2,
                      "c": 3,
                      "d": 4,
                      "e": [1,2,3,4]
                    }
             }
    output = jsonify(result, format=True)
    assert output == '''{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
        "e": [
            1,
            2,
            3,
            4
        ]
    }
}'''
    # Can't get into this block with python 2.6
    #

# Generated at 2022-06-23 05:19:55.379310
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify("None") == "\"None\""

    testDict = {'a': 1, 'b': 2}
    assert jsonify(testDict) == "{\"a\": 1, \"b\": 2}"

# Generated at 2022-06-23 05:20:05.768948
# Unit test for function jsonify
def test_jsonify():
    '''
    Unit test for function jsonify
    '''
    # Test 1. jsonify(None, False) == "{}"
    assert(jsonify(None, False) == "{}")

    # Test 2. jsonify(None, True) == "{}"
    assert(jsonify(None, True) == "{}")

    # Test 3. jsonify(a, False) == json.dumps(a, False)
    a = {'unicode_key': u'\u0123', 'nonunicode_key': 'abc'}
    assert(jsonify(a, False) == json.dumps(a, False))

    # Test 4. jsonify(a, True) == json.dumps(a, True)

# Generated at 2022-06-23 05:20:12.473591
# Unit test for function jsonify
def test_jsonify():
    results = (
        None,
        {"foo":"bar"},
        {"foo":"\u8349", "bar":"baz"},
        {"foo":"\xe8\x8b\x99", "bar":"baz"},
        {"foo":"\u8349", "bar":"baz", "boo":"\xe8\x8b\x99"}
    )
    formats = (False, True)
    for result in results:
        for fmt in formats:
            json_out = jsonify(result, fmt)
            assert isinstance(json_out, basestring)
            json_data = json.loads(json_out)
            assert isinstance(json_data, dict)

# Generated at 2022-06-23 05:20:14.613978
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"foo": "bar"}) == (
        "{\"foo\": \"bar\"}"
    )

# Generated at 2022-06-23 05:20:23.344149
# Unit test for function jsonify
def test_jsonify():
    '''
    function: jsonify
    command: ansible localhost -m jsonify
    expected_result:
        {"invocation": {"module_args": {"foo": "bar"}}}
    '''
    json_result = {
        "invocation": {
            "module_args": {
                "foo": "bar"
            }
        }
    }
    assert jsonify(json_result, format=True) == '''{
    "invocation": {
        "module_args": {
            "foo": "bar"
        }
    }
}'''


# Test 2

# Generated at 2022-06-23 05:20:33.758491
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat import StringIO

    j = jsonify({'hello': 'world'}, format=True)
    assert j == '''{
    "hello": "world"
}'''

    j = jsonify({u'\u1234': u'\u5678'}, format=True)
    assert j == u'''{
    "\u1234": "\u5678"
}'''

    j = jsonify({'hello': u'\u5678'}, format=False)
    assert j == u'{"hello": "\u5678"}'

    j = jsonify({'hello': u'\u5678'})
    assert j == u'{"hello": "\u5678"}'

    # Verify that if we use binary_type for string inputs it works

# Generated at 2022-06-23 05:20:37.064256
# Unit test for function jsonify
def test_jsonify():
    d = { "a":"b" }
    assert jsonify(d, format=True) == "{\"a\": \"b\"}\n"
    assert jsonify(d, format=False) == "{\"a\": \"b\"}"
    return True

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:20:42.975517
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import wrap_var
    result = dict(changed=False, rc=0)
    assert jsonify(result) == '{"changed": false, "rc": 0}'
    result = dict(changed=False, rc=0, results=['test1', wrap_var(u'\u9ec4')])
    assert jsonify(result) == '{"changed": false, "results": ["test1", "\\u9ec4"], "rc": 0}'


# Generated at 2022-06-23 05:20:49.125664
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}, False) == '{"foo":"bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:20:59.275277
# Unit test for function jsonify
def test_jsonify():
    from io import StringIO
    import sys

    # Capture stdout
    stdout = sys.stdout
    output = StringIO()
    sys.stdout = output

    # Test function
    result = {
        "alpha": {
            "num": 1,
            "foo": [1, 2],
            "bar": {
                "spam": "ham"
            }
        },
        "beta": 2
    }
    output1 = jsonify(result)
    output2 = jsonify(result, format=True)

    assert(output1 == '{"alpha": {"bar": {"spam": "ham"}, "foo": [1, 2], "num": 1}, "beta": 2}')


# Generated at 2022-06-23 05:21:04.887132
# Unit test for function jsonify
def test_jsonify():
    result={ "a": 1, "b": "2" }
    assert result == json.loads(jsonify(result, format=True))

    result={ u"a": 1, u"b": u"2" }
    assert result == json.loads(jsonify(result, format=True))

# Generated at 2022-06-23 05:21:07.184988
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":"b"}) == '{"a": "b"}'
    assert jsonify("Hello") == '"Hello"'

# Generated at 2022-06-23 05:21:18.196525
# Unit test for function jsonify
def test_jsonify():
    '''
    Ensure that we return a valid string when a dict is passed as paramater
    and that the string is valid json
    '''