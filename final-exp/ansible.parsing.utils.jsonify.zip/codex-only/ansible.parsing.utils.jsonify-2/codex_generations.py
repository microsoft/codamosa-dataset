

# Generated at 2022-06-23 05:11:16.874464
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(1) == '1'
    assert jsonify('string') == '"string"'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'key': 'value'}) == '{"key": "value"}'
    assert jsonify({'key': 'value'}, format=True) == '{\n    "key": "value"\n}'

# Generated at 2022-06-23 05:11:21.864740
# Unit test for function jsonify
def test_jsonify():
    test_value = {'a': 10, 'b': 'foo', 'c': [1,2,3]}
    json = jsonify(test_value)
    assert json == '''{
    "a": 10,
    "b": "foo",
    "c": [
        1,
        2,
        3
    ]
}'''

# Generated at 2022-06-23 05:11:29.018679
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils import jsonify
    res = dict(changed=False, rc=0, stdout="something", stderr="something else")
    test1 = jsonify(res)
    assert '"rc": 0' in test1
    assert '"stdout": "something"' in test1
    assert '"stderr": "something else"' in test1
    res['touched'] = 'None'
    test2 = jsonify(res)
    assert '"touched": null' in test2

# Generated at 2022-06-23 05:11:38.660453
# Unit test for function jsonify
def test_jsonify():
    # Test the various types that the documentation says should work
    # http://docs.python.org/2/library/json.html#encoders-and-decoders
    import decimal
    import datetime

    jsonify(None) == '{}'
    jsonify(False) == 'false'
    jsonify(True) == 'true'
    jsonify(1) == '1'
    jsonify(1.0) == '1.0'
    jsonify(decimal.Decimal('1.0')) == '1.0'

# Generated at 2022-06-23 05:11:39.413519
# Unit test for function jsonify
def test_jsonify():
    res = None
    assert jsonify(res) == '{}'

# Generated at 2022-06-23 05:11:42.071777
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:11:52.559513
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify() returns valid json
    '''
    import json
    from ansible.utils.jsonify import jsonify

    data = [ dict(one=1, two=2) ]
    json_data = jsonify(data)
    assert type(json_data) == str
    assert json.loads(json_data) == data
    assert json_data == '[{"two": 2, "one": 1}]'

    data = dict(one=1, two=2)
    json_data = jsonify(data)
    assert type(json_data) == str
    assert json.loads(json_data) == data
    assert json_data == '{"two": 2, "one": 1}'

    data = 'string'
    json_data = jsonify(data)
    assert type(json_data) == str

# Generated at 2022-06-23 05:12:04.107794
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify'''
    if PY3:
        assert jsonify([u'a', u'b'], format=False) == '["a","b"]'
        assert jsonify([u'a', u'b'], format=True) == '[\n    "a",\n    "b"\n]'
        assert jsonify(
            {u'a': u'a', u'b': u'b'}, format=False) == '{"a":"a","b":"b"}'
        assert jsonify(
            {u'a': u'a', u'b': u'b'}, format=True) == '{\n    "a": "a",\n    "b": "b"\n}'


# Generated at 2022-06-23 05:12:10.490726
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":"b"}) == '{"a": "b"}'
    assert jsonify({"a":"b"},True) == '{\n    "a": "b"\n}'
    assert jsonify({"a": {"b": "c"}}) == '{"a": {"b": "c"}}'
    assert jsonify({"a": {"b": "c"}},True) == '{\n    "a": {\n        "b": "c"\n    }\n}'

# Generated at 2022-06-23 05:12:14.211590
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"
    assert jsonify({'a':'b'}) == '{"a": "b"}'
    assert jsonify({'a':'b'}, format=True) == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 05:12:22.599368
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert jsonify(None) == "{}"
    assert jsonify({}) == "{}"
    assert jsonify({"k": "v"}) == '{"k": "v"}'
    assert jsonify([1, 2]) == '[1, 2]'

    assert jsonify(AnsibleUnsafeText(b'\xc5\xae\xc5\xa8\xc5\xb6\xc6\x92')) == '"\u0172\u0168\u0176\u01b2"'



# Generated at 2022-06-23 05:12:30.984918
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() '''

    results = {}
    results['test'] = "test"
    results['test2'] = 2 
    results['test3'] = {'test4':4, 'test5':5}
    results['test6'] = ['test7', 7, {'test8':8}]
    results['test9'] = None
    assert jsonify(results) == """{
    "test": "test", 
    "test2": 2, 
    "test3": {
        "test4": 4,
        "test5": 5
    },
    "test6": [
        "test7",
        7,
        {
            "test8": 8
        }
    ],
    "test9": null
}"""



# Generated at 2022-06-23 05:12:35.374999
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({
        "test": "success"
    }, True) == '{\n    "test": "success"\n}'
    assert jsonify({
        "test": "success"
    }, False) == '{"test": "success"}'
    assert sorted(jsonify({
        "test": "success"
    }).split(' ')) == sorted('{"test": "success"}'.split(' '))
    assert sorted(jsonify({
        "test": "success"
    }, True).split(' ')) == sorted('{\n    "test": "success"\n}'.split(' '))

# Generated at 2022-06-23 05:12:40.159965
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None)         == "{}"
    assert jsonify({})           == "{}"
    assert jsonify({'a': 'b'})   == '{"a": "b"}'
    assert jsonify([1,2,3])      == "[1, 2, 3]"

# Generated at 2022-06-23 05:12:47.568409
# Unit test for function jsonify
def test_jsonify():
    testlist = { 'foo' : 'bar', 'baz' : 'quux' }
    assert jsonify(testlist) == '{"baz": "quux", "foo": "bar"}'
    assert jsonify(jsonify(testlist)) == '"{\\"baz\\": \\"quux\\", \\"foo\\": \\"bar\\"}"'

# Need to test that this works when encoding is used
#assert jsonify(testlist,True) == '''{
#    "baz": "quux",
#    "foo": "bar"
#}'''

# Generated at 2022-06-23 05:12:54.729191
# Unit test for function jsonify
def test_jsonify():
    result = { 'a': 1, 'b': 2, 'c': { 'd': 'abc' }, 'e': [1,2,3] }
    assert jsonify(result, True) == '''{
    "a": 1,
    "b": 2,
    "c": {
        "d": "abc"
    },
    "e": [
        1,
        2,
        3
    ]
}'''
    assert jsonify(result, False) == '{"a": 1, "b": 2, "c": {"d": "abc"}, "e": [1, 2, 3]}'

# Generated at 2022-06-23 05:13:06.119297
# Unit test for function jsonify
def test_jsonify():
    def _test(value, expected):
        result = jsonify(value)
        assert result == expected, "expected '%s'=%s, got %s" % (value, expected, result)

    _test(None, "{}")
    _test(123, "123")
    _test("foo", "\"foo\"")
    _test([1,2,3], "[1, 2, 3]")
    _test({"a": "foo", "b": "bar"}, '{"a": "foo", "b": "bar"}')
    _test({"y": 123, "x": 456}, '{"x": 456, "y": 123}')

# Generated at 2022-06-23 05:13:09.838818
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}
    assert jsonify(result) == '{"foo": "bar"}'
    assert jsonify(result, True) == '{\n    "foo": "bar"\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:13:14.369069
# Unit test for function jsonify
def test_jsonify():
    test_data = True
    assert jsonify(test_data) == "true"
    test_data = False
    assert jsonify(test_data) == "false"
    test_data = None
    assert jsonify(test_data) == "{}"
    test_data = {"name": "value", "name1": "value1"}
    assert jsonify(test_data) == json.dumps(test_data)

# Generated at 2022-06-23 05:13:22.853285
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unicode import to_bytes
    from ansible.utils.unicode import to_str
    from collections import Mapping
    from collections import Sequence

    # Strings should be encoded
    assert to_unicode(jsonify(to_bytes("foo"))) == u'{}'
    assert to_unicode(jsonify(to_bytes("foo"), True)) == u"{}"

    # Decoded strings should pass through
    assert to_unicode(jsonify(to_unicode("foo"))) == u'{}'
    assert to_unicode(jsonify(to_unicode("foo"), True)) == u"{}"

    # Non-string, non-collection values should be converted to strings
    assert to_unicode(jsonify(1))

# Generated at 2022-06-23 05:13:31.724477
# Unit test for function jsonify
def test_jsonify():
    test_obj = {}
    result = jsonify(test_obj)
    assert type(result) == str
    test_obj = {1:"foo"}
    result = jsonify(test_obj)
    assert type(result) == str
    test_obj = {1:"foo", 2:"bar"}
    result = jsonify(test_obj)
    assert type(result) == str
    test_obj = "foo"
    result = jsonify(test_obj)
    assert type(result) == str
    test_obj = None
    result = jsonify(test_obj)
    assert type(result) == str

# Generated at 2022-06-23 05:13:35.561976
# Unit test for function jsonify
def test_jsonify():
    ''' function jsonify returns correct json string '''

    result = { 'name': 'Alice', 'age': 18 }
    assert jsonify(result) == '{"age": 18, "name": "Alice"}'


# Generated at 2022-06-23 05:13:42.618796
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert jsonify(dict(foo=1)) == '{"foo": 1}'
    assert jsonify(dict(foo="bar")) == '{"foo": "bar"}'
    assert jsonify(dict(foo=AnsibleUnsafeText("bar"))) == '{"foo": "bar"}'

# Generated at 2022-06-23 05:13:49.502858
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo=dict(one=True), bar=1, baz=0)) == '{"bar": 1, "baz": 0, "foo": {"one": true}}'
    assert jsonify(dict(foo=dict(one=True), bar=1, baz=0), format=True) == '''{
    "bar": 1,
    "baz": 0,
    "foo": {
        "one": true
    }
}'''

# Generated at 2022-06-23 05:13:50.347952
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'

# Generated at 2022-06-23 05:13:54.730399
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify('foo') == '"foo"'
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': [1,2,3]}) == '{"a": [1, 2, 3]}'

# Generated at 2022-06-23 05:14:04.549346
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    result = dict(
        ansible_facts=dict(
            foo=u'bar',
            baz=u'baz',
            k=dict(
                k1=u'v1',
                k2=u'v2',
                k3=AnsibleUnsafeText('v3'),
            )
        ),
        stdout=u'foobar'
    )

    ret = jsonify(result, format=True)

# Generated at 2022-06-23 05:14:15.313487
# Unit test for function jsonify
def test_jsonify():
    # Check for indent none when format not set
    assert jsonify(None, False) == "{}"
    assert jsonify({}, False) == "{}"
    assert jsonify({'name': 'Test'}, False) == "{\"name\": \"Test\"}"
    assert jsonify({'name': 'Test', 'value': 1}, False) == "{\"name\": \"Test\", \"value\": 1}"
    # Check for indent when format set
    assert jsonify(None, True) == "{}"
    assert jsonify({'name': 'Test'}, True) == '{\n    "name": "Test"\n}'
    assert jsonify({'name': 'Test', 'value': 1}, True) == '{\n    "name": "Test", \n    "value": 1\n}'
    # Check for unicode

# Generated at 2022-06-23 05:14:18.255120
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([u"¡unicode!", "!unicode!"]) == '[\n    "\\u00a1unicode!", \n    "!unicode!"\n]'

# Generated at 2022-06-23 05:14:29.932832
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify()
    '''

    # jsonify none
    assert "{}" == jsonify(None)

    # jsonify string
    assert '"foo"' == jsonify("foo")

    # jsonify byte string
    # import six
    # assert '"foo"' == jsonify(six.b("foo"))

    # jsonify int
    assert "4" == jsonify(4)

    # jsonify double
    assert "4.2" == jsonify(4.2)

    # jsonify boolean
    assert "true" == jsonify(True)
    assert "false" == jsonify(False)

    # jsonify list
    assert '["a", "b", "c"]' == jsonify(["a", "b", "c"])

    # jsonify dict

# Generated at 2022-06-23 05:14:31.860487
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a':1}) == '{"a": 1}'

# Generated at 2022-06-23 05:14:42.044177
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.jsonify import jsonify, test_jsonify
    import sys

    if sys.version_info < (2, 6):
        test_jsonify.skip("Cannot run test if version is < 2.6 because of lack of json lib")

    if not jsonify(None, False) == "{}":
        test_jsonify.fail("jsonify did not return {}")

    if not jsonify(None, True) == "{}":
        test_jsonify.fail("jsonify did not return {}")

    data_dict = jsonify({'foo':'bar', 'ping':'pong'}, False)

# Generated at 2022-06-23 05:14:43.441833
# Unit test for function jsonify
def test_jsonify():
    output = jsonify({'foo': 'bar'})
    assert output == '{"foo": "bar"}'

# Generated at 2022-06-23 05:14:50.495893
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify should format JSON output (uncompressed or uncompressed)
    '''
    assert jsonify(None) == "{}"
    assert jsonify("sample text") == "\"sample text\""
    assert jsonify([1, 2, 3]) == "[1, 2, 3]"
    assert jsonify({"a": "b"}) == "{\"a\": \"b\"}"
    assert jsonify({"c": "d"}, format=True) == "{\n    \"c\": \"d\"\n}"

# Generated at 2022-06-23 05:14:58.627288
# Unit test for function jsonify
def test_jsonify():
    from units.mock.loader import DictDataLoader

    mock_loader = DictDataLoader({
        "/etc/ansible/hosts": """
[webservers]
foo.example.com
        """,
    })

    # test empty
    result = jsonify(None)
    assert result == "{}"

    # test valid data
    data = dict(changed=False, host='foo.example.com', msg='', rc=0)
    result = jsonify(data)
    assert result == '{"changed": false, "host": "foo.example.com", "msg": "", "rc": 0}'

    # test invalid host
    data = dict(changed=False, host='172.16.0.0', msg='', rc=0)
    result = jsonify(data)

# Generated at 2022-06-23 05:15:05.393105
# Unit test for function jsonify
def test_jsonify():
    ''' function jsonify: unit tests '''

    assert jsonify(None) == "{}"
    assert jsonify(dict(a=1)) == ('{\n    "a": 1\n}')
    assert jsonify(dict(a=1), True) == ('{\n    "a": 1\n}')
    assert jsonify(dict(a=1), False) == ('{"a": 1}')
    assert jsonify(dict(a=1), None) == ('{"a": 1}')

    # Ensure that unicode strings are converted to utf8
    # NOTE: this test will fail unless a unicode_string
    # is sent in that contains the special character '\xb4'.
    # The string used in the test below will work on most
    # Linux machines.
    unicode_string = '\xc2\xb4'


# Generated at 2022-06-23 05:15:16.900562
# Unit test for function jsonify
def test_jsonify():

    # test a data structure
    b_orig = dict(changed=True, rc=0, results=[u'\u2019'])
    b = dict(changed=True, rc=0, results=[u'\u2019'])

    assert jsonify(b) == jsonify(b_orig)
    assert jsonify(b, True) == jsonify(b_orig, True)
    assert jsonify(b) == jsonify(b_orig)
    assert jsonify(b, True) == jsonify(b_orig, True)

    # test a single string
    a_orig = """{ changed: false, rc: 255, results: [ "Hello World" ] }"""
    a = jsonify(a_orig)

    assert a == a_orig

    # test a list of strings

# Generated at 2022-06-23 05:15:26.090525
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    test_list = dict(
        foo=1,
        bar=dict(
            baz=2,
        ),
    )
    test_list_formatted = '{\n    "bar": {\n        "baz": 2\n    }, \n    "foo": 1\n}'

    results = dict(
        test_list_2=test_list,
        test_list_formatted_2=test_list,
    )

# Generated at 2022-06-23 05:15:29.544414
# Unit test for function jsonify
def test_jsonify():
    if jsonify(dict(foo='bar')) != '{"foo": "bar"}':
        print("jsonify fails 1")
    if jsonify(dict(foo='bar'), True) != "{\n    \"foo\": \"bar\"\n}":
        print("jsonify fails 2")

# Generated at 2022-06-23 05:15:33.844201
# Unit test for function jsonify
def test_jsonify():
    res = jsonify({'foo': 'bar'})
    assert res == "{}"

    res = jsonify({'foo': 'bar'}, format=True)
    assert res == "{\n    \"foo\": \"bar\"\n}"


# Generated at 2022-06-23 05:15:37.120128
# Unit test for function jsonify
def test_jsonify():
    result = {'foo': 'bar'}
    assert jsonify(result) == '{"foo": "bar"}'

# Generated at 2022-06-23 05:15:42.888270
# Unit test for function jsonify
def test_jsonify():
    ''' Test that jsonify() works as expected '''
    data = [
        ({"a": 1}, "{\"a\": 1}"),
        ({"a": 1, "b": 2}, "{\"a\": 1, \"b\": 2}"),
    ]
    for (arg, expected) in data:
        assert jsonify(arg) == expected

# Generated at 2022-06-23 05:15:46.581634
# Unit test for function jsonify
def test_jsonify():
    ''' Unit test for function ansible.utils.jsonify '''

    assert jsonify({}) == '{}'
    assert jsonify({'a':'b'}) == '{\n    "a": "b"\n}'

# Generated at 2022-06-23 05:15:51.270210
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo':'bar'}) == '{"foo": "bar"}'

# allow jsonify to be called as a module
if __name__ == '__main__':
    print(jsonify({'foo': 'bar'}))

# Generated at 2022-06-23 05:16:01.249223
# Unit test for function jsonify
def test_jsonify():
    # Default
    data = {'foo': 'bar'}
    assert jsonify(data) == '{"foo": "bar"}'

    data = {'foo': 'bar', 'baz': 1234}
    assert jsonify(data) == '{"baz": 1234, "foo": "bar"}'

    # Format
    data = {'foo': 'bar'}
    assert jsonify(data, format=True) == '{\n    "foo": "bar"\n}'

    data = {'foo': 'bar', 'baz': 1234}
    assert jsonify(data, format=True) == '{\n    "baz": 1234, \n    "foo": "bar"\n}'

# Test Runner

# Generated at 2022-06-23 05:16:09.174715
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify('{"foo": "bar"}') == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'
    assert jsonify({"foo": 1}) == '{\n    "foo": 1\n}'
    assert jsonify({"foo": ["bar", "baz"]}) == '{\n    "foo": [\n        "bar", \n        "baz"\n    ]\n}'

# Generated at 2022-06-23 05:16:12.890988
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

    data = {'foo' : 'bar', 'baz' : 'qux'}
    assert jsonify(data) == '{"baz": "qux", "foo": "bar"}'
    assert jsonify(data, True) == '{\n    "baz": "qux",\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:16:16.209551
# Unit test for function jsonify
def test_jsonify():
    result = {'some': 'data'}
    assert jsonify(result, format=False) == json.dumps(result)

# Generated at 2022-06-23 05:16:19.752114
# Unit test for function jsonify
def test_jsonify():
    data = jsonify({'foo':'bar', 'xyz':'pdq'}, True)
    assert data == '''{
    "foo": "bar",
    "xyz": "pdq"
}'''

# Generated at 2022-06-23 05:16:29.595204
# Unit test for function jsonify
def test_jsonify():
    mydict = {
        'changed': True,
        'rc': 0,
        'results': [
            'foo',
            'bar',
            {
                'baz': 3
            }
        ]
    }
    j1 = jsonify(mydict, format=True)
    j2 = jsonify(mydict, format=False)
    assert j1 == '''{
    "changed": true, 
    "rc": 0, 
    "results": [
        "foo", 
        "bar", 
        {
            "baz": 3
        }
    ]
}'''
    assert j2 == '{"changed": true, "rc": 0, "results": ["foo", "bar", {"baz": 3}]}'

# Generated at 2022-06-23 05:16:37.159925
# Unit test for function jsonify
def test_jsonify():
    ''' test format_json function '''

    results = jsonify(dict(a=1,b=2,c=3))

    assert results == '{"a": 1, "b": 2, "c": 3}'

    results = jsonify(dict(a=1,b=2,c=3), format=True)

    assert results == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-23 05:16:39.954680
# Unit test for function jsonify
def test_jsonify():
    data = {'k1': 'foo', 'k2': 'bar'}
    data_str= '{"k1": "foo", "k2": "bar"}'
    assert jsonify(data) == data_str

# Generated at 2022-06-23 05:16:44.439817
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, True) == '{\n    "a": "b"\n}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:16:50.567901
# Unit test for function jsonify
def test_jsonify():
    result = {'blah': {'a': 'b', 'c': 'd'}}
    assert jsonify(result) == '{"blah": {"a": "b", "c": "d"}}'
    assert jsonify(result, format=True) == '{\n    "blah": {\n        "a": "b", \n        "c": "d"\n    }\n}'

# Generated at 2022-06-23 05:16:57.356481
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None, False) == '{}'
    assert jsonify(None, True) == '{}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}, True) == '{\n    "a": 1, \n    "b": 2, \n    "c": 3\n}'

# Generated at 2022-06-23 05:17:04.180066
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):

        result = dict(changed=True, rc=0, stdout="pong", start='2014-07-10 12:14:55.569145', end='2014-07-10 12:14:55.583731', delta='0:00:00.014586', cmd="ping")


# Generated at 2022-06-23 05:17:15.387594
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return valid json '''

    dict_list = [ {'a': 1}, {'b': 2} ]
    json_dict_list = "[{\"a\": 1}, {\"b\": 2}]"

    # Test a dict
    result = jsonify({'a': 1})
    if result != "{\"a\": 1}":
        raise AssertionError()

    # Test a list
    result = jsonify(['a', 1])
    if result != "[\"a\", 1]":
        raise AssertionError()

    # Test a string
    result = jsonify('a')
    if result != "\"a\"":
        raise AssertionError()

    # Test a list of dicts
    result = jsonify(dict_list)
    if result != json_dict_list:
        raise Assertion

# Generated at 2022-06-23 05:17:23.247221
# Unit test for function jsonify
def test_jsonify():
    result = dict(failed=False, changed=False, rc=0)
    run_output = jsonify(result, format=False)
    assert run_output == "{}"
    run_output = jsonify(result, format=True)
    assert run_output == "{\n    \"changed\": false, \n    \"failed\": false, \n    \"rc\": 0\n}"
    result = dict(failed=True, module_stderr="boom", module_stdout="", rc=1)
    run_output = jsonify(result, format=False)
    assert run_output == "{\"failed\": true, \"rc\": 1, \"module_stderr\": \"boom\", \"module_stdout\": \"\"}"
    run_output = jsonify(result, format=True)

# Generated at 2022-06-23 05:17:28.265758
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(True) == 'true'
    assert jsonify({'name':'ansible','age':5}) == '{"age": 5, "name": "ansible"}'

if __name__ == '__main__':
    import pytest

    pytest.main(['./test_utils_json.py'])

# Generated at 2022-06-23 05:17:33.205100
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'test': 'some data'}) == '{"test": "some data"}'
    assert jsonify({'test': {'test': 'some data'}}) == '{"test": {"test": "some data"}}'
    assert jsonify({'test': {'test': {'test': 'some data'}}}) == '{"test": {"test": {"test": "some data"}}}'


# Generated at 2022-06-23 05:17:37.584521
# Unit test for function jsonify
def test_jsonify():
    result = {'test': { 'test1': 'test2' } }
    assert jsonify(result) == '{"test": {"test1": "test2"}}'


# TODO: move this to proper unit test
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:17:49.012652
# Unit test for function jsonify
def test_jsonify():
    # AnsibleModule test
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch, Mock

    test_dict = {'test': 'dict'}
    test_list = ['test', 'list']

    module = Mock(spec=AnsibleModule)
    module.params = {}

    with patch.object(AnsibleModule, 'fail_json') as fail_json:
        # test None result
        result = jsonify(result=None, format=False)
        assert result == '{}'

        # test object result
        result = jsonify(result=test_dict, format=False)
        assert result == '{"test": "dict"}'

        # test formatted object result
        result = jsonify(result=test_dict, format=True)

# Generated at 2022-06-23 05:17:52.861956
# Unit test for function jsonify
def test_jsonify():

    # Test a None result
    result = jsonify(None)
    assert result == "{}"

    # Test a simple dictionary result
    result = jsonify({'hello': 'world'})
    assert result == '{"hello": "world"}'

# Generated at 2022-06-23 05:17:57.461736
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None)
    assert "[1, 2, 3]" == jsonify([1,2,3])
    assert "\"a\"" == jsonify('a')
    assert "\"[1, 2, 3]\"" == jsonify([1,2,3], True)

# Generated at 2022-06-23 05:18:04.387378
# Unit test for function jsonify
def test_jsonify():

    good_json = '{"a": 1, "b": 2}'
    good_json_formatted = '{\n    "a": 1,\n    "b": 2\n}'

    assert good_json == jsonify(dict(a=1, b=2))
    assert good_json == jsonify(dict(a=1, b=2), False)
    assert good_json_formatted == jsonify(dict(a=1, b=2), True)


# Generated at 2022-06-23 05:18:15.029212
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.module_utils.common

    strings = [
        "test",
        u"test",
        AnsibleUnsafeText("test"),
        ansible.module_utils.common.AnsibleModule,
        {
            'test': [u"test"],
            'test2': "test2",
            'test3': AnsibleUnsafeText("test3"),
            'test4': ansible.module_utils.common.AnsibleModule,
        }
    ]
    for x in strings:
        res = jsonify(x, format=False)
        res = jsonify(x, format=True)

# Generated at 2022-06-23 05:18:24.504704
# Unit test for function jsonify
def test_jsonify():
    ''' test for function jsonify '''
    assert jsonify({}) == "{}"
    assert jsonify(None) == "{}"

    assert (
        jsonify({
            "changed": False,
            "ping": "pong",
            "invocation": {
                "module_args": {}
            },
            "invocation": {
                "module_name": "/usr/bin/echo",
                "module_args": {}
            }
        }) == '{"changed": false, "invocation": {"module_args": {}, "module_name": "/usr/bin/echo"}, "ping": "pong"}'
    )

# Generated at 2022-06-23 05:18:26.905677
# Unit test for function jsonify
def test_jsonify():
    assert '{\n    "failed": false, \n    "changed": false\n}' == jsonify({'changed':False, 'failed':False}, True)

# Generated at 2022-06-23 05:18:28.675348
# Unit test for function jsonify
def test_jsonify():
    assert('invalid' in jsonify('invalid'))
    assert(jsonify([1,2,3]) == '[1, 2, 3]')

# Generated at 2022-06-23 05:18:39.401038
# Unit test for function jsonify
def test_jsonify():
    # Passes
    assert jsonify({}) == "{}"
    assert jsonify({'a': 'b'}) == '{\"a\": \"b\"}'
    assert jsonify({'tests': [1,2,3]}) == '{\"tests\": [1, 2, 3]}'
    assert jsonify({'tests': [1,2,3]}, format=True) == '{\n    \"tests\": [\n        1, \n        2, \n        3\n    ]\n}'

    # Fails
    assert jsonify({'a': 'b'}) == '{a: b}'
    assert jsonify({'tests': [1,2,3]}, format=True) == '{tests: [1, 2, 3]}'

# Generated at 2022-06-23 05:18:48.382838
# Unit test for function jsonify
def test_jsonify():
    result1 = dict(changed=True, failed=False)
    result2 = dict(foo='bar', yes=True, nope=False)

    assert jsonify(result1) == '{"changed": true, "failed": false}'
    assert jsonify(result1, format=True) == '{\n    "changed": true, \n    "failed": false\n}'
    assert jsonify(result2) == '{"foo": "bar", "nope": false, "yes": true}'
    assert jsonify(result2, format=True) == '{\n    "foo": "bar", \n    "nope": false, \n    "yes": true\n}'

# Generated at 2022-06-23 05:18:58.282802
# Unit test for function jsonify
def test_jsonify():
    data = {
        'id': '1',
        'data': {
            'item_a': 'test',
            'item_b': 1234,
            'item_c': None,
            'item_d': {
                'subitem_a': 'subitem',
                'subitem_b': 4321,
            }
        }
    }

    assert jsonify(data) == '{"data": {"item_b": 1234, "item_c": null, "item_d": {"subitem_a": "subitem", "subitem_b": 4321}, "item_a": "test"}, "id": "1"}'

# Generated at 2022-06-23 05:19:04.302738
# Unit test for function jsonify
def test_jsonify():
    jsonify_test(dict(a='123', b=dict(c=dict(d='123'))), True)
    jsonify_test(dict(a='123', b=dict(c=dict(d='123'))), False)
    jsonify_test(None, False)
    jsonify_test(dict(a='123', b=dict(c=dict(d='123'))), True)



# Generated at 2022-06-23 05:19:15.451542
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return json string or "{}" if no input '''
    examples = [
        {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5},
        {'a': 3.2, 'b': 'foo'},
        {'some_list': [1, 2, 3, 5, 7, 11, 13], 'some_string': 'hello'},
        {},
        None,
    ]

# Generated at 2022-06-23 05:19:17.673357
# Unit test for function jsonify
def test_jsonify():
    from ansible.playbook.play_context import PlayContext

    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}, True) == '{\n    "a": "b"\n}'



# Generated at 2022-06-23 05:19:20.318021
# Unit test for function jsonify
def test_jsonify():

    # place to write tests - disabled as they are not run as part of unit tests
    x = 0
    #assert(x != 1)

# Generated at 2022-06-23 05:19:30.792611
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": [(1,2),(3,4)]}) == '{"a": [[1, 2], [3, 4]]}'
    assert jsonify(["a", 1]) == '["a", 1]'
    assert jsonify(["a", [(1,2),(3,4)]]) == '["a", [[1, 2], [3, 4]]]'
    assert jsonify(["a", (1, {"b": ["foo", {"c": "bar"}]})]) == jsonify(["a", [1, {"b": ["foo", {"c": "bar"}]}]])


# ---- AnsibleModule support ----


# Generated at 2022-06-23 05:19:35.027101
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None, False)
    assert "{}" == jsonify(None, True)
    assert '{"a": "b"}' == jsonify({"a":"b"}, False)
    assert '{\n    "a": "b"\n}' == jsonify({"a":"b"}, True)

# Generated at 2022-06-23 05:19:40.261528
# Unit test for function jsonify
def test_jsonify():
    result = dict(foo='bar', baz=2)
    assert jsonify(result) == '{"baz": 2, "foo": "bar"}'
    assert jsonify(result, True) == '{\n    "baz": 2, \n    "foo": "bar"\n}'
    assert jsonify(None) == '{}'
    assert jsonify(None, True) == '{}'

# Generated at 2022-06-23 05:19:44.621720
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'

if __name__ == "__main__":

    from ansible import __version__

    result = dict(version=__version__, changed=True)
    print(jsonify(result))
    print(jsonify(result, format=True))

# Generated at 2022-06-23 05:19:55.230196
# Unit test for function jsonify
def test_jsonify():
    test = {
        "failed": True,
        "changed": True,
        "failed_hosts": { "foo": True },
        "stats": {
            "hosts": { "bar": True },
            "ok": True
        }
    }
    # result is a string, but this is done to simplify testing
    result = eval(jsonify(test))
    assert result == {
        "failed": True,
        "changed": True,
        "failed_hosts": { "foo": True },
        "stats": {
            "hosts": { "bar": True },
            "ok": True
        }
    }


# Generated at 2022-06-23 05:20:03.296989
# Unit test for function jsonify
def test_jsonify():
    res = {'a': True, 'b': [1, 2, 3], 'c': False, 'd': 4}
    assert jsonify(res, format=False) == '{"a": true, "b": [1, 2, 3], "c": false, "d": 4}'
    assert jsonify(res, format=True) == '{\n    "a": true, \n    "b": [\n        1, \n        2, \n        3\n    ], \n    "c": false, \n    "d": 4\n}'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:20:11.892285
# Unit test for function jsonify
def test_jsonify():
    # Tests with 'format=True' (indent=4)
    result = { 'a': [1,2,3], 'b': [4,5,6], 'c': [7,8,9] }
    expected1 = """{
    "a": [
        1,
        2,
        3
    ],
    "b": [
        4,
        5,
        6
    ],
    "c": [
        7,
        8,
        9
    ]
}"""
    output1 = jsonify(result, format=True)
    assert output1 == expected1
    result = { 'a': { 'b': [1, 2, 3], 'c': [4, 5, 6], 'd': [7, 8, 9]}}

# Generated at 2022-06-23 05:20:15.746903
# Unit test for function jsonify
def test_jsonify():
    result = {
        'abc': 123,
        'def': 456
     }
    assert type(result) == dict
    assert type(jsonify(result)) == str
    assert type(jsonify(result, True)) == str

# Generated at 2022-06-23 05:20:26.839072
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None)                                           == "{}"
    assert jsonify({'a': 'b'})                                     == "{\"a\": \"b\"}"
    assert jsonify({'a': 'b'}, True)                               == "{\n    \"a\": \"b\"\n}"
    assert jsonify({'a': {u'\u2665': 'b'}}, True)                  == "{\n    \"a\": {\n        \"\xe2\x99\xa5\": \"b\"\n    }\n}"
    assert jsonify({'a': {u'\u2665': 'b'}}, False)                 == "{\"a\": {\"\xe2\x99\xa5\": \"b\"}}"

# Generated at 2022-06-23 05:20:35.288144
# Unit test for function jsonify
def test_jsonify():
    # Test jsonify()
    print("Testing function jsonify")

    r = jsonify({})
    print("jsonify({}) = %s" % r)
    assert r == "{}"

    r = jsonify({"a":1, "b":2})
    print("jsonify({'a':1, 'b':2}) = %s" % r)
    assert r == '{"a": 1, "b": 2}'

    r = jsonify({"a":1, "b":2}, True)
    print("jsonify({'a':1, 'b':2}, True) = %s" % r)
    assert r == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-23 05:20:45.140111
# Unit test for function jsonify
def test_jsonify():
    # Test encoding of valid ASCII data
    assert jsonify({'a': 'b'}) == '{"a": "b"}'

    # Test encoding of valid Unicode data
    assert jsonify({'a': '\r\n'}) == '{"a": "\\r\\n"}'

    # Test encoding of invalid ASCII data
    assert jsonify({'a': chr(128)}) == '{"a": "\\u0080"}'

    # Test encoding of invalid Unicode data
    assert jsonify({'a': chr(0xffff)}) == '{"a": "\\uffff"}'

    # Test encoding of datatypes
    assert jsonify({'a': None}) == '{"a": null}'
    assert jsonify({'a': True}) == '{"a": true}'

# Generated at 2022-06-23 05:20:53.566597
# Unit test for function jsonify
def test_jsonify():
    import ansible.utils.jsonify as j
    assert j.jsonify('foo') == '"foo"'
    assert j.jsonify(42) == '42'

# Generated at 2022-06-23 05:21:02.496348
# Unit test for function jsonify
def test_jsonify():

    assert(jsonify({'hello': 'world'}) == '{"hello": "world"}')

    # Make sure jsonify can handle non-ascii chars.
    assert(jsonify({'hello': '\xe4\xbd\xa0\xe5\xa5\xbd'}) == '{"hello": "\\u4f60\\u597d"}')
    assert(jsonify({'hello': '\xe4\xbd\xa0\xe5\xa5\xbd'}, True) == '''{
    "hello": "\\u4f60\\u597d"
}''')

    # When unicode chars are in the output, the output will be encoded to utf-8.

# Generated at 2022-06-23 05:21:07.863263
# Unit test for function jsonify
def test_jsonify():
    result = { 'foo': ['bar', None, 42] }
    assert jsonify(result) == '{\n    "foo": [\n        "bar", \n        null, \n        42\n    ]\n}'
    assert jsonify(result, format=True) == '{\n    "foo": [\n        "bar", \n        null, \n        42\n    ]\n}'

# Generated at 2022-06-23 05:21:17.047802
# Unit test for function jsonify
def test_jsonify():
    test_result_none = jsonify(None)
    test_result_empty = jsonify({})
    test_result_data = jsonify({'foo': 'bar', 'age': 8})
    test_result_data_formatted = jsonify({'foo': 'bar', 'age': 8}, format=True)
    assert test_result_none == "{}"
    assert test_result_empty == "{}"
    assert test_result_data == '{"age": 8, "foo": "bar"}'
    assert test_result_data_formatted == '{\n    "age": 8, \n    "foo": "bar"\n}'