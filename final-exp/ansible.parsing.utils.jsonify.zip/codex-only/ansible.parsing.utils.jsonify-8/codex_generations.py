

# Generated at 2022-06-23 05:11:16.287560
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, True) == '''\
{
    "foo": "bar"
}\
'''

# Generated at 2022-06-23 05:11:24.022371
# Unit test for function jsonify
def test_jsonify():

    # Test simple values
    assert jsonify(True, True) == 'true'
    assert jsonify(False, True) == 'false'
    assert jsonify(None, True) == '{}'

    # Test basic arrays and objects
    assert jsonify([1, 2, 3, 4], True) == '''[
    1, 
    2, 
    3, 
    4
]'''
    assert jsonify({'a': 1, 'b': 'test'}, True) == '''{
    "a": 1, 
    "b": "test"
}'''

# Generated at 2022-06-23 05:11:27.735307
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'test': 'foo'}) == '{"test": "foo"}'
    assert jsonify({'test': 'foo'}, True) == '{\n    "test": "foo"\n}'

# Generated at 2022-06-23 05:11:37.562108
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    from ansible.utils.jsonify import AnsibleJSONEncoder

    # Check if jsonify output is valid json
    import json
    assert json.loads(jsonify({"a": "b"})) == {"a": "b"}

    # Check if jsonify converts None to {}
    assert jsonify(None) == "{}"

    # Check if jsonify converts ints to values
    assert jsonify(1) == "1"

    # Check if jsonify converts floats to values
    assert jsonify(1.2) == "1.2"

    # Check if jsonify converts bool to values
    assert jsonify(True) == "true"

    # Check if jsonify converts ints to values
    assert jsonify("string") == "\"string\""

    # Check if jsonify converts

# Generated at 2022-06-23 05:11:48.348995
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unicode import to_unicode
    assert "{}" == jsonify(None)
    assert jsonify("foo") == jsonify("foo")
    assert jsonify("foo") == to_unicode(jsonify("foo"))
    assert jsonify("foo") == jsonify("foo", format=False)
    assert jsonify("foo") == jsonify("foo", format=True)

    # Test with unicode string:
    # 'café' is a 4-bytes UTF-8 string, that is encoded in Unicode as the codepoint U+00E9 ('é' = LATIN SMALL LETTER E WITH ACUTE)
    café = to_unicode('café')
    assert jsonify(café) == jsonify(café)

# Generated at 2022-06-23 05:11:53.062365
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({"a": 1, "b": "foo"}) == '{"a": 1, "b": "foo"}'
    assert jsonify(["a", 1]) == '["a", 1]'
    assert jsonify(["a", 1], format=True) == '[\n    "a", \n    1\n]'


# Generated at 2022-06-23 05:12:00.115196
# Unit test for function jsonify
def test_jsonify():
    test1 = dict(spam="eggs", foo="bar")

    # Function should return proper JSON
    assert jsonify(test1) == '{"spam": "eggs", "foo": "bar"}'
    assert jsonify(test1, format=True) == '{\n    "foo": "bar", \n    "spam": "eggs"\n}'

    # Should handle None gracefully
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:12:09.076511
# Unit test for function jsonify
def test_jsonify():
    ''' test jsonify() '''

    from ansible.utils.unicode import to_unicode
    from ansible.utils import randomstrings

    # Test empty result
    result = jsonify(None)
    assert result == "{}"

    # Test basic result
    result = jsonify(dict(spam="eggs"))
    assert result == '{"spam": "eggs"}'

    # Test result with list
    result = jsonify(dict(foo=["bar", "baz"]))
    assert result == '{"foo": ["bar", "baz"]}'

    # Test result with unicode
    result = jsonify(dict(foo=to_unicode(randomstrings.to_ascii(128))))
    assert result == '{"foo": "%s"}' % randomstrings.to_ascii(128)

# Generated at 2022-06-23 05:12:13.963841
# Unit test for function jsonify
def test_jsonify():
    test_result = {
        'a': 1,
        'd': {
            'x': "message",
            'y': None
        },
        'e': [1, 2, 'a', 'b', {'test': 'test'}, None],
        'f': True,
        'g': False,
        'h': None
    }

    test_result_formatted = '''{
    "a": 1,
    "d": {
        "x": "message",
        "y": null
    },
    "e": [
        1,
        2,
        "a",
        "b",
        {
            "test": "test"
        },
        null
    ],
    "f": true,
    "g": false,
    "h": null
}'''

    assert json

# Generated at 2022-06-23 05:12:25.387499
# Unit test for function jsonify
def test_jsonify():
    result_none = None
    result_empty_dict = {}
    result_nonunicode_dict = { 'key': 'value' }
    result_unicode_dict = { 'key': u'value'}

    if jsonify(result_none) != "{}":
        raise AssertionError("jsonify(None) returned incorrect result")

    if jsonify(result_empty_dict) != '{}':
        raise AssertionError("jsonify({}) returned incorrect result")

    if jsonify(result_nonunicode_dict) != '{"key": "value"}':
        raise AssertionError("jsonify({'key': 'value'}) returned incorrect result")


# Generated at 2022-06-23 05:12:28.622660
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': 'bar', 'baz': 'qux'}
    correct = '{"baz": "qux", "foo": "bar"}'
    test = jsonify(data)
    assert test == correct, "jsonify() did not JSONify correctly"

# Generated at 2022-06-23 05:12:30.384834
# Unit test for function jsonify
def test_jsonify():
    data = {u'key': u'value'}
    assert jsonify(data) == '{"key": "value"}'

# Generated at 2022-06-23 05:12:33.325704
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(changed=True, rc=0)) == '{ "changed": true, "rc": 0 }'

# Test the in jsonify

# Generated at 2022-06-23 05:12:45.216749
# Unit test for function jsonify
def test_jsonify():
    d = {
        'admins': [ 'foo', 'bar' ],
        'users': [ 'bob', 'joe' ],
        '_meta': {
            'hostvars': {
                'host1': {'name': 'foo1'},
                'host2': {'name': 'foo2'},
            }
        }
    }
    j = jsonify(d, format=True)
    print(j)

# Generated at 2022-06-23 05:12:52.523248
# Unit test for function jsonify
def test_jsonify():
    data = {
        'changed': False,
        'ping': 'pong',
        'reverse': 'nibithca',
        '_ansible_verbose_always': True,
        'foo': {
            'bar': 'baz',
            'quux': 'quuux',
        }
    }
    res = json.loads(jsonify(data))
    for key in res.keys():
        if key in data:
            assert(res[key] == data[key])

# Generated at 2022-06-23 05:12:59.788740
# Unit test for function jsonify
def test_jsonify():
    result = {
        "count": 3,
        "results": [
            {"_ansible_foo": "bar", "_ansible_no_log": True, "foo": "bar"},
            {"failed": True, "changed": True, "module_stdout": "Your console speaks UTF-8"}
        ]
    }
    assert jsonify(result) == "{\"count\": 3, \"results\": [{\"_ansible_foo\": \"bar\", \"foo\": \"bar\"}, {\"failed\": true, \"changed\": true}]}"

# Generated at 2022-06-23 05:13:10.787413
# Unit test for function jsonify
def test_jsonify():
    data = { 'vars': { 'key': [ 1, 2, 3], 'key2': [{'key3': 'value3'}] } }
    data_json = jsonify(data)
    assert data_json == '{"vars": {"key": [1, 2, 3], "key2": [{"key3": "value3"}]}}'
    data_json = jsonify(data, format=True)

# Generated at 2022-06-23 05:13:18.176383
# Unit test for function jsonify
def test_jsonify():
    result = {'a': ['foo', 'bar'], 'b': 'foo'}
    assert jsonify(result, format=False) == '{"a": ["foo", "bar"], "b": "foo"}'
    assert jsonify(result, format=True) == '''{
    "a": [
        "foo",
        "bar"
    ],
    "b": "foo"
}'''

# Generated at 2022-06-23 05:13:29.419250
# Unit test for function jsonify
def test_jsonify():
    res = "{"
    assert jsonify(None) == res,"jsonify returned: " + jsonify(None)
    assert jsonify("") == res,"jsonify returned: " + jsonify("")
    res = "{\"boom\": \"test\"}"
    assert jsonify("{\"boom\": \"test\"}") == res,"jsonify returned: " + jsonify("{\"boom\": \"test\"}")
    res = "{\n"
    assert jsonify("\n") == res,"jsonify returned: " + jsonify("\n")
    res = "{\"boom\": \"test\"}"
    assert jsonify("{\"boom\": \"test\"}") == res,"jsonify returned: " + jsonify("{\"boom\": \"test\"}")
    res = "{\n    \"boom\": \"test\"\n}"

# Generated at 2022-06-23 05:13:40.135462
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert '{}' == jsonify(None)
    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'})

    # test failure to decode
    assert "{\"failed\": true, \"parsed\": false}" == jsonify({'failed' : True, 'parsed' : False})

    # test with_items
    with_items = {'failed': False}
    with_items['msg'] = "All items completed"

# Generated at 2022-06-23 05:13:46.006843
# Unit test for function jsonify
def test_jsonify():
    assert('{"a": 1}' == jsonify({"a": 1}))
    assert('{"a": 1, "b": 2}' == jsonify({"a": 1, "b": 2}))
    assert('{"a": 1, "b": 2, "c": 3}' == jsonify({"a": 1, "b": 2, "c": 3}))
    assert('{"a": [1, 2, 3]}' == jsonify({"a": [1, 2, 3]}))

# Generated at 2022-06-23 05:13:52.360011
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=1, b=2, c=3, d=dict(e=4, f=5, g=6))
    assert jsonify(data, False) == "{\"a\": 1, \"b\": 2, \"c\": 3, \"d\": {\"e\": 4, \"f\": 5, \"g\": 6}}"
    assert jsonify(data, True) == """{
    "a": 1,
    "b": 2,
    "c": 3,
    "d": {
        "e": 4,
        "f": 5,
        "g": 6
    }
}"""

# Generated at 2022-06-23 05:13:59.772551
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo":"bar"}) == "{\"foo\": \"bar\"}"
    assert jsonify({"foo":"bar"}, format=True) == "{\n    \"foo\": \"bar\"\n}"
    assert jsonify(None) == "{}"
    assert jsonify({"_ansible_no_log": True, "results": []}) == "{\"results\": []}"
    assert jsonify(["\u6d4b\u8bd5"]) == "[\"\u6d4b\u8bd5\"]"

# Generated at 2022-06-23 05:14:07.769145
# Unit test for function jsonify
def test_jsonify():
    '''
    jsonify unit test
    '''
    output_formatted = jsonify({'a': 1, 'b': 12, 'c': 123}, format=True)
    assert output_formatted == '{\n    "a": 1, \n    "b": 12, \n    "c": 123\n}'

    output_unformatted = jsonify({'a': 1, 'b': 12, 'c': 123})
    assert output_unformatted == '{"a": 1, "b": 12, "c": 123}'

    output_unicode = jsonify({'unicode': 'ÇÂçÀ'})
    assert output_unicode == '{"unicode": "ÇÂçÀ"}'

# Generated at 2022-06-23 05:14:11.775011
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '{\n    "foo": "bar"\n}'
    # make sure None is converted to empty dict
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:14:18.061793
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('hello') == '"hello"'
    assert jsonify(1) == '1'
    assert jsonify(1.1) == '1.1'
    assert jsonify(True) == 'true'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-23 05:14:26.905196
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'Hello, World!',
        'b': 42,
        'c': [1, 2, 3]
    }

    assert jsonify(data, format=False) == '{"a": "Hello, World!", "b": 42, "c": [1, 2, 3]}'
    assert jsonify(data, format=True) == '{\n    "a": "Hello, World!", \n    "b": 42, \n    "c": [\n        1, \n        2, \n        3\n    ]\n}'

# Generated at 2022-06-23 05:14:33.405996
# Unit test for function jsonify
def test_jsonify():
    test = { 'foo': 'bar', 'asdf': [ 1, 2, 3 ] }
    assert jsonify(test, format=False) == '{"asdf": [1, 2, 3], "foo": "bar"}'
    assert jsonify(test) == '{\n    "asdf": [\n        1,\n        2,\n        3\n    ],\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:14:44.305863
# Unit test for function jsonify
def test_jsonify():
    # jsonify() accepts a single argument, result.
    # If result is None, it returns {}
    res = jsonify(None)
    exp = '{}'
    assert res == exp, "jsonify(None) returned: %s, expected: %s" % (res, exp)

    # If result is NOT None, it is serialized as JSON.
    res = jsonify({'a':'b'})
    exp = '{"a": "b"}'
    assert res == exp, "jsonify({'a':'b'}) returned: %s, expected: %s" % (res, exp)

    # The format argument may be set to True to indent the JSON.
    res = jsonify({'a':'b'}, format=True)
    exp = """{
    "a": "b"
}"""

# Generated at 2022-06-23 05:14:50.872866
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify([1, 2, 3], True) == '[\n    1, \n    2, \n    3\n]'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify({'foo': 'bar'}, True) == '{\n    "foo": "bar"\n}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-23 05:14:58.637527
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.json_utils as json_utils

    module = AnsibleModule(argument_spec={})

    if not hasattr(json_utils, 'jsonify'):
        module.fail_json(msg="jsonify() function does not exist")

    result = dict(ansible_facts=dict(test_var=dict(test_var_key='test_var_result')))

    res = module.from_json(json_utils.jsonify(result))

    if not isinstance(res, dict):
        module.fail_json(msg="jsonify() did not return a dict")


# Generated at 2022-06-23 05:15:03.042829
# Unit test for function jsonify
def test_jsonify():
    ''' test for function jsonify '''

    # jsonify empty result
    j = jsonify(None)
    # assert that j is empty string
    assert j == "{}"

    # jsonify result with dict
    j = jsonify({'test':True}, True)
    # assert that j contains key test
    assert 'test' in j

# Generated at 2022-06-23 05:15:11.690791
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open

    TEST_STR = u'{"foo": "bar", "baz": "qux"}'
    TEST_DICT = json.loads(TEST_STR)
    TEST_BYTES = TEST_STR.encode('utf-8')

    class JsonifyTestCase(unittest.TestCase):

        def setUp(self):
            self.mock_open_patcher = patch('ansible.parsing.ajson.open', new_callable=mock_open, read_data=TEST_BYTES)
            self.mock_open = self.mock_open_patcher.start()

# Generated at 2022-06-23 05:15:17.861769
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify should return valid json, except for None '''
    from ansible.utils import jsonify
    from nose.plugins.skip import SkipTest

    try:
        jsonify({})
    except:
        raise SkipTest

    assert jsonify({}) == '{}'

    # while None is not json-serializable, we should still return a string
    # and not an exception
    assert jsonify(None) == '{}'

# FIXME: is this still used?

# Generated at 2022-06-23 05:15:25.765953
# Unit test for function jsonify
def test_jsonify():
    inner_inner_dict = { 'inner_key1': 'inner_value1'}
    inner_dict = { 'inner_key2': inner_inner_dict}
    test_dict = { 'key1': 'value1', 'key2': inner_dict, 'key3': [1, 2, 'a', 'b', inner_dict]}
    assert jsonify(test_dict) == '{"key1": "value1", "key2": {"inner_key2": {"inner_key1": "inner_value1"}}, "key3": [1, 2, "a", "b", {"inner_key2": {"inner_key1": "inner_value1"}}]}'
    assert jsonify(None) == '{}'


# Generated at 2022-06-23 05:15:28.935863
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'
    assert jsonify(dict(foo=dict(bar='baz'))) == '{"foo": {"bar": "baz"}}'

# Generated at 2022-06-23 05:15:39.582032
# Unit test for function jsonify
def test_jsonify():

    # Testing indent handling
    assert jsonify({'a': 1, 'b': 2}, format=False) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '{\n    "a": 1, \n    "b": 2\n}'

    # Testing None handling
    assert jsonify(None, format=False) == "{}"
    assert jsonify(None, format=True) == "{}"

    # Testing to ensure unicode characters are escaped
    # \xe2\x9c\x93 is the unicode version of the check mark
    unicode_mark = u'\xe2\x9c\x93'
    assert jsonify({'a': unicode_mark}, format=False) == '{"a": "\\u2713"}'


# Generated at 2022-06-23 05:15:40.883741
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:15:49.717154
# Unit test for function jsonify
def test_jsonify():

    test_dict = {'a': ["a1", "a2", "a3"],
                 'b': 2,
                 'c': 3.14,
                 'd': 'dddd',
                 'e': ['e1', 'e2', 'e3', {'e31': 'e31'}, {'e32': 'e32'}],
                 'f': True,
                 }
    test_str = jsonify(test_dict)
    test_str_json = json.dumps(test_dict)

    assert test_str == test_str_json
    # test no sort
    assert jsonify(1) == '1'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == '{}'

# Generated at 2022-06-23 05:15:54.629777
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(None) == "{}")
    assert(jsonify({'a': '1'}) == "{\"a\": \"1\"}")
    assert(jsonify({'a': '1', 'b': '2'}) == "{\"a\": \"1\", \"b\": \"2\"}")

# Generated at 2022-06-23 05:16:00.585103
# Unit test for function jsonify
def test_jsonify():
    result = {'a':1,'b':2,'c':3}
    assert jsonify(result) == '{"a":1,"b":2,"c":3}'
    assert jsonify(result, True) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert jsonify(None) == "{}"

# Generated at 2022-06-23 05:16:04.034391
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'key': 'value'}) == '{"key": "value"}'
    assert jsonify({u'unicode': u'unicode'}) == '{"unicode": "unicode"}'

# Generated at 2022-06-23 05:16:10.868678
# Unit test for function jsonify
def test_jsonify():
    # jsonify(None) -> {}
    assert jsonify(None) == "{}"

    # jsonify(None, True) -> {}
    assert jsonify(None, True) == "{}"

    # jsonify(dict()) -> "{}"
    assert jsonify({}) == "{}"

    # jsonify(dict(), True) -> "{\n}"
    assert jsonify({}, True) == "{\n}"

    # jsonify(dict(a=1)) -> "{\"a\": 1}"
    assert jsonify(dict(a=1)) == "{\"a\": 1}"

    # jsonify(dict(a=1), True) -> "{\n    \"a\": 1\n}"
    assert jsonify(dict(a=1), True) == "{\n    \"a\": 1\n}"

# Generated at 2022-06-23 05:16:23.326328
# Unit test for function jsonify
def test_jsonify():

    result = { 'ansible_facts': {u'foo': 1}}
    assert jsonify(result) == '{"ansible_facts":{"foo":1}}'

# Taken from: http://docs.python.org/2/library/unittest.html
if __name__ == '__main__':
    import unittest

    class JsonifyTests(unittest.TestCase):

        def test_jsonify(self):
            self.assertEqual(jsonify(None), '{}')
            self.assertEqual(jsonify({ 'ansible_facts': {u'foo': 1}}), '{"ansible_facts":{"foo":1}}')

# Load test suite
    tests = unittest.TestLoader().loadTestsFromTestCase(JsonifyTests)

 # Run test suite

# Generated at 2022-06-23 05:16:26.582011
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}, format=True) == '''{
    "foo": "bar"
}'''

# Generated at 2022-06-23 05:16:28.004295
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify({"a": 1}) == '{"a": 1}')

# Generated at 2022-06-23 05:16:34.138954
# Unit test for function jsonify
def test_jsonify():
    x = jsonify(dict(foo='bar'))
    y = jsonify(dict(foo='bar'), True)
    assert x == '{"foo": "bar"}'
    assert x != '{\n    "foo": "bar"\n}'
    assert y == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-23 05:16:43.069433
# Unit test for function jsonify
def test_jsonify():

    result = None
    assert jsonify(result) == "{}"

    result = { 'a': 'b' }
    assert jsonify(result) == '{"a": "b"}'

    result['c'] = ['123', 'xyz']
    assert jsonify(result) == '{"a": "b", "c": ["123", "xyz"]}'

    result['c'] = { 'd': 'e', 'f': 'g' }
    assert jsonify(result) == '{"a": "b", "c": {"d": "e", "f": "g"}}'

    result = { 'a': 'b', 'c': { 'd': 'e', 'f': 'g' } }

# Generated at 2022-06-23 05:16:54.515561
# Unit test for function jsonify
def test_jsonify():
    # result is None should return {} 
    assert jsonify(None) == "{}"

    # regular dictionary, with format
    j_text = jsonify({'key1': ['val1']}, format=True)
    assert j_text == '{\n    "key1": [\n        "val1"\n    ]\n}'

    # regular dictionary, without format
    j_text = jsonify({'key1': ['val1']}, format=False)
    assert j_text == '{"key1": ["val1"]}'

    # UnicodeDecodeError should be caught and ensure_ascii=False
    try:
        jsonify({'key1': ['val1', 'v\xe9']}, format=False)
    except UnicodeEncodeError:
        assert False

# Generated at 2022-06-23 05:16:56.987348
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': [1,2,3]}) == '{"a": [1, 2, 3]}'


# Generated at 2022-06-23 05:17:02.143783
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify([])) == "[]"
    assert (jsonify(None)) == "{}"
    assert (jsonify([1, 2, 3])) == "[1, 2, 3]"

# ---- the following is used by the test harness to help it discover this file and load it's UnitTests ----

# Generated at 2022-06-23 05:17:13.208472
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"  # Not exactly the same as above, but equivalent output

    # Dictionary
    test_dict = {
        'unicode': u'\u20ac',
        'int': 1,
        'false': False,
        'null': None,
    }
    assert jsonify(test_dict) == '''{
    "false": false,
    "int": 1,
    "null": null,
    "unicode": "\\u20ac"
}'''

    # List
    test_list = [u'\u20ac', 1, False, None]
    assert jsonify(test_list) == '''[
    "\\u20ac",
    1,
    false,
    null
]'''

    # OrderedDict

# Generated at 2022-06-23 05:17:20.612773
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['test']) == '["test"]'
    assert jsonify(['test'], True) == '''[\n    "test"\n]'''
    assert jsonify(dict(test='test'), True) == '''{\n    "test": "test"\n}'''
    assert jsonify(dict(test=[dict(name='test'), dict(name='test2')]), True) == '''{\n    "test": [\n        {\n            "name": "test"\n        }, \n        {\n            "name": "test2"\n        }\n    ]\n}'''

# Generated at 2022-06-23 05:17:22.077589
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({1:2})
    assert jsonify({'test':'passed'}, True)

# Generated at 2022-06-23 05:17:32.084922
# Unit test for function jsonify
def test_jsonify():
    print("testing jsonify()")

    results = []

    results.append( jsonify( json.loads('{"changed": false, "ping": "pong"}') ) )
    results.append( json.dumps( json.loads('{"changed": false, "ping": "pong"}'), sort_keys=True, indent=4 ) )
    results[0] == results[1]

    results.append( jsonify( json.loads('{"changed": false, "ping": "pong"}'), True) )
    results.append( json.dumps( json.loads('{"changed": false, "ping": "pong"}'), sort_keys=True, indent=4 ) )
    results[2] == results[3]

    results.append( jsonify( json.loads('{"changed": false, "ping": "pong"}'), False) )

# Generated at 2022-06-23 05:17:36.646722
# Unit test for function jsonify
def test_jsonify():
    assert "{}" == jsonify(None)
    assert json.loads("{}") == json.loads(jsonify(None))
    assert json.loads('{"a": 3}') == json.loads(jsonify({"a": 3}))

# UnitTest class to use with unittest framework

# Generated at 2022-06-23 05:17:39.888306
# Unit test for function jsonify
def test_jsonify():
    result = dict(changed=False, rc=5)
    assert jsonify(result, format=True) == '{\n    "changed": false, \n    "rc": 5\n}'

# Generated at 2022-06-23 05:17:50.383579
# Unit test for function jsonify
def test_jsonify():

    result = { 'user' : { 'name' : 'Joe' } }

    assert jsonify(result) == '{"user": {"name": "Joe"}}'
    assert jsonify(result, True) == '''{
    "user": {
        "name": "Joe"
    }
}'''

    result = [{ 'name' : 'Joe' }, { 'name' : 'Jeff' }]

    assert jsonify(result) == '[{"name": "Joe"}, {"name": "Jeff"}]'
    assert jsonify(result, True) == '''[
    {
        "name": "Joe"
    },
    {
        "name": "Jeff"
    }
]'''

# Generated at 2022-06-23 05:17:52.017868
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'

# Generated at 2022-06-23 05:18:03.807489
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'b'}, format=True) == '{\n    "a": "b"\n}'
    assert jsonify(['a', 'b'], format=True) == '[\n    "a", \n    "b"\n]'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert jsonify(['a', 'b', 'c', 'd']) == '["a", "b", "c", "d"]'

# Generated at 2022-06-23 05:18:15.242483
# Unit test for function jsonify
def test_jsonify():
    from ansible import constants
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    Obj1 = AnsibleUnsafeText(u"some text")

    args = {'host': Obj1, 'result': {'hello': 'world'}, 'format': False}
    result = jsonify(**args)
    assert result == "{\"host\": \"some text\", \"result\": {\"hello\": \"world\"}}"

    args['format'] = True
    result = jsonify(**args)
    assert result == """{
    \"host\": \"some text\",
    \"result\": {
        \"hello\": \"world\"
    }
}"""

    args['result'] = None
    result = jsonify(**args)
    assert result == "{}"

# Generated at 2022-06-23 05:18:27.148778
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == '{}'

    result = { "foo": "bar" }
    assert jsonify(result) == '{"foo": "bar"}'
    assert jsonify(result, True) == "{\n    \"foo\": \"bar\"\n}"

    assert jsonify({"some_key": { "inner_key": "foo", "inner_key2": "bar" }}, True) == """{
    \"some_key\": {
        \"inner_key\": \"foo\",
        \"inner_key2\": \"bar\"
    }
}"""


# Generated at 2022-06-23 05:18:39.561534
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify(None, format=True) == '{}'
    assert jsonify({'b':1,'a':2}) == '{"a": 2, "b": 1}'
    assert jsonify({'a':2,'b':1}, format=True) == '{\n    "a": 2, \n    "b": 1\n}'
    assert jsonify({'a':2,'b':1}, format=True) == '{\n    "a": 2, \n    "b": 1\n}'
    assert jsonify({u"\u4e2d":u"\u56fd"}) == u'{"\u4e2d": "\u56fd"}'

# Generated at 2022-06-23 05:18:41.390670
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'key': 'value'}, True) == '{\n    "key": "value"\n}'

# Generated at 2022-06-23 05:18:43.767258
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo="bar")) == '{"foo": "bar"}'

# TODO: test jsonify with non-ascii characters

# Generated at 2022-06-23 05:18:54.265852
# Unit test for function jsonify
def test_jsonify():
    def test():
        assert jsonify(None) == '{}'
        assert jsonify({}) == '{}'
        assert jsonify({'a': 1}) == '{"a": 1}'
        assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
        assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'
        assert jsonify(['a', 'b', 'c', ['d', 'e', 'f']]) == '["a", "b", "c", ["d", "e", "f"]]'

# Generated at 2022-06-23 05:18:59.503434
# Unit test for function jsonify
def test_jsonify():
    ''' unit test for function jsonify '''

    d = { 'a': 4, 'b': 5 }
    assert jsonify(d, False) == '{"a": 4, "b": 5}'
    assert jsonify(d, True) == '{\n    "a": 4, \n    "b": 5\n}'

# Generated at 2022-06-23 05:19:04.560411
# Unit test for function jsonify
def test_jsonify():
    ''' jsonify returns a JSON string of the best format possible '''
    assert isinstance(jsonify({}), str)

if __name__ == '__main__':
    import sys
    import doctest
    (failure_count, test_count) = doctest.testmod()
    sys.exit(failure_count)

# Generated at 2022-06-23 05:19:15.706778
# Unit test for function jsonify
def test_jsonify():
    from StringIO import StringIO
    from ansible.utils.jsonify import jsonify

    in_data = dict(spam='eggs', foo='bar', baz=[1,2,3,4])

    # Test format=False
    out_data = jsonify(in_data, False)
    assert isinstance(out_data, basestring)
    assert out_data == '{"baz": [1, 2, 3, 4], "foo": "bar", "spam": "eggs"}'

    # Test format=True
    out_data = StringIO()
    result = jsonify(in_data, True)
    assert isinstance(result, basestring)

# Generated at 2022-06-23 05:19:27.944503
# Unit test for function jsonify
def test_jsonify():
    result_original = {
        u'test_u': u'value_u',
        'test': 'value',
        'test_l': [3, 2, 1],
        'test_l_u': [u'3', u'2', u'1'],
        'test_d': {'a': 'A'},
        'test_d_u': {u'a': u'A'}
    }

    result_with_ascii = {
        'test_d': {
            'a' : 'A'
        },
        'test_l': [
            3,
            2,
            1
        ],
        'test': 'value',
        'test_u': u'value_u',
    }


# Generated at 2022-06-23 05:19:31.457145
# Unit test for function jsonify
def test_jsonify():
    test_result = {'a': 'fish'}
    assert jsonify(test_result) == '{"a": "fish"}'

# Generated at 2022-06-23 05:19:33.782154
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({1:2}) == '{\n    "1": 2\n}'



# Generated at 2022-06-23 05:19:42.067558
# Unit test for function jsonify
def test_jsonify():
    d = { "key" : "value", "list" : [1,2,3,4], "dict" : { "k" : "v" } }
    assert jsonify(d, False) == "{\"dict\": {\"k\": \"v\"}, \"list\": [1, 2, 3, 4], \"key\": \"value\"}"
    assert jsonify(d, True) == '''{
    "dict": {
        "k": "v"
    },
    "list": [
        1,
        2,
        3,
        4
    ],
    "key": "value"
}'''

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-23 05:19:52.002515
# Unit test for function jsonify
def test_jsonify():
    ''' ensure jsonify works as expected '''

    # Tests for None type input
    res = jsonify(None)
    assert res == '{}'

    # Tests for jsonify/serializing complex object with datetime
    from datetime import datetime
    from collections import namedtuple

    D_T_Str = str(datetime.now()) # '2014-05-01 00:00:00'
    D_T_Obj = datetime.strptime(D_T_Str, '%Y-%m-%d %H:%M:%S')
    ExampleObject = namedtuple('ExampleObject', 't d0 d1 d2')

# Generated at 2022-06-23 05:20:02.310798
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2}, format=True) == '''{
    "a": 1,
    "b": 2
}'''
    assert jsonify({'a': {'b': {'c': 'd'}}}, format=True) == '''{
    "a": {
        "b": {
            "c": "d"
        }
    }
}'''
    assert jsonify(['a', 'b', {'a': 1, 'b': 2}]) == '["a", "b", {"a": 1, "b": 2}]'

# Generated at 2022-06-23 05:20:04.505311
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify({'a': 'a'}) == '{"a": "a"}'

# Generated at 2022-06-23 05:20:11.528678
# Unit test for function jsonify
def test_jsonify():
    # assert with no indent
    result = { "foo": { "bar": "baz" } }
    data = jsonify(result, False)
    assert data == '{"foo": {"bar": "baz"}}'
    # assert with indent
    data = jsonify(result, True)
    assert data == '{\n    "foo": {\n        "bar": "baz"\n    }\n}'
    # assert with None
    result = None
    data = jsonify(result, False)
    assert data == '{}'

# TODO: test running jsonify(foo, True) where foo has a unicode string

# Generated at 2022-06-23 05:20:13.862832
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == '{}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'

# Generated at 2022-06-23 05:20:21.952500
# Unit test for function jsonify
def test_jsonify():

    assert jsonify(None) == "{}"

    assert '"a": 1' in jsonify({'a': 1})
    assert "'a': 1" in jsonify({'a': 1}, True)

    assert '"a": [1, 2, 3]' in jsonify({'a': [1,2,3]})
    assert "'a': [1, 2, 3]" in jsonify({'a': [1,2,3]}, True)

    assert '"a": {' in jsonify({'a': {'b': 2}})
    assert "'a': {" in jsonify({'a': {'b': 2}}, True)

# Generated at 2022-06-23 05:20:30.069375
# Unit test for function jsonify
def test_jsonify():
    # Test with None as input
    assert jsonify(None) == '{}'
    # Test with a list as input
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # Test with an int as input
    assert jsonify(42) == '42'
    # Test with a string as input
    assert jsonify("Ansible") == '"Ansible"'

# Test the function
if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-23 05:20:35.237711
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(False) == 'false'
    assert jsonify(True) == 'true'
    assert jsonify(None) == '{}'
    assert jsonify(77) == '77'
    assert jsonify('two words') == '"two words"'
    assert jsonify({'a': 'b', 'c': [1,2,3]}) == '{"a": "b", "c": [1, 2, 3]}'

# Generated at 2022-06-23 05:20:42.609426
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == "{}"
    assert jsonify(True) == "true"
    assert jsonify(False) == "false"
    assert jsonify({"a":1,"b":2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a":1,"b":2}.items()) == '[[1, "a"], [2, "b"]]'
    assert jsonify(["a",1,2]) == '["a", 1, 2]'

# ===========================================


# Generated at 2022-06-23 05:20:54.103785
# Unit test for function jsonify
def test_jsonify():
    int_result = {"test_int": 1}
    int_result_a = {"test_int": 1}
    str_result = {"test_str": "foo"}
    str_result_a = {"test_str": "foo"}
    list_result = {"test_list": [1, 2, 3]}
    list_result_a = {"test_list": [1, 2, 3]}
    dict_result = {"test_dict": {"foo": "bar"}}
    dict_result_a = {"test_dict": {"foo": "bar"}}
    dict_result_b = {"test_dict": {"foo": "bar"}}
    dict_result_c = {"test_dict": {"foo": "bar"}}

    assert jsonify(int_result) == jsonify(int_result_a)

# Generated at 2022-06-23 05:20:58.880741
# Unit test for function jsonify
def test_jsonify():
    assert json.loads(jsonify({'a':1, 'b':2})) == {'a':1, 'b':2}
    assert json.loads(jsonify({'a':1, 'b':2}, format=True)) == {'a':1, 'b':2}
    assert json.loads(jsonify(None)) == {}
    assert json.loads(jsonify(None, format=True)) == {}

# Generated at 2022-06-23 05:21:08.365488
# Unit test for function jsonify
def test_jsonify():

    testdata = {
        'name': 'foobar',
        'details': {
            'ip': ['192.168.1.1', '192.168.1.2', '192.168.1.3'],
            'uptime': 78,
        },
    }
    testresult = jsonify(testdata, format=False)
    # No assert, just make sure it doesn't error out
    assert(True)


if __name__ == "__main__":
    # import doctest
    # doctest.testmod()
    # Running jsonify test separately to avoid output
    test_jsonify()

# Generated at 2022-06-23 05:21:19.675500
# Unit test for function jsonify
def test_jsonify():
    testvalue = {
        '1':{'1':'1','2':'2'},
        '2':'two',
        '3':3,
        '4':[1,2,3,4]
    }
    assert jsonify(testvalue, True) == '{\n    "1": {\n        "1": "1", \n        "2": "2"\n    }, \n    "2": "two", \n    "3": 3, \n    "4": [\n        1, \n        2, \n        3, \n        4\n    ]\n}'
    assert jsonify(testvalue, False) == '{"1": {"1": "1", "2": "2"}, "2": "two", "3": 3, "4": [1, 2, 3, 4]}'